package com.santander.globile.app.views.serviceinvocationlib.repository

import com.santander.globile.app.views.serviceinvocationlib.interactors.RandomUsersInteractor
import com.santander.globile.app.views.serviceinvocationlib.interfaces.RandomUsersApi
import com.santander.globile.app.views.serviceinvocationlib.model.ErrorMessage
import com.santander.globile.app.views.serviceinvocationlib.model.ResultsContainer
import com.santander.globile.serviceinvocationlib.client.ApiClient

class RandomUsersRepository {

    val BASE_URL = "https://api.randomuser.me"

    val DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss"

    fun getRandomUsers(callback: RandomUsersCallback){
        val apiClient = ApiClient.Builder(BASE_URL).datePattern(DATE_PATTERN).build()

        val peopleInteractor = RandomUsersInteractor(apiClient.createService(RandomUsersApi::class.java))

        peopleInteractor.getRandomUsers{ results , error ->
            if (results != null){
                callback.onUsersSuccess(results)
            }

            if (error != null){
                callback.onError(error)
            }
        }
    }

    interface RandomUsersCallback {
        fun onUsersSuccess(users: ResultsContainer)
        fun onError(errorResponse: ErrorMessage?)
    }
}