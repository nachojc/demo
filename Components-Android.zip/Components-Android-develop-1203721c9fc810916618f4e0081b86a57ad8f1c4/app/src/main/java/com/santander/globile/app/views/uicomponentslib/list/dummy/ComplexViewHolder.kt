package com.santander.globile.app.views.uicomponentslib.list.dummy

import android.support.v7.widget.RecyclerView
import android.view.View
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericBinder
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener

class ComplexViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), GlobileGenericBinder<Any> {
    override fun bind(data: Any, listener: GlobileRecyclerListener<Any>?) {

    }

}