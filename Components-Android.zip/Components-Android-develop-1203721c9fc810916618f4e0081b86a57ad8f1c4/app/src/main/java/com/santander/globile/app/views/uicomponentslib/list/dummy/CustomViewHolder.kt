package com.santander.globile.app.views.uicomponentslib.list.dummy

import android.support.v7.widget.RecyclerView
import android.view.View
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericBinder
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener
import kotlinx.android.synthetic.main.custom_row.view.*

class CustomViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), GlobileGenericBinder<Any> {
    override fun bind(data: Any, listener: GlobileRecyclerListener<Any>?) {
        itemView?.let {view ->
            view.setOnClickListener{
                listener?.onClickListener(data,view,0)
            }
            view.button_edit.setOnClickListener {
                listener?.onClickListener(data,view,1)
            }
            view.button_close.setOnClickListener {
                listener?.onClickListener(data,view,2)
            }
        }
    }

}