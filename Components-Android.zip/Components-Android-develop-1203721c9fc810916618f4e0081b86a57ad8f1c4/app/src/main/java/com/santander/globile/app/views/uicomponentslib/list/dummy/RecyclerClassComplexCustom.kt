package com.santander.globile.app.views.uicomponentslib.list.dummy

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericRecyclerAdapter
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener
import kotlinx.android.synthetic.main.fragment_recycler_cards.*


class RecyclerClassComplexCustom: Fragment() , GlobileRecyclerListener<Any> {

    companion object {
        fun newInstance(): RecyclerClassComplexCustom {
            return RecyclerClassComplexCustom()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_recycler_cards, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val dummyList = ArrayList<Any>()
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())





        val customAdapter = object : GlobileGenericRecyclerAdapter<Any>(dummyList,this) {
            override fun getLayoutId(position: Int, obj: Any): Int {
               return when(position){
                    0->R.layout.example_row1
                    1->R.layout.example_row2
                    2->R.layout.example_row3
                   else -> R.layout.example_row1
               }
            }

            override fun getViewHolder(view: View, viewType: Int): RecyclerView.ViewHolder {
                return ComplexViewHolder(view)
            }
        }

        component_recycler_test1.layoutManager = LinearLayoutManager(context)
        component_recycler_test1.adapter = customAdapter

        component_recycler_test2.layoutManager = LinearLayoutManager(context)
        component_recycler_test2.adapter = customAdapter

        component_recycler_test3.layoutManager = LinearLayoutManager(context)
        component_recycler_test3.adapter = customAdapter


    }

    override fun onClickListener(data: Any, v: View, code: Int) {
    }
}
