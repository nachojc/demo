package com.santander.globile.app.views.uicomponentslib.tabs

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.views.uicomponentslib.pagecontroller.PageControllerFragment
import com.santander.globile.app.views.uicomponentslib.tabbar.TabBarFragment
import com.santander.globile.app.views.uicomponentslib.textinputlayout.GlobalInputTextLayoutFragment
import com.santander.globile.uicomponents.tablayout.GlobileBaseFragmentTabsAdapter
import com.santander.globile.uicomponents.tablayout.data.GlobileTab
import com.santander.globile.uicomponents.tablayout.data.GlobileTabsAdapterData
import kotlinx.android.synthetic.main.fragment_tabs.*

class TabsLayoutFragment : Fragment() {
    companion object {
        fun newInstance(): TabsLayoutFragment {
            return TabsLayoutFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_tabs, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val tab1 = GlobileTab(R.string.tabs_tab1, R.drawable.ic_nav, GlobalInputTextLayoutFragment.newInstance())
        val tab2 = GlobileTab(R.string.tabs_tab2, null, TabBarFragment.newInstance())
        val tab3 = GlobileTab(R.string.tabs_tab3, null, PageControllerFragment.newInstance())

        val tabList = ArrayList<GlobileTab>()
        tabList.add(tab1)
        tabList.add(tab2)
        tabList.add(tab3)

        val tabAdapterData = GlobileTabsAdapterData(tabList)

        val adapterTabs =
            activity?.supportFragmentManager?.let {
                GlobileBaseFragmentTabsAdapter(it, context!!, tabAdapterData)
            }

        viewpager.adapter = adapterTabs
        tabLayout.setupWithViewPager(viewpager)

    }
}