package com.santander.globile.app.views.uicomponentslib.list.dummy

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.uicomponents.list.simple.adapter.GlobileSimpleRecyclerAdapter
import com.santander.globile.uicomponents.list.simple.data.SimpleData
import kotlinx.android.synthetic.main.fragment_recycler_test.*


class RecyclerClassSimple: Fragment() {

    companion object {
        fun newInstance(): RecyclerClassSimple {
            return RecyclerClassSimple()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_recycler_test, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val list = ArrayList<SimpleData>()
        val simpledata1 = SimpleData("hola", "hola")
        val simpledata2 = SimpleData("adios", "adios")
        val simpledata3 = SimpleData("hola3", "hola3")
        val simpledata4 = SimpleData("hola4", "hola4")

        list.add(simpledata1)
        list.add(simpledata2)
        list.add(simpledata3)
        list.add(simpledata4)

        component_recycler_test.layoutManager = LinearLayoutManager(context)
        component_recycler_test.adapter = GlobileSimpleRecyclerAdapter(list)

    }
}
