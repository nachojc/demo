package com.santander.globile.app.views.uicomponentslib.icons

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatDelegate
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.uicomponents.image.icon.BadgeType
import com.santander.globile.uicomponents.image.icon.IconColor
import com.santander.globile.uicomponents.image.icon.IconSize
import kotlinx.android.synthetic.main.fragment_icons.*

class IconsFragment: Fragment() {

    companion object {
        fun newInstance(): IconsFragment {
            return IconsFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        return inflater?.inflate(R.layout.fragment_icons, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //Fila 1
        icon_1_1.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.SMALL)

        icon_1_2.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.MEDIUM)

        icon_1_3.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.BIG)


        icon_2_1.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.SMALL)

        icon_2_2.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.MEDIUM)

        icon_2_3.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.BIG)


        icon_3_1.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.SMALL)

        icon_3_2.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.MEDIUM)

        icon_3_3.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.BIG)


        //Fila 2
        icon_4_1.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.SMALL)
        icon_4_1.setBadge(0, BadgeType.PRIMARY, IconSize.SMALL)

        icon_4_2.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.MEDIUM)
        icon_4_2.setBadge(0, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_4_3.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.BIG)
        icon_4_3.setBadge(0, BadgeType.PRIMARY, IconSize.BIG)


        icon_5_1.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.SMALL)
        icon_5_1.setBadge(0, BadgeType.PRIMARY, IconSize.SMALL)

        icon_5_2.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.MEDIUM)
        icon_5_2.setBadge(0, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_5_3.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.BIG)
        icon_5_3.setBadge(0, BadgeType.PRIMARY, IconSize.BIG)


        icon_6_1.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.SMALL)
        icon_6_1.setBadge(0, BadgeType.SECONDARY, IconSize.SMALL)

        icon_6_2.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.MEDIUM)
        icon_6_2.setBadge(0, BadgeType.SECONDARY, IconSize.MEDIUM)

        icon_6_3.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.BIG)
        icon_6_3.setBadge(0, BadgeType.SECONDARY, IconSize.BIG)


        //Fila 3
        icon_7_1.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.SMALL)
        icon_7_1.setBadge(5, BadgeType.PRIMARY, IconSize.SMALL)

        icon_7_2.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.MEDIUM)
        icon_7_2.setBadge(5, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_7_3.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.BIG)
        icon_7_3.setBadge(5, BadgeType.PRIMARY, IconSize.BIG)


        icon_8_1.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.SMALL)
        icon_8_1.setBadge(5, BadgeType.PRIMARY, IconSize.SMALL)

        icon_8_2.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.MEDIUM)
        icon_8_2.setBadge(5, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_8_3.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.BIG)
        icon_8_3.setBadge(5, BadgeType.PRIMARY, IconSize.BIG)


        icon_9_1.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.SMALL)
        icon_9_1.setBadge(5, BadgeType.SECONDARY, IconSize.SMALL)

        icon_9_2.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.MEDIUM)
        icon_9_2.setBadge(5, BadgeType.SECONDARY, IconSize.MEDIUM)

        icon_9_3.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.BIG)
        icon_9_3.setBadge(5, BadgeType.SECONDARY, IconSize.BIG)


        //Fila 4
        icon_10_1.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.SMALL)
        icon_10_1.setBadge(55, BadgeType.PRIMARY, IconSize.SMALL)

        icon_10_2.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.MEDIUM)
        icon_10_2.setBadge(55, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_10_3.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.BIG)
        icon_10_3.setBadge(55, BadgeType.PRIMARY, IconSize.BIG)


        icon_11_1.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.SMALL)
        icon_11_1.setBadge(55, BadgeType.PRIMARY, IconSize.SMALL)

        icon_11_2.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.MEDIUM)
        icon_11_2.setBadge(55, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_11_3.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.BIG)
        icon_11_3.setBadge(55, BadgeType.PRIMARY, IconSize.BIG)


        icon_12_1.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.SMALL)
        icon_12_1.setBadge(55, BadgeType.SECONDARY, IconSize.SMALL)

        icon_12_2.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.MEDIUM)
        icon_12_2.setBadge(55, BadgeType.SECONDARY, IconSize.MEDIUM)

        icon_12_3.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.BIG)
        icon_12_3.setBadge(55, BadgeType.SECONDARY, IconSize.BIG)


        //Fila 5
        icon_13_1.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.SMALL)
        icon_13_1.setBadge(555, BadgeType.PRIMARY, IconSize.SMALL)

        icon_13_2.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.MEDIUM)
        icon_13_2.setBadge(555, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_13_3.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.BIG)
        icon_13_3.setBadge(555, BadgeType.PRIMARY, IconSize.BIG)


        icon_14_1.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.SMALL)
        icon_14_1.setBadge(555, BadgeType.PRIMARY, IconSize.SMALL)

        icon_14_2.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.MEDIUM)
        icon_14_2.setBadge(555, BadgeType.PRIMARY, IconSize.MEDIUM)

        icon_14_3.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.BIG)
        icon_14_3.setBadge(555, BadgeType.PRIMARY, IconSize.BIG)


        icon_15_1.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.SMALL)
        icon_15_1.setBadge(555, BadgeType.SECONDARY, IconSize.SMALL)

        icon_15_2.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.MEDIUM)
        icon_15_2.setBadge(555, BadgeType.SECONDARY, IconSize.MEDIUM)

        icon_15_3.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.BIG)
        icon_15_3.setBadge(555, BadgeType.SECONDARY, IconSize.BIG)

    }
}