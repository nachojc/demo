package com.santander.globile.app.views.main

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.model.Component
import com.santander.globile.app.utils.replaceFragment
import com.santander.globile.uicomponents.actionbar.GlobileActionBarActivity
import com.santander.globile.uicomponents.optionselection.dropdown.data.DropDownData
import com.santander.globile.uicomponents.optionselection.dropdown.listener.OnItemSelectedListener
import kotlinx.android.synthetic.main.fragment_core_components.*

class FragmentCoreComponents : Fragment(){
    companion object {
        fun newInstance(): FragmentCoreComponents {
            return FragmentCoreComponents()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_core_components, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val itemList = mutableListOf<DropDownData<Component>>()

       arguments?.let {
            Component.getComponentList(context, it.getInt("id"))
        }?.forEach {
            it.componentName?.let { name ->
                itemList.add(DropDownData(name,it))
            }
        }

        setTopDropdownParams(itemList, -1)

    }

    private fun setTopDropdownParams(itemsList: List<DropDownData<Component>>, initialSelection: Int) {
        core_dropdown.setGlobileDropdown(itemsList, initialSelection, object : OnItemSelectedListener<Component> {
            override fun onItemSelected(item: DropDownData<Component>) {
                if(item.key.isEmpty()){
                    fragment_content.visibility = View.GONE
                }else {
                    val fragment = item.value?.fragment
                    val componentName = item.value?.componentName
                    fragment?.let {
                        (activity as GlobileActionBarActivity).replaceFragment(
                            it,
                            R.id.fragment_content, componentName, false
                        )
                    }
                    fragment_content.visibility = View.VISIBLE
                }
            }

            override fun onNothingSelected() {

            }
        })
    }

}