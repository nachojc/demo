package com.santander.globile.app.views.uicomponentslib.alertbar

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import com.santander.globile.app.R
import com.santander.globile.uicomponents.alertbar.GlobileAlertBarListener
import com.santander.globile.uicomponents.alertbar.showGlobileAlertBar
import kotlinx.android.synthetic.main.activity_alertbar_with_toolbar.*

class AlertBarWithToolbarActivity: Activity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_alertbar_with_toolbar)
        setTheme(com.santander.globile.uicomponents.R.style.GlobileTheme_Red)

        val message = "The <b><font color=#EC0000>AlertBar</font></b> appears at top of this <b><font color=#EC0000>Activity</font></b> below <b><font color=#EC0000>custom toolbar</font></b>."
        val label = "ACTION"

        show_alert_button_activity.setOnClickListener {
            showGlobileAlertBar(R.id.custom_toolbar, message, label, object : GlobileAlertBarListener {
                override fun onActionPressed() {
                    Toast.makeText(applicationContext, "label clicked in Activity", Toast.LENGTH_SHORT).show()
                }

                override fun onDismissPressed() {
                    Toast.makeText(applicationContext, "cancel tapped in Activity", Toast.LENGTH_SHORT).show()
                }
            })

        }

        close_activity_button.setOnClickListener {
            finish()
        }

    }
}