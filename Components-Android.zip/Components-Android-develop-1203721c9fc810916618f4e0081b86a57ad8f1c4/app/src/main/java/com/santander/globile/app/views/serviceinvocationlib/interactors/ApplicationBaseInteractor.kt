package com.santander.globile.app.views.serviceinvocationlib.interactors

import com.santander.globile.serviceinvocationlib.callback.IBaseCallback
import com.santander.globile.serviceinvocationlib.interactor.IBaseInteractor
import retrofit2.Call
import retrofit2.Response

abstract class ApplicationBaseInteractor : IBaseInteractor() {

    override fun <OKResponseType, KOResponseType> handleErrorResponse(
        call: Call<OKResponseType>?,
        response: Response<OKResponseType>?,
        callback: IBaseCallback<OKResponseType, KOResponseType>,
        errorClass: Class<KOResponseType>,
        errorMapper: (Response<OKResponseType>?, Class<KOResponseType>) -> KOResponseType?
    ) {

        if (response?.code() == 400)
            callback.onResponseKO(errorMapper(response, errorClass))
        else
            callback.onResponseFail(Exception("Unexpected HTTP status code"))
    }
}