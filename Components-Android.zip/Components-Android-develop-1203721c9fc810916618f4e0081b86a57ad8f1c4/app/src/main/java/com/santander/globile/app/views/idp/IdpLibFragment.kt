package com.santander.globile.app.views.idp

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.idplib.handleOnActivityResult
import com.santander.globile.idplib.idpLaunch
import com.santander.globile.idplib.utils.IDP_REQUEST_CODE
import kotlinx.android.synthetic.main.fragment_idplib.*

class IdpLibFragment : Fragment() {

    companion object {
        fun newInstance(): IdpLibFragment {
            return IdpLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_idplib, container, false)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result received using callback
        idp_result_textview.text = handleOnActivityResult(data)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        open_idp_button.setOnClickListener {
            activity?.let {
                idpLaunch(it.applicationContext, IDP_REQUEST_CODE, url_text_input.text!!)
            }
        }
    }
}