package com.santander.globile.app.utils

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentTransaction
import android.support.v7.app.AppCompatActivity


fun AppCompatActivity.addFragment(fragment: Fragment, frameId: Int,backstack: String?){
    supportFragmentManager.inTransaction {
        add(frameId, fragment)
    }
}


fun AppCompatActivity.replaceFragment(
    fragment: Fragment,
    frameId: Int,
    backstack: String?,
    backStackCondition: Boolean = false
) {

    when {
        backStackCondition -> supportFragmentManager.inTransaction {
            replace(frameId, fragment)
            addToBackStack(backstack)
        }
        else -> supportFragmentManager.inTransaction {
            replace(frameId, fragment)
        }
    }


}


inline fun FragmentManager.inTransaction(func: FragmentTransaction.() -> FragmentTransaction) {
    beginTransaction().func().commit()
}

