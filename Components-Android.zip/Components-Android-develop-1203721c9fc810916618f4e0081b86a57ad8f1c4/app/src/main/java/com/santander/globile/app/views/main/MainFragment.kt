package com.santander.globile.app.views.main

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.model.Component
import com.santander.globile.app.utils.replaceFragment
import com.santander.globile.uicomponents.actionbar.GlobileActionBarActivity
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericRecyclerAdapter
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener
import kotlinx.android.synthetic.main.main_fragment.*


class MainFragment : Fragment(), GlobileRecyclerListener<Component>{

    companion object {
        fun newInstance(): MainFragment {
            return MainFragment()
        }
    }
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.main_fragment, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val context = activity?.applicationContext
        val activity = activity as MainActivity

        activity.enableGlobileLogo(true)
        activity.enableTitle(false)

        val adapter = object :GlobileGenericRecyclerAdapter<Component>(Component.getCoreList(context),this){
            override fun getLayoutId(position: Int, obj: Component): Int {
                return R.layout.component_list_element
            }

            override fun getViewHolder(view: View, viewType: Int): RecyclerView.ViewHolder {
                return ComponentListAdapter.MainViewHolder(view)
            }

        }


        component_recycler.layoutManager = LinearLayoutManager(context)
        component_recycler.adapter = adapter
        component_recycler.removeDecoration()

    }


    override fun onClickListener(data: Component, v: View, code: Int) {
        (activity as GlobileActionBarActivity).enableGlobileLogo(true)
        (activity as GlobileActionBarActivity).enableTitle(true)
        (activity as GlobileActionBarActivity).title = data.componentName
        val bundle = Bundle()
        bundle.putInt("id", data.componentId)

        (activity as GlobileActionBarActivity).replaceFragment(FragmentCoreComponents.newInstance().apply {
            arguments = bundle
        },R.id.main_content,data.componentName,true)
    }

}