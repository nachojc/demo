package com.santander.globile.app.views.localstoragelib

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v4.content.ContextCompat.getSystemService
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import com.santander.globile.app.R
import com.santander.globile.localstoragelib.LocalStorage
import kotlinx.android.synthetic.main.activity_localstoragelib.*

class LocalStorageLibFragment: Fragment() {

    companion object {
        fun newInstance(): LocalStorageLibFragment {
            return LocalStorageLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_localstoragelib, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        activity?.let {
            LocalStorage.init(it)
        }

        //Save value
        save_data_button.setOnClickListener {
            it.hideKeyboard()
            val value = data_edittext.text.toString()
            LocalStorage.saveData("alias", value)
        }

        //Get Data
        load_data_button.setOnClickListener {
            it.hideKeyboard()
            result_storage_textview.text = LocalStorage.loadData("alias")
        }

        //Remove Data
        delete_data_button.setOnClickListener {
            it.hideKeyboard()
            LocalStorage.removeData("alias")
        }
    }

    fun View.hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

}