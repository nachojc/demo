package com.santander.globile.app.views.uicomponentslib.stepper

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.fragment_stepper.*

class StepperFragment: Fragment() {

    var mOnGoingStep = 1

    companion object {
        fun newInstance(): StepperFragment {
            return StepperFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_stepper, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        left_arrow.setOnClickListener {
            if (mOnGoingStep > 1) mOnGoingStep--
            drawSteps()
        }

        right_arrow.setOnClickListener {
            if (mOnGoingStep < 8) mOnGoingStep++
            drawSteps()
        }

    }

    private fun drawSteps(){
        page_number.text = "$mOnGoingStep"
        if (mOnGoingStep <= 2) stepper_2lines.setCurrentStep(mOnGoingStep)
        if (mOnGoingStep <= 3) stepper_3lines.setCurrentStep(mOnGoingStep)
        if (mOnGoingStep <= 4) stepper_4lines.setCurrentStep(mOnGoingStep)
        if (mOnGoingStep <= 5) stepper_5lines.setCurrentStep(mOnGoingStep)
        stepper_continuous.setCurrentStep(mOnGoingStep)
    }
}