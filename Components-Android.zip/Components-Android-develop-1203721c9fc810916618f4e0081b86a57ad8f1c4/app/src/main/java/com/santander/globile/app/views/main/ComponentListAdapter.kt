package com.santander.globile.app.views.main

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.model.Component
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericBinder
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericRecyclerAdapter
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener
import com.santander.globile.uicomponents.list.simple.data.SimpleData
import kotlinx.android.synthetic.main.component_list_element.view.*

class ComponentListAdapter (private val componentsList: List<Component>, private val listener: (Component) -> Unit): RecyclerView.Adapter<ComponentListAdapter.MainViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ComponentListAdapter.MainViewHolder {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.component_list_element, parent, false)
        return MainViewHolder(v)
    }

    override fun onBindViewHolder(holder: ComponentListAdapter.MainViewHolder, position: Int) {
    }

    override fun getItemCount(): Int {
        return componentsList.size
    }

    class MainViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView),
        GlobileGenericBinder<Component> {
        override fun bind(data: Component, listener: GlobileRecyclerListener<Component>?) {
            itemView.name_textview.text = data.componentName
            itemView.image.background = data.imageId
            itemView.setOnClickListener {
                listener?.onClickListener(data,itemView,0)
            }
        }


    }

}