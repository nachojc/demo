package com.santander.globile.app.views.deviceinfolib

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.deviceinfolib.DeviceInfoReader
import com.santander.globile.deviceinfolib.activity.DeviceInfoActivity.Companion.DEVICE_INFO_REQUEST_CODE
import com.santander.globile.deviceinfolib.callback.DeviceInfoReaderCallback
import com.santander.globile.deviceinfolib.common.DeviceInfo
import com.santander.globile.deviceinfolib.common.getDeviceInfo
import com.santander.globile.deviceinfolib.common.handleOnActivityResult
import kotlinx.android.synthetic.main.activity_deviceinfolib.*

class DeviceInfoLibFragment : Fragment() {

    companion object {
        fun newInstance(): DeviceInfoLibFragment {
            return DeviceInfoLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_deviceinfolib, container, false)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result received using callback
        if (resultCode == DEVICE_INFO_REQUEST_CODE) {
            handleOnActivityResult(data, object : DeviceInfoReaderCallback {

                override fun onGetInfoCompleted(deviceInfo: DeviceInfo) {
                    printData(deviceInfo)
                }

                override fun onGetInfoError() {
                    model_result_textview.text = "Error"
                }

            })
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        retrievedata_button.setOnClickListener {
            getDeviceInfoFromMethods()
            //getDeviceInfoWithJson("{\"operation\":\"getDeviceInfo\",\"deviceInfoRequired\":[\"model\",\"isVirtual\",\"uuid\",\"platform\",\"version\",\"manufacturer\",\"serial\"]}")
        }
    }

    private fun getDeviceInfoFromMethods() {

        activity?.let {
            DeviceInfoReader.init(activity!!.applicationContext)
            val deviceInfo: DeviceInfo = DeviceInfo(
                model = DeviceInfoReader.getDeviceModel(),
                platform = DeviceInfoReader.getDevicePlatform(),
                uuid = DeviceInfoReader.getDeviceUUID(),
                version = DeviceInfoReader.getDeviceOSVersion(),
                manufacturer = DeviceInfoReader.getDeviceManufacturer(),
                isVirtual = DeviceInfoReader.getDeviceIsVirtual(),
                batteryLevel = DeviceInfoReader.getDeviceBatteryLevel(activity!!.applicationContext),
                batteryState = DeviceInfoReader.getDeviceBatteryState(activity!!.applicationContext),
                networkType = DeviceInfoReader.getDeviceNetworkType(activity!!.applicationContext)
            )

            DeviceInfoReader.getDeviceSerial(this){
                deviceInfo.serial = it
                printData(deviceInfo)
            }
        }
    }

    private fun getDeviceInfoWithJson(dataRequired: String){
        activity?.let {
            getDeviceInfo(it.applicationContext, DEVICE_INFO_REQUEST_CODE, dataRequired)
        }
    }

    private fun printData (data: DeviceInfo){
        model_result_textview.text = "Device model: ${data.model?:"-"}"
        platform_result_textview.text = "Platform: ${data.platform?:"-"}"
        uuid_result_textview.text = "Device UUID: ${data.uuid?:"-"}"
        version_result_textview.text = "Device OS version: ${data.version?:"-"}"
        manufacturer_result_textview.text = "Manufacturer: ${data.manufacturer?:"-"}"
        isVirtual_result_textview.text = "Is virtual device: ${data.isVirtual?:"-"}"
        serial_result_textview.text = "Device serial: ${data.serial?:"-"}"
        battery_level_result_textview.text = "Battery level: ${data.batteryLevel?:"-"}"
        battery_ischarging_result_textview.text = "Is device charging: ${data.batteryState?:"-"}"
        network_type_result_textview.text = "Network type: ${data.networkType?:"-"}"
    }
}