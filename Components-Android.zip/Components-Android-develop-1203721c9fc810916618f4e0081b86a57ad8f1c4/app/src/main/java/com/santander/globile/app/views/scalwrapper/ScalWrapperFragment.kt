package com.santander.globile.app.views.scalwrapper

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.globile.santander.mobisec.scal.contextdetection.SCALContextDetection
import com.globile.santander.mobisec.scal.contextdetection.listeners.*
import com.globile.santander.mobisec.scal.contextdetection.models.*
import com.globile.santander.mobisec.scal.securestorage.sharedPrefs.SCALSharedPreferencesSecureStorage
import com.globile.santander.mobisec.securestorage.SCALSharedPreferencesSecureStorageDefault
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.santander.globile.app.R
import com.santander.globile.scalwebwrapperlib.facade.data.ScalWebWrapperConstants
import com.santander.globile.uicomponents.optionselection.dropdown.data.DropDownData
import com.santander.globile.uicomponents.optionselection.dropdown.listener.OnItemSelectedListener
import kotlinx.android.synthetic.main.fragment_scalwrapper.*
import uk.co.santander.contextdetection.ContextDetectionDefaultImpl


class ScalWrapperFragment: Fragment(), GeopositionDataCallback,
    GeopositionRiskCallback, RiskStructCallback , DeviceDataCallback, ApplicationDataCallback,CommsDataCallback {

    private lateinit var scalContextDetectionModule: SCALContextDetection
    private lateinit var gson: Gson

    companion object {
        fun newInstance(): ScalWrapperFragment {
            return ScalWrapperFragment()
        }
    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_scalwrapper, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
        scalContextDetectionModule = SCALContextDetection(ContextDetectionDefaultImpl(context,
            SCALSharedPreferencesSecureStorage(
                SCALSharedPreferencesSecureStorageDefault(context)
            )
        ))

        val item1 = DropDownData("USER BINDING", 0)
        val item2 = DropDownData("DEVICE FINGERPRINT DATA", 1)
        val item3 = DropDownData("DEVICE RISK DATA", 2)
        val item4 = DropDownData("APPLICATION RISK DATA", 3)
        val item5 = DropDownData("COMMUNICATION RISK DATA", 4)
        val item6 = DropDownData("GEOPOSITION RISK DATA", 5)
        val item7 = DropDownData("ALL RISK DATA", 6)
        val item8 = DropDownData("DEVICE DATA", 7)
        val item9 = DropDownData("APPLICATION DATA", 8)
        val item10 = DropDownData("COMMUNICATION DATA", 9)
        val item11 = DropDownData("GEOPOSITION DATA", 10)

        val itemsList = listOf(item1, item2, item3, item4, item5,item6,item7,item8,item9,item10,item11)

        setTopDropdownParams(itemsList, -1)

    }

    override fun showEnableGpsDialog(): Boolean {
        return true
    }

    override fun onDeviceDataReady(deviceData: SCALDeviceData?) {
        textView.text = gson.toJson(deviceData).toString()
        progress_bar_view.visibility = View.GONE
    }

    override fun onGeopositionRiskReady(geopositionRisks: MutableList<DeviceRiskStruct>?) {
        textView.text = gson.toJson(geopositionRisks).toString()
        progress_bar_view.visibility = View.GONE
    }

    override fun onGeopositionAddressReady(scalGeoData: SCALGeoData?) {
        textView.text = gson.toJson(scalGeoData).toString()
        progress_bar_view.visibility = View.GONE
    }


    override fun onRisksReady(deviceRiskStructs: MutableList<DeviceRiskStruct>?) {
        textView.text = gson.toJson(deviceRiskStructs).toString()
        progress_bar_view.visibility = View.GONE
    }

    override fun onApplicationDataReady(applicationData: SCALApplicationData?) {
        textView.text = gson.toJson(applicationData).toString()
        progress_bar_view.visibility = View.GONE
    }

    override fun onCommsDataReady(commsData: SCALCommsData?) {
        textView.text = gson.toJson(commsData).toString()
        progress_bar_view.visibility = View.GONE
    }



    private fun setTopDropdownParams(itemsList: List<DropDownData<Int>>, initialSelection: Int) {
        top_dropdown.setGlobileDropdown(itemsList, initialSelection, object :
            OnItemSelectedListener<Int> {
            override fun onItemSelected(item: DropDownData<Int>) {
                item.value?.let {
                    progress_bar_view.visibility = View.VISIBLE
                    callLib(it)
                }
            }

            override fun onNothingSelected() {

            }
        })
    }

    private fun callLib(optionSelected: Int){
        when (optionSelected) {

            ScalWebWrapperConstants.USER_BINDING -> {
                textView.text = gson.toJson(scalContextDetectionModule.userBinding).toString()
                progress_bar_view.visibility = View.GONE
            }

            ScalWebWrapperConstants.DEVICE_RISK_DATA -> {
                textView.text = gson.toJson(scalContextDetectionModule.deviceRiskData)
                progress_bar_view.visibility = View.GONE
            }

            ScalWebWrapperConstants.APPLICATION_RISK_DATA -> {
                textView.text = gson.toJson(scalContextDetectionModule.applicationRiskData)
                progress_bar_view.visibility = View.GONE
            }

            ScalWebWrapperConstants.COMMUNICATION_RISK_DATA -> {
                textView.text = gson.toJson(scalContextDetectionModule.communicationRiskData)
                progress_bar_view.visibility = View.GONE
            }

            ScalWebWrapperConstants.APPLICATION_DATA -> {
                scalContextDetectionModule.getApplicationData(this)
            }

            ScalWebWrapperConstants.COMMUNICATION_DATA -> {
                scalContextDetectionModule.getCommunicationData(this)
            }

            ScalWebWrapperConstants.DEVICE_FINGERPRINT_DATA -> {
                textView.text = gson.toJson(scalContextDetectionModule.deviceFootprint)
                progress_bar_view.visibility = View.GONE
            }

            ScalWebWrapperConstants.DEVICE_DATA -> {
                scalContextDetectionModule.getDeviceData(this)
            }


            ScalWebWrapperConstants.GEOPOSITION_RISK_DATA -> {
                scalContextDetectionModule.getGeopositionRiskData(this, activity)
            }
            ScalWebWrapperConstants.ALL_RISK_DATA -> {
                scalContextDetectionModule.getAllRiskData(this,activity)
            }
            ScalWebWrapperConstants.GEOPOSITION_DATA ->{
                scalContextDetectionModule.getGeopositionData(this,activity)
            }
        }
    }

}