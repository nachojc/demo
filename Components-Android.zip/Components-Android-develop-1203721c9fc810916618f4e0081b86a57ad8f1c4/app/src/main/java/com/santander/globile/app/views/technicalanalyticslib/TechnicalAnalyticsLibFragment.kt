package com.santander.globile.app.views.technicalanalyticslib

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.technicalanalyticslib.GlobileAnalytics
import kotlinx.android.synthetic.main.activity_technicalanalyticslib.*

class TechnicalAnalyticsLibFragment: Fragment() {

    companion object {
        fun newInstance(): TechnicalAnalyticsLibFragment {
            return TechnicalAnalyticsLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_technicalanalyticslib, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Send Log
        log_technical_button.setOnClickListener {
            technical_result_textview.text = "Log ${getString(R.string.technicalanalytics_result)}"
            GlobileAnalytics.sendLogException(Exception("Exception Example app"))
        }

        // Force crash
        crash_technical_button.setOnClickListener {
            technical_result_textview.text = "Crash ${getString(R.string.technicalanalytics_result)}"
            GlobileAnalytics.sendLog("Log from Example app just before forced crash")
            val a = 1/0
        }

    }
}