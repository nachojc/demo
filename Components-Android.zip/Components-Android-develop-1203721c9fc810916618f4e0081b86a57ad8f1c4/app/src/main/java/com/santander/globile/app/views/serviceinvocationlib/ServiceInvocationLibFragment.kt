package com.santander.globile.app.views.serviceinvocationlib

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.views.serviceinvocationlib.model.ErrorMessage
import com.santander.globile.app.views.serviceinvocationlib.model.ResultsContainer
import com.santander.globile.app.views.serviceinvocationlib.repository.RandomUsersRepository
import com.santander.globile.uicomponents.errorhandling.common.BUTTON_POSITIVE_CODE
import com.santander.globile.uicomponents.errorhandling.common.ErrorHandlingParams
import com.santander.globile.uicomponents.errorhandling.dialog.ErrorHandlingDialogFragment
import kotlinx.android.synthetic.main.activity_serviceinvocaionlib.*

class ServiceInvocationLibFragment: Fragment(), ErrorHandlingDialogFragment.OnClickListener
    , ErrorHandlingDialogFragment.OnDismissListener {

    private val randomUsersRepository = RandomUsersRepository()

    companion object {
        fun newInstance(): ServiceInvocationLibFragment {
            return ServiceInvocationLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_serviceinvocaionlib, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        call_service_button.setOnClickListener {
            getUserName()
        }
    }

    private fun getUserName(){
        randomUsersRepository.getRandomUsers(object : RandomUsersRepository.RandomUsersCallback{
            override fun onUsersSuccess(users: ResultsContainer) {
                if (users.results != null && users.results.isNotEmpty()) {
                    serviceinvocation_result_textview.text = (users.results.get(0).name?.first?:"No first name").toString()
                } else {
                    serviceinvocation_result_textview.text = getString(R.string.serviceinvocation_no_users)
                }
            }

            override fun onError(errorResponse: ErrorMessage?) {
                serviceinvocation_result_textview.text = getString(R.string.serviceinvocation_error) + ": " + errorResponse?.msg
                showErrorDialog(errorResponse?.msg)
            }

        })
    }

    private fun showErrorDialog(errorMessage: String?) {
        val params = ErrorHandlingParams(
            title = getString(R.string.serviceinvocation_error_dialog_title),
            subtitle = getString(R.string.serviceinvocation_error_dialog_subtitle),
            message = errorMessage,
            negativeButtonText = getString(R.string.serviceinvocation_error_dialog_button_left),
            positiveButtonText = getString(R.string.serviceinvocation_error_dialog_button_right)
        )

        activity?.let {
            com.santander.globile.uicomponents.errorhandling.common.showErrorDialog(
                it.supportFragmentManager,
                "SERVICE_ERROR_DIALOG", params, this, this, this
            )
        }

    }

    override fun onDismiss() {
    }

    override fun onButtonClick(code: Int) {
        if (code == BUTTON_POSITIVE_CODE){
            serviceinvocation_result_textview.text = getString(R.string.serviceinvocation_error_dialog_button_left)
            getUserName()
        }
    }
}