package com.santander.globile.app.views.cachelib

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.utils.replaceFragment
import com.santander.globile.app.views.uicomponentslib.list.dummy.RecyclerClassComplexCustom
import com.santander.globile.app.views.uicomponentslib.list.dummy.RecyclerClassCustom
import com.santander.globile.app.views.uicomponentslib.list.dummy.RecyclerClassSimple
import com.santander.globile.uicomponents.actionbar.GlobileActionBarActivity
import com.santander.globile.uicomponents.common.GlobileButtonSelectorPosition
import com.santander.globile.uicomponents.optionselection.buttonselector.GlobileButtonSelector
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_CENTER
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_LEFT
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_RIGHT
import kotlinx.android.synthetic.main.fragment_recycler_list.*

class RecyclerListFragment: Fragment() {

    companion object {
        fun newInstance(): RecyclerListFragment {
            return RecyclerListFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_recycler_list, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        listLeft()
        globile_selector.globileButtonSelectorListener = object : GlobileButtonSelector.GlobileButtonSelectorListener{
            override fun onSelection(code: GlobileButtonSelectorPosition, appCompatButton: View) {
                when(code.position){
                    POSITION_LEFT -> listLeft()
                    POSITION_CENTER -> listCenter()
                    POSITION_RIGHT -> listRight()

                }
            }

        }
    }

    private fun listLeft(){
        (activity as GlobileActionBarActivity).replaceFragment(RecyclerClassSimple.newInstance(),R.id.frame_content,"RecyclerSimple")
    }

    private  fun listRight(){
        (activity as GlobileActionBarActivity).replaceFragment(RecyclerClassComplexCustom.newInstance(),R.id.frame_content,"RecyclerComplex")
    }

    private fun listCenter(){
        (activity as GlobileActionBarActivity).replaceFragment(RecyclerClassCustom.newInstance(),R.id.frame_content,"RecyclerCustom")
    }
}