package com.santander.globile.app.views.uicomponentslib.alertbar

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.santander.globile.app.R
import com.santander.globile.uicomponents.alertbar.GlobileAlertBarListener
import com.santander.globile.uicomponents.alertbar.showGlobileAlertBar
import kotlinx.android.synthetic.main.fragment_alertbar.*


class AlertBarFragment: Fragment() {

    companion object {
        fun newInstance(): AlertBarFragment {
            return AlertBarFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_alertbar, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val message = "This <b><font color=#EC0000>AlertBar</font></b> appears at top of <b><font color=#EC0000>Fragment</font></b> below activity <b><font color=#EC0000>toolbar</font></b>."
        val label = "ACTION"

        show_alert_button_fragment.setOnClickListener {
            showGlobileAlertBar(message, label, object : GlobileAlertBarListener{
                override fun onActionPressed() {
                    Toast.makeText(view.context, "label clicked", Toast.LENGTH_SHORT).show()
                }

                override fun onDismissPressed() {
                    Toast.makeText(view.context, "cancel tapped", Toast.LENGTH_SHORT).show()
                }

            })

        }

        open_activity_with_toolbar_button.setOnClickListener {
            val intent = Intent(context, AlertBarWithToolbarActivity::class.java)
            startActivity(intent)
        }

        open_activity_without_toolbar_button.setOnClickListener {
            val intent = Intent(context, AlertBarWithoutToolbarActivity::class.java)
            startActivity(intent)
        }

    }

}