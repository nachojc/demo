package com.santander.globile.app.views.securestoragelib

import android.content.Context
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import com.globile.santander.mobisec.scal.securestorage.sharedPrefs.SCALSharedPreferencesSecureStorage
import com.globile.santander.mobisec.securestorage.SCALSharedPreferencesSecureStorageDefault
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.activity_securestoragelib.*
import java.math.BigInteger
import java.security.MessageDigest

class SecureStorageLibFragment : Fragment() {

    private lateinit var secureStorage: SCALSharedPreferencesSecureStorage

    companion object {
        fun newInstance(): SecureStorageLibFragment {
            return SecureStorageLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_securestoragelib, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        secureStorage = SCALSharedPreferencesSecureStorage(SCALSharedPreferencesSecureStorageDefault(context))

        activity?.let {
            secureStorage.createNewSecureSharedPreferences("secure_data")
        }

        //Save value
        save_data_button.setOnClickListener {
            it.hideKeyboard()
            val value = data_edittext.text.toString()
            secureStorage.setString("password", value, "secure_data")
        }

        //Get Data
        load_data_button.setOnClickListener {
            it.hideKeyboard()
            val value = try {
                secureStorage.getString("password", "secure_data")
            } catch (e: IllegalStateException) {
                ""
            }
            val result = "value:\n${value}"
            result_storage_textview.text = if (value != null && value.isNotEmpty()) result else "Data not found"
        }

        //Get Encripted key and liveData
        load_encrypted_data_button.setOnClickListener {
            it.hideKeyboard()
            val preferences = activity?.getSharedPreferences("secure_data", Context.MODE_PRIVATE)
            val storedKey = hash("password")
            val value = preferences?.getString(storedKey, "null")
            val result = if (value != "null") "key:\n$storedKey\nvalue:\n$value" else "Data not found"
            result_storage_textview.text = result
        }

        //Remove Data
        delete_data_button.setOnClickListener {
            it.hideKeyboard()
            secureStorage.clearSecureSharedPreferences("secure_data")
        }

    }

    private fun hash(data: String): String {
        val md = MessageDigest.getInstance("MD5")
        return BigInteger(1, md.digest(data.toByteArray())).toString(16).padStart(32, '0')
    }

    fun View.hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }

}