package com.santander.globile.app.model

import android.annotation.TargetApi
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Build
import android.support.v4.app.Fragment
import com.santander.globile.app.R
import com.santander.globile.app.views.barcodescannerlib.BarcodeScannerLibFragment
import com.santander.globile.app.views.cachelib.*
import com.santander.globile.app.views.cardreaderlib.CardReaderLibFragment
import com.santander.globile.app.views.deviceinfolib.DeviceInfoLibFragment
import com.santander.globile.app.views.errorhandlinglib.ErrorHandlingLibFragment
import com.santander.globile.app.views.functionalanalyticslib.FunctionalAnalyticsLibFragment
import com.santander.globile.app.views.idp.IdpLibFragment
import com.santander.globile.app.views.localstoragelib.LocalStorageLibFragment
import com.santander.globile.app.views.scalwrapper.ScalWrapperFragment
import com.santander.globile.app.views.securestoragelib.SecureStorageLibFragment
import com.santander.globile.app.views.serviceinvocationlib.ServiceInvocationLibFragment
import com.santander.globile.app.views.technicalanalyticslib.TechnicalAnalyticsLibFragment
import com.santander.globile.app.views.uicomponentslib.alertbar.AlertBarFragment
import com.santander.globile.app.views.uicomponentslib.buttons.ButtonsFragment
import com.santander.globile.app.views.uicomponentslib.buttons.SliderFragment
import com.santander.globile.app.views.uicomponentslib.icons.IconsFragment
import com.santander.globile.app.views.uicomponentslib.icons.ProfileFragment
import com.santander.globile.app.views.uicomponentslib.optionselection.dropdown.DropdownFragment
import com.santander.globile.app.views.uicomponentslib.pagecontroller.PageControllerFragment
import com.santander.globile.app.views.uicomponentslib.stepper.StepperFragment
import com.santander.globile.app.views.uicomponentslib.tabbar.TabBarFragment
import com.santander.globile.app.views.uicomponentslib.tabs.TabsLayoutFragment
import com.santander.globile.app.views.uicomponentslib.textinputlayout.GlobalInputTextLayoutFragment

class Component(
    val componentId: Int,
    val fragment: Fragment?,
    val componentName: String?,
    val imageId: Drawable?
) {

    companion object {

        fun getComponentList(context: Context?, componentId: Int): List<Component> {
            return when (componentId) {
                0 -> getCoreComponentList(context)
                1 -> getComponentsIntegrationList(context)
                2 -> getDeviceIntegrationList(context)
                3 -> getSecurityList(context)
                4 -> getUIIntegrationList(context)
                else -> getUIIntegrationList(context)
            }
        }

        private fun getCoreComponentList(context: Context?): List<Component> {
            return listOf(
                Component(0, CacheLibFragment.newInstance(), context?.getString(R.string.cachelib), null),
                Component(
                    1,
                    TechnicalAnalyticsLibFragment.newInstance(),
                    context?.getString(R.string.technicalanalytcsfragment),
                    null
                ),
                Component(
                    2,
                    FunctionalAnalyticsLibFragment.newInstance(),
                    context?.getString(R.string.functionalanalyticsfragment),
                    null
                )
            )
        }

        private fun getComponentsIntegrationList(context: Context?): List<Component> {
            return listOf(
                Component(
                    0,
                    ServiceInvocationLibFragment.newInstance(),
                    context?.getString(R.string.serviceinvocationlib),
                    null
                ),
                Component(1, IdpLibFragment.newInstance(), context?.getString(R.string.idpFragment), null)
            )
        }

        private fun getDeviceIntegrationList(context: Context?): List<Component> {
            return listOf(
                Component(0, CardReaderLibFragment.newInstance(), context?.getString(R.string.cardreaderlib), null),
                Component(
                    1,
                    BarcodeScannerLibFragment.newInstance(),
                    context?.getString(R.string.barcodescannerfragment),
                    null
                )
            )
        }

        private fun getSecurityList(context: Context?): List<Component> {
            return listOf(
                Component(0, SecureStorageLibFragment.newInstance(),context?.getString(R.string.securestoragelib), null),
                Component(1, LocalStorageLibFragment.newInstance(), context?.getString(R.string.localstoragelib), null),
                Component(
                    2,
                    DeviceInfoLibFragment.newInstance(),
                    context?.getString(R.string.deviceinfofragment),
                    null
                ),
                Component(3,ScalWrapperFragment.newInstance(),context?.getString(R.string.scalFragment),null)
                )
        }

        private fun getUIIntegrationList(context: Context?): List<Component> {
            return listOf(
                Component(
                    0,
                    ErrorHandlingLibFragment.newInstance(),
                    context?.getString(R.string.errorhandlerlib),
                    null
                ),
                Component(1, ButtonsFragment.newInstance(), context?.getString(R.string.buttonsfragment), null),
                Component(
                    2,
                    GlobalInputTextLayoutFragment.newInstance(),
                    context?.getString(R.string.inputTextFragment),
                    null
                ),
                Component(3, IconsFragment.newInstance(), context?.getString(R.string.iconsfragment), null),
                Component(4, ProfileFragment.newInstance(), context?.getString(R.string.profilephotoFragment), null),
                Component(
                    5,
                    PageControllerFragment.newInstance(),
                    context?.getString(R.string.pagecontrollerfragment),
                    null
                ),
                Component(6, TabBarFragment.newInstance(), context?.getString(R.string.tabBarFragment), null),
                Component(7, TabsLayoutFragment.newInstance(), context?.getString(R.string.tabLayoutFragment), null),
                Component(
                    8,
                    ButtonSelectionFragment.newInstance(),
                    context?.getString(R.string.buttonSelectorFragment),
                    null
                ),
                Component(
                    9,
                    RadioButtonSelectionFragment.newInstance(),
                    context?.getString(R.string.radioButtonSelectorFragment),
                    null
                ),
                Component(
                    10,
                    CheckBoxFragment.newInstance(),
                    context?.getString(R.string.checkBoxSelectorFragment),
                    null
                ),
                Component(
                    11,
                    RecyclerListFragment.newInstance(),
                    context?.getString(R.string.recyclerListFragment),
                    null
                ),
                Component(12, DropdownFragment.newInstance(), context?.getString(R.string.dropdownFragment), null),
                Component(13, StepperFragment.newInstance(), context?.getString(R.string.stepperFragment), null),
                Component(14, AlertBarFragment.newInstance(), context?.getString(R.string.alertBarFragment), null),
                Component(15, SliderFragment.newInstance(), context?.getString(R.string.sliderFragment), null),
                Component(16, GlobileCardViewFragment.newInstance(), context?.getString(R.string.cardsFragment), null)
            )
        }


        @TargetApi(Build.VERSION_CODES.LOLLIPOP)
        fun getCoreList(context: Context?): List<Component> {
            return listOf(
                Component(0, null, context?.getString(R.string.category_cc), context?.getDrawable(R.drawable.corecomponents)),
                Component(1, null, context?.getString(R.string.category_ci), context?.getDrawable(R.drawable.componentintegration)),
                Component(2, null, context?.getString(R.string.category_di), context?.getDrawable(R.drawable.deviceintegration)),
                Component(3, null, context?.getString(R.string.category_sec), context?.getDrawable(R.drawable.security1)),
                Component(4, null, context?.getString(R.string.category_ui), context?.getDrawable(R.drawable.uiintegration1))
            )
        }
    }
}