package com.santander.globile.app.views.serviceinvocationlib.interactors

import com.santander.globile.app.views.serviceinvocationlib.interfaces.RandomUsersApi
import com.santander.globile.app.views.serviceinvocationlib.model.ErrorMessage
import com.santander.globile.app.views.serviceinvocationlib.model.ResultsContainer
import com.santander.globile.serviceinvocationlib.callback.IBaseCallback

class RandomUsersInteractor(private val randomUserApi: RandomUsersApi) : ApplicationBaseInteractor() {

    fun getRandomUsers(callback: (ResultsContainer?, ErrorMessage?) -> Unit) {
        doRequest(randomUserApi.getRandomUsers(), object : IBaseCallback<ResultsContainer, ErrorMessage>() {
            override fun onResponseOK(response: ResultsContainer?) {
                callback(response, null)
            }

            override fun onResponseKO(errorResponse: ErrorMessage?) {
                callback(null, errorResponse)
            }

            override fun onResponseFail(t: Throwable?) {
                callback(null, ErrorMessage(t?.message?:"Response Fail"))
            }
        }, ErrorMessage::class.java)
    }

}