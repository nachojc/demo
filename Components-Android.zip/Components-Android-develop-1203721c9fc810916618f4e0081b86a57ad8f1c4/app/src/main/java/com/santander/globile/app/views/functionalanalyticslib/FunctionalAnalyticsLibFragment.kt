package com.santander.globile.app.views.functionalanalyticslib

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.cachelib.GlobalFactoryCache
import com.santander.globile.functionalanalyticslib.FunctionalAnalytics
import com.santander.globile.functionalanalyticslib.FunctionalAnalytics.Companion.logEvent
import kotlinx.android.synthetic.main.activity_functionalanalyticslib.*

class FunctionalAnalyticsLibFragment: Fragment() {

    companion object {
        fun newInstance(): FunctionalAnalyticsLibFragment {
            return FunctionalAnalyticsLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_functionalanalyticslib, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        //Send event
        functional_button.setOnClickListener {
            activity?.applicationContext?.let {
                //Send analytics event
                FunctionalAnalytics.init(it)

                val eventMap = HashMap<String,Any?>()
                eventMap.put("item_id","functional_Android")
                eventMap.put("item_name","functional_view")
                eventMap.put("content_type","testType")
                eventMap.put("integer_value", 123456)
                logEvent("pageview",eventMap)

                functional_result_textview.text = getString(R.string.functionalanalytics_result)
            }

        }
    }
}