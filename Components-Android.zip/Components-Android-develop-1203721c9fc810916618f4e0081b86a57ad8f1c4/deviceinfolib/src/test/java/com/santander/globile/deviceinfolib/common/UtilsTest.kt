package com.santander.globile.deviceinfolib.common

import android.content.Intent
import com.google.common.truth.Truth
import com.santander.globile.deviceinfolib.activity.DeviceInfoActivity
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

@RunWith(RobolectricTestRunner::class)
class UtilsTest {

    @Test
    fun getDeviceInfoFromNullIntentData() {

        // Act
        val result = getDeviceInfoFromIntentData(null)

        // Assert
        Truth.assertThat(result).isNull()
    }

    @Test
    fun getDeviceInfoFromIntentData() {

        val model = "Emulator"
        val platform = "Android"
        val responseString = "{" +
                "  \"operation\": \"getDeviceInfo\"," +
                "  \"deviceInfo\": {" +
                "    \"model\": \"$model\"," +
                "    \"platform\": \"$platform\"" +
                "  }" +
                "}"

        val intent = Intent()
        intent.putExtra(
            DeviceInfoActivity.DEVICE_INFO_RESULT,
            responseString
        )

        // Act
        val result = getDeviceInfoFromIntentData(intent)

        // Assert
        val expectedResult = DeviceInfo (model = model, platform = platform)
        Truth.assertThat(result).isEqualTo(expectedResult)
    }
}