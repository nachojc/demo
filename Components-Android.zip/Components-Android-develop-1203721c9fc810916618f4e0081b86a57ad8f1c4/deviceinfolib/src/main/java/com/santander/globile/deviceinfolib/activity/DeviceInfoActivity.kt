package com.santander.globile.deviceinfolib.activity

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.gson.Gson
import com.santander.globile.deviceinfolib.DeviceInfoReader
import com.santander.globile.deviceinfolib.R
import com.santander.globile.deviceinfolib.common.DEVICE_REQUIRED_DATA
import com.santander.globile.deviceinfolib.common.DeviceInfo
import com.santander.globile.deviceinfolib.common.DeviceInfoRequest
import com.santander.globile.deviceinfolib.common.DeviceInfoResponse

class DeviceInfoActivity: AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_deviceinfo)
        title = ""
        val requiredDataArray = getRequiredDeviceInfo()

        val deviceInfo = DeviceInfo()
        if (!requiredDataArray.deviceInfoRequired.isNullOrEmpty()) {
            DeviceInfoReader.init(this)
            if ("model" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.model = DeviceInfoReader.getDeviceModel()
            }
            if ("platform" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.platform = DeviceInfoReader.getDevicePlatform()
            }
            if ("uuid" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.uuid = DeviceInfoReader.getDeviceUUID()
            }
            if ("version" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.version = DeviceInfoReader.getDeviceOSVersion()
            }
            if ("manufacturer" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.manufacturer = DeviceInfoReader.getDeviceManufacturer()
            }
            if ("isVirtual" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.isVirtual = DeviceInfoReader.getDeviceIsVirtual()
            }
            if ("batteryLevel" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.batteryLevel = DeviceInfoReader.getDeviceBatteryLevel(this)
            }
            if ("batteryState" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.batteryState = DeviceInfoReader.getDeviceBatteryState(this)
            }
            if ("networkType" in requiredDataArray.deviceInfoRequired) {
                deviceInfo.networkType = DeviceInfoReader.getDeviceNetworkType(this)
            }
            if ("serial" in requiredDataArray.deviceInfoRequired) {
                DeviceInfoReader.getDeviceSerial(this){ serial ->
                    deviceInfo.serial = serial
                    returnActivityResult(deviceInfo)
                }
            } else {
                returnActivityResult(deviceInfo)
            }

        } else {
            returnActivityResult(deviceInfo)
        }

    }

    private fun returnActivityResult(deviceInfo: DeviceInfo) {
        val jsonString = Gson().toJson(DeviceInfoResponse("getDeviceInfo", deviceInfo))
        setResult(DEVICE_INFO_REQUEST_CODE, Intent().putExtra(DEVICE_INFO_RESULT, jsonString))
        finish()
    }

    private fun getRequiredDeviceInfo(): DeviceInfoRequest {
        return if (intent.hasExtra(DEVICE_REQUIRED_DATA)) {
            Gson().fromJson(intent?.extras?.getString(DEVICE_REQUIRED_DATA), DeviceInfoRequest::class.java)
        } else {
            DeviceInfoRequest(null, null)
        }
    }

    companion object {

        const val DEVICE_INFO_REQUEST_CODE = 2
        const val DEVICE_INFO_RESULT = "deviceInfoResult"

    }
}