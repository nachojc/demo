package com.santander.globile.deviceinfolib.callback

import com.santander.globile.deviceinfolib.common.DeviceInfo

/**
 * This interface is used as a callback to receive the result from the get device info.
 */
interface DeviceInfoReaderCallback {

    /**
     * Card information successfully read.
     *
     * @param deviceInfo
     */
    fun onGetInfoCompleted(deviceInfo: DeviceInfo)

    /**
     * Error retrieven data or malformed json.
     */
    fun onGetInfoError()
}