package com.santander.globile.deviceinfolib.common

/**
 * Entity that holds the device info response variables.
 *
 * @param operation
 * @param deviceInfo
 */
data class DeviceInfoResponse (
    val operation: String,
    val deviceInfo: DeviceInfo
)