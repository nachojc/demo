package com.santander.globile.deviceinfolib.common

/**
 * Entity that holds the device info.
 *
 * @param model
 * @param platform
 * @param uuid
 * @param version
 * @param manufacturer
 * @param isVirtual
 * @param serial
 * @param batteryLevel
 * @param batteryState
 * @param networkType
 */

data class DeviceInfo(
    var model: String? = null,
    var platform: String? = null,
    var uuid: String? = null,
    var version: String? = null,
    var manufacturer: String? = null,
    var isVirtual: Boolean? = null,
    var serial: String? = null,
    var batteryLevel: Int? = null,
    var batteryState: Boolean? = null,
    var networkType: String? = null
)