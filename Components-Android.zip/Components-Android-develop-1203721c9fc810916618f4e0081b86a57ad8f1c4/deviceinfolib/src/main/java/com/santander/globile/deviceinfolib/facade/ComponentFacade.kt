package com.santander.globile.deviceinfolib.facade

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.google.gson.Gson
import com.santander.globile.deviceinfolib.common.getDeviceInfoFromIntentData
import com.santander.globile.deviceinfolib.common.intent

/**
 * This class allows compatibility with WebViewBridge component and Archetype dispatcher in case the app contains
 * at least one web that needs to get device information with this component.
 */
class ComponentFacade {
    /**
     * @param context Necessary to create the intent.
     * @param params Data as JSON with Device data required params: a [String] with the data
     * required to get from device.
     *
     * @return An [Intent] with the necessary extras to launch the activity for permissions [Activity].
     */
    fun getIntent(context: Context, params: String?): Intent = intent(context, params)

    /**
     * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the device data
     * as a JSON [String] from a DeviceInfo object.
     *
     * @param requestCode
     * @param resultCode
     * @param data
     *
     * @return Device data from as JSON from a DeviceInfo object.
     */
    fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?): String? =
        getDeviceInfoFromIntentData(data)?.let {
            Gson().toJson(it)
        }

}