# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2019-03-31
### Added
- Retrieve this information from device:
	- Device model.
	- Platform.
	- Device UUID.
	- OS version.
	- Manufacturer.
	- Device is virtual or not.
	- Device serial number.
	- Battery level.
	- Device is charging.
	- Network type.