# Introduction 
This component return security data from SCAL library.

# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file

```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:

```gradle
implementation project(':scalsecurestoragewrapperlib')
```
3. Sync project with Gradle files

# Use
## From Web app
Access this component from web through the `callComponent(args: ArrayList<Any>)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib). Call the function with the following values:

```
SCALSecureStorageSharedPreferenceParams
    val operation: String,
    val name: String,
    val alias: String,
    val plainData: Any? = null
)
```

```
data class SCALSecureStorageSqliteParams(
    val operation: String,
    val name: String,
    val version: Int,
    val query: String,
    val args: Array<String>
)
```

The possible operations are:

```
data class SCALSecureStorageOperationParam(
    val operation: SecureStorageOperation?
)

enum class SecureStorageOperation {
    createNewSecureSharedPreference,
    clearSecureSharedPreference,
    deleteSecureSharedPreference,
    saveBool,
    saveString,
    saveInteger,
    saveDouble,
    saveFloat,
    loadBool,
    loadString,
    loadInteger,
    loadDouble,
    loadFloat,
    removeSecureFile,
    clearSecureFile,
    writeToSecureFile,
    readFromSecureFile,
    initDataBase,
    removeDataBase,
    executeQuery
}
```


Some examples to save/load into the Shared Preference are: 

```
{
	'operation': 'saveString', //Operation name
	'name': 'SecureStorage', //Shared Preference name file
	'alias':'dataKey', //Alias of the data to store
	'plainData':'123456789' //Data to store
}
```

```
{
	'operation': 'clearSecureSharedPreference', //Operation name
	'name': 'SecureStorage' //Shared Preference name file
}
```


The result will be the data loaded from the Secure Storage formatted as JSON



# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "scalsecurestoragewrapperlib" from the Project sidemenu
4. Select Build -> Make Module 'scalsecurestoragewrapperlib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/scalsecurestoragewrapperlib/build/outputs/aar/
