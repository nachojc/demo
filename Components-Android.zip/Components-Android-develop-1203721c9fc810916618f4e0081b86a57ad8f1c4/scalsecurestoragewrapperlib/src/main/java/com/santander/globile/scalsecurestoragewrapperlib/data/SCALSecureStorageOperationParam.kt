package com.santander.globile.scalsecurestoragewrapperlib.facade.data

data class SCALSecureStorageOperationParam(
    val operation: SecureStorageOperation?
)

enum class SecureStorageOperation {
    createNewSecureSharedPreference,
    clearSecureSharedPreference,
    deleteSecureSharedPreference,
    saveBool,
    saveString,
    saveInteger,
    saveDouble,
    saveFloat,
    loadBool,
    loadString,
    loadInteger,
    loadDouble,
    loadFloat,
    removeSecureFile,
    clearSecureFile,
    writeToSecureFile,
    readFromSecureFile,
    initDataBase,
    removeDataBase,
    executeQuery
}