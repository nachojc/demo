# Introduction 
This component provides a webview interfaz to display any web content inside a native or web app.

# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android.git) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation "com.santander.globile:idplip:$idp_version"
```
3. It' neccesary to add the following activity into the manifest
```
<activity android:name="com.santander.globile.idplib.view.IdpActivity" 
			android:theme="@style/Theme.AppCompat.NoActionBar"/>
```
4. Sync project with Gradle files

# Use
## From Native app
### Idp Launch
Launch the WebView with `idpLaunch (context: Context, requestCode: Int, destinationURL: String? = null)`:

```kotlin
idpLaunch(context, IDP_REQUEST_CODE, "http://www.google.com")
```
Then collect the login token with `handleOnActivityResult (requestCode: Int, resultCode: Int, data: Intent?): String?` in the onActivityResult function

```kotlin
override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
	super.onActivityResult(requestCode, resultCode, data)

   // Result received using callback
   idp_result_textview.text = handleOnActivityResult(data)
}
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-android/tree/master/webviewbridgelib). Call the function with the following values:

componentName: "idplib"

componentParams: URL to load into component. For example: "http://www.google.com"

The returned Promise will be resolved with the following string:
```javascript
"token" : String. The result token of the login
```
### IDP Start
```javascript
callComponent('idplib','http://www.google.es').then((res) => {
    console.log(res)
})
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "idplib" from the Project sidemenu
4. Select Build -> Make Module 'idplib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/idplib/build/outputs/aar/

# Test
1. Open Components-Android project in Android Studio
2. Open "idplib" from the Project sidemenu
3. Open "java/com.santander.globile.idplib.common (test)"
4. Open file "UtilsTest"
5. Click ► icon next to "class UtilsTest"