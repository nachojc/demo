package com.santander.globile.idplib

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.support.v4.app.Fragment
import com.santander.globile.idplib.utils.IDP_RETURN_STRING
import com.santander.globile.idplib.utils.URL
import com.santander.globile.idplib.view.IdpActivity


/**
 * Returns the intent neccesary to launch the activity that loads the URL of the IDP
 *
 * @param context Necessary to create the [Intent].
 * @param destinationURL The URL of the web to perform the login.
 *
 * @return An [Intent] with the necessary extras to launch the WebView.
 */
fun intent(context: Context, destinationURL: String?): Intent =
    Intent(context, IdpActivity::class.java).apply {
        putExtra(URL, destinationURL)
        //putExtra(URL, "https://www.google.es")
    }

/**
 * Launches the activity with the URL of the IDP.
 *
 * @param requestCode Request code for [Activity.startActivityForResult] method.
 * @param destinationURL Hint text for the camera scan.
 */
fun Activity.idpLaunch(requestCode: Int, destinationURL: String) {

    startActivityForResult(intent(this, destinationURL), requestCode)
}


/**
 * Launches the activity with the URL of the IDP.
 *
 * @param requestCode Request code for [Activity.startActivityForResult] method.
 * @param destinationURL Hint text for the camera scan.
 */
fun Fragment.idpLaunch(context: Context, requestCode: Int, destinationURL: String) {

    startActivityForResult(intent(context, destinationURL), requestCode)
}


/**
 * This method receives the data from [Activity.onActivityResult] and uses to return the token from IDP.
 *
 * @param data Intent data from onActivityResult method.
 */
fun handleOnActivityResult(data: Intent?): String {
    return data?.getStringExtra(IDP_RETURN_STRING) as String
}