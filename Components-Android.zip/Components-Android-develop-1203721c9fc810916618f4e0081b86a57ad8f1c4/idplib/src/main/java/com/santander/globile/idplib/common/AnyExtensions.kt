package com.santander.globile.idplib.common

val Any.TAG: String
    get() = this::class.java.simpleName