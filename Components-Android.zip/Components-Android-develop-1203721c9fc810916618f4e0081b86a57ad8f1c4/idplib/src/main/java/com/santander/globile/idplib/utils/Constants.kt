package com.santander.globile.idplib.utils

const val URL = "URL"
const val IDP_RETURN_STRING = "TOKEN"
const val TOKEN_SUBSTRING = "?ot="
const val IDP_REQUEST_CODE = 11