package com.santander.globile.idplib.webview

import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Build
import android.support.annotation.RequiresApi
import android.util.Log
import android.webkit.*
import com.santander.globile.idplib.common.TAG
import com.santander.globile.idplib.listener.IdpListener


class CustomIdpWebViewClient (val idpListener: IdpListener): WebViewClient() {

    private var firstStateValue: String? = null


    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        Log.d(TAG, "Web Page onPageStarted: $url")
        super.onPageStarted(view, url, favicon)
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        Log.d(TAG, "Web Page onPageFinished: $url")
        super.onPageFinished(view, url)
    }

    @RequiresApi(Build.VERSION_CODES.M)
    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
        Log.d(TAG, "Web Page ReceivedError: ${error!!.description}")
        super.onReceivedError(view, request, error)
    }

    override fun onReceivedSslError(view: WebView, handler: SslErrorHandler, error: SslError) {
        Log.d(TAG, "onReceivedSslError")
        handler.proceed()
    }

    @RequiresApi(Build.VERSION_CODES.LOLLIPOP)
    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {

        Log.d(TAG, "shouldOverrideUrlLoading")

        var code: String? = null
        var state: String? = null

        request?.url?.let{
            code = request.url.getQueryParameter("code")
            state = request.url.getQueryParameter("state")
        }

        state?.let {
            if (firstStateValue == null) {
                firstStateValue = state
            }
        }

        code?.let { codeValue ->
            firstStateValue?.let { stateValue ->
                return if (firstStateValue == state) {
                    idpListener.onUrlDetected(codeValue)
                    true
                } else {
                    idpListener.onUrlDetected("State parameter error")
                    true
                }
            }
        }

        return false
    }

    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {

        Log.d(TAG, "shouldOverrideUrlLoading")

        var code: String? = null
        var state: String? = null

        url?.let{
            val uri = Uri.parse(url)
            code = uri.getQueryParameter("code")
            state = uri.getQueryParameter("state")
        }

        state?.let {
            if (firstStateValue == null) {
                firstStateValue = state
            }
        }

        code?.let { codeValue ->
            firstStateValue?.let { stateValue ->
                return if (firstStateValue == state) {
                    idpListener.onUrlDetected(codeValue)
                    true
                } else {
                    idpListener.onUrlDetected("State parameter error")
                    true
                }
            }
        }

        return false
    }

}