package com.santander.globile.idplib.listener

/**
 * Listener where the Web Client informs about the URL detection.
 */
interface IdpListener {

    fun onUrlDetected(token: String)

}