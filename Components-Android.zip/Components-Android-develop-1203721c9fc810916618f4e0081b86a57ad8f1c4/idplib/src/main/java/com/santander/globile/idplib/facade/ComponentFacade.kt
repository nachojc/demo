package com.santander.globile.idplib.facade

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.santander.globile.idplib.intent
import com.santander.globile.idplib.utils.IDP_RETURN_STRING


/**
 * This class allows compatibility with WebViewBridge component in case the app contains
 * at least one web that needs this component.
 */
class ComponentFacade {

    /**
     * @param context Necessary to create the intent.
     * @param params Data as JSON with the URL of the IDP.
     *
     * @return An [Intent] with the necessary extras to launch the IDP [Activity].
     */
    fun getIntent(context: Context, params: String?): Intent = intent(context, params)


    /**
     * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the token of a valid
     * login as a [String].
     *
     * @param requestCode
     * @param resultCode
     * @param data
     *
     * @return Received token from a successful login.
     */

    fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?): String? {
        return data?.getStringExtra(IDP_RETURN_STRING) as String
    }
}