package com.santander.globile.barcodescannerlib.common

/**
 * Entity that holds the information of the code and user action
 *
 * @property content code readed
 * @property formatName type of code readed
 * @property scanCancelled return when user exit scan mode without read a code
 */
data class BarcodeScannerInfo(
    var content: String? = null,
    var formatName: String? = null,
    var scanCancelled: Boolean? = null
)