package com.santander.globile.barcodescannerlib

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.support.v4.app.Fragment
import com.google.gson.Gson
import com.google.zxing.integration.android.IntentIntegrator
import com.santander.globile.barcodescannerlib.activity.BarcodeScannerActivity
import com.santander.globile.barcodescannerlib.callback.BarcodeScannerCallback
import com.santander.globile.barcodescannerlib.common.BarcodeScannerInfo
import com.santander.globile.barcodescannerlib.common.BarcodeScannerRequest
import com.santander.globile.barcodescannerlib.common.getCodeInfoFromIntentData

/**
 * Launches the barcode scanner from a [Fragment].
 *
 * @param scanInstructions Hint text for the camera scan.
 */
fun Fragment.scanCode(scanInstructions: String?) {
    val scanIntegrator = IntentIntegrator.forSupportFragment(this)
    scanInstructions?.let {
        scanIntegrator.setPrompt(it + "\n")
    }
    scanIntegrator.setOrientationLocked(false)
    scanIntegrator.initiateScan()
}

/**
 * Launches the barcode scanner from an [Activity].
 *
 *  @param scanInstructions Hint text for the camera scan.
 */
fun Activity.scanCode(scanInstructions: String?) {
    val scanIntegrator = IntentIntegrator(this)
    scanInstructions?.let {
        scanIntegrator.setPrompt(it + "\n")
    }
    scanIntegrator.setOrientationLocked(false)
    scanIntegrator.initiateScan()
}

/**
 * @param context Necessary to create the [Intent].
 * @param scanInstructions Hint text for the camera scan.
 *
 * @return An [Intent] with the necessary extras to launch the barcode scanner [Activity].
 */
fun intent(context: Context, scanInstructions: String? = null): Intent =
    Intent(context, BarcodeScannerActivity::class.java).apply {
        val gson = Gson()
        val instructions = gson.fromJson(scanInstructions, BarcodeScannerRequest::class.java)
        putExtra(BarcodeScannerActivity.EXTRA_SCAN_INSTRUCTIONS, instructions.scanInstructions)
    }

/**
 * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the scanned data
 * as [BarcodeScannerInfo]. Call when [Activity.onActivityResult] is called.
 *
 * @param requestCode Intent requestCode from onActivityResult method.
 * @param resultCode Intent resultCode from onActivityResult method.
 * @param data Intent data from onActivityResult method.
 * @param barcodeScannerCallback The result is returned using an interface of [BarcodeScannerCallback] type.
 */
fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?, barcodeScannerCallback: BarcodeScannerCallback) {
    getCodeInfoFromIntentData(resultCode, data)?.let { barcodeScannerCallback.onCodeScanCompleted(it) }
        ?: barcodeScannerCallback.onCodeScanCancelled()
}

/**
 * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the scanned data
 * as [BarcodeScannerInfo]. Call when [Activity.onActivityResult] is called.
 *
 * @param requestCode Intent requestCode from onActivityResult method.
 * @param resultCode Intent resultCode from onActivityResult method.
 * @param data Intent data from onActivityResult method.
 * @return [BarcodeScannerInfo] instance with scanned barcode data. It may be null.
 */
fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?): BarcodeScannerInfo? =
    getCodeInfoFromIntentData(resultCode, data)?.let {
        it
} ?: BarcodeScannerInfo(null, null, true)
