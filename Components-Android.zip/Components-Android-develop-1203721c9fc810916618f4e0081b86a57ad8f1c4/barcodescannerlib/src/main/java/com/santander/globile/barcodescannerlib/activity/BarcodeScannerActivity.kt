package com.santander.globile.barcodescannerlib.activity

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import com.santander.globile.barcodescannerlib.scanCode

class BarcodeScannerActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scanInstructions = loadParams()
        scanCode(scanInstructions)

    }

    private fun loadParams(): String? {
        return if (intent.hasExtra(EXTRA_SCAN_INSTRUCTIONS)) {
            intent?.extras?.getString(EXTRA_SCAN_INSTRUCTIONS)
        } else {
            null
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        setResult(resultCode, data)
        finish()
    }

    companion object {
        const val EXTRA_SCAN_INSTRUCTIONS = "SCAN_INSTRUCTIONS"
    }
}