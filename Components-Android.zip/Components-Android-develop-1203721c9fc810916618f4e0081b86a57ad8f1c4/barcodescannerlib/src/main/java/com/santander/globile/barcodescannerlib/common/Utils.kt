package com.santander.globile.barcodescannerlib.common

import android.content.Intent
import com.google.zxing.integration.android.IntentIntegrator

internal fun getCodeInfoFromIntentData(resultCode: Int, data: Intent?): BarcodeScannerInfo? {
    if (data == null) return null
    val result = IntentIntegrator.parseActivityResult(IntentIntegrator.REQUEST_CODE, resultCode, data)
    return if (result != null) {
        if (result.contents == null) {
            null
        } else {
            BarcodeScannerInfo(result.contents,result.formatName, false)
        }
    } else {
        BarcodeScannerInfo(null, null, false)
    }
}