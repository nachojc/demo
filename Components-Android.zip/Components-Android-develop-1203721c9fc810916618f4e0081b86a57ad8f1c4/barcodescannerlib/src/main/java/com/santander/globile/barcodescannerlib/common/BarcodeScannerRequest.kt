package com.santander.globile.barcodescannerlib.common

data class BarcodeScannerRequest (
    var scanInstructions: String? = null
)