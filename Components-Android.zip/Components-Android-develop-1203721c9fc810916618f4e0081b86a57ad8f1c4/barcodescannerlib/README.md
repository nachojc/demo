# Introduction 
This component provides barcode scanning using the device's camera to read the data from a barcode image.

# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':barcodescannerlib')
```
3. Sync project with Gradle files

# Use
## From Native app
### Scan barcode
Launch the barcode scanner with `scanCode (scanInstructions: String?)`:
```kotlin
scanCode("Scan product barcode")
```
Then collect the read data with `handleOnActivityResult (requestCode: Int, resultCode: Int, data: Intent?): String?` in the onActivityResult function, using `onCodeScanCompleted(scannerInfo: BarcodeScannerInfo)` and `onCodeScanCancelled()` to handle each case:
```kotlin
override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
    super.onActivityResult(requestCode, resultCode, data)
 
    // Result received using callback
    handleOnActivityResult(requestCode, resultCode, data, object : BarcodeScannerCallback {
 
        override fun onCodeScanCompleted(scannerInfo: BarcodeScannerInfo) {
            barcodescanner_result_textview.text = scannerInfo.content
        }
 
        override fun onCodeScanCancelled() {
            barcodescanner_result_textview.text = getString(R.string.barcodescanner_scan_cancelled)
        }
    })
 
}
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-android/tree/master/webviewbridgelib). Call the function with the following values:

componentName: "barcodescannerlib"

componentParams: 
```javascript
{
    "scanInstructions": "Scan product barcode",  // Message when scanning
}
```

The returned Promise will be resolved with the following JSON object:
```javascript
{
    "content": "String?",     
    "formatName": "String?",
    "scanCancelled": boolean
}
```
If user exit from scanner activity, the JSON only will return "scanCancelled": true
### Scan barcode
```javascript
callComponent('barcodescannerlib').then((res) => {
    console.log(res.content)
})
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "barcodescannerlib" from the Project sidemenu
4. Select Build -> Make Module 'barcodescannerlib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/barcodescannerlib/build/outputs/aar/

# Test
1. Open Components-Android project in Android Studio
2. Open "barcodescannerlib" from the Project sidemenu
3. Open "java/com.santander.globile.barcodescannerlib.common (test)"
4. Open file "UtilsTest"
5. Click ► icon next to "class UtilsTest"
