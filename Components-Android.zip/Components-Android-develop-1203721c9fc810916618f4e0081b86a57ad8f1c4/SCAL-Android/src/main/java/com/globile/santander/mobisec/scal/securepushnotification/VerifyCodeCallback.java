package com.globile.santander.mobisec.scal.securepushnotification;

public interface VerifyCodeCallback {

    void onCodeVerified();

    void onCodeError();
}
