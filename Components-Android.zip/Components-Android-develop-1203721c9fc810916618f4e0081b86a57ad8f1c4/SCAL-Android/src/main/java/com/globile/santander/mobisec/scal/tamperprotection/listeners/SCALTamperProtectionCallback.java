package com.globile.santander.mobisec.scal.tamperprotection.listeners;

/**
 * This callback is called when the verification ends.
 * The application shall block itself if the result is not true.
 */
public interface SCALTamperProtectionCallback {

    /**
     * @param result True if successful, False if failed, Null if verification process could not be performed.
     */
    void onPackageVerificationResult(Boolean result);

}
