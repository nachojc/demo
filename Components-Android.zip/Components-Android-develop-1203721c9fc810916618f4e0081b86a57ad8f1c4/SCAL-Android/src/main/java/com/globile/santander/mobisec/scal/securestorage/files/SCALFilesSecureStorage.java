package com.globile.santander.mobisec.scal.securestorage.files;

import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;

public class SCALFilesSecureStorage implements SCALFilesSecureStorageModule {
	
	private SCALFilesSecureStorageModule secureStorageImpl;
	
	public SCALFilesSecureStorage(SCALFilesSecureStorageModule secureStorageImpl) {
		this.secureStorageImpl = secureStorageImpl;
	}
	
	@Override
	@WorkerThread
	public boolean removeSecurefile(String alias) {
		return secureStorageImpl.removeSecurefile(alias);
	}
	
	@Override
	@WorkerThread
	public boolean clearSecurefile(String alias) {
		return secureStorageImpl.clearSecurefile(alias);
	}
	
	@Override
	@WorkerThread
	public boolean writeToSecureFile(String alias, byte[] data, SCALFileMode fileMode) {
		return secureStorageImpl.writeToSecureFile(alias, data, fileMode);
	}
	
	@Override
	public boolean writeToSecureFile(String alias, byte[] data) {
		return secureStorageImpl.writeToSecureFile(alias, data);
	}
	
	@Override
	@Nullable
	public byte[] readFromSecurefile(String alias) {
		return secureStorageImpl.readFromSecurefile(alias);
	}
	
}
