package com.globile.santander.mobisec.scal.biometricvault;

public class SCALBiometricVault implements SCALBiometricVaultModule {

    private SCALBiometricVaultModule scalBiometricVault;

    public SCALBiometricVault(SCALBiometricVaultModule scalBiometricVault) {
        this.scalBiometricVault = scalBiometricVault;
    }

    @Override
    public void storeCredentialAuthenticated(StoreCredentialCallback callback, String credential, String key, Integer duration) {
        scalBiometricVault.storeCredentialAuthenticated(callback, credential, key, duration);
    }

    @Override
    public void getCredentialAuthenticated(RequestCredentialCallback callback, String key) {
        scalBiometricVault.getCredentialAuthenticated(callback, key);
    }

}
