package com.globile.santander.mobisec.scal.securestorage.files;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;

public interface SCALFilesSecureStorageModule {
	
	/**
	 * Write any data on a secure file.
	 *
	 * @param data  byte array to be written
	 * @param alias the alias of the file
	 * @param fileMode write mode: overwrite, append or default
	 *
	 * @return true if the data was written, false otherwise
	 */
	@WorkerThread
	boolean writeToSecureFile(String alias, byte[] data, SCALFileMode fileMode);
	
	/**
	 * Write any data on a secure file. Using SCALFileMode.DEFAULT
	 *
	 * @param data  byte array to be written
	 * @param alias the alias of the file
	 *
	 * @return true if the data was written, false otherwise
	 */
	@WorkerThread
	boolean writeToSecureFile(String alias, byte[] data);
	
	/**
	 * Retrieve data provided by any secure file.
	 *
	 * @param alias the alias of the file
	 *
	 * @return the previously stored POJO
	 */
	@WorkerThread
	@Nullable
	byte[] readFromSecurefile(String alias);
	/**
	 * Delete an existing secure file
	 *
	 * @param alias tthe alias of the file
	 *
	 * @return true if the file was deleted or it did not exist, false otherwise
	 */
	@WorkerThread
	boolean removeSecurefile(String alias);
	
	/**
	 * Clear the secure file. It first delete the file and then create a new one.
	 *
	 * @param alias the alias of the file
	 *
	 * @return true if the file was cleared, false otherwise
	 */
	@WorkerThread
	boolean clearSecurefile(String alias);
	
}
