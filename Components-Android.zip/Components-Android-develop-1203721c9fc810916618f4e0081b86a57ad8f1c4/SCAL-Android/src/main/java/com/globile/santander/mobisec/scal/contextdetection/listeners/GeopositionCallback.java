package com.globile.santander.mobisec.scal.contextdetection.listeners;

public interface GeopositionCallback {
	
	/**
	 * @return If true, the first attempt to request location updates will result in a dialog
	 * to enable GPS on the device (if not enabled yet).
	 */
	boolean showEnableGpsDialog();
	
}