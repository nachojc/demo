package com.globile.santander.mobisec.scal.contextdetection.models;

import android.location.Address;
import android.support.annotation.Nullable;

public class SCALGeoData {

    private Address address;

    private SCALIpAddress ipAddress;

    public SCALGeoData(@Nullable Address address, @Nullable SCALIpAddress ipAddress) {
        this.address = address;
        this.ipAddress = ipAddress;
    }

    @Nullable
    public Address getAddress() {
        return address;
    }

    @Nullable
    public SCALIpAddress getIpAddress() {
        return ipAddress;
    }

}
