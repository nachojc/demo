package com.globile.santander.mobisec.scal.securestorage.database;

import com.globile.santander.mobisec.scal.securestorage.listeners.SCALDatabaseSecureStorageCallback;
import com.globile.santander.mobisec.scal.securestorage.models.SCALDBResult;

public class SCALDatabaseSecureStorage implements SCALDatabaseSecureStorageModule {
	
	private SCALDatabaseSecureStorageModule secureStorageImpl;
	
	public SCALDatabaseSecureStorage(SCALDatabaseSecureStorageModule secureStorageImpl) {
		this.secureStorageImpl = secureStorageImpl;
	}
	
	@Override
	public void initDatabase(String name, int version, SCALDatabaseSecureStorageCallback scalDatabaseSecureStorageCallback) {
		secureStorageImpl.initDatabase(name, version, scalDatabaseSecureStorageCallback);
	}
	
	@Override
	public boolean removeDatabase() {
		return secureStorageImpl.removeDatabase();
	}
	
	@Override
	public SCALDBResult executeQuery(String query, String[] args) {
		return secureStorageImpl.executeQuery(query, args);
	}
	
	@Override
	public void executeSQL(String sqlStatement, String[] args) {
		secureStorageImpl.executeSQL(sqlStatement, args);
	}
}
