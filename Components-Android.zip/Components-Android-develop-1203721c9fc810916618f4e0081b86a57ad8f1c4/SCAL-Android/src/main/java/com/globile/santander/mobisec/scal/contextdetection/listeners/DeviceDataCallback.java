package com.globile.santander.mobisec.scal.contextdetection.listeners;

import com.globile.santander.mobisec.scal.contextdetection.models.SCALDeviceData;

public interface DeviceDataCallback {
	
	/**
	 * Called when the data is ready to use
	 *
	 * @param deviceData device information
	 */
	void onDeviceDataReady(SCALDeviceData deviceData);
	
}