package com.globile.santander.mobisec.scal.tamperprotection;

import com.globile.santander.mobisec.scal.tamperprotection.listeners.SCALTamperProtectionCallback;

public class SCALTamperProtection implements SCALTamperProtectionModule {

    private SCALTamperProtectionModule tamperProtectionImpl;

    public SCALTamperProtection(SCALTamperProtectionModule tamperProtectionImpl) {
        this.tamperProtectionImpl = tamperProtectionImpl;
    }

    @Override
    public void verifySignature(String fingerprint, SCALTamperProtectionCallback callback) {
        tamperProtectionImpl.verifySignature(fingerprint, callback);
    }
}
