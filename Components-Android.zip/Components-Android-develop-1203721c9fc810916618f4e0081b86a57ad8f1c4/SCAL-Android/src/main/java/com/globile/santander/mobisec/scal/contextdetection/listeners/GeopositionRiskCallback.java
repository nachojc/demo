package com.globile.santander.mobisec.scal.contextdetection.listeners;

import com.globile.santander.mobisec.scal.contextdetection.models.DeviceRiskStruct;

import java.util.List;

public interface GeopositionRiskCallback extends GeopositionCallback {
	
	/**
	 * Called when the calculations risk struct is ready
	 *
	 * @param geopositionRisks
	 */
	void onGeopositionRiskReady(List<DeviceRiskStruct> geopositionRisks);
	
}