package com.globile.santander.mobisec.scal.contextdetection;

import android.app.Activity;
import com.globile.santander.mobisec.scal.contextdetection.listeners.*;
import com.globile.santander.mobisec.scal.contextdetection.models.DeviceRiskStruct;

import java.util.List;

public class SCALContextDetection implements SCALContextDetectionModule {
	
	private SCALContextDetectionModule contextDetectionImpl;
	
	public SCALContextDetection(SCALContextDetectionModule contextDetectionImpl) {
		this.contextDetectionImpl = contextDetectionImpl;
	}
	
	@Override
	public List<String> getUserBinding() {
		return contextDetectionImpl.getUserBinding();
	}
	
	@Override
	public String getDeviceFootprint() {
		return contextDetectionImpl.getDeviceFootprint();
	}
	
	@Override
	public void setDeviceFootprint(String footprint) {
		contextDetectionImpl.setDeviceFootprint(footprint);
	}
	
	@Override
	public List<DeviceRiskStruct> getDeviceRiskData() {
		return contextDetectionImpl.getDeviceRiskData();
	}
	
	@Override
	public List<DeviceRiskStruct> getApplicationRiskData() {
		return contextDetectionImpl.getApplicationRiskData();
	}
	
	@Override
	public List<DeviceRiskStruct> getCommunicationRiskData() {
		return contextDetectionImpl.getCommunicationRiskData();
	}
	
	@Override
	public void getGeopositionRiskData(GeopositionRiskCallback geopositionRiskCallback, Activity activity) {
		contextDetectionImpl.getGeopositionRiskData(geopositionRiskCallback, activity);
	}
	
	@Override
	public void getAllRiskData(RiskStructCallback riskCallback, Activity activity) {
		contextDetectionImpl.getAllRiskData(riskCallback, activity);
	}
	
	@Override
	public void getDeviceData(DeviceDataCallback deviceDataCallback) {
		contextDetectionImpl.getDeviceData(deviceDataCallback);
	}
	
	@Override
	public void getApplicationData(ApplicationDataCallback applicationDataCallback) {
		contextDetectionImpl.getApplicationData(applicationDataCallback);
	}
	
	@Override
	public void getCommunicationData(CommsDataCallback commsDataCallback) {
		contextDetectionImpl.getCommunicationData(commsDataCallback);
	}
	
	@Override
	public void getGeopositionData(GeopositionDataCallback geopositionDataCallback, Activity activity) {
		contextDetectionImpl.getGeopositionData(geopositionDataCallback, activity);
	}
	
	@Override
	public void getAllData(ContextDataCallback callback, GeopositionDataCallback geopositionDataCallback, Activity activity) {
		contextDetectionImpl.getAllData(callback, geopositionDataCallback, activity);
	}
}
