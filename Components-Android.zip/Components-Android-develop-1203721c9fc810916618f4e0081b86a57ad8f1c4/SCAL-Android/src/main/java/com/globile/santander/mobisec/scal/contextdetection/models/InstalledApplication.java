package com.globile.santander.mobisec.scal.contextdetection.models;

import java.util.ArrayList;
import java.util.List;

public class InstalledApplication {
	
	private String name;
	private int category;
	private String packageName;
	private int kernelUID;
	private String description;
	private List<AppNetworkInfo> appNetworkInfoList;
	
	public InstalledApplication() {
		this.appNetworkInfoList = new ArrayList<>();
	}
	
	public InstalledApplication(String name, int category, String packageName, int kernelUID, String description) {
		this.name = name;
		this.category = category;
		this.packageName = packageName;
		this.kernelUID = kernelUID;
		this.description = description;
		this.appNetworkInfoList = new ArrayList<>();
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public int getCategory() {
		return category;
	}
	
	public void setCategory(int category) {
		this.category = category;
	}
	
	public String getPackageName() {
		return packageName;
	}
	
	public void setPackageName(String packageName) {
		this.packageName = packageName;
	}
	
	public int getKernelUID() {
		return kernelUID;
	}
	
	public void setKernelUID(int kernelUID) {
		this.kernelUID = kernelUID;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public List<AppNetworkInfo> getAppNetworkInfoList() {
		return appNetworkInfoList;
	}
	
	public void setAppNetworkInfoList(List<AppNetworkInfo> appNetworkInfoList) {
		this.appNetworkInfoList = appNetworkInfoList;
	}
	
	public void addAppNetworkInfo(AppNetworkInfo appNetworkInfo) {
		this.appNetworkInfoList.add(appNetworkInfo);
	}
	
	@Override
	public String toString() {
		return "ApplicationData{" +
				"Name='" + name + '\'' +
				", Category=" + category +
				", PackageName='" + packageName + '\'' +
				", KernelUID=" + kernelUID +
				", Description='" + description + '\'' +
				", AppNetworkInfoList=" + appNetworkInfoList +
				'}';
	}
}