package com.globile.santander.mobisec.scal.contextdetection.models;

public class DeviceRiskStruct {
	
	private String parameter;
	private String valueDetected;
	private int riskCalculated;
	
	public DeviceRiskStruct() {
	}
	
	public DeviceRiskStruct(String parameter, String valueDetected, int riskCalculated) {
		this.parameter = parameter;
		this.valueDetected = valueDetected;
		this.riskCalculated = riskCalculated;
	}
	
	public String getParameter() {
		return parameter;
	}
	
	public void setParameter(String parameter) {
		this.parameter = parameter;
	}
	
	public String getValueDetected() {
		return valueDetected;
	}
	
	public void setValueDetected(String valueDetected) {
		this.valueDetected = valueDetected;
	}
	
	public int getRiskCalculated() {
		return riskCalculated;
	}
	
	public void setRiskCalculated(int riskCalculated) {
		this.riskCalculated = riskCalculated;
	}
	
	@Override
	public String toString() {
		return "DeviceRiskStruct{" +
				"parameter='" + parameter + '\'' +
				", valueDetected='" + valueDetected + '\'' +
				", riskCalculated=" + riskCalculated +
				'}';
	}
}
