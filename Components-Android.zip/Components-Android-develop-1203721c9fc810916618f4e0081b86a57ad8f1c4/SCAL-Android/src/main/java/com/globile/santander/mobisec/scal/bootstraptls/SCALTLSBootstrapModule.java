package com.globile.santander.mobisec.scal.bootstraptls;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import okhttp3.OkHttpClient;
import okhttp3.TlsVersion;

import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import java.util.Map;

public interface SCALTLSBootstrapModule {
	
	TlsVersion[] allowedTlsVersions = new TlsVersion[] { TlsVersion.TLS_1_2, TlsVersion.TLS_1_3 };
	
	/**
	 * @param clientBuilder Must be provided
	 * @param trustManager  Certificate manager
	 * @param tlsVersion    only TLS_1_2 and TLS_1_3 allowed
	 */
	void enableTLS(@NonNull OkHttpClient.Builder clientBuilder,
	               @NonNull X509TrustManager trustManager,
	               @NonNull TlsVersion tlsVersion);
	
	/**
	 * @param clientBuilder Must be provided
	 * @param trustManager  Certificate manager
	 * @param tlsVersion    only TLS_1_2 and TLS_1_3 allowed
	 * @param sslContext    custom SSLContext
	 */
	void enableTLS(@NonNull OkHttpClient.Builder clientBuilder,
	               @NonNull X509TrustManager trustManager,
	               @NonNull TlsVersion tlsVersion,
	               @Nullable SSLContext sslContext);
	
	/**
	 * @param clientBuilder Must be provided
	 * @param pins          {@link Map} of pins. A pattern name may have more than one pin
	 */
	void addPins(@NonNull OkHttpClient.Builder clientBuilder,
	             @NonNull Map<String, String[]> pins);
}
