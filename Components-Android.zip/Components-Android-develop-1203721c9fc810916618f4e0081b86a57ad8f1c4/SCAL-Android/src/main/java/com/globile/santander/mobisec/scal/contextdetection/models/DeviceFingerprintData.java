package com.globile.santander.mobisec.scal.contextdetection.models;

public class DeviceFingerprintData {
	
	private String IMEI;
	
	private String IMSI;
	
	public DeviceFingerprintData() {
	}
	
	public DeviceFingerprintData(String IMEI, String IMSI) {
		this.IMEI = IMEI;
		this.IMSI = IMSI;
	}
	
	public String getIMEI() {
		return IMEI;
	}
	
	public void setIMEI(String IMEI) {
		this.IMEI = IMEI;
	}
	
	public String getIMSI() {
		return IMSI;
	}
	
	public void setIMSI(String IMSI) {
		this.IMSI = IMSI;
	}
	
	@Override
	public String toString() {
		return "DeviceFingerprintData{" +
				"IMEI='" + IMEI + '\'' +
				", IMSI='" + IMSI + '\'' +
				'}';
	}
}
