package com.globile.santander.mobisec.scal.contextdetection.listeners;

import com.globile.santander.mobisec.scal.contextdetection.models.SCALContextData;

public interface ContextDataCallback {
	
	/**
	 * @param contextData class containing all the information. Inside there are three categories: Application, Comms and Device data related<br/>
	 */
	void onContextDataReady(SCALContextData contextData);
	
}