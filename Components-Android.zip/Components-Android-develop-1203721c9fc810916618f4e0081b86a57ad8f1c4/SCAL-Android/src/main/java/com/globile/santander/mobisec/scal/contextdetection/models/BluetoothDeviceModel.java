package com.globile.santander.mobisec.scal.contextdetection.models;

public class BluetoothDeviceModel {

    private String deviceName;
    private String address;
    private Integer type;

    public BluetoothDeviceModel(){}

    public BluetoothDeviceModel(String deviceName, String address, Integer type) {
        this.deviceName = deviceName;
        this.address = address;
        this.type = type;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "BluetoothDeviceModel{" +
                "deviceName='" + deviceName + '\'' +
                ", address='" + address + '\'' +
                ", type=" + type +
                '}';
    }
}
