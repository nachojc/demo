package com.globile.santander.mobisec.scal.contextdetection.models;

public class NetworkAddressConnection {

    private String protocol;

    private String localAddress;

    private String foreingAddress;

    private String state;

    private String txq;

    private String rxq;

    public NetworkAddressConnection(){}

    public NetworkAddressConnection(String protocol, String localAddress, String foreingAddress, String state, String txq, String rxq) {
        this.protocol = protocol;
        this.localAddress = localAddress;
        this.foreingAddress = foreingAddress;
        this.state = state;
        this.txq = txq;
        this.rxq = rxq;
    }

    public String getProtocol() {
        return protocol;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public String getLocalAddress() {
        return localAddress;
    }

    public void setLocalAddress(String localAddress) {
        this.localAddress = localAddress;
    }

    public String getForeingAddress() {
        return foreingAddress;
    }

    public void setForeingAddress(String foreingAddress) {
        this.foreingAddress = foreingAddress;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getTxq() {
        return txq;
    }

    public void setTxq(String txq) {
        this.txq = txq;
    }

    public String getRxq() {
        return rxq;
    }

    public void setRxq(String rxq) {
        this.rxq = rxq;
    }

    @Override
    public String toString() {
        return "NetworkAddressConnection{" +
                "Protocol='" + protocol + '\'' +
                ", Local Address='" + localAddress + '\'' +
                ", Foreing Address='" + foreingAddress + '\'' +
                ", State='" + state + '\'' +
                ", Txq='" + txq + '\'' +
                ", Rxq='" + rxq + '\'' +
                '}' + "\n";
    }
}
