package com.globile.santander.mobisec.scal.securestorage.listeners;
import net.sqlcipher.database.SQLiteDatabase;

public interface SCALDatabaseSecureStorageCallback {
	
	/**
	 * Called the first time the database is created. Here the developer may create the database structure, tables and columns
	 */
	void onCreate(SQLiteDatabase sqLiteDatabase);
	
	/**
	 * Called when the database already exist but the version does not match
	 *
	 * @param oldVersion the current database version
	 * @param newVersion the new database version
	 */
	void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion);
	
}
