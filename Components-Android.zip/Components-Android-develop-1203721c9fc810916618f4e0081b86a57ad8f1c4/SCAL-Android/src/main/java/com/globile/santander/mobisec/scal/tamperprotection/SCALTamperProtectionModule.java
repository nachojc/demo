package com.globile.santander.mobisec.scal.tamperprotection;

import com.globile.santander.mobisec.scal.tamperprotection.listeners.SCALTamperProtectionCallback;

/**
 * Will check if the provided fingerprint is the authentic one
 */
public interface SCALTamperProtectionModule {

    /**
     * Verifies if the signature of the application is authentic.
     * @param fingerprint The fingerprint of the application to check
     * @param callback A callback whose method will be called when the test ends
     */
    void verifySignature(String fingerprint, SCALTamperProtectionCallback callback);

}
