package com.globile.santander.mobisec.scal.securestorage.database;

import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import com.globile.santander.mobisec.scal.securestorage.listeners.SCALDatabaseSecureStorageCallback;
import com.globile.santander.mobisec.scal.securestorage.models.SCALDBResult;
import net.sqlcipher.database.SQLiteException;

public interface SCALDatabaseSecureStorageModule {
	
	/**
	 * Initialize database. Mandatory to call every time the application runs
	 *
	 * @param name     the name of the database
	 * @param version  the current version of the database
	 * @param callback used to handle database initialization progress. It has 2 methods, one for creating the database the first time and the second for
	 *                 upgrading it
	 */
	@WorkerThread
	void initDatabase(String name, int version, SCALDatabaseSecureStorageCallback callback);
	
	/**
	 * Deletes the database. After this, the database should be initialized
	 *
	 * @return if the database was successfully deleted; else false .
	 */
	@WorkerThread
	boolean removeDatabase();
	
	/**
	 * Make a query to the database
	 *
	 * @param query the SQL query. The SQL string must not be ; terminated
	 * @param args  You may include ?s in where clause in the query,
	 *              which will be replaced by the values from selectionArgs. The
	 *              values will be bound as Strings.
	 *
	 * @return A SCALDBResult object, which contains all the data .
	 *
	 * @throws SQLiteException if there is an issue executing the sql or the SQL string is invalid
	 */
	@WorkerThread
	SCALDBResult executeQuery(String query, @Nullable String[] args);
	
	/**
	 * Execute a single SQL statement that is NOT a SELECT or any other SQL statement that returns data.
	 *
	 * @param sqlStatement the SQL statement. The SQL string must not be ; terminated
	 * @param args         You may include ?s in where clause in the query,
	 *                     which will be replaced by the values from selectionArgs. The
	 *                     values will be bound as Strings.
	 *
	 * @throws SQLiteException if there is an issue executing the sql or the SQL string is invalid
	 */
	@WorkerThread
	void executeSQL(String sqlStatement, @Nullable String[] args);
}
