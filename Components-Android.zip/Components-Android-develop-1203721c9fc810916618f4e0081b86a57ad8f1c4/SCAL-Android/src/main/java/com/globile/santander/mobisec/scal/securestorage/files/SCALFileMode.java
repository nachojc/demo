package com.globile.santander.mobisec.scal.securestorage.files;

/**
 * File behaviours:
 * OVERWRITE_MODE: will overwrite if the file exists, otherwise it will create a new one.
 * APPEND_MODE: will append at the end of the file if it exists, otherwise it will create a new one.
 * DEFAULT_MODE: will fail if the file exists, otherwise it will create a new one.
 */
public enum SCALFileMode {
	OVERWRITE_MODE,
	APPEND_MODE,
	DEFAULT_MODE,
}

