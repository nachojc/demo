package com.globile.santander.mobisec.scal.securepushnotification;

/**
 * Created by oandujar on 12/03/2019.
 */
public interface SCALSecurePushNotificationModule {

    /**
     * This function will communicate with the backend server in order to start the sending
     * of a new code to the device. This function will calculate using the context detection module
     * the fingerprint of the device and then send this request to the server. This function also will
     * communicate with the backend server for first time.
     *
     * @param token will send at backend
     */
    void registerToken(String token);

    /**
     * This function will communicate with the backend server in order to request a new Second Factor
     * Authenticator. This function will calculate using the context detection module the fingerprint
     * of the device and then it will send this request to the back end server.
     */
    void requestNewSecondFactorAuthentication();

    /**
     * This method will send the code at backend in order to make a verification.
     * @param inputCode that user has entered
     */
    void verifyCode(VerifyCodeCallback verifyCodeCallback, String inputCode);

}
