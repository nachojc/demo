package com.globile.santander.mobisec.scal.biometricvault;

public interface RequestCredentialCallback {

    /**
     * If get credentialAuthenticated succeeds, the value of the stored credential should be
     * returned by this method.
     *
     * @return value of the stored credential, if not it should return a null value
     */
    void onCredentialAuthenticatedReady(String credential);

    /**
     * Triggered when a error becomes.
     * @param message
     */
    void onRequestCredentialFailure(String message);
}
