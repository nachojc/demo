package com.globile.santander.mobisec.scal.contextdetection.models;

import java.util.List;
import java.util.Map;

public class SCALApplicationData {
	
	private Map<DeviceDataKey, String> applicationData;
	private List<InstalledApplication> applicationList;
	private List<String> accounts;
	
	public SCALApplicationData(Map<DeviceDataKey, String> applicationData, List<InstalledApplication> applicationList, List<String> accounts) {
		this.applicationData = applicationData;
		this.applicationList = applicationList;
		this.accounts = accounts;
	}
	
	public Map<DeviceDataKey, String> getApplicationData() {
		return applicationData;
	}
	
	public List<InstalledApplication> getApplicationList() {
		return applicationList;
	}
	
	public List<String> getAccounts() {
		return accounts;
	}
}
