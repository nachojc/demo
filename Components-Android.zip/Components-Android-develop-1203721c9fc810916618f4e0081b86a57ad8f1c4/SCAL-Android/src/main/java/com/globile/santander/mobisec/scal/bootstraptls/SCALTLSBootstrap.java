package com.globile.santander.mobisec.scal.bootstraptls;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import okhttp3.OkHttpClient;
import okhttp3.TlsVersion;

import javax.net.ssl.SSLContext;
import javax.net.ssl.X509TrustManager;
import java.util.Map;

public class SCALTLSBootstrap implements SCALTLSBootstrapModule {
	
	private SCALTLSBootstrapModule tlsBootstrapImpl;
	
	public SCALTLSBootstrap(SCALTLSBootstrapModule tlsBootstrapImpl) {
		this.tlsBootstrapImpl = tlsBootstrapImpl;
	}
	
	@Override
	public void enableTLS(@NonNull OkHttpClient.Builder clientBuilder, @NonNull X509TrustManager trustManager, @NonNull TlsVersion tlsVersion) {
		tlsBootstrapImpl.enableTLS(clientBuilder, trustManager, tlsVersion);
	}
	
	@Override
	public void enableTLS(
			@NonNull OkHttpClient.Builder clientBuilder,
			@NonNull X509TrustManager trustManager, @NonNull TlsVersion tlsVersion, @Nullable SSLContext sslContext) {
		tlsBootstrapImpl.enableTLS(clientBuilder, trustManager, tlsVersion, sslContext);
	}
	
	@Override
	public void addPins(@NonNull OkHttpClient.Builder clientBuilder, @NonNull Map<String, String[]> pins) {
		tlsBootstrapImpl.addPins(clientBuilder, pins);
	}
}
