package com.globile.santander.mobisec.scal.securestorage.models;
import java.util.ArrayList;
import java.util.Map;

public class SCALDBResult extends ArrayList<Map<String, Object>> {
	
	private int current = 0;
	
	public <T> T getEntry(String key) {
		T value;
		if (isEmpty() || !get(current).containsKey(key)) return null;
		try {
			value = (T) get(current).get(key);
		} catch (ClassCastException e) {
			return null;
		}
		return value;
	}
	
	public boolean moveToFirst() {
		if (isEmpty()) return false;
		current = 0;
		return true;
	}
	
	public boolean moveToLast() {
		if (isEmpty()) return false;
		current = size() - 1;
		return true;
	}
	
	public boolean next() {
		if (isEmpty() || current == size() - 1) return false;
		current++;
		return true;
	}
}
