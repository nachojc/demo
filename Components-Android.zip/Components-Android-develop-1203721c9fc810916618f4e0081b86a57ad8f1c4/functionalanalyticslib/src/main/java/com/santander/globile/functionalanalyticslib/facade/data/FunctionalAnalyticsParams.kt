package com.santander.globile.functionalanalyticslib.facade.data

/**
 * Entity that holds Functional Analytics params.
 *
 * @param operation can contains: "log_event" or "set_user_property" data.
 * @param eventType: the type associated to analytics event.
 * @param params: Map or dictionary [params] to send for each event or properties to set to user.
 */

data class FunctionalAnalyticsParams(
    val operation: String? = null,
    val eventType: String? = null,
    val params: Any? = null
)

/**
 * Entity that holds Functional Analytics Response.
 *
 * @param success: the type associated to analytics event.
 * @param operation can contains: "log_event" or "set_user_property" data.
 */
data class FunctionalAnalyticsResult(
    val success: Boolean = false,
    val operation: String? = null
)
