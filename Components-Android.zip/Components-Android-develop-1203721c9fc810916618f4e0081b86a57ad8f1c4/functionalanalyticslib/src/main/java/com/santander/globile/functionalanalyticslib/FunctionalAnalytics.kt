package com.santander.globile.functionalanalyticslib

import android.content.Context
import android.os.Bundle
import com.google.firebase.analytics.FirebaseAnalytics

class FunctionalAnalytics {

    companion object {

        var firebaseAnalytics: FirebaseAnalytics? = null

        /**
         * This initialization method must be called using application [Context]
         * to create a [FunctionalAnalytics] singleton instance.
         * @param context Necessary context to instantiate singleton [FunctionalAnalytics] instance
         */
        fun init(context: Context) {
            // Obtain the FirebaseAnalytics instance.
            firebaseAnalytics = FirebaseAnalytics.getInstance(context)
        }

        /**
         * Log event in Firebase Analytics using singleton instance of Functional Analytics.
         *
         * @param eventType name of the custom event to register
         * @param map dictionary of key-value pairs with custom parameters associated to the event
         * @throws IllegalAccessException Throws an [IllegalAccessException] when FunctionalAnalytics Singleton instance
         * has not been initialized.
         */
        fun logEvent(eventType: String, map: HashMap<String,Any?>) {
            val bundle = Bundle()
            for (entry in map) {
                when (entry.value?.javaClass?.name) {
                    Boolean.javaClass.name ->
                        bundle.putBoolean(entry.key, entry.value as Boolean)
                    Double.javaClass.name ->
                        bundle.putDouble(entry.key, entry.value as Double)
                    Int.javaClass.name ->
                        bundle.putInt(entry.key, entry.value as Int)
                    Float.javaClass.name ->
                        bundle.putFloat(entry.key, entry.value as Float)
                    else ->
                        bundle.putString(entry.key, entry.value.toString())
                }
            }

            firebaseAnalytics?.logEvent(eventType, bundle)
                ?: error("FunctionalAnalytics must be initialized first.")
        }

        /**
         * Set user property in Firebase Analytics using singleton instance of Functional Analytics.
         *
         * @param key property name to asign to the user
         * @param value property value
         * @throws IllegalAccessException Throws an [IllegalAccessException] when FunctionalAnalytics Singleton instance
         * has not been initialized.
         */
        fun setUserProperty(key: String, value: Any?){
            firebaseAnalytics?.setUserProperty(key, value?.toString())
                ?: error("FunctionalAnalytics must be initialized first.")
        }

    }
}