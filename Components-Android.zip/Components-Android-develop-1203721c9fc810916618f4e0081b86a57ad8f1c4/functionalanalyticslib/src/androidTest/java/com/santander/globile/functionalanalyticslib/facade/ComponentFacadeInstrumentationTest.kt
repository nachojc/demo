package com.santander.globile.functionalanalyticslib.facade

class ComponentFacadeInstrumentationTest{

//    private val componentFacade = ComponentFacade()
//
//
//
//    @Test
//    fun testSendAnalyticsEventThroughComponentFacadeReturnResult() {
//        // Arrange
//        val appContext = InstrumentationRegistry.getTargetContext()
//        FunctionalAnalytics.init(appContext)
//        val mutableLiveData = componentFacade.liveData
//        val eventType = "select_content"
//        val request = "{" +
//                "  \"operation\": \"log_event\"," +
//                "  \"eventType\": \"$eventType\"," +
//                "  \"params\": {" +
//                "    \"item_id\": \"id_value\"," +
//                "    \"item_name\": \"name_value\"," +
//                "    \"content_type\": \"type_value\"," +
//                "    \"integer_value\": 123456" +
//                "  }" +
//                "}"
//
//
//        mutableLiveData.observeForever(observer)
//        val args = ArrayList<Any>()
//        args.add(request)
//        componentFacade.startComponent(args)
//
//        // Assert
//        val resultExpectedObj = ("{\"success\":true,\"operation\":\"log_event\"}").fromJson(FunctionalAnalyticsResult::class.java)
//        val resultObtainedObj = mutableLiveData.value?.fromJson(FunctionalAnalyticsResult::class.java)
//        assertEquals(resultExpectedObj, resultObtainedObj)
//
//    }
//
//    @Test
//    fun testSendBadformedJsonAnalyticsEventThroughComponentFacadeReturnNoSuccess() {
//        // Arrange
//        val appContext = InstrumentationRegistry.getTargetContext()
//        FunctionalAnalytics.init(appContext)
//
//        val eventType = "select_content"
//        val request = "{" +
//                "  \"operation\": \"log_event\"," +
//                "  \"eventType\": \"$eventType\"," +
//                "  \"params\": {" +
//                "    \"item_id\": \"id_value\"," +
//                "    \"item_name\": \"name_value\"," +
//                "    \"content_type\": \"type_value\"," +
//                "    \"integer_value\": 123456" +
//                "  " + //Missing "}"
//                "}"
//
//        // Act
//        val result = try {
//            componentFacade.startComponent(request)
//        } catch (e: Exception) {
//            e.message
//        }
//
//        // Assert
//        val resultExpectedObj = ("{\"success\":false,\"operation\":null}").fromJson(FunctionalAnalyticsResult::class.java)
//        val resultObtainedObj = result?.fromJson(FunctionalAnalyticsResult::class.java)
//        assertEquals(resultExpectedObj, resultObtainedObj)
//
//    }
//
//    @Test
//    fun testNotDefinedOperationToSendAnalyticsEventThroughComponentFacadeReturnNullOperation() {
//        // Arrange
//        val appContext = InstrumentationRegistry.getTargetContext()
//        FunctionalAnalytics.init(appContext)
//
//        val eventType = "select_content"
//        val request = "{" +
//                "  \"operation\": \"fake_operation\"," + //Not defined operation
//                "  \"eventType\": \"$eventType\"," +
//                "  \"params\": {" +
//                "    \"item_id\": \"id_value\"," +
//                "    \"item_name\": \"name_value\"," +
//                "    \"content_type\": \"type_value\"," +
//                "    \"integer_value\": 123456" +
//                "  }" +
//                "}"
//
//        // Act
//        val result = try {
//            componentFacade.startComponent(request)
//        } catch (e: Exception) {
//            e.message
//        }
//
//        // Assert
//        val resultExpectedObj = ("{\"success\":false,\"operation\":null}").fromJson(FunctionalAnalyticsResult::class.java)
//        val resultObtainedObj = result?.fromJson(FunctionalAnalyticsResult::class.java)
//        assertEquals(resultExpectedObj, resultObtainedObj)
//
//    }

}
