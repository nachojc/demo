package com.santander.globile.functionalanalyticslib.facade

import android.arch.core.executor.testing.InstantTaskExecutorRule
import android.arch.lifecycle.Observer
import org.junit.Assert
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class ComponentFacadeTest {

    private val componentFacade = ComponentFacade()
    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Mock
    lateinit var observer: Observer<String>


    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
    }

    @Test
    fun `Send analytics event through ComponentFacade must be initiated`() {
        // Arrange
        try {
            val eventType = "select_content"
            val request = "{" +
                    "  \"operation\": \"log_event\"," +
                    "  \"eventType\": \"$eventType\"," +
                    "  \"params\": {" +
                    "    \"item_id\": \"id_value\"," +
                    "    \"item_name\": \"name_value\"," +
                    "    \"content_type\": \"type_value\"," +
                    "    \"integer_value\": 123456" +
                    "  }" +
                    "}"

            val mutableLiveData = componentFacade.liveData
            mutableLiveData.observeForever(observer)
            val arg = ArrayList<Any>()
            arg.add(request)
            componentFacade.startComponent(arg)
        }catch (e: IllegalStateException){
            Assert.assertTrue(true)
        }



    }
}