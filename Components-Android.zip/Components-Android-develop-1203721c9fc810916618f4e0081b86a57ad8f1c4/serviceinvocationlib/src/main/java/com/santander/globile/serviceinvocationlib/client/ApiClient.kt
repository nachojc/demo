package com.santander.globile.serviceinvocationlib.client

import com.google.gson.GsonBuilder
import com.santander.globile.serviceinvocationlib.client.ApiClient.Builder
import okhttp3.CertificatePinner
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Configurable REST client with these parameters. It must be initialized via [Builder]:
 *  - API base URL.
 *  - Connection timeout. 10 seconds by default.
 *  - Read timeout. 10 seconds by default.
 *  - Write timeout. 10 seconds by default.
 *  - A [ApiClientLogLevel] to keep track in logs about HTTP request and responses. [ApiClientLogLevel.BODY] by default.
 *  - A date format necessary to parse dates from JSON. No date format provided by default.
 *  - [CertificatePin] list where each item is a pair formed by a hostname and its corresponding pin. Empty list by default.
 *  - Interceptor (from OkHttp3) list where each item is a request/response handler for example to add headers to the request. Empty list by default.
 */
class ApiClient private constructor(
    private var baseUrl: String,
    private val connectTimeout: Long = 10_000L, //milliseconds
    private val readTimeout: Long = 10_000L, //milliseconds
    private val writeTimeout: Long = 10_000L, //milliseconds
    logLevel: ApiClientLogLevel = ApiClientLogLevel.BODY,
    datePattern: String? = null,
    certificatePins: MutableList<CertificatePin> = ArrayList(),
    interceptors: MutableList<Interceptor> = ArrayList()
) {

    private val okHttpClient: OkHttpClient.Builder = OkHttpClient.Builder()

    private var retrofitBuilder: Retrofit.Builder

    init {

        okHttpClient.run {
            //The three different types of timeout are set
            connectTimeout(connectTimeout, TimeUnit.MILLISECONDS)
                .readTimeout(readTimeout, TimeUnit.MILLISECONDS)
                .writeTimeout(writeTimeout, TimeUnit.MILLISECONDS)

            //A logging interceptor for HTTP requests and responses is always added
            addInterceptor(HttpLoggingInterceptor().apply {
                level = logLevel.toHttpLoggingInterceptorEnum()
            })

            //Custom interceptors from Builder are added
            interceptors.forEach { customInterceptor -> addInterceptor(customInterceptor) }

            //A certificate pinning handler from okttp3.CertificatePinner is added with each [hostname, pin] pair provided
            //via Builder
            if (certificatePins.isNotEmpty())
                certificatePinner(CertificatePinner.Builder().apply {
                    certificatePins.forEach {
                        add(it.hostname, it.pin)
                    }
                }.build())
        }

        val gsonBuilder = GsonBuilder()
        //Date format to Gson converter factory
        if (datePattern != null)
            gsonBuilder.setDateFormat(datePattern)

        retrofitBuilder = Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create(gsonBuilder.create()))
    }

    /**
     * Set a new API base URL.
     * @param baseUrl
     */
    fun setBaseUrl(baseUrl: String) {
        this.baseUrl = baseUrl
        retrofitBuilder.baseUrl(baseUrl)
    }

    /**
    * Get the API base URL.
    * @return API Base URL.
    */
    fun getBaseUrl(): String = baseUrl

    /**
     * Set a new connection timeout. Default time unit is milliseconds.
     * @param connectTimeout
     * @param timeUnit TimeUnit.MILLISECONDS by default.
     */
    fun setConnectTimeout(connectTimeout: Long, timeUnit: TimeUnit = TimeUnit.MILLISECONDS) {
        okHttpClient.connectTimeout(connectTimeout, timeUnit)
    }

    /**
     * Set a new read timeout. Default time unit is milliseconds.
     * @param readTimeout
     * @param timeUnit TimeUnit.MILLISECONDS by default.
     */
    fun setReadTimeout(readTimeout: Long, timeUnit: TimeUnit = TimeUnit.MILLISECONDS) {
        okHttpClient.readTimeout(readTimeout, timeUnit)
    }

    /**
     * Set a new write timeout. Default time unit is milliseconds.
     * @param writeTimeout
     * @param timeUnit TimeUnit.MILLISECONDS by default.
     */
    fun setWriteTimeout(writeTimeout: Long, timeUnit: TimeUnit = TimeUnit.MILLISECONDS) {
        okHttpClient.writeTimeout(writeTimeout, timeUnit)
    }

    /**
     * Reset connection, read and write timeout values to original ones.
     */
    fun resetTimeOutValues() {
        okHttpClient.connectTimeout(connectTimeout, TimeUnit.MILLISECONDS)
            .readTimeout(readTimeout, TimeUnit.MILLISECONDS)
            .writeTimeout(writeTimeout, TimeUnit.MILLISECONDS)
    }

    /**
     * Provides an implementation of an interface with HTTP method annotations (GET, POST, etc)
     * @param serviceClass Interface which has to be implemented
     * @return Implemented servicesClass interface, ready to be called
     */
    fun <S> createService(serviceClass: Class<S>): S =
        retrofitBuilder
            .client(okHttpClient.build())
            .build()
            .create(serviceClass)

    /**
     * Builds an ApiClient with a required API base URL via constructor.
     * @param baseUrl API base URL
     */
    class Builder(private val baseUrl: String) {

        private var connectTimeout: Long = 10_000L //milliseconds
        private var readTimeout: Long = 10_000L //milliseconds
        private var writeTimeout: Long = 10_000L //milliseconds
        private var logLevel: ApiClientLogLevel = ApiClientLogLevel.BODY
        private var datePattern: String? = null
        private val certificatePins: MutableList<CertificatePin> = ArrayList()
        private val interceptors: MutableList<Interceptor> = ArrayList()

        /**
         * Set the connection timeout in milliseconds.
         */
        fun connectTimeout(connectTimeout: Long?): Builder {
            if(connectTimeout!=null && connectTimeout >0){
                this.connectTimeout = connectTimeout
            }
            return this
        }

        /**
         * Set the read timeout in milliseconds.
         */
        fun readTimeout(readTimeout: Long): Builder {
            this.readTimeout = readTimeout
            return this
        }

        /**
         * Set the write timeout in milliseconds.
         */
        fun writeTimeout(writeTimeout: Long): Builder {
            this.writeTimeout = writeTimeout
            return this
        }

        /**
         * Set one of the four available types of log: NONE, BASIC, HEADERS and BODY.
         */
        fun logLevel(logLevel: ApiClientLogLevel): Builder {
            this.logLevel = logLevel
            return this
        }

        /**
         * Set a date pattern used to parse the dates returned by the service.
         */
        fun datePattern(datePattern: String): Builder {
            this.datePattern = datePattern
            return this
        }

        /**
         * Set the pins used to configure the certificate pinning.
         * @param hostName A lower-case host name or wildcard pattern such as *.example.com
         * @param pin Hash of a certificate's Subject Public Key Info, base64-encoded and prefixed with either sha256 or sha1
         */
        fun addCertificatePin(hostName: String, pin: String): Builder {
            this.certificatePins.add(CertificatePin(hostName, pin))
            return this
        }

        /**
         * Adds a custom okttp3.Interceptor to handle the request and response involved in each service call.
         */
        fun addInterceptor(interceptor: Interceptor): Builder {
            this.interceptors.add(interceptor)
            return this
        }

        /**
         * Create the ApiClient instance using the configured values.
         */
        fun build() = ApiClient(
            baseUrl,
            connectTimeout,
            readTimeout,
            writeTimeout,
            logLevel,
            datePattern,
            certificatePins,
            interceptors
        )

    }

    companion object {

        private var apiClientSingletonInstance: ApiClient? = null

        private const val API_CLIENT_NOT_INITIALIZED_ERROR = "ApiClient must be initialized first"

        /**
         * Initializes the singleton instances of ApiClient that ComponentFacade will use.
         *
         * @param apiClient
         */
        fun init(apiClient: ApiClient) {
            apiClientSingletonInstance = apiClient
        }

        /**
         * Set a new API base URL.
         * @param baseUrl
         */
        fun setBaseUrl(baseUrl: String) {
            apiClientSingletonInstance?.setBaseUrl(baseUrl)
                ?: error(API_CLIENT_NOT_INITIALIZED_ERROR)
        }

        fun getBaseUrl(): String = apiClientSingletonInstance?.getBaseUrl()
            ?: error(API_CLIENT_NOT_INITIALIZED_ERROR)

        /**
         * Set a new connection timeout. Default time unit is milliseconds.
         * @param connectTimeout
         * @param timeUnit TimeUnit.MILLISECONDS by default
         */
        fun setConnectTimeout(connectTimeout: Long, timeUnit: TimeUnit = TimeUnit.MILLISECONDS) {
            apiClientSingletonInstance?.setConnectTimeout(connectTimeout, timeUnit)
                ?: error(API_CLIENT_NOT_INITIALIZED_ERROR)
        }

        /**
         * Set a new read timeout. Default time unit is milliseconds.
         * @param readTimeout
         * @param timeUnit TimeUnit.MILLISECONDS by default
         */
        fun setReadTimeout(readTimeout: Long, timeUnit: TimeUnit = TimeUnit.MILLISECONDS) {
            apiClientSingletonInstance?.setReadTimeout(readTimeout, timeUnit)
                ?: error(API_CLIENT_NOT_INITIALIZED_ERROR)
        }

        /**
         * Set a new write timeout. Default time unit is milliseconds.
         * @param writeTimeout
         * @param timeUnit TimeUnit.MILLISECONDS by default
         */
        fun setWriteTimeout(writeTimeout: Long, timeUnit: TimeUnit = TimeUnit.MILLISECONDS) {
            apiClientSingletonInstance?.setWriteTimeout(writeTimeout, timeUnit)
                ?: error(API_CLIENT_NOT_INITIALIZED_ERROR)
        }

        /**
         * Reset connection, read and write timeout values to original ones.
         */
        fun resetTimeOutValues() {
            apiClientSingletonInstance?.resetTimeOutValues()
                ?: error(API_CLIENT_NOT_INITIALIZED_ERROR)
        }

        /**
         * Provides an implementation of an interface with HTTP method annotations (GET, POST, etc)
         * @param serviceClass Interface which has to be implemented
         * @return Implemented servicesClass interface, ready to be called
         */
        fun <S> createService(serviceClass: Class<S>): S =
            apiClientSingletonInstance?.createService(serviceClass)
                ?: error(API_CLIENT_NOT_INITIALIZED_ERROR)

    }
}