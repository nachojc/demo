package com.santander.globile.serviceinvocationlib.interactor

import com.santander.globile.serviceinvocationlib.callback.IBaseCallback
import com.santander.globile.serviceinvocationlib.common.exception.MalformedResponseException
import com.santander.globile.serviceinvocationlib.common.exception.UnexpectedResponseException
import com.santander.globile.serviceinvocationlib.common.exception.unexpectedExceptionMessage
import com.santander.globile.serviceinvocationlib.common.extensions.parse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.net.HttpURLConnection

/**
 * REST service call handler class. It provides a method [doRequest] which will make the request and handle the
 * response using [handleSuccessfulResponse] and [handleErrorResponse] methods (both can be overridden)
 */
abstract class IBaseInteractor {

    /**
     * REST service call handling. This method receives two generic types:
     *  - OKResponseType: successful (default) response type.
     *  - KOResponseType: specific error response type. The response will be parsed
     *      to this type in case of error.
     *
     * @param call Retrofit Call (service to be called) with the specific OK return type
     * @param callback [IBaseCallback] interface with OK, KO and Fail cases
     * @param errorMapper Optional function to parse OK response to KO response. A simply json parser from error body
     * is provided by default
     */
    fun <OKResponseType, KOResponseType> doRequest(
        call: Call<OKResponseType>?,
        callback: IBaseCallback<OKResponseType, KOResponseType>,
        errorClass: Class<KOResponseType>,
        errorMapper: (Response<OKResponseType>?, Class<KOResponseType>) -> KOResponseType? = { response, errorClassParsed ->
            response?.errorBody()?.string()?.parse(errorClassParsed)
        }
    ) {

        call?.enqueue(object : Callback<OKResponseType> {
            override fun onResponse(call: Call<OKResponseType>?, response: Response<OKResponseType>?) {

                if (response == null)
                    callback.onResponseFail(MalformedResponseException("The service did not provide a response."))
                else {
                    callback.httpStatusCode = response.code()

                    //If response Http code is in the range [200..300), the OK handler method is called.
                    if (response.isSuccessful)
                        handleSuccessfulResponse(call, response, callback)
                    else
                        handleErrorResponse(call, response, callback, errorClass, errorMapper)
                }
            }

            override fun onFailure(call: Call<OKResponseType>?, t: Throwable?) {
                callback.onResponseFail(t)
            }
        })
    }

    /**
     * Default success response handler. Override if it does not fit to your project specifications.
     *
     * @param call Information about the REST service call, useful if the concrete implementation of this interactor
     * wants to know for example the endpoint that was called.
     * @param response ApiResponse from the service of the type expected
     * @param callback [IBaseCallback] interface with OK, KO and Fail cases
     */
    open fun <OKResponseType, KOResponseType> handleSuccessfulResponse(
        call: Call<OKResponseType>?,
        response: Response<OKResponseType>?,
        callback: IBaseCallback<OKResponseType, KOResponseType>
    ) {
        callback.onResponseOK(response?.body())
    }

    /**
     * Default error response handler. Override if it does not fit to your project specifications.
     *
     * @param call Information about the rest call useful if the concrete implementation of this interactor
     * wants to know for example the endpoint that was called.
     * @param response ApiResponse from the service of the type expected
     * @param callback [IBaseCallback] interface with OK, KO and Fail cases
     * @param errorMapper Parsing function to parse the error body of the response.
     * At this point, it is known that response.body() does not contain the service information,
     * it is in response.errorBody().
     */
    open fun <OKResponseType, KOResponseType> handleErrorResponse(
        call: Call<OKResponseType>?,
        response: Response<OKResponseType>?,
        callback: IBaseCallback<OKResponseType, KOResponseType>,
        errorClass: Class<KOResponseType>,
        errorMapper: (Response<OKResponseType>?, Class<KOResponseType>) -> KOResponseType?
    ) {
        //By default the failure cases are those that its Http code is not in the range [400..500).
        if (response?.code() != null
            && response.code() >= HttpURLConnection.HTTP_BAD_REQUEST
            && response.code() < HttpURLConnection.HTTP_INTERNAL_ERROR
        ) {
            try {
                callback.onResponseKO(errorMapper(response, errorClass))
            } catch (e: Exception) {
                callback.onResponseFail(MalformedResponseException(e.message ?: "Malformed response message."))
            }
        } else
            callback.onResponseFail(UnexpectedResponseException(unexpectedExceptionMessage(response?.code())))
    }

}