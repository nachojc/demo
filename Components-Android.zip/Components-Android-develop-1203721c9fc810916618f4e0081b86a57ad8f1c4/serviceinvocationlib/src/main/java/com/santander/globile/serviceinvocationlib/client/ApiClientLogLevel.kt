package com.santander.globile.serviceinvocationlib.client

import okhttp3.logging.HttpLoggingInterceptor.Level

/**
 * Enum class to specify the HTTP request and response log level
 */
enum class ApiClientLogLevel(private val httpLoggingInterceptorEnum: Level) {
    /** No logs. */
    NONE(Level.NONE),
    /** Just logs about request method and response code. */
    BASIC(Level.BASIC),
    /** BASIC log plus header information. */
    HEADERS(Level.HEADERS),
    /** HEADERS log plus body information. */
    BODY(Level.BODY);

    internal fun toHttpLoggingInterceptorEnum() = httpLoggingInterceptorEnum
}