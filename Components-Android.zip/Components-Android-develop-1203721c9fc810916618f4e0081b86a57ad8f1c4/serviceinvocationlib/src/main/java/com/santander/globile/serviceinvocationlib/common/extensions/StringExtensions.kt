package com.santander.globile.serviceinvocationlib.common.extensions

import com.google.gson.Gson

/**
 * String kotlin extension which parses [this] as a expected JSON String to a specific object
 * @param outputClass
 * @receiver The String to be parsed from JSON
 * @return Object of type outputClass. Null if an exception was thrown
 */
fun <OutputType> String?.parse(outputClass: Class<OutputType>): OutputType? = Gson().fromJson(this, outputClass)