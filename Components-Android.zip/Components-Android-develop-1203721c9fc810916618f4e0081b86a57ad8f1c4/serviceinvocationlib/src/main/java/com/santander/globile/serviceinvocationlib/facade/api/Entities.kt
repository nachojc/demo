package com.santander.globile.serviceinvocationlib.facade.api

internal data class Request(
    val method: String? = null,
    val baseurl: String,
    val path: String,
    val headers: List<NameValuePair>? = null,
    val queries: List<NameValuePair>? = null,
    val body: Any? = null,
    val connectTimeout: Long
)

internal data class NameValuePair(val name: String? = null, val value: String? = null)

internal fun List<NameValuePair>?.toMap(): Map<String?, String?> =
    this?.filter { it.name != null }?.associate { Pair(it.name, it.value) } ?: HashMap()

internal data class ApiResponse(
    val httpStatusCode: Int? = null,
    val url: String? = null,
    val body: Any? = null
)