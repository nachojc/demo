package com.santander.globile.serviceinvocationlib.common.extensions

import com.google.common.truth.Truth
import com.google.gson.JsonSyntaxException
import com.santander.globile.serviceinvocationlib.testutils.MockEntity
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class StringExtensionsTest {


    @Test
    fun testParseFromValidJsonToObject() {
        //Arrange
        val expectedPropertyValue = "hola"
        val jsonToParse = "{\"value\":\"$expectedPropertyValue\"}"

        //Act
        val resultMockEntity = jsonToParse.parse(MockEntity::class.java)

        //Assert
        Truth.assertThat(resultMockEntity).isInstanceOf(MockEntity::class.java)
        Truth.assertThat(resultMockEntity?.value).isEqualTo(expectedPropertyValue)
    }

    @Test
    fun testParseFromInvalidJsonToObject() {
        //Arrange
        val jsonToParse = "{\"value\"}"

        //Act
        try {
            jsonToParse.parse(MockEntity::class.java)
            //This line does not have to be reached. An expection has to be thrown.
            Truth.assertThat(false).isEqualTo(true)
        } catch (e: Exception) {
            //Assert
            Truth.assertThat(e).isInstanceOf(JsonSyntaxException::class.java)
        }
    }

    @Test
    fun testParseFromInvalidTypedJsonToObject() {
        //Arrange
        val jsonToParse = "{\"number\":\"hola\"}"

        //Act
        try {
            jsonToParse.parse(MockEntity::class.java)
            //This line does not have to be reached. An expection has to be thrown.
            Truth.assertThat(false).isEqualTo(true)
        } catch (e: Exception) {
            //Assert
            Truth.assertThat(e).isInstanceOf(JsonSyntaxException::class.java)
        }
    }
}