package com.santander.globile.serviceinvocationlib.common

import com.google.common.truth.Truth
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class UtilsTest {


    @Test
    fun `create a URL from base URL and relative endpoint without slashed previously set`() {
        // Arrange
        val baseUrl = "www.a.es"
        val relativeLayout = "endpoint"

        // Act
        val result = createUrl(baseUrl, relativeLayout)

        // Assert
        Truth.assertThat(result).isEqualTo("www.a.es/endpoint")
    }

    @Test
    fun `create a URL from base URL and relative endpoint with slash in base URL`() {
        // Arrange
        val baseUrl = "www.a.es/"
        val relativeLayout = "endpoint"

        // Act
        val result = createUrl(baseUrl, relativeLayout)

        // Assert
        Truth.assertThat(result).isEqualTo("www.a.es/endpoint")
    }

    @Test
    fun `create a URL from base URL and relative endpoint with slash in relative endpoint`() {
        // Arrange
        val baseUrl = "www.a.es"
        val relativeLayout = "/endpoint"

        // Act
        val result = createUrl(baseUrl, relativeLayout)

        // Assert
        Truth.assertThat(result).isEqualTo("www.a.es/endpoint")
    }

    @Test
    fun `create a URL from base URL and relative endpoint with slash in both base URL and relative endpoint`() {
        // Arrange
        val baseUrl = "www.a.es/"
        val relativeLayout = "/endpoint"

        // Act
        val result = createUrl(baseUrl, relativeLayout)

        // Assert
        Truth.assertThat(result).isEqualTo("www.a.es/endpoint")
    }
}
