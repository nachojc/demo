package com.santander.globile.serviceinvocationlib.testutils

import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import java.net.HttpURLConnection

var OK_BASE_URL = ""
var KO_BASE_URL = ""

class MockedTestServer @Throws(Exception::class)
constructor() {

    private val server = MockWebServer()
    private val port = 12345

    init {
        server.start(port)
        OK_BASE_URL = "${server.url("/")}ok"
        KO_BASE_URL = "${server.url("/")}ko"
        setDispatcher()
    }

    fun shutDown() {
        server.shutdown()
    }

    private fun setDispatcher() {
        server.setDispatcher(object : Dispatcher() {
            @Throws(InterruptedException::class)
            override fun dispatch(request: RecordedRequest): MockResponse? {

                val response = MockResponse().setResponseCode(HttpURLConnection.HTTP_OK)

                return response.setBody(getFileNameFromRequestPath(request.path))
            }
        })
    }

    private fun getFileNameFromRequestPath(path: String): String? =
        when {
            path.contains("ok") -> "{\"value\":\"hola\", \"number\":1}"
            path.contains("ko") -> "" // TODO
            else -> null
        }
}
