package com.santander.globile.serviceinvocationlib.testutils

import okhttp3.Request
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

// Custom implementations of retrofit2.Call<T>.
// In these test cases it is not relevant how the service handles the response. Also it allows to implement a
// synchronous solution of a mock server

abstract class BaseMockCall<T> : Call<T> {
    override fun enqueue(callback: Callback<T>) { }

    override fun isExecuted(): Boolean = false

    override fun clone(): Call<T> = null!!

    override fun isCanceled(): Boolean = false

    override fun cancel() { }

    override fun execute(): Response<T>? = null

    override fun request(): Request? = null

}

class OnResponseMockCall<T>(private val customResponse: Response<T>) : BaseMockCall<T>() {
    override fun enqueue(callback: Callback<T>) {
        callback.onResponse(this, customResponse)
    }
}

class OnFailureMockCall(private val t: Throwable) : BaseMockCall<Any>() {
    override fun enqueue(callback: Callback<Any>) {
        callback.onFailure(this, t)
    }
}
