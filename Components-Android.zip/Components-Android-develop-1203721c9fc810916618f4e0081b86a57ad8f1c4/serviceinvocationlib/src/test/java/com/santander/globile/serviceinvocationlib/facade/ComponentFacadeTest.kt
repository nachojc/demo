package com.santander.globile.serviceinvocationlib.facade

import android.arch.core.executor.testing.InstantTaskExecutorRule
import android.arch.lifecycle.Observer
import com.google.common.truth.Truth
import com.google.gson.Gson
import com.santander.globile.serviceinvocationlib.facade.api.ApiResponse
import com.santander.globile.serviceinvocationlib.testutils.MockedTestServer
import com.santander.globile.serviceinvocationlib.testutils.OK_BASE_URL
import org.junit.After
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import org.mockito.Mock
import org.mockito.MockitoAnnotations

@RunWith(JUnit4::class)
class ComponentFacadeTest {

    private lateinit var server: MockedTestServer

    private val componentFacade = ComponentFacade()

    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Mock
    lateinit var observer: Observer<String>


    @Before
    @Throws(Exception::class)
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        server = MockedTestServer()
    }

    @After
    @Throws(Exception::class)
    fun tearDown() {
        server.shutDown()
    }

    @Test
    fun `receive 200 status code and expected body`() {

        // Arrange
        val expectedResult = "{\"httpStatusCode\":200," +
                "\"url\":\"$OK_BASE_URL/endpoint?query1\\u003d23\"," +
                "\"body\":{\"value\":\"hola\",\"number\":1.0}}"

        val expectedJson = Gson().fromJson(expectedResult, ApiResponse::class.java)

        val params = "{\"method\":\"post\"," +
                "\"baseurl\":\"$OK_BASE_URL\"," +
                "\"path\":\"endpoint\"," +
                "\"headers\":[{\"name\":\"hola\", \"value\":\"weee\"}]," +
                "\"queries\":[{\"name\":\"query1\", \"value\":\"23\"}]," +
                "\"body\": {\"any\":1}}"
        // Act
        val args = ArrayList<Any>()
        args.add(params)

        componentFacade.liveData.observeForever(observer)
        componentFacade.startComponent(args)
        val responseJson = Gson().fromJson(componentFacade.liveData.value, ApiResponse::class.java)

        // Assert
        Truth.assertThat(responseJson).isEqualTo(expectedJson)
    }

    @Test
    fun `receive 200 status code and expected body with timeout`() {

        // Arrange
        val expectedResult = "{\"httpStatusCode\":200," +
                "\"url\":\"$OK_BASE_URL/endpoint?query1=23\"," +
                "\"body\":{\"value\":\"hola\",\"number\":1.0}}"

        val expectedJson = Gson().fromJson(expectedResult, ApiResponse::class.java)
        // Act
        val params = "{\"method\":\"post\"," +
                    "\"baseurl\":\"$OK_BASE_URL\"," +
                    "\"path\":\"endpoint\"," +
                    "\"headers\":[{\"name\":\"hola\", \"value\":\"weee\"}]," +
                    "\"queries\":[{\"name\":\"query1\", \"value\":\"23\"}]," +
                    "\"body\": {\"any\":1}," +
                    "\"connectTimeout\": 20000}"

        val args = ArrayList<Any>()
        args.add(params)

        componentFacade.liveData.observeForever(observer)
        componentFacade.startComponent(args)
        val responseJson = Gson().fromJson(componentFacade.liveData.value, ApiResponse::class.java)

        // Assert
        Truth.assertThat(responseJson).isEqualTo(expectedJson)
    }

    @Test
    fun `receive empty response due to incorrect HTTP method`() {
        // Arrange
        val expectedResult = "{\"url\":\"http://localhost:12345/ok/endpoint\"}"
        val expectedJson = Gson().fromJson(expectedResult, ApiResponse::class.java)

        // Act
        val params =
            "{\"method\":\"incorrectmethod\",\"baseurl\":\"$OK_BASE_URL\",\"path\":\"endpoint\",\"body\": {\"any\":1}}"

        val args = ArrayList<Any>()
        args.add(params)

        componentFacade.liveData.observeForever(observer)
        componentFacade.startComponent(args)
        val responseJson = Gson().fromJson(componentFacade.liveData.value, ApiResponse::class.java)

        // Assert
        Truth.assertThat(responseJson).isEqualTo(expectedJson)
    }

}