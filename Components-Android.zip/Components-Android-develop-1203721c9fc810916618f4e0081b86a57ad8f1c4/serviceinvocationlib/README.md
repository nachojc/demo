# Introduction 
This component offers a simplified HTTP client to make calls to an API backend.

# Prerequisites
This component requires the INTERNET permission, so the following line must be present in the app's AndroidManifest.xml:
```xml
<uses-permission android:name="android.permission.INTERNET"/>
```

# Install

## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':serviceinvocationlib')
```
3. Sync project with Gradle files

# Use

## From Native app
Component setup involves creating 4 files to describe the REST-based web service:
- Model
- Interface
- Interactor

### Describe input/output Data Model
Each JSON object sent/received must be described as data class model entities:
```kotlin
data class User(
    val id: String? = null,
    val name: String? = null,
    val age: Int? = null
)
```

### Define API Interface
Every method of an interface represents one possible API call. It must have a HTTP annotation (GET, POST, etc.) to specify the request type and the relative URL. The return value wraps the response in a Call object with the type of the expected result.
```kotlin
interface UserApi {
    @GET("users")
    Call<List<User>> getUsers();
}
```
You can use replacement blocks and query parameters to adjust the URL. A replacement block is added to the relative URL with {}. With the help of the @Path annotation on the method parameter, the value of that parameter is bound to the specific replacement block.
```kotlin
interface UserApi {
    @GET("users/{name}/accounts")
    Call<List<Commit>> getAccountsByName(@Path("name") String name);
}
```
Query parameters are added with the @Query annotation on a method parameter. They are automatically added at the end of the URL.
```kotlin
interface UserApi {
    @GET("users")
    Call<User> getUserById(@Query("id") Integer id);
}
```
The @Body annotation on a method parameter uses the object as the request body for the call.
```kotlin
interface UserApi {
    @POST("users")
    Call<User> postUser(@Body User user)
}
```

### Handle requests and responses with Interactor
An Interactor that inherits from IBaseInteractor and must implement onResponseOK, onResponseKO, and onResponseFail
```kotlin
class UserInteractor(private val userApi: UsersApi) : IBaseInteractor() {
    fun getUsers(callback: (ResultsContainer?, ErrorMessage?) -> Unit) {
        doRequest(userApi.getUsers(), object : IBaseCallback<List<User>, ErrorMessage>() {
            override fun onResponseOK(response: List<User>?) {
                callback(response, null)
            }
            override fun onResponseKO(errorResponse: ErrorMessage?) {
                callback(null, errorResponse)
            }
            override fun onResponseFail(t: Throwable?) {
                callback(null, ErrorMessage(t?.message?:"Response Fail"))
            }
        }, ErrorMessage::class.java)
    }
}
```

### Make web service call
First step is to initialize the ApiClient through its Builder, configuring any necessary properties:
```kotlin
val apiClient = ApiClient.Builder("www.example.com")
    .connectTimeout(30000)
    .readTimeout(20000)
    .writeTimeout(200000)
    .datePattern("dd/mm/yyyy")
    .logLevel(ApiClientLogLevel.HEADERS)
    .addCertificatePin("*.example.com", "sha256/AAAAAAAAAAAAAAAAAAA=")
    .build()
```
Then create an instance of the pertinent Interactor:
```kotlin
val userInteractor = UserInteractor(apiClient.createService(UserApi::class.java))
```
And finally launch the service call:
```kotlin
userInteractor.getUsers{ results , error ->
    if (results != null){
        ...
    }

    if (error != null){
        ...
    }
}
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib). Call the function with the following values:

componentName: "serviceinvocationlib"

componentParams:
```javascript
{
    "method": "string",                    // HTTP method ("get", "post", etc.)
    "baseurl": "https://www.example.com/", // Endpoint base url
    "path": "users",                       // Endpoint path
    "headers": [                           // HTTP Headers ("Authorization", "Content-Type", etc.)
        {
            "name": "string",
            "value": "string"
        }
    ],
    "queries": [                           // Query string parameters
        {
            "name": "string",
            "value": "string"
        }
    ],
    "body": { }                            // Any valid JSON (object, array, string, number, boolean, and null)
    "connectTimeout" : Long                // Connection timeout in milliseconds
}
```
The returned Promise will be resolved with the following JSON object:
```javascript
{
    "url": "string",       // URL of the service that was called
    "httpStatusCode": 200, // HTTP status code of the response
    "body": { }            // Body of the response, could be any valid JSON (object, array, string, number, boolean, and null)
}
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "serviceinvocationlib" from the Project sidemenu
4. Select Build -> Make Module 'serviceinvocationlib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/serviceinvocationlib/build/outputs/aar/

# Test
1. Open Components-Android project in Android Studio
2. Open "serviceinvocationlib" from the Project sidemenu
3. Open "java/com.santander.globile.serviceinvocationlib (test)"
4. Open "common/UtilsTest", "facade/ComponentFacadeTest", or "interactor/IBaseInteractorTest"
5. Click ► icon next to the class definition

# TODO
