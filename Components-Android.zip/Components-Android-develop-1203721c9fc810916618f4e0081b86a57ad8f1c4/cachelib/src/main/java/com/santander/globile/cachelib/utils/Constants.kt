package com.santander.globile.cachelib.utils

const val SAVE = "cache"
const val LOAD = "load"
const val REMOVECACHE = "remove"
const val REMOVE_ALL = "remove_all"
const val CODE_99 = "Wrong parameters or JSON malformed"
const val CODE_98 = "Operation not found"
const val CODE_97 = "Data not found"
const val DEFAULT = "Internal Error"
const val  ASSET_BASE_PATH = "../cachelib/src/main/assets/"
