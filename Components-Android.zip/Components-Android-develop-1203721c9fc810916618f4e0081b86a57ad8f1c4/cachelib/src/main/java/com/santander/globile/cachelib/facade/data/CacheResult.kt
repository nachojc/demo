package com.santander.globile.cachelib.facade.data

/**
 * Entity that holds CacheResult.
 *
 * @param success if operation success true else false
 * @param operation returns operation type
 * @param plainData is optional, returns plain data
 *
 */
data class CacheResult(
    val success: Boolean = false,
    val operation: String? = null,
    val plainData: Any? = null
)