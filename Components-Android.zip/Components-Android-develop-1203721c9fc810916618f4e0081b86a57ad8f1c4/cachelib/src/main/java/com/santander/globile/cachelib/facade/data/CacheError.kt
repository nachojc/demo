package com.santander.globile.cachelib.facade.data



/**
 * Entity that holds data error.
 *
 * @param message
 * @param code
 */
@Deprecated("Deprecated")
data class CacheError(
    val message: String? = null,
    val code: Int? = null
)