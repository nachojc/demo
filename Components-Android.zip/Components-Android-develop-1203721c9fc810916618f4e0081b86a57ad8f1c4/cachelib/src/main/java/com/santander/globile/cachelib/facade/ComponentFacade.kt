package com.santander.globile.cachelib.facade

import android.arch.lifecycle.MutableLiveData
import android.util.Log
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.santander.globile.cachelib.GlobalFactoryCache
import com.santander.globile.cachelib.facade.data.CacheParams
import com.santander.globile.cachelib.facade.data.CacheResult
import com.santander.globile.cachelib.utils.*


class ComponentFacade {

    var liveData: MutableLiveData<String> = MutableLiveData()
    lateinit var gson: Gson

    /**
     *
     * @param args A ArrayList with data to Use in this component:
     *
     * args[0] = params A JSON formatted [String] with four fields:
     *  - operation: "load", "cache", "remove" or "remove_all".
     *  - jsonObject contains [Any] object to use Cache Library
     *  - key contains [String] key to store or load data from Cache Library
     *  - expiryTime contains [Long] expiryTime in seconds to expiry data in Cache Library.
     *
     *   args[1] = context from application
     *   args[2] = activity from application
     */



    fun startComponent(args: ArrayList<Any>){

        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
        val params = args[0] as String

        var operation: String?
        var key: String?
        var expirationTime: Long?
        var jsonObject: Any?
        var success: Boolean
        var cacheResult: CacheResult?
        var plainData: Any? = null



            val cacheParams = Gson().fromJson(params, CacheParams::class.java)
            operation = cacheParams?.operation?.toLowerCase().let {
                if (it != SAVE && it != LOAD && it != REMOVECACHE && it != REMOVE_ALL)
                    null
                else
                    it
            }

            Log.d(TAG, operation)
            key = cacheParams?.key
            expirationTime = cacheParams.expiryTime
            jsonObject = cacheParams.jsonObject


            if(cacheParams!=null) {
                if (operation != null) {
                    success = when (operation) {
                        SAVE -> {
                            key?.let {
                                jsonObject?.let {
                                    plainData = jsonObject
                                    GlobalFactoryCache.saveCacheData(key,jsonObject,expirationTime)

                                }
                            }?: false
                        }
                        LOAD -> {
                            key?.let {
                                GlobalFactoryCache.getCacheData(key)
                                true
                            }?: false


                        }
                        REMOVECACHE -> {
                            key?.let {
                                GlobalFactoryCache.removeCacheData(key)
                            } ?: false
                        }
                        REMOVE_ALL -> {
                            GlobalFactoryCache.cache.clear()
                            GlobalFactoryCache.cache.isEmpty()
                        }

                        else -> {
                            false
                        }
                    }
                } else {
                    success = false
                }
            }else{
                success = false
            }
            cacheResult =  CacheResult(success,operation, plainData)

        liveData.apply {
            postValue( gson.toJson(
                cacheResult).toString())
        }

    }

}





