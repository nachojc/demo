package com.santander.globile.cachelib.impl

import com.santander.globile.cachelib.utils.expireData

class CacheData(private val expirationTimeMillisec: Long? = null) {
   private val  currentTime= System.currentTimeMillis()
    var data: Pair<String, Any>? = null
        get() {
            return if(!expireData(expirationTimeMillisec,currentTime)) {
                field
            }else{
                null
            }
        }
}