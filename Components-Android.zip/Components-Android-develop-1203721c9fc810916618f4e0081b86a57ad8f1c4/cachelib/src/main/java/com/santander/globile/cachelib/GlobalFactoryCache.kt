package com.santander.globile.cachelib

import com.santander.globile.cachelib.impl.CacheData

class GlobalFactoryCache {

    companion object {
        var cache = mutableListOf<CacheData>()

        /**
         *
         * @param tag a data tag name saved [String] in [cache]
         * @return a [Any] object with values previously saved
         *
         * */

        fun getCacheData(tag: String): Any? {
            return tag.takeIf {
                it.isNotEmpty()
            }.let {
                return cache.find {
                    it.data?.first == tag
                }?.data?.second
            }
        }

        /**
         *
         * @param tag [String] a data tag name to create data in [cache]
         * @param value [Any] any type of data to save in cache
         * @param timeExpirationSeconds [Long] (OPTIONAL) time expiration in seconds to delete cache.
         * @return [Boolean] true if success false if failure.
         *
         * */

        fun saveCacheData(tag: String, value: Any, timeExpirationSeconds: Long? = null): Boolean {
            tag.takeIf {
                it.isNotEmpty()
            }?.let {
                val timeExpirationMilliseconds = timeExpirationSeconds?.let {
                    it * 1000
                }

                cache.forEachIndexed { position, element ->
                    if (element.data?.first.equals(tag)) {
                        cache[position] = createCacheData(tag, value, timeExpirationMilliseconds)
                        return true
                    }
                }
                cache.add(createCacheData(tag, value, timeExpirationMilliseconds))
                return true
            }
            return false
        }

        /**
         *
         * @param tag [String] a data tag name to remove data in [cache]
         * @return [Boolean] true if success false if failure.
         *
         */

        fun removeCacheData(tag: String): Boolean {
            tag.takeIf {
                it.isNotEmpty()
            }.let {
                cache.find {
                    it.data?.first == tag
                }?.let {
                    cache.remove(it)
                    return true
                }
            }
            return false
        }


        private fun createCacheData(tag: String, value: Any, timeExpiration: Long?): CacheData {
            return CacheData(timeExpiration).apply {
                data = Pair(tag, value)
            }
        }
    }
}