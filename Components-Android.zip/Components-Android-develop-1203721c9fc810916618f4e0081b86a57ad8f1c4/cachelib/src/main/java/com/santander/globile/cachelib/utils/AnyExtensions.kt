package com.santander.globile.cachelib.utils

val Any.TAG: String
    get() = this::class.java.simpleName