package com.santander.globile.cachelib.utils

import java.util.concurrent.TimeUnit

/**
 * Function to check if data must expire
 *
 * @param expirationTimeMillisec
 * @param currentTime
 */
fun expireData(expirationTimeMillisec: Long?, currentTime: Long?) :Boolean{
    currentTime?.let {
        expirationTimeMillisec?.let {
            return System.currentTimeMillis() - currentTime >= TimeUnit.MILLISECONDS.toMillis(
                it
            )
        }
    }
    return false
}