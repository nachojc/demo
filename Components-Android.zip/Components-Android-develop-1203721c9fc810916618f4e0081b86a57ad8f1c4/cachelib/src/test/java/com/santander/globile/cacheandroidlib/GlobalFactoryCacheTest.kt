package com.santander.globile.cacheandroidlib

import com.santander.globile.cachelib.GlobalFactoryCache
import org.junit.Assert.*
import org.junit.Test


class GlobalFactoryCacheTest {

    @Test
    fun `save cache object and retrieve data`() {
        GlobalFactoryCache.saveCacheData("tag1","data value")
        assertEquals("data value", GlobalFactoryCache.getCacheData("tag1").toString())
        GlobalFactoryCache.removeCacheData("tag1")
    }

    @Test
    fun `save cache and delete`(){
        GlobalFactoryCache.saveCacheData("tag1","data value")
        assertEquals("data value", GlobalFactoryCache.getCacheData("tag1").toString())
        GlobalFactoryCache.removeCacheData("tag1")
        assertNull(GlobalFactoryCache.getCacheData("tag1"))
    }

    @Test
    fun `delete all cache`(){
        GlobalFactoryCache.cache.clear()
        assertTrue(GlobalFactoryCache.cache.isEmpty())
    }

}