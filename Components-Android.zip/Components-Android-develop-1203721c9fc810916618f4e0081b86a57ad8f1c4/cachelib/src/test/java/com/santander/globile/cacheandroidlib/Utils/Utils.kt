package com.santander.globile.cacheandroidlib.Utils

import android.arch.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.santander.globile.cachelib.facade.ComponentFacade
import com.santander.globile.cachelib.facade.data.CacheParams
import com.santander.globile.cachelib.utils.ASSET_BASE_PATH
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStreamReader

class Utils {

    companion object {

        fun getFacade(): ComponentFacade{
            return ComponentFacade()
        }

        fun getLiveData(facade: ComponentFacade): MutableLiveData<String> {
            return facade.liveData
        }
        fun launchOperation(facade: ComponentFacade,cacheParams: CacheParams) {
            val paramJson =  Gson().toJson(cacheParams).toString()
            val data = ArrayList<Any>()
            data.add(paramJson)
            return facade.startComponent(data)
        }

        @Throws(IOException::class)
        fun readJsonFile(filename: String): String {
            val br = BufferedReader(InputStreamReader(FileInputStream(ASSET_BASE_PATH + filename)))
            val sb = StringBuilder()
            var line: String? = br.readLine()
            while (line != null) {
                sb.append(line)
                line = br.readLine()
            }

            return sb.toString()
        }


    }
}