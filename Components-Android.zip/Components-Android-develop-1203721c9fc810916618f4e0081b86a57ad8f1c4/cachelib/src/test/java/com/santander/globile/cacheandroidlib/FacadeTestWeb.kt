package com.santander.globile.cacheandroidlib

import android.arch.core.executor.testing.InstantTaskExecutorRule
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.Observer
import com.google.gson.Gson
import com.santander.globile.cacheandroidlib.Utils.Utils
import com.santander.globile.cacheandroidlib.Utils.Utils.Companion.readJsonFile
import com.santander.globile.cachelib.facade.data.CacheParams
import com.santander.globile.cachelib.facade.data.CacheResult
import com.santander.globile.cachelib.utils.REMOVECACHE
import org.junit.Assert
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.mockito.Mock
import org.mockito.MockitoAnnotations


class FacadeTestWeb {

    @get:Rule
    val rule = InstantTaskExecutorRule()

    @Mock
    lateinit var observer: Observer<String>


    @Before
    fun setUp(){
        MockitoAnnotations.initMocks(this)
    }

    @Test
    fun saveDataFromWeb() {
        val json = readJsonFile("saveData.json")
        val cacheParams = Gson().fromJson(json, CacheParams::class.java)
        val facade = Utils.getFacade()
        val mutableLiveData: MutableLiveData<String> = facade.liveData
        mutableLiveData.observeForever(observer)
        Utils.launchOperation(facade,cacheParams)
        val response = readJsonFile("response1.json")
        val cacheResponse =  Gson().fromJson(response, CacheResult::class.java)
        val cacheResponseExpected =  Gson().fromJson(mutableLiveData.value, CacheResult::class.java)
        assertEquals(cacheResponse, cacheResponseExpected)
    }

    @Test
    fun getDataFromWeb() {
        val json = readJsonFile("saveData.json")
        val jsonLoad = readJsonFile("getData.json")
        val cacheParamsSave = Gson().fromJson(json, CacheParams::class.java)
        val facade = Utils.getFacade()
        val mutableLiveData: MutableLiveData<String> = facade.liveData
        mutableLiveData.observeForever(observer)
        Utils.launchOperation(facade,cacheParamsSave)
        val cacheParamsLoad = Gson().fromJson(jsonLoad, CacheParams::class.java)
        Utils.launchOperation(facade,cacheParamsLoad)
        Assert.assertNotNull(mutableLiveData.value)
    }

    @Test
    fun removeDataFromWeb() {
        val json = readJsonFile("saveData.json")
        val jsonRemove = readJsonFile("removeCache.json")
        val cacheParamsSave = Gson().fromJson(json, CacheParams::class.java)
        val facade = Utils.getFacade()
        val mutableLiveData: MutableLiveData<String> = facade.liveData
        mutableLiveData.observeForever(observer)
        Utils.launchOperation(facade,cacheParamsSave)
        val cacheParamsRemove = Gson().fromJson(jsonRemove, CacheParams::class.java)
        Utils.launchOperation(facade,cacheParamsRemove)
        val valueExpected = CacheResult(operation = REMOVECACHE,success = true)
        val value = Gson().fromJson(mutableLiveData.value, CacheResult::class.java)
        Assert.assertEquals(valueExpected, value)
    }


    @Test
    fun removeAllDataFromWeb(){
        val json = readJsonFile("saveData.json")
        val cacheParams = Gson().fromJson(json, CacheParams::class.java)
        val facade = Utils.getFacade()
        val mutableLiveData: MutableLiveData<String> = facade.liveData
        mutableLiveData.observeForever(observer)
        Utils.launchOperation(facade,cacheParams)
        val jsonClear = readJsonFile("clear.json")
        val cacheParamsClear = Gson().fromJson(jsonClear, CacheParams::class.java)
        Utils.launchOperation(facade,cacheParamsClear)
        val jsonResponse = readJsonFile("clear_response.json")
        val cacheClearResponseExpected = Gson().fromJson(jsonResponse, CacheResult::class.java)
        val cacheClearResponse = Gson().fromJson(mutableLiveData.value, CacheResult::class.java)
        assertEquals(cacheClearResponseExpected,cacheClearResponse)
    }

}