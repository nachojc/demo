# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).


## [1.1.0] - 2019-04-26
### Changed
- Unify Perpetual and Expirable cache into one unique cache
- Abstract cache instance management (automatically create on write), leaving only data access interface ("save", "load", "remove" and "remove_all")
- Simplify web JSON to one level (remove "cacheData" object)
- Changed hybrid interface

## [1.0.0] - 2019-02-28
### Added
- This CHANGELOG

### Changed
- README file now includes user manual

## [0.1.0] - 2019-01-31
### Added
- Create expirable/persistent cache
- Save data to cache
- Retrieve data from cache
- Remove data in cache
