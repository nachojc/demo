# Introduction 
This component temporarily stores data so that future requests for that data can be served faster.

# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation "com.santander.globile:cachelib:$cachelib_version"
```
3. Sync project with Gradle files

# Use
## From Native app

To use all functionalities you should call `GlobalFactoryCache` object.

### Save data to cache
Save data in cache by adding an alias and value pair with `GlobalFactoryCache.saveCacheData(tag: String, value: Any, timeExpirationSeconds: Long? = null): Boolean`,  data can expire with [timeExpirationSeconds] parameter:

```kotlin
val success = GlobalFactoryCache.saveCacheData("tag","data",60)
```

### Retrieve data from cache
Retrieve data from cache with `GlobalFactoryCache.getCacheData(tag: String): Any?`:

```kotlin
val data = GlobalFactoryCache.getCacheData(tag)
```

### Remove data from cache
Remove data in a cache with `GlobalFactoryCache.removeCacheData(tag: String): Boolean` it returns boolean if operation success:

```kotlin
val success = GlobalFactoryCache.removeCacheData("tag")
```

### Delete all data
Delete all data stored in cache with `cache` object:

```kotlin
GlobalFactoryCache.cache.clear()
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib). Call the function with the following values:

* componentName: "cachelib"

* componentParams:

	```javascript
	{
	  "operation": "String", // "load", "cache", "remove", "remove_all"
	  "jsonObject": {}, // Object to store in cache,
	  "key": "String", // Alias to store in cache
	  "expiryTime": "Long" // Time expiration in seconds
	}
	```


The returned Promise will be resolved with the following JSON object:

```javascript
{
  "operation": "String", // "load", "cache", "remove", "remove_all"
  "plainData": {}, // cached data (only returned in "load" operation)
  "success": "String", //operation success or failed
}
```

### Save data to cache

```javascript
callComponent('cachelib', {
    operation: 'cache',
    jsonObject: 'This could be any data, including JSON or HTML',
    key: 'myCacheAlias',
    expiryTime: '20'
    }
})
```

### Retrieve data from cache

```javascript
callComponent('cachelib', {
    operation: 'load',
    key: 'myCacheAlias'
}).then((res) => {
    if(res.success){
        console.log(res.plainData)
    }else{
        console.log("Error")
    }
})
```

### Remove data from cache

```javascript
callComponent('cachelib', {
    operation: 'remove',
    key: 'myCacheAlias'
}).then((res) => {
    if(res.success){
        console.log("Data removed")
    }else{
        console.log("Error")
    }
})
```

### Remove all data from cache
```javascript
callComponent('cachelib', {
    operation: 'remove_all'
}).then((res) => {
    if(res.success){
        console.log("All data removed")
    }else{
        console.log("Error")
    }
})
```



# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "cachelib" from the Project sidemenu
4. Select Build -> Make Module 'cachelib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/cachelib/build/outputs/aar/

# Test
1. Open Components-Android project in Android Studio
2. Open "cachelib" from the Project sidemenu
3. Open "java/com.santander.globile.cacheandroidlib (test)"
4. Open file "GlobalFactoryCacheTest"
5. Click ► icon next to "class GlobalFactoryCacheTest"