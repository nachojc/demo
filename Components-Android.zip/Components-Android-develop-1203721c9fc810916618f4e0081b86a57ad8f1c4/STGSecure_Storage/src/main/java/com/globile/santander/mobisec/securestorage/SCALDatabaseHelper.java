package com.globile.santander.mobisec.securestorage;

import android.content.Context;
import android.database.SQLException;

import com.globile.santander.mobisec.scal.securestorage.listeners.SCALDatabaseSecureStorageCallback;

import net.sqlcipher.database.SQLiteDatabase;
import net.sqlcipher.database.SQLiteOpenHelper;

public class SCALDatabaseHelper extends SQLiteOpenHelper {
	
	private SCALDatabaseSecureStorageCallback secureStorageCallback;
	
	public SCALDatabaseHelper(Context context, String name, int version, SCALDatabaseSecureStorageCallback secureStorageCallback) {
		super(context, name, null, version);
		this.secureStorageCallback = secureStorageCallback;
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		secureStorageCallback.onCreate(db);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		secureStorageCallback.onUpgrade(db, oldVersion, newVersion);
	}
	
	public SQLiteDatabase openWritable(String password) throws SQLException {
		return getWritableDatabase(password);
	}
}
