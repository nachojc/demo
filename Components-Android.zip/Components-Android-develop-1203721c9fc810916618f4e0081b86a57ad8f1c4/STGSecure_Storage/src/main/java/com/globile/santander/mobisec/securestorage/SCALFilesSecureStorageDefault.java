package com.globile.santander.mobisec.securestorage;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import android.util.Base64;
import android.util.Log;

import com.globile.santander.mobisec.cryptocipher.SecureStorage;
import com.globile.santander.mobisec.scal.securestorage.files.SCALFileMode;
import com.globile.santander.mobisec.scal.securestorage.files.SCALFilesSecureStorageModule;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.security.GeneralSecurityException;

public class SCALFilesSecureStorageDefault implements SCALFilesSecureStorageModule {
	
	private Context context;
	
	public SCALFilesSecureStorageDefault(Context context) {
		this.context = context;
	}
	
	@Override
	@WorkerThread
	public boolean removeSecurefile(String alias) {
		File file = getMaskedFile(alias);
		return file.delete();
	}
	
	@Override
	@WorkerThread
	public boolean clearSecurefile(String alias) {
		return removeSecurefile(alias) && writeToSecureFile(alias, null, SCALFileMode.DEFAULT_MODE);
	}
	
	@WorkerThread
	public boolean writeToSecureFile(String alias, @Nullable byte[] data, SCALFileMode fileMode) {
		FileWriter fileWriter = null;
		try {
			File file = getMaskedFile(alias);
			boolean create = fileMode != SCALFileMode.DEFAULT_MODE;
			
			if (file.exists()) {
				if (fileMode == SCALFileMode.DEFAULT_MODE) return false;
			} else {
				if (create) {
					if (!file.createNewFile()) return false;
				} else {
					return false;
				}
			}
			
			boolean append = fileMode == SCALFileMode.APPEND_MODE;
			if (append) {
				byte[] storedBytes = readFromSecurefile(alias);
				if (storedBytes != null) {
					ByteArrayOutputStream output = new ByteArrayOutputStream();
					output.write(storedBytes);
					output.write(data);
					
					data = output.toByteArray();
				}
			}
			
			String encrypted = encrypt(data, alias);
			
			fileWriter = new FileWriter(file, false);
			fileWriter.write(encrypted);
			fileWriter.flush();
			
			return true;
		} catch (IOException e) {
			Log.e(getClass().getSimpleName(), "writeToSecureFile", e);
		} catch (GeneralSecurityException e) {
			Log.e(getClass().getSimpleName(), "writeToSecureFile: failed encryption", e);
		} finally {
			safeClose(fileWriter);
		}
		return false;
	}
	
	@Override
	public boolean writeToSecureFile(String alias, byte[] data) {
		return writeToSecureFile(alias, data, SCALFileMode.DEFAULT_MODE);
	}
	
	@Override
	@WorkerThread
	@Nullable
	public byte[] readFromSecurefile(String alias) {
		FileReader fileReader = null;
		try {
			File file = getMaskedFile(alias);
			if (!file.exists()) {
				return null;
			}
			
			BufferedReader reader = new BufferedReader(new FileReader(file));
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line).append("\n");
			}
			reader.close();
			
			return decrypt(sb.toString(), alias);
		} catch (IOException e) {
			Log.e(getClass().getSimpleName(), "readFromSecurefile", e);
		} catch (GeneralSecurityException e) {
			Log.e(getClass().getSimpleName(), "readFromSecurefile: failed decryption", e);
		} finally {
			safeClose(fileReader);
		}
		return null;
	}
	
	/**
	 * Using SecureStorage class, encrypt the data
	 *
	 * @param data  the data serialized
	 * @param alias the alias of the key
	 *
	 * @return
	 */
	private String encrypt(byte[] data, String alias) throws GeneralSecurityException {
		return new SecureStorage(context, alias).encrypt(Base64.encodeToString(data, Base64.NO_WRAP));
	}
	
	/**
	 * Decrypt the encrypted string using SecureStorage class
	 *
	 * @param strEncrypted the string encrypted
	 * @param alias        the alias of the key
	 *
	 * @return decrypted data
	 */
	@Nullable
	private byte[] decrypt(String strEncrypted, String alias) throws GeneralSecurityException {
		String decrypted = new SecureStorage(this.context, alias).decrypt(strEncrypted);
		if (decrypted != null) {
			return Base64.decode(decrypted, Base64.NO_WRAP);
		}
		return null;
	}
	
	/**
	 * Build a File from an alias using some transformation
	 *
	 * @param alias the alias of the file
	 *
	 * @return the file
	 */
	private File getMaskedFile(String alias) {
		return new File(context.getFilesDir(), transformAlias(alias));
	}
	
	/**
	 * Transform the alias using the class SecureStorage
	 *
	 * @param alias to be transformed
	 *
	 * @return
	 */
	private String transformAlias(String alias) {
		return SecureStorage.hash(alias);
	}
	
	private void safeClose(Closeable closeable) {
		try {
			if (closeable != null) {
				closeable.close();
			}
		} catch (IOException e) {
			Log.e(getClass().getSimpleName(), "safeClose", e);
		}
	}
}
