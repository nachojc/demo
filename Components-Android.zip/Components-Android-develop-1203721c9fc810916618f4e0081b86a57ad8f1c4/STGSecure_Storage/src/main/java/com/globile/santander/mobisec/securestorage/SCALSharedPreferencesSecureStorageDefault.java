package com.globile.santander.mobisec.securestorage;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.support.annotation.Nullable;
import android.util.Log;

import com.globile.santander.mobisec.cryptocipher.SecureStorage;
import com.globile.santander.mobisec.scal.securestorage.sharedPrefs.SCALSharedPreferencesSecureStorageModule;

import java.io.File;
import java.security.GeneralSecurityException;

public class SCALSharedPreferencesSecureStorageDefault implements SCALSharedPreferencesSecureStorageModule {
	
	private Context context;
	
	public SCALSharedPreferencesSecureStorageDefault(Context context) {
		this.context = context;
	}
	
	@Override
	public boolean createNewSecureSharedPreferences(String name) {
		SharedPreferences prefs = getMaskedSharedPrefs(name);
		return prefs.edit().commit();
	}
	
	@Override
	public boolean clearSecureSharedPreferences(String name) {
		SharedPreferences prefs = getMaskedSharedPrefs(name);
		return prefs.edit().clear().commit();
	}
	
	@Override
	public boolean deleteSecureSharedPreferences(String name) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			return context.deleteSharedPreferences(hash(name));
		} else {
			String filePath = context.getFilesDir().getParent() + "/shared_prefs/" + hash(name) + ".xml";
			File deletePrefFile = new File(filePath);
			return deletePrefFile.delete();
		}
	}
	
	@Override
	public boolean setBoolean(String key, @Nullable Boolean value, String sharedPreferencesName) {
		return setString(key, String.valueOf(value), sharedPreferencesName);
	}
	
	@Override
	public boolean setString(String key, @Nullable String value, String sharedPreferencesName) {
		try {
			SharedPreferences prefs = getMaskedSharedPrefs(sharedPreferencesName);
			SharedPreferences.Editor ed = prefs.edit();
			String hash = hash(key);
			if (hash == null) {
				return false;
			}
			ed.putString(hash, getEncryptedValue(key, value));
			ed.apply();
			return true;
		} catch (GeneralSecurityException e) {
			Log.e(getClass().getSimpleName(), "setString: failed encryption", e);
			return false;
		}
	}
	
	private String hash(String key) {
		return SecureStorage.hash(key);
	}
	
	private SharedPreferences getMaskedSharedPrefs(String name) {
		return context.getSharedPreferences(hash(name), Context.MODE_PRIVATE);
	}
	
	/**
	 * @param toEncrypt the value to encrypt
	 *
	 * @return the encrypted value
	 */
	private String getEncryptedValue(String key, @Nullable String toEncrypt) throws GeneralSecurityException {
		return new SecureStorage(context, key).encrypt(toEncrypt);
	}
	
	@Override
	public boolean setInteger(String key, @Nullable Integer value, String sharedPreferencesName) {
		return setString(key, String.valueOf(value), sharedPreferencesName);
	}
	
	@Override
	public boolean setLong(String key, @Nullable Long value, String sharedPreferencesName) {
		return setString(key, String.valueOf(value), sharedPreferencesName);
	}
	
	@Override
	public boolean setDouble(String key, @Nullable Double value, String sharedPreferencesName) {
		return setString(key, String.valueOf(value), sharedPreferencesName);
	}
	
	@Override
	public boolean setFloat(String key, @Nullable Float value, String sharedPreferencesName) {
		return setString(key, String.valueOf(value), sharedPreferencesName);
	}
	
	@Nullable
	@Override
	public Boolean getBoolean(String key, String sharedPreferencesName) {
		return Boolean.valueOf(getString(key, sharedPreferencesName));
	}
	
	@Nullable
	@Override
	public String getString(String key, String sharedPreferencesName) {
		SharedPreferences prefs = getMaskedSharedPrefs(sharedPreferencesName);
		String encryptedValue = prefs.getString(hash(key), null);
		if (encryptedValue == null) return null;
		try {
			return getDecryptedValue(key, encryptedValue);
		} catch (GeneralSecurityException e) {
			Log.e(getClass().getSimpleName(), "getString: failed decryption", e);
			return null;
		}
	}
	
	/**
	 * @param key            Key
	 * @param encryptedValue Encrypted value
	 *
	 * @return Dedcrypted value
	 */
	private String getDecryptedValue(String key, String encryptedValue) throws GeneralSecurityException {
		return new SecureStorage(context, key).decrypt(encryptedValue);
	}
	
	@Nullable
	@Override
	public Integer getInteger(String key, String sharedPreferencesName) {
		String value = getString(key, sharedPreferencesName);
		try {
			return value == null ? null : Integer.valueOf(value);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Nullable
	@Override
	public Long getLong(String key, String sharedPreferencesName) {
		String value = getString(key, sharedPreferencesName);
		try {
			return value == null ? null : Long.valueOf(value);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Nullable
	@Override
	public Double getDouble(String key, String sharedPreferencesName) {
		String value = getString(key, sharedPreferencesName);
		try {
			return value == null ? null : Double.valueOf(value);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@Nullable
	@Override
	public Float getFloat(String key, String sharedPreferencesName) {
		String value = getString(key, sharedPreferencesName);
		try {
			return value == null ? null : Float.valueOf(value);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}
		return null;
	}
}
