# Introduction 
This component persists data on the device for access in the current or future sessions.

# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':localstoragelib')
```
3. Sync project with Gradle files

# Use
## From Native app
### Initialize component
Initialize the component with `init(context: Context)`:
```kotlin
LocalStorage.init(this)
```
### Save data to storage
Save data to an initialized storage with `saveData(alias: String, data: String)`:
```kotlin
LocalStorage.saveData("alias", "value")
```
### Retrieve data from storage
Retrieve data from storage with `loadData (alias: String, defValue: String?)`:
```kotlin
LocalStorage.loadData("alias")
```
### Remove data from storage
Remove data in storage with `removeData(alias:String)`:
```kotlin
LocalStorage.removeData("alias")
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib). Call the function with the following values:

componentName: "localstoragelib"

componentParams:
```javascript
{
    "operation": "save", // "save", "load", "remove"
    "alias": "userData", // alias for stored data
    "data": userData     // data to store
}
```
The returned Promise will be resolved with the following JSON object:
```javascript
{
    "operation": "String", // "save", "load", "remove"
    "success": "Boolean",  // whether the operation was successfully executed
    "data": "String"       // stored data (only returned in "load" operation)
}
```
### Save data to storage
```javascript
callComponent('localstoragelib', {
    operation: 'save',
    alias: 'userData',
    data: '{"name": "John Smith", "ID": "43534523V"}'
})
```
### Retrieve data from storage
```javascript
callComponent('localstoragelib', {
    operation: 'load',
    alias: 'userData'
}).then((res) => {
    console.log(res.data)
})
```
### Remove data from storage
```javascript
callComponent('localstoragelib', {
    operation: 'remove',
    alias: 'userData'
})
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "localstoragelib" from the Project sidemenu
4. Select Build -> Make Module 'localstoragelib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/localstoragelib/build/outputs/aar/

# Test
1. Open Components-Android project in Android Studio
2. Open "localstoragelib" from the Project sidemenu
3. Open "java/com.santander.globile.localstoragelib (test)"
4. Open file "LocalStorageTest"
5. Click ► icon next to "class LocalStorageTest"

# TODO
