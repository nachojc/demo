package com.santander.globile.localstoragelib.testutils

data class MockEntity(val value: String? = null, val number: Int? = null)