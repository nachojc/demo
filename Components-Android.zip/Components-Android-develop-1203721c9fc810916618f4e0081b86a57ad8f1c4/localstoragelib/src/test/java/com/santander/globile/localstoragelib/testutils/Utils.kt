package com.santander.globile.localstoragelib.testutils

import android.content.Context
import android.content.SharedPreferences
import org.mockito.ArgumentMatchers
import org.mockito.Mockito

fun initMockedSharedPreferences(
    context: Context,
    sharedPreferences: SharedPreferences,
    editor: SharedPreferences.Editor
) {
    Mockito.`when`(context.getSharedPreferences(ArgumentMatchers.anyString(), ArgumentMatchers.anyInt()))
        .thenReturn(sharedPreferences)

    Mockito.`when`(sharedPreferences.edit())
        .thenReturn(editor)

    Mockito.`when`(editor.putString(ArgumentMatchers.anyString(), ArgumentMatchers.anyString()))
        .thenReturn(editor)
}