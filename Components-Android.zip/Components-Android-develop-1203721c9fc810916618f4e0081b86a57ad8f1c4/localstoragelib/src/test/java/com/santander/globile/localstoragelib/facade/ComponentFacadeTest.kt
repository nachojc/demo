package com.santander.globile.localstoragelib.facade

import android.arch.core.executor.testing.InstantTaskExecutorRule
import android.arch.lifecycle.Observer
import android.content.Context
import android.content.SharedPreferences
import com.google.common.truth.Truth
import com.santander.globile.localstoragelib.LocalStorage
import com.santander.globile.localstoragelib.testutils.initMockedSharedPreferences
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class ComponentFacadeTest {

    private val componentFacade = ComponentFacade()
    private val mutableLiveData = componentFacade.liveData

    @get:Rule
    val rule = InstantTaskExecutorRule()


    @Mock
    lateinit var sharedPreferences: SharedPreferences

    @Mock
    lateinit var context: Context

    @Mock
    lateinit var editor: SharedPreferences.Editor

    @Mock
    lateinit var observer: Observer<String>

    @Before
    fun setUp() {
        MockitoAnnotations.initMocks(this)
        initMockedSharedPreferences(context, sharedPreferences, editor)
        LocalStorage.init(context)
    }

    @Test
    fun `Store plain string into SharedPreferences through ComponentFacade`() {
        // Arrange
        val alias = "a"
        val data = "b"
        val request = "{\"operation\":\"save\"," +
                "\"alias\": \"$alias\"," +
                "\"data\": \"$data\"}"

        val args = ArrayList<Any>()
        args.add(request)

        mutableLiveData.observeForever(observer)

        // Act
        componentFacade.startComponent(args)

        // Assert
        verify(sharedPreferences, times(1)).edit()
        verify(editor, times(1)).putString(alias, data)
        verify(editor, times(1)).apply()
        Truth.assertThat(mutableLiveData.value).isEqualTo("{\"success\":true,\"operation\":\"save\"}")
    }

    @Test
    fun `Store object into SharedPreferences through ComponentFacade`() {
        // Arrange
        val alias = "a"
        val objectData = "{\"value\":\"something\"}"
        val request = "{\"operation\":\"save\",\"alias\":\"$alias\",\"data\":$objectData}"
        val args = ArrayList<Any>()
        args.add(request)
        mutableLiveData.observeForever(observer)
        // Act
        componentFacade.startComponent(args)

        // Assert
        verify(sharedPreferences, times(1)).edit()
        verify(editor, times(1)).putString(alias, objectData)
        verify(editor, times(1)).apply()
        Truth.assertThat(mutableLiveData.value).isEqualTo("{\"success\":true,\"operation\":\"save\"}")
    }

    @Test
    fun `Get string data into SharedPreferences through ComponentFacade`() {
        // Arrange
        val alias = "a"
        val storedData = "b"
        val request = "{\"operation\":\"load\",\"alias\":\"$alias\"}"
        `when`(sharedPreferences.getString(alias, null)).thenReturn(storedData)

        val args = ArrayList<Any>()
        args.add(request)
        mutableLiveData.observeForever(observer)
        // Act
        componentFacade.startComponent(args)

        // Assert
        verify(sharedPreferences, times(1)).getString(alias, null)
        Truth.assertThat(mutableLiveData.value).isEqualTo(
            "{\"success\":true,\"operation\":\"load\",\"data\":\"$storedData\"}"
        )
    }

    @Test
    fun `Get object data into SharedPreferences through ComponentFacade`() {
        // Arrange
        val alias = "a"
        val storedData = "{\"value\":\"something\"}"
        val request = "{\"operation\":\"load\",\"alias\":\"$alias\"}"
        `when`(sharedPreferences.getString(alias, null)).thenReturn(storedData)

        val args = ArrayList<Any>()
        args.add(request)
        mutableLiveData.observeForever(observer)
        // Act
        componentFacade.startComponent(args)

        // Assert
        verify(sharedPreferences, times(1)).getString(alias, null)
        Truth.assertThat(mutableLiveData.value).isEqualTo(
            "{\"success\":true,\"operation\":\"load\",\"data\":\"{\\\"value\\\":\\\"something\\\"}\"}"
        )
    }

}