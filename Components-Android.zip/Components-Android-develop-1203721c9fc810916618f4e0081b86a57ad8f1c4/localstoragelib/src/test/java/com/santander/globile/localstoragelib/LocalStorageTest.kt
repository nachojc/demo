package com.santander.globile.localstoragelib

import android.content.Context
import android.content.SharedPreferences
import com.google.common.truth.Truth.assertThat
import com.santander.globile.localstoragelib.testutils.MockEntity
import com.santander.globile.localstoragelib.testutils.initMockedSharedPreferences
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito.*
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class LocalStorageTest {

    private lateinit var localStorage: LocalStorage

    @Mock
    lateinit var sharedPreferences: SharedPreferences

    @Mock
    lateinit var context: Context

    @Mock
    lateinit var editor: SharedPreferences.Editor

    @Before
    fun setUp() {
        initMockedSharedPreferences(context, sharedPreferences, editor)

        localStorage = LocalStorage(context)
    }

    @Test
    fun `Store plain string into SharedPreferences`() {
        // Arrange
        val alias = "alias"
        val data = "data"

        // Act
        localStorage.saveData(alias, data)

        // Assert
        verify(sharedPreferences, times(1)).edit()
        verify(editor, times(1)).putString(alias, data)
        verify(editor, times(1)).apply()
    }

    @Test
    fun `Store object into SharedPreferences, it must be stored as a JSON string`() {
        // Arrange
        val alias = "alias"
        val data = MockEntity("v", 1)
        val jsonData = "{\"value\":\"v\",\"number\":1}"

        // Act
        localStorage.saveData(alias, data)

        // Assert
        verify(sharedPreferences, times(1)).edit()
        verify(editor, times(1)).putString(alias, jsonData)
        verify(editor, times(1)).apply()
    }

    @Test
    fun `Get plain string from SharedPreferences without default value`() {
        // Arrange
        val alias = "alias"
        val expectedData = "data"
        `when`(sharedPreferences.getString(alias, null)).thenReturn(expectedData)

        // Act
        val result = localStorage.loadData(alias)

        // Assert
        verify(sharedPreferences, times(1)).getString(alias, null)
        assertThat(result).isEqualTo(expectedData)
    }

    @Test
    fun `Get plain string from SharedPreferences with default value`() {
        // Arrange
        val alias = "alias"
        val defaultValue = "default"
        val expectedData = "data"
        `when`(sharedPreferences.getString(alias, defaultValue)).thenReturn(expectedData)

        // Act
        val result = localStorage.loadData(alias, defaultValue)

        // Assert
        verify(sharedPreferences, times(1)).getString(alias, defaultValue)
        assertThat(result).isEqualTo(expectedData)
    }

    @Test
    fun `Get plain string from SharedPreferences with default value returned due to null stored value`() {
        // Arrange
        val alias = "alias"
        val defaultValue = "default"
        // By default SharedPreference mock will return null on its getString method

        // Act
        val result = localStorage.loadData(alias, defaultValue)

        // Assert
        verify(sharedPreferences, times(1)).getString(alias, defaultValue)
        assertThat(result).isEqualTo(defaultValue)
    }

    @Test
    fun `Get object from SharedPreferences without default value, it must be parsed into the given Class`() {
        // Arrange
        val alias = "alias"
        val jsonData = "{\"value\":\"v\",\"number\":1}"
        `when`(sharedPreferences.getString(alias, null)).thenReturn(jsonData)

        // Act
        val result = localStorage.loadData(alias, MockEntity::class.java)

        // Assert
        verify(sharedPreferences, times(1)).getString(alias, null)
        assertThat(result).isInstanceOf(MockEntity::class.java)
        assertThat(result?.value).isEqualTo("v")
        assertThat(result?.number).isEqualTo(1)
    }

    @Test
    fun `Get object from SharedPreferences with default value returned due to malformed json stored value`() {
        // Arrange
        val alias = "alias"
        val defaultValue = MockEntity("a", 2)
        val jsonData = "invalid json"
        `when`(sharedPreferences.getString(alias, null)).thenReturn(jsonData)

        // Act
        val result = localStorage.loadData(alias, MockEntity::class.java, defaultValue)

        // Assert
        verify(sharedPreferences, times(1)).getString(alias, null)
        assertThat(result).isInstanceOf(MockEntity::class.java)
        assertThat(result?.value).isEqualTo("a")
        assertThat(result?.number).isEqualTo(2)
    }
}