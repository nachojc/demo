package com.santander.globile.localstoragelib

import android.content.Context
import com.google.gson.JsonSyntaxException
import com.santander.globile.localstoragelib.common.fromJson
import com.santander.globile.localstoragelib.common.toJson

class LocalStorage(context: Context) {

    private val sharedPreferences =
        context.getSharedPreferences(LOCAL_STORAGE_SHARED_PREFS_FILENAME, Context.MODE_PRIVATE)

    /**
     * Saves some object data into local storage associated to given alias.
     *
     * @param alias
     * @param data
     */
    fun saveData(alias: String, data: Any?) {
        storeDataInSharedPreferences(alias, if (data is String?) data else data.toJson())
    }

    /**
     * Loads some data as [String] from local storage related to given alias.
     *
     * @param alias
     * @return Data from shared preferences.
     */
    fun loadData(alias: String, defValue: String? = null): String? =
        getDataFromSharedPreferences(alias, defValue) ?: defValue

    /**
     * Loads some [T] data from local storage related to given alias.
     *
     * @param alias
     * @param dataClass
     * @return Data from shared preferences.
     */
    fun <T> loadData(alias: String, dataClass: Class<T>, defValue: T? = null): T? =
        try {
            getDataFromSharedPreferences(alias, null)?.fromJson(dataClass) ?: defValue
        } catch (e: JsonSyntaxException) {
            defValue
        }

    /**
     * Removes the data from the local storage associated with given key.
     *
     * @param alias
     */
    fun removeData(alias: String) {
        sharedPreferences.edit().remove(alias).apply()
    }

    private fun storeDataInSharedPreferences(alias: String, data: String?) {
        sharedPreferences.edit().putString(alias, data).apply()
    }

    private fun getDataFromSharedPreferences(alias: String, defValue: String?): String? =
        sharedPreferences.getString(alias, defValue)

    companion object {

        private const val LOCAL_STORAGE_SHARED_PREFS_FILENAME = "local_data"

        private var localStorageSingletonInstance: LocalStorage? = null

        /**
         * This initialization method must be called using application [Context]
         * to create a [LocalStorage] singleton instance.
         * @param context Necessary context to instantiate singleton [LocalStorage] instance
         */
        fun init(context: Context) {
            localStorageSingletonInstance = LocalStorage(context)
        }

        /**
         * This initialization method must be called using an already initialized [LocalStorage]
         *
         * @param localStorage Instantiated [LocalStorage]
         */
        fun init(localStorage: LocalStorage) {
            localStorageSingletonInstance = localStorage
        }

        /**
         * Saves some object data into local storage using singleton instance of LocalStorage.
         *
         * @param alias
         * @param data
         * @throws IllegalAccessException Throws an [IllegalAccessException] when LocalStorage Singleton instance
         * has not been initialized.
         */
        fun saveData(alias: String, data: Any?) {
            localStorageSingletonInstance?.saveData(alias, data)
                ?: error("LocalStorage must be initialized first.")
        }

        /**
         * Loads some data as [String] from local storage related to given alias
         * using singleton instance of SecureStorage.
         *
         * @param alias
         * @return Decrypted data from shared preferences.
         * @throws IllegalAccessException Throws an [IllegalAccessException] when LocalStorage Singleton instance
         * has not been initialized.
         */
        fun loadData(alias: String): String? =
            if (localStorageSingletonInstance != null)
                localStorageSingletonInstance?.loadData(alias)
            else
                error("LocalStorage must be initialized first.")

        /**
         * Removes the data from local storage associated with given key.
         *
         * @param alias
         * @throws IllegalAccessException Throws an [IllegalAccessException] when LocalStorage Singleton instance
         * has not been initialized.
         */
        fun removeData(alias: String) {
            localStorageSingletonInstance?.removeData(alias) ?: error("LocalStorage must be initialized first.")
        }

    }
}