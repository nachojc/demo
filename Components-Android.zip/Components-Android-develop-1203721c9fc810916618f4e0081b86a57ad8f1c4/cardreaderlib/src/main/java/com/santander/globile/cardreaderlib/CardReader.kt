package com.santander.globile.cardreaderlib

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.support.v4.app.Fragment
import com.santander.globile.cardreaderlib.callback.CardReaderCallback
import com.santander.globile.cardreaderlib.common.CardInfo
import com.santander.globile.cardreaderlib.common.getCardInfoFromIntentData
import io.card.payment.CardIOActivity

/**
 * Launches the card scanner from a [Fragment].
 *
 * @param context Necessary to create the [Intent]
 * @param requestCode Request code for [Activity.startActivityForResult] method.
 * @param scanInstructions Hint text for the camera scan.
 */
fun Fragment.scanCard(context: Context, requestCode: Int, scanInstructions: String? = null) {

    startActivityForResult(intent(context, scanInstructions), requestCode)
}

/**
 * Launches the card scanner from an [Activity].
 *
 * @param requestCode Request code for [Activity.startActivityForResult] method.
 * @param scanInstructions Hint text for the camera scan.
 */
fun Activity.scanCard(requestCode: Int, scanInstructions: String? = null) {

    startActivityForResult(intent(this, scanInstructions), requestCode)
}

/**
 * @param context Necessary to create the [Intent].
 * @param scanInstructions Hint text for the camera scan.
 *
 * @return An [Intent] with the necessary extras to launch the scanner [Activity].
 */
fun intent(context: Context, scanInstructions: String?): Intent =
    Intent(context, CardIOActivity::class.java).apply {
        putExtra(CardIOActivity.EXTRA_HIDE_CARDIO_LOGO, true)
        putExtra(CardIOActivity.EXTRA_USE_PAYPAL_ACTIONBAR_ICON, false)
        putExtra(CardIOActivity.EXTRA_SCAN_INSTRUCTIONS, scanInstructions ?: "")
    }

/**
 * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the scanned data
 * as [CardInfo]. Call when [Activity.onActivityResult] is called.
 *
 * @param data Intent data from onActivityResult method.
 * @param cardReaderCallback The result is returned using an interface of [CardReaderCallback] type.
 */
fun handleOnActivityResult(data: Intent?, cardReaderCallback: CardReaderCallback) {

    getCardInfoFromIntentData(data)?.let { cardReaderCallback.onCardScanCompleted(it) }
        ?: cardReaderCallback.onCardScanCancelled()
}

/**
 * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the scanned data
 * as [CardInfo]. Call when [Activity.onActivityResult] is called.
 *
 * @param data Intent data from onActivityResult method.
 * @return [CardInfo] instance with scanned card data. It may be null.
 */
fun handleOnActivityResult(data: Intent?): CardInfo? = getCardInfoFromIntentData(data)