package uk.co.santander.contextdetection;

import android.app.Activity;
import android.content.Context;
import android.support.annotation.NonNull;
import com.globile.santander.mobisec.scal.contextdetection.listeners.*;

public abstract class DeviceDataAsyncProvider {
	
	/**
	 * Call this methods in order to obtain the geoposition
	 */
	static void getGeopositionData(GeopositionDataCallback geopositionDataCallback, Activity activity) {
		LocationProviderImpl.requestLocation(geopositionDataCallback, activity);
	}
	
	/**
	 * Call this methods in order to obtain the geoposition calculation structure risk.
	 */
	static void getGeopositionRiskData(GeopositionRiskCallback geopositionRiskCallback, Activity activity) {
		LocationRiskProviderImpl.requestLocationRisk(geopositionRiskCallback, activity);
	}
	
	/**
	 * Retrieve all the data in one call
	 *
	 * Make sure the permissions are granted before calling this method. The list of permissions is: ACCESS_COARSE_LOCATION, ACCESS_FINE_LOCATION,
	 * READ_PHONE_STATE, GET_ACCOUNTS and ACCESS_NETWORK_STATE. If the permissions are denied, the results will be incomplete but it will no fail.
	 *
	 * @param contextDataCallback
	 * @param geopositionDataCallback
	 * @param activity
	 */
	static void getAllData(
			@NonNull ContextDataCallback contextDataCallback, @NonNull GeopositionDataCallback geopositionDataCallback, @NonNull Activity activity) {
		LocationProviderImpl.requestLocation(geopositionDataCallback, activity);
		new AllDataProviderTask(contextDataCallback, activity).execute();
	}
	
	/**
	 * Call this methods in order to obtain all calculation structure risk.
	 */
	static void getAllRiskData(RiskStructCallback riskCallback, Activity activity) {
		LocationRiskProviderImpl.requestLocationRisk(riskCallback, activity);
		new RiskProviderTask(riskCallback, activity).execute();
	}
	
	static void getDeviceData(@NonNull DeviceDataCallback deviceDataCallback, Context context) {
		new DeviceDataProviderTask(deviceDataCallback, context).execute();
	}
	
	static void getApplicationData(@NonNull ApplicationDataCallback applicationDataCallback, Context context) {
		new ApplicationDataProviderTask(applicationDataCallback, context).execute();
	}
	
	static void getCommunicationData(@NonNull CommsDataCallback commsDataCallback, Context context) {
		new CommsDataProviderTask(commsDataCallback, context).execute();
	}
}
