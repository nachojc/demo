package uk.co.santander.contextdetection;

public enum RiskType {
    LOW(1),
    MEDIUM(5),
    HIGH(10);

    private int riskCalculated;

    RiskType(int riskCalculated){
        this.riskCalculated = riskCalculated;
    }

    public int getRiskCalculated() {
        return riskCalculated;
    }

    public void setRiskCalculated(int riskCalculated) {
        this.riskCalculated = riskCalculated;
    }
}
