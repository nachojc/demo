package uk.co.santander.contextdetection;

import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import com.globile.santander.mobisec.scal.contextdetection.listeners.CommsDataCallback;
import com.globile.santander.mobisec.scal.contextdetection.models.SCALCommsData;

import java.lang.ref.WeakReference;

class CommsDataProviderTask extends AsyncTask<Void, Void, SCALCommsData> {
	
	private WeakReference<CommsDataCallback> callbackWeakReference;
	private WeakReference<Context> contextWeakReference;
	
	CommsDataProviderTask(@NonNull CommsDataCallback callback, @NonNull Context context) {
		this.contextWeakReference = new WeakReference<>(context);
		this.callbackWeakReference = new WeakReference<>(callback);
	}
	
	@Override
	protected SCALCommsData doInBackground(Void... params) {
		if (contextWeakReference.get() != null) {
			return DeviceDataSyncProvider.getCommunicationData(contextWeakReference.get());
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(SCALCommsData commsData) {
		if (commsData != null && callbackWeakReference.get() != null) {
			callbackWeakReference.get().onCommsDataReady(commsData);
		}
	}
}
