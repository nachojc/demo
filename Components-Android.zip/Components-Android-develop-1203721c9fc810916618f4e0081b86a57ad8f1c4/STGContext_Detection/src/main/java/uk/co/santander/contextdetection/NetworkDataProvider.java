package uk.co.santander.contextdetection;

import android.content.Context;
import android.net.TrafficStats;
import com.globile.santander.mobisec.scal.contextdetection.models.AppNetworkInfo;
import com.globile.santander.mobisec.scal.contextdetection.models.NetworkAddressConnection;

import com.globile.santander.mobisec.scal.contextdetection.models.AppNetworkInfo;
import com.globile.santander.mobisec.scal.contextdetection.models.NetworkAddressConnection;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.*;

public class NetworkDataProvider {

    private Context context;
    private Map<Integer, AppNetworkInfo> apps = new HashMap<>();
    private final List<AppNetworkInfo> appInfos = new ArrayList<>();
    private final Map<String, String> STATE = stateMap();

    private Map<String, String> stateMap() {
        Map<String, String> m = new HashMap<String, String>();
        m.put("01", "ESTABLISHED");
        m.put("02", "SYN_SENT");
        m.put("03", "SYN_RECV");
        m.put("04", "FIN_WAIT1");
        m.put("05", "FIN_WAIT2");
        m.put("06", "TIME_WAIT");
        m.put("07", "CLOSE");
        m.put("08", "CLOSE_WAIT");
        m.put("09", "LAST_ACK");
        m.put("0A", "LISTEN");
        m.put("0B", "CLOSING");
        return Collections.unmodifiableMap(m);
    }

    NetworkDataProvider(Context context) {
        this.context = context;
    }

    public void buildNetstat() {
        apps.clear();
        appInfos.clear();
        parseProcNetTcp();
        parseProcNetTcp6();
        parseProcNetUdp();
        parseProcNetUdp6();
        appInfos.add(new AppNetworkInfo(-1, getLogHeader()));
        appInfos.add(new AppNetworkInfo(-1, parseProcNetRoute()));
        for (AppNetworkInfo obj : apps.values()) {
            appInfos.add(obj);
        }
    }

    private void parseProcNetTcp() {
        String[] lines = executeCommand("cat /proc/net/tcp");
        for (int i = 1; i < lines.length; i++) {
            String[] data = lines[i].trim().split("\\s+");
            int uid = Integer.parseInt(data[7]);
            if (!apps.containsKey(uid)) {
                apps.put(uid, new AppNetworkInfo(uid, context.getPackageManager().getNameForUid(uid)));
            }
            StringBuilder sb = new StringBuilder();
            sb.append(Integer.parseInt(data[4].substring(0, 8), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[4].substring(9, 16), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[1].substring(6, 8), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[1].substring(4, 6), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[1].substring(2, 4), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[1].substring(0, 2), 16));
            sb.append(":");
            sb.append(Integer.parseInt(data[1].substring(9), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[2].substring(6, 8), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[2].substring(4, 6), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[2].substring(2, 4), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[2].substring(0, 2), 16));
            sb.append(":");
            sb.append(Integer.parseInt(data[2].substring(9), 16));
            sb.append(" ");
            sb.append(STATE.get(data[3]));
            sb.append(" ");

            String address = sb.toString();

            apps.get(uid).addTcp(splitAddress(address, "TCP"));
        }

    }

    private void parseProcNetTcp6() {
        String[] lines = executeCommand("cat /proc/net/tcp6");
        for (int i = 1; i < lines.length; i++) {
            String[] data = lines[i].trim().split("\\s+");
            int uid = Integer.parseInt(data[7]);
            if (!apps.containsKey(uid)) {
                apps.put(uid, new AppNetworkInfo(uid, context.getPackageManager().getNameForUid(uid)));
            }

            StringBuilder sb = new StringBuilder();
            sb.append(Integer.parseInt(data[4].substring(0, 8), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[4].substring(9, 16), 16));
            sb.append(" ");
            sb.append(decodeIp6(data[1].substring(0, 32)));
            sb.append(":");
            sb.append(Integer.parseInt(data[1].substring(33), 16));
            sb.append(" ");
            sb.append( decodeIp6(data[2].substring(0, 32)));
            sb.append(":");
            sb.append(Integer.parseInt(data[2].substring(33), 16));
            sb.append(" ");
            sb.append(STATE.get(data[3]));
            sb.append(" ");

            String address = sb.toString();
            apps.get(uid).addTcp6(splitAddress(address, "TCP6"));
        }
    }

    private void parseProcNetUdp() {
        String[] lines = executeCommand("cat /proc/net/udp");
        for (int i = 1; i < lines.length; i++) {
            String[] data = lines[i].trim().split("\\s+");
            int uid = Integer.parseInt(data[7]);
            if (!apps.containsKey(uid)) {
                apps.put(uid, new AppNetworkInfo(uid, context.getPackageManager().getNameForUid(uid)));
            }

            StringBuilder sb = new StringBuilder();
            sb.append(Integer.parseInt(data[4].substring(0, 8), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[4].substring(9, 16), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[1].substring(6, 8), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[1].substring(4, 6), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[1].substring(2, 4), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[1].substring(0, 2), 16));
            sb.append(":");
            sb.append(Integer.parseInt(data[1].substring(9), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[2].substring(6, 8), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[2].substring(4, 6), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[2].substring(2, 4), 16));
            sb.append(".");
            sb.append(Integer.parseInt(data[2].substring(0, 2), 16));
            sb.append(":");
            sb.append(Integer.parseInt(data[2].substring(9), 16));
            sb.append(" ");
            sb.append(STATE.get(data[3]));
            sb.append(" ");

            String address = sb.toString();
            apps.get(uid).addUdp(splitAddress(address, "UDP"));
        }
    }

    private void parseProcNetUdp6() {
        String[] lines = executeCommand("cat /proc/net/udp6");
        for (int i = 1; i < lines.length; i++) {
            String[] data = lines[i].trim().split("\\s+");
            int uid = Integer.parseInt(data[7]);
            if (!apps.containsKey(uid)) {
                apps.put(uid, new AppNetworkInfo(uid, context.getPackageManager().getNameForUid(uid)));
            }

            StringBuilder sb = new StringBuilder();
            sb.append(Integer.parseInt(data[4].substring(0, 8), 16));
            sb.append(" ");
            sb.append(Integer.parseInt(data[4].substring(9, 16), 16));
            sb.append(" ");
            sb.append(decodeIp6(data[1].substring(0, 32)));
            sb.append(":");
            sb.append(Integer.parseInt(data[1].substring(33), 16));
            sb.append(" ");
            sb.append(decodeIp6(data[2].substring(0, 32)));
            sb.append(":");
            sb.append(Integer.parseInt(data[2].substring(33), 16));
            sb.append(" ");
            sb.append(STATE.get(data[3]));
            sb.append(" ");

            String address = sb.toString();
            apps.get(uid).addUdp6(splitAddress(address, "UDP6"));
        }
    }

    private String parseProcNetRoute() {
        String[] lines = executeCommand("cat /proc/net/route");
        StringBuilder routeOut = new StringBuilder();
        routeOut.append("Kernel IP routing table\n\n");
        for (int i = 1; i < lines.length; i++) {
            String[] data = lines[i].trim().split("\\s+");
            routeOut.append("Iface: " + data[0] + "\nDest: "
                    + Integer.parseInt(data[1].substring(6, 8), 16) + "."
                    + Integer.parseInt(data[1].substring(4, 6), 16) + "."
                    + Integer.parseInt(data[1].substring(2, 4), 16) + "."
                    + Integer.parseInt(data[1].substring(0, 2), 16) + "\nGate: "
                    + Integer.parseInt(data[2].substring(6, 8), 16) + "."
                    + Integer.parseInt(data[2].substring(4, 6), 16) + "."
                    + Integer.parseInt(data[2].substring(2, 4), 16) + "."
                    + Integer.parseInt(data[2].substring(0, 2), 16) + "\nMask: "
                    + Integer.parseInt(data[7].substring(6, 8), 16) + "."
                    + Integer.parseInt(data[7].substring(4, 6), 16) + "."
                    + Integer.parseInt(data[7].substring(2, 4), 16) + "."
                    + Integer.parseInt(data[7].substring(0, 2), 16) + "\nFlags: "
                    + data[3] + "\nMetric: " + data[6] + "\nRef: " + data[4] + "\nUse: " + data[5] + "\n\n");
        }
        return routeOut.toString();
    }

    private String decodeIp6(String s) {
        StringBuilder ip6 = new StringBuilder();
        for (int i = 0; i < s.length(); i += 4) {
            if (s.substring(i, i + 4).equalsIgnoreCase("0000")) {
                ip6.append(":");
                continue;
            }
            if (i == 16 && s.substring(i, i + 4).equalsIgnoreCase("FFFF")) {
                ip6.append("FFFF:");
                ip6.append("" + Integer.parseInt(s.substring(30, 32), 16) + "."
                        + Integer.parseInt(s.substring(28, 30), 16) + "."
                        + Integer.parseInt(s.substring(26, 28), 16) + "."
                        + Integer.parseInt(s.substring(24, 26), 16));
                return ip6.toString();
            }
            ip6.append(s.substring(i, i + 4) + ((i == 28) ? "" : ":"));
        }
        return ip6.toString();
    }

    private NetworkAddressConnection splitAddress(String str, String protocol){
        String[] address = str.trim().split("\\s+");

        NetworkAddressConnection addressConnection = new NetworkAddressConnection();

        addressConnection.setLocalAddress(address[2]);
        addressConnection.setForeingAddress(address[3]);
        addressConnection.setTxq(address[0]);
        addressConnection.setRxq(address[1]);
        addressConnection.setState(address[4]);
        addressConnection.setProtocol(protocol);

        return addressConnection;
    }

    private String[] executeCommand(String command) {
        Process ns = null;
        try {
            ns = Runtime.getRuntime().exec(command);
        } catch (IOException e) {
            e.printStackTrace();
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(ns.getInputStream()));
        int read;
        char[] buffer = new char[4096];
        StringBuffer output = new StringBuffer();
        try {
            while ((read = br.read(buffer)) > 0) {
                output.append(buffer, 0, read);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            ns.waitFor();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return output.toString().trim().split("\\r?\\n");
    }

    private String getLogHeader() {
        StringBuilder output = new StringBuilder();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        output.append(dateFormat.format(new Date()));
        output.append(" \n");
        output.append("Total Rx since boot: " + TrafficStats.getTotalRxBytes() + "\n");
        output.append("Total Tx since boot: " + TrafficStats.getMobileTxBytes() + "\n\n");
        return output.toString();
    }

    public Map<Integer, AppNetworkInfo> getApps() {
        return apps;
    }

    public List<AppNetworkInfo> getAppInfos() {
        return appInfos;
    }
}
