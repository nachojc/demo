package uk.co.santander.contextdetection;

import android.app.Activity;
import android.content.Context;
import com.globile.santander.mobisec.scal.contextdetection.SCALContextDetectionModule;
import com.globile.santander.mobisec.scal.contextdetection.listeners.*;
import com.globile.santander.mobisec.scal.contextdetection.models.DeviceRiskStruct;
import com.globile.santander.mobisec.scal.securestorage.sharedPrefs.SCALSharedPreferencesSecureStorageModule;

import java.util.List;

public class ContextDetectionDefaultImpl implements SCALContextDetectionModule {

    private Context context;
    private SCALSharedPreferencesSecureStorageModule sharedPreferences;

    public ContextDetectionDefaultImpl(Context context, SCALSharedPreferencesSecureStorageModule sharedPreferences) {
        this.context = context;
        this.sharedPreferences = sharedPreferences;
    }

    @Override
    public List<String> getUserBinding() {
        return DeviceDataSyncProvider.getUserBinding(context);
    }

    @Override
    public String getDeviceFootprint() {
        return DeviceDataSyncProvider.getDeviceFingerprinting(sharedPreferences, context.getContentResolver());
    }

    @Override
    public void setDeviceFootprint(String footprint) {
        DeviceDataSyncProvider.setDeviceFootprint(sharedPreferences, footprint);
    }

    @Override
    public List<DeviceRiskStruct> getDeviceRiskData() {
        return DeviceDataSyncProvider.getDeviceRiskData(context);
    }

    @Override
    public List<DeviceRiskStruct> getApplicationRiskData() {
        return DeviceDataSyncProvider.getApplicationRiskData(context);
    }

    @Override
    public List<DeviceRiskStruct> getCommunicationRiskData() {
        return DeviceDataSyncProvider.getCommunicationRiskData(context);
    }
    
    @Override
    public void getDeviceData(DeviceDataCallback deviceDataCallback) {
        DeviceDataAsyncProvider.getDeviceData(deviceDataCallback, context);
    }
    
    @Override
    public void getApplicationData(ApplicationDataCallback applicationDataCallback) {
        DeviceDataAsyncProvider.getApplicationData(applicationDataCallback, context);
    }
    
    @Override
    public void getCommunicationData(CommsDataCallback commsDataCallback) {
        DeviceDataAsyncProvider.getCommunicationData(commsDataCallback, context);
    }

    @Override
    public void getGeopositionData(GeopositionDataCallback geopositionDataCallback, Activity activity) {
        DeviceDataAsyncProvider.getGeopositionData(geopositionDataCallback, activity);
    }

    @Override
    public void getGeopositionRiskData(GeopositionRiskCallback geopositionRiskCallback, Activity activity) {
        DeviceDataAsyncProvider.getGeopositionRiskData(geopositionRiskCallback, activity);
    }

    @Override
    public void getAllRiskData(RiskStructCallback riskCallback, Activity activity) {
        DeviceDataAsyncProvider.getAllRiskData(riskCallback, activity);
    }

    @Override
    public void getAllData(ContextDataCallback callback, GeopositionDataCallback geopositionDataCallback, Activity activity) {
        DeviceDataAsyncProvider.getAllData(callback, geopositionDataCallback, activity);
    }

}
