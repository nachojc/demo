package uk.co.santander.contextdetection;

import android.content.Context;
import android.os.Build;
import com.globile.santander.mobisec.scal.contextdetection.models.DeviceRiskStruct;

import java.util.ArrayList;
import java.util.List;

class DeviceRiskCalculation {
	
	/**
	 * Device risk are annotated with RD
	 *
	 * @param context
	 *
	 * @return a list with all RD risks
	 */
	static List<DeviceRiskStruct> getDeviceRiskStruct(Context context) {
		List<DeviceRiskStruct> riskStructList = new ArrayList<>();
		for (RiskKey riskKey : RiskKey.values()) {
			switch (riskKey) {
				case KEY_RISK_OS_VERSION:
					riskStructList.add(evaluateOsRisk(riskKey));
					break;
				case KEY_RISK_DEV_OPTIONS:
					riskStructList.add(evaluateDevOptionsRisk(riskKey, context));
					break;
				case KEY_RISK_JAILBREAK_ROOT:
					riskStructList.add(evaluateRootRisk(riskKey));
					break;
				case KEY_RISK_USB:
					riskStructList.add(evaluateUSBRisk(riskKey, context));
					break;
				case KEY_RISK_DEVICE_AUTH_SETTINGS:
					riskStructList.add(evaluateDeviceAuthSettingsRisk(riskKey, context));
					break;
				default:
					break;
			}
		}
		return riskStructList;
	}
	
	/**
	 * Application risk are annotated with RA
	 *
	 * @param context
	 *
	 * @return a list with all RA risks
	 */
	static List<DeviceRiskStruct> getApplicationRiskStruct(Context context) {
		List<DeviceRiskStruct> riskStructList = new ArrayList<>();
		for (RiskKey riskKey : RiskKey.values()) {
			switch (riskKey) {
				case KEY_RISK_MALWARE_DETECTION:
					riskStructList.add(evaluateMalwareDetectionRisk(riskKey, context));
					break;
				case KEY_RISK_TAMPER_DETECTION:
					riskStructList.add(evaluateTamperDetectionRisk(riskKey, context));
					break;
				case KEY_RISK_PUA_DETECTION:
					riskStructList.add(evaluatePUADetectionRisk(riskKey, context));
					break;
				case KEY_RISK_GOODWARE_VULN_APPS:
					riskStructList.add(evaluateGoodwareVulnAppsRisk(riskKey, context));
					break;
				case KEY_RISK_OPEN_PORTS:
					riskStructList.add(evaluateOpenPortsRisk(riskKey, context));
					break;
				
				default:
					break;
			}
		}
		return riskStructList;
	}
	
	/**
	 * Communication risk are annotated with RC
	 *
	 * @param context
	 *
	 * @return a list with all RC risks
	 */
	static List<DeviceRiskStruct> getCommunicationRiskStruct(Context context) {
		List<DeviceRiskStruct> riskStructList = new ArrayList<>();
		for (RiskKey riskKey : RiskKey.values()) {
			switch (riskKey) {
				
				case KEY_RISK_WIFI_TYPE:
					riskStructList.add(evaluateWifiTypeRisk(riskKey, context));
					break;
				case KEY_RISK_DATA_TRANSMISSION:
					riskStructList.add(evaluateDataTransmissionRisk(riskKey, context));
					break;
				case KEY_RISK_BLUETOOTH:
					riskStructList.add(evaluateBluetoothRisk(riskKey));
					break;
				case KEY_RISK_NFC:
					riskStructList.add(evaluateNFCRisk(riskKey, context));
					break;
				default:
					break;
			}
		}
		return riskStructList;
	}
	
	/**
	 * Geoposition risk are annotated with RDa
	 *
	 * @param context
	 *
	 * @return a list with all RDa risks
	 */
	static List<DeviceRiskStruct> getGeopositionRiskStruct(Context context) {
		List<DeviceRiskStruct> riskStructList = new ArrayList<>();
		for (RiskKey riskKey : RiskKey.values()) {
			switch (riskKey) {
				case KEY_RISK_GEOLOCATION:
					riskStructList.add(evaluateGeolocationRisk(riskKey, context));
					break;
				case KEY_RISK_VISIBLE_NOTIFICATIONS:
					riskStructList.add(evaluateVisibleNotificationsRisk(riskKey, context));
					break;
				default:
					break;
			}
		}
		return riskStructList;
	}
	
	static List<DeviceRiskStruct> getAllRiskStruct(Context context) {
		List<DeviceRiskStruct> riskStructList = new ArrayList<>();
		riskStructList.addAll(getDeviceRiskStruct(context));
		riskStructList.addAll(getApplicationRiskStruct(context));
		riskStructList.addAll(getCommunicationRiskStruct(context));
		riskStructList.addAll(getGeopositionRiskStruct(context));
		return riskStructList;
	}
	
	private static DeviceRiskStruct evaluateNFCRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		boolean isNFCEnabled = DeviceDataProviderImpl.isNFCEnabled(context);
		deviceRisk.setValueDetected(ContextDetectionUtils.parseBooleanToOnOff(isNFCEnabled));
		
		// Low - Off
		// Medium - On
		deviceRisk.setRiskCalculated(isNFCEnabled ? RiskType.MEDIUM.getRiskCalculated() : RiskType.LOW.getRiskCalculated());
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateBluetoothRisk(RiskKey riskKey) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		boolean isBluetoothEnabled = DeviceDataProviderImpl.isBluetoothEnabled();
		deviceRisk.setValueDetected(ContextDetectionUtils.parseBooleanToOnOff(isBluetoothEnabled));
		
		// Low - Off
		// Medium - On
		deviceRisk.setRiskCalculated(isBluetoothEnabled ? RiskType.MEDIUM.getRiskCalculated() : RiskType.LOW.getRiskCalculated());
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateDataTransmissionRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		String networkFormatterType = DeviceDataProviderImpl.getNetworkFormattedType(context);
		deviceRisk.setValueDetected(networkFormatterType);
		
		// Low - 4G
		// Medium - 3G
		// High - <3G
		switch (networkFormatterType) {
			case "4g":
				deviceRisk.setRiskCalculated(RiskType.LOW.getRiskCalculated());
				break;
			case "3g":
				deviceRisk.setRiskCalculated(RiskType.MEDIUM.getRiskCalculated());
				break;
			default:
				deviceRisk.setRiskCalculated(RiskType.HIGH.getRiskCalculated());
				break;
		}
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateWifiTypeRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		String wifiType = DeviceDataProviderImpl.getNetworkSecurityType(context);
		deviceRisk.setValueDetected(wifiType);
		
		// Low - WPA-2
		// Medium - WPA, WEP
		// High - Non-encrypted
		switch (wifiType) {
			// No wifi connection detected
			case "N/A":
				deviceRisk.setValueDetected("Wifi disconnected");
			case "WPA-2":
				deviceRisk.setRiskCalculated(RiskType.LOW.getRiskCalculated());
				break;
			case "WPA":
			case "WEP":
				deviceRisk.setRiskCalculated(RiskType.MEDIUM.getRiskCalculated());
				break;
			default:
				deviceRisk.setRiskCalculated(RiskType.HIGH.getRiskCalculated());
				break;
		}
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateOpenPortsRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		//TODO: implement it properly
		deviceRisk.setValueDetected("N/A");
		
		// Low - 443
		// Medium - TDB (Ports 21, 22)
		// High - Blacklisted IPs
		deviceRisk.setRiskCalculated(-1);
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateGoodwareVulnAppsRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		//TODO: implement it properly
		String goodwareVulnApps = DeviceDataProviderImpl.getGoodwareVulnApps(context);
		deviceRisk.setValueDetected(goodwareVulnApps);
		
		// Low - No
		// Medium - Yes
		deviceRisk.setRiskCalculated(-1);
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluatePUADetectionRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		//TODO: implement it properly
		String puaDetection = DeviceDataProviderImpl.getPUADetection(context);
		deviceRisk.setValueDetected(puaDetection);
		
		// Low - No
		// Medium - Yes
		deviceRisk.setRiskCalculated(-1);
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateTamperDetectionRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		//TODO: implement it properly
		String tamperDetection = DeviceDataProviderImpl.getTamperDetection(context);
		deviceRisk.setValueDetected(tamperDetection);
		
		// Low - No
		// High - Yes
		deviceRisk.setRiskCalculated(-1);
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateMalwareDetectionRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		//TODO: implement it properly
		String malwareDetection = DeviceDataProviderImpl.getMalwareDetection(context);
		deviceRisk.setValueDetected(malwareDetection);
		
		// Low - N
		// Medium - TDB
		// High - Banking malware
		deviceRisk.setRiskCalculated(-1);
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateVisibleNotificationsRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		boolean areNotificationVisible = DeviceDataProviderImpl.areNotifVisible(context);
		deviceRisk.setValueDetected(ContextDetectionUtils.parseBooleanToAffirmation(areNotificationVisible));
		
		// Low - No
		// Medium - Yes
		deviceRisk.setRiskCalculated(areNotificationVisible ? RiskType.MEDIUM.getRiskCalculated() : RiskType.LOW.getRiskCalculated());
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateGeolocationRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		//TODO: implement it properly
		String geolocationRisk = context.getString(R.string.result_none);
		deviceRisk.setValueDetected(geolocationRisk);
		
		// Low - Expected country
		// Medium - TDB
		// High - TDB
		deviceRisk.setRiskCalculated(5);
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateDeviceAuthSettingsRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		String deviceAuthSettings = DeviceDataProviderImpl.getDeviceAuthSettings(context);
		deviceRisk.setValueDetected(deviceAuthSettings);
		
		// Low - Biometric factor
		// Medium - Pattern
		// High - Not enabled
		int authRisk;
		switch (deviceAuthSettings) {
			case "Biometric":
				authRisk = RiskType.LOW.getRiskCalculated();
				break;
			case "PatternOrPIN":
				authRisk = RiskType.MEDIUM.getRiskCalculated();
				break;
			case "NotEnabled":
			default:
				authRisk = RiskType.HIGH.getRiskCalculated();
				break;
		}
		
		deviceRisk.setRiskCalculated(authRisk);
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateUSBRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		boolean devOptions = DeviceDataProviderImpl.isUSBDebugEnabled(context);
		deviceRisk.setValueDetected(ContextDetectionUtils.parseBooleanToEnable(devOptions));
		
		// Low - Disabled
		// Medium - Enabled
		deviceRisk.setRiskCalculated(devOptions ? RiskType.HIGH.getRiskCalculated() : RiskType.LOW.getRiskCalculated());
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateRootRisk(RiskKey riskKey) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		boolean isRooted = DeviceDataProviderImpl.isRooted();
		deviceRisk.setValueDetected(ContextDetectionUtils.parseBooleanToAffirmation(isRooted));
		
		// Low - No
		// High - Yes
		deviceRisk.setRiskCalculated(isRooted ? RiskType.HIGH.getRiskCalculated() : RiskType.LOW.getRiskCalculated());
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateDevOptionsRisk(RiskKey riskKey, Context context) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		// If devOptionEnabled == 1, DevOption is enabled
		boolean devOptionEnabled = DeviceDataProviderImpl.getDevOptionEnabled(context);
		deviceRisk.setValueDetected(ContextDetectionUtils.parseBooleanToAffirmation(devOptionEnabled));
		
		// Low - Disabled
		// Medium - Enabled
		deviceRisk.setRiskCalculated(devOptionEnabled ? RiskType.MEDIUM.getRiskCalculated() : RiskType.LOW.getRiskCalculated());
		return deviceRisk;
	}
	
	private static DeviceRiskStruct evaluateOsRisk(RiskKey riskKey) {
		DeviceRiskStruct deviceRisk = createDeviceRisk(riskKey);
		String osVersion = DeviceDataProviderImpl.getOsVersion();
		deviceRisk.setValueDetected(osVersion);
		
		// Low - >= Android 8
		// Medium - <= Android 7
		// High - < Android 5
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
			deviceRisk.setRiskCalculated(RiskType.LOW.getRiskCalculated());
		} else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.LOLLIPOP) {
			deviceRisk.setRiskCalculated(RiskType.HIGH.getRiskCalculated());
		} else if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.N) {
			deviceRisk.setRiskCalculated(RiskType.MEDIUM.getRiskCalculated());
		}
		return deviceRisk;
	}
	
	private static DeviceRiskStruct createDeviceRisk(RiskKey riskKey) {
		DeviceRiskStruct deviceRisk = new DeviceRiskStruct();
		deviceRisk.setParameter(riskKey.getNameRiskKey());
		return deviceRisk;
	}
}
