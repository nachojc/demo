package uk.co.santander.contextdetection;

import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import com.globile.santander.mobisec.scal.contextdetection.listeners.ContextDataCallback;
import com.globile.santander.mobisec.scal.contextdetection.models.SCALContextData;

import java.lang.ref.WeakReference;

class AllDataProviderTask extends AsyncTask<Void, Void, SCALContextData> {
	
	private WeakReference<ContextDataCallback> callbackWeakReference;
	private WeakReference<Context> contextWeakReference;
	
	AllDataProviderTask(@NonNull ContextDataCallback callback, @NonNull Context context) {
		this.contextWeakReference = new WeakReference<>(context);
		this.callbackWeakReference = new WeakReference<>(callback);
	}
	
	@Override
	protected SCALContextData doInBackground(Void... params) {
		if (contextWeakReference.get() != null) {
			return DeviceDataSyncProvider.getAllSyncData(contextWeakReference.get());
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(SCALContextData contextData) {
		if (contextData != null && callbackWeakReference.get() != null) {
			callbackWeakReference.get().onContextDataReady(contextData);
		}
	}
}
