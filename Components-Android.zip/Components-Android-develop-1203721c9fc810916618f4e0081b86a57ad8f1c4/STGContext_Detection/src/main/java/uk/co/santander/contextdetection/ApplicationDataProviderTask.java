package uk.co.santander.contextdetection;

import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import com.globile.santander.mobisec.scal.contextdetection.listeners.ApplicationDataCallback;
import com.globile.santander.mobisec.scal.contextdetection.models.SCALApplicationData;

import java.lang.ref.WeakReference;

class ApplicationDataProviderTask extends AsyncTask<Void, Void, SCALApplicationData> {
	
	private WeakReference<ApplicationDataCallback> callbackWeakReference;
	private WeakReference<Context> contextWeakReference;
	
	ApplicationDataProviderTask(@NonNull ApplicationDataCallback callback, @NonNull Context context) {
		this.contextWeakReference = new WeakReference<>(context);
		this.callbackWeakReference = new WeakReference<>(callback);
	}
	
	@Override
	protected SCALApplicationData doInBackground(Void... params) {
		if (contextWeakReference.get() != null) {
			return DeviceDataSyncProvider.getApplicationData(contextWeakReference.get());
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(SCALApplicationData scalApplicationData) {
		if (scalApplicationData != null && callbackWeakReference.get() != null) {
			callbackWeakReference.get().onApplicationDataReady(scalApplicationData);
		}
	}
}
