package com.santander.globile.scalwebwrapperlib.facade.data

data class SCALWebWrapperParams(
    val operation: Int = 0
)
