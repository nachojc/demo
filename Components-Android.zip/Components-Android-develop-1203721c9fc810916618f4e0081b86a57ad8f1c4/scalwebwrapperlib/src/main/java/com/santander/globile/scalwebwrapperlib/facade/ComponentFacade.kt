package com.santander.globile.scalwebwrapperlib.facade

import android.app.Activity
import android.arch.lifecycle.MutableLiveData
import android.content.Context
import com.globile.santander.mobisec.scal.contextdetection.SCALContextDetection
import com.globile.santander.mobisec.scal.contextdetection.listeners.*
import com.globile.santander.mobisec.scal.contextdetection.models.*
import com.globile.santander.mobisec.scal.securestorage.sharedPrefs.SCALSharedPreferencesSecureStorage
import com.globile.santander.mobisec.securestorage.SCALSharedPreferencesSecureStorageDefault
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.santander.globile.scalwebwrapperlib.facade.data.SCALWebWrapperParams
import com.santander.globile.scalwebwrapperlib.facade.data.ScalWebWrapperConstants
import uk.co.santander.contextdetection.ContextDetectionDefaultImpl

/**
 * This class allows compatibility with WebViewBridge component and Archetype dispatcher in case the app contains
 * at least one web that needs to scan a security liveData from phone.
 */
class ComponentFacade :  GeopositionDataCallback,
    GeopositionRiskCallback, RiskStructCallback, DeviceDataCallback,ApplicationDataCallback,CommsDataCallback {

    var liveData: MutableLiveData<String> = MutableLiveData()
    lateinit var gson: Gson

    /**
     *
     * @param args A ArrayList with liveData to Use in this component:
     *
     *   args[0] = params formatted [String] with one field:
     *      const val USER_BINDING = 0
     *      const val DEVICE_FINGERPRINT_DATA = 1
     *      const val DEVICE_RISK_DATA = 2
     *      const val APPLICATION_RISK_DATA = 3
     *      const val COMMUNICATION_RISK_DATA = 4
     *      const val GEOPOSITION_RISK_DATA = 5
     *      const val ALL_RISK_DATA = 6
     *      const val DEVICE_DATA = 7
     *      const val APPLICATION_DATA = 8
     *      const val COMMUNICATION_DATA = 9
     *      const val GEOPOSITION_DATA = 10
     *
     *   args[1] = context from application
     *   args[2] = activity from application
     *
     *  @return A liveData formated [String] with liveData class parsed as JSON
     */

    fun startComponent(args: ArrayList<Any>){

        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
        val params = args[0] as String
        val context = args[1] as Context
        val activity = args[2] as Activity

        val scalWebWrapperParams =  gson.fromJson(params, SCALWebWrapperParams::class.java)
        val scalContextDetectionModule = SCALContextDetection(ContextDetectionDefaultImpl(context,SCALSharedPreferencesSecureStorage(
            SCALSharedPreferencesSecureStorageDefault(context)
        )))

        when (scalWebWrapperParams.operation) {

            ScalWebWrapperConstants.USER_BINDING -> {
                liveData.postValue(gson.toJson(scalContextDetectionModule.userBinding).toString())
            }

            ScalWebWrapperConstants.DEVICE_FINGERPRINT_DATA -> {
                liveData.postValue(gson.toJson(scalContextDetectionModule.deviceFootprint))
            }

            ScalWebWrapperConstants.DEVICE_RISK_DATA -> {
                liveData.postValue(gson.toJson(scalContextDetectionModule.deviceRiskData))
            }

            ScalWebWrapperConstants.APPLICATION_RISK_DATA -> {
                liveData.postValue(gson.toJson(scalContextDetectionModule.applicationRiskData))
            }

            ScalWebWrapperConstants.COMMUNICATION_RISK_DATA -> {
                liveData.postValue(gson.toJson(scalContextDetectionModule.communicationRiskData))
            }

            ScalWebWrapperConstants.COMMUNICATION_DATA -> {
                scalContextDetectionModule.getCommunicationData(this)
            }

            ScalWebWrapperConstants.APPLICATION_DATA -> {
                scalContextDetectionModule.getApplicationData(this)
            }

            ScalWebWrapperConstants.DEVICE_DATA -> {
                scalContextDetectionModule.getDeviceData(this)
            }

            ScalWebWrapperConstants.GEOPOSITION_RISK_DATA -> {
                scalContextDetectionModule.getGeopositionRiskData(this, activity)
            }
            ScalWebWrapperConstants.ALL_RISK_DATA -> {
                scalContextDetectionModule.getAllRiskData(this,activity)
            }
            ScalWebWrapperConstants.GEOPOSITION_DATA ->{
                scalContextDetectionModule.getGeopositionData(this,activity)
            }
        }
    }

    override fun onApplicationDataReady(applicationData: SCALApplicationData?) {
        liveData.postValue(gson.toJson(applicationData))
    }


    override fun onDeviceDataReady(deviceData: SCALDeviceData?) {
        liveData.postValue(gson.toJson(deviceData))
    }

    override fun onRisksReady(deviceRiskStructs: MutableList<DeviceRiskStruct>?) {
         liveData.postValue(gson.toJson(deviceRiskStructs))
    }

    override fun onGeopositionRiskReady(geopositionRisks: MutableList<DeviceRiskStruct>?) {
        liveData.postValue(gson.toJson(geopositionRisks))
    }

    override fun onCommsDataReady(commsData: SCALCommsData?) {
        liveData.postValue(gson.toJson(commsData))
    }

    override fun showEnableGpsDialog(): Boolean {
        return true
    }

    override fun onGeopositionAddressReady(scalGeoData: SCALGeoData?) {
        liveData.postValue(gson.toJson(scalGeoData))
    }



}