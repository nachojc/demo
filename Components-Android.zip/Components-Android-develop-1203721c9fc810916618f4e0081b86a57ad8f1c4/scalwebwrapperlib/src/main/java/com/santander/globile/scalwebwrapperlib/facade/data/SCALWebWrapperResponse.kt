package com.santander.globile.scalwebwrapperlib.facade.data

import android.os.Parcel
import android.os.Parcelable

data class SCALWebWrapperResponse(
    val operation: Int = 0,
    val data: String?
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString()
    )


    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(operation)
        parcel.writeString(data)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<SCALWebWrapperResponse> {
        override fun createFromParcel(parcel: Parcel): SCALWebWrapperResponse {
            return SCALWebWrapperResponse(parcel)
        }

        override fun newArray(size: Int): Array<SCALWebWrapperResponse?> {
            return arrayOfNulls(size)
        }
    }
}