package com.globile.santander.mobisec.cryptocipher;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Base64;
import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.spec.AlgorithmParameterSpec;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;

/**
 * Created by oandujar on 05/03/2019.
 */
public class Crypto {
	
	private static final String TAG = Crypto.class.getName();
	
	private static final Charset UTF_8 = Charset.forName("UTF-8");
	private static final String IV_SEPARATOR = "]";
	private static final String AES_GCM_NO_PADDING = "AES/GCM/NoPadding";
	private static final String ERROR_WITH_ENCRYPTION = "Error on encrypt";
	private static final String ERROR_WITH_DECRYPTION = "Error on decrypt";
	private static final String ERROR_WITH_IV = "Error on IV";
	
	private static final int TAG_LENGTH_BYTES = 16;
	private static final int CIPHER_CHUNK_SIZE = 64 * 1024;
	
	/**
	 * Method used to encrypt plain text.
	 *
	 * @return encrypted data in Base64 String or null if any error occur.
	 */
	public String encrypt(@NonNull String data, @NonNull Key key) throws GeneralSecurityException {
		String result;
		try {
			Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			
			byte[] iv = cipher.getIV();
			String ivString = Base64.encodeToString(iv, Base64.NO_WRAP);
			result = ivString + IV_SEPARATOR;
			
			byte[] plainData = data.getBytes(UTF_8);
			byte[] decodedData = decode(cipher, plainData);
			
			String encodedString = Base64.encodeToString(decodedData, Base64.NO_WRAP);
			result += encodedString;
			
			return result;
		} catch (NoSuchAlgorithmException | IOException | BadPaddingException |
				IllegalBlockSizeException | NoSuchPaddingException | InvalidKeyException e) {
			Log.e(TAG, ERROR_WITH_ENCRYPTION, e);
			throw new GeneralSecurityException("failed encrypt", e);
		}
	}
	
	/**
	 * Method used to encrypt plain text.
	 *
	 * @return encrypted data in Base64 String or null if any error occur.
	 */
	public String encrypt(@NonNull String data, @NonNull Key key, byte[] iv) throws GeneralSecurityException {
		try {
			Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
			cipher.init(Cipher.ENCRYPT_MODE, key, getParams(iv));
			
			byte[] plainData = data.getBytes(UTF_8);
			byte[] decodedData = decode(cipher, plainData);
			
			return Base64.encodeToString(decodedData, Base64.NO_WRAP);
		} catch (NoSuchAlgorithmException | IOException
				| BadPaddingException | IllegalBlockSizeException
				| NoSuchPaddingException | InvalidKeyException
				| InvalidAlgorithmParameterException e) {
			Log.e(TAG, ERROR_WITH_ENCRYPTION, e);
			throw new GeneralSecurityException("failed encrypt", e);
		}
	}
	
	private byte[] decode(@NonNull Cipher cipher, @NonNull byte[] data)
			throws IOException, BadPaddingException, IllegalBlockSizeException {
		ByteArrayOutputStream bout = new ByteArrayOutputStream();
		for (int i = 0; i < data.length; i += CIPHER_CHUNK_SIZE) {
			int len = Math.min(CIPHER_CHUNK_SIZE, data.length - i);
			byte[] ciphered = cipher.update(data, i, len);
			if (ciphered != null) {
				bout.write(ciphered);
			}
		}
		bout.write(cipher.doFinal());
		return bout.toByteArray();
	}
	
	/**
	 * Method used to decrypt.
	 *
	 * @return decrypted data or null if any error occur
	 */
	public String decrypt(@NonNull String data, @NonNull Key key) throws GeneralSecurityException {
		String[] split = data.split(IV_SEPARATOR);
		if(split.length == 2) {
			return decrypt(split[1], key, split[0]);
		}
		return null;
	}
	
	/**
	 * Method used to decrypt.
	 *
	 * @return decrypted data or null if any error occur
	 */
	public String decrypt(@NonNull String data, @NonNull Key key, String ivString) throws GeneralSecurityException {
		try {
			Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
			cipher.init(Cipher.DECRYPT_MODE, key, getParams(Base64.decode(ivString, Base64.NO_WRAP)));
			
			byte[] encryptedData = Base64.decode(data, Base64.NO_WRAP);
			byte[] decodedData = decode(cipher, encryptedData);
			return new String(decodedData, UTF_8);
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException |
				IOException | InvalidAlgorithmParameterException | BadPaddingException |
				IllegalBlockSizeException e) {
			Log.e(TAG, ERROR_WITH_DECRYPTION, e);
			throw new GeneralSecurityException("failed decrypt", e);
		}
	}
	
	private static AlgorithmParameterSpec getParams(final byte[] iv) {
		return getParams(iv, 0, iv.length);
	}
	
	private static AlgorithmParameterSpec getParams(final byte[] buf, int offset, int len) {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {
			// GCMParameterSpec should always be present in Java 7 or newer, but it's missing on
			// some Android devices with API level <= 19. Fortunately, we can initialize the cipher
			// with just an IvParameterSpec. It will use a tag size of 128 bits.
			return new IvParameterSpec(buf, offset, len);
		}
		return new GCMParameterSpec(TAG_LENGTH_BYTES * 8, buf, offset, len);
	}
	
	public byte[] generateRandomIv(Key key) {
		try {
			Cipher cipher = Cipher.getInstance(AES_GCM_NO_PADDING);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			return cipher.getIV();
		} catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException e) {
			Log.e(TAG, ERROR_WITH_IV, e);
		}
		throw new IllegalStateException("error generating random iv");
	}
	
	/**
	 * Create a hash using SHA-256
	 *
	 * @param text to hash
	 *
	 * @return the hash
	 */
	@Nullable
	static String hash(String text) {
		return hash(text, "SHA-256");
	}
	
	/**
	 * Create a hash using the algorithm provided
	 *
	 * @param text to hash
	 *
	 * @return the hash
	 */
	@Nullable
	static String hash(String text, String algorithm) {
		try {
			MessageDigest digest = MessageDigest.getInstance(algorithm);
			byte[] bytes = text.getBytes(UTF_8);//Can't use constant instead; available from API level 19, current min is 17. How to suppress warning?
			byte[] hash = digest.digest(bytes);
			StringBuilder hexString = new StringBuilder();
			for (byte aHash : hash) {
				String hex = Integer.toHexString(0xff & aHash);
				if (hex.length() == 1) hexString.append('0');
				hexString.append(hex);
			}
			return hexString.toString();
		} catch (NoSuchAlgorithmException e) {
			Log.e(Crypto.class.getCanonicalName(), "failed to hash using " + algorithm, e);
		}
		return null;
	}
}