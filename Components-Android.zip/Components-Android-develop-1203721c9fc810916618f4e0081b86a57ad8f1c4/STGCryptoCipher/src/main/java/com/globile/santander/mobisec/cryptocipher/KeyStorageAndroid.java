package com.globile.santander.mobisec.cryptocipher;
import android.support.annotation.NonNull;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.crypto.SecretKey;

abstract class KeyStorageAndroid {
	
	KeyStore createKeyStore()
			throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
		throw new UnsupportedOperationException("Must override methods");
	}
	
	/**
	 * Create and saves 256 AES SecretKey key using provided alias and password.
	 * <p/>
	 * Saves key to KeyStore. Uses keystore with default type located in application cache on device if API < 23.
	 * Uses AndroidKeyStore if API is >= 23.
	 *
	 * @return KeyPair or null if any error occurs
	 */
	SecretKey generateSymmetricKey(@NonNull String alias, char[] password, Integer remainingTime, boolean authenticated) {
		KeyProps keyProps = new KeyProps.Builder()
				.setAlias(SecureStorage.hash(alias))
				.setPassword(password)
				.setKeySize(256)
				.setKeyType("AES")
				.setBlockModes("GCM")
				.setEncryptionPaddings("NoPadding")
				.setRemainingTime(remainingTime)
				.build();
		return generateSymmetricKey(keyProps, authenticated);
	}
	
	/**
	 * Create and saves SecretKey key specified in KeyProps.
	 * <p/>
	 * Saves key to KeyStore. Uses keystore with default type located in application cache on device if API < 23.
	 * Uses AndroidKeyStore if API is >= 23.
	 *
	 * @return KeyPair or null if any error occurs
	 */
	SecretKey generateSymmetricKey(@NonNull KeyProps keyProps, boolean authenticated) {
		throw new UnsupportedOperationException("Must override methods");
	}
	
	SecretKey getSymmetricKey(@NonNull String alias, char[] password) {
		throw new UnsupportedOperationException("Must override methods");
	}
	
	/**
	 * Method to store a existing key in KeyStore.
	 *
	 * @param alias alias to store the key
	 * @param key   the key
	 */
	void storeSymmetricKey(String alias, SecretKey key, char[] password) throws GeneralSecurityException {
		throw new UnsupportedOperationException("Must override methods");
	}
	
	/**
	 * Check if a key exist on KeyStore.
	 *
	 * @return true if key with given alias is in keystore
	 */
	boolean hasKey(@NonNull String alias) {
		throw new UnsupportedOperationException("Must override methods");
	}
	
	/**
	 * Remove existing key in KeyStore
	 *
	 * @param alias to be removed
	 */
	void removeKey(String alias) {
		throw new UnsupportedOperationException("Must override methods");
	}
}
