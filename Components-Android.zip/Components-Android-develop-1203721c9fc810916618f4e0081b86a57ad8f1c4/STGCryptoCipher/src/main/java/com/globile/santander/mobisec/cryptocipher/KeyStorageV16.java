package com.globile.santander.mobisec.cryptocipher;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import static java.security.KeyStore.getDefaultType;
import static java.security.KeyStore.getInstance;

/**
 * Created by oandujar on 05/03/2019.
 */
class KeyStorageV16 extends KeyStorageAndroid {
	
	static final String TAG = KeyStorageV16.class.getName();
	
	private static final String DEFAULT_KEYSTORE_NAME = "keystore";
	private static final char[] DEFAULT_KEYSTORE_PASSWORD = BuildConfig.APPLICATION_ID.toCharArray();
	private static final String ERROR_GENERATE_KEY = "Error generating Key";
	private static final String ERROR_GETTING_KEY = "Error getting Key";
	private static final String ERROR_SETTING_KEY = "Error setting Key";
	private static final String ERROR_RETRIEVING_KEY = "Error retrieving key";
	
	private char[] mKeystorePassword = DEFAULT_KEYSTORE_PASSWORD;
	private final File mKeystoreFile;
	
	private KeyStore mDefaultKeyStore;
	private final Context mContext;
	
	/**
	 * Constructor to instantiate KeyStorage
	 *
	 * @param context used to initialize file directory, with default name and password on KeyStorage.
	 */
	KeyStorageV16(@NonNull Context context) {
		this.mContext = context;
		mKeystoreFile = new File(mContext.getFilesDir(), SecureStorage.hash(DEFAULT_KEYSTORE_NAME));
	}
	
	/**
	 * Constructor to instantiate KeyStorage
	 *
	 * @param context  used to initialize file directory
	 * @param name     used to identify current KeyStore
	 * @param password used to store data on KeyStore
	 */
	KeyStorageV16(@NonNull Context context, @NonNull String name, char[] password) {
		mContext = context;
		mKeystorePassword = password;
		mKeystoreFile = new File(mContext.getFilesDir(), SecureStorage.hash(name));
	}
	
	/**
	 * Cache for android keystore
	 */
	
	@Override
	KeyStore createKeyStore()
			throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
		if (mDefaultKeyStore == null) {
			String defaultType = getDefaultType();
			mDefaultKeyStore = getInstance(defaultType);
			if (!mKeystoreFile.exists()) {
				mDefaultKeyStore.load(null);
			} else {
				mDefaultKeyStore.load(new FileInputStream(mKeystoreFile), mKeystorePassword);
			}
		}
		return mDefaultKeyStore;
	}
	
	/**
	 * Create and saves SecretKey key specified in KeyProps.
	 * <p/>
	 * Saves key to KeyStore. Uses keystore with default type located in application cache on device if API < 23.
	 * Uses AndroidKeyStore if API is >= 23.
	 *
	 * @return KeyPair or null if any error occurs
	 */
	SecretKey generateSymmetricKey(@NonNull KeyProps keyProps, boolean authenticated) {
		return generateDefaultSymmetricKey(keyProps);
	}
	
	private SecretKey createSymmetricKey(KeyProps keyProps) throws NoSuchAlgorithmException {
		KeyGenerator keyGenerator = KeyGenerator.getInstance(keyProps.mKeyType);
		keyGenerator.init(keyProps.mKeySize);
		SecretKey key = keyGenerator.generateKey();
		return key;
	}
	
	private SecretKey generateDefaultSymmetricKey(KeyProps keyProps) {
		try {
			SecretKey key = createSymmetricKey(keyProps);
			KeyStore.SecretKeyEntry keyEntry = new KeyStore.SecretKeyEntry(key);
			KeyStore keyStore = createKeyStore();
			
			//Dont hash the alias again here
			keyStore.setEntry(keyProps.mAlias, keyEntry, new KeyStore.PasswordProtection(keyProps.mPassword));
			keyStore.store(new FileOutputStream(mKeystoreFile), mKeystorePassword);
			return key;
		} catch (NoSuchAlgorithmException | CertificateException | KeyStoreException | IOException e) {
			Log.e(TAG, ERROR_GENERATE_KEY, e);
		}
		return null;
	}
	
	/**
	 * Getting symmetric key from KeyStore
	 *
	 * @return SecretKey or null if any error occurs
	 */
	SecretKey getSymmetricKey(@NonNull String alias, char[] password) {
		return getSymmetricKeyFromDefaultKeyStore(alias, password);
	}
	
	private SecretKey getSymmetricKeyFromDefaultKeyStore(@NonNull String alias, char[] password) {
		SecretKey result = null;
		try {
			KeyStore keyStore = createKeyStore();
			result = (SecretKey) keyStore.getKey(SecureStorage.hash(alias), password);
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException | UnrecoverableEntryException e) {
			Log.e(TAG, ERROR_GETTING_KEY, e);
		}
		return result;
	}
	
	/**
	 * Method to store a existing key in KeyStore.
	 *
	 * @param alias alias to store the key
	 * @param key   the key
	 */
	void storeSymmetricKey(String alias, SecretKey key, char[] password) throws GeneralSecurityException {
		try {
			KeyStore keyStore = createKeyStore();
			keyStore.setKeyEntry(SecureStorage.hash(alias), key, password, null);
			keyStore.store(new FileOutputStream(mKeystoreFile), mKeystorePassword);
			
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException e) {
			Log.e(TAG, ERROR_SETTING_KEY, e);
			throw new GeneralSecurityException("store symmetric key failed", e);
		}
	}
	
	/**
	 * Check if a key exist on KeyStore.
	 *
	 * @return true if key with given alias is in keystore
	 */
	boolean hasKey(@NonNull String alias) {
		boolean result = false;
		try {
			KeyStore keyStore = createKeyStore();
			result = isKeyEntry(alias, keyStore);
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException e) {
			Log.e(TAG, ERROR_RETRIEVING_KEY, e);
		}
		
		return result;
	}
	
	/**
	 * Remove existing key in KeyStore
	 *
	 * @param alias to be removed
	 */
	void removeKey(String alias) {
		try {
			KeyStore keyStore = createKeyStore();
			keyStore.deleteEntry(SecureStorage.hash(alias));
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException e) {
			Log.e(TAG, ERROR_RETRIEVING_KEY, e);
		}
	}
	
	private boolean isKeyEntry(@NonNull String alias, KeyStore keyStore) throws KeyStoreException {
		return keyStore != null && keyStore.isKeyEntry(SecureStorage.hash(alias));
	}
}
