package com.globile.santander.mobisec.cryptocipher;

import android.content.Context;
import android.support.annotation.Nullable;

import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.SecretKey;

/**
 * Created by oandujar on 05/03/2019.
 */
public class SecureStorage {
	
	private KeyStorage keyStorage;
	private Crypto crypto;
	
	private String alias;
	private char[] password;
	private Integer remainingTime;
	private boolean authenticated;
	
	public SecureStorage(Context context, String alias) {
		this.alias = alias;
		
		init(context);
	}
	
	public SecureStorage(Context context, String alias, @Nullable char[] password) {
		this.alias = alias;
		this.password = password;
		
		init(context);
	}
	
	public SecureStorage(Context context, String alias, @Nullable Integer remainingTime) {
		this.alias = alias;
		this.password = alias.toCharArray();
		this.remainingTime = remainingTime;
		
		init(context);
	}
	
	public SecureStorage(Context context, String alias, Integer remainingTime, boolean authenticated) {
		this.alias = alias;
		this.remainingTime = remainingTime;
		this.authenticated = authenticated;
		
		init(context);
	}
	
	private void init(Context context) {
		this.crypto = new Crypto();
		this.keyStorage = new KeyStorage(context);
		initCrypto();
	}
	
	/**
	 * Method used to init Crypto, in order to create a new symmetric SecretKey.
	 */
	private void initCrypto() {
		createSecretKey(alias, remainingTime, authenticated);
	}
	
	/**
	 * Method used to get current SecretKey.
	 *
	 * @return SecretKey
	 */
	public SecretKey getSecretKey() {
		return keyStorage.getSymmetricKey(alias, password);
	}
	
	/**
	 * Method used to get a SecretKey.
	 *
	 * @return SecretKey
	 */
	public SecretKey getSecretKey(String alias) {
		return keyStorage.getSymmetricKey(alias, password);
	}
	
	/**
	 * Method to create  a SecretKey with a provided alias
	 *
	 * @param alias for the SecretKey
	 */
	public void createSecretKey(String alias, Integer remainingTime, boolean authenticated) {
		if (!keyStorage.hasKey(alias)) {
			keyStorage.generateSymmetricKey(alias, password, remainingTime, authenticated);
		}
	}
	
	/**
	 * Method used to encrypt.
	 *
	 * @param str plain data to encrypt.
	 * @param key the key to encrypt
	 *
	 * @return encrypted data in Base64 String or null if any error occur.
	 */
	public String encrypt(String str, Key key) throws GeneralSecurityException {
		return crypto.encrypt(str, key);
	}
	
	/**
	 * Method used to encrypt. The key used is the default one
	 *
	 * @param str plain data to encrypt.
	 *
	 * @return encrypted data in Base64 String or null if any error occur.
	 */
	public String encrypt(String str) throws GeneralSecurityException {
		return encrypt(str, getSecretKey());
	}
	
	/**
	 * Method used to decrypt.
	 *
	 * @param strEncrypted Base64 encrypted data with iv key.
	 * @param key          the key to decrypt
	 *
	 * @return decrypted data or null if any error occur.
	 */
	public String decrypt(String strEncrypted, Key key) throws GeneralSecurityException {
		return crypto.decrypt(strEncrypted, key);
	}
	
	/**
	 * Method used to decrypt. The key used is the default one
	 *
	 * @param strEncrypted Base64 encrypted data with iv key.
	 *
	 * @return decrypted data or null if any error occur.
	 */
	public String decrypt(String strEncrypted) throws GeneralSecurityException {
		return decrypt(strEncrypted, getSecretKey());
	}
	
	/**
	 * Create a hash using SHA-256
	 *
	 * @param text to hash
	 *
	 * @return the hash
	 */
	@Nullable
	public static String hash(String text) {
		return Crypto.hash(text);
	}
	
}
