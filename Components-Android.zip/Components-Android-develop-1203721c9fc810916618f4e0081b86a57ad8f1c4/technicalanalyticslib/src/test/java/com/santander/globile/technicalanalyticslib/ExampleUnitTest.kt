package com.santander.globile.technicalanalyticslib

import com.santander.globile.technicalanalyticslib.facade.ComponentFacade

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {


    @Test
    fun addition_isCorrect() {
        val jsonData = "{\"operation\":\"exception\",\"logId\":2,\"key\":\"key\",\"value\":\"Hola mundo\",\"exceptionMsg\":\"eXCEPTION Hola mundo\"}"
        val facade = ComponentFacade()
        facade.startComponent(jsonData)
        assertSame(true,true)
    }


}
