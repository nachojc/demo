package com.santander.globile.technicalanalyticslib.facade.data


/**
 * Entity that holds Technical Analytics Response.
 *
 * @param success: the type associated to analytics event.
 * @param operation can contains: "log_event" or "set_user_property" liveData.
 */
data class TechnicalAnalyticsResponse(
    val success: Boolean = false,
    val operation: String? = null
)
