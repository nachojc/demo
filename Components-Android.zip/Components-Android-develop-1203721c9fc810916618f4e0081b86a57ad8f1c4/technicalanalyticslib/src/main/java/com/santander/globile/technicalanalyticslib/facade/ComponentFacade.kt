package com.santander.globile.technicalanalyticslib.facade

import android.arch.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.santander.globile.technicalanalyticslib.GlobileAnalytics
import com.santander.globile.technicalanalyticslib.facade.data.TechnicalAnalyticsParams
import com.santander.globile.technicalanalyticslib.facade.data.TechnicalAnalyticsResponse
import com.santander.globile.technicalanalyticslib.utils.EXCEPTION
import com.santander.globile.technicalanalyticslib.utils.PERSONALIZEDKEY
import com.santander.globile.technicalanalyticslib.utils.SENDLOG
import com.santander.globile.technicalanalyticslib.utils.USERID

/**
 * This class allows compatibility with WebViewBridge component and Archetype dispatcher in case the app contains
 * at least one web that needs to store technical analytics from app.
 */
class ComponentFacade {

    var liveData: MutableLiveData<String> = MutableLiveData()
    lateinit var gson: Gson

    /**
     *
     * @param args A ArrayList with liveData to Use in this component:
     *
     *   args[0] = params A JSON formatted [String] with four fields:
     *  - operation: "sendLog", "personalizedKey", "exception" or "userId".
     *  - logId: Type of Log
     *      - Log.Verbose: 2
     *      - Log.Debug: 3
     *      - Log.Info: 4
     *      - Log.Warn: 5
     *      - Log.Error: 6
     *      - Log.Assert: 7
     *  - Key: Key of Personalized key or Log Key
     *  - Value: Value of Personalized Key or Log Value
     *      - Value can be Any type of Primitive object in personalized key
     *      - Value only can be [String] in Log type
     *  - UserId: Crashlytics UserId
     *  - ExceptionMsg: Exception Message as String to set in Exception(message:String)
     *
     *   args[1] = context from application
     *   args[2] = activity from application
     *
     *  return a formated [String] parsed as JSON as livedata observed in viewmodel
     */

    fun startComponent(args: ArrayList<Any>){

        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
        var operation: String?

        val technicalAnalyticsParams = gson.fromJson(args[0] as String, TechnicalAnalyticsParams::class.java)

        operation = technicalAnalyticsParams?.operation?.toLowerCase().let {
            if (it != SENDLOG && it != PERSONALIZEDKEY && it != EXCEPTION && it != USERID)
                null
            else
                it
        }

        if (operation != null) {
            when (operation) {
                SENDLOG -> {
                    if (technicalAnalyticsParams.logId != null) {
                        technicalAnalyticsParams.key?.let {
                            GlobileAnalytics.sendLog(
                                technicalAnalyticsParams.logId,
                                it, technicalAnalyticsParams.value.toString()
                            )
                        }
                    } else {
                        GlobileAnalytics.sendLog(technicalAnalyticsParams.toString())
                    }
                }
                USERID -> {
                    technicalAnalyticsParams.userId?.let {
                        GlobileAnalytics.setUserIdentifier(it)
                    }
                }
                EXCEPTION -> {
                    technicalAnalyticsParams.exceptionMsg?.let {
                        GlobileAnalytics.sendLogException(Exception(it))
                    }
                }
                PERSONALIZEDKEY -> {
                    when (technicalAnalyticsParams.value?.javaClass?.name) {
                        String.javaClass.name ->
                            technicalAnalyticsParams.key?.let {
                                GlobileAnalytics.setPersonalizedStringKey(
                                    it,
                                    technicalAnalyticsParams.value as String
                                )
                            }
                        Boolean.javaClass.name ->
                            technicalAnalyticsParams.key?.let {
                                GlobileAnalytics.setPersonalizedBoolKey(
                                    it,
                                    technicalAnalyticsParams.value as Boolean
                                )
                            }
                        Double.javaClass.name ->
                            technicalAnalyticsParams.key?.let {
                                GlobileAnalytics.setPersonalizedDoubleKey(
                                    it,
                                    technicalAnalyticsParams.value as Double
                                )
                            }
                        Int.javaClass.name ->
                            technicalAnalyticsParams.key?.let {
                                GlobileAnalytics.setPersonalizedIntKey(it, technicalAnalyticsParams.value as Int)
                            }
                        Float.javaClass.name ->
                            technicalAnalyticsParams.key?.let {
                                GlobileAnalytics.setPersonalizedFloatKey(
                                    it,
                                    technicalAnalyticsParams.value as Float
                                )
                            }
                    }
                }
            }
        }
        liveData.postValue(gson.toJson(TechnicalAnalyticsResponse(true,operation)))
    }
}





