package com.santander.globile.uicomponents.cardview

import android.content.Context
import android.support.v7.widget.CardView
import android.util.AttributeSet


open class GlobileCardView @JvmOverloads constructor(
     context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
 ) :
     CardView(context, attrs, defStyleAttr)
