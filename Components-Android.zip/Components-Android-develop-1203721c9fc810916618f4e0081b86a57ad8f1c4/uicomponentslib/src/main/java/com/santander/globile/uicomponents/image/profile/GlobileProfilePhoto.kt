package com.santander.globile.uicomponents.image.profile

import android.content.Context
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import com.allenliu.badgeview.BadgeFactory
import com.allenliu.badgeview.BadgeView
import com.santander.globile.uicomponents.R
import kotlinx.android.synthetic.main.profile_photo_globile.view.*

class GlobileProfilePhoto @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : ConstraintLayout(context, attrs, defStyle) {

    var badgeText: String = ""
    var badgeShape: Int = BadgeView.SHAPE_CIRCLE
    var textSize: Float = 0F
    var badgeWidth: Float = 0F
    var badgeHeight: Float = 0F

    init {
        LayoutInflater.from(context).inflate(R.layout.profile_photo_globile, this)
    }


    /**
     * Method to set up the icon
     *
     * @param photo Int. The resource of the picture to be shown
     * @param badgeCount Int.
     */
    fun setProfilePhoto (photo: Int, badgeCount: Int? = null) {

        profile_image.setImageResource(photo)
        profile_initials.visibility = View.GONE

        badgeCount?.let {
            prepareBadge(it, profile_image)
        }
    }


    /**
     * Method to set up the initials in case there is no picture. In case more than 3 characters are sent,
     * only the first 3 of them will be shown
     *
     * @param initials String. The string with the initials
     * @param badgeCount Int.
     */
    fun setInitials(initials: String, badgeCount: Int? = null) {

        profile_image.visibility = View.GONE

        profile_initials.text = if (initials.length > 2) {
            initials.substring(0, 2).toUpperCase()
        } else {
            initials.toUpperCase()
        }

        badgeCount?.let {
            prepareBadge(it,profile_initials)
        }
    }

    fun setInitialsWithName (name: String, badgeCount: Int? = null) {

        profile_image.visibility = View.GONE

        val split = name.trimEnd().trimStart().split(" ")
        if (split[0].isNotBlank()) {

            var initials = ""
            when {
                split.size == 1 -> {
                    initials = split[0].first().toString()
                }
                split.size >= 2 -> {
                    initials = split[0].first().toString() + split[split.size-1].first()
                }
            }

            profile_initials.text = initials.toUpperCase()

            badgeCount?.let {
                prepareBadge(it,profile_initials)
            }
        }
    }

    private fun prepareBadge(badgeCount: Int, view: View) {
        when {
            badgeCount <= 0 -> {
                badgeShape = BadgeView.SHAPE_CIRCLE
                textSize = 0F
                badgeWidth = resources.getDimension(R.dimen.profile_badge_size_empty)
                badgeHeight = resources.getDimension(R.dimen.profile_badge_size_empty)
            }
            badgeCount in 1..9 -> {
                badgeText = badgeCount.toString()
                badgeShape = BadgeView.SHAPE_CIRCLE
                textSize = resources.getDimension(R.dimen.profile_badge_text_size)
                badgeWidth = resources.getDimension(R.dimen.profile_badge_height)
                badgeHeight = resources.getDimension(R.dimen.profile_badge_height)
            }
            badgeCount in 10..99 -> {
                badgeText = badgeCount.toString()
                badgeShape = BadgeView.SHAPTE_ROUND_RECTANGLE
                textSize = resources.getDimension(R.dimen.profile_badge_text_size)
                badgeWidth = resources.getDimension(R.dimen.profile_badge_width)
                badgeHeight = resources.getDimension(R.dimen.profile_badge_height)
            }
            badgeCount > 99 -> {
                badgeText = "99+"
                badgeShape = BadgeView.SHAPTE_ROUND_RECTANGLE
                textSize = resources.getDimension(R.dimen.profile_badge_text_size)
                badgeWidth = resources.getDimension(R.dimen.profile_badge_width)
                badgeHeight = resources.getDimension(R.dimen.profile_badge_height)
            }
        }
        createBadge (
            width = badgeWidth,
            height = badgeHeight,
            shape = badgeShape,
            badgeCount = badgeText,
            view = view,
            textSize = textSize)
    }


    private fun createBadge(
        textColor: Int = resources.getColor(R.color.white),
        badgeBackgroundColor: Int = resources.getColor(R.color.boston_red),
        width: Float,
        height: Float,
        textSize: Float,
        shape: Int,
        badgeCount: String,
        view: View) {

        BadgeFactory.create(context)
            .setTextColor(textColor)
            .setBadgeBackground(badgeBackgroundColor)
            .setWidthAndHeight(width.toInt(),height.toInt())
            .setTextSize(textSize.toInt())
            .setSpace(0F.toInt(),0F.toInt())
            .setShape(shape)
            .setBadgeGravity(Gravity.END or Gravity.TOP)
            .setBadgeCount(badgeCount)
            .bind(view)
    }
}

