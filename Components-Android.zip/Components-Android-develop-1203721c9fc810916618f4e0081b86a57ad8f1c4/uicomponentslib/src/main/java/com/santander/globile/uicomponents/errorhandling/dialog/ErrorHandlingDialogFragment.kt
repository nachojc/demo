package com.santander.globile.uicomponents.errorhandling.dialog

import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.support.v4.app.DialogFragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Button
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.errorhandling.common.*
import kotlinx.android.synthetic.main.dialog_fragment_error_handling.*


class ErrorHandlingDialogFragment : DialogFragment() {

    private var _onDismissListener: OnDismissListener? = null

    private var _onButtonPositive: OnClickListener? = null

    private var _onButtonNegative: OnClickListener? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val view = inflater.inflate(R.layout.dialog_fragment_error_handling, container, false)
        if (dialog != null && dialog.window != null) {
            dialog.window.requestFeature(Window.FEATURE_NO_TITLE)
            dialog.window.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        }
        return view

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        title.text = arguments?.getString(TITLE_TEXT)
        subTitle.text = arguments?.getString(SUBTITLE_TEXT)
        message.text = arguments?.getString(MESSAGE_TEXT)
        val positive = arguments?.getString(POSITIVE_BUTTON_MESSAGE_TEXT)
        val negative = arguments?.getString(NEGATIVE_BUTTON_MESSAGE_TEXT)

        showButton(positiveButton,positive,_onButtonPositive, BUTTON_POSITIVE_CODE)
        showButton(negativeButton,negative,_onButtonNegative, BUTTON_NEGATIVE_CODE)

        close.setOnClickListener {
            dismiss()
            _onDismissListener?.onDismiss()
        }
    }

    private fun showButton(view : Button, text: String?, listener: OnClickListener?,code: Int){
        if (!text.isNullOrBlank() && listener != null) {
            view.text = text
            view.setOnClickListener {
                dismiss()
                listener.onButtonClick(code)
            }
            view.visibility = View.VISIBLE
        } else {
            view.visibility = View.GONE
        }
    }

    private fun setOnDismissListener(onDismissListener: OnDismissListener) {
        _onDismissListener = onDismissListener
    }

    private fun setOnPositiveButtonListener(onButtonRightListener: OnClickListener) {
        _onButtonPositive = onButtonRightListener
    }

    private fun setOnNegativeButtonListener(onButtonLeftListener: OnClickListener) {
        _onButtonNegative = onButtonLeftListener
    }

    interface OnDismissListener {
        fun onDismiss()
    }

    interface OnClickListener {
        fun onButtonClick(code: Int)
    }

    /**
     *
     * Class to Build Error Handling Dialog Fragment with Parameters
     *
     * - title : Title of dialog
     * - subTitle : Subtitle of dialog
     * - message : Message of dialog
     * - buttonRightListener : Listener of button right
     * - buttonLeftListener :  Listener of button Left
     * - onDissmissListener : Listener of close button
     *
     */

    class Builder {

        private var titleText: String? = null
        private var subTitleText: String? = null
        private var messageText: String? = null
        private var positiveButtonText: String? = null
        private var negativeButtonText: String? = null
        private var onDismissListener: OnDismissListener? = null
        private var onPositiveButtonListener: OnClickListener? = null
        private var onNegativeButtonListener: OnClickListener? = null

        fun title(titleText: String): Builder {
            this.titleText = titleText
            return this
        }

        fun subTitle(subTitle: String): Builder {
            this.subTitleText = subTitle
            return this
        }

        fun message(message: String): Builder {
            this.messageText = message
            return this
        }

        fun addPositiveButton(text: String, onButtonListener: OnClickListener): Builder {
            this.positiveButtonText = text
            this.onPositiveButtonListener = onButtonListener
            return this
        }

        fun addNegativeButton(text: String, onButtonListener: OnClickListener): Builder {
            this.negativeButtonText = text
            this.onNegativeButtonListener = onButtonListener
            return this
        }

        fun onDismissListener(onDismissListener: OnDismissListener): Builder {
            this.onDismissListener = onDismissListener
            return this
        }


        fun build(): ErrorHandlingDialogFragment = ErrorHandlingDialogFragment().apply {
            onDismissListener?.let { setOnDismissListener(it) }
            onPositiveButtonListener?.let { setOnNegativeButtonListener(it) }
            onNegativeButtonListener?.let { setOnPositiveButtonListener(it) }
            arguments = Bundle().apply {
                titleText?.let {
                    putString(TITLE_TEXT, it)
                }
                subTitleText?.let {
                    putString(SUBTITLE_TEXT, it)
                }
                messageText?.let {
                    putString(MESSAGE_TEXT, it)
                }
                positiveButtonText?.let {
                    putString(POSITIVE_BUTTON_MESSAGE_TEXT, it)
                }
                negativeButtonText?.let {
                    putString(NEGATIVE_BUTTON_MESSAGE_TEXT, it)
                }
            }
        }
    }
}