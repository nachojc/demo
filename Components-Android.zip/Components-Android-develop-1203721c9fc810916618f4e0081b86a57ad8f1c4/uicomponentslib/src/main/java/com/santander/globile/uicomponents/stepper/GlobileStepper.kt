package com.santander.globile.uicomponents.stepper

import android.content.Context
import android.os.Build
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.ProgressBar
import com.santander.globile.uicomponents.R

class GlobileStepper @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : LinearLayout(context, attrs, defStyle) {

    private var mSeparatedLinesLayout: ConstraintLayout? = null
    private var mStepsList: ArrayList<ViewAndOnGoing> = arrayListOf()
    private var mProgressBar: ProgressBar? = null

    private var mNumberOfSteps = 5

    init {
        LayoutInflater.from(context)
            .inflate(R.layout.globile_stepper, this, true)

        mSeparatedLinesLayout = findViewById(R.id.separated_lines_stepper)
        mStepsList.add(ViewAndOnGoing(findViewById(R.id.step_0), 1))
        mStepsList.add(ViewAndOnGoing(findViewById(R.id.step_1), 2))
        mStepsList.add(ViewAndOnGoing(findViewById(R.id.step_2), 3))
        mStepsList.add(ViewAndOnGoing(findViewById(R.id.step_3), 4))
        mStepsList.add(ViewAndOnGoing(findViewById(R.id.step_4), 5))
        mProgressBar = findViewById(R.id.continuous_stepper)

        createCustomLayout(attrs)

    }

    private fun createCustomLayout(attrs: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GlobileStepper, 0, 0)
        val numberOfSteps = attributes.getInt(R.styleable.GlobileStepper_numberOfSteps, 0)

        mNumberOfSteps = numberOfSteps

        mSeparatedLinesLayout?.visibility = View.GONE
        mProgressBar?.visibility = View.GONE

        if (numberOfSteps > 5){
            mProgressBar?.visibility = View.VISIBLE
        } else {
            mSeparatedLinesLayout?.visibility = View.VISIBLE
            mStepsList.forEach {
                if (numberOfSteps < it.onGoing) it.view?.visibility = View.GONE
            }
        }
        setCurrentStep(1)
        attributes.recycle()
    }

    /**
     * Set on going step to show segments colors according to number of steps
     *
     * @param currentStep number of step, from 0 to size-1
     */
    fun setCurrentStep(currentStep: Int){
        if (mNumberOfSteps > 5){
            mProgressBar?.progress = ((currentStep.toFloat()/mNumberOfSteps.toFloat()) * 100).toInt()
        } else {
            mStepsList.forEach {
                val stepColor: StepColor = when {
                    currentStep == it.onGoing -> StepColor.ONGOING
                    currentStep < it.onGoing -> StepColor.NEXT
                    else -> StepColor.COMPLETED
                }
                it.view?.setStepBackground(stepColor)
            }
        }
    }

    private fun View.setStepBackground(stepColor: StepColor){
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            setBackgroundColor(context.resources.getColor(stepColor.color, null))
        } else {
            setBackgroundColor(context.resources.getColor(stepColor.color))
        }
    }

    private class ViewAndOnGoing (val view: View?, val onGoing: Int)

    private enum class StepColor (val color: Int){
        COMPLETED(R.color.completed_step),
        ONGOING(R.color.ongoing_step),
        NEXT(R.color.next_step)
    }

}