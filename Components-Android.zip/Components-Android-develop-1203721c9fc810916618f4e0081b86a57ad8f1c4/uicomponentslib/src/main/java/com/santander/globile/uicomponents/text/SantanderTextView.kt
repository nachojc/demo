package com.santander.globile.uicomponents.text

import android.content.Context
import android.os.Build
import android.util.AttributeSet
import com.santander.globile.uicomponents.R

/**
 * This custom TextView uses the font provided by Santander
 */
@SuppressWarnings("CustomViewStyleable, PrivateResource")
open class SantanderTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : android.support.v7.widget.AppCompatTextView(context, attrs, defStyleAttr) {
    init {
        if (Build.VERSION.SDK_INT < 23) {
            setTextAppearance(context, R.style.SantanderTextViewAppearance)
        }
        else {
            setTextAppearance(R.style.SantanderTextViewAppearance)
        }

    }

}