package com.santander.globile.uicomponents.alertbar

import android.app.Activity
import android.graphics.Typeface
import android.os.Build
import android.support.v4.app.Fragment
import android.support.v4.content.res.ResourcesCompat
import android.support.v7.widget.Toolbar
import android.text.Html
import android.text.TextUtils
import android.util.TypedValue
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.RelativeLayout
import android.widget.TextView
import com.androidadvance.topsnackbar.TSnackbar
import com.santander.globile.uicomponents.R
import kotlinx.android.synthetic.main.globile_alertbar_layout.view.*

/**
 * Show the GlobileAlertBar at top of the [Fragment]
 *
 * @param messageHTMLText [String] information to show to the user.
 * @param actionText [String] of the label at the right of the message where the user can click.
 * @param alertBarListener listener of user actions, can click on label (returns onActionPressed) or in close alertbar image (returns onDismissPressed)
 */
fun Fragment.showGlobileAlertBar(messageHTMLText: String, actionText: String, alertBarListener: GlobileAlertBarListener){

    val view = this.layoutInflater.inflate(R.layout.globile_alertbar_layout, null)

    (this.view?.parent as ViewGroup).addView(view)

    val snackbar = setSnackBarView(view, messageHTMLText, actionText, object : GlobileAlertBarListener{
        override fun onActionPressed() {
            alertBarListener.onActionPressed()
        }

        override fun onDismissPressed() {
            alertBarListener.onDismissPressed()
        }
    })

    // Show snackbar
    snackbar.show()

}

/**
 * Show the GlobileAlertBar at top of an [Activity] that have no toolbar
 *
 * @param messageHTMLText [String] information to show to the user.
 * @param actionText [String] of the label at the right of the message where the user can click.
 * @param alertBarListener listener of user actions, can click on label (returns onActionPressed) or in close alertbar image (returns onDismissPressed)
 */
fun Activity.showGlobileAlertBar(messageHTMLText: String, actionText: String, alertBarListener: GlobileAlertBarListener){

    val rootLayout = findViewById<FrameLayout>(android.R.id.content)
    val view = this.layoutInflater.inflate(R.layout.globile_alertbar_layout, null)

    val snackbar = setSnackBarView(view, messageHTMLText, actionText, object : GlobileAlertBarListener{
        override fun onActionPressed() {
            alertBarListener.onActionPressed()
        }

        override fun onDismissPressed() {
            alertBarListener.onDismissPressed()
        }
    })

    rootLayout.addView(view)

    // Show snackbar
    snackbar.show()

}

/**
 * Show the GlobileAlertBar in [Activity] below a custom toolbar
 *
 * @param toolbarId [Int] id resource of the custom toolbar in xml file
 * @param messageHTMLText [String] information to show to the user.
 * @param actionText [String] of the label at the right of the message where the user can click.
 * @param alertBarListener listener of user actions, can click on label (returns onActionPressed) or in close alertbar image (returns onDismissPressed)
 */
fun Activity.showGlobileAlertBar(toolbarId: Int, messageHTMLText: String, actionText: String, alertBarListener: GlobileAlertBarListener){

    val rootLayout = findViewById<FrameLayout>(android.R.id.content)
    val view = this.layoutInflater.inflate(R.layout.globile_alertbar_layout, (rootLayout.findViewById(toolbarId) as ViewGroup).parent as ViewGroup)

    val toolbar = rootLayout.findViewById<Toolbar>(toolbarId)

    val snackbar = setSnackBarView(view, messageHTMLText, actionText, object : GlobileAlertBarListener{
        override fun onActionPressed() {
            alertBarListener.onActionPressed()
        }

        override fun onDismissPressed() {
            alertBarListener.onDismissPressed()
        }
    })

    if (toolbar != null) {
        addTopMargin(snackbar, toolbar)
        toolbar.bringToFront()
    } else {
        rootLayout.addView(view)
    }

    // Show snackbar
    snackbar.show()

}

interface GlobileAlertBarListener {
    fun onActionPressed()
    fun onDismissPressed()
}

/**
 * Create and inflate the view with the designed alert bar
 */
private fun setSnackBarView(view: View, messageHTMLText: String, labelText: String, alertBarListener: GlobileAlertBarListener):TSnackbar{

    // Create snackbar associated to a view
    val snackbar = TSnackbar.make(
        view.coordinator_layout,
        "",
        TSnackbar.LENGTH_LONG
    )
    val snackbarView = snackbar.getView()
    snackbarView.background = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
        view.context!!.getDrawable(R.drawable.alertbar_background)
    } else {
        view.context!!.resources.getDrawable(R.drawable.alertbar_background)
    }

    // Main message text and params to adjust view
    val textView = snackbarView.findViewById(com.androidadvance.topsnackbar.R.id.snackbar_text) as TextView
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        textView.setTextColor(view.context!!.resources.getColor(R.color.alertbar_text, null))
    } else {
        textView.setTextColor(view.context!!.resources.getColor(R.color.alertbar_text))
    }

    val font = R.font.santander_text_regular
    val typeface = font.let {
        ResourcesCompat.getFont(view.context!!, it)
    } ?: run {
        ResourcesCompat.getFont(view.context!!, R.font.santander_text_regular)
    }
    textView.setTypeface(typeface, Typeface.NORMAL)
    textView.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13F)
    textView.maxLines = 2
    textView.ellipsize = TextUtils.TruncateAt.END

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
        textView.setText(Html.fromHtml(messageHTMLText, Html.FROM_HTML_MODE_LEGACY), TextView.BufferType.SPANNABLE)
    } else {
        textView.setText(Html.fromHtml(messageHTMLText), TextView.BufferType.SPANNABLE)
    }

    // Left icon params and listener
    val scale = view.context.getResources().getDisplayMetrics().density
    // convert the DP into pixel
    val iconPadding = (24 * scale + 0.5f).toInt()
    snackbar.setIconLeft(R.drawable.alertbar_cancel, 18F)
    snackbar.setIconPadding(iconPadding)

    // Textview image position and listener
    val textViewLeftPadding = (8 * scale + 0.5f).toInt()
    textView.setPadding(textViewLeftPadding,0,0,0)

    textView.setOnTouchListener(View.OnTouchListener { p0, event ->
        if(event?.action == MotionEvent.ACTION_DOWN) {
            if(event.rawX <= textView.getLeft() + textView.compoundDrawables[0].bounds.width() + iconPadding) {
                alertBarListener.onDismissPressed()
                snackbar.dismiss()
                return@OnTouchListener true
            }
        }
        false
    })

    // Right label
    snackbar.setAction(labelText) { alertBarListener.onActionPressed() }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        snackbar.setActionTextColor(view.context!!.resources.getColor(R.color.alertbar_label, null))
    } else {
        snackbar.setActionTextColor(view.context!!.resources.getColor(R.color.alertbar_label))
    }

    return snackbar
}

/*
 * Add margin at top of alerbar to appear below toolbar
 */
private fun addTopMargin(snackbar: TSnackbar, toolbar: Toolbar){

    val snackbarView = snackbar.getView()

    val params = RelativeLayout.LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT, RelativeLayout.LayoutParams.WRAP_CONTENT)
    params.topMargin = toolbar.height

    snackbarView.layoutParams = params

}