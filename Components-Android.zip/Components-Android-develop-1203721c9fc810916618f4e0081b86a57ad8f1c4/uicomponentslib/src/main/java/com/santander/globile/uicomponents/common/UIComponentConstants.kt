package com.santander.globile.uicomponents.common

class UIComponentConstants {
    companion object {
        const val INTERVAL_EXCEPTION_MESSAGE = "The slider's interval is not correct. The division between the maximum number and the interval must be zero."
    }
}