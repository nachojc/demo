package com.santander.globile.uicomponents.errorhandling.common

import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentTransaction
import com.santander.globile.uicomponents.errorhandling.dialog.ErrorHandlingDialogFragment


/**
 * Method to init SupportFragmentManager
 *
 * @param supportFragmentManager
 * @param dialogTag : TAG to launch dialogFragment
 *
 */
internal fun initSupportFragmentManager(
    supportFragmentManager: FragmentManager,
    dialogTag: String
): FragmentTransaction {
    val ft = supportFragmentManager.beginTransaction()
    val prev = supportFragmentManager.findFragmentByTag(dialogTag)
    if (prev != null) {
        ft.remove(prev)
    }
    ft.addToBackStack(null)
    return ft
}

/**
 * Show DialogFragment with callbacks.
 *
 * @param supportFragmentManager
 * @param dialogTag : TAG to launch dialogFragment
 * @param errorHandlingParams : Params to launch ErrorHandler
 * @param onPositiveButtonListener: Positive Button Listener
 * @param onNegativeButtonListener : Negative Button Listener
 * @param onButtonDismissListener: Close Button Listener
 *
 */

fun showErrorDialog(
    supportFragmentManager: FragmentManager,
    dialogTag: String = DIALOG_TAG,
    errorHandlingParams: ErrorHandlingParams,
    onPositiveButtonListener: ErrorHandlingDialogFragment.OnClickListener,
    onNegativeButtonListener: ErrorHandlingDialogFragment.OnClickListener,
    onButtonDismissListener: ErrorHandlingDialogFragment.OnDismissListener
) {

    val ft = initSupportFragmentManager(supportFragmentManager, dialogTag)
    ErrorHandlingDialogFragment.Builder()

        .addPositiveButton(errorHandlingParams.positiveButtonText ?: "",onPositiveButtonListener)
        .addNegativeButton(errorHandlingParams.negativeButtonText?: "",onNegativeButtonListener)
        .message(errorHandlingParams.message ?: "")
        .title(errorHandlingParams.title ?: "")
        .subTitle(errorHandlingParams.subtitle ?: "")
        .onDismissListener(onButtonDismissListener)
        .build().show(ft, dialogTag)
}