package com.santander.globile.uicomponents.list.simple.data

data class SimpleData(var key:String, var value:String)