package com.santander.globile.uicomponents.errorhandling.common

const val TITLE_TEXT = "title"
const val SUBTITLE_TEXT = "subtitle"
const val MESSAGE_TEXT = "message"
const val POSITIVE_BUTTON_MESSAGE_TEXT = "positive_button_text"
const val NEGATIVE_BUTTON_MESSAGE_TEXT = "negative_button_text"
const val BUTTON_POSITIVE_CODE = 1
const val BUTTON_NEGATIVE_CODE = 2
const val BUTTON_DISMISS_CODE = 3
const val DIALOG_TAG = "dialog"