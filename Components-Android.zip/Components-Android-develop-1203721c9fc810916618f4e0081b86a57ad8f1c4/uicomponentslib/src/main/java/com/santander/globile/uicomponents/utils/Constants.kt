package com.santander.globile.uicomponents.utils

class ComponentConstants {
    companion object {
        const val RED_TOOLBAR_STYLE = 1
        const val WHITE_TOOLBAR_STYLE = 2
        const val POSITION_LEFT = 0
        const val POSITION_TOP = 1
        const val POSITION_RIGHT = 2
        const val POSITION_BOTTOM = 3
        const val POSITION_CENTER = 4

        const val COLOR_SANTANDER_RED = 0
        const val COLOR_SANTANDER_TURQUOSE = 1
    }


}