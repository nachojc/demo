package com.santander.globile.uicomponents.tablayout.data


/**
 * Data model to use GlobileBaseFragmentTabsAdapter and GlobileTab
 *
 * @property tabs : Array of [GlobileTab]
 */
data class GlobileTabsAdapterData(val tabs: ArrayList<GlobileTab>)