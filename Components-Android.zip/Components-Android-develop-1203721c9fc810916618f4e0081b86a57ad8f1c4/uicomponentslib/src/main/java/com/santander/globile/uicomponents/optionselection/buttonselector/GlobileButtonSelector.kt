package com.santander.globile.uicomponents.optionselection.buttonselector

import android.content.Context
import android.support.v7.widget.AppCompatButton
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.common.GlobileButtonSelectorPosition
import kotlinx.android.synthetic.main.globile_button_selector.view.*

class GlobileButtonSelector @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    var buttonLeft : AppCompatButton
    var buttonCenter: AppCompatButton
    var buttonRight: AppCompatButton
    var globileButtonSelectorListener: GlobileButtonSelectorListener? = null

    private var lineLeft: View
    private var lineright: View
    private var buttonType: Int = 0
    private var defaultSelection: Int = 0
    private var buttonRightText: String? = null
    private var buttonCenterText: String? = null
    private var buttonLeftText: String? = null


    init {
        LayoutInflater.from(context)
            .inflate(R.layout.globile_button_selector, this, true)

        buttonLeft = globile_button_selector_left
        buttonCenter = globile_button_selector_center
        buttonRight = globile_button_selector_right
        lineLeft = selector_line_left
        lineright = selector_line_right
        createCustomLayout(attrs)

        buttonLeft.setOnClickListener{view->
           buttonLeftClick(view)
        }
        buttonCenter.setOnClickListener { view ->
            buttonCenterClick(view)
        }
        buttonRight.setOnClickListener {view ->
            buttonRightClick(view)
        }
    }

    /**
     * Create Layout with custom attributes
     *
     * @param attrs
     */
    private fun createCustomLayout(attrs: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GlobileButtonSelector, 0, 0)
        buttonType = attributes.getInt(R.styleable.GlobileButtonSelector_optionsCount,0)
        defaultSelection = attributes.getInt(R.styleable.GlobileButtonSelector_defaultSelector,0)
        buttonRightText = attributes.getString(R.styleable.GlobileButtonSelector_buttonRightText)
        buttonCenterText = attributes.getString(R.styleable.GlobileButtonSelector_buttonCenterText)
        buttonLeftText = attributes.getString(R.styleable.GlobileButtonSelector_buttonLeftText)

        buttonRightText?.let {
            buttonRight.text = it
        }
        buttonCenterText?.let {
            buttonCenter.text = it
        }
        buttonLeftText?.let {
            buttonLeft.text = it
        }
        if(buttonType>0){
            buttonCenter.visibility = View.VISIBLE
        }else{
            buttonCenter.visibility = View.GONE
        }

        when(defaultSelection){
            0 -> buttonLeftClick(buttonLeft)
            1 -> buttonCenterClick(buttonCenter)
            2 -> buttonRightClick(buttonRight)
        }


        attributes.recycle()
    }


    /**
     * Button left click configuration
     *
     * @param v: AppCompactButton view
     */
    private fun buttonLeftClick(v: View){
        buttonLeft.isSelected = true
        buttonCenter.isSelected = false
        buttonRight.isSelected = false
        lineLeft.visibility = View.GONE
        lineright.visibility = View.VISIBLE
        globileButtonSelectorListener?.onSelection(GlobileButtonSelectorPosition.LEFT,v)
    }


    /**
     * Button center click configuration
     *
     * @param v: AppCompactButton view
     */
    private fun buttonCenterClick(v: View){
        buttonLeft.isSelected = false
        buttonCenter.isSelected = true
        buttonRight.isSelected = false
        lineLeft.visibility = View.GONE
        lineright.visibility = View.GONE
        globileButtonSelectorListener?.onSelection(GlobileButtonSelectorPosition.CENTER,v)
    }

    /**
     * Button right click configuration
     *
     * @param v: AppCompactButton view
     */
    private fun buttonRightClick(v:View){
        if(buttonType>0){
            buttonCenter.isSelected = false
            lineLeft.visibility = View.VISIBLE
        }else{
            buttonRight.isSelected = true
            lineLeft.visibility = View.GONE
        }
        lineright.visibility = View.GONE
        buttonRight.isSelected = true
        buttonLeft.isSelected = false
        globileButtonSelectorListener?.onSelection(GlobileButtonSelectorPosition.RIGHT,v)
    }

    /**
     * Basic interface to handle on selection listener.
     */
    interface GlobileButtonSelectorListener {
        fun onSelection(code: GlobileButtonSelectorPosition, appCompatButton: View)
    }

}