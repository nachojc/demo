package com.santander.globile.uicomponents.cardview

import android.content.Context
import android.support.v4.content.ContextCompat
import android.util.AttributeSet
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.list.common.recycler.GlobileRecyclerView

class GlobileCardListView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : GlobileCardView(context, attrs,defStyleAttr) {
    override fun onFinishInflate() {
        super.onFinishInflate()

        val view = getChildAt(0)
        if(view is GlobileRecyclerView) {
            view.apply {
                background = ContextCompat.getDrawable(context, R.drawable.border_cardview)
                isNestedScrollingEnabled = false
            }
        }

    }
}