package com.santander.globile.uicomponents.tablayout

import android.content.Context
import android.graphics.Typeface
import android.support.constraint.ConstraintLayout
import android.support.design.widget.TabLayout
import android.support.v4.view.ViewPager
import android.support.v7.widget.AppCompatTextView
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.tablayout.data.GlobileTabsAdapterData
import com.santander.globile.uicomponents.utils.tintDrawable
import kotlinx.android.synthetic.main.globile_custom_tab.view.*


class GlobileTabLayout @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : TabLayout(context, attrs, defStyleAttr) {

    private var viewPager: ViewPager? = null

    init {
        addOnTabSelectedListener(object : OnTabSelectedListener {
            override fun onTabSelected(tab: Tab) {
                val textView = tab.customView?.findViewById<AppCompatTextView>(R.id.globileCustomTabText)
                val image = tab.customView?.findViewById<ImageView>(R.id.tabIcon)
                textView?.setTypeface(null, Typeface.BOLD)
                image?.tabIcon?.tintDrawable(R.color.santander_red)
            }

            override fun onTabUnselected(tab: Tab) {
                val textView = tab.customView?.globileCustomTabText
                val image = tab.customView?.findViewById<ImageView>(R.id.tabIcon)
                textView?.setTypeface(null, Typeface.NORMAL)
                image?.tabIcon?.tintDrawable(R.color.medium_grey)
            }

            override fun onTabReselected(tab: Tab) {
            }
        })
    }

    override fun onAttachedToWindow() {
        if (viewPager == null) {
            if (parent is ViewPager) viewPager = parent as ViewPager
        }
        super.onAttachedToWindow()
    }

    override fun setupWithViewPager(viewPager: ViewPager?, autoRefresh: Boolean) {
        this.viewPager = viewPager
        try {
            val adapter = viewPager?.adapter as GlobileBaseFragmentTabsAdapter
            super.setupWithViewPager(viewPager, autoRefresh)
            addCustomView(adapter.globileTabsAdapterData)
        }catch (e: Exception){
            Log.e("ClassCastException","Adapter in ViewPager must be GlobileBaseFragmentTabsAdapter")
        }
    }

    /**
     * Method to add custom view tabs with badges
     *
     * @param globileTabsAdapterData: Data model to use custom view tabs
     */

    private fun addCustomView(globileTabsAdapterData: GlobileTabsAdapterData) {
        globileTabsAdapterData.tabs.forEachIndexed { index, tab ->
            val customTab = LayoutInflater.from(context).inflate(R.layout.globile_custom_tab, null) as ConstraintLayout

            if (tab.iconId != null && tab.iconId != 0) {
                tab.iconId.let {
                    customTab.tabIcon.setImageResource(it)
                }
                if (index == 0) {
                    customTab.tabIcon.tintDrawable(R.color.santander_red)
                    customTab.globileCustomTabText?.setTypeface(null, Typeface.BOLD)
                } else {
                    customTab.tabIcon.tintDrawable(R.color.medium_grey)
                    customTab.globileCustomTabText?.setTypeface(null, Typeface.NORMAL)
                }
                customTab.globileCustomTabText.maxLines = 1
                customTab.globileCustomTabText.setLines(1)
            } else {
                customTab.tabIcon.visibility = View.GONE
                customTab.globileCustomTabText.maxLines = 2
                customTab.globileCustomTabText.setLines(2)
            }
            customTab.globileCustomTabText.text = context.getString(tab.titleId)
            if (index == globileTabsAdapterData.tabs.size - 1) {
                customTab.tablayout_divider.visibility = View.GONE
            }
            this.getTabAt(index)?.customView = customTab
        }
    }


}