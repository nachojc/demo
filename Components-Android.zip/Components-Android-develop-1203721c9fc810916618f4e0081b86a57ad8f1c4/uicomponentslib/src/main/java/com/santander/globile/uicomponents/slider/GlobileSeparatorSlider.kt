package com.santander.globile.uicomponents.slider

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.common.UIComponentConstants.Companion.INTERVAL_EXCEPTION_MESSAGE
import com.santander.globile.uicomponents.text.SantanderTextView
import com.santander.globile.uicomponents.utils.ComponentConstants
import io.apptik.widget.MultiSlider
import java.util.concurrent.atomic.AtomicInteger


class GlobileSeparatorSlider @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private var relativeLayout: RelativeLayout? = null
    private var WidthMeasureSpec = 0
    private var HeightMeasureSpec = 0
    private var isAlignmentResetOnLayoutChange: Boolean = false
    private var defaultColor: Int? = null
    private var type: Int? = null

    private var min_number: Int = 0
    private var max_number: Int = 0
    private var interval: Int = 1
    private var data: List<Int>? = null
    private var showSeparator: Boolean = false

    private var intervals: RelativeLayout? = null
    private var seekbarCountInit: SantanderTextView? = null
    private var seekbarCountEnd: SantanderTextView? = null
    private var seekbar_range: MultiSlider? = null
    private var listener: GlobileSliderListener? = null

    /**
     * Add GlobileSliderListener to slider.
     */
    var globileSliderListener: GlobileSliderListener? = null
        set(value) {
            listener = value
        }

    /**
     * Enable separator lines below slider.
     */
    var enableSeparator: Boolean = false
        set(value) {
            showSeparator = value
            intervals?.visibility = if (value) {
                View.VISIBLE
            } else {
                View.GONE
            }
        }

    /**
     * Set minimum value text in slider.
     */
    var minText: String? = null
        set(value) {
            seekbarCountInit?.text = value
        }


    /**
     * Set maximum value text in slider.
     */
    var maxText: String? = null
        set(value) {
            seekbarCountEnd?.text = value
        }

    init {
        createInitAttributes(attrs)
        val inflater = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        if (defaultColor == ComponentConstants.COLOR_SANTANDER_RED) {
            if (type == 0) {
                inflater.inflate(R.layout.seekbar_with_intervals_red, this)
            } else {
                inflater.inflate(R.layout.seekbar_range_with_intervals_red, this)
            }
        } else {
            if (type == 0) {
                inflater.inflate(R.layout.seekbar_with_intervals_turquose, this)
            } else {
                inflater.inflate(R.layout.seekbar_range_with_intervals_turquose, this)
            }
        }

        val _interval = findViewById<RelativeLayout>(R.id.intervals)
        val _seekbarCountInit = findViewById<SantanderTextView>(R.id.seekbarCountInit)
        val _seekbarCountEnd = findViewById<SantanderTextView>(R.id.seekbarCountEnd)
        val _seekbar_range = findViewById<MultiSlider>(R.id.seekbar_range)
        _seekbar_range.setOnThumbValueChangeListener { _, _, thumbIndex, value ->
            getValue(value)?.let {
                listener?.onSelectionListener(thumbIndex,it)
            }
        }
        this.seekbar_range = _seekbar_range
        this.intervals = _interval
        this.seekbarCountInit = _seekbarCountInit
        this.seekbarCountEnd = _seekbarCountEnd
        createCustomLayout(attrs)
    }

    private fun createCustomLayout(attrs: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GlobileSeparatorSlider, 0, 0)
        enableSeparator = attributes.getBoolean(R.styleable.GlobileSeparatorSlider_enable_separator, false)
        min_number = attributes.getInt(R.styleable.GlobileSeparatorSlider_min_number, 0)
        max_number = attributes.getInt(R.styleable.GlobileSeparatorSlider_max_number, 0)
        interval = attributes.getInt(R.styleable.GlobileSeparatorSlider_interval, 1)
        minText = attributes.getString(R.styleable.GlobileSeparatorSlider_min_text)
        maxText = attributes.getString(R.styleable.GlobileSeparatorSlider_max_text)

        if (isDivisible(max_number, interval)) {
            setData(min_number, max_number, interval)
        } else {
            throw Exception(INTERVAL_EXCEPTION_MESSAGE)
        }
        attributes.recycle()
    }

    private fun createInitAttributes(attrs: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GlobileSeparatorSlider, 0, 0)
        defaultColor = attributes.getInt(R.styleable.GlobileSeparatorSlider_default_color, 0)
        type = attributes.getInt(R.styleable.GlobileSeparatorSlider_slider_type, 0)
        attributes.recycle()
    }


    /**
     * Get Slider Values in hashmap
     * @return [SliderData]
     */
    fun getSliderValues(): SliderData {
        val map = HashMap<Int, Int?>()
        seekbar_range?.let {
            map[0] = getValue(it.getThumb(0).value)
            if (type != 0) {
                map[1] = getValue(it.getThumb(1).value)
            }
        }
        return SliderData(map)
    }

    /**
     * Get value by position
     *
     * @param index : position of interval.
     */
    fun getValue(index: Int): Int? = data?.let {
        it[index]
    }

    /**
     * Set Data to init slider
     *
     * @param min : minimum value in slider
     * @param max : maximum value in slider
     * @param interval : interval to divide values in slider.
     */
    fun setData(min: Int, max: Int, interval: Int) {
        val data = getIntervals(min, max, interval)
        this.data = data
        if (showSeparator) {
            displayIntervals(data)
        }
        seekbar_range?.max = data.size - 1
    }


    /**
     * Check if values is divisible with rest zero. If not will throw an exception.
     *
     * @param max
     * @param interval
     */
    private fun isDivisible(max: Int, interval: Int): Boolean = (max % interval) == 0


    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        super.onLayout(changed, l, t, r, b)

        if (changed && showSeparator) {
            if (!isAlignmentResetOnLayoutChange) {
                alignIntervals()
                // We've changed the intervals layout, we need to refresh.
                relativeLayout?.let {
                    it.measure(WidthMeasureSpec, HeightMeasureSpec)
                    it.layout(
                        it.left,
                        it.top,
                        it.right,
                        it.bottom
                    )
                }
            }
        }
    }

    private fun alignIntervals() {

        if (seekbar_range != null) {
            val widthOfSeekbarThumb = getSeekbarThumbWidth()
            val thumbOffset = widthOfSeekbarThumb / 2

            val widthOfSeekbar = seekbar_range?.width
            val firstIntervalWidth = getRelativeLayout()?.getChildAt(0)?.width
            val remainingPaddableWidth = firstIntervalWidth?.let {
                widthOfSeekbar?.let {
                    widthOfSeekbar - firstIntervalWidth - widthOfSeekbarThumb
                }
            }


            val numberOfIntervals = seekbar_range?.max
            val maximumWidthOfEachInterval = numberOfIntervals?.let {
                remainingPaddableWidth?.div(it)
            }

            alignFirstInterval(thumbOffset)
            maximumWidthOfEachInterval?.let {
                alignIntervalsInBetween(maximumWidthOfEachInterval)
                alignLastInterval(thumbOffset, maximumWidthOfEachInterval)
            }
            isAlignmentResetOnLayoutChange = true
        }
    }

    private fun getSeekbarThumbWidth(): Int {
        return resources.getDimensionPixelOffset(R.dimen.seekbar_thumb_width)
    }

    private fun alignFirstInterval(offset: Int) {
        val firstInterval = getRelativeLayout()?.getChildAt(0) as TextView
        firstInterval.setPadding(offset, 0, 0, 0)
    }

    private fun alignIntervalsInBetween(maximumWidthOfEachInterval: Int) {
        var widthOfPreviousIntervalsText = 0

        // Don't align the first or last interval.
        val childCount = getRelativeLayout()?.childCount
        childCount?.let {
            for (index in 1 until it - 1) {
                val textViewInterval = getRelativeLayout()?.getChildAt(index) as SantanderTextView
                val widthOfText = textViewInterval.width

                // This works out how much left padding is needed to center the current interval.
                val leftPadding =
                    Math.round((maximumWidthOfEachInterval - widthOfText / 2 - widthOfPreviousIntervalsText / 2).toFloat())
                textViewInterval.setPadding(leftPadding, 0, 0, 0)

                widthOfPreviousIntervalsText = widthOfText
            }
        }
    }

    private fun alignLastInterval(offset: Int, maximumWidthOfEachInterval: Int) {
        val lastIndex = getRelativeLayout()?.childCount!! - 1

        val lastInterval = getRelativeLayout()?.getChildAt(lastIndex) as SantanderTextView
        val widthOfText = lastInterval.width

        val leftPadding = Math.round((maximumWidthOfEachInterval - widthOfText).toFloat())
        lastInterval.setPadding(leftPadding, 0, 0, 0)
    }

    @Synchronized
    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        WidthMeasureSpec = widthMeasureSpec
        HeightMeasureSpec = heightMeasureSpec

        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
    }

    private fun displayIntervals(list: List<Int>) {
        var idOfPreviousInterval = 0

        if (getRelativeLayout()?.childCount == 0) {
            for (interval in list) {
                val textViewInterval = createInterval()
                alignTextViewToRightOfPreviousInterval(textViewInterval, idOfPreviousInterval)

                idOfPreviousInterval = textViewInterval.id

                getRelativeLayout()?.addView(textViewInterval)
            }
        }
    }

    private fun createInterval(): TextView {
        val textBoxView = LayoutInflater.from(context)
            .inflate(R.layout.seekbar_with_intervals_labels, null) as View

        val textView = textBoxView
            .findViewById(R.id.textViewInterval) as SantanderTextView

        textBoxView.id = generateViewId()
        return textView
    }

    private val sNextGeneratedId = AtomicInteger(1)

    /**
     * Generate a value suitable for use in [.setId].
     * This value will not collide with ID values generated at build time by aapt for R.id.
     *
     * @return a generated ID value
     */
    private fun generateViewIdentifier(): Int {
        while (true) {
            val result = sNextGeneratedId.get()
            // aapt-generated IDs have the high byte nonzero; clamp to the range under that.
            var newValue = result + 1
            if (newValue > 0x00FFFFFF) newValue = 1 // Roll over to 1, not 0.
            if (sNextGeneratedId.compareAndSet(result, newValue)) {
                return result
            }
        }
    }

    private fun setAlignmentResetOnLayoutChange() {
        alignIntervals()

        // We've changed the intervals layout, we need to refresh.
        relativeLayout?.let {
            it.measure(WidthMeasureSpec, HeightMeasureSpec)
            it.layout(
                it.left,
                it.top,
                it.right,
                it.bottom
            )
        }

    }

    private fun alignTextViewToRightOfPreviousInterval(textView: TextView, idOfPreviousInterval: Int) {
        val params =
            RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)

        if (idOfPreviousInterval > 0) {
            params.addRule(RelativeLayout.RIGHT_OF, idOfPreviousInterval)
        }

        textView.layoutParams = params
    }

    private fun getIntervals(min: Int, max: Int, interval: Int): List<Int> {
        return object : ArrayList<Int>() {
            init {
                var min = min
                var max = max
                while (min <= max) {
                    add(min)
                    min += interval
                }

            }
        }
    }



    private fun getRelativeLayout(): RelativeLayout? {
        if (relativeLayout == null) {
            relativeLayout = findViewById<RelativeLayout>(R.id.intervals)
        }
        return relativeLayout
    }
}