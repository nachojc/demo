package com.santander.globile.uicomponents.buttons.tertiarybutton

import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Build
import android.support.v4.content.ContextCompat
import android.text.SpannableString
import android.text.style.UnderlineSpan
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.widget.FrameLayout
import com.santander.globile.uicomponents.R
import kotlinx.android.synthetic.main.tertiary_button.view.*


/**
 * Custom button that shows a button with the tertiary design of the Santander with an icon or arrow with text or linked text.
 *
 * @param context
 * @param attrs
 * @param defStyleAttr
 *
 * attrs defined at xml file when add this component in a layout using XML Namespace Prefix "app" with this attributes:
 * - app:tertiaryButtonText : Set button text [String].
 * - app:tertiaryPrimaryColor : Set text and icon color, [Boolean] true=SantanderColor, false=turquoise.
 * - app:tertiaryImageResource : Set icon resource with 24dp max height, optional.
 * - app:tertiaryShowArrow : Show arrow after text [Boolean].
 * - app:tertiaryIsLink : Underline text [Boolean].
 */

class TertiaryButton @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : FrameLayout(context, attrs, defStyleAttr) {

    private val mContext = context
    private var mButtonText = ""
    private var mButtonSecondText = ""
    private var mPrimaryColor = true
    private var mImageResource: Drawable?
    private var mShowArrow = false
    private var mIsLink = false
    private var mShowSecondText = false

    init {

        LayoutInflater.from(mContext)
            .inflate(R.layout.tertiary_button, this, true)

        val typedArray = mContext.obtainStyledAttributes(attrs, R.styleable.TertiaryButton)
        mButtonText = typedArray.getString(R.styleable.TertiaryButton_tertiaryButtonText)?:""
        mButtonSecondText = typedArray.getString(R.styleable.TertiaryButton_tertiaryButtonSecondText)?:""
        mPrimaryColor = typedArray.getBoolean(R.styleable.TertiaryButton_tertiaryPrimaryColor, true)
        mImageResource = typedArray.getDrawable(R.styleable.TertiaryButton_tertiaryImageResource)
        mShowArrow = typedArray.getBoolean(R.styleable.TertiaryButton_tertiaryShowArrow, false)
        mIsLink = typedArray.getBoolean(R.styleable.TertiaryButton_tertiaryIsLink, false)
        setViews()

        typedArray.recycle()
    }

    private fun setViews(){

        tertiary_button_second_textview.visibility = View.VISIBLE

        // Set textView font, size and text
        with(tertiary_button_textview){
            val textColor = if (mPrimaryColor) R.color.tertiary_button_primary else R.color.tertiary_button_secondary
            if (Build.VERSION.SDK_INT < 23) {
                setTextAppearance(context, R.style.GlobileTertiaryButtonStyleTextAppearance)
            }
            else {
                setTextAppearance(R.style.GlobileTertiaryButtonStyleTextAppearance)
            }
            setTextColor(ContextCompat.getColor(mContext, textColor))
            if (mIsLink) {
                val mySpannableString = SpannableString(mButtonText)
                mySpannableString.setSpan(UnderlineSpan(), 0, mySpannableString.length, 0)
                text = mySpannableString
                mShowSecondText = mButtonSecondText != ""
            } else {
                text = mButtonText
            }
        }

        with(tertiary_button_second_textview) {
            if (Build.VERSION.SDK_INT < 23) {
                setTextAppearance(context, R.style.GlobileTertiaryButtonStyleTextAppearance)
            }
            else {
                setTextAppearance(R.style.GlobileTertiaryButtonStyleTextAppearance)
            }
            text = " $mButtonSecondText"
            visibility = if (mShowSecondText) {
                View.VISIBLE
            } else {
                View.GONE
            }
        }

        // Set left image if is defined
        with(tertiary_button_letf_imageview){
            visibility = if (mImageResource != null) {
                setImageDrawable(mImageResource)
                View.VISIBLE
            } else View.GONE
        }

        // Set arrow after text with defined color
        with(tertiary_button_right_imageview){
            visibility = if (mShowArrow){
                val arrowImage = if (mPrimaryColor) R.drawable.chevron_right_red else R.drawable.chevron_right_turquoise
                setImageDrawable(ContextCompat.getDrawable(mContext, arrowImage))
                View.VISIBLE
            } else View.GONE
        }

    }

    fun setLinkOnClickListener (listener: OnClickListener) {
        if (mIsLink) {
            tertiary_button_textview.setOnClickListener {
                listener.onClick(tertiary_button_textview)
            }
        }
    }

}