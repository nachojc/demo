package com.santander.globile.uicomponents.list.common.adapter

import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener

/**
 * Interface to bind data in viewholder.
 *
 * @param T Generic any type of data.
 */
interface GlobileGenericBinder<T> {
    /**
     * Function to bind data in viewholder
     *
     * @param data : Generic Any type of data declared in interface
     * @param listener : Onclick listener with Any tye of data declared in interface
     */
    fun bind(data: T,listener: GlobileRecyclerListener<T>?)
}