package com.santander.globile.uicomponents.common

import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.COLOR_SANTANDER_RED
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.COLOR_SANTANDER_TURQUOSE
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_BOTTOM
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_CENTER
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_LEFT
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_RIGHT
import com.santander.globile.uicomponents.utils.ComponentConstants.Companion.POSITION_TOP

enum class GlobileIconPosition(val position: Int) {
    LEFT(POSITION_LEFT),
    TOP(POSITION_TOP),
    RIGHT(POSITION_RIGHT),
    BOTTOM(POSITION_BOTTOM)
}

enum class GlobileButtonSelectorPosition(val position: Int){
    LEFT(POSITION_LEFT),
    CENTER(POSITION_CENTER),
    RIGHT(POSITION_RIGHT)
}

enum class GlobileDefaultColorComponents(val color: Int){
    RED(COLOR_SANTANDER_RED),
    TURQUOSE(COLOR_SANTANDER_TURQUOSE)
}