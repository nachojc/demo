package com.santander.globile.uicomponents.utils

import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.drawable.Drawable
import android.os.Build
import android.support.v7.widget.AppCompatTextView

fun AppCompatTextView.tintDrawable(color: Int) {
    this.compoundDrawables.let { compoundDrawables ->
        for (drawable: Drawable in compoundDrawables) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                drawable.colorFilter =
                    PorterDuffColorFilter(context.resources.getColor(color, null), PorterDuff.Mode.SRC_IN)
            }else{
                drawable.colorFilter =
                    PorterDuffColorFilter(context.resources.getColor(color), PorterDuff.Mode.SRC_IN)
            }
        }
    }
}