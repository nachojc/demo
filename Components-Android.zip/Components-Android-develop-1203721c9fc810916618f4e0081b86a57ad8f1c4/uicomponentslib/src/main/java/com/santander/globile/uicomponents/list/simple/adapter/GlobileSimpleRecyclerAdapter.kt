package com.santander.globile.uicomponents.list.simple.adapter

import android.support.v7.widget.RecyclerView
import android.view.View
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericRecyclerAdapter
import com.santander.globile.uicomponents.list.simple.data.SimpleData
import com.santander.globile.uicomponents.list.simple.viewholder.GlobileSimpleViewHolder

class GlobileSimpleRecyclerAdapter(data: List<SimpleData>): GlobileGenericRecyclerAdapter<SimpleData>(data) {
    override fun getLayoutId(position: Int, obj: SimpleData): Int {
        return R.layout.globile_simple_row
    }

    override fun getViewHolder(view: View, viewType: Int): RecyclerView.ViewHolder {
        return GlobileSimpleViewHolder(view)
    }
}