package com.santander.globile.uicomponents.buttons.endingbutton

import android.content.Context
import android.os.Build
import android.support.v7.widget.AppCompatButton
import android.util.AttributeSet
import android.view.Gravity
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.utils.toDP


@Suppress("DEPRECATION")
class EndingButton @JvmOverloads constructor(context: Context, attrs: AttributeSet?, defStyleAttr: Int = 0):
        AppCompatButton (context, attrs, defStyleAttr) {

    init {

        val typedArray = getContext().obtainStyledAttributes(attrs, R.styleable.EndingButton)
        val buttonType = typedArray.getInt(R.styleable.EndingButton_buttonType, 0)

        when (buttonType) {
            0 -> {
                setPrimaryButton()
            }
            1 -> {
                setSecondaryButton()
            }
        }

        typedArray.recycle()

        when(isEnabled) {
            false -> setDisabledButton()
        }

        val padding_in_dp_top_bottom = 8
        val padding_in_dp_right_left = 12
        setPadding(padding_in_dp_right_left.toDP,padding_in_dp_top_bottom.toDP,padding_in_dp_right_left.toDP,padding_in_dp_top_bottom.toDP)
        minHeight = 32.toDP
        compoundDrawablePadding = 15.toDP
        setGravity()

    }

    fun setPrimaryButton() {
        if (Build.VERSION.SDK_INT < 23) {
            setTextAppearance(context, R.style.GlobileEndingButtonPrimaryStyleTextAppearance)
        }
        else {
            setTextAppearance(R.style.GlobileEndingButtonPrimaryStyleTextAppearance)
        }
        setBackgroundResource(R.drawable.ending_button_primary)
    }

    fun setSecondaryButton() {
        if (Build.VERSION.SDK_INT < 23) {
            setTextAppearance(context, R.style.GlobileEndingButtonSecondaryStyleTextAppearance)
        }
        else {
            setTextAppearance(R.style.GlobileEndingButtonSecondaryStyleTextAppearance)
        }
        setBackgroundResource(R.drawable.ending_button_secondary)
    }

    fun setDisabledButton() {

        if (Build.VERSION.SDK_INT < 23) {
            setTextAppearance(context, R.style.GlobileEndingButtonDisabledStyleTextAppearance)
        }
        else {
            setTextAppearance(R.style.GlobileEndingButtonDisabledStyleTextAppearance)
        }
    }

    private fun setGravity() {
        gravity = Gravity.CENTER
    }

}
