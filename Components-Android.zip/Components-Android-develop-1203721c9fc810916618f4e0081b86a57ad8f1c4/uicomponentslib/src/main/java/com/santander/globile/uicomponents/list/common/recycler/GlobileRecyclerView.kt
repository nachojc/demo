package com.santander.globile.uicomponents.list.common.recycler

import android.content.Context
import android.os.Build
import android.support.v7.widget.RecyclerView
import android.util.AttributeSet
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.list.common.decoration.GlobileSeparationDecorator


class GlobileRecyclerView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : RecyclerView(context, attrs, defStyleAttr) {
    init {
        addDecoration(R.color.light_grey)
    }

    /**
     * Method to add Separator with color in RecyclerView
     *
     * @param color: Separator color
     */

    fun addDecoration(color: Int){
        val decorator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            context?.getColor(color)?.let { GlobileSeparationDecorator(context, it, 1f) }
        } else {
            context?.resources?.getColor(color)?.let { GlobileSeparationDecorator(context, it, 1f) }
        }
        decorator?.let {
            this.addItemDecoration(it)
        }
    }

    /**
     * Method to remove separators in RecyclerView
     */

    fun removeDecoration(){
        val itemDecoration: ItemDecoration? = getItemDecorationAt(0).let { it }
        while ((itemDecorationCount > 0)) {
            itemDecoration?.let { removeItemDecoration(it) }
        }
    }

}