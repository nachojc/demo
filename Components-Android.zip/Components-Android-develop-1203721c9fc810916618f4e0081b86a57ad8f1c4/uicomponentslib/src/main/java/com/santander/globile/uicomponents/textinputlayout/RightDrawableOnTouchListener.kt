package com.santander.globile.uicomponents.textinputlayout

import android.graphics.drawable.Drawable
import android.support.v7.widget.AppCompatEditText
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener

/**
 * Class to get onTouch event in RightDrawable into AppcompatEditText
 *
 * @constructor
 * @param view [AppCompatEditText]
 */

abstract class RightDrawableOnTouchListener
    (view: AppCompatEditText) : OnTouchListener {
    internal var drawable: Drawable? = null
    private val fuzz = 10

    init {
        val drawables = view.compoundDrawables
        if (drawables != null && drawables.size == 4)
            this.drawable = drawables[2]
    }


    override fun onTouch(v: View, event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN && drawable != null) {
            val x = event.x.toInt()
            val y = event.y.toInt()
            val bounds = drawable!!.bounds
            if (x >= v.right - bounds.width() - fuzz && x <= v.right - v.paddingRight + fuzz
                && y >= v.paddingTop - fuzz && y <= v.height - v.paddingBottom + fuzz
            ) {
                return onDrawableTouch(event)
            }
        }
        return false
    }

    abstract fun onDrawableTouch(event: MotionEvent): Boolean

}