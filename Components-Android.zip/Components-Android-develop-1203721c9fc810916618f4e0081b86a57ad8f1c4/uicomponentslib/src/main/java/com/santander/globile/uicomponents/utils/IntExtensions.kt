package com.santander.globile.uicomponents.utils

import android.content.res.Resources

val Int.toPx: Int
    get() = (this / Resources.getSystem().displayMetrics.density).toInt()
val Int.toDP: Int
    get() = (this * Resources.getSystem().displayMetrics.density).toInt()