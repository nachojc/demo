package com.santander.globile.uicomponents.list.simple.viewholder

import android.support.v7.widget.RecyclerView
import android.view.View
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericBinder
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener
import com.santander.globile.uicomponents.list.simple.data.SimpleData
import kotlinx.android.synthetic.main.globile_simple_row.view.*

class GlobileSimpleViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), GlobileGenericBinder<SimpleData> {
    override fun bind(data: SimpleData, listener: GlobileRecyclerListener<SimpleData>?) {
        itemView.let { view ->
            view.simple_row_key.text = data.key
            view.simple_row_value.text = data.value
            view.setOnClickListener{
                listener?.onClickListener(data,view,0)
            }
        }
    }

}