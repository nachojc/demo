package com.santander.globile.uicomponents.pagecontroller

import android.content.Context
import android.os.Build
import android.support.v4.view.ViewPager
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.FrameLayout
import com.santander.globile.uicomponents.R
import kotlinx.android.synthetic.main.page_controller_indicator.view.*

/**
 * Custom page indicator that shows dots associated to a page viewer with the design of the Santander Globile.
 *
 * @param context
 * @param attrs
 * @param defStyleAttr
 *
 * attrs defined at xml file when add this component in a layout using XML Namespace Prefix "app" with this attributes:
 * - app:pageindicator_activeColor : Set color of the visible page dot.(Default: Santander Red)
 * - app:pageindicator_inactiveColor : Set color of the not visible pages dot.(Default: Light Grey)
 * - app:pageindicator_radius : Set normal dot radius in dp.(Default: 4dp)
 * - app:pageindicator_marginBetweenCircles : Set space between two dots.(Default: 6dp)
 * - app:pageindicator_maxNormalSizeDots : Set number of dots with normal size.(Default: 4)
 * - app:pageindicator_fadingDots : Set number of dots with decreasing size.(Default: 2)
 */


class PageControllerIndicator @JvmOverloads constructor(
        context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
    ) : FrameLayout(context, attrs, defStyleAttr) {

    private val mContext = context
    private var mMaxDots = 4
    private var mFadingDots = 2
    private var mActiveColor: Int?
    private var mInactiveColor: Int?
    private var mRadius: Float?
    private var mMarginBetweenDots: Float?

    // Init component with attributes from xml
    init {
        LayoutInflater.from(mContext)
            .inflate(R.layout.page_controller_indicator, this, true)

        val typedArray = mContext.obtainStyledAttributes(attrs, R.styleable.PageControllerIndicator)

        mMaxDots = typedArray.getInt(R.styleable.PageControllerIndicator_pageindicator_maxNormalSizeDots, 4)
        setMaxNumberNormalDots(mMaxDots)

        mFadingDots = typedArray.getInt(R.styleable.PageControllerIndicator_pageindicator_fadingDots,2)
        setFadingDots(mFadingDots)

        val activeColor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            resources.getColor(R.color.page_controller_active, null)
        } else {
            resources.getColor(R.color.page_controller_active)
        }
        mActiveColor = typedArray.getInt(R.styleable.PageControllerIndicator_pageindicator_activeColor, activeColor)
        mActiveColor?.let{ setActiveColor(it) }

        val inactiveColor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            resources.getColor(R.color.page_controller_inactive, null)
        } else {
            resources.getColor(R.color.page_controller_inactive)
        }
        mInactiveColor = typedArray.getInt(R.styleable.PageControllerIndicator_pageindicator_inactiveColor, inactiveColor)
        mInactiveColor?.let{ setInactiveColor(it) }

        mRadius = typedArray.getDimension(R.styleable.PageControllerIndicator_pageindicator_radius, getResources().getDimensionPixelSize(R.dimen.default_dot_radius).toFloat())
        mRadius?.let{ setRadius(it) }

        mMarginBetweenDots = typedArray.getDimension(R.styleable.PageControllerIndicator_pageindicator_marginBetweenCircles, getResources().getDimensionPixelSize(R.dimen.default_margin_between_dots).toFloat())
        mMarginBetweenDots?.let{ setMarginBetweenDots(it)}

        typedArray.recycle()
    }

    /**
     * Bind view pager with page indicator
     * @param viewPager
     */
    fun setViewPager(viewPager: ViewPager){
        indicator.setViewPager(viewPager)
    }

    /**
     * Set color of the visible page dot
     * @param color
     */
    fun setActiveColor(color: Int){
        indicator.fillColor = color
        mActiveColor = color
    }

    /**
     * Set color of the not visible pages dot.
     * @param color
     */
    fun setInactiveColor(color: Int){
        indicator.pageColor = color
        mInactiveColor = color
    }

    /**
     * Set normal dot radius in dp.
     * @param radius
     */
    fun setRadius(radius: Float){
        indicator.radius = radius
        mRadius = radius
    }

    /**
     * Set space between two dots.
     * @param margin
     */
    fun setMarginBetweenDots(margin: Float){
        indicator.setMarginBetweenCircles(margin)
        mMarginBetweenDots = margin
    }

    /**
     * Set number of dots with normal size.
     * @param numberDots
     */
    fun setMaxNumberNormalDots(numberDots: Int){
        indicator.setOnSurfaceCount(numberDots)
        mMaxDots = numberDots
    }

    /**
     * Set number of dots with decreasing size.
     * @param fadingDots
     */
    fun setFadingDots(fadingDots: Int){
        indicator.setRisingCount(fadingDots)
        mFadingDots = fadingDots
    }
}