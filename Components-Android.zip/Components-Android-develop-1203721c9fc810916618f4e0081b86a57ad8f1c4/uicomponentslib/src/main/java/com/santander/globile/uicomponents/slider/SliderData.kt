package com.santander.globile.uicomponents.slider

/**
 * Slider data to store data from slider.
 *
 * @property data
 *  - Key :  Position of thumb
 *  - Value: Value from thumb
 */
data class SliderData(val data: Map<Int,Int?>)
