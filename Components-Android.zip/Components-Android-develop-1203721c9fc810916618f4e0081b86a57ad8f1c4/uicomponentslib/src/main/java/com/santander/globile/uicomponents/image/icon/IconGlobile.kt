package com.santander.globile.uicomponents.image.icon

import android.content.Context
import android.content.res.ColorStateList
import android.os.Build
import android.support.constraint.ConstraintLayout
import android.support.v4.widget.ImageViewCompat
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import com.allenliu.badgeview.BadgeFactory
import com.allenliu.badgeview.BadgeView
import com.santander.globile.uicomponents.R
import kotlinx.android.synthetic.main.icon_globile.view.*


class IconGlobile @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : ConstraintLayout (context, attrs, defStyle) {

    init {
        LayoutInflater.from(context).inflate(R.layout.icon_globile, this)
    }

    /**
     * Method to create the badge depending the number received
     *
     * @param num Int. Number to set into the badge
     * @param theme BadgeType. Enum type with 3 possible color appearances
     * @param size IconSize. Enum with the 3 possible sizes
     */
    fun setBadge (num: Int, theme: BadgeType, size: IconSize) {

        var backgroundBadgeColor = 0
        var textBadgeColor = 0
        var textSize = resources.getDimension(R.dimen.badge_textsize_small)
        var width = resources.getDimension(R.dimen.badge_width_small)
        var height: Float = resources.getDimension(R.dimen.badge_height_small)
        var space = resources.getDimension(R.dimen.badge_space_small)
        var emptySize = resources.getDimension(R.dimen.badge_empty_size_small)
        var emptySpace = resources.getDimension(R.dimen.badge_empty_space_small)


        when (theme) {
            BadgeType.PRIMARY ->{
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    backgroundBadgeColor = resources.getColor(R.color.boston_red, null)
                    textBadgeColor = resources.getColor(R.color.white, null)
                } else {
                    backgroundBadgeColor = resources.getColor(R.color.boston_red)
                    textBadgeColor = resources.getColor(R.color.white)
                }
            }
            BadgeType.SECONDARY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    backgroundBadgeColor = resources.getColor(R.color.white, null)
                    textBadgeColor = resources.getColor(R.color.boston_red, null)
                } else {
                    backgroundBadgeColor = resources.getColor(R.color.white)
                    textBadgeColor = resources.getColor(R.color.boston_red)
                }
            }
            BadgeType.DISABLED -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    backgroundBadgeColor = resources.getColor(R.color.boston_red, null)
                    textBadgeColor = resources.getColor(R.color.white, null)
                } else {
                    backgroundBadgeColor = resources.getColor(R.color.boston_red)
                    textBadgeColor = resources.getColor(R.color.white)
                }
            }
        }

        when (size) {
            IconSize.SMALL -> {
                textSize = resources.getDimension(R.dimen.badge_textsize_small)
                width = resources.getDimension(R.dimen.badge_width_small)
                height = resources.getDimension(R.dimen.badge_height_small)
                space = resources.getDimension(R.dimen.badge_space_small)
                emptySize = resources.getDimension(R.dimen.badge_empty_size_small)
                emptySpace = resources.getDimension(R.dimen.badge_empty_space_small)
            }
            IconSize.MEDIUM -> {
                textSize = resources.getDimension(R.dimen.badge_textsize_medium)
                width = resources.getDimension(R.dimen.badge_width_medium)
                height = resources.getDimension(R.dimen.badge_height_medium)
                space = resources.getDimension(R.dimen.badge_space_medium)
                emptySize = resources.getDimension(R.dimen.badge_empty_size_medium)
                emptySpace = resources.getDimension(R.dimen.badge_empty_space_medium)
            }
            IconSize.BIG -> {
                textSize = resources.getDimension(R.dimen.badge_textsize_big)
                width = resources.getDimension(R.dimen.badge_width_big)
                height = resources.getDimension(R.dimen.badge_height_big)
                space = resources.getDimension(R.dimen.badge_space_big)
                emptySize = resources.getDimension(R.dimen.badge_empty_size_big)
                emptySpace = resources.getDimension(R.dimen.badge_empty_space_big)
            }
        }

        when {
            num <= 0 -> {
                createBadge(textColor = textBadgeColor, badgeBackgroundColor = backgroundBadgeColor, width = emptySize, height = emptySize, textSize = 0F, space = emptySpace)
            }
            num in 1..9 -> {
                createBadge(textColor = textBadgeColor, badgeBackgroundColor = backgroundBadgeColor, width = height, height = height, textSize = textSize, space = space, badgeCount = num.toString())
            }
            num in 10..99 -> {
                createBadge(textColor = textBadgeColor, badgeBackgroundColor = backgroundBadgeColor, width = width, height = height, textSize = textSize, space = space, shape = BadgeView.SHAPTE_ROUND_RECTANGLE, badgeCount = num.toString())
            }
            num > 99 -> {
                createBadge(textColor = textBadgeColor, badgeBackgroundColor = backgroundBadgeColor, width = width, height = height, textSize = textSize, space = space, shape = BadgeView.SHAPTE_ROUND_RECTANGLE, badgeCount = "99+")
            }
        }
    }

    private fun createBadge(
        textColor: Int,
        badgeBackgroundColor: Int,
        width: Float,
        height: Float,
        textSize: Float,
        space: Float,
        shape: Int = BadgeView.SHAPE_CIRCLE,
        badgeCount: String = "0") {

        BadgeFactory.create(context)
            .setTextColor(textColor)
            .setBadgeBackground(badgeBackgroundColor)
            .setWidthAndHeight(width.toInt(),height.toInt())
            .setTextSize(textSize.toInt())
            .setSpace(space.toInt(),space.toInt())
            .setShape(shape)
            .setBadgeGravity(Gravity.END or Gravity.TOP)
            .setBadgeCount(badgeCount)
            .bind(icon_image)
    }


    /**
     * Method to set up the icon
     *
     * @param icon Int. The resource to be shown
     * @param iconColor IconColor. Enum type with 3 possible color appearances
     * @param size IconSize. Enum with the 3 possible sizes
     */
    fun setIcon (icon: Int, iconColor: IconColor, size: IconSize) {

        val color = when (iconColor) {
            IconColor.BOSTON_RED -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    resources.getColor(R.color.boston_red, null)
                } else {
                    resources.getColor(R.color.boston_red)
                }
            }
            IconColor.GREY -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    resources.getColor(R.color.grey, null)
                } else {
                    resources.getColor(R.color.grey)
                }
            }
            IconColor.WHITE -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    resources.getColor(R.color.white, null)
                } else {
                    resources.getColor(R.color.white)
                }
            }
        }

        icon_image.setImageResource(icon)
        ImageViewCompat.setImageTintList(icon_image, ColorStateList.valueOf(color))


        val dimensionInDp = when (size) {
            IconSize.SMALL -> {
                resources.getDimension(R.dimen.icon_size_small).toInt()
            }
            IconSize.MEDIUM -> {
                resources.getDimension(R.dimen.icon_size_medium).toInt()
            }
            IconSize.BIG -> {
                resources.getDimension(R.dimen.icon_size_big).toInt()
            }
        }

        icon_image.layoutParams.height = dimensionInDp
        icon_image.layoutParams.width = dimensionInDp
        icon_image.requestLayout()
    }

}

enum class BadgeType {PRIMARY, SECONDARY, DISABLED}
enum class IconColor {BOSTON_RED, GREY, WHITE}
enum class IconSize {SMALL, MEDIUM, BIG}