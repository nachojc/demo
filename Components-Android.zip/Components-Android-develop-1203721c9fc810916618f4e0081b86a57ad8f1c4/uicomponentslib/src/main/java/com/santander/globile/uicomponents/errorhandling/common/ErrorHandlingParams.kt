package com.santander.globile.uicomponents.errorhandling.common



/**
 * Entity that holds Error Handler params
 *
 *
 * @param title : title in error dialog.
 * @param subtitle: subtitle in error dialog.
 * @param message: message text in error dialog.
 * @param positiveButtonText: text in positive button.
 * @param negativeButtonText: text in negative button.
 *
 */
data class ErrorHandlingParams(
    var title: String? = null,
    var subtitle: String? = null,
    var message: String? = null,
    var positiveButtonText: String? = null,
    var negativeButtonText: String? = null
)