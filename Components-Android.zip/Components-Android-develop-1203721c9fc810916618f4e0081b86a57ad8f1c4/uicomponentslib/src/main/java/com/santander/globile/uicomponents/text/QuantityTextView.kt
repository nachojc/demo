package com.santander.globile.uicomponents.text

import android.content.Context
import android.graphics.*
import android.text.TextPaint
import android.util.AttributeSet
import android.view.View
import com.santander.globile.uicomponents.R
import java.text.DecimalFormatSymbols
import java.text.NumberFormat
import java.util.*
import kotlin.math.floor

class QuantityTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val textPaint = TextPaint(Paint.ANTI_ALIAS_FLAG)

    private val symbolText = Text()
    private val integerPartText = Text()
    private val decimalPartText = Text()

    private var mWidth: Int = 0
    private var mHeight: Int = 0

    private var integerSize: Float
    private var symbolsAndDecimalSize: Float
    private var symbol: String
    private var symbolAtEnd: Boolean
    private val textMargins: Float
    private var amount: Float
    private var color: Int
    private var font: String?

    init {

        val typedArray = context.theme.obtainStyledAttributes(
            attrs, R.styleable.QuantityTextView,
            0, R.style.QuantityDefaultStyle
        )

        try {

            amount = typedArray.getFloat(R.styleable.QuantityTextView_amount, 0F)
            symbolAtEnd = typedArray.getBoolean(R.styleable.QuantityTextView_currencyAtEnd, false)
            textMargins = typedArray.getDimension(R.styleable.QuantityTextView_textMargins, 0F)
            integerSize = typedArray.getDimension(R.styleable.QuantityTextView_baseTextSize, 18F)
            symbolsAndDecimalSize = integerSize * 0.75F
            symbol = typedArray.getString(R.styleable.QuantityTextView_currency) ?: ""
            color = typedArray.getColor(R.styleable.QuantityTextView_textColor, Color.BLACK)
            font = typedArray.getString(R.styleable.QuantityTextView_quantityTextFont)

        } finally {
            typedArray.recycle()
        }
    }

    fun setAmount(amount: Float) {
        this.amount = amount
        requestLayout()
    }

    fun getAmount(): Float = amount

    fun setCurrency(symbol: String) {
        this.symbol = symbol
        requestLayout()
    }

    fun setColor(color: Int) {
        this.color = color
        requestLayout()
    }

    fun setSize(size: Float) {
        integerSize = size
        symbolsAndDecimalSize = integerSize * 0.75F
        requestLayout()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)

        initQuantityTexts()
        initTextPaint()

        textPaint.textSize = integerPartText.size
        val offset = textPaint.fontMetrics.bottom.toInt()

        val (width, height) = calculateBounds(widthMeasureSpec, heightMeasureSpec, offset)
        calculatePositions(offset.toFloat())

        setMeasuredDimension(width, height)
    }

    private fun initQuantityTexts() {

        // Integer and decimal part are calculated
        var integerPart = amount.toInt()
        val tmp = if (amount < 0) amount * -1 else amount
        val decimals = ((tmp - floor(tmp)) * 100).toInt()

        // '-' is added when amount is negative and currencySymbol is placed at the start
        val currencySymbol = if (!symbolAtEnd && amount < 0) {
            integerPart *= -1
            "-$symbol"
        } else symbol

        // Currency symbol text and size
        symbolText.text = currencySymbol
        symbolText.size = symbolsAndDecimalSize

        // Integer part text and size
        integerPartText.text =
                // '-' is added to integer part when it is 0 but amount is negative and currencySymbol is placed at the end
                if (integerPart == 0 && amount < 0 && symbolAtEnd)
                    "-$integerPart"
                else
                    NumberFormat.getNumberInstance(Locale.getDefault()).format(integerPart).toString()
        integerPartText.size = integerSize

        // Decimal part text and size
        val decimalSeparator = DecimalFormatSymbols(Locale.getDefault()).decimalSeparator
        decimalPartText.text = "$decimalSeparator${if (decimals < 10) "0$decimals" else decimals.toString()}"
        decimalPartText.size = symbolsAndDecimalSize
    }

    private fun initTextPaint() {
        textPaint.style = Paint.Style.FILL
        textPaint.color = color

        textPaint.typeface = try {
            Typeface.createFromAsset(
                context.assets,
                "fonts/${font?.run { if (!endsWith(fontSuffix)) plus(fontSuffix) else this } ?: defaultFont}"
            )
        } catch (e: Exception) {
            Typeface.createFromAsset(context.assets, "fonts/$defaultFont")
        }
    }

    private fun calculateBounds(widthMeasureSpec: Int, heightMeasureSpec: Int, offset: Int): Pair<Int, Int> {

        symbolText.calculateBounds()
        integerPartText.calculateBounds()
        decimalPartText.calculateBounds()

        val widthSize = MeasureSpec.getSize(widthMeasureSpec)
        val widthMode = MeasureSpec.getMode(widthMeasureSpec)
        val heightSize = MeasureSpec.getSize(heightMeasureSpec)
        val heightMode = MeasureSpec.getMode(heightMeasureSpec)

        mWidth = when (widthMode) {
            MeasureSpec.EXACTLY -> {
                widthSize
            }
            MeasureSpec.AT_MOST, MeasureSpec.UNSPECIFIED -> {
                (2 * textMargins.toInt()) + symbolText.w + integerPartText.w + decimalPartText.w + paddingBottom + paddingTop + offset
            }
            else -> throw IllegalArgumentException("Invalid provided width")
        }

        mHeight = when (heightMode) {
            MeasureSpec.EXACTLY -> {
                heightSize
            }
            MeasureSpec.AT_MOST, MeasureSpec.UNSPECIFIED -> {
                integerPartText.h + paddingTop + paddingBottom + offset
            }
            else -> throw IllegalArgumentException("Invalid provided height")
        }

        return Pair(mWidth, mHeight)
    }

    private fun calculatePositions(offset: Float) {

        calculateX(paddingStart + (offset / 2F))

        calculateY((paddingTop + integerPartText.h).toFloat())
    }

    private fun calculateX(fromX: Float) {
        if (!symbolAtEnd)
            symbolText.x = fromX
        integerPartText.x = if (symbolAtEnd) fromX else symbolText.x + symbolText.w + textMargins
        decimalPartText.x = textMargins.apply { if (!symbolAtEnd) this * 2 } + integerPartText.x + integerPartText.w
        if (symbolAtEnd)
            symbolText.x = decimalPartText.x + textMargins + decimalPartText.w
    }

    private fun calculateY(fromY: Float) {
        if (!symbolAtEnd)
            symbolText.y = fromY - (integerPartText.h - symbolText.h + symbolText.bounds.bottom)
        integerPartText.y = fromY
        decimalPartText.y = fromY
        if (symbolAtEnd)
            symbolText.y = fromY
    }

    override fun onDraw(canvas: Canvas?) {
        super.onDraw(canvas)

        symbolText.draw(canvas)
        integerPartText.draw(canvas)
        decimalPartText.draw(canvas)
    }

    inner class Text {
        var text = ""
        var x: Float = 0F
        var y: Float = 0F
        var w: Int = 0
        var h: Int = 0
        var size: Float = 0F
        var bounds: Rect = Rect()

        fun calculateBounds() {
            textPaint.textSize = size
            textPaint.getTextBounds(text, 0, text.length, bounds)
            w = bounds.width()
            h = bounds.height()
        }

        fun draw(canvas: Canvas?) {
            textPaint.textSize = size

            canvas?.drawText(text, x, y, textPaint)
        }

    }

    companion object {
        private const val defaultFont = "SantanderText-Regular.ttf"
        private const val fontSuffix = ".ttf"
    }
}