package com.santander.globile.uicomponents

import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.santander.globile.uicomponents.actionbar.GlobileActionBarActivity
import com.santander.globile.uicomponents.actionbar.ToolbarStyle


class MainActivity : GlobileActionBarActivity(ToolbarStyle.STYLE_WHITE) {

    override fun setLayoutId(): Int {
       return R.layout.activity_main
    }

    override fun setActionIconResource(): Int? {
        return null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Hello Title"
        addOnClickListenerActionIcon(View.OnClickListener {
            Toast.makeText(this,"hello world",Toast.LENGTH_SHORT).show()
        })
        hideActionIcon()
        setDrawerEnabled(false)
    }

}
