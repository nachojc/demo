package com.santander.globile.uicomponents.utils

import android.view.animation.Animation
import com.santander.globile.uicomponents.common.__AnimationListener

inline fun Animation.setAnimationListener(
    func: __AnimationListener.() -> Unit) {
    val listener = __AnimationListener()
    listener.func()
    setAnimationListener(listener)
}