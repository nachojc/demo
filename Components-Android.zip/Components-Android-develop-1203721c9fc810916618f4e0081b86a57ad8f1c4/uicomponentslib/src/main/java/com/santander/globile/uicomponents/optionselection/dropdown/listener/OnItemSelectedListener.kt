package com.santander.globile.uicomponents.optionselection.dropdown.listener

import com.santander.globile.uicomponents.optionselection.dropdown.data.DropDownData

/**
 * Interface to handle onclick listener in GlobileDropDown.
 *
 * @param T : Generic any type of data.
 */
interface OnItemSelectedListener <T> {
    fun onItemSelected(item: DropDownData<T>)
    fun onNothingSelected()
}