(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["modules-demo-demo-module"],{

/***/ "./src/app/modules/demo/demo.component.html":
/*!**************************************************!*\
  !*** ./src/app/modules/demo/demo.component.html ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\n\n\n  <h1>\n   {{ title }} ready!\n  </h1>\n  <p>event msg: {{text}}</p>\n<p>\n    <button sn-button>Hola</button>\n</p>\n\n"

/***/ }),

/***/ "./src/app/modules/demo/demo.component.scss":
/*!**************************************************!*\
  !*** ./src/app/modules/demo/demo.component.scss ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  text-align: center; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9kZXZlbG9wL1NhbnRhbmRlci9HbG9iYWxlL0Zyb250L1N0YXJ0ZXJBcHAtQW5ndWxhci9zcmMvYXBwL21vZHVsZXMvZGVtby9kZW1vLmNvbXBvbmVudC5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUVBO0VBQ0ksa0JBQWtCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9tb2R1bGVzL2RlbW8vZGVtby5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBpbXBvcnQgJ3ZhcmlhYmxlcyc7XG5cbjpob3N0e1xuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/modules/demo/demo.component.ts":
/*!************************************************!*\
  !*** ./src/app/modules/demo/demo.component.ts ***!
  \************************************************/
/*! exports provided: DemoComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoComponent", function() { return DemoComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _santander_components_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @santander/components-library */ "./dist/@santander/components-library/fesm5/santander-components-library.js");



var DemoComponent = /** @class */ (function () {
    function DemoComponent(bridge) {
        this.bridge = bridge;
        this.title = 'Demo event Intercemptor';
        this.text = '';
    }
    DemoComponent.prototype.ngOnInit = function () {
        var _this = this;
        this._main$ = this.bridge.onMain().subscribe(function (dto) {
            console.log(dto);
        });
        this._other$ = this.bridge.onEvent('other').subscribe(function (dto) {
            _this.text = dto;
            console.log(dto);
        });
    };
    DemoComponent.prototype.ngOnDestroy = function () {
        this._main$.unsubscribe();
        this._other$.unsubscribe();
    };
    DemoComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'sn-demo',
            template: __webpack_require__(/*! ./demo.component.html */ "./src/app/modules/demo/demo.component.html"),
            styles: [__webpack_require__(/*! ./demo.component.scss */ "./src/app/modules/demo/demo.component.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_santander_components_library__WEBPACK_IMPORTED_MODULE_2__["CallbackIntegrationService"]])
    ], DemoComponent);
    return DemoComponent;
}());



/***/ }),

/***/ "./src/app/modules/demo/demo.module.ts":
/*!*********************************************!*\
  !*** ./src/app/modules/demo/demo.module.ts ***!
  \*********************************************/
/*! exports provided: DemoModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoModule", function() { return DemoModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _demo_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./demo.routing.module */ "./src/app/modules/demo/demo.routing.module.ts");
/* harmony import */ var _santander_components_library__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @santander/components-library */ "./dist/@santander/components-library/fesm5/santander-components-library.js");
/* harmony import */ var _demo_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./demo.component */ "./src/app/modules/demo/demo.component.ts");






var DemoModule = /** @class */ (function () {
    function DemoModule() {
    }
    DemoModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _demo_routing_module__WEBPACK_IMPORTED_MODULE_3__["DemoRoutingModule"],
                _santander_components_library__WEBPACK_IMPORTED_MODULE_4__["ButtonModule"]
            ],
            declarations: [
                _demo_component__WEBPACK_IMPORTED_MODULE_5__["DemoComponent"]
            ],
            providers: []
        })
    ], DemoModule);
    return DemoModule;
}());



/***/ }),

/***/ "./src/app/modules/demo/demo.routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/modules/demo/demo.routing.module.ts ***!
  \*****************************************************/
/*! exports provided: DemoRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DemoRoutingModule", function() { return DemoRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _demo_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./demo.component */ "./src/app/modules/demo/demo.component.ts");




var routes = [
    { path: '', component: _demo_component__WEBPACK_IMPORTED_MODULE_3__["DemoComponent"] },
    { path: '**', redirectTo: '/' }
];
var DemoRoutingModule = /** @class */ (function () {
    function DemoRoutingModule() {
    }
    DemoRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], DemoRoutingModule);
    return DemoRoutingModule;
}());



/***/ })

}]);
//# sourceMappingURL=modules-demo-demo-module.js.map