(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./dist/@santander/components-library/fesm5/santander-components-library.js":
/*!**********************************************************************************!*\
  !*** ./dist/@santander/components-library/fesm5/santander-components-library.js ***!
  \**********************************************************************************/
/*! exports provided: ɵa, ɵb, ɵf, ɵh, ɵd, ɵc, ɵe, ɵg, ɵi, ButtonModule, CurrencyModule, CurrencyService, CountryEnum, CURRENCY, IconModule, IconMenuModule, HeaderModule, MenuHeaderModule, TabBaruModule, CallbackIntegrationService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵa", function() { return ButtonComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵb", function() { return CurrencyComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵf", function() { return IconModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵh", function() { return IconMenuModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵd", function() { return IconMenuComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵc", function() { return IconComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵe", function() { return HeaderComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵg", function() { return MenuHeaderComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ɵi", function() { return TabBarComponent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ButtonModule", function() { return ButtonModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrencyModule", function() { return CurrencyModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CurrencyService", function() { return CurrencyService; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CountryEnum", function() { return CountryEnum; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CURRENCY", function() { return CURRENCY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconModule", function() { return IconModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconMenuModule", function() { return IconMenuModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HeaderModule", function() { return HeaderModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MenuHeaderModule", function() { return MenuHeaderModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabBaruModule", function() { return TabBaruModule; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CallbackIntegrationService", function() { return CallbackIntegrationService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm5/index.js");





var BUTTON_HOST_ATTRIBUTES = [
    'sn-button',
    'sn-button-small',
    'sn-button-full',
    'sn-button-large',
    'sn-button-strech',
    'sn-button-outlined',
    'sn-button-secondary'
];
var ButtonComponent = /** @class */ (function () {
    function ButtonComponent(_elementRef) {
        this._elementRef = _elementRef;
    }
    ButtonComponent.prototype.onClick = function (target) {
        target.classList.add('sn-button-clicked');
    };
    ButtonComponent.prototype.ngOnInit = function () {
        var e_1, _a;
        try {
            for (var BUTTON_HOST_ATTRIBUTES_1 = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__values"])(BUTTON_HOST_ATTRIBUTES), BUTTON_HOST_ATTRIBUTES_1_1 = BUTTON_HOST_ATTRIBUTES_1.next(); !BUTTON_HOST_ATTRIBUTES_1_1.done; BUTTON_HOST_ATTRIBUTES_1_1 = BUTTON_HOST_ATTRIBUTES_1.next()) {
                var attr = BUTTON_HOST_ATTRIBUTES_1_1.value;
                if (this._hasHostAttributes(attr)) {
                    this._elementRef.nativeElement.classList.add(attr);
                }
            }
        }
        catch (e_1_1) { e_1 = { error: e_1_1 }; }
        finally {
            try {
                if (BUTTON_HOST_ATTRIBUTES_1_1 && !BUTTON_HOST_ATTRIBUTES_1_1.done && (_a = BUTTON_HOST_ATTRIBUTES_1.return)) _a.call(BUTTON_HOST_ATTRIBUTES_1);
            }
            finally { if (e_1) throw e_1.error; }
        }
    };
    ButtonComponent.prototype._hasHostAttributes = function () {
        var _this = this;
        var attributes = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            attributes[_i] = arguments[_i];
        }
        return attributes.some(function (attribute) {
            return _this._elementRef.nativeElement.hasAttribute(attribute);
        });
    };
    ButtonComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                    selector: "sn-button,\n    button[sn-button],\n    button[sn-button-small],\n    button[sn-button-full],\n    button[sn-button-large],\n    button[sn-button-strech],\n    button[sn-button-outlined],\n    button[sn-button-secondary],\n    a[sn-button]",
                    template: '<ng-content></ng-content>',
                    encapsulation: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ViewEncapsulation"].None,
                    styles: ["button.sn-button{color:var(--sn-button__color-secondary,#fff);background-color:var(--sn-button__color-primary,#ec0000);font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;font-size:16px;margin:0;min-width:140px;min-height:48px;line-height:36px;padding:0 24px;border-radius:24px;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5)}button.sn-button:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00);animation:1.6s button-pressed;-webkit-animation:1.6s button-pressed}button.sn-button[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}button.sn-button.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}button.sn-button.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}button.sn-button.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}button.sn-button.link:hover:not([disabled]){border:none}button.sn-button.link:not([disabled]):active{box-shadow:none}button.sn-button-secondary{color:var(--sn-button__color-primary,#ec0000);background-color:#f0a9a9;font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;font-size:16px;margin:0;min-width:140px;min-height:48px;line-height:36px;padding:5px 24px;border-radius:24px;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5)}button.sn-button-secondary:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00);background-color:var(--sn-button__color-primary,#ec0000) 0;color:var(--sn-button__color-secondary,#fff)}button.sn-button-secondary[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}button.sn-button-secondary.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}button.sn-button-secondary.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}button.sn-button-secondary.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}button.sn-button-secondary.link:hover:not([disabled]){border:none}button.sn-button-secondary.link:not([disabled]):active{box-shadow:none}button.sn-button-secondary:disabled{background-color:var(--sn-button__color-secondary,#fff);border:solid 1px var(--sn-background-color__disabled,#d9d9d9);color:var(--sn-font-color__disabled,#999)}a.sn-button{color:var(--sn-button__color-secondary,#fff);background-color:var(--sn-button__color-primary,#ec0000);font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;font-size:16px;margin:0;min-width:140px;min-height:48px;line-height:36px;padding:5px 24px;border-radius:24px;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5)}a.sn-button:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00)}a.sn-button[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}a.sn-button.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}a.sn-button.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}a.sn-button.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}a.sn-button.link:hover:not([disabled]){border:none}a.sn-button.link:not([disabled]):active{box-shadow:none}.sn-button-small{color:var(--sn-button__color-secondary,#fff);background-color:var(--sn-button__color-primary,#ec0000);font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;margin:0;min-width:140px;min-height:48px;padding:0 12px;border-radius:24px;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);font-size:11px;min-width:44px;line-height:24px}.sn-button-small:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00)}.sn-button-small[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}.sn-button-small.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}.sn-button-small.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}.sn-button-small.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}.sn-button-small.link:hover:not([disabled]){border:none}.sn-button-small.link:not([disabled]):active{box-shadow:none}.sn-button-large{color:var(--sn-button__color-secondary,#fff);background-color:var(--sn-button__color-primary,#ec0000);font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;margin:0;min-width:140px;min-height:48px;padding:0 28px;border-radius:24px;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);font-size:18px;min-width:48px;line-height:42px}.sn-button-large:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00)}.sn-button-large[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}.sn-button-large.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}.sn-button-large.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}.sn-button-large.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}.sn-button-large.link:hover:not([disabled]){border:none}.sn-button-large.link:not([disabled]):active{box-shadow:none}.sn-button-full{color:var(--sn-button__color-secondary,#fff);background-color:var(--sn-button__color-primary,#ec0000);font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;font-size:16px;margin:0;min-width:140px;min-height:48px;line-height:36px;padding:0 24px;border-radius:0;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);width:100%;box-shadow:none;min-height:40pt}.sn-button-full:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00)}.sn-button-full[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}.sn-button-full.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}.sn-button-full.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}.sn-button-full.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}.sn-button-full.link:hover:not([disabled]){border:none}.sn-button-full.link:not([disabled]):active{box-shadow:none}.sn-button-outlined{color:var(--sn-background-color__disabled,#d9d9d9);background-color:var(--sn-button__color-secondary,#fff);font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;font-size:16px;margin:0;min-width:140px;min-height:48px;line-height:36px;padding:0 24px;border-radius:24px;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);border:1px solid var(--sn-background-color__disabled,#d9d9d9);cursor:not-allowed}.sn-button-outlined:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00)}.sn-button-outlined[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}.sn-button-outlined.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}.sn-button-outlined.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}.sn-button-outlined.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}.sn-button-outlined.link:hover:not([disabled]){border:none}.sn-button-outlined.link:not([disabled]):active{box-shadow:none}.sn-button-strech{color:var(--sn-button__color-secondary,#fff);background-color:var(--sn-button__color-primary,#ec0000);font-family:var(--sn-font-family__sans-serif,SantanderText);box-sizing:border-box;position:relative;-webkit-user-select:none;-moz-user-select:none;-ms-user-select:none;user-select:none;cursor:pointer;outline:0!important;border:none;-webkit-tap-highlight-color:transparent;display:inline-block;white-space:nowrap;text-decoration:none;vertical-align:baseline;font-weight:700;font-style:normal;font-stretch:normal;letter-spacing:normal;text-align:center;font-size:16px;margin:0;min-width:140px;min-height:48px;line-height:36px;padding:0 24px;border-radius:24px;overflow:visible;box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-webkit-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);-moz-box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5);width:100%}.sn-button-strech:not([disabled]):active{background-color:var(--sn-button__background-color--active,#c00)}.sn-button-strech[disabled]{box-shadow:none;background-color:var(--sn-button__background-color--disabled,#d9d9d9);color:var(--sn-button__font-color--disabled,#999);cursor:not-allowed}.sn-button-strech.outlined{background-color:var(--sn-font-color__disabled,#d9d9d9);color:var(--sn-button__color-secondary,#fff);border:1px solid var(--sn-font-color__disabled,#d9d9d9)}.sn-button-strech.outlined:hover:not([disabled]){color:var(--sn-button__color-primary,#ec0000)}.sn-button-strech.link{color:var(--sn-button__color-primary,#ec0000);background-color:var(--sn-button__color-secondary,#fff);border:none}.sn-button-strech.link:hover:not([disabled]){border:none}.sn-button-strech.link:not([disabled]):active{box-shadow:none}@keyframes button-pressed{0%,100%{-webkit-transform:scale3d(1,1,1);transform:scale3d(1,1,1);background-color:var(--sn-button__color-red,#e00);box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5)}37%{-webkit-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9);background-color:var(--sn-button__color-red-pressed,#ba2d22);box-shadow:none}}@-webkit-keyframes button-pressed{0%,100%{-webkit-transform:scale3d(1,1,1);transform:scale3d(1,1,1);background-color:var(--sn-button__color-red,#e00);box-shadow:0 14px 14px -12px rgba(var(--sn-color__primary),.5)}37%{-webkit-transform:scale3d(.9,.9,.9);transform:scale3d(.9,.9,.9);background-color:var(--sn-button__color-red-pressed,#ba2d22);box-shadow:none}}"]
                }] }
    ];
    /** @nocollapse */
    ButtonComponent.ctorParameters = function () { return [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["ElementRef"] }
    ]; };
    ButtonComponent.propDecorators = {
        onClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["HostListener"], args: ['click', ['$event.target'],] }]
    };
    return ButtonComponent;
}());

var ButtonModule = /** @class */ (function () {
    function ButtonModule() {
    }
    ButtonModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                    imports: [],
                    declarations: [ButtonComponent],
                    exports: [ButtonComponent]
                },] }
    ];
    return ButtonModule;
}());

var CountryEnum;
(function (CountryEnum) {
    CountryEnum["GB"] = "GBP";
    CountryEnum["SP"] = "EUR";
    CountryEnum["PT"] = "EUR";
    CountryEnum["DE"] = "EUR";
    CountryEnum["US"] = "USD";
    CountryEnum["MX"] = "MXN";
    CountryEnum["BR"] = "BRL";
    CountryEnum["UY"] = "UTU";
    CountryEnum["AR"] = "ARS";
})(CountryEnum || (CountryEnum = {}));
var CURRENCY = {
    'GBP': { symbol: '£', decimals: 2, decimal: '.', miles: ',', position: 'left' },
    'EUR': { symbol: '€', decimals: 2, decimal: ',', miles: '.', position: 'right' },
    'USD': { symbol: '$', decimals: 2, decimal: ',', miles: '.', position: 'right' },
    'MXN': { symbol: 'M$', decimals: 2, decimal: ',', miles: '.', position: 'right' },
    'BRL': { symbol: 'R$', decimals: 2, decimal: ',', miles: '.', position: 'right' },
    'ARS': { symbol: '$', decimals: 2, decimal: ',', miles: '.', position: 'right' },
    'UYU': { symbol: '$U', decimals: 2, decimal: ',', miles: '.', position: 'right' },
};

var CurrencyService = /** @class */ (function () {
    function CurrencyService() {
        this._currency = CURRENCY['EUR'];
    }
    CurrencyService.prototype.setCurrency = function (value) {
        if (CURRENCY[value] && value) {
            this._currency = CURRENCY[value];
        }
    };
    Object.defineProperty(CurrencyService.prototype, "symbol", {
        get: function () {
            return this._currency.symbol;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyService.prototype, "position", {
        get: function () {
            return this._currency.position;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyService.prototype, "decimal", {
        get: function () {
            return this._currency.decimal;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyService.prototype, "decimals", {
        get: function () {
            return this._currency.decimals;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyService.prototype, "miles", {
        get: function () {
            return this._currency.miles;
        },
        enumerable: true,
        configurable: true
    });
    CurrencyService.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"], args: [{
                    providedIn: 'root',
                },] }
    ];
    CurrencyService.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["defineInjectable"])({ factory: function CurrencyService_Factory() { return new CurrencyService(); }, token: CurrencyService, providedIn: "root" });
    return CurrencyService;
}());

/**
 *Crea un elemento currency.
 *
 * @export
 * @class CurrencyComponent
 */
var CurrencyComponent = /** @class */ (function () {
    function CurrencyComponent(currencyService) {
        this.currencyService = currencyService;
        this._value = 0;
        this.hideCurrency = false;
        this._currency = currencyService;
    }
    Object.defineProperty(CurrencyComponent.prototype, "currencyCode", {
        /**
         *  Parametro para definir el icono a mostrar.
         *
         * @type {string}
         * @memberof CurrencyComponent
         */
        set: function (code) {
            this._currency = new CurrencyService();
            this._currency.setCurrency(code);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyComponent.prototype, "value", {
        set: function (val) {
            if (!isNaN(val)) {
                this._value = val;
            }
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyComponent.prototype, "symbol", {
        get: function () {
            return this._currency ? this._currency.symbol : '';
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyComponent.prototype, "integer", {
        get: function () {
            return this.format(parseInt('' + this._value, 10));
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyComponent.prototype, "decimal", {
        get: function () {
            var dec = '' + Math.abs(Math.floor((this._value % 1) * Math.pow(10, this._currency.decimals)));
            return dec + '0'.repeat(this._currency.decimals - dec.length);
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(CurrencyComponent.prototype, "decimals", {
        get: function () {
            return this._currency.decimal;
        },
        enumerable: true,
        configurable: true
    });
    CurrencyComponent.prototype.isCurrencyAtLeft = function () {
        return this.currencyPosition === 'left' || (this._currency && this._currency.position === 'left');
    };
    CurrencyComponent.prototype.showCurrency = function () {
        return !this.hideCurrency;
    };
    CurrencyComponent.prototype.format = function (input) {
        var regx = /(\d+)(\d{3})/;
        var result = '' + input;
        while (regx.test(result)) {
            result = result.replace(regx, '$1' + this._currency.miles + '$2');
        }
        return result;
    };
    CurrencyComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                    selector: 'sn-currency',
                    template: "<div>\n    <span *ngIf=\"isCurrencyAtLeft() && showCurrency()\" class=\"first\">{{symbol}}</span>\n    <div class=\"integer\">{{integer}}</div>{{decimals}}\n    <div class=\"decimal\">{{decimal}}</div>\n    <span *ngIf=\"!isCurrencyAtLeft() && showCurrency()\">{{symbol}}</span>\n</div>\n",
                    styles: [":host{display:initial}:host div{line-height:1em;display:inline-flex;position:relative}:host div div.decimal,:host div span{font-size:.75em;margin-top:.25em;line-height:1em}:host div span.first{margin:.07em .1em 0 0}:host([flat]) div div.decimal,:host([flat]) div span{font-size:1em;margin-top:0}:host([flat]) div span.first{margin:0 .1em 0 0}"]
                }] }
    ];
    /** @nocollapse */
    CurrencyComponent.ctorParameters = function () { return [
        { type: CurrencyService }
    ]; };
    CurrencyComponent.propDecorators = {
        currencyPosition: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
        hideCurrency: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['hide-currency',] }],
        currencyCode: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['code',] }],
        value: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"], args: ['value',] }]
    };
    return CurrencyComponent;
}());

var CurrencyModule = /** @class */ (function () {
    function CurrencyModule() {
    }
    CurrencyModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                    imports: [
                        _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]
                    ],
                    declarations: [
                        CurrencyComponent,
                    ],
                    exports: [
                        CurrencyComponent
                    ]
                },] }
    ];
    return CurrencyModule;
}());

/**
 *Crea un elemento con un icono.
 *
 * @export
 * @class IconComponent
 */
var IconComponent = /** @class */ (function () {
    function IconComponent() {
    }
    IconComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                    selector: 'sn-icon',
                    template: "<i [class]=\"icon\"></i>\n",
                    styles: ["@charset \"UTF-8\";@font-face{font-family:\"Flame Icons\";src:url(assets/fonts/sn-icons.eot?pi8lf6);src:url(assets/fonts/sn-icons.eot?pi8lf6#iefix) format(\"embedded-opentype\"),url(assets/fonts/sn-icons.ttf?pi8lf6) format(\"truetype\"),url(assets/fonts/sn-icons.woff?pi8lf6) format(\"woff\"),url(assets/fonts/sn-icons.svg?pi8lf6#sn-icons) format(\"svg\");font-style:normal}i{font-family:\"Flame Icons\"!important;speak:none;font-style:normal;font-variant:normal;text-transform:none;line-height:1;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.sn-BAN01:before{content:\"\uE900\"}.sn-BAN01B:before{content:\"\uE901\"}.sn-BAN01C:before{content:\"\uE902\"}.sn-BAN02:before{content:\"\uE903\"}.sn-BAN02B:before{content:\"\uE904\"}.sn-BAN02C:before{content:\"\uE905\"}.sn-BAN03:before{content:\"\uE906\"}.sn-BAN04:before{content:\"\uE907\"}.sn-BAN04B:before{content:\"\uE908\"}.sn-BAN04C:before{content:\"\uE909\"}.sn-BAN05:before{content:\"\uE90A\"}.sn-BAN06:before{content:\"\uE90B\"}.sn-BAN07:before{content:\"\uE90C\"}.sn-BAN08:before{content:\"\uE90D\"}.sn-BAN08B:before{content:\"\uE90E\"}.sn-BAN08C:before{content:\"\uE90F\"}.sn-BAN09:before{content:\"\uE910\"}.sn-BAN10:before{content:\"\uE911\"}.sn-BAN11:before{content:\"\uE912\"}.sn-BAN12:before{content:\"\uE913\"}.sn-BAN13:before{content:\"\uE914\"}.sn-BAN14:before{content:\"\uE915\"}.sn-BAN15:before{content:\"\uE916\"}.sn-BAN16:before{content:\"\uE917\"}.sn-BAN17:before{content:\"\uE918\"}.sn-BAN19:before{content:\"\uE919\"}.sn-BAN20:before{content:\"\uE91A\"}.sn-BAN21:before{content:\"\uE91B\"}.sn-BAN23:before{content:\"\uE91C\"}.sn-BAN24:before{content:\"\uE91D\"}.sn-BAN24B:before{content:\"\uE91E\"}.sn-BAN24C:before{content:\"\uE91F\"}.sn-BAN26:before{content:\"\uE920\"}.sn-BAN27:before{content:\"\uE921\"}.sn-BAN28:before{content:\"\uE922\"}.sn-BAN29:before{content:\"\uE923\"}.sn-BAN34:before{content:\"\uE924\"}.sn-BAN36:before{content:\"\uE925\"}.sn-BAN37:before{content:\"\uE926\"}.sn-BAN38:before{content:\"\uE927\"}.sn-BAN39:before{content:\"\uE928\"}.sn-BAN40:before{content:\"\uE929\"}.sn-BAN41:before{content:\"\uE92A\"}.sn-BAN42:before{content:\"\uE92B\"}.sn-BAN42B:before{content:\"\uE92C\"}.sn-BAN42C:before{content:\"\uE92D\"}.sn-BAN43:before{content:\"\uE92E\"}.sn-BAN44:before{content:\"\uE92F\"}.sn-BAN45:before{content:\"\uE930\"}.sn-BAN45B:before{content:\"\uE931\"}.sn-BAN45C:before{content:\"\uE932\"}.sn-BAN46:before{content:\"\uE933\"}.sn-BAN46B:before{content:\"\uE934\"}.sn-BAN46C:before{content:\"\uE935\"}.sn-BAN47:before{content:\"\uE936\"}.sn-BAN47B:before{content:\"\uE937\"}.sn-BAN47C:before{content:\"\uE938\"}.sn-BAN48:before{content:\"\uE939\"}.sn-BAN48B:before{content:\"\uE93A\"}.sn-BAN48C:before{content:\"\uE93B\"}.sn-BAN49:before{content:\"\uE93C\"}.sn-BAN50:before{content:\"\uE93D\"}.sn-BAN53:before{content:\"\uE93E\"}.sn-BAN53B:before{content:\"\uE93F\"}.sn-BAN53C:before{content:\"\uE940\"}.sn-BAN54:before{content:\"\uE941\"}.sn-BAN54B:before{content:\"\uE942\"}.sn-BAN54C:before{content:\"\uE943\"}.sn-BAN55:before{content:\"\uE944\"}.sn-BAN55B:before{content:\"\uE945\"}.sn-BAN55C:before{content:\"\uE946\"}.sn-BAN56:before{content:\"\uE947\"}.sn-BAN57:before{content:\"\uE948\"}.sn-BAN57B:before{content:\"\uE949\"}.sn-BAN58:before{content:\"\uE94A\"}.sn-BAN59:before{content:\"\uE94B\"}.sn-BAN60:before{content:\"\uE94C\"}.sn-BAN60B:before{content:\"\uE94D\"}.sn-BAN60C:before{content:\"\uE94E\"}.sn-BAN61:before{content:\"\uE94F\"}.sn-BAN62:before{content:\"\uE950\"}.sn-BAN62B:before{content:\"\uE951\"}.sn-BAN62C:before{content:\"\uE952\"}.sn-BAN63:before{content:\"\uE953\"}.sn-BAN64:before{content:\"\uE954\"}.sn-BAN65:before{content:\"\uE955\"}.sn-BAN66:before{content:\"\uE956\"}.sn-BAN66B:before{content:\"\uE957\"}.sn-BAN66C:before{content:\"\uE958\"}.sn-BAN67:before{content:\"\uE959\"}.sn-BAN68:before{content:\"\uE95A\"}.sn-BAN69:before{content:\"\uE95B\"}.sn-BAN70:before{content:\"\uE95C\"}.sn-BAN71:before{content:\"\uE95D\"}.sn-BAN72:before{content:\"\uE95E\"}.sn-BAN73:before{content:\"\uE95F\"}.sn-BAN74:before{content:\"\uE960\"}.sn-BAN75:before{content:\"\uE961\"}.sn-BAN75B:before{content:\"\uE962\"}.sn-BAN76:before{content:\"\uE963\"}.sn-BAN76B:before{content:\"\uE964\"}.sn-BAN76C:before{content:\"\uE965\"}.sn-BAN77:before{content:\"\uE966\"}.sn-BAN79:before{content:\"\uE967\"}.sn-BAN80:before{content:\"\uE968\"}.sn-BAN81:before{content:\"\uE969\"}.sn-BAN82:before{content:\"\uE96A\"}.sn-BAN83:before{content:\"\uE96B\"}.sn-BAN86:before{content:\"\uE96C\"}.sn-BAN87:before{content:\"\uE96D\"}.sn-BAN88:before{content:\"\uE96E\"}.sn-BAN89:before{content:\"\uE96F\"}.sn-BAN90:before{content:\"\uE970\"}.sn-BAN92:before{content:\"\uE971\"}.sn-BAN93:before{content:\"\uE972\"}.sn-BAN94:before{content:\"\uE973\"}.sn-BAN95:before{content:\"\uE974\"}.sn-BAN96:before{content:\"\uE975\"}.sn-BAN97:before{content:\"\uE976\"}.sn-BAN98:before{content:\"\uE977\"}.sn-CHAN01:before{content:\"\uE978\"}.sn-CHAN02:before{content:\"\uE979\"}.sn-CHAN02B:before{content:\"\uE97A\"}.sn-CHAN02C:before{content:\"\uE97B\"}.sn-CHAN03:before{content:\"\uE97C\"}.sn-CHAN04:before{content:\"\uE97D\"}.sn-CHAN05B:before{content:\"\uE97E\"}.sn-CHAN05C:before{content:\"\uE97F\"}.sn-CHAN05D:before{content:\"\uE980\"}.sn-CHAN06:before{content:\"\uE981\"}.sn-CHAN07:before{content:\"\uE982\"}.sn-CHAN08:before{content:\"\uE983\"}.sn-CHAN10:before{content:\"\uE984\"}.sn-CHAN11:before{content:\"\uE985\"}.sn-CHAN12:before{content:\"\uE986\"}.sn-CHAN13:before{content:\"\uE987\"}.sn-CHAN14:before{content:\"\uE988\"}.sn-CHAN15:before{content:\"\uE989\"}.sn-CHAN16:before{content:\"\uE98A\"}.sn-CHAN17:before{content:\"\uE98B\"}.sn-CHAN18:before{content:\"\uE98C\"}.sn-CHAN19:before{content:\"\uE98D\"}.sn-CHAN20:before{content:\"\uE98E\"}.sn-CHAN21:before{content:\"\uE98F\"}.sn-CHAN22:before{content:\"\uE990\"}.sn-CHAN23:before{content:\"\uE991\"}.sn-CHAN24:before{content:\"\uE992\"}.sn-CHAN25:before{content:\"\uE993\"}.sn-CHAN26:before{content:\"\uE994\"}.sn-CHAN27:before{content:\"\uE995\"}.sn-CHAN28:before{content:\"\uE996\"}.sn-CHAN29:before{content:\"\uE997\"}.sn-CHAN30:before{content:\"\uE998\"}.sn-CHAN31:before{content:\"\uE999\"}.sn-CHAN32:before{content:\"\uE99A\"}.sn-CHAN33:before{content:\"\uE99B\"}.sn-CHAN34:before{content:\"\uE99C\"}.sn-CHAN35:before{content:\"\uE99D\"}.sn-CHAN36:before{content:\"\uE99E\"}.sn-CHAN38:before{content:\"\uE99F\"}.sn-CHAN40:before{content:\"\uE9A0\"}.sn-CHAN41:before{content:\"\uE9A1\"}.sn-CHAN42:before{content:\"\uE9A2\"}.sn-CHAN43:before{content:\"\uE9A3\"}.sn-CHAN44:before{content:\"\uE9A4\"}.sn-CHAN45:before{content:\"\uE9A5\"}.sn-DOC01:before{content:\"\uE9A6\"}.sn-DOC02:before{content:\"\uE9A7\"}.sn-DOC03:before{content:\"\uE9A8\"}.sn-DOC04:before{content:\"\uE9A9\"}.sn-DOC05:before{content:\"\uE9AA\"}.sn-DOC05B:before{content:\"\uE9AB\"}.sn-DOC05C:before{content:\"\uE9AC\"}.sn-DOC06:before{content:\"\uE9AD\"}.sn-DOC06B:before{content:\"\uE9AE\"}.sn-DOC06C:before{content:\"\uE9AF\"}.sn-DOC07:before{content:\"\uE9B0\"}.sn-DOC08:before{content:\"\uE9B1\"}.sn-DOC08B:before{content:\"\uE9B2\"}.sn-DOC08C:before{content:\"\uE9B3\"}.sn-DOC09:before{content:\"\uE9B4\"}.sn-DOC10:before{content:\"\uE9B5\"}.sn-DOC10B:before{content:\"\uE9B6\"}.sn-DOC10C:before{content:\"\uE9B7\"}.sn-DOC11:before{content:\"\uE9B8\"}.sn-DOC11B:before{content:\"\uE9B9\"}.sn-DOC11C:before{content:\"\uE9BA\"}.sn-DOC12:before{content:\"\uE9BB\"}.sn-DOC13:before{content:\"\uE9BC\"}.sn-DOC13B:before{content:\"\uE9BD\"}.sn-DOC13C:before{content:\"\uE9BE\"}.sn-FUNC01:before{content:\"\uE9BF\"}.sn-FUNC02:before{content:\"\uE9C0\"}.sn-FUNC02B:before{content:\"\uE9C1\"}.sn-FUNC02C:before{content:\"\uE9C2\"}.sn-FUNC03:before{content:\"\uE9C3\"}.sn-FUNC04:before{content:\"\uE9C4\"}.sn-FUNC05:before{content:\"\uE9C5\"}.sn-FUNC06:before{content:\"\uE9C6\"}.sn-FUNC07:before{content:\"\uE9C7\"}.sn-FUNC08:before{content:\"\uE9C8\"}.sn-FUNC09:before{content:\"\uE9C9\"}.sn-FUNC10:before{content:\"\uE9CA\"}.sn-FUNC100:before{content:\"\uE9CB\"}.sn-FUNC101:before{content:\"\uE9CC\"}.sn-FUNC102:before{content:\"\uE9CD\"}.sn-FUNC103:before{content:\"\uE9CE\"}.sn-FUNC104:before{content:\"\uE9CF\"}.sn-FUNC105:before{content:\"\uE9D0\"}.sn-FUNC106:before{content:\"\uE9D1\"}.sn-FUNC107:before{content:\"\uE9D2\"}.sn-FUNC108:before{content:\"\uE9D3\"}.sn-FUNC109:before{content:\"\uE9D4\"}.sn-FUNC11:before{content:\"\uE9D5\"}.sn-FUNC110:before{content:\"\uE9D6\"}.sn-FUNC111:before{content:\"\uE9D7\"}.sn-FUNC112:before{content:\"\uE9D8\"}.sn-FUNC113:before{content:\"\uE9D9\"}.sn-FUNC114:before{content:\"\uE9DA\"}.sn-FUNC115:before{content:\"\uE9DB\"}.sn-FUNC115B:before{content:\"\uE9DC\"}.sn-FUNC115C:before{content:\"\uE9DD\"}.sn-FUNC116:before{content:\"\uE9DE\"}.sn-FUNC118:before{content:\"\uE9DF\"}.sn-FUNC119:before{content:\"\uE9E0\"}.sn-FUNC13:before{content:\"\uE9E1\"}.sn-FUNC14:before{content:\"\uE9E2\"}.sn-FUNC15:before{content:\"\uE9E3\"}.sn-FUNC16:before{content:\"\uE9E4\"}.sn-FUNC17:before{content:\"\uE9E5\"}.sn-FUNC18:before{content:\"\uE9E6\"}.sn-FUNC19:before{content:\"\uE9E7\"}.sn-FUNC19B:before{content:\"\uE9E8\"}.sn-FUNC19C:before{content:\"\uE9E9\"}.sn-FUNC20:before{content:\"\uE9EA\"}.sn-FUNC21:before{content:\"\uE9EB\"}.sn-FUNC22:before{content:\"\uE9EC\"}.sn-FUNC23:before{content:\"\uE9ED\"}.sn-FUNC24:before{content:\"\uE9EE\"}.sn-FUNC25:before{content:\"\uE9EF\"}.sn-FUNC26:before{content:\"\uE9F0\"}.sn-FUNC27:before{content:\"\uE9F1\"}.sn-FUNC28:before{content:\"\uE9F2\"}.sn-FUNC29:before{content:\"\uE9F3\"}.sn-FUNC30:before{content:\"\uE9F4\"}.sn-FUNC31:before{content:\"\uE9F5\"}.sn-FUNC32:before{content:\"\uE9F6\"}.sn-FUNC33:before{content:\"\uE9F7\"}.sn-FUNC34:before{content:\"\uE9F8\"}.sn-FUNC35:before{content:\"\uE9F9\"}.sn-FUNC36:before{content:\"\uE9FA\"}.sn-FUNC37:before{content:\"\uE9FB\"}.sn-FUNC38:before{content:\"\uE9FC\"}.sn-FUNC39:before{content:\"\uE9FD\"}.sn-FUNC40:before{content:\"\uE9FE\"}.sn-FUNC41:before{content:\"\uE9FF\"}.sn-FUNC42:before{content:\"\uEA00\"}.sn-FUNC43:before{content:\"\uEA01\"}.sn-FUNC44:before{content:\"\uEA02\"}.sn-FUNC45:before{content:\"\uEA03\"}.sn-FUNC46:before{content:\"\uEA04\"}.sn-FUNC47:before{content:\"\uEA05\"}.sn-FUNC48:before{content:\"\uEA06\"}.sn-FUNC49:before{content:\"\uEA07\"}.sn-FUNC50:before{content:\"\uEA08\"}.sn-FUNC51:before{content:\"\uEA09\"}.sn-FUNC52:before{content:\"\uEA0A\"}.sn-FUNC53:before{content:\"\uEA0B\"}.sn-FUNC56:before{content:\"\uEA0C\"}.sn-FUNC57:before{content:\"\uEA0D\"}.sn-FUNC58:before{content:\"\uEA0E\"}.sn-FUNC59:before{content:\"\uEA0F\"}.sn-FUNC60:before{content:\"\uEA10\"}.sn-FUNC61:before{content:\"\uEA11\"}.sn-FUNC62:before{content:\"\uEA12\"}.sn-FUNC63:before{content:\"\uEA13\"}.sn-FUNC64:before{content:\"\uEA14\"}.sn-FUNC65:before{content:\"\uEA15\"}.sn-FUNC66:before{content:\"\uEA16\"}.sn-FUNC67:before{content:\"\uEA17\"}.sn-FUNC68:before{content:\"\uEA18\"}.sn-FUNC69:before{content:\"\uEA19\"}.sn-FUNC70:before{content:\"\uEA1A\"}.sn-FUNC71:before{content:\"\uEA1B\"}.sn-FUNC72:before{content:\"\uEA1C\"}.sn-FUNC73:before{content:\"\uEA1D\"}.sn-FUNC74:before{content:\"\uEA1E\"}.sn-FUNC75:before{content:\"\uEA1F\"}.sn-FUNC76:before{content:\"\uEA20\"}.sn-FUNC77:before{content:\"\uEA21\"}.sn-FUNC78:before{content:\"\uEA22\"}.sn-FUNC79:before{content:\"\uEA23\"}.sn-FUNC80:before{content:\"\uEA24\"}.sn-FUNC82:before{content:\"\uEA25\"}.sn-FUNC83:before{content:\"\uEA26\"}.sn-FUNC84:before{content:\"\uEA27\"}.sn-FUNC85:before{content:\"\uEA28\"}.sn-FUNC86:before{content:\"\uEA29\"}.sn-FUNC87:before{content:\"\uEA2A\"}.sn-FUNC88:before{content:\"\uEA2B\"}.sn-FUNC89:before{content:\"\uEA2C\"}.sn-FUNC90:before{content:\"\uEA2D\"}.sn-FUNC91:before{content:\"\uEA2E\"}.sn-FUNC92:before{content:\"\uEA2F\"}.sn-FUNC93:before{content:\"\uEA30\"}.sn-FUNC94:before{content:\"\uEA31\"}.sn-FUNC95:before{content:\"\uEA32\"}.sn-FUNC96:before{content:\"\uEA33\"}.sn-FUNC97:before{content:\"\uEA34\"}.sn-FUNC98:before{content:\"\uEA35\"}.sn-FUNC99:before{content:\"\uEA36\"}.sn-SERV01:before{content:\"\uEA37\"}.sn-SERV02:before{content:\"\uEA38\"}.sn-SERV03:before{content:\"\uEA39\"}.sn-SERV04:before{content:\"\uEA3A\"}.sn-SERV05:before{content:\"\uEA3B\"}.sn-SERV06:before{content:\"\uEA3C\"}.sn-SERV07:before{content:\"\uEA3D\"}.sn-SERV08:before{content:\"\uEA3E\"}.sn-SERV09:before{content:\"\uEA3F\"}.sn-SERV10:before{content:\"\uEA40\"}.sn-SERV11:before{content:\"\uEA41\"}.sn-SERV12:before{content:\"\uEA42\"}.sn-SERV13:before{content:\"\uEA43\"}.sn-SERV14:before{content:\"\uEA44\"}.sn-SERV15:before{content:\"\uEA45\"}.sn-SERV16:before{content:\"\uEA46\"}.sn-SERV17:before{content:\"\uEA47\"}.sn-SERV18:before{content:\"\uEA48\"}.sn-SERV19:before{content:\"\uEA49\"}.sn-SERV20:before{content:\"\uEA4A\"}.sn-SERV21:before{content:\"\uEA4B\"}.sn-SERV22:before{content:\"\uEA4C\"}.sn-SERV23:before{content:\"\uEA4D\"}.sn-SERV24:before{content:\"\uEA4E\"}.sn-SERV25:before{content:\"\uEA4F\"}.sn-SERV26:before{content:\"\uEA50\"}.sn-SERV27:before{content:\"\uEA51\"}.sn-SERV28:before{content:\"\uEA52\"}.sn-SERV29:before{content:\"\uEA53\"}.sn-SERV30:before{content:\"\uEA54\"}.sn-SERV31:before{content:\"\uEA55\"}.sn-SERV32:before{content:\"\uEA56\"}.sn-SERV33:before{content:\"\uEA57\"}.sn-SERV34:before{content:\"\uEA58\"}.sn-SERV35:before{content:\"\uEA59\"}.sn-SERV36:before{content:\"\uEA5A\"}.sn-SERV37:before{content:\"\uEA5B\"}.sn-SERV38:before{content:\"\uEA5C\"}.sn-SERV39:before{content:\"\uEA5D\"}.sn-SERV40:before{content:\"\uEA5E\"}.sn-SERV41:before{content:\"\uEA5F\"}.sn-SERV42:before{content:\"\uEA60\"}.sn-SERV43:before{content:\"\uEA61\"}.sn-SERV44:before{content:\"\uEA62\"}.sn-SERV45:before{content:\"\uEA63\"}.sn-SERV46:before{content:\"\uEA64\"}.sn-SERV47:before{content:\"\uEA65\"}.sn-SERV48:before{content:\"\uEA66\"}.sn-SERV49:before{content:\"\uEA67\"}.sn-SERV49B:before{content:\"\uEA68\"}.sn-SERV50:before{content:\"\uEA69\"}.sn-SERV51:before{content:\"\uEA6A\"}.sn-SERV52:before{content:\"\uEA6B\"}.sn-SERV53:before{content:\"\uEA6C\"}.sn-SERV54:before{content:\"\uEA6D\"}.sn-SERV55:before{content:\"\uEA6E\"}.sn-SERV56:before{content:\"\uEA6F\"}.sn-SMOV01:before{content:\"\uEA70\"}.sn-SMOV02:before{content:\"\uEA71\"}.sn-SMOV03:before{content:\"\uEA72\"}.sn-SMOV04:before{content:\"\uEA73\"}.sn-SMOV05:before{content:\"\uEA74\"}.sn-SMOV06:before{content:\"\uEA75\"}.sn-SMOV07:before{content:\"\uEA76\"}.sn-SMOV08:before{content:\"\uEA77\"}.sn-SMOV09:before{content:\"\uEA78\"}.sn-SMOV10:before{content:\"\uEA79\"}.sn-SMOV11:before{content:\"\uEA7A\"}.sn-SMOV12:before{content:\"\uEA7B\"}.sn-SMOV13:before{content:\"\uEA7C\"}.sn-SMOV14:before{content:\"\uEA8A\"}.sn-SMOV15:before{content:\"\uEA8B\"}.sn-SMOV16:before{content:\"\uEA8C\"}.sn-SMOV17:before{content:\"\uEA8D\"}.sn-SMOV18:before{content:\"\uEA8E\"}.sn-SYS01:before{content:\"\uEA7D\"}.sn-SYS02:before{content:\"\uEA7E\"}.sn-SYS03:before{content:\"\uEA7F\"}.sn-SYS04:before{content:\"\uEA80\"}.sn-SYS05:before{content:\"\uEA81\"}.sn-SYS06:before{content:\"\uEA82\"}.sn-SYS07:before{content:\"\uEA83\"}.sn-SYS08:before{content:\"\uEA84\"}.sn-SYS09:before{content:\"\uEA85\"}.sn-SYS10:before{content:\"\uEA86\"}.sn-SYS11:before{content:\"\uEA87\"}.sn-SYS12:before{content:\"\uEA88\"}.sn-SYS14:before{content:\"\uEA89\"}"]
                }] }
    ];
    IconComponent.propDecorators = {
        icon: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }]
    };
    return IconComponent;
}());

var IconModule = /** @class */ (function () {
    function IconModule() {
    }
    IconModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"]],
                    declarations: [IconComponent],
                    exports: [IconComponent]
                },] }
    ];
    return IconModule;
}());

var IconMenuComponent = /** @class */ (function () {
    function IconMenuComponent() {
    }
    IconMenuComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                    selector: 'sn-icon-menu',
                    template: "<div [class.active]=\"active\">\n    <sn-icon [icon]=\"icon\"></sn-icon>\n    <div *ngIf=\"label\">{{label}}</div>\n</div>\n",
                    styles: ["div{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;height:100%;width:100%}div sn-icon{color:#ec0000;font-size:32px;height:32px;line-height:32px}div div{font-size:13px;line-height:18px}:host(.active) div div{color:#ec0000}"]
                }] }
    ];
    IconMenuComponent.propDecorators = {
        icon: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
        label: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
        active: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }]
    };
    return IconMenuComponent;
}());

var IconMenuModule = /** @class */ (function () {
    function IconMenuModule() {
    }
    IconMenuModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                    imports: [
                        _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                        IconModule,
                    ],
                    declarations: [
                        IconMenuComponent,
                    ],
                    exports: [
                        IconMenuComponent
                    ]
                },] }
    ];
    return IconMenuModule;
}());

var HeaderComponent = /** @class */ (function () {
    function HeaderComponent() {
    }
    HeaderComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                    selector: 's-header',
                    template: "<img src=\"assets/images/santander-logo.svg\" alt=\"Santander\">\n<span>\n    <img src=\"assets/images/secure-banking.svg\" alt=\"Secure\" secure>\n</span>\n",
                    host: {
                        role: 'header'
                    },
                    styles: [":host(){display:block;height:78px;box-sizing:border-box;background-color:#fff;border-bottom:1px solid #979797}:host() img{height:25px;padding-left:32px;padding-top:24px}:host() span{display:none}:host([secure]) span{display:contents}:host([secure]) span img{padding-right:24px;float:right;padding-top:24px;height:25px;padding-left:8px}"]
                }] }
    ];
    return HeaderComponent;
}());

var HeaderModule = /** @class */ (function () {
    function HeaderModule() {
    }
    HeaderModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                    imports: [],
                    declarations: [HeaderComponent],
                    exports: [HeaderComponent]
                },] }
    ];
    return HeaderModule;
}());

var MenuHeaderComponent = /** @class */ (function () {
    function MenuHeaderComponent() {
        this.onMenuClick = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
        this.onMenuBack = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
    }
    MenuHeaderComponent.prototype.onMenuBtn = function () {
        this.onMenuClick.emit(true);
    };
    MenuHeaderComponent.prototype.onBackBtn = function () {
        this.onMenuBack.emit(true);
    };
    MenuHeaderComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                    selector: 'sn-menu-header',
                    template: "<div class=\"container\">\n    <sn-icon icon=\"sn-SYS14\" (click)=\"onBackBtn()\"></sn-icon>\n    <span>{{title}}</span>\n    <sn-icon icon=\"sn-SYS12\" (click)=\"onMenuBtn()\"></sn-icon>\n</div>",
                    host: {
                        role: 'header'
                    },
                    styles: [":host{color:#ec0000}:host .container{height:56px;display:flex;flex-flow:row nowrap;align-items:center}:host span{flex:1 1 auto;text-align:center;font-weight:700;font-size:18px}sn-icon{font-size:24px;margin:0 16px;cursor:pointer}"]
                }] }
    ];
    MenuHeaderComponent.propDecorators = {
        title: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
        onMenuClick: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"] }],
        onMenuBack: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"] }]
    };
    return MenuHeaderComponent;
}());

var MenuHeaderModule = /** @class */ (function () {
    function MenuHeaderModule() {
    }
    MenuHeaderModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                    imports: [_angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"], IconModule],
                    declarations: [MenuHeaderComponent],
                    exports: [MenuHeaderComponent]
                },] }
    ];
    return MenuHeaderModule;
}());

var TabBarComponent = /** @class */ (function () {
    function TabBarComponent() {
        this.click = new _angular_core__WEBPACK_IMPORTED_MODULE_2__["EventEmitter"]();
    }
    TabBarComponent.prototype.onClick = function (item) {
        this.click.emit(item);
    };
    TabBarComponent.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"], args: [{
                    selector: 'sn-tabbar',
                    template: "    <div>\n        <sn-icon-menu \n        [icon]=\"item.icon\" \n        [label]=\"item.name\" \n        *ngFor=\"let item of options\"\n        (click)=\"onClick(item)\" \n        ></sn-icon-menu>\n    </div>",
                    styles: [":host{background-color:#f7fbfc;border-top:1px solid #cedee7;border-bottom:1px solid #cedee7;min-height:78px;position:relative;display:flex}:host div{width:100%;display:inline-flex;align-items:center;padding:12px 0}:host sn-icon-menu{border-right:1px solid #cedee7;height:100%;margin-right:-1px;flex:1;padding:0 4px}:host sn-icon-menu:last-child{border:0;margin-right:0}"]
                }] }
    ];
    TabBarComponent.propDecorators = {
        options: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Input"] }],
        click: [{ type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Output"], args: ['on-click',] }]
    };
    return TabBarComponent;
}());

var TabBaruModule = /** @class */ (function () {
    function TabBaruModule() {
    }
    TabBaruModule.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"], args: [{
                    imports: [
                        _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                        IconMenuModule
                    ],
                    declarations: [
                        TabBarComponent,
                    ],
                    exports: [
                        TabBarComponent
                    ]
                },] }
    ];
    return TabBaruModule;
}());

var CallbackIntegrationService = /** @class */ (function () {
    function CallbackIntegrationService() {
        this._events = { _main: new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]() };
        window.addEventListener('main', this.mainHandle.bind(this), false);
    }
    CallbackIntegrationService.prototype.onMain = function () {
        return this._events._main.asObservable();
    };
    CallbackIntegrationService.prototype.onEvent = function (event) {
        if (!this._events.hasOwnProperty(event)) {
            this._events[event] = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        }
        window.addEventListener(event, this.eventHandle.bind(this), false);
        return this._events[event].asObservable();
    };
    CallbackIntegrationService.prototype.ngOnDestroy = function () {
        window.removeEventListener('main', this.mainHandle.bind(this));
        delete this._events._main;
        for (var key in this._events) {
            if (this._events.hasOwnProperty(key)) {
                window.removeEventListener(key, this.mainHandle.bind(this));
            }
        }
    };
    // **
    // * funcion para enviar evento
    // **
    // function dispatchCustomEvent(value) {
    //   var event = new CustomEvent('main', { 'detail': value });
    //   window.dispatchEvent(event);
    // }
    CallbackIntegrationService.prototype.mainHandle = function (data) {
        this._events._main.next(data.detail);
    };
    CallbackIntegrationService.prototype.eventHandle = function (data) {
        this._events[data.type].next(data.detail);
    };
    CallbackIntegrationService.decorators = [
        { type: _angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"], args: [{
                    providedIn: 'root'
                },] }
    ];
    /** @nocollapse */
    CallbackIntegrationService.ctorParameters = function () { return []; };
    CallbackIntegrationService.ngInjectableDef = Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["defineInjectable"])({ factory: function CallbackIntegrationService_Factory() { return new CallbackIntegrationService(); }, token: CallbackIntegrationService, providedIn: "root" });
    return CallbackIntegrationService;
}());

/*
 * Public API Surface of @santander/components-library
 */

/**
 * Generated bundle index. Do not edit.
 */



//# sourceMappingURL=santander-components-library.js.map

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./modules/demo/demo.module": [
		"./src/app/modules/demo/demo.module.ts",
		"modules-demo-demo-module"
	],
	"./modules/transations/transations.module": [
		"./src/app/modules/transations/transations.module.ts",
		"modules-transations-transations-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return __webpack_require__.e(ids[1]).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/app/app.component.css":
/*!***********************************!*\
  !*** ./src/app/app.component.css ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIn0= */"

/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<!--The content below is only a placeholder and can be replaced.-->\n\n\n<sn-menu-header title=\"Accounts\"></sn-menu-header>\n<div class=\"container\">\n  <router-outlet #router=\"outlet\"></router-outlet>\n\n\n</div>\n"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _santander_components_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @santander/components-library */ "./dist/@santander/components-library/fesm5/santander-components-library.js");



var AppComponent = /** @class */ (function () {
    function AppComponent(currencyService) {
        this.currencyService = currencyService;
    }
    AppComponent.prototype.ngOnInit = function () {
        this.currencyService.setCurrency(_santander_components_library__WEBPACK_IMPORTED_MODULE_2__["CountryEnum"].GB);
    };
    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.css */ "./src/app/app.component.css")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_santander_components_library__WEBPACK_IMPORTED_MODULE_2__["CurrencyService"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _santander_components_library__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @santander/components-library */ "./dist/@santander/components-library/fesm5/santander-components-library.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./app.routing.module */ "./src/app/app.routing.module.ts");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");







var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            declarations: [
                _app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]
            ],
            imports: [
                _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"],
                _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"],
                _santander_components_library__WEBPACK_IMPORTED_MODULE_4__["MenuHeaderModule"],
            ],
            providers: [
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_6__["APP_BASE_HREF"], useValue: '/' },
                { provide: _angular_common__WEBPACK_IMPORTED_MODULE_6__["LocationStrategy"], useClass: _angular_common__WEBPACK_IMPORTED_MODULE_6__["HashLocationStrategy"] },
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_3__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/app.routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app.routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");



var routes = [
    // { path: 'access', component: AccesViewComponent },
    { path: 'transations',
        // component: AccountComponent
        loadChildren: './modules/transations/transations.module#TransationsModule',
    },
    { path: 'demo',
        loadChildren: './modules/demo/demo.module#DemoModule',
    },
    { path: '', redirectTo: '/transations', pathMatch: 'full' },
    { path: '**', redirectTo: '/demo', pathMatch: 'full' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { useHash: true })
            ],
            // imports: [RouterModule.forRoot(routes)],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.error(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /develop/Santander/Globale/Front/StarterApp-Angular/src/main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map