import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
// import {  SHeaderComponentModule } from '@santander/s-common';
import { HeaderComponent, SHeaderComponentModule } from '@santander/s-common';


@NgModule({
  declarations: [
    HeaderComponent,
    AppComponent,
  ],
  imports: [
    BrowserModule,
    // SHeaderComponentModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
