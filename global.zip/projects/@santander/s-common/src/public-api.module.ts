import { NgModule } from '@angular/core';
import { SHeaderComponentModule } from './components';
// import { HeaderComponent } from './components/header/header.component';


@NgModule({
  exports: [
    SHeaderComponentModule,
    // HeaderComponent
  ]
})

export class SCommonModule { }
