import { TestBed } from '@angular/core/testing';

import { SCommonService } from './s-common.service';

describe('SCommonService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SCommonService = TestBed.get(SCommonService);
    expect(service).toBeTruthy();
  });
});
