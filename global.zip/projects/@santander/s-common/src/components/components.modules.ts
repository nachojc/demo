export { SHeaderComponentModule as SHeaderComponentModule} from './header/header.module';
