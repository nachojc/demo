import * as mockSimpleWealthAdvicePaymentResponse from '@src/api-mock/responses/FinancialAdvicePayment/FinancialAdvicePayment-Success.json';
import { axios } from '@utils/api';

import {
  SimpleWealthAdvicePayment,
  SimpleWealthAdvicePaymentRequest,
} from '../simple-wealth-advice-payment';

const simpleWealthAdvicePaymentModel = new SimpleWealthAdvicePayment();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      post: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

const mockRequest: SimpleWealthAdvicePaymentRequest = {
  payment: {
    idempotentKey: '',
    transactionId: '',
    requestType: 'CardDetails',
    redirectUrl: '',
    channel: '',
    psp: '',
    pspData: '',
    correlationId: '',
  },
  secureOpportunityId: '',
  address: {
    line1: 'Address Line 1',
    postalCode: 'NR1 1NG',
    postalTownCity: 'Norwich',
    county: 'Norfolk',
    country: 'United Kingdom',
  },
};

describe('Aviva Simple Wealth Advice Payment Model', () => {
  it('should call correct endpoint', async () => {
    mockedAxios.post.mockImplementation(() =>
      Promise.resolve({ data: mockSimpleWealthAdvicePaymentResponse.content })
    );

    await simpleWealthAdvicePaymentModel.makePayment(mockRequest);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/navigator/financialAdvicePayment',
      mockRequest
    );
  });
});
