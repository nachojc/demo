import { axios } from '@utils/api';

import { CreateSimpleWealthAccountModel } from '../create-simple-wealth-account';

const createSimpleWealthAccountModel = new CreateSimpleWealthAccountModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      post: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('CreateSimpleWealthAccountModel', () => {
  it('should call correct endpoint', async () => {
    mockedAxios.post.mockImplementation(() => Promise.resolve());

    await createSimpleWealthAccountModel.createAccount();

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/navigator/account'
    );
  });
});
