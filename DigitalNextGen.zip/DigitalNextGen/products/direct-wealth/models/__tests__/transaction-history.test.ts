import * as CashTransactionHistoryData from '@src/api-mock/responses/DirectWealth/TransactionHistory/Cash/cash_transaction_history.json';
import * as ProductTransactionHistoryData from '@src/api-mock/responses/DirectWealth/TransactionHistory/Product/product_transaction_history.json';
import { axios } from '@utils/api';

import { TransactionHistoryModel } from '../transaction-history';

const transactionHistoryModel = new TransactionHistoryModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Transaction History Model', () => {
  it('should send the request correctly with passed props for product', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: ProductTransactionHistoryData.content,
      })
    );

    await transactionHistoryModel.fetchTransactionHistory(
      'test-secure-policy-number',
      'investmentTransactionHistory',
      1,
      ['Filter1', 'Filter2']
    );

    expect(mockedAxios.get).toHaveBeenLastCalledWith(
      '/MessagingApi/api/v1/directWealth/subAccount/test-secure-policy-number/investmentTransactionHistory?Page=1&Filter=Filter1|Filter2'
    );
  });

  it('should send the request correctly with passed props for cash', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: CashTransactionHistoryData.content,
      })
    );

    await transactionHistoryModel.fetchTransactionHistory(
      'test-secure-policy-number',
      'cashTransactionHistory',
      2
    );

    expect(mockedAxios.get).toHaveBeenLastCalledWith(
      '/MessagingApi/api/v1/directWealth/subAccount/test-secure-policy-number/cashTransactionHistory?Page=2'
    );
  });
});
