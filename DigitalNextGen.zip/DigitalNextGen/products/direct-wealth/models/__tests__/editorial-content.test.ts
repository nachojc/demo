import * as EditorialContentData from '@src/api-mock/responses/DirectWealth/EditorialContent/Editorial_Content.json';
import { axios } from '@utils/api';

import { EditorialContentModel } from '../editorial-content';

const editorialContentModel = new EditorialContentModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Editorial Content Model', () => {
  it('should send the request correctly with passed context and userUnderstanding', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: EditorialContentData.content,
      })
    );

    await editorialContentModel.fetchEditorialContent(
      'PortfolioSummary',
      'Novice'
    );

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/content/en-GB/direct-wealth/editorial_content/v1/PortfolioSummary?userUnderstanding=Novice'
    );
  });
});
