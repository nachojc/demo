import * as FindAndCombineCustomerDetails from '@src/api-mock/responses/DirectWealth/FindAndCombineCustomerDetails/FindAndCombineCustomerDetailsHasPensionCompleteDetails.json';
import { axios } from '@utils/api';

import { FindAndCombineCustomerDetailsModel } from '../find-and-combine-customer-details';

const mockedAxios = axios as jest.Mocked<typeof axios>;
const findAndCombineCustomerDetailsModel =
  new FindAndCombineCustomerDetailsModel();

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Find and Combine Customer Details Model', () => {
  it('should send the request correctly with passed context', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: FindAndCombineCustomerDetails.content,
      })
    );

    await findAndCombineCustomerDetailsModel.fetchFindAndCombineCustomerDetails();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/findAndCombine/details'
    );
  });
});
