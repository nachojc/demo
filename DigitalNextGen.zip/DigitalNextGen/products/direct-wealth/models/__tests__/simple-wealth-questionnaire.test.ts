import * as SimpleWealthData from '@src/api-mock/responses/DirectWealth/NavigatorServiceGet/questionnaire-complete.json';
import * as SimpleWealthQuestionnaireResponse from '@src/api-mock/responses/DirectWealth/SubmitNavigatorQuestionnaire/SubmitNavigatorQuestionnaireSuccessRiskLevel1.json';
import { axios } from '@utils/api';

import { SimpleWealthQuestionnaireModel } from '../simple-wealth-questionnaire';

const simpleWealthQuestionnaireModel = new SimpleWealthQuestionnaireModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;
const mockQuestionnaireData = SimpleWealthData.content.questionnaireResponses;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      post: jest.fn(),
      put: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Aviva Simple Wealth Model', () => {
  it('should call correct endpoint for submit', async () => {
    mockedAxios.post.mockImplementation(() =>
      Promise.resolve({
        data: SimpleWealthQuestionnaireResponse.content,
      })
    );

    await simpleWealthQuestionnaireModel.submitQuestionnaire(
      mockQuestionnaireData
    );

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/navigator/factFindQuestionnaire',
      SimpleWealthData.content.questionnaireResponses
    );
  });

  it('should call correct endpoint for adjust', async () => {
    mockedAxios.put.mockImplementation(() =>
      Promise.resolve({
        data: SimpleWealthQuestionnaireResponse.content,
      })
    );

    await simpleWealthQuestionnaireModel.adjustQuestionnaire(
      mockQuestionnaireData
    );

    expect(mockedAxios.put).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/navigator/factFindQuestionnaire',
      SimpleWealthData.content.questionnaireResponses
    );
  });
});
