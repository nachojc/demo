import * as FAQs from '@src/api-mock/responses/DirectWealth/FAQs/FAQs.json';
import { axios } from '@utils/api';

import { FAQsModel } from '../faqs';

const faqsModel = new FAQsModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('FAQs Model', () => {
  it('should send the request correctly with passed context', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: FAQs.content,
      })
    );

    await faqsModel.fetchFAQs('PensionConsolidationSummary');

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/content/en-GB/direct-wealth/faqs/v1/PensionConsolidationSummary'
    );
  });
});
