import * as DirectWealthAccountData from '@src/api-mock/responses/DirectWealth/account/Default_account.json';
import { axios } from '@utils/api';

import { DirectWealthAccountModel } from '../direct-wealth-account';

const directWealthAccountModel = new DirectWealthAccountModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Account Model', () => {
  it('should send the request correctly with passed secureAccountNumber', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: DirectWealthAccountData.content,
      })
    );

    await directWealthAccountModel.fetchDirectWealthAccount(
      'test-secure-account-number'
    );

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      `/MessagingApi/api/v1/directWealth/account/test-secure-account-number`
    );
  });
});
