import * as FindAndCombinePensionProviders from '@src/api-mock/responses/DirectWealth/FindAndCombinePensionProviders/FindAndCombinePensionProviders.json';
import { axios } from '@utils/api';

import { FindAndCombinePensionProvidersModel } from '../find-and-combine-pension-providers';

const mockedAxios = axios as jest.Mocked<typeof axios>;
const findAndCombinePensionProvidersModel =
  new FindAndCombinePensionProvidersModel();

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Pension Providers Model', () => {
  it('should send the request correctly with passed context', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: FindAndCombinePensionProviders.content,
      })
    );

    await findAndCombinePensionProvidersModel.fetchFindAndCombinePensionProviders();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/findAndCombine/pensionProviders'
    );
  });
});
