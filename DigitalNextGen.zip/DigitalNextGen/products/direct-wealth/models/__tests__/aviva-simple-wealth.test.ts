import * as AvivaSimpleWealthData from '@src/api-mock/responses/DirectWealth/NavigatorServiceGet/payment-complete.json';
import { axios } from '@utils/api';

import { AvivaSimpleWealthModel } from '../aviva-simple-wealth';

const avivaSimpleWealthModel = new AvivaSimpleWealthModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Aviva Simple Wealth Model', () => {
  it('should call correct endpoint', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: AvivaSimpleWealthData.content,
      })
    );

    await avivaSimpleWealthModel.fetchAvivaSimpleWealth();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/navigator/'
    );
  });
});
