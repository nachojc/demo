import * as SimpleWealthSuitabilityReportData from '@src/api-mock/responses/DirectWealth/NavigatorSuitabilityReport/NavigatorSuitibilityReportSuccess.json';
import { axios } from '@utils/api';

import { SimpleWealthSuitabilityReportModel } from '../simple-wealth-suitability-report';

const simpleWealthSuitabilityReportModel =
  new SimpleWealthSuitabilityReportModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Simple Wealth Suitability Report Model', () => {
  it('should call correct endpoint', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: SimpleWealthSuitabilityReportData.content,
      })
    );

    await simpleWealthSuitabilityReportModel.getSuitabilityReport('id');

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/navigator/suitabilityReport/id'
    );
  });
});
