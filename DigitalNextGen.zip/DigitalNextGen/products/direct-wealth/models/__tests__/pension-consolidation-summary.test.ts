import * as PCSSuccess from '@src/api-mock/responses/DirectWealth/PensionConsolidationSummary/PCSSuccess.json';
import { axios } from '@utils/api';
import { ZodError } from 'zod';

import { PensionConsolidationSummaryModel } from '../pension-consolidation-summary';

const pensionConsolidationSummaryModel = new PensionConsolidationSummaryModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Pension Consolidation Summary Model', () => {
  it('should send the request correctly', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: PCSSuccess.content,
      })
    );

    await pensionConsolidationSummaryModel.fetchPensionConsolidationSummary();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/directWealth/pensionConsolidationSummary'
    );
  });

  it('should throw error if data was parsed unsuccessfully', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: null,
      })
    );

    await expect(
      pensionConsolidationSummaryModel.fetchPensionConsolidationSummary()
    ).rejects.toThrow(ZodError);
  });
});
