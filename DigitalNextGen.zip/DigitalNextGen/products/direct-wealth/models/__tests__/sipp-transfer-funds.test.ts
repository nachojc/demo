import * as DefaultSippTransferFunds from '@src/api-mock/responses/DirectWealth/SippTransferFunds/sipp-transfer-funds.json';
import * as DefaultUniversalFund from '@src/api-mock/responses/DirectWealth/SIPPUniversalFund/sipp-universal-fund.json';
import { axios } from '@utils/api';

import { SippTransferFundsModel } from '../sipp-transfer-funds';

const sippTransferFundsModel = new SippTransferFundsModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      post: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('Sipp Transfer Fund Model', () => {
  it('should send the request correctly for fetchSippTransferFunds', async () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: DefaultSippTransferFunds.content,
      })
    );

    await sippTransferFundsModel.fetchSippTransferFunds();

    expect(mockedAxios.get).toHaveBeenCalledWith(
      '/MessagingApi/api/v1/directWealth/sippTransferIn/readyMadeFunds'
    );
  });

  it('should send the request correctly for fetchUniversalFund', async () => {
    mockedAxios.post.mockImplementation(() =>
      Promise.resolve({
        data: DefaultUniversalFund.content,
      })
    );

    await sippTransferFundsModel.fetchUniversalFund(67);

    expect(mockedAxios.post).toHaveBeenCalledWith(
      '/MessagingApi/api/v1/directWealth/sippTransferIn/universalRetirementFund',
      {
        RetirementAge: 67,
      }
    );
  });
});
