import { axios } from '@utils/api';

import {
  DirectWealthAccount,
  DirectWealthAccountSchema,
} from '../validation/schemas/direct-wealth-account';

const DW_ACCOUNT_PATH = '/MessagingApi/api/v1/directWealth/account';

export class DirectWealthAccountModel {
  async fetchDirectWealthAccount(
    secureAccountNumber?: string
  ): Promise<DirectWealthAccount> {
    const { data } = await axios.get(
      `${DW_ACCOUNT_PATH}/${secureAccountNumber}`
    );

    const result = DirectWealthAccountSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
