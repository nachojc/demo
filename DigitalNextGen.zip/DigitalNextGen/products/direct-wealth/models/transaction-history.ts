import { axios } from '@utils/api';

import {
  TransactionHistory,
  TransactionHistorySchema,
} from '../validation/schemas/transaction-history';

// eslint-disable-next-line @typescript-eslint/naming-convention
export type TransactionHistoryType =
  | 'investmentTransactionHistory'
  | 'cashTransactionHistory';

export class TransactionHistoryModel {
  async fetchTransactionHistory(
    securePolicyNumber: string,
    transactionHistoryType: TransactionHistoryType,
    page?: number,
    filters?: string[]
  ): Promise<TransactionHistory> {
    const filterParams =
      filters && filters.length > 0 ? `&Filter=${filters?.join('|')}` : '';

    const url =
      `/MessagingApi/api/v1/directWealth/subAccount/${securePolicyNumber}/${transactionHistoryType}?Page=${page}${filterParams}`.trim();

    const { data } = await axios.get(url);

    const result = TransactionHistorySchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
