import { axios } from '@utils/api';

import {
  DirectWealthSubaccountISAAllowance,
  DirectWealthSubaccountISAAllowanceSchema,
} from '../validation/schemas/direct-wealth-subaccount';

export class DirectWealthSubaccountISAAllowanceModel {
  async fetchDirectWealthSubaccountISAAllowance(
    securePolicyNumber: string
  ): Promise<DirectWealthSubaccountISAAllowance> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/subAccount/${securePolicyNumber}/isaAllowance`
    );
    const result = DirectWealthSubaccountISAAllowanceSchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
