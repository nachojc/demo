import {
  IsaDocument,
  IsaDocumentSchema,
} from '@direct-wealth/validation/schemas/isa-document';
import { axios } from '@utils/api';

export class IsaDocumentModel {
  async fetchIsaDocument(id: string): Promise<IsaDocument> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/isaDocument/${id}`
    );
    const result = IsaDocumentSchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
