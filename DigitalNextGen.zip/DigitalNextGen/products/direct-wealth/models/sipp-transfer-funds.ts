import { axios } from '@utils/api';

import {
  SippTransferFunds,
  SippTransferFundsSchema,
} from '../validation/schemas/sipp-transfer-funds';
import {
  SippUniversalFund,
  SippUniversalFundSchema,
} from '../validation/schemas/sipp-universal-funds';

export class SippTransferFundsModel {
  async fetchSippTransferFunds(): Promise<SippTransferFunds> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/sippTransferIn/readyMadeFunds`
    );

    const result = SippTransferFundsSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }

  async fetchUniversalFund(retirementAge: number): Promise<SippUniversalFund> {
    const { data } = await axios.post(
      `/MessagingApi/api/v1/directWealth/sippTransferIn/universalRetirementFund`,
      {
        RetirementAge: retirementAge,
      }
    );

    const result = SippUniversalFundSchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
