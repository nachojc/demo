import {
  PensionConsolidationDetails,
  PensionConsolidationDetailsSchema,
} from '@direct-wealth/validation/schemas/pension-consolidation-details';
import { axios } from '@utils/api';

export class PensionConsolidationDetailsModel {
  async fetchPensionConsolidationDetails(
    secureId?: string
  ): Promise<PensionConsolidationDetails> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/pensionConsolidationDetails/${secureId}`
    );
    const result = PensionConsolidationDetailsSchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
