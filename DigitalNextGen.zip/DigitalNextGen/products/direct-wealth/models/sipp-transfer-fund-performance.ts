import { axios } from '@utils/api';

import {
  SIPPTransferFundPerformance,
  SIPPTransferFundPerformanceSchema,
} from '../validation/schemas/sipp-transfer-fund-performance';

export class SIPPTransferFundPerformanceModel {
  async fetchSIPPTransferFundPerformance(
    fundId: string
  ): Promise<SIPPTransferFundPerformance> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/sippTransferIn/fundPerformance/${fundId}`
    );
    const result = SIPPTransferFundPerformanceSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
