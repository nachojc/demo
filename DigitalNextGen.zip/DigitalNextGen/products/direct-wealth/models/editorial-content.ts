import { axios } from '@utils/api';

import {
  EditorialContent,
  EditorialContentResponseSchema,
} from '../validation/schemas/editorial-content';

export type UserUnderstanding = 'Novice' | 'Experienced';

export class EditorialContentModel {
  async fetchEditorialContent(
    context?: string,
    userUnderstanding?: UserUnderstanding
  ): Promise<EditorialContent> {
    const userUnderstandingParam = userUnderstanding
      ? `?userUnderstanding=${userUnderstanding}`
      : '';

    const { data } = await axios.get(
      `/MessagingApi/api/v1/content/en-GB/direct-wealth/editorial_content/v1/${context}${userUnderstandingParam}`
    );

    const result = EditorialContentResponseSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data.content;
  }
}
