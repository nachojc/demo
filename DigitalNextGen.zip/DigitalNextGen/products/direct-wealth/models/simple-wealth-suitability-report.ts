import {
  SimpleWealthSuitabilityReport,
  SimpleWealthSuitabilityReportSchema,
} from '@direct-wealth/validation/schemas/simple-wealth-suitability-report';
import { axios } from '@utils/api';

export class SimpleWealthSuitabilityReportModel {
  async getSuitabilityReport(
    secureSuitabilityReportId: string
  ): Promise<SimpleWealthSuitabilityReport> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/navigator/suitabilityReport/${secureSuitabilityReportId}`
    );
    const result = SimpleWealthSuitabilityReportSchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
