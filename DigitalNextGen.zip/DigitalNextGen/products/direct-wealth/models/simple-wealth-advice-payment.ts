import { SimpleWealthAdvicePaymentResponseSchema } from '@direct-wealth/features/simple-wealth/payment/validation/schemas/simple-wealth-advice-payment';
import { axios } from '@utils/api';

export type SimpleWealthAdvicePaymentRequest = {
  payment: {
    idempotentKey: string;
    transactionId: string;
    requestType: 'CardDetails' | 'ThreeDS2';
    redirectUrl: string;
    channel: string;
    psp: string;
    pspData: string;
    previousPspResponseData?: string | null;
    correlationId: string;
  };
  secureOpportunityId: string;
  middleName?: string | null;
  address: {
    line1: string;
    line2?: string | null;
    line3?: string | null;
    postalCode: string;
    county: string;
    postalTownCity: string;
    country: string;
  };
};

export class SimpleWealthAdvicePayment {
  async makePayment(paymentRequest: SimpleWealthAdvicePaymentRequest) {
    const { data } = await axios.post(
      '/MessagingApi/api/v1/directWealth/navigator/financialAdvicePayment',
      paymentRequest
    );

    return SimpleWealthAdvicePaymentResponseSchema.parse(data);
  }
}
