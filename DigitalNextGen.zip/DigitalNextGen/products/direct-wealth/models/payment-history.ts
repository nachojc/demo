import { axios } from '@utils/api';

import {
  PaymentHistory,
  PaymentHistorySchema,
} from '../validation/schemas/payment-history';

export class PaymentHistoryModel {
  async fetchPaymentHistory(
    secureAccountNumber?: string
  ): Promise<PaymentHistory> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/subAccount/${secureAccountNumber}/paymentHistory`
    );

    const result = PaymentHistorySchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
