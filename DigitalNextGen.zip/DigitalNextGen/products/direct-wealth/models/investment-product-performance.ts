import { axios } from '@utils/api';

import { ChartTimescale } from '../common/hooks/use-investment-product-performance';
import {
  InvestmentProductPerformance,
  InvestmentProductPerformanceSchema,
} from '../validation/schemas/investment-product-performance';

export class InvestmentProductPerformanceModel {
  async fetchInvestmentProductPerformance(
    securePolicyNumber: string,
    timescale: ChartTimescale
  ): Promise<InvestmentProductPerformance> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/subAccount/${securePolicyNumber}/investmentProductPerformance?Timescale=${timescale}`
    );
    const result = InvestmentProductPerformanceSchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
