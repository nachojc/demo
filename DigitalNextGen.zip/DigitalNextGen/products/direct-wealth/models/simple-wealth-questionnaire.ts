import { Question } from '@direct-wealth/features/simple-wealth/navigation/provider/state/fact-find';
import { AvivaSimpleWealthProjectionSchema } from '@direct-wealth/validation/schemas/aviva-simple-wealth';
import { axios } from '@utils/api';

export type QuestionnaireData = {
  questionnaireId: string;
  stage: string;
  responses?: Question[];
};

export class SimpleWealthQuestionnaireModel {
  async submitQuestionnaire(questionnaireData: QuestionnaireData) {
    const { data } = await axios.post(
      '/MessagingApi/api/v1/directWealth/navigator/factFindQuestionnaire',
      questionnaireData
    );

    return AvivaSimpleWealthProjectionSchema.parse(data);
  }

  async adjustQuestionnaire(questionnaireData: QuestionnaireData) {
    const { data } = await axios.put(
      '/MessagingApi/api/v1/directWealth/navigator/factFindQuestionnaire',
      questionnaireData
    );

    return AvivaSimpleWealthProjectionSchema.parse(data);
  }
}
