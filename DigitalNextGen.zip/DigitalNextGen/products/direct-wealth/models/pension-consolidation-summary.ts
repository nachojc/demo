import {
  PensionConsolidationSummary,
  PensionConsolidationSummarySchema,
} from '@direct-wealth/validation/schemas/pension-consolidation-summary';
import { axios } from '@utils/api';

export class PensionConsolidationSummaryModel {
  async fetchPensionConsolidationSummary(): Promise<PensionConsolidationSummary> {
    const { data } = await axios.get(
      '/MessagingApi/api/v1/directWealth/pensionConsolidationSummary'
    );

    const result = PensionConsolidationSummarySchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
