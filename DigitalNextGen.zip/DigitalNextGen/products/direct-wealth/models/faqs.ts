import {
  FAQ,
  FAQsSchema,
  OpenAnIsaFAQ,
  OpenAnIsaFAQsSchema,
} from '@direct-wealth/validation/schemas/faqs';
import { axios } from '@utils/api';

const normalizeOpenAnIsaResponseData = (data: OpenAnIsaFAQ[]): FAQ[] => {
  return data.map((obj) => {
    return { question: obj.Question, answer: obj.Response };
  });
};

export class FAQsModel {
  async fetchFAQs(context?: string): Promise<FAQ[]> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/content/en-GB/direct-wealth/faqs/v1/${context}`
    );

    const result = FAQsSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data.faqs;
  }

  async fetchOpenAnIsaFAQs(): Promise<FAQ[]> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/content/en-GB/direct-wealth/isa_faqs/v1`
    );

    const result = OpenAnIsaFAQsSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return normalizeOpenAnIsaResponseData(result.data.Content);
  }
}
