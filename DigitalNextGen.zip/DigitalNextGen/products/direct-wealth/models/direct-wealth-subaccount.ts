import { axios } from '@utils/api';

import {
  DirectWealthSubaccount,
  DirectWealthSubaccountSchema,
} from '../validation/schemas/direct-wealth-subaccount';

export class DirectWealthSubaccountModel {
  async fetchDirectWealthSubaccount(
    securePolicyNumber: string
  ): Promise<DirectWealthSubaccount> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/subAccount/${securePolicyNumber}`
    );
    const result = DirectWealthSubaccountSchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
