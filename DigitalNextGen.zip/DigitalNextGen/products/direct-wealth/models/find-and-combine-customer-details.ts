import {
  CustomerDetails,
  CustomerDetailsSchema,
} from '@direct-wealth/validation/schemas/find-and-combine/customer-details';
import { axios } from '@utils/api';

export class FindAndCombineCustomerDetailsModel {
  async fetchFindAndCombineCustomerDetails(): Promise<CustomerDetails> {
    const { data } = await axios.get(
      '/MessagingApi/api/v1/directWealth/findAndCombine/details'
    );

    const result = CustomerDetailsSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
