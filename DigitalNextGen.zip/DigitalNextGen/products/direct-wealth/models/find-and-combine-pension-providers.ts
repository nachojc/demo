import {
  PensionProviders,
  PensionProvidersSchema,
} from '@direct-wealth/validation/schemas/find-and-combine/pension-providers';
import { axios } from '@utils/api';

export class FindAndCombinePensionProvidersModel {
  async fetchFindAndCombinePensionProviders(): Promise<PensionProviders> {
    const { data } = await axios.get(
      '/MessagingApi/api/v1/directWealth/findAndCombine/pensionProviders'
    );

    const result = PensionProvidersSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
