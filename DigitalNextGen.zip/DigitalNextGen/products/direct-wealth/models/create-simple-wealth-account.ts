import { axios } from '@utils/api';

export class CreateSimpleWealthAccountModel {
  async createAccount() {
    await axios.post('/MessagingApi/api/v1/directWealth/navigator/account');
  }
}
