import { TopAppBarDW } from '@aviva/ion-mobile';
import { PortfolioSummaryHeader } from '@direct-wealth/components/portfolio-header';
import { PortfolioSummaryScreen } from '@direct-wealth/features/portfolio-summary';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import { TopAppBarIDV } from '@src/features/idv/components/idv-header/idv-header';

export type DirectWealthTabStackRouteParams = {
  ['PortfolioSummary']: undefined;
  ['Unlock Portfolio']: undefined;
  ['Consent Screen']: undefined;
  ['Choose ID Screen']: undefined;
  ['IDV Error Screen']: undefined;
  ['Issuing Country']: { PartyId: string; SecurePolicyNumber: string };
  ['Privacy Policy']: undefined;
  ['Privacy Notice']: undefined;
  ['Aviva Co Uk']: undefined;
  ['Ico Org Uk']: undefined;
  ['app']: { screen: string };
};
export type DirectWealthTabStackScreenNames =
  keyof DirectWealthTabStackRouteParams;

const Stack = createNativeStackNavigator<DirectWealthTabStackRouteParams>();

export const DirectWealthTabStack = () => {
  return (
    <Stack.Navigator screenOptions={{ header: TopAppBarDW }}>
      <Stack.Screen
        name="PortfolioSummary"
        component={PortfolioSummaryScreen}
        options={{ header: PortfolioSummaryHeader }}
      />
      <Stack.Group
        screenOptions={{
          title: 'Identity verification',
          header: TopAppBarIDV,
        }}
      >
        <Stack.Screen
          name="Unlock Portfolio"
          getComponent={() =>
            require('@src/features/idv').UnlockPortfolioScreen
          }
        />
        <Stack.Screen
          name="Consent Screen"
          getComponent={() => require('@src/features/idv').ConsentScreen}
        />
        <Stack.Screen
          name="Choose ID Screen"
          getComponent={() => require('@src/features/idv').ChooseIdScreen}
        />
        <Stack.Screen
          name="Issuing Country"
          getComponent={() =>
            require('@src/features/idv/choose-id/issuing-country-screen')
              .IssuingCountryScreen
          }
        />
        <Stack.Screen
          name="IDV Error Screen"
          getComponent={() => require('@src/features/idv').IDVErrorScreen}
        />
      </Stack.Group>

      <Stack.Screen
        name="Privacy Notice"
        getComponent={() => require('@src/features').PrivacyNoticeScreen}
        options={{
          title: 'Privacy Notice',
          gestureEnabled: false,
          header: TopAppBarDW,
        }}
      />

      <Stack.Group
        screenOptions={{ header: AvivaWebViewTopAppBar, presentation: 'modal' }}
      >
        <Stack.Screen
          name="Privacy Policy"
          getComponent={() => require('@src/features').PrivacyPolicyScreen}
        />
        <Stack.Screen
          name="Aviva Co Uk"
          getComponent={() => require('@src/features').AvivaCoUkScreen}
        />
        <Stack.Screen
          name="Ico Org Uk"
          getComponent={() => require('@src/features').IcoOrgUkScreen}
        />
      </Stack.Group>
    </Stack.Navigator>
  );
};
