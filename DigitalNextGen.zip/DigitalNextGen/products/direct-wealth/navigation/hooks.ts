import { BottomTabNavigationProp } from '@react-navigation/bottom-tabs';
import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { BottomTabsRouteParams } from '@src/navigation/bottom-tabs';

import {
  DirectWealthTabStackRouteParams,
  DirectWealthTabStackScreenNames,
} from './index';

export type DirectWealthTabStackRoute<
  T extends keyof DirectWealthTabStackRouteParams
> = RouteProp<DirectWealthTabStackRouteParams, T>;

export type DirectWealthTabStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<DirectWealthTabStackRouteParams>,
  BottomTabNavigationProp<BottomTabsRouteParams>
>;
/**
 * @description A typed wrapper around useRoute
 *
 * @T
 * T is the name of the screen from which you're calling this hook
 * It must be a key of DirectWealthTabStackRouteParams
 */
export function useDirectWealthTabStackRoute<
  T extends DirectWealthTabStackScreenNames
>() {
  return useRoute<DirectWealthTabStackRoute<T>>();
}

/**
 * @description A typed wrapper around useNavigation
 *
 * It must be a key of DirectWealthTabStackNavigation
 */
export function useDirectWealthTabStackNavigation() {
  return useNavigation<DirectWealthTabStackNavigation>();
}
