import { APP_BASE } from '@constants/analytics';

export const WEALTH_BASE = APP_BASE + 'wealth|';
export const PCS_PENSION_DASHBOARD = WEALTH_BASE + 'pcs|pension-dashboard';

export const PENSION_DASHBOARD_PENSION_CARD_TAPPED =
  PCS_PENSION_DASHBOARD + '|pension-card-tapped';

export const PENSION_DASHBOARD_ERROR = PCS_PENSION_DASHBOARD + '|error';
export const PENSION_DASHBOARD_ERROR_RETRY =
  PENSION_DASHBOARD_ERROR + '|retry-tapped';

export const PENSION_DASHBOARD_FAQ_TAPPED = (faq: string) =>
  PCS_PENSION_DASHBOARD + '|' + faq + '-tapped';
