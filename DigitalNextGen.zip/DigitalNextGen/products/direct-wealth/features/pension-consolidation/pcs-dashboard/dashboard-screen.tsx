import {
  FloatingButtonTotalHeight,
  LoadingState,
  NotificationCard,
  ScrollView,
  Stack,
  YStack,
} from '@aviva/ion-mobile';
import { Text } from '@aviva/ion-mobile/components/text';
import { ErrorView } from '@direct-wealth/components/error-view/error-view';
import { VirtualAssistant } from '@direct-wealth/components/virtual-assistant/virtual-assistant';
import { EditorialContentList } from '@direct-wealth/features/editorial-content/editorial-content-list';
import {
  PensionConsolidationSummary,
  TransferInformation,
} from '@direct-wealth/validation/schemas/pension-consolidation-summary';
import { useSelector } from '@legendapp/state/react';
import { FeatureFlags } from '@src/feature-flags';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { isIpad } from '@src/utils/is-ipad';

import { PCSReadyToTransfer } from '../components/pcs-ready-to-transfer/pcs-ready-to-transfer';
import { PensionCardList } from '../components/pension-card-list';
import {
  PENSION_DASHBOARD_ERROR,
  PENSION_DASHBOARD_ERROR_RETRY,
} from './analytics';
import { FAQsSection } from './pcs-faqs';
import { DashboardScreenViewProps } from './types';
import { useDashboardViewModel } from './use-dashboard-view-model';

export const DashboardScreenView = ({ model }: DashboardScreenViewProps) => {
  const {
    content,
    handlePensionCardPress,
    isLoading,
    isError,
    refetch,
    readyToTransferPress,
  } = model;

  const { t } = useTranslationDW();

  const FAQsEnabled = useSelector(FeatureFlags.dwFAQsEnabled);
  if (isError) {
    return (
      <ErrorView
        onRetry={refetch}
        onRetryAnalyticsTag={PENSION_DASHBOARD_ERROR_RETRY}
        screenTrackAnalyticsTag={PENSION_DASHBOARD_ERROR}
      />
    );
  }

  return (
    <>
      <ScrollView
        contentContainerStyle={{ paddingBottom: FloatingButtonTotalHeight }}
        showsVerticalScrollIndicator={false}
        backgroundColor={'$White'}
      >
        <YStack tablet={isIpad}>
          <Stack paddingHorizontal="$xl" paddingBottom={'$xl'}>
            {isLoading ? (
              <LoadingState text="oneMoment" />
            ) : (
              <>
                <Text
                  fontVariant="heading2-regular-Secondary800"
                  tamaguiTextProps={{ marginVertical: '$xxl' }}
                >
                  {t('pensionConsolidation.heading')}
                </Text>
                <Stack gap={'$xxl'}>
                  <PensionsNotInTransfer
                    content={content}
                    handlePensionCardPress={handlePensionCardPress}
                  />
                  <PCSReadyToTransfer
                    parentComponent="pcs-dashboard-screen"
                    onPress={readyToTransferPress}
                  />
                  <PensionsInTransfer
                    content={content}
                    handlePensionCardPress={handlePensionCardPress}
                  />
                </Stack>
              </>
            )}
          </Stack>
          {FAQsEnabled && <FAQsSection />}
        </YStack>
        <EditorialContentList
          backgroundColor="White"
          context="PensionConsolidationSummary"
          orientation="horizontal"
          tagInfo={{ type: 'pcs-dashboard' }}
        />
      </ScrollView>
      <VirtualAssistant
        analyticsData="pcs|pension-dashboard"
        pageMarker="wealth-pcs-dashboard"
      />
    </>
  );
};

function PensionsNotInTransfer({
  content,
  handlePensionCardPress,
}: {
  content?: PensionConsolidationSummary;
  handlePensionCardPress: (
    secureId: string,
    transferInformation: TransferInformation
  ) => void;
}) {
  const { t } = useTranslationDW();

  if (
    content == null ||
    content.pensionsNotInTransfer == null ||
    content.pensionsNotInTransfer.length === 0
  ) {
    return null;
  }

  return (
    <Stack>
      <Text
        fontVariant="heading5-semibold-Secondary800"
        tamaguiTextProps={{
          marginBottom: '$sm',
        }}
      >
        {t('pensionConsolidation.subHeading')}
      </Text>
      <Text
        fontVariant="body-regular-Secondary800"
        tamaguiTextProps={{
          marginBottom: '$xl',
        }}
      >
        {t('pensionConsolidation.subHeadingDescription')}
      </Text>
      <PensionCardList
        pensionData={content.pensionsNotInTransfer}
        onCardPress={handlePensionCardPress}
      />
      <NotificationCard
        iconVariant="information"
        title=""
        subtitle={t('pensionConsolidation.transferWarning')}
        marginTop={'$xl'}
      />
    </Stack>
  );
}

function PensionsInTransfer({
  content,
  handlePensionCardPress,
}: {
  content?: PensionConsolidationSummary;
  handlePensionCardPress: (
    secureId: string,
    transferInformation: TransferInformation
  ) => void;
}) {
  const { t } = useTranslationDW();

  if (
    content == null ||
    content.pensionsInTransfer == null ||
    content.pensionsInTransfer.length === 0
  ) {
    return null;
  }

  return (
    <Stack>
      <Text
        fontVariant="heading5-semibold-Secondary800"
        tamaguiTextProps={{ marginBottom: '$sm' }}
      >
        {t('pensionConsolidation.transferSubHeading')}
      </Text>
      <Text
        fontVariant="body-regular-Secondary800"
        tamaguiTextProps={{
          marginBottom: '$xl',
        }}
      >
        {t('pensionConsolidation.transferSubHeadingDescription')}
      </Text>
      <PensionCardList
        pensionData={content?.pensionsInTransfer}
        onCardPress={handlePensionCardPress}
      />
    </Stack>
  );
}

export const DashboardScreen = () => {
  const model = useDashboardViewModel();
  return <DashboardScreenView model={model} />;
};
