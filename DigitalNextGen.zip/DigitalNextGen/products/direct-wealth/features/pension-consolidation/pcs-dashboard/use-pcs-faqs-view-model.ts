import { useFAQs } from '@direct-wealth/common/hooks/use-faqs';
import { useAnalytics } from '@hooks/use-analytics';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { toKebabCaseWithoutSpecialCharecter } from '@src/utils/convert-to-kebab-case/convert-to-kebab-case';
import { useCallback } from 'react';
import { Linking } from 'react-native';

import { PENSION_DASHBOARD_FAQ_TAPPED } from './analytics';

export const useFAQsViewModel = () => {
  const { data: faqs } = useFAQs('PensionConsolidationSummary');

  const { trackUserEvent } = useAnalytics();

  const onFAQPress = useCallback(
    (faq: string) => {
      const faqString = toKebabCaseWithoutSpecialCharecter(faq);

      trackUserEvent(PENSION_DASHBOARD_FAQ_TAPPED(faqString));
    },
    [trackUserEvent]
  );

  const { navigate } = useAppStackNavigation();
  const onLinkPress = useCallback(
    (url: string) => {
      if (url === 'tel:08002851088') {
        Linking.openURL(`${url.replace(/\s+/g, '')}`);
        return;
      }
      navigate('Web View', { url });
    },
    [navigate]
  );

  return { faqs, onFAQPress, onLinkPress };
};
