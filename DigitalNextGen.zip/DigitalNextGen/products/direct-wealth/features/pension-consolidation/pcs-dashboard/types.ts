import { useDashboardViewModel } from './use-dashboard-view-model';

export type DashboardScreenViewProps = {
  model: ReturnType<typeof useDashboardViewModel>;
};
