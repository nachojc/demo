import { Stack, Text } from '@aviva/ion-mobile';
import { ExpansionPanel } from '@aviva/ion-mobile/components/expansion-panel';
import { FAQ } from '@direct-wealth/validation/schemas/faqs';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { RenderHtml } from '@src/utils/render-html/render-html';
import { useState } from 'react';
import { Dimensions } from 'react-native';
import { HTMLSource } from 'react-native-render-html';

import { useFAQsViewModel } from './use-pcs-faqs-view-model';

const windowWidth = Dimensions.get('window').width - 32;
export function FAQs({
  faqs,
  onPress,
  onLinkPress,
}: {
  faqs: FAQ[];
  onPress: (faq: string) => void;
  onLinkPress: (url: string) => void;
}) {
  return (
    <Stack testID={getTestId('pcs-faqs')}>
      <Text
        tamaguiTextProps={{
          marginBottom: 5,
          marginTop: 24,
          paddingHorizontal: 14,
        }}
        fontVariant="heading5-semibold-Secondary800"
      >
        FAQ’s
      </Text>
      <Stack marginTop={12}>
        {faqs.map((faq, index) => {
          return (
            <FAQPanel
              key={`${faq.question}-${faq.answer}`}
              faq={faq}
              index={index}
              onPress={onPress}
              onLinkPress={onLinkPress}
            />
          );
        })}
      </Stack>
    </Stack>
  );
}

function FAQPanel({
  faq,
  index,
  onPress,
  onLinkPress,
}: {
  faq: FAQ;
  index: number;
  onPress: (faq: string) => void;
  onLinkPress: (url: string) => void;
}) {
  const [isExpanded, setIsExpanded] = useState(false);

  const HtmlSource: HTMLSource = {
    html: `${faq.answer}`,
  };

  /**
   * iPad devices do not support phone numbers,
   * so 'when' on iPad devices,we will strip the
   * HTML link markup and only keep the text content
   */
  if (isIpad && HtmlSource.html.includes('tel:')) {
    const anchorTagMatch = HtmlSource.html.match(/<a.*?>(.*?)<\/a>,/);
    if (anchorTagMatch) {
      HtmlSource.html = HtmlSource.html.replace(
        anchorTagMatch[0],
        anchorTagMatch[1].concat('.')
      );
    }
  }

  return (
    <ExpansionPanel
      testID={getTestId(`faq-expansion-panel-${index}`)}
      isExpanded={isExpanded}
      title={faq.question}
      content={
        <Stack maxWidth={windowWidth}>
          <RenderHtml
            source={HtmlSource}
            width={windowWidth}
            styles={{ faqs: { color: '#373737', fontSize: 14 } }}
            onPress={onLinkPress}
          />
        </Stack>
      }
      onPress={() => {
        setIsExpanded(!isExpanded);
        onPress(faq.question);
      }}
      selectedIndex={0}
      index={0}
    />
  );
}

export const FAQsSection = () => {
  const model = useFAQsViewModel();
  if (model.faqs == null || model.faqs.length === 0) {
    return null;
  }
  return (
    <FAQs
      faqs={model.faqs}
      onPress={model.onFAQPress}
      onLinkPress={model.onLinkPress}
    />
  );
};
