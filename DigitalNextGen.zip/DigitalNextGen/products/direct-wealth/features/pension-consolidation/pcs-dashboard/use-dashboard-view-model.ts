import { usePensionConsolidationSummary } from '@direct-wealth/common/hooks/use-pension-consolidation-summary';
import {
  PCSPension,
  PensionConsolidationSummary,
  TransferInformation,
} from '@direct-wealth/validation/schemas/pension-consolidation-summary';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { useCallback, useMemo } from 'react';

import {
  PCS_PENSION_DASHBOARD,
  PENSION_DASHBOARD_PENSION_CARD_TAPPED,
} from './analytics';

const getQuotesStatusContextData = (pensions?: PCSPension[]) => {
  let quotesStatusContextData = 'pension-transfer|';

  const allUniqueTransferInfo = [
    ...new Set(pensions?.map((item) => item.information)),
  ];

  allUniqueTransferInfo.forEach((transferInformation, i, row) => {
    if (transferInformation === 'EligibleToTransfer') {
      quotesStatusContextData += 'eligible';
    } else if (transferInformation === 'MayLoseBenefits') {
      quotesStatusContextData += 'eligible-lose-benefits';
    }
    if (i + 1 !== row.length) {
      quotesStatusContextData += '-';
    }
  });
  return quotesStatusContextData;
};

const getAnalyticsContextData = (content?: PensionConsolidationSummary) => {
  const contextData: { [key: string]: string } = {
    numofpensions: (content?.pensionsNotInTransfer?.length ?? 0).toString(),
  };

  content?.pensionsInTransfer?.map((item, index) => {
    contextData[
      `pensiontransferred${index + 1}`
    ] = `full transfer|${item.value}|${item.productDisplayName}`;
    // TODO: hardcoded full transfer for now since we don't support partial and need
    // backend to add the fullTransfer prop in pcs summary api - Reference ticket: MANGA-4852
  });

  contextData.quotestatus = getQuotesStatusContextData(
    content?.pensionsNotInTransfer
  );

  return contextData;
};

export const useDashboardViewModel = () => {
  const [content, { isError, isLoading, refetch }] =
    usePensionConsolidationSummary();

  const { navigate } = useAppStackNavigation();
  const analytics = useAnalytics();

  const contextData = useMemo(
    () => getAnalyticsContextData(content),
    [content]
  );

  useOnPageLoad({ pageTag: PCS_PENSION_DASHBOARD, contextData });

  const handlePensionCardPress = (
    secureId: string,
    transferInformation: TransferInformation
  ) => {
    analytics.trackUserEvent(PENSION_DASHBOARD_PENSION_CARD_TAPPED);
    navigate('Pension Details', { secureId, transferInformation });
  };

  const readyToTransferPress = useCallback(() => {
    console.log('TODO: Navigate to multi select screen once its made');
  }, []);

  return {
    content,
    handlePensionCardPress,
    isError,
    isLoading,
    refetch,
    readyToTransferPress,
  };
};
