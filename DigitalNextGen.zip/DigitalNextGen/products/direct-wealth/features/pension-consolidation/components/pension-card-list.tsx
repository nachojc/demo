import { YStack } from '@aviva/ion-mobile';
import { AlertChipText } from '@aviva/ion-mobile/components/chip/chip.styles';
import { BasePensionDetailsCard } from '@direct-wealth/components/pension-details-card';
import { PENSION_TRANSFER_STATUS } from '@direct-wealth/components/transfer-status-card/pension_transfer-status';
import {
  PCSPension,
  TransferInformation,
} from '@direct-wealth/validation/schemas/pension-consolidation-summary';
import { convertISODateToShortMonthFormat } from '@src/utils/date-converters';
import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { getTestId } from '@src/utils/get-test-id';
import { useCallback } from 'react';

type PensionCardListProps = {
  pensionData?: PCSPension[];
  onCardPress: (
    secureId: string,
    transferInformation: TransferInformation
  ) => void;
};

export const PensionCardList = ({
  pensionData,
  onCardPress,
}: PensionCardListProps) => {
  return (
    <YStack space={'$xl'} testID={getTestId('pcs-pension-card-list')}>
      {pensionData?.map((item) => {
        return (
          <PensionCard
            key={`${item.secureId}-${item.policyNumber}`}
            pension={item}
            onCardPress={onCardPress}
          />
        );
      })}
    </YStack>
  );
};

export const PensionCard = ({
  pension,
  onCardPress,
}: {
  pension: PCSPension;
  onCardPress: (
    secureId: string,
    transferInformation: TransferInformation
  ) => void;
}) => {
  const {
    productDisplayName,
    policyNumber,
    value,
    valuationDate,
    employerName,
    secureId,
    information,
    transferStatus,
  } = pension;

  const pensionTransferStatus =
    information === 'InTransfer' ? transferStatus : information;

  const { chipTitle, iconName, variant, status } =
    PENSION_TRANSFER_STATUS[pensionTransferStatus];

  const onPress = useCallback(() => {
    onCardPress(secureId, information);
  }, [onCardPress, information, secureId]);

  return (
    <YStack testID={getTestId('pcs-pension-card')} marginHorizontal="$-sm">
      <BasePensionDetailsCard
        headerText={productDisplayName}
        showSeperator
        iconInfo={{
          iconName: 'chevron-right',
          iconStyles: { space: '$md' },
        }}
        contentDetails={[
          { key: 'Plan number:', value: policyNumber },
          {
            key: `Value as of ${convertISODateToShortMonthFormat(
              valuationDate
            )}:`,
            value: formatCurrencyValue(value),
          },
          {
            key: 'Employer name:',
            value: employerName ?? '',
          },
        ]}
        onCardPress={onPress}
        infoChips={[
          {
            testID: getTestId(`test-alert-chip-${status}`),
            name: iconName,
            variant,
            text: <AlertChipText size={'sm'}>{chipTitle}</AlertChipText>,
          },
        ]}
      />
    </YStack>
  );
};
