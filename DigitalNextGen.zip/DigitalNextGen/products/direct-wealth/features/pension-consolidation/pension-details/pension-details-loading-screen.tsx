import { Shimmer, Stack, XStack, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

export const PensionDetailsLoadingScreen = () => (
  <YStack paddingTop={'$xxl'} tablet={isIpad}>
    <YStack px="$xl">
      <YStack paddingEnd="$sm" mb="'$lg'" space={'$md'} marginBottom={'$xxl'}>
        <Shimmer width={'60%'} height={32} />
        <Shimmer width={'100%'} height={32} />
        <Shimmer width={'60%'} height={26} />
      </YStack>

      <Stack
        borderColor="$Gray200"
        borderStyle="solid"
        borderWidth={1}
        padding={'$xxl'}
        borderRadius={'$2'}
        space={'$md'}
        marginBottom={'$xxxl'}
      >
        <XStack space={'$md'}>
          <Shimmer width={32} height={32} />
          <YStack space={'$md'}>
            <Shimmer width={'70%'} height={22} />
            <Shimmer width={'30%'} height={22} />
            <Shimmer width={'70%'} height={22} />
            <Shimmer width={'70%'} height={22} />
            <Shimmer width={'40%'} height={22} />
            <Shimmer width={'70%'} height={22} />
            <Shimmer width={'70%'} height={22} />
            <Shimmer width={'60%'} height={22} />
          </YStack>
        </XStack>
      </Stack>

      <Stack space={'$md'} marginBottom={'$xxl'}>
        <Shimmer width={'50%'} height={22} />
        <Shimmer width={'100%'} height={22} />
        <Shimmer width={'60%'} height={22} />
      </Stack>

      <Stack space={'$md'} marginBottom={'$xxl'}>
        <Shimmer width={'100%'} height={50} borderRadius={50} />
      </Stack>

      <Stack space={'$md'} marginBottom={'$xl'}>
        <Shimmer width={'50%'} height={22} />
        <Shimmer width={'100%'} height={22} />
        <Shimmer width={'20%'} height={22} />
      </Stack>
    </YStack>
  </YStack>
);
