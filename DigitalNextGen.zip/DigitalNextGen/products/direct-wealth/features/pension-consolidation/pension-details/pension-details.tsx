import {
  Button,
  DynamicHeightModal,
  FloatingButtonTotalHeight,
  getTokens,
  IconText,
  NotificationCard,
  ScrollView,
  Separator,
  Stack,
  Text,
  TextWithLinks,
  YStack,
} from '@aviva/ion-mobile';
import { PDFCard } from '@aviva/ion-mobile/components/cards/pdf-card';
import { config } from '@config';
import { ErrorView } from '@direct-wealth/components/error-view/error-view';
import { TransferStatusCard } from '@direct-wealth/components/transfer-status-card/transfer-status-card';
import { VirtualAssistant } from '@direct-wealth/components/virtual-assistant/virtual-assistant';
import { BenefitContent } from '@direct-wealth/validation/schemas/pension-consolidation-details';
import { useAnalytics } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { convertISODateToShortMonthFormat } from '@src/utils';
import { spellOutString } from '@src/utils/accessibility';
import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { formatPercentageValue } from '@src/utils/format-percentage-value';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useState } from 'react';
import { Platform } from 'react-native';

import { PCS_CONSIDER_TRANSFERRING_TAPPED } from '../components/pcs-ready-to-transfer/analytics';
import { PCSReadyToTransferCopy } from '../components/pcs-ready-to-transfer/constants';
import { PENSION_DETAILS_PREFIX } from './analytics';
import { InfoTable, TitleContent, TitleTooltip } from './components';
import { PensionDetailsIconCard } from './components/pension-details-icon-card';
import { RetirementBenefits } from './components/retirement-benefits';
import {
  ValuableBenefitsValue,
  ValueBenefits,
} from './components/valuable-benefits';
import { PensionDetailsCopy, RetirementBenefitsTitles } from './constants';
import { PensionDetailsLoadingScreen } from './pension-details-loading-screen';
import { ErrorBenefitsContainer } from './styles';
import { TransferringToolTip } from './transferring-tooltip';
import {
  ModalContent,
  PensionDetailsRouteProps,
  PensionDetailsViewProps,
} from './types';
import { usePensionDetailsViewModel } from './use-pension-details-view-model';
import { YouMayLoseBenefitsDialog } from './you-may-lose-benefits-dialog';

const {
  ANNUAL_MANAGEMENT_CHARGE,
  CHARGES_INFORMATION,
  CURRENT_PENSION_VALUE,
  EMPLOYER_NAME,
  EXIT_FEE,
  FUND_MANAGEMENT_CHARGE,
  INFORMATION_FROM,
  INVESTED_IN_WITH,
  NO_SAFEGUARDED_BENEFITS,
  PDF_CARD_SUBTITLE,
  PDF_CARD_TITLE,
  PENSION_BENEFITS,
  MUST_READ_LOR,
  PENSION_CHARGES,
  PENSION_DETAILS,
  PENSION_DOCUMENTS,
  PENSION_VALUATION_DATE,
  PLAN_NUMBER,
  POLICY_FEE,
  SAFEGUARDED_BENEFITS,
  SCHEME_PROVIDER,
  PENSION_BENEFITS_DESCRIPTION,
  VIEW_OUR_GLOSSARY_LINK_TEXT,
  GLOSSARY_LINK_URL,
  TOTAL_EXPENSE_RATIO,
  TRANSFER_VALUE,
  VALUABLE_BENEFITS,
  EXIT_FEE_WARNING,
  BENEFITS_WARNING,
  LOR_FALLBACK_WARNING,
  YOUR_TRANSFER,
  YOUR_TRANSFER_ACCESSIBILITY_LABEL,
  PENSION_CONSOLIDATION_DETAILS_ERROR,
  PENSION_CONSOLIDATION_DETAILS_RETRY,
  TRANSFER_THIS_PENSION,
} = PensionDetailsCopy;

const { REVIEW_INFO_SINGULAR, CONSIDER_THESE } = PCSReadyToTransferCopy;

export const PensionDetailsView = ({ model }: PensionDetailsViewProps) => {
  const { t } = useTranslationDW();
  const [isModalVisible, setIsModalVisible] = useState(false),
    [modalContent, setModalContent] = useState<ModalContent>({
      title: '',
      body: '',
    }),
    { navigate } = useAppStackNavigation();

  const toggleModal = () => {
    setIsModalVisible(!isModalVisible);
  };
  const tokens = getTokens();

  const {
    pensionDetails,
    refetch,
    isError,
    isLoading,
    pensionCanBeConsolidated,
    transferInformation,
    sendTooltipPressed,
    isLoseBenefitsDialogVisible,
    onStartTransferRequestPress,
    startTransferRequest,
    onLoseBenefitDialogCancelPress,
    transferStatus,
    handleOnLetterOfResponseClick,
    supportPhoneNumbersData,
  } = model;

  if (isError) {
    return (
      <ErrorView
        onRetry={refetch}
        title={PENSION_CONSOLIDATION_DETAILS_ERROR}
        message={PENSION_CONSOLIDATION_DETAILS_RETRY}
      />
    );
  }

  if (isLoading || !pensionDetails) {
    return <PensionDetailsLoadingScreen />;
  }

  const {
    transferValue,
    valuationDate,
    investedInWithProfitFund,
    currentPensionValue: currentPension,
    policyNumber,
    productDisplayName,
    employerName,
    schemeProvider,
    annualManagementCharges,
    fundManagementCharges,
    totalExpenseRatios,
    policyFee,
    exitFee,
    valuableBenefits,
    safeguardedBenefits,
    letterOfResponseDocumentId,
    hasGuaranteedIncome,
    hasIncomeDrawdown,
    hasTakeYourPensionAsCash,
  } = pensionDetails;

  const phoneNumber =
    supportPhoneNumbersData?.uklRetirementSolutionsNumber?.content;

  const openHours =
    supportPhoneNumbersData?.uklRetirementSolutionsNumber?.openHours;

  const isLetterOfResponseDocumentIdPresent =
    !!letterOfResponseDocumentId.value;

  const letterOfResponseDocumentIdValue = letterOfResponseDocumentId.value;

  const isExitFeeOverZero = !!exitFee.value.rate && exitFee.value.rate > 0;

  const isValuableBenefits = valuableBenefits.value.length > 0;

  const isSafeguardedBenefits = !!safeguardedBenefits.value;

  const shouldShowBenefitsWarning = isValuableBenefits || isSafeguardedBenefits;

  const benefitLinksArray: ValuableBenefitsValue[] = valuableBenefits?.value;

  const showTransferStatusCard =
    transferStatus && transferStatus !== 'NotSpecified';

  const retirementBenefits: BenefitContent[] = [];

  const showReadyToTransfer =
    pensionCanBeConsolidated && isLetterOfResponseDocumentIdPresent;

  const chatButtonSpace = showReadyToTransfer
    ? FloatingButtonTotalHeight
    : tokens.space.$xxl.val;

  if (hasGuaranteedIncome) {
    retirementBenefits.push({
      title: RetirementBenefitsTitles.hasGuaranteedIncome,
      ...hasGuaranteedIncome,
    });
  }

  if (hasIncomeDrawdown) {
    retirementBenefits.push({
      title: RetirementBenefitsTitles.hasIncomeDrawdown,
      ...hasIncomeDrawdown,
    });
  }

  if (hasTakeYourPensionAsCash) {
    retirementBenefits.push({
      title: RetirementBenefitsTitles.hasTakeYourPensionAsCash,
      ...hasTakeYourPensionAsCash,
    });
  }

  const displayToolTip = (title: string, body?: string | null) => {
    if (body) {
      sendTooltipPressed(title);
      setModalContent({
        title,
        body,
      });
      toggleModal();
    }
  };

  const onWebviewPress = (url: string) => {
    navigate('Web View', {
      url: config.AVIVA_BASE_URL.get() + url,
    });
  };

  const navigateToHelpAndSupport = () => {
    navigate('Web View', {
      url: `https://www.aviva.co.uk/help-and-support/contact-us/`,
    });
  };

  const amcDisplayValue = () => {
    if (totalExpenseRatios.value.length > 0) {
      return t('pensionDetails.includedInTotalExpenseRatio');
    } else {
      if (annualManagementCharges.value.length > 0) {
        return convertArrayToReadableFormat(annualManagementCharges.value);
      } else {
        return '0.00%';
      }
    }
  };

  const fmcDisplayValue = () => {
    if (totalExpenseRatios.value.length > 0) {
      return t('pensionDetails.includedInTotalExpenseRatio');
    } else {
      if (fundManagementCharges.value.length > 0) {
        return convertArrayToReadableFormat(fundManagementCharges.value);
      } else {
        return '0.00%';
      }
    }
  };

  return (
    <>
      <ScrollView
        contentContainerStyle={{ paddingBottom: FloatingButtonTotalHeight }}
        paddingTop={tokens.space.xl}
        backgroundColor={'$White'}
      >
        <YStack tablet={isIpad}>
          <YStack px={tokens.space.xl}>
            <YStack mb="$lg" paddingEnd="$sm">
              <Text fontVariant="heading2-regular-Secondary800">
                {productDisplayName.value}
              </Text>
              <Text
                fontVariant="heading4-light-Pension11"
                tamaguiTextProps={{
                  accessibilityValue: {
                    text: `${PLAN_NUMBER}${
                      policyNumber.value
                        ? `, ${spellOutString(policyNumber.value)}`
                        : ''
                    }`,
                  },
                }}
              >
                {PLAN_NUMBER} {policyNumber.value}
              </Text>
            </YStack>
            <PensionDetailsIconCard transferStatus={transferInformation} />
            <PCSPensionDetails readyToTransfer={showReadyToTransfer} />
            {showTransferStatusCard && (
              <YStack>
                <TransferStatusCard
                  title={YOUR_TRANSFER}
                  titleAccessibilityLabel={YOUR_TRANSFER_ACCESSIBILITY_LABEL}
                  transferStatus={transferStatus}
                  phoneNumber={phoneNumber}
                  openHours={openHours}
                  navigateToHelpAndSupport={navigateToHelpAndSupport}
                />
              </YStack>
            )}
          </YStack>
          <InfoTable
            title={EMPLOYER_NAME}
            value={employerName.value ?? 'Unknown'}
          />
          <InfoTable
            title={PLAN_NUMBER}
            value={policyNumber.value ?? 'Unknown'}
            valueAccessibilityLabel={
              policyNumber.value
                ? spellOutString(policyNumber.value)
                : undefined
            }
          />
          <InfoTable
            title={SCHEME_PROVIDER}
            value={schemeProvider.value ?? 'Unknown'}
          />
          <InfoTable
            title={CURRENT_PENSION_VALUE}
            value={formatCurrencyValue(currentPension.value)}
            testID={getTestId('current-pension-value')}
            onPress={
              currentPension.tooltip
                ? () =>
                    displayToolTip(
                      CURRENT_PENSION_VALUE,
                      currentPension.tooltip
                    )
                : undefined
            }
          />
          <InfoTable
            title={TRANSFER_VALUE}
            value={formatCurrencyValue(transferValue.value)}
            testID={getTestId('transfer-value')}
            onPress={
              transferValue.tooltip
                ? () => displayToolTip(TRANSFER_VALUE, transferValue.tooltip)
                : undefined
            }
          />
          <InfoTable
            title={PENSION_VALUATION_DATE}
            value={convertISODateToShortMonthFormat(valuationDate.value)}
          />
          <InfoTable
            title={INVESTED_IN_WITH}
            value={investedInWithProfitFund.value ? 'Yes' : 'No'}
            testID={getTestId('invalid-in-with')}
            onPress={
              investedInWithProfitFund.tooltip
                ? () =>
                    displayToolTip(
                      INVESTED_IN_WITH,
                      investedInWithProfitFund.tooltip
                    )
                : undefined
            }
          />
          <Separator />
          <TitleContent title={PENSION_CHARGES}>
            {CHARGES_INFORMATION}
          </TitleContent>
          <Separator />
          <InfoTable
            title={ANNUAL_MANAGEMENT_CHARGE}
            value={amcDisplayValue()}
            testID={getTestId('annual-management-charge')}
            onPress={
              annualManagementCharges.tooltip
                ? () =>
                    displayToolTip(
                      ANNUAL_MANAGEMENT_CHARGE,
                      annualManagementCharges.tooltip
                    )
                : undefined
            }
          />
          <InfoTable
            title={FUND_MANAGEMENT_CHARGE}
            value={fmcDisplayValue()}
            testID={getTestId('fund-management-charge')}
            onPress={
              fundManagementCharges.tooltip
                ? () =>
                    displayToolTip(
                      FUND_MANAGEMENT_CHARGE,
                      fundManagementCharges.tooltip
                    )
                : undefined
            }
          />
          <InfoTable
            title={TOTAL_EXPENSE_RATIO}
            value={
              totalExpenseRatios.value.length > 0
                ? convertArrayToReadableFormat(totalExpenseRatios.value)
                : t('pensionDetails.notProvided')
            }
            testID={getTestId('total-expense-ratio')}
            onPress={
              totalExpenseRatios.tooltip
                ? () =>
                    displayToolTip(
                      TOTAL_EXPENSE_RATIO,
                      totalExpenseRatios.tooltip
                    )
                : undefined
            }
          />
          <InfoTable
            title={POLICY_FEE}
            value={
              totalExpenseRatios.value.length > 0
                ? t('pensionDetails.includedInTotalExpenseRatio')
                : convertFeeToString(policyFee)
            }
            testID={getTestId('policy-fee')}
            onPress={
              policyFee.tooltip
                ? () => displayToolTip(POLICY_FEE, policyFee.tooltip)
                : undefined
            }
          />
          {isExitFeeOverZero && (
            <ErrorBenefitsContainer>
              <IconText
                iconName={'alert-circle'}
                iconColor={tokens.color.Error.val}
                iconSizeOption={'medium'}
                title={EXIT_FEE_WARNING}
                titleFontVariant="small-semibold-Error"
              />
            </ErrorBenefitsContainer>
          )}
          <InfoTable
            title={EXIT_FEE}
            value={convertFeeToString(exitFee)}
            testID={getTestId('exit-fee')}
            onPress={
              exitFee.tooltip
                ? () => displayToolTip(EXIT_FEE, exitFee.tooltip)
                : undefined
            }
          />
          {retirementBenefits.length > 0 && (
            <RetirementBenefits
              retirementBenefits={retirementBenefits}
              displayToolTip={displayToolTip}
            />
          )}
          <Separator />
          <TitleContent title={PENSION_BENEFITS}>
            <TextWithLinks<typeof PENSION_BENEFITS_DESCRIPTION>
              template={PENSION_BENEFITS_DESCRIPTION}
              links={{
                glossary: {
                  text: VIEW_OUR_GLOSSARY_LINK_TEXT,
                  onPress: () => onWebviewPress(GLOSSARY_LINK_URL),
                  props: {
                    textDecorationLine: 'underline',
                    fontWeight: '$bold',
                    color: '$Tertiary800',
                  },
                },
              }}
              fontVariant="body-regular-Gray700"
            />
          </TitleContent>
          <YStack marginHorizontal={'$xl'} marginBottom={'$xl'}>
            <NotificationCard
              iconVariant="information"
              subtitle={MUST_READ_LOR}
              subtitleTextProps={{ fontSize: tokens.size[4] }}
            />
          </YStack>
          <TitleTooltip
            text={VALUABLE_BENEFITS}
            onPress={() =>
              displayToolTip(VALUABLE_BENEFITS, valuableBenefits.tooltip)
            }
          />
          {shouldShowBenefitsWarning && (
            <ErrorBenefitsContainer testID={getTestId('benefit-warning')}>
              <IconText
                iconName={'alert-circle'}
                iconColor={tokens.color.Error.val}
                iconSizeOption={'medium'}
                title={BENEFITS_WARNING}
                titleFontVariant="small-semibold-Error"
              />
            </ErrorBenefitsContainer>
          )}
          <ValueBenefits
            benefitLinksArray={benefitLinksArray}
            displayToolTip={displayToolTip}
          />
          <TitleTooltip
            text={SAFEGUARDED_BENEFITS}
            onPress={() =>
              displayToolTip(SAFEGUARDED_BENEFITS, safeguardedBenefits.tooltip)
            }
          />
          <Text
            fontVariant="small-semibold-WealthBlue"
            tamaguiTextProps={{
              mx: tokens.space.xl,
              mt: tokens.space.xxl,
              mb: tokens.space.xxxl,
            }}
          >
            {safeguardedBenefits.value ?? NO_SAFEGUARDED_BENEFITS}
          </Text>
          <Separator />
          <YStack
            paddingHorizontal={tokens.space.xl}
            paddingBottom={tokens.space.xl}
          >
            <Text
              fontVariant="heading5-semibold-Secondary800"
              tamaguiTextProps={{
                marginBottom: tokens.space.md,
                marginTop: tokens.space.xxl,
                accessibilityRole: 'header',
              }}
            >
              {PENSION_DOCUMENTS}
            </Text>
            {isLetterOfResponseDocumentIdPresent &&
            letterOfResponseDocumentIdValue ? (
              <YStack paddingTop={tokens.space.xl}>
                <PDFCard
                  onPress={() => handleOnLetterOfResponseClick()}
                  title={PDF_CARD_TITLE}
                  subtitle={PDF_CARD_SUBTITLE}
                />
              </YStack>
            ) : (
              <NotificationCard
                subtitle={LOR_FALLBACK_WARNING}
                subtitleTextProps={{
                  fontSize: '$body',
                  fontWeight: '$regular',
                  lineHeight: 20,
                }}
                iconVariant="warning"
              />
            )}

            <DynamicHeightModal
              isOpen={isModalVisible}
              onClose={toggleModal}
              backgroundColor="DWPrimary500"
            >
              <Text
                tamaguiTextProps={{ letterSpacing: -0.3 }}
                fontVariant={'heading3-semibold-White'}
                testID={getTestId('modal-title')}
              >
                {modalContent?.title}
              </Text>

              <Text
                fontVariant="body-regular-White"
                tamaguiTextProps={{ mt: '$lg' }}
                testID={getTestId('modal-body')}
              >
                {modalContent?.body}
              </Text>
            </DynamicHeightModal>
          </YStack>
          {isLoseBenefitsDialogVisible && (
            <YouMayLoseBenefitsDialog
              onContinue={startTransferRequest}
              onCancel={onLoseBenefitDialogCancelPress}
            />
          )}
        </YStack>
      </ScrollView>
      <VirtualAssistant
        chatButtonSpaceFromBottom={chatButtonSpace}
        analyticsData="pcs|pension-details"
        pageMarker="wealth-pcs-details"
      />
      {showReadyToTransfer && (
        <YStack
          testID={getTestId('start-transfer-request-container')}
          padding="$xl"
          paddingBottom={'$xxl'}
          backgroundColor="$White"
          shadowOpacity={0.15}
          shadowRadius={5}
          elevation={Platform.OS === 'android' ? '$1' : undefined}
        >
          <YStack tabletNarrow={isIpad} pb={isIpad ? '$xl' : undefined}>
            <Button onPress={onStartTransferRequestPress}>
              {TRANSFER_THIS_PENSION}
            </Button>
          </YStack>
        </YStack>
      )}
    </>
  );
};

export const PensionDetailsScreen = ({
  route,
}: {
  route: PensionDetailsRouteProps;
}) => {
  const { secureId } = route.params;
  const model = usePensionDetailsViewModel(secureId);
  return <PensionDetailsView model={model} />;
};

const PCSPensionDetails = ({
  readyToTransfer,
}: {
  readyToTransfer: boolean;
}) => {
  const [isTransferringModalVisible, setIsTransferringModalVisible] =
    useState(false);

  const analytics = useAnalytics();

  const onConsiderTransferRequest = () => {
    analytics.trackUserEvent(
      PENSION_DETAILS_PREFIX + PCS_CONSIDER_TRANSFERRING_TAPPED
    );
    setIsTransferringModalVisible(true);
  };

  return (
    <Stack paddingVertical={'$md'}>
      {readyToTransfer ? (
        <>
          <Text
            fontVariant="heading5-semibold-Secondary800"
            tamaguiTextProps={{
              accessibilityRole: 'header',
              marginVertical: '$md',
            }}
          >
            {PENSION_DETAILS}
          </Text>
          <TextWithLinks
            fontVariant="body-regular-Gray700"
            testID={getTestId('ready-to-transfer-blurb')}
            tamaguiTextProps={{ fontSize: '$body' }}
            template={REVIEW_INFO_SINGULAR}
            links={{
              considerIf: {
                text: CONSIDER_THESE,
                onPress: onConsiderTransferRequest,
                props: {
                  fontSize: '$body',
                  fontWeight: '$bold',
                  color: '$Tertiary800',
                  textDecorationLine: 'underline',
                },
              },
            }}
          />
          {isTransferringModalVisible && (
            <TransferringToolTip
              analyticsBase={PENSION_DETAILS_PREFIX}
              isTooltipVisible={isTransferringModalVisible}
              setIsTooltipVisible={setIsTransferringModalVisible}
            />
          )}
        </>
      ) : (
        <>
          <Text
            fontVariant="heading5-semibold-Secondary800"
            tamaguiTextProps={{
              accessibilityRole: 'header',
              marginVertical: '$md',
            }}
          >
            {PENSION_DETAILS}
          </Text>
          <Text fontVariant="body-regular-Gray700">{INFORMATION_FROM}</Text>
        </>
      )}
    </Stack>
  );
};

// Helper Functions

const convertArrayToReadableFormat = (arrayToConvert: number[]) => {
  if (arrayToConvert.length === 1) {
    return `${arrayToConvert[0].toFixed(2)}%`;
  } else if (arrayToConvert.length > 1) {
    return 'See LoR';
  } else {
    return 'N/A';
  }
};

const convertFeeToString = (fee: {
  value: {
    monetaryValue?: number | null;
    rate?: number | null;
  };
}) => {
  if (fee.value?.monetaryValue) {
    return formatCurrencyValue(fee.value.monetaryValue);
  }
  if (fee.value?.rate) {
    return formatPercentageValue(fee.value.rate, 2) ?? 'N/A';
  }
  return 'N/A';
};
