import {
  Button,
  ButtonVariant,
  Dialog,
  getTokens,
  getVariableValue,
  Icon,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useTrackStateEvent } from '@hooks/use-analytics';

import { PAGE_MAY_LOSE_BENEFITS_OVERLAY } from './analytics';
import { YouMayLoseBenefitsConstants } from './constants';

const {
  YOU_MAY_LOSE_BENEFITS_TITLE,
  YOU_MAY_LOSE_BENEFITS,
  BUTTON_CONTINUE,
  BUTTON_CANCEL,
} = YouMayLoseBenefitsConstants;

const tokens = getTokens();
export const YouMayLoseBenefitsDialog = ({
  onContinue,
  onCancel,
}: {
  onContinue: () => void;
  onCancel: () => void;
}) => {
  useTrackStateEvent(PAGE_MAY_LOSE_BENEFITS_OVERLAY);

  return (
    <Dialog
      icon={
        <YStack marginBottom="$md">
          <Icon
            name="info"
            color={getVariableValue(tokens.color.Information)}
          />
        </YStack>
      }
      open
      title={YOU_MAY_LOSE_BENEFITS_TITLE}
      center
      copy={
        <Text fontVariant={'body-regular-Gray800'}>
          {YOU_MAY_LOSE_BENEFITS}
        </Text>
      }
    >
      <YStack space="$md" marginTop="$xl" key="hi">
        <Button onPress={onContinue} height={44}>
          {BUTTON_CONTINUE}
        </Button>

        <Button variant={ButtonVariant.LINK_TEXT} onPress={onCancel}>
          {BUTTON_CANCEL}
        </Button>
      </YStack>
    </Dialog>
  );
};
