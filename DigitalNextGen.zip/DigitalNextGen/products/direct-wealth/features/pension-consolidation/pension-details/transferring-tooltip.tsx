import {
  Modal,
  Text,
  TextWithLinks,
  useWindowDimensions,
} from '@aviva/ion-mobile';
import { useDirectWealthAccount } from '@direct-wealth/common/hooks';
import { useAnalytics } from '@hooks/use-analytics';
import { useCustomer } from '@hooks/use-customer';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { Dispatch, SetStateAction, useCallback, useEffect } from 'react';

import {
  ACTION_READY_TO_CONSOLIDATE_MODAL_ADVICE_TAPPED,
  ACTION_READY_TO_CONSOLIDATE_MODAL_TERMS_TAPPED,
  CONSIDER_TRANSFER_MODAL,
  CONSIDER_TRANSFER_MODAL_CLOSED_TAPPED,
} from './analytics';
import { TransferringTooltipCopy } from './constants';

type TransferringTooltipProps = {
  analyticsBase: string;
  isTooltipVisible: boolean;
  setIsTooltipVisible: Dispatch<SetStateAction<boolean>>;
};

const {
  TITLE,
  INFORMATION_PROVIDED,
  TERMS_AND_CONDITIONS_LINK,
  TERMS_AND_CONDITIONS_LINK_HINT,
  CONSIDER_CHARGES_ADVICE,
  DISINVESTED_CAVEAT,
  DECIDE_TO_CANCEL,
  CAPITAL_AT_RISK,
  GET_ADVICE,
  ADVICE_LINK,
} = TransferringTooltipCopy;

export const TransferringToolTip = ({
  analyticsBase,
  isTooltipVisible,
  setIsTooltipVisible,
}: TransferringTooltipProps) => {
  const analytics = useAnalytics();

  useEffect(() => {
    analytics.trackStateEvent(analyticsBase + CONSIDER_TRANSFER_MODAL);
  }, [analytics, analyticsBase]);

  const handleCloseModal = useCallback(() => {
    analytics.trackUserEvent(
      analyticsBase + CONSIDER_TRANSFER_MODAL_CLOSED_TAPPED
    );
    setIsTooltipVisible(false);
  }, [analytics, analyticsBase, setIsTooltipVisible]);

  const { navigate } = useAppStackNavigation();

  const navigateToAdvice = () => {
    analytics.trackUserEvent(ACTION_READY_TO_CONSOLIDATE_MODAL_ADVICE_TAPPED);
    setIsTooltipVisible(false);
    // wait for render cycle to dismiss before presenting
    setTimeout(() => {
      navigate('Web View', { url: 'https://www.unbiased.co.uk' });
    }, 0);
  };

  const navigateToTerms = () => {
    analytics.trackUserEvent(ACTION_READY_TO_CONSOLIDATE_MODAL_TERMS_TAPPED);
    setIsTooltipVisible(false);
    navigate('Pdf View', {
      pdfSource: {
        url: 'https://static.aviva.io/content/dam/document-library/adviser/customerplatform/rd01003c.pdf',
      },
      isDW: true,
      name: 'Terms and Conditions',
    });
  };

  const { data } = useCustomer();
  const { data: directWealthAccount } = useDirectWealthAccount(
    data?.DirectWealth?.[0]?.SecureAccountNumber
  );

  const hasSippProduct =
    directWealthAccount?.products.find(
      (product) => product.accountType === 'SIPP'
    ) !== undefined;

  const getDimensions = (height: number, width: number) => {
    return height > width ? 0.5 : 0.75;
  };
  const informationProvided = hasSippProduct
    ? INFORMATION_PROVIDED.replace('a new Aviva SIPP', 'your Aviva SIPP')
    : INFORMATION_PROVIDED;

  const { height, width } = useWindowDimensions();
  return (
    <Modal
      isOpen={isTooltipVisible}
      onClose={handleCloseModal}
      backgroundColor="DWPrimary500"
      modalHeight={isIpad ? getDimensions(height, width) : undefined}
      isIpadWidth
    >
      <Text fontVariant={'heading3-semibold-White'}>{TITLE}</Text>
      <TextWithLinks<typeof informationProvided>
        testID={getTestId('transferring-modal-information')}
        fontVariant="body-regular-White"
        tamaguiTextProps={{ mt: '$lg' }}
        template={informationProvided}
        links={{
          termsAndConditions: {
            text: TERMS_AND_CONDITIONS_LINK,
            accessibilityHint: TERMS_AND_CONDITIONS_LINK_HINT,
            onPress: navigateToTerms,
            props: {
              fontSize: '$body',
              fontWeight: '$semibold',
              color: '$White',
              textDecorationLine: 'underline',
            },
          },
        }}
      />
      <Text fontVariant="body-regular-White" tamaguiTextProps={{ mt: '$xl' }}>
        {CONSIDER_CHARGES_ADVICE}
      </Text>
      <Text fontVariant="body-regular-White" tamaguiTextProps={{ mt: '$xl' }}>
        {DISINVESTED_CAVEAT}
      </Text>
      <Text fontVariant="body-regular-White" tamaguiTextProps={{ mt: '$xl' }}>
        {DECIDE_TO_CANCEL}
      </Text>
      <Text fontVariant="body-regular-White" tamaguiTextProps={{ mt: '$xl' }}>
        {CAPITAL_AT_RISK}
      </Text>
      <TextWithLinks<typeof GET_ADVICE>
        testID={getTestId('transferring-modal-advice')}
        fontVariant="body-regular-White"
        tamaguiTextProps={{ mt: '$xl' }}
        template={GET_ADVICE}
        links={{
          advice: {
            text: ADVICE_LINK,
            onPress: navigateToAdvice,
            props: {
              fontSize: '$body',
              fontWeight: '$semibold',
              color: '$White',
              textDecorationLine: 'underline',
            },
          },
        }}
      />
    </Modal>
  );
};
