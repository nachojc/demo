export const PensionDetailsCopy = {
  ANNUAL_MANAGEMENT_CHARGE: 'Annual management charge',
  BASED_ON_THE_INFORMATION:
    'If you choose to go ahead, you won’t lose certain valuable benefits and there won’t be any exit fees based on our checks below. A more detailed explanation is in {{glossary}}. Also, check your letter of response below in case there are any other benefits we’ve not checked for.',
  CHARGES_INFORMATION:
    'Information about the charges from your current provider, including any exit fees if you decide to transfer. Check your Letter of Response (LoR) at the end of this page for more details. ',
  CONSIDER_IF_LINK: 'consider if transferring is right for you',
  CURRENT_PENSION_VALUE: 'Current pension value',
  EMPLOYER_NAME: 'Employer name',
  EXIT_FEE: 'Exit fee',
  FUND_MANAGEMENT_CHARGE: 'Fund management charge',
  OUR_GLOSSARY_LINK_TEXT: 'our glossary',
  VIEW_OUR_GLOSSARY_LINK_TEXT: 'view our glossary.',
  GLOSSARY_LINK_URL:
    '/retirement/pensions/find-and-combine/glossary-of-benefits',
  GREAT_NEWS_TITLE: 'Great news! You can transfer your pension to us.',
  WARNING_TITLE:
    'You can transfer this pension, but you’ll lose certain benefits and/or there’ll be an exit fee',
  MAY_LOSE_BENEFITS_COPY:
    'For details of which benefits we have checked for, visit {{glossary}}. It’s important to read your letter of response below in case there are any other benefits we’ve not checked for.',
  INFORMATION_FROM:
    'Information from your current provider including the value of your pension.',
  INVESTED_IN_WITH: 'Invested in a with-profits fund?',
  OPENS_IN_TOOLTIP: 'Opens in tooltip',
  PDF_CARD_SUBTITLE:
    'Letter from your current provider with the pension information we asked for',
  MUST_READ_LOR:
    'You must read the letter of response to access the full list of benefits you may lose if you transfer this pension. These can also include Guaranteed Income (Annuity), Income Drawdown and taking your pension as cash.',
  PDF_CARD_TITLE: 'Letter of response',
  PENSION_BENEFITS: 'Pension benefits',
  PENSION_CHARGES: 'Pension charges',
  PENSION_DETAILS: 'Pension details',
  PENSION_DOCUMENTS: 'Pension documents',
  PENSION_VALUATION_DATE: 'Pension valuation date',
  PLAN_NUMBER: 'Plan number:',
  POLICY_FEE: 'Policy fee',
  SAFEGUARDED_BENEFITS: 'Safeguarded benefits',
  SCHEME_PROVIDER: 'Scheme provider',
  READY_TO_TRANSFER: 'Ready to transfer?',
  REVIEW_INFORMATION:
    'Review the information for this pension and {{considerIf}} before you continue.',
  TRANSFER_THIS_PENSION: 'Transfer this pension',
  PENSION_BENEFITS_DESCRIPTION:
    'If you transfer this pension, the benefits you will lose are listed below. For details of the benefits we have checked for, {{glossary}}',
  TOTAL_EXPENSE_RATIO: 'Total expense ratio',
  TRANSFER_VALUE: 'Transfer value',
  VALUABLE_BENEFITS: 'Valuable benefits',
  EXIT_FEE_WARNING: 'There is an exit fee',
  BENEFITS_WARNING: 'You may lose these benefits',
  LOR_FALLBACK_WARNING:
    'The letter from your current provider with the pension information we asked for will be displayed here when ready, and you will then be able to request to transfer this pension. Please check back again soon.',
  YOUR_TRANSFER: 'Your transfer',
  YOUR_TRANSFER_ACCESSIBILITY_LABEL: 'Your transfer status',
  NO_SAFEGUARDED_BENEFITS: 'No safeguarded benefits',
  PENSION_CONSOLIDATION_DETAILS_ERROR:
    "We're unable to display your pension details",
  PENSION_CONSOLIDATION_DETAILS_RETRY: 'Please try again.',
  RETIREMENT_BENEFITS: 'Retirement Options',
  RETIREMENT_BENEFITS_INFORMATION:
    'The retirement options available on this pension.',
  RETIREMENT_BENEFITS_WARNING: 'You may lose these benefits',
  BENEFIT_AVAILABLE: 'YES',
  BENEFIT_NOT_AVAILABLE: 'NO',
} as const;

export const TransferringTooltipCopy = {
  TITLE: 'Consider if transferring is right for you',
  INFORMATION_PROVIDED:
    "We've provided the information and letter of response for each of your pension results to help you decide if you want to transfer that pension from your current provider into a new Aviva SIPP. Please ensure you have reviewed this information carefully as well as the {{termsAndConditions}}.",
  TERMS_AND_CONDITIONS_LINK: 'Terms and Conditions',
  TERMS_AND_CONDITIONS_LINK_HINT: 'Opens pdf',
  CONSIDER_CHARGES_ADVICE:
    'Transferring pensions is not right for everyone and you need to consider the charges, funds and safeguarded and/or valuable benefits that could be lost.',
  DISINVESTED_CAVEAT:
    "While the transfer is taking place you may be disinvested for the time it takes to complete the transfer. This means that you won't benefit from any rise in the price of investments during that time.",
  DECIDE_TO_CANCEL:
    'If you decide to cancel your transfer, your existing provider may not accept your pension back.',
  CAPITAL_AT_RISK:
    "Your capital is at risk and the value of your pension can go down as well as up and you may get back less than you pay in. There is no guarantee you'll be any better off by transferring.",
  GET_ADVICE:
    "If you are unsure about the suitability of transferring you should get advice that you will need to pay for. If you don't have an adviser you can find one at {{advice}}. There are certain circumstances in which you will have to get advice.",
  ADVICE_LINK: 'unbiased.co.uk',
} as const;

export const YouMayLoseBenefitsConstants = {
  YOU_MAY_LOSE_BENEFITS_TITLE: 'You may lose benefits',
  YOU_MAY_LOSE_BENEFITS:
    'You may lose benefits by transferring your selected pension. Please ensure you have reviewed your pension details before continuing with your transfer.',
  BUTTON_CONTINUE: 'Continue with transfer',
  BUTTON_CANCEL: 'Cancel',
};

export const ValuableBenefitsCopy = {
  NO_VALUABLE_BENEFITS_FALLBACK: 'Check your letter of response',
};

export const RetirementBenefitsTitles = {
  hasGuaranteedIncome: 'Guaranteed income (annuity)',
  hasIncomeDrawdown: 'Income drawdown',
  hasTakeYourPensionAsCash: 'Take your pension as cash',
};

export const RetirementBenefitsAnalyticsTags = [
  'ukmyaviva|wealth|find-and-combine|dashboard|guaranteed-income-tapped',
  'ukmyaviva|wealth|find-and-combine|dashboard|income-drawdown-tapped',
  'ukmyaviva|wealth|find-and-combine|dashboard|take-as-cash-tapped',
];
