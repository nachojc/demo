import { usePensionConsolidationDetails } from '@direct-wealth/common/hooks/use-pension-consolidation-details';
import { usePensionConsolidationSummary } from '@direct-wealth/common/hooks/use-pension-consolidation-summary';
import { useSupportPhoneNumbers } from '@direct-wealth/features/sipp-transfer/navigation/provider/state/hooks/use-support-phone-numbers';
import {
  TransferInformation,
  TransferStatus,
} from '@direct-wealth/validation/schemas/pension-consolidation-summary';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { convertToKebabCase } from '@src/utils/convert-to-kebab-case';
import { removeSpecialCharacters } from '@src/utils/string-manipulation/edit-strings';
import { PdfSourceFactory } from '@utils/download-pdf/pdf-source';
import { useState } from 'react';

import {
  ACTION_MAY_LOSE_BENEFITS_CANCEL_TAPPED,
  ACTION_MAY_LOSE_BENEFITS_CONTINUE_TAPPED,
  PENSION_DETAILS_PREFIX,
} from './analytics';

export const usePensionDetailsViewModel = (secureId: string) => {
  const [isLoseBenefitsDialogVisible, setIsLoseBenefitsDialogVisible] =
    useState(false);
  const { navigate } = useAppStackNavigation();
  const {
    data: pensionDetails,
    isError,
    isLoading,
    refetch,
  } = usePensionConsolidationDetails(secureId);

  const analytics = useAnalytics();

  useOnPageLoad({ pageTag: PENSION_DETAILS_PREFIX });

  const supportPhoneNumbersData = useSupportPhoneNumbers();

  const [pensionConsolidationSummaryData] = usePensionConsolidationSummary();

  const letterOfResponseDocumentIdValue = pensionDetails
    ?.letterOfResponseDocumentId.value as string;

  const transferInformation =
    pensionConsolidationSummaryData?.pensionsNotInTransfer?.find(
      (p) => p.secureId === secureId
    )?.information as TransferInformation;

  const transferStatus =
    pensionConsolidationSummaryData?.pensionsInTransfer?.find(
      (p) => p.secureId === secureId
    )?.transferStatus as TransferStatus;

  const pensionCanBeConsolidated =
    transferInformation === 'EligibleToTransfer' ||
    transferInformation === 'MayLoseBenefits';

  const sendTooltipPressed = (tooltipName: string) => {
    const str = convertToKebabCase(removeSpecialCharacters(tooltipName));
    analytics.trackUserEvent(`${PENSION_DETAILS_PREFIX}|tooltip|${str}-tapped`);
  };

  const sendMayLoseBenefitsContinuePressed = () => {
    analytics.trackUserEvent(ACTION_MAY_LOSE_BENEFITS_CONTINUE_TAPPED);
  };

  const sendMayLoseBenefitsCancelPressed = () => {
    analytics.trackUserEvent(ACTION_MAY_LOSE_BENEFITS_CANCEL_TAPPED);
  };

  const onStartTransferRequestPress = () => {
    if (transferInformation === 'MayLoseBenefits') {
      setIsLoseBenefitsDialogVisible(true);
    } else {
      startTransferRequest();
    }
  };

  const handleOnLetterOfResponseClick = () => {
    analytics.trackUserEvent(
      `${PENSION_DETAILS_PREFIX}|pdf|${convertToKebabCase(
        'letter-of-response'
      )}-tapped`
    );
    navigate('Pdf View', {
      pdfSource: PdfSourceFactory.fromDocumentId(
        letterOfResponseDocumentIdValue
      ),
      isDW: true,
      name: 'Letter of response',
    });
  };

  const startTransferRequest = () => {
    if (transferInformation === 'MayLoseBenefits') {
      sendMayLoseBenefitsContinuePressed();
    }
    setIsLoseBenefitsDialogVisible(false);
    navigate('SIPP Transfer', {
      screen: 'Before You Start',
      params: { secureId },
    });
  };

  const onLoseBenefitDialogCancelPress = () => {
    setIsLoseBenefitsDialogVisible(false);
    sendMayLoseBenefitsCancelPressed();
  };

  return {
    refetch,
    isLoading,
    isError,
    pensionDetails,
    pensionCanBeConsolidated,
    transferInformation,
    sendTooltipPressed,
    sendMayLoseBenefitsCancelPressed,
    sendMayLoseBenefitsContinuePressed,
    transferStatus,
    isLoseBenefitsDialogVisible,
    onStartTransferRequestPress,
    startTransferRequest,
    onLoseBenefitDialogCancelPress,
    handleOnLetterOfResponseClick,
    supportPhoneNumbersData,
  };
};
