import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';

import { usePensionDetailsViewModel } from './use-pension-details-view-model';

export type ModalContent = { title: string; body: string };

export type PensionDetailsRouteProps = NativeStackScreenProps<
  AppStackDWRouteParams,
  'Pension Details'
>['route'];

export type PensionDetailsViewProps = {
  model: ReturnType<typeof usePensionDetailsViewModel>;
};
