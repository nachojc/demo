import { PAGE_WEALTH } from '@constants/analytics';

export const PENSION_DETAILS_PREFIX = PAGE_WEALTH + `|pcs|pension-details`;

export const PAGE_MAY_LOSE_BENEFITS_OVERLAY =
  PENSION_DETAILS_PREFIX + `|may-lose-benefits-overlay`;
export const ACTION_MAY_LOSE_BENEFITS_CONTINUE_TAPPED =
  PENSION_DETAILS_PREFIX + `|may-lose-benefits-overlay|continue-tapped`;
export const ACTION_MAY_LOSE_BENEFITS_CANCEL_TAPPED =
  PENSION_DETAILS_PREFIX + `|may-lose-benefits-overlay|cancel-tapped`;

export const CONSIDER_TRANSFER_MODAL = '|consider-transferring|modal';
export const CONSIDER_TRANSFER_MODAL_CLOSED_TAPPED =
  CONSIDER_TRANSFER_MODAL + '|closed-tapped';

export const ACTION_READY_TO_TRANSFER_TAPPED =
  PENSION_DETAILS_PREFIX + `|ready-to-transfer-tapped`;

export const ACTION_READY_TO_CONSOLIDATE_MODAL_ADVICE_TAPPED =
  PENSION_DETAILS_PREFIX + CONSIDER_TRANSFER_MODAL + '|unbiased-tapped';

export const ACTION_READY_TO_CONSOLIDATE_MODAL_TERMS_TAPPED =
  PENSION_DETAILS_PREFIX + CONSIDER_TRANSFER_MODAL + '|terms-tapped';
