import { styled, YStack } from '@aviva/ion-mobile';

export const ErrorBenefitsContainer = styled(YStack, {
  name: 'Error Benefits Container',
  paddingLeft: '$xl',
  paddingTop: '$sm',
});
