import { render, screen } from '@src/jest/testing-library';
import { NavigationContainer } from '@react-navigation/native';
import { NavbarProvider } from '@src/common/providers/nav-control';

import { NuanceChatOnboardingScreen } from '../nuance-onboarding';

jest.useFakeTimers();

const NuanceChatOnboardingTestScreen = () => (
  <NavigationContainer>
    <NavbarProvider>
      <NuanceChatOnboardingScreen
        isModalVisible
        onClose={() => console.log('close')}
        onPress={() => console.log('press')}
      />
    </NavbarProvider>
  </NavigationContainer>
);

describe('async onboarding screen', () => {
  it('render header', () => {
    render(<NuanceChatOnboardingTestScreen />);

    expect(screen.getByTestId('image')).toBeOnTheScreen();
    expect(screen.getByText('Help and support')).toBeOnTheScreen();
    expect(
      screen.getByText(
        'As a Wealth customer you can now message our support team from your app.'
      )
    ).toBeOnTheScreen();
  });

  it('render list', () => {
    render(<NuanceChatOnboardingTestScreen />);

    expect(screen.getByText('Flexible and convenient')).toBeOnTheScreen();
    expect(
      screen.getByText('Quick responses whenever possible')
    ).toBeOnTheScreen();
    expect(
      screen.getByText("We'll let you know when we're in touch")
    ).toBeOnTheScreen();

    expect(
      screen.getByText(
        "Contact us 24 hours a day. We'll respond during our operating hours 8am-5:30pm Monday to Friday."
      )
    ).toBeOnTheScreen();
    expect(
      screen.getByText(
        'For some queries we may be able to provide an automated answer straight away.'
      )
    ).toBeOnTheScreen();
    expect(
      screen.getByText(
        "If we aren't available, we'll send you a notification when we respond if you have them turned on."
      )
    ).toBeOnTheScreen();
  });

  it('render button', () => {
    render(<NuanceChatOnboardingTestScreen />);

    const button = screen.getByTestId('test:id/start-chat');
    expect(button).toBeOnTheScreen();
  });
});
