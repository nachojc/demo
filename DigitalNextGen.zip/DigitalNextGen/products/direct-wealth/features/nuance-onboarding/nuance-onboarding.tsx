import {
  Button,
  getTokens,
  getVariableValue,
  Icon,
  Image,
  Modal,
  Stack,
  styled,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { Text as RNText } from 'react-native';

const title = [
  'Flexible and convenient',
  'Quick responses whenever possible',
  "We'll let you know when we're in touch",
];
const copy = [
  "Contact us 24 hours a day. We'll respond during our operating hours 8am-5:30pm Monday to Friday.",
  'For some queries we may be able to provide an automated answer straight away.',
  "If we aren't available, we'll send you a notification when we respond if you have them turned on.",
];

type ListItemProp = {
  title: string;
  copy: string;
  icon: React.ReactNode;
};

const ListItem = (props: ListItemProp) => {
  return (
    <XStack mt="$xxl">
      {props.icon && <Stack mr="$md">{props.icon}</Stack>}
      <YStack f={1}>
        <Text
          fontVariant="body-semibold-White"
          tamaguiTextProps={{
            lineHeight: 20.11,
          }}
        >
          {props.title}
        </Text>
        <Text
          fontVariant="small-regular-White"
          tamaguiTextProps={{
            lineHeight: 17.6,
          }}
        >
          {props.copy}
        </Text>
      </YStack>
    </XStack>
  );
};

const NumberedIcon = ({ num }: { num: string }) => (
  <Stack>
    <Icon name="number-ellipse" />
    <RNText
      style={{
        fontWeight: 'bold',
        position: 'absolute',
        left: 0,
        right: 0,
        lineHeight: 24,
        textAlign: 'center',
      }}
    >
      {num}
    </RNText>
  </Stack>
);

type NuanceChatOnboardingProps = {
  isModalVisible: boolean;
  onClose: () => void;
  onPress: () => void;
};

export const NuanceChatOnboardingScreen = ({
  isModalVisible,
  onClose,
  onPress,
}: NuanceChatOnboardingProps) => {
  const tokens = getTokens();

  return (
    <Modal
      isOpen={isModalVisible}
      onClose={onClose}
      closeIconColor="White"
      backgroundColor="WealthBlue"
      bottomPadding={getVariableValue(tokens.space.xxl)}
    >
      <OnboardingContainer testID={getTestId('chat-window')}>
        <Stack>
          <Image
            testID="image"
            accessibilityIgnoresInvertColors
            source={require('assets/phone/phone.png')}
            resizeMode="contain"
            style={{
              marginTop: getVariableValue(tokens.space.$md),
              marginBottom: getVariableValue(tokens.space.$xxxl),
              width: getVariableValue(tokens.size[14]),
              height: getVariableValue(tokens.size[14]),
              alignSelf: 'center',
            }}
          />
          <YStack>
            <Text
              fontVariant="heading3-semibold-White"
              tamaguiTextProps={{
                lineHeight: 30.17,
                mb: '$md',
              }}
            >
              Help and support
            </Text>
            <Text
              fontVariant="small-regular-White"
              tamaguiTextProps={{
                lineHeight: 17.6,
              }}
            >
              As a Wealth customer you can now message our support team from
              your app.
            </Text>
          </YStack>
          <YStack>
            <ListItem
              title={title[0]}
              copy={copy[0]}
              icon={<NumberedIcon num="1" />}
            />
            <ListItem
              title={title[1]}
              copy={copy[1]}
              icon={<NumberedIcon num="2" />}
            />
            <ListItem
              title={title[2]}
              copy={copy[2]}
              icon={<NumberedIcon num="3" />}
            />
          </YStack>
        </Stack>
        <YStack tabletNarrow={isIpad} pb={isIpad ? '$xxxxl' : undefined}>
          <Button onPress={onPress} testID={getTestId('start-chat')}>
            Start a conversation
          </Button>
        </YStack>
      </OnboardingContainer>
    </Modal>
  );
};

const OnboardingContainer = styled(YStack, {
  f: 1,
  jc: 'space-between',
  tablet: isIpad,
});
