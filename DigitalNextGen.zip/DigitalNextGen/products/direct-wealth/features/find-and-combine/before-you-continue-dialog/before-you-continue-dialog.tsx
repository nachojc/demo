import {
  Button,
  ButtonVariant,
  Dialog,
  getVariableValue,
  Icon,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useTrackStateEvent } from '@hooks/use-analytics';
import { config } from '@src/common/config';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { useCallback } from 'react';

import { WORKPLACE_WARNING } from './analytics';
import { BeforeYouContinueDialogConstants } from './constants';
import { useBeforeYouContinueDialogAnalytics } from './hooks/use-before-you-continue-dialog-analytics';

const { HEADING, SUBHEADING, CONTINUE, GO_TO_OUR_WEBSITE, CANCEL } =
  BeforeYouContinueDialogConstants;

type BeforeYouContinueDialogProps = {
  isVisible: boolean;
  onClose: () => void;
  onContinuePress: () => void;
};

export const BeforeYouContinueDialog = ({
  isVisible,
  onClose,
  onContinuePress,
}: BeforeYouContinueDialogProps) => {
  const {
    sendWorkplaceWarningCancelTapped,
    sendWorkplaceWarningContinueTapped,
    sendWorkplaceWarningGoToWebsiteTapped,
  } = useBeforeYouContinueDialogAnalytics();

  useTrackStateEvent(WORKPLACE_WARNING);
  const { navigate } = useAppStackNavigation();

  const handleContinue = useCallback(() => {
    sendWorkplaceWarningContinueTapped();
    onContinuePress();
  }, [sendWorkplaceWarningContinueTapped, onContinuePress]);

  const handleGoToWebView = useCallback(() => {
    sendWorkplaceWarningGoToWebsiteTapped();
    onClose();
    navigate('Web View', {
      url:
        config.AVIVA_BASE_URL.get() + '/retirement/pensions/find-and-combine/',
    });
  }, [onClose, sendWorkplaceWarningGoToWebsiteTapped, navigate]);

  const handleCancel = useCallback(() => {
    sendWorkplaceWarningCancelTapped();
    onClose();
  }, [onClose, sendWorkplaceWarningCancelTapped]);

  return (
    <Dialog
      open={isVisible}
      title={HEADING}
      copy={SUBHEADING}
      center
      icon={
        <Icon
          color={getVariableValue(tokens.color.Information)}
          height={getVariableValue(tokens.size[6])}
          name="info"
          width={getVariableValue(tokens.size[6])}
        />
      }
    >
      <YStack mt="$xl" gap="$md">
        <Button
          variant={ButtonVariant.BRAND}
          onPress={handleContinue}
          accessibilityLabel="Continue"
          testID={getTestId('continue-button')}
        >
          {CONTINUE}
        </Button>
        <Button
          variant={ButtonVariant.OUTLINED}
          onPress={handleGoToWebView}
          accessibilityLabel="Go to our website"
          accessibilityHint="Navigates to the MyAviva website"
          testID={getTestId('go-to-our-website-button')}
          useStyledButtonText={false}
        >
          <Icon
            color={getVariableValue(tokens.color.Secondary800)}
            height={getVariableValue(tokens.size[6])}
            name="external-link"
            width={getVariableValue(tokens.size[6])}
          />
          <Text
            fontVariant={'body-semibold-Secondary800'}
            tamaguiTextProps={{ marginLeft: '$md' }}
          >
            {GO_TO_OUR_WEBSITE}
          </Text>
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={handleCancel}
          accessibilityLabel="Cancel"
          accessibilityHint="Returns to previous screen"
          testID={getTestId('cancel-button')}
        >
          {CANCEL}
        </Button>
      </YStack>
    </Dialog>
  );
};
