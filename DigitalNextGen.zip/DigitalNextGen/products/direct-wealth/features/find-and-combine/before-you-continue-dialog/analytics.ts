import { PAGE_WEALTH } from '@constants/analytics';

export const WORKPLACE_WARNING = `${PAGE_WEALTH}|find-and-combine|before-you-start|workplace-warning-dialog`;
export const WORKPLACE_WARNING_CONTINUE_TAPPED = `${WORKPLACE_WARNING}|continue-tapped`;
export const WORKPLACE_WARNING_GO_TO_WEBSITE_TAPPED = `${WORKPLACE_WARNING}|go-to-website-tapped`;
export const WORKPLACE_WARNING_CANCEL_TAPPED = `${WORKPLACE_WARNING}|cancel-tapped`;
