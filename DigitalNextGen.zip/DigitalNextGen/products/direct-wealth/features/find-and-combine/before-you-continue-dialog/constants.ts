export const BeforeYouContinueDialogConstants = {
  HEADING: 'Before you continue',
  SUBHEADING:
    'If you want to combine pensions into your Aviva workplace pension you’ll need to do this on our website instead.',
  CONTINUE: 'Continue',
  GO_TO_OUR_WEBSITE: 'Go to our website',
  CANCEL: 'Cancel',
};
