import { PAGE_WEALTH } from '@constants/analytics';

export const SIGN_APPLICATION_SCREEN = `${PAGE_WEALTH}|find-and-combine|apply|sign-application`;
export const SIGN_APPLICATION_CLEAR_TAPPED = `${SIGN_APPLICATION_SCREEN}|clear-tapped`;
export const SIGN_APPLICATION_CONTINUE_TAPPED = `${SIGN_APPLICATION_SCREEN}|continue-tapped`;
