import { YStack } from '@aviva/ion-mobile';
import { SignaturePad } from '@direct-wealth/components/signature-pad/signature-pad';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { isIpad } from '@src/utils/is-ipad';
import { isEmptyString } from '@src/utils/string-manipulation';

import { useFindAndCombineStackNavigation } from '../navigation/hooks';
import { useFindAndCombine } from '../navigation/provider/index';
import {
  SIGN_APPLICATION_CLEAR_TAPPED,
  SIGN_APPLICATION_CONTINUE_TAPPED,
  SIGN_APPLICATION_SCREEN,
} from './analytics';

export const SignApplicationScreen = () => {
  const { trackUserEvent } = useAnalytics();
  const { navigate } = useFindAndCombineStackNavigation();
  const findAndCombineState = useFindAndCombine();

  useOnPageLoad({ pageTag: SIGN_APPLICATION_SCREEN });

  const onClearPress = () => {
    trackUserEvent(SIGN_APPLICATION_CLEAR_TAPPED);
    findAndCombineState.signature.set('');
  };

  const onDonePress = (signatureValue: string) => {
    trackUserEvent(SIGN_APPLICATION_CONTINUE_TAPPED);
    if (!isEmptyString(signatureValue)) {
      findAndCombineState.signature.set(signatureValue);
      navigate('Review application');
      return;
    }
    navigate('Your signature', { signatureValue });
  };

  return (
    <YStack
      flex={1}
      paddingHorizontal="$xl"
      paddingVertical="$xl"
      tablet={isIpad}
      mt={isIpad ? '$xxxl' : undefined}
    >
      <SignaturePad
        onClearPress={onClearPress}
        onDonePress={onDonePress}
        screenOrientation="landscape"
      />
    </YStack>
  );
};
