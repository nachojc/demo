import {
  Button,
  EditAddressCard,
  HeadingGroup,
  Icon,
  Link,
  ScrollView,
  Separator,
  Stack,
  Text,
  TextInput,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import {
  AddressForm,
  AddressFormSchema,
} from '@aviva/ion-mobile/components/address-form/types';
import { PostcodeLookup } from '@aviva/ion-mobile/components/postcode-lookup/postcode-lookup';
import { useFindAndCombineCustomerDetails } from '@direct-wealth/common/hooks/use-find-and-combine-customer-details';
import { NationalInsuranceNumberModal } from '@direct-wealth/components/national-insurance-number-modal/national-insurance-number-modal';
import { UpdateYourDetailsDialog } from '@direct-wealth/components/update-details-dialog/update-details-dialog';
import { CustomerAddressDetails } from '@direct-wealth/validation/schemas/find-and-combine/customer-details';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import { useCustomer } from '@hooks/use-customer';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useSelector } from '@legendapp/state/react';
import { PhoneNumberInput } from '@src/components/forms/phone-number-input';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import {
  NationalInsuranceNumberForm,
  NationalInsuranceNumberSchema,
} from '@src/validation/schemas/national-insurance-number-schema';
import {
  PhoneNumberForm,
  PhoneNumberSchema,
} from '@src/validation/schemas/phone-number';
import { Dispatch, SetStateAction, useMemo, useState } from 'react';
import { Controller, useForm, UseFormReturn } from 'react-hook-form';
import { Keyboard } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AddAddressModal } from '../address-entry-modals/add-address-modal';
import { EditAddressModal } from '../address-entry-modals/edit-address-modal';
import { useFindAndCombineStackNavigation } from '../navigation/hooks';
import { useFindAndCombine } from '../navigation/provider';
import { FindAndCombineStepper } from '../stepper/find-and-combine-stepper';
import {
  YOUR_DETAILS,
  YOUR_DETAILS_CONTINUE_TAPPED,
  YOUR_DETAILS_EDIT_ADDRESS_CARD_TAPPED,
  YOUR_DETAILS_EDIT_ADDRESS_CLOSE_TAPPED,
  YOUR_DETAILS_EDIT_ADDRESS_REMOVE_ADDRESS_TAPPED,
  YOUR_DETAILS_EDIT_ADDRESS_UPDATE_ADDRESS_TAPPED,
  YOUR_DETAILS_ENTER_ADDRESS_MANUALLY_ADD_ADDRESS_TAPPED,
  YOUR_DETAILS_ENTER_ADDRESS_MANUALLY_CLOSE_TAPPED,
  YOUR_DETAILS_ENTER_ADDRESS_MANUALLY_TAPPED,
  YOUR_DETAILS_NINO_TOOLTIP_TAPPED,
  YOUR_DETAILS_POSTCODE_LOOKUP_TAPPED,
  YOUR_DETAILS_UPDATE_ADDRESS_TAPPED,
  YOUR_DETAILS_UPDATE_DETAILS_DIALOG,
  YOUR_DETAILS_UPDATE_DETAILS_DIALOG_CANCEL_TAPPED,
  YOUR_DETAILS_UPDATE_DETAILS_DIALOG_CONTINUE_TAPPED,
  YOUR_DETAILS_UPDATE_NAME_TAPPED,
} from './analytics';

export const YourDetailsScreen = () => {
  useOnPageLoad({ pageTag: YOUR_DETAILS });
  const safeAreaInsets = useSafeAreaInsets();
  const { trackUserEvent } = useAnalytics();
  const findAndCombineState = useFindAndCombine();
  const { navigate } = useFindAndCombineStackNavigation();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourDetails',
  });

  const [dialogInfo, setDialogInfo] = useState({
    isVisible: false,
    title: t('updateNameDialogTitle'),
  });

  const { data: customerDetails, isSuccess } =
    useFindAndCombineCustomerDetails();

  const ninoForm = useForm<NationalInsuranceNumberForm>({
    resolver: zodResolver(NationalInsuranceNumberSchema),
    mode: 'onChange',
    defaultValues: {
      nationalInsuranceNumber: undefined,
    },
  });

  const phoneNumberForm = useForm<PhoneNumberForm>({
    resolver: zodResolver(PhoneNumberSchema),
    mode: 'onChange',
    defaultValues: {
      phoneNumber: {
        number: undefined,
        country: {
          code: '+44',
          name: 'United Kingdom',
        },
      },
    },
  });

  const hasMobileNumber = customerDetails?.hasMobileNumber;
  const hasNationalInsuranceNumber =
    customerDetails?.hasNationalInsuranceNumber;
  const stateAddress = useSelector(
    findAndCombineState.personalInformation.address
  );
  const hasAddress = customerDetails?.address != null || stateAddress != null;

  const isCTAEnabled = useMemo(() => {
    if (hasMobileNumber && hasNationalInsuranceNumber && hasAddress) {
      return true;
    }
    if (!hasMobileNumber && !hasNationalInsuranceNumber) {
      return (
        ninoForm.formState.isValid &&
        phoneNumberForm.formState.isValid &&
        hasAddress
      );
    }
    if (hasMobileNumber && !hasNationalInsuranceNumber) {
      return ninoForm.formState.isValid && hasAddress;
    }
    if (!hasMobileNumber && hasNationalInsuranceNumber) {
      return phoneNumberForm.formState.isValid && hasAddress;
    }
    return false;
  }, [
    hasAddress,
    hasMobileNumber,
    hasNationalInsuranceNumber,
    ninoForm.formState.isValid,
    phoneNumberForm.formState.isValid,
  ]);

  if (!isSuccess) {
    return null;
  }

  const { address } = customerDetails;

  const onContinuePress = () => {
    const { nationalInsuranceNumber } = ninoForm.getValues();
    const { phoneNumber } = phoneNumberForm.getValues();

    if (nationalInsuranceNumber != null) {
      findAndCombineState.personalInformation.nationalInsuranceNumber.set(
        nationalInsuranceNumber
      );
    }

    if (phoneNumber.number != null) {
      findAndCombineState.personalInformation.mobileNumber.set({
        number: phoneNumber.number,
        code: phoneNumber.country.code,
        name: phoneNumber.country.name,
      });
    }

    Keyboard.dismiss();
    trackUserEvent(YOUR_DETAILS_CONTINUE_TAPPED);
    navigate('Your pensions');
  };

  const onUpdateDetailsDialogContinuePress = () => {
    trackUserEvent(YOUR_DETAILS_UPDATE_DETAILS_DIALOG_CONTINUE_TAPPED);
    setDialogInfo({ isVisible: false, title: t('updateName') });
  };

  const onUpdateDetailsDialogCancelPress = () => {
    trackUserEvent(YOUR_DETAILS_UPDATE_DETAILS_DIALOG_CANCEL_TAPPED);
    setDialogInfo({ isVisible: false, title: t('updateName') });
  };

  return (
    <ScrollView
      contentContainerStyle={{
        flexGrow: 1,
        paddingHorizontal: tokens.space.xl.val,
        paddingBottom: safeAreaInsets.bottom + tokens.space.xxl.val,
        paddingTop: tokens.space.xs.val,
      }}
      automaticallyAdjustKeyboardInsets
      showsVerticalScrollIndicator={false}
      keyboardShouldPersistTaps="handled"
    >
      <YStack tablet={isIpad} flex={isIpad ? 1 : undefined}>
        <FindAndCombineStepper screen={'Your details'} />
        <YStack justifyContent="space-between" flex={1} mt={'$xs'}>
          <Stack>
            <HeadingGroup heading={t('title')} subHeading={t('subtitle')} />
            <Separator borderColor="$Gray200" marginVertical="$xxl" />

            <Stack marginBottom={'$xxl'}>
              <CustomerName setDialogInfo={setDialogInfo} />
              {address && (
                <CustomerAddress
                  setDialogInfo={setDialogInfo}
                  address={address}
                />
              )}
              {!hasNationalInsuranceNumber && (
                <NationalInsuranceNumberInput form={ninoForm} />
              )}
              {!hasMobileNumber && <MobileNumberInput form={phoneNumberForm} />}
              {!address && <AddressSection />}
            </Stack>
          </Stack>
          <YStack tabletNarrow={isIpad}>
            <Button disabled={!isCTAEnabled} onPress={onContinuePress}>
              {t('continueCTA')}
            </Button>
          </YStack>
          {dialogInfo.isVisible && (
            <UpdateYourDetailsDialog
              analyticsTag={YOUR_DETAILS_UPDATE_DETAILS_DIALOG}
              isVisible={dialogInfo.isVisible}
              onCancelPress={onUpdateDetailsDialogCancelPress}
              onContinuePress={onUpdateDetailsDialogContinuePress}
              title={dialogInfo.title}
            />
          )}
        </YStack>
      </YStack>
    </ScrollView>
  );
};

const CustomerName = ({
  setDialogInfo,
}: {
  setDialogInfo: Dispatch<
    SetStateAction<{
      isVisible: boolean;
      title: string;
    }>
  >;
}) => {
  const { data: customer, isSuccess } = useCustomer();
  const analytics = useAnalytics();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourDetails',
  });

  const onUpdateNamePress = () => {
    setDialogInfo({
      isVisible: true,
      title: t('updateNameDialogTitle'),
    });
    analytics.trackUserEvent(YOUR_DETAILS_UPDATE_NAME_TAPPED);
  };

  if (!isSuccess) {
    return null;
  }
  return (
    <YStack space={'$md'} marginBottom={'$xxl'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {t('name')}
      </Text>
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >{`${customer.Firstname} ${customer.Surname}`}</Text>
      <Link
        LinkTextProps={{
          fontSize: '$small',
          textDecorationLine: 'underline',
        }}
        onPress={onUpdateNamePress}
      >
        {t('updateName')}
      </Link>
    </YStack>
  );
};

const CustomerAddress = ({
  address,
  setDialogInfo,
}: {
  address: CustomerAddressDetails;
  setDialogInfo: Dispatch<
    SetStateAction<{
      isVisible: boolean;
      title: string;
    }>
  >;
}) => {
  const analytics = useAnalytics();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourDetails',
  });
  const {
    firstLineOfAddress,
    secondLineOfAddress,
    thirdLineOfAddress,
    townOrCity,
    postcode,
    region,
    country,
  } = address;

  const onUpdateAddressPress = () => {
    setDialogInfo({
      isVisible: true,
      title: t('updateAddressDialogTitle'),
    });
    analytics.trackUserEvent(YOUR_DETAILS_UPDATE_ADDRESS_TAPPED);
  };
  return (
    <YStack space={'$md'} marginBottom={'$xxl'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {t('address')}
      </Text>
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {firstLineOfAddress}
        {secondLineOfAddress ? `\n${secondLineOfAddress}` : ''}
        {thirdLineOfAddress ? `\n${thirdLineOfAddress}` : ''}
        {`\n${townOrCity}`}
        {region ? `\n${region}` : ''}
        {`\n${postcode}`}
        {`\n${country}`}
      </Text>
      <Link
        LinkTextProps={{ fontSize: '$small', textDecorationLine: 'underline' }}
        onPress={onUpdateAddressPress}
      >
        {t('updateAddress')}
      </Link>
    </YStack>
  );
};

const NationalInsuranceNumberInput = ({
  form,
}: {
  form: UseFormReturn<NationalInsuranceNumberForm>;
}) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourDetails',
  });
  const analytics = useAnalytics();

  const [ninoModalIsVisible, setNinoModalIsVisible] = useState(false);

  const onTooltipPress = () => {
    analytics.trackUserEvent(YOUR_DETAILS_NINO_TOOLTIP_TAPPED);
    setNinoModalIsVisible(true);
  };
  return (
    <Stack space={'$md'} marginBottom={'$xxl'}>
      <XStack justifyContent="space-between">
        <Text fontVariant="body-semibold-Secondary800">
          {t('ninoInputTitle')}
        </Text>
        <Stack
          onPress={onTooltipPress}
          hitSlop={{ top: 24, bottom: 24, left: 24, right: 24 }}
          accessible
          accessibilityRole={'button'}
          accessibilityHint={t('ninoInputAccessibilityHint')}
        >
          <Icon
            color={tokens.color.Secondary800.val}
            height={tokens.size[5].val}
            name="info"
            width={tokens.size[5].val}
          />
        </Stack>
      </XStack>
      <Text fontVariant="body-regular-Secondary800">
        {t('ninoInputDescription')}
      </Text>
      <Controller
        name={'nationalInsuranceNumber'}
        control={form.control}
        render={({ field: { onChange, value }, fieldState }) => {
          return (
            <TextInput
              testID={getTestId('nino-input')}
              tamaguiInputProps={{
                value,
                onChangeText: onChange,
                placeholder: t('ninoInputPlaceholder'),
                returnKeyType: 'done',
                onSubmitEditing: () => Keyboard.dismiss(),
              }}
              error={fieldState.invalid}
              errorText={t('ninoInputError')}
            />
          );
        }}
      />
      <NationalInsuranceNumberModal
        isVisible={ninoModalIsVisible}
        setIsVisible={setNinoModalIsVisible}
        pageTag={YOUR_DETAILS}
      />
    </Stack>
  );
};

const MobileNumberInput = ({
  form,
}: {
  form: UseFormReturn<PhoneNumberForm>;
}) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourDetails',
  });
  return (
    <Stack space={'$md'} marginBottom={'$xxl'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {t('mobileNumberInputTitle')}
      </Text>
      <Text
        fontVariant="small-regular-Secondary800"
        tamaguiTextProps={{ lineHeight: '$overline' }}
      >
        {t('mobileNumberInputDescription')}
      </Text>
      <Controller
        name={'phoneNumber'}
        control={form.control}
        render={({ field: { onChange, value }, fieldState }) => {
          const { country, number } = value;
          return (
            <PhoneNumberInput
              countryCode={country}
              number={number}
              onChange={onChange}
              error={fieldState.invalid}
              errorText={t('mobileNumberInputError')}
              placeholder={t('mobileNumberInputPlaceholder')}
            />
          );
        }}
      />
    </Stack>
  );
};

const AddressSection = () => {
  const analytics = useAnalytics();
  const findAndCombineState = useFindAndCombine();

  const [isAddAddressModalVisible, setIsAddAddressModalVisible] =
    useState(false);
  const [isEditAddressModalVisible, setIsEditAddressModalVisible] =
    useState(false);

  const address = findAndCombineState.personalInformation.address.get();
  const defaultCountry = 'United Kingdom';
  const defaultAddress = {
    lineOne: '',
    lineTwo: null,
    lineThree: null,
    town: '',
    postcode: '',
  };

  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourDetails',
  });

  const hasCustomerAddress =
    findAndCombineState.personalInformation.address.get() !== undefined;

  const addressForm = useForm<AddressForm>({
    resolver: zodResolver(AddressFormSchema),
    defaultValues: defaultAddress,
    mode: 'onChange',
  });

  const onEnterAddressManuallyPressed = () => {
    analytics.trackUserEvent(YOUR_DETAILS_ENTER_ADDRESS_MANUALLY_TAPPED);
    setIsAddAddressModalVisible(true);
    addressForm.reset(defaultAddress);
  };

  const onEditAddressPressed = () => {
    analytics.trackUserEvent(YOUR_DETAILS_EDIT_ADDRESS_CARD_TAPPED);
    setIsEditAddressModalVisible(true);
    populateCurrentAddress();
  };

  const handleCloseAddAddressModal = () => {
    setIsAddAddressModalVisible(false);
    addressForm.reset();
  };

  const handleCloseEditAddressModal = () => {
    setIsEditAddressModalVisible(false);
    addressForm.reset();
  };

  const onCloseAddAddressModalPressed = () => {
    analytics.trackUserEvent(YOUR_DETAILS_ENTER_ADDRESS_MANUALLY_CLOSE_TAPPED);
    handleCloseAddAddressModal();
  };

  const onCloseEditAddressModalPressed = () => {
    analytics.trackUserEvent(YOUR_DETAILS_EDIT_ADDRESS_CLOSE_TAPPED);
    handleCloseEditAddressModal();
  };

  const setAddressState = () => {
    const addressValues = addressForm.getValues();
    findAndCombineState.personalInformation.address.set({
      firstLineOfAddress: addressValues.lineOne,
      secondLineOfAddress: addressValues.lineTwo ?? '',
      thirdLineOfAddress: addressValues.lineThree ?? '',
      townOrCity: addressValues.town,
      postcode: addressValues.postcode,
      country: defaultCountry,
    });
  };

  const onAddAddressPressed = () => {
    analytics.trackUserEvent(
      YOUR_DETAILS_ENTER_ADDRESS_MANUALLY_ADD_ADDRESS_TAPPED
    );
    setAddressState();
    handleCloseAddAddressModal();
  };

  const onUpdateAddressPressed = () => {
    analytics.trackUserEvent(YOUR_DETAILS_EDIT_ADDRESS_UPDATE_ADDRESS_TAPPED);
    setAddressState();
    handleCloseEditAddressModal();
  };

  const onPostcodeLookupPressed = () => {
    analytics.trackUserEvent(YOUR_DETAILS_POSTCODE_LOOKUP_TAPPED);
  };

  const populateCurrentAddress = () => {
    const currentAddress = {
      lineOne: address.firstLineOfAddress ?? '',
      lineTwo: address.secondLineOfAddress,
      lineThree: address.thirdLineOfAddress,
      town: address.townOrCity ?? '',
      postcode: address.postcode ?? '',
    };

    addressForm.reset(currentAddress);
  };

  const onRemoveAddressPressed = () => {
    analytics.trackUserEvent(YOUR_DETAILS_EDIT_ADDRESS_REMOVE_ADDRESS_TAPPED);
    findAndCombineState.personalInformation.address.set(undefined);
    handleCloseEditAddressModal();
  };

  return (
    <YStack>
      {hasCustomerAddress ? (
        <EditAddressCard
          cardContent={address}
          onCardPress={onEditAddressPressed}
        />
      ) : (
        <>
          <PostcodeLookup
            form={addressForm}
            onAddressSelect={setAddressState}
            onPostcodeSearchTapped={onPostcodeLookupPressed}
          />
          <Link onPress={onEnterAddressManuallyPressed}>
            {t('addManuallyCTA')}
          </Link>
        </>
      )}
      <AddAddressModal
        isVisible={isAddAddressModalVisible}
        addressForm={addressForm}
        onAddAddressPressed={onAddAddressPressed}
        onClosePressed={onCloseAddAddressModalPressed}
      />
      <EditAddressModal
        isVisible={isEditAddressModalVisible}
        addressForm={addressForm}
        onUpdateAddressPressed={onUpdateAddressPressed}
        onRemoveAddressPressed={onRemoveAddressPressed}
        onClosePressed={onCloseEditAddressModalPressed}
      />
    </YStack>
  );
};
