import {
  Button,
  ButtonVariant,
  ScrollView,
  Separator,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { EmptyProductCard } from '@aviva/ion-mobile/components/cards/empty-product-card/empty-product-card';
import { DeletePensionDialog } from '@direct-wealth/components/delete-pension-dialog';
import { PensionDetailsCard } from '@direct-wealth/components/pension-details-card';
import { PensionRemovedSnackbar } from '@direct-wealth/components/pension-removed-snackbar';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect } from 'react';

import { FindAndCombineStepper } from '../stepper/find-and-combine-stepper';
import { PENSION_DETAILS_SCREEN } from './analytics';
import { useYourPensionsViewModel } from './use-your-pensions-view-model';

export type YourPensionsViewProps = {
  model: ReturnType<typeof useYourPensionsViewModel>;
};

export const YourPensionsView = ({ model }: YourPensionsViewProps) => {
  const {
    deletePensionDialogTag,
    generateKeyValue,
    handleAddAnotherPensionButton,
    handleAddFirstPensionButton,
    handleCancelDeletePension,
    handleConfirmDelete,
    handleContinueButton,
    handleEmptyCardButton,
    handleRemovePensionButton,
    handleSnackbarUndo,
    isRemoveDialogOpen,
    showSnackbar,
    yourPensionsData,
    handleSnackbarCompletion,
  } = model;

  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourPensions',
  });

  const pensions = yourPensionsData;

  useOnPageLoad({ pageTag: PENSION_DETAILS_SCREEN });

  const isAddAnotherRequired = pensions.length < 5 && !!pensions.length;

  const { elementRef: addPensionRef, focus: focusAddPension } = useA11yFocus();

  useEffect(() => {
    if (!showSnackbar) {
      focusAddPension();
    }
  }, [showSnackbar]);

  return (
    <ScrollView
      contentContainerStyle={{ flexGrow: 1 }}
      showsVerticalScrollIndicator={false}
      paddingHorizontal={'$xl'}
    >
      <YStack tablet={isIpad} flex={1}>
        <FindAndCombineStepper screen={'Pension details'} />
        <YStack marginTop={tokens.space.md.val} accessible>
          <Text fontVariant="heading2-regular-Secondary800">{t('title')}</Text>
          <Text fontVariant="heading4-light-Gray800">{t('subtitle')}</Text>
        </YStack>
        <Separator borderColor="$Gray300" marginVertical="$xxl" />
        {!pensions.length && (
          <EmptyProductCard
            title={t('emptyProductCardHeading')}
            description={t('addPensionDetails')}
            onPress={handleEmptyCardButton}
            cardRef={addPensionRef}
          />
        )}
        <YStack gap="$xxl">
          {!!pensions.length &&
            pensions.map((pension, index) => {
              const heading =
                pension?.pensionProviderName ?? `Unknown provider`;
              const planNumber = pension?.planNumber ?? `Not provided`;
              const employerName = pension?.employerName ?? '';
              const employmentStartDate = pension?.startDate;
              const employmentEndDate = pension?.endDate;
              let employmentDates = '';
              if (employmentStartDate && employmentEndDate) {
                employmentDates = `${employmentStartDate} - ${employmentEndDate}`;
              }

              return (
                <PensionDetailsCard
                  key={`${index}-${planNumber}`}
                  heading={heading}
                  pensionDetails={generateKeyValue(
                    planNumber,
                    employerName,
                    employmentDates
                  )}
                  actionButton={{
                    icon: 'delete',
                    copy: 'Remove',
                    onPress: () => {
                      !!pension && handleRemovePensionButton(pension);
                    },
                    accessibilityHint: `Removes ${heading}`,
                  }}
                />
              );
            })}
        </YStack>
        <YStack
          marginTop={52}
          marginBottom={30}
          flexGrow={1}
          justifyContent="flex-end"
        >
          {!pensions.length && (
            <YStack
              tabletNarrow={isIpad}
              paddingBottom={isIpad ? '$xxl' : undefined}
            >
              <Button
                onPress={handleAddFirstPensionButton}
                accessibilityHint={t('moveOntoTheNextStep')}
              >
                {t('addFirstPension')}
              </Button>
            </YStack>
          )}
          {isAddAnotherRequired && (
            <YStack tabletNarrow={isIpad}>
              <Button
                marginBottom={'$xl'}
                variant={ButtonVariant.OUTLINED}
                onPress={handleAddAnotherPensionButton}
                accessibilityLabel={t('addAnotherPension')}
                testID={getTestId('Add another pension Button')}
                ref={addPensionRef}
              >
                {t('addAnotherPension')}
              </Button>
            </YStack>
          )}
          {!!pensions.length && (
            <YStack
              tabletNarrow={isIpad}
              paddingBottom={isIpad ? '$xxl' : undefined}
            >
              <Button
                onPress={handleContinueButton}
                accessibilityLabel="Continue"
                accessibilityHint={t('moveOntoTheNextStep')}
                testID={getTestId('Continue Button')}
              >
                {t('submit')}
              </Button>
            </YStack>
          )}
        </YStack>

        {isRemoveDialogOpen && (
          <DeletePensionDialog
            isOpen={isRemoveDialogOpen}
            onConfirm={handleConfirmDelete}
            onCancel={handleCancelDeletePension}
            screenEventTag={deletePensionDialogTag}
            isLastPension={pensions?.length === 1}
          />
        )}
        {showSnackbar && (
          <PensionRemovedSnackbar
            floatingBottom={
              isIpad && !isAddAnotherRequired ? tokens.size[11].val : undefined
            }
            handleSnackbarUndo={handleSnackbarUndo}
            handleCompletion={handleSnackbarCompletion}
          />
        )}
      </YStack>
    </ScrollView>
  );
};

export const YourPensionsScreen = () => {
  const model = useYourPensionsViewModel();
  return <YourPensionsView model={model} />;
};
