import { useAnalytics } from '@hooks/use-analytics';
import { useSelector } from '@legendapp/state/react';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useCallback, useRef, useState } from 'react';

import { useManageFindAndCombinePensions } from '../hooks/use-manage-pensions/use-manage-pensions';
import { useFindAndCombineStackNavigation } from '../navigation/hooks';
import { useFindAndCombine } from '../navigation/provider';
import { Pensions } from '../navigation/provider/state/pensions';
import {
  PENSION_DETAILS_ADD_ANOTHER_TAPPED,
  PENSION_DETAILS_ADD_FIRST_PENSION_TAPPED,
  PENSION_DETAILS_ADD_PENSION_DETAILS_CARD_TAPPED,
  PENSION_DETAILS_CONTINUE_TAPPED,
  PENSION_DETAILS_REMOVE_LAST_PENSION_DIALOG,
  PENSION_DETAILS_REMOVE_LAST_PENSION_DIALOG_CANCEL_TAPPED,
  PENSION_DETAILS_REMOVE_LAST_PENSION_DIALOG_CONFIRM_TAPPED,
  PENSION_DETAILS_REMOVE_PENSION_DIALOG,
  PENSION_DETAILS_REMOVE_PENSION_DIALOG_CANCEL_TAPPED,
  PENSION_DETAILS_REMOVE_PENSION_DIALOG_CONFIRM_TAPPED,
  PENSION_DETAILS_REMOVE_PENSION_TAPPED,
  PENSION_DETAILS_REMOVE_PENSION_UNDO_TAPPED,
} from './analytics';

type KeyValue = {
  key: string;
  value: string;
};

export const useYourPensionsViewModel = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourPensions',
  });
  const findAndCombineState = useFindAndCombine();
  const { trackUserEvent } = useAnalytics();
  const navigation = useFindAndCombineStackNavigation();
  const [showSnackbar, setShowSnackbar] = useState(false);
  const [isRemoveDialogOpen, setIsRemoveDialogOpen] = useState(false);
  const pensionToBeDeleted = useRef<Pensions>();
  const pensionList = useSelector(findAndCombineState.pensions);
  const { deletePension, markPensionForDeletion, undoMarkPensionForDeletion } =
    useManageFindAndCombinePensions();

  const handleRemovePensionButton = useCallback(
    (pension: Pensions) => {
      trackUserEvent(PENSION_DETAILS_REMOVE_PENSION_TAPPED);
      setIsRemoveDialogOpen(true);
      pensionToBeDeleted.current = pension;
    },
    [trackUserEvent]
  );

  const handleSnackbarCompletion = () => {
    setShowSnackbar(false);
    pensionToBeDeleted.current && deletePension();
    pensionToBeDeleted.current = undefined;
  };

  const handleSnackbarUndo = useCallback(() => {
    trackUserEvent(PENSION_DETAILS_REMOVE_PENSION_UNDO_TAPPED);
    undoMarkPensionForDeletion(pensionToBeDeleted.current);
    pensionToBeDeleted.current = undefined;
    setShowSnackbar(false);
  }, [trackUserEvent, undoMarkPensionForDeletion]);

  const yourPensionsData = pensionList.filter(
    (pension) => !!pension && !pension?.deleted
  );

  const isLastPension = yourPensionsData.length === 1;

  const handleConfirmDelete = useCallback(() => {
    trackUserEvent(
      isLastPension
        ? PENSION_DETAILS_REMOVE_LAST_PENSION_DIALOG_CONFIRM_TAPPED
        : PENSION_DETAILS_REMOVE_PENSION_DIALOG_CONFIRM_TAPPED
    );
    setIsRemoveDialogOpen(false);
    pensionToBeDeleted.current &&
      markPensionForDeletion(pensionToBeDeleted.current);
    setShowSnackbar(true);
  }, [trackUserEvent, isLastPension, markPensionForDeletion, setShowSnackbar]);

  const handleCancelDeletePension = () => {
    trackUserEvent(
      isLastPension
        ? PENSION_DETAILS_REMOVE_LAST_PENSION_DIALOG_CANCEL_TAPPED
        : PENSION_DETAILS_REMOVE_PENSION_DIALOG_CANCEL_TAPPED
    );
    setIsRemoveDialogOpen(false);
  };

  const deletePensionDialogTag = isLastPension
    ? PENSION_DETAILS_REMOVE_LAST_PENSION_DIALOG
    : PENSION_DETAILS_REMOVE_PENSION_DIALOG;

  const handleAddAnotherPensionButton = () => {
    trackUserEvent(PENSION_DETAILS_ADD_ANOTHER_TAPPED);
    navigation.navigate('Add pension');
  };

  const handleContinueButton = () => {
    trackUserEvent(PENSION_DETAILS_CONTINUE_TAPPED);
    navigation.navigate('Previous details');
  };

  const handleEmptyCardButton = () => {
    trackUserEvent(PENSION_DETAILS_ADD_PENSION_DETAILS_CARD_TAPPED);
    navigation.navigate('Add pension');
  };

  const handleAddFirstPensionButton = () => {
    trackUserEvent(PENSION_DETAILS_ADD_FIRST_PENSION_TAPPED);
    navigation.navigate('Add pension');
  };

  const generateKeyValue = (
    planNumber: string,
    employerName: string,
    employmentDates: string
  ): KeyValue[] => {
    const array: KeyValue[] = [];

    if (!employerName && !employmentDates) {
      array.push({ key: t('planNumber'), value: planNumber });
      return array;
    }

    array.push(
      { key: t('employer'), value: employerName },
      { key: t('employmentDates'), value: employmentDates }
    );

    return array;
  };

  return {
    deletePensionDialogTag,
    generateKeyValue,
    handleAddAnotherPensionButton,
    handleAddFirstPensionButton,
    handleCancelDeletePension,
    handleConfirmDelete,
    handleContinueButton,
    handleEmptyCardButton,
    handleRemovePensionButton,
    handleSnackbarUndo,
    isRemoveDialogOpen,
    setIsRemoveDialogOpen,
    showSnackbar,
    yourPensionsData,
    handleSnackbarCompletion,
  };
};
