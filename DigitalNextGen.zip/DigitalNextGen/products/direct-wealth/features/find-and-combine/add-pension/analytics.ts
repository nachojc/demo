import { PAGE_WEALTH } from '@constants/analytics';

export const ADD_PENSION = `${PAGE_WEALTH}|find-and-combine|apply|add-pension`;
export const ADD_PENSION_PENSION_PROVIDER_KNOWN = `${ADD_PENSION}|pension-provider-yes-tapped`;
export const ADD_PENSION_PENSION_PROVIDER_UNKNOWN = `${ADD_PENSION}|pension-provider-no-tapped`;
export const ADD_PENSION_PLAN_NUMBER_TOOLTIP_TAPPED = `${ADD_PENSION}|plan-number-tooltip-tapped`;
export const ADD_PENSION_PLAN_NUMBER_TOOLTIP_CLOSE_TAPPED = `${ADD_PENSION}|plan-number-tooltip|close-tapped`;
export const ADD_PENSION_PROVIDER_TOOLTIP_TAPPED = `${ADD_PENSION}|provider-tooltip-tapped`;
export const ADD_PENSION_PROVIDER_TOOLTIP_CLOSE_TAPPED = `${ADD_PENSION}|provider-tooltip|close-tapped`;
export const ADD_PENSION_EMPLOYMENT_START_DATE_TAPPED = `${ADD_PENSION}|employment-start-date-tapped`;
export const ADD_PENSION_EMPLOYMENT_END_DATE_TAPPED = `${ADD_PENSION}|employment-end-date-tapped`;
export const ADD_PENSION_TAPPED = `${ADD_PENSION}|add-pension-tapped`;
