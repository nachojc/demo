import {
  Button,
  DatePicker,
  Dropdown,
  getVariableValue,
  Icon,
  SegmentedControls,
  Stack,
  Text,
  TextInput,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { formatDateString } from '@src/utils/format-date-string';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { ReactNode, useEffect, useState } from 'react';
import { Controller } from 'react-hook-form';
import { Keyboard } from 'react-native';

import { useAddPensionAnalytics } from './hooks/use-add-pension-analytics';
import { useAddPensionForm } from './hooks/use-add-pension-form';
import { PensionProviderTooltip } from './pension-provider-tooltip/pension-provider-tooltip';
import { PlanNumberToolTip } from './plan-number-tooltip/plan-number-tooltip';

type InputFieldProps = {
  label: string;
  field: ReactNode;
  withMargin?: boolean;
  accessibilityHint?: string;
};

const InputField = ({
  label,
  field,
  withMargin,
  accessibilityHint,
}: InputFieldProps) => (
  <YStack space="$lg" marginBottom={withMargin && '$xxl'}>
    <Text
      fontVariant="body-semibold-Secondary800"
      tamaguiTextProps={{ accessibilityHint }}
    >
      {label}
    </Text>
    {field}
  </YStack>
);

export const AddPensionForm = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.addPension',
  });

  const { form, handleAddPension, pensionProviders } = useAddPensionForm();

  const {
    control,
    watch,
    handleSubmit,
    trigger,
    formState: { errors, isValid },
  } = form;

  const [pensionProviderKnown, employmentStartDate, employmentEndDate] = watch([
    'pensionProviderKnown',
    'employmentStartDate',
    'employmentEndDate',
  ]);

  useEffect(() => {
    if (employmentStartDate && employmentEndDate) {
      if (
        formatDateString(employmentStartDate) >
        formatDateString(employmentEndDate)
      ) {
        form.setError('employmentEndDate', {
          message: t('dateCannotBeBeforeStartDate'),
        });
      } else if (
        'employmentEndDate' in errors &&
        errors.employmentEndDate &&
        errors.employmentEndDate.message === t('dateCannotBeBeforeStartDate')
      ) {
        form.clearErrors('employmentEndDate');
        trigger('employmentEndDate');
      }
    }
  }, [employmentStartDate]);

  const {
    sendEmploymentEndDateInputSelectedAnalytics,
    sendEmploymentStartDateInputSelectedAnalytics,
    sendPensionProviderTooltipAnalytics,
    sendFindAndCombineToolTipTapped,
    sendFindAndCombineToolTipCloseTapped,
    sendPensionProviderToggleSelectedAnalytics,
  } = useAddPensionAnalytics();

  const [isPensionProviderTooltipOpen, setIsPensionProviderTooltipOpen] =
    useState(false);

  const [isPlanNumberTooltipOpen, setIsPlanNumberTooltipOpen] = useState(false);

  const closePlanNumberTooltip = () => {
    sendFindAndCombineToolTipCloseTapped();
    setIsPlanNumberTooltipOpen(false);
  };

  const onPlanNumberTooltipPress = () => {
    sendFindAndCombineToolTipTapped();
    setIsPlanNumberTooltipOpen(!isPlanNumberTooltipOpen);
  };

  useEffect(() => {
    form.clearErrors();
    if (pensionProviderKnown === 'No') {
      form.setValue('pensionProviderName', '');
      return;
    }
    form.setValue('employerName', '');
    form.setValue('employmentStartDate', '');
    form.setValue('employmentEndDate', '');
  }, [pensionProviderKnown, form]);

  return (
    <YStack justifyContent="space-between" flex={1}>
      <Stack>
        <Controller
          name="pensionProviderKnown"
          control={control}
          render={({ field: { onChange } }) => (
            <YStack>
              <XStack justifyContent="space-between" marginBottom="$lg">
                <Stack flex={1} paddingRight="$xxl">
                  <Text fontVariant="body-semibold-Secondary800">
                    {t('labelPensionProvider')}
                  </Text>
                </Stack>
                <Stack
                  onPress={() => {
                    setIsPensionProviderTooltipOpen((isOpen) => !isOpen);
                    sendPensionProviderTooltipAnalytics();
                  }}
                  hitSlop={{ top: 28, bottom: 28, left: 28, right: 28 }}
                  accessible
                  accessibilityRole="button"
                  accessibilityLabel={t('pensionProviderTooltipAccessibility')}
                  testID={getTestId('pension-provider-tooltip')}
                >
                  <Icon
                    color={tokens.color.Secondary800.val}
                    height={tokens.size[5].val}
                    name="info"
                    width={tokens.size[5].val}
                  />
                </Stack>
              </XStack>
              <SegmentedControls
                optionOne="Yes"
                optionTwo="No"
                onChange={(toggleValue) => {
                  onChange(toggleValue ? 'Yes' : 'No');
                  sendPensionProviderToggleSelectedAnalytics(!!toggleValue);
                }}
              />
            </YStack>
          )}
        />
        {pensionProviderKnown === 'Yes' && (
          <>
            <Controller
              name="pensionProviderName"
              control={control}
              render={({ field: { onChange, value } }) => {
                return (
                  <YStack marginTop="$lg">
                    <InputField
                      label="Pension provider"
                      field={
                        <Dropdown
                          required
                          testID={getTestId(
                            'add-pension-provider-name-dropdown'
                          )}
                          value={value}
                          onValueChange={(item) => {
                            const id = pensionProviders.find(
                              (p) => p.name === item
                            )?.id;
                            if (id == null) {
                              return;
                            }
                            form.setValue('pensionProviderId', id);
                            onChange(item);
                          }}
                          items={pensionProviders.map((pp) => pp.name)}
                          selectInputProps={{
                            searchTextPlaceholder: 'Search',
                          }}
                          placeHolderText={'Select company name'}
                          searchBar
                          onExpand={Keyboard.dismiss}
                        />
                      }
                    />
                  </YStack>
                );
              }}
            />
            <Controller
              name="planNumber"
              control={control}
              render={({ field: { onChange, value } }) => {
                return (
                  <InputField
                    label=""
                    accessibilityHint={t('required')}
                    withMargin
                    field={
                      <>
                        <XStack
                          justifyContent="space-between"
                          marginBottom="$lg"
                        >
                          <Text fontVariant="body-semibold-Secondary800">
                            {t('labelPlanNumber')}
                          </Text>
                          <Stack
                            onPress={onPlanNumberTooltipPress}
                            hitSlop={{
                              top: 28,
                              bottom: 28,
                              left: 28,
                              right: 28,
                            }}
                            accessible
                            accessibilityRole="button"
                            accessibilityLabel="Plan Number tooltip."
                            accessibilityHint="Display information modal."
                          >
                            <Icon
                              name="info"
                              color={getVariableValue(
                                tokens.color.Secondary800
                              )}
                              height={getVariableValue(tokens.size[5])}
                              width={getVariableValue(tokens.size[5])}
                            />
                          </Stack>
                        </XStack>
                        <YStack marginBottom={'$md'}>
                          <Text fontVariant="small-regular-Gray800">
                            {t('planNumberSubtitle')}
                          </Text>
                        </YStack>
                        <TextInput
                          testID={getTestId('add-pension-plan-number-input')}
                          required
                          tamaguiInputProps={{
                            value,
                            onChangeText: onChange,
                            placeholder: t('placeHolderPlanNumber'),
                            onSubmitEditing: Keyboard.dismiss,
                          }}
                        />
                      </>
                    }
                  />
                );
              }}
            />
            <PlanNumberToolTip
              isOpen={isPlanNumberTooltipOpen}
              onClose={closePlanNumberTooltip}
            />
          </>
        )}
        {pensionProviderKnown === 'No' && (
          <>
            <Text
              fontVariant="small-regular-Gray800"
              tamaguiTextProps={{
                marginTop: '$xl',
                marginBottom: '$xxl',
              }}
            >
              {t('employmentDetailsText')}
            </Text>
            <Controller
              name="employerName"
              control={control}
              render={({ field: { onChange, value } }) => {
                return (
                  <InputField
                    accessibilityHint={t('required')}
                    label={t('labelEmployerName')}
                    withMargin
                    field={
                      <TextInput
                        testID={getTestId('add-pension-employer-name-input')}
                        required
                        tamaguiInputProps={{
                          value,
                          onChangeText: onChange,
                          placeholder: t('placeHolderEmployerName'),
                          onSubmitEditing: Keyboard.dismiss,
                        }}
                      />
                    }
                  />
                );
              }}
            />
            <Controller
              name="employmentStartDate"
              control={control}
              render={({ field: { onChange, value } }) => {
                return (
                  <InputField
                    label={t('labelEmploymentStartDate')}
                    withMargin
                    field={
                      <DatePicker
                        tamaguiInputProps={{
                          value,
                          onChangeText: onChange,
                          placeholder: 'DD/MM/YYYY',
                          testID: getTestId(
                            `add-pension-employment-start-date-input`
                          ),
                        }}
                        onExpand={sendEmploymentStartDateInputSelectedAnalytics}
                        datePickerProps={{
                          date: value ? formatDateString(value) : new Date(),
                        }}
                        error={
                          'employmentStartDate' in errors &&
                          !!errors.employmentStartDate
                        }
                        errorText={
                          'employmentStartDate' in errors
                            ? errors.employmentStartDate?.message
                            : ''
                        }
                      />
                    }
                  />
                );
              }}
            />
            <Controller
              name="employmentEndDate"
              control={control}
              render={({ field: { onChange, value } }) => {
                return (
                  <InputField
                    label={t('labelEmploymentEndDate')}
                    withMargin
                    field={
                      <DatePicker
                        tamaguiInputProps={{
                          value,
                          onChangeText: onChange,
                          placeholder: 'DD/MM/YYYY',
                          testID: getTestId(
                            `add-pension-employment-end-date-input`
                          ),
                        }}
                        onExpand={sendEmploymentEndDateInputSelectedAnalytics}
                        datePickerProps={{
                          date: value ? formatDateString(value) : new Date(),
                        }}
                        error={
                          'employmentEndDate' in errors &&
                          !!errors.employmentEndDate
                        }
                        errorText={
                          'employmentEndDate' in errors
                            ? errors.employmentEndDate?.message
                            : ''
                        }
                      />
                    }
                  />
                );
              }}
            />
          </>
        )}
      </Stack>
      <YStack tabletNarrow={isIpad}>
        <Button
          marginTop="$md"
          disabled={!isValid}
          testID={getTestId('add-pension-button')}
          onPress={handleSubmit(handleAddPension)}
        >
          {t('addPensionCTA')}
        </Button>
      </YStack>
      <PensionProviderTooltip
        isTooltipVisible={isPensionProviderTooltipOpen}
        setIsTooltipVisible={setIsPensionProviderTooltipOpen}
      />
    </YStack>
  );
};
