import {
  getTokens,
  HeadingGroup,
  ScrollView,
  Separator,
  YStack,
} from '@aviva/ion-mobile';
import { FocusKeyboardAvoidingView } from '@aviva/ion-mobile/components/focus-keyboard-avoiding-view/focus-keyboard-avoiding-view';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { isIpad } from '@src/utils/is-ipad';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useManageFindAndCombinePensions } from '../hooks/use-manage-pensions/use-manage-pensions';
import { FindAndCombineStepper } from '../stepper/find-and-combine-stepper';
import { AddPensionForm } from './add-pension-form';
import { ADD_PENSION } from './analytics';

export const AddPensionScreen = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.addPension',
  });

  useOnPageLoad({ pageTag: ADD_PENSION });
  const { getPensionsCount } = useManageFindAndCombinePensions();

  const safeAreaInsets = useSafeAreaInsets();
  const tokens = getTokens();
  return (
    <FocusKeyboardAvoidingView style={{ flex: 1 }}>
      <ScrollView
        keyboardShouldPersistTaps="handled"
        contentContainerStyle={{
          flexGrow: 1,
          paddingHorizontal: tokens.space.$xl.val,
          paddingBottom: safeAreaInsets.bottom + tokens.space.$xxl.val,
        }}
        showsVerticalScrollIndicator={false}
      >
        <YStack tablet={isIpad} flex={1}>
          <FindAndCombineStepper screen={'Pension details'} />
          <HeadingGroup
            heading={`${t('headerTitle')} ${getPensionsCount() + 1}`}
            subHeading={t('headerSubtitle')}
          />
          <Separator borderColor="$Gray300" marginVertical="$xxl" />
          <AddPensionForm />
        </YStack>
      </ScrollView>
    </FocusKeyboardAvoidingView>
  );
};
