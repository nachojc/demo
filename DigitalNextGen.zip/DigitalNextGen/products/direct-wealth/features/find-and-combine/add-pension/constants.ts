export const AddPensionConstants = {
  HEADER_TITLE: 'Pension',
  HEADER_SUBTITLE:
    'Tell us about this pension. Please add as much detail as you know.',
  LABEL_PENSION_PROVIDER:
    'Do you know the name of the pension provider company?',
  TEXT_EMPLOYMENT_DETAILS:
    'We need details of your employment to find your pension.',
  LABEL_EMPLOYER_NAME: 'Name of employer',
  PLAN_NUMBER: 'Plan number for this pension (optional)',
  PLAN_NUMBER_SUBTITLE:
    'Add your plan number if you have it. This will reduce the time it takes us to find your pension.',
  PLACEHOLDER_EMPLOYER_NAME: 'Enter name of employer',
  PLACEHOLDER_PLAN_NUMBER: 'Enter plan number',
  LABEL_EMPLOYMENT_START_DATE: 'Approximately when did you start working here?',
  LABEL_EMPLOYMENT_END_DATE: 'Approximately when did you stop working here?',
  DATE_CANNOT_BE_FUTURE: 'Date cannot be in the future.',
  DATE_CANNOT_BE_TODAY_AND_FUTURE: 'Date cannot be today or in the future.',
  DATE_CANNOT_BE_BEFORE_START_DATE:
    'Date cannot be before the employment start date.',
  ADD_PENSION: 'Add pension',
};
