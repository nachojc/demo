import {
  Button,
  ButtonVariant,
  HeadingGroup,
  NotificationCard,
  Separator,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useAccessibility } from '@src/common/providers/accessibility';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { isIpad } from '@src/utils/is-ipad';
import { isEmptyString } from '@src/utils/string-manipulation';
import { useCallback, useEffect, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  useFindAndCombineStackNavigation,
  useFindAndCombineStackRoute,
} from '../navigation/hooks';
import { FindAndCombineStepper } from '../stepper/find-and-combine-stepper';
import { YourSignatureDialog } from '../your-signature-dialog/your-signature-dialog';
import {
  YOUR_SIGNATURE_CONTINUE_WITHOUT_SIGNATURE_TAPPED,
  YOUR_SIGNATURE_SCREEN,
  YOUR_SIGNATURE_SIGN_NOW_TAPPED,
} from './analytics';

export const YourSignatureScreen = () => {
  const { navigate } = useFindAndCombineStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const { bottom } = useSafeAreaInsets();
  const { isScreenReaderEnabled } = useAccessibility();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.yourSignature',
  });
  const route = useFindAndCombineStackRoute<'Your signature'>();
  const [isYourSignatureDialogVisible, setIsYourSignatureDialogVisible] =
    useState(false);
  useOnPageLoad({ pageTag: YOUR_SIGNATURE_SCREEN });

  const continueWithoutSignaturePressed = useCallback(() => {
    trackUserEvent(YOUR_SIGNATURE_CONTINUE_WITHOUT_SIGNATURE_TAPPED);
    if (!isScreenReaderEnabled) {
      setIsYourSignatureDialogVisible(true);
    } else {
      navigate('Review application');
    }
  }, [isScreenReaderEnabled, navigate, trackUserEvent]);

  const handleContinue = useCallback(() => {
    trackUserEvent(YOUR_SIGNATURE_SIGN_NOW_TAPPED);
    navigate('Sign application');
  }, [trackUserEvent, navigate]);

  useEffect(() => {
    if (route.params) {
      const { signatureValue } = route.params;
      setIsYourSignatureDialogVisible(isEmptyString(signatureValue));
    }
  }, [route]);

  return (
    <YStack
      flex={1}
      paddingHorizontal={'$xl'}
      paddingBottom={bottom + tokens.space.xxl.val}
      tablet={isIpad}
    >
      <FindAndCombineStepper screen={'Your signature'} />
      <YStack flex={1}>
        <HeadingGroup heading={t('title')} subHeading={t('subtitle')} />
        <Separator borderColor="$Gray200" marginVertical="$xxl" />
        <NotificationCard
          iconVariant="information"
          subtitle={
            isScreenReaderEnabled
              ? t('notificationWithScreenReader')
              : t('notificationWithoutScreenReader')
          }
        />
      </YStack>
      <YStack tabletNarrow={isIpad}>
        <Button
          variant={ButtonVariant.OUTLINED}
          marginBottom={'$xl'}
          onPress={continueWithoutSignaturePressed}
        >
          {t('continueWithoutSignature')}
        </Button>
        <Button onPress={handleContinue}>{t('signNow')}</Button>
      </YStack>
      {isYourSignatureDialogVisible && (
        <YourSignatureDialog
          isYourSignatureDialogVisible={isYourSignatureDialogVisible}
          setIsYourSignatureDialogVisible={setIsYourSignatureDialogVisible}
        />
      )}
    </YStack>
  );
};
