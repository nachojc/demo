import { PAGE_WEALTH } from '@constants/analytics';

export const YOUR_SIGNATURE_SCREEN = `${PAGE_WEALTH}|find-and-combine|apply|your-signature`;
export const YOUR_SIGNATURE_CONTINUE_WITHOUT_SIGNATURE_TAPPED = `${YOUR_SIGNATURE_SCREEN}|continue-without-signature-tapped`;
export const YOUR_SIGNATURE_SIGN_NOW_TAPPED = `${YOUR_SIGNATURE_SCREEN}|sign-now-tapped`;
