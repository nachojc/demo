import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';

import {
  FindAndCombineStackRouteParams,
  FindAndCombineStackScreenNames,
} from './types';

export type FindAndCombineStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<FindAndCombineStackRouteParams>,
  NativeStackNavigationProp<Pick<AppStackDWRouteParams, 'ProductDashboard'>>
>;

export type FindAndCombineStackRoute<
  T extends keyof FindAndCombineStackRouteParams
> = RouteProp<FindAndCombineStackRouteParams, T>;

/**
 * @description A typed wrapper around useRoute
 *
 * @T
 * T is the name of the screen from which you're calling this hook
 * It must be a key of FindAndCombineStackRouteParams
 */
export function useFindAndCombineStackRoute<
  T extends FindAndCombineStackScreenNames
>() {
  return useRoute<FindAndCombineStackRoute<T>>();
}

/**
 * @description A typed wrapper around useNavigation
 *
 * For use within the Find and Combine navigation stack
 */
export function useFindAndCombineStackNavigation() {
  return useNavigation<FindAndCombineStackNavigation>();
}
