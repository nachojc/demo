import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { tokens } from '@src/theme/tokens';

import { findAndCombineHeader } from './header/find-and-combine-header';
import { FindAndCombineProvider } from './provider';
import { FindAndCombineStackRouteParams } from './types';

const Stack = createNativeStackNavigator<FindAndCombineStackRouteParams>();

export const FindAndCombineStack = () => {
  return (
    <FindAndCombineProvider>
      <Stack.Navigator
        initialRouteName="Landing"
        screenOptions={{
          header: (props) =>
            findAndCombineHeader({ showCloseButton: false, ...props }),
        }}
      >
        <Stack.Group
          screenOptions={{
            contentStyle: { backgroundColor: tokens.color.White.val },
          }}
        >
          <Stack.Screen
            name="Landing"
            options={{
              header: (props) =>
                findAndCombineHeader({ showCloseButton: false, ...props }),
            }}
            getComponent={() =>
              require('../onboarding/landing-screen/landing-screen')
                .LandingScreen
            }
          />
          <Stack.Screen
            name="How it works"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../onboarding/how-it-works/how-it-works-screen.tsx')
                .HowItWorksScreen
            }
          />
          <Stack.Screen
            name="Before you start"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../onboarding/before-you-start/before-you-start-screen.tsx')
                .BeforeYouStartScreen
            }
          />
          <Stack.Screen
            name="Identity verification"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../identity-verification/identity-verification-screen')
                .IdentityVerificationScreen
            }
          />
          <Stack.Screen
            name="Your details"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../your-details/your-details-screen').YourDetailsScreen
            }
          />
          <Stack.Screen
            name="Your pensions"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../your-pensions/your-pensions-screen')
                .YourPensionsScreen
            }
          />
          <Stack.Screen
            name="Add pension"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../add-pension/add-pension-screen').AddPensionScreen
            }
          />
          <Stack.Screen
            name="Previous details"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../previous-details/previous-details-screen')
                .PreviousDetailsScreen
            }
          />
          <Stack.Screen
            name="Your signature"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../your-signature/your-signature-screen')
                .YourSignatureScreen
            }
          />
          <Stack.Screen
            name="Sign application"
            options={{
              header: (props) => findAndCombineHeader({ ...props }),
              orientation: 'landscape',
            }}
            getComponent={() =>
              require('../sign-application/sign-application-screen')
                .SignApplicationScreen
            }
          />
          <Stack.Screen
            name="Review application"
            options={{ header: (props) => findAndCombineHeader({ ...props }) }}
            getComponent={() =>
              require('../review-application/review-application-screen')
                .ReviewApplicationScreen
            }
          />
          <Stack.Screen
            name="Application submitted"
            options={{ headerShown: false, gestureEnabled: false }}
            getComponent={() =>
              require('../application-submitted/application-submitted-screen')
                .ApplicationSubmittedScreen
            }
          />
        </Stack.Group>
      </Stack.Navigator>
    </FindAndCombineProvider>
  );
};
