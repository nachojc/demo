import { CompositeNavigationProp, RouteProp } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';

export type FindAndCombineStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<FindAndCombineStackRouteParams>,
  NativeStackNavigationProp<Pick<AppStackDWRouteParams, 'ProductDashboard'>>
>;

export type FindAndCombineStackRoute<
  T extends keyof FindAndCombineStackRouteParams
> = RouteProp<FindAndCombineStackRouteParams, T>;

export type FindAndCombineStackRouteParams = {
  ['Landing']: undefined;
  ['How it works']: undefined;
  ['Before you start']: undefined;
  ['Identity verification']: undefined;
  ['Your details']: undefined;
  ['Your pensions']: undefined;
  ['Add pension']: undefined;
  ['Previous details']: undefined;
  ['Your signature']: { signatureValue: string } | undefined;
  ['Sign application']: undefined;
  ['Review application']: undefined;
  ['Application submitted']: undefined;
};

export type FindAndCombineStackScreenNames =
  keyof FindAndCombineStackRouteParams;
