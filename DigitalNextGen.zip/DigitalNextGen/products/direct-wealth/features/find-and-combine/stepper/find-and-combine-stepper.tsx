import { SteppedProgress } from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';

import { useFindAndCombineConditionalNavigation } from '../hooks/use-find-and-combine-conditional-navigation/use-find-and-combine-conditional-navigation';

export const FindAndCombineStepper = ({ screen }: { screen: string }) => {
  const { currentStep, totalSteps, boldLabel } =
    useFindAndCombineConditionalNavigation().getStepperValues(screen);

  return (
    <SteppedProgress
      currentStep={currentStep}
      totalSteps={totalSteps}
      label={screen}
      boldLabel={boldLabel}
      containerProps={{
        backgroundColor: tokens.color.White.val,
        paddingTop: tokens.space.xxxl.val,
      }}
    />
  );
};
