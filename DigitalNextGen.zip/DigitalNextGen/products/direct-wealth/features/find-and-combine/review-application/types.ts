import { Dispatch, MutableRefObject, RefObject, SetStateAction } from 'react';

import { Pensions } from '../navigation/provider/state/pensions';

export type KeyValue = {
  key: string;
  value: string;
};

export type PensionDetailsProps = {
  handleOpenSnackbar: () => void;
  handleCloseSnackbar: () => void;
  pensionToBeDeleted: MutableRefObject<Pensions | undefined>;
  pensions: Pensions[];
  addPensionRef: RefObject<any>;
};

export type CheckboxCardProps = {
  confirm: boolean;
  setConfirm: Dispatch<SetStateAction<boolean>>;
  description: string;
};
