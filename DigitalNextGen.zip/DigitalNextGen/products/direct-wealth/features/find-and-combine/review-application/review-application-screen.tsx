import {
  Button,
  Checkbox,
  HeadingGroup,
  Link,
  PDFCard,
  ScrollView,
  Separator,
  Stack,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { EmptyProductCard } from '@aviva/ion-mobile/components/cards/empty-product-card/empty-product-card';
import { ExpansionPanel } from '@aviva/ion-mobile/components/expansion-panel';
import { config } from '@config';
import {
  ISO_8601_DATE_FORMAT,
  UK_DATE_SHORT_FORMAT,
} from '@constants/string-formats';
import { useFindAndCombineCustomerDetails } from '@direct-wealth/common/hooks/use-find-and-combine-customer-details';
import { DeletePensionDialog } from '@direct-wealth/components/delete-pension-dialog';
import { LoadingState } from '@direct-wealth/components/loading-state/loading-state';
import { PensionDetailsCard } from '@direct-wealth/components/pension-details-card';
import { PensionRemovedSnackbar } from '@direct-wealth/components/pension-removed-snackbar';
import { UpdateYourDetailsDialog } from '@direct-wealth/components/update-details-dialog/update-details-dialog';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { useCustomer } from '@hooks/use-customer';
import { useSelector } from '@legendapp/state/react';
import { ApiErrorDialog } from '@src/components/api-error-dialog/api-error-dialog';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';
import { formatDateToFormat } from '@src/utils';
import { spellOutString } from '@src/utils/accessibility';
import { screenReaderTranslate } from '@src/utils/accessibility/accessibility-label';
import { isIpad } from '@src/utils/is-ipad';
import {
  Dispatch,
  SetStateAction,
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useManageFindAndCombinePensions } from '../hooks/use-manage-pensions/use-manage-pensions';
import { useFindAndCombineStackNavigation } from '../navigation/hooks';
import { useFindAndCombine } from '../navigation/provider';
import { useSubmitFindAndCombineApplication } from '../navigation/provider/state/hooks/use-submit-find-and-combine-application';
import { Pensions } from '../navigation/provider/state/pensions';
import {
  PersonalInformationAddress,
  PersonalInformationMobileNumber,
} from '../navigation/provider/state/personal-details';
import { PreviousAddresses } from '../navigation/provider/state/previous-addresses';
import { PreviousName } from '../navigation/provider/state/previous-names';
import { FindAndCombineStepper } from '../stepper/find-and-combine-stepper';
import {
  REVIEW_APPLICATION,
  REVIEW_APPLICATION_ADD_PENSION_DETAILS_TAPPED,
  REVIEW_APPLICATION_PRIVACY_NOTICE_TAPPED,
  REVIEW_APPLICATION_REMOVE_LAST_PENSION_DIALOG,
  REVIEW_APPLICATION_REMOVE_LAST_PENSION_DIALOG_CANCEL_TAPPED,
  REVIEW_APPLICATION_REMOVE_LAST_PENSION_DIALOG_YES_TAPPED,
  REVIEW_APPLICATION_REMOVE_PENSION_DIALOG,
  REVIEW_APPLICATION_REMOVE_PENSION_DIALOG_CANCEL_TAPPED,
  REVIEW_APPLICATION_REMOVE_PENSION_DIALOG_YES_TAPPED,
  REVIEW_APPLICATION_REMOVE_PENSION_TAPPED,
  REVIEW_APPLICATION_REMOVE_PENSION_UNDO_TAPPED,
  REVIEW_APPLICATION_SUBMIT_TAPPED,
  REVIEW_APPLICATION_TERMS_ACCEPTED_TAPPED,
  REVIEW_APPLICATION_TERMS_OF_USE_TAPPED,
  REVIEW_APPLICATION_TERMS_UNACCEPTED_TAPPED,
  REVIEW_APPLICATION_UPDATE_ADDRESS_TAPPED,
  REVIEW_APPLICATION_UPDATE_DIALOG,
  REVIEW_APPLICATION_UPDATE_DIALOG_CANCEL_TAPPED,
  REVIEW_APPLICATION_UPDATE_DIALOG_CONTINUE_TAPPED,
  REVIEW_APPLICATION_UPDATE_NAME_TAPPED,
  SUBMIT_APPLICATION,
} from './analytics';
import { CheckboxCardProps, KeyValue, PensionDetailsProps } from './types';

export const ReviewApplicationScreen = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication',
  });
  const { trackUserEvent } = useAnalytics();
  useTrackStateEvent(REVIEW_APPLICATION);
  const safeAreaInsets = useSafeAreaInsets();
  const { navigate } = useFindAndCombineStackNavigation();

  const [showSnackbar, setShowSnackbar] = useState(false);
  const [confirm, setConfirm] = useState(false);

  const pensionToBeDeleted = useRef<Pensions>();

  const { elementRef: addPensionRef, focus: focusAddPension } = useA11yFocus();

  const {
    deletePension,
    undoMarkPensionForDeletion,
    pensionsBeforeDeletion: pensions,
  } = useManageFindAndCombinePensions();

  const {
    submitFindAndCombineApplication,
    isLoading: isSubmissionLoading,
    isError: isSubmissionError,
    error: errorSubmission,
    isSuccess: isSubmissionSuccess,
  } = useSubmitFindAndCombineApplication();

  useEffect(() => {
    if (isSubmissionSuccess) {
      navigate('Application submitted');
    }
  }, [isSubmissionSuccess, navigate]);

  useEffect(() => {
    if (!showSnackbar) {
      focusAddPension();
    }
  }, [showSnackbar]);

  const handleSnackbarCompletion = () => {
    setShowSnackbar(false);
    pensionToBeDeleted.current && deletePension();
    pensionToBeDeleted.current = undefined;
  };

  const handleSnackbarUndo = useCallback(() => {
    trackUserEvent(REVIEW_APPLICATION_REMOVE_PENSION_UNDO_TAPPED);
    undoMarkPensionForDeletion(pensionToBeDeleted.current);
    pensionToBeDeleted.current = undefined;
    setShowSnackbar(false);
  }, [trackUserEvent, undoMarkPensionForDeletion]);

  const onSubmit = useCallback(() => {
    trackUserEvent(REVIEW_APPLICATION_SUBMIT_TAPPED);
    submitFindAndCombineApplication();
  }, [trackUserEvent, submitFindAndCombineApplication]);

  const onRetry = useCallback(() => {
    submitFindAndCombineApplication();
  }, [submitFindAndCombineApplication]);

  return (
    <>
      <ScrollView
        contentContainerStyle={{
          flexGrow: 1,
          paddingHorizontal: tokens.space.xl.val,
          paddingBottom: safeAreaInsets.bottom + tokens.space.xxl.val,
          paddingTop: tokens.space.xs.val,
        }}
        showsVerticalScrollIndicator={false}
      >
        <YStack tablet={isIpad} flexGrow={1}>
          <FindAndCombineStepper screen={'Review application'} />
          <YStack justifyContent="space-between" flex={1} mt={'$xs'}>
            <Stack gap={'$xxl'} flex={isIpad ? 1 : undefined}>
              <HeadingGroup heading={t('title')} subHeading={t('subtitle')} />
              <Stack marginHorizontal={'$-xl'}>
                <Separator borderColor="$Gray300" />
                <PersonalDetails />
                <PreviousNamesAndAddresses />
              </Stack>
              <PensionDetails
                handleOpenSnackbar={() => {
                  setShowSnackbar(true);
                }}
                handleCloseSnackbar={() => {
                  setShowSnackbar(false);
                }}
                pensionToBeDeleted={pensionToBeDeleted}
                pensions={pensions}
                addPensionRef={addPensionRef}
              />
              <Documents />
              <CheckboxCard
                confirm={confirm}
                setConfirm={setConfirm}
                description={t('checkboxDescription')}
              />
            </Stack>
          </YStack>
        </YStack>
        <YStack tabletNarrow={isIpad} paddingTop="$xxxl">
          <Button disabled={!confirm || !pensions.length} onPress={onSubmit}>
            {t('continueCTA')}
          </Button>
        </YStack>
      </ScrollView>
      {isSubmissionLoading && (
        <LoadingState
          title={t('loadingState.title')}
          text={t('loadingState.copy')}
        />
      )}
      <ApiErrorDialog
        isError={isSubmissionError}
        pageTag={SUBMIT_APPLICATION}
        onRetry={onRetry}
        error={errorSubmission as string | string[] | null}
      />
      {showSnackbar && (
        <PensionRemovedSnackbar
          handleSnackbarUndo={handleSnackbarUndo}
          handleCompletion={handleSnackbarCompletion}
        />
      )}
    </>
  );
};

const PersonalDetails = () => {
  const { trackUserEvent } = useAnalytics();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.personalDetailsSection',
  });
  const [isExpanded, setIsExpanded] = useState(false);
  const [dialogTitle, setDialogTitle] = useState<string | null>(null);
  const findAndCombineState = useFindAndCombine();
  const {
    address: stateAddress,
    nationalInsuranceNumber,
    mobileNumber,
  } = useSelector(findAndCombineState.personalInformation);

  const { data: customerDetails, isSuccess } =
    useFindAndCombineCustomerDetails();

  if (!isSuccess) {
    return null;
  }

  const { address: apiAddress } = customerDetails;

  const getUserAddress = () => {
    if (stateAddress) {
      return {
        ...stateAddress,
        country: 'United Kingdom',
      };
    }
    return apiAddress;
  };

  const userAddress = getUserAddress();

  const onUpdateDetailsDialogContinuePress = () => {
    trackUserEvent(REVIEW_APPLICATION_UPDATE_DIALOG_CONTINUE_TAPPED);
    setDialogTitle(null);
  };

  const onUpdateDetailsDialogCancelPress = () => {
    trackUserEvent(REVIEW_APPLICATION_UPDATE_DIALOG_CANCEL_TAPPED);
    setDialogTitle(null);
  };

  return (
    <Stack>
      <ExpansionPanel
        isExpanded={isExpanded}
        contentStyle={{ borderTopWidth: 0, paddingTop: 0 }}
        title={t('sectionHeader')}
        content={
          <Stack gap={'$xxl'}>
            <CustomerName setDialogTitle={setDialogTitle} />
            {userAddress && (
              <CustomerAddress
                setDialogTitle={setDialogTitle}
                address={userAddress}
                showLink={!stateAddress}
              />
            )}
            {nationalInsuranceNumber && (
              <CustomerNino nino={nationalInsuranceNumber} />
            )}
            {mobileNumber && <CustomerPhone phoneNumber={mobileNumber} />}
          </Stack>
        }
        onPress={() => {
          setIsExpanded(!isExpanded);
        }}
        selectedIndex={0}
        index={0}
      />
      {dialogTitle != null && (
        <UpdateYourDetailsDialog
          isVisible
          title={dialogTitle}
          analyticsTag={REVIEW_APPLICATION_UPDATE_DIALOG}
          onContinuePress={onUpdateDetailsDialogContinuePress}
          onCancelPress={onUpdateDetailsDialogCancelPress}
        />
      )}
    </Stack>
  );
};

const CustomerName = ({
  setDialogTitle,
}: {
  setDialogTitle: Dispatch<SetStateAction<string | null>>;
}) => {
  const { data: customer, isSuccess } = useCustomer();
  const analytics = useAnalytics();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.personalDetailsSection',
  });

  const onUpdateNamePress = () => {
    setDialogTitle(t('updateNameDialogTitle'));
    analytics.trackUserEvent(REVIEW_APPLICATION_UPDATE_NAME_TAPPED);
  };

  if (!isSuccess) {
    return null;
  }
  return (
    <YStack space={'$md'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {t('name')}
      </Text>
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >{`${customer.Firstname} ${customer.Surname}`}</Text>
      <Link
        LinkTextProps={{
          fontSize: '$small',
          textDecorationLine: 'underline',
        }}
        onPress={onUpdateNamePress}
      >
        {t('updateName')}
      </Link>
    </YStack>
  );
};

const CustomerAddress = ({
  address,
  setDialogTitle,
  showLink,
}: {
  address: PersonalInformationAddress;
  setDialogTitle: Dispatch<SetStateAction<string | null>>;
  showLink: boolean;
}) => {
  const analytics = useAnalytics();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.personalDetailsSection',
  });

  const {
    firstLineOfAddress,
    secondLineOfAddress,
    thirdLineOfAddress,
    townOrCity,
    postcode,
    country,
  } = address;

  const onUpdateAddressPress = () => {
    setDialogTitle(t('updateAddressDialogTitle'));
    analytics.trackUserEvent(REVIEW_APPLICATION_UPDATE_ADDRESS_TAPPED);
  };
  return (
    <YStack space={'$md'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {t('address')}
      </Text>
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {firstLineOfAddress}
        {secondLineOfAddress ? `\n${secondLineOfAddress}` : ''}
        {thirdLineOfAddress ? `\n${thirdLineOfAddress}` : ''}
        {`\n${townOrCity}`}
        {`\n${postcode}`}
        {`\n${country}`}
      </Text>
      {showLink && (
        <Link
          LinkTextProps={{
            fontSize: '$small',
            textDecorationLine: 'underline',
          }}
          onPress={onUpdateAddressPress}
        >
          {t('updateAddress')}
        </Link>
      )}
    </YStack>
  );
};

const CustomerNino = ({ nino }: { nino: string }) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.personalDetailsSection',
  });
  return (
    <YStack space={'$md'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {t('ninoTitle')}
      </Text>
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{
          lineHeight: '$small',
          accessibilityLabel: spellOutString(nino),
        }}
      >
        {nino}
      </Text>
    </YStack>
  );
};

const CustomerPhone = ({
  phoneNumber,
}: {
  phoneNumber: PersonalInformationMobileNumber;
}) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.personalDetailsSection',
  });
  if (phoneNumber == null) {
    return null;
  }
  return (
    <YStack space={'$md'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {t('mobileNumberTitle')}
      </Text>
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ lineHeight: '$small' }}
      >
        {phoneNumber.code}
        {phoneNumber.number?.replace(/^0/, '')}
      </Text>
    </YStack>
  );
};

const PreviousNamesAndAddresses = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const findAndCombineState = useFindAndCombine();
  const { previousAddresses, previousNames } = useSelector(findAndCombineState);
  const { t } = useTranslationDW({
    keyPrefix:
      'findAndCombine.reviewApplication.previousNamesAndAddressesSection',
  });
  if (previousAddresses.length === 0 && previousNames.length === 0) {
    return null;
  }
  return (
    <Stack>
      <ExpansionPanel
        isExpanded={isExpanded}
        contentStyle={{ borderTopWidth: 0, paddingTop: 0 }}
        title={t('sectionTitle')}
        content={
          <Stack gap={'$xxl'}>
            {previousNames && previousNames.length > 0 && (
              <PreviousNamesSection previousNames={previousNames} />
            )}
            {previousAddresses && previousAddresses.length > 0 && (
              <PreviousAddressesSection previousAddresses={previousAddresses} />
            )}
          </Stack>
        }
        onPress={() => {
          setIsExpanded(!isExpanded);
        }}
        selectedIndex={0}
        index={0}
      />
    </Stack>
  );
};

const PreviousNamesSection = ({
  previousNames,
}: {
  previousNames: PreviousName[];
}) => {
  const { t } = useTranslationDW({
    keyPrefix:
      'findAndCombine.reviewApplication.previousNamesAndAddressesSection',
  });

  return (
    <Stack gap={'$xxl'}>
      {previousNames.map((name, index) => (
        <YStack key={`${index}-${name.firstName}`}>
          <Text
            fontVariant="body-semibold-Secondary800"
            tamaguiTextProps={{ lineHeight: '$small', marginBottom: '$md' }}
          >
            {t('nameTitle') + `${index + 1}`}
          </Text>
          <Text
            fontVariant="body-regular-Gray800"
            tamaguiTextProps={{ lineHeight: '$small' }}
          >
            {name.firstName} {name.lastName}
          </Text>
        </YStack>
      ))}
    </Stack>
  );
};

const PreviousAddressesSection = ({
  previousAddresses,
}: {
  previousAddresses: PreviousAddresses[];
}) => {
  const { t } = useTranslationDW({
    keyPrefix:
      'findAndCombine.reviewApplication.previousNamesAndAddressesSection',
  });
  return (
    <Stack gap={'$xxl'}>
      {previousAddresses.map(({ address, startDate, endDate }) => {
        const formattedStartDate = formatDateToFormat(
          startDate ?? '',
          UK_DATE_SHORT_FORMAT,
          ISO_8601_DATE_FORMAT
        );

        const formattedEndDate = formatDateToFormat(
          endDate ?? '',
          UK_DATE_SHORT_FORMAT,
          ISO_8601_DATE_FORMAT
        );
        return (
          <YStack key={`${formattedStartDate}-${formattedEndDate}`}>
            <Text
              fontVariant="body-semibold-Secondary800"
              tamaguiTextProps={{ lineHeight: '$small', marginBottom: '$md' }}
            >
              {t('addressTitle')}
              {` ${formattedStartDate} to ${formattedEndDate}`}
            </Text>
            <Text
              fontVariant="body-regular-Gray800"
              tamaguiTextProps={{ lineHeight: '$small' }}
            >
              {address.firstLineOfAddress}
              {address?.secondLineOfAddress &&
                `\n${address.secondLineOfAddress}`}
              {address?.thirdLineOfAddress && `\n${address.thirdLineOfAddress}`}
              {`\n${address.townOrCity}`}
              {`\n${address.postcode}`}
              {`\n${address.country}`}
            </Text>
          </YStack>
        );
      })}
    </Stack>
  );
};

const Documents = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.documentsSection',
  });
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();

  const navigateToPrivacyNotice = () => {
    trackUserEvent(REVIEW_APPLICATION_PRIVACY_NOTICE_TAPPED);
    navigate('Pdf View', {
      pdfSource: {
        url:
          config.CONTENT_BASE_URL.get() +
          '/content/dam/document-library/adviser/workplace/wc04591.pdf',
      },
      isDW: true,
      name: 'Privacy Notice',
    });
  };

  const navigateToTermsOfUse = () => {
    trackUserEvent(REVIEW_APPLICATION_TERMS_OF_USE_TAPPED);
    navigate('Pdf View', {
      pdfSource: {
        url:
          config.CONTENT_BASE_URL.get() +
          '/content/dam/document-library/adviser/workplace/wc10067.pdf',
      },
      isDW: true,
      name: 'Terms of Use',
    });
  };

  return (
    <Stack gap={'$xl'}>
      <Text fontVariant="heading4-regular-Gray800">{t('title')}</Text>
      <Text fontVariant="body-regular-Gray800">{t('subtitle')}</Text>
      <PDFCard title={t('pdfOne')} onPress={navigateToPrivacyNotice} />
      <PDFCard title={t('pdfTwo')} onPress={navigateToTermsOfUse} />
    </Stack>
  );
};

const PensionDetails = ({
  handleOpenSnackbar,
  handleCloseSnackbar,
  pensionToBeDeleted,
  pensions,
  addPensionRef,
}: PensionDetailsProps) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.pensionDetails',
  });
  const { navigate } = useFindAndCombineStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const [isRemoveDialogOpen, setIsRemoveDialogOpen] = useState(false);

  const { markPensionForDeletion } = useManageFindAndCombinePensions();
  const isLastPenstion = pensions.length === 1;

  const handleRemovePensionButton = useCallback(
    (pension: Pensions) => {
      trackUserEvent(REVIEW_APPLICATION_REMOVE_PENSION_TAPPED);
      setIsRemoveDialogOpen(true);
      handleCloseSnackbar();
      pensionToBeDeleted.current = pension;
    },
    [
      trackUserEvent,
      handleCloseSnackbar,
      pensionToBeDeleted,
      setIsRemoveDialogOpen,
    ]
  );

  const handleEmptyCardButton = useCallback(() => {
    trackUserEvent(REVIEW_APPLICATION_ADD_PENSION_DETAILS_TAPPED);
    navigate('Add pension');
  }, [navigate, trackUserEvent]);

  const handleConfirmDelete = useCallback(() => {
    trackUserEvent(
      isLastPenstion
        ? REVIEW_APPLICATION_REMOVE_LAST_PENSION_DIALOG_YES_TAPPED
        : REVIEW_APPLICATION_REMOVE_PENSION_DIALOG_YES_TAPPED
    );
    setIsRemoveDialogOpen(false);
    pensionToBeDeleted.current &&
      markPensionForDeletion(pensionToBeDeleted.current);
    handleOpenSnackbar();
  }, [
    trackUserEvent,
    handleOpenSnackbar,
    markPensionForDeletion,
    pensionToBeDeleted,
    isLastPenstion,
  ]);

  const handleCancelDeletePension = () => {
    trackUserEvent(
      isLastPenstion
        ? REVIEW_APPLICATION_REMOVE_LAST_PENSION_DIALOG_CANCEL_TAPPED
        : REVIEW_APPLICATION_REMOVE_PENSION_DIALOG_CANCEL_TAPPED
    );
    setIsRemoveDialogOpen(false);
  };

  return (
    <Stack>
      <Stack flex={1} gap="$xxl">
        <Text fontVariant="heading4-regular-Secondary800">{t('subtitle')}</Text>
        {!pensions.length && (
          <Stack gap="$xxl">
            <Text fontVariant="body-regular-Gray800">
              {t('emptyProductCardDescription')}
            </Text>
            <EmptyProductCard
              title={t('emptyProductCardHeading')}
              description={t('addPensionDetails')}
              onPress={handleEmptyCardButton}
              cardRef={addPensionRef}
            />
          </Stack>
        )}
        {pensions.map((pension, index) => (
          <SinglePension
            key={`${index}-${pension.planNumber}`}
            pension={pension}
            onPress={handleRemovePensionButton}
          />
        ))}
        <Text fontVariant="body-regular-Gray800">{t('description')}</Text>
      </Stack>
      {isRemoveDialogOpen && (
        <DeletePensionDialog
          isOpen={isRemoveDialogOpen}
          onConfirm={handleConfirmDelete}
          onCancel={handleCancelDeletePension}
          screenEventTag={
            isLastPenstion
              ? REVIEW_APPLICATION_REMOVE_LAST_PENSION_DIALOG
              : REVIEW_APPLICATION_REMOVE_PENSION_DIALOG
          }
          isLastPension={isLastPenstion}
        />
      )}
    </Stack>
  );
};

const SinglePension = ({
  pension,
  onPress,
}: {
  pension?: Pensions;
  onPress: (pension: Pensions) => void;
}) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.reviewApplication.pensionDetails',
  });

  if (pension == null) {
    return null;
  }

  const generateKeyValue = (
    planNumber: string,
    employerName: string,
    employmentDates: string
  ): KeyValue[] => {
    const array: KeyValue[] = [];

    if (!employerName && !employmentDates) {
      array.push({ key: t('planNumber'), value: planNumber });
      return array;
    }

    array.push(
      { key: t('employer'), value: employerName },
      { key: t('employmentDates'), value: employmentDates }
    );

    return array;
  };

  const heading = pension.pensionProviderName ?? t('unknownProvider');
  const planNumber = pension.planNumber ?? t('notProvided');
  const employerName = pension.employerName ?? '';
  const employmentStartDate = pension.startDate;
  const employmentEndDate = pension.endDate;
  const employmentDates =
    employmentStartDate && employmentEndDate
      ? `${employmentStartDate} - ${employmentEndDate}`
      : '';

  return (
    <YStack gap="$xxl">
      <PensionDetailsCard
        heading={heading}
        pensionDetails={generateKeyValue(
          planNumber,
          employerName,
          employmentDates
        )}
        actionButton={{
          icon: 'delete',
          copy: 'Remove',
          onPress: () => onPress(pension),
          accessibilityHint: `Removes ${heading}`,
        }}
      />
    </YStack>
  );
};

const CheckboxCard = ({
  confirm,
  setConfirm,
  description,
}: CheckboxCardProps) => {
  const { trackUserEvent } = useAnalytics();
  const onPress = () => {
    trackUserEvent(
      !confirm
        ? REVIEW_APPLICATION_TERMS_ACCEPTED_TAPPED
        : REVIEW_APPLICATION_TERMS_UNACCEPTED_TAPPED
    );
    setConfirm((confirmValue) => !confirmValue);
  };
  return (
    <XStack
      onPress={onPress}
      accessibilityRole="checkbox"
      accessibilityLabel={screenReaderTranslate(description)}
      accessibilityState={{ checked: confirm }}
      accessible
      gap="$xl"
    >
      <Checkbox
        value={confirm}
        onValueChange={onPress}
        checkboxProps={{
          borderColor: confirm ? '$Success' : '$Gray400',
          mt: '$xs',
        }}
        accessible={false}
      />
      <YStack flex={1}>
        <Text fontVariant="body-regular-Gray800">{description}</Text>
      </YStack>
    </XStack>
  );
};
