import {
  Button,
  FocusAwareStatusBar,
  ScrollView,
  Text,
  YStack,
  ZStack,
} from '@aviva/ion-mobile';
import { TimelineList } from '@aviva/ion-mobile/components/timeline/timeline-list';
import {
  IPAD_THANK_YOU_TEXT_WIDTH,
  THANK_YOU_SCREEN_TOP_PADDING,
} from '@constants/style-constants';
import { useDirectWealthTabStackNavigation } from '@direct-wealth/navigation/hooks';
import { useAnalytics } from '@hooks/use-analytics';
import { useDisableGoBack } from '@hooks/use-disable-go-back';
import { isManga } from '@hooks/use-expo-config';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { CroppedImage } from '@src/components/cropped-image/cropped-image';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  APPLICATION_SUBMITTED,
  APPLICATION_SUBMITTED_CTA_TAPPED,
} from './analytics';

const image = require('@assets/sipp-transfer-success/sipp-transfer-success.webp');

const imageHeight = 326;
const imageWidth = 232;

const headingStyles = {
  fontSize: 64,
  letterSpacing: 7.35,
  lineHeight: 60,
};

export const ApplicationSubmittedScreen = () => {
  const safeAreaInsets = useSafeAreaInsets();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.applicationSubmitted',
  });
  const { trackUserEvent } = useAnalytics();
  const { navigate } = useDirectWealthTabStackNavigation();

  useOnPageLoad({ pageTag: APPLICATION_SUBMITTED });
  useDisableGoBack(true);

  const onContinuePress = () => {
    trackUserEvent(APPLICATION_SUBMITTED_CTA_TAPPED);
    navigate(isManga() ? 'Summary Tab' : 'PortfolioSummary');
  };

  return (
    <ScrollView
      contentContainerStyle={{
        flexGrow: 1,
        paddingBottom: safeAreaInsets.bottom + tokens.space.xxl.val,
        paddingTop: safeAreaInsets.top + THANK_YOU_SCREEN_TOP_PADDING,
        paddingHorizontal: tokens.space.xl.val,
      }}
      backgroundColor={tokens.color.WealthBlue.val}
      showsVerticalScrollIndicator={false}
    >
      <YStack flex={1} tablet={isIpad}>
        <FocusAwareStatusBar style="light" />
        <Header />
        <Confirmation />
        <Timeline />
      </YStack>
      <YStack tabletNarrow={isIpad}>
        <Button marginTop="$xxxxl" onPress={onContinuePress}>
          {t('continueCTA')}
        </Button>
      </YStack>
    </ScrollView>
  );
};

const Header = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.applicationSubmitted',
  });
  return (
    <ZStack
      accessibilityElementsHidden
      importantForAccessibility={'no-hide-descendants'}
      height={imageHeight}
      testID={getTestId('application-submitted-thank-you-image')}
    >
      <CroppedImage
        cropDegree={5.5}
        source={image}
        width={imageWidth}
        height={imageHeight}
        linearGradient={{
          start: { x: 0, y: 0 },
          end: { x: 0, y: 1 },
          colors: ['#0000001A', '#000000A1'],
          locations: [0, 1],
        }}
      />
      <YStack
        space="$lg"
        my="auto"
        px="$xxl"
        {...(isIpad && {
          px: undefined,
          width: IPAD_THANK_YOU_TEXT_WIDTH,
          alignSelf: 'center',
        })}
      >
        <Text
          fontVariant="heading0-semibold-White"
          tamaguiTextProps={{ ...headingStyles, textAlign: 'left' }}
        >
          {t('headingTop')}
        </Text>
        <Text
          fontVariant="heading0-semibold-White"
          tamaguiTextProps={{ ...headingStyles, textAlign: 'right' }}
        >
          {t('headingBottom')}
        </Text>
      </YStack>
    </ZStack>
  );
};

const Confirmation = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.applicationSubmitted',
  });
  return (
    <YStack space="$xxl" marginBottom="$xxxl" px="$xxxxl" marginTop={'$xxxl'}>
      <Text
        fontVariant="body-regular-White"
        tamaguiTextProps={{ textAlign: 'center' }}
      >
        {t('confirmationMessage')}
      </Text>
      <Text
        fontVariant="body-regular-White"
        tamaguiTextProps={{ textAlign: 'center' }}
        testID={getTestId('application-submitted-confirmation-text')}
      >
        {t('confirmationEmail')}
      </Text>
    </YStack>
  );
};

const Timeline = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.applicationSubmitted',
  });
  const timelineItems = [
    {
      title: t('timelineOneTitle'),
      time: undefined,
      description: t('timelineOneDescription'),
    },
    {
      title: t('timelineTwoTitle'),
      time: t('timelineTwoTime'),
      description: t('timelineTwoDescription'),
    },
    {
      title: t('timelineThreeTitle'),
      time: t('timelineThreeTime'),
      description: t('timelineThreeDescription'),
    },
  ];
  return (
    <>
      <Text
        fontVariant="heading5-semibold-White"
        tamaguiTextProps={{ marginBottom: '$xl' }}
      >
        {t('timelineTitle')}
      </Text>
      <TimelineList items={timelineItems} darkMode />
    </>
  );
};
