import { PAGE_WEALTH } from '@constants/analytics';

export const APPLICATION_SUBMITTED = `${PAGE_WEALTH}|find-and-combine|apply|application-submitted`;
export const APPLICATION_SUBMITTED_CTA_TAPPED = `${APPLICATION_SUBMITTED}|go-to-my-dashboard-tapped`;
