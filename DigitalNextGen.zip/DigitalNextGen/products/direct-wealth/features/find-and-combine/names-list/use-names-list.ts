import { useAnalytics } from '@hooks/use-analytics';
import { useState } from 'react';

import { useFindAndCombine } from '../navigation/provider';

export type NamesInputAnalytics = {
  yes: string;
  no: string;
  addNewName: string;
  removeName: string;
};

export const useNamesList = ({
  limit,
  analyticsTags,
}: {
  limit: number;
  analyticsTags: NamesInputAnalytics;
}) => {
  const { previousNameQuestion, previousNames } = useFindAndCombine();
  const namesListData = previousNames?.get();

  const [numberInputs, setNumberInputs] = useState<number>(
    namesListData ? namesListData?.length : 0
  );

  const [isVisible, setIsVisible] = useState(previousNameQuestion.get());
  const { trackUserEvent } = useAnalytics();

  const addName = () => {
    if (previousNames.length < limit) {
      trackUserEvent(analyticsTags.addNewName);
      previousNames[previousNames.length].set({ firstName: '', lastName: '' });
      setNumberInputs(numberInputs + 1);
    }
  };

  const removeName = (index: number) => {
    trackUserEvent(analyticsTags.removeName);
    previousNames.set((names) =>
      names.filter((_, currentIndex) => currentIndex !== index)
    );
    setNumberInputs(numberInputs - 1);
  };

  const onSegmentedControlChange = (selection?: boolean) => {
    previousNameQuestion.set(selection);
    setNumberInputs(1);

    if (selection === false) {
      trackUserEvent(analyticsTags.no);
      setIsVisible(false);
      previousNames.set([]);
    }
    if (selection) {
      trackUserEvent(analyticsTags.yes);
      previousNames[0].set({ firstName: '', lastName: '' });
      setIsVisible(true);
    }
  };

  return {
    previousNameQuestion,
    previousNames,
    addName,
    removeName,
    onSegmentedControlChange,
    numberInputs,
    isVisible,
  };
};
