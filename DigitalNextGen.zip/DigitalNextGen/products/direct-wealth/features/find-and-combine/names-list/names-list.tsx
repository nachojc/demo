import {
  Icon,
  SegmentedControls,
  Separator,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { InputField } from '@direct-wealth/components/input-field';
import {
  PreviousNameForm,
  PreviousNameFormSchema,
} from '@direct-wealth/validation/schemas/find-and-combine/previous-name';
import { zodResolver } from '@hookform/resolvers/zod';
import { FormInput } from '@src/components/forms/form-input';
import { tokens } from '@theme/tokens';
import { Controller, useForm, UseFormReturn } from 'react-hook-form';
import { Keyboard } from 'react-native';

import { useFindAndCombine } from '../navigation/provider';
import { NamesInputAnalytics, useNamesList } from './use-names-list';

type NameInputCopy = {
  yes: string;
  no: string;
  remove: string;
  firstName: string;
  firstNamePlaceHolder: string;
  lastName: string;
  lastNamePlaceHolder: string;
  addAnotherName: string;
  question: string;
};

type NamesListProps = {
  title?: string;
  limit?: number;
  analyticsTags: NamesInputAnalytics;
  copy: NameInputCopy;
  onSelectionChange?: (value?: boolean) => void;
};

export const NamesList = ({
  title = 'Previous name',
  limit = 5,
  analyticsTags,
  copy,
  onSelectionChange,
}: NamesListProps) => {
  const {
    previousNameQuestion,
    previousNames,
    addName,
    removeName,
    onSegmentedControlChange,
    numberInputs,
    isVisible,
  } = useNamesList({ limit, analyticsTags });

  const inputForm = useForm<PreviousNameForm>({
    resolver: zodResolver(PreviousNameFormSchema),
    mode: 'onChange',
    defaultValues: {
      previousNames: [],
    },
  });

  return (
    <YStack marginTop={'$xxl'}>
      <>
        <Text
          tamaguiTextProps={{ marginRight: '$xxl', marginBottom: '$lg' }}
          fontVariant="body-semibold-Secondary800"
        >
          {copy.question}
        </Text>

        <SegmentedControls
          optionOne={copy.yes}
          optionTwo={copy.no}
          defaultValue={previousNameQuestion.get()}
          onChange={(selection) => {
            onSegmentedControlChange(selection);
            if (onSelectionChange) {
              onSelectionChange(selection);
            }
          }}
        />
      </>
      {isVisible && (
        <>
          {previousNames.map((name, i) => (
            <YStack key={`${JSON.stringify(name.firstName)}-${i}`}>
              <Separator
                borderColor="$Gray200"
                marginVertical="$xxl"
                marginHorizontal={'$-xl'}
              />
              <XStack justifyContent="space-between" pb={'$xl'}>
                <Text fontVariant="heading4-light-Secondary800">{`${title} ${
                  i + 1
                }`}</Text>
                {i > 0 ? (
                  <XStack
                    accessible
                    accessibilityRole="button"
                    accessibilityLabel={`${copy.remove} button`}
                    accessibilityHint={`${copy.remove} name`}
                    onPress={() => removeName(i)}
                  >
                    <Icon name="delete" color={tokens.color.Tertiary800.val} />
                    <Text
                      tamaguiTextProps={{
                        paddingLeft: '$sm',
                        marginTop: '$xs',
                      }}
                      fontVariant="body-semibold-Tertiary800"
                    >
                      {copy.remove}
                    </Text>
                  </XStack>
                ) : null}
              </XStack>
              <NameInputs id={i} copy={copy} form={inputForm} />
            </YStack>
          ))}
          <Separator borderColor="$Gray200" marginVertical="$xxl" />
          <XStack
            accessible
            accessibilityRole="button"
            accessibilityLabel={`${copy.addAnotherName} button`}
            onPress={addName}
          >
            <Icon
              name="plus"
              color={
                numberInputs >= limit
                  ? tokens.color.Gray400.val
                  : tokens.color.Tertiary800.val
              }
            />
            <Text
              tamaguiTextProps={{ paddingLeft: '$sm' }}
              fontVariant={
                numberInputs >= limit
                  ? 'body-semibold-Gray400'
                  : 'body-semibold-Tertiary800'
              }
            >
              {copy.addAnotherName}
            </Text>
          </XStack>
          <Separator borderColor="$Gray200" marginTop="$xxl" />
        </>
      )}
    </YStack>
  );
};

const NameInputs = ({
  id,
  copy,
  form,
}: {
  id: number;
  copy: NameInputCopy;
  form: UseFormReturn<PreviousNameForm>;
}) => {
  const { control, setFocus } = form;
  const { previousNames } = useFindAndCombine();

  const setFirstName = (value: string) => {
    previousNames[id].firstName.set(value);
  };

  const setLastName = (value: string) => {
    previousNames[id].lastName.set(value);
  };

  return (
    <YStack space={'$xl'}>
      <Controller
        name={`previousNames.${id}.firstName`}
        control={control}
        render={({ field: { value } }) => {
          return (
            <InputField
              label={copy.firstName}
              field={
                <FormInput
                  control={control}
                  name={`previousNames.${id}.firstName`}
                  tamaguiInputProps={{
                    defaultValue: previousNames.get()[id]?.firstName ?? '',
                    accessibilityLabel: `${copy.firstName} input`,
                    maxLength: 250,
                    placeholder: copy.firstNamePlaceHolder,
                    onChangeText: setFirstName,
                    value,
                    returnKeyType: 'next',
                    onSubmitEditing: () => {
                      setFocus(`previousNames.${id}.lastName`);
                    },
                  }}
                />
              }
            />
          );
        }}
      />
      <Controller
        name={`previousNames.${id}.lastName`}
        control={control}
        render={({ field: { value } }) => {
          return (
            <InputField
              label={copy.lastName}
              field={
                <FormInput
                  control={control}
                  name={`previousNames.${id}.lastName`}
                  tamaguiInputProps={{
                    defaultValue: previousNames.get()[id]?.lastName ?? '',
                    accessibilityLabel: `${copy.lastName} input`,
                    maxLength: 250,
                    placeholder: copy.lastNamePlaceHolder,
                    onChangeText: setLastName,
                    value,
                    returnKeyType: 'done',
                    onSubmitEditing: () => Keyboard.dismiss(),
                  }}
                />
              }
            />
          );
        }}
      />
    </YStack>
  );
};
