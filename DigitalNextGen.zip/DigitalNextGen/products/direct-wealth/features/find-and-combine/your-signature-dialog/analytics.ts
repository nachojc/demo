import { PAGE_WEALTH } from '@constants/analytics';

export const YOUR_SIGNATURE_DIALOG = `${PAGE_WEALTH}|find-and-combine|apply|your-signature|continue-without-dialog`;
export const CONTINUE_WITHOUT_DIALOG_PROVIDE_SIGNATURE_TAPPED = `${YOUR_SIGNATURE_DIALOG}|provide-now-tapped`;
export const CONTINUE_WITHOUT_DIALOG_CONTINUE_TAPPED = `${YOUR_SIGNATURE_DIALOG}|continue-without-tapped`;
