import {
  Button,
  ButtonVariant,
  Dialog,
  getVariableValue,
  Icon,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { Dispatch, SetStateAction, useCallback } from 'react';

import { useFindAndCombineStackNavigation } from '../navigation/hooks';
import {
  CONTINUE_WITHOUT_DIALOG_CONTINUE_TAPPED,
  CONTINUE_WITHOUT_DIALOG_PROVIDE_SIGNATURE_TAPPED,
  YOUR_SIGNATURE_DIALOG,
} from './analytics';

type YourSignatureDialogProps = {
  isYourSignatureDialogVisible: boolean;
  setIsYourSignatureDialogVisible: Dispatch<SetStateAction<boolean>>;
};

export const YourSignatureDialog = ({
  isYourSignatureDialogVisible,
  setIsYourSignatureDialogVisible,
}: YourSignatureDialogProps) => {
  const { trackUserEvent } = useAnalytics();

  useTrackStateEvent(YOUR_SIGNATURE_DIALOG);

  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.continueWithoutSignaturePopup',
  });

  const { navigate } = useFindAndCombineStackNavigation();

  const handleProvideSignatureNow = useCallback(() => {
    setIsYourSignatureDialogVisible(false);
    trackUserEvent(CONTINUE_WITHOUT_DIALOG_PROVIDE_SIGNATURE_TAPPED);
    navigate('Sign application');
  }, [navigate, trackUserEvent, setIsYourSignatureDialogVisible]);

  const handleContinueWithoutSignature = useCallback(() => {
    setIsYourSignatureDialogVisible(false);
    trackUserEvent(CONTINUE_WITHOUT_DIALOG_CONTINUE_TAPPED);
    navigate('Review application');
  }, [navigate, trackUserEvent, setIsYourSignatureDialogVisible]);

  return (
    <Dialog
      open={isYourSignatureDialogVisible}
      title={t('title')}
      copy={t('description')}
      center
      icon={
        <Icon
          color={getVariableValue(tokens.color.Information)}
          height={getVariableValue(tokens.size[6])}
          name="info"
          width={getVariableValue(tokens.size[6])}
        />
      }
    >
      <YStack mt="$xl" gap="$md">
        <Button
          onPress={handleProvideSignatureNow}
          accessibilityLabel={t('provideSignatureLabel')}
        >
          {t('provideSignature')}
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={handleContinueWithoutSignature}
        >
          {t('continueWithoutSignature')}
        </Button>
      </YStack>
    </Dialog>
  );
};
