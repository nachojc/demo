import { Button, Stack, Text, YStack } from '@aviva/ion-mobile';

import { useFindAndCombineConditionalNavigation } from '../hooks/use-find-and-combine-conditional-navigation/use-find-and-combine-conditional-navigation';

export const IdentityVerificationScreen = () => {
  const { continueNavigation } = useFindAndCombineConditionalNavigation();
  return (
    <Stack flex={1} backgroundColor={'$DWPrimary500'}>
      <YStack
        flex={1}
        justifyContent="center"
        margin="$xxxl"
        alignItems="center"
        alignSelf="center"
      >
        <Text
          fontVariant="heading5-semibold-White"
          tamaguiTextProps={{ mt: '$xxl', mb: '$xl' }}
        >
          Identity verification screen
        </Text>
      </YStack>
      <Button
        marginBottom={'$xxl'}
        marginHorizontal={'$xl'}
        accessibilityLabel="Download new app"
        onPress={() => continueNavigation('Identity verification')}
      >
        next
      </Button>
    </Stack>
  );
};
