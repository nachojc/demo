import {
  Button,
  HeadingGroup,
  ScrollView,
  Separator,
  YStack,
} from '@aviva/ion-mobile';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { isIpad } from '@src/utils/is-ipad';
import { isEmptyString } from '@src/utils/string-manipulation';
import { tokens } from '@theme/tokens';
import { useState } from 'react';

import { NamesList } from '../names-list/names-list';
import { useFindAndCombineStackNavigation } from '../navigation/hooks';
import { useFindAndCombine } from '../navigation/provider';
import { FindAndCombineStepper } from '../stepper/find-and-combine-stepper';
import {
  PREVIOUS_DETAILS,
  PREVIOUS_DETAILS_ADD_ANOTHER_NAME_TAPPED,
  PREVIOUS_DETAILS_PREVIOUS_NAME_NO_TAPPED,
  PREVIOUS_DETAILS_PREVIOUS_NAME_YES_TAPPED,
  PREVIOUS_DETAILS_REMOVE_NAME_TAPPED,
} from './analytics';
import { usePreviousDetailsAnalytics } from './hooks/use-previous-details-analytics';
import { PreviousAddressList } from './previous-address-list';

export const PreviousDetailsScreen = () => {
  const { navigate } = useFindAndCombineStackNavigation();
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.previousDetails',
  });

  const previousNamesCopy = {
    yes: t('nameList.yes'),
    no: t('nameList.no'),
    firstName: t('nameList.firstName'),
    lastName: t('nameList.lastName'),
    firstNamePlaceHolder: t('nameList.firstNamePlaceHolder'),
    lastNamePlaceHolder: t('nameList.lastNamePlaceHolder'),
    addAnotherName: t('nameList.addAnotherName'),
    question: t('nameList.question'),
    remove: t('nameList.remove'),
  };

  useOnPageLoad({ pageTag: PREVIOUS_DETAILS });
  const { sendContinueTappedAnalytics } = usePreviousDetailsAnalytics();

  const {
    previousNames,
    previousNameQuestion,
    previousAddresses,
    previousAddressQuestion,
  } = useFindAndCombine();

  const initValueForNameQuestion = (): boolean | undefined => {
    if (previousNameQuestion.get()) {
      if (
        (previousNames.get() !== undefined &&
          previousNames
            .get()
            .filter(
              (name) =>
                isEmptyString(name.firstName) && isEmptyString(name.lastName)
            ).length === previousNames.length) ||
        previousNames.get() === undefined
      ) {
        return undefined;
      } else {
        return true;
      }
    } else {
      return previousNameQuestion.get();
    }
  };

  const hasInitValueForAddressQuestion = () => {
    if (previousAddresses.get().length > 0) {
      if (
        previousAddresses.get().length ===
        previousAddresses
          .get()
          .filter((address) =>
            isEmptyString(address.address.firstLineOfAddress)
          ).length
      ) {
        previousAddressQuestion.set(undefined);
        return false;
      }
      return true;
    }
    return false;
  };

  const [isNameDataFilled, setIsNameDataFilled] = useState<boolean>(
    initValueForNameQuestion() !== undefined
  );

  const [isAddressDataFilled, setIsAddressDataFilled] = useState(() => {
    return hasInitValueForAddressQuestion();
  });

  return (
    <ScrollView
      keyboardShouldPersistTaps="handled"
      contentContainerStyle={{
        flexGrow: 1,
        paddingBottom: tokens.space.xxl.val,
        paddingHorizontal: tokens.space.xl.val,
      }}
      automaticallyAdjustKeyboardInsets
      showsVerticalScrollIndicator={false}
    >
      <YStack flex={1} tablet={isIpad}>
        <FindAndCombineStepper screen={'Previous details'} />
        <YStack flex={1}>
          <HeadingGroup
            heading={t('title')}
            subHeading={t('subtitle')}
            marginBottom="$xxl"
          />
          <Separator borderColor="$Gray200" />
          <NamesList
            copy={previousNamesCopy}
            analyticsTags={{
              yes: PREVIOUS_DETAILS_PREVIOUS_NAME_YES_TAPPED,
              no: PREVIOUS_DETAILS_PREVIOUS_NAME_NO_TAPPED,
              addNewName: PREVIOUS_DETAILS_ADD_ANOTHER_NAME_TAPPED,
              removeName: PREVIOUS_DETAILS_REMOVE_NAME_TAPPED,
            }}
            onSelectionChange={() => {
              setIsNameDataFilled(true);
            }}
          />
          <PreviousAddressList
            onFormChange={(value) => {
              setIsAddressDataFilled(value);
            }}
          />
        </YStack>
        <YStack tabletNarrow={isIpad}>
          <Button
            disabled={!isNameDataFilled || !isAddressDataFilled}
            onPress={() => {
              sendContinueTappedAnalytics();
              navigate('Your signature');
            }}
            marginBottom={'$xxl'}
          >
            {t('continueCTA')}
          </Button>
        </YStack>
      </YStack>
    </ScrollView>
  );
};
