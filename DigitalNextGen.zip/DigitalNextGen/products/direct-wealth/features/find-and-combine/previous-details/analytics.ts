import { PAGE_WEALTH } from '@constants/analytics';

export const PREVIOUS_DETAILS = `${PAGE_WEALTH}|find-and-combine|apply|previous-details`;
export const PREVIOUS_DETAILS_CONTINUE_TAPPED = `${PREVIOUS_DETAILS}|continue-tapped`;
export const PREVIOUS_DETAILS_PREVIOUS_NAME_YES_TAPPED = `${PREVIOUS_DETAILS}|previous-name-yes-tapped`;
export const PREVIOUS_DETAILS_PREVIOUS_NAME_NO_TAPPED = `${PREVIOUS_DETAILS}|previous-name-no-tapped`;
export const PREVIOUS_DETAILS_ADD_ANOTHER_NAME_TAPPED = `${PREVIOUS_DETAILS}|add-another-name-tapped`;
export const PREVIOUS_DETAILS_REMOVE_NAME_TAPPED = `${PREVIOUS_DETAILS}|remove-name-tapped`;
export const PREVIOUS_DETAILS_ADDRESS_CHANGED_YES_TAPPED = `${PREVIOUS_DETAILS}|previous-address-yes-tapped`;
export const PREVIOUS_DETAILS_ADDRESS_CHANGED_NO_TAPPED = `${PREVIOUS_DETAILS}|previous-address-no-tapped`;
export const PREVIOUS_DETAILS_POSTCODE_LOOKUP_TAPPED = `${PREVIOUS_DETAILS}|postcode-lookup-tapped`;
export const PREVIOUS_DETAILS_ENTER_ADDRESS_MANUALLY_TAPPED = `${PREVIOUS_DETAILS}|enter-address-manually-tapped`;
export const PREVIOUS_DETAILS_ENTER_ADDRESS_MANUALLY_ADD_ADDRESS_TAPPED = `${PREVIOUS_DETAILS}|enter-address-manually|add-address-tapped`;
export const PREVIOUS_DETAILS_ENTER_ADDRESS_MANUALLY_CLOSE_TAPPED = `${PREVIOUS_DETAILS}|enter-address-manually|close-tapped`;
export const PREVIOUS_DETAILS_EDIT_ADDRESS_TAPPED = `${PREVIOUS_DETAILS}|edit-address-tapped`;
export const PREVIOUS_DETAILS_UPDATE_ADDRESS_TAPPED = `${PREVIOUS_DETAILS}|edit-address|update-tapped`;
export const PREVIOUS_DETAILS_REMOVE_ADDRESS_TAPPED = `${PREVIOUS_DETAILS}|edit-address|remove-tapped`;
export const PREVIOUS_DETAILS_EDIT_ADDRESS_CLOSE_TAPPED = `${PREVIOUS_DETAILS}|edit-address|close-tapped`;
export const PREVIOUS_DETAILS_ADD_ANOTHER_ADDRESS_TAPPED = `${PREVIOUS_DETAILS}|add-another-address-tapped`;
