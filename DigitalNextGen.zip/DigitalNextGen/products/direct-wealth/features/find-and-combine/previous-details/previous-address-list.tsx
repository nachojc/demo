import {
  DatePicker,
  EditAddressCard,
  Icon,
  Link,
  SegmentedControls,
  Separator,
  Stack,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { PostcodeLookup } from '@aviva/ion-mobile/components/postcode-lookup/postcode-lookup';
import { UK_DATE_FORMAT } from '@constants/string-formats';
import { InputField } from '@direct-wealth/components/input-field';
import { PreviousAddressForm } from '@direct-wealth/validation/schemas/find-and-combine/previous-address';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { convertIsoDate } from '@src/utils';
import { formatDateString } from '@src/utils/format-date-string';
import { getTestId } from '@src/utils/get-test-id';
import { isEmptyString } from '@src/utils/string-manipulation';
import { tokens } from '@theme/tokens';
import { subDays } from 'date-fns';
import { useEffect } from 'react';
import { Controller, UseFormReturn } from 'react-hook-form';

import { AddAddressModal } from '../address-entry-modals/add-address-modal';
import { EditAddressModal } from '../address-entry-modals/edit-address-modal';
import { useFindAndCombine } from '../navigation/provider';
import { usePreviousAddressForm } from './hooks/use-previous-address-form';
import { usePreviousDetailsAnalytics } from './hooks/use-previous-details-analytics';

export const PreviousAddressList = ({
  onFormChange,
}: {
  onFormChange: (value: boolean) => void;
}) => {
  const {
    addressForm,
    form,
    isEditModalVisible,
    isManualEntryModalVisible,
    isVisible,
    onAddAnotherAddress,
    onAddNewPreviousAddressPressed,
    onEditAddressPressed,
    onEnterAddressManuallyPressed,
    onRemoveAddressPressed,
    onSegmentedControlChange,
    onUpdateAddressPressed,
    setIsEditModalVisible,
    setIsManualEntryModalVisible,
    setAddress,
    getPreviousAddresses,
    numberOfAddressFormsToShow,
  } = usePreviousAddressForm();

  const {
    sendEditAddressCloseTappedAnalytics,
    sendEnterAddressManuallyCloseTapped,
    sendPostcodeSearchTappedAnalytics,
  } = usePreviousDetailsAnalytics();

  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.previousDetails.previousAddressList',
  });

  const { previousAddressQuestion } = useFindAndCombine();

  const { elementRef: postcodeSearchRef, focus: focusOnPostcodeSearch } =
    useA11yFocus();

  const previousAddresses = getPreviousAddresses();
  const numberOfAddressLimit = 5;
  const disableAddAnotherAddressCTA =
    previousAddresses.length + numberOfAddressFormsToShow ===
    numberOfAddressLimit;

  const defaultValue = () => {
    if (previousAddressQuestion.get()) {
      return previousAddresses.length === 0 ? undefined : true;
    } else {
      return previousAddressQuestion.get();
    }
  };

  const dateFormValues = form.getValues();

  useEffect(() => {
    if (previousAddressQuestion.get() === undefined) {
      onFormChange(false);
    } else if (previousAddressQuestion.get()) {
      onFormChange(
        (previousAddresses.length !== 0 &&
          dateFormValues.previousAddressDates.every(
            (dates) =>
              !isEmptyString(dates?.startDate) && !isEmptyString(dates?.endDate)
          ) &&
          form.formState.isValid) ||
          (previousAddresses.length === 0 && isVisible)
      );
    } else {
      onFormChange(true);
    }
  }, [
    dateFormValues,
    onFormChange,
    previousAddressQuestion,
    form,
    previousAddresses,
    isVisible,
  ]);

  const closeAddAddressModal = () => {
    sendEnterAddressManuallyCloseTapped();
    setIsManualEntryModalVisible(false);
    addressForm.reset();
  };

  const handleOnCloseEditAddress = () => {
    sendEditAddressCloseTappedAnalytics();
    setIsEditModalVisible(false);
    addressForm.reset();
  };

  return (
    <>
      <YStack marginTop={'$xxl'}>
        <Stack marginBottom={'$xxl'}>
          <Text
            tamaguiTextProps={{
              marginRight: '$xxl',
              marginBottom: '$md',
              lineHeight: '$small',
            }}
            fontVariant="body-semibold-Secondary800"
          >
            {t('question')}
          </Text>

          <SegmentedControls
            optionOne={t('yes')}
            optionTwo={t('no')}
            defaultValue={defaultValue()}
            onChange={(value) => {
              previousAddressQuestion.set(value);
              onSegmentedControlChange(value);
            }}
          />
        </Stack>
        <YStack justifyContent="space-between" marginBottom="$xxl">
          <>
            {isVisible && (
              <>
                {previousAddresses.map((addr, index) => {
                  const { id, address, startDate, endDate } = addr;
                  return (
                    <YStack key={id}>
                      <Separator
                        borderColor="$Gray200"
                        marginHorizontal={'$-xl'}
                      />
                      <Text
                        fontVariant="heading4-light-Gray800"
                        tamaguiTextProps={{
                          marginTop: '$xxl',
                          marginBottom: '$lg',
                        }}
                      >
                        {t('title')} {index + 1}
                      </Text>
                      <YStack marginBottom="$xxl" marginTop="$md" space={20}>
                        <EditAddressCard
                          cardContent={address}
                          onCardPress={() => {
                            onEditAddressPressed(id);
                          }}
                        />
                        <DateRangePicker
                          form={form}
                          id={id}
                          fromDate={startDate}
                          toDate={endDate}
                        />
                      </YStack>
                    </YStack>
                  );
                })}

                {[...Array(numberOfAddressFormsToShow)].map((_, index) => (
                  <YStack key={`address-list-${index}`}>
                    <Separator
                      borderColor="$Gray200"
                      marginHorizontal={'$-xl'}
                    />
                    <Text
                      fontVariant="heading4-light-Gray800"
                      tamaguiTextProps={{
                        marginTop: '$xxl',
                        marginBottom: '$lg',
                      }}
                    >
                      {t('title')} {previousAddresses.length + index + 1}
                    </Text>
                    <YStack marginBottom="$xxxl" marginTop="$md">
                      <PostcodeLookup
                        form={addressForm}
                        innerRef={postcodeSearchRef}
                        onAddressSelect={(address) => {
                          setAddress({ address, isNew: true });
                        }}
                        onPostcodeSearchTapped={
                          sendPostcodeSearchTappedAnalytics
                        }
                      />
                      <Link
                        onPress={() => {
                          onEnterAddressManuallyPressed();
                        }}
                      >
                        {t('addManuallyCTA')}
                      </Link>
                    </YStack>
                  </YStack>
                ))}

                <Separator
                  borderColor="$DWLightGrey"
                  marginHorizontal={'$-xl'}
                />

                <XStack
                  accessible
                  accessibilityRole="button"
                  accessibilityLabel={`${t('addAnotherAddressA11y')}`}
                  accessibilityState={{
                    disabled: disableAddAnotherAddressCTA,
                  }}
                  onPress={() => {
                    if (!disableAddAnotherAddressCTA) {
                      onAddAnotherAddress();
                      setTimeout(focusOnPostcodeSearch, 1000);
                    }
                  }}
                  paddingVertical={'$xxl'}
                  alignItems="center"
                >
                  <Icon
                    name="plus"
                    color={
                      disableAddAnotherAddressCTA
                        ? tokens.color.Gray400.val
                        : tokens.color.Tertiary800.val
                    }
                  />
                  <Text
                    tamaguiTextProps={{ paddingLeft: '$sm' }}
                    fontVariant={
                      disableAddAnotherAddressCTA
                        ? 'body-semibold-Gray400'
                        : 'body-semibold-Tertiary800'
                    }
                  >
                    {t('addAnotherAddress')}
                  </Text>
                </XStack>

                <Separator borderColor="$Gray200" marginHorizontal={'$-xl'} />

                {isEditModalVisible && (
                  <EditAddressModal
                    isVisible={isEditModalVisible}
                    addressForm={addressForm}
                    onUpdateAddressPressed={onUpdateAddressPressed}
                    onRemoveAddressPressed={onRemoveAddressPressed}
                    onClosePressed={handleOnCloseEditAddress}
                  />
                )}

                {isManualEntryModalVisible && (
                  <AddAddressModal
                    isVisible={isManualEntryModalVisible}
                    addressForm={addressForm}
                    onAddAddressPressed={onAddNewPreviousAddressPressed}
                    onClosePressed={closeAddAddressModal}
                  />
                )}
              </>
            )}
          </>
        </YStack>
      </YStack>
    </>
  );
};

const DateRangePicker = ({
  id,
  form,
  fromDate,
  toDate,
}: {
  id: string;
  form: UseFormReturn<PreviousAddressForm>;
  fromDate?: string;
  toDate?: string;
}) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.previousDetails.previousAddressDate',
  });

  const { updateAddressDateState, getPreviousAddresses } =
    usePreviousAddressForm();
  const { control, trigger, watch } = form;

  const addressIndex = getPreviousAddresses().findIndex(
    (address) => address.id === id
  );

  const [startDate, endDate] = watch([
    `previousAddressDates.${addressIndex}.startDate`,
    `previousAddressDates.${addressIndex}.endDate`,
  ]);

  useEffect(() => {
    startDate &&
      endDate &&
      trigger(`previousAddressDates.${addressIndex}.endDate`);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [startDate]);

  return (
    <YStack space="$xxl">
      <Controller
        name={`previousAddressDates.${addressIndex}.startDate`}
        control={control}
        defaultValue={fromDate ? convertIsoDate(fromDate, UK_DATE_FORMAT) : ''}
        render={({ field: { onChange, value }, fieldState: { error } }) => {
          return (
            <InputField
              label={t('fromDate')}
              field={
                <DatePicker
                  tamaguiInputProps={{
                    value,
                    onChangeText: (val) => {
                      onChange(val);
                      updateAddressDateState(id, 'startDate', val);
                    },
                    placeholder: 'DD/MM/YYYY',
                    testID: getTestId('address-start-date-input'),
                  }}
                  datePickerProps={{
                    date: value ? formatDateString(value) : new Date(),
                    maximumDate: subDays(new Date(), 1),
                  }}
                  error={Boolean(error)}
                  errorText={error?.message}
                />
              }
            />
          );
        }}
      />

      <Controller
        name={`previousAddressDates.${addressIndex}.endDate`}
        control={control}
        defaultValue={toDate ? convertIsoDate(toDate, UK_DATE_FORMAT) : ''}
        render={({ field: { onChange, value }, fieldState: { error } }) => {
          return (
            <InputField
              label={t('toDate')}
              field={
                <DatePicker
                  tamaguiInputProps={{
                    value,
                    onChangeText: (val) => {
                      onChange(val);
                      updateAddressDateState(id, 'endDate', val);
                    },
                    placeholder: 'DD/MM/YYYY',
                    testID: getTestId('address-end-date-input'),
                  }}
                  datePickerProps={{
                    date: value ? formatDateString(value) : new Date(),
                    maximumDate: new Date(),
                  }}
                  error={Boolean(error)}
                  errorText={error?.message}
                />
              }
            />
          );
        }}
      />
    </YStack>
  );
};
