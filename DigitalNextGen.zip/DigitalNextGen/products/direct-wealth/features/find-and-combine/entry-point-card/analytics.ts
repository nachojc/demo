import { PAGE_WEALTH } from '@constants/analytics';

export const PORTFOLIO_ENTRY_POINT_CARD = `${PAGE_WEALTH}|portfolio-summary|find-and-combine-card-tapped`;
export const PERFORMANCE_ENTRY_POINT_CARD = `${PAGE_WEALTH}|sipp|product-detail-performance|find-and-combine-card-tapped`;
export const ENQUIRER_ENTRY_POINT_CARD = `${PAGE_WEALTH}|pcs|enquirer|enquirer-summary|find-and-combine-card-tapped`;
export const LOCKED = `|idv-web`;
export const WEALTH_HUB_ENTRY_POINT_CARD = `${PAGE_WEALTH}|home-dashboard|wealth-hub|find-your-pensions-tapped`;
export const HOME_DASHBOARD_ENTRY_POINT_CARD = `${PAGE_WEALTH}|home-dashboard|find-your-pensions-tapped`;
