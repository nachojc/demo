import { EditorialContentCard } from '@direct-wealth/components/editorial-content-card';
import { useAnalytics } from '@hooks/use-analytics';
import { useIsDPA2Unlocked } from '@hooks/use-is-dpa2-unlocked';
import { useSelector } from '@legendapp/state/react';
import { config } from '@src/common/config';
import { FeatureFlags } from '@src/feature-flags';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { useCallback } from 'react';

import {
  ENQUIRER_ENTRY_POINT_CARD,
  HOME_DASHBOARD_ENTRY_POINT_CARD,
  LOCKED,
  PERFORMANCE_ENTRY_POINT_CARD,
  PORTFOLIO_ENTRY_POINT_CARD,
  WEALTH_HUB_ENTRY_POINT_CARD,
} from './analytics';

export const FCEntryPointCard = ({
  parentComponent,
  isEnquirer = false,
}: {
  parentComponent:
    | 'portfolio-summary'
    | 'performance-tab'
    | 'wealth-hub'
    | 'manga-dashboard';
  isEnquirer?: boolean;
}) => {
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const userIsDPA2Unlocked = useIsDPA2Unlocked();

  const dwFindAndCombineEnabled = useSelector(
    FeatureFlags.dwFindAndCombineEnabled
  );

  const onPress = useCallback(() => {
    if (isEnquirer) {
      // User is on the Enquirer Page - Check if they are locked
      trackUserEvent(
        userIsDPA2Unlocked
          ? ENQUIRER_ENTRY_POINT_CARD
          : ENQUIRER_ENTRY_POINT_CARD + LOCKED
      );
    } else if (parentComponent === 'performance-tab') {
      // User is on the Performance Page - Check if they are locked
      trackUserEvent(
        userIsDPA2Unlocked
          ? PERFORMANCE_ENTRY_POINT_CARD
          : PERFORMANCE_ENTRY_POINT_CARD + LOCKED
      );
    } else if (parentComponent === 'wealth-hub') {
      // User is on the Wealth Hub Page - Check if they are locked
      trackUserEvent(
        userIsDPA2Unlocked
          ? WEALTH_HUB_ENTRY_POINT_CARD
          : WEALTH_HUB_ENTRY_POINT_CARD + LOCKED
      );
    } else if (parentComponent === 'manga-dashboard') {
      // User is on the Home Dashboard Page - Check if they are locked
      trackUserEvent(
        userIsDPA2Unlocked
          ? HOME_DASHBOARD_ENTRY_POINT_CARD
          : HOME_DASHBOARD_ENTRY_POINT_CARD + LOCKED
      );
    } else {
      // User is on the Portoflio Summary - Check if they are locked
      trackUserEvent(
        userIsDPA2Unlocked
          ? PORTFOLIO_ENTRY_POINT_CARD
          : PORTFOLIO_ENTRY_POINT_CARD + LOCKED
      );
    }
    if (userIsDPA2Unlocked && dwFindAndCombineEnabled) {
      navigate('Find And Combine', { screen: 'Landing' });
    } else {
      navigate('Web View', {
        url:
          config.AVIVA_BASE_URL.get() +
          '/retirement/pensions/find-and-combine/',
      });
    }
  }, [
    dwFindAndCombineEnabled,
    isEnquirer,
    navigate,
    parentComponent,
    trackUserEvent,
    userIsDPA2Unlocked,
  ]);

  return (
    <EditorialContentCard
      type="NoSubtitle"
      icon="search"
      variant="small"
      title={'Find lost pensions and easily combine your money in one place'}
      onPress={onPress}
    />
  );
};
