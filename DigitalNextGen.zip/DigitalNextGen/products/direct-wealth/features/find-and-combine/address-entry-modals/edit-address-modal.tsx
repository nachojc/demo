import {
  Button,
  ButtonVariant,
  Modal,
  Stack,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { AddressInputForm } from '@aviva/ion-mobile/components/address-form/address-form';
import { AddressForm } from '@aviva/ion-mobile/components/address-form/types';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { isIpad } from '@src/utils/is-ipad';
import { UseFormReturn } from 'react-hook-form';
import { KeyboardAvoidingView } from 'react-native';

type EditAddressModalProps = {
  isVisible: boolean;
  addressForm: UseFormReturn<AddressForm>;
  onUpdateAddressPressed: () => void;
  onRemoveAddressPressed: () => void;
  onClosePressed: () => void;
};

export const EditAddressModal = ({
  isVisible,
  addressForm,
  onUpdateAddressPressed,
  onRemoveAddressPressed,
  onClosePressed,
}: EditAddressModalProps) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.addressEntryModals.editAddressModal',
  });

  const {
    formState: { isValid },
  } = addressForm;

  return (
    <Modal
      isOpen={isVisible}
      onClose={onClosePressed}
      backgroundColor="White"
      closeIconColor={'Secondary800'}
      modalHeight={0.9}
      hasTextInput
    >
      <YStack flex={isIpad ? 1 : undefined}>
        <KeyboardAvoidingView>
          <Stack marginBottom="$md">
            <Text
              fontVariant={'heading4-light-Gray800'}
              tamaguiTextProps={{ paddingBottom: '$xxl' }}
            >
              {t('editAddress')}
            </Text>
            <AddressInputForm form={addressForm} />
          </Stack>
        </KeyboardAvoidingView>
      </YStack>

      <YStack tabletNarrow={isIpad} paddingBottom={isIpad ? '$xxl' : undefined}>
        <Button
          onPress={onUpdateAddressPressed}
          disabled={!isValid}
          marginBottom="$xxl"
        >
          {t('updateAddressCTA')}
        </Button>
        <Button
          variant={ButtonVariant.OUTLINED_ERROR}
          onPress={onRemoveAddressPressed}
        >
          {t('removeAddressCTA')}
        </Button>
      </YStack>
    </Modal>
  );
};
