import { Button, Modal, Text, YStack } from '@aviva/ion-mobile';
import { AddressInputForm } from '@aviva/ion-mobile/components/address-form/address-form';
import { AddressForm } from '@aviva/ion-mobile/components/address-form/types';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { isIpad } from '@src/utils/is-ipad';
import { UseFormReturn } from 'react-hook-form';
import { KeyboardAvoidingView } from 'react-native';

export const AddAddressModal = ({
  isVisible,
  addressForm,
  onAddAddressPressed,
  onClosePressed,
}: {
  isVisible: boolean;
  addressForm: UseFormReturn<AddressForm>;
  onAddAddressPressed: () => void;
  onClosePressed: () => void;
}) => {
  const { t } = useTranslationDW({
    keyPrefix: 'findAndCombine.addressEntryModals.addAddressModal',
  });

  const {
    formState: { isValid },
  } = addressForm;

  return (
    <Modal
      isOpen={isVisible}
      onClose={onClosePressed}
      backgroundColor="White"
      closeIconColor={'Secondary800'}
      modalHeight={0.9}
      hasTextInput
    >
      <YStack flex={isIpad ? 1 : undefined}>
        <KeyboardAvoidingView>
          <Text
            fontVariant={'heading4-light-Gray800'}
            tamaguiTextProps={{ paddingBottom: '$xxl' }}
          >
            {t('addAddress')}
          </Text>
          <AddressInputForm form={addressForm} />
        </KeyboardAvoidingView>
      </YStack>
      <YStack tabletNarrow={isIpad} paddingBottom={isIpad ? '$xxl' : undefined}>
        <Button onPress={onAddAddressPressed} disabled={!isValid}>
          {t('addAddress')}
        </Button>
      </YStack>
    </Modal>
  );
};
