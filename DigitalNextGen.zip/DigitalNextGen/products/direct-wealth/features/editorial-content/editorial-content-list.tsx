import { getVariableValue, Stack, Text, YStack } from '@aviva/ion-mobile';
import { Carousel } from '@aviva/ion-mobile/components/carousel';
import { ItemSeparator } from '@src/components/item-separator';
import { TabletMosaicStack } from '@src/components/tablet-mosaic-stack';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useCallback, useEffect } from 'react';

import {
  EditorialContentCard,
  subtitleMap,
} from '../../components/editorial-content-card';
import { ErrorState } from '../../components/error-state/error-state';
import { EditorialContentCarouselLoading } from '../portfolio-summary/components/editorial-content-carousel-loading';
import { EditorialContentListLoading } from '../portfolio-summary/components/editorial-content-list-loading';
import {
  ContentListProps,
  EditorialContentProps,
  EditorialContentViewProps,
  ListItemProps,
} from './types';
import { useEditorialContentViewModel } from './use-editorial-content-view-model';

const CARD_WIDTH = 207;
const CAROUSEL_HEIGHT = 205; // Max large card height
const LIST_HEIGHT = 288;

const itemSeparatorSpacing = tokens.space.sm.val;
const snapToInterval = CARD_WIDTH + 2 * itemSeparatorSpacing;

export const NoviceEditorialData = {
  title: 'Learn more about investing',
  subtitle: 'Articles and videos to understand how to trade',
};

const ListItem = ({
  context,
  item,
  index,
  orientation = 'vertical',
  navigateToWebView,
  navigateToVideo,
  content,
}: ListItemProps) => {
  const { type, title, actionTag } = item;
  const isHorizontal = orientation === 'horizontal';

  const isVideo = type === 'Video';
  const isTool = type === 'Tool';

  const thumbnailUri = isVideo ? item?.videoThumbnailUri : item?.imageUri;
  const navigationUrl = isVideo ? item.videoUrl : item.webUrl;
  const icon = isTool ? item.icon : null;

  const handlePress = useCallback(() => {
    if (isVideo) {
      navigateToVideo(
        {
          title,
          uri: navigationUrl,
          transcript: item.transcript,
        },
        actionTag
      );
    } else {
      navigateToWebView({ url: navigationUrl }, actionTag);
    }
  }, [
    isVideo,
    navigateToWebView,
    navigateToVideo,
    title,
    navigationUrl,
    item,
    actionTag,
  ]);

  const getVariant = () => {
    if (isIpad && context === 'PortfolioSummary') {
      return 'iPad';
    } else {
      return orientation === 'vertical' ? 'small' : 'large';
    }
  };

  return (
    <YStack
      {...(isHorizontal && {
        width: CARD_WIDTH,
      })}
      marginRight={isIpad && '$xxl'}
      accessible
      accessibilityLabel={`${title}. ${index + 1} of ${content?.length}.`}
      accessibilityRole="link"
      accessibilityHint={`${subtitleMap[type]} this article on Aviva.co.uk`}
    >
      <EditorialContentCard
        type={type}
        title={title}
        onPress={handlePress}
        variant={getVariant()}
        image={thumbnailUri}
        icon={icon}
      />
    </YStack>
  );
};

const ContentList = ({
  content,
  orientation,
  navigateToWebView,
  navigateToVideo,
  isLoading,
  isError,
  refetch,
}: ContentListProps) => {
  const isHorizontal = orientation === 'horizontal';

  if (isError) {
    return (
      <Stack paddingHorizontal="$xl">
        <ErrorState
          variant="transparent"
          buttonAccessibilityHint="Error view due to being unable to load this content"
          message="Sorry, we were unable to load this content."
          buttonValue="Retry"
          onRetry={refetch}
          height={isHorizontal ? CAROUSEL_HEIGHT : LIST_HEIGHT}
        />
      </Stack>
    );
  }

  if (isLoading) {
    return isHorizontal ? (
      <EditorialContentCarouselLoading height={CAROUSEL_HEIGHT} />
    ) : (
      <EditorialContentListLoading height={LIST_HEIGHT} />
    );
  }
  if (isIpad && !isHorizontal) {
    return (
      <TabletMosaicStack
        columnMapOverride={{
          tabletLandscape: 2,
          tabletLandscapeLarge: 2,
        }}
        items={content ? content : []}
        renderSection={(children, index) => (
          <YStack key={`col-${index}`} space="$lg" flex={1}>
            {children}
          </YStack>
        )}
        renderItem={(item, index) => (
          <ListItem
            key={item.id}
            item={item}
            index={index}
            orientation={orientation}
            navigateToWebView={navigateToWebView}
            navigateToVideo={navigateToVideo}
            content={content}
          />
        )}
      />
    );
  }
  return isHorizontal
    ? content && (
        <Carousel
          testID={getTestId('editorial-content-carousel')}
          contentWidth={CARD_WIDTH}
          snapToInterval={snapToInterval}
          ItemSeparatorComponent={ItemSeparator}
          styles={{ ai: isIpad ? undefined : 'center' }}
        >
          {content.map((item, index) => (
            <Stack
              key={`${item.id}-${item.title}`}
              flex={1}
              width={CARD_WIDTH}
              my="$xl"
            >
              <ListItem
                key={item.id}
                item={item}
                index={index}
                orientation={orientation}
                navigateToWebView={navigateToWebView}
                navigateToVideo={navigateToVideo}
                content={content}
              />
            </Stack>
          ))}
        </Carousel>
      )
    : content && (
        <YStack
          accessibilityLabel="Editorial Content List"
          accessibilityHint="List of editorial content cards"
          testID={getTestId('vertical-list')}
          style={{ paddingHorizontal: tokens.space.xl.val }}
          space={tokens.space.xl.val}
        >
          {content.map((item, index) => (
            <ListItem
              key={`${item.id}-${item.title}`}
              item={item}
              index={index}
              orientation={orientation}
              navigateToWebView={navigateToWebView}
              navigateToVideo={navigateToVideo}
              content={content}
            />
          ))}
        </YStack>
      );
};

export const EditorialContentListView = ({
  model,
  context,
  orientation = 'horizontal',
  backgroundColor = 'Gray100',
}: EditorialContentViewProps) => {
  const {
    content,
    isError,
    isLoading,
    refetch,
    navigateToWebView,
    navigateToVideo,
    EditorialContentData,
    userUnderstanding,
    sendCustomImpressionTag,
  } = model;

  useEffect(() => {
    if (content) {
      sendCustomImpressionTag(content);
    }
  }, [content, sendCustomImpressionTag]);

  return (
    <YStack
      paddingVertical="$xxl"
      backgroundColor={getVariableValue(tokens.color[backgroundColor])}
    >
      <YStack
        tablet={isIpad}
        paddingHorizontal={
          isIpad && context === 'PortfolioSummary' ? '$xxxl' : '$xl'
        }
        accessibilityRole="header"
        testID={getTestId('editorial-content')}
      >
        <Text
          fontVariant="heading5-semibold-Secondary800"
          testID={getTestId('editorial-content-title')}
          tamaguiTextProps={{ accessibilityRole: 'header' }}
        >
          {userUnderstanding === 'Novice'
            ? NoviceEditorialData.title
            : EditorialContentData[context].title}
        </Text>
        <Text
          fontVariant="small-regular-Gray700"
          tamaguiTextProps={{ marginBottom: '$xl' }}
          testID={getTestId('editorial-content-subtitle')}
        >
          {userUnderstanding === 'Novice'
            ? NoviceEditorialData.subtitle
            : EditorialContentData[context].subtitle}
        </Text>
      </YStack>
      <YStack tablet={isIpad}>
        <ContentList
          content={content}
          orientation={orientation}
          navigateToWebView={navigateToWebView}
          navigateToVideo={navigateToVideo}
          isLoading={isLoading}
          isError={isError}
          refetch={refetch}
        />
      </YStack>
    </YStack>
  );
};

export const EditorialContentList = ({
  context,
  userUnderstanding,
  orientation,
  backgroundColor,
  tagInfo,
}: EditorialContentProps) => {
  const model = useEditorialContentViewModel(
    context,
    userUnderstanding,
    tagInfo
  );
  return (
    <EditorialContentListView
      orientation={orientation}
      backgroundColor={backgroundColor}
      model={model}
      context={context}
    />
  );
};
