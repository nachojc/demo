import {
  act,
  mockTrackStateEvent,
  mockTrackUserEvent,
  renderHook,
} from '@src/jest/testing-library';
import EditorialContent from '@src/api-mock/responses/DirectWealth/EditorialContent/Editorial_Content.json';

import { EditorialContentResponseSchema } from '../../../validation/schemas/editorial-content';
import { useEditorialContentViewModel } from '../use-editorial-content-view-model';

const mockEditorialContent = EditorialContentResponseSchema.parse(
  EditorialContent.content
).content;

let mockContent = mockEditorialContent;
let mockIsError = false;
let mockIsLoading = false;
const mockRefetch = jest.fn();
const mockNavigateToWebView = jest.fn();

jest.mock('../../../common/hooks/use-editorial-content', () => ({
  useEditorialContent: () => ({
    data: mockContent,
    isError: mockIsError,
    isLoading: mockIsLoading,
    refetch: mockRefetch,
    navigateToWebView: mockNavigateToWebView,
  }),
}));

const resetAllMocks = () => {
  mockContent = mockEditorialContent;
  mockIsError = false;
  mockIsLoading = false;
};

describe('use-editorial-content-view-model', () => {
  afterEach(resetAllMocks);

  it('should return the correct content data', async () => {
    const { result } = renderHook(useEditorialContentViewModel);

    expect(result.current.content).toEqual(
      EditorialContentResponseSchema.parse(EditorialContent.content).content
    );
  });

  it('should return isLoading as true if editorial data is still loading', () => {
    mockIsError = true;

    const { result } = renderHook(useEditorialContentViewModel);

    expect(result.current.isError).toEqual(true);
  });

  it('should return isLoading as true if editorial data fetch returns an error', () => {
    mockIsLoading = true;

    const { result } = renderHook(useEditorialContentViewModel);

    expect(result.current.isLoading).toEqual(true);
  });

  it('should call correct analytics tag when refetch is pressed', async () => {
    mockIsError = true;

    const { result } = renderHook(() =>
      useEditorialContentViewModel('EnquirerSummary', 'Novice', {
        type: 'enquirer|portfolio-summary',
      })
    );

    result.current.refetch();

    expect(mockRefetch).toHaveBeenCalledTimes(1);
    expect(mockTrackUserEvent).toHaveBeenCalledWith(
      'ukmyaviva|wealth|enquirer|portfolio-summary|content-retry-tapped'
    );
  });

  it('should call mockTrackUserEvent with correct tag when editorial content item is tapped', () => {
    const { result } = renderHook(() =>
      useEditorialContentViewModel('SippInformation', 'Novice', {
        type: 'SIPP',
        tab: 'Holdings',
      })
    );

    act(() => {
      result.current.navigateToWebView(
        { url: 'www.test.com' },
        'article-title-tapped'
      );
    });

    expect(mockTrackUserEvent).toHaveBeenLastCalledWith(
      'ukmyaviva|wealth|SIPP|productDetail-Holdings|article-title-tapped'
    );
  });

  it('should call mockTrackUserEvent with correct tag when editorial content item is tapped and user is Enquirer', () => {
    const { result } = renderHook(() =>
      useEditorialContentViewModel('EnquirerSummary', 'Novice', {
        type: 'enquirer|portfolio-summary',
      })
    );

    act(() => {
      result.current.navigateToWebView(
        { url: 'www.test.com' },
        'article-title-tapped'
      );
    });

    expect(mockTrackUserEvent).toHaveBeenLastCalledWith(
      'ukmyaviva|wealth|enquirer|portfolio-summary|article-title-tapped'
    );
  });

  it('should call mockScreenEvent with the list of truncated content titles', () => {
    const { result } = renderHook(() =>
      useEditorialContentViewModel('SippInformation', 'Novice', {
        type: 'SIPP',
        tab: 'Holdings',
      })
    );

    act(() => {
      result.current.sendCustomImpressionTag(mockContent);
    });

    expect(mockTrackStateEvent).toHaveBeenLastCalledWith(
      'ukmyaviva|wealth|SIPP|productDetail-Holdings',
      {
        contentcustomimpression:
          'isa-calculator-1|what-is-investing-2|how-to-keep-calm-when-stock-markets-fluc-3',
      }
    );
  });

  it('should call mockTrackUserEvent with correct tag when editorial content item is tapped from wealth hub screen', () => {
    const { result } = renderHook(() =>
      useEditorialContentViewModel('PortfolioSummary', undefined, {
        type: 'home-dashboard|wealth-hub',
      })
    );

    act(() => {
      result.current.navigateToWebView(
        { url: 'www.test.com' },
        'article-title-tapped'
      );
    });

    expect(mockTrackUserEvent).toHaveBeenLastCalledWith(
      'ukmyaviva|wealth|home-dashboard|wealth-hub|article-title-tapped'
    );
  });
});
