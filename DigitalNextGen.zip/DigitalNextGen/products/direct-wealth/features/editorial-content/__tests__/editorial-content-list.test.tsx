import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';
import { UserUnderstanding } from 'products/direct-wealth/models/editorial-content';
import { EditorialContext } from 'products/direct-wealth/validation/schemas/editorial-content';

import {
  EditorialContentListView,
  NoviceEditorialData,
} from '../editorial-content-list';
import { EditorialContentBaseProps } from '../types';
import {
  EditorialContentData,
  useEditorialContentViewModel,
} from '../use-editorial-content-view-model';

type DeepPartial<T> = T extends (infer U)[]
  ? DeepPartial<U>[]
  : { [P in keyof T]?: DeepPartial<T[P]> };

type EditorialContentListTestViewProps = DeepPartial<
  ReturnType<typeof useEditorialContentViewModel>
>;

jest.mock('@hooks/use-auth', () => ({
  useAuth: () => ({
    isSignedIn: true,
  }),
}));

const EditorialContentListTestView = ({
  props,
  modelProps,
  userUnderstanding = 'Experienced',
}: {
  props?: Partial<EditorialContentBaseProps>;
  modelProps?: EditorialContentListTestViewProps;
  userUnderstanding?: UserUnderstanding;
}) => {
  const model = useEditorialContentViewModel(
    'PortfolioSummary',
    userUnderstanding
  );
  return (
    <EditorialContentListView
      context="SippInformation"
      orientation="horizontal"
      model={{ ...model, ...(modelProps as typeof model) }}
      {...props}
    />
  );
};

describe('EditorialContentList', () => {
  afterEach(() => {
    jest.clearAllMocks();
    cleanup();
  });

  it.each(Object.keys(EditorialContentData))(
    'should display correct title and subtitle when %s context is passed for an experienced investor',
    (editorialContext) => {
      render(
        <EditorialContentListTestView
          props={{ context: editorialContext as EditorialContext }}
        />
      );
      const listTitle = screen.getByText(
        EditorialContentData[editorialContext as EditorialContext].title
      );
      const listSubtitle = screen.getByText(
        EditorialContentData[editorialContext as EditorialContext].subtitle
      );

      expect(listTitle).toBeOnTheScreen();
      expect(listSubtitle).toBeOnTheScreen();
    }
  );

  it('should render the correct title and subtitle for a novice investor', () => {
    render(<EditorialContentListTestView userUnderstanding="Novice" />);

    const listTitle = screen.getByText(NoviceEditorialData.title);
    const listSubtitle = screen.getByText(NoviceEditorialData.subtitle);

    expect(listTitle).toBeOnTheScreen();
    expect(listSubtitle).toBeOnTheScreen();
  });

  it('should render error component when isError is true', async () => {
    render(<EditorialContentListTestView modelProps={{ isError: true }} />);
    await waitFor(() => {
      const errorMessage = screen.getByText(
        'Sorry, we were unable to load this content.'
      );
      expect(errorMessage).toBeOnTheScreen();
    });
  });

  it('should should call refetch function when isError is true and Retry is pressed', async () => {
    const mockRefetch = jest.fn();

    render(
      <EditorialContentListTestView
        modelProps={{ isError: true, refetch: mockRefetch }}
      />
    );

    const retryButton = await screen.findByText('Retry');
    expect(retryButton).toBeOnTheScreen();
    fireEvent.press(retryButton);
    expect(mockRefetch).toHaveBeenCalledTimes(1);
  });

  it('should render carousel loading component when isLoading is true', async () => {
    render(
      <EditorialContentListTestView
        modelProps={{
          isLoading: true,
        }}
      />
    );
    await waitFor(() => {
      const loadingShimmer = screen.getAllByLabelText(
        'Editorial Content Carousel Loading'
      );
      expect(loadingShimmer[0]).toBeOnTheScreen();
    });
  });

  it('should render list loading component when isLoading is true with vertical list', async () => {
    render(
      <EditorialContentListTestView
        props={{ orientation: 'vertical' }}
        modelProps={{ isLoading: true }}
      />
    );
    await waitFor(() => {
      const loadingShimmer = screen.getAllByLabelText(
        'Editorial Content List Loading'
      );
      expect(loadingShimmer[0]).toBeOnTheScreen();
    });
  });

  it('should render the list with small styled cards when orientation vertical is passed', async () => {
    render(
      <EditorialContentListTestView props={{ orientation: 'vertical' }} />
    );
    const cardContainer = await screen.findAllByTestId(
      'editorial-content-card'
    );

    expect(screen.getByLabelText('Editorial Content List')).toBeOnTheScreen();
    expect(cardContainer[0]).toHaveStyle({ flexDirection: 'row' });
  });

  it('should render the list with horizontal padding when orientation vertical is passed', async () => {
    render(
      <EditorialContentListTestView props={{ orientation: 'vertical' }} />
    );
    const cardContainer = await screen.findByTestId(getTestId('vertical-list'));
    expect(cardContainer).toHaveStyle({ paddingHorizontal: 16 });
  });

  it('should render the carousel with large styled cards when orientation horizontal is passed', async () => {
    render(
      <EditorialContentListTestView props={{ orientation: 'horizontal' }} />
    );
    const cardContainer = await screen.findAllByTestId(
      'editorial-content-card'
    );

    expect(
      screen.getByTestId(getTestId('editorial-content-carousel'))
    ).toBeOnTheScreen();
    expect(cardContainer[0]).toHaveStyle({ flexDirection: 'column' });
  });

  it('should display the content returned from the model in the list', async () => {
    render(<EditorialContentListTestView />);
    const card1Title = await screen.findByText('ISA Calculator', {
      includeHiddenElements: true,
    });
    const card2Title = await screen.findByText('What is Investing?', {
      includeHiddenElements: true,
    });
    const card3Title = await screen.findByText(
      'How to keep calm when stock markets fluctuate',
      {
        includeHiddenElements: true,
      }
    );

    expect(card1Title).toBeOnTheScreen();
    expect(card2Title).toBeOnTheScreen();
    expect(card3Title).toBeOnTheScreen();
  });
});
