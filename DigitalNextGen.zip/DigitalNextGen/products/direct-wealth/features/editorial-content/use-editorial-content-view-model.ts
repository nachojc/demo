import { PAGE_WEALTH } from '@constants/analytics';
import { useAnalytics } from '@hooks/use-analytics';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { convertToKebabCase } from '@src/utils';
import { removeSpecialCharacters } from '@src/utils/string-manipulation';
import { UserUnderstanding } from 'products/direct-wealth/models/editorial-content';
import { SubaccountAccount } from 'products/direct-wealth/validation/schemas/direct-wealth-subaccount';
import { useCallback } from 'react';

import { useEditorialContent } from '../../common/hooks/use-editorial-content';
import {
  EditorialContent,
  EditorialContext,
} from '../../validation/schemas/editorial-content';

type EditorialContentCopy = {
  title: string;
  subtitle: string;
};

export const EditorialContentData: {
  [key in EditorialContext]: EditorialContentCopy;
} = {
  PortfolioSummary: {
    title: 'Get the most from your products',
    subtitle: 'Articles and videos tailored to you',
  },
  EnquirerSummary: {
    title: 'Get the most from your money',
    subtitle: 'Articles and videos tailored to you',
  },
  SippInformation: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  GiaInformation: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  IsaInformation: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  DrawdownInformation: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  SippInvestments: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  GiaInvestments: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  IsaInvestment: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  DrawdownInvestments: {
    title: 'Learn more',
    subtitle: 'Articles and videos to take control of your wealth',
  },
  PensionConsolidationSummary: {
    title: 'Learn more about pensions',
    subtitle: 'Articles and videos tailored to you',
  },
  OpenAnIsa: {
    title: 'Learn more about ISAs',
    subtitle: 'Articles and videos to help decide if an ISA is right for you',
  },
};

export type TagInfo = {
  type?:
    | SubaccountAccount
    | 'portfolio-summary'
    | 'pcs-dashboard'
    | 'enquirer|portfolio-summary'
    | 'home-dashboard|wealth-hub'
    | 'isa-apply-direct|landing-page';
  tab?: string;
};

export const useEditorialContentViewModel = (
  context?: EditorialContext,
  userUnderstanding?: UserUnderstanding,
  tagInfo?: TagInfo
) => {
  const result = useEditorialContent(context, userUnderstanding);
  const { data: content, isError, isLoading } = result;
  const { refetch } = result;

  const { navigate } = useAppStackNavigation();

  const analytics = useAnalytics();

  const tabInfo = tagInfo?.tab ? `|productDetail-${tagInfo.tab}` : '';

  const sendEditorialContentTag = useCallback(
    (actionTag: string) => {
      analytics.trackUserEvent(
        `${PAGE_WEALTH}|${tagInfo?.type}${tabInfo}|${actionTag}`
      );
    },
    [analytics, tagInfo?.type, tabInfo]
  );

  const createCustomImpressionString = (editorialContent: EditorialContent) => {
    const allBannerTitles: string[] = [];
    editorialContent.forEach((contentDetail, index) => {
      const kebabTitle = convertToKebabCase(
        removeSpecialCharacters(contentDetail.title)
      );
      const carouselPosition = index + 1;
      return allBannerTitles.push(
        kebabTitle.substring(0, 40) + `-${carouselPosition}`
      );
    });
    return allBannerTitles.join('|');
  };

  const sendCustomImpressionTag = useCallback(
    (editorialContent: EditorialContent) => {
      analytics.trackStateEvent(`${PAGE_WEALTH}|${tagInfo?.type}${tabInfo}`, {
        contentcustomimpression: createCustomImpressionString(editorialContent),
      });
    },
    [analytics, tagInfo?.type, tabInfo]
  );

  const navigateToWebView = useCallback(
    (link: { url: string }, actionTag?: string | null) => {
      actionTag && sendEditorialContentTag(actionTag);
      navigate('Web View', link);
    },
    [navigate, sendEditorialContentTag]
  );

  const navigateToVideo = useCallback(
    (
      video: { title: string; uri: string; transcript: string },
      actionTag?: string | null
    ) => {
      actionTag && sendEditorialContentTag(actionTag);
      navigate('Video Player', video);
    },
    [navigate, sendEditorialContentTag]
  );

  const refetchEditorialContent = () => {
    analytics.trackUserEvent(
      `${PAGE_WEALTH}|${tagInfo?.type}${tabInfo}|content-retry-tapped`
    );
    refetch();
  };

  return {
    content,
    isError,
    isLoading,
    refetch: refetchEditorialContent,
    navigateToWebView,
    EditorialContentData,
    navigateToVideo,
    userUnderstanding,
    sendCustomImpressionTag,
  };
};
