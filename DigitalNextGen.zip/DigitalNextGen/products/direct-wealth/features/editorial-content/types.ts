import { UserUnderstanding } from '@direct-wealth/models/editorial-content';
import {
  EditorialContent,
  EditorialContext,
} from '@direct-wealth/validation/schemas/editorial-content';
import { Color } from '@src/theme/tokens';

import {
  TagInfo,
  useEditorialContentViewModel,
} from './use-editorial-content-view-model';

type Orientation = 'horizontal' | 'vertical';

export type ListItemProps = {
  context?: EditorialContext;
  item: EditorialContent[number];
  orientation: Orientation;
  navigateToWebView: (link: { url: string }, actionTag?: string | null) => void;
  navigateToVideo: (
    video: {
      title: string;
      uri: string;
      transcript: string;
    },
    actionTag?: string | null
  ) => void;
  index: number;
  content?: EditorialContent;
};

export type ContentListProps = {
  context?: EditorialContext;
  content?: EditorialContent;
  orientation: Orientation;
  navigateToWebView: (link: { url: string }, actionTag?: string | null) => void;
  navigateToVideo: (
    video: {
      title: string;
      uri: string;
      transcript: string;
    },
    actionTag?: string | null
  ) => void;
  isLoading: boolean;
  isError: boolean;
  refetch: () => void;
};

export type EditorialContentBaseProps = {
  orientation?: Orientation;
  backgroundColor?: Color;
  context: EditorialContext;
};

export type EditorialContentViewProps = EditorialContentBaseProps & {
  model: ReturnType<typeof useEditorialContentViewModel>;
};

export type EditorialContentProps = EditorialContentBaseProps & {
  userUnderstanding?: UserUnderstanding;
  tagInfo?: TagInfo;
};
