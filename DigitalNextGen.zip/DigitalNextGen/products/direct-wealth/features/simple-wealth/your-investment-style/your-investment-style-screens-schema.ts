import { z } from 'zod';

export const YourInvestmentStyleSchema = z.object({ response: z.string() });

export type YourInvestmentStyleForm = z.infer<typeof YourInvestmentStyleSchema>;
