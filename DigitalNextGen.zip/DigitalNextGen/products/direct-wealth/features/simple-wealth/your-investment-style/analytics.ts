import { PAGE_WEALTH } from '@constants/analytics';

import {
  SIMPLE_WEALTH,
  YOUR_INVESTMENT_STYLE,
} from '../navigation/header/analytics';

export const screenAnalyticsTagForQuestion = (question: number) => {
  return `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${YOUR_INVESTMENT_STYLE}|question-${question}`;
};

export const continueTappedTagForQuestion = (question: number) => {
  return `${screenAnalyticsTagForQuestion(question)}|continue-tapped`;
};
export const BACK_TO_START_ANALYTICS = `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${YOUR_INVESTMENT_STYLE}|question-thirteen|modal-pop-up|back-to-start-tapped`;
export const CONFIRM_ANALYTICS = `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${YOUR_INVESTMENT_STYLE}|question-thirteen|modal-pop-up|confirm-tapped`;
