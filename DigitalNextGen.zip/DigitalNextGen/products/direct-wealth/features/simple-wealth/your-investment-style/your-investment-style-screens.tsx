import {
  Button,
  Dialog,
  LoadingState,
  RadioCard,
  ScrollView,
  Stack,
  TamaguiTextProps,
  Text,
  ValueRangeProgress,
  YStack,
} from '@aviva/ion-mobile';
import {
  useSimpleWealthStackNavigation,
  useSimpleWealthStackRoute,
} from '@direct-wealth/features/simple-wealth/navigation/hooks';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useFocusEffect } from '@react-navigation/native';
import { ErrorDialog } from '@src/components/error-dialog';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Controller, useForm, useWatch } from 'react-hook-form';
import { SafeAreaView } from 'react-native';

import {
  BACK_TO_START_ANALYTICS,
  CONFIRM_ANALYTICS,
  continueTappedTagForQuestion,
  screenAnalyticsTagForQuestion,
} from './analytics';
import { useSubmitSimpleWealthQuestionnaire } from './hooks/use-submit-simple-wealth-questionnaire';
import YourInvestmentStyleData from './your-investment-style-questions.json';
import {
  YourInvestmentStyleForm,
  YourInvestmentStyleSchema,
} from './your-investment-style-screens-schema';

const RETRY_LIMIT = 5;
const ATRResponses: { questionId: string; responseIds: string[] }[] = [];

const getAnswer = (questionId: string) => {
  const index = ATRResponses.findIndex(
    (item) => item?.questionId === questionId ?? false
  );
  return index !== -1 ? ATRResponses[index].responseIds[0] : undefined;
};

const radioText: TamaguiTextProps = {
  fontSize: tokens.size['4'],
  fontWeight: '$regular',
  color: tokens.color.Gray700,
};

export const YourInvestmentStyleScreen = () => {
  const {
    params: { Question, reset },
  } = useSimpleWealthStackRoute<'YourInvestmentStyleQuestions'>();

  const { t } = useTranslationDW({
    keyPrefix: 'navigator',
  });

  useOnPageLoad({ pageTag: screenAnalyticsTagForQuestion(Question) });

  const { trackUserEvent } = useAnalytics();
  const navigation = useSimpleWealthStackNavigation();
  const { isLoading, isError, submitQuestionnaire } =
    useSubmitSimpleWealthQuestionnaire();
  const questionIndex = Question - 1;
  const formRef = useRef(false);
  const retryCount = useRef(0);
  const [modalVisible, setModalVisible] = useState(false);
  const [errorDialog, setErrorDialog] = useState(false);

  const questionProgressText = `${t(
    'yourInvestmentStyle.questionProgress'
  )} ${Question} ${t('yourInvestmentStyle.questionProgressSeparator')} ${
    YourInvestmentStyleData.questions.length
  }`;

  const questionLookup = YourInvestmentStyleData.questions.find(
    (question) => question.order === Question
  );
  if (reset) {
    ATRResponses.length = 0;
  }
  useFocusEffect(
    useCallback(() => {
      formRef.current = true;
    }, [])
  );

  if (questionLookup === undefined) {
    throw new TypeError(
      'Question ' + { Question } + 'should always be present in ATRData'
    );
  }
  const { id: questionId, text: questionText, responses } = questionLookup;

  const AttitudeToRiskFormResolver = zodResolver(YourInvestmentStyleSchema);

  const form = useForm<YourInvestmentStyleForm>({
    resolver: AttitudeToRiskFormResolver,
    defaultValues: {
      response: getAnswer(questionId),
    },
  });

  const { handleSubmit, control } = form;

  const formWatcher = useWatch<YourInvestmentStyleForm>({
    control,
    defaultValue: undefined,
  });

  const handleContinue = useCallback(async () => {
    if (!formRef.current) {
      return;
    }

    trackUserEvent(continueTappedTagForQuestion(Question));

    const formValues = form.getValues();

    const index = ATRResponses.findIndex(
      (item) => item?.questionId === questionId ?? false
    );

    if (getAnswer(questionId)) {
      ATRResponses[index] = {
        questionId,
        responseIds: [formValues.response],
      };
    } else {
      ATRResponses.push({
        questionId,
        responseIds: [formValues.response],
      });
    }

    if (Question === YourInvestmentStyleData.questions.length) {
      setModalVisible(true);
      return;
    }
    navigation.push('YourInvestmentStyleQuestions', {
      Question: Question + 1,
    });
    formRef.current = false;
  }, [Question, form, navigation, questionId, trackUserEvent]);

  const onConfirm = async () => {
    trackUserEvent(CONFIRM_ANALYTICS);
    setModalVisible(false);
    const isSuccess = await submitQuestionnaire(ATRResponses);

    if (isSuccess) {
      setModalVisible(false);
      navigation.reset({
        index: 0,
        routes: [{ name: 'InvestmentStyleScreen' }],
      });
    } else if (!isError && retryCount.current <= RETRY_LIMIT) {
      retryCount.current++;
      onConfirm();
    } else {
      retryCount.current = 0;
      setModalVisible(false);
      setErrorDialog(true);
    }
  };

  const onBackToStart = () => {
    trackUserEvent(BACK_TO_START_ANALYTICS);
    setModalVisible(false);
    navigation.reset({
      index: 0,
      routes: [
        { name: 'YourInvestmentStyleQuestions', params: { Question: 1 } },
      ],
    });
  };

  useFocusEffect(
    useCallback(() => {
      formRef.current = true;
    }, [])
  );

  useEffect(() => {
    if (isError) {
      setModalVisible(false);
      setErrorDialog(true);
    }
  }, [isError]);

  return (
    <SafeAreaView
      style={{
        height: '100%',
      }}
    >
      <ScrollView
        contentContainerStyle={{ flexGrow: 1 }}
        showsHorizontalScrollIndicator={false}
      >
        <YStack
          testID={getTestId('bodyContainer')}
          px={'$xl'}
          f={1}
          jc={'space-between'}
          tablet={isIpad}
        >
          <YStack>
            <ValueRangeProgress
              mt={tokens.space.xxl}
              mb={tokens.space.md}
              currentValue={questionIndex}
              startValue={0}
              endValue={13}
              progressIndicatorColor={'$Primary500'}
            />
            <Text
              fontVariant="small-regular-Gray800"
              tamaguiTextProps={{
                mt: '$-md',
                mb: '$xl',
                accessibilityRole: 'header',
              }}
            >
              {questionProgressText}
            </Text>
            <YStack>
              <Text
                fontVariant="heading4-light-Gray800"
                tamaguiTextProps={{ mb: '$lg' }}
              >
                {questionText}
              </Text>
              {responses
                .sort((a, b) => a.order - b.order)
                .map((response, index) => {
                  return (
                    <Controller
                      name="response"
                      control={control}
                      key={response.id}
                      render={({ field: { onChange, value } }) => {
                        return (
                          <RadioCard
                            a11yOpts={{
                              item: index + 1,
                              total: responses.length,
                            }}
                            title={response.text}
                            titleTextProps={radioText}
                            selected={value === response.id}
                            onPress={() => {
                              onChange(response.id);
                            }}
                            mt="$sm"
                            accessibilityHint="Required"
                          />
                        );
                      }}
                    />
                  );
                })}
            </YStack>
          </YStack>

          <YStack
            testID={getTestId('buttonContainer')}
            pb={isIpad ? '$xxl' : undefined}
            tabletNarrow={isIpad}
          >
            <Button
              mb="$lg"
              mt="$xxl"
              ml="$xl"
              mr="$xl"
              onPress={handleSubmit(handleContinue)}
              accessibilityHint={t('common.continueAccessibilityHint')}
              disabled={formWatcher.response === undefined}
            >
              {t('common.continue')}
            </Button>
          </YStack>
          <Dialog
            open={modalVisible}
            title={
              <Text fontVariant="heading3-bold-Gray800">
                {t('yourInvestmentStyle.confirmYourAnswers')}
              </Text>
            }
          >
            <Stack marginTop="$xl">
              <Text fontVariant="body-regular-Gray700">
                {t('yourInvestmentStyle.confirmYourAnswersContent')}
              </Text>
              <Button onPress={onConfirm} marginTop={'$xxl'}>
                {t('yourInvestmentStyle.confirm')}
              </Button>
              <Button
                variant="linkText"
                onPress={onBackToStart}
                marginTop={'$md'}
              >
                {t('yourInvestmentStyle.backToStart')}
              </Button>
            </Stack>
          </Dialog>
          {isLoading && !isError ? <LoadingState text="nextStep" /> : null}
          {errorDialog ? (
            <ErrorDialog
              open={errorDialog}
              onPress={() => setErrorDialog(false)}
              center
            />
          ) : null}
        </YStack>
      </ScrollView>
    </SafeAreaView>
  );
};
