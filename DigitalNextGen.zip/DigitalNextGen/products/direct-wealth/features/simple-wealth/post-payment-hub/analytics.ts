import { PAGE_WEALTH } from '@constants/analytics';

import {
  SIMPLE_WEALTH,
  SIMPLE_WEALTH_POST_PAYMENT,
} from '../navigation/header/analytics';

export const POST_PAYMENT_HUB_PAGE = `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${SIMPLE_WEALTH_POST_PAYMENT}`;
export const POST_PAYMENT_HUB_SUITABILITY_REPORT_TAPPED = `${POST_PAYMENT_HUB_PAGE}|suitability-report-tapped`;
export const POST_PAYMENT_HUB_ISA_INFO_TAPPED = `${POST_PAYMENT_HUB_PAGE}|isa-info-tapped`;
export const POST_PAYMENT_HUB_ADVICE_DOCS_TAPPED = `${POST_PAYMENT_HUB_PAGE}|nav-services-info-tapped`;
export const POST_PAYMENT_HUB_EXPIRED_MODAL = `${POST_PAYMENT_HUB_PAGE}|expired-modal`;
export const POST_PAYMENT_HUB_EXPIRED_MODAL_GOT_IT_TAPPED = `${POST_PAYMENT_HUB_EXPIRED_MODAL}|got-it-tapped`;
export const POST_PAYMENT_HUB_MONEY_COACH_TAPPED = `${POST_PAYMENT_HUB_PAGE}|money-coach-tapped`;
export const POST_PAYMENT_HUB_DIGITAL_ADVICE_SUMMARY_TAPPED = `${POST_PAYMENT_HUB_PAGE}|digital-advice-summary-tapped`;
export const POST_PAYMENT_HUB_BOOK_CALL_TAPPED = `${POST_PAYMENT_HUB_PAGE}|book-call-tapped`;
export const POST_PAYMENT_HUB_INVEST_NOW_TAPPED = `${POST_PAYMENT_HUB_PAGE}|invest-now-tapped`;
