import {
  Button,
  ButtonVariant,
  Card,
  Dialog,
  Icon,
  IconName,
  ScrollView,
  Stack,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { AlertChipExtendable } from '@aviva/ion-mobile/components/chip/alert-chips';
import { AlertChipText } from '@aviva/ion-mobile/components/chip/chip.styles';
import { LoadingSpinner } from '@aviva/ion-mobile/components/loading-spinner';
import { DigitalAdvice } from '@direct-wealth/validation/schemas/aviva-simple-wealth';
import { useAnalytics } from '@hooks/use-analytics';
import { useNavigateToDashboard } from '@hooks/use-navigate-to-dashboard';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { ObservableObject } from '@legendapp/state';
import { useSelector } from '@legendapp/state/react';
import { config } from '@src/common/config';
import { ErrorDialog } from '@src/components/error-dialog';
import { FeatureFlags } from '@src/feature-flags';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';
import { PdfSourceFactory } from '@src/utils/download-pdf/pdf-source';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { differenceInCalendarDays } from 'date-fns';
import { memo, useEffect, useMemo, useState } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useAdviceSummaryNavigation } from '../advice-summary/use-advice-summary-navigation/use-advice-summary-navigation';
import {
  HeroCard,
  HeroCardIconVariant,
} from '../components/hero-card/hero-card';
import {
  HeaderComponent,
  HeaderComponentLoading,
} from '../components/simple-wealth-hub-header-cluster/header-cluster';
import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import { useNavigatorState } from '../navigation/provider';
import { MandatoryDocuments } from '../navigation/provider/state/post-payment';
import {
  POST_PAYMENT_HUB_ADVICE_DOCS_TAPPED,
  POST_PAYMENT_HUB_BOOK_CALL_TAPPED,
  POST_PAYMENT_HUB_EXPIRED_MODAL,
  POST_PAYMENT_HUB_EXPIRED_MODAL_GOT_IT_TAPPED,
  POST_PAYMENT_HUB_INVEST_NOW_TAPPED,
  POST_PAYMENT_HUB_ISA_INFO_TAPPED,
  POST_PAYMENT_HUB_MONEY_COACH_TAPPED,
  POST_PAYMENT_HUB_PAGE,
  POST_PAYMENT_HUB_SUITABILITY_REPORT_TAPPED,
} from './analytics';
import { useGetAdviceSummaryProgress } from './hooks/use-get-advice-summary-progress';
import { usePostPaymentHub } from './hooks/use-post-payment-hub';
import { useAndroidBackToPortfolio } from './hooks/useAndroidBackToPortfolio';

export const PostPaymentHub = () => {
  const safeAreaInsets = useSafeAreaInsets();
  const {
    avivaSimpleWealth: { digitalAdvice } = {},
    isLoading,
    isError,
    fetchData,
    suitabilityDocumentData,
    fundId,
  } = usePostPaymentHub();

  const count = digitalAdvice?.expiryDate
    ? differenceInCalendarDays(new Date(digitalAdvice.expiryDate), new Date())
    : 0;

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const shouldShowError = !isLoading && isError && count > 0;
  const isLoaded = !isLoading && !shouldShowError;
  const paddingBottom = isIpad
    ? safeAreaInsets.bottom + tokens.space.xxxxl.val
    : safeAreaInsets.bottom + tokens.space.xl.val;

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{
        flexGrow: 1,
        paddingBottom,
        backgroundColor: tokens.color.Gray050.val,
      }}
    >
      {isLoading && <LoadingView />}

      {shouldShowError && <ErrorView refetch={fetchData} />}

      {isLoaded && (
        <SuccessView
          suitabilityDocumentData={suitabilityDocumentData}
          fundId={fundId}
          digitalAdvice={digitalAdvice as DigitalAdvice}
        />
      )}
    </ScrollView>
  );
};

const LoadingView = () => {
  const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
  return (
    <>
      <HeaderComponentLoading title={t('pageTitle')} />
      <Stack marginTop={'$xxxxl'} marginHorizontal={'$xxxl'}>
        <Card>
          <Stack
            paddingHorizontal={'$xxl'}
            paddingVertical={'$xxxl'}
            alignItems="center"
          >
            <LoadingSpinner />
            <Text
              fontVariant="body-regular-Gray800"
              tamaguiTextProps={{ marginTop: '$xxl' }}
            >
              {t('loading')}
            </Text>
          </Stack>
        </Card>
      </Stack>
    </>
  );
};

const ErrorView = ({ refetch }: { refetch: () => void }) => {
  const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
  const { navigateToDashboard } = useNavigateToDashboard();
  return (
    <>
      <HeaderComponentLoading title={t('pageTitle')} />
      <ErrorDialog
        open
        center
        onPress={refetch}
        title={t('errorTitle')}
        copy={t('errorCopy')}
        buttonText={t('errorCta')}
        cancelButton
        onPressCancel={navigateToDashboard}
      />
    </>
  );
};

export const SuccessView = ({
  suitabilityDocumentData,
  fundId,
  digitalAdvice,
}: {
  suitabilityDocumentData?: {
    encryptedDocumentId: string;
    name: string;
  };
  fundId: string;
  digitalAdvice: DigitalAdvice;
}) => {
  useOnPageLoad({ pageTag: POST_PAYMENT_HUB_PAGE });
  const { navigatorState } = useNavigatorState();

  const { mandatoryDocuments } = navigatorState.postPayment;
  const docs = useSelector(mandatoryDocuments);
  const completedTaskCount = Object.values(docs).filter(
    (document) => document
  ).length;

  useAndroidBackToPortfolio();

  const digitalAdviceSummaryEnabled = useSelector(
    FeatureFlags.dwSimpleWealthDigitalAdviceEnabled
  );

  const count = digitalAdvice?.expiryDate
    ? differenceInCalendarDays(new Date(digitalAdvice.expiryDate), new Date())
    : 0;

  const navigatorServiceInformationDocument =
    digitalAdvice?.navigatorServiceInformation;

  const isAdviceExpired = count <= 0;

  return (
    <>
      <PageHeader
        digitalAdviceSummaryEnabled={digitalAdviceSummaryEnabled}
        count={count}
      />
      <Stack marginHorizontal="$xl" flex={1} justifyContent="space-between">
        <YStack tablet={isIpad} testID={getTestId('infoSection')}>
          <Information
            completedTaskCount={completedTaskCount}
            totalTasksCount={Object.values(docs).length}
          />
          <YStack gap={'$lg'} marginTop={'$xxl'}>
            {digitalAdviceSummaryEnabled && <AdviceSummaryCard />}
            <SustainabilityCard
              complete={docs.sustainabilityReportRead}
              state={mandatoryDocuments}
              suitabilityDocumentData={suitabilityDocumentData}
            />
            <StocksAndSharesInfoCard
              complete={docs.keyIsaInformationRead}
              state={mandatoryDocuments}
            />
            <ServiceInformationCard
              complete={docs.adviceDocumentsRead}
              state={mandatoryDocuments}
              serviceInformationDocument={
                navigatorServiceInformationDocument ?? ''
              }
            />
          </YStack>
        </YStack>

        <CTAs
          isEnabled={docs.sustainabilityReportRead}
          isAdviceValid={!isAdviceExpired}
          fundId={fundId}
        />
      </Stack>

      {isAdviceExpired && <AdviceExpiredModal />}
    </>
  );
};

const PageHeader = memo(
  ({
    digitalAdviceSummaryEnabled,
    count,
  }: {
    digitalAdviceSummaryEnabled: boolean;
    count: number;
  }) => {
    const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
    const { t: tCommon } = useTranslationDW({ keyPrefix: 'navigator.common' });
    const { t: tHub } = useTranslationDW({ keyPrefix: 'navigator.hub' });
    const { navigate } = useSimpleWealthStackNavigation();
    const { startAdviceSummaryFlow } = useAdviceSummaryNavigation();
    const { trackUserEvent } = useAnalytics();
    const { completedSteps, totalSteps } = useGetAdviceSummaryProgress();

    const getHeroActionDetails = (): {
      icon: HeroCardIconVariant;
      label: string;
    } => {
      if (completedSteps === 0) {
        return { icon: 'play', label: tHub('START') };
      } else if (completedSteps > 0 && completedSteps < totalSteps) {
        return {
          icon: 'play',
          label: tCommon('continue'),
        };
      } else {
        return {
          icon: 'replay',
          label: t('heroCardDigitalAdvice.replayLabel'),
        };
      }
    };

    const { icon, label } = getHeroActionDetails();

    const heroCard = useMemo(() => {
      if (digitalAdviceSummaryEnabled) {
        return {
          heroCardIcon: icon,
          heroCardImageRight: require('assets/dw-simple-wealth/simple-wealth-advice-summary/simple-wealth-advice-summary.png'),
          heroCardLabel: t('heroCardDigitalAdvice.label'),
          heroCardOnPress: startAdviceSummaryFlow,
          heroCardStartLabel: label,
          heroCardTitle: t('heroCardDigitalAdvice.title'),
        };
      } else {
        return {
          heroCardIcon: 'arrow-right' as HeroCardIconVariant,
          heroCardImageRight: require('assets/dw-simple-wealth/simple-wealth-money-coach/simple-wealth-money-coach.png'),
          heroCardLabel: t('heroCardBookACall.label'),
          heroCardOnPress: () => {
            trackUserEvent(POST_PAYMENT_HUB_MONEY_COACH_TAPPED);
            navigate('BookACall');
          },
          heroCardStartLabel: t('heroCardBookACall.startLabel'),
          heroCardTitle: t('heroCardBookACall.title'),
        };
      }
    }, [
      digitalAdviceSummaryEnabled,
      icon,
      label,
      navigate,
      startAdviceSummaryFlow,
      t,
      trackUserEvent,
    ]);

    return (
      <Stack marginBottom="$xxl">
        {count > 0 ? (
          <HeaderComponent
            infoBarIcon={'clock-colored'}
            infoBarLabel={t('timeframe')}
            infoLabelBold={t('timeframeBold', { count })}
            title={t('pageTitle')}
          >
            <HeroCard
              label={heroCard.heroCardLabel}
              title={heroCard.heroCardTitle}
              startLabel={heroCard.heroCardStartLabel}
              imageSource={heroCard.heroCardImageRight}
              backgroundColor={'$Quaternary500'}
              iconVariant={heroCard.heroCardIcon}
              onPress={heroCard.heroCardOnPress}
            />
          </HeaderComponent>
        ) : (
          <HeaderComponent
            infoBarIcon={'danger'}
            infoBarLabel={t('recommendationExpired')}
            title={t('pageTitle')}
          >
            <Stack width="100%">
              <Card backgroundColor={'$ErrorTint'}>
                <Card.Generic.Content
                  left={
                    <Icon name="alert-circle" color={tokens.color.Error.val} />
                  }
                >
                  <Text
                    fontVariant="body-semibold-Secondary800"
                    tamaguiTextProps={{ mb: '$sm' }}
                  >
                    {t('adviceExpiredTitle')}
                  </Text>
                  <Text fontVariant="small-regular-Gray800">
                    {t('adviceExpiredContent')}
                  </Text>
                </Card.Generic.Content>
              </Card>
            </Stack>
          </HeaderComponent>
        )}
      </Stack>
    );
  }
);

const Information = memo(
  ({
    completedTaskCount,
    totalTasksCount,
  }: {
    completedTaskCount: number;
    totalTasksCount: number;
  }) => {
    const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
    return (
      <YStack>
        <XStack
          marginBottom="$md"
          alignItems="center"
          justifyContent="space-between"
          accessible
        >
          <Text fontVariant="heading4-bold-WealthBlue">{t('title')}</Text>
          <AlertChipExtendable
            name={'tick'}
            text={
              <AlertChipText
                size={'sm'}
              >{`${completedTaskCount} of ${totalTasksCount}`}</AlertChipText>
            }
            variant="success"
            accessibilityLabel={`${completedTaskCount} of ${totalTasksCount} tasks completed`}
          />
        </XStack>
        <Text fontVariant="body-regular-Gray800">{t('description')}</Text>
      </YStack>
    );
  }
);

const AdviceSummaryCard = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'navigator.postPaymentHub.adviceSummaryCard',
  });
  const { startAdviceSummaryFlow } = useAdviceSummaryNavigation();

  const { completedSteps, totalSteps } = useGetAdviceSummaryProgress();
  return (
    <SelectionCard
      description={t('body')}
      icon={'circle-play'}
      onPress={startAdviceSummaryFlow}
      selected={completedSteps === totalSteps}
      title={t('title')}
      progress={{ completedSteps, totalSteps }}
    />
  );
};

const SustainabilityCard = memo(
  ({
    complete,
    state,
    suitabilityDocumentData,
  }: {
    complete: boolean;
    state: ObservableObject<MandatoryDocuments>;
    suitabilityDocumentData?: {
      encryptedDocumentId: string;
      name: string;
    };
  }) => {
    const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
    const { trackUserEvent } = useAnalytics();
    const { navigate } = useAppStackNavigation();

    const handleOnPress = () => {
      if (suitabilityDocumentData?.encryptedDocumentId) {
        navigate('Pdf View', {
          pdfSource: PdfSourceFactory.fromDocumentId(
            suitabilityDocumentData.encryptedDocumentId
          ),
          name: suitabilityDocumentData?.name ?? '',
        });
      }
      trackUserEvent(POST_PAYMENT_HUB_SUITABILITY_REPORT_TAPPED);

      if (!complete) {
        state.sustainabilityReportRead.set(true);
      }
    };
    return (
      <SelectionCard
        title={t('sustainabilityCard.title')}
        description={t('sustainabilityCard.description')}
        icon={'tickBox'}
        selected={complete}
        onPress={handleOnPress}
      />
    );
  }
);

const StocksAndSharesInfoCard = memo(
  ({
    complete,
    state,
  }: {
    complete: boolean;
    state: ObservableObject<MandatoryDocuments>;
  }) => {
    const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
    const { trackUserEvent } = useAnalytics();
    const { navigate } = useSimpleWealthStackNavigation();

    const handleOnPress = () => {
      trackUserEvent(POST_PAYMENT_HUB_ISA_INFO_TAPPED);
      navigate('KeyISAInformationScreen');
      if (!complete) {
        state.keyIsaInformationRead.set(true);
      }
    };
    return (
      <SelectionCard
        title={t('isaInfoCard.title')}
        description={t('isaInfoCard.description')}
        icon={'infoCircle'}
        onPress={handleOnPress}
        selected={complete}
      />
    );
  }
);

const ServiceInformationCard = memo(
  ({
    complete,
    state,
    serviceInformationDocument,
  }: {
    complete: boolean;
    state: ObservableObject<MandatoryDocuments>;
    serviceInformationDocument: string;
  }) => {
    const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
    const { trackUserEvent } = useAnalytics();
    const { navigate } = useAppStackNavigation();

    const handleOnPress = () => {
      trackUserEvent(POST_PAYMENT_HUB_ADVICE_DOCS_TAPPED);

      if (serviceInformationDocument) {
        navigate('Pdf View', {
          pdfSource: {
            url: serviceInformationDocument,
          },
          name: 'Service Information',
        });
      }

      if (!complete) {
        state.adviceDocumentsRead.set(true);
      }
    };
    return (
      <SelectionCard
        title={t('adviceCard.title')}
        description={t('adviceCard.description')}
        icon={'file'}
        onPress={handleOnPress}
        selected={complete}
      />
    );
  }
);

const CTAs = ({
  isEnabled,
  isAdviceValid,
  fundId,
}: {
  isEnabled: boolean;
  isAdviceValid: boolean;
  fundId: string;
}) => {
  const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
  const { navigate } = useSimpleWealthStackNavigation();
  const { navigate: appStackNavigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();

  const handleInvestNowPressed = () => {
    trackUserEvent(POST_PAYMENT_HUB_INVEST_NOW_TAPPED);

    if (FeatureFlags.dwIsaApplySimpleWealthNativeFlowEnabled.get()) {
      appStackNavigate('ISA Apply', { screen: 'ISA Apply Invest Now' });
    } else {
      navigate('Web View', {
        url:
          config.BASE_URL.get() +
          `/MyPortfolio/public/WrapSimpleApply?fundId=${fundId}`,
        ssoEnabled: true,
      });
    }
  };
  const handleBookACallPressed = () => {
    trackUserEvent(POST_PAYMENT_HUB_BOOK_CALL_TAPPED);
    navigate('BookACall');
  };

  const investNowIcon = (
    <Icon
      name={isEnabled ? 'pie-chart' : 'lock'}
      color={tokens.color.Gray800.val}
      style={{ marginRight: tokens.space.md.val }}
    />
  );

  return (
    <YStack
      marginVertical="$md"
      justifyContent="space-between"
      tabletNarrow={isIpad}
      testID={getTestId('buttonSection')}
    >
      {isAdviceValid && (
        <Button
          disabled={!isEnabled}
          icon={investNowIcon}
          marginTop="$xl"
          accessibilityRole="button"
          onPress={handleInvestNowPressed}
        >
          {t('investCTA')}
        </Button>
      )}
      <Button
        variant={isAdviceValid ? ButtonVariant.OUTLINED : ButtonVariant.BRAND}
        marginTop="$xl"
        onPress={handleBookACallPressed}
        accessibilityRole="button"
      >
        {t('callCTA')}
      </Button>
    </YStack>
  );
};

type SelectionCardProps = {
  description: string;
  icon: IconName;
  onPress: () => void;
  selected: boolean;
  title: string;
  progress?: { completedSteps: number; totalSteps: number };
};

const SelectionCard = memo(
  ({
    description,
    icon,
    onPress,
    selected,
    title,
    progress,
  }: SelectionCardProps) => {
    const progressAccessibilityLabel = progress
      ? `${progress.completedSteps} steps complete out of ${progress.totalSteps}`
      : '';

    const accessibilityStatus = selected
      ? 'Documents Completed.'
      : 'Documents Outstanding';

    const accessibilityLabel = `${title}, ${description}. ${progressAccessibilityLabel}. ${accessibilityStatus}`;

    return (
      <YStack
        backgroundColor="$White"
        borderRadius="$2"
        borderColor={
          selected ? tokens.color.Success.val : tokens.color.Gray200.val
        }
        borderWidth="$xxs"
        padding="$xl"
        onPress={onPress}
        accessible
        accessibilityLabel={accessibilityLabel}
        accessibilityRole="button"
        testID={getTestId('selection-card')}
      >
        <XStack marginBottom={'$sm'}>
          <Icon
            name={icon}
            color={
              selected ? tokens.color.Success.val : tokens.color.Teal600.val
            }
          />
          <Text
            tamaguiTextProps={{ marginLeft: '$md', marginRight: 'auto' }}
            fontVariant="body-semibold-Wealth600"
          >
            {title}
          </Text>
          <Icon
            name={selected ? 'tick' : 'right-circle-arrow'}
            color={
              selected ? tokens.color.Success.val : tokens.color.Tertiary800.val
            }
          />
        </XStack>
        <Text
          fontVariant="small-regular-WealthBlue"
          tamaguiTextProps={{ marginHorizontal: '$xxxl' }}
        >
          {description}
        </Text>
        {progress && <ProgressStepper progress={progress} />}
      </YStack>
    );
  }
);

const ProgressStepper = ({
  progress,
}: {
  progress: { completedSteps: number; totalSteps: number };
}) => {
  const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
  const { completedSteps, totalSteps } = progress;
  const steps = Array.from({ length: totalSteps }, (_, i) => {
    const currentStep = i + 1;
    let segmentColour = '$Information';
    if (currentStep <= completedSteps) {
      segmentColour = '$Success';
    }
    return (
      <Stack
        key={i}
        height={8}
        flex={1}
        backgroundColor={segmentColour}
        opacity={currentStep <= completedSteps ? 1 : 0.4}
        borderRadius={16}
      />
    );
  });

  const getStepperLabel = () => {
    return completedSteps < totalSteps
      ? t('adviceSummaryCard.yourInvestmentGoals')
      : t('adviceSummaryCard.tapToReplay');
  };

  return (
    <YStack marginLeft={'$xxxl'} marginTop={16}>
      <Stack flex={1} marginBottom={4}>
        <XStack justifyContent="space-between" space="$space.sm">
          {steps}
        </XStack>
      </Stack>
      <Text fontVariant="overline-regular-WealthBlue">{`${completedSteps} of ${totalSteps} - ${getStepperLabel()}`}</Text>
    </YStack>
  );
};

const AdviceExpiredModal = () => {
  const { trackStateEvent, trackUserEvent } = useAnalytics();
  const { t } = useTranslationDW({ keyPrefix: 'navigator.postPaymentHub' });
  const [isOpen, setIsOpen] = useState(true);

  useEffect(() => {
    trackStateEvent(POST_PAYMENT_HUB_EXPIRED_MODAL);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onConfirm = () => {
    trackUserEvent(POST_PAYMENT_HUB_EXPIRED_MODAL_GOT_IT_TAPPED);
    setIsOpen(false);
  };
  return (
    <Dialog
      open={isOpen}
      center
      icon={<Icon name={'document-expired'} width={80} height={80} />}
      title={t('adviceExpiredTitle')}
      copy={t('adviceExpiredContent')}
    >
      <Stack space="$md" marginTop="$xl">
        <Button onPress={onConfirm}>{t('confirmButton')}</Button>
      </Stack>
    </Dialog>
  );
};
