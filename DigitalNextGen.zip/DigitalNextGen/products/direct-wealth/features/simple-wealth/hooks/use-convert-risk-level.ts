export const useConvertRiskLevel = (riskNumber: number) => {
  switch (riskNumber) {
    case 1: {
      return 'CAUTIOUS';
    }
    case 2: {
      return 'CAUTIOUS_TO_MODERATE';
    }
    case 3: {
      return 'MODERATE';
    }
    case 4: {
      return 'MODERATE_TO_ADVENTUROUS';
    }
    case 5: {
      return 'ADVENTUROUS';
    }
    default: {
      return 'CAUTIOUS';
    }
  }
};
