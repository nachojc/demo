import { RiskProfileCardStatus } from '@direct-wealth/components/risk-profile-card/types';
import { useCallback, useEffect, useState } from 'react';

import { useSimpleWealthAccountService } from '../simple-wealth-hub/use-simple-wealth-account-service';

type UserRiskLevel = {
  riskLevel: number | undefined;
  formattedRiskLevel: RiskProfileCardStatus;
  isRiskLevelRefetchError: boolean;
  fetchInvestmentRiskLevel: () => void;
};

export const useGetUserRiskLevel = (): UserRiskLevel => {
  const [isRiskLevelRefetchError, setIsRiskLevelRefetchError] = useState(false);
  const [formattedRiskLevel, setFormattedRiskLevel] =
    useState<RiskProfileCardStatus>('CAUTIOUS');
  const [riskLevel, setRiskLevel] = useState<number>();
  const { refetch } = useSimpleWealthAccountService();

  const fetchInvestmentRiskLevel = useCallback(async () => {
    try {
      const { data: refetchData, isError: refetchIsError } = await refetch();

      if (refetchIsError) {
        setIsRiskLevelRefetchError(true);
        return;
      }
      if (refetchData) {
        const { projection } = refetchData;

        setIsRiskLevelRefetchError(false);
        setRiskLevel(projection?.advisedInvestmentProfile.riskLevel);
        const formatted = formatRiskLevel(
          projection?.advisedInvestmentProfile.riskLevel ?? 1
        );
        setFormattedRiskLevel(formatted);
      }
    } catch (error) {
      setIsRiskLevelRefetchError(true);
    }
  }, [refetch]);

  useEffect(() => {
    fetchInvestmentRiskLevel();
  }, [fetchInvestmentRiskLevel]);

  const formatRiskLevel = (level: number) => {
    switch (level) {
      case 1: {
        return 'CAUTIOUS';
      }
      case 2: {
        return 'CAUTIOUS_TO_MODERATE';
      }
      case 3: {
        return 'MODERATE';
      }
      case 4: {
        return 'MODERATE_TO_ADVENTUROUS';
      }
      case 5: {
        return 'ADVENTUROUS';
      }
      default: {
        return 'CAUTIOUS';
      }
    }
  };

  return {
    riskLevel,
    formattedRiskLevel,
    isRiskLevelRefetchError,
    fetchInvestmentRiskLevel,
  };
};
