import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';

export const useFinancialGoals = () => {
  const { t } = useTranslationDW({ keyPrefix: 'navigator' });

  const goalResponses: { [key: string]: string } = {
    [t('financialGoal.goal1SomethingSpecial')]: 'FF004R007',
    [t('financialGoal.goal2Emergency')]: 'FF004R002',
    [t('financialGoal.goal3Income')]: 'FF004R003',
    [t('financialGoal.goal4ChildrensFuture')]: 'FF004R004',
    [t('financialGoal.goal5Home')]: 'FF004R005',
    [t('financialGoal.goal6Travel')]: 'FF004R006',
    [t('financialGoal.goal7Savings')]: 'FF004R001',
    [t('financialGoal.goal8Retirement')]: 'FF004R008',
    [t('financialGoal.goal9BuyAHouse')]: 'FF004R009',
    [t('financialGoal.goal10Wedding')]: 'FF004R010',
  };

  const goalNames = Object.keys(goalResponses);

  const getGoalDescrById = (customerName: string, responseId?: string) => {
    switch (responseId) {
      case 'FF004R001': {
        return `${t('financialGoal.descriptionSavings', { customerName })}`;
      }
      case 'FF004R004': {
        return `${t('financialGoal.descriptionChildrens', { customerName })}`;
      }
      case 'FF004R005': {
        return `${t('financialGoal.descriptionHome', { customerName })}`;
      }
      case 'FF004R006': {
        return `${t('financialGoal.descriptionTravelling', { customerName })}`;
      }
      case 'FF004R007': {
        return `${t('financialGoal.descriptionTreat', { customerName })}`;
      }
      case 'FF004R009': {
        return `${t('financialGoal.descriptionBuyHouse', { customerName })}`;
      }
      case 'FF004R010': {
        return `${t('financialGoal.descriptionWedding', { customerName })}`;
      }
      default:
        return `${t('financialGoal.descriptionTreat', { customerName })}`;
    }
  };

  const getGoalById = (responseId?: string) => {
    const goal = Object.entries(goalResponses).find(
      ([_, value]) => value === responseId
    )?.[0];
    // Returns the something special as a fallback as this is generic
    return goal ?? goalResponses[0];
  };

  const getGoalWithAnimationById = (
    goalId?: string
  ): { goal: string; animation: string } => {
    const goalName = getGoalById(goalId);
    const goalsObject: { goal: string; animation: string }[] = [
      {
        goal: goalNames[0],
        animation: require('@assets/simple-wealth/goals-treat.json'),
      },
      {
        goal: goalNames[1],
        animation: require('@assets/simple-wealth/goals-travel.json'),
      },
      {
        goal: goalNames[2],
        animation: require('@assets/simple-wealth/goals-travel.json'),
      },
      {
        goal: goalNames[3],
        animation: require('@assets/simple-wealth/goals-travel.json'),
      },
      {
        goal: goalNames[4],
        animation: require('@assets/simple-wealth/goals-home.json'),
      },
      {
        goal: goalNames[5],
        animation: require('@assets/simple-wealth/goals-travel.json'),
      },
      {
        goal: goalNames[6],
        animation: require('@assets/simple-wealth/goals-travel.json'),
      },
      {
        goal: goalNames[7],
        animation: require('@assets/simple-wealth/goals-travel.json'),
      },
      {
        goal: goalNames[8],
        animation: require('@assets/simple-wealth/goals-buy-house.json'),
      },
      {
        goal: goalNames[9],
        animation: require('@assets/simple-wealth/goals-wedding.json'),
      },
    ];

    // Returns the goals-travel JSON as a fallback as this is generic
    return goalsObject.find((g) => g.goal === goalName) ?? goalsObject[6];
  };

  return {
    goalResponses,
    goalNames,
    getGoalById,
    getGoalWithAnimationById,
    getGoalDescrById,
  };
};
