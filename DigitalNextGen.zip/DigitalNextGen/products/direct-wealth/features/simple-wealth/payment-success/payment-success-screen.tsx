import { Button, getVariableValue, Text, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import Lottie from 'lottie-react-native';
import { SafeAreaView, ScrollView } from 'react-native';

import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import { useNavigatorState } from '../navigation/provider';
import { PAYMENT_SUCCESS_BACK, PAYMENT_SUCCESS_SCREEN } from './analytics';

export const PaymentSuccessScreen = () => {
  const { navigate } = useSimpleWealthStackNavigation();
  const { trackUserEvent, trackStateEvent } = useAnalytics();
  const { t } = useTranslationDW({ keyPrefix: 'navigator' });
  const { navigatorState } = useNavigatorState();

  trackStateEvent(PAYMENT_SUCCESS_SCREEN);

  const onContinuePress = () => {
    trackUserEvent(PAYMENT_SUCCESS_BACK);
    if (navigatorState.wasPaymentRecorded.get()) {
      navigate('PostPaymentHub');
    } else {
      navigate('SimpleWealthHub');
    }
  };

  return (
    <SafeAreaView
      style={{
        height: '100%',
      }}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ flexGrow: 1 }}
        style={{ paddingHorizontal: getVariableValue(tokens.space.xxl) }}
      >
        <YStack
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
          }}
          tabletNarrow={isIpad}
        >
          <Lottie
            style={{
              width: '100%',
              height: tokens.size[12].val,
            }}
            source={require('@assets/piggy-bank-grey/piggy-bank-grey.json')}
            autoPlay
            loop
            testID={getTestId('animation')}
          />
          <Text
            tamaguiTextProps={{
              my: '$xl',
              accessibilityRole: 'header',
            }}
            fontVariant="heading4-semibold-Secondary800"
          >
            {t('paymentSuccess.title')}
          </Text>
          <Text
            tamaguiTextProps={{
              mb: '$xxl',
              accessibilityRole: 'text',
              textAlign: 'center',
            }}
            fontVariant="heading5-regular-Gray800"
          >
            {t('paymentSuccess.subtitle')}
          </Text>
        </YStack>
        <YStack
          tabletNarrow={isIpad}
          testID={getTestId('continue-button-container')}
        >
          <Button
            accessibilityHint={t('paymentSuccess.confirm')}
            mb="$lg"
            mt="$xxl"
            onPress={onContinuePress}
          >
            {t('paymentSuccess.confirm')}
          </Button>
        </YStack>
      </ScrollView>
    </SafeAreaView>
  );
};
