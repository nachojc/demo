import { PAGE_WEALTH } from '@constants/analytics';

import { PAYMENT, SIMPLE_WEALTH } from '../navigation/header/analytics';

export const PAYMENT_SUCCESS_SCREEN = `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${PAYMENT}|success-screen`;
export const PAYMENT_SUCCESS_CLOSE = `${PAYMENT_SUCCESS_SCREEN}|close-tapped`;
export const PAYMENT_SUCCESS_BACK = `${PAYMENT_SUCCESS_SCREEN}|back-to-nav-tapped`;
