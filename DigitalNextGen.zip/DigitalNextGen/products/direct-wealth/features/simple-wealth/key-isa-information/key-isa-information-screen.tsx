import { PDFCard, ScrollView, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { useSimpleWealthAccountService } from '../simple-wealth-hub/use-simple-wealth-account-service';
import {
  KEY_ISA_DOCUMENTS_PAGE,
  KEY_ISA_INFORMATION_FUND_FACTSHEET_TAPPED,
  KEY_ISA_INFORMATION_KEY_FEATURES_TAPPED,
  KEY_ISA_INFORMATION_KEY_INVESTOR_INFO_TAPPED,
  KEY_ISA_INFORMATION_TERMS_AND_CONDITIONS_TAPPED,
} from './analytics';

export const KeyISAInformationScreen = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'navigator.keyISADocuments',
  });
  const safeAreaInsets = useSafeAreaInsets();
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const { avivaSimpleWealth: { digitalAdvice } = {} } =
    useSimpleWealthAccountService();

  useOnPageLoad({ pageTag: KEY_ISA_DOCUMENTS_PAGE });

  const navigateToPdfUrl = (name: string, link: string, tag: string) => {
    trackUserEvent(tag);
    navigate('Pdf View', {
      pdfSource: {
        url: link,
      },
      name,
    });
  };

  return (
    <ScrollView
      showsVerticalScrollIndicator={false}
      contentContainerStyle={{
        flexGrow: 1,
        paddingBottom: safeAreaInsets.bottom + tokens.space.xl.val,
        backgroundColor: tokens.color.Gray050.val,
      }}
    >
      <YStack tablet={isIpad} testID={getTestId('pdfSection')}>
        {digitalAdvice?.keyFeaturesIsaAndSnS && (
          <PDFCard
            title={t('keyFeatures')}
            onPress={() => {
              navigateToPdfUrl(
                t('keyFeatures'),
                digitalAdvice?.keyFeaturesIsaAndSnS ?? '',
                KEY_ISA_INFORMATION_KEY_FEATURES_TAPPED
              );
            }}
          />
        )}
        {digitalAdvice?.kiid && (
          <PDFCard
            title={t('keyInvestorInformation')}
            onPress={() => {
              navigateToPdfUrl(
                t('keyInvestorInformation'),
                digitalAdvice?.kiid ?? '',
                KEY_ISA_INFORMATION_KEY_INVESTOR_INFO_TAPPED
              );
            }}
          />
        )}
        {digitalAdvice?.fundFactsheet && (
          <PDFCard
            title={t('fundFactSheet')}
            onPress={() => {
              navigateToPdfUrl(
                t('fundFactSheet'),
                digitalAdvice?.fundFactsheet ?? '',
                KEY_ISA_INFORMATION_FUND_FACTSHEET_TAPPED
              );
            }}
          />
        )}
        {digitalAdvice?.isaTsAndCs && (
          <PDFCard
            title={t('termsAndConditions')}
            onPress={() => {
              navigateToPdfUrl(
                t('termsAndConditions'),
                digitalAdvice?.isaTsAndCs ?? '',
                KEY_ISA_INFORMATION_TERMS_AND_CONDITIONS_TAPPED
              );
            }}
          />
        )}
      </YStack>
    </ScrollView>
  );
};
