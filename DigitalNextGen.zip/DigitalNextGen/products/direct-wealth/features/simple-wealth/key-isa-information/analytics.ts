import { PAGE_WEALTH } from '@constants/analytics';

import {
  KEY_ISA_DOCUMENTS,
  SIMPLE_WEALTH,
} from '../navigation/header/analytics';

export const KEY_ISA_DOCUMENTS_PAGE = `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${KEY_ISA_DOCUMENTS}`;

export const KEY_ISA_INFORMATION_KEY_FEATURES_TAPPED = `${KEY_ISA_DOCUMENTS_PAGE}|key-features-tapped`;
export const KEY_ISA_INFORMATION_KEY_INVESTOR_INFO_TAPPED = `${KEY_ISA_DOCUMENTS_PAGE}|key-investor-info-tapped`;
export const KEY_ISA_INFORMATION_FUND_FACTSHEET_TAPPED = `${KEY_ISA_DOCUMENTS_PAGE}|fund-factsheet-tapped`;
export const KEY_ISA_INFORMATION_TERMS_AND_CONDITIONS_TAPPED = `${KEY_ISA_DOCUMENTS_PAGE}|terms-and-conditions-tapped`;
