export const mockSimpleWealthStackNavigation = jest.fn();

jest.mock('./navigation/hooks', () => ({
  useSimpleWealthStackNavigation: () => ({
    navigate: mockSimpleWealthStackNavigation,
  }),
}));
