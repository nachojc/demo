export type YourFinancialSituationSummaryItem = {
  question: string;
  answer: string;
};

export type YourFinancialSituationSummarySection = {
  title: string;
  items: YourFinancialSituationSummaryItem[];
};

export type YourFinancialSituationStatus =
  | 'YOURE_ALL_SET'
  | 'REVIEW_YOUR_ANSWERS'
  | 'PERSONAL_CONSIDERATION'
  | 'AFFORDABILITY'
  | 'INVESTMENT_GOALS'
  | 'ELIGIBILITY'
  | 'LOADING';
