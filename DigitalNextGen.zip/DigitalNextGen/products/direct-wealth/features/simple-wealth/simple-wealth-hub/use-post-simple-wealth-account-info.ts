import { CreateSimpleWealthAccountModel } from '@direct-wealth/models/create-simple-wealth-account';
import { useCallback, useState } from 'react';

export const usePostSimpleWealthAccountInfo = () => {
  const [isError, setIsError] = useState(false);

  const submitPostNavAccountInfo = useCallback(async () => {
    let accountCreated = false;
    try {
      await new CreateSimpleWealthAccountModel().createAccount();
      accountCreated = true;
    } catch {
      setIsError(true);
    }

    return accountCreated;
  }, []);

  return {
    isError,
    submitPostNavAccountInfo,
  };
};
