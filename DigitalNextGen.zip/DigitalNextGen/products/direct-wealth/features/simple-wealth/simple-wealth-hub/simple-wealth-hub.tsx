import {
  Button,
  Card,
  Icon,
  LoadingState,
  ScrollView,
  Stack,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { AlertChipExtendable } from '@aviva/ion-mobile/components/chip/alert-chips';
import { AlertChipText } from '@aviva/ion-mobile/components/chip/chip.styles';
import { YourFinancialSituationCard } from '@direct-wealth/components/your-financial-situation-card/your-financial-situation-card';
import { YourFinancialSituationSchema } from '@direct-wealth/components/your-financial-situation-card/your-financial-situation-schema';
import { YourInvestmentForecastCard } from '@direct-wealth/components/your-investment-forecast-card/your-investment-forecast-card';
import { YourInvestmentForecastSchema } from '@direct-wealth/components/your-investment-forecast-card/your-investment-forecast-schema';
import { YourInvestmentStyleCard } from '@direct-wealth/components/your-investment-style-card/your-investment-style-card';
import { YourInvestmentStyleSchema } from '@direct-wealth/components/your-investment-style-card/your-investment-style-schema';
import { useAnalytics } from '@hooks/use-analytics';
import { ErrorDialog } from '@src/components/error-dialog';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect, useState } from 'react';
import { AccessibilityRole, Pressable, SafeAreaView } from 'react-native';

import { HeroCard } from '../components/hero-card/hero-card';
import { HeaderComponent } from '../components/simple-wealth-hub-header-cluster/header-cluster';
import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import { useNavigatorState } from '../navigation/provider';
import {
  HUB_PAGE,
  PENDING_ADVICE_HUB_PAGE,
  SIMPLE_WEALTH_PAY_NOW,
} from './analytics';
import { useSimpleWealthHubState } from './use-simple-wealth-hub-state';

export const SimpleWealthHub = () => {
  const { navigatorState } = useNavigatorState();

  const {
    chipNumber,
    heroButtonText,
    heroIcon,
    heroLabel,
    heroTitle,
    infoBarIcon,
    infoBarLabel,
    onPressYourFinancialSituation,
    yourFinancialSituationStatus,
    onYourInvestmentStylePress,
    yourInvestmentStyleCardStatus,
    onPressInfoBar,
    onPressHeroCard,
    onPressYourInvestmentForecast,
    yourInvestmentForecastStatus,
    shouldShowPreparingAdvice,
    avivaSimpleWealth,
    isFetching,
    isError,
    refetchError,
    refetch,
    userDataSynced,
  } = useSimpleWealthHubState();

  const { trackUserEvent, trackStateEvent } = useAnalytics();

  const { t } = useTranslationDW({ keyPrefix: 'navigator' });

  const { navigate } = useSimpleWealthStackNavigation();

  const [refreshActive, setRefreshActive] = useState(false);

  useEffect(() => {
    if (refreshActive && !isError) {
      setRefreshActive(false);
      navigate('UsefulInfo');
    }
  }, [setRefreshActive, isError, refreshActive, navigate]);

  const refetchGetAPI = () => {
    setRefreshActive(true);
    refetch();
  };

  useEffect(() => {
    if (avivaSimpleWealth?.projection?.stage === 'Final') {
      navigatorState.projectionComplete.set(true);
    }
  }, [avivaSimpleWealth?.projection?.stage, navigatorState.projectionComplete]);

  useEffect(() => {
    if (shouldShowPreparingAdvice) {
      trackStateEvent(PENDING_ADVICE_HUB_PAGE);
    } else {
      trackStateEvent(HUB_PAGE);
    }
  }, [shouldShowPreparingAdvice, trackStateEvent]);

  const payNowIcon = (
    <Stack marginHorizontal="$sm">
      <Icon
        key="payNowIcon"
        name={
          yourInvestmentForecastStatus === 'COMPLETE' ? 'credit-card' : 'lock'
        }
        color={tokens.color.Gray800.val}
      />
    </Stack>
  );

  if (isError || refetchError) {
    return <ErrorDialog open onPress={() => refetch()} center />;
  }

  if (isFetching) {
    return <LoadingState text={'nextStep'} />;
  }
  const space = isIpad ? undefined : tokens.space.xl.val;

  const yourFinancialSituationData =
    YourFinancialSituationSchema[yourFinancialSituationStatus];
  const yourInvestmentStyleData =
    YourInvestmentStyleSchema[yourInvestmentStyleCardStatus];
  const investmentForecastData =
    YourInvestmentForecastSchema[yourInvestmentForecastStatus];

  return (
    <SafeAreaView style={{ height: '100%' }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <HeaderComponent
          title={t('header.SIMPLE_WEALTH')}
          infoBarLabel={infoBarLabel}
          infoBarIcon={infoBarIcon}
          infoBarOnPress={onPressInfoBar}
        >
          <HeroCard
            label={heroLabel()}
            title={heroTitle()}
            startLabel={heroButtonText()}
            imageSource={require('assets/dw-simple-wealth/simple-wealth-financial-situation/simple-wealth-financial-situation.png')}
            iconVariant={heroIcon}
            onPress={onPressHeroCard}
          />
        </HeaderComponent>
        {userDataSynced ? (
          <YStack flex={1}>
            <YStack
              pr="$xl"
              marginVertical="$xl"
              tablet={isIpad}
              testID={getTestId('navigatorHeaderSection')}
            >
              <YStack accessible>
                {shouldShowPreparingAdvice ? (
                  <YStack pl={space} mb="$xxl" mt="$lg">
                    <Text
                      fontVariant="heading4-bold-WealthBlue"
                      tamaguiTextProps={{
                        marginBottom: tokens.space.md.val,
                      }}
                    >
                      {t('hub.recommendationHeader')}
                    </Text>
                    <Text
                      tamaguiTextProps={{
                        marginBottom: tokens.space.xxl.val,
                      }}
                      fontVariant="body-regular-WealthBlue"
                    >
                      {t('hub.decisionRecommendation')}
                    </Text>
                    <Card mode="outlined">
                      <Card.Generic.Content
                        left={
                          <Icon
                            name="infoCircle"
                            color={tokens.color.Teal600.val}
                          />
                        }
                      >
                        <Text fontVariant="body-semibold-WealthBlue">
                          {t('hub.preparingAdviceHeader')}
                        </Text>
                        <Text fontVariant="small-regular-WealthBlue">
                          {t('hub.preparingAdviceCopy')}
                        </Text>
                      </Card.Generic.Content>
                    </Card>
                  </YStack>
                ) : null}
                <XStack marginBottom="$sm" alignItems="center">
                  <Text
                    tamaguiTextProps={{
                      marginLeft: space,
                      marginRight: 'auto',
                    }}
                    fontVariant="heading5-semibold-Wealth600"
                  >
                    {t('hub.TITLE')}
                  </Text>
                  <AlertChipExtendable
                    name={'tick'}
                    text={
                      <AlertChipText
                        size={'sm'}
                      >{`${chipNumber} of 3`}</AlertChipText>
                    }
                    variant="success"
                    accessible={false}
                  />
                </XStack>
              </YStack>
              <Text
                fontVariant="body-regular-Gray800"
                tamaguiTextProps={{ ml: space, mr: '$xxxl' }}
              >
                {t('hub.SUBTITLE')}
              </Text>
            </YStack>
            <YStack
              flex={1}
              justifyContent="space-between"
              mx="$xl"
              tablet={isIpad}
              testID={getTestId('navigatorInfoSection')}
            >
              <YStack>
                <Pressable
                  key="factFinderCard"
                  accessibilityRole={
                    yourFinancialSituationData.accessibilityRole as AccessibilityRole
                  }
                  disabled={yourFinancialSituationStatus === 'YOURE_ALL_SET'}
                  testID={getTestId('pressable-fact-find-card')}
                  onPress={() => onPressYourFinancialSituation()}
                >
                  <YourFinancialSituationCard
                    status={yourFinancialSituationStatus}
                  />
                </Pressable>
                <Pressable
                  key="atrCard"
                  onPress={() => onYourInvestmentStylePress()}
                  accessibilityRole={
                    yourInvestmentStyleData.accessibilityRole as AccessibilityRole
                  }
                  disabled={yourInvestmentStyleCardStatus === 'COMPLETE'}
                  testID={getTestId('pressable-atr-card')}
                >
                  <YourInvestmentStyleCard
                    status={yourInvestmentStyleCardStatus}
                    showProgress={false}
                  />
                </Pressable>
                <Pressable
                  key="projectionCard"
                  onPress={() => onPressYourInvestmentForecast()}
                  accessibilityRole={
                    investmentForecastData.accessibilityRole as AccessibilityRole
                  }
                  disabled={yourInvestmentForecastStatus === 'COMPLETE'}
                  testID={getTestId('pressable-projections-card')}
                >
                  <YourInvestmentForecastCard
                    status={yourInvestmentForecastStatus}
                    showProgress={false}
                  />
                </Pressable>
              </YStack>

              {!shouldShowPreparingAdvice ? (
                <YStack
                  tabletNarrow={isIpad}
                  {...(isIpad && { pb: '$xxxxl' })}
                  testID={getTestId('navigatorButtonSection')}
                >
                  <Button
                    key="payNowButton"
                    icon={payNowIcon}
                    disabled={
                      yourInvestmentForecastStatus === 'COMPLETE' ? false : true
                    }
                    mb="$lg"
                    mt="$xxl"
                    onPress={() => {
                      trackUserEvent(SIMPLE_WEALTH_PAY_NOW);
                      refetchGetAPI();
                    }}
                    gap="$md"
                    accessibilityRole="button"
                    accessibilityLabel={t('hub.PAY_NOW')}
                  >
                    {t('hub.PAY_NOW')}
                  </Button>
                </YStack>
              ) : null}
            </YStack>
          </YStack>
        ) : null}
      </ScrollView>
    </SafeAreaView>
  );
};
