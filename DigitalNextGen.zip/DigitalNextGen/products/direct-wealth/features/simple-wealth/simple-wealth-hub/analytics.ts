import { PAGE_WEALTH } from '@constants/analytics';

import { SIMPLE_WEALTH } from '../navigation/header/analytics';

export const HUB_PAGE = `${PAGE_WEALTH}|${SIMPLE_WEALTH}|hub-page`;
export const NEW_TO_SIMPLE_WEALTH = `${HUB_PAGE}|new-to-navigator-tapped`;
export const START_YOUR_FINANCIAL_SITUATION = `${HUB_PAGE}|start-fact-finder-tapped`;
export const YOUR_FINANCIAL_SITUATION_INTRO = `${HUB_PAGE}|fact-finder-intro-tapped`;
export const YOUR_FINANCIAL_SITUATION_GOALS = `${HUB_PAGE}|fact-finder-goals-tapped`;
export const YOUR_FINANCIAL_SITUATION_AFFORDABILITY = `${HUB_PAGE}|fact-finder-affordability-tapped`;
export const YOUR_FINANCIAL_SITUATION_PERSONAL = `${HUB_PAGE}|fact-finder-personal-tapped`;
export const YOUR_FINANCIAL_SITUATION_REVIEW = `${HUB_PAGE}|fact-finder-review-tapped`;
export const SIMPLE_WEALTH_PAY_NOW = `${HUB_PAGE}|pay-now-tapped`;
export const YOUR_INVESTMENT_FORECAST_TAPPED = `${HUB_PAGE}|your-projections-tapped`;
export const PENDING_ADVICE_HUB_PAGE = `${PAGE_WEALTH}|${SIMPLE_WEALTH}|pending-advice-hub-page`;
