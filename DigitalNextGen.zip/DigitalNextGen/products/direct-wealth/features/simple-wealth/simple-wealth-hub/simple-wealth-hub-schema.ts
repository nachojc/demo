import { tokens } from '@src/theme/tokens';

export const YourFinancialSituationSchema = {
  INACTIVE: {
    title: 'Attitude to risk',
    titleAccessibilityLabel: 'Attitude to risk',
    bodyText:
      'It is a long established fact that a reader will be distracted by the readable content',
    showProgress: false,
    progressSegments: 7,
    progress: 0,
    progressTitle: 'Introduction',
    iconLeft: 'alert-triangle-outline',
    iconRight: 'right-circle-arrow',
    iconRightColor: tokens.color.Tertiary800.val,
  },
  ACTIVE: {
    title: 'Attitude to risk',
    titleAccessibilityLabel: 'Attitude to risk',
    bodyText:
      'It is a long established fact that a reader will be distracted by the readable content',
    showProgress: false,
    progressSegments: 7,
    progress: 0,
    progressTitle: 'Introduction',
    iconLeft: 'alert-triangle-outline',
    iconRight: 'right-circle-arrow',
    iconRightColor: tokens.color.Tertiary800.val,
  },
  PART_COMPLETE: {
    title: 'Attitude to risk',
    titleAccessibilityLabel: 'Attitude to risk',
    bodyText:
      'It is a long established fact that a reader will be distracted by the readable content',
    showProgress: true,
    progressSegments: 7,
    progress: 1,
    progressTitle: 'Introduction',
    iconLeft: 'alert-triangle-outline',
    iconRight: 'right-circle-arrow',
    iconRightColor: tokens.color.Tertiary800.val,
  },
  COMPLETE: {
    title: 'Attitude to risk',
    titleAccessibilityLabel: 'Attitude to risk',
    bodyText:
      'It is a long established fact that a reader will be distracted by the readable content',
    showProgress: true,
    progressSegments: 7,
    progress: 7,
    progressTitle: 'Introduction',
    iconLeft: 'alert-triangle-outline',
    iconRight: 'tick',
    iconRightColor: '',
  },
  PREPARING: {
    title: "We're preparing your advice",
    titleAccessibilityLabel: "We're preparing your advice",
    bodyText:
      "While your ISA application and payment are being processed we're working on your personal investment recommendation",
    showProgress: false,
    progressSegments: 7,
    progress: 7,
    progressTitle: 'Introduction',
    iconLeft: 'alert-circle-outline',
    iconRight: 'right-circle-arrow',
    iconRightColor: tokens.color.Tertiary800.val,
  },
  LOCKED: {
    title: 'Attitude to risk',
    titleAccessibilityLabel: "We're preparing your advice",
    bodyText:
      'It is a long established fact that a reader will be distracted by the readable content',
    showProgress: false,
    progressSegments: 7,
    progress: 7,
    progressTitle: 'Introduction',
    iconLeft: 'alert-circle-outline',
    iconRight: 'lock',
    iconRightColor: '',
  },
};
