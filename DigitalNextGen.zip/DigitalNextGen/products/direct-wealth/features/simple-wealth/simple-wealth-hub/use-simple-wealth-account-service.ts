import { useAvivaSimpleWealth } from '@direct-wealth/common/hooks/use-aviva-simple-wealth';
import { useSelector } from '@legendapp/state/react';
import { FeatureFlags } from '@src/feature-flags';

import { useNavigatorState } from '../navigation/provider';
import {
  QuestionIds,
  YourFinancialSituation,
} from '../navigation/provider/state/fact-find';

export const useSimpleWealthAccountService = () => {
  const { syncYourFinancialSituationQuestionnaire, navigatorState } =
    useNavigatorState();
  const isNavigatorEnabledFeatureFlag = useSelector(
    FeatureFlags.dwSimpleWealthEnabled
  );
  const [avivaSimpleWealth, { isFetching, isError, refetch }] =
    useAvivaSimpleWealth(isNavigatorEnabledFeatureFlag);
  let userDataSynced = false;

  if (avivaSimpleWealth?.questionnaireResponses?.responses ?? false) {
    const { responses } = avivaSimpleWealth?.questionnaireResponses ?? {};

    const userYourFinancialSituationResponses: Partial<YourFinancialSituation> =
      Object.keys(QuestionIds).reduce(
        (acc, key) => {
          const response = responses?.find(
            (r) => r.questionId === QuestionIds[key as keyof typeof QuestionIds]
          );
          if (response) {
            acc[key as keyof typeof QuestionIds] = {
              questionId: response.questionId ?? '',
              responseValue: response.responseValue ?? undefined,
              responseIds: response.responseIds ?? undefined,
            };
          } else {
            acc[key as keyof typeof QuestionIds] = undefined;
          }
          return acc;
        },
        {
          reviewComplete: true,
          lastInteracted: null,
        } as Partial<YourFinancialSituation>
      );
    syncYourFinancialSituationQuestionnaire(
      userYourFinancialSituationResponses as YourFinancialSituation
    );
  }
  navigatorState.atrComplete.set(!!avivaSimpleWealth?.projection);
  userDataSynced = true;
  return { isFetching, isError, avivaSimpleWealth, refetch, userDataSynced };
};
