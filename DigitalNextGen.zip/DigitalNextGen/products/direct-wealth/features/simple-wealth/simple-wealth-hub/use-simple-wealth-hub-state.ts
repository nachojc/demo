import { IconName } from '@aviva/ion-mobile';
import { YourInvestmentForecastStatus } from '@direct-wealth/components/your-investment-forecast-card/types';
import { YourInvestmentStyleStatus } from '@direct-wealth/components/your-investment-style-card/types';
import { useAnalytics } from '@hooks/use-analytics';
import { resetNavigator } from '@interfaces/storage';
import { computed } from '@legendapp/state';
import { useSelector } from '@legendapp/state/react';
import { useFocusEffect } from '@react-navigation/native';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import differenceInCalendarDays from 'date-fns/differenceInCalendarDays';
import { useCallback, useEffect, useState } from 'react';

import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import { useNavigatorState } from '../navigation/provider';
import {
  START_YOUR_FINANCIAL_SITUATION,
  YOUR_FINANCIAL_SITUATION_AFFORDABILITY,
  YOUR_FINANCIAL_SITUATION_GOALS,
  YOUR_FINANCIAL_SITUATION_INTRO,
  YOUR_FINANCIAL_SITUATION_PERSONAL,
  YOUR_FINANCIAL_SITUATION_REVIEW,
  YOUR_INVESTMENT_FORECAST_TAPPED,
} from './analytics';
import { YourFinancialSituationStatus } from './types';
import { useSimpleWealthAccountService } from './use-simple-wealth-account-service';
import { useInactivityCheck } from './useInactivityCheck';

// Constants for statuses
const STATUS_YOURE_ALL_SET = 'YOURE_ALL_SET';
const FF_STAGE_ELIGIBILITY = 'ELIGIBILITY';
const FF_STAGE_REVIEW = 'REVIEW_YOUR_ANSWERS';
const FF_STAGE_PERSONAL_CONSIDERATION = 'PERSONAL_CONSIDERATION';
const FF_STAGE_AFFORDABILITY = 'AFFORDABILITY';
const FF_STAGE_INVESTMENT_GOALS = 'INVESTMENT_GOALS';

const STAGE_ACTIVE = 'ACTIVE';
const STAGE_INACTIVE = 'INACTIVE';
const STAGE_COMPLETE = 'COMPLETE';

export const useSimpleWealthHubState = () => {
  const { avivaSimpleWealth, isFetching, isError, refetch, userDataSynced } =
    useSimpleWealthAccountService();
  const { resetInteractionTimer } = useInactivityCheck();
  const { navigate } = useSimpleWealthStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const { navigatorState, resetNavigatorState } = useNavigatorState();
  const { t } = useTranslationDW({ keyPrefix: 'navigator' });

  const [yourFinancialSituationStatus, setYourFinancialSituationStatus] =
    useState<YourFinancialSituationStatus>('LOADING');
  const [yourInvestmentStyleCardStatus, setYourInvestmentStyleCardStatus] =
    useState<YourInvestmentStyleStatus>(STAGE_INACTIVE);
  const [yourInvestmentForecastStatus, setYourInvestmentForecastStatus] =
    useState<YourInvestmentForecastStatus>(STAGE_INACTIVE);
  const [chipNumber, setChipNumber] = useState(0);
  const [refetchError, setRefetchError] = useState(false);
  const [infoBarLabel, setInfoBarLabel] = useState('');
  const [shouldShowPreparingAdvice, setShouldShowPreparingAdvice] =
    useState(false);

  const yourInvestmentStyleComplete = useSelector(navigatorState.atrComplete);
  const yourInvestmentForecastComplete = useSelector(
    navigatorState.projectionComplete
  );
  const youAreAllSet = useSelector(navigatorState.factFind.reviewComplete);

  useEffect(() => {
    const fetchAndSetExpiryDays = async () => {
      try {
        let closingDate = avivaSimpleWealth?.person?.opportunity?.closeDate;

        if (chipNumber > 1) {
          const { data: refetchData, isError: refetchIsError } =
            await refetch();

          if (refetchIsError) {
            setRefetchError(true);
            return;
          }

          setRefetchError(false);
          closingDate = refetchData?.person?.opportunity?.closeDate ?? '';
        }

        updateInfoBarLabel(closingDate as string);
      } catch (error) {
        setRefetchError(true);
      }
    };

    const updateInfoBarLabel = (closingDate: string) => {
      const validDays = closingDate
        ? differenceInCalendarDays(new Date(closingDate), new Date())
        : 0;
      const isPostYourInvestmentStyleCompletion =
        chipNumber === 2 || chipNumber === 3;
      const label = isPostYourInvestmentStyleCompletion
        ? t('hub.YOUR_INVESTMENT_STYLE_INFO_BAR', { count: validDays })
        : t('hub.NEW_TO_SIMPLE_WEALTH_INFO_BAR');

      setInfoBarLabel(label);
    };

    fetchAndSetExpiryDays();
  }, [
    chipNumber,
    avivaSimpleWealth?.person?.opportunity?.closeDate,
    refetch,
    t,
  ]);

  const amount = avivaSimpleWealth?.hybridAdvicePrice ?? 0;

  const preparingAdvice = computed(
    () =>
      navigatorState.wasPaymentRecorded.get() !== undefined &&
      !navigatorState.wasPaymentRecorded.get()
  );

  const yourFinancialSituationStarted = computed(
    () =>
      (navigatorState.factFind.initialEligibilityRequirementsMet?.responseIds?.get()
        ?.length ?? 0) > 0
  );

  const reviewYourAnswers = computed(
    () =>
      (navigatorState.factFind.workplacePensions.responseIds?.get()?.length ??
        0) > 0
  );

  const personalConsideration = computed(() => {
    const foreseenChangesResponseIds =
      navigatorState.factFind.foreseenChanges.responseIds?.get();
    const changesAffectInvestmentPlansResponseIds =
      navigatorState.factFind.changesAffectInvestmentPlans.responseIds?.get();

    return (
      foreseenChangesResponseIds?.[0] === 'FF011R002' ||
      (foreseenChangesResponseIds?.[0] === 'FF011R001' &&
        changesAffectInvestmentPlansResponseIds?.[0] === 'FF012R002') ||
      false
    );
  });

  const affordability = computed(() =>
    Boolean(navigatorState.factFind.initialPayment.responseValue?.get())
  );

  const getSection = useCallback(() => {
    /* FACT FIND/YOUR FINANCIAL SITUATION STAGES
    0 of 5 - ELIGIBILITY
    1 of 5 - INVESTMENT_GOALS
    2 of 5 - AFFORDABILITY
    3 of 5 - PERSONAL_CONSIDERATION
    4 of 5 - REVIEW_YOUR_ANSWERS
    5 of 5 - YOURE_ALL_SET
    */
    const sections: {
      sectionName: YourFinancialSituationStatus;
      value: boolean;
    }[] = [
      { sectionName: STATUS_YOURE_ALL_SET, value: youAreAllSet },
      { sectionName: FF_STAGE_REVIEW, value: reviewYourAnswers.get() },
      {
        sectionName: FF_STAGE_PERSONAL_CONSIDERATION,
        value: personalConsideration.get(),
      },
      { sectionName: FF_STAGE_AFFORDABILITY, value: affordability.get() },
      {
        sectionName: FF_STAGE_INVESTMENT_GOALS,
        value: yourFinancialSituationStarted.get(),
      },
      {
        sectionName: FF_STAGE_ELIGIBILITY,
        value: !yourFinancialSituationStarted.get(),
      },
    ];

    const completedSection = sections.find((section) => section.value);

    return completedSection
      ? completedSection.sectionName
      : FF_STAGE_ELIGIBILITY;
  }, [
    youAreAllSet,
    yourFinancialSituationStarted,
    reviewYourAnswers,
    personalConsideration,
    affordability,
  ]);

  const focusEffectCallback = useCallback(() => {
    if (resetNavigator.get()) {
      resetNavigator.set(false);
      resetNavigatorState();
    }

    let FFstage: YourFinancialSituationStatus = FF_STAGE_ELIGIBILITY;
    let YourInvestmentStyleStage: YourInvestmentStyleStatus = STAGE_INACTIVE;
    let YourInvestmentForecastStage: YourInvestmentForecastStatus =
      STAGE_INACTIVE;
    const showPreparingAdvice = preparingAdvice.get();

    if (yourFinancialSituationStarted.get()) {
      if (
        youAreAllSet &&
        !yourInvestmentStyleComplete &&
        !yourInvestmentForecastComplete
      ) {
        FFstage = STATUS_YOURE_ALL_SET;
        YourInvestmentStyleStage = STAGE_ACTIVE;
      } else if (
        youAreAllSet &&
        yourInvestmentStyleComplete &&
        !yourInvestmentForecastComplete
      ) {
        FFstage = STATUS_YOURE_ALL_SET;
        YourInvestmentStyleStage = STAGE_COMPLETE;
        YourInvestmentForecastStage = STAGE_ACTIVE;
      } else if (
        youAreAllSet &&
        yourInvestmentStyleComplete &&
        yourInvestmentForecastComplete
      ) {
        FFstage = STATUS_YOURE_ALL_SET;
        YourInvestmentStyleStage = STAGE_COMPLETE;
        YourInvestmentForecastStage = STAGE_COMPLETE;
      } else {
        FFstage = getSection();
      }
    }

    setYourInvestmentStyleCardStatus(YourInvestmentStyleStage);
    setYourFinancialSituationStatus(FFstage);
    setYourInvestmentForecastStatus(YourInvestmentForecastStage);
    setShouldShowPreparingAdvice(showPreparingAdvice);
    setChipNumber(
      [
        youAreAllSet,
        yourInvestmentStyleComplete,
        yourInvestmentForecastComplete,
      ].filter((sec) => sec).length
    );
  }, [
    preparingAdvice,
    yourFinancialSituationStarted,
    youAreAllSet,
    yourInvestmentStyleComplete,
    yourInvestmentForecastComplete,
    getSection,
    resetNavigatorState,
  ]);

  useFocusEffect(focusEffectCallback);

  const optionalTrackUser = (screen: string, option?: boolean) => {
    if (option === false) {
      return;
    }
    trackUserEvent(screen);
  };

  type AnalyticsOption = boolean | undefined;

  const onPressYourFinancialSituation = (
    analyticsOption: AnalyticsOption = true
  ) => {
    const analytics =
      analyticsOption !== undefined && !analyticsOption ? false : true;

    if (yourFinancialSituationStatus === 'LOADING') {
      return;
    }
    if (yourFinancialSituationStatus === STATUS_YOURE_ALL_SET) {
      return;
    }
    resetInteractionTimer();

    if (yourFinancialSituationStatus === FF_STAGE_REVIEW) {
      optionalTrackUser(YOUR_FINANCIAL_SITUATION_REVIEW, analytics);
      navigate('ReviewScreen');
      return;
    }

    if (yourFinancialSituationStatus === FF_STAGE_PERSONAL_CONSIDERATION) {
      optionalTrackUser(YOUR_FINANCIAL_SITUATION_PERSONAL, analytics);
      navigate('FinancialProtectionScreen');
      return;
    }

    if (yourFinancialSituationStatus === FF_STAGE_AFFORDABILITY) {
      optionalTrackUser(YOUR_FINANCIAL_SITUATION_AFFORDABILITY, analytics);
      navigate('EmergencySavingsScreen');
      return;
    }

    if (yourFinancialSituationStatus === FF_STAGE_INVESTMENT_GOALS) {
      optionalTrackUser(YOUR_FINANCIAL_SITUATION_GOALS, analytics);
      navigate('FinancialGoalScreen');
      return;
    }

    optionalTrackUser(YOUR_FINANCIAL_SITUATION_INTRO, analytics);
    navigate('YourFinancialSituationIntro');
  };

  const infoBarIcon: IconName =
    chipNumber === 2 ? 'danger' : 'info-chat-bubble';

  const heroLabel = () => {
    if (chipNumber === 1) {
      return t('hub.LETS_WORK_OUT');
    }
    if (chipNumber >= 2) {
      return t('hub.TAKE_A_LOOK');
    }
    return t('hub.HELP_US_UNDERSTAND');
  };
  const heroTitle = () => {
    if (chipNumber === 1) {
      return t('hub.RISK_LEVEL');
    }
    if (chipNumber >= 2) {
      return t('hub.INVESTMENT_FORECAST');
    }
    return t('hub.FINANCIAL_SITUATION');
  };

  const heroButtonText = () => {
    if (chipNumber >= 2) {
      return t('hub.VIEW');
    }

    if (
      yourFinancialSituationStatus === STATUS_YOURE_ALL_SET &&
      !yourInvestmentStyleComplete
    ) {
      return t('hub.START');
    }

    return yourFinancialSituationStarted.get()
      ? t('hub.JUMP_BACK_IN')
      : t('hub.START');
  };

  const heroIcon: IconName = chipNumber >= 2 ? 'arrow-right' : 'play';

  const onYourInvestmentStylePress = () => {
    if (
      yourFinancialSituationStatus === STATUS_YOURE_ALL_SET &&
      !yourInvestmentStyleComplete
    ) {
      resetInteractionTimer();
      navigate('IntroductionScreen');
    }
  };

  const onPressAdviceSummaryCard = () => {
    if (yourInvestmentStyleCardStatus === STAGE_COMPLETE) {
      navigate('AdviceSummaryIntro');
    }
  };

  const onPressInfoBar = () => {
    if (chipNumber >= 2) {
      navigate('InvestmentStyleScreen');
      return;
    }

    navigate('OnboardingInformationScreenPush', {
      removeContinueButton: true,
      amount,
    });
  };

  const onPressHeroCard = () => {
    if (
      yourFinancialSituationStatus === STATUS_YOURE_ALL_SET &&
      !yourInvestmentStyleComplete
    ) {
      resetInteractionTimer();
      navigate('IntroductionScreen');

      return;
    }

    if (chipNumber === 2 && affordability.get()) {
      navigate('YourInvestmentForecastIntroduction');
      return;
    }

    if (chipNumber === 3 && affordability.get()) {
      navigate('YourInvestmentForecastGoals', {
        hasConfirmedYourInvestmentForecast: true,
      });
      return;
    }

    trackUserEvent(START_YOUR_FINANCIAL_SITUATION);
    onPressYourFinancialSituation(false);
  };

  const onPressYourInvestmentForecast = () => {
    if (yourInvestmentStyleComplete && !yourInvestmentForecastComplete) {
      resetInteractionTimer();
      trackUserEvent(YOUR_INVESTMENT_FORECAST_TAPPED);
      navigate('YourInvestmentForecastIntroduction');
    }
  };

  return {
    heroIcon,
    heroButtonText,
    heroTitle,
    heroLabel,
    infoBarLabel,
    infoBarIcon,
    onPressYourFinancialSituation,
    chipNumber,
    yourFinancialSituationStatus,
    onYourInvestmentStylePress,
    yourInvestmentStyleCardStatus,
    onPressAdviceSummaryCard,
    onPressInfoBar,
    onPressHeroCard,
    onPressYourInvestmentForecast,
    yourInvestmentForecastStatus,
    shouldShowPreparingAdvice,
    avivaSimpleWealth,
    isFetching,
    isError,
    refetchError,
    refetch,
    userDataSynced,
  };
};
