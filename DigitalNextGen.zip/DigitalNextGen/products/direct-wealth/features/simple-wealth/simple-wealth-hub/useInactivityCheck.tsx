import { useNavigatorState } from '@direct-wealth/features/simple-wealth/navigation/provider';

export const useInactivityCheck = () => {
  const { navigatorState, resetNavigatorState } = useNavigatorState();
  const currentDate = new Date();
  let storedDate = navigatorState.factFind.lastInteracted.get();

  if (!storedDate) {
    navigatorState.factFind.lastInteracted.set(currentDate);
    storedDate = currentDate;
  }

  function isWithinInterval() {
    const now = new Date();
    const twentyEightDaysAgo = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate() - 28
    );

    const stored = new Date(storedDate);
    return stored >= twentyEightDaysAgo;
  }
  if (!isWithinInterval()) {
    resetNavigatorState();
  }

  const resetInteractionTimer = () => {
    navigatorState.factFind.lastInteracted.set(currentDate);
  };

  return { resetInteractionTimer };
};
