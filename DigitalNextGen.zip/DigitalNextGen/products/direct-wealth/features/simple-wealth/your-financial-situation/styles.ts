import { TamaguiTextProps } from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';

export const radioText: TamaguiTextProps = {
  fontSize: tokens.size['4'],
  fontWeight: '$regular',
  color: tokens.color.Gray800,
};

export const titleText: TamaguiTextProps = {
  fontSize: tokens.size['4'],
  fontWeight: '$semibold',
  color: tokens.color.Gray800,
};

export const subtitleText: TamaguiTextProps = {
  fontSize: tokens.size['4'],
  fontWeight: '$regular',
  color: tokens.color.Gray800,
};
