import {
  Button,
  Icon,
  Separator,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { LoadingState } from '@direct-wealth/components/loading-state/loading-state';
import { AvivaSimpleWealthProjection } from '@direct-wealth/validation/schemas/aviva-simple-wealth';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useSelector } from '@legendapp/state/react';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { ErrorDialog } from '@src/components/error-dialog';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { formatPercentageValue } from '@src/utils/format-percentage-value';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { tokens } from '@theme/tokens';
import { useCallback, useState } from 'react';
import { SafeAreaView, ScrollView } from 'react-native';

import {
  PotentialReturn,
  PotentialReturnsCard,
} from '../components/potential-returns-card/potential-returns-card';
import {
  useSimpleWealthStackNavigation,
  useSimpleWealthStackRoute,
} from '../navigation/hooks';
import { useNavigatorState } from '../navigation/provider';
import { useSimpleWealthAccountService } from '../simple-wealth-hub/use-simple-wealth-account-service';
import {
  ASSUMPTIONS_BUTTON_ANALYTICS,
  CONTINUE_BUTTON_ANALYTICS,
  EDIT_CONTRIBUTIONS_BUTTON_ANALYTICS,
  GOALS_SCREEN,
} from './analytics';
import { useAdjustSimpleWealthQuestionnaire } from './hooks/use-adjust-simple-wealth-questionnaire';
import { YourInvestmentForecastChart } from './your-investment-forecast-chart';

export const YourInvestmentForecastGoals = () => {
  const {
    params: { hasConfirmedYourInvestmentForecast },
  } = useSimpleWealthStackRoute<'YourInvestmentForecastGoals'>();

  const { isFetching, isError, refetch } = useSimpleWealthAccountService();
  const { navigate } = useSimpleWealthStackNavigation();
  const { navigatorState } = useNavigatorState();
  const { trackUserEvent } = useAnalytics();
  const [projectionData, setProjectionData] =
    useState<AvivaSimpleWealthProjection>();

  const { finaliseQuestionnaire } = useAdjustSimpleWealthQuestionnaire();

  const { factFind } = navigatorState;

  const initialContribution = useSelector(
    factFind.initialPayment.responseValue
  );
  const monthlyPayment = useSelector(factFind.monthlyPayment.responseValue);
  const investmentPeriod = useSelector(factFind.investmentPeriod.responseValue);

  const [isPutLoading, setIsPutLoading] = useState(false);
  const [isPutError, setIsPutError] = useState(false);
  const [isRefetchError, setIsRefetchError] = useState(false);

  const { goBack } = useNavigation();

  const focusEffectCallback = useCallback(() => {
    const fetchAndSetProjections = async () => {
      try {
        const { data: refetchData, isError: refetchIsError } = await refetch();

        if (refetchIsError) {
          setIsRefetchError(true);
          return;
        }
        if (refetchData) {
          const { projection } = refetchData;
          setIsRefetchError(false);
          setProjectionData(projection as AvivaSimpleWealthProjection);
        }
      } catch (error) {
        setIsRefetchError(true);
      }
    };

    fetchAndSetProjections();
  }, [refetch]);

  useFocusEffect(focusEffectCallback);

  const { t } = useTranslationDW({ keyPrefix: 'navigator' });

  const handleEditContributions = () => {
    trackUserEvent(EDIT_CONTRIBUTIONS_BUTTON_ANALYTICS);
    navigate('YourInvestmentForecastEditContributions');
  };

  const handleAssumptions = () => {
    trackUserEvent(ASSUMPTIONS_BUTTON_ANALYTICS);
    navigate('YourInvestmentForecastAssumptions');
  };

  const handleAPIError = () => {
    goBack();
  };

  useOnPageLoad({ pageTag: GOALS_SCREEN });

  const submitStage = useCallback(async () => {
    if (hasConfirmedYourInvestmentForecast) {
      goBack();
      return;
    }

    setIsPutLoading(true);

    try {
      const result = await finaliseQuestionnaire();
      setIsPutLoading(false);

      if (result) {
        trackUserEvent(CONTINUE_BUTTON_ANALYTICS);
        navigatorState.projectionComplete.set(true);
        navigate('YourInvestmentForecastRecommendationScreen');
      } else {
        setIsPutLoading(false);
        setIsPutError(true);
      }
    } catch {
      setIsPutError(true);
      setIsPutLoading(false);
    }
  }, [
    hasConfirmedYourInvestmentForecast,
    goBack,
    finaliseQuestionnaire,
    trackUserEvent,
    navigatorState.projectionComplete,
    navigate,
  ]);

  if (isRefetchError) {
    return (
      <ErrorDialog
        open
        onPress={() => {
          refetch();
          setIsRefetchError(false);
        }}
        center
      />
    );
  }

  if (isError) {
    return <ErrorDialog open onPress={() => handleAPIError()} center />;
  }

  if (isPutError) {
    return <ErrorDialog open onPress={() => setIsPutError(false)} center />;
  }

  if (isFetching || isPutLoading) {
    return <LoadingState title={t('common.pleaseWait')} />;
  }

  return (
    <SafeAreaView
      style={{
        height: '100%',
      }}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <YStack
          tablet={isIpad}
          marginHorizontal="$xl"
          gap="$xl"
          style={{ flex: 1 }}
          testID={getTestId('bodyContainer')}
        >
          <Text
            tamaguiTextProps={{ accessibilityRole: 'header' }}
            fontVariant="heading2-regular-White"
          >
            {`${t(
              'yourInvestmentForecastGoals.goalsTitleStart'
            )} ${formatCurrencyValue(
              projectionData?.projections.finalMediumGrowthRateProjection
                ?.projectionValue ?? '',
              0
            )} ${t(
              'yourInvestmentForecastGoals.goalsTitleMiddle'
            )} ${investmentPeriod} ${t('common.years')}`}
          </Text>
          <YStack
            backgroundColor={'$WealthBlue95'}
            borderColor={'$WealthBlue80'}
            borderWidth={'$xxs'}
            borderRadius={'$4'}
            paddingTop={'$xl'}
            paddingBottom={'$xl'}
            accessible
            accessibilityLabel={t(
              'yourInvestmentForecastGoals.graphAccessibilityLabel'
            )}
          >
            <YourInvestmentForecastChart
              apiProjectionData={projectionData?.projections ?? {}}
              initialContribution={initialContribution ?? 0}
            />
            <YStack paddingHorizontal={'$lg'} marginTop={'$-xxl'}>
              <Text fontVariant="overline-regular-Gray300">
                {t('yourInvestmentForecastGoals.graphDisclaimerText')}
              </Text>
            </YStack>
          </YStack>
          <PotentialReturnsCard
            title={t('yourInvestmentForecastGoals.potentialReturnsCardTitle')}
            investmentPeriod={investmentPeriod}
            oneOffContribution={initialContribution}
            monthlyPayment={monthlyPayment}
            onPress={handleEditContributions}
            hideEditButton={hasConfirmedYourInvestmentForecast}
            potentialReturns={[
              {
                barColour: tokens.color.LowReturns.val,
                riskDescr: t(
                  'yourInvestmentForecastGoals.potentialReturnsCardLow'
                ),
                riskAmount:
                  projectionData?.projections.finalLowGrowthRateProjection
                    ?.projectionValue,
                riskPercent:
                  projectionData?.projections.finalLowGrowthRateProjection
                    ?.projectionRate,
                percentColour: tokens.color.PinkLight.val,
              } as PotentialReturn,
              {
                barColour: tokens.color.BlueMid.val,
                riskDescr: t(
                  'yourInvestmentForecastGoals.potentialReturnsCardMedium'
                ),
                riskAmount:
                  projectionData?.projections.finalMediumGrowthRateProjection
                    ?.projectionValue,
                riskPercent:
                  projectionData?.projections.finalMediumGrowthRateProjection
                    ?.projectionRate,
                percentColour: tokens.color.BlueLighter.val,
              } as PotentialReturn,
              {
                barColour: tokens.color.Primary400.val,
                riskDescr: t(
                  'yourInvestmentForecastGoals.potentialReturnsCardHigh'
                ),
                riskAmount:
                  projectionData?.projections.finalHighGrowthRateProjection
                    ?.projectionValue,
                riskPercent:
                  projectionData?.projections.finalHighGrowthRateProjection
                    ?.projectionRate,
                percentColour: tokens.color.YellowLight.val,
              } as PotentialReturn,
            ]}
          />
          <YStack
            backgroundColor={tokens.color.WealthBlue95.val}
            p="$xl"
            borderRadius={'$4'}
            borderColor={'$WealthBlue80'}
            borderWidth={'$xxs'}
          >
            <Text fontVariant="body-semibold-White">
              {t('yourInvestmentForecastGoals.assumptionsCardTitle')}
            </Text>
            <Text fontVariant="body-regular-White">
              {t('yourInvestmentForecastGoals.assumptionsCardCopy')}
            </Text>
            <Separator mt="$lg" mb="$xl" borderColor={'$WealthBlue80'} />
            <XStack
              onPress={handleAssumptions}
              testID={getTestId('handle-assumptions-button')}
              pb={'$md'}
              accessibilityRole="button"
              accessibilityLabel={t(
                'yourInvestmentForecastGoals.assumptionsCardButtonText'
              )}
              accessible
            >
              <Text
                tamaguiTextProps={{ flex: 1 }}
                fontVariant="body-semibold-White"
              >
                {t('yourInvestmentForecastGoals.assumptionsCardButtonText')}
              </Text>
              <Icon name={'chevron-right'} color={tokens.color.White.val} />
            </XStack>
          </YStack>
          <YStack
            backgroundColor={tokens.color.WealthBlue95.val}
            borderRadius={'$4'}
            borderColor={'$WealthBlue80'}
            borderWidth={'$xxs'}
            p={'$xl'}
            gap={'$xl'}
          >
            <Text fontVariant="heading5-semibold-White">
              {t('yourInvestmentForecastGoals.infoCardTitle')}
            </Text>
            <XStack alignItems="center">
              <XStack flex={1} pr={'$md'}>
                <Text fontVariant="body-regular-White">
                  {`${t(
                    'yourInvestmentForecastGoals.infoCardCopyStart'
                  )} ${formatPercentageValue(
                    projectionData?.projections.finalCashProjection
                      ?.projectionRate ?? null,
                    2
                  )} ${t(
                    'yourInvestmentForecastGoals.infoCardCopyMiddle'
                  )} ${formatCurrencyValue(
                    projectionData?.projections.finalCashProjection
                      ?.projectionValue ?? '',
                    0
                  )}${t('yourInvestmentForecastGoals.infoCardCopyFullstop')}`}
                </Text>
              </XStack>
              <Icon
                name={'money-circles'}
                testID={'card-icon'}
                height={48}
                width={48}
              />
            </XStack>
          </YStack>
        </YStack>
        <YStack
          testID={getTestId('buttonContainer')}
          tabletNarrow={isIpad}
          pt={isIpad ? '$xxxl' : undefined}
        >
          <Button
            accessibilityHint={t(
              'yourInvestmentForecastGoals.continueAccessibilityHint'
            )}
            mb="$xxl"
            mt="$xxl"
            marginHorizontal="$lg"
            onPress={submitStage}
          >
            {!hasConfirmedYourInvestmentForecast
              ? t('yourInvestmentForecastGoals.confirmButton')
              : t('common.back')}
          </Button>
        </YStack>
      </ScrollView>
    </SafeAreaView>
  );
};
