import {
  Button,
  Icon,
  IconName,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { CustomisableChip } from '@aviva/ion-mobile/components/chip/customisableChip';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { SafeAreaView, ScrollView, View } from 'react-native';

import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import {
  VIEW_YOUR_INVESTMENT_FORECAST_BUTTON_ANALYTICS,
  YOUR_INVESTMENT_FORECAST_INTRODUCTION_SCREEN,
} from './analytics';

const TextWithIcon = ({ title, icon }: { title: string; icon: IconName }) => {
  return (
    <XStack flex={1} marginTop="$lg" testID={getTestId('text-with-icon')}>
      <Icon
        width={tokens.size[8].val}
        height={tokens.size[8].val}
        name={icon}
      />
      <Text
        fontVariant={'body-regular-Gray100'}
        tamaguiTextProps={{ flex: 1, marginRight: '$xxl', marginLeft: '$md' }}
      >
        {title}
      </Text>
    </XStack>
  );
};

export const YourInvestmentForecastIntro = () => {
  const { navigate } = useSimpleWealthStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const { t } = useTranslationDW({ keyPrefix: 'navigator' });

  useOnPageLoad({ pageTag: YOUR_INVESTMENT_FORECAST_INTRODUCTION_SCREEN });

  const handleContinue = () => {
    trackUserEvent(VIEW_YOUR_INVESTMENT_FORECAST_BUTTON_ANALYTICS);
    navigate('YourInvestmentForecastGoals', {
      hasConfirmedYourInvestmentForecast: false,
    });
  };

  return (
    <SafeAreaView style={{ height: '100%' }}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          flexGrow: 1,
          marginHorizontal: tokens.space.xl.val,
        }}
      >
        <YStack tablet={isIpad} gap="$md" testID={getTestId('bodyContainer')}>
          <Text
            fontVariant="heading2-regular-White"
            tamaguiTextProps={{
              marginTop: '$xl',
              marginBottom: '$md',
              accessibilityRole: 'header',
            }}
          >
            {t('yourInvestmentForecastIntro.title')}
          </Text>
          <CustomisableChip
            text={t('yourInvestmentForecastIntro.alertTime')}
            iconName={'clockWithBackground'}
            iconColor={tokens.color.Information.val}
            backgroundColor={'$Secondary700'}
            textColor={'$White'}
          />
          <Text
            fontVariant="heading5-semibold-White"
            tamaguiTextProps={{ marginTop: '$xl' }}
          >
            {t('yourInvestmentForecastIntro.subtitle')}
          </Text>
          <TextWithIcon
            title={t('yourInvestmentForecastIntro.sectionOne')}
            icon={'person-scan'}
          />
          <TextWithIcon
            title={t('yourInvestmentForecastIntro.sectionTwo')}
            icon={'horizontal-bar-chart'}
          />
          <TextWithIcon
            title={t('yourInvestmentForecastIntro.sectionThree')}
            icon={'bar-chart'}
          />
        </YStack>
        <View style={{ flex: 1 }} />
        <YStack tabletNarrow={isIpad} testID={getTestId('buttonContainer')}>
          <XStack
            paddingHorizontal="$xl"
            paddingVertical="$lg"
            marginTop="$xl"
            borderWidth={1}
            borderColor={tokens.color.Gray200Opacity20.val}
            borderRadius={'$2'}
            backgroundColor={tokens.color.WealthBlue95}
            testID={getTestId('info-box')}
          >
            <Icon name={'infoCircle'} color={tokens.color.Information.val} />
            <Text
              fontVariant={'small-regular-Gray300'}
              tamaguiTextProps={{ flex: 1, paddingLeft: '$lg' }}
            >
              {t('yourInvestmentForecastIntro.extraInfo')}
            </Text>
          </XStack>
          <Button mt="$xxl" mb="$xl" onPress={handleContinue}>
            {t('yourInvestmentForecastIntro.viewYourInvestmentForecast')}
          </Button>
        </YStack>
      </ScrollView>
    </SafeAreaView>
  );
};
