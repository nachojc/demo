import {
  BulletPoint,
  Button,
  IconText,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { SafeAreaView, ScrollView } from 'react-native';

import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import { ASSUMPTIONS_CONFIRM_ACTION, ASSUMPTIONS_SCREEN } from './analytics';

export const YourInvestmentForecastAssumptions = () => {
  const { navigate } = useSimpleWealthStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const { t } = useTranslationDW({ keyPrefix: 'navigator' });

  useOnPageLoad({ pageTag: ASSUMPTIONS_SCREEN });

  const assumptionsContent: string[] = t('assumptionsAndCharges.assumptions', {
    returnObjects: true,
  });
  const chargesContent: string[] = t('assumptionsAndCharges.charges', {
    returnObjects: true,
  });

  return (
    <SafeAreaView
      style={{
        height: '100%',
      }}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ flexGrow: 1 }}
      >
        <YStack
          testID={getTestId('bodyContainer')}
          marginHorizontal="$xl"
          gap="$xl"
          style={{ flex: 1 }}
          tablet={isIpad}
        >
          <Text
            fontVariant="heading3-regular-White"
            tamaguiTextProps={{
              accessibilityRole: 'header',
            }}
          >
            {t('assumptionsAndCharges.title')}
          </Text>

          <YStack
            backgroundColor={'$WealthBlue95'}
            borderColor={'$WealthBlue80'}
            borderWidth={'$xxs'}
            borderRadius={'$4'}
            paddingHorizontal={'$xl'}
            paddingTop={'$md'}
            gap={'$-md'}
          >
            <Text
              fontVariant="body-semibold-White"
              tamaguiTextProps={{ mb: '$xl' }}
            >
              {t('assumptionsAndCharges.assumptionsHeader')}
            </Text>
            {assumptionsContent.map((text) => (
              <IconText
                key={text}
                iconSizeOption="large"
                iconName="tick2"
                title={text}
                titleFontVariant="body-regular-Gray100"
              />
            ))}
          </YStack>

          <YStack
            backgroundColor={'$WealthBlue95'}
            borderColor={'$WealthBlue80'}
            borderWidth={'$xxs'}
            borderRadius={'$4'}
            paddingHorizontal={'$xl'}
            paddingVertical={'$lg'}
            gap={'$lg'}
          >
            <Text
              fontVariant="body-semibold-White"
              tamaguiTextProps={{ mb: '$lg' }}
            >
              {t('assumptionsAndCharges.chargesHeader')}
            </Text>
            {chargesContent.map((text) => (
              <XStack accessible key={text}>
                <BulletPoint fontVariant={'body-regular-Gray100'} />
                <Text
                  tamaguiTextProps={{ flexWrap: 'wrap', flex: 1 }}
                  fontVariant={'body-regular-Gray100'}
                >
                  {text}
                </Text>
              </XStack>
            ))}
          </YStack>
        </YStack>
        <YStack tabletNarrow={isIpad} testID={getTestId('buttonContainer')}>
          <Button
            accessibilityHint={t('assumptionsAndCharges.confirmButtonA11yHint')}
            mb="$xxl"
            mt="$xxl"
            marginHorizontal="$lg"
            onPress={() => {
              trackUserEvent(ASSUMPTIONS_CONFIRM_ACTION);
              navigate('YourInvestmentForecastGoals', {
                hasConfirmedYourInvestmentForecast: false,
              });
            }}
          >
            {t('assumptionsAndCharges.confirmButton')}
          </Button>
        </YStack>
      </ScrollView>
    </SafeAreaView>
  );
};
