import { i18n } from '@src/i18n/i18n';
import { z } from 'zod';

import { SimpleWealthConstants } from '../common/simple-wealth-constants';

const { DEPOSIT_MINIMUM, MONTHLY_PAYMENT_MINIMUM } = SimpleWealthConstants;

export const YourInvestmentForecastContributionsSchema = z.object({
  projectionEditContributions: z
    .object({
      projectionEditContributionsDeposit: z.number().optional(),
      projectionEditContributionsMonthlyPayment: z.number().optional(),
      duration: z.number().min(1, {
        message: 'Please input the duration you want to invest for in years',
      }),
    })
    .refine(
      ({
        projectionEditContributionsDeposit,
        projectionEditContributionsMonthlyPayment,
      }) => {
        return !(
          projectionEditContributionsMonthlyPayment &&
          projectionEditContributionsDeposit === 0 &&
          (projectionEditContributionsMonthlyPayment <
            MONTHLY_PAYMENT_MINIMUM ||
            !projectionEditContributionsMonthlyPayment)
        );
      },
      {
        path: ['projectionEditContributionsMonthlyPayment'],

        message: i18n.t('navigator.contributions.MONTHLY_AMOUNT_ERROR', {
          ns: 'dw',
        }),
      }
    )
    .refine(
      ({
        projectionEditContributionsDeposit,
        projectionEditContributionsMonthlyPayment,
      }) => {
        return !(
          projectionEditContributionsDeposit &&
          projectionEditContributionsMonthlyPayment === 0 &&
          projectionEditContributionsDeposit < DEPOSIT_MINIMUM
        );
      },
      {
        path: ['projectionEditContributionsDeposit'],
        message: i18n.t('navigator.contributions.DEPOSIT_ERROR', { ns: 'dw' }),
      }
    )
    .refine(
      ({
        projectionEditContributionsDeposit,
        projectionEditContributionsMonthlyPayment,
      }) => {
        return !(
          projectionEditContributionsDeposit &&
          projectionEditContributionsMonthlyPayment &&
          projectionEditContributionsDeposit < DEPOSIT_MINIMUM &&
          projectionEditContributionsMonthlyPayment < MONTHLY_PAYMENT_MINIMUM
        );
      },
      {
        path: ['projectionEditContributionsDeposit'],
        message: i18n.t('navigator.contributions.DEPOSIT_ERROR', { ns: 'dw' }),
      }
    )
    .refine(
      ({
        projectionEditContributionsDeposit,
        projectionEditContributionsMonthlyPayment,
      }) => {
        return !(
          projectionEditContributionsDeposit &&
          projectionEditContributionsMonthlyPayment &&
          projectionEditContributionsDeposit < DEPOSIT_MINIMUM &&
          projectionEditContributionsMonthlyPayment < MONTHLY_PAYMENT_MINIMUM
        );
      },
      {
        path: ['projectionEditContributionsMonthlyPayment'],
        message: i18n.t('navigator.contributions.MONTHLY_AMOUNT_ERROR', {
          ns: 'dw',
        }),
      }
    ),
});

export type YourInvestmentForecastContributionsForm = z.infer<
  typeof YourInvestmentForecastContributionsSchema
>;
