import {
  BulletPoint,
  Button,
  Checkbox,
  DynamicHeightModal,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { getMaximumIsaAllowance } from '@direct-wealth/common/utils/get-maximum-isa-allowance';
import { useAnalytics } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useState } from 'react';

import {
  INCREASED_CONTRIBUTIONS_MODAL_CLOSE,
  INCREASED_CONTRIBUTIONS_MODAL_CONFIRM,
} from './analytics';

const { maximumFormattedValue } = getMaximumIsaAllowance();
type IncreasedContributionsPopupProps = {
  isVisible: boolean;
  onClosePress: () => void;
  onConfirmPress: () => void;
};

export const IncreasedContributionsPopup = ({
  isVisible,
  onClosePress,
  onConfirmPress,
}: IncreasedContributionsPopupProps) => {
  const { t } = useTranslationDW({
    keyPrefix: 'navigator',
  });

  const { trackUserEvent } = useAnalytics();

  const [isChecked, setIsChecked] = useState(false);

  const handleCloseTapped = () => {
    trackUserEvent(INCREASED_CONTRIBUTIONS_MODAL_CLOSE);
    onClosePress();
  };

  const handleConfirmTapped = () => {
    trackUserEvent(INCREASED_CONTRIBUTIONS_MODAL_CONFIRM);
    onConfirmPress();
  };

  return (
    <DynamicHeightModal
      isOpen={isVisible}
      onClose={handleCloseTapped}
      backgroundColor="White"
      closeIconColor="WealthBlue"
    >
      <Text
        fontVariant={'heading3-semibold-WealthBlue'}
        tamaguiTextProps={{
          marginBottom: '$xl',
        }}
      >
        {t('yourInvestmentForecastEditContributions.popupTitle')}
      </Text>
      <XStack accessible mb="$xl">
        <BulletPoint fontVariant={'body-regular-Gray800'} />
        <Text
          tamaguiTextProps={{ flexWrap: 'wrap', flex: 1 }}
          fontVariant={'body-regular-Gray800'}
        >
          {t('yourInvestmentForecastEditContributions.allowanceAgreement', {
            maximumFormattedValue,
          })}
        </Text>
      </XStack>
      <XStack accessible mb="$xxxl">
        <BulletPoint fontVariant={'body-regular-Gray800'} />
        <Text
          tamaguiTextProps={{ flexWrap: 'wrap', flex: 1 }}
          fontVariant={'body-regular-Gray800'}
        >
          {t('yourInvestmentForecastEditContributions.lifeImpactAgreement')}
        </Text>
      </XStack>
      <YStack tabletNarrow={isIpad} testID={getTestId('footerContainer')}>
        <XStack mt={'$xxxxl'}>
          <Checkbox
            testID={'increased-contributions-checkbox'}
            onValueChange={(val) => setIsChecked(val)}
            value={isChecked}
            marginTop={'$lg'}
            marginRight={'$lg'}
            hitSlop={{
              top: tokens.size[6].val,
              bottom: tokens.size[6].val,
              left: tokens.size[6].val,
              right: tokens.size[6].val,
            }}
          />
          <Text
            fontVariant={'body-regular-Gray800'}
            tamaguiTextProps={{ flex: 1, pt: '$md' }}
          >
            {t(
              'yourInvestmentForecastEditContributions.increasedContributionsCheckbox'
            )}
          </Text>
        </XStack>
        <Button
          mt="$xl"
          onPress={handleConfirmTapped}
          testID={getTestId('increased-contributions-action-button')}
          disabled={!isChecked}
          accessibilityHint={t(
            'yourInvestmentForecastEditContributions.accessibilityDialogContinueButton'
          )}
        >
          {t('common.confirm')}
        </Button>
      </YStack>
    </DynamicHeightModal>
  );
};
