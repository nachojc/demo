import {
  Button,
  ButtonVariant,
  Dialog,
  DynamicHeightModal,
  FormCounter,
  Link,
  NumberInput,
  Stack,
  Text,
  TextWithLinks,
  Theme,
  YStack,
} from '@aviva/ion-mobile';
import { FocusKeyboardAvoidingView } from '@aviva/ion-mobile/components/focus-keyboard-avoiding-view/focus-keyboard-avoiding-view';
import { getMaximumIsaAllowance } from '@direct-wealth/common/utils/get-maximum-isa-allowance';
import { LoadingState } from '@direct-wealth/components/loading-state/loading-state';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { ErrorDialog } from '@src/components/error-dialog';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useCallback, useEffect, useState } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { ScrollView, View } from 'react-native';

import { useMaxContributionsExceededCalculator } from '../../../common/hooks/use-max-contributions-exceeded-calculator';
import { SimpleWealthConstants } from '../common/simple-wealth-constants';
import { InputFieldWithInfo } from '../components/input-field-with-info/input-field-with-info';
import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import { useNavigatorState } from '../navigation/provider';
import {
  AVIVA_SAVE_LINK_ANALYTICS,
  INCREASED_CONTRIBUTIONS_MODAL,
  MODAL_CHOOSE_DIFFERENT_ANALYTICS,
  MODAL_CLOSE_ANALYTICS,
  MODAL_EXIT_ADVICE_ANALYTICS,
  UPDATE_CONTRIBUTIONS_ANALYTIC,
  YOUR_INVESTMENT_FORECAST_EDIT_CONTRIBUTIONS_SCREEN,
} from './analytics';
import { useAdjustSimpleWealthQuestionnaire } from './hooks/use-adjust-simple-wealth-questionnaire';
import { IncreasedContributionsPopup } from './increased-contributions-popup';
import {
  YourInvestmentForecastContributionsForm,
  YourInvestmentForecastContributionsSchema,
} from './your-investment-forecast-edit-contributions-schema';

const { MONTHLY_PAYMENT_MAX } = SimpleWealthConstants;
const { maximumFormattedValue, maximumValue } = getMaximumIsaAllowance();

export const YourInvestmentForecastEditContributions = () => {
  const { trackUserEvent } = useAnalytics();
  const { adjustContributions } = useAdjustSimpleWealthQuestionnaire();
  const [modalVisible, setModalVisible] = useState(false);
  const [isModalVisibleDuration, setIsModalVisibleDuration] = useState(false);
  const [
    increasedContributionsPopupVisible,
    setIncreasedContributionsPopupVisible,
  ] = useState(false);
  const [apiErrorVisible, setApiErrorVisible] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [modalText, setModalText] = useState('');
  const { navigatorState } = useNavigatorState();
  const { navigate } = useSimpleWealthStackNavigation();
  const { maxContributionExceeded } = useMaxContributionsExceededCalculator();
  const [isEmpty, setIsEmpty] = useState(false);

  const { t } = useTranslationDW();

  const YourInvestmentForecastEditContributionsFormResolver = zodResolver(
    YourInvestmentForecastContributionsSchema
  );

  const form = useForm<YourInvestmentForecastContributionsForm>({
    resolver: YourInvestmentForecastEditContributionsFormResolver,
    defaultValues: {
      projectionEditContributions: {
        projectionEditContributionsDeposit:
          navigatorState.factFind.initialPayment?.responseValue?.get() ?? 0,
        projectionEditContributionsMonthlyPayment:
          navigatorState.factFind.monthlyPayment?.responseValue?.get() ?? 0,
        duration:
          navigatorState.factFind.investmentPeriod.responseValue.get() ?? 0,
      },
    },
    mode: 'onChange',
  });

  const {
    control,
    handleSubmit,
    getValues,
    watch,
    formState: { isValid },
  } = form;
  const [formValues] = watch(['projectionEditContributions']);

  useOnPageLoad({
    pageTag: YOUR_INVESTMENT_FORECAST_EDIT_CONTRIBUTIONS_SCREEN,
  });

  const submitAdjustment = useCallback(async () => {
    const {
      duration,
      projectionEditContributionsDeposit,
      projectionEditContributionsMonthlyPayment,
    } = getValues().projectionEditContributions;

    try {
      setIsLoading(true);

      const result = await adjustContributions(
        duration,
        projectionEditContributionsDeposit,
        projectionEditContributionsMonthlyPayment
      );

      if (result) {
        navigatorState.factFind.initialPayment.responseValue.set(
          projectionEditContributionsDeposit
        );
        navigatorState.factFind.monthlyPayment.responseValue.set(
          projectionEditContributionsMonthlyPayment
        );
        navigatorState.factFind.investmentPeriod.responseValue.set(duration);

        setIsLoading(false);
        navigate('YourInvestmentForecastGoals', {
          hasConfirmedYourInvestmentForecast: false,
        });
      } else {
        handleApiError();
      }
    } catch {
      handleApiError();
    }
  }, [
    adjustContributions,
    getValues,
    navigate,
    navigatorState.factFind.initialPayment.responseValue,
    navigatorState.factFind.investmentPeriod.responseValue,
    navigatorState.factFind.monthlyPayment.responseValue,
  ]);

  const handleContinue = useCallback(() => {
    const originalInitialPaymentValue =
      navigatorState.factFind?.initialPayment?.responseValue.get();
    const originalMontlhyPaymentValue =
      navigatorState.factFind?.monthlyPayment.responseValue.get();
    const {
      projectionEditContributionsDeposit,
      projectionEditContributionsMonthlyPayment,
    } = getValues().projectionEditContributions;

    if (
      (projectionEditContributionsDeposit &&
        projectionEditContributionsDeposit > originalInitialPaymentValue) ||
      (projectionEditContributionsMonthlyPayment &&
        projectionEditContributionsMonthlyPayment > originalMontlhyPaymentValue)
    ) {
      trackUserEvent(INCREASED_CONTRIBUTIONS_MODAL);
      setIncreasedContributionsPopupVisible(true);
    } else {
      submitAdjustment();
    }
    trackUserEvent(UPDATE_CONTRIBUTIONS_ANALYTIC);
  }, [
    getValues,
    navigatorState.factFind?.initialPayment?.responseValue,
    navigatorState.factFind?.monthlyPayment.responseValue,
    submitAdjustment,
    trackUserEvent,
  ]);

  const handleFormSubmit = (event: React.BaseSyntheticEvent) => {
    const {
      projectionEditContributions: { duration },
    } = getValues();
    const {
      projectionEditContributionsDeposit: depositValue,
      projectionEditContributionsMonthlyPayment: monthlyPaymentValue,
    } = formValues;

    setIsEmpty(false);

    if (depositValue === 0 && monthlyPaymentValue === 0) {
      setIsEmpty(true);
      return;
    }

    if (duration > 0 && duration < 5) {
      setIsModalVisibleDuration(true);
      return;
    }

    if (depositValue && depositValue > maximumValue) {
      setModalText(
        t('navigator.contributions.EXCEED_YEARLY_AMOUNT_WARNING_CONTENT', {
          maximumFormattedValue,
        })
      );
      setModalVisible(true);
      return;
    }

    if (monthlyPaymentValue && monthlyPaymentValue > MONTHLY_PAYMENT_MAX) {
      setModalText(
        t('navigator.contributions.EXCEED_MONTHLY_AMOUNT_WARNING_CONTENT', {
          maximumFormattedValue,
        })
      );
      setModalVisible(true);
      return;
    }
    if (
      maxContributionExceeded({
        maximumDeposit: maximumValue,
        deposit: depositValue,
        monthlyPayment: monthlyPaymentValue,
      })
    ) {
      setModalText(
        t('navigator.contributions.EXCEED_LIMIT_IN_TAX_YEAR_CONTENT', {
          maximumFormattedValue,
        })
      );
      setModalVisible(true);
      return;
    }

    handleSubmit(handleContinue)(event);
  };

  const determineDepositValue = (deposit: number | undefined) => {
    const { projectionEditContributionsMonthlyPayment: monthlyPaymentValue } =
      formValues;

    if (deposit) {
      return deposit.toString();
    }

    if (monthlyPaymentValue) {
      return '0';
    }

    return '';
  };

  const determineMonthlyValue = (monthyPayment: number | undefined) => {
    const { projectionEditContributionsDeposit: depositValue } = formValues;

    if (monthyPayment) {
      return monthyPayment.toString();
    }

    if (depositValue) {
      return '0';
    }

    return '';
  };

  const handleApiError = () => {
    setIsLoading(false);
    setApiErrorVisible(true);
  };

  const handlePopUpConfirm = async () => {
    setIncreasedContributionsPopupVisible(false);
    await submitAdjustment();
  };

  const handleLinkPress = useCallback(
    (url: string) => {
      setIsModalVisibleDuration(false);
      navigate('Web View', {
        url,
      });
    },
    [navigate]
  );

  const linkProps = {
    color: '#6CACFF',
    textDecorationLine: 'underline',
  };

  const onAvivaSaveLinkPress = () => {
    setIsModalVisibleDuration(false);
    trackUserEvent(AVIVA_SAVE_LINK_ANALYTICS);
    handleLinkPress('https://www.aviva.co.uk/investments/savings-accounts');
  };

  const onMoneyhelperLinkPress = () => {
    setIsModalVisibleDuration(false);
    handleLinkPress('https://www.moneyhelper.org.uk/en/savings/how-to-save');
  };

  const onExitAdviceLinkPress = () => {
    trackUserEvent(MODAL_EXIT_ADVICE_ANALYTICS);
    navigate('YourInvestmentForecastGoals', {
      hasConfirmedYourInvestmentForecast: false,
    });
  };

  const onChooseDifferentDurationPress = () => {
    trackUserEvent(MODAL_CHOOSE_DIFFERENT_ANALYTICS);
    setIsModalVisibleDuration(false);
  };

  const onClosePress = () => {
    trackUserEvent(MODAL_CLOSE_ANALYTICS);
    setIsModalVisibleDuration(false);
  };

  useEffect(() => {
    const {
      projectionEditContributionsDeposit: depositValue,
      projectionEditContributionsMonthlyPayment: monthlyPaymentValue,
      duration,
    } = formValues;
    if ((!depositValue && !monthlyPaymentValue) || !duration) {
      setIsEmpty(true);
    } else {
      setIsEmpty(false);
    }
  }, [formValues]);

  return (
    <>
      <FocusKeyboardAvoidingView>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ flexGrow: 1 }}
        >
          <YStack
            marginHorizontal="$xl"
            gap="$md"
            tablet={isIpad}
            testID={getTestId('bodyContainer')}
          >
            <Text
              fontVariant="heading3-regular-Wealth800"
              tamaguiTextProps={{
                marginTop: '$xl',
                accessibilityRole: 'header',
              }}
            >
              {t('navigator.yourInvestmentForecastEditContributions.title')}
            </Text>
            <Text fontVariant="body-regular-Wealth800">
              {t('navigator.yourInvestmentForecastEditContributions.subtitle')}
            </Text>
            <Controller
              name="projectionEditContributions"
              control={control}
              render={({ field: { value, onChange } }) => {
                const {
                  projectionEditContributionsDeposit,
                  projectionEditContributionsMonthlyPayment,
                } = value;
                return (
                  <>
                    <YStack
                      style={{
                        flex: 1,
                        marginTop: tokens.space.xxl.val,
                      }}
                    >
                      <InputFieldWithInfo
                        label={t(
                          'navigator.yourInvestmentForecastEditContributions.contributionTitle'
                        )}
                        showBorder={false}
                        field={
                          <NumberInput
                            allowDecimal={false}
                            required
                            symbol="prefix"
                            tamaguiInputProps={{
                              value: determineDepositValue(
                                projectionEditContributionsDeposit
                              ),
                              onChangeText: (newText: string) => {
                                value.projectionEditContributionsDeposit =
                                  Number(newText);
                                onChange(value);
                              },
                              placeholder: t(
                                'navigator.contributions.DEPOSIT_AMOUNT_PLACEHOLDER'
                              ),
                            }}
                          />
                        }
                      />
                    </YStack>
                    <YStack
                      style={{
                        flex: 1,
                        marginTop: tokens.space.xxl.val,
                      }}
                      marginBottom="$xxl"
                    >
                      <InputFieldWithInfo
                        label={t(
                          'navigator.contributions.MONTHLY_AMOUNT_TITLE'
                        )}
                        showBorder={false}
                        field={
                          <NumberInput
                            allowDecimal={false}
                            required
                            symbol="prefix"
                            tamaguiInputProps={{
                              value: determineMonthlyValue(
                                projectionEditContributionsMonthlyPayment
                              ),
                              onChangeText: (newText: string) => {
                                value.projectionEditContributionsMonthlyPayment =
                                  Number(newText);
                                onChange(value);
                              },
                              placeholder: t(
                                'navigator.contributions.MONTHLY_AMOUNT_PLACEHOLDER'
                              ),
                            }}
                          />
                        }
                      />
                    </YStack>
                  </>
                );
              }}
            />
            <Theme name="wealth">
              <Controller
                name="projectionEditContributions.duration"
                control={control}
                render={({ field: { onChange, value } }) => {
                  return (
                    <Theme name="wealth">
                      <FormCounter
                        accessibilityLabel="Investment years"
                        buttonVariant={ButtonVariant.SUB_BRAND}
                        min={0}
                        max={40}
                        value={value}
                        onChange={(newValueStr: string) => {
                          const newValue = parseInt(newValueStr, 10);
                          onChange(newValue);
                        }}
                        onIncrease={() => {
                          if (value) {
                            onChange(value + 1);
                          } else {
                            onChange(1);
                          }
                        }}
                        onDecrease={() => {
                          value && onChange(value - 1);
                        }}
                        title={t(
                          'navigator.yourInvestmentForecastEditContributions.durationTitle'
                        )}
                        required
                      />
                    </Theme>
                  );
                }}
              />
            </Theme>
          </YStack>

          <View style={{ flex: 1 }} />
          <YStack tabletNarrow={isIpad} testID={getTestId('buttonContainer')}>
            <Button
              accessibilityHint={t(
                'navigator.yourInvestmentForecastEditContributions.accessibilityUpdateButton'
              )}
              mb="$xxl"
              mt="$xxl"
              marginHorizontal="$lg"
              onPress={handleFormSubmit}
              disabled={!isValid || isEmpty}
            >
              {t('navigator.common.update')}
            </Button>
          </YStack>
          <Dialog
            open={modalVisible}
            title={t('navigator.contributions.EXCEED_AMOUNT_WARNING_TITLE')}
            copy={modalText}
          >
            <Stack space="$md" marginTop="$xl">
              <Button
                onPress={() => setModalVisible(false)}
                accessibilityHint={t(
                  'navigator.yourInvestmentForecastEditContributions.accessibilityDialogOkayButton'
                )}
              >
                {t('navigator.common.okay')}
              </Button>
            </Stack>
          </Dialog>
          <IncreasedContributionsPopup
            isVisible={increasedContributionsPopupVisible}
            onClosePress={() => {
              setIncreasedContributionsPopupVisible(false);
            }}
            onConfirmPress={handlePopUpConfirm}
          />

          <DynamicHeightModal
            backgroundColor="WealthBlue"
            closeIconColor={'White'}
            isOpen={isModalVisibleDuration}
            onClose={onClosePress}
          >
            <Text
              tamaguiTextProps={{ pb: '$md' }}
              fontVariant="heading3-semibold-White"
            >
              {t('navigator.duration.MODAL_TITLE')}
            </Text>
            <Text fontVariant="body-regular-White">
              {t('navigator.duration.MODAL_CONTENT')}
            </Text>

            <TextWithLinks
              fontVariant="body-regular-White"
              template={t('navigator.duration.AVIVA_SAVE_CONTENT')}
              testID="aviva-save"
              tamaguiTextProps={{ pb: '$xxl' }}
              links={{
                avivaSaveMarketplace: {
                  text: t('navigator.duration.AVIVA_SAVE_TEXT'),
                  accessibilityHint: t(
                    'navigator.duration.AVIVA_SAVE_LINK_HINT'
                  ),
                  onPress: onAvivaSaveLinkPress,
                  props: linkProps,
                },
                moneyhelperHTS: {
                  text: t('navigator.duration.MONEY_HELPER_HTS_TEXT'),
                  accessibilityHint: t(
                    'navigator.duration.AVIVA_SAVE_LINK_HINT'
                  ),
                  onPress: onMoneyhelperLinkPress,
                  props: linkProps,
                },
              }}
            />

            <Button
              mb="$xl"
              mt="$xl"
              onPress={onChooseDifferentDurationPress}
              textProps={{
                color: tokens.color.Secondary800.val,
              }}
            >
              {t('navigator.duration.MODAL_BUTTON_TEXT')}
            </Button>
            <Link
              onPress={onExitAdviceLinkPress}
              style={{
                alignSelf: 'center',
              }}
              accessibilityLabel={t('navigator.duration.EXIT_ADVICE')}
              accessibilityHint={t('navigator.duration.EXIT_ADVICE')}
              testID={getTestId('exit-advice-link')}
              LinkTextProps={{ color: tokens.color.Primary500.val }}
            >
              {t('navigator.duration.EXIT_ADVICE')}
            </Link>
          </DynamicHeightModal>
        </ScrollView>
      </FocusKeyboardAvoidingView>
      {apiErrorVisible && (
        <ErrorDialog open onPress={() => setApiErrorVisible(false)} center />
      )}
      {isLoading && (
        <LoadingState
          title={t('loading.pleaseWait')}
          text={t('loading.nextStep')}
        />
      )}
    </>
  );
};
