import {
  Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_HighGrowthRateProjection,
  Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_LowGrowthRateProjection,
  Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_MediumGrowthRateProjection,
  Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_Projections,
} from '@src/api/generated/requests';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import ReactNativeFusionCharts, {
  ChartObject,
} from 'react-native-fusioncharts';

type DataPoint = {
  value: number;
};

type Category = {
  label: string;
  showLabel: boolean;
};

type ProjectionChartProps = {
  apiProjectionData: Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_Projections;
  initialContribution: number;
};

const getChartDataPoints = (
  lowApiData: Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_LowGrowthRateProjection[],
  midApiData: Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_MediumGrowthRateProjection[],
  highApiData: Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_Navigator_FactFindQuestionnaire_Model_HighGrowthRateProjection[],
  initialContribution: number,
  term: number
) => {
  const lowData = new Array<DataPoint>();
  const midData = new Array<DataPoint>();
  const highData = new Array<DataPoint>();

  lowData.push({ value: initialContribution });
  midData.push({ value: initialContribution });
  highData.push({ value: initialContribution });

  for (let i = 0; i < term; i++) {
    lowData.push({ value: lowApiData?.[i].value ?? 0 });
    midData.push({ value: midApiData?.[i].value ?? 0 });
    highData.push({ value: highApiData?.[i].value ?? 0 });
  }

  return {
    lowData,
    midData,
    highData,
  };
};

export const getAxisLabels = (term: number) => {
  const maxAllowedLabels = 6;
  const labelStep = Math.ceil(term / maxAllowedLabels);
  const categories = new Array<Category>();

  categories.push({ label: '', showLabel: false });
  for (let i = 1; i <= term; i++) {
    categories.push({
      label: `${i}Y`,
      showLabel: i % labelStep === 0,
    });
  }

  return categories;
};

export const YourInvestmentForecastChart = ({
  apiProjectionData,
  initialContribution,
}: ProjectionChartProps) => {
  const { t } = useTranslationDW({ keyPrefix: 'navigator.projections' });

  if (
    apiProjectionData.lowGrowthRateProjections == null ||
    apiProjectionData.mediumGrowthRateProjections == null ||
    apiProjectionData.highGrowthRateProjections == null
  ) {
    return;
  }

  const term = apiProjectionData.lowGrowthRateProjections?.length ?? 0;

  const { lowData, midData, highData } = getChartDataPoints(
    apiProjectionData.lowGrowthRateProjections,
    apiProjectionData.mediumGrowthRateProjections,
    apiProjectionData.highGrowthRateProjections,
    initialContribution,
    term
  );

  const chartData = [
    {
      seriesname: t('low'),
      includeInLegend: 0,
      color: tokens.color.RoseLight.val,
      data: lowData,
    },
    {
      seriesname: t('mid'),
      includeInLegend: 0,
      color: tokens.color.BlueMid.val,
      data: midData,
    },
    {
      seriesname: t('high'),
      includeInLegend: 0,
      color: tokens.color.Primary400.val,
      data: highData,
    },
  ];

  const chartConfig: ChartObject = {
    type: 'msspline',
    width: '100%',
    height: 320,
    dataFormat: 'json',
    dataSource: {
      chart: {
        bgAlpha: 100,
        bgColor: tokens.color.WealthBlue95.val,
        canvasBgColor: tokens.color.WealthBlue95.val,
        baseFont: 'Arial',
        canvasBgAlpha: 100,
        divLineDashed: 1,
        divLineDashLen: tokens.space['0.5'],
        divLineDashGap: tokens.space.sm.val,
        drawAnchors: 0,
        drawCrossLine: 1,
        crossLineAlpha: 100,
        crossLineColor: tokens.color.WealthBlue45.val,
        formatNumber: 1,
        formatNumberScale: 1,
        labelDisplay: 'NONE',
        labelFontColor: tokens.color.WealthBlue45.val,
        lineThickness: 2,
        setAdaptiveYMin: true,
        theme: 'fusion',
        yAxisBgColor: tokens.color.DWPrimary500.val,
        yAxisValueFontColor: tokens.color.White.val,
      },
      categories: [
        {
          category: getAxisLabels(term),
        },
      ],
      dataset: chartData,
    },
  };

  return <ReactNativeFusionCharts chartConfig={chartConfig} />;
};
