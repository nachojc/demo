import {
  Button,
  Icon,
  Image,
  ScrollView,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { config } from '@src/common/config';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { SafeAreaView } from 'react-native';

import { useSimpleWealthStackNavigation } from '../navigation/hooks';
import { useSimpleWealthAccountService } from '../simple-wealth-hub/use-simple-wealth-account-service';
import {
  PAY_NOW,
  YOUR_INVESTMENT_FORECAST_RECOMMENDATION_MODAL,
} from './your-investment-forecast-recommendation-screen/analytics';

export const YourInvestmentForecastRecommendationScreen = () => {
  const { avivaSimpleWealth } = useSimpleWealthAccountService();
  const amount = avivaSimpleWealth?.person?.opportunity?.amount ?? 0;
  const { t } = useTranslationDW({ keyPrefix: 'navigator' });

  const { navigate } = useSimpleWealthStackNavigation();

  const { trackUserEvent, trackStateEvent } = useAnalytics();

  trackStateEvent(YOUR_INVESTMENT_FORECAST_RECOMMENDATION_MODAL);
  const imageUrl =
    config.CONTENT_BASE_URL.get() +
    '/shared/mobile/dw/aviva-man-investment-forecast.png';

  const handlePayTapped = () => {
    trackUserEvent(PAY_NOW);
    navigate('UsefulInfo');
  };

  return (
    <SafeAreaView
      style={{
        height: '100%',
      }}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ flexGrow: 1 }}
        style={{ paddingHorizontal: tokens.space.xxl.val }}
      >
        <YStack
          tabletNarrow={isIpad}
          testID={getTestId('your-investment-forecast-recommendation')}
          flex={1}
          justifyContent="center"
        >
          <XStack alignSelf="center" mt="auto" mb="auto">
            <YStack alignItems="center">
              <Image
                accessibilityIgnoresInvertColors
                source={{ uri: imageUrl }}
                resizeMode="contain"
                style={{
                  width: tokens.size[16].val,
                  height: tokens.size[16].val,
                }}
              />
              <Text
                fontVariant="heading4-semibold-White"
                tamaguiTextProps={{ mb: '$md', mt: '$xxl' }}
              >
                {t('yourInvestmentForecastRecommendationModal.subtitle')}
              </Text>
              <Text
                fontVariant="heading5-regular-Gray250"
                tamaguiTextProps={{
                  marginHorizontal: '$md',
                  textAlign: 'center',
                }}
              >
                {t('yourInvestmentForecastRecommendationModal.message')}
              </Text>
            </YStack>
          </XStack>
          {amount !== 0 ? (
            <YStack
              tabletNarrow={isIpad}
              testID={getTestId('pay-now-container')}
            >
              <Button
                icon={<Icon name="credit-card" />}
                mt="$xxxl"
                marginHorizontal="$xl"
                testID={getTestId('pay-now-button')}
                onPress={handlePayTapped}
                accessibilityHint={t(
                  'yourInvestmentForecastRecommendationModal.payButtonA11yHint'
                )}
                gap="$md"
              >
                {`${t(
                  'yourInvestmentForecastRecommendationModal.payButton'
                )} ${formatCurrencyValue(amount)}`}
              </Button>
            </YStack>
          ) : null}
        </YStack>
      </ScrollView>
    </SafeAreaView>
  );
};
