import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';

import { SimpleWealthStackRouteParams, SimpleWealthStackScreenNames } from '.';

export type SimpleWealthStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<SimpleWealthStackRouteParams>,
  NativeStackNavigationProp<Pick<AppStackDWRouteParams, 'ProductDashboard'>>
>;

export type SimpleWealthStackRoute<
  T extends keyof SimpleWealthStackRouteParams
> = RouteProp<SimpleWealthStackRouteParams, T>;

/**
 * @description A typed wrapper around useRoute
 *
 * @T
 * T is the name of the screen from which you're calling this hook
 * It must be a key of SimpleWealthStackRouteParams
 */
export function useSimpleWealthStackRoute<
  T extends SimpleWealthStackScreenNames
>() {
  return useRoute<SimpleWealthStackRoute<T>>();
}

/**
 * @description A typed wrapper around useNavigation
 *
 * For use within the SimpleWealth navigation stack
 */
export function useSimpleWealthStackNavigation() {
  return useNavigation<SimpleWealthStackNavigation>();
}
