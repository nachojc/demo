import { getTokens, getVariableValue, TopAppBarDW } from '@aviva/ion-mobile';
import { PAGE_WEALTH } from '@constants/analytics';
import { useNavigateToDashboard } from '@hooks/use-navigate-to-dashboard';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { PSP } from '@src/validation/schemas/pension-payment-methods';

import { ADVICE_SUMMARY_COSTS_AND_CHARGES } from '../advice-summary/advice-summary-costs-and-charges/analytics';
import { ADVICE_SUMMARY_GOALS } from '../advice-summary/advice-summary-goals/analytics';
import { ADVICE_SUMMARY_IMPORTANT_POINTS } from '../advice-summary/advice-summary-important-points/analytics';
import { ADVICE_SUMMARY_INVESTMENT_STYLE } from '../advice-summary/advice-summary-investment-style/analytics';
import { ADVICE_SUMMARY_NEXT_STEPS } from '../advice-summary/advice-summary-next-steps/analytics';
import { ADVICE_SUMMARY_RECOMMENDATION } from '../advice-summary/advice-summary-recommendation/analytics';
import { useAdviceSummaryCloseNavigation } from '../advice-summary/use-advice-summary-navigation/use-advice-summary-close-navigation';
import {
  AdviceSummaryRouteParams,
  AdviceSummaryScreenNames,
} from '../advice-summary/use-advice-summary-navigation/use-advice-summary-navigation';
import { BOOK_A_CALL_SCREEN } from '../payment/book-a-call/analytics';
import {
  BILL_PAYMENTS_KICKOUT_SCREEN,
  BILL_PAYMENTS_SCREEN,
} from '../your-financial-situation/affordability/bill-payments-screen/analytics';
import {
  CHANGE_PAYMENT_AMOUNT_KICKOUT_SCREEN,
  CHANGE_PAYMENT_AMOUNT_SCREEN,
} from '../your-financial-situation/affordability/change-payment-amount-screen/analytics';
import {
  EMERGENCY_SAVINGS_KICKOUT_SCREEN,
  EMERGENCY_SAVINGS_SCREEN,
} from '../your-financial-situation/affordability/emergency-savings-screen/analytics';
import {
  HIGH_INTEREST_DEBT_KICKOUT,
  HIGH_INTEREST_DEBT_SCREEN,
} from '../your-financial-situation/affordability/high-interest-debt-screen/analytics';
import { INVESTING_IMPACT_SCREEN } from '../your-financial-situation/affordability/investing-impact-screen/analytics';
import {
  INVESTMENT_PLANS_KICKOUT_SCREEN,
  INVESTMENT_PLANS_SCREEN,
} from '../your-financial-situation/affordability/investment-plans-screen/analytics';
import { LOSS_OF_INCOME_SCREEN } from '../your-financial-situation/affordability/loss-of-income-screen/analytics';
import { PREREQUISITES_SCREEN } from '../your-financial-situation/eligibility/prerequisites-screen/analytics';
import { YOUR_FINANCIAL_SITUATION_INTRO_SCREEN } from '../your-financial-situation/intro-screen/analytics';
import { CONTRIBUTIONS_SCREEN } from '../your-financial-situation/investment-goals/contributions-screen/analytics';
import { DURATION_SCREEN } from '../your-financial-situation/investment-goals/duration-screen/analytics';
import {
  FINANCIAL_GOAL,
  FINANCIAL_SITUATION,
} from '../your-financial-situation/investment-goals/financial-goal-screen/analytics';
import {
  FINANCIAL_PROTECTION_KICKOUT_SCREEN,
  FINANCIAL_PROTECTION_SCREEN,
} from '../your-financial-situation/personal-situation/financial-protection-screen/analytics';
import {
  WORKPLACE_PENSION_KICKOUT_SCREEN,
  WORKPLACE_PENSION_SCREEN,
} from '../your-financial-situation/personal-situation/workplace-pension-screen/analytics';
import { REVIEW_SCREEN } from '../your-financial-situation/review/review-screen/analytics';
import {
  ASSUMPTIONS_SCREEN,
  YOUR_INVESTMENT_FORECAST_EDIT_CONTRIBUTIONS_SCREEN,
} from '../your-investment-forecast/analytics';
import { INVESTMENT_STYLE_SCREEN } from '../your-investment-style/investment-style-screen/analytics';
import {
  ADVICE,
  KEY_ISA_DOCUMENTS,
  PAYMENT,
  PAYMENT_NOT_PROCESSED,
  SIMPLE_WEALTH,
  SIMPLE_WEALTH_POST_PAYMENT,
  SUCCESS_PAGE,
  YOUR_INVESTMENT_STYLE,
} from './header/analytics';
import { simpleWealthHeader } from './header/simple-wealth-header';
import { useSimpleWealthStackNavigation } from './hooks';
import { NavigatorProvider } from './provider';

export type SimpleWealthStackRouteParams = NavigatorRouteParams &
  AdviceSummaryRouteParams;

type NavigatorRouteParams = {
  ['PortfolioSummary']: undefined;
  ['SimpleWealthHub']: undefined;
  ['YourFinancialSituationIntro']: undefined;
  ['YourInvestmentStyleQuestions']: { Question: number; reset?: boolean };
  ['OnboardingInformationScreen']: {
    removeContinueButton: boolean;
    amount: number;
  };
  ['OnboardingInformationScreenPush']: {
    removeContinueButton: boolean;
    amount: number;
  };
  //TODO Look to remove this Web View screen following completion of DW into MANGA and use AppStackNavigation for the web jump
  // - The aim being to avoid unnecessary duplication of web view screens - ticket raised: MANGA-13964
  ['Web View']: {
    url: string;
    ssoEnabled?: boolean;
    appendVisitorInfoEnabled?: boolean;
  };
  ['PrerequisitesScreen']: undefined;
  ['FinancialGoalScreen']: undefined;
  ['DurationScreen']: undefined;
  ['ContributionsScreen']: undefined;
  ['EmergencySavingsScreen']: undefined;
  ['EmergencySavingsKickoutScreen']: undefined;
  ['InvestingImpactScreen']: undefined;
  ['InvestmentStyleScreen']: undefined;
  ['ChangePaymentAmountScreen']: undefined;
  ['ChangePaymentAmountKickoutScreen']: undefined;
  ['HighInterestDebtScreen']: undefined;
  ['HighInterestDebtKickoutScreen']: undefined;
  ['BillPaymentsScreen']: undefined;
  ['BillPaymentsKickoutScreen']: undefined;
  ['LossOfIncomeScreen']: undefined;
  ['InvestmentPlansScreen']: undefined;
  ['FinancialGoalKickoutScreen']: {
    investmentType: string;
  };
  ['InvestmentPlansKickoutScreen']: undefined;
  ['FinancialProtectionScreen']: undefined;
  ['FinancialProtectionKickoutScreen']: undefined;
  ['WorkplacePensionScreen']: undefined;
  ['WorkplacePensionKickoutScreen']: undefined;
  ['ReviewScreen']: undefined;
  ['IntroductionScreen']: undefined;
  ['YourInvestmentForecastIntroduction']: undefined;
  ['BookACall']: undefined;
  ['YourInvestmentForecastGoals']: {
    hasConfirmedYourInvestmentForecast: boolean;
  };
  ['YourInvestmentForecastEditContributions']: undefined;
  ['YourInvestmentForecastRecommendationScreen']: undefined;
  ['YourInvestmentForecastAssumptions']: undefined;
  ['AdditionalInfo']: {
    paymentCorrelationId: string;
    clientKey: string | null;
    ShouldCaptureBillingAddress: boolean;
    ShouldCaptureCardHolderName: boolean;
    psp: string;
    pspData: PSP;
  };
  ['UsefulInfo']: undefined;
  ['PostPaymentHub']: undefined;
  ['PaymentSuccessScreen']: undefined;
  ['PaymentNotProcessed']: undefined;
  ['KeyISAInformationScreen']: undefined;
};

export type SimpleWealthStackScreenNames = keyof SimpleWealthStackRouteParams;

const Stack = createNativeStackNavigator<SimpleWealthStackRouteParams>();

export const SimpleWealthStack = () => {
  const tokens = getTokens();
  const { t } = useTranslationDW({ keyPrefix: 'navigator' });
  const { navigate } = useSimpleWealthStackNavigation();
  const { navigateToDashboard } = useNavigateToDashboard();

  const { onClose } = useAdviceSummaryCloseNavigation();

  const digitalAdviceBackNavigation = () => {
    navigate('PostPaymentHub');
  };

  const navigatorPrePaymentHub = () => {
    navigate('SimpleWealthHub');
  };

  const digitalAdviceCloseNavigation = (
    currentScreen: AdviceSummaryScreenNames
  ) => {
    onClose(currentScreen);

    navigate('PostPaymentHub');
  };

  return (
    <NavigatorProvider>
      <Stack.Navigator
        initialRouteName="SimpleWealthHub"
        screenOptions={{
          headerShown: true,
          header: TopAppBarDW,
        }}
      >
        <Stack.Group
          screenOptions={{
            contentStyle: {
              backgroundColor: getVariableValue(tokens.color.White),
            },
          }}
        >
          <Stack.Screen
            name="SimpleWealthHub"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/simple-wealth-hub/simple-wealth-hub')
                .SimpleWealthHub
            }
            options={() => ({
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH}`,
                  handleBackButton: navigateToDashboard,
                  handleCloseButton: navigateToDashboard,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="YourFinancialSituationIntro"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/intro-screen/your-financial-situation-intro-screen')
                .YourFinancialSituationIntroScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: YOUR_FINANCIAL_SITUATION_INTRO_SCREEN,
                  closeButton: false,
                  title: '',
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="OnboardingInformationScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/simple-wealth-hub/onboarding-information-screen/onboarding-information-screen')
                .OnboardingInformationScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH}`,
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="OnboardingInformationScreenPush"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/simple-wealth-hub/onboarding-information-screen/onboarding-information-screen')
                .OnboardingInformationScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH}`,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="PrerequisitesScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/eligibility/prerequisites-screen')
                .PrerequisitesScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: PREREQUISITES_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="FinancialGoalScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/investment-goals/financial-goal-screen')
                .FinancialGoalScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: FINANCIAL_GOAL,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="DurationScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/investment-goals/duration-screen')
                .DurationScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: DURATION_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="ContributionsScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/investment-goals/contributions-screen')
                .ContributionsScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: CONTRIBUTIONS_SCREEN,
                  title: t('header.INVESTMENT_GOALS'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="EmergencySavingsScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/emergency-savings-screen/')
                .EmergencySavingsScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: EMERGENCY_SAVINGS_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="EmergencySavingsKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/emergency-savings-screen/emergency-savings-kickout-screen')
                .EmergencySavingsKickoutScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: EMERGENCY_SAVINGS_KICKOUT_SCREEN,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="InvestingImpactScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/investing-impact-screen')
                .InvestingImpactScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: INVESTING_IMPACT_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="ChangePaymentAmountScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/change-payment-amount-screen/')
                .ChangePaymentAmountScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: CHANGE_PAYMENT_AMOUNT_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="ChangePaymentAmountKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/change-payment-amount-screen/change-payment-amount-kickout-screen')
                .ChangePaymentAmountKickoutScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: CHANGE_PAYMENT_AMOUNT_KICKOUT_SCREEN,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="HighInterestDebtScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/high-interest-debt-screen/')
                .HighInterestDebtScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: HIGH_INTEREST_DEBT_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="FinancialGoalKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/investment-goals/financial-goal-screen/')
                .FinancialGoalKickoutScreen
            }
            options={({ route }) => {
              const pageTag =
                FINANCIAL_SITUATION + '|' + route.params?.investmentType;

              return {
                header: (props) =>
                  simpleWealthHeader({
                    pageAnalyticsTag: pageTag,
                    title: '',
                    closeButton: false,
                    ...props,
                  }),
              };
            }}
          />
          <Stack.Screen
            name="HighInterestDebtKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/high-interest-debt-screen/')
                .HighInterestDebtKickoutScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: HIGH_INTEREST_DEBT_KICKOUT,
                  title: '',
                  ...props,
                  closeButton: false,
                }),
            }}
          />
          <Stack.Screen
            name="BillPaymentsScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/bill-payments-screen/')
                .BillPaymentsScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: BILL_PAYMENTS_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="BillPaymentsKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/bill-payments-screen/bill-payments-kickout-screen')
                .BillPaymentsKickoutScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: BILL_PAYMENTS_KICKOUT_SCREEN,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="LossOfIncomeScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/loss-of-income-screen/')
                .LossOfIncomeScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: LOSS_OF_INCOME_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="InvestmentPlansScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/investment-plans-screen/')
                .InvestmentPlansScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: INVESTMENT_PLANS_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="InvestmentPlansKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/affordability/investment-plans-screen/investment-plans-kickout-screen')
                .InvestmentPlansKickoutScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: INVESTMENT_PLANS_KICKOUT_SCREEN,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="FinancialProtectionScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/personal-situation/financial-protection-screen/')
                .FinancialProtectionScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: FINANCIAL_PROTECTION_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="FinancialProtectionKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/personal-situation/financial-protection-screen/financial-protection-kickout-screen')
                .FinancialProtectionKickoutScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: FINANCIAL_PROTECTION_KICKOUT_SCREEN,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="WorkplacePensionScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/personal-situation/workplace-pension-screen')
                .WorkplacePensionScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: WORKPLACE_PENSION_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="WorkplacePensionKickoutScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/personal-situation/workplace-pension-screen/workplace-pension-kickout-screen')
                .WorkplacePensionKickoutScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: WORKPLACE_PENSION_KICKOUT_SCREEN,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="ReviewScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-financial-situation/review/review-screen/review-screen')
                .ReviewScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: REVIEW_SCREEN,
                  title: t('header.FINANCIAL_SITUATION'),
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="IntroductionScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-investment-style/introduction-screen/introduction-screen')
                .IntroductionScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: REVIEW_SCREEN,
                  title: '',
                  theme: 'directWealth',
                  backgroundColor: tokens.color.WealthBlue95.val,
                  closeButton: false,
                  ...props,
                }),
            }}
          />
          <Stack.Screen
            name="InvestmentStyleScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/your-investment-style/investment-style-screen/investment-style-screen')
                .InvestmentStyleScreen
            }
            options={({ navigation }) => {
              return {
                header: (props) =>
                  simpleWealthHeader({
                    pageAnalyticsTag: INVESTMENT_STYLE_SCREEN,
                    title: '',
                    theme: 'light',
                    backgroundColor: tokens.color.Gray050.val,
                    closeButton: false,
                    handleBackButton: () => {
                      navigation.navigate('SimpleWealthHub');
                    },
                    ...props,
                  }),
              };
            }}
          />
          <Stack.Screen
            name="YourInvestmentStyleQuestions"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/your-investment-style/your-investment-style-screens.tsx')
                .YourInvestmentStyleScreen
            }
            options={({ navigation, route }) => {
              const question = route.params?.Question;

              return {
                header: (props) =>
                  simpleWealthHeader({
                    pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${YOUR_INVESTMENT_STYLE}`,
                    title: t('header.INVESTMENT_STYLE'),
                    handleBackButton: () => {
                      question === 1
                        ? navigation.navigate('SimpleWealthHub')
                        : navigation.goBack();
                    },
                    ...props,
                    back: {
                      title:
                        question === 1
                          ? 'Navigator Hub screen'
                          : 'previous question',
                    },
                  }),
              };
            }}
          />
          <Stack.Screen
            name="YourInvestmentForecastIntroduction"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/your-investment-forecast/your-investment-forecast-intro-screen.tsx')
                .YourInvestmentForecastIntro
            }
            options={() => ({
              contentStyle: {
                backgroundColor: getVariableValue(tokens.color.WealthBlue),
              },
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: ``,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="YourInvestmentForecastRecommendationScreen"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/your-investment-forecast/your-investment-forecast-recommendation-screen.tsx')
                .YourInvestmentForecastRecommendationScreen
            }
            options={() => ({
              contentStyle: {
                backgroundColor: getVariableValue(tokens.color.WealthBlue),
              },
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: ``,
                  title: t('yourInvestmentForecastRecommendationModal.title'),
                  closeButton: true,
                  shouldShowBackIcon: false,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="BookACall"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/payment/book-a-call/book-a-call-screen.tsx')
                .BookACall
            }
            options={() => ({
              contentStyle: {
                backgroundColor: getVariableValue(tokens.color.WealthBlue),
              },
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: BOOK_A_CALL_SCREEN,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="YourInvestmentForecastGoals"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/your-investment-forecast/your-investment-forecast-goals-screen.tsx')
                .YourInvestmentForecastGoals
            }
            options={() => ({
              contentStyle: {
                backgroundColor: getVariableValue(tokens.color.WealthBlue),
              },
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: ``,
                  title: '',
                  closeButton: false,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="YourInvestmentForecastAssumptions"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/your-investment-forecast/your-investment-forecast-assumptions-screen.tsx')
                .YourInvestmentForecastAssumptions
            }
            options={() => ({
              contentStyle: {
                backgroundColor: getVariableValue(tokens.color.WealthBlue),
              },
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: `${ASSUMPTIONS_SCREEN}`,
                  title: '',
                  closeButton: false,
                  ...props,
                  back: {
                    title: 'Projections',
                  },
                }),
            })}
          />
          <Stack.Screen
            name="YourInvestmentForecastEditContributions"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/your-investment-forecast/your-investment-forecast-edit-contributions-screen.tsx')
                .YourInvestmentForecastEditContributions
            }
            options={() => ({
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag:
                    YOUR_INVESTMENT_FORECAST_EDIT_CONTRIBUTIONS_SCREEN,
                  title: '',
                  closeButton: false,
                  theme: 'plain',
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="UsefulInfo"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/payment/useful-info/useful-info-screen.tsx')
                .UsefulInfoScreen
            }
            options={() => ({
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: ``,
                  title: 'Payment',
                  handleBackButton: navigatorPrePaymentHub,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="AdditionalInfo"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/payment/additional-info/additional-info-screen.tsx')
                .AdditionalInfoScreen
            }
            options={() => ({
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: ``,
                  title: 'Payment',
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="PostPaymentHub"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/post-payment-hub/post-payment-hub-screen.tsx')
                .PostPaymentHub
            }
            options={() => ({
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH_POST_PAYMENT}`,
                  title: '',
                  closeButton: false,
                  handleBackButton: navigateToDashboard,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="PaymentSuccessScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/payment-success/payment-success-screen.tsx')
                .PaymentSuccessScreen
            }
            options={({ navigation }) => {
              return {
                header: (props) =>
                  simpleWealthHeader({
                    pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${PAYMENT}|${SUCCESS_PAGE}`,
                    title: 'Payment',
                    closeButton: false,
                    shouldShowBackIcon: false,
                    handleBackButton: () => {
                      navigation.navigate('SimpleWealthHub');
                    },
                    ...props,
                  }),
              };
            }}
          />
          <Stack.Screen
            name="PaymentNotProcessed"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/payment/payment-not-processed/payment-not-processed-screen.tsx')
                .PaymentNotProcessedScreen
            }
            options={({ navigation }) => {
              return {
                header: (props) =>
                  simpleWealthHeader({
                    pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${PAYMENT}|${PAYMENT_NOT_PROCESSED}`,
                    title: 'Payment',
                    handleBackButton: () => {
                      navigation.navigate('SimpleWealthHub');
                    },
                    ...props,
                  }),
              };
            }}
          />
          <Stack.Screen
            name="AdviceSummaryIntro"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/advice-summary/advice-summary-intro/advice-summary-intro.tsx')
                .AdviceSummaryIntro
            }
            options={({ navigation }) => ({
              contentStyle: {
                backgroundColor: getVariableValue(tokens.color.WealthBlue),
              },
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: `${PAGE_WEALTH}|${SIMPLE_WEALTH}|${ADVICE}`,
                  title: '',
                  handleBackButton: () => {
                    onClose('AdviceSummaryIntro');
                    navigation.goBack();
                  },
                  closeButton: false,
                  ...props,
                }),
            })}
          />
          <Stack.Screen
            name="AdviceSummaryGoals"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/advice-summary/advice-summary-goals/advice-summary-goals.tsx')
                .AdviceSummaryGoals
            }
            options={() => ({
              contentStyle: { backgroundColor: tokens.color.Tertiary800.val },
              header: (props) =>
                simpleWealthHeader({
                  ...props,
                  pageAnalyticsTag: `${ADVICE_SUMMARY_GOALS}`,
                  title: 'Advice Summary',
                  backgroundColor: tokens.color.Tertiary800.val,
                  back: undefined,
                  handleBackButton: digitalAdviceBackNavigation,
                  handleCloseButton: () => {
                    digitalAdviceCloseNavigation('AdviceSummaryGoals');
                  },
                }),
            })}
          />
          <Stack.Screen
            name="AdviceSummaryInvestmentStyle"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/advice-summary/advice-summary-investment-style/advice-summary-investment-style.tsx')
                .AdviceSummaryInvestmentStyle
            }
            options={() => ({
              contentStyle: { backgroundColor: tokens.color.Gray050.val },
              header: (props) =>
                simpleWealthHeader({
                  ...props,
                  pageAnalyticsTag: `${ADVICE_SUMMARY_INVESTMENT_STYLE}`,
                  title: 'Advice Summary',
                  backgroundColor: tokens.color.Gray050.val,
                  back: undefined,
                  theme: 'light',
                  handleBackButton: digitalAdviceBackNavigation,
                  handleCloseButton: digitalAdviceBackNavigation,
                }),
            })}
          />
          <Stack.Screen
            name="AdviceSummaryRecommendation"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/advice-summary/advice-summary-recommendation/advice-summary-recommendation.tsx')
                .AdviceSummaryRecommendation
            }
            options={() => ({
              header: (props) =>
                simpleWealthHeader({
                  ...props,
                  pageAnalyticsTag: `${ADVICE_SUMMARY_RECOMMENDATION}`,
                  title: 'Advice Summary',
                  backgroundColor: tokens.color.NavigatorBlue.val,
                  back: undefined,
                  theme: 'light',
                  handleBackButton: digitalAdviceBackNavigation,
                  handleCloseButton: digitalAdviceBackNavigation,
                }),
            })}
          />
          <Stack.Screen
            name="AdviceSummaryCostsAndCharges"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/advice-summary/advice-summary-costs-and-charges/advice-summary-costs-and-charges.tsx')
                .AdviceSummaryCostsAndCharges
            }
            options={() => ({
              contentStyle: { backgroundColor: tokens.color.Gray050.val },
              header: (props) =>
                simpleWealthHeader({
                  ...props,
                  pageAnalyticsTag: `${ADVICE_SUMMARY_COSTS_AND_CHARGES}`,
                  title: 'Advice Summary',
                  backgroundColor: tokens.color.Gray050.val,
                  back: undefined,
                  theme: 'light',
                  handleBackButton: digitalAdviceBackNavigation,
                  handleCloseButton: digitalAdviceBackNavigation,
                }),
            })}
          />
          <Stack.Screen
            name="AdviceSummaryImportantPoints"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/advice-summary/advice-summary-important-points/advice-summary-important-points.tsx')
                .AdviceSummaryImportantPoints
            }
            options={() => ({
              contentStyle: { backgroundColor: tokens.color.WealthBlue.val },
              header: (props) =>
                simpleWealthHeader({
                  ...props,
                  pageAnalyticsTag: `${ADVICE_SUMMARY_IMPORTANT_POINTS}`,
                  title: 'Advice Summary',
                  backgroundColor: tokens.color.WealthBlue.val,
                  back: undefined,
                  handleBackButton: digitalAdviceBackNavigation,
                  handleCloseButton: digitalAdviceBackNavigation,
                }),
            })}
          />
          <Stack.Screen
            name="AdviceSummaryNextSteps"
            getComponent={() =>
              require('products/direct-wealth/features/simple-wealth/advice-summary/advice-summary-next-steps/advice-summary-next-steps.tsx')
                .AdviceSummaryNextSteps
            }
            options={() => ({
              header: (props) =>
                simpleWealthHeader({
                  ...props,
                  pageAnalyticsTag: `${ADVICE_SUMMARY_NEXT_STEPS}`,
                  title: 'Advice Summary',
                  backgroundColor: tokens.color.White.val,
                  theme: 'light',
                  back: undefined,
                  handleBackButton: digitalAdviceBackNavigation,
                  handleCloseButton: digitalAdviceBackNavigation,
                }),
            })}
          />
          <Stack.Screen
            name="KeyISAInformationScreen"
            getComponent={() =>
              require('@direct-wealth/features/simple-wealth/key-isa-information/key-isa-information-screen.tsx')
                .KeyISAInformationScreen
            }
            options={{
              header: (props) =>
                simpleWealthHeader({
                  pageAnalyticsTag: KEY_ISA_DOCUMENTS,
                  title: 'Key ISA information',
                  closeButton: false,
                  ...props,
                }),
            }}
          />
        </Stack.Group>
        <Stack.Screen
          name="Web View"
          getComponent={() =>
            require('@direct-wealth/common/utils/external-webview')
              .ExternalWebview
          }
          options={{
            headerShown: true,
            header: AvivaWebViewTopAppBar,
            title: 'aviva.co.uk',
          }}
        />
      </Stack.Navigator>
    </NavigatorProvider>
  );
};
