export const CASH = '|cash';
export const HOLDINGS = '|holdings';
export const TAPPED = '-tapped';
export const FILTER = 'filter-tapped';
export const SHOW_MORE = '-showmore-tapped';
export const PRODUCT_DETAIL = '|productDetail-performance|transactions';

export const PRODUCT_DETAIL_HOLDINGS = PRODUCT_DETAIL + HOLDINGS;
export const PRODUCT_DETAIL_CASH = PRODUCT_DETAIL + CASH;

export const PRODUCT_DETAIL_HOLDINGS_TAPPED =
  PRODUCT_DETAIL + HOLDINGS + TAPPED;
export const PRODUCT_DETAIL_CASH_TAPPED = PRODUCT_DETAIL + CASH + TAPPED;
