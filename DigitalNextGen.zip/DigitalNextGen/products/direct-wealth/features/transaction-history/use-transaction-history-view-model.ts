import { PAGE_WEALTH } from '@constants/analytics';
import { useAnalytics } from '@hooks/use-analytics';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { SubaccountAccount } from 'products/direct-wealth/validation/schemas/direct-wealth-subaccount';
import { useCallback, useEffect, useState } from 'react';

import { useTransactionHistory } from '../../common/hooks/use-transaction-history';
import { TransactionHistoryType } from '../../models/transaction-history';
import {
  CashTransactionDetailsParamsSchema,
  ProductTransactionDetailsParamsSchema,
  Transaction,
} from '../../validation/schemas/transaction-history';
import { FILTER, PRODUCT_DETAIL, SHOW_MORE } from './analytics';
import { getUpdatedTransactions, isProductTransaction } from './utils';

export type MonthlyTransaction = {
  title: string;
  data: Transaction[];
};

export type MonthlyTransactionSectionList = MonthlyTransaction[];

export const useTransactionHistoryViewModel = (
  securePolicyNumber: string,
  transactionHistoryType: TransactionHistoryType,
  accountType: SubaccountAccount
) => {
  const [page, setPage] = useState(1);
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [isApplyingFilters, setIsApplyingFilters] = useState<boolean>(false);
  const [filters, setFilters] = useState<string[]>([]);
  const [transactions, setTransactions] =
    useState<MonthlyTransactionSectionList>([]);

  const analytics = useAnalytics();

  const tab =
    transactionHistoryType === 'investmentTransactionHistory'
      ? 'holdings'
      : 'cash';
  const { navigate } = useAppStackNavigation();

  const [transactionHistory, { isError, isLoading, refetch, isFetching }] =
    useTransactionHistory(
      securePolicyNumber,
      transactionHistoryType,
      page,
      selectedFilters
    );

  const isListEnd = transactionHistory?.listEnd || false;

  useEffect(() => {
    if (isApplyingFilters && !isFetching) {
      setIsApplyingFilters(false);
    }
  }, [isApplyingFilters, isFetching]);

  useEffect(() => {
    if (transactionHistory) {
      setTransactions((prevFormattedMonthlyTransactions) =>
        getUpdatedTransactions(
          prevFormattedMonthlyTransactions,
          transactionHistory?.transactions || [],
          page
        )
      );
      setFilters(transactionHistory?.possibleFilters);
      setPage(transactionHistory.page);
      setSelectedFilters(transactionHistory.selectedFilters);
    }
    // Omitted page from dependencies as it would cause an unnecessary re-render,
    // transactionHistory will update when page state is set and triggers the one re-render needed
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [transactionHistory]);

  const loadNextPage = useCallback(() => {
    analytics.trackUserEvent(
      `${PAGE_WEALTH}|${accountType}${PRODUCT_DETAIL}|${tab}${SHOW_MORE}`
    );
    !transactionHistory?.listEnd && setPage((prevPage) => prevPage + 1);
  }, [accountType, analytics, tab, transactionHistory?.listEnd]);

  const updateFilters = useCallback(
    (selectedFilter: string, isSelected: boolean) => {
      analytics.trackUserEvent(
        `${PAGE_WEALTH}|${accountType}${PRODUCT_DETAIL}|${tab}|${FILTER}|${selectedFilter
          .split(' ')
          .join('')}`
      );
      setIsApplyingFilters(true);
      setPage(1);

      if (selectedFilter === 'All') {
        setSelectedFilters([]);
      } else {
        setSelectedFilters(
          isSelected
            ? [...selectedFilters, selectedFilter]
            : selectedFilters.filter(
                (filter: string) => filter !== selectedFilter
              )
        );
      }
    },
    [accountType, analytics, selectedFilters, tab]
  );

  const isLoadingFirstTime =
    isLoading && !isApplyingFilters && transactions?.length === 0;

  const navigateToTransactionDetails = (transaction: Transaction) => {
    const params = isProductTransaction(transaction)
      ? ProductTransactionDetailsParamsSchema.parse(transaction)
      : CashTransactionDetailsParamsSchema.parse(transaction);
    navigate('Transaction Details', params);
  };

  return {
    navigateToTransactionDetails,
    transactions,
    selectedFilters,
    setSelectedFilters,
    filters,
    loadNextPage,
    updateFilters,
    refetch,
    isError,
    isLoadingFirstTime,
    isApplyingFilters,
    shouldShowLoadMore: !isListEnd && !isApplyingFilters,
    shouldShowLoadMoreSpinner: isLoading,
    accountType,
  };
};
