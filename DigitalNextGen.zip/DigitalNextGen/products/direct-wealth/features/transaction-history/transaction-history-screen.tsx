import { Tabs } from '@aviva/ion-mobile';
import { FilterList } from '@aviva/ion-mobile/components/filter-list';
import { PAGE_WEALTH } from '@constants/analytics';
import { useAnalytics } from '@hooks/use-analytics';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';
import { SubaccountAccount } from 'products/direct-wealth/validation/schemas/direct-wealth-subaccount';

import {
  PRODUCT_DETAIL_CASH_TAPPED,
  PRODUCT_DETAIL_HOLDINGS_TAPPED,
} from './analytics';
import { CashTab } from './cash-tab/cash-tab';
import { HoldingsTab } from './holdings-tab/holdings-tab';
import { TransactionsListShimmerLoading } from './transactions-list-loading';

export type TransactionHistoryRouteProps = NativeStackScreenProps<
  AppStackDWRouteParams,
  'Transaction History'
>['route'];

const HoldingsTabScreen = (
  securePolicyNumber: string,
  accountType: SubaccountAccount
) => (
  <HoldingsTab
    securePolicyNumber={securePolicyNumber}
    accountType={accountType}
  />
);

const CashTabScreen = (
  securePolicyNumber: string,
  accountType: SubaccountAccount
) => (
  <CashTab securePolicyNumber={securePolicyNumber} accountType={accountType} />
);

const LazyPlaceHolder = () => (
  <>
    <FilterList filters={[]} onFiltersChange={() => null} />
    <TransactionsListShimmerLoading height={'100%'} />
  </>
);

export const TransactionHistoryScreenView = ({
  securePolicyNumber,
  accountType,
}: TransactionHistoryRouteProps['params']) => {
  const { trackUserEvent } = useAnalytics();

  const transactionHistoryTabRoutes = [
    {
      key: 'Holdings Tab',
      title: 'Holdings',
      component: () => HoldingsTabScreen(securePolicyNumber, accountType),
    },
    {
      key: 'Cash Tab',
      title: 'Cash',
      component: () => CashTabScreen(securePolicyNumber, accountType),
    },
  ];

  const onTabChange = (tabName: string) => {
    switch (tabName) {
      case 'Holdings':
        trackUserEvent(
          `${PAGE_WEALTH}|${accountType}${PRODUCT_DETAIL_HOLDINGS_TAPPED}`
        );
        break;
      case 'Cash':
        trackUserEvent(
          `${PAGE_WEALTH}|${accountType}${PRODUCT_DETAIL_CASH_TAPPED}`
        );
        break;
      default:
        break;
    }
  };

  return (
    <Tabs
      lazy
      renderLazyPlaceholder={LazyPlaceHolder}
      tabBarVariant="dwBlue"
      tabRoutes={transactionHistoryTabRoutes}
      onTabChange={onTabChange}
    />
  );
};

export const TransactionHistoryScreen = ({
  route,
}: {
  route: TransactionHistoryRouteProps;
}) => <TransactionHistoryScreenView {...route.params} />;
