import { Stack, Text, XStack, YStack } from '@aviva/ion-mobile';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';

type TransactionDetailsRouteProps = NativeStackScreenProps<
  AppStackDWRouteParams,
  'Transaction Details'
>['route'];

export type TransactionDetailsScreenViewProps = {
  route: TransactionDetailsRouteProps;
};

const DETAIL_ROW_TITLES = {
  description: 'Description',
  amount: 'Amount',
  referenceNumber: 'Reference number',
  cost: 'Share price',
  quantity: 'Number of shares sold',
  company: 'Company',
  transactionType: 'Transaction type',
};

type DetailKeys = keyof typeof DETAIL_ROW_TITLES;

const renderTransactionDetails = (
  params: AppStackDWRouteParams['Transaction Details']
) => {
  return Object.entries(params).map(([key, value]) => {
    // Filter rows with undefined values, plus 'heading' and 'date' as we render them separately
    const rowTitle = DETAIL_ROW_TITLES[key as DetailKeys];
    const showRow =
      ![key, value].some((element) => element === undefined) && rowTitle;

    return showRow ? (
      <XStack width={'100%'} key={key} p="$lg">
        <Text
          fontVariant="small-regular-DWPrimary500"
          tamaguiTextProps={{
            width: '40%',
          }}
          testID={getTestId(key)}
        >
          {rowTitle}
        </Text>
        <Text
          fontVariant="body-semibold-DWPrimary500"
          tamaguiTextProps={{
            width: '60%',
            textAlign: 'right',
          }}
        >
          {value}
        </Text>
      </XStack>
    ) : null;
  });
};

export const TransactionDetailsScreenView = ({
  route,
}: TransactionDetailsScreenViewProps) => {
  const { transactionDate, heading } = route.params;
  return (
    <Stack backgroundColor={'white'} flex={1}>
      <YStack tablet={isIpad}>
        <Stack p={'$xl'}>
          <Text
            fontVariant="heading2-regular-DWPrimary500"
            tamaguiTextProps={{ lineHeight: 60, letterSpacing: -1 }}
            testID={getTestId('transaction-details-heading')}
          >
            {heading}
          </Text>
          <Text
            fontVariant="heading4-light-Gray500"
            tamaguiTextProps={{
              letterSpacing: -0.5,
            }}
            testID={getTestId('transaction-details-date')}
          >
            {transactionDate}
          </Text>
        </Stack>
        <XStack backgroundColor={'$Gray200'} height={0.3} />
        {renderTransactionDetails(route.params)}
      </YStack>
    </Stack>
  );
};

export const TransactionDetailsScreen = ({
  route,
}: {
  route: TransactionDetailsRouteProps;
}) => {
  return <TransactionDetailsScreenView route={route} />;
};
