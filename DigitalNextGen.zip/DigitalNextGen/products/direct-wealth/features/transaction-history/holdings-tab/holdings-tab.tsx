import { LoadingState, YStack } from '@aviva/ion-mobile';
import { FilterList } from '@aviva/ion-mobile/components/filter-list';
import { PAGE_WEALTH } from '@constants/analytics';
import { useAnalytics } from '@hooks/use-analytics';
import { useFocusEffect } from '@react-navigation/native';
import { isIpad } from '@src/utils/is-ipad';
import { SubaccountAccount } from 'products/direct-wealth/validation/schemas/direct-wealth-subaccount';
import { useCallback } from 'react';

import { ErrorState } from '../../../../direct-wealth/components/error-state/error-state';
import { TransactionList } from '../../../../direct-wealth/components/transaction-list/transaction-list';
import { PRODUCT_DETAIL_HOLDINGS } from '../analytics';
import { Constants } from '../constants';
import { TransactionsListShimmerLoading } from '../transactions-list-loading';
import { useTransactionHistoryViewModel } from '../use-transaction-history-view-model';

export type TransactionTabProps = {
  model: ReturnType<typeof useTransactionHistoryViewModel>;
};
type HoldingsTabProps = {
  securePolicyNumber: string;
  accountType: SubaccountAccount;
};

export const HoldingsTabView = ({ model }: TransactionTabProps) => {
  const {
    transactions,
    selectedFilters,
    filters,
    loadNextPage,
    updateFilters,
    refetch,
    navigateToTransactionDetails,
    isError,
    isLoadingFirstTime,
    isApplyingFilters,
    shouldShowLoadMore,
    shouldShowLoadMoreSpinner,
    accountType,
  } = model;
  const { UNABLE_TO_LOAD } = Constants;
  const analytics = useAnalytics();

  useFocusEffect(
    useCallback(() => {
      analytics.trackStateEvent(
        `${PAGE_WEALTH}|${accountType}${PRODUCT_DETAIL_HOLDINGS}`
      );
    }, [accountType, analytics])
  );

  if (isError) {
    return (
      <YStack
        backgroundColor={'$White'}
        flex={1}
        paddingHorizontal="$xl"
        paddingTop={isIpad ? undefined : '40%'}
        justifyContent={isIpad ? 'center' : undefined}
      >
        <ErrorState
          variant="transparent"
          buttonAccessibilityHint="Error view due to being unable to load this content"
          message={UNABLE_TO_LOAD}
          buttonValue="Retry"
          onRetry={refetch}
          height={274}
        />
      </YStack>
    );
  }

  if (isLoadingFirstTime) {
    return <TransactionsListShimmerLoading height={'100%'} />;
  }

  return (
    <>
      <YStack
        backgroundColor={'$White'}
        flex={1}
        accessible={isApplyingFilters}
        accessibilityLabel="Transaction list"
      >
        <FilterList
          accessibilityLabel="Holdings transaction types filter"
          filters={filters}
          selectedFilters={selectedFilters}
          onFiltersChange={updateFilters}
          listName="Holdings transaction types filter"
        />

        <TransactionList
          transactions={transactions}
          navigateToTransactionDetails={navigateToTransactionDetails}
          loadNextPage={loadNextPage}
          shouldShowLoadMore={shouldShowLoadMore}
          shouldShowLoadMoreSpinner={shouldShowLoadMoreSpinner}
        />
      </YStack>
      {isApplyingFilters && (
        <LoadingState fullscreen={false} text="transactions" />
      )}
    </>
  );
};

export const HoldingsTab = ({
  securePolicyNumber,
  accountType,
}: HoldingsTabProps) => {
  const model = useTransactionHistoryViewModel(
    securePolicyNumber,
    'investmentTransactionHistory',
    accountType
  );

  return <HoldingsTabView model={model} />;
};
