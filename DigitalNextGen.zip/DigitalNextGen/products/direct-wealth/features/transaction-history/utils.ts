import { format, isSameMonth } from 'date-fns';
import {
  CashTransactionDetailsParams,
  ProductTransactionDetailsParams,
  Transaction,
} from 'products/direct-wealth/validation/schemas/transaction-history';

import { MonthlyTransactionSectionList } from './use-transaction-history-view-model';

export const formatTransactions = (
  transactions: Transaction[]
): MonthlyTransactionSectionList =>
  transactions.reduce(
    (
      formattedData: MonthlyTransactionSectionList,
      transaction: Transaction
    ) => {
      const date = transaction.transactionDate.raw;

      const categoryTitle = isSameMonth(date, new Date())
        ? 'This month'
        : format(date, 'MMMM yyyy');

      const lastMonthlyTransaction = formattedData[formattedData.length - 1];

      if (lastMonthlyTransaction?.title === categoryTitle) {
        lastMonthlyTransaction?.data.push(transaction);
      } else {
        formattedData.push({
          title: categoryTitle,
          data: [transaction],
        });
      }

      return formattedData;
    },
    [] as MonthlyTransactionSectionList
  );

export const stitchTransactions = (
  previousMonthlyTransactions: MonthlyTransactionSectionList,
  currentMonthlyTransactions: MonthlyTransactionSectionList
) => {
  const lastGroupOfPreviousMonthlyTransactions =
    previousMonthlyTransactions[previousMonthlyTransactions.length - 1];

  if (
    lastGroupOfPreviousMonthlyTransactions.title ===
    currentMonthlyTransactions[0]?.title
  ) {
    lastGroupOfPreviousMonthlyTransactions.data = [
      ...lastGroupOfPreviousMonthlyTransactions.data,
      ...currentMonthlyTransactions[0].data,
    ];
    currentMonthlyTransactions.shift();
  }

  return previousMonthlyTransactions.concat(currentMonthlyTransactions);
};

export const getUpdatedTransactions = (
  prevFormattedMonthlyTransactions: MonthlyTransactionSectionList,
  newTransactions: Transaction[],
  page: number
) =>
  page > 1 && prevFormattedMonthlyTransactions.length > 0
    ? stitchTransactions(
        prevFormattedMonthlyTransactions,
        formatTransactions(newTransactions)
      )
    : formatTransactions(newTransactions);

// Type predicate
export const isProductTransaction = (
  transaction:
    | ProductTransactionDetailsParams
    | CashTransactionDetailsParams
    | Transaction
): transaction is ProductTransactionDetailsParams => {
  return (
    (transaction as ProductTransactionDetailsParams).quantity !== undefined
  );
};
