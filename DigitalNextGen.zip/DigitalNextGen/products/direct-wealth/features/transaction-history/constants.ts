export const Constants = {
  NO_TRANSACTIONS: 'No transactions to display',
  UNABLE_TO_LOAD: 'Sorry, we were unable to load your transactions.',
};

export const previouslyFormattedTransactions = [
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: 'Today',
          raw: new Date('2023-07-06T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'This month',
  },
];

export const formattedMonthlyTransactionsPage1 = [
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: 'Today',
          raw: new Date('2023-07-06T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'This month',
  },
];

export const formattedMonthlyTransactionsPage2 = [
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'This month',
  },
  {
    data: [
      {
        amount: { raw: 2999.23, formatted: '£2,999.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '20th April 2023',
          raw: new Date('2023-04-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'April 2023',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '20th March 2023',
          raw: new Date('2023-03-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'March 2023',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '20th January 2023',
          raw: new Date('2023-01-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '20th January 2023',
          raw: new Date('2023-01-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'January 2023',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '20th December 2022',
          raw: new Date('2022-12-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '19th December 2022',
          raw: new Date('2022-12-19T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'December 2022',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '19th November 2022',
          raw: new Date('2022-11-19T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'November 2022',
  },
];

export const mockStitchedMonthlyTransactions = [
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: 'Today',
          raw: new Date('2023-07-06T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'This month',
  },
  {
    data: [
      {
        amount: { raw: 2999.23, formatted: '£2,999.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '20th April 2023',
          raw: new Date('2023-04-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'April 2023',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '20th March 2023',
          raw: new Date('2023-03-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'March 2023',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Fund Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '20th January 2023',
          raw: new Date('2023-01-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '20th January 2023',
          raw: new Date('2023-01-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'January 2023',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '20th December 2022',
          raw: new Date('2022-12-20T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '19th December 2022',
          raw: new Date('2022-12-19T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'December 2022',
  },
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '2222222',
        cost: 2229,
        heading: 'Fund Purchase2',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82222',
        status: 'Complete',
        transactionDate: {
          formatted: '19th November 2022',
          raw: new Date('2022-11-19T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'November 2022',
  },
];

export const formattedMonthlyFilteredTransactions = [
  {
    data: [
      {
        amount: { raw: 2000.23, formatted: '£2,000.23' },
        company: '7IM AAP Adventurous C Inc',
        cost: 29,
        heading: 'Filtered Purchase',
        productType: 'Eti',
        quantity: 100,
        referenceNumber: '82111',
        status: 'Complete',
        transactionDate: {
          formatted: '5th July 2023',
          raw: new Date('2023-07-05T00:00:00.000Z'),
        },
        transactionType: 'Transfer into account',
      },
    ],
    title: 'This month',
  },
];
