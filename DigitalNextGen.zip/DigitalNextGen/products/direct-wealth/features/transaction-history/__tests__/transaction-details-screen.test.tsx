import { render, screen } from '@src/jest/testing-library';

import { TransactionDetailsScreen } from '../transaction-details-screen';

describe('Transaction Details Screen', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });
  it('should render a screen with details of a given CASH transaction', () => {
    const mockParams = {
      amount: '£2,000.23',
      heading: 'Charges',
      transactionDate: '20th Apr 2023',
      referenceNumber: '12345',
      description: 'Direct OMC Funds',
    };

    render(
      <TransactionDetailsScreen
        route={{
          key: 'key',
          name: 'Transaction Details',
          params: mockParams,
        }}
      />
    );

    const amount = screen.getByText('£2,000.23');
    const heading = screen.getByText(/Charges/i);
    const date = screen.getByText('20th Apr 2023');
    const description = screen.getByText('Direct OMC Funds');

    expect(amount).toBeOnTheScreen();
    expect(heading).toBeOnTheScreen();
    expect(date).toBeOnTheScreen();
    expect(description).toBeOnTheScreen();
  });

  it('should render a screen with details of a given HOLDINGS transaction', () => {
    const mockParams = {
      amount: '£4000.23',
      company: '7IM AAP Adventurous C Inc',
      cost: '£29.00',
      heading: 'Fund Purchase',
      quantity: 100,
      referenceNumber: '00111',
      status: 'Complete',
      transactionDate: '6th Jul 2023',
      transactionType: 'Transfer into account',
    };
    render(
      <TransactionDetailsScreen
        route={{
          key: 'key',
          name: 'Transaction Details',
          params: mockParams,
        }}
      />
    );

    const amount = screen.getByText('£4000.23');
    const company = screen.getByText('7IM AAP Adventurous C Inc');
    const cost = screen.getByText('£29.00');
    const transactionType = screen.getByText('Fund Purchase');
    const date = screen.getByText('6th Jul 2023');

    expect(amount).toBeOnTheScreen();
    expect(company).toBeOnTheScreen();
    expect(cost).toBeOnTheScreen();
    expect(transactionType).toBeOnTheScreen();
    expect(date).toBeOnTheScreen();
  });
});
