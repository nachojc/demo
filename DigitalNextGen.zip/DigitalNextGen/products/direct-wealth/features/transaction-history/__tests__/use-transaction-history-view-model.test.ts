import {
  act,
  mockTrackUserEvent,
  renderHook,
  waitFor,
} from '@src/jest/testing-library';

import {
  CashTransactionDetailsParamsSchema,
  ProductTransactionDetailsParamsSchema,
} from '../../../validation/schemas/transaction-history';
import {
  formattedMonthlyFilteredTransactions,
  formattedMonthlyTransactionsPage1,
  mockStitchedMonthlyTransactions,
} from '../constants';
import { useTransactionHistoryViewModel } from '../use-transaction-history-view-model';

const MOCK_POLICY_NUMBER = 'mock-secure-policy-number';
const MOCK_POLICY_NUMBER_2 = `${MOCK_POLICY_NUMBER}-2`;
const mockAppStackNavigate = jest.fn();

jest.mock('src/navigation/app/hooks.ts', () => ({
  useAppStackNavigation: () => ({
    navigate: mockAppStackNavigate,
  }),
}));

describe('use-transaction-summary-view-model', () => {
  beforeAll(() => {
    jest.useFakeTimers().setSystemTime(new Date('2023-07-06'));
  });
  afterEach(() => {
    jest.resetAllMocks();
  });
  afterAll(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
  });

  it('should return correctly formatted transactions for initial page load', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER,
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    await waitFor(() =>
      expect(result.current.transactions).toEqual(
        formattedMonthlyTransactionsPage1
      )
    );
  });

  it('should call navigate with the correct params when navigateToTransactionDetails is called with CASH transaction details', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        'mock-secure-policy-number',
        'cashTransactionHistory',
        'SIPP'
      )
    );

    await waitFor(() =>
      expect(result.current.transactions[0].data[0]).toBeTruthy()
    );

    const { navigateToTransactionDetails, transactions } = result.current;

    navigateToTransactionDetails(transactions[0].data[0]);

    const parsed = CashTransactionDetailsParamsSchema.parse(
      result.current.transactions[0].data[0]
    );

    expect(mockAppStackNavigate).toHaveBeenCalled();
    expect(mockAppStackNavigate).toHaveBeenCalledWith(
      'Transaction Details',
      parsed
    );
  });

  it('should call navigate with the correct params when navigateToTransactionDetails is called with HOLDING transaction details', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        'mock-secure-policy-number',
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    await waitFor(() =>
      expect(result.current.transactions[0].data[0]).toBeTruthy()
    );

    const { navigateToTransactionDetails, transactions } = result.current;

    navigateToTransactionDetails(transactions[0].data[0]);

    const parsed = ProductTransactionDetailsParamsSchema.parse(
      result.current.transactions[0].data[0]
    );

    expect(mockAppStackNavigate).toHaveBeenCalled();
    expect(mockAppStackNavigate).toHaveBeenCalledWith(
      'Transaction Details',
      parsed
    );
  });

  it('should return correctly formatted transactions when loading next page', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER_2,
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    await waitFor(() =>
      expect(result.current.transactions).toEqual(
        formattedMonthlyTransactionsPage1
      )
    );

    act(() => {
      result.current.loadNextPage();
    });

    await waitFor(() =>
      expect(result.current.transactions).toEqual(
        mockStitchedMonthlyTransactions
      )
    );
  });

  it('should return correctly formatted transactions when a filter is applied', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER_2,
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    await waitFor(() =>
      expect(result.current.transactions).toEqual(
        formattedMonthlyTransactionsPage1
      )
    );

    act(() => {
      result.current.updateFilters('Purchase', true);
    });

    await waitFor(() =>
      expect(result.current.transactions).toEqual(
        formattedMonthlyFilteredTransactions
      )
    );
  });

  it('should return correctly formatted transactions when a filter is applied then unapplied', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        'mock-secure-policy-number-2',
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    act(() => {
      result.current.setSelectedFilters(['Purchase']);
    });

    act(() => {
      result.current.updateFilters('Purchase', false);
    });

    await waitFor(() =>
      expect(result.current.transactions).toEqual(
        formattedMonthlyTransactionsPage1
      )
    );
  });

  it('should return correctly formatted transactions when the All filter is applied', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        'mock-secure-policy-number-2',
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    act(() => {
      result.current.setSelectedFilters(['Purchase']);
    });

    act(() => {
      result.current.updateFilters('All', true);
    });

    await waitFor(() =>
      expect(result.current.transactions).toEqual(
        formattedMonthlyTransactionsPage1
      )
    );
  });

  it('should call mockTrackUserEvent when the show more button is clicked', () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        'mock-secure-policy-number-2',
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    act(() => {
      result.current.loadNextPage();
    });

    expect(mockTrackUserEvent).toHaveBeenLastCalledWith(
      'ukmyaviva|wealth|SIPP|productDetail-performance|transactions|holdings-showmore-tapped'
    );
  });

  it('should call mockTrackUserEvent when a filter is tapped', () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        'mock-secure-policy-number-2',
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    act(() => {
      result.current.updateFilters('Purchase', true);
    });

    expect(mockTrackUserEvent).toHaveBeenLastCalledWith(
      'ukmyaviva|wealth|SIPP|productDetail-performance|transactions|holdings|filter-tapped|Purchase'
    );
  });

  it('should set isApplyingFilters to false if it is not fetching', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER_2,
        'investmentTransactionHistory',
        'SIPP'
      )
    );

    expect(result.current.isApplyingFilters).toBe(false);
  });

  it('should set isApplyingFilters to true when update filter', () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER_2,
        'investmentTransactionHistory',
        'SIPP'
      )
    );
    expect(result.current.isApplyingFilters).toBe(false);

    act(() => {
      result.current.updateFilters('Purchase', true);
    });
    expect(result.current.isApplyingFilters).toBe(true);
  });

  it('should set isLoadingFirstTime to true on initial loading', () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER_2,
        'investmentTransactionHistory',
        'SIPP'
      )
    );
    expect(result.current.isLoadingFirstTime).toBe(true);
  });

  it('should set shouldShowLoadMore state correctly', () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER_2,
        'investmentTransactionHistory',
        'SIPP'
      )
    );
    expect(result.current.shouldShowLoadMore).toBe(true);
  });

  it('should set shouldShowLoadMoreSpinner state correctly', async () => {
    const { result } = renderHook(() =>
      useTransactionHistoryViewModel(
        MOCK_POLICY_NUMBER_2,
        'investmentTransactionHistory',
        'SIPP'
      )
    );
    act(() => {
      result.current.loadNextPage();
    });
    expect(result.current.shouldShowLoadMoreSpinner).toBe(true);
  });
});
