import Product_Transaction_History from '@src/api-mock/responses/DirectWealth/TransactionHistory/Product/product_transaction_history.json';
import Product_Transaction_History_Page_2 from '@src/api-mock/responses/DirectWealth/TransactionHistory/Product/product_transaction_history_page_2.json';

import { TransactionHistorySchema } from '../../../validation/schemas/transaction-history';
import {
  formattedMonthlyTransactionsPage1,
  formattedMonthlyTransactionsPage2,
  mockStitchedMonthlyTransactions,
  previouslyFormattedTransactions,
} from '../constants';
import {
  formatTransactions,
  getUpdatedTransactions,
  isProductTransaction,
  stitchTransactions,
} from '../utils';

const CURRENT_DATE = new Date('2023-07-06');

describe('utils', () => {
  beforeAll(() => {
    jest.useFakeTimers().setSystemTime(CURRENT_DATE);
  });
  afterAll(() => {
    jest.useRealTimers();
  });

  it('formatTransactions should format transaction data into section list data', () => {
    const formattedTransactions = formatTransactions(
      TransactionHistorySchema.parse(Product_Transaction_History.content)
        .transactions
    );
    expect(formattedTransactions).toEqual(formattedMonthlyTransactionsPage1);
  });

  it('getUpdatedTransactions should correctly return stitched and formatted transactions when page is 1', () => {
    expect(
      getUpdatedTransactions(
        [],
        TransactionHistorySchema.parse(Product_Transaction_History.content)
          .transactions,
        1
      )
    ).toEqual(formattedMonthlyTransactionsPage1);
  });

  it('getUpdatedTransactions should correctly return stitched and formatted transactions when page is 2', () => {
    expect(
      getUpdatedTransactions(
        previouslyFormattedTransactions,
        TransactionHistorySchema.parse(
          Product_Transaction_History_Page_2.content
        ).transactions,
        2
      )
    ).toEqual(mockStitchedMonthlyTransactions);
  });

  it('stitchTransactions should correctly merge and group 2 sets of transactions', () => {
    const stitchedTransactions = stitchTransactions(
      formattedMonthlyTransactionsPage1,
      formattedMonthlyTransactionsPage2
    );

    expect(stitchedTransactions).toEqual(mockStitchedMonthlyTransactions);
    expect(stitchedTransactions[0].data).toHaveLength(4);
  });

  it('should correctly determine if the transaction type is product', async () => {
    const productTransactionCheck = isProductTransaction(
      TransactionHistorySchema.parse(Product_Transaction_History.content)
        .transactions[0]
    );
    const cashTransactionCheck = isProductTransaction({
      amount: { formatted: '£2,000.23', raw: 2000.23 },
      heading: 'Transfer In',
      status: 'Complete',
      transactionDate: {
        formatted: '20th April 2023',
        raw: new Date('2023-07-06'),
      },
      transactionType: 'Transfer into account',
      referenceNumber: '12345',
    });

    expect(productTransactionCheck).toBe(true);
    expect(cashTransactionCheck).toBe(false);
  });
});
