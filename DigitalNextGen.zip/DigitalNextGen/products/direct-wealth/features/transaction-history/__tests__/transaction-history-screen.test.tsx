import {
  cleanup,
  fireEvent,
  mockTrackStateEvent,
  mockTrackUserEvent,
  render,
  screen,
} from '@src/jest/testing-library';
import { NavigationContainer } from '@react-navigation/native';
import { getTestId } from '@src/utils/get-test-id';

import {
  TransactionHistoryRouteProps,
  TransactionHistoryScreen,
} from '../transaction-history-screen';

jest.mock('@react-navigation/native', () => {
  const actualNav = jest.requireActual('@react-navigation/native');
  return { ...actualNav, useIsFocused: () => true };
});

const renderTransactionHistoryScreen = (
  routeParamsOverrides: Partial<TransactionHistoryRouteProps['params']> = {}
) =>
  render(
    <NavigationContainer>
      <TransactionHistoryScreen
        route={{
          key: 'key',
          name: 'Transaction History',
          params: {
            securePolicyNumber: '12345',
            accountType: 'SIPP',
            ...routeParamsOverrides,
          },
        }}
      />
    </NavigationContainer>
  );

describe('Transaction History Screen', () => {
  afterEach(() => {
    jest.clearAllMocks();
    cleanup();
  });
  it('should render a screen with two tabs for investments and cash', async () => {
    renderTransactionHistoryScreen();

    expect(screen.getByTestId(getTestId('holdings'))).toBeOnTheScreen();
    expect(screen.getByTestId(getTestId('cash'))).toBeOnTheScreen();
  });
});

describe('Analytics for the Transaction History Screen', () => {
  afterEach(() => {
    jest.useRealTimers();
    jest.clearAllMocks();
    cleanup();
  });
  it('should call mockOnPageLoadEvent when the holdings tab loads', () => {
    renderTransactionHistoryScreen();

    expect(mockTrackStateEvent).toHaveBeenCalledWith(
      'ukmyaviva|wealth|SIPP|productDetail-performance|transactions|holdings'
    );
  });

  it('should call trackUserEvent when the tab is clicked', () => {
    renderTransactionHistoryScreen();

    fireEvent.press(screen.getByTestId(getTestId('cash')));

    expect(mockTrackUserEvent).toHaveBeenCalledWith(
      'ukmyaviva|wealth|SIPP|productDetail-performance|transactions|cash-tapped'
    );

    fireEvent.press(screen.getByTestId(getTestId('holdings')));

    expect(mockTrackUserEvent).toHaveBeenCalledWith(
      'ukmyaviva|wealth|SIPP|productDetail-performance|transactions|holdings-tapped'
    );
  });
});
