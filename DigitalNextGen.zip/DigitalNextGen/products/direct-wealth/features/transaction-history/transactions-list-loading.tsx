import { Separator, Shimmer, XStack, YStack } from '@aviva/ion-mobile';

const renderShimmerItem = (count: number) => (
  <>
    <YStack paddingVertical="$lg" pl={16} backgroundColor="$Gray050">
      <Shimmer height={22} width={100} />
    </YStack>
    {Array.from(Array(count).keys()).map((value, i) => {
      return (
        <YStack key={value}>
          <XStack
            marginVertical="$lg"
            accessibilityLabel="Transaction List Loading"
            accessibilityHint="Loading list item for transactions"
          >
            <XStack justifyContent="space-between" flex={1}>
              <YStack mr={26} ml={16} space={6}>
                <Shimmer height={16} width={150} />
                <Shimmer height={16} width={200} />
              </YStack>
              <YStack mr={16} justifyContent="center">
                <Shimmer height={20} width={56} />
              </YStack>
            </XStack>
          </XStack>
          {i < count - 1 ? <Separator /> : null}
        </YStack>
      );
    })}
  </>
);
export const TransactionsListShimmerLoading = ({
  height,
}: {
  height?: number | string;
}) => (
  <YStack
    height={height}
    backgroundColor="$White"
    testID="transaction-shimmer-loading"
  >
    {renderShimmerItem(3)}
    {renderShimmerItem(4)}
  </YStack>
);
