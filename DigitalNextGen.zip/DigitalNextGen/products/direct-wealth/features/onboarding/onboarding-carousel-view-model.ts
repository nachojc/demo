import { useAnalytics } from '@hooks/use-analytics';
import { dwOnboardingComplete } from '@interfaces/storage';
import { Source } from 'react-native-fast-image';

import {
  ACTION_CLOSE_ONBOARDING_SCREEN_ONE,
  ACTION_CLOSE_ONBOARDING_SCREEN_THREE,
  ACTION_CLOSE_ONBOARDING_SCREEN_TWO,
  ACTION_LOGIN_ONBOARDING_SCREEN_THREE,
  ACTION_NEXT_ONBOARDING_SCREEN_ONE,
  ACTION_NEXT_ONBOARDING_SCREEN_TWO,
  PAGE_ONBOARDING_SCREEN_ONE,
  PAGE_ONBOARDING_SCREEN_THREE,
  PAGE_ONBOARDING_SCREEN_TWO,
} from './analytics';

export type DwOnboardingScreenProps = {
  key: number;
  image: Source;
  headingText: string;
  bodyText: string;
  pageTag: string;
  closeTag: string;
  nextTag: string;
};

const screens: DwOnboardingScreenProps[] = [
  {
    key: 0,
    image: require('assets/pie_chart_phone/pie-chart-phone.png'),
    headingText: 'Welcome to Aviva Wealth',
    bodyText:
      'You’re a step closer to managing your investments from the palm of your hand.',
    pageTag: PAGE_ONBOARDING_SCREEN_ONE,
    closeTag: ACTION_CLOSE_ONBOARDING_SCREEN_ONE,
    nextTag: ACTION_NEXT_ONBOARDING_SCREEN_ONE,
  },
  {
    key: 1,
    image: require('assets/graph_phone/graph-phone.png'),
    headingText: 'Manage your portfolio',
    bodyText:
      'Keep your finger on the pulse of your portfolio, so you can check on how it’s performing when markets change.',
    pageTag: PAGE_ONBOARDING_SCREEN_TWO,
    closeTag: ACTION_CLOSE_ONBOARDING_SCREEN_TWO,
    nextTag: ACTION_NEXT_ONBOARDING_SCREEN_TWO,
  },
  {
    key: 2,
    image: require('assets/investor_phone/investor-phone.png'),
    headingText: 'Become a more confident investor',
    bodyText:
      'We’ll help you understand your finances, so you’ll be talking like one of our experts in no time.',
    pageTag: PAGE_ONBOARDING_SCREEN_THREE,
    closeTag: ACTION_CLOSE_ONBOARDING_SCREEN_THREE,
    nextTag: ACTION_LOGIN_ONBOARDING_SCREEN_THREE,
  },
];

export const useDwOnboardingCarouselViewModel = () => {
  const { trackUserEvent, trackStateEvent } = useAnalytics();

  const handleClose = (index: number) => {
    trackUserEvent(screens[index].closeTag);
    dwOnboardingComplete.set(true);
  };

  const completeOnboarding = () => {
    dwOnboardingComplete.set(true);
    handleNext(screens[screens.length - 1].key);
  };

  const handleNext = (index: number) => {
    trackUserEvent(screens[index].nextTag);
  };

  const firePageTag = (index: number) => {
    trackStateEvent(screens[index].pageTag);
  };

  return {
    handleClose,
    handleNext,
    firePageTag,
    screens,
    completeOnboarding,
  };
};
