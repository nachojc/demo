import {
  FocusAwareStatusBar,
  FullScreenCarouselModal,
  getTokens,
  getVariableValue,
  Stack,
  Theme,
} from '@aviva/ion-mobile';

import { Introduction } from './accessibilityText';
import { DwOnboardingCarouselSlide } from './carousel-slide';
import { useDwOnboardingCarouselViewModel } from './onboarding-carousel-view-model';

type OnboardingCarouselProps = {
  model: ReturnType<typeof useDwOnboardingCarouselViewModel>;
};

export const DwOnboardingView = ({ model }: OnboardingCarouselProps) => {
  const { completeOnboarding, firePageTag, handleClose, handleNext, screens } =
    model;

  return (
    <>
      <FocusAwareStatusBar
        style="light"
        backgroundColor={getVariableValue(getTokens().color.$WealthBlue)}
      />
      <Theme name="wealth">
        <Stack flex={1} bg="$WealthBlue">
          <FullScreenCarouselModal
            headerIconVariant="light"
            leftLabel="Back"
            rightLabel="Next"
            lastRightLabel="Login"
            items={screens.map((screen) => (
              <DwOnboardingCarouselSlide {...screen} key={screen.key} />
            ))}
            onClose={handleClose}
            onRightLabelPress={handleNext}
            onPageLoad={firePageTag}
            onLastRightLabelPress={completeOnboarding}
            carouselAccessibilityTitle={Introduction}
          />
        </Stack>
      </Theme>
    </>
  );
};

export const DwOnboardingScreen = () => {
  const model = useDwOnboardingCarouselViewModel();

  return <DwOnboardingView model={model} />;
};
