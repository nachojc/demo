import {
  getTokens,
  getVariableValue,
  Image,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { Source } from 'react-native-fast-image';

type DwOnboardingCarouselSlideProps = {
  image: Source;
  headingText: string;
  bodyText: string;
  key: number;
};

export const DwOnboardingCarouselSlide = ({
  image,
  headingText,
  bodyText,
}: DwOnboardingCarouselSlideProps) => {
  const { size, space } = getTokens();
  return (
    <YStack
      ai={'center'}
      paddingTop="$xxxl"
      backgroundColor={'$WealthBlue'}
      accessible
      accessibilityLabel={`${headingText}, ${bodyText}`}
    >
      <Image
        testID="carousel-screen-image"
        accessibilityIgnoresInvertColors
        source={image}
        resizeMode="contain"
        style={{
          width: getVariableValue(size[14]),
          height: getVariableValue(size[17]),
          marginBottom: getVariableValue(space.$xxl),
          padding: 0,
        }}
      />
      <Text
        fontVariant={'heading5-semibold-Secondary800'}
        tamaguiTextProps={{
          textAlignVertical: 'center',
          marginTop: '$xxl',
          marginBottom: '$xl',
          color: 'white',
          textAlign: 'center',
          width: 320,
          accessibilityLabel: headingText,
        }}
      >
        {headingText}
      </Text>
      <Text
        fontVariant={'body-regular-Gray800'}
        tamaguiTextProps={{
          marginBottom: '$xl',
          textAlign: 'center',
          color: 'white',
          width: 320,
        }}
      >
        {bodyText}
      </Text>
    </YStack>
  );
};
