import { APP_BASE } from '@constants/analytics';

const DW_BASE = APP_BASE + 'wealth|onboarding|';

export const PAGE_ONBOARDING_SCREEN_ONE = DW_BASE + '1';

export const PAGE_ONBOARDING_SCREEN_TWO = DW_BASE + '2';

export const PAGE_ONBOARDING_SCREEN_THREE = DW_BASE + '3';

export const ACTION_CLOSE_ONBOARDING_SCREEN_ONE =
  PAGE_ONBOARDING_SCREEN_ONE + '|close-tapped';

export const ACTION_NEXT_ONBOARDING_SCREEN_ONE =
  PAGE_ONBOARDING_SCREEN_ONE + '|next-tapped';

export const ACTION_CLOSE_ONBOARDING_SCREEN_TWO =
  PAGE_ONBOARDING_SCREEN_TWO + '|close-tapped';

export const ACTION_NEXT_ONBOARDING_SCREEN_TWO =
  PAGE_ONBOARDING_SCREEN_TWO + '|next-tapped';

export const ACTION_CLOSE_ONBOARDING_SCREEN_THREE =
  PAGE_ONBOARDING_SCREEN_THREE + '|close-tapped';

export const ACTION_LOGIN_ONBOARDING_SCREEN_THREE =
  PAGE_ONBOARDING_SCREEN_THREE + '|login-tapped';
