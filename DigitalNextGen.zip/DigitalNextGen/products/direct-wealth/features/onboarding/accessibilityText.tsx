export const Introduction = 'Welcome to Aviva Wealth, carousel, screen';
export const CloseButton = 'Close, button.';
