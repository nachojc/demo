import { APP_BASE } from '@constants/analytics';

export const END_OF_LIFE_PAGE_TAG = `${APP_BASE}aviva-app-prompt`;
export const END_OF_LIFE_ACTION_TAG = `${END_OF_LIFE_PAGE_TAG}|download-tapped`;
