import { Button, Image, Stack, Text, YStack } from '@aviva/ion-mobile';

import { useEndOfLifeViewModel } from './use-end-of-life-view-model';

type EndOfLifeScreenViewProps = {
  model: ReturnType<typeof useEndOfLifeViewModel>;
};
export const EndOfLifeScreenView = ({ model }: EndOfLifeScreenViewProps) => {
  return (
    <Stack flex={1} backgroundColor={'$DWPrimary500'}>
      <YStack
        flex={1}
        justifyContent="center"
        margin="$xxxl"
        alignItems="center"
        alignSelf="center"
      >
        <Image
          style={{
            width: 144,
            height: 144,
            borderRadius: 28,
          }}
          accessibilityIgnoresInvertColors
          source={require('assets/myaviva-eol.png')}
        />
        <Text
          fontVariant="heading5-semibold-White"
          tamaguiTextProps={{ mt: '$xxl', mb: '$xl' }}
        >
          We’ve moved!
        </Text>
        <Text
          fontVariant="body-regular-White"
          tamaguiTextProps={{ mb: '$xxl', textAlign: 'center' }}
        >
          Please download our brand new MyAviva App. You can still see your
          products on the go, using your same login details as before.
        </Text>
      </YStack>
      <Button
        marginBottom={'$xxl'}
        marginHorizontal={'$xl'}
        accessibilityLabel="Download new app"
        onPress={model.navigateToAppStore}
      >
        Download new app
      </Button>
    </Stack>
  );
};

export const EndOfLifeScreen = () => {
  const model = useEndOfLifeViewModel();
  return <EndOfLifeScreenView model={model} />;
};
