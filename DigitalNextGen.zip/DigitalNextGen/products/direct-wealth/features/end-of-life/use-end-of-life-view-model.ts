import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { Linking, Platform } from 'react-native';

import { END_OF_LIFE_ACTION_TAG, END_OF_LIFE_PAGE_TAG } from './analytics';

export const useEndOfLifeViewModel = () => {
  useOnPageLoad({ pageTag: END_OF_LIFE_PAGE_TAG });

  const appleAppStoreLink = 'https://apps.apple.com/gb/app/myaviva/id852352703';
  const googlePlayStoreLink =
    'market://details?id=co.uk.aviva.myavivaapp&hl=en&gl=US';

  const navigateToAppStore = () => {
    fireActionTag();
    if (Platform.OS === 'ios') {
      Linking.openURL(appleAppStoreLink);
    } else if (Platform.OS === 'android') {
      Linking.openURL(googlePlayStoreLink);
    }
  };

  const { trackUserEvent } = useAnalytics();

  const fireActionTag = () => {
    trackUserEvent(END_OF_LIFE_ACTION_TAG);
  };

  return {
    navigateToAppStore,
    fireActionTag,
    appleAppStoreLink,
    googlePlayStoreLink,
  };
};
