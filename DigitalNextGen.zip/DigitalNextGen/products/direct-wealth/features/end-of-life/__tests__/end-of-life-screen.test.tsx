import { fireEvent, render, screen } from '@src/jest/testing-library';
import { NavigationContainer } from '@react-navigation/native';
import { NavbarProvider } from '@src/common/providers/nav-control';

import { EndOfLifeScreen } from '../end-of-life-screen';

const mockNavigateToAppStore = jest.fn();
const mockFirePageTag = jest.fn();

jest.mock('../use-end-of-life-view-model', () => ({
  useEndOfLifeViewModel: () => ({
    navigateToAppStore: mockNavigateToAppStore,
    firePageTag: mockFirePageTag,
  }),
}));

const renderEndOfLifeScreen = () => {
  render(
    <NavigationContainer>
      <NavbarProvider>
        <EndOfLifeScreen />
      </NavbarProvider>
    </NavigationContainer>
  );
};

describe('EndOfLifeScreen', () => {
  it('should render EndOfLifeScreen with correct copy', () => {
    renderEndOfLifeScreen();

    expect(screen.getByText('We’ve moved!')).toBeOnTheScreen();
    expect(
      screen.getByText(
        'Please download our brand new MyAviva App. You can still see your products on the go, using your same login details as before.'
      )
    ).toBeOnTheScreen();
    expect(screen.getByText('Download new app')).toBeOnTheScreen();
  });

  it('Download new app button fires navigateToAppStore', () => {
    renderEndOfLifeScreen();

    const button = screen.getByText('Download new app');
    fireEvent.press(button);

    expect(mockNavigateToAppStore).toHaveBeenCalled();
  });
});
