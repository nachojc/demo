import {
  mockOnPageLoadEvent,
  mockTrackUserEvent,
  renderHook,
} from '@src/jest/testing-library';
import { Linking, Platform } from 'react-native';

import { useEndOfLifeViewModel } from '../use-end-of-life-view-model';

const actionTag = 'ukmyaviva|aviva-app-prompt|download-tapped';

describe('EndOfLifeScreen View Model', () => {
  it('should fire page tag', () => {
    renderHook(useEndOfLifeViewModel);

    expect(mockOnPageLoadEvent).toHaveBeenCalledWith({
      pageTag: 'ukmyaviva|aviva-app-prompt',
    });
  });

  it('should fire action tag', () => {
    const { result } = renderHook(useEndOfLifeViewModel);

    result.current.fireActionTag();
    expect(mockTrackUserEvent).toHaveBeenCalledWith(actionTag);
  });

  it('appleAppStoreLink should be correct', () => {
    const { result } = renderHook(useEndOfLifeViewModel);

    expect(result.current.appleAppStoreLink).toEqual(
      'https://apps.apple.com/gb/app/myaviva/id852352703'
    );
  });

  it('googlePlayStoreLink should be correct', () => {
    const { result } = renderHook(useEndOfLifeViewModel);

    expect(result.current.googlePlayStoreLink).toEqual(
      'market://details?id=co.uk.aviva.myavivaapp&hl=en&gl=US'
    );
  });

  it('should navigate user to apple app store link', () => {
    Platform.OS = 'ios';

    const { result } = renderHook(useEndOfLifeViewModel);
    result.current.navigateToAppStore();

    expect(mockTrackUserEvent).toHaveBeenCalledWith(actionTag);
    expect(Linking.openURL).toHaveBeenCalledWith(
      result.current.appleAppStoreLink
    );
  });

  it('should navigate user to google play store link', () => {
    Platform.OS = 'android';

    const { result } = renderHook(useEndOfLifeViewModel);
    result.current.navigateToAppStore();

    expect(mockTrackUserEvent).toHaveBeenCalledWith(actionTag);
    expect(Linking.openURL).toHaveBeenCalledWith(
      result.current.googlePlayStoreLink
    );
  });
});
