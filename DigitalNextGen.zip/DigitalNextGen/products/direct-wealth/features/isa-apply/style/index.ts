import { variants } from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';

const { width, maxWidth, alignSelf } = variants.tablet.true;

export const modalTabletStyles = {
  width,
  maxWidth,
  alignSelf,
} as const;

export const dropdownTabletContentStyles = {
  paddingHorizontal: tokens.space.xxxl.val,
};
