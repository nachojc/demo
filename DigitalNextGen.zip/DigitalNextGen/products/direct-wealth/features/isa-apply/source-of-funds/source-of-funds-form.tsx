import { z } from 'zod';

export const SourceOfFundsFormSchema = z
  .object({
    source: z.string().min(1),
    otherSource: z.string().nullish(),
  })
  .superRefine(({ source, otherSource }, ctx) => {
    if (
      (source === 'Other' && otherSource && otherSource.length < 2) ||
      (source === 'Other' && !otherSource)
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Please tell us where your funds come from',
        path: ['otherSource'],
      });
    }
    if (source === 'Other' && otherSource && otherSource.length > 50) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          'Please tell us where your funds come from in under 50 characters',
        path: ['otherSource'],
      });
    }
  });

export type SourceOfFundsForm = z.infer<typeof SourceOfFundsFormSchema>;
