import {
  Button,
  Dropdown,
  HeadingGroup,
  Separator,
  YStack,
} from '@aviva/ion-mobile';
import { InputField } from '@direct-wealth/components/input-field';
import { dropdownTabletContentStyles } from '@direct-wealth/features/isa-apply/style/index';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useSelector } from '@legendapp/state/react';
import { FormInput } from '@src/components/forms/form-input';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect, useMemo } from 'react';
import { Controller, useForm } from 'react-hook-form';
import { Keyboard } from 'react-native';

import { IsaApplyProgressStepper } from '../components/isa-apply-progress-stepper/isa-apply-progress-stepper';
import { IsaApplyScrollView } from '../components/isa-apply-scroll-view/isa-apply-scroll-view';
import { isaApplyBaseAnalyicsTag } from '../navigation/header/utils';
import { useIsaApplyStackNavigation } from '../navigation/hooks';
import { useIsaApply } from '../navigation/provider';
import { SOURCE_OF_FUNDS, SOURCE_OF_FUNDS_CONTINUE_TAPPED } from './analytics';
import {
  SourceOfFundsForm,
  SourceOfFundsFormSchema,
} from './source-of-funds-form';

export const SourceOfFundsScreen = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'isaApply.sourceOfFunds',
  });

  const { trackUserEvent } = useAnalytics();

  const { navigate } = useIsaApplyStackNavigation();
  const isaApplyState = useIsaApply();
  const hasSinglePayment = isaApplyState.payments.initial.amount.get() != null;
  const hasMonthlyPayment = isaApplyState.payments.monthly.amount.get() != null;

  const stateSingleSource = isaApplyState.payments.initial.sourceOfWealth.get();
  const stateSingleOtherSource =
    isaApplyState.payments.initial.otherSourceOfWealth.get();

  const stateMonthlySource =
    isaApplyState.payments.monthly.sourceOfWealth.get();
  const stateMonthlyOtherSource =
    isaApplyState.payments.monthly.otherSourceOfWealth.get();

  const { isNavigatorCustomer } = useSelector(isaApplyState);

  const ISA_APPLY_BASE_ANALYTICS = useMemo(
    () => isaApplyBaseAnalyicsTag(isNavigatorCustomer),
    [isNavigatorCustomer]
  );

  useOnPageLoad({
    pageTag: `${ISA_APPLY_BASE_ANALYTICS}|${SOURCE_OF_FUNDS}`,
  });

  const sourceOfWealthList =
    isaApplyState.dropdownValues.SourceOfWealthOption.get().map(
      (result) => result.displayValue ?? ''
    );

  const singleForm = useForm<SourceOfFundsForm>({
    resolver: zodResolver(SourceOfFundsFormSchema),
    mode: 'onChange',
    defaultValues: {
      source: isaApplyState.dropdownValues.SourceOfWealthOption.get().find(
        (item) => item.fnzEnumerationValue === stateSingleSource
      )?.displayValue,
      otherSource: stateSingleOtherSource,
    },
  });

  const monthlyForm = useForm<SourceOfFundsForm>({
    resolver: zodResolver(SourceOfFundsFormSchema),
    mode: 'onChange',
    defaultValues: {
      source: isaApplyState.dropdownValues.SourceOfWealthOption.get().find(
        (item) => item.fnzEnumerationValue === stateMonthlySource
      )?.displayValue,
      otherSource: stateMonthlyOtherSource,
    },
  });

  const [singleSourceValue] = singleForm.watch(['source']);
  const [monthlySourceValue] = monthlyForm.watch(['source']);

  const setSingleSourceOfFunds = () => {
    const singleSource = singleForm.getValues().source;
    const { otherSource } = singleForm.getValues();

    const singleSourceEnum =
      isaApplyState.dropdownValues.SourceOfWealthOption.get().find(
        (item) => item.displayValue === singleSource
      )?.fnzEnumerationValue;

    isaApplyState.payments.initial.sourceOfWealth.set(singleSourceEnum);
    isaApplyState.payments.initial.otherSourceOfWealth.set(otherSource);
  };

  const setMonthlySourceOfFunds = () => {
    const monthlySource = monthlyForm.getValues().source;
    const { otherSource } = monthlyForm.getValues();

    const monthlySourceEnum =
      isaApplyState.dropdownValues.SourceOfWealthOption.get().find(
        (item) => item.displayValue === monthlySource
      )?.fnzEnumerationValue;

    isaApplyState.payments.monthly.sourceOfWealth.set(monthlySourceEnum);
    isaApplyState.payments.monthly.otherSourceOfWealth.set(otherSource);
  };

  const handleContinue = () => {
    if (hasSinglePayment) {
      setSingleSourceOfFunds();
    }

    if (hasMonthlyPayment) {
      setMonthlySourceOfFunds();
    }

    trackUserEvent(
      `${ISA_APPLY_BASE_ANALYTICS}|${SOURCE_OF_FUNDS_CONTINUE_TAPPED}`
    );

    navigate('ISA Apply Review');
  };

  const buttonIsDisabled = useMemo(() => {
    return (
      !!(hasSinglePayment && !singleForm.formState.isValid) ||
      !!(hasMonthlyPayment && !monthlyForm.formState.isValid)
    );
  }, [
    hasMonthlyPayment,
    hasSinglePayment,
    monthlyForm.formState.isValid,
    singleForm.formState.isValid,
  ]);

  useEffect(() => {
    singleForm.trigger();
    monthlyForm.trigger();
  }, []);

  return (
    <IsaApplyScrollView>
      <IsaApplyProgressStepper currentStep={2} />
      <YStack flex={1}>
        <HeadingGroup heading={t('title')} subHeading={t('subtitle')} />
        <Separator borderColor="$Gray300" marginVertical="$xxl" />
        {hasSinglePayment && (
          <InputField
            label={t('singlePaymentLabel')}
            field={
              <Controller
                name="source"
                control={singleForm.control}
                render={({ field: { onChange, value } }) => (
                  <Dropdown
                    dropdownContentStyles={
                      isIpad && { ...dropdownTabletContentStyles }
                    }
                    required
                    value={value}
                    onValueChange={onChange}
                    items={sourceOfWealthList || []}
                    placeHolderText={t('dropdownPlaceholder')}
                    testID={getTestId('single-source-dropdown')}
                  />
                )}
              />
            }
            withMargin
          />
        )}
        {singleSourceValue === 'Other' && (
          <InputField
            label={t('otherSingleSourceLabel')}
            field={
              <FormInput
                control={singleForm.control}
                name="otherSource"
                placeholder={t('otherSourcePlaceholder')}
                tamaguiInputProps={{
                  returnKeyType: 'done',
                  onSubmitEditing: () => Keyboard.dismiss(),
                }}
                testID={getTestId('single-other-source')}
              />
            }
          />
        )}
        {hasMonthlyPayment && (
          <InputField
            label={t('monthlyPaymentLabel')}
            field={
              <Controller
                name="source"
                control={monthlyForm.control}
                render={({ field: { onChange, value } }) => (
                  <Dropdown
                    dropdownContentStyles={
                      isIpad && { ...dropdownTabletContentStyles }
                    }
                    required
                    value={value}
                    onValueChange={onChange}
                    items={sourceOfWealthList || []}
                    placeHolderText={t('dropdownPlaceholder')}
                    testID={getTestId('monthly-source-dropdown')}
                  />
                )}
              />
            }
            withMargin
          />
        )}
        {monthlySourceValue === 'Other' && (
          <InputField
            label={t('otherMonthlySourceLabel')}
            field={
              <FormInput
                control={monthlyForm.control}
                name="otherSource"
                placeholder={t('otherSourcePlaceholder')}
                tamaguiInputProps={{
                  returnKeyType: 'done',
                  onSubmitEditing: () => Keyboard.dismiss(),
                }}
                testID={getTestId('monthly-other-source')}
              />
            }
          />
        )}
      </YStack>
      <YStack testID={getTestId('continue-cta')} tabletNarrow={isIpad}>
        <Button onPress={handleContinue} disabled={buttonIsDisabled}>
          {t('continueCTA')}
        </Button>
      </YStack>
    </IsaApplyScrollView>
  );
};
