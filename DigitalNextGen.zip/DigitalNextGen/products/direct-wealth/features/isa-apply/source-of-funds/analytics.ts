export const SOURCE_OF_FUNDS = 'source-of-funds';
export const SOURCE_OF_FUNDS_CONTINUE_TAPPED = `${SOURCE_OF_FUNDS}|continue-tapped`;
