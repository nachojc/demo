import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { tokens } from '@src/theme/tokens';

import { isaApplyHeader } from './header/isa-apply-header';
import { IsaApplyProvider } from './provider';
import { EmploymentStatus } from './provider/state/employment-details';

export type IsaApplyStackScreenNames = keyof IsaApplyStackRouteParams;
export type IsaApplyStackRouteParams = {
  // Onboarding
  ['ISA Apply Landing']: undefined;
  ['ISA Apply ISA Product']: undefined;
  ['ISA Apply Before You Start']: undefined;
  ['ISA Apply Ready To Go']: undefined;
  // Investment
  ['ISA Apply Investment Selection']: undefined;
  ['ISA Apply Fund Selection']: undefined;
  ['ISA Apply Fund Details']: undefined;
  ['ISA Apply Allocation']: undefined;
  ['ISA Apply Allocation Edit']: undefined;
  // Payment
  ['ISA Apply Add Money']: undefined;
  ['ISA Apply Invest Now']: undefined; // Navigator Only
  ['ISA Apply Select Bank Details']: undefined;
  ['ISA Apply Add Bank Details']: undefined;
  ['ISA Apply Monthly Payment Day']: undefined; // Navigator Only
  // Personal Details
  ['ISA Apply Personal Details']: undefined;
  // Employment Details
  ['ISA Apply Employment Status']: undefined;
  ['ISA Apply Employment Information']: { employmentStatus: EmploymentStatus };
  // Source of Funds
  ['ISA Apply Source Of Funds']: undefined;
  // Review and Submit
  ['ISA Apply Review']: undefined;
  ['ISA Apply Direct Debit']: undefined;
  ['ISA Apply Important Information']: undefined;
  ['ISA Apply Thank You']: undefined;
};

const Stack = createNativeStackNavigator<IsaApplyStackRouteParams>();

export const IsaApplyScreens = () => {
  return (
    <IsaApplyProvider>
      <Stack.Navigator
        initialRouteName="ISA Apply Landing"
        screenOptions={{
          headerShown: true,
          header: isaApplyHeader,
        }}
      >
        <Stack.Group
          screenOptions={{
            header: isaApplyHeader,
            contentStyle: { backgroundColor: tokens.color.White.val },
          }}
        >
          <Stack.Screen
            name="ISA Apply Landing"
            getComponent={() =>
              require('../onboarding/landing-screen/landing-screen')
                .LandingScreen
            }
          />
          <Stack.Screen
            name="ISA Apply ISA Product"
            getComponent={() =>
              require('../onboarding/isa-product/isa-product-screen')
                .IsaProductScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Before You Start"
            getComponent={() =>
              require('../onboarding/before-you-start/before-you-start-screen.tsx')
                .BeforeYouStartScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Ready To Go"
            getComponent={() =>
              require('../onboarding/ready-to-go/ready-to-go-screen')
                .ReadyToGoScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Investment Selection"
            getComponent={() =>
              require('../investment/investment-selection/investment-selection-screen')
                .InvestmentSelectionScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Fund Selection"
            getComponent={() =>
              require('../investment/fund-selection/fund-selection-screen')
                .FundSelectionScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Fund Details"
            getComponent={() =>
              require('../investment/fund-details/fund-details-screen')
                .FundDetailsScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Allocation"
            getComponent={() =>
              require('../investment/allocation/allocation-screen')
                .AllocationScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Allocation Edit"
            getComponent={() =>
              require('../investment/allocation-edit/allocation-edit-screen')
                .AllocationEditScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Add Money"
            getComponent={() =>
              require('../payment/add-money/add-money-screen').AddMoneyScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Invest Now"
            getComponent={() =>
              require('../payment/invest-now/invest-now-screen').InvestNowScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Select Bank Details"
            getComponent={() =>
              require('../payment/select-bank-details/select-bank-details-screen')
                .SelectBankDetailsScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Add Bank Details"
            getComponent={() =>
              require('../payment/add-bank-details/add-bank-details-screen')
                .AddBankDetailsScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Monthly Payment Day"
            getComponent={() =>
              require('../payment/monthly-payment-day/monthly-payment-day-screen')
                .MonthlyPaymentDayScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Personal Details"
            getComponent={() =>
              require('../personal-details/personal-details-screen')
                .PersonalDetailsScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Employment Status"
            getComponent={() =>
              require('../employment-details/employment-status/employment-status-screen')
                .EmploymentStatusScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Employment Information"
            getComponent={() =>
              require('../employment-details/employment-information/employment-information-screen')
                .EmploymentInformationScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Source Of Funds"
            getComponent={() =>
              require('../source-of-funds/source-of-funds-screen')
                .SourceOfFundsScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Review"
            getComponent={() =>
              require('../review-and-submit/review/review-screen').ReviewScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Direct Debit"
            getComponent={() =>
              require('../review-and-submit/direct-debit/direct-debit-screen')
                .DirectDebitScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Important Information"
            getComponent={() =>
              require('../review-and-submit/important-information/important-information-screen')
                .ImportantInformationScreen
            }
          />
          <Stack.Screen
            name="ISA Apply Thank You"
            options={{ headerShown: false, gestureEnabled: false }}
            getComponent={() =>
              require('../review-and-submit/thank-you/thank-you-screen')
                .ThankYouScreen
            }
          />
        </Stack.Group>
      </Stack.Navigator>
    </IsaApplyProvider>
  );
};
