import {
  CompositeNavigationProp,
  useNavigation,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';

import { IsaApplyStackRouteParams } from './index';

type IsaApplyStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<IsaApplyStackRouteParams>,
  NativeStackNavigationProp<Pick<AppStackDWRouteParams, 'ProductDashboard'>>
>;

/**
 * @description A typed wrapper around useNavigation
 *
 * For use within the Isa Apply navigation stack
 */
export function useIsaApplyStackNavigation() {
  return useNavigation<IsaApplyStackNavigation>();
}
