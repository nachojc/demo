import {
  Button,
  Dropdown,
  EditAddressCard,
  HeadingGroup,
  Icon,
  Link,
  Separator,
  Stack,
  Text,
  TextInput,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import {
  AddressForm,
  AddressFormSchema,
} from '@aviva/ion-mobile/components/address-form/types';
import { PostcodeLookup } from '@aviva/ion-mobile/components/postcode-lookup/postcode-lookup';
import { InputField } from '@direct-wealth/components/input-field';
import { NationalInsuranceNumberModal } from '@direct-wealth/components/national-insurance-number-modal/national-insurance-number-modal';
import { dropdownTabletContentStyles } from '@direct-wealth/features/isa-apply/style/index';
import {
  PersonalDetailsForm,
  PersonalDetailsFormSchema,
} from '@direct-wealth/validation/schemas/isa-apply/personal-details';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useSelector } from '@legendapp/state/react';
import { PhoneNumberInput } from '@src/components/forms/phone-number-input';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useMemo, useState } from 'react';
import {
  Controller,
  SubmitHandler,
  useForm,
  UseFormReturn,
} from 'react-hook-form';
import { Keyboard } from 'react-native';

import { IsaApplyProgressStepper } from '../components/isa-apply-progress-stepper/isa-apply-progress-stepper';
import { IsaApplyScrollView } from '../components/isa-apply-scroll-view/isa-apply-scroll-view';
import { getFnzIdFromDisplayValue } from '../employment-details/employment-information/utils';
import { isaApplyBaseAnalyicsTag } from '../navigation/header/utils';
import { useIsaApplyStackNavigation } from '../navigation/hooks';
import { useIsaApply } from '../navigation/provider';
import { AddAddressModal } from './add-address-modal';
import {
  ADD_ADDRESS_TAPPED,
  CONTINUE_TAPPED,
  EDIT_ADDRESS_TAPPED,
  ENTER_ADDRESS_MANUALLY_CLOSE_TAPPED,
  ENTER_ADDRESS_MANUALLY_TAPPED,
  PERSONAL_DETAILS,
  PERSONAL_DETAILS_NINO_TOOLTIP_TAPPED,
  POSTCODE_LOOKUP_TAPPED,
  UPDATE_ADDRESS_CLOSE_TAPPED,
  UPDATE_ADDRESS_TAPPED,
} from './analytics';
import { CustomerNameSection } from './customer-name-section';
import { EditAddressModal } from './edit-address-modal';

export const PersonalDetailsScreen = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'isaApply.personalDetails',
  });
  const { navigate } = useIsaApplyStackNavigation();
  const { personalDetails } = useIsaApply();
  const { title, nino, nationality, contactNumber, address } =
    useSelector(personalDetails);
  const { trackUserEvent } = useAnalytics();

  const DEFAULT_VALID_CONTACT = '07912345678';

  // We hard code a valid default value for contact number if a prepop value exists.
  // This is due to rare occasions where prepop values do not meet our validation.
  // On handleContinue the prepop value is used.

  const form = useForm<PersonalDetailsForm>({
    resolver: zodResolver(PersonalDetailsFormSchema),
    mode: 'onChange',
    defaultValues: {
      title: title ?? undefined,
      nationalInsuranceNumber: nino ?? undefined,
      nationality: nationality ?? undefined,
      phoneNumber: {
        number: contactNumber?.number ? DEFAULT_VALID_CONTACT : undefined,
        country: {
          code: contactNumber?.code ?? '+44',
          name: contactNumber?.name ?? 'United Kingdom',
        },
      },
    },
  });

  const isaState = useIsaApply();

  const { isNavigatorCustomer, dropdownValues } = useSelector(isaState);

  const ISA_APPLY_BASE_ANALYTICS = useMemo(
    () => isaApplyBaseAnalyicsTag(isNavigatorCustomer),
    [isNavigatorCustomer]
  );

  useOnPageLoad({
    pageTag: `${ISA_APPLY_BASE_ANALYTICS}|${PERSONAL_DETAILS}`,
  });

  const handleContinue: SubmitHandler<PersonalDetailsForm> = async (
    formData
  ) => {
    personalDetails.title.set(formData.title);
    personalDetails.nino.set(formData.nationalInsuranceNumber);
    const nationalityToSet = getFnzIdFromDisplayValue(
      formData.nationality,
      dropdownValues?.Country
    );
    personalDetails.nationality.set(nationalityToSet);
    if (!contactNumber?.number) {
      personalDetails.contactNumber.set({
        code: formData.phoneNumber.country.code,
        number: formData.phoneNumber.number,
      });
    }
    trackUserEvent(`${ISA_APPLY_BASE_ANALYTICS}|${CONTINUE_TAPPED}`);
    navigate('ISA Apply Employment Status');
  };

  return (
    <IsaApplyScrollView>
      <IsaApplyProgressStepper currentStep={2} />
      <YStack justifyContent="space-between" flex={1} mt={'$xs'}>
        <Stack>
          <HeadingGroup heading={t('title')} subHeading={t('subtitle')} />
          <Separator
            borderColor="$Gray200"
            marginVertical="$xxl"
            testID={getTestId('separator')}
          />
          <CustomerNameSection baseTag={ISA_APPLY_BASE_ANALYTICS} />
          {!title && <TitleInput form={form} />}
          {!nino && (
            <NinoInput form={form} baseTag={ISA_APPLY_BASE_ANALYTICS} />
          )}
          {!nationality && <NationalityInput form={form} />}
          {!contactNumber?.number && <MobileNumberInput form={form} />}
          <AddressSection baseTag={ISA_APPLY_BASE_ANALYTICS} />
        </Stack>
        <YStack testID={getTestId('continue-cta')} tabletNarrow={isIpad}>
          <Button
            marginTop={'$xxxl'}
            onPress={form.handleSubmit(handleContinue)}
            disabled={!(form.formState.isValid && address != null)}
          >
            {t('continueCTA')}
          </Button>
        </YStack>
      </YStack>
    </IsaApplyScrollView>
  );
};

const defaultAddress = {
  lineOne: '',
  lineTwo: null,
  lineThree: null,
  town: '',
  postcode: '',
};

type TitleInputProps = {
  form: UseFormReturn<PersonalDetailsForm>;
};

const TitleInput = ({ form }: TitleInputProps) => {
  const { t } = useTranslationDW({ keyPrefix: 'isaApply.personalDetails' });
  const { dropdownValues } = useIsaApply();
  const { control } = form;

  return (
    <Controller
      name="title"
      control={control}
      render={({ field: { onChange, value } }) => {
        return (
          <InputField
            label={t('userTitle')}
            field={
              <Dropdown
                dropdownContentStyles={
                  isIpad && { ...dropdownTabletContentStyles }
                }
                required
                value={value}
                onValueChange={onChange}
                items={dropdownValues.PersonTitle.get().map(
                  (result) => result.displayValue!
                )}
                searchBar={false}
                placeHolderText={t('titlePlaceholder')}
                testID={getTestId('Title Dropdown')}
                accessibilityLabel={t('userTitleAccessibility')}
              />
            }
            withMargin
          />
        );
      }}
    />
  );
};

const NinoInput = ({
  form,
  baseTag,
}: {
  form: UseFormReturn<PersonalDetailsForm>;
  baseTag: string;
}) => {
  const { t } = useTranslationDW({ keyPrefix: 'isaApply.personalDetails' });
  const { trackUserEvent } = useAnalytics();
  const [ninoModalIsVisible, setNinoModalIsVisible] = useState(false);

  const onTooltipPress = () => {
    trackUserEvent(`${baseTag}|${PERSONAL_DETAILS_NINO_TOOLTIP_TAPPED}`);
    setNinoModalIsVisible(true);
  };

  return (
    <>
      <Stack space={'$md'} marginBottom={'$xxl'}>
        <XStack justifyContent="space-between">
          <Text fontVariant="body-semibold-Secondary800">
            {t('ninoInputTitle')}
          </Text>
          <Stack
            onPress={onTooltipPress}
            accessible
            accessibilityLabel={t('ninoInputAccessibilityLabel')}
            accessibilityRole={'button'}
            hitSlop={{ top: 24, bottom: 24, left: 24, right: 24 }}
          >
            <Icon
              color={tokens.color.Secondary800.val}
              height={tokens.size[5].val}
              name="info"
              width={tokens.size[5].val}
            />
          </Stack>
        </XStack>
        <Text fontVariant="small-regular-Secondary800">
          {t('ninoInputDescription')}
        </Text>
        <Controller
          name={'nationalInsuranceNumber'}
          control={form.control}
          render={({ field: { onChange, value }, fieldState }) => {
            return (
              <TextInput
                testID={getTestId('national-insurance-number')}
                tamaguiInputProps={{
                  value,
                  onChangeText: onChange,
                  placeholder: t('ninoInputPlaceholder'),
                  returnKeyType: 'done',
                  onSubmitEditing: () => Keyboard.dismiss(),
                  marginBottom: 0,
                }}
                required
                error={fieldState.invalid}
                errorText={t('ninoInputError')}
              />
            );
          }}
        />
      </Stack>
      <NationalInsuranceNumberModal
        isVisible={ninoModalIsVisible}
        setIsVisible={setNinoModalIsVisible}
        pageTag={`${baseTag}|${PERSONAL_DETAILS}`}
      />
    </>
  );
};

type NationalityInputProps = {
  form: UseFormReturn<PersonalDetailsForm>;
};
const NationalityInput = ({ form }: NationalityInputProps) => {
  const { t } = useTranslationDW({ keyPrefix: 'isaApply.personalDetails' });
  const { dropdownValues } = useIsaApply();
  const { control } = form;

  return (
    <Controller
      name="nationality"
      control={control}
      render={({ field: { onChange, value } }) => {
        return (
          <InputField
            label={t('nationality')}
            field={
              <Dropdown
                dropdownContentStyles={
                  isIpad && { ...dropdownTabletContentStyles }
                }
                required
                value={value}
                onValueChange={onChange}
                items={dropdownValues.Country.get().map(
                  (result) => result.displayValue!
                )}
                searchBar
                placeHolderText={t('nationalityPlaceholder')}
                testID={getTestId('Nationality')}
                accessibilityLabel={t('nationalityAccessibility')}
              />
            }
            withMargin
          />
        );
      }}
    />
  );
};

const MobileNumberInput = ({
  form,
}: {
  form: UseFormReturn<PersonalDetailsForm>;
}) => {
  const { t } = useTranslationDW({ keyPrefix: 'isaApply.personalDetails' });
  const { control } = form;

  return (
    <Stack space={'$md'} marginBottom={'$xxl'}>
      <Stack
        space={'$md'}
        accessible
        accessibilityLabel={`${t('phoneNumber')}. ${t(
          'phoneNumberInputDescription'
        )}`}
      >
        <Text
          fontVariant="body-semibold-Secondary800"
          tamaguiTextProps={{ lineHeight: '$small' }}
        >
          {t('phoneNumber')}
        </Text>
        <Text
          fontVariant="small-regular-Secondary800"
          tamaguiTextProps={{ lineHeight: '$overline' }}
        >
          {t('phoneNumberInputDescription')}
        </Text>
      </Stack>
      <Controller
        name="phoneNumber"
        control={control}
        render={({ field: { onChange, value }, fieldState }) => {
          const { number, country } = value;
          return (
            <PhoneNumberInput
              dropdownContentStyles={
                isIpad && { ...dropdownTabletContentStyles }
              }
              required
              countryCode={country}
              number={number}
              onChange={onChange}
              error={fieldState.invalid}
              errorText={t('phoneNumberError')}
              placeholder={t('phoneNumberPlaceholder')}
            />
          );
        }}
      />
    </Stack>
  );
};

const AddressSection = ({ baseTag }: { baseTag: string }) => {
  const { trackUserEvent } = useAnalytics();
  const { t } = useTranslationDW({
    keyPrefix: 'isaApply.personalDetails.addressSection',
  });
  const isaApplyState = useIsaApply();
  const [isAddAddressModalVisible, setIsAddAddressModalVisible] =
    useState(false);
  const [isEditAddressModalVisible, setIsEditAddressModalVisible] =
    useState(false);

  const address = useSelector(isaApplyState.personalDetails.address);
  const hasCustomerAddress = address != null;

  const addressForm = useForm<AddressForm>({
    resolver: zodResolver(AddressFormSchema),
    defaultValues: defaultAddress,
    mode: 'onBlur',
  });

  const onEnterAddressManuallyPressed = () => {
    trackUserEvent(`${baseTag}|${ENTER_ADDRESS_MANUALLY_TAPPED}`);
    setIsAddAddressModalVisible(true);
    addressForm.reset(defaultAddress);
  };

  const onEditAddressPressed = () => {
    trackUserEvent(`${baseTag}|${EDIT_ADDRESS_TAPPED}`);
    setIsEditAddressModalVisible(true);
    populateCurrentAddress();
  };

  const handleCloseAddAddressModal = () => {
    setIsAddAddressModalVisible(false);
    addressForm.reset();
  };

  const handleCloseEditAddressModal = () => {
    setIsEditAddressModalVisible(false);
    addressForm.reset();
  };

  const onCloseAddAddressModalPressed = () => {
    trackUserEvent(`${baseTag}|${ENTER_ADDRESS_MANUALLY_CLOSE_TAPPED}`);
    handleCloseAddAddressModal();
  };

  const onCloseEditAddressModalPressed = () => {
    trackUserEvent(`${baseTag}|${UPDATE_ADDRESS_CLOSE_TAPPED}`);
    handleCloseEditAddressModal();
  };

  const setAddressState = () => {
    const addressValues = addressForm.getValues();
    isaApplyState.personalDetails.address.set({
      firstLineOfAddress: addressValues.lineOne,
      secondLineOfAddress: addressValues.lineTwo ?? '',
      thirdLineOfAddress: addressValues.lineThree ?? '',
      townOrCity: addressValues.town,
      postcode: addressValues.postcode,
      country: 'United Kingdom',
    });
  };

  const onAddAddressPressed = () => {
    trackUserEvent(`${baseTag}|${ADD_ADDRESS_TAPPED}`);
    setAddressState();
    handleCloseAddAddressModal();
  };

  const onUpdateAddressPressed = () => {
    trackUserEvent(`${baseTag}|${UPDATE_ADDRESS_TAPPED}`);
    setAddressState();
    handleCloseEditAddressModal();
  };

  const onPostcodeLookupPressed = () => {
    trackUserEvent(`${baseTag}|${POSTCODE_LOOKUP_TAPPED}`);
  };

  const populateCurrentAddress = () => {
    addressForm.reset({
      lineOne: address.firstLineOfAddress ?? '',
      lineTwo: address.secondLineOfAddress,
      lineThree: address.thirdLineOfAddress,
      town: address.townOrCity ?? '',
      postcode: address.postcode ?? '',
    });
  };

  return (
    <YStack>
      {hasCustomerAddress ? (
        <EditAddressCard
          cardContent={address}
          onCardPress={onEditAddressPressed}
        />
      ) : (
        <>
          <PostcodeLookup
            form={addressForm}
            onAddressSelect={setAddressState}
            onPostcodeSearchTapped={onPostcodeLookupPressed}
          />
          <Link onPress={onEnterAddressManuallyPressed}>
            {t('addManuallyCTA')}
          </Link>
        </>
      )}
      <AddAddressModal
        isIpad={isIpad}
        isVisible={isAddAddressModalVisible}
        addressForm={addressForm}
        onAddAddressPressed={onAddAddressPressed}
        onClosePressed={onCloseAddAddressModalPressed}
      />
      <EditAddressModal
        isIpad={isIpad}
        isVisible={isEditAddressModalVisible}
        addressForm={addressForm}
        onUpdateAddressPressed={onUpdateAddressPressed}
        onClosePressed={onCloseEditAddressModalPressed}
      />
    </YStack>
  );
};
