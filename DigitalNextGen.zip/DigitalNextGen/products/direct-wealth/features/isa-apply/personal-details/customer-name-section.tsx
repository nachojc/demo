import { Link, Text, YStack } from '@aviva/ion-mobile';
import { UpdateYourDetailsDialog } from '@direct-wealth/components/update-details-dialog/update-details-dialog';
import { useAnalytics } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useState } from 'react';

import { useIsaApply } from '../navigation/provider';
import {
  PERSONAL_DETAILS_UPDATE_DETAILS_DIALOG,
  PERSONAL_DETAILS_UPDATE_DETAILS_DIALOG_CANCEL_TAPPED,
  PERSONAL_DETAILS_UPDATE_DETAILS_DIALOG_CONTINUE_TAPPED,
  PERSONAL_DETAILS_UPDATE_NAME_TAPPED,
} from './analytics';

export const CustomerNameSection = ({ baseTag }: { baseTag: string }) => {
  const { t } = useTranslationDW({
    keyPrefix: 'isaApply.personalDetails',
  });
  const [displayUpdateNameDialog, setDisplayUpdateNameDialog] = useState(false);
  const { trackUserEvent } = useAnalytics();
  const { personalDetails } = useIsaApply();
  const { firstName, lastName } = personalDetails.get();

  const onUpdateNamePress = () => {
    setDisplayUpdateNameDialog(true);
    trackUserEvent(`${baseTag}|${PERSONAL_DETAILS_UPDATE_NAME_TAPPED}`);
  };

  const onUpdateDetailsDialogContinuePress = () => {
    trackUserEvent(
      `${baseTag}|${PERSONAL_DETAILS_UPDATE_DETAILS_DIALOG_CONTINUE_TAPPED}`
    );
    setDisplayUpdateNameDialog(false);
  };

  const onUpdateDetailsDialogCancelPress = () => {
    trackUserEvent(
      `${baseTag}|${PERSONAL_DETAILS_UPDATE_DETAILS_DIALOG_CANCEL_TAPPED}`
    );
    setDisplayUpdateNameDialog(false);
  };

  return (
    <>
      <YStack space={'$md'} marginBottom={'$xxl'}>
        <Text
          fontVariant="body-semibold-Secondary800"
          tamaguiTextProps={{ lineHeight: '$small' }}
        >
          {t('name')}
        </Text>
        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{ lineHeight: '$small' }}
        >
          {`${firstName} ${lastName}`}
        </Text>
        <Link
          LinkTextProps={{
            fontSize: '$small',
            textDecorationLine: 'underline',
          }}
          onPress={onUpdateNamePress}
        >
          {t('updateName')}
        </Link>
      </YStack>

      {displayUpdateNameDialog && (
        <UpdateYourDetailsDialog
          analyticsTag={`${baseTag}|${PERSONAL_DETAILS_UPDATE_DETAILS_DIALOG}`}
          isVisible={displayUpdateNameDialog}
          onCancelPress={onUpdateDetailsDialogCancelPress}
          onContinuePress={onUpdateDetailsDialogContinuePress}
          title={t('updateNameDialogTitle')}
        />
      )}
    </>
  );
};
