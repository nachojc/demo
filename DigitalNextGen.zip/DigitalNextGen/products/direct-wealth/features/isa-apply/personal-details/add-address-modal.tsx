import { Button, Modal, Stack, Text, YStack } from '@aviva/ion-mobile';
import { AddressInputForm } from '@aviva/ion-mobile/components/address-form/address-form';
import { AddressForm } from '@aviva/ion-mobile/components/address-form/types';
import { DropdownBaseProps } from '@aviva/ion-mobile/components/dropdown-types/dropdown/types';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { UseFormReturn } from 'react-hook-form';
import { KeyboardAvoidingView } from 'react-native';

type AddAddressModalProps = Pick<DropdownBaseProps, 'modalStyles'> & {
  isIpad?: boolean;
  isVisible: boolean;
  addressForm: UseFormReturn<AddressForm>;
  onAddAddressPressed: () => void;
  onClosePressed: () => void;
};

export const AddAddressModal = ({
  isIpad = false,
  isVisible,
  addressForm,
  onAddAddressPressed,
  onClosePressed,
  modalStyles,
}: AddAddressModalProps) => {
  const { t } = useTranslationDW({
    keyPrefix: 'isaApply.personalDetails.addAddressModal',
  });
  const {
    formState: { isValid },
  } = addressForm;
  return (
    <Modal
      modalStyles={modalStyles}
      isOpen={isVisible}
      onClose={onClosePressed}
      backgroundColor="White"
      closeIconColor={'Secondary800'}
      modalHeight={0.9}
    >
      <KeyboardAvoidingView
        style={{ flex: 1, justifyContent: 'space-between' }}
      >
        <Stack>
          <Text
            fontVariant={'heading4-light-Gray800'}
            tamaguiTextProps={{ paddingBottom: '$xxl' }}
          >
            {t('addAddress')}
          </Text>
          <AddressInputForm form={addressForm} />
        </Stack>
        <YStack tabletNarrow={isIpad}>
          <Button onPress={onAddAddressPressed} disabled={!isValid}>
            {t('addAddress')}
          </Button>
        </YStack>
      </KeyboardAvoidingView>
    </Modal>
  );
};
