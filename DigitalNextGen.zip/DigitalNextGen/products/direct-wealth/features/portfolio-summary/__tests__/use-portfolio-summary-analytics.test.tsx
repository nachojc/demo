import {
  mockTrackStateEvent,
  mockTrackUserEvent,
  renderHook,
} from '@src/jest/testing-library';

import { usePortfolioSummaryAnalytics } from '../hooks/use-portfolio-summary-analytics';
import { ProductStatus } from '../types';

describe('use-portfolio-summary-analytics', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it.each([
    ['Error', 'ukmyaviva|wealth|fullscreenerror'],
    ['Loading', 'ukmyaviva|wealth|loading'],
    ['PendingModal', 'ukmyaviva|wealth|portfolio-summary|pendingmodal'],
    ['Ready', 'ukmyaviva|wealth|portfolio-summary'],
    ['LockedModal', 'ukmyaviva|wealth|portfolio-summary|lockedmodal'],
  ] as const)(
    'should send the correct screen tag when the screen status is $screenStatus',
    (screenStatus, expectedTag) => {
      const { result } = renderHook(usePortfolioSummaryAnalytics);

      result.current.sendScreenEventTag(screenStatus);

      expect(mockTrackStateEvent).toHaveBeenCalledWith(expectedTag);
    }
  );

  it.each([
    [
      'Drawdown',
      ProductStatus.Active,
      'ukmyaviva|wealth|portfolio-summary|pensiondrawdowncard-tapped',
    ],
    [
      'GIA',
      ProductStatus.Active,
      'ukmyaviva|wealth|portfolio-summary|investmentaccountcard-tapped',
    ],
    [
      'ISA',
      ProductStatus.Active,
      'ukmyaviva|wealth|portfolio-summary|stocksandsharesisacard-tapped',
    ],
    [
      'SIPP',
      ProductStatus.Active,
      'ukmyaviva|wealth|portfolio-summary|pensioncard-tapped',
    ],
    [
      'Drawdown',
      ProductStatus.Closing,
      'ukmyaviva|wealth|portfolio-summary|accountclosingpensiondrawdowncard-tapped',
    ],
    [
      'GIA',
      ProductStatus.Closing,
      'ukmyaviva|wealth|portfolio-summary|accountclosinginvestmentaccountcard-tapped',
    ],
    [
      'ISA',
      ProductStatus.Closing,
      'ukmyaviva|wealth|portfolio-summary|accountclosingstocksandsharesisacard-tapped',
    ],
    [
      'SIPP',
      ProductStatus.Closing,
      'ukmyaviva|wealth|portfolio-summary|accountclosingpensioncard-tapped',
    ],
    [
      'GIA',
      ProductStatus.Locked,
      'ukmyaviva|wealth|portfolio-summary|lockedinvestmentaccountcard-tapped',
    ],
    [
      'ISA',
      ProductStatus.Locked,
      'ukmyaviva|wealth|portfolio-summary|lockedstocksandsharesisacard-tapped',
    ],
    [
      'SIPP',
      ProductStatus.Locked,
      'ukmyaviva|wealth|portfolio-summary|lockedpensioncard-tapped',
    ],
    [
      'GIA',
      ProductStatus.Pending,
      'ukmyaviva|wealth|portfolio-summary|pendinginvestmentaccountcard-tapped',
    ],
    [
      'ISA',
      ProductStatus.Pending,
      'ukmyaviva|wealth|portfolio-summary|pendingstocksandsharesisacard-tapped',
    ],
    [
      'SIPP',
      ProductStatus.Pending,
      'ukmyaviva|wealth|portfolio-summary|pendingpensioncard-tapped',
    ],
    [
      'Drawdown',
      ProductStatus.Submitted,
      'ukmyaviva|wealth|portfolio-summary|accountopeningpensiondrawdowncard-tapped',
    ],
    [
      'GIA',
      ProductStatus.Submitted,
      'ukmyaviva|wealth|portfolio-summary|accountopeninginvestmentaccountcard-tapped',
    ],
    [
      'ISA',
      ProductStatus.Submitted,
      'ukmyaviva|wealth|portfolio-summary|accountopeningstocksandsharesisacard-tapped',
    ],
    [
      'SIPP',
      ProductStatus.Submitted,
      'ukmyaviva|wealth|portfolio-summary|accountopeningpensioncard-tapped',
    ],
  ] as const)(
    'should send the correct card action tag when account type is $accountType and status is $productStatus',
    (accountType, productStatus, expectedTag) => {
      const { result } = renderHook(usePortfolioSummaryAnalytics);

      result.current.sendCardActionTag(accountType, productStatus);

      expect(mockTrackUserEvent).toHaveBeenCalledWith(expectedTag);
    }
  );

  it.each`
    promoType                 | expectedTag
    ${'displayGiaPromotion'}  | ${'ukmyaviva|wealth|portfolio-summary|investmentaccountpromo-tapped'}
    ${'displayIsaPromotion'}  | ${'ukmyaviva|wealth|portfolio-summary|stocksandsharesisapromo-tapped'}
    ${'displaySippPromotion'} | ${'ukmyaviva|wealth|portfolio-summary|pensionpromo-tapped'}
  `(
    'should send the correct promo card action tag when the promo type is $promoType',
    ({ promoType, expectedTag }) => {
      const { result } = renderHook(usePortfolioSummaryAnalytics);

      result.current.sendPromoCardActionTag(promoType, true);

      expect(mockTrackUserEvent).toHaveBeenCalledWith(expectedTag);
    }
  );

  it.each`
    promoType                 | expectedTag
    ${'displayGiaPromotion'}  | ${'ukmyaviva|wealth|portfolio-summary|no-products|investmentaccountpromo-tapped'}
    ${'displayIsaPromotion'}  | ${'ukmyaviva|wealth|portfolio-summary|no-products|stocksandsharesisapromo-tapped'}
    ${'displaySippPromotion'} | ${'ukmyaviva|wealth|portfolio-summary|no-products|pensionpromo-tapped'}
  `(
    'should send the correct promo card action tag when the promo type is $promoType and user has no DW products',
    ({ promoType, expectedTag }) => {
      const { result } = renderHook(usePortfolioSummaryAnalytics);

      result.current.sendPromoCardActionTag(promoType, false);

      expect(mockTrackUserEvent).toHaveBeenCalledWith(expectedTag);
    }
  );

  it.each([
    [
      'PendingAccept',
      'ukmyaviva|wealth|portfolio-summary|pendingmodal|ok-tapped',
    ],
    ['Retry', 'ukmyaviva|wealth|fullscreenerror|retry-tapped'],
    [
      'LockedModalCancel',
      'ukmyaviva|wealth|portfolio-summary|lockedmodal|cancel-tapped',
    ],
    [
      'LockedModalUnlockPortfolio',
      'ukmyaviva|wealth|portfolio-summary|lockedmodal|unlock-portfolio-tapped',
    ],
    [
      'LockedUnlockPortfolio',
      'ukmyaviva|wealth|portfolio-summary|locked|unlock-portfolio-tapped',
    ],
    ['GainLossTooltip', 'ukmyaviva|wealth|portfolio-summary|help-icon-tapped'],
  ] as const)(
    'should send the correct button action tag when the button type is $buttonType',
    (buttonType, expectedTag) => {
      const { result } = renderHook(usePortfolioSummaryAnalytics);

      result.current.sendButtonActionTag(buttonType);

      expect(mockTrackUserEvent).toHaveBeenCalledWith(expectedTag);
    }
  );
});
