import { fireEvent, render, screen, waitFor } from '@src/jest/testing-library';
import { SimpleWealthOnboardingCardStatus } from '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey';
import { NavigationContainer } from '@react-navigation/native';

import { PortfolioSummaryScreenView } from '../portfolio-summary-screen';
import { usePortfolioSummaryViewModel } from '../use-portfolio-summary-view-model';

type DeepPartial<T> = T extends (infer U)[]
  ? DeepPartial<U>[]
  : { [P in keyof T]?: DeepPartial<T[P]> };

type PortfolioSummaryTestViewProps = DeepPartial<
  ReturnType<typeof usePortfolioSummaryViewModel>
>;

const mockAppStackNavigate = jest.fn();
jest.mock('src/navigation/app/hooks.ts', () => ({
  useAppStackNavigation: () => ({
    navigate: mockAppStackNavigate,
    reset: jest.fn(),
  }),
}));

jest.mock('@src/navigation/linking', () => ({
  SavedDeepLink: {
    get: () => 'some-random-deep-link',
    delete: () => jest.fn(),
  },
}));
const mockRefetchGetApi = jest.fn();
let mockIsSimpleWealthGetApiError = true;

jest.mock(
  '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey',
  () => ({
    useInitialiseSimpleWealthJourney: () => ({
      isSimpleWealthEnabled: true,
      simpleWealthGetApiRefetch: mockRefetchGetApi,
      simpleWealthOnboardingCardStatus:
        'initial' as SimpleWealthOnboardingCardStatus,
      isSimpleWealthGetApiError: mockIsSimpleWealthGetApiError,
    }),
  })
);

jest.useFakeTimers();

const PortfolioSummaryScreenOnboardingTestView = (
  props: PortfolioSummaryTestViewProps
) => {
  const model = usePortfolioSummaryViewModel();
  return (
    <NavigationContainer>
      <PortfolioSummaryScreenView
        model={{
          ...model,
          ...(props as typeof model),
          isEnquirer: true,
        }}
      />
    </NavigationContainer>
  );
};

describe('Portfolio summary screen get api error', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should show the post api error dialog', async () => {
    mockIsSimpleWealthGetApiError = true;
    render(<PortfolioSummaryScreenOnboardingTestView />);

    const errorDialog = await screen.findByText(
      "We're sorry, something went wrong."
    );

    await waitFor(async () => {
      expect(errorDialog).toBeTruthy();
    });

    const okButton = await screen.findByText('OK');
    expect(okButton).toBeTruthy();

    fireEvent.press(okButton);

    await waitFor(() => {
      expect(mockRefetchGetApi).toHaveBeenCalled();
    });
  });

  it('should not show the post api error dialog', async () => {
    mockIsSimpleWealthGetApiError = false;
    render(<PortfolioSummaryScreenOnboardingTestView />);

    const errorDialog = screen.queryByText(
      "We're sorry, something went wrong."
    );
    await waitFor(() => {
      expect(errorDialog).toBeNull();
    });
  });
});
