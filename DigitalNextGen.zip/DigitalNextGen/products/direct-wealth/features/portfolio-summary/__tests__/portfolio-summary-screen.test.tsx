import {
  act,
  cleanup,
  fireEvent,
  mockTrackUserEvent,
  render,
  screen,
  waitFor,
} from '@src/jest/testing-library';
import { SimpleWealthOnboardingCardStatus } from '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey';
import {
  navigatorShouldShowOnboardingPopup,
  unlockProductRequested,
} from '@interfaces/storage';
import { NavigationContainer } from '@react-navigation/native';
import { setMock } from '@src/api-mock/helpers';
import defaultAccountData from '@src/api-mock/responses/DirectWealth/account/Default_account.json';
import { config } from '@src/common/config';
import { FeatureFlags } from '@src/feature-flags';
import { getTestId } from '@src/utils/get-test-id';
import { Products } from '@src/validation/schemas/product/products';

import { Constants } from '../../../components/gain-loss-tooltip/constants';
import { PortfolioSummaryScreenView } from '../portfolio-summary-screen';
import { usePortfolioSummaryViewModel } from '../use-portfolio-summary-view-model';

const findAndCombineCardText =
  'Find lost pensions and easily combine your money in one place';

jest.useFakeTimers();

type DeepPartial<T> = T extends (infer U)[]
  ? DeepPartial<U>[]
  : { [P in keyof T]?: DeepPartial<T[P]> };

type PortfolioSummaryTestViewProps = DeepPartial<
  ReturnType<typeof usePortfolioSummaryViewModel>
>;

const mockRefetchGetApi = jest.fn();
let mockIsSimpleWealthGetApiError = false;
let mockIsSimpleWealthEnabled = true;
let mockSimpleWealthOnboardingCardStatus =
  'initial' as SimpleWealthOnboardingCardStatus;
const mockDaysToAdviceExpiry = 6;
const mockHasOpportunity = true;
const mockSimpleWealthCardPressed = jest.fn();

jest.mock(
  '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey',
  () => ({
    useInitialiseSimpleWealthJourney: () => ({
      isSimpleWealthEnabled: mockIsSimpleWealthEnabled,
      simpleWealthGetApiRefetch: mockRefetchGetApi,
      simpleWealthOnboardingCardStatus: mockSimpleWealthOnboardingCardStatus,
      isSimpleWealthGetApiError: mockIsSimpleWealthGetApiError,
      daysToAdviceExpiry: mockDaysToAdviceExpiry,
      hasOpportunity: mockHasOpportunity,
      simpleWealthCardPressed: mockSimpleWealthCardPressed,
    }),
  })
);

let mockIsPCSEntryPointViewModelError = false;
jest.mock(
  '../../pension-consolidation-summary/use-pcs-entry-point-view-model',
  () => ({
    usePCSEntryPointViewModel: () => ({
      shouldRenderPCSEntryPointView: true,
      pensionStatus: {
        hasPensions: true,
        pensionsInTransfer: 1,
        pensionsNotInTransfer: 6,
      },
      isError: mockIsPCSEntryPointViewModelError,
    }),
  })
);

const mockDirectWealthTabStackNavigate = jest.fn();
jest.mock('../../../navigation/hooks.ts', () => ({
  useDirectWealthTabStackNavigation: () => ({
    navigate: mockDirectWealthTabStackNavigate,
  }),
}));

const mockAppStackNavigate = jest.fn();
jest.mock('src/navigation/app/hooks.ts', () => ({
  useAppStackNavigation: () => ({
    navigate: mockAppStackNavigate,
    reset: jest.fn(),
  }),
}));

jest.mock('@src/navigation/linking', () => ({
  SavedDeepLink: {
    get: () => 'some-random-deep-link',
    delete: () => jest.fn(),
  },
}));

const mockProducts: Products[] = [
  {
    __tag: 'Unknown',
    PolicyNumber: 'VB61009824',
    SecurePolicyNumber: 'VB61009824',
    ProductType: 'HeritageProtectionDpaFull',
    ProductCode: '20040',
    IsLoaded: true,
    DisplayName: 'Life insurance',
  },
  {
    __tag: 'Unknown',
    PolicyNumber: 'VB61009824',
    SecurePolicyNumber: 'VB61009824',
    ProductType: 'HeritageProtectionDpaFull',
    ProductCode: '20040',
    IsLoaded: true,
    DisplayName: 'Life insurance',
  },
];

const mockSetPoliciesCount = jest.fn();
const mockSetProdDetails = jest.fn();
jest.mock('../../../common/hooks/use-policies-context-keys', () => ({
  usePoliciesContextKeys: () => ({
    setPoliciesCountContextKeys: mockSetPoliciesCount,
    setProdDetails: mockSetProdDetails,
    policiesContextKeysRef: { current: {} },
  }),
}));

jest.mock('@hooks/use-auth', () => ({
  useAuth: () => ({
    isSignedIn: true,
  }),
}));

jest.mock('../components/portfolio-summary-chart', () => ({
  PortfolioSummaryChart: jest.fn(),
}));

jest.mock('@react-navigation/native', () => {
  const actualNav = jest.requireActual('@react-navigation/native');
  return { ...actualNav, useIsFocused: () => true };
});

let mockIsManga = true;
jest.mock('@hooks/use-expo-config', () => ({
  isManga: () => mockIsManga,
  getAppID: () => 'co.uk.aviva.myaviva',
  displayName: () => 'MyAviva',
}));

const PortfolioSummaryScreenTestView = (
  props: PortfolioSummaryTestViewProps
) => {
  const model = usePortfolioSummaryViewModel();
  return (
    <NavigationContainer>
      <PortfolioSummaryScreenView
        model={{
          ...model,
          ...(props as typeof model),
        }}
      />
    </NavigationContainer>
  );
};

const PortfolioSummaryScreenOnboardingTestView = (
  props: PortfolioSummaryTestViewProps
) => {
  const model = usePortfolioSummaryViewModel();
  return (
    <NavigationContainer>
      <PortfolioSummaryScreenView
        model={{
          ...model,
          ...(props as typeof model),
          isEnquirer: true,
        }}
      />
    </NavigationContainer>
  );
};

describe('Portfolio summary screen', () => {
  beforeEach(() => {
    jest.useFakeTimers().setSystemTime(new Date('2023-10-30'));
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
    cleanup();
  });

  it('should render error text if isError === true', async () => {
    render(<PortfolioSummaryScreenTestView isError />);
    act(() => jest.runAllTimers());
    const errorHeader = await screen.findByText('Something went wrong');
    const errorMessage = screen.getByText(
      'We were unable to load your information at this time. Please try again later.'
    );
    expect(errorHeader).toBeOnTheScreen();
    expect(errorMessage).toBeOnTheScreen();
  });

  it('should render loading screen if isLoading === true', () => {
    render(<PortfolioSummaryScreenTestView isLoading />);
    expect(screen.getByLabelText('Loading visual')).toBeOnTheScreen();
    expect(screen.getAllByLabelText('Loading')).toHaveLength(10);
  });

  it('should render correct loading screen if isLoading === true and pensionsLoading === true and user is Enquirer', () => {
    render(
      <PortfolioSummaryScreenTestView isLoading isEnquirer pensionsLoading />
    );
    expect(screen.getByLabelText('Loading enquirer header')).toBeOnTheScreen();
    expect(screen.getAllByLabelText('Loading')).toHaveLength(18);
  });

  it('should render correct loading screen if isLoading === true or pensionsLoading  === true and user is Enquirer', () => {
    render(
      <PortfolioSummaryScreenTestView
        isLoading={false}
        isEnquirer
        pensionsLoading
      />
    );
    expect(screen.getByLabelText('Loading enquirer header')).toBeOnTheScreen();
    expect(screen.getAllByLabelText('Loading')).toHaveLength(18);
  });

  it('should render the PortfolioVisualSummary view with correct date when DirectWealthAccount is present', async () => {
    render(<PortfolioSummaryScreenTestView />);

    const titleDate = await screen.findByTestId('portfolio-value-date');

    expect(titleDate).toHaveTextContent('CURRENT PORTFOLIO VALUE');
  });

  it('should render the enquirer header view with correct header when DirectWealthAccount is present and user is Enquirer', async () => {
    render(
      <PortfolioSummaryScreenTestView isEnquirer pensionsLoading={false} />
    );
    const titleDate = await screen.findByTestId(getTestId('enquirer-header'));
    expect(titleDate).toHaveTextContent('CURRENT PORTFOLIO VALUE');
  });

  it('should render the correct header message if user is Enquirer', async () => {
    render(<PortfolioSummaryScreenTestView isEnquirer />);

    const headerText = await screen.findByText(
      'It looks like you currently don’t hold any active wealth products. Get started below.'
    );

    expect(headerText).toBeTruthy();
  });

  it('should render find and combine entry point if I have no pensions results available and user is Enquirer', async () => {
    render(
      <PortfolioSummaryScreenTestView
        isEnquirer
        pensionConsolidationSummaryStatus={{
          hasPensions: false,
          pensionsInTransfer: 0,
          pensionsNotInTransfer: 0,
        }}
      />
    );
    expect(
      await screen.findByText('Take control of your wealth')
    ).toBeOnTheScreen();
    expect(await screen.findByText(findAndCombineCardText)).toBeOnTheScreen();
  });

  it('should call find and combine external web link when Find and Combine card is pressed and user is Enquirer', () => {
    render(
      <PortfolioSummaryScreenTestView
        pensionConsolidationSummaryStatus={{ hasPensions: false }}
        isEnquirer
        pensionsLoading={false}
      />
    );
    const findAndCombineCard = screen.getByText(findAndCombineCardText);
    fireEvent.press(findAndCombineCard);

    expect(mockAppStackNavigate).toHaveBeenCalledTimes(1);
    expect(mockAppStackNavigate).toHaveBeenCalledWith('Web View', {
      url:
        config.AVIVA_BASE_URL.get() + '/retirement/pensions/find-and-combine/',
    });
  });

  it('should call right analytics tag when Find and Combine card is pressed and user is Enquirer', () => {
    render(
      <PortfolioSummaryScreenTestView
        pensionConsolidationSummaryStatus={{ hasPensions: false }}
        isEnquirer
        pensionsLoading={false}
      />
    );
    const findAndCombineCard = screen.getByText(findAndCombineCardText);
    fireEvent.press(findAndCombineCard);
    expect(mockTrackUserEvent).toHaveBeenCalledWith(
      'ukmyaviva|wealth|pcs|enquirer|enquirer-summary|find-and-combine-card-tapped|idv-web'
    );
  });

  it('should display the right message if there is an error and user is Enquirer', () => {
    mockIsPCSEntryPointViewModelError = true;
    mockIsManga = false;
    render(
      <PortfolioSummaryScreenTestView isEnquirer pensionsLoading={false} />
    );
    const pensionChecksText = screen.getByText(
      'Sorry, we were unable to load this content.'
    );

    expect(pensionChecksText).toBeOnTheScreen();
  });

  it('should display find and combine entry card if there is an error and user is Enquirer', () => {
    mockIsPCSEntryPointViewModelError = true;
    mockIsManga = false;
    render(
      <PortfolioSummaryScreenTestView isEnquirer pensionsLoading={false} />
    );
    expect(
      screen.getByText('Sorry, we were unable to load this content.')
    ).toBeOnTheScreen();
    expect(screen.getByText(findAndCombineCardText)).toBeOnTheScreen();
  });

  it('should not render the PortfolioVisualSummary when DirectWealthAccount is not present', () => {
    render(<PortfolioSummaryScreenTestView directWealthAccount={undefined} />);

    expect(screen.queryByTestId('portfolio-value-date')).not.toBeOnTheScreen();
  });

  it('should call setPoliciesCountContextKeys from usePoliciesContextKeys hook onFocus', () => {
    render(<PortfolioSummaryScreenTestView products={mockProducts} />);

    expect(mockSetPoliciesCount).toHaveBeenCalledWith(mockProducts);
  });

  it('should render the PCS entry point view', () => {
    mockIsManga = false;
    render(
      <PortfolioSummaryScreenTestView isError={false} isLoading={false} />
    );
    const component = screen.getByTestId(
      'test:id/pcs-entry-point-view-container'
    );
    expect(component).toBeOnTheScreen();
  });

  it('should not render the Simple Wealth button when isSimpleWealth enabled is false', async () => {
    mockIsSimpleWealthEnabled = false;
    render(<PortfolioSummaryScreenTestView />);

    await waitFor(() => {
      const simpleWealthButtonText = screen.queryByText('Navigator');
      expect(screen.queryByText(simpleWealthButtonText)).not.toBeOnTheScreen();
    });
  });
});

describe('Promotional Cards', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should call the correct onPress when ISA Card is tapped', async () => {
    mockIsSimpleWealthEnabled = false;
    render(<PortfolioSummaryScreenTestView />);

    const card = screen.getByText('Stocks & Shares ISA', {
      includeHiddenElements: true,
    });
    fireEvent.press(card);

    expect(mockAppStackNavigate).toHaveBeenCalledTimes(1);
    expect(mockAppStackNavigate).toHaveBeenCalledWith('Web View', {
      url: 'https://baseexample.com/investments/stocks-and-shares-isa/',
    });
  });

  it('should call the correct onPress when ISA Card is tapped and the dwIsaApplyDirectNativeFlowEnabled FeatureFlag is true', async () => {
    FeatureFlags.dwIsaApplyDirectNativeFlowEnabled.set(true);
    mockIsSimpleWealthEnabled = false;
    render(<PortfolioSummaryScreenTestView />);

    const card = screen.getByText('Stocks & Shares ISA', {
      includeHiddenElements: true,
    });
    fireEvent.press(card);
    expect(mockAppStackNavigate).toHaveBeenNthCalledWith(1, 'ISA Apply', {
      screen: 'ISA Apply Landing',
    });
  });

  it('should call the correct onPress when SIPP Card is tapped', async () => {
    mockIsSimpleWealthEnabled = false;
    render(<PortfolioSummaryScreenTestView />);

    const card = screen.getByText('Pension (SIPP)', {
      includeHiddenElements: true,
    });
    fireEvent.press(card);

    expect(mockAppStackNavigate).toHaveBeenCalledTimes(1);
    expect(mockAppStackNavigate).toHaveBeenCalledWith('Web View', {
      url: 'https://baseexample.com/retirement/aviva-pension/',
    });
  });

  it('should call the correct onPress when GIA Card is tapped', async () => {
    mockIsSimpleWealthEnabled = false;
    render(<PortfolioSummaryScreenTestView />);

    const card = screen.getByText('Investment Account', {
      includeHiddenElements: true,
    });
    fireEvent.press(card);

    expect(mockAppStackNavigate).toHaveBeenCalledTimes(1);
    expect(mockAppStackNavigate).toHaveBeenCalledWith('Web View', {
      url: 'https://baseexample.com/investments/investment-account/',
    });
  });
});

describe('Portfolio summary screen product cards', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  const UnlockPortfolioButton = 'Unlock your portfolio';

  it('should not show product cards when no DW products', async () => {
    render(
      <PortfolioSummaryScreenTestView
        directWealthAccount={undefined}
        promotions={[]}
      />
    );
    expect(screen.queryByText(/Pension \(SIPP\)/i)).not.toBeOnTheScreen();
    expect(screen.queryByText(/Stocks & Shares ISA/i)).not.toBeOnTheScreen();
    expect(screen.queryByText(/Investment account/i)).not.toBeOnTheScreen();
  });

  it('should render Gain or Loss tooltip modal when hint icon is pressed', async () => {
    render(<PortfolioSummaryScreenTestView />);

    const tooltipIcon = await screen.findByLabelText('Gain or Loss tooltip.');
    fireEvent.press(tooltipIcon);

    expect(
      await screen.findByText(Constants.GAIN_LOSS_TOOLTIP_TITLE)
    ).toBeOnTheScreen();
  });

  it('should render product cards with valuation formatted in GBP to 2 decimal places', async () => {
    render(<PortfolioSummaryScreenTestView />);

    expect(await screen.findByText(/Pension \(SIPP\)/i)).toBeOnTheScreen();
    expect(screen.getByText(/Stocks & Shares ISA/i)).toBeOnTheScreen();
    expect(screen.getByText(/Investment account/i)).toBeOnTheScreen();
    expect(screen.getByText(/Pension drawdown \(SIPP\)/i)).toBeOnTheScreen();

    ['£17,599.91', '£100.00', '£1,389.36', '£3,247.20'].forEach(
      (formattedProductValuation) => screen.getByText(formattedProductValuation)
    );
  });

  it('should render positive TrendValue if product gainOrLoss is positive', async () => {
    render(<PortfolioSummaryScreenTestView />);

    const positiveGainOrLoss = await screen.findByText(/\+£2,566\.98/);
    expect(positiveGainOrLoss).toBeOnTheScreen();
    expect(positiveGainOrLoss).toHaveStyle({ color: '#4F9F31' });
  });

  it('should render negative TrendValue if product gainOrLoss is negative', async () => {
    render(<PortfolioSummaryScreenTestView />);

    const negativeGainOrLoss = await screen.findByText(/-£0.62/);
    expect(negativeGainOrLoss).toBeOnTheScreen();
    expect(negativeGainOrLoss).toHaveStyle({ color: '#D90000' });
  });

  it('should render TrendValue with no changes if product gainOrLoss is 0', async () => {
    render(<PortfolioSummaryScreenTestView />);

    const noGainOrLoss = await screen.findByText(/\+ £0\.00/);
    expect(noGainOrLoss).toBeOnTheScreen();
    expect(noGainOrLoss).toHaveStyle({ color: '#717171' });
  });

  it('should navigate to Product Dashboard when product card is pressed', async () => {
    render(<PortfolioSummaryScreenTestView />);

    const productCard = await screen.findByText('Pension (SIPP)');
    fireEvent.press(productCard);

    await waitFor(() => {
      expect(mockAppStackNavigate).toHaveBeenNthCalledWith(
        1,
        'ProductDashboard',
        { securePolicyNumber: 'EFygsYiwN_twp89o6nd2y6FNxuEaI_DQCePRe6W88MI1' }
      );
    });
  });

  it('should call setProdDetails with policyId, prodName, pensionProvider and prodNameStatus when product card is pressed', async () => {
    render(<PortfolioSummaryScreenTestView products={mockProducts} />);
    const pensionSippProdDetails = {
      policyId: 'EFygsYiwN_twp89o6nd2y6FNxuEaI_DQCePRe6W88MI1',
      prodName: 'Pension (SIPP)',
      pensionProvider: 'Fnz',
      prodNameStatus:
        'pension(sipp):active|stocks&sharesisa:active|investmentaccount:active|pensiondrawdown(sipp):active',
    };
    const productCard = await screen.findByText('Pension (SIPP)');
    fireEvent.press(productCard);

    await waitFor(() => {
      expect(mockSetProdDetails).toHaveBeenCalledWith(pensionSippProdDetails);
    });
  });

  it('should not render the floating unlock button when customer DPA level is equal to product DPA requirement', async () => {
    render(<PortfolioSummaryScreenTestView />);

    expect(
      screen.queryByLabelText(UnlockPortfolioButton)
    ).not.toBeOnTheScreen();
  });

  it('should render the floating unlock button when customer DPA level is below product DPA requirement', async () => {
    setMock('Customer', 'Customer all insurance products dpa 1');

    render(<PortfolioSummaryScreenTestView />);

    await waitFor(() => {
      expect(screen.getByLabelText(UnlockPortfolioButton)).toBeOnTheScreen();
    });
  });

  it('should render the unlock product dialog when a locked product card is pressed', async () => {
    setMock('Customer', 'Customer all insurance products dpa 1');
    render(<PortfolioSummaryScreenTestView />);

    fireEvent.press(await screen.findByText('Pension (SIPP)'));

    await waitFor(() => {
      expect(
        screen.getByLabelText('Unlock your portfolio Dialog Button')
      ).toBeOnTheScreen();
    });
  });

  it('should dismiss dialog and go to idv journey when press Unlock your portfolio Dialog Button', async () => {
    setMock('Customer', 'Customer all insurance products dpa 1');
    render(<PortfolioSummaryScreenTestView />);

    fireEvent.press(await screen.findByText('Pension (SIPP)'));

    const unlockPolicyDialogButtonQuery = await screen.findByLabelText(
      'Unlock your portfolio Dialog Button'
    );
    fireEvent.press(unlockPolicyDialogButtonQuery);

    await waitFor(() => {
      expect(mockDirectWealthTabStackNavigate).toHaveBeenLastCalledWith(
        'Unlock Portfolio'
      );
    });
    expect(unlockPolicyDialogButtonQuery).not.toBeOnTheScreen();
  });

  it('should render the pending chip when user just finished idv journey and local storage dwIDVJourneyComplete flag is true', async () => {
    unlockProductRequested.set(true);
    setMock('Customer', 'Customer all insurance products dpa 1');

    render(<PortfolioSummaryScreenTestView />);

    await waitFor(() => {
      expect(screen.getAllByText('Pending').length).toBe(4);
    });
  });

  it('should unset local storage dwIDVJourneyComplete flag and render the pending chip when idv check is in progress', async () => {
    unlockProductRequested.set(true);
    setMock('Customer', 'Customer all insurance products dpa 1');
    setMock('Idv', 'Customer IDV In Progress');

    render(<PortfolioSummaryScreenTestView />);

    const elements = await screen.findAllByText('Pending');

    expect(elements.length).toBe(4);
    expect(unlockProductRequested.get()).toBeUndefined();
  });

  it('should render the pending dialog when a pending product card is pressed', async () => {
    setMock('Customer', 'Customer all insurance products dpa 1');
    setMock('Idv', 'Customer IDV In Progress');

    render(<PortfolioSummaryScreenTestView />);

    fireEvent.press(await screen.findByText('Pension (SIPP)'));

    await waitFor(() => {
      expect(
        screen.getByText(
          /We are processing your request to unlock your portfolio/
        )
      ).toBeOnTheScreen();
    });
  });

  it('should unset local storage dwIDVJourneyComplete flag when dpa level is 2', async () => {
    unlockProductRequested.set(true);
    setMock('Customer', 'Customer all insurance products');

    render(<PortfolioSummaryScreenTestView />);

    await screen.findByText(defaultAccountData.content.products[0].displayName);

    expect(unlockProductRequested.get()).toBeUndefined();
  });

  it('should display no account text if there is no direct wealth account', async () => {
    setMock('Customer', 'Customer no direct wealth products');
    render(<PortfolioSummaryScreenTestView />);

    const noAccountText = await screen.findByText(
      /It looks like you currently don’t hold any active wealth products with us. Add products to your portfolio below./i
    );
    expect(noAccountText).toBeOnTheScreen();
  });

  it('should display the onboarding card title', async () => {
    mockIsSimpleWealthEnabled = true;
    mockSimpleWealthOnboardingCardStatus = 'initial';
    mockIsSimpleWealthGetApiError = false;
    render(<PortfolioSummaryScreenOnboardingTestView />);

    await waitFor(() => {
      expect(screen.getByText('Get ISA confident')).toBeOnTheScreen();
    });
  });

  it('should have correct colours on card', async () => {
    render(<PortfolioSummaryScreenOnboardingTestView />);

    await waitFor(() => {
      const imgBg = screen.getByTestId(
        'test:id/onboarding-product-card-image-bg'
      );

      expect(imgBg).toHaveStyle({
        backgroundColor: '#BEDCE2',
      });
    });

    await waitFor(() => {
      const textBg = screen.getByTestId(
        'test:id/onboarding-product-card-text-bg'
      );

      expect(textBg).toHaveStyle({
        backgroundColor: '#BEDCE2',
      });
    });

    await waitFor(() => {
      const linkBg = screen.getByTestId(
        'test:id/onboarding-product-card-link-bg'
      );

      expect(linkBg).toHaveStyle({
        backgroundColor: '#BEDCE2',
      });
    });
  });

  it('should render the simple wealth onboarding card subtitle', async () => {
    mockIsSimpleWealthEnabled = true;
    mockSimpleWealthOnboardingCardStatus = 'initial';
    mockIsSimpleWealthGetApiError = false;
    render(<PortfolioSummaryScreenOnboardingTestView />);
    const onboardingCard = await screen.findByText(
      'Find the right fund for you with a trusted advice recommendation'
    );
    expect(onboardingCard).toBeOnTheScreen();
  });

  it('should fire the correct analytics when the simple wealth card onboarding card is pressed', async () => {
    mockIsSimpleWealthEnabled = true;
    mockSimpleWealthOnboardingCardStatus = 'initial';
    mockIsSimpleWealthGetApiError = false;
    render(<PortfolioSummaryScreenOnboardingTestView />);
    const onboardingCard = await screen.findByText(
      'Find the right fund for you with a trusted advice recommendation'
    );
    fireEvent.press(onboardingCard);
    await screen.findByText(
      'Find the right fund for you with a trusted advice recommendation'
    );
    expect(mockTrackUserEvent).toHaveBeenNthCalledWith(
      1,
      'ukmyaviva|wealth|portfolio-summary|new-navigator-card-tapped'
    );
  });

  it('should call simple wealth card handler when the simple wealth onboarding card is pressed', async () => {
    mockRefetchGetApi.mockResolvedValue({
      data: { person: { opportunity: {} } },
    });
    render(<PortfolioSummaryScreenOnboardingTestView />);
    const onboardingCard = await screen.findByText(
      'Find the right fund for you with a trusted advice recommendation'
    );
    fireEvent.press(onboardingCard);

    await waitFor(() => {
      expect(mockSimpleWealthCardPressed).toHaveBeenCalled();
    });
  });

  it('should not show simple wealth onboarding modal if the screen is not mounted', async () => {
    /* Stops simple wealth modal appearing if user moves away from this screen */
    mockRefetchGetApi.mockResolvedValue({
      data: {
        person: { opportunity: {} },
        isEligbileForNavigatorJourney: true,
      },
    });
    navigatorShouldShowOnboardingPopup.set(true);
    const { unmount } = render(
      <PortfolioSummaryScreenOnboardingTestView
        isError={false}
        isLoading={false}
      />
    );

    unmount();
    jest.advanceTimersByTime(6000);

    await waitFor(() => {
      expect(navigatorShouldShowOnboardingPopup.get()).toBe(true);
    });
  });
});
