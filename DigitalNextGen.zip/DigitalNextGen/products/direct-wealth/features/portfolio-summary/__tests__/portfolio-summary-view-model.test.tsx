import { act, renderHook, waitFor } from '@src/jest/testing-library';
import DirectWealthAccountDataNoValuations from '@src/api-mock/responses/DirectWealth/account/Account_with_all_valuation_zero.json';
import DirectWealthAccountWithOnePromotion from '@src/api-mock/responses/DirectWealth/account/Account_with_one_promotion.json';
import DirectWealthAccountPromotions from '@src/api-mock/responses/DirectWealth/account/Account_with_promotions.json';
import DirectWealthAccountData from '@src/api-mock/responses/DirectWealth/account/Default_account.json';
import DirectWealthAccountIsOpeningNoValuations from '@src/api-mock/responses/DirectWealth/account/Total_valuation_zero_account_opening.json';

import { DirectWealthAccountSchema } from '../../../validation/schemas/direct-wealth-account';
import { FormattedProduct, ProductStatus } from '../types';
import { usePortfolioSummaryViewModel } from '../use-portfolio-summary-view-model';

let mockIsDirectWealthLoading = false;
let mockIsDirectWealthError = false;
let mockIsPhotoIdvStatusLoading = false;
let mockIsPhotoIdvStatusError = false;
let mockCustomerRefetch = jest.fn();
let mockDWRefetch = jest.fn();
let mockPhotoIdvStatusRefetch = jest.fn();

const eligibilityFlag = 'isEligibleForDirectWealthSippTransfer.V2';

let mockCustomer: object | null = {
  CustomerDPALevel: '2',
  PartyId: '456',
  DirectWealth: [
    {
      SecureAccountNumber: '123',
    },
  ],
  Eligibilities: [
    {
      Type: eligibilityFlag,
      Value: true,
    },
  ],
};

const directWealthAccount = {
  accountNumber: '123',
  displayName: 'hello',
  valuation: { raw: 1000, formatted: '£1000.00' },
  isLoaded: true,
  products: [
    {
      displayName: 'A product',
      valuation: { raw: 400, formatted: '£400.00' },
      accountType: 'ISA',
      status: 'Locked',
      dpaLevel: '2',
    },
    {
      displayName: 'Another product',
      valuation: { raw: 600, formatted: '£600.00' },
      accountType: 'SIPP',
      status: 'Locked',
      dpaLevel: '2',
    },
    {
      displayName: 'Zero valuation product',
      valuation: { raw: 0, formatted: '£0.00' },
      accountType: 'GIA',
      status: 'Locked',
      dpaLevel: '2',
    },
  ],
};

let mockDirectWealthAccount: object | null = directWealthAccount;
let mockIsEligibleForNavigatorJourney = true;

const mockPhotoIdvStatus = 'allowed';

let mockScreenAction = jest.fn();
let mockCardAction = jest.fn();
let mockPromoCardAction = jest.fn();
let mockButtonActionTag = jest.fn();

const resetAllMocks = () => {
  mockIsDirectWealthLoading = false;
  mockIsDirectWealthError = false;
  mockIsPhotoIdvStatusLoading = false;
  mockIsPhotoIdvStatusError = false;
  mockScreenAction = jest.fn();
  mockButtonActionTag = jest.fn();
  mockCardAction = jest.fn();
  mockPromoCardAction = jest.fn();
  mockCustomerRefetch = jest.fn();
  mockDWRefetch = jest.fn();
  mockPhotoIdvStatusRefetch = jest.fn();
  mockIsEligibleForNavigatorJourney = true;

  mockCustomer = {
    CustomerDPALevel: '2',
    PartyId: '456',
    DirectWealth: [
      {
        SecureAccountNumber: '123',
      },
    ],
    Eligibilities: [
      {
        Type: eligibilityFlag,
        Value: true,
      },
    ],
  };
  mockDirectWealthAccount = directWealthAccount;
};

jest.useFakeTimers();

jest.mock(
  '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey',
  () => ({
    useInitialiseSimpleWealthJourney: () => ({
      isSimpleWealthEnabled: mockIsEligibleForNavigatorJourney,
    }),
  })
);

jest.mock('@hooks/use-greeting-message', () => ({
  useGreetingMessage: () => 'Good morning',
}));

jest.mock('@hooks/use-auth', () => ({
  useAuth: () => ({
    isSignedIn: true,
  }),
}));

jest.mock('@hooks/use-customer', () => ({
  useCustomer: () => ({ data: mockCustomer }),
}));

const mockUseDirectWealthAccount = jest.fn().mockImplementation(() => ({
  data: mockDirectWealthAccount,
  isLoading: mockIsDirectWealthLoading,
  isError: mockIsDirectWealthError,
  refetch: mockDWRefetch,
}));

jest.mock('@direct-wealth/common/hooks', () => ({
  useDirectWealthAccount: () => mockUseDirectWealthAccount(),
}));

jest.mock('@hooks/use-user-photo-idv-status', () => ({
  useUserPhotoIdvStatus: () => [
    {
      isInitialLoading: mockIsPhotoIdvStatusLoading,
      isError: mockIsPhotoIdvStatusError,
      refetch: mockPhotoIdvStatusRefetch,
    },
    mockPhotoIdvStatus,
  ],
}));

jest.mock('../hooks/use-portfolio-summary-analytics', () => ({
  usePortfolioSummaryAnalytics: () => ({
    sendScreenEventTag: mockScreenAction,
    sendScreenEventTagWithContextKeys: mockScreenAction,
    sendCardActionTag: mockCardAction,
    sendPromoCardActionTag: mockPromoCardAction,
    sendButtonActionTag: mockButtonActionTag,
  }),
}));

const mockNavigate = jest.fn();
const mockReset = jest.fn();

jest.mock('src/navigation/app/hooks.ts', () => ({
  useAppStackNavigation: () => ({
    navigate: mockNavigate,
    reset: mockReset,
  }),
}));

jest.mock('../../../navigation/hooks', () => ({
  useDirectWealthTabStackNavigation: () => ({
    navigate: jest.fn(),
  }),
}));

const mockDelete = jest.fn();

jest.mock('@src/navigation/linking', () => ({
  SavedDeepLink: {
    get: () => 'some-random-deep-link',
    delete: () => mockDelete(),
  },
}));

describe('use-profile-summary-view-model', () => {
  describe('when all APIs are succeeded', () => {
    afterEach(() => {
      resetAllMocks();
      jest.clearAllMocks();
    });

    it('should handle deeplink if there is one save in SavedDeepLink observable', () => {
      renderHook(usePortfolioSummaryViewModel);
      expect(mockReset).toHaveBeenCalledWith('some-random-deep-link');
      expect(mockDelete).toHaveBeenCalled();
    });

    it('should return correctly filtered productListSections data with one no-valuation product', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.productListSections).toEqual([
        {
          id: 'withValuation',
          data: [
            {
              accountType: 'ISA',
              derivedStatus: 'Locked',
              displayName: 'A product',
              dpaLevel: '2',
              status: 'Locked',
              valuation: { raw: 400, formatted: '£400.00' },
            },
            {
              accountType: 'SIPP',
              derivedStatus: 'Locked',
              displayName: 'Another product',
              dpaLevel: '2',
              status: 'Locked',
              valuation: { raw: 600, formatted: '£600.00' },
            },
          ],
        },
        {
          id: 'withoutValuation',
          showSeparator: true,
          data: [
            {
              accountType: 'GIA',
              derivedStatus: 'Locked',
              displayName: 'Zero valuation product',
              dpaLevel: '2',
              status: 'Locked',
              valuation: { raw: 0, formatted: '£0.00' },
            },
          ],
        },
      ]);
    });

    it('should return correctly filtered productListSections data, and showSeparator as true, with products with both valuation and no valuation', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.productListSections?.[0].data).toHaveLength(2);
      expect(result.current.productListSections?.[1].data).toHaveLength(1);
      expect(result.current.productListSections?.[1].showSeparator).toBe(true);
    });

    it('should return correctly filtered productListSections data, and showSeparator as false, with all products having a valuation', () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountData.content
      );

      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.productListSections?.[0].data).toHaveLength(4);
      expect(result.current.productListSections?.[1].data).toHaveLength(0);
      expect(result.current.productListSections?.[1].showSeparator).toBe(false);
    });

    it('should return correctly filtered productListSections data, and showSeparator as false, with all no-valuation products', () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountDataNoValuations.content
      );

      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.productListSections?.[0].data).toHaveLength(0);
      expect(result.current.productListSections?.[1].data).toHaveLength(4);
      expect(result.current.productListSections?.[1].showSeparator).toBe(false);
    });

    it('should return correct promotions data, when all promotions are true', () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountPromotions.content
      );

      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.promotions[0].id).toEqual('displayIsaPromotion');
      expect(result.current.promotions[1].id).toEqual('displaySippPromotion');
      expect(result.current.promotions[2].id).toEqual('displayGiaPromotion');
    });

    it('should return correct promotions data, when one promotion is true', () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountWithOnePromotion.content
      );

      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.promotions).toHaveLength(1);
      expect(result.current.promotions[0].id).toEqual('displaySippPromotion');
    });

    it('should return no promotions, when all promotions are false', () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountData.content
      );

      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.promotions).toHaveLength(0);
    });

    it('should return correct portfolio summary data when customer and direct wealth calls are successful', async () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.portfolioChartData).toEqual({
        state: 'populated',
        data: [
          { label: '40.0%', type: 'ISA', value: 400 },
          { label: '60.0%', type: 'SIPP', value: 600 },
        ],
      });
      expect(result.current.isError).toEqual(false);
      expect(result.current.isLoading).toEqual(false);
    });

    it("should return state = 'opening' when the customer has products but the total valuation is zero and at least one product is in the opening state", async () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountIsOpeningNoValuations.content
      );

      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.portfolioChartData).toEqual({
        state: 'opening',
        data: [{ value: 1, label: '0%' }],
      });
    });

    it("should return state = 'empty' when the customer has products but the total valuation is zero and all products are in the open state", async () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountDataNoValuations.content
      );
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.portfolioChartData).toEqual({
        state: 'empty',
        data: [{ value: 1, label: '0%' }],
      });
    });

    it('should not return isLoading if there is no secureAccountNumber', () => {
      mockCustomer = {
        CustomerDPALevel: '2',
        PartyId: '456',
      };
      mockIsDirectWealthLoading = true;
      const { result } = renderHook(usePortfolioSummaryViewModel);
      expect(result.current.isLoading).toEqual(false);
    });

    it('should return the correct isLoading flag when DW is loading and there is SecureAccountNumber', async () => {
      mockCustomer = {
        DirectWealth: [{ SecureAccountNumber: '123' }],
      };
      mockIsDirectWealthLoading = true;
      const { result, rerender } = renderHook(usePortfolioSummaryViewModel);
      expect(result.current.isLoading).toEqual(true);

      rerender(undefined);
      expect(result.current.isLoading).toEqual(true);

      mockIsDirectWealthLoading = false;
      rerender(undefined);
      expect(result.current.isLoading).toEqual(false);
    });

    it('should send correct screen tag on render', () => {
      renderHook(usePortfolioSummaryViewModel);

      expect(mockScreenAction).toHaveBeenCalledWith('Ready');
    });

    it('should send correct screen tag if data is loading', () => {
      const { rerender } = renderHook(usePortfolioSummaryViewModel);
      mockIsDirectWealthLoading = true;
      rerender(undefined);

      expect(mockScreenAction).toHaveBeenCalledWith('Loading');
    });

    it('should send correct screen tag when an error occurs', () => {
      const { rerender } = renderHook(usePortfolioSummaryViewModel);
      mockIsDirectWealthError = true;
      rerender(undefined);

      expect(mockScreenAction).toHaveBeenCalledWith('Error');
    });

    it('should send correct screen tag when is not loading, no error and no directWealthAccount', () => {
      const { rerender } = renderHook(usePortfolioSummaryViewModel);
      mockDirectWealthAccount = null;
      rerender(undefined);

      expect(mockScreenAction).toHaveBeenCalledWith('NoProducts');
    });

    it('should send correct screen tag when the pending modal is displayed', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      act(() => {
        result.current.setIsPendingDialogOpen(true);
      });

      expect(mockScreenAction).toHaveBeenCalledWith('Ready');
      expect(mockScreenAction).toHaveBeenCalledWith('PendingModal');
    });

    it('should return isError as true when direct wealth account returns an error', () => {
      mockCustomer = {
        DirectWealth: [{ SecureAccountNumber: '123' }],
      };
      mockIsDirectWealthError = true;

      const { result } = renderHook(usePortfolioSummaryViewModel);
      expect(result.current.isError).toEqual(true);
    });

    it('should call DW API refetch if DW API fails and there is an account number when refetch is called from result', async () => {
      mockCustomer = {
        DirectWealth: [{ SecureAccountNumber: '123' }],
      };
      mockIsDirectWealthError = true;

      const { result } = renderHook(usePortfolioSummaryViewModel);

      result.current.refetch();

      expect(mockDWRefetch).toHaveBeenCalledTimes(1);
    });

    it('should call photoIdvStatus refetch if photoIdvStatus API fails', async () => {
      mockCustomer = {
        DirectWealth: [{ SecureAccountNumber: '123' }],
        PartyId: '456',
        CustomerDPALevel: '1',
      };
      mockIsDirectWealthError = false;
      mockIsPhotoIdvStatusError = true;

      const { result } = renderHook(usePortfolioSummaryViewModel);
      result.current.refetch();

      expect(mockPhotoIdvStatusRefetch).toHaveBeenCalledTimes(1);
    });

    it('should return showDPAUnlockButton as false when customer dpa level is equal or above a products dpa access level', async () => {
      mockDirectWealthAccount = DirectWealthAccountSchema.parse(
        DirectWealthAccountData.content
      );

      const { result } = renderHook(usePortfolioSummaryViewModel);

      await waitFor(() => {
        expect(result.current.showDPAUnlockButton).toEqual(false);
      });
    });

    it('should return showDPAUnlockButton as true when customer dpa level is lower than a products dpa access level', async () => {
      mockCustomer = {
        CustomerDPALevel: '1',
        PartyId: '456',
        DirectWealth: [
          {
            SecureAccountNumber: '123',
          },
        ],
      };

      const { result } = renderHook(usePortfolioSummaryViewModel);

      await waitFor(() => {
        expect(result.current.showDPAUnlockButton).toEqual(true);
      });
    });

    it('should not assume account locked and set showDPAUnlockButton to true when customer dpa level is undefined', async () => {
      mockCustomer = {
        CustomerDPALevel: undefined,
        PartyId: '456',
        DirectWealth: [{ SecureAccountNumber: '123' }],
      };

      const { result } = renderHook(usePortfolioSummaryViewModel);

      await waitFor(() => {
        expect(result.current.showDPAUnlockButton).toEqual(false);
      });
    });

    it('should refetch DW api when there is secureAccountNumber but customerDPALevel is 2', () => {
      mockCustomer = {
        CustomerDPALevel: '2',
        PartyId: '456',
        DirectWealth: [{ SecureAccountNumber: '123' }],
      };
      mockIsDirectWealthError = true;
      mockIsPhotoIdvStatusError = true;

      const { result } = renderHook(usePortfolioSummaryViewModel);
      result.current.refetch();

      expect(mockCustomerRefetch).toHaveBeenCalledTimes(0);
      expect(mockDWRefetch).toHaveBeenCalledTimes(1);
      expect(mockPhotoIdvStatusRefetch).toHaveBeenCalledTimes(0);
    });

    it('should refetch photoIdvStatus when there is secureAccountNumber but customerDPALevel is 1', () => {
      mockCustomer = {
        CustomerDPALevel: '1',
        PartyId: '456',
        DirectWealth: [{ SecureAccountNumber: '123' }],
      };
      mockIsDirectWealthError = true;
      mockIsPhotoIdvStatusError = true;

      const { result } = renderHook(usePortfolioSummaryViewModel);
      result.current.refetch();

      expect(mockPhotoIdvStatusRefetch).toHaveBeenCalledTimes(1);
      expect(mockDWRefetch).toHaveBeenCalledTimes(1);
    });

    it('should set showSippTransferPromotion as true when api flag is true', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.showSippTransferPromotion).toBeTruthy();
    });

    it('should set showSippTransferPromotion as false when api flag is false', () => {
      mockCustomer = {
        Eligibilities: [
          {
            Type: eligibilityFlag,
            Value: false,
          },
        ],
      };
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.showSippTransferPromotion).toBeFalsy();
    });

    it('should call the function sendCardActionTag with the account type and product status as parameters when navigateToProductDashboard has been called', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      result.current.navigateToProductDashboard(
        'testsecurityPolicynumber',
        'Drawdown'
      );

      expect(mockCardAction).toHaveBeenCalledWith('Drawdown', 'Active');
    });

    it('should call the function sendPromoActionTag with the promo type as parameters when navigateToWebView has been called', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      result.current.handlePromotionalCardPress('testURI', 'testPromoType');

      expect(mockPromoCardAction).toHaveBeenCalledWith('testPromoType', true);
    });

    it('should call the function sendButtonActionTag with the button type = PendingAccept as parameters when the pending dialog is closed', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      act(() => {
        result.current.setIsPendingDialogOpen(false);
      });

      expect(mockButtonActionTag).toHaveBeenCalledWith('PendingAccept');
    });

    it('should call the function sendButtonActionTag with the button type = Retry as parameters when the refetch function has been called', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      act(() => {
        result.current.refetch();
      });

      expect(mockButtonActionTag).toHaveBeenCalledWith('Retry');
    });

    it('should call the function sendButtonActionTag with the button type = LockedModalCancel when sendLockedModalCloseAnalytics has been called', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      result.current.sendLockedModalCloseAnalytics();

      expect(mockButtonActionTag).toHaveBeenCalledWith('LockedModalCancel');
    });

    it('should call the function sendCardActionTag with the account type = SIPP and status = Locked and  when sendProductCardTappedAnalytics has been called', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      result.current.sendProductCardTappedAnalytics(
        'SIPP',
        ProductStatus.Locked
      );

      expect(mockCardAction).toHaveBeenCalledWith('SIPP', 'Locked');
    });

    it('should send correct screen tag when the locked modal is displayed', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      act(() => {
        result.current.setIsLockedDialogOpen(true);
      });

      expect(mockScreenAction).toHaveBeenCalledWith('LockedModal');
    });

    it('should send the correct sendButtonActionTag when navigateToUnlockPortfolio is called and locked modal is open', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      act(() => {
        result.current.setIsLockedDialogOpen(true);
      });
      act(() => {
        result.current.navigateToUnlockPortfolio();
      });

      expect(mockButtonActionTag).toHaveBeenCalledWith(
        'LockedModalUnlockPortfolio'
      );
    });

    it('should send the correct sendButtonActionTag when navigateToUnlockPortfolio is called and locked modal is closed', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      act(() => {
        result.current.navigateToUnlockPortfolio();
      });

      expect(mockButtonActionTag).toHaveBeenCalledWith('LockedUnlockPortfolio');
    });

    it('should call mockTrackStateEvent with desired params when sendPortfolioValueAnalytics is called', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      result.current.sendPortfolioValueAnalytics(12345);

      expect(mockScreenAction).toHaveBeenCalledWith('Ready', {
        portfoliovalue: '12345',
      });
    });

    it.each([ProductStatus.Active, ProductStatus.Submitted])(
      'should call navigation with ProductDashboard and securePolicyNumber',
      (productStatus) => {
        const { result } = renderHook(usePortfolioSummaryViewModel);

        result.current.handleProductCardPress({
          accountType: 'SIPP',
          derivedStatus: productStatus,
          securePolicyNumber: 'gwruhgo',
          displayName: 'MockName',
        } as FormattedProduct);

        expect(mockNavigate).toHaveBeenLastCalledWith('ProductDashboard', {
          securePolicyNumber: 'gwruhgo',
        });
      }
    );

    it.each([
      ProductStatus.Closing,
      ProductStatus.Locked,
      ProductStatus.Pending,
    ])(
      'should not call navigation when ProductStatus is %s',
      (productStatus) => {
        const { result } = renderHook(usePortfolioSummaryViewModel);

        act(() => {
          result.current.handleProductCardPress({
            accountType: 'SIPP',
            derivedStatus: productStatus,
            securePolicyNumber: 'gwruhgo',
            displayName: 'MockName',
          } as FormattedProduct);
        });

        expect(mockNavigate).not.toHaveBeenCalled();
      }
    );

    it('should format the directWealthAccount data, adding derivedStatus and prodNameStatus', () => {
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.directWealthAccount?.prodNameStatus).toEqual(
        'aproduct:locked|anotherproduct:locked|zerovaluationproduct:locked'
      );
      expect(
        (result.current.directWealthAccount?.products[0] as FormattedProduct)
          .derivedStatus
      ).toEqual('Locked');
    });
  });

  describe('when direct wealth API fail', () => {
    it('should return with productsAccountNumberOnly static data for productListSections', () => {
      mockCustomer = {
        Products: [
          {
            valuation: { raw: 0, formatted: 'Unavailable' },
            __tag: 'DWProduct',
            gainOrLoss: { raw: null, formatted: null },
            gainOrLossPercentage: { raw: null, formatted: null },
            status: 'Unavailable',
            derivedStatus: 'Unavailable',
            displayName: '',
            policyNumber: '80103',
            accountType: '',
            isLoaded: false,
            dpaLevel: '2',
            ProductCode: '80103',
            AccountNumber: '123',
          },
        ],
      };
      mockUseDirectWealthAccount.mockImplementation(() => [
        null,
        { isError: true, isLoading: false },
      ]);
      const { result } = renderHook(usePortfolioSummaryViewModel);

      expect(result.current.productListSections).toEqual([
        {
          id: 'withoutValuation',
          showSeparator: true,
          data: [
            {
              valuation: { raw: 0, formatted: 'Unavailable' },
              __tag: 'DWProduct',
              gainOrLoss: { raw: null, formatted: null },
              gainOrLossPercentage: { raw: null, formatted: null },
              accountNumber: '123',
              status: 'Unavailable',
              derivedStatus: 'Unavailable',
              displayName: 'Stocks and Shares ISA',
              securePolicyNumber: undefined,
              policyNumber: '123',
              accountType: '',
              isLoaded: false,
              dpaLevel: '2',
            },
          ],
        },
      ]);
    });
  });
});
