import { act, cleanup, render, screen } from '@src/jest/testing-library';
import { navigatorShouldShowOnboardingPopup } from '@interfaces/storage';
import { NavigationContainer } from '@react-navigation/native';

import { PortfolioSummaryScreenView } from '../portfolio-summary-screen';
import { usePortfolioSummaryViewModel } from '../use-portfolio-summary-view-model';

type DeepPartial<T> = T extends (infer U)[]
  ? DeepPartial<U>[]
  : { [P in keyof T]?: DeepPartial<T[P]> };

type PortfolioSummaryTestViewProps = DeepPartial<
  ReturnType<typeof usePortfolioSummaryViewModel>
>;

const mockDirectWealthTabStackNavigate = jest.fn();
jest.mock('../../../navigation/hooks.ts', () => ({
  useDirectWealthTabStackNavigation: () => ({
    navigate: mockDirectWealthTabStackNavigate,
  }),
}));

const mockAppStackNavigate = jest.fn();
jest.mock('src/navigation/app/hooks.ts', () => ({
  useAppStackNavigation: () => ({
    navigate: mockAppStackNavigate,
    reset: jest.fn(),
  }),
}));

jest.mock(
  '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey',
  () => ({
    useInitialiseSimpleWealthJourney: () => ({
      isSimpleWealthEnabled: true,
    }),
  })
);

jest.mock('@react-navigation/native', () => {
  const actualNav = jest.requireActual('@react-navigation/native');
  return { ...actualNav, useIsFocused: () => true };
});

jest.mock('@src/navigation/linking', () => ({
  SavedDeepLink: {
    get: () => 'some-random-deep-link',
    delete: () => jest.fn(),
  },
}));

const PortfolioSummaryScreenTestView = (
  props: PortfolioSummaryTestViewProps
) => {
  const model = usePortfolioSummaryViewModel();
  return (
    <NavigationContainer>
      <PortfolioSummaryScreenView
        model={{
          ...model,
          ...(props as typeof model),
        }}
      />
    </NavigationContainer>
  );
};

describe('Portfolio summary onboarding modal test', () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.clearAllMocks();
    jest.useRealTimers();
    cleanup();
  });

  it('should display modal if the simple wealth feature flag is true and simpleWealthShouldShowOnboardingPopup is true', async () => {
    navigatorShouldShowOnboardingPopup.set(true);

    render(<PortfolioSummaryScreenTestView isLoading={false} />);

    act(() => {
      jest.advanceTimersByTime(6000);
    });

    const modalText = await screen.findByText('Find your perfect match');

    expect(modalText).toBeOnTheScreen();
  });

  it('should display modal if the simple wealth feature flag is true and enquirer is true', async () => {
    navigatorShouldShowOnboardingPopup.set(true);

    render(<PortfolioSummaryScreenTestView isLoading={false} isEnquirer />);

    act(() => {
      jest.advanceTimersByTime(6000);
    });

    const modalText = await screen.findByText('Find your perfect match');

    expect(modalText).toBeOnTheScreen();
  });

  it('should display modal if the simple wealth feature flag is true and enquirer is false', async () => {
    navigatorShouldShowOnboardingPopup.set(true);

    render(
      <PortfolioSummaryScreenTestView isLoading={false} isEnquirer={false} />
    );

    act(() => {
      jest.advanceTimersByTime(6000);
    });

    const modalText = await screen.findByText('Find your perfect match');

    expect(modalText).toBeOnTheScreen();
  });

  it('should not display modal if the simple wealth feature flag is true and simpleWealthShouldShowOnboardingPopup is false', async () => {
    navigatorShouldShowOnboardingPopup.set(false);

    render(<PortfolioSummaryScreenTestView isLoading={false} isEnquirer />);

    act(() => {
      jest.advanceTimersByTime(6000);
    });

    const modalText = screen.queryByText('Find your perfect match');

    expect(modalText).not.toBeOnTheScreen();
  });
});
