import { ValueOf } from 'type-fest';

import { DirectWealthProduct } from '../../validation/schemas/direct-wealth-account';

export type FormattedDirectWealthAccount = {
  accountNumber?: string;
  displayName?: string;
  valuation?: {
    raw: number;
    formatted: string;
  };
  isLoaded?: boolean;
  displaySippPromotion?: boolean;
  displayIsaPromotion?: boolean;
  displayGiaPromotion?: boolean;
  products: DirectWealthProduct[];
  prodNameStatus?: string;
};

export type FormattedProduct = DirectWealthProduct & {
  derivedStatus: ProductStatus;
  pensionProvider?: string;
  isError?: boolean;
  policyIndex?: number;
};

type ChartData = {
  label: string;
  value: number;
  type: Account;
}[];

export type PortfolioChart =
  | { state: 'empty'; data: [{ value: number; label: string }] }
  | { state: 'opening'; data: [{ value: number; label: string }] }
  | {
      state: 'populated';
      data: ChartData;
    };

export type ProductStatus = ValueOf<typeof ProductStatus>;
export const ProductStatus = {
  Locked: 'Locked',
  Pending: 'Pending',
  Active: 'Active',
  Submitted: 'Submitted',
  Closing: 'Closing',
} as const;

export type ProductSection = {
  id: string;
  showSeparator?: boolean;
  data: FormattedProduct[];
};

export type Account = 'Drawdown' | 'GIA' | 'ISA' | 'SIPP';

type AccountTag = Record<string, string>;

export type CardActionTag = Record<ProductStatus, AccountTag>;

export type PromoCardAction = Record<string, string>;
