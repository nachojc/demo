import {
  ProductCardLoading,
  Shimmer,
  Stack,
  styled,
  YStack,
} from '@aviva/ion-mobile';

export const EnquirerSummaryLoadingScreen = () => {
  return (
    <Stack accessibilityLabel="Loading enquirer header">
      <HeaderContainer>
        <Shimmer width={'60%'} height={12} colorScheme={'dark'} />
        <Stack height={22} />
        <Shimmer width={'45%'} height={45} colorScheme={'dark'} />
        <Stack height={22} />
        <Shimmer width={'75%'} height={24} colorScheme={'dark'} />
      </HeaderContainer>
      <ListContainer>
        <ItemContainer>
          <Stack height={50} />
          <ProductCardLoading />
          <Stack height={22} />
          <ProductCardLoading />
          <Stack height={22} />
          <ProductCardLoading />
        </ItemContainer>
      </ListContainer>
    </Stack>
  );
};

const HeaderContainer = styled(YStack, {
  name: 'Header Container',
  backgroundColor: '$WealthBlue95',
  padding: '$xxxxl',
  alignItems: 'center',
});

const ItemContainer = styled(YStack, {
  name: 'Item Container',
  paddingHorizontal: '$xl',
  marginBottom: '$xl',
  backgroundColor: '$backgroundTransparent',
});

const ListContainer = styled(YStack, {
  backgroundColor: '$White',
  paddingBottom: '$xxl',
});
