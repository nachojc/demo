import { usePensionConsolidationSummary } from '@direct-wealth/common/hooks/use-pension-consolidation-summary';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { SavedDeepLink } from '@src/navigation/linking';
import { useCallback, useEffect, useLayoutEffect, useState } from 'react';

import { usePoliciesContextKeys } from '../../common/hooks/use-policies-context-keys';
import { useDirectWealthTabStackNavigation } from '../../navigation/hooks';
import { PensionStatus } from '../pension-consolidation-summary/use-pcs-entry-point-view-model';
import { usePortfolioSummaryAnalytics } from './hooks/use-portfolio-summary-analytics';
import { usePortfolioSummaryApi } from './hooks/use-portfolio-summary-api';
import { usePromotionalData } from './hooks/use-promotional-card-data';
import { Account, FormattedProduct, ProductStatus } from './types';

export const usePortfolioSummaryViewModel = () => {
  const deepLink = SavedDeepLink.get();
  const [isLockedDialogOpen, setIsLockedDialogOpen] = useState(false);
  const [isPendingDialogOpen, setIsPendingDialogOpen] = useState<boolean>();
  const [isGainLossTooltipOpen, setIsGainLossTooltipOpen] =
    useState<boolean>(false);

  const { navigate: appStackNavigate, reset: appStackNavigateReset } =
    useAppStackNavigation();
  const { navigate: dwTabStackNavigate } = useDirectWealthTabStackNavigation();
  const {
    sendScreenEventTag,
    sendScreenEventTagWithContextKeys,
    sendCardActionTag,
    sendPromoCardActionTag,
    sendButtonActionTag,
  } = usePortfolioSummaryAnalytics();

  useLayoutEffect(() => {
    if (deepLink) {
      /*
        This is added for deeplink handling.
        If the user is in logged out state, we store the deep link in SavedDeepLink observable.
        In portofolio summary we check on first render if there is a deeplink stored.
        If yes we reset the navigation stack to that deeplink.
      */
      // eslint-disable-next-line
      // @ts-ignore
      appStackNavigateReset(deepLink);
      SavedDeepLink.delete();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const { setPoliciesCountContextKeys, setProdDetails } =
    usePoliciesContextKeys();

  const {
    isLoading,
    isError,
    refetch,
    directWealthAccount,
    portfolioChartData,
    productListSections,
    filteredPromotionalData,
    isAnyProductLocked,
    hasSippProduct,
    isEnquirer,
    products,
    isEligibleForSippTransfer,
  } = usePortfolioSummaryApi();

  const [data, { isLoading: pensionsLoading }] =
    usePensionConsolidationSummary();

  const { promotionalDataEnquirer, promotionalData } = usePromotionalData();
  const defaultPromoData = isEnquirer
    ? promotionalDataEnquirer
    : promotionalData;

  const pensionConsolidationSummaryStatus: PensionStatus = {
    hasPensions:
      !!data?.pensionsInTransfer?.length ||
      !!data?.pensionsNotInTransfer?.length,
    pensionsInTransfer: data?.pensionsInTransfer?.length ?? 0,
    pensionsNotInTransfer: data?.pensionsNotInTransfer?.length ?? 0,
  };

  const showSippTransferPromotion = isEligibleForSippTransfer;

  //Analytics

  useEffect(() => {
    if (isPendingDialogOpen) {
      sendScreenEventTag('PendingModal');
    }
    if (isPendingDialogOpen === false) {
      sendButtonActionTag('PendingAccept');
    }
  }, [isPendingDialogOpen, sendScreenEventTag, sendButtonActionTag]);

  useEffect(() => {
    if (isLoading) {
      sendScreenEventTag('Loading');
    }
  }, [isLoading, sendScreenEventTag]);

  useEffect(() => {
    sendScreenEventTag('Ready');
  }, [sendScreenEventTag]);

  useEffect(() => {
    if (isError) {
      sendScreenEventTag('Error');
    }
  }, [isError, sendScreenEventTag]);

  useEffect(() => {
    if (isLockedDialogOpen) {
      sendScreenEventTag('LockedModal');
    }
  }, [isLockedDialogOpen, sendScreenEventTag]);

  useEffect(() => {
    if (isGainLossTooltipOpen) {
      sendButtonActionTag('GainLossTooltip');
    }
  }, [isGainLossTooltipOpen, sendButtonActionTag]);

  useEffect(() => {
    if (!isLoading && !isError && !directWealthAccount) {
      sendScreenEventTag('NoProducts');
    }
  }, [directWealthAccount, isError, isLoading, sendScreenEventTag]);

  const sendProductCardTappedAnalytics = (
    accountType: Account,
    status: ProductStatus
  ) => {
    sendCardActionTag(accountType, status);
  };

  const sendLockedModalCloseAnalytics = () => {
    sendButtonActionTag('LockedModalCancel');
  };

  const sendPortfolioValueAnalytics = (dwValuation: number) => {
    sendScreenEventTagWithContextKeys('Ready', {
      portfoliovalue: dwValuation.toString(),
    });
  };

  // End

  const navigateToProductDashboard = (
    securePolicyNumber: string,
    accountType: Account
  ) => {
    sendCardActionTag(accountType, ProductStatus.Active);
    appStackNavigate('ProductDashboard', {
      securePolicyNumber,
    });
  };

  const navigateToUnlockPortfolio = useCallback(() => {
    isLockedDialogOpen
      ? sendButtonActionTag('LockedModalUnlockPortfolio')
      : sendButtonActionTag('LockedUnlockPortfolio');

    setIsLockedDialogOpen(false);
    dwTabStackNavigate('Unlock Portfolio');
  }, [dwTabStackNavigate, isLockedDialogOpen, sendButtonActionTag]);

  const handlePromotionalCardPress = (
    url: string,
    promoType: string,
    onPress?: () => void
  ) => {
    sendPromoCardActionTag(promoType, !!directWealthAccount);
    onPress ? onPress() : appStackNavigate('Web View', { url });
  };

  const setDetailsAndNavigateToDashboard = (
    securePolicyNumber: string,
    displayName: string,
    accountType: Account,
    prodNameStatus?: string,
    pensionProvider?: string
  ) => {
    setProdDetails({
      policyId: securePolicyNumber,
      prodName: displayName,
      prodNameStatus,
      ...(pensionProvider && {
        pensionProvider,
      }),
    });
    navigateToProductDashboard(securePolicyNumber, accountType);
  };

  const handleProductCardPress = (item: FormattedProduct) => {
    const {
      accountType,
      derivedStatus,
      securePolicyNumber,
      displayName,
      pensionProvider,
    } = item;
    switch (derivedStatus) {
      case ProductStatus.Locked:
        sendProductCardTappedAnalytics(accountType, ProductStatus.Locked);
        setIsLockedDialogOpen(true);
        break;
      case ProductStatus.Closing:
        sendProductCardTappedAnalytics(accountType, ProductStatus.Closing);
        break;
      case ProductStatus.Submitted:
        sendProductCardTappedAnalytics(accountType, ProductStatus.Submitted);
        setDetailsAndNavigateToDashboard(
          securePolicyNumber,
          displayName,
          accountType,
          directWealthAccount?.prodNameStatus,
          pensionProvider
        );
        break;
      case ProductStatus.Pending:
        setIsPendingDialogOpen(true);
        break;
      default:
        setDetailsAndNavigateToDashboard(
          securePolicyNumber,
          displayName,
          accountType,
          directWealthAccount?.prodNameStatus,
          pensionProvider
        );
    }
  };

  return {
    isLoading,
    isError,
    refetch,
    directWealthAccount,
    portfolioChartData,
    productListSections,
    promotions: filteredPromotionalData ?? defaultPromoData,
    showDPAUnlockButton: isAnyProductLocked,
    isLockedDialogOpen,
    setIsLockedDialogOpen,
    isPendingDialogOpen,
    setIsPendingDialogOpen,
    showSippTransferPromotion,
    sendProductCardTappedAnalytics,
    sendLockedModalCloseAnalytics,
    handlePromotionalCardPress,
    navigateToProductDashboard,
    navigateToUnlockPortfolio,
    products,
    isGainLossTooltipOpen,
    setIsGainLossTooltipOpen,
    handleProductCardPress,
    setPoliciesCountContextKeys,
    sendPortfolioValueAnalytics,
    hasSippProduct,
    isEnquirer,
    pensionConsolidationSummaryStatus,
    pensionsLoading,
  };
};
