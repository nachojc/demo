import {
  ProductCard,
  ProductCardContentProps,
  StackProps,
} from '@aviva/ion-mobile';
import { isManga } from '@hooks/use-expo-config';
import { DW_ACCOUNT_TYPE_COLORS } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { SectionList } from 'react-native';

import { FormattedProduct, ProductSection, ProductStatus } from '../types';
import { ItemContainer, ListContainer } from './product-card-list-styles';

type ProductCardListItem = Pick<
  StackProps,
  'marginHorizontal' | 'paddingVertical'
> & {
  item: FormattedProduct;
  onCardPress: (item: FormattedProduct) => void;
  currentIndex: number;
  totalItems?: number;
  stripColor?: string;
  isError?: boolean;
};

type ProductCardListProps = {
  onCardPress: (item: FormattedProduct) => void;
  sections: ProductSection[];
  totalNumberOfProducts?: number;
  colorPaletteProduct?: {
    [key: string]: string;
  };
  isError?: boolean;
};

const getChipProps = (
  status: ProductStatus | 'Unavailable'
): ProductCardContentProps['chipProps'] => {
  switch (status) {
    case 'Locked':
      return {
        variant: 'error',
        title: 'Locked',
        accessibilityLabel: ` Warning - Account locked.`,
      };
    case 'Submitted':
      return {
        variant: 'warning',
        title: 'Account Opening',
        accessibilityLabel: ` Warning - Account Opening.`,
      };
    case 'Closing':
      return {
        variant: 'error',
        title: 'Account Closing',
        accessibilityLabel: ` Warning - Account Closing.`,
      };
    case 'Pending':
      return {
        variant: 'warning',
        title: 'Pending',
        accessibilityLabel: ` Warning - Account pending.`,
      };
    case 'Unavailable':
      return {
        variant: 'warning',
        title: 'Please visit our website',
        accessibilityLabel: `Warning - Account Unavailable`,
      };
    case 'Active':
      return undefined;
    default:
      return undefined;
  }
};

const getDataItemAccessibilityLabel = (
  item: FormattedProduct,
  currentIndex: number,
  totalItems?: number
) => {
  const { gainOrLoss, valuation, gainOrLossPercentage } = item;
  const accessibilityHintSuffix = totalItems
    ? `, ${currentIndex + 1} of ${totalItems}.`
    : '.';

  const formattedValue = gainOrLoss?.raw
    ? `£${Math.abs(gainOrLoss.raw)}`
    : '£0';
  const trend = gainOrLoss?.raw && gainOrLoss?.raw < 0 ? 'lost' : 'gained';
  const percentageText = gainOrLossPercentage?.raw
    ? `${gainOrLossPercentage.raw}%`
    : '0%';
  const changeInGainOrLoss = gainOrLoss?.raw
    ? `You have ${trend} ${formattedValue} which is ${percentageText}.`
    : `There is no change in value.`;
  const accessibilityText = `Total account value is ${valuation.formatted}. ${changeInGainOrLoss}`;

  return `${
    item.displayName
  }${accessibilityHintSuffix} ${accessibilityText} Account number: ${item.policyNumber
    .split('')
    .join(' ')
    .replace('-', 'hyphen')}.`;
};

/* We are reusing ProductList on MANGA dashboard to show DW product cards and
      on MANGA it is meant to show a color line on the left with financial icon instead of the dot. */
const getCircleOrIconProp = (item: FormattedProduct) =>
  isManga()
    ? { leftIconName: 'financial' as const }
    : {
        leftCircleColor:
          DW_ACCOUNT_TYPE_COLORS[
            item.accountType as keyof typeof DW_ACCOUNT_TYPE_COLORS
          ],
      };

export const ProductListItem = ({
  item,
  onCardPress,
  currentIndex,
  totalItems,
  stripColor,
  isError,
  marginHorizontal,
  paddingVertical,
}: ProductCardListItem) => {
  return (
    <ItemContainer
      marginHorizontal={marginHorizontal}
      paddingVertical={paddingVertical}
    >
      <ProductCard
        stripColor={isManga() ? stripColor : undefined}
        testID={getTestId(item.displayName)}
        accessibilityLabel={getDataItemAccessibilityLabel(
          item,
          currentIndex,
          totalItems
        )}
        accessibilityHint={`Navigates to your ${item.displayName}`}
        onPress={() => {
          onCardPress(item);
        }}
      >
        <ProductCard.Content
          {...(item.valuation.raw > 0 && getCircleOrIconProp(item))}
          showUnavailableMessage={isError}
          rightIconName={isError ? 'external-link' : 'chevron-right'}
          heading={item.displayName}
          dataItemsProps={[
            {
              heading: 'Total account value:',
              value: item.valuation.formatted,
              gainOrLoss:
                item.derivedStatus !== 'Submitted'
                  ? item.gainOrLoss
                  : {
                      raw: null,
                      formatted: null,
                    },
              gainOrLossPercentage: item.gainOrLossPercentage,
              productName: item.displayName,
            },
            {
              heading: 'Account number:',
              value: item.policyNumber,
              isValueHorizontal: true,
              isValueTextSmall: true,
              productName: item.displayName,
            },
          ]}
          chipProps={getChipProps(item.derivedStatus)}
        />
      </ProductCard>
    </ItemContainer>
  );
};

export const ProductCardList = ({
  sections,
  onCardPress,
  totalNumberOfProducts,
  isError,
  colorPaletteProduct = {},
}: ProductCardListProps) => {
  return (
    <ListContainer>
      <SectionList
        sections={sections}
        renderItem={({ item, index }) => (
          <ProductListItem
            key={`product-card-${item.policyNumber}-${index}`}
            item={item}
            isError={isError}
            onCardPress={onCardPress}
            currentIndex={index}
            totalItems={totalNumberOfProducts}
            stripColor={colorPaletteProduct[item.policyNumber]}
            marginHorizontal="$xl"
            paddingVertical="$md"
          />
        )}
        scrollEnabled={false}
        keyExtractor={(item) => item.securePolicyNumber}
        showsVerticalScrollIndicator={false}
      />
    </ListContainer>
  );
};
