import { Shimmer, XStack, YStack } from '@aviva/ion-mobile';

export const EditorialContentCarouselLoading = ({
  height = 205,
}: {
  height?: number;
}) => (
  <XStack accessibilityLabel="Loading carousel" paddingHorizontal="$xl">
    {[...Array(2)].map((_, i) => {
      return (
        <YStack
          key={`editorial-content-${i}`}
          accessibilityLabel="Editorial Content Carousel Loading"
          accessibilityHint="Loading carousel item for editorial content"
          height={height}
          marginRight={10}
        >
          <Shimmer height={112} width={207} borderRadius={5} />
          <YStack space={8} marginTop={12}>
            <Shimmer height={18} width={207} />
            <Shimmer height={18} width={190} />
            <Shimmer height={16} width={60} />
          </YStack>
        </YStack>
      );
    })}
  </XStack>
);
