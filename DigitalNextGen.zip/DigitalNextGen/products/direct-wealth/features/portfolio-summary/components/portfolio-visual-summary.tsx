import { getTokens, getVariableValue, Text, XStack } from '@aviva/ion-mobile';
import { useTranslation } from 'react-i18next';

import { ChartHeaderContainer, PortfolioChartContainer } from '../styles';
import { FormattedDirectWealthAccount, PortfolioChart } from '../types';
import { PortfolioSummaryChart } from './portfolio-summary-chart';

export const PortfolioVisualSummary = ({
  directWealthAccount,
  portfolioChartData,
}: {
  directWealthAccount: FormattedDirectWealthAccount;
  portfolioChartData: PortfolioChart;
}) => {
  const tokens = getTokens();
  const { t } = useTranslation();
  return (
    <PortfolioChartContainer>
      <ChartHeaderContainer
        accessible
        accessibilityRole="text"
        accessibilityLabel={`Your current portfolio value is ${directWealthAccount?.valuation?.formatted}.`}
      >
        <XStack testID="portfolio-value-date">
          <Text
            fontVariant="overline-semibold-Gray300"
            tamaguiTextProps={{
              letterSpacing: getVariableValue(tokens.space.xs),
            }}
          >
            {t('pension.performance.currentPortfolioValue')}
          </Text>
        </XStack>
        <Text fontVariant="heading0-semibold-White">
          {directWealthAccount.valuation?.formatted.toString()}
        </Text>
      </ChartHeaderContainer>
      <PortfolioSummaryChart chartData={portfolioChartData} />
    </PortfolioChartContainer>
  );
};
