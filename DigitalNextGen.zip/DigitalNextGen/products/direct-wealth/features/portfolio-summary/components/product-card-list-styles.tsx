import { styled, YStack } from '@aviva/ion-mobile';

export const ListContainer = styled(YStack, {
  minHeight: 100,
});

export const ItemContainer = styled(YStack, {
  name: 'Item Container',
  backgroundColor: '$backgroundTransparent',
});
