import { Shimmer, XStack, YStack } from '@aviva/ion-mobile';

export const EditorialContentListLoading = ({
  height,
}: {
  height?: number;
}) => (
  <YStack height={height}>
    {[...Array(3)].map((_, i) => {
      return (
        <XStack
          key={`editorial-content-${i}`}
          marginVertical="$md"
          marginHorizontal="$xl"
          accessibilityLabel="Editorial Content List Loading"
          accessibilityHint="Loading list item for editorial content"
        >
          <XStack>
            <Shimmer height={80} width={80} borderRadius={5} />
            <YStack mr={26} ml={16} space={6}>
              <Shimmer height={16} width={200} />
              <Shimmer height={16} width={170} />
              <Shimmer height={16} width={75} />
            </YStack>
            <Shimmer height={20} width={16} />
          </XStack>
        </XStack>
      );
    })}
  </YStack>
);
