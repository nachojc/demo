import { Stack, Text, YStack } from '@aviva/ion-mobile';
import { SimpleWealthOnboardingCardStatus } from '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey';
import { EditorialContentCard } from '@direct-wealth/components/editorial-content-card';
import { FCEntryPointCard } from '@direct-wealth/features/find-and-combine/entry-point-card/entry-point-card';
import { OnboardingCard } from '@direct-wealth/features/simple-wealth/components/onboarding-card/onboarding-card';
import { useAnalytics } from '@hooks/use-analytics';
import { useSelector } from '@legendapp/state/react';
import { config } from '@src/common/config';
import { FeatureFlags } from '@src/feature-flags';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { createRoleLinkOpenHint } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';

import {
  WEALTH_CONTROL_AVIVA_SAVE_CARD_CLICKED,
  WEALTH_CONTROL_TRANSFER_CARD_CLICKED,
} from '../analytics';

export const FIND_AND_COMBINE_TITLE =
  'Find lost pensions and easily combine your money in one place';

export const SIPP_WITH_PRODUCTS_TITLE =
  'Transfer other pensions into your Self-Invested Personal Pension';

export const SIPP_WITHOUT_PRODUCTS_TITLE =
  'Transfer other pensions into a new Self-Invested Personal Pension';

export const AVIVA_SAVE_TITLE =
  'Aviva Save: Login or get started with our savings marketplace';

export const ISA_APPLY_DIRECT_TITLE = 'ISA Apply Direct';

/**
 * @deprecated use TakeControlCardList instead
 * This component is only visible in DW.
 * After DW has merged into MANGA this component will be removed.
 */
export const WealthControlCardList = ({
  showSippTransfer = false,
  hasSippProduct = false,
  isEnquirer = false,
  isSimpleWealthEnabled = false,
  simpleWealthOnboardingCardStatus = 'initial',
  simpleWealthCardPressed,
  daysToAdviceExpiry,
}: {
  showSippTransfer?: boolean;
  hasSippProduct?: boolean;
  isEnquirer?: boolean;
  isSimpleWealthEnabled?: boolean;

  simpleWealthCardPressed: () => void;
  simpleWealthOnboardingCardStatus?: SimpleWealthOnboardingCardStatus;
  daysToAdviceExpiry?: number;
}) => {
  const { navigate } = useAppStackNavigation();
  const analytics = useAnalytics();
  const isaApplyDirectFlowEnabled = useSelector(
    FeatureFlags.dwIsaApplyDirectNativeFlowEnabled
  );

  const onSIPPCardPress = () => {
    analytics.trackUserEvent(WEALTH_CONTROL_TRANSFER_CARD_CLICKED, {
      quotetype: 'manual-entry',
    });
    navigate('SIPP Transfer', { screen: 'Before You Start' });
  };

  const onAvivaSaveCardPress = () => {
    analytics.trackUserEvent(WEALTH_CONTROL_AVIVA_SAVE_CARD_CLICKED);
    navigate('Web View', {
      url: config.AVIVA_BASE_URL.get() + '/investments/savings-accounts/',
    });
  };

  const onIsaApplyDirectCardPress = () => {
    navigate('ISA Apply', { screen: 'ISA Apply Landing' });
  };

  const SIPP_TITLE = hasSippProduct
    ? SIPP_WITH_PRODUCTS_TITLE
    : SIPP_WITHOUT_PRODUCTS_TITLE;

  return (
    <YStack
      backgroundColor="$White"
      paddingVertical={'$xxl'}
      paddingHorizontal={'$xl'}
    >
      <Stack accessible accessibilityRole="header">
        <Text
          testID={getTestId('take-control-of-your-wealth')}
          fontVariant="heading5-semibold-Secondary800"
          tamaguiTextProps={{ marginBottom: '$xl' }}
        >
          Take control of your wealth
        </Text>
      </Stack>
      <YStack space={'$xl'}>
        <Stack
          accessible
          accessibilityLabel={`Content 1 of ${
            showSippTransfer ? 3 : 2
          }. ${FIND_AND_COMBINE_TITLE}`}
          accessibilityRole="link"
        >
          <FCEntryPointCard
            isEnquirer={isEnquirer}
            parentComponent="portfolio-summary"
          />
        </Stack>
        {showSippTransfer && (
          <Stack
            accessible
            accessibilityHint={createRoleLinkOpenHint(SIPP_TITLE)}
            accessibilityLabel={`Content 2 of 3. ${SIPP_TITLE}.`}
            accessibilityRole="link"
          >
            <EditorialContentCard
              type="NoSubtitle"
              icon="plus"
              variant="small"
              title={SIPP_TITLE}
              onPress={onSIPPCardPress}
            />
          </Stack>
        )}
        <Stack
          accessible
          accessibilityLabel={`Content ${showSippTransfer ? 3 : 2} of ${
            showSippTransfer ? 3 : 2
          }. ${AVIVA_SAVE_TITLE}`}
          accessibilityRole="link"
        >
          <EditorialContentCard
            type="NoSubtitle"
            icon="piggy-bank"
            variant="small"
            title={AVIVA_SAVE_TITLE}
            onPress={onAvivaSaveCardPress}
          />
        </Stack>
        {isaApplyDirectFlowEnabled && (
          <Stack>
            <EditorialContentCard
              type="NoSubtitle"
              variant="small"
              title={ISA_APPLY_DIRECT_TITLE}
              onPress={onIsaApplyDirectCardPress}
            />
          </Stack>
        )}
        {isSimpleWealthEnabled && (
          <OnboardingCard
            linkPosition="flex-start"
            variant={'basic'}
            product={'dw'}
            status={simpleWealthOnboardingCardStatus}
            onPress={simpleWealthCardPressed}
            daysToAdviceExpiry={daysToAdviceExpiry}
          />
        )}
      </YStack>
    </YStack>
  );
};
