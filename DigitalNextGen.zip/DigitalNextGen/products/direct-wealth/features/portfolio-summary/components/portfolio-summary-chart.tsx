import { getTokens, getVariableValue, Stack, Text } from '@aviva/ion-mobile';
import { DW_ACCOUNT_TYPE_COLORS } from '@src/theme/tokens';
import { exhaustive } from '@src/utils/exhaustive';
import { getTestId } from '@src/utils/get-test-id';
import { useMemo } from 'react';
import { Dimensions } from 'react-native';
import RNFusionCharts, { ChartObject } from 'react-native-fusioncharts';

import { ChartBodyContainer } from '../styles';
import { Account, PortfolioChart } from '../types';

const productTypeMap: { [key in Account]: string } = {
  SIPP: 'Self Invested Personal Pension',
  ISA: 'Individual Savings Account',
  GIA: 'General Investment Account',
  Drawdown: 'Pension Drawdown',
};

export const chartCanvasHeight = Dimensions.get('window').width - 120;
export const pieRadius = chartCanvasHeight * 0.4;
export const doughnutRadius = pieRadius * 0.65;

export const PortfolioSummaryChart = ({
  chartData,
}: {
  chartData: PortfolioChart;
}) => {
  const tokens = getTokens();

  const paletteColors =
    chartData.state === 'populated'
      ? chartData.data?.map(({ type }) => DW_ACCOUNT_TYPE_COLORS[type])
      : [getVariableValue(tokens.color.WealthBlue80)];

  const startingAngle = chartData.state === 'populated' ? 90 : 125;

  const accessibilityLabel = useMemo(
    () => getChartAccessibilityLabels(chartData),
    [chartData]
  );

  const chartConfig: ChartObject = {
    type: 'doughnut2d',
    width: '100%',
    height: chartCanvasHeight,
    dataFormat: 'json',
    dataSource: {
      chart: {
        theme: 'fusion',
        paletteColors,
        pieRadius,
        doughnutRadius,
        bgColor: getVariableValue(tokens.color.WealthBlue95),
        labelFont: 'Verdana',
        labelFontSize: 12,
        labelFontColor: getVariableValue(tokens.color.White),
        smartLineAlpha: 0,
        enableRotation: false,
        enableSlicing: false,
        showValues: false,
        showLegend: false,
        enableSmartLabels: 1,
        manageLabelOverflow: 1,
        showPlotBorder: true,
        plotBorderColor: getVariableValue(tokens.color.WealthBlue95),
        plotBorderThickness: 4,
        startingAngle,
        showTooltip: false,
        plotHoverEffect: false,
        chartTopMargin: 0,
        chartBottomMargin: 0,
        chartLeftMargin: 0,
        chartRightMargin: 0,
        labelDistance: 2,
      },
      data: chartData.data,
    },
  };

  return (
    <>
      <Stack
        accessible
        accessibilityLabel={accessibilityLabel}
        testID={getTestId('total-portfolio-value-graph')}
        marginTop={'$xl'}
        height={chartCanvasHeight}
      >
        <RNFusionCharts chartConfig={chartConfig} />
      </Stack>
      {chartData.state === 'opening' && (
        <ChartBodyContainer>
          <Text
            fontVariant="small-regular-White"
            tamaguiTextProps={{ textAlign: 'center' }}
          >
            When your account has opened, the value will be shown above.
          </Text>
        </ChartBodyContainer>
      )}
    </>
  );
};

function getChartAccessibilityLabels(chartData: PortfolioChart) {
  switch (chartData.state) {
    case 'opening':
      return 'Total Portfolio Value Graph. No portfolio breakdown to display. When your account has opened, the value will be shown above.';
    case 'empty':
      return 'Total Portfolio Value Graph. No portfolio breakdown to display.';
    case 'populated':
      return chartData.data.reduce((acc, cur) => {
        return `Total Portfolio Value Graph. ${
          acc + productTypeMap[cur.type]
        } ${cur.label}. `;
      }, '');
    default:
      exhaustive(chartData);
  }
}
