import { styled, YStack } from '@aviva/ion-mobile';

export const EnquirerContainer = styled(YStack, {
  name: 'Portfolio Chart Container',
  backgroundColor: '$WealthBlue95',
});

export const EnquirerSummaryContainer = styled(YStack, {
  name: 'Chart Header Container',
  padding: '$xxxxl',
  marginHorizontal: '$xxl',
  alignItems: 'center',
});
