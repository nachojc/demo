import { getTokens, getVariableValue, Text, XStack } from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';
import { useTranslation } from 'react-i18next';

import {
  EnquirerContainer,
  EnquirerSummaryContainer,
} from './enquirer-summary-header-styles';

export const EnquirerSummaryHeader = () => {
  const tokens = getTokens();
  const { t } = useTranslation();

  return (
    <EnquirerContainer>
      <EnquirerSummaryContainer
        accessible
        accessibilityRole="text"
        accessibilityLabel={`Your current portfolio value is £0.00`}
      >
        <XStack testID={getTestId('enquirer-header')}>
          <Text
            fontVariant="overline-semibold-Gray300"
            tamaguiTextProps={{
              letterSpacing: getVariableValue(tokens.space.xs),
            }}
          >
            {t('pension.performance.currentPortfolioValue')}
          </Text>
        </XStack>

        <Text
          fontVariant="heading0-semibold-White"
          tamaguiTextProps={{
            paddingBottom: '$xl',
          }}
        >
          £0.00
        </Text>
        <Text
          fontVariant="small-regular-White"
          tamaguiTextProps={{
            textAlign: 'center',
          }}
        >
          It looks like you currently don’t hold any active wealth products. Get
          started below.
        </Text>
      </EnquirerSummaryContainer>
    </EnquirerContainer>
  );
};
