import { getTokens, getVariableValue, Text, YStack } from '@aviva/ion-mobile';
import { PromotionalCard } from '@aviva/ion-mobile/components/cards/promotional-card/promotional-card';
import { PromotionalCardHeight } from '@aviva/ion-mobile/components/cards/promotional-card/promotional-card-styles';
import { Carousel } from '@aviva/ion-mobile/components/carousel';
import { getTestId } from '@src/utils/get-test-id';
import { useWindowDimensions } from 'react-native';

import { PromotionalDataItem } from '../hooks/use-promotional-card-data';

type PromotionalCardListProps = {
  promotionalData: PromotionalDataItem[];
  onPress: (link: string, promoType: string, onPress?: () => void) => void;
  hasDirectWealthAccount: boolean;
  isEnquirer?: boolean;
};

export const PromotionalCardList = ({
  promotionalData,
  onPress,
  hasDirectWealthAccount,
  isEnquirer = false,
}: PromotionalCardListProps) => {
  const paddingHorizontal = getVariableValue(getTokens().space.xl);
  const { width: deviceWidth } = useWindowDimensions();
  const cardWidth = deviceWidth - paddingHorizontal * 3;

  return (
    <YStack paddingTop={'$xl'} paddingHorizontal={'$xl'}>
      <Text
        tamaguiTextProps={{
          testID: getTestId('promotional-content-header'),
          paddingBottom: '$xl',
          accessibilityRole: 'header',
          accessibilityHint: 'Carousel content',
        }}
        fontVariant="heading5-semibold-Secondary800"
      >
        Add products to your portfolio
      </Text>
      {!hasDirectWealthAccount && !isEnquirer ? (
        <Text
          tamaguiTextProps={{
            paddingBottom: '$xl',
          }}
          fontVariant="body-regular-Gray700"
        >
          It looks like you currently don’t hold any active wealth products with
          us. Add products to your portfolio below.
        </Text>
      ) : null}
      <Carousel
        height={PromotionalCardHeight}
        testID={getTestId('promotional-content')}
        contentWidth={cardWidth}
        showDots
      >
        {promotionalData?.map((item, index) => (
          <YStack
            key={item.id}
            style={{ marginRight: paddingHorizontal }}
            spaceDirection="horizontal"
          >
            <PromotionalCard
              index={index}
              testID={`promo-card-${index}`}
              heading={item.title}
              text={item.description}
              linkText="Learn more"
              cardWidth={cardWidth}
              accessibilityLabel={`Content ${index + 1} of ${
                promotionalData?.length
              }. Learn more about ${item.title}`}
              accessibilityRole="link"
              accessibilityHint="Opens external webpage"
              onPress={() => {
                onPress(item.url, item.id, item.onPress);
              }}
            />
          </YStack>
        ))}
      </Carousel>
    </YStack>
  );
};
