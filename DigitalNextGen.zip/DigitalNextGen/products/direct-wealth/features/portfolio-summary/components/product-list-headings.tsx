import {
  getTokens,
  getVariableValue,
  Icon,
  Stack,
  Text,
  XStack,
} from '@aviva/ion-mobile';
import { Dispatch, SetStateAction } from 'react';

export const PortfolioSummaryHeadings = ({
  setIsGainLossTooltipOpen,
}: {
  setIsGainLossTooltipOpen: Dispatch<SetStateAction<boolean>>;
}) => {
  const tokens = getTokens();

  return (
    <Stack
      padding={'$xl'}
      backgroundColor={getVariableValue(tokens.color.WealthBlue95)}
    >
      <Text
        fontVariant="heading5-semibold-White"
        tamaguiTextProps={{ accessible: false, marginBottom: '$xl' }}
      >
        Your wealth portfolio
      </Text>
      <XStack alignItems="center" space="$md">
        <Text
          fontVariant="body-regular-White"
          tamaguiTextProps={{ accessible: false }}
        >
          See how your performance is calculated
        </Text>
        <Stack
          onPress={() => {
            setIsGainLossTooltipOpen((value) => !value);
          }}
          hitSlop={{ top: 28, bottom: 28, left: 28, right: 28 }}
          accessible
          accessibilityRole="button"
          accessibilityLabel="Gain or Loss tooltip."
          accessibilityHint="Display information modal."
        >
          <Icon
            name="info"
            color={getVariableValue(tokens.color.Primary500)}
            stroke={getVariableValue(tokens.color.Gray900)}
            height={getVariableValue(tokens.size[4])}
            width={getVariableValue(tokens.size[4])}
          />
        </Stack>
      </XStack>
    </Stack>
  );
};
