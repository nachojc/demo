import { Button, Dialog, Stack } from '@aviva/ion-mobile';

export const PendingDialog = ({
  titleText,
  copyText,
  cancelButtonLabel,
  open,
  onCancel,
}: {
  open: boolean;
  onCancel: () => void;
  titleText: string;
  copyText: string;
  cancelButtonLabel: string;
}) => (
  <Dialog open={open} title={titleText} copy={copyText}>
    <Stack space="$md" marginTop="$xl">
      <Button onPress={onCancel} accessibilityLabel="Cancel Dialog Button">
        {cancelButtonLabel}
      </Button>
    </Stack>
  </Dialog>
);
