import { Button, ButtonVariant, Dialog, Stack } from '@aviva/ion-mobile';

export const LockedDialog = ({
  open,
  onUnlock,
  onCancel,
  titleText,
  copyText,
  unlockButtonLabel,
  cancelButtonLabel,
}: {
  open: boolean;
  onUnlock: () => void;
  onCancel: () => void;
  titleText: string;
  copyText: string;
  unlockButtonLabel: string;
  cancelButtonLabel: string;
}) => (
  <Dialog open={open} title={titleText} copy={copyText}>
    <Stack space="$md" marginTop="$xl" key="hi">
      <Button
        onPress={onUnlock}
        accessibilityLabel="Unlock your portfolio Dialog Button"
      >
        {unlockButtonLabel}
      </Button>
      <Button
        variant={ButtonVariant.LINK_TEXT}
        onPress={onCancel}
        accessibilityLabel="Cancel Dialog Button"
      >
        {cancelButtonLabel}
      </Button>
    </Stack>
  </Dialog>
);
