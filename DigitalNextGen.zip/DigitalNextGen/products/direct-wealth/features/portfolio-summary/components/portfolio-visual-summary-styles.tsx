import { styled, YStack } from '@aviva/ion-mobile';

export const ValuationContainer = styled(YStack, {
  alignItems: 'baseline',
  flexDirection: 'row',
});
