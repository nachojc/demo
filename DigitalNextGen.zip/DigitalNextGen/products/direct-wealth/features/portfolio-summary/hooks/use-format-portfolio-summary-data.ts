import {
  DirectWealthAccount,
  DirectWealthProduct,
} from '@direct-wealth/validation/schemas/direct-wealth-account';
import { unlockProductRequested } from '@interfaces/storage';
import { Observable } from '@legendapp/state';
import { useSelector } from '@legendapp/state/react';
import { DIRECT_WEALTH_PRODUCT_CODES } from '@src/features/dashboard/constants';
import { DirectWealthAccounts } from '@src/validation/schemas/customer';
import { Products } from '@src/validation/schemas/product/products';
import { useEffect } from 'react';

import { ProductSection, ProductStatus } from '../types';
import { usePortfolioChartData } from './use-portfolio-chart-data';
import { usePromotionalData } from './use-promotional-card-data';

const dwDisplayNameMap = {
  80103: 'Stocks and Shares ISA',
  80105: 'Pension (SIPP)',
  80106: 'Investment account',
  80107: 'Pension drawdown (SIPP)',
};
type DWProductCodes = keyof typeof dwDisplayNameMap;
type ObsBoolean = boolean | Observable<boolean | null>;

type FormattedDirectWealthAccountProps = {
  isUserIDVPending: ObsBoolean;
  customerDPALevel?: string;
  directWealthProducts: DirectWealthAccounts;
  directWealthAccount: DirectWealthAccount;
};

export type FormattedDirectWealthAccount = DirectWealthAccount & {
  prodNameStatus: string;
};

export type ProductListSection = {
  id: 'withValuation' | 'withoutValuation';
  showSeparator?: boolean;
  data: ProductSection['data'];
};

export const useFormatPortfolioSummaryData = (
  directWealthAccount?: DirectWealthAccount,
  directWealthProducts?: DirectWealthAccounts,
  customerDPALevel?: string,
  photoIdvStatus?: string,
  customerProducts?: Products[]
) => {
  // This is set to true when user completes IDV flow,
  // had to be done this way as the IDV status doesn't update straight away after user submits documents.

  const hasunlockProductRequested = useSelector(() => unlockProductRequested);

  const isUserIDVPending: ObsBoolean =
    customerDPALevel !== '2' &&
    (photoIdvStatus === 'inProgress' || hasunlockProductRequested);

  useEffect(() => {
    if (customerDPALevel === '2' || photoIdvStatus === 'inProgress') {
      // We delete unlockProductRequested flag once we have got the updated status from the API
      unlockProductRequested.delete();
    }
  }, [customerDPALevel, photoIdvStatus]);

  const { promotionalData } = usePromotionalData();
  const filteredPromotionalData =
    directWealthAccount &&
    promotionalData.filter((promotion) => directWealthAccount[promotion.id]);

  const portfolioChartData = usePortfolioChartData(directWealthAccount);

  const isAnyProductLocked =
    !isUserIDVPending &&
    directWealthAccount?.products.some((item) => {
      return checkIsProductLocked(item.dpaLevel, customerDPALevel);
    });

  const hasSippProduct = directWealthAccount?.products.find(
    (product) => product.accountType === 'SIPP'
  );

  const formattedDirectWealthAccount =
    directWealthAccount &&
    formatDirectWealthAccount({
      isUserIDVPending,
      customerDPALevel,
      directWealthProducts,
      directWealthAccount,
    });

  const productListSections = getProductListSections(
    formattedDirectWealthAccount,
    customerProducts
  );

  return {
    formattedDirectWealthAccount,
    portfolioChartData,
    productListSections,
    filteredPromotionalData,
    isAnyProductLocked,
    hasSippProduct,
  };
};

const getProductsAvailables = (
  formattedDirectWealthAccount?: FormattedDirectWealthAccount
) => {
  const productsWithValuation = formattedDirectWealthAccount?.products?.filter(
    ({ valuation }) => valuation.raw > 0
  );

  const productsWithoutValuation =
    formattedDirectWealthAccount?.products?.filter(
      ({ valuation }) => valuation.raw === 0
    );
  const productsAvailable = productsWithValuation && productsWithoutValuation;

  return { productsWithValuation, productsWithoutValuation, productsAvailable };
};

export const getProductListSections = (
  formattedDirectWealthAccount?: FormattedDirectWealthAccount,
  customerProducts?: Products[]
): ProductListSection[] => {
  const { productsWithValuation, productsWithoutValuation, productsAvailable } =
    getProductsAvailables(formattedDirectWealthAccount);

  const dwCustomerProducts = customerProducts?.filter(
    (product) =>
      product.ProductCode &&
      DIRECT_WEALTH_PRODUCT_CODES.includes(product.ProductCode)
  );
  const productsAccountNumberOnly =
    !productsAvailable && dwCustomerProducts
      ? dwCustomerProducts.map((dwItem) => ({
          __tag: 'DWProduct',
          valuation: { raw: 0, formatted: 'Unavailable' },
          gainOrLoss: { raw: null, formatted: null },
          gainOrLossPercentage: { raw: null, formatted: null },
          accountNumber: dwItem?.AccountNumber || '',
          status: 'Unavailable',
          derivedStatus: 'Unavailable',
          displayName:
            (dwItem.ProductCode &&
              dwDisplayNameMap[
                dwItem.ProductCode as unknown as DWProductCodes
              ]) ||
            dwItem.DisplayName ||
            '',
          securePolicyNumber: dwItem?.SecurePolicyNumber,
          policyNumber: dwItem?.AccountNumber || '',
          accountType: '',
          isLoaded: false,
          dpaLevel: '2',
        }))
      : [];
  return productsAvailable
    ? [
        {
          id: 'withValuation',
          data: productsWithValuation as ProductSection['data'],
        },
        {
          id: 'withoutValuation',
          showSeparator:
            productsWithValuation &&
            productsWithValuation.length > 0 &&
            productsWithoutValuation &&
            productsWithoutValuation.length > 0,
          data: productsWithoutValuation as ProductSection['data'],
        },
      ]
    : [
        {
          id: 'withoutValuation',
          showSeparator: productsAccountNumberOnly.length > 0,
          data: productsAccountNumberOnly as ProductSection['data'],
        },
      ];
};

export const formatDirectWealthAccount = ({
  isUserIDVPending,
  customerDPALevel,
  directWealthProducts,
  directWealthAccount,
}: FormattedDirectWealthAccountProps): FormattedDirectWealthAccount => {
  const productNamesandStatuses: string[] = [];
  const productsWithDerivedStatus = directWealthAccount?.products.map(
    (product) => {
      const productStatus = getProductStatus(
        product,
        isUserIDVPending,
        customerDPALevel
      );
      const pensionProvider = getPensionProvider(product, directWealthProducts);

      productNamesandStatuses.push(
        `${product.displayName}:${productStatus}`
          .replace(/\s/g, '')
          .toLowerCase()
      );
      return {
        ...product,
        derivedStatus: productStatus,
        pensionProvider,
      };
    }
  );

  return {
    ...directWealthAccount,
    products: productsWithDerivedStatus,
    prodNameStatus: productNamesandStatuses.join('|'),
  };
};

const getPensionProvider = (
  product: DirectWealthProduct,
  directWealthProducts: DirectWealthAccounts
) => {
  if (product.accountType === 'SIPP') {
    return directWealthProducts?.find(
      (dwproduct) => dwproduct?.AccountNumber === product.accountNumber
    )?.HostSystem;
  }
  return undefined;
};

const checkIsProductLocked = (
  requireDPALevel?: string,
  customerDPALevel?: string
) => {
  if (customerDPALevel === undefined || requireDPALevel === undefined) {
    return false;
  }
  return parseFloat(customerDPALevel) < parseFloat(requireDPALevel);
};

const getProductStatus = (
  product: DirectWealthProduct,
  isUserIDVPending: ObsBoolean,
  customerDPALevel?: string
) => {
  if (isUserIDVPending) {
    return ProductStatus.Pending;
  }
  if (checkIsProductLocked(product.dpaLevel, customerDPALevel)) {
    return ProductStatus.Locked;
  }
  return product.status as ProductStatus;
};
