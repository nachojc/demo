import { DirectWealthAccount } from '@direct-wealth/validation/schemas/direct-wealth-account';
import { useCallback, useEffect, useState } from 'react';

import { PortfolioChart } from '../types';

const calculateValuePercentage = (value: number, totalValue: number) => {
  return `${((value / totalValue) * 100).toFixed(1)}%`;
};

export const usePortfolioChartData = (
  directWealthAccount?: DirectWealthAccount
) => {
  const [chartData, setChartData] = useState<PortfolioChart>({
    state: 'empty',
    data: [{ value: 1, label: '0%' }],
  });

  const productIsOpening = useCallback(() => {
    if (directWealthAccount == null) {
      return false;
    }

    const valueIsZero = (directWealthAccount.valuation?.raw ?? 0) === 0;
    const isOpening =
      directWealthAccount.products.find(
        (product) => product.status === 'Submitted'
      ) != null;

    return valueIsZero && isOpening;
  }, [directWealthAccount]);

  useEffect(() => {
    if (
      directWealthAccount == null ||
      directWealthAccount.products.length === 0 ||
      directWealthAccount.valuation.raw === 0
    ) {
      setChartData(
        productIsOpening()
          ? { state: 'opening', data: [{ value: 1, label: '0%' }] }
          : { state: 'empty', data: [{ value: 1, label: '0%' }] }
      );
    } else {
      const data = directWealthAccount.products
        .filter(({ valuation }) => valuation.raw > 0)
        .map(({ valuation, accountType }) => ({
          label: calculateValuePercentage(
            valuation.raw,
            directWealthAccount.valuation.raw
          ),
          value: valuation.raw,
          type: accountType,
        }));
      setChartData({ state: 'populated', data });
    }
  }, [directWealthAccount, productIsOpening]);

  return chartData;
};
