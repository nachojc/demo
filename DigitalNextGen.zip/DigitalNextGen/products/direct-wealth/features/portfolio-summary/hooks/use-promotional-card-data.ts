import { config } from '@config';
import { getMaximumIsaAllowance } from '@direct-wealth/common/utils/get-maximum-isa-allowance';
import { useSelector } from '@legendapp/state/react';
import { FeatureFlags } from '@src/feature-flags';
import { useAppStackNavigation } from '@src/navigation/app/hooks';

export type PromotionalDataItem = {
  id: 'displaySippPromotion' | 'displayIsaPromotion' | 'displayGiaPromotion';
  title: string;
  description: string;
  url: string;
  onPress?: () => void;
};
const { maximumFormattedValue } = getMaximumIsaAllowance();
export const usePromotionalData = () => {
  const { navigate } = useAppStackNavigation();
  const isaApplyNativeFlowEnabled = useSelector(
    FeatureFlags.dwIsaApplyDirectNativeFlowEnabled
  );
  const BASE = config.AVIVA_BASE_URL.get();

  const promotionalData: PromotionalDataItem[] = [
    {
      id: 'displayIsaPromotion',
      title: 'Stocks & Shares ISA',
      description: `A tax-efficient way of investing for tomorrow with a ${maximumFormattedValue} allowance.`,
      url: `${BASE}/investments/stocks-and-shares-isa/`,
      onPress: isaApplyNativeFlowEnabled
        ? () => {
            navigate('ISA Apply', { screen: 'ISA Apply Landing' });
          }
        : undefined,
    },
    {
      id: 'displaySippPromotion',
      title: 'Pension (SIPP)',
      description:
        'Invest with a pension that puts you in control of your future.',
      url: `${BASE}/retirement/aviva-pension/`,
    },
    {
      id: 'displayGiaPromotion',
      title: 'Investment Account',
      description:
        'Used all of your tax-free allowance in your Stocks and Shares ISA, why not look at an Investment Account?',
      url: `${BASE}/investments/investment-account/`,
    },
  ];

  const promotionalDataEnquirer: PromotionalDataItem[] = [
    {
      id: 'displayIsaPromotion',
      title: 'Stocks & Shares ISA',
      description: `A tax-efficient way of investing for tomorrow with a ${maximumFormattedValue} allowance.`,
      url: `${BASE}/investments/stocks-and-shares-isa/`,
    },
    {
      id: 'displayGiaPromotion',
      title: 'Investment Account',
      description:
        'Used all of your tax-free allowance in your Stocks and Shares ISA, why not look at an Investment Account?',
      url: `${BASE}/investments/investment-account/`,
    },
  ];

  return {
    promotionalData,
    promotionalDataEnquirer,
  };
};
