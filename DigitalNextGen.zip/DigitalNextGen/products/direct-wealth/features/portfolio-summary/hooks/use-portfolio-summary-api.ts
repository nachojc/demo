import { useCustomer } from '@hooks/use-customer';
import { useUserPhotoIdvStatus } from '@hooks/use-user-photo-idv-status';
import { useCallback, useMemo } from 'react';

import { useDirectWealthAccount } from '../../../common/hooks';
import { useFormatPortfolioSummaryData } from './use-format-portfolio-summary-data';
import { usePortfolioSummaryAnalytics } from './use-portfolio-summary-analytics';

export const usePortfolioSummaryApi = () => {
  const { sendButtonActionTag } = usePortfolioSummaryAnalytics();

  const { data: customer } = useCustomer();

  const customerDPALevel = customer?.CustomerDPALevel;
  const isEligibleForSippTransfer =
    customer?.Eligibilities?.find(
      (eligibility) =>
        eligibility.Type === 'isEligibleForDirectWealthSippTransfer.V2'
    )?.Value ?? false;

  const [
    {
      isInitialLoading: isIdvLoading,
      isError: isPhotoIdvStatusError,
      refetch: refetchPhotoIdvStatus,
    },
    photoIdvStatus,
  ] = useUserPhotoIdvStatus(customer);

  const firstDirectWealthAccount = customer?.DirectWealth?.[0];
  const SecureAccountNumber = firstDirectWealthAccount?.SecureAccountNumber;

  const {
    data: directWealthAccount,
    isError: isDWError,
    isLoading: isDWLoading,
    refetch: refetchDW,
  } = useDirectWealthAccount(SecureAccountNumber);

  const refetch = useCallback(() => {
    sendButtonActionTag('Retry');
    if (isPhotoIdvStatusError && customerDPALevel === '1') {
      refetchPhotoIdvStatus();
    }
    refetchDW();
  }, [
    customerDPALevel,
    isPhotoIdvStatusError,
    refetchDW,
    refetchPhotoIdvStatus,
    sendButtonActionTag,
  ]);

  const isError = useMemo(
    () => isDWError || isPhotoIdvStatusError,
    [isDWError, isPhotoIdvStatusError]
  );

  const isLoading = useMemo(
    () => ((isDWLoading && !!SecureAccountNumber) || isIdvLoading) && !isError,
    [isDWLoading, isError, isIdvLoading, SecureAccountNumber]
  );

  //TODO: refactor
  const {
    formattedDirectWealthAccount,
    portfolioChartData,
    productListSections,
    filteredPromotionalData,
    isAnyProductLocked,
    hasSippProduct,
  } = useFormatPortfolioSummaryData(
    directWealthAccount, // typeof object which is coming from useDirectWealthAccount(secureAccountNumber)
    customer?.DirectWealth,
    customerDPALevel,
    photoIdvStatus,
    customer?.Products
  );

  return {
    isLoading,
    isError,
    refetch,
    portfolioChartData,
    directWealthAccount: formattedDirectWealthAccount,
    productListSections,
    filteredPromotionalData,
    isAnyProductLocked,
    hasSippProduct,
    isEnquirer: customer?.IsEnquirer,
    photoIdvStatus,
    customerDPALevel,
    products: customer?.Products,
    isEligibleForSippTransfer,
  };
};
