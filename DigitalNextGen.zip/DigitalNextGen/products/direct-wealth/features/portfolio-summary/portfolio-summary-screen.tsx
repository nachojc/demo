import { Button, ScrollView, YStack } from '@aviva/ion-mobile';
import { useInitialiseSimpleWealthJourney } from '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey';
import { LoadingState } from '@direct-wealth/components/loading-state/loading-state';
import { OnboardingCard } from '@direct-wealth/features/simple-wealth/components/onboarding-card/onboarding-card';
import { navigatorShouldShowOnboardingPopup } from '@interfaces/storage';
import { useFocusEffect } from '@react-navigation/native';
import { ErrorDialog } from '@src/components/error-dialog';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useCallback, useState } from 'react';

import { ErrorView } from '../../components/error-view/error-view';
import { GainLossTooltip } from '../../components/gain-loss-tooltip/gain-loss-tooltip';
import { EditorialContentList } from '../editorial-content/editorial-content-list';
import { PCSEntryPoint } from '../pension-consolidation-summary/pcs-entry-point';
import { OnboardingModalPopup } from '../simple-wealth/components/onboarding-modal-popup/onboarding-modal-popup';
import { EnquirerSummaryHeader } from './components/enquirer-summary-header';
import { LockedDialog } from './components/locked-dialog';
import { PendingDialog } from './components/pending-dialog';
import { PortfolioVisualSummary } from './components/portfolio-visual-summary';
import { ProductCardList } from './components/product-card-list';
import { PortfolioSummaryHeadings } from './components/product-list-headings';
import { PromotionalCardList } from './components/promotional-card-list';
import { WealthControlCardList } from './components/wealth-control-card-list';
import { EnquirerSummaryLoadingScreen } from './enquirer-summary-loading-screen';
import { PortfolioSummaryLoadingScreen } from './portfolio-summary-loading-screen';
import {
  Background,
  FloatingContainer,
  ListContainer,
  TopBackground,
} from './styles';
import { usePortfolioSummaryViewModel } from './use-portfolio-summary-view-model';

type PortfolioSummaryScreenViewProps = {
  model: ReturnType<typeof usePortfolioSummaryViewModel>;
};

const FloatingUnlockButton = ({ onUnlock }: { onUnlock: () => void }) => (
  <FloatingContainer>
    <Button
      onPress={onUnlock}
      accessibilityLabel="Unlock your portfolio"
      accessibilityHint="Navigates to unlock your portfolio using our identity verification"
    >
      Unlock your portfolio
    </Button>
  </FloatingContainer>
);

export const PortfolioSummaryScreenView = ({
  model,
}: PortfolioSummaryScreenViewProps) => {
  const {
    isError,
    productListSections,
    isLoading,
    refetch,
    showDPAUnlockButton,
    isLockedDialogOpen,
    setIsLockedDialogOpen,
    sendLockedModalCloseAnalytics,
    portfolioChartData,
    promotions,
    handlePromotionalCardPress,
    isPendingDialogOpen,
    setIsPendingDialogOpen,
    showSippTransferPromotion,
    navigateToUnlockPortfolio,
    directWealthAccount,
    products,
    isGainLossTooltipOpen,
    setIsGainLossTooltipOpen,
    handleProductCardPress,
    setPoliciesCountContextKeys,
    sendPortfolioValueAnalytics,
    hasSippProduct,
    isEnquirer,
    pensionConsolidationSummaryStatus,
    pensionsLoading,
  } = model;

  const { t } = useTranslationDW();

  const {
    simpleWealthGetApiRefetch,
    simpleWealthGetIsLoading,
    isSimpleWealthGetApiError,
    setIsAccountApiError,
    isAccountApiError,
    isSimpleWealthEnabled,
    simpleWealthOnboardingCardStatus,
    daysToAdviceExpiry,
    simpleWealthCardPressed,
  } = useInitialiseSimpleWealthJourney();

  const ONBOARDING_POPUP_TIME = 4000;
  const [isOnboardingModalVisible, setIsOnboardingModalVisible] =
    useState(false);

  const LoadingScreen = isEnquirer
    ? EnquirerSummaryLoadingScreen
    : PortfolioSummaryLoadingScreen;
  const { hasPensions } = pensionConsolidationSummaryStatus;

  const loading = isEnquirer ? pensionsLoading || isLoading : isLoading;

  useFocusEffect(
    useCallback(() => {
      if (products) {
        setPoliciesCountContextKeys(products);
      }
    }, [products, setPoliciesCountContextKeys])
  );

  useFocusEffect(
    useCallback(() => {
      let isMounted = true;
      const shouldShowOnboardingPopup =
        navigatorShouldShowOnboardingPopup.get();
      if (shouldShowOnboardingPopup && isSimpleWealthEnabled) {
        const timer = setTimeout(() => {
          if (isMounted) {
            setIsOnboardingModalVisible(true);
            navigatorShouldShowOnboardingPopup.set(false);
          }
        }, ONBOARDING_POPUP_TIME);

        return () => {
          isMounted = false;
          setIsOnboardingModalVisible(false);
          clearTimeout(timer);
        };
      }
      return () => null;
    }, [isSimpleWealthEnabled])
  );

  useFocusEffect(
    useCallback(() => {
      if (directWealthAccount?.valuation?.raw) {
        sendPortfolioValueAnalytics(directWealthAccount.valuation.raw);
      }
    }, [directWealthAccount?.valuation?.raw, sendPortfolioValueAnalytics])
  );

  if (isError) {
    return <ErrorView onRetry={refetch} />;
  }

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <>
      {isEnquirer ? (
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
        >
          <EnquirerSummaryHeader />
          {!hasPensions && (
            <WealthControlCardList
              simpleWealthCardPressed={simpleWealthCardPressed}
              isEnquirer
            />
          )}

          <ListContainer>
            <YStack marginHorizontal={'$xl'}>
              {isSimpleWealthEnabled ? (
                <YStack paddingVertical="$lg">
                  <OnboardingCard
                    linkPosition="flex-start"
                    variant={'basic'}
                    product={'dw'}
                    status={simpleWealthOnboardingCardStatus}
                    onPress={simpleWealthCardPressed}
                    daysToAdviceExpiry={daysToAdviceExpiry}
                  />
                </YStack>
              ) : null}
              <PCSEntryPoint
                parentComponent={'portfolio-summary-screen-enquirer'}
              />
            </YStack>
            {promotions.length > 0 ? (
              <PromotionalCardList
                promotionalData={promotions}
                onPress={handlePromotionalCardPress}
                hasDirectWealthAccount={false}
                isEnquirer
              />
            ) : null}
          </ListContainer>
          <EditorialContentList
            context="EnquirerSummary"
            orientation="horizontal"
            tagInfo={{ type: 'enquirer|portfolio-summary' }}
            userUnderstanding="Novice"
          />
        </ScrollView>
      ) : (
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          showsVerticalScrollIndicator={false}
        >
          <TopBackground hasWealthBackground={!!directWealthAccount} />
          {directWealthAccount ? (
            <PortfolioVisualSummary
              directWealthAccount={directWealthAccount}
              portfolioChartData={portfolioChartData}
            />
          ) : null}
          <ListContainer>
            {directWealthAccount ? (
              <>
                <PortfolioSummaryHeadings
                  setIsGainLossTooltipOpen={setIsGainLossTooltipOpen}
                />
                <Background />
                {productListSections && (
                  <ProductCardList
                    sections={productListSections}
                    totalNumberOfProducts={
                      directWealthAccount?.products?.length
                    }
                    onCardPress={handleProductCardPress}
                  />
                )}
              </>
            ) : null}
            <YStack marginHorizontal={16}>
              <PCSEntryPoint parentComponent={'portfolio-summary-screen'} />
            </YStack>
            {promotions.length > 0 && (
              <PromotionalCardList
                promotionalData={promotions}
                onPress={handlePromotionalCardPress}
                hasDirectWealthAccount={!!directWealthAccount}
              />
            )}
          </ListContainer>
          <EditorialContentList
            context="PortfolioSummary"
            orientation="horizontal"
            tagInfo={{ type: 'portfolio-summary' }}
          />
          <WealthControlCardList
            showSippTransfer={showSippTransferPromotion}
            hasSippProduct={!!hasSippProduct}
            isSimpleWealthEnabled={isSimpleWealthEnabled}
            simpleWealthCardPressed={simpleWealthCardPressed}
            simpleWealthOnboardingCardStatus={simpleWealthOnboardingCardStatus}
            daysToAdviceExpiry={daysToAdviceExpiry}
          />
        </ScrollView>
      )}

      {isSimpleWealthEnabled ? (
        <>
          <OnboardingModalPopup
            isVisible={isOnboardingModalVisible}
            onHandleTrySimpleWealthPress={() => {
              setIsOnboardingModalVisible(false);
              simpleWealthCardPressed();
            }}
            onHandleNoButtonPress={() => {
              setIsOnboardingModalVisible(false);
            }}
          />
        </>
      ) : null}
      {showDPAUnlockButton && (
        <FloatingUnlockButton onUnlock={navigateToUnlockPortfolio} />
      )}
      {simpleWealthGetIsLoading && <LoadingState text={'loading'} />}
      <ErrorDialog
        open={isAccountApiError}
        onPress={() => setIsAccountApiError(false)}
        center
      />
      <ErrorDialog
        open={isSimpleWealthGetApiError}
        onPress={simpleWealthGetApiRefetch}
        center
      />
      <LockedDialog
        titleText={t('productCardLockedDialogText.title')}
        copyText={t('productCardLockedDialogText.copy')}
        unlockButtonLabel={t('productCardLockedDialogText.unlockButtonLabel')}
        cancelButtonLabel={t('productCardLockedDialogText.cancelButtonLabel')}
        open={isLockedDialogOpen}
        onUnlock={navigateToUnlockPortfolio}
        onCancel={() => {
          sendLockedModalCloseAnalytics();
          setIsLockedDialogOpen(false);
        }}
      />
      <PendingDialog
        titleText={t('productCardPendingDialogText.title')}
        copyText={t('productCardPendingDialogText.copy')}
        cancelButtonLabel={t('productCardPendingDialogText.cancelButtonLabel')}
        open={isPendingDialogOpen || false}
        onCancel={() => setIsPendingDialogOpen(false)}
      />
      <GainLossTooltip
        isTooltipVisible={isGainLossTooltipOpen}
        setIsTooltipVisible={setIsGainLossTooltipOpen}
      />
    </>
  );
};
export const PortfolioSummaryScreen = () => {
  const model = usePortfolioSummaryViewModel();
  return <PortfolioSummaryScreenView model={model} />;
};
