import { Stack, styled, YStack } from '@aviva/ion-mobile';

export const ListContainer = styled(YStack, {
  backgroundColor: '$White',
  paddingBottom: '$xxl',
});

export const TopBackground = styled(Stack, {
  height: 500,
  position: 'absolute',
  top: -500,
  left: 0,
  right: 0,

  variants: {
    hasWealthBackground: {
      true: {
        backgroundColor: '$WealthBlue95',
      },
    },
  },
});

export const ItemContainer = styled(YStack, {
  name: 'Item Container',
  paddingHorizontal: '$xl',
  marginBottom: '$xl',
  backgroundColor: '$backgroundTransparent',
});

export const FloatingContainer = styled(YStack, {
  padding: '$xl',
  backgroundColor: '$White',
  borderTopWidth: 1,
  borderTopColor: '$Gray100',
});

export const Background = styled(YStack, {
  height: 80,
  marginBottom: -80,
  backgroundColor: '$WealthBlue95',
});

// Portfolio Chart

const PortfolioHeaderContainerHeight = 122;
const PortfolioBodyContainerHeight = 44;

export const PortfolioChartContainer = styled(YStack, {
  name: 'Portfolio Chart Container',
  backgroundColor: '$WealthBlue95',
});

export const ChartHeaderContainer = styled(YStack, {
  name: 'Chart Header Container',
  backgroundColor: '$WealthBlue95',
  paddingVertical: '$xxl',
  alignItems: 'center',
  maxHeight: PortfolioHeaderContainerHeight,
});

export const ChartBodyContainer = styled(YStack, {
  name: 'Chart Body Container',
  backgroundColor: '$WealthBlue95',
  alignItems: 'center',
  marginTop: 16,
  marginBottom: 12,
  paddingHorizontal: 71,
  height: PortfolioBodyContainerHeight,
});
