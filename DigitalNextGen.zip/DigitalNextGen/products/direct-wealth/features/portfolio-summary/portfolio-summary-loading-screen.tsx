import {
  DoughnutShimmer,
  ProductCardLoading,
  Shimmer,
  Stack,
} from '@aviva/ion-mobile';

import {
  chartCanvasHeight,
  doughnutRadius,
  pieRadius,
} from './components/portfolio-summary-chart';
import {
  Background,
  ChartHeaderContainer,
  ItemContainer,
  ListContainer,
} from './styles';

const thickness = (pieRadius - doughnutRadius) * 2;

export const PortfolioSummaryLoadingScreen = () => {
  return (
    <Stack>
      <Stack backgroundColor={'$WealthBlue95'} paddingBottom={16}>
        <ChartHeaderContainer>
          <Shimmer width={'45%'} height={14} colorScheme={'dark'} />
          <Stack height={22} />
          <Shimmer width={'45%'} height={36} colorScheme={'dark'} />
        </ChartHeaderContainer>
        <Stack
          marginTop={'$xl'}
          height={chartCanvasHeight}
          justifyContent="center"
          alignItems="center"
        >
          <DoughnutShimmer
            colorScheme={'dark'}
            radius={pieRadius}
            thickness={thickness}
          />
        </Stack>
        <Stack paddingTop={22} paddingHorizontal={'$xl'}>
          <Shimmer width={'50%'} height={23} colorScheme={'dark'} />
          <Stack height={16} />
          <Shimmer width={'75%'} height={18} colorScheme={'dark'} />
        </Stack>
      </Stack>
      <ListContainer>
        <Background />
        <ItemContainer>
          <ProductCardLoading />
        </ItemContainer>
      </ListContainer>
    </Stack>
  );
};
