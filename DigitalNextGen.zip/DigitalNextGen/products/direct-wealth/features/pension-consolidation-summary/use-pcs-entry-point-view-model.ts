import { config } from '@config';
import { usePensionConsolidationSummary } from '@direct-wealth/common/hooks/use-pension-consolidation-summary';
import { useAnalytics } from '@hooks/use-analytics';
import { isManga } from '@hooks/use-expo-config';
import { useRemoteFeatureFlag } from '@hooks/use-remote-feature-flag';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { exhaustive } from '@src/utils/exhaustive';
import { useMemo } from 'react';

import {
  ACTION_DASHBOARD_PCS_CARD_TAPPED,
  ACTION_WEALTH_HUB_PCS_CARD_TAPPED,
  PORTFOLIO_SUMMARY_ENQUIRER_PCS,
  PORTFOLIO_SUMMARY_PCS,
  PRODUCT_DETAILS_PCS,
} from './analytics';

export type ParentComponent =
  | 'product-details-screen'
  | 'portfolio-summary-screen'
  | 'portfolio-summary-screen-enquirer'
  | 'manga-dashboard-screen'
  | 'wealth-hub-screen';

export type PensionStatus = {
  hasPensions: boolean;
  pensionsInTransfer: number;
  pensionsNotInTransfer: number;
};

export const usePCSEntryPointViewModel = (parentComponent: ParentComponent) => {
  const { navigate } = useAppStackNavigation();
  const analytics = useAnalytics();
  const { value: dwInMangaEnabled } = useRemoteFeatureFlag(
    'release-myaviva-direct-wealth-in-manga'
  );

  const [data, { isLoading, isError, refetch }] =
    usePensionConsolidationSummary();

  const pensionStatus: PensionStatus = {
    hasPensions:
      !!data?.pensionsInTransfer?.length ||
      !!data?.pensionsNotInTransfer?.length,
    pensionsInTransfer: data?.pensionsInTransfer?.length ?? 0,
    pensionsNotInTransfer: data?.pensionsNotInTransfer?.length ?? 0,
  };

  const hasPensionsTag = pensionStatus.hasPensions
    ? 'pcs-card'
    : 'no-pension-card';

  const title =
    parentComponent === 'portfolio-summary-screen-enquirer' ||
    parentComponent === 'product-details-screen'
      ? ''
      : 'Pension services';

  const tag = useMemo(
    () => getAnalyticsTag(parentComponent, hasPensionsTag),
    [hasPensionsTag, parentComponent]
  );

  const onPress = () => {
    if (isError) {
      return;
    }

    if (isManga()) {
      analytics.trackUserEvent(tag);
      if (!dwInMangaEnabled) {
        return;
      }
    }

    analytics.trackUserEvent(tag, {
      quotetype: 'tracing-service',
    });

    if (pensionStatus.hasPensions) {
      navigate('PCS Dashboard');
      return;
    }
    navigate('Web View', {
      url:
        config.AVIVA_BASE_URL.get() + '/retirement/pensions/find-and-combine/',
    });
  };

  return { onPress, pensionStatus, isLoading, isError, refetch, title };
};

const getAnalyticsTag = (
  parentComponent: ParentComponent,
  hasPensionsTag: string
): string => {
  switch (parentComponent) {
    case 'portfolio-summary-screen-enquirer':
      return `${PORTFOLIO_SUMMARY_ENQUIRER_PCS}${hasPensionsTag}-tapped`;
    case 'portfolio-summary-screen':
      return `${PORTFOLIO_SUMMARY_PCS}${hasPensionsTag}-tapped`;
    case 'product-details-screen':
      return `${PRODUCT_DETAILS_PCS}${hasPensionsTag}-tapped`;
    case 'manga-dashboard-screen':
      return ACTION_DASHBOARD_PCS_CARD_TAPPED;
    case 'wealth-hub-screen':
      return ACTION_WEALTH_HUB_PCS_CARD_TAPPED;
    default:
      exhaustive(parentComponent);
  }
};
