import { isManga } from '@hooks/use-expo-config';
import { useRemoteFeatureFlag } from '@hooks/use-remote-feature-flag';

import { PCSResultsCard } from './components/pcs-results-card';
import { PCSResultsCardLoading } from './components/pcs-results-card-loading';
import {
  ParentComponent,
  usePCSEntryPointViewModel,
} from './use-pcs-entry-point-view-model';

export const PCSEntryPoint = ({
  parentComponent,
  onCardPress,
}: {
  parentComponent: ParentComponent;
  onCardPress?: () => void;
}) => {
  const { onPress, pensionStatus, isLoading, isError, refetch, title } =
    usePCSEntryPointViewModel(parentComponent);

  const { value: dwInMangaEnabled } = useRemoteFeatureFlag(
    'release-myaviva-direct-wealth-in-manga'
  );

  if ((isManga() && isError) || !pensionStatus.hasPensions) {
    return null;
  }
  if (isLoading) {
    return <PCSResultsCardLoading />;
  }
  return (
    <PCSResultsCard
      cardTitle={isManga() && dwInMangaEnabled ? undefined : title}
      isError={isError}
      onPress={onCardPress || onPress}
      pensionStatus={pensionStatus}
      refetch={refetch}
    />
  );
};
