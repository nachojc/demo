import { PAGE_WEALTH } from '@constants/analytics';

export const PORTFOLIO_SUMMARY_ENQUIRER_PCS = `${PAGE_WEALTH}|pcs|enquirer|portfolio-summary|`;
export const PORTFOLIO_SUMMARY_PCS = `${PAGE_WEALTH}|pcs|portfolio-summary|`;
export const PRODUCT_DETAILS_PCS = `${PAGE_WEALTH}|pcs|product-details|`;

export const ACTION_DASHBOARD_PCS_CARD_TAPPED =
  PAGE_WEALTH + '|home-dashboard|pension-dashboard-tapped';

export const ACTION_WEALTH_HUB_PCS_CARD_TAPPED = `${PAGE_WEALTH}|home-dashboard|wealth-hub|pension-dashboard-tapped`;
