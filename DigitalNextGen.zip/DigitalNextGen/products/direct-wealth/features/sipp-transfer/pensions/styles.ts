import { ScrollView, styled, TamaguiText, YStack } from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';
import { isIpad } from '@src/utils/is-ipad';

export const ContainerScrollView = styled(ScrollView, {
  flex: 1,
  backgroundColor: '$White',
  paddingHorizontal: '$xl',
  space: '$xxl',
  paddingTop: '$sm',
});

export const TitleContainer = styled(YStack, {
  space: '$xxl',
  paddingBottom: '$xxxl',
});

export const Paragraph = styled(TamaguiText, {
  color: '$Gray750',
  fontWeight: '400',
  fontSize: '$body',
  lineHeight: 24,
});

export const SnackbarContainer = styled(YStack, {
  position: 'absolute',
  width: '100%',
  padding: '$md',
  bottom: isIpad ? tokens.size[13].val : 30,
  paddingBottom: isIpad ? '$xxl' : undefined,
  tabletNarrow: isIpad,
});

export const ModalContent = styled(YStack, {
  space: '$lg',
});

export const ButtonContainer = styled(YStack, {
  space: '$xl',
  tabletNarrow: isIpad,
});
