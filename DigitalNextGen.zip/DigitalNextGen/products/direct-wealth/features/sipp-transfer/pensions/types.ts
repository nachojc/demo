import { ValueOf } from 'type-fest';

export const CompanyEnteredFromSearch = {
  SearchCompany: 'Search for company',
  EnterManually: 'Enter manually',
} as const;

export const TransferOptions = {
  InFull: 'In full',
  InPart: 'In part',
} as const;

export type CompanyEnteredFromSearchActionTag = Record<
  ValueOf<typeof CompanyEnteredFromSearch>,
  string
>;
export type TransferOptionsActionTag = Record<
  ValueOf<typeof TransferOptions>,
  string
>;
