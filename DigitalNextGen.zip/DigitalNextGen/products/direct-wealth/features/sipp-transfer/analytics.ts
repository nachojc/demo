import { PAGE_WEALTH } from '@constants/analytics';

export const PAGE_WEALTH_SIPP_TRANSFER = `${PAGE_WEALTH}|sipp-transfer`;
