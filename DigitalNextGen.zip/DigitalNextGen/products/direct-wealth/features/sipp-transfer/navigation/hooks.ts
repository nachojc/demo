import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';

import { SIPPStackRouteParams, SIPPStackScreenNames } from './index';

export type SIPPStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<SIPPStackRouteParams>,
  NativeStackNavigationProp<Pick<AppStackDWRouteParams, 'ProductDashboard'>>
>;

export type SIPPStackRoute<T extends keyof SIPPStackRouteParams> = RouteProp<
  SIPPStackRouteParams,
  T
>;

/**
 * @description A typed wrapper around useRoute
 *
 * @T
 * T is the name of the screen from which you're calling this hook
 * It must be a key of SIPPStackRouteParams
 */
export function useSIPPStackRoute<T extends SIPPStackScreenNames>() {
  return useRoute<SIPPStackRoute<T>>();
}

/**
 * @description A typed wrapper around useNavigation
 *
 * For use within the SIPP navigation stack
 */
export function useSIPPStackNavigation() {
  return useNavigation<SIPPStackNavigation>();
}
