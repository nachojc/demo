import { getTokens, getVariableValue, TopAppBarDW } from '@aviva/ion-mobile';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';

import { FundAllocationTitleValues } from '../funds/fund-allocation/fund-allocation-screen';
import { FundDetailTitleValues } from '../funds/fund-details/fund-details-screen/fund-details-screen';
import { EditEntryPoint } from '../pensions/edit-pension/types';
import { SIPPHeader } from './header/sipp-header';
import { SIPPProvider } from './provider';
import { MissingPersonalDetails } from './provider/state/personal-details';

export type SIPPStackRouteParams = {
  ['Before You Start']: { secureId?: string } | undefined;
  ['Stronger Nudge']: undefined;
  ['Continue Without Advice']: undefined;
  ['Reasons to Transfer']: undefined;
  ['Sipp Onboarding Carousel']: undefined;
  ['Ready To Transfer']: undefined;
  ['About SIPP Transfer']: undefined;
  ['Employment Details - Employed']: undefined;
  ['Add Pension']: undefined;
  ['Edit Pension']: { policyNumber: string; entryPoint: EditEntryPoint };
  ['Employment Details - Self Employed']: undefined;
  ['Employment Details - Retired']: undefined;
  ['Employment Details - Not In Work']: undefined;
  ['Review Pensions']: undefined;
  //TODO Look to remove this Web View screen following completion of DW into MANGA and use AppStackNavigation for the web jump
  // - The aim being to avoid unnecessary duplication of web view screens - ticket raised: MANGA-13964
  ['Web View']: { url: string; ssoEnabled?: boolean };
  ['Investment Selection']: undefined;
  ['Risk Selection']: undefined;
  ['Fund Details']: FundDetailTitleValues;
  ['Fund Allocation Details']: undefined;
  ['Fund Allocation']: FundAllocationTitleValues;
  ['Your Details']: MissingPersonalDetails['missingPersonalDataFields'];
  ['Select Retirement Age']: undefined;
  ['Employment Status']: undefined;
  ['Pension Wise Valid Appointment Past']: undefined;
  ['Booking Appointment']: undefined;
  ['Wait for your appointment']: undefined;
  ['Guidance - Not Returning Customer']: undefined;
  ['Guidance - No Valid Appointment']: undefined;
  ['Guidance - Valid Appointment']: {
    when: 'future' | 'past';
  };
  ['Review Application']: undefined;
  ['Submit Application']: { encryptedTransferId: string };
  ['Success']: undefined;
};

export type SIPPStackScreenNames = keyof SIPPStackRouteParams;

const Stack = createNativeStackNavigator<SIPPStackRouteParams>();

export const SIPPStack = () => {
  const tokens = getTokens();

  return (
    <SIPPProvider>
      <Stack.Navigator
        initialRouteName="Before You Start"
        screenOptions={{
          headerShown: true,
          header: TopAppBarDW,
          title: 'SIPP Transfer',
        }}
      >
        <Stack.Group
          screenOptions={{
            header: SIPPHeader,
            contentStyle: {
              backgroundColor: getVariableValue(tokens.color.White),
            },
          }}
        >
          <Stack.Screen
            name="Reasons to Transfer"
            getComponent={() =>
              require('../stronger-nudge/reasons-you-are-transfering/reasons-you-are-transferring-screen')
                .ReasonsYouAreTransferringScreen
            }
          />

          <Stack.Screen
            name="Sipp Onboarding Carousel"
            getComponent={() =>
              require('../onboarding/onboarding-carousel/onboarding-carousel')
                .SippOnboardingScreen
            }
            options={{ headerShown: false }}
          />
          <Stack.Screen
            name="Employment Details - Employed"
            getComponent={() =>
              require('../employment/employment-details/employed/employed-screen')
                .EmployedScreen
            }
          />
          <Stack.Screen
            name="Employment Details - Self Employed"
            getComponent={() =>
              require('../employment/employment-details/self-employed/self-employed-screen')
                .SelfEmployedScreen
            }
          />
          <Stack.Screen
            name="Employment Details - Retired"
            getComponent={() =>
              require('../employment/employment-details/retired/retired-screen')
                .RetiredScreen
            }
          />
          <Stack.Screen
            name="Employment Details - Not In Work"
            getComponent={() =>
              require('../employment/employment-details/not-in-work/not-in-work-screen')
                .NotInWorkScreen
            }
          />

          <Stack.Screen
            name="Add Pension"
            getComponent={() =>
              require('../pensions/add-pension/add-pension-screen')
                .AddPensionScreen
            }
          />
          <Stack.Screen
            name="Edit Pension"
            getComponent={() =>
              require('../pensions/edit-pension/edit-pension-screen')
                .EditPensionScreen
            }
          />
          <Stack.Screen
            name="Review Pensions"
            getComponent={() =>
              require('../pensions/review-pensions/review-pensions-screen')
                .ReviewPensionsScreen
            }
          />
          <Stack.Screen
            name="Investment Selection"
            getComponent={() =>
              require('../funds/investment-selection/investment-selection-screen')
                .InvestmentSelection
            }
          />
          <Stack.Screen
            name="Fund Details"
            getComponent={() =>
              require('../funds/fund-details/fund-details-screen/fund-details-screen')
                .FundDetails
            }
          />
          <Stack.Screen
            name="Employment Status"
            getComponent={() =>
              require('../employment/employment-status/employment-status-screen')
                .EmploymentStatusScreen
            }
          />
          <Stack.Screen
            name="Risk Selection"
            getComponent={() =>
              require('../funds/risk-selection/risk-selection-screen')
                .RiskSelection
            }
          />
          <Stack.Screen
            name="Fund Allocation Details"
            getComponent={() =>
              require('../funds/fund-allocation-details/fund-allocation-details-screen')
                .FundAllocationDetailsScreen
            }
          />
          <Stack.Screen
            name="Fund Allocation"
            getComponent={() =>
              require('../funds/fund-allocation/fund-allocation-screen')
                .FundAllocationScreen
            }
          />
          <Stack.Screen
            name="Your Details"
            getComponent={() =>
              require('../your-details/your-details-screen').YourDetailsScreen
            }
          />
          <Stack.Screen
            name="Booking Appointment"
            getComponent={() =>
              require('../stronger-nudge/booking/booking-appointment-screen')
                .BookingAppointmentScreen
            }
          />
          <Stack.Screen
            name="Wait for your appointment"
            getComponent={() =>
              require('../stronger-nudge/guidance/wait-for-your-appointment/wait-for-your-appointment-screen')
                .WaitForYourAppointmentScreen
            }
          />
          <Stack.Screen
            name="Guidance - Not Returning Customer"
            getComponent={() =>
              require('../stronger-nudge/guidance').NotReturningCustomerScreen
            }
          />
          <Stack.Screen
            name="Guidance - No Valid Appointment"
            getComponent={() =>
              require('../stronger-nudge/guidance').NoValidAppointmentScreen
            }
          />
          <Stack.Screen
            name="Guidance - Valid Appointment"
            getComponent={() =>
              require('../stronger-nudge/guidance').ValidAppointmentScreen
            }
            initialParams={{
              when: 'past',
            }}
          />
          <Stack.Screen
            name="Review Application"
            getComponent={() =>
              require('../review-and-submit/review-application/review-application-screen')
                .ReviewApplicationScreen
            }
          />
          <Stack.Screen
            name="Submit Application"
            getComponent={() =>
              require('../review-and-submit/submit/sipp-transfer-submit-screen')
                .SIPPTransferSubmitScreen
            }
          />
          <Stack.Screen
            name="Select Retirement Age"
            getComponent={() =>
              require('../funds/select-retirement-age/select-retirement-age-screen')
                .SelectRetirementAgeScreen
            }
          />
          <Stack.Screen
            name="Before You Start"
            getComponent={() =>
              require('../onboarding/before-you-start/before-you-start-screen')
                .BeforeYouStartScreen
            }
          />
          <Stack.Screen
            name="Ready To Transfer"
            options={{
              contentStyle: {
                backgroundColor: getVariableValue(tokens.color.White),
              },
            }}
            getComponent={() =>
              require('../onboarding/ready-to-transfer/ready-to-transfer-screen')
                .ReadyToTransferScreen
            }
          />
          <Stack.Screen
            name="About SIPP Transfer"
            getComponent={() =>
              require('../onboarding/about-sipp-transfer/about-sipp-transfer')
                .AboutSippTransferScreen
            }
          />
          <Stack.Screen
            name="Continue Without Advice"
            getComponent={() =>
              require('../stronger-nudge/no-advice/continue-without-advice-screen')
                .ContinueWithoutAdviceScreen
            }
          />
        </Stack.Group>
        <Stack.Screen
          name="Web View"
          getComponent={() =>
            require('@direct-wealth/common/utils/external-webview')
              .ExternalWebview
          }
          options={{
            headerShown: true,
            header: AvivaWebViewTopAppBar,
          }}
        />
        <Stack.Screen
          name="Success"
          getComponent={() =>
            require('@direct-wealth/features/sipp-transfer/review-and-submit/success/sipp-transfer-success-screen')
              .SIPPTransferSuccessScreen
          }
          options={{
            headerShown: false,
            header: undefined,
          }}
        />
      </Stack.Navigator>
    </SIPPProvider>
  );
};
