import { useMemo } from 'react';

import { getAge } from '../funds/select-retirement-age/utils';
import { useSIPP } from '../navigation/provider';

const Steps = [
  'Pre-transfer checks',
  'Pensions to transfer',
  'Select your investments',
  'Your details',
  'Review application',
  'Final details',
];

export const useStepperValues = (step: number) => {
  const max = useMaxSteps();
  const steppedLabel = Steps[step - 1];
  const currentStep = max === 6 ? step : step - 1;

  return {
    currentStep,
    max,
    steppedLabel,
    boldLabel: `Step ${currentStep} of ${max}`,
  };
};

export const useMaxSteps = () => {
  const sippState = useSIPP();
  const dateOfBirth = sippState.personalDetails?.dateOfBirth?.get();
  const isUserAboveFifty = useMemo(
    () => (dateOfBirth ? getAge({ dateOfBirth }) : 0) >= 50,
    [dateOfBirth]
  );
  return isUserAboveFifty ? 6 : 5;
};
