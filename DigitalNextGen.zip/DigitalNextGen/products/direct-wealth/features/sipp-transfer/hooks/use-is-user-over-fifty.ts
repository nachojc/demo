import { getAge } from '../funds/select-retirement-age/utils';
import { useSIPP } from '../navigation/provider';

export const useIsUserOverFifty = () => {
  const sippState = useSIPP();
  const dateOfBirth = sippState.personalDetails?.dateOfBirth?.get();
  return (dateOfBirth ? getAge({ dateOfBirth }) : 0) >= 50;
};
