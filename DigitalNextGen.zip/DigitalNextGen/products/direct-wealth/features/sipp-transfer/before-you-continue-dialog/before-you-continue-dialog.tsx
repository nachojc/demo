import {
  Button,
  ButtonVariant,
  Dialog,
  getVariableValue,
  Icon,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useTrackStateEvent } from '@hooks/use-analytics';
import { config } from '@src/common/config';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { useCallback } from 'react';

import { WORKPLACE_WARNING } from './analytics';
import { useBeforeYouContinueDialogAnalytics } from './hooks/use-before-you-continue-dialog-analytics';

type BeforeYouContinueDialogProps = {
  isVisible: boolean;
  onClose: () => void;
  onContinuePress: () => void;
};

export const BeforeYouContinueDialog = ({
  isVisible,
  onClose,
  onContinuePress,
}: BeforeYouContinueDialogProps) => {
  const {
    sendWorkplaceWarningCancelTapped,
    sendWorkplaceWarningContinueTapped,
    sendWorkplaceWarningGoToWebsiteTapped,
  } = useBeforeYouContinueDialogAnalytics();

  useTrackStateEvent(WORKPLACE_WARNING);

  const { t } = useTranslationDW({
    keyPrefix: 'sippTransfer.beforeYouContinueDialog',
  });

  const { navigate } = useAppStackNavigation();

  const handleContinue = useCallback(() => {
    sendWorkplaceWarningContinueTapped();
    onContinuePress();
  }, [sendWorkplaceWarningContinueTapped, onContinuePress]);

  const handleGoToWebView = useCallback(() => {
    sendWorkplaceWarningGoToWebsiteTapped();
    onClose();
    navigate('Web View', {
      url: config.BASE_URL.get() + '/MyPortfolio',
      ssoEnabled: true,
    });
  }, [onClose, sendWorkplaceWarningGoToWebsiteTapped, navigate]);

  const handleCancel = useCallback(() => {
    sendWorkplaceWarningCancelTapped();
    onClose();
  }, [onClose, sendWorkplaceWarningCancelTapped]);

  return (
    <Dialog
      open={isVisible}
      title={t('heading')}
      copy={t('subheading')}
      center
      icon={
        <Icon
          color={getVariableValue(tokens.color.Information)}
          height={getVariableValue(tokens.size[6])}
          name="info"
          width={getVariableValue(tokens.size[6])}
        />
      }
    >
      <YStack mt="$xl" gap="$md">
        <Button
          variant={ButtonVariant.BRAND}
          onPress={handleContinue}
          accessibilityLabel={t('continue')}
          testID={getTestId('continue-button')}
        >
          {t('continue')}
        </Button>
        <Button
          variant={ButtonVariant.OUTLINED}
          onPress={handleGoToWebView}
          accessibilityLabel={t('goToOurWebsite')}
          accessibilityHint={t('goToOurWebsiteHint')}
          testID={getTestId('go-to-our-website-button')}
          useStyledButtonText={false}
        >
          <Icon
            color={getVariableValue(tokens.color.Secondary800)}
            height={getVariableValue(tokens.size[6])}
            name="external-link"
            width={getVariableValue(tokens.size[6])}
          />
          <Text
            fontVariant={'body-semibold-Secondary800'}
            tamaguiTextProps={{ marginLeft: '$md' }}
          >
            {t('goToOurWebsite')}
          </Text>
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={handleCancel}
          accessibilityLabel={t('cancel')}
          accessibilityHint={t('cancelHint')}
          testID={getTestId('cancel-button')}
        >
          {t('cancel')}
        </Button>
      </YStack>
    </Dialog>
  );
};
