import {
  Button,
  ButtonVariant,
  Dialog,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { useIsDPA2Unlocked } from '@hooks/use-is-dpa2-unlocked';
import { useSelector } from '@legendapp/state/react';
import { config } from '@src/common/config';
import { FeatureFlags } from '@src/feature-flags';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';

import {
  FIND_PENSION_DIALOG,
  FIND_PENSION_DIALOG_CANCEL_TAPPED,
  FIND_PENSION_DPA2_LOCKED,
  FIND_PENSION_DPA2_UNLOCKED,
} from './analytics';

type FindPensionDialog = {
  isVisible: boolean;
  onClosePress: () => void;
};

export const FindPensionDialog = ({
  isVisible,
  onClosePress,
}: FindPensionDialog) => {
  const { trackUserEvent } = useAnalytics();

  const { t } = useTranslation(undefined, {
    keyPrefix: 'sipp.findPensionDialog',
  });

  useTrackStateEvent(FIND_PENSION_DIALOG);

  const { navigate } = useAppStackNavigation();

  const userIsDPA2Unlocked = useIsDPA2Unlocked();

  const dwFindAndCombineEnabled = useSelector(
    FeatureFlags.dwFindAndCombineEnabled
  );

  const handleFindYourPensionDetailsPress = useCallback(() => {
    onClosePress();

    if (userIsDPA2Unlocked && dwFindAndCombineEnabled) {
      trackUserEvent(FIND_PENSION_DPA2_UNLOCKED);

      navigate('Find And Combine', { screen: 'Landing' });
    } else {
      trackUserEvent(FIND_PENSION_DPA2_LOCKED);

      navigate('Web View', {
        url:
          config.AVIVA_BASE_URL.get() +
          '/retirement/pensions/find-and-combine/',
      });
    }
  }, [
    userIsDPA2Unlocked,
    trackUserEvent,
    navigate,
    onClosePress,
    dwFindAndCombineEnabled,
  ]);

  const handleCancelPress = () => {
    onClosePress();
    trackUserEvent(FIND_PENSION_DIALOG_CANCEL_TAPPED);
  };

  return (
    <Dialog center open={isVisible} title={t('title')} copy={t('description')}>
      <YStack marginTop="$xl" gap="$md">
        <Button
          variant={ButtonVariant.BRAND}
          onPress={handleFindYourPensionDetailsPress}
          accessibilityHint={t('findPensionCTAAccessibilityHint')}
          accessibilityLabel={t('findPensionCTAAccessibilityLabel')}
        >
          <XStack pt="$md" gap="$md">
            <Text fontVariant={'body-semibold-Secondary800'}>
              {t('findPensionCTA')}
            </Text>
          </XStack>
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={handleCancelPress}
          accessibilityHint={t('cancelCTAAccessibility')}
        >
          {t('cancelCTA')}
        </Button>
      </YStack>
    </Dialog>
  );
};
