import { PAGE_WEALTH } from '@constants/analytics';

export const FIND_PENSION_DIALOG = `${PAGE_WEALTH}|sipp-transfer|find-pension-dialog`;
export const FIND_PENSION_DIALOG_CANCEL_TAPPED = `${FIND_PENSION_DIALOG}|cancel-tapped`;
export const FIND_PENSION_DPA2_UNLOCKED = `${FIND_PENSION_DIALOG}|find-pension-tapped`;
export const FIND_PENSION_DPA2_LOCKED = `${FIND_PENSION_DIALOG}|web-idv`;
