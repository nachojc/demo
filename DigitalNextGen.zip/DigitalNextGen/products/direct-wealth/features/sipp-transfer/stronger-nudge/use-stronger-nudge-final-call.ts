import { useDirectWealthServicePutApiV1DirectWealthStrongerNudge } from '@src/api/generated/queries';
import { Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_StrongerNudge_Model_StrongerNudgeRequestModel } from '@src/api/generated/requests';
import { useCallback } from 'react';

import { getAge } from '../funds/select-retirement-age/utils';
import { useSIPP } from '../navigation/provider';
import { useStrongerNudgeSubmissionData } from '../navigation/provider/state/hooks/use-stronger-nudge-submission-data';
import { ReasonForOptOut } from '../navigation/provider/state/stronger-nudge';

export const useStrongerNudgeFinalCall = () => {
  const { mutate, ...rest } =
    useDirectWealthServicePutApiV1DirectWealthStrongerNudge();
  const sippState = useSIPP();
  const strongerNudgeSubmissionData = useStrongerNudgeSubmissionData();
  const isNewCustomer = !sippState.userDetails.securePolicyNumber?.get();
  const dateOfBirth = sippState.personalDetails?.dateOfBirth?.get();
  const userOverFifty = (dateOfBirth ? getAge({ dateOfBirth }) : 0) >= 50;
  const securePolicyNumber = sippState.userDetails.securePolicyNumber?.get();
  const appointmentDateTime =
    sippState.strongerNudge.appointmentDateTime?.get() || undefined;
  const previousOutcome = sippState.strongerNudge.previousOutcome?.get();

  const submitStrongerNudgeData = useCallback(
    (
      submissionData: Aviva_Digital_MobileApi_Endpoints_DirectWealth_V1_StrongerNudge_Model_StrongerNudgeRequestModel,
      policyNumber?: string
    ) => {
      if (policyNumber && userOverFifty) {
        mutate({
          securePolicyNumber: policyNumber,
          requestBody: submissionData,
        });
      }
    },
    [mutate, userOverFifty]
  );

  const userReceivedGuidance = () => {
    if (isNewCustomer) {
      sippState.strongerNudge.guidanceReceived?.set(true);
      sippState.strongerNudge.reasonForOptOutOption?.delete();
      sippState.strongerNudge.otherReason?.delete();
    } else {
      submitStrongerNudgeData(
        {
          guidanceReceived: true,
          appointmentDateTime,
          previousOutcome,
        },
        securePolicyNumber
      );
    }
  };

  const userOptedOut = (
    reasonForOptOutOption?: ReasonForOptOut,
    otherReason?: string
  ) => {
    if (isNewCustomer) {
      sippState.strongerNudge.guidanceReceived?.set(false);
      sippState.strongerNudge.reasonForOptOutOption?.set(reasonForOptOutOption);
      sippState.strongerNudge.otherReason?.set(otherReason);
    } else {
      submitStrongerNudgeData(
        {
          guidanceReceived: false,
          reasonForOptOutOption,
          otherReason,
          appointmentDateTime,
          previousOutcome,
        },
        securePolicyNumber
      );
    }
  };

  const finalCall = useCallback(
    (policyNumber?: string) => {
      if (policyNumber) {
        submitStrongerNudgeData(strongerNudgeSubmissionData, policyNumber);
      }
    },
    [strongerNudgeSubmissionData, submitStrongerNudgeData]
  );

  return {
    finalCall,
    userReceivedGuidance,
    userOptedOut,
    ...rest,
  };
};
