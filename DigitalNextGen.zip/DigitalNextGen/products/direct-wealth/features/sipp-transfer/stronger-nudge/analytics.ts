import { PAGE_WEALTH_SIPP_TRANSFER } from '../analytics';

export const PAGE_WEALTH_SIPP_TRANSFER_STRONGER_NUDGE = `${PAGE_WEALTH_SIPP_TRANSFER}|stronger-nudge`;
