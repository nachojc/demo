export const Constants = {
  STEP_1_OF_6: 'Step 1 of 6',
  HEADER_TITLE: 'Why are you transferring your pension?',
  HEADER_SUBTITLE:
    "Tell us why you're transferring to an Aviva Self-Invested Personal Pension.",
  STATEMENT_TITLE: 'Which statement best suits you?',
  STATEMENT_ENJOY_PLAN_BENEFITS:
    "I am wanting to enjoy my plan benefits such as buying an annuity (income for life), commencing income drawdown, or withdrawing money from my pension pot. After careful consideration, this is the option I'd like to take.",
  STATEMENT_UNDECIDED:
    "I am undecided as to how I'll enjoy my plan benefits or I'm transferring for another reason such as consolidating my pension pots, lower charges and different investment choices.",
  PLEASE_SELECT_AN_OPTION: 'Please select an option.',
  BUTTON_CONTINUE: 'Continue',
  GUIDANCE_HEADING: 'Get guidance on your choice with Pension Wise',
  GUIDANCE_DIALOG_COPY:
    'That’s great! It’s good to know you’ve received guidance from Pension Wise. If your personal circumstances or the value of your pension plans have changed significantly, you may benefit from receiving guidance again.',
  NO_VALID_APPOINTMENT_QUESTION:
    'You told us previously that you would book an appointment for free guidance with Pension Wise.\n\nDid you attend an appointment?',
  GUIDANCE_NOT_RETURNING_QUESTION:
    'Have you received guidance from Pension Wise?',
  VALID_APPOINTMENT_IN_THE_PAST:
    'We can see that an appointment was booked with Pension Wise for you on:',
  VALID_APPOINTMENT_IN_THE_FUTURE:
    'Pension Wise guidance: Your appointment was booked for:',
  ATTEND_APPOINTMENT_QUESTION_PAST: 'Did you attend an appointment?',
  ATTEND_APPOINTMENT_QUESTION_FUTURE:
    'Have you rearranged and attended an appointment earlier than this?',
  ATTEND_OTHER_APPOINTMENT_QUESTION:
    'Have you attended any other Pension Wise guidance appointments?',
  WAITING_DIALOG_COPY:
    "Great, we're pleased you've chosen to wait until you’ve had your appointment.",
  WAITING_DIALOG_ADVICE:
    'After your appointment please come back and continue with your pension transfer.',
  WAITING_HEADER: 'Wait for your appointment with Pension Wise',
  APPOINTMENT_DATE: 'Appointment date',
  REQUIRED: 'Required',
};

export const ConstantsPWCantProceed = {
  PW_INFO:
    'Pension Wise provides free and impartial guidance. They can help you make an informed decision about what to do with your pension savings, discuss your different pension options, and help you understand what your overall financial situation will be when you retire.',
  ADVICE:
    'Alternatively, you could obtain advice from an FCA regulated financial adviser who can provide advice suitable to your own personal circumstances. An adviser will charge for this service.',
  UNABLE_TO_PROCEED:
    "We're unable to proceed with your request until you confirm you've received Pension Wise guidance or financial advice, or opt out from both.",
};

export const ConstantsPWUnableProceed = {
  PW_INFO:
    'We can see that the Pension Wise appointment date we booked for you has not yet passed. Remember, Pension Wise provide free and impartial guidance. They can help you make an informed decision about what to do with your pension savings, discuss your different pension options, and help you understand what your overall financial situation will be when you retire.',
  ADVICE:
    'We therefore encourage you to keep the appointment, or make an alternative appointment with them, rather than complete your transfer without receiving guidance.',
  UNABLE_TO_PROCEED:
    "We're unable to proceed with your request until you confirm you've received Pension Wise guidance or financial advice, or opt out from both.",
};

export const ConstantsPWProceed = {
  PENSION_WISE: 'Pension Wise',
  ENCOURAGE: 'We encourage you to get some ',
  GUIDANCE: 'free specialist guidance',
  FROM: ' from',
  SERVICE:
    ' is a government-backed service from MoneyHelper with a range of appointments to suit you, either face to face or over the phone. With ',
  SERVICE_MORE:
    ', you’ll be speaking to an independent pension specialist, who will discuss your different pension options and the other things you need to think about. They’ll also explain how each option is taxed and provide information about how to look out for pension scams.',
  ADVICE:
    'You can also obtain advice from a regulated financial adviser who can provide advice suitable to your own personal circumstances.  An adviser will charge for this service.',
  VISIT_UNBIASED: 'You can {{website}}.',
  VISIT_UNBIASED_LINK:
    'visit Unbiased to find an independent financial adviser near you',
  VISIT_UNBIASED_LINK_HINT: 'Opens website',
} as const;

export const ConstantsReasonsYouAreTransferring = {
  PENSIONS_TO_TRANSFER: 'Pre-transfer checks',
  STEP_1_OF_6: 'Step 1 of 6',
  HEADER_TITLE: 'Reason you are transferring',
  HEADER_SUBTITLE_1:
    'If you’re planning to take an income from your pension right away or make cash withdrawals, it’s important we tell you about',
  HEADER_SUBTITLE_2:
    'from MoneyHelper. This is a government-backed service that provides free, specialised and impartial guidance to help you make an informed decision about what to do with your pension savings.',
  PENSION_WISE: 'Pension Wise',
  OPTION_TITLE:
    'Once you’ve transferred your pension, do you plan to start taking money from it right away?',
  DIALOG_TITLE: 'Progress will not be saved',
  DIALOG_SUBTITLE:
    'Please note that by exiting the SIPP transfer at any stage, your progress will not be stored and you will have to start again.',
  YES_UNDERSTAND: 'Yes, I understand',
  CANCEL: 'Cancel',
  BUTTON_CONTINUE: 'Continue',
  REQUIRED: 'Required',
};

export const BookingAppointment = {
  HEADING: 'You’re booking an appointment with\nPension Wise',
  SUB_HEADING: 'We’re pleased you’ve chosen to get\nfurther guidance',
  TO_BOOK_APPOINTMENT: 'To book an appointment with Pension Wise you can:',
  BOOK_FREE_APPOINTMENT: 'Call Pension Wise to book your appointment',
  CALL_US: 'Call us and we’ll book an appointment for you',
  VISIT_MONEY_HELPER: 'Alternatively you can {{website}}.',
  VISIT_MONEY_HELPER_LINK: 'visit Money Helper to book an appointment',
  VISIT_MONEY_HELPER_LINK_HINT: 'Opens website',
  FOR_PROTECTION:
    'For our joint protection, telephone calls may be recorded or monitored.',
  OBTAIN_ADVICE: `You can also obtain advice from a regulated financial adviser who can provide advice suitable to your own personal circumstances.  An adviser will charge for this service.`,
  VISIT_UNBIASED: 'You can {{website}}.',
  VISIT_UNBIASED_LINK:
    'visit Unbiased to find an independent financial adviser near you',
  VISIT_UNBIASED_LINK_HINT: 'Opens website',
  COME_BACK:
    'After your appointment please come back and continue with your pension transfer.',
  CALL_PENSION_WISE: 'Call Pension Wise',
  BACK_TO_PORTFOLIO: 'Back to your portfolio',
  VISIT_PAGE: '{{website}}',
  VISIT_PAGE_LINK: 'Visit our contact information page',
  VISIT_PAGE_LINK_HINT: 'Opens website',
  DAY: 'Monday - Friday',
  TIME: '8:00am - 6:00pm',
} as const;

export const ContinueWithoutAdvice = {
  HEADING: 'Continue without speaking to Pension Wise or taking advice',
  SCROLL_ACC_LABEL: 'Continue Without Advice Screen',
  NOTIFICATION_TITLE:
    "You're choosing to go ahead without taking any financial advice or guidance.",
  NOTIFICATION_SUBTITLE:
    "This isn't something we would recommend - Pension Wise guidance is free and impartial.",
  SUBTITLE: 'Which statement best suits you?',

  NO_TIME_SUBTITLE:
    "I don't have time to wait / I’m not willing to wait / inconvenient appointment time",

  ALREADY_KNOW_SUBTITLE:
    'I feel I already have a good understanding / knowledge',

  NO_BENEFIT_SUBTITLE:
    "I don't see any benefit to me in getting guidance or advice",

  OTHER_SUBTITLE: 'Other',
  OTHER_REASON_TITLE: 'Please enter reason (max 50 chars.)',
  OTHER_ERROR_DESCRIPTION: 'Please enter a reason to continue',
};

export const UnableToProceed = {
  BUTTON_WAIT: 'Wait for my appointment',
  BUTTON_REARANGE: 'Rearrange my appointment',
  BUTTON_BOOK: 'I want to book a session',
  BUTTON_CONTINUE: 'Continue without advice or guidance',
};
