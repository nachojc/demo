import {
  Button,
  getTokens,
  IconText,
  RadioCard,
  RadioGroup,
  ScrollView,
  Separator as TamaguiSeparator,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { AccessibleHeader } from '@direct-wealth/components/accessible-header';
import { isIpad } from '@src/utils/is-ipad';
import { useState } from 'react';

import { Constants } from './stronger-nudge-constants';

type SelectedOptions = 'enjoyBenifits' | 'undecided';

const Separator = () => {
  return (
    <TamaguiSeparator width="100%" borderColor="$Gray200" my="$xxl" mx="$xl" />
  );
};

export const StrongerNudgeView = () => {
  const {
    HEADER_TITLE,
    HEADER_SUBTITLE,
    STATEMENT_TITLE,
    STATEMENT_ENJOY_PLAN_BENEFITS,
    STATEMENT_UNDECIDED,
    BUTTON_CONTINUE,
    PLEASE_SELECT_AN_OPTION,
  } = Constants;

  const tokens = getTokens();
  const [showError, setShowError] = useState(false);
  const [selected, setSelected] = useState<SelectedOptions>();

  const continueHandler = () => {
    if (!selected) {
      setShowError(true);
    }
  };

  const selectCard = (option: SelectedOptions) => {
    setShowError(false);
    setSelected(option);
  };

  return (
    <ScrollView
      contentContainerStyle={{ flexGrow: 1 }}
      accessibilityLabel="Stronger Nudge Screen"
      bc={'$White'}
    >
      <YStack tablet={isIpad}>
        <AccessibleHeader
          heading={HEADER_TITLE}
          subHeading={HEADER_SUBTITLE}
          step={1}
        />
        <Separator />
        <YStack marginHorizontal="$xl" marginBottom="$xl">
          <YStack marginBottom="$lg">
            <Text fontVariant={'heading4-regular-Gray800'}>
              {STATEMENT_TITLE}
            </Text>
          </YStack>
          <RadioGroup accessibilityLabel={HEADER_TITLE} a11yOpts={{ total: 2 }}>
            <RadioCard
              a11yOpts={{ item: 1, total: 2 }}
              accessibilityLabel="Enjoy plan benefits"
              subtitleContainerProps={{ paddingTop: 0 }}
              subtitle={STATEMENT_ENJOY_PLAN_BENEFITS}
              error={showError}
              selected={selected === 'enjoyBenifits'}
              onPress={() => selectCard('enjoyBenifits')}
            />
            <YStack marginBottom="$xl" />
            <RadioCard
              a11yOpts={{ item: 2, total: 2 }}
              accessibilityLabel="undecided"
              subtitleContainerProps={{ paddingTop: 0 }}
              subtitle={STATEMENT_UNDECIDED}
              error={showError}
              selected={selected === 'undecided'}
              onPress={() => selectCard('undecided')}
            />
          </RadioGroup>
          {showError && (
            <IconText
              description={PLEASE_SELECT_AN_OPTION}
              iconName="alert-circle"
              iconSizeOption="xlarge"
              fontVariant="body-regular-Error"
              iconColor={tokens.color.Error.val}
            />
          )}
          <YStack marginBottom="$xxl" />
          <YStack marginTop="$md">
            <Button onPress={continueHandler}>{BUTTON_CONTINUE}</Button>
          </YStack>
        </YStack>
      </YStack>
    </ScrollView>
  );
};

export const StrongerNudgeScreen = () => <StrongerNudgeView />;
