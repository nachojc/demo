import {
  AddressForm,
  AddressFormSchema,
} from '@aviva/ion-mobile/components/address-input/address-form';
import {
  YourDetailsForm,
  YourDetailsFormSchema,
} from '@direct-wealth/validation/schemas/sipp-transfer/your-details';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import { useForm } from 'react-hook-form';

import { useSIPPStackNavigation } from '../navigation/hooks';
import { useSIPP } from '../navigation/provider';
import {
  PERSONAL_DETAILS_CONTINUE,
  PERSONAL_DETAILS_POSTCODE_LOOKUP,
} from './analytics';

type DefaultValues = {
  addressLine1?: string;
  addressLine2?: string;
  addressLine3?: string;
  postalTownCity?: string;
  postcode?: string;
  nationality?: string;
  contactNumber?: string;
  nino?: string;
  title?: string;
  country?: string;
};

type FormSubmitData = {
  title: string;
  nationality: string;
  nationalInsuranceNumber: string;
  phoneNumber: {
    number: string;
    country: {
      code: string;
      name: string;
    };
  };
};

export const useYourDetailsViewModel = () => {
  const { personalDetails, dropdownValues } = useSIPP();
  const { navigate } = useSIPPStackNavigation();
  const analytics = useAnalytics();

  const nationalityValue = () => {
    const currentNationality = personalDetails.nationality?.get();
    if (currentNationality && currentNationality !== 'NotSpecified') {
      return currentNationality;
    }
    return undefined;
  };

  const isAddressMissing =
    personalDetails.missingRequiredFields?.get()?.missingPersonalDataFields
      .address;

  const addressLine1Value = personalDetails.addressLine1?.get() ?? undefined;
  const addressLine2Value = personalDetails.addressLine2?.get() ?? undefined;
  const addressLine3Value = personalDetails.addressLine3?.get() ?? undefined;
  const postalTownCityValue =
    personalDetails.postalTownCity?.get() ?? undefined;
  const postcodeValue = personalDetails.postcode?.get() ?? undefined;

  const defaultValues: DefaultValues = {
    addressLine1: isAddressMissing ? undefined : addressLine1Value,
    addressLine2: isAddressMissing ? undefined : addressLine2Value,
    addressLine3: isAddressMissing ? undefined : addressLine3Value,
    postalTownCity: isAddressMissing ? undefined : postalTownCityValue,
    postcode: isAddressMissing ? undefined : postcodeValue,
    nationality: nationalityValue(),
    contactNumber: personalDetails.contactNumber?.get() ?? undefined,
    nino: personalDetails.nino?.get() ?? undefined,
    title: personalDetails.title?.get() ?? undefined,
    country: personalDetails.country?.get() ?? undefined,
  };

  const DEFAULT_VALID_NINO = 'AA123456A';
  const DEFAULT_VALID_CONTACT = '07912345678';
  const DEFAULT_VALID_POSTCODE = 'N1 6NN';

  const countries = dropdownValues
    .get()
    .CountryCode?.map((value) => value.displayValue);
  // We hard code a valid default value for nino and contact number if a prepop value exists.
  // This is due to rare occasions where prepop values do not meet our validation.
  // On Submission the prepop value is used.
  const form = useForm<YourDetailsForm>({
    resolver: zodResolver(YourDetailsFormSchema),
    mode: 'onChange',
    defaultValues: {
      title: defaultValues.title,
      nationalInsuranceNumber: defaultValues.nino
        ? DEFAULT_VALID_NINO
        : undefined,
      nationality: defaultValues.nationality,
      phoneNumber: {
        number: defaultValues.contactNumber ? DEFAULT_VALID_CONTACT : undefined,
        country: {
          code: personalDetails.contactNumberCode?.get()?.code ?? '+44',
          name:
            personalDetails.contactNumberCode?.get()?.code ?? 'United Kingdom',
        },
      },
    },
  });

  const addressForm = useForm<AddressForm>({
    resolver: zodResolver(AddressFormSchema),
    mode: 'onChange',
    defaultValues: {
      addressLine1: defaultValues.addressLine1,
      addressLine2: defaultValues.addressLine2,
      addressLine3: defaultValues.addressLine3,
      postalTownCity: defaultValues.postalTownCity,
      postcode: defaultValues.postcode ? DEFAULT_VALID_POSTCODE : undefined,
    },
  });

  const onFormSubmit = (data: FormSubmitData) => {
    analytics.trackUserEvent(PERSONAL_DETAILS_CONTINUE);

    const ninoValue = defaultValues.nino
      ? defaultValues.nino
      : data.nationalInsuranceNumber;

    const contactNumberValue = defaultValues.contactNumber
      ? defaultValues.contactNumber
      : data.phoneNumber.number;

    const countryValue = defaultValues.country ?? 'GBR';

    const address = addressForm.getValues();

    const postcodeUpdatedValue = defaultValues.postcode
      ? defaultValues.postcode
      : address.postcode;

    personalDetails.addressLine1?.set(address.addressLine1);
    personalDetails.addressLine2?.set(address.addressLine2);
    personalDetails.addressLine3?.set(address.addressLine3);
    personalDetails.postalTownCity?.set(address.postalTownCity);
    personalDetails.postcode?.set(postcodeUpdatedValue);
    personalDetails.title?.set(data.title);
    personalDetails.nino?.set(ninoValue);
    personalDetails.nationality?.set(data.nationality);
    personalDetails.contactNumber?.set(contactNumberValue);
    personalDetails.contactNumberCode?.set({
      code: data.phoneNumber.country.code,
      name: data.phoneNumber.country.name,
    });
    personalDetails.country?.set(countryValue);
    navigate('Employment Status');
  };

  const defaultOnScreenDetails = {
    firstName: personalDetails.firstName?.get(),
    lastName: personalDetails.lastName?.get(),
    nino: personalDetails.nino?.get(),
  };

  const sendPostcodeSearchTappedAnalytics = () => {
    analytics.trackUserEvent(PERSONAL_DETAILS_POSTCODE_LOOKUP);
  };

  return {
    form,
    countries,
    addressForm,
    onFormSubmit,
    defaultOnScreenDetails,
    sendPostcodeSearchTappedAnalytics,
  };
};
