// this will be completed as part of MANGA-5561
import {
  Button,
  Dropdown,
  Stack,
  Text,
  TextInput,
  YStack,
} from '@aviva/ion-mobile';
import { FocusKeyboardAvoidingView } from '@aviva/ion-mobile/components/focus-keyboard-avoiding-view/focus-keyboard-avoiding-view';
import { AddressInput } from '@direct-wealth/components/address-input/address-input';
import { InputField } from '@direct-wealth/components/input-field';
import { SippScrollView } from '@direct-wealth/components/sipp-scroll-view/sipp-scroll-view';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { PhoneNumberInput } from '@src/components/forms/phone-number-input/phone-number-input';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect } from 'react';
import { Controller } from 'react-hook-form';

import { SIPPStackRouteParams } from '../navigation';
import { PERSONAL_DETAILS_ADDRESS, PERSONAL_DETAILS_SCREEN } from './analytics';
import { YourDetailsConstants } from './constants';
import { useYourDetailsViewModel } from './use-your-details-view-model';

const {
  HEADING,
  SUBHEADING,
  NI_NUMBER,
  ENTER_YOUR_NI_NUMBER,
  NI_NUMBER_ERROR,
  NATIONALITY,
  NATIONALITY_PLEASE_SELECT,
  TITLE_PLACEHOLDER,
  FIRST_NAME,
  LAST_NAME,
  CONTINUE,
} = YourDetailsConstants;

export type YourDetailsScreenProps = NativeStackScreenProps<
  SIPPStackRouteParams,
  'Your Details'
>;

type YourDetailViewProps = {
  route: YourDetailsScreenProps['route'];
  model: ReturnType<typeof useYourDetailsViewModel>;
};

const DefaultDetail = ({ title, value }: { title: string; value: string }) => {
  return (
    <YStack tablet={isIpad} mb="$xxl">
      <Text fontVariant="body-semibold-Secondary800">{title}</Text>
      <Text fontVariant="body-regular-Gray800">{value}</Text>
    </YStack>
  );
};

export const YourDetailsView = ({ model, route }: YourDetailViewProps) => {
  const {
    form,
    addressForm,
    onFormSubmit,
    defaultOnScreenDetails,
    countries,
    sendPostcodeSearchTappedAnalytics,
  } = model;

  const {
    control,
    formState: { isValid },
    handleSubmit,
  } = form;

  const {
    formState: { isValid: isValidAddress },
  } = addressForm;

  const {
    title: showTitle,
    nino: showNino,
    nationality: showNationality,
    contactNumber: showPhone,
    address: showAddress,
  } = route.params;

  useOnPageLoad({ pageTag: PERSONAL_DETAILS_SCREEN });

  useEffect(() => {
    if (!showAddress) {
      addressForm.trigger();
    }
  }, [addressForm, showAddress]);

  return (
    <>
      <FocusKeyboardAvoidingView>
        <SippScrollView heading={HEADING} subheading={SUBHEADING} step={4}>
          {defaultOnScreenDetails.firstName && (
            <DefaultDetail
              title={FIRST_NAME}
              value={defaultOnScreenDetails.firstName}
            />
          )}
          {defaultOnScreenDetails.lastName && (
            <DefaultDetail
              title={LAST_NAME}
              value={defaultOnScreenDetails.lastName}
            />
          )}

          {!showNino && defaultOnScreenDetails.nino && (
            <DefaultDetail
              title={NI_NUMBER}
              value={defaultOnScreenDetails.nino}
            />
          )}

          <YStack tablet={isIpad} flex={1} justifyContent="flex-start">
            {showTitle && (
              <Controller
                name="title"
                control={control}
                render={({ field: { onChange, value } }) => {
                  return (
                    <InputField
                      label={'Title'}
                      field={
                        <Dropdown
                          required
                          value={value}
                          onValueChange={onChange}
                          items={['Mr', 'Mrs', 'Miss', 'Ms']}
                          searchBar={false}
                          placeHolderText={TITLE_PLACEHOLDER}
                          testID={getTestId('Title Dropdown')}
                        />
                      }
                      withMargin
                    />
                  );
                }}
              />
            )}
            {showNino && (
              <Controller
                name="nationalInsuranceNumber"
                control={control}
                render={({ field: { onChange, value }, fieldState }) => {
                  return (
                    <InputField
                      label={NI_NUMBER}
                      field={
                        <TextInput
                          tamaguiInputProps={{
                            value,
                            onChangeText: onChange,
                            placeholder: ENTER_YOUR_NI_NUMBER,
                          }}
                          error={fieldState.invalid}
                          errorText={NI_NUMBER_ERROR}
                          testID={getTestId('ni-number-input')}
                        />
                      }
                      withMargin
                    />
                  );
                }}
              />
            )}

            {showNationality && (
              <Controller
                name="nationality"
                control={control}
                render={({ field: { onChange, value } }) => {
                  return (
                    <InputField
                      label={NATIONALITY}
                      field={
                        <Dropdown
                          required
                          value={value}
                          onValueChange={onChange}
                          items={countries || []}
                          searchBar={false}
                          placeHolderText={NATIONALITY_PLEASE_SELECT}
                        />
                      }
                      withMargin
                    />
                  );
                }}
              />
            )}

            {showPhone && (
              <Controller
                name="phoneNumber"
                control={control}
                render={({ field: { onChange, value }, fieldState }) => {
                  const { number, country } = value;
                  return (
                    <Stack marginBottom={'$xxl'}>
                      <PhoneNumberInput
                        countryCode={country}
                        number={number}
                        onChange={onChange}
                        error={fieldState.invalid}
                        errorText="Please enter a valid mobile number."
                        placeholder="Enter your phone number"
                        label="Your Phone Number:"
                      />
                    </Stack>
                  );
                }}
              />
            )}

            {showAddress && (
              <AddressInput
                form={addressForm}
                onPostcodeSearchTapped={sendPostcodeSearchTappedAnalytics}
                manualAddressLinkTag={PERSONAL_DETAILS_ADDRESS}
              />
            )}
          </YStack>

          <YStack tabletNarrow={isIpad}>
            <Button
              marginTop={'$xxxl'}
              onPress={handleSubmit(onFormSubmit)}
              accessibilityLabel="Continue Button"
              disabled={!isValid || !isValidAddress}
            >
              {CONTINUE}
            </Button>
          </YStack>
        </SippScrollView>
      </FocusKeyboardAvoidingView>
    </>
  );
};

export const YourDetailsScreen = ({ route }: YourDetailsScreenProps) => {
  const model = useYourDetailsViewModel();
  return <YourDetailsView model={model} route={route} />;
};
