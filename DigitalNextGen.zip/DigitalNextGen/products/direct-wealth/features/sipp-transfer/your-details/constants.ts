export const YourDetailsConstants = {
  NATIONALITY: 'Nationality',
  NATIONALITY_PLEASE_SELECT: 'Please select',
  HEADING: 'Your details',
  SUBHEADING:
    'We just need some additional information to confirm who you are.',
  NI_NUMBER: 'National Insurance Number',
  ENTER_YOUR_NI_NUMBER: 'Enter your National Insurance Number',
  NI_NUMBER_ERROR: 'Please enter a valid National Insurance Number',
  PHONE_NUMBER: 'Phone Number',
  ENTER_YOUR_PHONE_NUMBER: 'Enter Your Phone Number',
  ENTER_VALID_PHONE: 'Please enter a valid mobile number.',
  CONTINUE: 'Continue',
  TITLE_PLACEHOLDER: 'Please Select',
  FIRST_NAME: 'First name',
  LAST_NAME: 'Last name',
};
