import { PAGE_WEALTH } from '@constants/analytics';

export const PERSONAL_DETAILS_SCREEN = `${PAGE_WEALTH}|sipp-transfer|personal-details`;

export const PERSONAL_DETAILS_POSTCODE_LOOKUP =
  PERSONAL_DETAILS_SCREEN + '|postcode-lookup-tapped';
export const PERSONAL_DETAILS_ADDRESS =
  PERSONAL_DETAILS_SCREEN + '|enter-address-manually-tapped';
export const PERSONAL_DETAILS_CONTINUE =
  PERSONAL_DETAILS_SCREEN + '|continue-tapped';
