import { APP_BASE } from '@constants/analytics';
import { convertToKebabCase } from '@src/utils';

export const PAGE_WEALTH = APP_BASE + 'wealth|';

export const createAnalyticTag = (
  accountTag?: string,
  holdingTitle?: string | null
) => {
  const ACCOUNTTYPE_PRODUCTDETAIL_HOLDINGPAGETITLE =
    PAGE_WEALTH +
    accountTag +
    '|productDetail-investments|' +
    convertToKebabCase(holdingTitle);
  const INDIVIDUAL_HOLDING_PAGE_STATE =
    ACCOUNTTYPE_PRODUCTDETAIL_HOLDINGPAGETITLE;
  const INDIVIDUAL_HOLDING_PAGE_TRADE_BTN_CLICK =
    ACCOUNTTYPE_PRODUCTDETAIL_HOLDINGPAGETITLE + '|trade-tapped';
  const INDIVIDUAL_HOLDING_PAGE_UNITS_HELD_CLICK =
    ACCOUNTTYPE_PRODUCTDETAIL_HOLDINGPAGETITLE + '|unitsHeld-tapped';
  return [
    INDIVIDUAL_HOLDING_PAGE_TRADE_BTN_CLICK,
    INDIVIDUAL_HOLDING_PAGE_UNITS_HELD_CLICK,
    INDIVIDUAL_HOLDING_PAGE_STATE,
  ];
};
