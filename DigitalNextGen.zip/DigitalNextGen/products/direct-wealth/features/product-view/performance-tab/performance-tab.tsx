import {
  Card,
  FloatingButtonTotalHeight,
  getTokens,
  getVariableValue,
  Icon,
  LoadingState,
  Stack,
  Text,
  TransactionSummary,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { AccessibleTabsScrollView } from '@aviva/ion-mobile/components/collapsible-tabs/scroll-view';
import { TransactionDataItemProps } from '@aviva/ion-mobile/components/transaction-summary';
import { config } from '@config';
import { uriToInterceptFnZWebJourney } from '@constants/fnz';
import { webLinks } from '@constants/web-links';
import {
  SimpleWealthOnboardingCardStatus,
  useInitialiseSimpleWealthJourney,
} from '@direct-wealth/common/hooks/use-initialise-simple-wealth-journey';
import { PCSEntryPoint } from '@direct-wealth/features/pension-consolidation-summary/pcs-entry-point';
import { usePCSEntryPointViewModel } from '@direct-wealth/features/pension-consolidation-summary/use-pcs-entry-point-view-model';
import { Product } from '@direct-wealth/features/simple-wealth/components/onboarding-card/onboarding-card';
import { TakeControlWealthCard } from '@direct-wealth/features/simple-wealth/components/take-control-wealth-card/take-control-wealth-card';
import { AvivaSimpleWealth } from '@direct-wealth/validation/schemas/aviva-simple-wealth';
import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { isManga } from '@hooks/use-expo-config';
import { useWealthHubEligibility } from '@hooks/use-wealth-hub-eligibility';
import { FundValue } from '@src/components/fund-value/fund-value';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { QueryObserverResult } from '@tanstack/react-query';
import { useCallback, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Pressable } from 'react-native';

import { EditorialContentCard } from '../../../components/editorial-content-card';
import { GainLossTooltip } from '../../../components/gain-loss-tooltip/gain-loss-tooltip';
import { NotificationHeader } from '../product-dashboard/dw-notification-header';
import { ProductDashBoardViewProps } from '../product-dashboard/use-product-dashboard-view-model';
import {
  DRAWDOWN_TAG,
  GIA_TAG,
  ISA_TAG,
  PRODUCT_DETAIL_PERFORMANCE,
  PRODUCT_DETAIL_PERFORMANCE_CHARGES_TAPPED,
  PRODUCT_DETAIL_PERFORMANCE_DIRECT_DEBIT_TAPPED,
  PRODUCT_DETAIL_PERFORMANCE_GAINLOSS_TOOLTIP_TAPPED,
  PRODUCT_DETAIL_PERFORMANCE_MANAGE_PRODUCTS_TAPPED,
  PRODUCT_DETAIL_PERFORMANCE_TOP_UP_TAPPED,
  PRODUCT_DETAIL_PERFORMANCE_TRANSACTIONS_TAPPED,
  PRODUCT_DETAIL_PERFORMANCE_TRANSFER_IN_AN_EXTERNAL_PENSION_TAPPED,
  SIPP_TAG,
  WEALTH_BASE,
} from './../product-dashboard/analytics';
import { InvestmentProductPerformanceChartView } from './chart/chart-view-investment-product';

const interceptClosingWebView = 'Intercept Closing Webview';

type PerformanceTabProps = {
  data: ProductDashBoardViewProps['data'];
  fnzDeepLinksEnabled?: boolean;
  isEligibleForSippTransfer?: boolean;
  isNavigatorEnabled?: boolean;
  amount?: number;
  navigatorOnboardingCardStatus?: SimpleWealthOnboardingCardStatus;
  daysToAdviceExpiry?: number;
  refetch?: () => Promise<QueryObserverResult<AvivaSimpleWealth, unknown>>;
};

export const PerformanceTab = ({
  data,
  fnzDeepLinksEnabled,
  isEligibleForSippTransfer,
}: PerformanceTabProps) => {
  const tokens = getTokens();
  const { t } = useTranslation();
  const { trackUserEvent } = useAnalytics();
  const { navigate } = useAppStackNavigation();

  const {
    isSimpleWealthGetApiError,
    isSimpleWealthEnabled,
    simpleWealthOnboardingCardStatus,
    daysToAdviceExpiry,
    simpleWealthCardPressed,
    simpleWealthGetIsLoading,
    isAccountApiError,
  } = useInitialiseSimpleWealthJourney();

  const [content] = useWealthHubEligibility();

  const isSimpleWealthEligible = isManga()
    ? isSimpleWealthEnabled &&
      content?.simpleWealth &&
      !isSimpleWealthGetApiError &&
      !isAccountApiError
    : isSimpleWealthEnabled;

  const [isTooltipVisible, setIsTooltipVisible] = useState(false);

  const {
    accountType,
    gainOrLoss,
    valuation,
    transactionSummary,
    uiComponentAvailability,
    securePolicyNumber,
    startDate,
    status,
    gainOrLossPercentage,
  } = data;

  const {
    displayViewDirectDebitCta,
    displaySetUpDirectDebitCta,
    displayViewTransactionsCta,
  } = uiComponentAvailability;

  let accountTypeTag = '';

  switch (accountType) {
    case 'SIPP':
      accountTypeTag = SIPP_TAG;
      break;
    case 'ISA':
      accountTypeTag = ISA_TAG;
      break;
    case 'GIA':
      accountTypeTag = GIA_TAG;
      break;
    case 'Drawdown':
      accountTypeTag = DRAWDOWN_TAG;
      break;
  }

  useTrackStateEvent(
    `${WEALTH_BASE}${accountTypeTag}${PRODUCT_DETAIL_PERFORMANCE}`
  );

  const setupDirectDebitAction = useCallback(() => {
    trackUserEvent(
      `${WEALTH_BASE}${accountTypeTag}${PRODUCT_DETAIL_PERFORMANCE_TOP_UP_TAPPED}`
    );
    navigate(interceptClosingWebView, {
      uri: webLinks.managePayment(
        data.encryptedHierarchyId,
        fnzDeepLinksEnabled
      ),
      interceptUri: 'fnzc.co.uk/sso/ReturnToAppProductView',
    });
  }, [
    trackUserEvent,
    accountTypeTag,
    navigate,
    data.encryptedHierarchyId,
    fnzDeepLinksEnabled,
  ]);

  const formattedTransactionSummaryItems = useMemo<
    TransactionDataItemProps[]
  >(() => {
    const cashPaidIn: TransactionDataItemProps = {
      title: t('pension.performance.transactionSummaryCashPaidIn'),
      value: transactionSummary.cashPaidIn,
      format: 'capital',
    };
    const summaryCharges: TransactionDataItemProps = {
      title: t('pension.performance.transactionSummaryCharges'),
      value: transactionSummary.charges,
      format: 'capital',
      onPress: () => {
        trackUserEvent(
          `${WEALTH_BASE}${accountTypeTag}${PRODUCT_DETAIL_PERFORMANCE_CHARGES_TAPPED}`
        );

        navigate('Web View', {
          url: `${config.AVIVA_BASE_URL.get()}/investments/investment-charges/`,
        });
      },
    };

    // NOTE: MANGA-3692, commenting it out because it might return
    // NOTE: Make sure put TRANSACTION_SUMMARY_TRANSFERS_IN import and return
    // NOTE: Make sure undo test file too
    // const transfersIn: TransactionDataItemProps = {
    //   title: TRANSACTION_SUMMARY_TRANSFERS_IN,
    //   value: transactionSummary.transfersIn,
    //   format: 'capital',
    // };

    const cashWithdrawn: TransactionDataItemProps = {
      title: t('pension.performance.transactionSummaryCashWithdrawn'),
      value: transactionSummary.cashWithdrawn,
      format: 'capital',
    };

    return [cashPaidIn, cashWithdrawn, summaryCharges];
  }, [t, accountTypeTag, transactionSummary, trackUserEvent, navigate]);

  const onFundValuePress = () => setIsTooltipVisible(!isTooltipVisible);
  const onViewDirectDebitPress = () => {
    trackUserEvent(
      `${WEALTH_BASE}${accountTypeTag}${PRODUCT_DETAIL_PERFORMANCE_DIRECT_DEBIT_TAPPED}`
    );
    navigate('Manage Debit', { securePolicyNumber });
  };

  isTooltipVisible &&
    trackUserEvent(
      `${WEALTH_BASE}${accountTypeTag}${PRODUCT_DETAIL_PERFORMANCE_GAINLOSS_TOOLTIP_TAPPED}`
    );

  const manageYourProductAction = useCallback(() => {
    trackUserEvent(
      WEALTH_BASE +
        accountTypeTag +
        PRODUCT_DETAIL_PERFORMANCE_MANAGE_PRODUCTS_TAPPED
    );
    navigate(interceptClosingWebView, {
      uri: webLinks.wrapPolicy(data.encryptedHierarchyId),
      interceptUri: uriToInterceptFnZWebJourney,
    });
  }, [navigate, data.encryptedHierarchyId, trackUserEvent, accountTypeTag]);

  const isAccountActive = !(status === 'Closing' || status === 'Submitted');

  return (
    <>
      {!isAccountActive && <NotificationHeader status={status} />}
      <AccessibleTabsScrollView
        style={{ paddingBottom: FloatingButtonTotalHeight }}
      >
        <YStack bg={'$DWPrimary500'} paddingTop={tokens.space.xxxl}>
          <FundValue
            colorMain="White"
            colorNegative="Red30"
            colorZero="White"
            colorPositive="Positive"
            colorSecondary="Gray300"
            showTrendValue={status !== 'Submitted'}
            gainOrLoss={gainOrLoss}
            gainOrLossPercentage={gainOrLossPercentage}
            valuation={valuation}
            onPress={onFundValuePress}
          />
        </YStack>
        <YStack height={530} bg="$DWPrimary500" paddingHorizontal={'$xl'}>
          <InvestmentProductPerformanceChartView
            accountType={accountType}
            securePolicyNumber={securePolicyNumber}
            startDate={startDate}
            variant={'dark'}
          />
        </YStack>
        <YStack tablet={isIpad} p="$xl" mt={-tokens.size[12].val}>
          <XStack pb="$xl" justifyContent="space-between">
            <Text
              testID={getTestId('transaction-summary')}
              fontVariant="heading4-semibold-White"
            >
              {t('pension.performance.transactionSummaryTitle')}
            </Text>
            {displayViewTransactionsCta && (
              <Pressable
                testID={getTestId('show-all-transactions')}
                accessibilityLabel={t('pension.performance.showAll')}
                accessibilityHint={t('pension.performance.showAllHint')}
                accessibilityRole="link"
                onPress={() => {
                  trackUserEvent(
                    `${WEALTH_BASE}${accountTypeTag}${PRODUCT_DETAIL_PERFORMANCE_TRANSACTIONS_TAPPED}`
                  );
                  navigate('Transaction History', {
                    securePolicyNumber,
                    accountType,
                  });
                }}
              >
                <XStack marginTop={'$sm'}>
                  <Text fontVariant="heading5-semibold-Primary500">
                    {t('pension.performance.showAllCta')}
                  </Text>
                  <Icon
                    name="chevron-right"
                    color={getVariableValue(tokens.color.Primary500)}
                  />
                </XStack>
              </Pressable>
            )}
          </XStack>
          <TransactionSummary items={formattedTransactionSummaryItems} />
          <Stack>
            {accountType && isAccountActive && (
              <Text
                tamaguiTextProps={{ marginTop: 26 }}
                fontVariant="heading5-semibold-Secondary800"
              >
                {t(`pension.performance.manageListTitle.${accountType}`)}
              </Text>
            )}
            <Stack />
          </Stack>

          {isAccountActive ? (
            <YStack paddingVertical={'$xl'} gap={'$xl'}>
              {accountType !== 'Drawdown' && (
                <Card
                  onPress={setupDirectDebitAction}
                  accessibilityHint={t(
                    'common.linkHint.navigatesToAvivaWebsite'
                  )}
                >
                  <Card.Generic.Content
                    right={
                      <Icon
                        name="external-link"
                        color={tokens.color.Gray400.val}
                      />
                    }
                  >
                    <Text fontVariant="body-semibold-Secondary800">
                      {t(`pension.performance.topUp.${accountType}`)}
                    </Text>
                  </Card.Generic.Content>
                </Card>
              )}
              {displayViewDirectDebitCta && (
                <Card
                  onPress={onViewDirectDebitPress}
                  accessibilityHint={t(
                    'common.linkHint.navigatesToAvivaWebsite'
                  )}
                >
                  <Card.Generic.Content
                    right={
                      <Icon
                        name="external-link"
                        color={tokens.color.Gray400.val}
                      />
                    }
                  >
                    <Text fontVariant="body-semibold-Secondary800">
                      {t('pension.performance.viewDirectDebitCardTitle')}
                    </Text>
                  </Card.Generic.Content>
                </Card>
              )}
              {!displayViewDirectDebitCta && displaySetUpDirectDebitCta && (
                <Card
                  onPress={setupDirectDebitAction}
                  accessibilityHint={t(
                    'common.linkHint.navigatesToAvivaWebsite'
                  )}
                >
                  <Card.Generic.Content
                    right={
                      <Icon
                        name="external-link"
                        color={tokens.color.Gray400.val}
                      />
                    }
                  >
                    <Text fontVariant="body-semibold-Secondary800">
                      {t('pension.performance.setDirectDebitCardTitle')}
                    </Text>
                  </Card.Generic.Content>
                </Card>
              )}
              <Card
                onPress={manageYourProductAction}
                accessibilityHint={t('common.linkHint.navigatesToAvivaWebsite')}
              >
                <Card.Generic.Content
                  right={
                    <Icon
                      name="external-link"
                      color={tokens.color.Gray400.val}
                    />
                  }
                >
                  <Text
                    fontVariant="body-semibold-Secondary800"
                    tamaguiTextProps={{ mb: '$sm' }}
                  >
                    {t(`pension.performance.manageCardTitle.${accountType}`)}
                  </Text>
                  {(accountType === 'ISA' || accountType === 'SIPP') && (
                    <Text fontVariant="small-regular-Gray800">
                      {t(
                        `pension.performance.manageCardSubtitle.${accountType}`
                      )}
                    </Text>
                  )}
                </Card.Generic.Content>
              </Card>

              {accountType === 'SIPP' && (
                <SIPPEntryPointCards
                  isEligibleForSippTransfer={isEligibleForSippTransfer}
                />
              )}

              {(accountType === 'SIPP' || accountType === 'GIA') &&
              isSimpleWealthEligible ? (
                <Stack marginTop={'$xl'}>
                  <TakeControlWealthCard
                    status={simpleWealthOnboardingCardStatus}
                    product={accountType.toLowerCase() as Product}
                    daysToAdviceExpiry={daysToAdviceExpiry}
                    onPress={simpleWealthCardPressed}
                  />
                </Stack>
              ) : null}
            </YStack>
          ) : null}
        </YStack>
        <GainLossTooltip
          isTooltipVisible={isTooltipVisible}
          setIsTooltipVisible={setIsTooltipVisible}
        />

        {simpleWealthGetIsLoading && <LoadingState text={'loading'} />}
        <YStack height={'$xxl'} marginVertical={'$xxxxl'} />
      </AccessibleTabsScrollView>
    </>
  );
};

const SIPPEntryPointCards = ({
  isEligibleForSippTransfer,
}: {
  isEligibleForSippTransfer?: boolean;
}) => {
  const { pensionStatus } = usePCSEntryPointViewModel('product-details-screen');
  if (pensionStatus.hasPensions) {
    return (
      <Stack>
        <PCSEntryPoint parentComponent="product-details-screen" />
      </Stack>
    );
  }
  if (isEligibleForSippTransfer) {
    return (
      <Stack>
        <SIPPEntryPoint />
      </Stack>
    );
  }
  return null;
};

const SIPPEntryPoint = () => {
  const { t } = useTranslation();
  const { trackUserEvent } = useAnalytics();
  const { navigate } = useAppStackNavigation();

  const navigateToNativeSippTransfer = () => {
    trackUserEvent(
      WEALTH_BASE +
        'SIPP' +
        PRODUCT_DETAIL_PERFORMANCE_TRANSFER_IN_AN_EXTERNAL_PENSION_TAPPED,
      {
        quotetype: 'manual-entry',
      }
    );
    navigate('SIPP Transfer', {
      screen: 'Before You Start',
    });
  };

  return (
    <EditorialContentCard
      type="NoSubtitle"
      icon="plus"
      variant="small"
      title={t('pension.performance.nativeTransferCardTitle')}
      onPress={navigateToNativeSippTransfer}
    />
  );
};
