import {
  Button,
  getTokens,
  ScrollView,
  SectionHeading,
  Shimmer,
  Text,
  TransactionListItem,
  useWindowDimensions,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { uriToInterceptFnZWebJourney } from '@constants/fnz';
import { webLinks } from '@constants/web-links';
import { useAnalytics } from '@hooks/use-analytics';
import { useCustomer } from '@hooks/use-customer';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { A11yProps } from '@src/common/types/a11y';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import {
  convertISODateToDotFormat,
  convertISODateToLongFormat,
} from '@src/utils/date-converters';
import { formatPensionFunds } from '@src/utils/format-pension-data';
import { isIpad } from '@src/utils/is-ipad';
import { fonts } from '@theme/fonts';
import { Fragment, useCallback } from 'react';
import { useTranslation } from 'react-i18next';

import { useDirectWealthSubaccount } from '../../../../../products/direct-wealth/common/hooks/use-direct-wealth-subaccount';
import { ErrorState } from '../../../../../products/direct-wealth/components/error-state/error-state';
import { DirectWealthSubaccount } from '../../../../../products/direct-wealth/validation/schemas/direct-wealth-subaccount';
import { PaymentHistory } from '../../../../../products/direct-wealth/validation/schemas/payment-history';
import { usePaymentHistory } from '../../../common/hooks/use-payment-history';
import {
  ERROR_LOADING_PAYMENT_HISTORY,
  ERROR_RETRY_LOAD_PAYMENT_HISTORY_TAPPED,
  MANAGE_DIRECT_DEBIT_SCREEN,
  PRODUCT_DETAIL_PERFORMANCE_MANAGE_PAYMENTS_TAPPED,
  WEALTH_BASE,
} from './../product-dashboard/analytics';

export type ManageDebitScreenProps = NativeStackScreenProps<
  AppStackDWRouteParams,
  'Manage Debit'
>;

const ScreenHeader = ({ displayName }: { displayName: string }) => {
  const tokens = getTokens();
  return (
    <YStack
      paddingTop={tokens.space.xxl}
      paddingBottom={tokens.space.xxl}
      paddingHorizontal={tokens.space.xl}
      borderBottomWidth={tokens.space.xxs}
      borderBottomColor={tokens.color.Gray100}
    >
      <XStack accessibilityLabel={'your direct debits'} accessible>
        <Text
          fontVariant="heading2-regular-Secondary800"
          tamaguiTextProps={{
            fontWeight: fonts.heading.weight.regular,
            letterSpacing: tokens.space['-xxs'],
            importantForAccessibility: 'no',
            accessibilityLabel: 'your direct debits',
          }}
        >
          Your direct debit(s)
        </Text>
      </XStack>
      <Text
        fontVariant="heading4-regular-Gray800"
        tamaguiTextProps={{
          fontWeight: fonts.heading.weight.light,
          letterSpacing: tokens.space['-xxs'],
        }}
      >
        {displayName}
      </Text>
    </YStack>
  );
};

const Template = ({
  title,
  value,
  accessibilityLabel,
}: { title: string; value: string } & A11yProps) => {
  const tokens = getTokens();
  return (
    <YStack
      flexDirection="row"
      justifyContent="space-between"
      margin={tokens.space.xl}
    >
      <Text fontVariant="small-regular-DWPrimary500">{title}</Text>
      <Text
        fontVariant="body-semibold-WealthBlue"
        tamaguiTextProps={{ accessibilityLabel }}
      >
        {value}{' '}
      </Text>
    </YStack>
  );
};

const ShowDirectDebits = ({
  regularPayments,
}: Pick<DirectWealthSubaccount, 'regularPayments'>) => {
  const tokens = getTokens();
  if (
    regularPayments === null ||
    regularPayments === undefined ||
    !regularPayments.length
  ) {
    return null;
  }

  if (regularPayments.length === 1) {
    return (
      <>
        <Template
          title="Amount"
          value={`£${regularPayments[0].amount} - ${regularPayments[0].frequency}`}
        />
        <Template
          title="First payment"
          value={convertISODateToDotFormat(regularPayments[0].firstPayment)}
          accessibilityLabel={convertISODateToLongFormat(
            regularPayments[0].firstPayment
          )}
        />
        <Template
          title="Next payment"
          value={convertISODateToDotFormat(regularPayments[0].nextPayment)}
          accessibilityLabel={convertISODateToLongFormat(
            regularPayments[0].nextPayment
          )}
        />
      </>
    );
  } else {
    return (
      <>
        {regularPayments.map((directDebit, index) => (
          <Fragment
            key={`${directDebit.frequency}-${directDebit.firstPayment}`}
          >
            <Text
              tamaguiTextProps={{
                paddingLeft: tokens.space.xl,
                marginTop: tokens.space.xxl,
              }}
              fontVariant="heading5-semibold-DWBlack"
            >
              Direct Debit {index + 1}
            </Text>
            <Template
              title="Amount"
              value={`£${directDebit.amount}/${directDebit.frequency}`}
            />
            <Template
              title="First payment"
              value={convertISODateToDotFormat(regularPayments[0].firstPayment)}
              accessibilityLabel={convertISODateToLongFormat(
                regularPayments[0].firstPayment
              )}
            />
            <Template
              title="Next payment"
              value={convertISODateToDotFormat(regularPayments[0].nextPayment)}
              accessibilityLabel={convertISODateToLongFormat(
                regularPayments[0].nextPayment
              )}
            />
          </Fragment>
        ))}
      </>
    );
  }
};

const PreloadingShimmers = () => {
  return (
    <>
      {[1, 2, 3, 4].map((a) => {
        return (
          <YStack
            key={a.toString()}
            flexDirection={'row'}
            justifyContent={'space-between'}
            paddingBottom="$xl"
            paddingHorizontal="$xl"
          >
            <XStack flexDirection={'column'} space={'$md'}>
              <Shimmer width={100} height={20} />
              <Shimmer width={150} height={30} />
            </XStack>
            <XStack alignSelf={'center'}>
              <Shimmer width={100} height={20} />
            </XStack>
          </YStack>
        );
      })}
    </>
  );
};

const ShowPaymentsHistory = ({
  payments,
}: {
  payments: PaymentHistory['payments'];
}) => {
  const tokens = getTokens();
  return (
    <YStack
      borderTopWidth={tokens.space.xxs}
      borderTopColor={tokens.color.Gray100}
    >
      {payments.map((payment) => {
        const formattedTransferValue = formatPensionFunds(payment.amount);
        return formattedTransferValue ? (
          <YStack
            key={`${payment.referenceNumber}-${payment.settlementDate}`}
            borderBottomWidth={tokens.space.xxs}
            borderBottomColor={tokens.color.Gray100}
          >
            <TransactionListItem
              date={payment.transactionDate.formatted}
              transferType="DIRECT DEBIT"
              transferValue={formattedTransferValue}
            />
          </YStack>
        ) : null;
      })}
    </YStack>
  );
};

export const ManageDirectDebitScreen = ({
  route,
}: Pick<ManageDebitScreenProps, 'route'>) => {
  const { t } = useTranslation();
  const analytics = useAnalytics();
  const { securePolicyNumber } = route.params;
  const tokens = getTokens();
  const { data: subaccount } = useDirectWealthSubaccount(securePolicyNumber);
  const { data: customer } = useCustomer();
  const { navigate } = useAppStackNavigation();
  const { height } = useWindowDimensions();
  const isEnableFnzDeepLinking = customer?.FeatureToggles?.EnableFnzDeepLinking;
  useOnPageLoad({
    pageTag: `${WEALTH_BASE}${subaccount?.accountType}${MANAGE_DIRECT_DEBIT_SCREEN}`,
  });

  const managePaymentAction = useCallback(() => {
    analytics.trackUserEvent(
      `${WEALTH_BASE}${subaccount?.accountType}${PRODUCT_DETAIL_PERFORMANCE_MANAGE_PAYMENTS_TAPPED}`
    );
    navigate('Intercept Closing Webview', {
      uri: webLinks.managePayment(
        subaccount?.encryptedHierarchyId ?? '',
        isEnableFnzDeepLinking
      ),
      interceptUri: uriToInterceptFnZWebJourney,
    });
  }, [
    navigate,
    subaccount?.encryptedHierarchyId,
    isEnableFnzDeepLinking,
    analytics,
    subaccount?.accountType,
  ]);

  if (subaccount === undefined) {
    return null;
  }

  const { accountType } = subaccount;

  return (
    <YStack bg={tokens.color.White} f={1} height={isIpad ? height : undefined}>
      <ScrollView>
        <YStack tablet={isIpad} padding={isIpad ? '$xl' : undefined}>
          <ScreenHeader displayName={subaccount.displayName} />
          <ShowDirectDebits regularPayments={subaccount.regularPayments} />

          {/* Manage payment button */}
          <YStack p="$xl" tabletNarrow={isIpad}>
            <Button
              accessibilityLabel={t('pension.performance.managePaymentsButton')}
              accessibilityHint="On click opens FNZ manage your product webview"
              onPress={managePaymentAction}
            >
              {t('pension.performance.managePaymentsButton')}
            </Button>
          </YStack>

          {/* Payment History */}
          <YStack paddingHorizontal="$xl">
            <SectionHeading heading="Payment History" />
          </YStack>

          <PaymentHistoryComponent
            accountType={accountType}
            securePolicyNumber={securePolicyNumber}
          />
        </YStack>
      </ScrollView>
    </YStack>
  );
};

const PaymentHistoryComponent = ({
  accountType,
  securePolicyNumber,
}: {
  accountType: string;
  securePolicyNumber: string;
}) => {
  const tokens = getTokens();
  const { t } = useTranslation();
  const [paymentHistory, state] = usePaymentHistory(securePolicyNumber);
  const analytics = useAnalytics();

  if (state.isLoading) {
    return <PreloadingShimmers />;
  }

  if (state.isError) {
    analytics.trackStateEvent(
      `${WEALTH_BASE}${accountType}${ERROR_LOADING_PAYMENT_HISTORY}`
    );
    return (
      <YStack
        paddingBottom={tokens.space.xxl}
        paddingHorizontal={tokens.space.xl}
      >
        <ErrorState
          variant="light"
          message={t('pension.performance.loadErrorMsg')}
          buttonValue={t('pension.performance.retryButton')}
          buttonAccessibilityHint={t('pension.performance.retryButtonHint')}
          onRetry={() => {
            analytics.trackUserEvent(
              `${WEALTH_BASE}${accountType}${ERROR_RETRY_LOAD_PAYMENT_HISTORY_TAPPED}`
            );
            state.refetch();
          }}
          height={tokens.size[16].val}
        />
      </YStack>
    );
  }

  return (
    <>
      {paymentHistory === undefined ||
      !paymentHistory.payments.length ? null : (
        <ShowPaymentsHistory payments={paymentHistory.payments} />
      )}
    </>
  );
};
