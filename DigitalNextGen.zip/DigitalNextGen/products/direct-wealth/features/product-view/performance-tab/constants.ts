export const TODAY = 'TODAY';

export const todayLabel = (value: number) => ({
  label: TODAY,
  displayValue: TODAY,
  value,
});
