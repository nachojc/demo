import { Shimmer, Stack, Tabs, XStack, YStack } from '@aviva/ion-mobile';

const PerformanceLoadingTabScreen = () => (
  <YStack
    flexDirection={'column'}
    justifyContent={'space-between'}
    paddingTop="$xl"
    paddingHorizontal="$xl"
    backgroundColor={'$WealthBlue95'}
  >
    <XStack
      flexDirection={'column'}
      space={'$md'}
      alignItems={'center'}
      paddingTop="$xl"
    >
      <Shimmer width={200} height={10} colorScheme={'dark'} />
      <Shimmer width={200} height={40} colorScheme={'dark'} />
      <Shimmer width={140} height={10} colorScheme={'dark'} />
    </XStack>
    <XStack
      flexDirection={'column'}
      space={'$md'}
      margin={'auto'}
      paddingTop="$xxxl"
    >
      <Shimmer width={320} height={270} colorScheme={'dark'} />
    </XStack>
    <XStack flexDirection={'column'} space={'$md'} height={150} />
  </YStack>
);

export const InvestmentsLoadingTabScreen = () => (
  <YStack>
    <YStack
      backgroundColor={'$WealthBlue95'}
      height={55}
      marginBottom={-65}
      overflow="visible"
    />
    <Stack marginTop={50} marginLeft={15}>
      <Shimmer width={320} height={80} colorScheme={'light'} />
    </Stack>

    <Stack marginTop={20} marginLeft={15}>
      <Shimmer width={320} height={80} colorScheme={'light'} />
    </Stack>
  </YStack>
);

export const InformationLoadingTabScreen = () => (
  <YStack space={'$md'} paddingVertical={'$xxxl'} paddingHorizontal={'$xl'}>
    <Shimmer width={210} height={20} colorScheme={'light'} />
    <Shimmer width={320} height={20} colorScheme={'light'} />
    <Shimmer width={320} height={20} colorScheme={'light'} />
    <Shimmer width={320} height={20} colorScheme={'light'} />
    <Shimmer width={320} height={20} colorScheme={'light'} />
    <Shimmer width={320} height={20} colorScheme={'light'} />
  </YStack>
);

const DWHeaderPreloadingShimmers = () => {
  return (
    <YStack
      flexDirection={'row'}
      justifyContent={'space-between'}
      paddingTop="$xl"
      paddingHorizontal="$xl"
      backgroundColor="$WealthBlue"
    >
      <XStack flexDirection={'column'} space={'$md'}>
        <Shimmer width={200} height={20} colorScheme={'dark'} />
        <Shimmer width={200} height={20} colorScheme={'dark'} />
      </XStack>
    </YStack>
  );
};

export const ProductLoadingScreen = () => {
  return (
    <>
      <DWHeaderPreloadingShimmers />
      <Tabs
        tabBarVariant="dwBlue"
        tabRoutes={[
          {
            key: 'Performance',
            title: 'Performance',
            component: PerformanceLoadingTabScreen,
          },
          {
            key: 'Investments',
            title: 'Investments',
            component: InvestmentsLoadingTabScreen,
          },
          {
            key: 'Information',
            title: 'Information',
            component: InformationLoadingTabScreen,
          },
        ]}
      />
    </>
  );
};
