import { NotificationCard, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';
import { SubaccountAccountStatus } from 'products/direct-wealth/validation/schemas/direct-wealth-subaccount';

const data = {
  Closing: {
    title: 'Your account is in the process of closing.',
    icon: 'error',
  },
  Submitted: {
    title: 'Your account is in the process of opening.',
    icon: 'warning',
  },
} as const;

type NotificationHeaderProps = { status: SubaccountAccountStatus };
export const NotificationHeader = ({ status }: NotificationHeaderProps) => {
  if (!(status === 'Closing' || status === 'Submitted')) {
    return null;
  }

  return (
    <YStack p="$xl" bg="$DWPrimary500">
      <YStack tablet={isIpad}>
        <NotificationCard
          subtitle={data[status].title}
          iconVariant={data[status].icon}
          accessibilityLabel="Notification Bar"
          accessibilityHint="Notification bar with message of your account status"
          subtitleTextProps={{
            fontSize: 16,
            fontWeight: '400',
            fontStyle: 'normal',
          }}
        />
      </YStack>
    </YStack>
  );
};
