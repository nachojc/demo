import {
  FloatingButtonTotalHeight,
  getTokens,
  Snackbar,
  Tabs,
  TabsProps,
  useWindowDimensions,
  YStack,
} from '@aviva/ion-mobile';
import { useScrollManager } from '@aviva/ion-mobile/components/collapsible-tabs/accessible-tabs';
import { TabsContext } from '@aviva/ion-mobile/components/collapsible-tabs/context';
import { CollapsibleHeader } from '@direct-wealth/components/product-dash-app-bar/animated-top-app-bar';
import { VirtualAssistant } from '@direct-wealth/components/virtual-assistant/virtual-assistant';
import { useAnalytics } from '@hooks/use-analytics';
import Clipboard from '@react-native-clipboard/clipboard';
import NetInfo from '@react-native-community/netinfo';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { useNavbar } from '@src/common/providers/nav-control';
import { AnimatedHeader } from '@src/components/animated-header';
import { AppStackDWRouteParams } from '@src/navigation/app/direct-wealth-screens';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { isIpad } from '@src/utils/is-ipad';
import {
  DirectWealthSubaccount,
  DirectWealthSubaccountISAAllowance,
} from 'products/direct-wealth/validation/schemas/direct-wealth-subaccount';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { Alert } from 'react-native';

import { ErrorView } from '../../../../direct-wealth/components/error-view/error-view';
import { InformationTab } from '../information-tab/information-tab';
import {
  DisplayOptions,
  getInvestmentBottomSheetOptions,
  InvestmentsTab,
} from '../investments-tab';
import { PerformanceTab } from '../performance-tab';
import {
  ACCOUNT_NUMBER_COPY_TAPPED,
  createTotalPolicyValueString,
  PRODUCT_DETAIL_INFORMATION_TAB_TAPPED,
  PRODUCT_DETAIL_INVESTMENT_TAB_TAPPED,
  PRODUCT_DETAIL_PERFORMANCE_TAB_TAPPED,
  WEALTH_BASE,
} from './analytics';
import { Constants } from './constants';
import { ProductLoadingScreen } from './product-loading-screen';
import {
  ProductDashBoardViewPropsWithAllowance,
  useProductDashboardViewModel,
} from './use-product-dashboard-view-model';

const {
  POLICY_NUMBER_COPIED,
  TAB_PERFORMANCE,
  TAB_INVESTMENTS,
  TAB_INFORMATION,
} = Constants;

export const chatButtonAction = [
  TAB_PERFORMANCE,
  TAB_INVESTMENTS,
  TAB_INFORMATION,
];

export type AccountStatus = Extract<
  DirectWealthSubaccount['status'],
  'Closing' | 'Submitted'
>;

export const ProductDashboard = ({
  data,
}: ProductDashBoardViewPropsWithAllowance) => {
  const {
    subaccount,
    subAccountISAAllowance,
    fnzDeepLinksEnabled,
    isEligibleForSippTransfer,
  } = data;
  const {
    accountType,
    displayName,
    policyNumber,
    uiComponentAvailability,
    supportChannels,
    investments,
    encryptedHierarchyId,
  } = subaccount;
  const tokens = getTokens();
  const { trackUserEvent } = useAnalytics();
  const [displaySnackbar, setDisplaySnackbar] = useState(false);
  const { scrollHandler, headerOpen } = useScrollManager(30);
  const providerValue = useMemo(() => ({ scrollHandler }), [scrollHandler]);
  const { setShowTitle } = useNavbar();

  const navigator = useAppStackNavigation();

  const [selectedTabIndex, setSelectedTabIndex] = useState(0);

  const analytics = useAnalytics();
  const PER_CHAR_SPACE = 11.5;

  const sendProductValueAnalytics = useCallback(
    (
      subaccountInvestments: DirectWealthSubaccount['investments'],
      remainingISAAllowance?: DirectWealthSubaccountISAAllowance['remainingAllowance']
    ) => {
      analytics.trackStateEvent(`${WEALTH_BASE}${accountType}|product-detail`, {
        fundvalue:
          subaccountInvestments &&
          createTotalPolicyValueString(subaccountInvestments),
        ...(remainingISAAllowance && {
          remainingisaallowance: `${remainingISAAllowance}`,
        }),
      });
    },
    [analytics, accountType]
  );

  useEffect(() => {
    setShowTitle(!headerOpen);
  }, [headerOpen, setShowTitle]);

  useEffect(() => {
    navigator.setOptions({ title: displayName });
  }, [displayName, navigator]);

  useEffect(() => {
    if (investments) {
      sendProductValueAnalytics(
        investments,
        subAccountISAAllowance?.remainingAllowance
      );
    }
  }, [investments, sendProductValueAnalytics, subAccountISAAllowance]);

  const showChatButton =
    Array.isArray(supportChannels) &&
    supportChannels.includes('VirtualAssistant');

  const investmentBottomSheetOptions: DisplayOptions[] =
    getInvestmentBottomSheetOptions({
      uiComponentAvailability,
      navigator,
      fnzDeeplinksEnabled: fnzDeepLinksEnabled,
      encryptedHierarchyId,
      accountType,
    });

  const PerformanceTabScreen = useCallback(() => {
    return (
      <PerformanceTab
        data={subaccount}
        fnzDeepLinksEnabled={fnzDeepLinksEnabled}
        isEligibleForSippTransfer={isEligibleForSippTransfer}
      />
    );
  }, [subaccount, fnzDeepLinksEnabled, isEligibleForSippTransfer]);

  const InvestmentsTabScreen = useCallback(
    () => (
      <InvestmentsTab
        data={subaccount}
        investmentBottomSheetOptions={investmentBottomSheetOptions}
        fnzDeepLinksEnabled={fnzDeepLinksEnabled}
      />
    ),
    [subaccount, fnzDeepLinksEnabled]
  );

  const InformationTabScreen = useCallback(
    () => (
      <InformationTab
        fnzDeepLinksEnabled={fnzDeepLinksEnabled}
        subaccount={subaccount}
        subAccountISAAllowance={subAccountISAAllowance}
      />
    ),
    [fnzDeepLinksEnabled, subAccountISAAllowance, subaccount]
  );

  let snackbarTimeout: NodeJS.Timeout;
  const copyToClipboard = () => {
    analytics.trackUserEvent(
      WEALTH_BASE + accountType + ACCOUNT_NUMBER_COPY_TAPPED
    );
    clearTimeout(snackbarTimeout);
    Clipboard.setString(policyNumber);
    setDisplaySnackbar(true);
    snackbarTimeout = setTimeout(async () => {
      setDisplaySnackbar(false);
    }, 4500);
  };

  const chatButtonSpace = (tabIndex: number) => {
    if (tabIndex === 1) {
      const showTradeButton =
        investments.length > 0 &&
        investmentBottomSheetOptions.length > 0 &&
        !isIpad;
      if (showTradeButton) {
        return FloatingButtonTotalHeight;
      }
    }

    return tokens.space.$xxl.val;
  };

  const productDashboardTabRoutes: TabsProps['tabRoutes'] = [
    {
      key: TAB_PERFORMANCE,
      title: TAB_PERFORMANCE,
      component: PerformanceTabScreen,
    },
    {
      key: TAB_INVESTMENTS,
      title: TAB_INVESTMENTS,
      component: InvestmentsTabScreen,
    },
    {
      key: TAB_INFORMATION,
      title: TAB_INFORMATION,
      component: InformationTabScreen,
    },
  ];

  const onTabChange: TabsProps['onTabChange'] = (tabName) => {
    switch (tabName) {
      case TAB_PERFORMANCE:
        trackUserEvent(
          `${WEALTH_BASE}${accountType}${PRODUCT_DETAIL_PERFORMANCE_TAB_TAPPED}`
        );
        break;
      case TAB_INVESTMENTS:
        trackUserEvent(
          `${WEALTH_BASE}${accountType}${PRODUCT_DETAIL_INVESTMENT_TAB_TAPPED}`
        );
        break;
      case TAB_INFORMATION:
        trackUserEvent(
          `${WEALTH_BASE}${accountType}${PRODUCT_DETAIL_INFORMATION_TAB_TAPPED}`
        );
        break;
      default:
        break;
    }
  };
  const { width: windowWidth } = useWindowDimensions();

  const distributedWidthForMobile = () => {
    const lengths = productDashboardTabRoutes.map((e) => e.title.length);
    const minTabWidthRequired = Math.max(...lengths) * PER_CHAR_SPACE;
    const defaultTabWidth = windowWidth / productDashboardTabRoutes.length;
    return Math.max(minTabWidthRequired, defaultTabWidth);
  };

  return (
    <>
      <TabsContext.Provider value={providerValue}>
        <YStack marginLeft={!isIpad && '$-sm'} f={1}>
          <AnimatedHeader
            component={
              <CollapsibleHeader
                displayName={displayName}
                policyNumber={policyNumber}
                onIconPress={copyToClipboard}
              />
            }
            openContainer={headerOpen}
          />
          <Tabs
            tabBarVariant="dwBlue"
            tabRoutes={productDashboardTabRoutes}
            onIndexChange={setSelectedTabIndex}
            onTabChange={onTabChange}
            tabStyle={{
              width: isIpad ? undefined : distributedWidthForMobile(),
            }}
          />
        </YStack>
      </TabsContext.Provider>

      <VirtualAssistant
        showChatButton={showChatButton}
        chatButtonSpaceFromBottom={chatButtonSpace(selectedTabIndex)}
        subaccountData={subaccount}
        pageMarker="wealth-details"
        analyticsData={`${accountType.toLowerCase()}|product-detail-${chatButtonAction[
          selectedTabIndex
        ].toLowerCase()}`}
      />

      {displaySnackbar && (
        <YStack
          position="absolute"
          width={`${tokens.size[11].val}%`}
          left={`${tokens.size['0.5'].val}%`}
          bottom={0}
        >
          <Snackbar
            snackbar
            snackbarSingleLine
            showBorder={false}
            enterTime={100}
            exitTime={4100}
            title={POLICY_NUMBER_COPIED}
          />
        </YStack>
      )}
    </>
  );
};

type ProductDashboardRouteProps = NativeStackScreenProps<
  AppStackDWRouteParams,
  'ProductDashboard'
>['route'];

export const ProductDashboardScreen = ({
  route,
}: {
  route: ProductDashboardRouteProps;
}) => {
  const {
    isLoading,
    isError,
    refetch,
    subaccount,
    subAccountISAAllowance,
    isOverAllowanceLimit,
    fnzDeepLinksEnabled,
    isEligibleForSippTransfer,
  } = useProductDashboardViewModel(route.params.securePolicyNumber);
  const { isConnected } = NetInfo.useNetInfo();

  if (isLoading) {
    return <ProductLoadingScreen />;
  }

  if (isError) {
    return (
      <ErrorView
        onRetry={() => {
          !isConnected
            ? Alert.alert(
                'You need to be connected to the internet to continue.',
                'Please check your connection and try again.',
                [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Retry', onPress: () => refetch() },
                ]
              )
            : refetch();
        }}
      />
    );
  }

  return subaccount ? (
    <ProductDashboard
      data={{
        subaccount,
        subAccountISAAllowance,
        isOverAllowanceLimit,
        fnzDeepLinksEnabled,
        isEligibleForSippTransfer,
      }}
    />
  ) : (
    <ErrorView onRetry={refetch} />
  );
};
