import { useCustomer } from '@hooks/use-customer';

import { useDirectWealthSubaccount } from '../../../common/hooks/use-direct-wealth-subaccount';
import { useDirectWealthSubaccountISAAllowance } from '../../../common/hooks/use-direct-wealth-subaccount-isa-allowance';

export const useProductDashboardViewModel = (securePolicyNumber: string) => {
  const { data: customer } = useCustomer();
  const {
    data: subaccount,
    isLoading,
    isError,
    refetch,
  } = useDirectWealthSubaccount(securePolicyNumber);

  const { data: subAccountISAAllowance, data: subAccountISAAllowanceRest } =
    useDirectWealthSubaccountISAAllowance(
      securePolicyNumber,
      subaccount?.accountType
    );

  const isOverAllowanceLimit =
    subAccountISAAllowance &&
    subAccountISAAllowance.currentFinancialYearInvestment /
      subAccountISAAllowance.isaAllowance >=
      0.8;
  return {
    subaccount,
    isLoading,
    isError,
    refetch,
    subAccountISAAllowance,
    subAccountISAAllowanceRest,
    isOverAllowanceLimit,
    fnzDeepLinksEnabled: customer?.FeatureToggles?.EnableFnzDeepLinking,
    isEligibleForSippTransfer:
      customer?.Eligibilities?.find(
        (eligibility) =>
          eligibility.Type === 'isEligibleForDirectWealthSippTransfer.V2'
      )?.Value ?? false,
  };
};

export type SubAccountISAAllowance = NonNullable<
  ReturnType<typeof useProductDashboardViewModel>['subAccountISAAllowance']
>;

export type ProductDashBoardViewPropsWithAllowance = {
  data: {
    subaccount: NonNullable<
      ReturnType<typeof useProductDashboardViewModel>['subaccount']
    >;
    subAccountISAAllowance?: SubAccountISAAllowance;
    isOverAllowanceLimit?: boolean;
    fnzDeepLinksEnabled?: boolean;
    isEligibleForSippTransfer?: boolean;
  };
};

export type ProductDashBoardViewProps = {
  data: NonNullable<
    ReturnType<typeof useProductDashboardViewModel>['subaccount']
  >;
};
