import { APP_BASE } from '@constants/analytics';
import { DirectWealthSubaccount } from 'products/direct-wealth/validation/schemas/direct-wealth-subaccount';

export const WEALTH_BASE = APP_BASE + 'wealth|';

export const createAnalyticTag = (accountTag: string) => {
  const INVESTMENT_TAB_TRADE_BTN_CLICK =
    WEALTH_BASE + accountTag + '|productDetail-investments|trade-tapped';
  const WEALTH_BASE_CHATBOT =
    WEALTH_BASE + accountTag + '|productDetail|chatbot-tapped';
  return [WEALTH_BASE_CHATBOT, INVESTMENT_TAB_TRADE_BTN_CLICK];
};

export const createTotalPolicyValueString = (
  subaccountInvestments: Required<DirectWealthSubaccount['investments']>
): string => {
  const totalValue = subaccountInvestments.reduce(
    (total, obj) => {
      if (obj.value) {
        if (obj.isCash) {
          total.cash += obj.value;
        } else {
          total.fund += obj.value;
        }
        total.overall += obj.value;
        return total;
      }
      return total;
    },
    { cash: 0, fund: 0, overall: 0 }
  );
  return `total-${totalValue?.overall}|cash-${totalValue?.cash}|fund-${totalValue?.fund}`;
};

export const ERROR_LOADING_GRAPH = '|error-loading-graph';
export const ERROR_RETRY_LOAD_GRAPH_TAPPED = '|error|retry-load-graph-tapped';

export const ERROR_LOADING_PAYMENT_HISTORY = '|error-loading-payment-history';
export const ERROR_RETRY_LOAD_PAYMENT_HISTORY_TAPPED =
  '|error|retry-load-payment-history-tapped';

export const ACCOUNT_NUMBER_COPY_TAPPED =
  '|productDetail|accountnumbercopy-tapped';

export const PRODUCT_DETAIL_PERFORMANCE = '|productDetail-performance';

export const PRODUCT_DETAIL_PERFORMANCE_GAINLOSS_TOOLTIP_TAPPED =
  '|productDetail-performance|gainlosstooltip-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_TRANSACTIONS_TAPPED =
  '|productDetail-performance|transactions-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_CHARGES_TAPPED =
  '|productDetail-performance|charges-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_MANAGE_PAYMENTS_TAPPED =
  '|productDetail-performance|managepayments-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_DIRECT_DEBIT_TAPPED =
  '|productDetail-performance|directdebit-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_TOP_UP_TAPPED =
  '|productDetail-performance|top-up-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_TRANSFER_IN_AN_EXTERNAL_PENSION_TAPPED =
  '|productDetail-performance|transfer-in-an-external-pension-pension-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_MANAGE_PRODUCTS_TAPPED =
  '|product-detail-performance|manage-product-tapped';

export const PRODUCT_DETAIL_GRAPH_GRAPHTIMESELECTOR =
  '|productDetail|graphTimeSelector|';

export const MANAGE_DIRECT_DEBIT_SCREEN = '|productDetail|manageDirectDebit';

export const PRODUCT_DETAIL_INFORMATION_TAB_TAPPED =
  '|productDetail|information-tapped';

export const PRODUCT_DETAIL_PERFORMANCE_TAB_TAPPED =
  '|productDetail|performance-tapped';

export const PRODUCT_DETAIL_INVESTMENT_TAB_TAPPED =
  '|productDetail|investments-tapped';

export const SIPP_TAG = 'sipp';
export const ISA_TAG = 'isa';
export const GIA_TAG = 'investment-account';
export const DRAWDOWN_TAG = 'pension-drawdown';
