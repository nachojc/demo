export const Constants = {
  TRADE: 'Trade',
  POLICY_NUMBER_COPIED: 'Account number copied to clipboard',
  POLICY_NUMBER: 'Account number: ',
  TAB_PERFORMANCE: 'Performance',
  TAB_INVESTMENTS: 'Investments',
  TAB_INFORMATION: 'Information',
};
