import { Button, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

export const InvestmentsTabFooter = ({
  showTradeButton,
  handlePresentBottomSheet,
  isAccountActive,
}: {
  showTradeButton: boolean;
  handlePresentBottomSheet: () => void;
  isAccountActive: boolean;
}) => {
  return (
    <>
      {showTradeButton && isAccountActive ? (
        <YStack
          width={'100%'}
          backgroundColor={'$White'}
          padding={'$xl'}
          paddingBottom={'$xxl'}
          borderTopWidth={isIpad ? undefined : 1}
          borderTopColor={isIpad ? undefined : '$Gray200'}
        >
          <YStack tabletNarrow={isIpad}>
            <Button
              onPress={handlePresentBottomSheet}
              accessibilityLabel="Trade"
              accessibilityHint="On click opens a slide menu, with option to buy or sell shares and buy, sell or switch funds"
              accessible
            >
              Trade
            </Button>
          </YStack>
        </YStack>
      ) : null}
    </>
  );
};
