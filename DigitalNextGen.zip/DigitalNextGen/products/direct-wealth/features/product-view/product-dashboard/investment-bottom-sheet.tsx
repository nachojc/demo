import { BottomSheet, BottomSheetActions, getTokens } from '@aviva/ion-mobile';
import { BottomActionSheetItem } from '@components/bottom-action-sheet-item';
import { useAnalytics } from '@hooks/use-analytics';
import { convertToKebabCase } from '@src/utils';
import { RefObject } from 'react';
import { useWindowDimensions } from 'react-native';

import { DisplayOptions } from '../investments-tab/bottom-sheet-options';

type InvestmentSheetProps = {
  accountType?: string;
  holdingTitle?: string | null;
  bottomSheetRef: RefObject<BottomSheetActions>;
  sheetOptions: DisplayOptions[];
};

type InvestmentContentProps = Omit<InvestmentSheetProps, 'bottomSheetRef'> & {
  onDismiss: () => void;
};

const convertTitle = (title?: string | null) =>
  title ? convertToKebabCase(title) + '|' : '';

const InvestmentSheet = ({
  accountType,
  holdingTitle,
  onDismiss,
  sheetOptions,
}: InvestmentContentProps) => {
  const analytics = useAnalytics();
  const APIholdingtitleString = convertTitle(holdingTitle);

  return (
    <>
      {sheetOptions.map((item) => (
        <BottomActionSheetItem
          key={item.title}
          accessibilityLabel={item.title}
          accessibilityHint={`Pressing this button will navigate you to the ${item.title} screen`}
          icon={item.icon}
          title={item.title}
          queryParameter={item.queryParameter}
          onOptionPress={() => {
            onDismiss();
            analytics.trackUserEvent(
              `ukmyaviva|wealth|${accountType}|productDetail-investments|${APIholdingtitleString}trade|${item.queryParameter}-tapped`
            );
            item.onOptionPress?.();
          }}
        />
      ))}
    </>
  );
};

export const InvestmentBottomSheet = ({
  accountType,
  holdingTitle,
  sheetOptions,
  bottomSheetRef,
}: InvestmentSheetProps) => {
  const { height: h } = useWindowDimensions();
  const tokens = getTokens();
  const OPTION_HEIGHT = tokens.size[9].val;
  const EXTRA_SHEET_HEIGHT = tokens.size[10].val;

  const height = sheetOptions.length * OPTION_HEIGHT + EXTRA_SHEET_HEIGHT;
  const snapPoint = (height / h) * 100;

  const dismiss = () => bottomSheetRef.current?.dismiss();

  return (
    <BottomSheet ref={bottomSheetRef} snapPoints={[snapPoint, snapPoint + 5]}>
      <InvestmentSheet
        accountType={accountType}
        holdingTitle={holdingTitle}
        onDismiss={dismiss}
        sheetOptions={sheetOptions}
      />
    </BottomSheet>
  );
};
