import { formatPercentageValue } from '@src/utils/format-percentage-value';
import z from 'zod';

import {
  GainOrLossPercentageSchema,
  GainOrLossSchema,
} from './direct-wealth-account';

export const SubaccountAccountTypeSchema = z.enum([
  'SIPP',
  'Drawdown',
  'GIA',
  'ISA',
] as const);

export const SubaccountAccountStatusSchema = z.enum([
  'Active',
  'Closing',
  'Closed',
  'Submitted',
] as const);

export const PercentageOfAccountSchema = z
  .number()
  .nullable()
  .transform((value) => ({
    raw: value,
    formatted: formatPercentageValue(value, 1),
  }));

export const InvestmentSchema = z.object({
  name: z.string().nullable(),
  quantity: z.number().nullable(),
  quantityType: z.string().nullable(),
  value: z.number().nullable(),
  gainOrLoss: GainOrLossSchema,
  gainOrLossPercentage: GainOrLossPercentageSchema,
  percentageOfAccount: PercentageOfAccountSchema,
  isCash: z.boolean(),
  fundRiskLevel: z.number(),
  productId: z.string(),
  encryptedProductId: z.string(),
});

export const RegularPayment = z.object({
  frequency: z.string(),
  firstPayment: z.string(),
  nextPayment: z.string(),
  amount: z.number(),
});

export const TransactionSummary = z.object({
  cashPaidIn: z.number().nullable(),
  cashWithdrawn: z.number().nullable(),
  transfersIn: z.number().nullish(),
  charges: z.number().nullable(),
});

export const Transfer = z.object({
  status: z.string(),
  lastUpdate: z.string(),
});

export const UiComponentAvailabilitySchema = z.object({
  displaySellSharesCta: z.optional(z.boolean()),
  displaySellFundsCta: z.optional(z.boolean()),
  displaySwitchFundsCta: z.boolean(),
  displaySetUpDirectDebitCta: z.boolean(),
  displayViewDirectDebitCta: z.boolean(),
  displayViewTransactionsCta: z.boolean(),
});

export const DirectWealthSubaccountSchema = z.object({
  hierarchyId: z.string(),
  encryptedHierarchyId: z.string(),
  accountType: SubaccountAccountTypeSchema,
  displayName: z.string(),
  valuation: z.number(),
  gainOrLoss: GainOrLossSchema,
  gainOrLossPercentage: GainOrLossPercentageSchema,
  investments: z.array(InvestmentSchema),
  valuesAsAtDate: z.string(),
  startDate: z.string().transform((date) => new Date(date)),
  hostSystem: z.string(),
  uiComponentAvailability: UiComponentAvailabilitySchema,
  policyNumber: z.string(),
  securePolicyNumber: z.string(),
  isLoaded: z.boolean(),
  dpaLevel: z.string(),
  supportChannels: z.array(z.string({})).nullish(),
  status: SubaccountAccountStatusSchema,
  transactionSummary: TransactionSummary,
  transfers: z.array(Transfer).nullish(),
  regularPayments: z.array(RegularPayment).nullish(),
});

export const DirectWealthSubaccountISAAllowanceSchema = z.object({
  currentFinancialYearInvestmentToDate: z.number(), // All processed payments.
  scheduledRegularPayments: z.number(), // Upcoming payments.
  currentFinancialYearInvestment: z.number(), // All payments, processed and upcoming.
  isaAllowance: z.number(),
  remainingAllowance: z.number(),
  financialYearStart: z.string(),
  financialYearEnd: z.string(),
  enableTopUpCTA: z.boolean(),
  enableGiaPromoCard: z.boolean(),
});

export type SubaccountAccount = z.infer<typeof SubaccountAccountTypeSchema>;
export type SubaccountAccountStatus = z.infer<
  typeof SubaccountAccountStatusSchema
>;

export type DirectWealthSubaccount = z.infer<
  typeof DirectWealthSubaccountSchema
>;

export type DirectWealthSubaccountISAAllowance = z.infer<
  typeof DirectWealthSubaccountISAAllowanceSchema
>;
export type Investment = z.infer<typeof InvestmentSchema>;

export type UiComponentAvailability = z.infer<
  typeof UiComponentAvailabilitySchema
>;
