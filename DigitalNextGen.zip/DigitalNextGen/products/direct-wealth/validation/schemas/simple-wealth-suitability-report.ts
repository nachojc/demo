import { z } from 'zod';

export const SimpleWealthSuitabilityReportSchema = z.object({
  encryptedDocumentId: z.string().nullable(),
  fileName: z.string().nullable(),
});

export type SimpleWealthSuitabilityReport = z.infer<
  typeof SimpleWealthSuitabilityReportSchema
>;
