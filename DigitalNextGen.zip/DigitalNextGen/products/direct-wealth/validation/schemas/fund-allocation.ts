import { z } from 'zod';

const refineAllocation = (val: string, ctx: z.RefinementCtx) => {
  if (Number(val) > 100) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Allocation cannot be over 100%',
    });
  }
  if (Number(val) < 0) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'Please enter a valid value',
    });
  }
};

export const FundAllocationSchema = z.object({
  fundPercentage: z.string().superRefine(refineAllocation),
  cashPercentage: z.string().superRefine(refineAllocation),
});

export type FundAllocationForm = z.infer<typeof FundAllocationSchema>;
