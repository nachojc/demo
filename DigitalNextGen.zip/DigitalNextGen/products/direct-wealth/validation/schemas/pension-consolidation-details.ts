import { z } from 'zod';

const DetailItemString = z.object({
  value: z.string().nullish(),
  tooltip: z.string().nullish(),
});

const DetailItemNumber = z.object({
  value: z.number(),
  tooltip: z.string().nullish(),
});

const DetailItemBoolean = z.object({
  value: z.boolean(),
  tooltip: z.string().nullish(),
});

const DetailItemStringArray = z.object({
  value: z.array(z.number()),
  tooltip: z.string().nullish(),
});

const DetailItemFees = z.object({
  value: z.object({
    monetaryValue: z.number().nullish(),
    rate: z.number().nullish(),
  }),
  tooltip: z.string().nullish(),
});

const ProviderAddress = z.object({
  address_1: z.string().nullish(),
  address_2: z.string().nullish(),
  address_3: z.string().nullish(),
  town: z.string().nullish(),
  county: z.string().nullish(),
  postcode: z.string().nullish(),
});

const RetirementBenefitSchema = z.object({
  title: z.string(),
  value: z.boolean(),
  tooltip: z.string().nullish(),
});

export const PensionConsolidationDetailsSchema = z.object({
  productDisplayName: DetailItemString,
  policyNumber: DetailItemString,
  cedingPensionPlanId: z.string().nullish(),
  employerName: DetailItemString,
  schemeProvider: DetailItemString,
  currentPensionValue: DetailItemNumber,
  transferValue: DetailItemNumber,
  valuationDate: z.object({
    value: z.string(),
    tooltip: z.null(),
  }),
  investedInWithProfitFund: DetailItemBoolean,
  annualManagementCharges: DetailItemStringArray,
  fundManagementCharges: DetailItemStringArray,
  totalExpenseRatios: DetailItemStringArray,
  policyFee: DetailItemFees,
  exitFee: DetailItemFees,
  valuableBenefits: z.object({
    value: z.array(
      z.object({
        benefitType: z.string(),
        displayName: z.string(),
        tooltip: z.string(),
      })
    ),
    tooltip: z.string().nullish(),
  }),
  safeguardedBenefits: z.object({
    value: z.null(),
    tooltip: z.string().nullish(),
  }),
  letterOfResponseDocumentId: z.object({
    value: z.string().nullish(),
    tooltip: z.string().nullish(),
  }),
  pensionProviderAddress: ProviderAddress,
  hasGuaranteedIncome: DetailItemBoolean.nullish(),
  hasIncomeDrawdown: DetailItemBoolean.nullish(),
  hasTakeYourPensionAsCash: DetailItemBoolean.nullish(),
});

export type PensionConsolidationDetails = z.infer<
  typeof PensionConsolidationDetailsSchema
>;

export type BenefitContent = z.infer<typeof RetirementBenefitSchema>;
