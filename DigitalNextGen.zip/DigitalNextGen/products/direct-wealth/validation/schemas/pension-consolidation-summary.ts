import { z } from 'zod';

const TransferStatus = z.enum([
  'NotSpecified',
  'TransferReceived',
  'TransferRequested',
  'TransferInitiated',
  'FurtherInformationRequired',
  'TransferInProgress',
  'Completed',
  'Cancelled',
]);

const TransferInformation = z.enum([
  'EligibleToTransfer',
  'MayLoseBenefits',
  'InTransfer',
]);

const ProviderAddress = z.object({
  address_1: z.string().nullish(),
  address_2: z.string().nullish(),
  address_3: z.string().nullish(),
  town: z.string().nullish(),
  county: z.string().nullish(),
  postcode: z.string().nullish(),
});

const PCSPension = z.object({
  productDisplayName: z.string(),
  policyNumber: z.string(),
  value: z.number(),
  valuationDate: z.string(),
  transferStatus: TransferStatus,
  information: TransferInformation,
  secureId: z.string(),
  employerName: z.string().nullish(),
  pensionProviderAddress: ProviderAddress,
});

export const PensionConsolidationSummarySchema = z.object({
  pensionsNotInTransfer: z.array(PCSPension).optional(),
  pensionsInTransfer: z.array(PCSPension).optional(),
});

export type TransferStatus = z.infer<typeof TransferStatus>;
export type TransferInformation = z.infer<typeof TransferInformation>;
export type PCSPension = z.infer<typeof PCSPension>;
export type PensionConsolidationSummary = z.infer<
  typeof PensionConsolidationSummarySchema
>;
