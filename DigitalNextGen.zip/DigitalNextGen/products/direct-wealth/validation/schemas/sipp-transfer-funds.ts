import { z } from 'zod';

import { SippUniversalFundSchema } from './sipp-universal-funds';

export const SippTransferFundSchema = SippUniversalFundSchema.extend({
  maxDisplayRiskLevel: z.number(),
  displayRiskLevel: z.number(),
  highLevelDescription: z.string(),
});

export const SippTransferFundsSchema = z.object({
  funds: z.array(SippTransferFundSchema),
});
export type SippTransferFund = z.infer<typeof SippTransferFundSchema>;

export type SippTransferFunds = z.infer<typeof SippTransferFundsSchema>;
