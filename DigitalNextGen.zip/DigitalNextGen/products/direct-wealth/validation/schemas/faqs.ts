import { z } from 'zod';

const ContextSchema = z.enum(['PensionConsolidationSummary']);

export const FAQSchema = z.object({
  question: z.string(),
  answer: z.string(),
});
export const FAQsSchema = z.object({
  faqs: z.array(FAQSchema),
});

export const OpenAnIsaFAQSchema = z.object({
  Question: z.string(),
  Response: z.string(),
});

export const OpenAnIsaFAQsSchema = z.object({
  Content: z.array(OpenAnIsaFAQSchema),
});

export type FAQContext = z.infer<typeof ContextSchema>;
export type FAQ = z.infer<typeof FAQSchema>;
export type OpenAnIsaFAQ = z.infer<typeof OpenAnIsaFAQSchema>;
export type FAQs = z.infer<typeof FAQsSchema>;
export type OpenAnIsaFAQs = z.infer<typeof OpenAnIsaFAQsSchema>;
