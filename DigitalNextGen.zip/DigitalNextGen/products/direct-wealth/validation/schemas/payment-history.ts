import { convertISODateToTodayYesterdayNoYearFull } from '@src/utils/date-converters/convert-iso-date-to-today-yesterday-no-year-full';
import { z } from 'zod';

const Payment = z.object({
  heading: z.string(),
  transactionType: z.string(),
  settlementDate: z.string(),
  transactionDate: z.string().transform((date) => {
    const dateObj = new Date(date);
    return {
      raw: dateObj,
      formatted: convertISODateToTodayYesterdayNoYearFull(date),
    };
  }),
  status: z.string(),
  amount: z.number(),
  referenceNumber: z.string(),
});

export const PaymentHistorySchema = z.object({
  payments: z.array(Payment),
});

export type PaymentHistory = z.infer<typeof PaymentHistorySchema>;
