import { UK_DATE_FORMAT } from '@constants/string-formats';
import { convertIsoDate } from '@src/utils';
import { formatPercentageValue } from '@src/utils/format-percentage-value';
import { z } from 'zod';

const formatSIPPChargesFunds = (value: number | null) => {
  if (value == null) {
    return value;
  }
  const formattedValue = formatPercentageValue(value, 2);
  return `${formattedValue}`;
};

export const SIPPFundChargesSchema = z
  .number()
  .nullable()
  .transform((value) => ({
    raw: value,
    formatted: formatSIPPChargesFunds(value),
  }));

const PerformanceSchema = z.object({
  startDate: z
    .string()
    .transform((date) => convertIsoDate(date, UK_DATE_FORMAT)),
  endDate: z.string().transform((date) => convertIsoDate(date, UK_DATE_FORMAT)),
  performance: z.number(),
});

export const SippUniversalFundSchema = z.object({
  title: z.string(),
  fundName: z.string(),
  aimOfTheFund: z.string(),
  typicalCharges: SIPPFundChargesSchema,
  fundManagedCharges: SIPPFundChargesSchema,
  avivaCharges: SIPPFundChargesSchema,
  avivaChargesLink: z.string(),
  totalCharges: SIPPFundChargesSchema,
  fundFactSheet: z.string().nullable(),
  kiid: z.string().nullable(),
  fundId: z.string(),
  sedol: z.string(),
  productId: z.string(),
  discretePerformance: z.array(PerformanceSchema).nullish(),
});

export type SippUniversalFund = z.infer<typeof SippUniversalFundSchema>;
