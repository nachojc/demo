import { format, isToday } from 'date-fns';
import { z } from 'zod';

const TransactionSchema = z.object({
  heading: z.string(),
  transactionType: z.string(),
  description: z.string().nullish(),
  transactionDate: z.string().transform((date) => {
    const dateObj = new Date(date);
    return {
      raw: dateObj,
      formatted: isToday(dateObj) ? 'Today' : format(dateObj, 'do MMMM yyyy'),
    };
  }),
  status: z.string(),
  amount: z.number().transform((amount) => ({
    raw: amount,
    formatted: new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      minimumFractionDigits: 2,
    }).format(amount),
  })),
  company: z.string().nullish(),
  cost: z.number().nullish(),
  quantity: z.number().nullish(),
  productType: z.string().nullish(),
  referenceNumber: z.string().nullish(),
  settlementDate: z.string().nullish(),
});

export const TransactionHistorySchema = z.object({
  transactions: z.array(TransactionSchema),
  page: z.number(),
  listEnd: z.boolean(),
  selectedFilters: z.array(z.string()),
  possibleFilters: z.array(z.string()),
});

export const CashTransactionDetailsParamsSchema = z
  .object({
    heading: z.string(),
    transactionType: z.string().nullable(),
    amount: z
      .object({
        raw: z.number(),
        formatted: z.string(),
      })
      .transform((amount) => amount.formatted),
    referenceNumber: z.string().nullish(),
    transactionDate: z
      .object({
        raw: z.date(),
        formatted: z.string(),
      })
      .transform((date) => format(date.raw, 'eeee do MMM yyyy')),
  })
  .transform(({ transactionType, ...rest }) => ({
    description: transactionType,
    ...rest,
  }));

export const ProductTransactionDetailsParamsSchema = z.object({
  heading: z.string().nullable(),
  transactionType: z.string().nullable(),
  transactionDate: z
    .object({
      raw: z.date(),
      formatted: z.string(),
    })
    .transform((date) => format(date.raw, 'eeee do MMM yyyy'))
    .nullable(),
  status: z.string(),
  amount: z
    .object({
      raw: z.number(),
      formatted: z.string(),
    })
    .transform((amount) => amount.formatted),
  company: z.string().nullable(),
  cost: z
    .number()
    .transform((cost) => `£${cost.toFixed(2)}`)
    .nullable(),
  quantity: z.number().nullable(),
  referenceNumber: z.string(),
});

export type Transaction = z.infer<typeof TransactionSchema>;
export type TransactionHistory = z.infer<typeof TransactionHistorySchema>;
export type CashTransactionDetailsParams = z.infer<
  typeof CashTransactionDetailsParamsSchema
>;
export type ProductTransactionDetailsParams = z.infer<
  typeof ProductTransactionDetailsParamsSchema
>;
