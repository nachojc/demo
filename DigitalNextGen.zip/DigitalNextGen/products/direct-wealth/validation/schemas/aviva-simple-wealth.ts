import { z } from 'zod';

const Opportunity = z.object({
  id: z.string(),
  amount: z.number(),
  closeDate: z.string(),
  secureSuitabilityReportId: z.string(),
});

const Person = z.object({
  name: z.string(),
  opportunity: Opportunity.nullable(),
});

const AdvisedInvestmentProfile = z.object({
  riskLevel: z.number(),
});

const FinalProjection = z.object({
  projectionRate: z.number().nullable(),
  projectionValue: z.number(),
});

const MonthlyProjection = z.object({
  month: z.number(),
  value: z.number(),
});

const Projections = z.object({
  finalLowGrowthRateProjection: FinalProjection,
  finalMediumGrowthRateProjection: FinalProjection,
  finalHighGrowthRateProjection: FinalProjection,
  finalCashProjection: FinalProjection,
  lowGrowthRateProjections: z.array(MonthlyProjection),
  mediumGrowthRateProjections: z.array(MonthlyProjection),
  highGrowthRateProjections: z.array(MonthlyProjection),
  cashProjections: z.array(MonthlyProjection),
});

export const AvivaSimpleWealthProjectionSchema = z.object({
  stage: z.string(),
  status: z.string(),
  advisedInvestmentProfile: AdvisedInvestmentProfile,
  projections: Projections,
});

const Responses = z.object({
  questionId: z.string(),
  responseIds: z.array(z.string()).nullable(),
  responseValue: z.number().nullable(),
});

const QuestionnaireResponses = z.object({
  questionnaireId: z.string(),
  responseSetId: z.string(),
  stage: z.string(),
  responses: z.array(Responses),
});

const DigitalAdviceSchema = z.object({
  fundId: z.string(),
  fundName: z.string(),
  fundDisplayName: z.string().nullable(),
  fundDescription: z.string().nullable(),
  SEDOL: z.string(),
  navigatorServiceInformation: z.string(),
  kiid: z.string(),
  fundFactsheet: z.string(),
  keyFeaturesIsaAndSnS: z.string(),
  isaTsAndCs: z.string(),
  expiryDate: z.string(),
});

export const AvivaSimpleWealthSchema = z.object({
  isEligbileForNavigatorJourney: z.boolean(),
  hybridAdvicePrice: z.number(),
  person: Person.nullable(),
  projection: AvivaSimpleWealthProjectionSchema.nullable(),
  questionnaireResponses: QuestionnaireResponses.nullable(),
  digitalAdvice: DigitalAdviceSchema.nullable(),
});

export type AvivaSimpleWealth = z.infer<typeof AvivaSimpleWealthSchema>;
export type DigitalAdvice = z.infer<typeof DigitalAdviceSchema>;

export type AvivaSimpleWealthProjection = z.infer<
  typeof AvivaSimpleWealthProjectionSchema
>;
