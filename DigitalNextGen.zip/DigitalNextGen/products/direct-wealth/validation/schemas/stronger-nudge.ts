import { z } from 'zod';

export const StrongerNudgeSchema = z.object({
  isReturningCustomer: z.boolean(),
  appointmentDateTime: z.string().transform((date) => new Date(date)),
  previousOutcome: z.string(),
});

export type StrongerNudge = z.infer<typeof StrongerNudgeSchema>;
