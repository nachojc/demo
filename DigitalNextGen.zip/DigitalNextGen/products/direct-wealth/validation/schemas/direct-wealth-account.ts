import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { formatPensionFunds } from '@src/utils/format-pension-data';
import { formatPercentageValue } from '@src/utils/format-percentage-value';
import { Account } from 'products/direct-wealth/features/portfolio-summary/types';
import z from 'zod';

const ValuationSchema = z.number().transform((value) => ({
  raw: value,
  formatted: formatCurrencyValue(value),
}));

export const GainOrLossSchema = z
  .number()
  .nullable()
  .transform((value) => ({
    raw: value,
    formatted: formatPensionFunds(value, true),
  }));

export const GainOrLossPercentageSchema = z
  .number()
  .nullable()
  .transform((value) => ({
    raw: value,
    formatted: formatPercentageValue(value, 2),
  }));

export const DirectWealthProductSchema = z.object({
  __tag: z
    .string()
    .optional()
    .default('DWProduct') as unknown as z.ZodLiteral<'DWProduct'>,
  valuation: ValuationSchema,
  gainOrLoss: GainOrLossSchema,
  gainOrLossPercentage: GainOrLossPercentageSchema,
  accountNumber: z.string(),
  displayName: z.string(),
  accountType: z.string().transform((val) => val as Account),
  policyNumber: z.string(),
  securePolicyNumber: z.string(),
  isLoaded: z.boolean(),
  dpaLevel: z.string(),
  status: z.enum(['Active', 'Closing', 'Submitted'] as const),
  supportChannels: z.array(z.string()).optional(),
  productCode: z.string().optional(),
});

export const DirectWealthAccountSchema = z.object({
  accountNumber: z.string(),
  displayName: z.string(),
  valuation: ValuationSchema,
  isLoaded: z.boolean(),
  displaySippPromotion: z.boolean(),
  displayIsaPromotion: z.boolean(),
  displayGiaPromotion: z.boolean(),
  products: z.array(DirectWealthProductSchema),
});

export type DirectWealthProduct = z.infer<typeof DirectWealthProductSchema>;

export type DirectWealthAccount = z.infer<typeof DirectWealthAccountSchema>;
