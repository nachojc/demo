import z from 'zod';

export const ContextSchema = z.enum([
  'PortfolioSummary',
  'SippInformation',
  'SippInvestments',
  'DrawdownInformation',
  'DrawdownInvestments',
  'GiaInvestments',
  'GiaInformation',
  'IsaInformation',
  'IsaInvestment',
  'PensionConsolidationSummary',
  'EnquirerSummary',
  'OpenAnIsa',
]);

export const EditorialBaseSchema = z.object({
  id: z.string(),
  categories: z.string(),
  understandingLevel: z.string(),
  title: z.string(),
  description: z.string().nullish(),
  actionTag: z.string().nullish(),
});

export const EditorialArticleSchema = EditorialBaseSchema.extend({
  type: z.literal('Article'),
  imageUri: z.string().nullish(),
  webUrl: z.string(),
  articleInfo: z.string().nullish(),
});

export const EditorialVideoSchema = EditorialBaseSchema.extend({
  type: z.literal('Video'),
  videoUrl: z.string(),
  videoThumbnailUri: z.string(),
  transcript: z.string(),
  videoInfo: z.string().nullish(),
});

const EditorialToolSchema = EditorialBaseSchema.extend({
  type: z.literal('Tool'),
  articleInfo: z.string().nullish(),
  icon: z.enum(['calculator']).nullish(),
  imageUri: z.string().nullish(),
  webUrl: z.string(),
});

export const EditorialContentSchema = z.array(
  z.discriminatedUnion('type', [
    EditorialArticleSchema,
    EditorialVideoSchema,
    EditorialToolSchema,
  ])
);

export const EditorialContentResponseSchema = z.object({
  content: EditorialContentSchema,
});

export type EditorialContext = z.infer<typeof ContextSchema>;

export type EditorialArticle = z.infer<typeof EditorialArticleSchema>;
export type EditorialVideo = z.infer<typeof EditorialVideoSchema>;

export type EditorialContent = z.infer<typeof EditorialContentSchema>;

export type EditorialContentResponse = z.infer<
  typeof EditorialContentResponseSchema
>;
