import { isToday } from 'date-fns';
import { z } from 'zod';

import { formatDate } from './investment-product-performance';

const showFirstAndLast = (index: number, lastIndex: number) =>
  index === 0 || index === lastIndex;

const performancePointSchema = z.object({
  value: z.number(),
  date: z.string().transform((date) => new Date(date)),
});

export const SIPPTransferFundPerformanceSchema = z.object({
  performancePoints: z.array(performancePointSchema),
});

export const FundPerformanceValuationSchema = z
  .array(
    z
      .object({
        date: z.date(),
        value: z.number(),
      })
      .transform(({ date, value }) => {
        return {
          displayValue: formatDate(date, 'LLL do yyyy'),
          label: isToday(date) ? 'TODAY' : formatDate(date, 'LLL'),
          value,
          date,
        };
      })
  )
  .optional();

export const AllTimeFundPerformanceValuationSchema = z
  .array(
    z
      .object({
        date: z.date(),
        value: z.number(),
      })
      .transform(({ date, value }) => {
        return {
          displayValue: formatDate(date, 'LLL do yyyy'),
          label: isToday(date) ? 'TODAY' : formatDate(date, 'LLL yyyy'),
          value,
          date,
        };
      })
  )
  .transform((arr) => {
    return arr.map((el, index) => {
      return {
        ...el,
        showLabel: showFirstAndLast(index, arr.length - 1),
      };
    });
  })
  .optional();

export type SIPPTransferFundPerformance = z.infer<
  typeof SIPPTransferFundPerformanceSchema
>;

export type FundPerformanceValuation = z.infer<
  typeof FundPerformanceValuationSchema
>;
