import { todayLabel } from '@direct-wealth/features/product-view/performance-tab/constants';
import { format, isToday } from 'date-fns';
import { z } from 'zod';

const TODAY = `TODAY`;

export const formatDate = (date: Date, dateFormat: string) =>
  isToday(date) ? 'TODAY' : format(date, dateFormat).toUpperCase();

const Valuation = z
  .object({
    date: z.union([z.string(), z.date()]),
    value: z.number(),
  })
  .transform(({ date, value }) => {
    const dateObj = new Date(date);
    return {
      dayLabel: formatDate(dateObj, 'do'),
      monthLabel: formatDate(dateObj, 'LLL'),
      yearLabel: format(dateObj, 'yyyy').toUpperCase(),
      date: dateObj,
      value,
    };
  });

const ChartValuations = z.array(
  z.object({
    displayValue: z.string().optional(),
    label: z.string(),
    value: z.number(),
  })
);

export const InvestmentProductPerformanceSchema = z.object({
  valuationsByDate: z.array(Valuation),
});

export const AllTimeValuationsSchema =
  InvestmentProductPerformanceSchema.transform(({ valuationsByDate }) => {
    const labelsArr: { label: string }[] = [];
    const valuesArr: { value: number; displayValue: string }[] = [];
    const dataLabels = valuationsByDate.map(
      ({ value, yearLabel, dayLabel }) => {
        if (dayLabel === TODAY) {
          labelsArr.push(todayLabel(value));
        } else {
          labelsArr.push({ label: yearLabel });
        }
        valuesArr.push({
          value,
          displayValue: dayLabel === TODAY ? TODAY : yearLabel,
        });
        return {
          labels: labelsArr,
          values: valuesArr,
        };
      }
    );

    return {
      categories: [{ category: dataLabels[0].labels }],
      dataset: [{ data: dataLabels[0].values }],
    };
  });

export type AllTimeValuations = z.infer<typeof AllTimeValuationsSchema>;
export type InvestmentProductPerformance = z.infer<
  typeof InvestmentProductPerformanceSchema
>;

export type Valuation = z.infer<typeof Valuation>;
export type ChartValuations = z.infer<typeof ChartValuations>;
