import { z } from 'zod';

export const IsaDocumentSchema = z.string();

export type IsaDocument = z.infer<typeof IsaDocumentSchema>;
