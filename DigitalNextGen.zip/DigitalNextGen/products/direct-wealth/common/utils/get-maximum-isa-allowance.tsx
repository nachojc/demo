/**
 * Currently the maximum ISA allowance in the UK is £20,000.00.
 *
 * We need this information in a few places in the app accross
 * different flows, so this function will return the maximum isa
 * allowance and give us just one place to updater should this
 * figure change in the future.

 */
export const getMaximumIsaAllowance = () => {
  return {
    maximumValue: 20000.0,
    maximumFormattedValue: '£20,000',
  };
};
