export const getAccessibileIsaFundDisplayName = (fundDisplayName: string) => {
  switch (fundDisplayName) {
    case 'Aviva Multi-Asset Core Fund I':
      return 'Aviva Multi Asset Core Fund One';
    case 'Aviva Multi-Asset Core Fund II':
      return 'Aviva Multi Asset Core Fund Two';
    case 'Aviva Multi-Asset Core Fund III':
      return 'Aviva Multi Asset Core Fund Three';
    case 'Aviva Multi-Asset Core Fund IV':
      return 'Aviva Multi Asset Core Fund Four';
    case 'Aviva Multi-Asset Core Fund V':
      return 'Aviva Multi Asset Core Fund Five';
    default:
      return '';
  }
};
