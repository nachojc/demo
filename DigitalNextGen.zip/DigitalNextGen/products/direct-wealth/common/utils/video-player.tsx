import {
  Button,
  ButtonVariant,
  Icon,
  Stack,
  Text,
  XStack,
} from '@aviva/ion-mobile';
import { TranscriptDropdown } from '@aviva/ion-mobile/components/transcript-dropdown';
import { BrightCoveVideo } from '@src/components/bright-cove-video';
import { ScrollableScreen } from '@src/components/scrollable-screen';

import { useVideoPlayerViewModel } from './use-video-player-view-model';
import { ContentContainer, PageTitle } from './video-player.style';

type VideoPlayerScreenProps = {
  model: ReturnType<typeof useVideoPlayerViewModel>;
};

export const VideoPlayerScreenView = ({ model }: VideoPlayerScreenProps) => {
  return (
    <ScrollableScreen>
      <ContentContainer>
        <PageTitle>{model.videoTitle}</PageTitle>
        <BrightCoveVideo
          testID="brightcove-player"
          source={{ uri: model.videoUri }}
          allowsFullscreenVideo
          useProgressBar={false}
        />
        <TranscriptDropdown
          noBorder
          bottomBorderRadius={5}
          borderColor="$Gray200"
          borderWidth={0.5}
          title={
            <XStack space="$md">
              <Icon name={'file-text'} />
              <Text fontVariant={'heading5-semibold-Tertiary800'}>
                {'Transcript'}
              </Text>
            </XStack>
          }
          onPress={model.toggleTranscriptOpen}
          isExpanded={model.isTranscriptOpen}
          content={
            <Stack paddingTop="$xxl">
              <Text fontVariant="body-regular-Gray800">{model.transcript}</Text>
              {model.isTranscriptOpen && (
                <Stack jc="center">
                  <Button
                    testID="close-transcript"
                    accessibilityRole="button"
                    accessibilityLabel="Close transcript"
                    onPress={model.toggleTranscriptOpen}
                    variant={ButtonVariant.LINK_TEXT}
                  >
                    {'Close transcript'}
                  </Button>
                </Stack>
              )}
            </Stack>
          }
          selectedIndex={0}
          index={0}
        />
      </ContentContainer>
    </ScrollableScreen>
  );
};

export const VideoPlayerScreen = () => {
  const model = useVideoPlayerViewModel();

  return <VideoPlayerScreenView model={model} />;
};
