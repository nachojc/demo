import { useToggle } from '@hooks/use-toggle';
import { useAppStackRoute } from '@src/navigation/app/hooks';

export const useVideoPlayerViewModel = () => {
  const route = useAppStackRoute<'Video Player'>();
  const {
    title: videoTitle,
    uri: videoUri,
    transcript: transcript,
  } = route.params;

  const [isTranscriptOpen, toggleTranscriptOpen] = useToggle(false);

  return {
    videoTitle,
    videoUri,
    transcript,
    isTranscriptOpen,
    toggleTranscriptOpen,
  };
};
