import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { WebViewComponent } from '@src/components/web-view';
import { AppStackRouteParams } from '@src/navigation/app';

type Props = NativeStackScreenProps<AppStackRouteParams, 'Web View'>;

export const ExternalWebview = ({ route }: Props) => {
  const {
    url: uri,
    ssoEnabled = false,
    appendVisitorInfoEnabled = true,
  } = route.params;
  return (
    <WebViewComponent
      ssoEnabled={ssoEnabled}
      appendVisitorInfoEnabled={appendVisitorInfoEnabled}
      source={{
        uri,
      }}
    />
  );
};
