import { styled, TamaguiText, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

export const PageTitle = styled(TamaguiText, {
  color: '$Gray800',
  fontWeight: '600',
  fontSize: '$heading4',
  fontFamily: '$heading',
  pb: '$md',
});

export const ContentContainer = styled(YStack, {
  px: '$xl',
  tablet: isIpad,
});
