import { SimpleWealthSuitabilityReportModel } from '@direct-wealth/models/simple-wealth-suitability-report';
import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

type GetSimpleWealthSuitabilityReportResult = Awaited<
  ReturnType<
    InstanceType<
      typeof SimpleWealthSuitabilityReportModel
    >['getSuitabilityReport']
  >
>;

type SimpleWealthSuitabilityReportQueryResult = UseQueryResult<
  GetSimpleWealthSuitabilityReportResult,
  unknown
>;

type UseSimpleWealthSuitabilityReportReturn = [
  simpleWealthSuitabilityReport: SimpleWealthSuitabilityReportQueryResult['data'],
  queryResults: Omit<SimpleWealthSuitabilityReportQueryResult, 'data'>
];

const log = getLogger(useSimpleWealthSuitabilityReport.name);

export function useSimpleWealthSuitabilityReport(
  secureSuitabilityReportId: string,
  enabled = true
): UseSimpleWealthSuitabilityReportReturn {
  const { data: simpleWealthSuitabilityReport, ...rest } = useQuery({
    queryKey: [['simpleWealthSuitabilityReport']] as const,
    queryFn: () =>
      new SimpleWealthSuitabilityReportModel().getSuitabilityReport(
        secureSuitabilityReportId
      ),
    onError: (e) => {
      log.apiError(e);
    },
    enabled,
  });

  return [simpleWealthSuitabilityReport, rest];
}
