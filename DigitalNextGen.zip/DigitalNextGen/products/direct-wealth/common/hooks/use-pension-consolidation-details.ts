import { PensionConsolidationDetailsModel } from '@direct-wealth/models/pension-consolidation-details';
import { getLogger } from '@interfaces/logger';
import { useQuery } from '@tanstack/react-query';

const log = getLogger(usePensionConsolidationDetails.name);

export function usePensionConsolidationDetails(secureId?: string) {
  return useQuery({
    queryKey: ['pensionConsolidationDetails', secureId],
    queryFn: () =>
      new PensionConsolidationDetailsModel().fetchPensionConsolidationDetails(
        secureId
      ),
    enabled: !!secureId,
    onError: (e) => {
      log.apiError(e);
    },
  });
}
