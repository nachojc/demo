import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import {
  TransactionHistoryModel,
  TransactionHistoryType,
} from '../../models/transaction-history';

type FetchTransactionHistoryResult = Awaited<
  ReturnType<
    InstanceType<typeof TransactionHistoryModel>['fetchTransactionHistory']
  >
>;

type TransactionHistoryQueryResult = UseQueryResult<
  FetchTransactionHistoryResult,
  unknown
>;

type UseEditorialContentReturn = [
  transactionHistory: TransactionHistoryQueryResult['data'],
  queryResults: Omit<TransactionHistoryQueryResult, 'data'>
];

const log = getLogger(useTransactionHistory.name);

export function useTransactionHistory(
  securePolicyNumber: string,
  transactionHistoryType: TransactionHistoryType,
  page: number,
  filters?: string[]
): UseEditorialContentReturn {
  const { data: transactionHistory, ...rest } = useQuery({
    queryKey: [
      'transactionHistory',
      securePolicyNumber,
      transactionHistoryType,
      page,
      filters,
    ] as const,
    queryFn: () =>
      new TransactionHistoryModel().fetchTransactionHistory(
        securePolicyNumber,
        transactionHistoryType,
        page,
        filters
      ),
    onError: (e) => {
      log.apiError(e);
    },
  });

  return [transactionHistory, rest];
}
