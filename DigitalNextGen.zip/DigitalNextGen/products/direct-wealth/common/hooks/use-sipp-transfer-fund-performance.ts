import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import { SIPPTransferFundPerformanceModel } from '../../models/sipp-transfer-fund-performance';

export const ChartTimescales = [
  'SixMonths',
  'OneYear',
  'YearToDate',
  'FiveYear',
] as const;

export type ChartTimescale = (typeof ChartTimescales)[number];

type FetchSIPPTransferFundPerformanceResult = Awaited<
  ReturnType<
    InstanceType<
      typeof SIPPTransferFundPerformanceModel
    >['fetchSIPPTransferFundPerformance']
  >
>;

type SIPPTransferFundPerformanceQueryResult = UseQueryResult<
  FetchSIPPTransferFundPerformanceResult,
  unknown
>;

type UseSIPPTransferFundPerformanceReturn = [
  content: SIPPTransferFundPerformanceQueryResult['data'],
  queryResults: Omit<SIPPTransferFundPerformanceQueryResult, 'data'>
];

const log = getLogger(useSIPPTransferFundPerformance.name);

export function useSIPPTransferFundPerformance(
  fundId: string
): UseSIPPTransferFundPerformanceReturn {
  const { data: content, ...rest } = useQuery({
    queryKey: ['sippTransferFundPerformance', fundId] as const,
    queryFn: () =>
      new SIPPTransferFundPerformanceModel().fetchSIPPTransferFundPerformance(
        fundId
      ),
    onError: (e) => {
      log.apiError(e);
    },
  });

  return [content, rest];
}
