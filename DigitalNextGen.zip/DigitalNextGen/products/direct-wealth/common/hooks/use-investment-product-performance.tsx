import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import { InvestmentProductPerformanceModel } from '../../models/investment-product-performance';

export const ChartTimescales = [
  'OneMonth',
  'SixMonths',
  'OneYear',
  'YearToDate',
  'SinceInception',
] as const;

export type ChartTimescale = (typeof ChartTimescales)[number];

type FetchInvestmentProductPerformance = Awaited<
  ReturnType<
    InstanceType<
      typeof InvestmentProductPerformanceModel
    >['fetchInvestmentProductPerformance']
  >
>;

export type InvestmentProductPerformanceQueryResult = UseQueryResult<
  FetchInvestmentProductPerformance,
  unknown
>;

type UseInvestmentProductPerformanceReturn = [
  investmentProductPerformance: InvestmentProductPerformanceQueryResult['data'],
  queryResults: Omit<InvestmentProductPerformanceQueryResult, 'data'>
];

const log = getLogger(useInvestmentProductPerformance.name);

export function useInvestmentProductPerformance(
  securePolicyNumber: string,
  timescale: ChartTimescale
): UseInvestmentProductPerformanceReturn {
  const { data: investmentProductPerformance, ...rest } = useQuery({
    queryKey: [
      ['investmentProductPerformance', securePolicyNumber, timescale],
    ] as const,
    queryFn: () =>
      new InvestmentProductPerformanceModel().fetchInvestmentProductPerformance(
        securePolicyNumber,
        timescale
      ),
    onError: (e) => {
      log.apiError(e);
    },
  });

  return [investmentProductPerformance, rest];
}
