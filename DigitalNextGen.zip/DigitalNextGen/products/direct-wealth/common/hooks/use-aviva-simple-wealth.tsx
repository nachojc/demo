import { AvivaSimpleWealthModel } from '@direct-wealth/models/aviva-simple-wealth';
import { AvivaSimpleWealth } from '@direct-wealth/validation/schemas/aviva-simple-wealth';
import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

type FetchAvivaSimpleWealthResult = Awaited<
  ReturnType<
    InstanceType<typeof AvivaSimpleWealthModel>['fetchAvivaSimpleWealth']
  >
>;

type AvivaSimpleWealthQueryResult = UseQueryResult<
  FetchAvivaSimpleWealthResult,
  unknown
>;

type UseAvivaSimpleWealthReturn = [
  avivaSimpleWealth: AvivaSimpleWealth,
  queryResults: Omit<AvivaSimpleWealthQueryResult, 'data'>
];

const log = getLogger(useAvivaSimpleWealth.name);

export function useAvivaSimpleWealth(
  enabled = true
): UseAvivaSimpleWealthReturn {
  const { data: avivaSimpleWealth, ...rest } = useQuery({
    queryKey: [['avivaSimpleWealth']] as const,
    queryFn: () => new AvivaSimpleWealthModel().fetchAvivaSimpleWealth(),
    onError: (e) => {
      log.apiError(e);
    },
    enabled,
  });

  return [avivaSimpleWealth as AvivaSimpleWealth, rest];
}
