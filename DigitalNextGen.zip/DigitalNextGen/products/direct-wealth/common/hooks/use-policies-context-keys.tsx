import { observable } from '@legendapp/state';
import { useObserveEffect } from '@legendapp/state/react';
import { Products } from '@src/validation/schemas/product/products';
import { useRef } from 'react';

export type PoliciesContextKeys = {
  numOfPolicies: string;
  numPolTypes: string;
  policyId?: string;
  prodName?: string;
  prodNameStatus?: string;
  pensionProvider?: string;
};

const PoliciesContextKeysContextInitialState: PoliciesContextKeys = {
  numOfPolicies: '0',
  numPolTypes: '0',
  policyId: undefined,
  prodName: undefined,
  prodNameStatus: undefined,
  pensionProvider: undefined,
};

const policiesContextKeysObservable = observable<PoliciesContextKeys>(
  PoliciesContextKeysContextInitialState
);

const getCountsValue = (policies: Products[]) => {
  const polTypes = new Set(policies.map((policy) => policy.ProductType));

  return {
    numOfPolicies: policies.length.toString(),
    numPolTypes: polTypes.size.toString(),
  };
};

const getPoliciesContextKeys = () => {
  const keys = policiesContextKeysObservable.get();
  return keys?.policyId && keys?.prodName ? keys : {};
};

/*
 * This hook exposes the policiesContextKeysObservable state
 * and some helpers to set and update the different part of it,
 * the observable should be used just through this hook.
 */
export const usePoliciesContextKeys = () => {
  const policiesContextKeysRef = useRef(getPoliciesContextKeys());
  useObserveEffect(policiesContextKeysObservable, () => {
    policiesContextKeysRef.current = getPoliciesContextKeys();
  });

  /*
   * setPoliciesCountContextKeys sets numOfPolicies and numPolTypes context keys on
   * portfolio-summary-view, it also unsets policyId and prodName.
   * At the moment the only way to get out of a product journey
   * is to pass by portfolio-summary-view so policyId and prodName are cleared there
   * as it is the entry point of the journey.
   */
  const setPoliciesCountContextKeys = (policies: Products[]) => {
    const { numOfPolicies, numPolTypes } = getCountsValue(policies);

    policiesContextKeysObservable.set({
      numOfPolicies,
      numPolTypes,
      policyId: undefined,
      prodName: undefined,
      prodNameStatus: undefined,
      pensionProvider: undefined,
    });
  };
  /*
   * setProdDetails set policyId and prodName when the user navigate to
   * a product dashboard.
   */
  const setProdDetails = ({
    policyId,
    prodName,
    prodNameStatus,
    pensionProvider,
  }: {
    policyId: string;
    prodName: string;
    prodNameStatus?: string;
    pensionProvider?: string;
  }) => {
    policiesContextKeysObservable.set((prev) => ({
      ...prev,
      policyId,
      prodName,
      prodNameStatus,
      pensionProvider,
    }));
  };

  /*
   * function to remove the observable on logout
   */
  const deletePoliciesContextKeysObservable = () => {
    policiesContextKeysObservable.delete();
  };

  return {
    /*
     * This condition makes sure the context keys are set just when
     * we are inside the product journey (when policyId and prodName),
     * if they are not then we return an empty object.
     */
    policiesContextKeysRef,
    setPoliciesCountContextKeys,
    setProdDetails,
    deletePoliciesContextKeysObservable,
  };
};
