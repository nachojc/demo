import { FindAndCombineCustomerDetailsModel } from '@direct-wealth/models/find-and-combine-customer-details';
import { getLogger } from '@interfaces/logger';
import { useQuery } from '@tanstack/react-query';

const log = getLogger(useFindAndCombineCustomerDetails.name);

export function useFindAndCombineCustomerDetails(isLazyQuery = false) {
  return useQuery({
    queryKey: ['findAndCombineCustomerDetails'] as const,
    queryFn: () =>
      new FindAndCombineCustomerDetailsModel().fetchFindAndCombineCustomerDetails(),
    onError: (e) => {
      log.apiError(e);
    },
    enabled: !isLazyQuery,
  });
}
