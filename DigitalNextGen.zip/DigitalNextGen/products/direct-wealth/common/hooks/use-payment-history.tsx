import { useQuery, UseQueryResult } from '@tanstack/react-query';

import { getLogger } from '../../../../src/common/interfaces/logger';
import { PaymentHistoryModel } from '../../models/payment-history';

type FetchPaymentHistoryResult = Awaited<
  ReturnType<InstanceType<typeof PaymentHistoryModel>['fetchPaymentHistory']>
>;

type PaymentHistoryQueryResult = UseQueryResult<
  FetchPaymentHistoryResult,
  unknown
>;

type UsePaymentHistoryReturn = [
  paymentHistory: PaymentHistoryQueryResult['data'],
  queryResults: Omit<PaymentHistoryQueryResult, 'data'>
];

const log = getLogger(usePaymentHistory.name);

export function usePaymentHistory(
  secureAccountNumber?: string
): UsePaymentHistoryReturn {
  const { data: paymentHistory, ...rest } = useQuery({
    queryKey: ['paymentHistory', secureAccountNumber] as const,
    queryFn: () =>
      new PaymentHistoryModel().fetchPaymentHistory(secureAccountNumber),
    onError: (e) => {
      log.apiError(e);
    },
    retry: false,
  });

  return [paymentHistory, rest];
}
