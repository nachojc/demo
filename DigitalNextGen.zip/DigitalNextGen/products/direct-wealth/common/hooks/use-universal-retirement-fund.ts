import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import { SippTransferFundsModel } from '../../models/sipp-transfer-funds';

type FetchUniversalRetirementFundResult = Awaited<
  ReturnType<InstanceType<typeof SippTransferFundsModel>['fetchUniversalFund']>
>;

type UniversalRetirementFundsQueryResult = UseQueryResult<
  FetchUniversalRetirementFundResult,
  unknown
>;

type UseUniversalRetirementFund = [
  content: UniversalRetirementFundsQueryResult['data'],
  queryResults: Omit<UniversalRetirementFundsQueryResult, 'data'>
];

const log = getLogger(useUniversalRetirementFund.name);

export function useUniversalRetirementFund(
  retirementAge: number
): UseUniversalRetirementFund {
  const { data: content, ...rest } = useQuery({
    enabled: false,
    queryKey: ['universalRetirementFund', retirementAge] as const,
    queryFn: () =>
      new SippTransferFundsModel().fetchUniversalFund(retirementAge),
    onError: (e) => {
      log.apiError(e);
    },
  });

  return [content, rest];
}
