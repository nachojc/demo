import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import {
  EditorialContentModel,
  UserUnderstanding,
} from '../../models/editorial-content';

type FetchEditorialContentResult = Awaited<
  ReturnType<
    InstanceType<typeof EditorialContentModel>['fetchEditorialContent']
  >
>;

type EditorialContentQueryResult = UseQueryResult<
  FetchEditorialContentResult,
  unknown
>;

const log = getLogger(useEditorialContent.name);

export function useEditorialContent(
  context?: string,
  userUnderstanding?: UserUnderstanding
): EditorialContentQueryResult {
  return useQuery({
    queryKey: ['editorialContent', context, userUnderstanding] as const,
    queryFn: () =>
      new EditorialContentModel().fetchEditorialContent(
        context,
        userUnderstanding
      ),
    onError: (e) => {
      log.apiError(e);
    },
  });
}
