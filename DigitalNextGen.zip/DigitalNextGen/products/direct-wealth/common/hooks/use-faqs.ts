import { FAQsModel } from '@direct-wealth/models/faqs';
import { FAQContext } from '@direct-wealth/validation/schemas/faqs';
import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

type FetchFAQsResult = Awaited<
  ReturnType<InstanceType<typeof FAQsModel>['fetchFAQs']>
>;

type FAQsQueryResult = UseQueryResult<FetchFAQsResult, unknown>;

const log = getLogger(useFAQs.name);

export function useFAQs(context?: FAQContext): FAQsQueryResult {
  return useQuery({
    queryKey: ['faqs', context] as const,
    queryFn: () => new FAQsModel().fetchFAQs(context),
    onError: (e) => {
      log.error(e);
      log.apiError(e);
    },
  });
}
