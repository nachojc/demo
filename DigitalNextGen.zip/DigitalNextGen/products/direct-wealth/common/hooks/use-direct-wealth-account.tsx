import { DirectWealthAccount } from '@direct-wealth/validation/schemas/direct-wealth-account';
import { getLogger } from '@interfaces/logger';
import { useQueries, useQuery, UseQueryResult } from '@tanstack/react-query';

import { DirectWealthAccountModel } from '../../models/direct-wealth-account';

type FetchDirectWealthAccountResult = Awaited<
  ReturnType<
    InstanceType<typeof DirectWealthAccountModel>['fetchDirectWealthAccount']
  >
>;

export type DirectWealthAccountQueryResult = UseQueryResult<
  FetchDirectWealthAccountResult,
  unknown
>;

const log = getLogger(useDirectWealthAccount.name);

export function useDirectWealthAccount(secureAccountNumber?: string) {
  return useQuery({
    queryKey: ['directWealthAccount', secureAccountNumber] as const,
    queryFn: () =>
      new DirectWealthAccountModel().fetchDirectWealthAccount(
        secureAccountNumber
      ),
    onError: (e) => {
      log.apiError(e);
    },
    enabled: !!secureAccountNumber,
  });
}

type UseDirectWealthMiltiAccountsReturn = {
  accounts: DirectWealthAccount[];
  isLoading: boolean;
  error: unknown[];
};

export const useDirectWealthMultiAccounts = (
  secureAccountNumbers?: (string | undefined)[]
): UseDirectWealthMiltiAccountsReturn => {
  const results = useQueries({
    queries: (secureAccountNumbers || [])
      .filter((item) => !!item)
      .map((secureAccountNumber) => ({
        queryKey: ['directWealthAccount', secureAccountNumber] as const,
        queryFn: () =>
          new DirectWealthAccountModel().fetchDirectWealthAccount(
            secureAccountNumber
          ),
        onError: (e: unknown) => {
          log.error({ secureAccountNumber, e });
        },
        enabled: !!secureAccountNumber,
      })),
  });

  return {
    accounts: results.map(
      (result) => result.data as unknown as DirectWealthAccount
    ),
    isLoading: results.some((result) => result.isLoading),
    error: results.map((result) => result.error),
  };
};
