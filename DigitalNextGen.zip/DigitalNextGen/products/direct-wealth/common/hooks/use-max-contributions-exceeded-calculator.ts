import { getYear, intervalToDuration, isBefore } from 'date-fns';

type MaxContributionsExceedCalulator = {
  maximumDeposit: number;
  deposit: number | undefined;
  monthlyPayment: number | undefined;
};
export const useMaxContributionsExceededCalculator = () => {
  const maxContributionExceeded = ({
    maximumDeposit,
    deposit = 0,
    monthlyPayment = 0,
  }: MaxContributionsExceedCalulator) => {
    const currentDate = new Date();
    const currentYear = getYear(currentDate);
    const nextTaxYearStart = new Date(currentYear, 3, 5);

    const isBeforeCurrentYearApril = isBefore(currentDate, nextTaxYearStart);
    const yearOfTaxYearEnd = isBeforeCurrentYearApril
      ? currentYear
      : currentYear + 1;

    const monthsUntil5thApril = intervalToDuration({
      start: currentDate,
      end: new Date(yearOfTaxYearEnd, 3, 5),
    }).months;

    if (monthsUntil5thApril === undefined) {
      return false;
    }

    const monthlyMultipler =
      monthsUntil5thApril === 0 ? 1 : Number(monthsUntil5thApril);

    const totalThisTaxYear = deposit + monthlyPayment * monthlyMultipler;
    const isOverAllowedIsaAmount = totalThisTaxYear > maximumDeposit;

    return isOverAllowedIsaAmount;
  };

  return {
    maxContributionExceeded,
  };
};
