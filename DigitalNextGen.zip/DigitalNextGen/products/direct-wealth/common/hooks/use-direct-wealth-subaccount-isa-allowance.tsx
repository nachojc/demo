import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import { DirectWealthSubaccountISAAllowanceModel } from '../../models/direct-wealth-subaccount-isa-allowance';

type FetchDirectWealthSubaccountISAAllowanceResult = Awaited<
  ReturnType<
    InstanceType<
      typeof DirectWealthSubaccountISAAllowanceModel
    >['fetchDirectWealthSubaccountISAAllowance']
  >
>;

export type DirectWealthSubaccountQueryResult = UseQueryResult<
  FetchDirectWealthSubaccountISAAllowanceResult,
  unknown
>;

const log = getLogger(useDirectWealthSubaccountISAAllowance.name);

export function useDirectWealthSubaccountISAAllowance(
  securePolicyNumber: string,
  accountType?: string
): DirectWealthSubaccountQueryResult {
  return useQuery({
    queryKey: [
      ['directWealthSubAccountISAAllowance', securePolicyNumber],
    ] as const,
    queryFn: () =>
      new DirectWealthSubaccountISAAllowanceModel().fetchDirectWealthSubaccountISAAllowance(
        securePolicyNumber
      ),
    onError: (e) => {
      log.apiError(e);
    },
    enabled: !!securePolicyNumber && accountType === 'ISA',
  });
}
