import { usePostSimpleWealthAccountInfo } from '@direct-wealth/features/simple-wealth/simple-wealth-hub/use-post-simple-wealth-account-info';
import { AvivaSimpleWealth } from '@direct-wealth/validation/schemas/aviva-simple-wealth';
import { hasStartedNavigatorJourney } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { FeatureFlags } from '@src/feature-flags';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { QueryObserverResult } from '@tanstack/react-query';
import { differenceInCalendarDays } from 'date-fns';
import { Dispatch, SetStateAction, useEffect, useState } from 'react';

import { useAvivaSimpleWealth } from './use-aviva-simple-wealth';

export type SimpleWealthOnboardingCardStatus =
  | 'initial'
  | 'started'
  | 'hasAdvice';

type IsEligbileForSimpleWealthJourney = {
  simpleWealthGetIsLoading: boolean;
  isSimpleWealthGetApiError: boolean;
  isAccountApiError: boolean;
  setIsAccountApiError: Dispatch<SetStateAction<boolean>>;
  isSimpleWealthEnabled: boolean;
  simpleWealthOnboardingCardStatus: SimpleWealthOnboardingCardStatus;
  daysToAdviceExpiry: number;
  hasOpportunity: boolean;
  hasDigitalAdvice: boolean;
  amount: number;
  simpleWealthCardPressed: () => Promise<void>;
  simpleWealthGetApiRefetch: () => Promise<
    QueryObserverResult<AvivaSimpleWealth, unknown>
  >;
};

export const useInitialiseSimpleWealthJourney =
  (): IsEligbileForSimpleWealthJourney => {
    const { navigate } = useAppStackNavigation();
    const { submitPostNavAccountInfo } = usePostSimpleWealthAccountInfo();
    const [isSimpleWealthGetApiError, setIsSimpleWealthGetApiError] =
      useState(false);
    const [isAccountApiError, setIsAccountApiError] = useState(false);
    const [accountCreated, setAccountCreated] = useState(false);
    const [simpleWealthGetIsLoading, setSimpleWealthGetIsLoading] =
      useState(false);

    let isSimpleWealthEnabled = false;
    let simpleWealthOnboardingCardStatus: SimpleWealthOnboardingCardStatus =
      'initial';
    let daysToAdviceExpiry = 0;
    let hasOpportunity = false;
    let hasDigitalAdvice = false;
    let amount = 0;

    const simpleWealthStarted = useSelector(hasStartedNavigatorJourney);
    const isSimpleWealthEnabledFeatureFlag = useSelector(
      FeatureFlags.dwSimpleWealthEnabled
    );
    const isSimpleWealthIgnoreEligibilityFeatureFlag = useSelector(
      FeatureFlags.dwIsaApplySimpleWealthIgnoreEligibility
    );

    const [
      avivaSimpleWealth,
      {
        isError: simpleWealthGetIsError,
        refetch: simpleWealthGetApiRefetch,
        isRefetchError,
      },
    ] = useAvivaSimpleWealth(isSimpleWealthEnabledFeatureFlag);

    useEffect(() => {
      if (simpleWealthGetIsError) {
        setIsSimpleWealthGetApiError(true);
      }
    }, [simpleWealthGetIsError]);

    if (isSimpleWealthEnabledFeatureFlag) {
      isSimpleWealthEnabled =
        avivaSimpleWealth?.isEligbileForNavigatorJourney ||
        isSimpleWealthIgnoreEligibilityFeatureFlag;

      simpleWealthOnboardingCardStatus =
        simpleWealthStarted ||
        avivaSimpleWealth?.questionnaireResponses?.responses
          ? 'started'
          : 'initial';

      if (avivaSimpleWealth?.digitalAdvice) {
        simpleWealthOnboardingCardStatus = 'hasAdvice';
        daysToAdviceExpiry = avivaSimpleWealth?.digitalAdvice?.expiryDate
          ? differenceInCalendarDays(
              new Date(avivaSimpleWealth?.digitalAdvice?.expiryDate),
              new Date()
            )
          : 0;
      }

      if (daysToAdviceExpiry < 0) {
        simpleWealthOnboardingCardStatus = 'initial';
      }

      if (avivaSimpleWealth?.person?.opportunity) {
        hasOpportunity = true;
      }

      if (avivaSimpleWealth?.digitalAdvice) {
        hasDigitalAdvice = true;
      }

      if (avivaSimpleWealth?.hybridAdvicePrice) {
        amount = avivaSimpleWealth?.hybridAdvicePrice;
      }
    }

    const startSimpleWealthJourney = (userHasDigitalAdvice: boolean) => {
      if (userHasDigitalAdvice) {
        navigate('SimpleWealthStack', {
          screen: 'PostPaymentHub',
        });
      } else if (simpleWealthOnboardingCardStatus === 'started') {
        navigate('SimpleWealthStack', {
          screen: 'SimpleWealthHub',
        });
      } else {
        navigate('SimpleWealthStack', {
          screen: 'OnboardingInformationScreen',
          params: { removeContinueButton: false, amount },
        });
      }
    };

    const simpleWealthCardPressed = async () => {
      try {
        setSimpleWealthGetIsLoading(true);
        const { data: refetchData } = await simpleWealthGetApiRefetch();

        if (isRefetchError || simpleWealthGetIsError) {
          setSimpleWealthGetIsLoading(false);
          setIsSimpleWealthGetApiError(true);
          return;
        }
        if (refetchData) {
          setSimpleWealthGetIsLoading(false);
          setIsAccountApiError(false);
          const hasAdvice = !!refetchData.digitalAdvice;
          const userHasOpportunity = !!refetchData.person?.opportunity;
          if (userHasOpportunity || accountCreated) {
            startSimpleWealthJourney(hasAdvice);
          } else if (!accountCreated) {
            setSimpleWealthGetIsLoading(true);
            const accountCreationSuccessful = await submitPostNavAccountInfo();
            if (accountCreationSuccessful) {
              setSimpleWealthGetIsLoading(false);
              setAccountCreated(true);
              startSimpleWealthJourney(hasAdvice);
            } else {
              setIsAccountApiError(true);
              setSimpleWealthGetIsLoading(false);
            }
          }
        }
      } catch (error) {
        setSimpleWealthGetIsLoading(false);
        setIsSimpleWealthGetApiError(true);
      }
    };

    return {
      isSimpleWealthGetApiError,
      isAccountApiError,
      setIsAccountApiError,
      simpleWealthGetIsLoading,
      simpleWealthGetApiRefetch,
      isSimpleWealthEnabled,
      simpleWealthOnboardingCardStatus,
      daysToAdviceExpiry,
      hasOpportunity,
      hasDigitalAdvice,
      amount,
      simpleWealthCardPressed,
    };
  };
