import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import { SippTransferFundsModel } from '../../models/sipp-transfer-funds';

type FetchSippTransferFundsResult = Awaited<
  ReturnType<
    InstanceType<typeof SippTransferFundsModel>['fetchSippTransferFunds']
  >
>;

type SippTransferFundsQueryResult = UseQueryResult<
  FetchSippTransferFundsResult,
  unknown
>;

type UseSippTransferFundsReturn = [
  content: SippTransferFundsQueryResult['data'],
  queryResults: Omit<SippTransferFundsQueryResult, 'data'>
];

const log = getLogger(useSippTransferFunds.name);

export function useSippTransferFunds(): UseSippTransferFundsReturn {
  const { data: content, ...rest } = useQuery({
    enabled: false,
    queryKey: ['readyMadeFunds'] as const,
    queryFn: () => new SippTransferFundsModel().fetchSippTransferFunds(),
    onError: (e) => {
      log.apiError(e);
    },
  });

  return [content, rest];
}
