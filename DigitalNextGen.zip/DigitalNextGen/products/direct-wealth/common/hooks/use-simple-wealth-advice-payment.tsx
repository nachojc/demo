import {
  SimpleWealthAdvicePayment,
  SimpleWealthAdvicePaymentRequest,
} from '@direct-wealth/models/simple-wealth-advice-payment';
import { useMutation } from '@tanstack/react-query';

export const useSimpleWealthAdvicePayment = () => {
  const { mutateAsync: submitPayment } = useMutation({
    mutationKey: ['simple-wealth-advice-payment'] as const,
    mutationFn: (paymentRequest: SimpleWealthAdvicePaymentRequest) =>
      new SimpleWealthAdvicePayment().makePayment(paymentRequest),
  });

  return { submitPayment };
};
