import { PensionConsolidationSummaryModel } from '@direct-wealth/models/pension-consolidation-summary';
import { useCustomer } from '@hooks/use-customer';
import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

type FetchPensionConsolidationSummaryResult = Awaited<
  ReturnType<
    InstanceType<
      typeof PensionConsolidationSummaryModel
    >['fetchPensionConsolidationSummary']
  >
>;

type PensionConsolidationSummaryQueryResult = UseQueryResult<
  FetchPensionConsolidationSummaryResult,
  unknown
>;

type UsePensionConsolidationSummaryReturn = [
  data: PensionConsolidationSummaryQueryResult['data'],
  queryResults: Omit<PensionConsolidationSummaryQueryResult, 'data'>
];

const log = getLogger(usePensionConsolidationSummary.name);

export function usePensionConsolidationSummary(): UsePensionConsolidationSummaryReturn {
  const customer = useCustomer();
  const isCustomerDpa1 = customer.data?.CustomerDPALevel === '1';
  const { data, ...rest } = useQuery({
    queryKey: ['pensionConsolidationSummary'] as const,
    queryFn: () =>
      new PensionConsolidationSummaryModel().fetchPensionConsolidationSummary(),
    onError: (e) => {
      log.apiError(e);
    },
    enabled: !isCustomerDpa1,
  });

  return [data, rest];
}
