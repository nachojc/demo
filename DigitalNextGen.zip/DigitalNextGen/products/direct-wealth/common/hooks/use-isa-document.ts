import { IsaDocumentModel } from '@direct-wealth/models/isa-document-id';
import { getLogger } from '@interfaces/logger';
import { useQuery } from '@tanstack/react-query';

type UseIsaDocumentReturn = {
  isSuccess: boolean;
  isError: boolean;
};

const log = getLogger(useIsaDocument.name);

export function useIsaDocument(
  id: string,
  enabled: boolean
): UseIsaDocumentReturn {
  const { isSuccess, isError } = useQuery({
    queryKey: ['id', id] as const,
    queryFn: () => new IsaDocumentModel().fetchIsaDocument(id),
    onError: (e) => {
      log.apiError(e);
    },
    enabled,
  });

  return { isSuccess, isError };
}
