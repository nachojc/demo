import { getLogger } from '@interfaces/logger';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

import { DirectWealthSubaccountModel } from '../../models/direct-wealth-subaccount';

type FetchDirectWealthSubaccountResult = Awaited<
  ReturnType<
    InstanceType<
      typeof DirectWealthSubaccountModel
    >['fetchDirectWealthSubaccount']
  >
>;

type DirectWealthSubaccountQueryResult = UseQueryResult<
  FetchDirectWealthSubaccountResult,
  unknown
>;

const log = getLogger(useDirectWealthSubaccount.name);

export function useDirectWealthSubaccount(
  securePolicyNumber: string
): DirectWealthSubaccountQueryResult {
  return useQuery({
    queryKey: [['directWealthSubaccount', securePolicyNumber]] as const,
    queryFn: () =>
      new DirectWealthSubaccountModel().fetchDirectWealthSubaccount(
        securePolicyNumber
      ),
    onError: (e) => {
      log.apiError(e);
    },
    enabled: !!securePolicyNumber,
  });
}
