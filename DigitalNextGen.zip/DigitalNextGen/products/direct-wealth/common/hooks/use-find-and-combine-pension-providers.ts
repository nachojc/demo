import { FindAndCombinePensionProvidersModel } from '@direct-wealth/models/find-and-combine-pension-providers';
import { getLogger } from '@interfaces/logger';
import { useQuery } from '@tanstack/react-query';

const log = getLogger(useFindAndCombinePensionProviders.name);

export function useFindAndCombinePensionProviders(isLazyQuery = false) {
  return useQuery({
    queryKey: ['findAndCombinePensionProviders'] as const,
    queryFn: () =>
      new FindAndCombinePensionProvidersModel().fetchFindAndCombinePensionProviders(),
    onError: (e) => {
      log.apiError(e);
    },
    enabled: !isLazyQuery,
  });
}
