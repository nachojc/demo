import { Button, ButtonVariant, Dialog, Icon, YStack } from '@aviva/ion-mobile';
import { PAGE_WEALTH } from '@constants/analytics';
import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { useCallback } from 'react';

import {
  EXIT_DIALOG,
  EXIT_DIALOG_CANCEL_TAPPED,
  EXIT_DIALOG_CONTINUE_TAPPED,
} from './analytics';

export const ExitWarningDialog = ({
  analyticsTag,
  isVisible,
  onCancel,
  onContinue,
}: {
  analyticsTag: string;
  isVisible: boolean;
  onCancel: () => void;
  onContinue: () => void;
}) => {
  const { trackUserEvent } = useAnalytics();
  const PAGE_TAG = `${PAGE_WEALTH}|${analyticsTag}|`;
  useTrackStateEvent(`${PAGE_TAG}${EXIT_DIALOG}`);

  const { t } = useTranslationDW({
    keyPrefix: 'exitWarningDialog',
  });

  const handleContinue = useCallback(() => {
    trackUserEvent(`${PAGE_TAG}${EXIT_DIALOG_CONTINUE_TAPPED}`);
    onContinue();
  }, [onContinue, PAGE_TAG, trackUserEvent]);

  const handleCancel = useCallback(() => {
    trackUserEvent(`${PAGE_TAG}${EXIT_DIALOG_CANCEL_TAPPED}`);
    onCancel();
  }, [onCancel, PAGE_TAG, trackUserEvent]);

  return (
    <Dialog
      open={isVisible}
      title={t('title')}
      copy={t('description')}
      center
      icon={
        <Icon
          accessible={false}
          color={tokens.color.Error.val}
          height={tokens.size[6].val}
          name={'alert-circle'}
          width={tokens.size[6].val}
        />
      }
    >
      <YStack marginTop="$xl" gap="$md">
        <Button
          variant={ButtonVariant.BRAND}
          onPress={handleContinue}
          accessibilityHint="Exit the journey"
        >
          {t('continueCTA')}
        </Button>
        <Button variant={ButtonVariant.LINK_TEXT} onPress={handleCancel}>
          {t('cancelCTA')}
        </Button>
      </YStack>
    </Dialog>
  );
};
