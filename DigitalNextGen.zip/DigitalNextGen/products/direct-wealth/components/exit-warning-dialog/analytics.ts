export const EXIT_DIALOG = 'progress-will-not-be-saved-dialog';
export const EXIT_DIALOG_CONTINUE_TAPPED = `${EXIT_DIALOG}|yes-tapped`;
export const EXIT_DIALOG_CANCEL_TAPPED = `${EXIT_DIALOG}|cancel-tapped`;
