import { styled, TamaguiText, XStack } from '@aviva/ion-mobile';
import { tokens } from '@theme/tokens';

export const Container = styled(XStack, {
  borderRadius: 99.9,
  backgroundColor: tokens.color.Gray050Opacity20,
  variants: {
    lightMode: {
      true: {
        backgroundColor: tokens.color.DWLightGrey,
      },
    },
  },
});

export const Tab = styled(XStack, {
  flex: 1,
  padding: '$md',
  borderRadius: 99.9,
  justifyContent: 'center',
  alignItems: 'center',
  variants: {
    active: {
      true: {
        backgroundColor: tokens.color.Primary500,
      },
    },
    inactive: {
      true: {},
    },
  },
});

export const TabText = styled(TamaguiText, {
  color: tokens.color.White,
  fontWeight: '500',
  fontSize: tokens.size[4],
  variants: {
    activeAndDisabled: {
      true: {
        color: tokens.color.DWPrimary500,
      },
    },
    isDisabled: {
      true: {
        color: tokens.color.WhiteOpacity50,
      },
    },
    active: {
      true: {
        color: tokens.color.DWPrimary500,
      },
    },
    lightMode: {
      true: {
        color: tokens.color.Gray900,
      },
    },
  },
});
