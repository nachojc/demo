import { getTokens } from '@aviva/ion-mobile';
import { GraphTabProps } from '@direct-wealth/components/performance-chart/chart.types';
import { useAnimatedTabs } from '@hooks/use-animated-tabs';
import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';
import Animated from 'react-native-reanimated';

import {
  ChartTimescale as InvestmentProductTimescale,
  ChartTimescales as InvestmentProductTimescales,
} from '../../common/hooks/use-investment-product-performance';
import {
  ChartTimescale as FundPerformanceTimescale,
  ChartTimescales as FundPerformanceTimescales,
} from '../../common/hooks/use-sipp-transfer-fund-performance';
import { Container, Tab, TabText } from './graph-selector-styles';

type GraphTabsProps = {
  tabs: ({
    timescale: FundPerformanceTimescale | InvestmentProductTimescale;
    onPress: (index: number) => void;
  } & Pick<GraphTabProps, 'isDisabled' | 'isLoading'>)[];
} & Pick<GraphTabProps, 'chartData' | 'lightMode'>;

export const GraphTabs = ({ tabs, chartData, lightMode }: GraphTabsProps) => {
  const tokens = getTokens();
  const { t } = useTranslation();

  const { animatedStyles, selectedTabIndex, tabWidth, handleTabSelect } =
    useAnimatedTabs();

  let a11yItems: string[] = [];

  if (Array.isArray(chartData)) {
    a11yItems = chartData.map((item) =>
      t(`pension.performance.graph.lineItem`, {
        formattedAmount: formatCurrencyValue(item.value),
        formattedDate: item.displayValue,
      })
    );
  } else {
    a11yItems =
      chartData?.dataset?.[0]?.data.map((item, i) =>
        t(`pension.performance.graph.lineItem`, {
          formattedAmount: formatCurrencyValue(item.value),
          formattedDate: chartData?.categories?.[0]?.category?.[i]?.label,
        })
      ) ?? [];
  }

  const getBorderWidth = () => {
    return lightMode ? 0 : 1;
  };

  const getBackgroundColor = () => {
    return lightMode
      ? tokens.color.Primary500.val
      : tokens.color.DWPrimary500.val;
  };

  return (
    <Container lightMode={lightMode}>
      <Animated.View
        testID="Animated Graph Bar Selector"
        style={[
          animatedStyles,
          {
            width: `${100 / tabs.length}%`,
            position: 'absolute',
            height: '100%',
            backgroundColor: isIpad ? undefined : getBackgroundColor(),
            borderWidth: isIpad ? undefined : getBorderWidth(),
            borderRadius: 99.9,
          },
        ]}
      />
      {tabs.map(({ timescale, isDisabled, isLoading, onPress }, index) => {
        const isTabActive = selectedTabIndex === index;

        const a11yTitle = t(
          `pension.performance.graph.a11yLabels.${timescale}`
        );
        const a11yNum = t(
          `pension.performance.graph.${
            isTabActive ? 'tabItemNumberSelected' : 'tabItemNumber'
          }`,
          {
            num: index + 1,
            len: tabs.length,
          }
        );
        const a11yTag = isTabActive
          ? `${a11yTitle}, ${a11yNum}, ${a11yItems}`
          : `${a11yTitle}, ${a11yNum}`;

        return (
          <Tab
            key={timescale}
            accessible
            accessibilityLabel={isLoading ? '' : a11yTag}
            accessibilityLiveRegion={
              isTabActive && !isLoading ? 'polite' : 'none'
            }
            onLayout={(event: {
              nativeEvent: { layout: { width: number } };
            }) => {
              tabWidth.current = event.nativeEvent.layout.width;
            }}
            onPress={() => {
              handleTabSelect(index);
              onPress(index);
            }}
            disabled={isDisabled}
            inactive={!isTabActive}
            active={isTabActive}
            testID={`graph-tabs-${timescale}`}
          >
            <TabText
              lightMode={lightMode}
              active={isTabActive}
              isDisabled={isDisabled}
              activeAndDisabled={isTabActive && isDisabled}
              accessibilityHint={`${
                isDisabled ? 'This button is disabled.' : ''
              }`}
            >
              {t(`pension.performance.graph.labels.${timescale}`)}
            </TabText>
          </Tab>
        );
      })}
    </Container>
  );
};

type GraphSelectorProps = {
  selectTimescale: (
    timescale: FundPerformanceTimescale | InvestmentProductTimescale
  ) => void;
  chartTimescales:
    | typeof FundPerformanceTimescales
    | typeof InvestmentProductTimescales;
} & Pick<GraphTabProps, 'chartData' | 'isDisabled' | 'isLoading' | 'lightMode'>;

export const GraphSelector = ({
  selectTimescale,
  isDisabled,
  isLoading,
  chartData,
  lightMode,
  chartTimescales,
}: GraphSelectorProps) => (
  <GraphTabs
    lightMode={lightMode}
    tabs={chartTimescales.map(
      (timescale: FundPerformanceTimescale | InvestmentProductTimescale) => ({
        timescale,
        onPress: () => selectTimescale(timescale),
        isDisabled,
        isLoading,
      })
    )}
    chartData={chartData}
  />
);
