export type YourInvestmentStyleStatus =
  | 'INACTIVE'
  | 'ACTIVE'
  | 'COMPLETE'
  | 'PART_COMPLETE'
  | 'PREPARING'
  | 'LOCKED';

export type YourInvestmentStyleCardProps = {
  status: YourInvestmentStyleStatus;
  showProgress?: boolean;
};
