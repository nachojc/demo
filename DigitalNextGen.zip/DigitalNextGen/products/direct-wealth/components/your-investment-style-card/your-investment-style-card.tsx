import { IconName } from '@aviva/ion-mobile';

import { ActionCard } from '../action-card/action-card';
import { YourInvestmentStyleCardProps } from './types';
import { YourInvestmentStyleSchema } from './your-investment-style-schema';

export const YourInvestmentStyleCard = ({
  status,
  showProgress,
}: YourInvestmentStyleCardProps) => {
  const data = YourInvestmentStyleSchema[status];
  return (
    <ActionCard
      title={data.title}
      bodyText={data.bodyText}
      showProgress={status === 'LOCKED' ? false : showProgress}
      progressSegments={data.progressSegments}
      progress={data.progress}
      progressTitle={data.progressTitle}
      iconLeft={data.iconLeft as IconName}
      iconRight={
        status === 'INACTIVE' || status === 'PREPARING'
          ? undefined
          : (data.iconRight as IconName)
      }
      iconRightColor={data.iconRightColor}
    />
  );
};
