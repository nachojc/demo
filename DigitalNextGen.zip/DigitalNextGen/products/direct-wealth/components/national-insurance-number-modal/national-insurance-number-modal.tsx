import {
  DynamicHeightModal,
  ScrollView,
  Stack,
  Text,
  XStack,
} from '@aviva/ion-mobile';
import { BulletPoint } from '@aviva/ion-mobile/components/bullet-point';
import { useAnalytics } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';

import { NINO_MODAL_CLOSED } from './analytics';

const renderBulletPointItem = (item: string) => {
  return (
    <XStack accessible key={item}>
      <BulletPoint fontVariant={'body-regular-White'} />
      <Text
        tamaguiTextProps={{ flexWrap: 'wrap', flex: 1 }}
        fontVariant={'body-regular-White'}
      >
        {item}
      </Text>
    </XStack>
  );
};

export type NationalInsuranceNumberModalProps = {
  isVisible: boolean;
  setIsVisible: (answer: boolean) => void;
  pageTag: string;
};

export const NationalInsuranceNumberModal = ({
  isVisible,
  setIsVisible,
  pageTag,
}: NationalInsuranceNumberModalProps) => {
  const { t } = useTranslationDW({
    keyPrefix: 'ninoModal',
  });
  const { trackUserEvent } = useAnalytics();

  const onClose = () => {
    trackUserEvent(pageTag + NINO_MODAL_CLOSED);
    setIsVisible(false);
  };

  return (
    <DynamicHeightModal
      backgroundColor="Wealth800"
      closeIconAccessibilityHint={t('accessibilityHint')}
      closeIconColor={'White'}
      isOpen={isVisible}
      onClose={onClose}
    >
      <ScrollView automaticallyAdjustKeyboardInsets>
        <Stack justifyContent="space-between" flex={1}>
          <Stack>
            <Text
              fontVariant={'heading3-semibold-White'}
              tamaguiTextProps={{ paddingBottom: '$md' }}
            >
              {t('title')}
            </Text>
            <Text
              fontVariant={'body-regular-White'}
              tamaguiTextProps={{ paddingBottom: '$xxl' }}
            >
              {t('description')}
            </Text>
            <Text fontVariant={'body-regular-White'}>{t('listTitle')}</Text>
            {t('bulletPoints', { returnObjects: true }).map(
              renderBulletPointItem
            )}
          </Stack>
        </Stack>
      </ScrollView>
    </DynamicHeightModal>
  );
};
