export const NINO_MODAL_CLOSED = `|nino-tooltip|close-tapped`;
