import { getTokens, getVariableValue, styled, YStack } from '@aviva/ion-mobile';

export const NoDataMainContainer = styled(YStack, {
  alignItems: 'center',
  backgroundColor: '$DWPrimary500',
  height: 470,
  paddingHorizontal: getVariableValue(getTokens().size[3]),
  space: '$xl',
} as const);

export const NoDataContainer = styled(YStack, {
  alignItems: 'center',
  borderColor: '$Gray700',
  borderRadius: getVariableValue(getTokens().size[3]),
  borderWidth: '$xxs',
  height: 274,
  justifyContent: 'center',
  marginTop: getVariableValue(getTokens().size[7]),
  paddingHorizontal: getVariableValue(getTokens().size[10]),
  paddingVertical: getVariableValue(getTokens().size[10]),
  space: '$xl',
} as const);
