export const Constants = {
  ONCE_YOU_VE_MADE_TRANSACTIONS:
    "Once you've made transactions, this area will show your product's activity as a graph.",
};
