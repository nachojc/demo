import { getTokens, getVariableValue, Icon, Text } from '@aviva/ion-mobile';

import { Constants } from './constants';
import { NoDataContainer, NoDataMainContainer } from './styles';

const { ONCE_YOU_VE_MADE_TRANSACTIONS } = Constants;

export const GraphNoDataState = () => {
  return (
    <NoDataMainContainer
      accessibilityHint="Not enough data to show the graph"
      accessibilityLabel="Not enough data to show the graph"
    >
      <NoDataContainer>
        <Icon
          color={getVariableValue(getTokens().color.White)}
          height={40}
          name="trending-up"
          width={40}
        />
        <Text
          fontVariant={'small-regular-White'}
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          {ONCE_YOU_VE_MADE_TRANSACTIONS}
        </Text>
      </NoDataContainer>
    </NoDataMainContainer>
  );
};
