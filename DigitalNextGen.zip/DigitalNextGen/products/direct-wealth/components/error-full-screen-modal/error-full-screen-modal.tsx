import {
  Button,
  getTokens,
  Icon,
  Modal,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useCallback, useEffect, useState } from 'react';

import {
  NETWORK_ERROR,
  NETWORK_ERROR_CLOSE_TAPPED,
  NETWORK_ERROR_RETRY_TAPPED,
  TECHNICAL_ERROR,
  TECHNICAL_ERROR_CLOSE_TAPPED,
  TECHNICAL_ERROR_RETRY_TAPPED,
} from './analytics';

type ErrorFullScreenModalProps = {
  isError: boolean;
  onRetry: () => void;
  buttonTitle: string;
  buttonAccessibilityHint?: string;
  error: string | null | string[];
  pageTag: string;
};

export const ErrorFullScreenModal = ({
  isError,
  onRetry,
  buttonTitle,
  buttonAccessibilityHint,
  error,
  pageTag,
}: ErrorFullScreenModalProps) => {
  const [isVisible, setIsVisible] = useState(false);

  const { trackUserEvent, trackStateEvent } = useAnalytics();

  const { t } = useTranslationDW();

  const tokens = getTokens();

  type RequestError = 'technicalError' | 'networkError';

  const requestError: RequestError = error?.toString().includes('Network Error')
    ? 'networkError'
    : 'technicalError';

  const errorTitle =
    requestError === 'networkError'
      ? t('networkError.title')
      : t('technicalError.title');

  const errorText =
    requestError === 'networkError'
      ? t('networkError.copy')
      : t('technicalError.copy');

  const errorPageTag =
    requestError === 'networkError'
      ? `${pageTag}${NETWORK_ERROR}`
      : `${pageTag}${TECHNICAL_ERROR}`;

  const closeTag =
    requestError === 'networkError'
      ? `${pageTag}${NETWORK_ERROR_CLOSE_TAPPED}`
      : `${pageTag}${TECHNICAL_ERROR_CLOSE_TAPPED}`;

  const retryTag =
    requestError === 'networkError'
      ? `${pageTag}${NETWORK_ERROR_RETRY_TAPPED}`
      : `${pageTag}${TECHNICAL_ERROR_RETRY_TAPPED}`;

  useEffect(() => {
    if (isError) {
      setIsVisible(true);
    }

    if (isError && pageTag) {
      trackStateEvent(errorPageTag);
    }
  }, [isError, pageTag, errorPageTag, trackStateEvent]);

  const handleClose = useCallback(() => {
    if (pageTag) {
      trackUserEvent(closeTag);
    }
    setIsVisible(false);
  }, [trackUserEvent, closeTag, pageTag]);

  const handleRetry = useCallback(() => {
    if (pageTag) {
      trackUserEvent(retryTag);
    }
    onRetry();
  }, [onRetry, trackUserEvent, retryTag, pageTag]);

  return (
    <Modal
      isOpen={isVisible}
      onClose={handleClose}
      backgroundColor="WealthBlue"
      modalHeight={1}
    >
      <YStack
        flex={1}
        paddingHorizontal="$xxxxl"
        alignItems="center"
        justifyContent="center"
        gap="$xl"
        accessible
      >
        <Icon
          name="alert-circle-outline"
          color={tokens.color.White.val}
          height={tokens.size[10].val}
          width={tokens.size[10].val}
        />
        <Text
          fontVariant="heading5-semibold-White"
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          {errorTitle}
        </Text>
        <Text
          fontVariant="body-regular-Gray250"
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          {errorText}
        </Text>
      </YStack>
      <Button
        onPress={handleRetry}
        accessibilityLabel={buttonTitle}
        accessibilityHint={buttonAccessibilityHint}
      >
        {buttonTitle}
      </Button>
    </Modal>
  );
};
