export const TECHNICAL_ERROR = `|technical-error`;
export const TECHNICAL_ERROR_RETRY_TAPPED = `${TECHNICAL_ERROR}|retry-tapped`;
export const TECHNICAL_ERROR_CLOSE_TAPPED = `${TECHNICAL_ERROR}|close-tapped`;
export const NETWORK_ERROR = `|network-error`;
export const NETWORK_ERROR_RETRY_TAPPED = `${NETWORK_ERROR}|retry-tapped`;
export const NETWORK_ERROR_CLOSE_TAPPED = `${NETWORK_ERROR}|close-tapped`;
