import { tokens } from '@theme/tokens';

export type ColorScheme = 'directWealth' | 'plain' | 'dwEndOfLife' | 'light';

const getColors = (scheme: ColorScheme) => {
  return tabColors[scheme];
};

// TODO: Remove tabsTheme file and refactor the code. A lot of DW code has it in deps.
// DW app shouldn't be dependent on direct-wealth/components/tabs/tabsTheme.ts
// This file was meant to be used only in Tabs (deleted) not in whole DW app.
export const theme = (scheme: ColorScheme) => ({ ...getColors(scheme) });

export type TabColorSetup = {
  bg: string;
  indicator: string;
  text: string;
  pressColor: string;
  inactiveColor: string;
  iconColor: string;
  statusBar: 'light' | 'dark';
  headerTextColor: string;
};

type GroupColor = {
  [key: string]: TabColorSetup;
};

export const tabColors: GroupColor = {
  directWealth: {
    bg: tokens.color.WealthBlue.val,
    indicator: tokens.color.Primary500.val,
    text: tokens.color.White.val,
    pressColor: tokens.color.Primary600.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
    iconColor: tokens.color.White.val,
    statusBar: 'light',
    headerTextColor: tokens.color.White.val,
  },
  dwEndOfLife: {
    bg: tokens.color.DWPrimary500.val,
    indicator: tokens.color.Primary500.val,
    text: tokens.color.White.val,
    pressColor: tokens.color.Primary600.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
    iconColor: tokens.color.White.val,
    statusBar: 'light',
    headerTextColor: tokens.color.White.val,
  },
  plain: {
    bg: tokens.color.White.val,
    indicator: tokens.color.Primary500.val,
    text: tokens.color.White.val,
    pressColor: tokens.color.Primary600.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
    iconColor: tokens.color.Secondary800.val,
    statusBar: 'light',
    headerTextColor: tokens.color.Secondary800.val,
  },
  light: {
    bg: tokens.color.White.val,
    indicator: tokens.color.Primary500.val,
    text: tokens.color.WealthBlue.val,
    pressColor: tokens.color.Primary600.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
    iconColor: tokens.color.WealthBlue.val,
    statusBar: 'dark',
    headerTextColor: tokens.color.WealthBlue.val,
  },
};
