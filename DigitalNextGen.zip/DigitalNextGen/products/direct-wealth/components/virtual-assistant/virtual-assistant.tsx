import { PAGE_WEALTH } from '@constants/analytics';
import { NuanceChatOnboardingScreen as DwNuanceChatOnboadingScreen } from '@direct-wealth/features/nuance-onboarding/nuance-onboarding';
import { useAnalytics } from '@hooks/use-analytics';
import { createWealthMetadata, useChat } from '@hooks/use-chat';
import { useCustomer } from '@hooks/use-customer';
import { isManga } from '@hooks/use-expo-config';
import { asyncOnboardingComplete } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { NuanceChatOnboardingScreen as MangaNuanceChatOnboadingScreen } from '@src/components/nuance-chat/nuance-onboarding/nuance-onboarding';
import { FeatureFlags } from '@src/feature-flags';
import { useState } from 'react';

import {
  CHATBOT_TAPPED,
  CHATBOT_WINDOW,
  CHATBOT_WINDOW_CLOSE_TAPPED,
  CHATBOT_WINDOW_MINIMISED,
  ONBOARDING_CLOSE_TAPPED,
  ONBOARDING_CONTINUE_TAPPED,
  ONBOARDING_MODAL,
} from './analytics';
import { FloatingChatButton } from './components/floating-chat-button';
import { VirtualAssistantProps } from './types';

const NuanceChatOnboardingScreen = ({
  isModalVisible,
  onClose,
  onPress,
}: {
  isModalVisible: boolean;
  onClose: () => void;
  onPress: () => void;
}) => {
  if (isManga()) {
    return (
      <MangaNuanceChatOnboadingScreen
        isModalVisible={isModalVisible}
        onClose={onClose}
        onPress={onPress}
        theme="dark"
      />
    );
  }
  return (
    <DwNuanceChatOnboadingScreen
      isModalVisible={isModalVisible}
      onClose={onClose}
      onPress={onPress}
    />
  );
};

/**
 * Virtual Assistant component
 * @param showChatButton `Optional` Param to show chat button or not
 * @param chatButtonSpaceFromBottom `Optional` Param to provide bottom spacing for chat button
 * @param subaccountData `Optional` Param to build product context for nuance eg. *SIPP*, *ISA*, *GIA*, *Drawdown*
 * @param pageMarker Param to send nuance metadata eg. *wealth-details*, *wealth-pcs-dashboard*
 * @param analyticsData Param to create Analytics tags  e.g. *ukmyaviva|wealth|${analyticsData}|chatbot-window*
 * @returns
 */

export const VirtualAssistant = ({
  showChatButton = true,
  chatButtonSpaceFromBottom,
  subaccountData,
  pageMarker,
  analyticsData,
}: VirtualAssistantProps) => {
  const [showChatOnboarding, setShowChatOnboarding] = useState(false);
  const analytics = useAnalytics();
  const analyticsTag = `${PAGE_WEALTH}|${analyticsData}`;
  const chat = useChat();
  const { data: customer } = useCustomer();
  const isEnquirer = customer?.IsEnquirer;
  const isVirtualAssistantEnabled = useSelector(
    FeatureFlags.dwVirtualAssistantEnabled
  );

  if (!showChatButton || !isVirtualAssistantEnabled || isEnquirer) {
    return null;
  }

  const openOnboardingScreen = () => {
    analytics.trackUserEvent(`${analyticsTag}${CHATBOT_TAPPED}`);
    analytics.trackStateEvent(`${analyticsTag}${ONBOARDING_MODAL}`);
    setShowChatOnboarding(true);
  };

  const handleOpenChat = () => {
    asyncOnboardingComplete.get()
      ? openChat(CHATBOT_TAPPED)
      : openOnboardingScreen();
  };

  const closeOnboarding = () => {
    setShowChatOnboarding(false);
    asyncOnboardingComplete.set(true);
    analytics.trackUserEvent(`${analyticsTag}${ONBOARDING_CLOSE_TAPPED}`);
  };

  const completeOnboarding = () => {
    asyncOnboardingComplete.set(true);
    openChat(ONBOARDING_CONTINUE_TAPPED);
  };

  const openChat = (action: string) => {
    chat.initChat();
    chat.openChat(
      createWealthMetadata(subaccountData, pageMarker),
      () => {
        setShowChatOnboarding(false);
        analytics.trackUserEvent(`${analyticsTag}${CHATBOT_WINDOW_MINIMISED}`);
      },
      () => {
        setShowChatOnboarding(false);
        analytics.trackUserEvent(
          `${analyticsTag}${CHATBOT_WINDOW_CLOSE_TAPPED}`
        );
      }
    );
    analytics.trackUserEvent(`${analyticsTag}${action}`);
    analytics.trackStateEvent(`${analyticsTag}${CHATBOT_WINDOW}`);
  };

  return (
    <>
      <NuanceChatOnboardingScreen
        isModalVisible={showChatOnboarding}
        onClose={closeOnboarding}
        onPress={completeOnboarding}
      />
      <FloatingChatButton
        handleOpenChat={handleOpenChat}
        spaceFromBottom={chatButtonSpaceFromBottom}
      />
    </>
  );
};
