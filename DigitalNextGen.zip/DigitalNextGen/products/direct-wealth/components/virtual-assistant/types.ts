import { DirectWealthSubaccount } from '@direct-wealth/validation/schemas/direct-wealth-subaccount';
import { WealthPageMarkerData } from '@hooks/use-chat';

export type VirtualAssistantProps = {
  showChatButton?: boolean;
  chatButtonSpaceFromBottom?: number;
  subaccountData?: DirectWealthSubaccount;
  pageMarker: WealthPageMarkerData;
  analyticsData: string;
};
