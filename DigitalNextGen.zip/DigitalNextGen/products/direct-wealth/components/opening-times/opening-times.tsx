import { Text, YStack } from '@aviva/ion-mobile';

type OpeningTimesProps = {
  times?: { day: string; time: string }[] | null;
};

export const OpeningTimes = ({ times }: OpeningTimesProps) => (
  <YStack testID="opening-times-container">
    {times?.map((item) => {
      return (
        <YStack key={`${item.day}-${item.time}`}>
          <Text fontVariant="body-semibold-Secondary800">{item.day}:</Text>
          <Text fontVariant="body-regular-Gray800">{item.time}</Text>
        </YStack>
      );
    })}
  </YStack>
);
