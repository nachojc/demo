export const Constants = {
  GAIN_LOSS_TOOLTIP_TITLE: 'Gain / loss',
  GAIN_LOSS_TOOLTIP_INTRO_CONTENT_1:
    'Gain or loss since you funded your account. If you buy or sell shares the valuation used will update within 15 minutes of the transaction, otherwise it is calculated as at the last working day.',
  GAIN_LOSS_TOOLTIP_INTRO_CONTENT_2: `Gain or loss measures how much your investments have returned to you through changes in value including:\n`,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_1: `Realised gains and losses (if you sold an investment at a higher or lower price than you purchased it)`,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_2: `Unrealised gains and losses (investments you have not yet sold down meaning any gains or losses are 'on paper')`,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_3: `Any income generated (interest, rebates and dividends)`,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_4: `Deduction of any tax and charges paid out`,
  GAIN_LOSS_TOOLTIP_RETURNS: `Understanding returns`,
  GAIN_LOSS_TOOLTIP_RETURNS_CONTENT_1: `It’s best to consider return figures in the context of your investing goals. Investing works best over the long term, and staying invested for five years or more can increase your chance of positive returns.`,
  GAIN_LOSS_TOOLTIP_RETURNS_CONTENT_2: `Gain / loss figures shown are personal to your investment choices. To review the historic performance of a specific investment, fund fact sheets and holdings information can be more helpful. It’s also important to remember that past performance isn’t an indicator of future performance.`,
};
