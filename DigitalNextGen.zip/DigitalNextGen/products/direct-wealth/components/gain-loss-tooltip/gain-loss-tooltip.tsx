import { Modal, Text, XStack, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';
import { Dispatch, SetStateAction, useCallback } from 'react';
import { useWindowDimensions } from 'react-native';

import { Constants } from './constants';

const {
  GAIN_LOSS_TOOLTIP_TITLE,
  GAIN_LOSS_TOOLTIP_INTRO_CONTENT_1,
  GAIN_LOSS_TOOLTIP_INTRO_CONTENT_2,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_1,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_2,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_3,
  GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_4,
  GAIN_LOSS_TOOLTIP_RETURNS,
  GAIN_LOSS_TOOLTIP_RETURNS_CONTENT_1,
  GAIN_LOSS_TOOLTIP_RETURNS_CONTENT_2,
} = Constants;

type GainLossTooltip = {
  isTooltipVisible: boolean;
  setIsTooltipVisible: Dispatch<SetStateAction<boolean>>;
};

export const GainLossTooltip = ({
  isTooltipVisible,
  setIsTooltipVisible,
}: GainLossTooltip) => {
  const handleCloseModal = useCallback(() => {
    setIsTooltipVisible(false);
  }, [setIsTooltipVisible]);

  const { height, width } = useWindowDimensions();
  const bulletPreamble = '\u2022   ';

  const getiPadHeight = () => {
    return height < width ? 0.75 : 0.5;
  };

  return (
    <YStack>
      <Modal
        isOpen={isTooltipVisible}
        modalHeight={isIpad ? getiPadHeight() : undefined}
        onClose={handleCloseModal}
        backgroundColor="DWPrimary500"
        isIpadWidth
      >
        <Text fontVariant={'heading2-semibold-White'}>
          {GAIN_LOSS_TOOLTIP_TITLE}
        </Text>

        <Text fontVariant="body-regular-White" tamaguiTextProps={{ mt: '$lg' }}>
          {GAIN_LOSS_TOOLTIP_INTRO_CONTENT_1}
        </Text>

        <Text fontVariant="body-regular-White" tamaguiTextProps={{ mt: '$lg' }}>
          {GAIN_LOSS_TOOLTIP_INTRO_CONTENT_2}
        </Text>

        <XStack marginLeft="$md" paddingBottom="$xl" flexDirection="row">
          <Text fontVariant="body-regular-White">{bulletPreamble}</Text>
          <Text
            fontVariant="body-regular-White"
            tamaguiTextProps={{
              flexShrink: 1,
            }}
          >
            {GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_1}
          </Text>
        </XStack>

        <XStack marginLeft="$md" paddingBottom="$xl" flexDirection="row">
          <Text fontVariant="body-regular-White">{bulletPreamble}</Text>
          <Text
            fontVariant="body-regular-White"
            tamaguiTextProps={{
              flexShrink: 1,
            }}
          >
            {GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_2}
          </Text>
        </XStack>

        <XStack marginLeft="$md" paddingBottom="$xl" flexDirection="row">
          <Text fontVariant="body-regular-White">{bulletPreamble}</Text>
          <Text
            fontVariant="body-regular-White"
            tamaguiTextProps={{
              flexShrink: 1,
            }}
          >
            {GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_3}
          </Text>
        </XStack>

        <XStack marginLeft="$md" paddingBottom="$xl" flexDirection="row">
          <Text fontVariant="body-regular-White">{bulletPreamble}</Text>
          <Text
            fontVariant="body-regular-White"
            tamaguiTextProps={{
              flexShrink: 1,
            }}
          >
            {GAIN_LOSS_TOOLTIP_INTRO_BULLET_CONTENT_4}
          </Text>
        </XStack>

        <Text
          fontVariant="heading4-semibold-White"
          tamaguiTextProps={{ mt: '$xl' }}
        >
          {GAIN_LOSS_TOOLTIP_RETURNS}
        </Text>

        <Text fontVariant="body-regular-White" tamaguiTextProps={{ mt: '$xl' }}>
          {GAIN_LOSS_TOOLTIP_RETURNS_CONTENT_1}
        </Text>
        <Text
          fontVariant="body-regular-White"
          tamaguiTextProps={{ mt: '$xl', mb: '$xxl' }}
        >
          {GAIN_LOSS_TOOLTIP_RETURNS_CONTENT_2}
        </Text>
      </Modal>
    </YStack>
  );
};
