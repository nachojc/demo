import {
  getTokens,
  getVariableValue,
  ScrollView,
  ScrollViewProps,
  Separator,
  YStack,
} from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { PropsWithChildren, ReactElement } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { AccessibleHeader } from '../accessible-header';

type SippScrollViewProps = PropsWithChildren<{
  contentContainerStyle?: ScrollViewProps['contentContainerStyle'];
  headerContent?: ReactElement;
  heading: string;
  headingAccessibilityLabel?: string;
  step?: number;
  subheading?: string;
  withoutSeparator?: boolean;
}>;

export const SippScrollView = ({
  children,
  contentContainerStyle = {},
  headerContent,
  heading,
  headingAccessibilityLabel,
  step,
  subheading,
  withoutSeparator,
}: SippScrollViewProps) => {
  const safeAreaInsets = useSafeAreaInsets();
  const tokens = getTokens();
  return (
    <ScrollView
      testID={getTestId('sipp-scroll-view')}
      keyboardShouldPersistTaps="handled"
      {...(isIpad && {
        keyboardDismissMode: 'on-drag',
      })}
      flex={1}
      contentContainerStyle={{
        flexGrow: 1,
        paddingTop: getVariableValue(tokens.space.$xxl),
        paddingHorizontal: getVariableValue(tokens.space.$xl),
        paddingBottom:
          safeAreaInsets.bottom + getVariableValue(tokens.space.$xxl),
        ...(typeof contentContainerStyle === 'object'
          ? contentContainerStyle
          : {}),
      }}
      showsVerticalScrollIndicator={false}
    >
      {headerContent}
      <YStack tablet={isIpad} f={1}>
        <AccessibleHeader
          heading={heading}
          subHeading={subheading}
          step={step}
          headingAccessibilityLabel={headingAccessibilityLabel}
        />
        {!withoutSeparator ? (
          <Separator
            marginBottom="$xxl"
            borderColor={'$Gray200'}
            testID={getTestId('sipp-scroll-view-separator')}
          />
        ) : null}
        {children}
      </YStack>
    </ScrollView>
  );
};
