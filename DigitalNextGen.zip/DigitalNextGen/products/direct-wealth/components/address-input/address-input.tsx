import {
  ButtonVariant,
  Icon,
  Link,
  Modal,
  Stack,
  Text,
  TextInput,
  YStack,
} from '@aviva/ion-mobile';
import {
  AddressForm,
  PostcodeSearchForm,
  PostcodeSearchSchema,
} from '@aviva/ion-mobile/components/address-input/address-form';
import { AddressConstants } from '@aviva/ion-mobile/components/address-input/constants';
import { LoadingSpinner } from '@aviva/ion-mobile/components/loading-spinner';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import { useAddressServiceGetApiV1Address } from '@src/api/generated/queries';
import { Aviva_Digital_MobileApi_Endpoints_PostcodeLookup_V1_Model_AddressModel } from '@src/api/generated/requests';
import { FormInput } from '@src/components/forms/form-input';
import { getTestId } from '@src/utils/get-test-id';
import { useCallback, useEffect, useState } from 'react';
import { Controller, useForm, UseFormReturn } from 'react-hook-form';
import { Keyboard } from 'react-native';
import { ValueOf } from 'type-fest';

import { InputField } from '../input-field';

export const AddressFieldName = {
  AddressLineOne: 'addressLine1',
  AddressLineTwo: 'addressLine2',
  AddressLineThree: 'addressLine3',
  PostalTownCity: 'postalTownCity',
  Postcode: 'postcode',
  PostcodeLookup: 'PostcodeLookup',
} as const;

type AddressInputProps = {
  form: UseFormReturn<AddressForm>;
  manualAddressLinkTag?: string;
  onPostcodeSearchTapped?: () => void;
  onFieldFocus?: (fieldType: ValueOf<typeof AddressFieldName>) => void;
  onAddressSelect?: (address: string) => void;
  header?: string;
  defaultShowAddressForm?: boolean;
};

const {
  POSTCODE_SEARCH,
  POSTCODE_SEARCH_PLACEHOLDER,
  ADDRESS_LINE_ONE,
  ADDRESS_LINE_ONE_PLACEHOLDER,
  ADDRESS_LINE_ONE_ERROR,
  ADDRESS_LINE_TWO,
  ADDRESS_LINE_TWO_PLACEHOLDER,
  ADDRESS_LINE_THREE,
  ADDRESS_LINE_THREE_PLACEHOLDER,
  POSTAL_TOWN_CITY,
  POSTAL_TOWN_CITY_PLACEHOLDER,
  POSTAL_TOWN_CITY_ERROR,
  POSTCODE,
  POSTCODE_PLACEHOLDER,
  POSTCODE_ERROR,
  MANUAL_ENTRY,
  LOADING_RESULTS,
  INVALID_POSTCODE_SERVICE_ERROR,
} = AddressConstants;

export const AddressInput = ({
  form,
  manualAddressLinkTag,
  onPostcodeSearchTapped = () => undefined,
  onFieldFocus = () => undefined,
  onAddressSelect,
  header = POSTCODE_SEARCH,
  defaultShowAddressForm = false,
}: AddressInputProps) => {
  const [showAddressForm, setShowAddressForm] = useState(
    defaultShowAddressForm
  );
  const [showModal, setShowModal] = useState(false);
  const [postcode, setPostcode] = useState('');

  const postcodeSearchForm = useForm<PostcodeSearchForm>({
    resolver: zodResolver(PostcodeSearchSchema),
    defaultValues: {
      postcodeSearch: undefined,
    },
  });

  const analytics = useAnalytics();
  const { control, setFocus } = form;
  const { control: postcodeControl } = postcodeSearchForm;
  const { data, isFetching, isError, error, refetch } =
    useAddressServiceGetApiV1Address(
      { postcode },
      ['AddressServiceGetApiV1Address', postcode],
      {
        enabled: false,
        cacheTime: 0,
        staleTime: 0,
      }
    );
  const postcodeSearchFieldName = 'postcodeSearch';

  useEffect(() => {
    if (postcode.length) {
      refetch();
    }
  }, [postcode, refetch]);

  const handleAddressSelection = useCallback(
    async (index: number) => {
      const selectedAddress = data?.Addresses?.[index];

      if (onAddressSelect) {
        onAddressSelect(
          `${selectedAddress?.AddressLineOne}, ${selectedAddress?.PostalTownCity}`
        );
      }

      form.setValue(
        AddressFieldName.AddressLineOne,
        selectedAddress?.AddressLineOne ?? ''
      );
      form.setValue(
        AddressFieldName.AddressLineTwo,
        selectedAddress?.AddressLineTwo ?? ''
      );
      form.setValue(
        AddressFieldName.AddressLineThree,
        selectedAddress?.AddressLineThree ?? ''
      );
      form.setValue(
        AddressFieldName.PostalTownCity,
        selectedAddress?.PostalTownCity ?? ''
      );
      form.setValue(AddressFieldName.Postcode, selectedAddress?.Postcode ?? '');

      await form.trigger();
      setShowAddressForm(true);
      setShowModal(false);
    },
    [onAddressSelect, data?.Addresses, form]
  );

  return (
    <>
      <YStack>
        <FormInput
          type="search"
          onFocus={() => onFieldFocus(AddressFieldName.PostcodeLookup)}
          onSearch={async (val) => {
            onPostcodeSearchTapped();
            await postcodeSearchForm.trigger(postcodeSearchFieldName);
            if (
              !postcodeSearchForm.getFieldState(postcodeSearchFieldName).invalid
            ) {
              setPostcode(val ?? '');
              setShowModal(true);
            }
            Keyboard.dismiss();
          }}
          name={postcodeSearchFieldName}
          control={postcodeControl}
          label={header}
          hasIcon
          iconColor={'white'}
          buttonVariant={ButtonVariant.DIRECT_WEALTH}
          buttonTestID="searchPostcode"
          placeholder={POSTCODE_SEARCH_PLACEHOLDER}
        />
        {!showAddressForm && (
          <Link
            onPress={() => {
              if (manualAddressLinkTag) {
                analytics.trackUserEvent(manualAddressLinkTag);
              }
              setShowAddressForm(true);
            }}
            marginBottom="$xxxl"
          >
            {MANUAL_ENTRY}
          </Link>
        )}
        {showAddressForm && (
          <YStack>
            <Controller
              name={AddressFieldName.AddressLineOne}
              control={control}
              render={({ field: { onChange, value }, fieldState }) => {
                return (
                  <InputField
                    label={ADDRESS_LINE_ONE}
                    field={
                      <TextInput
                        testID={getTestId('address-line-one')}
                        tamaguiInputProps={{
                          value,
                          returnKeyType: 'next',
                          onSubmitEditing: () =>
                            setFocus(AddressFieldName.AddressLineTwo),
                          onChangeText: onChange,
                          onFocus: () =>
                            onFieldFocus(AddressFieldName.AddressLineOne),
                          placeholder: ADDRESS_LINE_ONE_PLACEHOLDER,
                        }}
                        error={fieldState.invalid}
                        errorText={ADDRESS_LINE_ONE_ERROR}
                      />
                    }
                    withMargin
                  />
                );
              }}
            />
            <Controller
              name={AddressFieldName.AddressLineTwo}
              control={control}
              render={({ field: { onChange, value } }) => {
                return (
                  <InputField
                    label={ADDRESS_LINE_TWO}
                    field={
                      <TextInput
                        testID={getTestId('address-line-two')}
                        tamaguiInputProps={{
                          value,
                          returnKeyType: 'next',
                          onSubmitEditing: () =>
                            setFocus(AddressFieldName.AddressLineThree),
                          onChangeText: onChange,
                          onFocus: () =>
                            onFieldFocus(AddressFieldName.AddressLineTwo),
                          placeholder: ADDRESS_LINE_TWO_PLACEHOLDER,
                        }}
                      />
                    }
                    withMargin
                  />
                );
              }}
            />
            <Controller
              name={AddressFieldName.AddressLineThree}
              control={control}
              render={({ field: { onChange, value } }) => {
                return (
                  <InputField
                    label={ADDRESS_LINE_THREE}
                    field={
                      <TextInput
                        testID={getTestId('address-line-three')}
                        tamaguiInputProps={{
                          value,
                          returnKeyType: 'next',
                          onSubmitEditing: () =>
                            setFocus(AddressFieldName.PostalTownCity),
                          onChangeText: onChange,
                          onFocus: () =>
                            onFieldFocus(AddressFieldName.AddressLineThree),
                          placeholder: ADDRESS_LINE_THREE_PLACEHOLDER,
                        }}
                      />
                    }
                    withMargin
                  />
                );
              }}
            />
            <Controller
              name={AddressFieldName.PostalTownCity}
              control={control}
              render={({ field: { onChange, value }, fieldState }) => {
                return (
                  <InputField
                    label={POSTAL_TOWN_CITY}
                    field={
                      <TextInput
                        testID={getTestId('postal-town-city')}
                        tamaguiInputProps={{
                          value,
                          returnKeyType: 'next',
                          onSubmitEditing: () =>
                            setFocus(AddressFieldName.Postcode),
                          onChangeText: onChange,
                          onFocus: () =>
                            onFieldFocus(AddressFieldName.PostalTownCity),
                          placeholder: POSTAL_TOWN_CITY_PLACEHOLDER,
                        }}
                        error={fieldState.invalid}
                        errorText={POSTAL_TOWN_CITY_ERROR}
                      />
                    }
                    withMargin
                  />
                );
              }}
            />
            <Controller
              name={AddressFieldName.Postcode}
              control={control}
              render={({ field: { onChange, value }, fieldState }) => {
                return (
                  <InputField
                    label={POSTCODE}
                    field={
                      <TextInput
                        testID={getTestId('postcode')}
                        tamaguiInputProps={{
                          value,
                          onChangeText: onChange,
                          placeholder: POSTCODE_PLACEHOLDER,
                        }}
                        error={fieldState.invalid}
                        errorText={POSTCODE_ERROR}
                      />
                    }
                    withMargin
                  />
                );
              }}
            />
          </YStack>
        )}
      </YStack>
      <Modal
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
        }}
        backgroundColor="White"
        closeIconColor="DWPrimary500"
        modalHeight={0.9}
      >
        {isFetching && (
          <YStack flex={1} alignItems="center" justifyContent="center">
            <LoadingSpinner size={40} />
            <Stack marginTop="$xxl">
              <Text fontVariant="body-regular-Gray800">{LOADING_RESULTS}</Text>
            </Stack>
          </YStack>
        )}
        {isError && !isFetching && (
          <YStack flex={1} alignItems="center" justifyContent="center">
            <Icon name="alert-circle-outline" width={40} height={40} />
            <Stack marginTop="$xxl">
              <Text
                fontVariant="body-regular-Gray800"
                tamaguiTextProps={{ textAlign: 'center' }}
              >
                {String(error).includes('Bad Request')
                  ? INVALID_POSTCODE_SERVICE_ERROR
                  : `Sorry, we were unable to return results for '${postcode}'. Please try again.`}
              </Text>
            </Stack>
          </YStack>
        )}
        {!isFetching &&
          !isError &&
          data?.Addresses &&
          data?.Addresses.map(
            (
              returnedAddress: Aviva_Digital_MobileApi_Endpoints_PostcodeLookup_V1_Model_AddressModel,
              index: number
            ) => (
              <YStack
                testID={`Address: ${String(index)}`}
                key={`Address-${index}`}
                paddingVertical="$xl"
                borderBottomWidth={1}
                borderColor="$Gray300"
                onPress={() => handleAddressSelection(index)}
              >
                <Text fontVariant="body-semibold-Gray800">
                  {`${returnedAddress.AddressLineOne}, ${returnedAddress.PostalTownCity}`}
                </Text>
              </YStack>
            )
          )}
      </Modal>
    </>
  );
};
