import { Button, ButtonVariant, YStack } from '@aviva/ion-mobile';
import { LoadingSpinner } from '@aviva/ion-mobile/components/loading-spinner';

type ListFooterComponentProps = {
  shouldShowLoadMoreSpinner: boolean;
  onPress: () => void;
};
export const ListFooterComponent = ({
  onPress,
  shouldShowLoadMoreSpinner,
}: ListFooterComponentProps) =>
  shouldShowLoadMoreSpinner ? (
    <YStack alignItems="center" testID="list-footer-spinner-container">
      <LoadingSpinner size={50} />
    </YStack>
  ) : (
    <Button variant={ButtonVariant.LINK_TEXT} onPress={onPress}>
      Show more
    </Button>
  );
