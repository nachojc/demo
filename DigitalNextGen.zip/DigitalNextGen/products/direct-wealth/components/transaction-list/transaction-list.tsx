import {
  IconText,
  SectionHeading,
  TransactionListItem,
  YStack,
} from '@aviva/ion-mobile';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { tokens } from '@src/theme/tokens';
import { isIpad } from '@src/utils/is-ipad';
import { MonthlyTransactionSectionList } from 'products/direct-wealth/features/transaction-history/use-transaction-history-view-model';
import { Transaction } from 'products/direct-wealth/validation/schemas/transaction-history';
import { SectionList } from 'react-native';

import { EmptyState } from './empty-state';
import { ListFooterComponent } from './list-footer-component';

type TransactionListProp = {
  transactions: MonthlyTransactionSectionList;
  navigateToTransactionDetails: (transaction: Transaction) => void;
  loadNextPage: () => void;
  shouldShowLoadMoreSpinner: boolean;
  shouldShowLoadMore: boolean;
};

export const TransactionList = ({
  transactions,
  navigateToTransactionDetails,
  loadNextPage,
  shouldShowLoadMoreSpinner,
  shouldShowLoadMore,
}: TransactionListProp) => {
  return (
    <SectionList
      initialNumToRender={20}
      sections={transactions}
      style={{ marginBottom: tokens.size['5'].val }}
      keyExtractor={(item, index) => `${item.heading}_${index}`}
      renderItem={({ item }: { item: Transaction }) => {
        return (
          <YStack tablet={isIpad}>
            <TransactionListItem
              onPress={() => navigateToTransactionDetails(item)}
              date={item.transactionDate.formatted}
              transferType={item.heading.toUpperCase()}
              transferValue={item.amount.formatted}
            />
          </YStack>
        );
      }}
      ListHeaderComponent={HeaderMessage}
      ListEmptyComponent={transactions?.length === 0 ? <EmptyState /> : null}
      ListFooterComponent={
        shouldShowLoadMore ? (
          <ListFooterComponent
            onPress={loadNextPage}
            shouldShowLoadMoreSpinner={shouldShowLoadMoreSpinner}
          />
        ) : null
      }
      renderSectionHeader={({ section: { title } }) => (
        <YStack tablet={isIpad}>
          <SectionHeading
            variant="transaction"
            heading={title}
            showIcon={false}
          />
        </YStack>
      )}
    />
  );
};

const HeaderMessage = () => {
  const { t } = useTranslationDW({
    keyPrefix: 'transactionList',
  });

  return (
    <YStack tablet={isIpad}>
      <YStack backgroundColor={'$Gray050'} px={'$xl'} pt={'$md'}>
        <IconText
          iconSizeOption="xlarge"
          iconName="info"
          subtitle={t('pendingTransactionsCopy')}
          iconColor={tokens.color.Information.val}
          alignIcon="center"
        />
      </YStack>
    </YStack>
  );
};
