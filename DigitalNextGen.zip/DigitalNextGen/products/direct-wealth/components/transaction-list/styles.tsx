import { styled, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

export const EmptyStateContainer = styled(YStack, {
  ai: 'center',
  justifyContent: isIpad ? 'center' : 'flex-start',
  marginTop: isIpad ? null : '40%',
  flex: isIpad ? 1 : undefined,
});
