import { Icon, Text, useWindowDimensions, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

import { Constants } from '../../features/transaction-history/constants';
import { EmptyStateContainer } from './styles';

export const EmptyState = () => {
  const { height } = useWindowDimensions();
  return (
    <YStack height={isIpad ? height * 0.65 : undefined}>
      <EmptyStateContainer>
        <Icon name="alert-circle-outline" height={40} width={40} />
        <Text
          fontVariant={'body-regular-Gray900'}
          tamaguiTextProps={{ textAlign: 'center', marginTop: '$xxxl' }}
        >
          {Constants.NO_TRANSACTIONS}
        </Text>
      </EmptyStateContainer>
    </YStack>
  );
};
