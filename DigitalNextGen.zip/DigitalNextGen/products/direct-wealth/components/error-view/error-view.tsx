import { Button, Icon, IconName, Stack, Text, YStack } from '@aviva/ion-mobile';
import {
  useAnalytics,
  useConditionalTrackStateEvent,
} from '@hooks/use-analytics';
import { useNavigation } from '@react-navigation/native';
import { tokens } from '@src/theme/tokens';
import { isIpad } from '@src/utils/is-ipad';
import { useCallback } from 'react';

export type ErrorViewProps = {
  onRetry?: () => void;
  iconName?: IconName;
  title?: string;
  message?: string;
  screenTrackAnalyticsTag?: string;
  onCloseAnalyticsTag?: string;
  onRetryAnalyticsTag?: string;
  closeOnRetry?: boolean;
};

export const ErrorView = ({
  onRetry,
  iconName = 'alert-circle-outline',
  title = 'Something went wrong',
  message = 'We were unable to load your information at this time. Please try again later.',
  screenTrackAnalyticsTag = '',
  onRetryAnalyticsTag = '',
  closeOnRetry = false,
}: ErrorViewProps) => {
  const navigation = useNavigation();
  const { trackUserEvent } = useAnalytics();
  useConditionalTrackStateEvent(screenTrackAnalyticsTag);

  const onRetryHandler = useCallback(() => {
    if (onRetryAnalyticsTag) {
      trackUserEvent(onRetryAnalyticsTag);
    }
    if (closeOnRetry) {
      navigation.goBack();
    }
    if (onRetry) {
      onRetry();
    }
  }, [onRetryAnalyticsTag, closeOnRetry, onRetry, trackUserEvent, navigation]);

  return (
    <Stack testID="error-view" f={1} bc="$WealthBlue" px="$xl" pb="$xxl">
      <Stack f={1} jc="center" ai="center" mx="$xl" space="$xl">
        <Icon
          name={iconName}
          height={69}
          width={132}
          color={tokens.color.White.val}
        />
        <Text
          fontVariant="heading5-semibold-White"
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          {title}
        </Text>
        <Text
          fontVariant="body-regular-Gray250"
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          {message}
        </Text>
      </Stack>
      <YStack
        tabletNarrow={isIpad}
        paddingBottom={isIpad ? '$xxxl' : undefined}
      >
        <Button
          onPress={onRetryHandler}
          accessibilityLabel="retry"
          accessibilityHint="retry button on error screen"
          testID="error-view-retry-button"
        >
          Retry
        </Button>
      </YStack>
    </Stack>
  );
};
