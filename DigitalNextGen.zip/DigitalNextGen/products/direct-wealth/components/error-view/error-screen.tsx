import { useAppStackRoute } from '@src/navigation/app/hooks';

import { ErrorView } from './error-view';

export const ErrorScreen = () => {
  const { params } = useAppStackRoute<'Error Screen'>();
  return <ErrorView {...params} />;
};
