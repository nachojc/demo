import { Snackbar } from '@aviva/ion-mobile';
import { useTrackStateEvent } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { isIpad } from '@src/utils/is-ipad';

import { SnackbarContainer } from '../../features/sipp-transfer/pensions/styles';

type PensionRemovedSnackbarProps = {
  floatingBottom?: number;
  handleSnackbarUndo: () => void;
  handleCompletion: () => void;
  screenEventTag?: string;
};

export const PensionRemovedSnackbar = ({
  floatingBottom,
  handleSnackbarUndo,
  handleCompletion,
  screenEventTag,
}: PensionRemovedSnackbarProps) => {
  useTrackStateEvent(screenEventTag ?? null);

  const { t } = useTranslationDW({
    keyPrefix: 'pensionRemovedSnackbar',
  });

  const pensionRemovedSnackbar = (
    <Snackbar
      snackbar
      snackbarSingleLine
      enterTime={100}
      exitTime={5000}
      title={t('title')}
      actionButton={t('actionButtonText')}
      snackbarOnPress={{
        onActionPress: handleSnackbarUndo,
        accessibilityAnnouncementDuration: 5000,
      }}
      completionHandler={handleCompletion}
      accessibilityLabel={t('accessibilityLabel')}
      accessibilityRole="button"
      accessibilityFocusWhenVisible
    />
  );

  return floatingBottom ? (
    <SnackbarContainer bottom={isIpad && floatingBottom}>
      {pensionRemovedSnackbar}
    </SnackbarContainer>
  ) : (
    <SnackbarContainer>{pensionRemovedSnackbar}</SnackbarContainer>
  );
};
