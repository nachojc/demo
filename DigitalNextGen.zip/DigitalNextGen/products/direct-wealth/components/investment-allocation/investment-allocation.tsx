import {
  CardActionButton,
  getTokens,
  getVariableValue,
  Icon,
  Separator,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { PropsWithChildren } from 'react';

type Allocation = { name: string; value: number };

type InvestmentAllocationProps = PropsWithChildren<{
  cash?: Allocation;
  chooseLaterSelected?: boolean;
  investment?: Allocation;
  isISA?: boolean;
  onEditPress?: () => void;
}>;

const FundAllocated = ({ title, value }: { title: string; value: number }) => (
  <YStack space="$md">
    <Text fontVariant="body-regular-Gray800">{title}</Text>
    <Text fontVariant="body-semibold-Gray800">{value}%</Text>
  </YStack>
);

const AllocationCopy = ({
  chooseLaterSelected,
  isISA,
}: {
  chooseLaterSelected: boolean;
  isISA: boolean;
}) => {
  const tokens = getTokens();
  const { t } = useTranslationDW({
    keyPrefix: 'investmentAllocation',
  });

  if (isISA) {
    return (
      <Text fontVariant="body-regular-Gray800">{t('isa.smallprint')}</Text>
    );
  }

  return chooseLaterSelected ? (
    <XStack space={'$sm'} marginTop={'$sm'}>
      <Icon
        name="alert-circle"
        color={getVariableValue(tokens.color.Error)}
        height={16}
      />
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ flex: 1, flexWrap: 'wrap', marginTop: '$-sm' }}
      >
        {t('sipp.chooseLater')}
      </Text>
    </XStack>
  ) : (
    <Text fontVariant="body-regular-Gray800">
      {t('sipp.investmentOptionSelected')}
    </Text>
  );
};

export const InvestmentAllocation = ({
  cash,
  chooseLaterSelected = false,
  investment,
  isISA = false,
  onEditPress,
}: InvestmentAllocationProps) => (
  <YStack
    padding={'$xl'}
    space="$xl"
    borderColor={'$Gray300'}
    borderWidth={1}
    borderRadius={5}
  >
    <XStack justifyContent="space-between">
      <Text fontVariant="body-semibold-Secondary800">
        Investment allocation
      </Text>
      {!chooseLaterSelected && onEditPress && (
        <CardActionButton
          text="Edit"
          icon="edit"
          onPress={onEditPress}
          accessibilityHint="Edits investment allocation"
        />
      )}
    </XStack>
    <Separator borderColor={'$Gray200'} />
    {investment ? (
      <FundAllocated title={investment.name} value={investment.value} />
    ) : null}
    {cash ? <FundAllocated title={cash.name} value={cash.value} /> : null}
    <AllocationCopy chooseLaterSelected={chooseLaterSelected} isISA={isISA} />
  </YStack>
);
