export * from './investment-allocation';
