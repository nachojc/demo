import {
  getTokens,
  getVariableValue,
  Icon,
  Text,
  XStack,
} from '@aviva/ion-mobile';

export const ErrorMessage = ({ copy }: { copy: string }) => {
  const tokens = getTokens();
  return (
    <XStack>
      <Icon
        name={'alert-circle'}
        color={getVariableValue(tokens.color.Error)}
      />
      <Text
        fontVariant={'body-regular-Error'}
        tamaguiTextProps={{
          paddingLeft: getVariableValue(tokens.space.sm),
          alignSelf: 'center',
        }}
      >
        {copy}
      </Text>
    </XStack>
  );
};
