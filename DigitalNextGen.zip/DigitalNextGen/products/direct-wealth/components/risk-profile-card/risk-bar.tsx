import {
  Stack,
  TamaguiProgress,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { useCallback } from 'react';

import { RiskBarProps } from './types';

export const RiskBar = ({
  riskLevel,
  progressLeftText,
  progressRightText,
}: RiskBarProps) => {
  const progressBar = useCallback(() => {
    const segments = Array.from({ length: 6 }, (_, i) => {
      let segmentColour = '$Gray200';
      if (riskLevel === i) {
        segmentColour = '$Information';
      }
      const segmentWidth = i === 0 ? tokens.size[4].val : undefined;
      return (
        <Stack
          key={i}
          flex={i === riskLevel ? 1.5 : 1}
          maxWidth={segmentWidth}
          width={segmentWidth}
          height="$1"
        >
          <TamaguiProgress
            minWidth={0}
            borderRadius="$2"
            backgroundColor={segmentColour}
            testID={getTestId('risk-segment')}
            height={i === riskLevel ? '$1.5' : '$1'}
            top={i === riskLevel ? -1 : undefined}
          >
            <TamaguiProgress.Indicator backgroundColor={segmentColour} />
          </TamaguiProgress>
        </Stack>
      );
    });
    return segments;
  }, [riskLevel]);
  return (
    <YStack
      accessibilityElementsHidden
      importantForAccessibility="no-hide-descendants"
    >
      <TamaguiProgress
        minWidth={0}
        borderRadius="$2"
        height="$1"
        backgroundColor="$Gray200"
        testID={getTestId('risk-bar')}
        overflow="visible"
        alignItems="center"
      >
        <XStack>{progressBar()}</XStack>
      </TamaguiProgress>
      <XStack justifyContent="space-between" alignItems="flex-start" my="$md">
        <Text fontVariant="small-regular-Gray800">{progressLeftText}</Text>
        <Text fontVariant="small-regular-Gray800">{progressRightText}</Text>
      </XStack>
    </YStack>
  );
};
