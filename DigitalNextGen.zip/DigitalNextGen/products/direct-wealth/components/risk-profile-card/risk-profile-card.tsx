import { Icon, Text, XStack, YStack } from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';

import { RiskBar } from './risk-bar';
import { RiskProfileCardSchema } from './risk-profile-card-schema';
import { RiskProfileCardProps } from './types';

export const RiskProfileCard = ({ status }: RiskProfileCardProps) => {
  const {
    bodyText,
    iconLeft,
    notification,
    progressLeftText,
    progressRightText,
    riskLevel,
    title,
    titleAccessibilityLabel,
  } = RiskProfileCardSchema[status];

  return (
    <YStack
      backgroundColor="$White"
      borderRadius="$2"
      borderColor="$Gray300"
      borderWidth="$xxs"
      padding="$xl"
      gap="$xl"
      testID={getTestId('risk-profile-card')}
    >
      <XStack
        alignItems="center"
        gap="$md"
        accessibilityLabel={`${titleAccessibilityLabel ?? title}`}
      >
        <Icon name={iconLeft} color={tokens.color.Wealth600.val} />
        <Text fontVariant="heading4-semibold-Wealth600">{title}</Text>
      </XStack>
      <RiskBar
        riskLevel={riskLevel}
        progressLeftText={progressLeftText}
        progressRightText={progressRightText}
      />
      <XStack
        backgroundColor="$InformationTint"
        borderRadius={4}
        padding="$xl"
        gap="$xl"
      >
        <Icon
          accessible={false}
          name="info"
          color={tokens.color.Information.val}
        />
        <Text
          fontVariant="small-regular-Gray800"
          tamaguiTextProps={{ flex: 1 }}
        >
          {notification}
        </Text>
      </XStack>
      <Text fontVariant="body-regular-Gray800">{bodyText}</Text>
    </YStack>
  );
};
