export type RiskProfileCardStatus =
  | 'CAUTIOUS'
  | 'CAUTIOUS_TO_MODERATE'
  | 'MODERATE'
  | 'MODERATE_TO_ADVENTUROUS'
  | 'ADVENTUROUS';

export type RiskProfileCardProps = {
  status: RiskProfileCardStatus;
};

export type RiskBarProps = {
  riskLevel: number;
  progressLeftText: string;
  progressRightText: string;
};
