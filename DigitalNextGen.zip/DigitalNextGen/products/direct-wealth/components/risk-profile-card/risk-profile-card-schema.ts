export const RiskProfileCardSchema = {
  CAUTIOUS: {
    title: 'Cautious',
    titleAccessibilityLabel: 'Cautious',
    bodyText:
      'You prefer to focus much more on reducing the potential for losses than on increasing returns. It is important to you that any losses in the value of your investment are minimised if possible and you will sacrifice higher returns to achieve this.',
    riskLevel: 1,
    progressLeftText: 'Lower risk & reward',
    progressRightText: 'Higher risk & reward',
    iconLeft: 'speedometer',
    notification:
      "Based on what you've told us, this is where we've pitched your investment style",
  },
  CAUTIOUS_TO_MODERATE: {
    title: 'Cautious to moderate',
    titleAccessibilityLabel: 'Cautious to moderate',
    bodyText:
      'You prefer to prioritise being cautious overtaking too much investment risk while still balancing risk and reward.',
    riskLevel: 2,
    progressLeftText: 'Lower risk & reward',
    progressRightText: 'Higher risk & reward',
    iconLeft: 'speedometer',
    notification:
      "Based on what you've told us, this is where we've pitched your investment style",
  },
  MODERATE: {
    title: 'Moderate',
    titleAccessibilityLabel: 'Moderate',
    bodyText:
      'You prefer balancing investment risk and reward. You are prepared to take on more risk to increase the chance of better returns. Capital protection is less important to you than achieving a better return on the investment.',
    riskLevel: 3,
    progressLeftText: 'Lower risk & reward',
    progressRightText: 'Higher risk & reward',
    iconLeft: 'speedometer',
    notification:
      "Based on what you've told us, this is where we've pitched your investment style",
  },
  MODERATE_TO_ADVENTUROUS: {
    title: 'Moderate to adventurous',
    titleAccessibilityLabel: 'Moderate to adventurous',
    bodyText:
      'You prefer to prioritise taking investment risk over capital protection for the prospect of greater returns over the longer term.',
    riskLevel: 4,
    progressLeftText: 'Lower risk & reward',
    progressRightText: 'Higher risk & reward',
    iconLeft: 'speedometer',
    notification:
      "Based on what you've told us, this is where we've pitched your investment style",
  },
  ADVENTUROUS: {
    title: 'Adventurous',
    titleAccessibilityLabel: 'Adventurous',
    bodyText:
      'You prefer to maximise investment returns and are not concerned about protection of your capital. You are prepared to accept high levels of risk to ensure you have the potential to receive high returns over the longer term.',
    riskLevel: 5,
    progressLeftText: 'Lower risk & reward',
    progressRightText: 'Higher risk & reward',
    iconLeft: 'speedometer',
    notification:
      "Based on what you've told us, this is where we've pitched your investment style",
  },
} as const;
