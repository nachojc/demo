import {
  Button,
  ButtonVariant,
  Dialog,
  Icon,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { webLinks } from '@constants/web-links';
import { useTrackStateEvent } from '@hooks/use-analytics';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';

type UpdateYourDetailsDialogProps = {
  analyticsTag: string;
  isVisible: boolean;
  onCancelPress: () => void;
  onContinuePress: () => void;
  title: string;
};

export const UpdateYourDetailsDialog = ({
  analyticsTag,
  isVisible,
  onCancelPress,
  onContinuePress,
  title,
}: UpdateYourDetailsDialogProps) => {
  useTrackStateEvent(analyticsTag);

  const { navigate } = useAppStackNavigation();

  const { t } = useTranslationDW({
    keyPrefix: 'updateYourDetailsDialog',
  });

  const handleContinueToWeb = () => {
    onContinuePress();
    navigate('Web View', { url: webLinks.profile, ssoEnabled: true });
  };

  return (
    <Dialog
      open={isVisible}
      title={title}
      copy={t('subtitle')}
      center
      icon={
        <Icon
          accessible={false}
          color={tokens.color.Information.val}
          name="info"
        />
      }
    >
      <YStack marginTop="$xl" gap="$md">
        <Button
          variant={ButtonVariant.BRAND}
          onPress={handleContinueToWeb}
          accessibilityHint={t('continueAccessibilityHint')}
          accessibilityLabel={t('continue')}
          testID={getTestId('go-to-our-website-button')}
        >
          <XStack pt="$md" gap="$md">
            <Icon name="external-link" />
            <Text fontVariant={'body-semibold-Secondary800'}>
              {t('continue')}
            </Text>
          </XStack>
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={onCancelPress}
          accessibilityHint={t('cancelAccessibilityHint')}
        >
          {t('cancel')}
        </Button>
      </YStack>
    </Dialog>
  );
};
