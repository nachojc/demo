import { IconName } from '@aviva/ion-mobile';

import { ActionCard } from '../action-card/action-card';
import { YourFinancialSituationCardProps } from './types';
import { YourFinancialSituationSchema } from './your-financial-situation-schema';

export const YourFinancialSituationCard = ({
  status,
  showProgress,
}: YourFinancialSituationCardProps) => {
  const data = YourFinancialSituationSchema[status];
  return (
    <ActionCard
      title={data.title}
      bodyText={data.bodyText}
      showProgress={showProgress}
      progressSegments={data.progressSegments}
      progress={data.progress}
      progressTitle={data.progressTitle}
      iconLeft={data.iconLeft as IconName}
      iconRight={data.iconRight as IconName}
      iconRightColor={data.iconRightColor}
    />
  );
};
