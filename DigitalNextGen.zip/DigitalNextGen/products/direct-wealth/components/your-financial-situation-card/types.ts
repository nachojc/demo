export type YourFinancialSituationStatus =
  | 'ELIGIBILITY'
  | 'INVESTMENT_GOALS'
  | 'AFFORDABILITY'
  | 'PERSONAL_CONSIDERATION'
  | 'REVIEW_YOUR_ANSWERS'
  | 'YOURE_ALL_SET'
  | 'LOADING';

export type YourFinancialSituationCardProps = {
  status: YourFinancialSituationStatus;
  showProgress?: boolean;
};
