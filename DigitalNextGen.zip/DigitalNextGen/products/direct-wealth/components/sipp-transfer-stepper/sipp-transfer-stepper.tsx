import { SteppedProgress, YStackProps } from '@aviva/ion-mobile';

import { useStepperValues } from '../../features/sipp-transfer/hooks/use-stepper-values';

type SippTransferStepperProps = {
  step: number;
  containerProps?: YStackProps;
};

export const SippTransferStepper = ({
  containerProps,
  step,
}: SippTransferStepperProps) => {
  const { currentStep, max, steppedLabel, boldLabel } = useStepperValues(step);
  return (
    <SteppedProgress
      boldLabel={boldLabel}
      containerProps={containerProps}
      currentStep={currentStep}
      label={steppedLabel}
      totalSteps={max}
    />
  );
};
