export type YourInvestmentForecastStatus =
  | 'INACTIVE'
  | 'ACTIVE'
  | 'COMPLETE'
  | 'PART_COMPLETE'
  | 'PREPARING'
  | 'LOCKED';

export type YourInvestmentForecastCardProps = {
  status: YourInvestmentForecastStatus;
  showProgress?: boolean;
};
