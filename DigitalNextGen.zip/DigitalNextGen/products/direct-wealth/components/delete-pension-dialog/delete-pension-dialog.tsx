import {
  Button,
  ButtonVariant,
  Dialog,
  getTokens,
  Icon,
  Stack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

export const DeletePensionDialog = ({
  isOpen,
  onConfirm,
  onCancel,
  screenEventTag,
  isLastPension,
}: {
  isOpen: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  screenEventTag?: string;
  isLastPension: boolean;
}) => {
  const tokens = getTokens();
  const { t } = useTranslation();
  const analytics = useAnalytics();

  useEffect(() => {
    if (isOpen && screenEventTag) {
      analytics.trackStateEvent(screenEventTag);
    }
  }, [isOpen, screenEventTag, analytics]);

  return (
    <Dialog
      open={isOpen}
      center
      icon={
        <Icon
          accessible={false}
          color={tokens.color.Error.val}
          name={'alert-circle'}
        />
      }
      title={t('sipp.reviewPensions.deletePensionDialog.title')}
      copy={isLastPension && t('sipp.reviewPensions.deletePensionDialog.copy')}
    >
      <Stack space="$md" marginTop="$xl" key="hi">
        <Button onPress={onConfirm}>
          {t('sipp.reviewPensions.deletePensionDialog.confirmButtonLabel')}
        </Button>
        <Button variant={ButtonVariant.LINK_TEXT} onPress={onCancel}>
          {t('sipp.reviewPensions.deletePensionDialog.cancelButtonLabel')}
        </Button>
      </Stack>
    </Dialog>
  );
};
