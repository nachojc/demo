import { HeadingGroup, YStack, YStackProps } from '@aviva/ion-mobile';
import { useMaxSteps } from '@direct-wealth/features/sipp-transfer/hooks/use-stepper-values';
import { useNavigation } from '@react-navigation/native';
import { useEffect } from 'react';

import { SippTransferStepper } from '../sipp-transfer-stepper/sipp-transfer-stepper';

type AccessibleHeaderProps = YStackProps & {
  heading: string;
  subHeading?: string;
  step?: number;
  headingAccessibilityLabel?: string;
};

export const AccessibleHeader = ({
  heading,
  subHeading,
  step,
  headingAccessibilityLabel,
  ...props
}: AccessibleHeaderProps) => {
  useInjectAccLabelToNavHeader({
    headingAccessibilityLabel: headingAccessibilityLabel ?? heading,
    step,
  });

  return (
    <YStack marginBottom={'$xxl'} {...props}>
      {step != null && <SippTransferStepper step={step} />}
      <HeadingGroup heading={heading} subHeading={subHeading} />
    </YStack>
  );
};

export const useInjectAccLabelToNavHeader = ({
  headingAccessibilityLabel,
  step,
}: {
  headingAccessibilityLabel: string;
  step?: number;
}) => {
  const simpleWealth = useNavigation();

  const maxSteps = useMaxSteps();
  const stepsTitle = step == null ? ': ' : `, step ${step} of ${maxSteps}. `;
  const titleAccessibilityLabelSuffix = `${stepsTitle}${headingAccessibilityLabel}`;

  // useEffect is preferred here since layout won't be updated
  useEffect(() => {
    // send titleAccessibilityLabelSuffix to the navigation header for accessibility
    // this is only the suffix to be added to the title found in the screen options
    simpleWealth.setOptions({ titleAccessibilityLabelSuffix });
  }, [simpleWealth, titleAccessibilityLabelSuffix]);
};
