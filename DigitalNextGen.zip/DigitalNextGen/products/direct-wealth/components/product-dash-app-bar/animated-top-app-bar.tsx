import {
  FocusAwareStatusBar,
  getVariableValue,
  Icon,
  Stack,
  Text,
  XStack,
} from '@aviva/ion-mobile';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { trackUserEvent } from '@hooks/use-analytics';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { useNavbar } from '@src/common/providers/nav-control';
import { tokens } from '@theme/tokens';
import { useEffect } from 'react';
import Animated from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { Constants } from '../../features/product-view/product-dashboard/constants';
import { theme as makeTheme } from '../tabs/tabsTheme';

export type TopAppBarProps = Partial<NativeStackHeaderProps> & {
  textLabel?: string;
  backAnalyticsTag?: string;
};
export const CollapsibleHeader = ({
  displayName,
  policyNumber,
  onIconPress,
}: {
  displayName: string;
  policyNumber?: string;
  onIconPress?: () => void;
}) => {
  const { POLICY_NUMBER } = Constants;
  return (
    <XStack
      flexDirection="column"
      paddingHorizontal={'$xl'}
      paddingVertical="$lg"
    >
      <Text
        fontVariant="heading3-semibold-White"
        tamaguiTextProps={{
          accessibilityRole: 'header',
        }}
      >
        {displayName}
      </Text>
      {policyNumber && (
        <XStack ai="center">
          <Text
            fontVariant="body-regular-Gray250"
            tamaguiTextProps={{
              accessibilityLabel: `${POLICY_NUMBER} ${policyNumber
                .split('')
                .join(' ')}`,
            }}
          >
            {POLICY_NUMBER}
            <Text
              decoration="underline"
              fontVariant="body-semibold-White"
              tamaguiTextProps={{
                onPress: onIconPress,
              }}
            >
              {policyNumber}
            </Text>
          </Text>
          <Icon
            name={'copy'}
            height={tokens.size[4].val}
            onPress={onIconPress}
            accessibilityRole="button"
            accessibilityLabel={`Copy ${POLICY_NUMBER}`}
            accessibilityElementsHidden={false}
          />
        </XStack>
      )}
    </XStack>
  );
};
export const AnimatedTopAppBar = ({
  textLabel,
  back,
  navigation,
  route,
  backAnalyticsTag,
  ...rest
}: TopAppBarProps) => {
  const insets = useSafeAreaInsets();
  const { reanimatedStyle } = useNavbar();
  const { elementRef, focus } = useA11yFocus();
  const title = rest?.options?.title ?? textLabel ?? route?.name;
  const headerTheme = makeTheme('directWealth');
  const handleBackButtonPress = () => {
    if (backAnalyticsTag) {
      trackUserEvent(backAnalyticsTag);
    }
    return navigation?.goBack();
  };

  const backTitleAccessibilityHint =
    back?.title === 'Bottom tabs' ? (back.title = 'Dashboard') : back?.title;

  useEffect(() => {
    focus();
  }, []);

  return (
    <>
      <FocusAwareStatusBar
        style={headerTheme.statusBar}
        backgroundColor={headerTheme.bg}
      />
      <XStack
        paddingHorizontal={'$xl'}
        paddingTop={insets.top + 8}
        backgroundColor={headerTheme.bg}
        paddingBottom={'$md'}
        accessibilityLabel="Header"
        accessibilityHint={`${title} Header`}
      >
        <Stack flex={1}>
          {back && (
            <Stack
              flex={1}
              onPress={handleBackButtonPress}
              accessible
              accessibilityRole="button"
              accessibilityLabel="Back"
              accessibilityHint={
                back.title
                  ? `Return to ${backTitleAccessibilityHint}`
                  : 'Go back'
              }
              ref={elementRef}
            >
              <Icon
                name={'chevron-left'}
                color={getVariableValue(tokens.color.White)}
                style={{ position: 'relative' }}
              />
            </Stack>
          )}
        </Stack>
        <Stack flex={4} alignItems="center">
          <Animated.View testID="animatedView" style={[reanimatedStyle]}>
            <Text fontVariant={`heading5-semibold-White`}>{title}</Text>
          </Animated.View>
        </Stack>
        <Stack flex={1} justifyContent="flex-end" />
      </XStack>
    </>
  );
};
