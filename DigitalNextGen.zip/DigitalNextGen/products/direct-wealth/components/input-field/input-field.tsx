import { Text, YStack } from '@aviva/ion-mobile';
import { ReactNode } from 'react';

type InputFieldProps = {
  label?: string;
  field: ReactNode;
  withMargin?: boolean;
};

export const InputField = ({ label, field, withMargin }: InputFieldProps) => (
  <YStack space="$lg" marginBottom={withMargin && '$xxl'}>
    {label && <Text fontVariant="body-semibold-Secondary800">{label}</Text>}
    {field}
  </YStack>
);
