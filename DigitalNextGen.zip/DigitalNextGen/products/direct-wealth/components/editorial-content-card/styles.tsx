import { Stack, styled, YStack } from '@aviva/ion-mobile';

export const Container = styled(Stack, {
  variants: {
    variant: {
      large: {
        flexDirection: 'column',
        maxWidth: 207,
      },
      small: {
        flexDirection: 'row',
      },
      iPad: {
        flexDirection: 'row',
        paddingTop: 20,
      },
    },
  } as const,
});

export const CopyContainer = styled(YStack, {
  space: 4,
  variants: {
    variant: {
      large: {
        marginTop: '$md',
      },
      small: {
        flex: 1,
        marginLeft: '$xl',
      },
      iPad: {
        marginHorizontal: '$xl',
        width: 160,
      },
    },
  } as const,
});

export const ToolContainer = styled(YStack, {
  borderRadius: 5,
  alignItems: 'center',
  justifyContent: 'center',
  backgroundColor: '$WealthBlue',
  variants: {
    variant: {
      large: {
        width: '100%',
        height: 112,
      },
      small: {
        width: 107,
        height: 60,
      },

      iPad: {
        width: 107,
      },
    },
  } as const,
});
