import { Icon, IconName, Image, Text } from '@aviva/ion-mobile';
import { tokens } from '@theme/tokens';

import { Container, CopyContainer, ToolContainer } from './styles';

type Content = 'Article' | 'Video' | 'Tool' | 'NoSubtitle';

type EditorialContentCardProps = {
  type: Content;
  title: string;
  variant?: 'small' | 'large' | 'iPad';
  icon?: IconName | null;
  image?: string | null;
  onPress: () => void;
};

export const subtitleMap: {
  [key in Content]: string;
} = {
  Article: 'Read',
  Video: 'Watch',
  Tool: 'Learn more',
  NoSubtitle: '',
};

export const EditorialContentCard = ({
  type,
  title,
  variant = 'large',
  icon,
  image,
  onPress,
}: EditorialContentCardProps) => {
  const isLarge = variant === 'large';
  const hasNoSubtitle = type === 'NoSubtitle';
  const imageHeight = isLarge ? 112 : 60;
  const imageWidth = isLarge ? '100%' : 107;
  const iconSize = isLarge ? 49 : 36;

  return (
    <Container
      variant={variant}
      onPress={onPress}
      testID="editorial-content-card"
    >
      {icon ? (
        <ToolContainer variant={variant} testID="editorial-content-icon">
          <Icon
            name={icon}
            width={iconSize}
            height={iconSize}
            color={tokens.color.White.val}
          />
        </ToolContainer>
      ) : (
        <Image
          accessibilityIgnoresInvertColors
          testID="editorial-content-image"
          source={
            image
              ? { uri: image }
              : require('../../../../assets/gradient/gradient.png')
          }
          style={{
            width: imageWidth,
            height: imageHeight,
            borderRadius: 5,
          }}
        />
      )}
      <CopyContainer variant={variant}>
        <Text
          tamaguiTextProps={{ lineHeight: 20, ellipse: true, numberOfLines: 3 }}
          fontVariant="body-regular-Secondary800"
        >
          {title}
        </Text>
        {!hasNoSubtitle && (
          <Text
            tamaguiTextProps={{ lineHeight: 16 }}
            fontVariant="small-regular-Tertiary800"
            testID="editorial-content-subtitle"
          >
            {subtitleMap[type]}
          </Text>
        )}
      </CopyContainer>
      {!isLarge && (
        <Icon color={tokens.color.Gray400.val} name="chevron-right" />
      )}
    </Container>
  );
};
