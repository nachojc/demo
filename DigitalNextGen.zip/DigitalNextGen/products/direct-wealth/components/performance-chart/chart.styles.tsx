import { Stack, styled } from '@aviva/ion-mobile';

const ShimmerContainer = styled(Stack, {
  paddingVertical: '$xxl',
  width: '100%',
  alignItems: 'center',
  variants: {
    variant: {
      light: {
        backgroundColor: '$White',
      },
      dark: {
        backgroundColor: '$DWPrimary500',
      },
    },
  },
});

const ErrorContainer = styled(Stack, {
  paddingVertical: '$xxl',
  variants: {
    variant: {
      light: {
        backgroundColor: '$White',
      },
      dark: {
        backgroundColor: '$DWPrimary500',
      },
    },
  },
});

const ChartContainer = styled(Stack, {
  minHeight: 320,
  variants: {
    variant: {
      light: {
        backgroundColor: '$White',
      },
      dark: {
        backgroundColor: '$DWPrimary500',
      },
    },
  },
});

export { ChartContainer, ErrorContainer, ShimmerContainer };
