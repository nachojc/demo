import {
  ChartTooltip,
  getVariableValue,
  Shimmer,
  Stack,
  StackProps,
  useDebounceValue,
} from '@aviva/ion-mobile';
import { InvestmentProductPerformanceChartViewModel } from '@direct-wealth/features/product-view/performance-tab/chart/use-investment-product-performance-chart-view-model';
import { FundPerformanceChartViewModel } from '@direct-wealth/features/sipp-transfer/funds/fund-details/fund-performance-tab/use-fund-performance-chart-view-model';
import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { getTestId } from '@src/utils/get-test-id';
import { tokens } from '@theme/tokens';
import { isAfter, subMonths } from 'date-fns';
import { useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Dimensions, useWindowDimensions } from 'react-native';

import {
  ChartTimescale as InvestmentProductTimescale,
  ChartTimescales as InvestmentProductTimescales,
} from '../../common/hooks/use-investment-product-performance';
import {
  ChartTimescale as FundPerformanceTimescale,
  ChartTimescales as FundPerformanceTimescales,
} from '../../common/hooks/use-sipp-transfer-fund-performance';
import { ErrorState } from '../error-state/error-state';
import { GraphSelector } from '../graph/graph-selector';
import { GraphNoDataState } from '../graph-no-data-state/graph-no-data-state';
import { ErrorContainer, ShimmerContainer } from './chart.styles';
import { ChartTooltipProps, DataPoint, GraphTabProps } from './chart.types';
import { PerformanceChartConfig } from './chart-config';

type Timescales = InvestmentProductTimescale & FundPerformanceTimescale;

const ChartGraphTabs = ({
  chartData,
  chartTimescales,
  setChartTimescale,
  isError,
  isLoading,
  isDisabled,
  lightMode,
  trackGraphTimeSelectorTapped,
}: GraphTabProps & {
  chartTimescales:
    | typeof InvestmentProductTimescales
    | typeof FundPerformanceTimescales;
  trackGraphTimeSelectorTapped: (timescale: Timescales) => void;
}) => (
  <GraphSelector
    chartTimescales={chartTimescales}
    selectTimescale={(
      timescale: InvestmentProductTimescale | FundPerformanceTimescale
    ) => {
      trackGraphTimeSelectorTapped(timescale as Timescales);
      setChartTimescale(timescale as Timescales);
    }}
    isLoading={isLoading}
    isDisabled={isDisabled || isError || isLoading}
    chartData={chartData}
    lightMode={lightMode}
  />
);

type Props = {
  model:
    | InvestmentProductPerformanceChartViewModel
    | FundPerformanceChartViewModel;
  startDate: Date;
  variant: 'light' | 'dark';
  containerProps?: StackProps;
  tooltipProps?: Partial<ChartTooltipProps>;
};

export const PerformanceChart = ({
  model,
  startDate,
  variant,
  tooltipProps,
  containerProps,
}: Props) => {
  const { t } = useTranslation();

  const [dataPoint, setDataPoint] = useState<DataPoint>(null);
  const debouncedDataPoint = useDebounceValue(dataPoint, 100);

  const {
    chartType,
    chartTimescale,
    chartTimescales,
    setChartTimescale,
    showNoDataState,
    showGraphTabs,
    formattedChartData,
    labelDisplay,
    dataSourceChartConfig,
    formattedLabelStep,
    errorMessage,
    isError,
    isLoading,
    refetch,
    trackErrorLoadingGraph,
    trackErrorRetryLoadGraphTapped,
    trackGraphTimeSelectorTapped,
  } = model;

  const chartCanvasHeight = 320; // This is Chart container height, if it's something else the inner graph will scroll
  const chartCanvasWidth =
    Dimensions.get('window').width - getVariableValue(tokens.size[6].val);
  const { width } = useWindowDimensions();

  useEffect(() => {
    // When switching to a new timescale, clear selected datapoint and do not show tooltip
    setDataPoint(null);
  }, [chartTimescale, width]);

  const today = new Date();
  const isDisabled = isAfter(startDate, subMonths(today, 1));

  const chartView = useMemo(() => {
    if (isLoading) {
      return (
        <ShimmerContainer variant={variant}>
          <Shimmer
            height={272}
            width={chartCanvasWidth}
            colorScheme={variant}
          />
        </ShimmerContainer>
      );
    }

    if (showNoDataState) {
      return <GraphNoDataState />;
    }

    if (isError) {
      trackErrorLoadingGraph();
      return (
        <ErrorContainer variant={variant}>
          <ErrorState
            onRetry={() => {
              trackErrorRetryLoadGraphTapped();

              refetch();
            }}
            message={
              errorMessage ??
              'Sorry, we were unable to load your activity graph.'
            }
            variant={variant}
            height={272}
            buttonValue="Retry"
            buttonAccessibilityHint="Press to retry loading the data for your activity graph"
          />
        </ErrorContainer>
      );
    }

    return (
      <PerformanceChartConfig
        chartType={chartType}
        chartTimescale={chartTimescale}
        chartData={formattedChartData}
        chartCanvasHeight={chartCanvasHeight}
        labelStep={formattedLabelStep || 0}
        labelDisplay={labelDisplay}
        setDataPoint={setDataPoint}
        variant={variant}
        dataSourceChartConfig={dataSourceChartConfig}
      />
    );
  }, [
    chartCanvasWidth,
    chartTimescale,
    labelDisplay,
    chartType,
    dataSourceChartConfig,
    errorMessage,
    formattedChartData,
    formattedLabelStep,
    isError,
    isLoading,
    refetch,
    showNoDataState,
    trackErrorLoadingGraph,
    trackErrorRetryLoadGraphTapped,
    variant,
  ]);

  return (
    <Stack position="relative" {...containerProps}>
      {debouncedDataPoint && (
        <ChartTooltip
          dataPoint={debouncedDataPoint}
          valueFn={formatCurrencyValue}
          {...tooltipProps}
        />
      )}

      <Stack
        testID={getTestId('chart-view')}
        accessible
        accessibilityLabel={t('pension.performance.chart')}
      >
        {chartView}
      </Stack>

      {showGraphTabs && (
        <ChartGraphTabs
          isDisabled={isDisabled}
          chartTimescales={chartTimescales}
          setChartTimescale={setChartTimescale}
          isError={isError}
          isLoading={isLoading}
          trackGraphTimeSelectorTapped={trackGraphTimeSelectorTapped}
          chartData={formattedChartData}
          lightMode={variant === 'light'}
        />
      )}
    </Stack>
  );
};
