import ReactNativeFusionCharts, {
  ChartObject,
} from 'react-native-fusioncharts';

import { ChartContainer } from './chart.styles';
import { PerformanceChartConfigProps } from './chart.types';

export const PerformanceChartConfig = ({
  chartType,
  chartTimescale,
  chartData,
  chartCanvasHeight,
  labelStep,
  setDataPoint,
  variant,
  dataSourceChartConfig,
  labelDisplay,
}: PerformanceChartConfigProps) => {
  const chartConfig: ChartObject = {
    type: 'spline',
    width: '100%',
    height: chartCanvasHeight,
    dataFormat: 'json',
    dataSource: {
      chart: {
        ...dataSourceChartConfig?.chart,
        labelStep,
        labelDisplay,
      },
      data: chartData,
    },
  };

  const allTimeChartConfig: ChartObject = {
    type: 'scrollline2d',
    width: '100%',
    height: 320,
    dataFormat: 'json',
    dataSource: {
      chart: dataSourceChartConfig?.allTimeChart,
      ...chartData,
    },
  };

  const config =
    chartTimescale === 'SinceInception' && chartType === 'investmentProduct'
      ? allTimeChartConfig
      : chartConfig;

  return (
    <ChartContainer
      importantForAccessibility="no-hide-descendants"
      variant={variant}
    >
      <ReactNativeFusionCharts
        chartConfig={config}
        events={{
          dataPlotRollOver: (e) => {
            const { dataValue, chartX, chartY, displayValue } = e.data;
            setDataPoint({ dataValue, displayValue, chartX, chartY });
          },
          dataPlotRollOut: () => setDataPoint(null),
          scrollStart: () => setDataPoint(null),
        }}
      />
    </ChartContainer>
  );
};
