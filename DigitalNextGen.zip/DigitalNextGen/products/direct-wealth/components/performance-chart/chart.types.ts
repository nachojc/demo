import { InvestmentProductPerformanceChartViewModel } from '@direct-wealth/features/product-view/performance-tab/chart/use-investment-product-performance-chart-view-model';
import { FundPerformanceChartViewModel } from '@direct-wealth/features/sipp-transfer/funds/fund-details/fund-performance-tab/use-fund-performance-chart-view-model';
import {
  AllTimeValuations,
  ChartValuations,
} from 'products/direct-wealth/validation/schemas/investment-product-performance';
import { Dispatch, SetStateAction } from 'react';
import { DataPlotClick } from 'react-native-fusioncharts';

import { ChartTimescale as InvestmentProductTimescale } from '../../common/hooks/use-investment-product-performance';
import { ChartTimescale as FundPerformanceTimescale } from '../../common/hooks/use-sipp-transfer-fund-performance';

export const ChartType = {
  fundPerformance: 'fundPerformance',
  investmentProduct: 'investmentProduct',
} as const;

export type DataPoint = Pick<
  DataPlotClick,
  'displayValue' | 'dataValue' | 'chartX' | 'chartY'
> | null;

export type ChartTooltipProps = {
  dataPoint: NonNullable<DataPoint>;
  variant: 'dark' | 'light';
  valueFn?: (x: number) => string | number;
};

export type ChartData = ChartValuations | AllTimeValuations;

export type GraphTabProps = {
  chartData?: ChartData;
  setChartTimescale:
    | Dispatch<SetStateAction<InvestmentProductTimescale>>
    | Dispatch<SetStateAction<FundPerformanceTimescale>>;
  isError: boolean;
  isLoading: boolean;
  isDisabled: boolean;
  lightMode?: boolean;
};

export const LabelDisplay = {
  auto: 'auto',
  none: 'none',
} as const;

export type PerformanceChartConfigProps = {
  chartType: keyof typeof ChartType;
  chartData?: ChartData;
  chartCanvasHeight: number;
  chartTimescale: InvestmentProductTimescale | FundPerformanceTimescale;
  setDataPoint: (point: DataPoint) => void;
  labelStep: number;
  labelDisplay: keyof typeof LabelDisplay;
  variant: 'dark' | 'light';
  dataSourceChartConfig:
    | InvestmentProductPerformanceChartViewModel['dataSourceChartConfig']
    | FundPerformanceChartViewModel['dataSourceChartConfig'];
};
