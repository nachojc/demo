import { Separator, styled, XStack, YStack } from '@aviva/ion-mobile';

export const Container = styled(YStack, {
  backgroundColor: '$White',
  borderWidth: 1,
  borderColor: '$Gray300',
  borderRadius: 5,
  padding: '$xl',
});

export const Header = styled(XStack, {
  justifyContent: 'space-between',
});

export const Divider = styled(Separator, {
  marginVertical: '$xl',
});

export const Content = styled(YStack, {
  space: '$lg',
});

export const Entry = styled(XStack, {
  justifyContent: 'space-between',
});

export const BodyContainer = styled(YStack, {
  space: '$lg',
});

export const CardButtonContainer = styled(XStack, {
  flexGrow: 0,
  minWidth: 80,
});

export const IconContainer = styled(XStack, {
  margin: 'auto',
});

export const CardHeader = styled(XStack, {
  justifyContent: 'space-between',
  alignItems: 'flex-start',
  marginBottom: '$xl',
  display: 'flex',
});

export const BasePensionDetailsContainer = styled(YStack, {
  backgroundColor: '$White',
  borderRadius: '$2',
  elevation: '$2',
  padding: '$xl',
  borderColor: 'transparent',
  borderWidth: '$xs',
  variants: {
    selected: {
      true: {
        borderColor: '$Success',
        borderWidth: '$xs',
      },
    },
  } as const,
});
