import {
  NumberInput,
  SegmentedControls,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { ReactNode, useState } from 'react';

const TransferOptions = {
  InFull: 'In full',
  InPart: 'In part',
} as const;

type SegmentControl = {
  title: string;
  pensionValue: number;
  onInputChange: ({
    isValid,
    currentValue,
    isSelected,
  }: {
    isValid: boolean;
    currentValue: number;
    isSelected: keyof typeof TransferOptions | undefined;
  }) => void;
  onInputFocus?: () => void;
  onPressOptionOne: () => void;
  onPressOptionTwo: () => void;
};

export const SegementedControl = ({
  title,
  pensionValue,
  onInputChange,
  onInputFocus,
  onPressOptionOne,
  onPressOptionTwo,
}: SegmentControl) => {
  const [valueToTransfer, setValueToTransfer] = useState<string>();
  const [currentSelected, setCurrentSelected] =
    useState<keyof typeof TransferOptions>();
  const errorText =
    Number(valueToTransfer) === 0
      ? 'Value must be greater than 0'
      : 'Amount cannot be greater than the current pension value';

  const isValidFunction = (value: string) => {
    const isValid = Number(value) > 0 && Number(value) <= pensionValue;
    return {
      isValid,
      currentValue: Number(value),
      isSelected: currentSelected,
    };
  };

  return (
    <>
      <Text fontVariant="body-semibold-Secondary800">{title}</Text>
      <SegmentedControls
        styles={{ mx: 0, marginVertical: '$lg' }}
        optionOne={TransferOptions.InFull}
        optionTwo={TransferOptions.InPart}
        onChange={(value) => {
          if (value) {
            setCurrentSelected('InFull');
            onPressOptionOne();
          } else {
            setCurrentSelected('InPart');
            onPressOptionTwo();
          }
        }}
      />
      {currentSelected === 'InPart' ? (
        <InputField
          label={'Value to transfer'}
          field={
            <NumberInput
              required
              symbol="prefix"
              tamaguiInputProps={{
                value: valueToTransfer,
                onChangeText: (value) => {
                  setValueToTransfer(value);
                  onInputChange(isValidFunction(value));
                },
                onFocus: () => {
                  if (onInputFocus) {
                    onInputFocus();
                  }
                },
                placeholder: '0.00',
                keyboardType: 'number-pad',
              }}
              error={
                Number(valueToTransfer) > pensionValue ||
                Number(valueToTransfer) === 0
              }
              errorText={errorText}
            />
          }
        />
      ) : null}
    </>
  );
};

type InputFieldProps = {
  label: string;
  field: ReactNode;
  withMargin?: boolean;
};

const InputField = ({ label, field, withMargin }: InputFieldProps) => (
  <YStack space="$lg" marginBottom={withMargin && '$xxl'}>
    <Text fontVariant="body-semibold-Secondary800">{label}</Text>
    {field}
  </YStack>
);
