import {
  CardActionButton,
  Checkbox,
  Icon,
  IconName,
  Separator,
  Stack,
  StackProps,
  TamaguiTextProps,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import {
  AlertChipExtendable,
  AlertChipExtendableProps,
} from '@aviva/ion-mobile/components/chip/alert-chips';
import { getTestId } from '@src/utils/get-test-id';
import { ReactNode } from 'react';
import { AccessibilityProps, AccessibilityValue } from 'react-native';

import {
  BasePensionDetailsContainer,
  BodyContainer,
  CardButtonContainer,
  CardHeader,
  Container,
  Content,
  Divider,
  Entry,
  Header,
  IconContainer,
} from './styles';

type PensionDetailCardProps = AccessibilityProps & {
  headerText: string;
  onCardPress?: VoidFunction;
  showSeperator?: boolean;
  buttonChildren?: ReactNode;
  children?: ReactNode;
  styles?: StackProps;
  headerStyles?: StackProps;
  textStyles?: TamaguiTextProps;
  buttonStyles?: StackProps;
  selected?: boolean;
};

type IconProps = AccessibilityProps & {
  iconName: IconName | 'checkbox';
  iconText?: string;
  onIconPress?: () => void;
  iconStyles?: StackProps;
};

type PensionContentDetails = { key: string; value?: string }[];

type BasePensionCardProps = {
  headerText: string;
  showSeperator?: boolean;
  onCardPress?: () => void;
  iconInfo: IconProps;
  contentDetails?: PensionContentDetails;
  infoChips?: AlertChipExtendableProps[];
  children?: ReactNode;
  selected?: boolean;
};

type PensionDetails = { key: string; value?: string }[];

export type ActionButton = {
  icon: IconName;
  copy: string;
  accessibilityHint?: string;
  onPress: () => void;
};

type CardButtonProps = AccessibilityProps & {
  name?: IconName | 'checkbox';
  text?: string;
  onIconPress?: () => void;
  styles?: StackProps;
  selected?: boolean;
};

const CardButton = ({
  name = 'delete',
  text,
  onIconPress,
  accessible = false,
  accessibilityLabel,
  accessibilityHint,
  accessibilityValue,
  styles,
  selected,
}: CardButtonProps) => {
  return (
    <IconContainer
      onPress={onIconPress}
      accessible={accessible}
      accessibilityLabel={accessibilityLabel}
      accessibilityHint={accessibilityHint}
      accessibilityValue={accessibilityValue}
      accessibilityRole="button"
      marginRight={name === 'checkbox' ? '$-md' : 0}
      {...styles}
    >
      {name === 'checkbox' ? (
        <Checkbox
          testID="selection-card-checkbox"
          value={selected}
          onValueChange={onIconPress}
          error={false}
        />
      ) : (
        <Icon name={name} width={20} height={20} />
      )}
      <Text fontVariant="body-semibold-Tertiary800">{text}</Text>
    </IconContainer>
  );
};

const PensionEntry = ({
  leftText,
  leftTestId,
  rightText,
  rightTestId,
}: {
  leftText: string;
  leftTestId?: string;
  rightText?: string;
  rightTestId?: string;
}) => (
  <Entry>
    <Text
      fontVariant="body-regular-Gray800"
      tamaguiTextProps={{ marginRight: '$sm' }}
      testID={leftTestId}
    >
      {leftText}
    </Text>
    <Text
      fontVariant="body-semibold-Gray800"
      tamaguiTextProps={{ flex: 1, flexWrap: 'wrap', textAlign: 'right' }}
      testID={rightTestId}
    >
      {rightText}
    </Text>
  </Entry>
);

export const PensionDetailsCard = ({
  heading,
  pensionDetails,
  actionButton,
}: {
  heading: string;
  pensionDetails: PensionDetails;
  actionButton?: ActionButton;
}) => {
  const accessibilityLabel = `${heading}. ${pensionDetails
    .map((i) => `'${i.key}: ${i.value}'`)
    .join('. ')}`;
  return (
    <Stack>
      <Container accessible accessibilityLabel={accessibilityLabel}>
        <Header>
          <Text
            fontVariant="body-semibold-Secondary800"
            tamaguiTextProps={{ flex: 1, marginRight: '$xl' }}
          >
            {heading}
          </Text>
          {actionButton ? (
            <Stack>
              <CardActionButton
                text={actionButton.copy}
                icon={actionButton.icon}
                onPress={actionButton.onPress}
                accessibilityHint={actionButton.accessibilityHint}
              />
            </Stack>
          ) : null}
        </Header>
        <Divider />
        <Content>
          {pensionDetails.map((entry) => (
            <Entry key={`${entry.key}-${entry.value}`}>
              <Text
                fontVariant="body-regular-Gray800"
                testID={getTestId(`pension-details-card-${entry.key}`)}
              >
                {entry.key}
              </Text>
              <Text
                fontVariant="body-semibold-Gray800"
                testID={getTestId(`pension-details-card-${entry.key}-value`)}
                tamaguiTextProps={{ marginLeft: '$xl' }}
              >
                {entry.value}
              </Text>
            </Entry>
          ))}
        </Content>
      </Container>
    </Stack>
  );
};

/**
 * @description Base template for Pension Details cards.
 * @param accessible Is default to true, ensuring that the parent container is the focus.
 * Passing a property of accessible={false}, will allow the children: Header Text, Button and Children to be in focus.
 * @returns JSX.Element
 */
export const DetailsCardBase = ({
  headerText,
  onCardPress,
  showSeperator = true,
  buttonChildren,
  accessible = true,
  accessibilityLabel,
  accessibilityRole,
  accessibilityHint,
  accessibilityValue,
  styles,
  headerStyles,
  textStyles,
  buttonStyles,
  children,
  selected,
}: PensionDetailCardProps) => {
  return (
    <BasePensionDetailsContainer
      selected={selected}
      onPress={onCardPress}
      accessible={accessible}
      accessibilityLabel={accessibilityLabel}
      accessibilityRole={accessibilityRole}
      accessibilityHint={accessibilityHint}
      accessibilityValue={accessibilityValue}
      {...styles}
      testID={getTestId('pension-details-card')}
    >
      <CardHeader {...headerStyles}>
        <Text
          testID={getTestId('pension-details-card-header')}
          fontVariant="body-semibold-Secondary800"
          tamaguiTextProps={{
            flex: 1,
            accessible: !accessible,
            ...textStyles,
          }}
        >
          {headerText}
        </Text>
        {buttonChildren ? (
          <CardButtonContainer {...buttonStyles} accessible={!accessible}>
            {buttonChildren}
          </CardButtonContainer>
        ) : null}
      </CardHeader>
      {showSeperator ? <Separator marginBottom={'$md'} /> : null}
      <YStack accessible={!accessible}>{children}</YStack>
    </BasePensionDetailsContainer>
  );
};

export const BasePensionDetailsCard = ({
  headerText,
  onCardPress,
  iconInfo,
  contentDetails = [],
  infoChips = [],
  children,
  showSeperator = true,
  selected,
}: BasePensionCardProps) => {
  return (
    <DetailsCardBase
      headerText={headerText}
      onCardPress={onCardPress}
      accessible={!iconInfo.accessible}
      showSeperator={showSeperator}
      selected={selected}
      buttonChildren={
        <CardButton
          selected={selected}
          name={iconInfo.iconName}
          text={iconInfo.iconText}
          onIconPress={iconInfo.onIconPress}
          styles={iconInfo.iconStyles}
          accessible={iconInfo.accessible}
          accessibilityHint={iconInfo.accessibilityHint}
          accessibilityLabel={iconInfo.accessibilityLabel}
        />
      }
    >
      <BodyContainer accessible>
        {contentDetails.map((entry, index) => (
          <PensionEntry
            key={`${entry.key}-${entry.value}`}
            leftText={entry.key}
            leftTestId={getTestId(`pension-details-card-item-${index}-label`)}
            rightText={entry.value}
            rightTestId={getTestId(`pension-details-card-item-${index}-value`)}
          />
        ))}
      </BodyContainer>

      {infoChips.length ? (
        <XStack
          marginTop={'$lg'}
          flexDirection="column"
          alignItems="flex-start"
        >
          {infoChips.map((entry) => (
            <AlertChipExtendable
              key={`${entry.name}-${entry.text}`}
              name={entry.name}
              testID={entry.testID}
              text={entry.text}
              variant={entry.variant}
            />
          ))}
        </XStack>
      ) : null}
      {children}
    </DetailsCardBase>
  );
};

export const PensionDetailsCardSlimLine = ({
  headerText,
  contentDetails = [],
  accessibilityLabel = 'Pension Details Card',
  accessibilityHint,
  accessibilityValue,
}: {
  headerText: string;
  contentDetails?: PensionContentDetails;
  accessibilityHint?: string;
  accessibilityLabel?: string;
  accessibilityValue?: AccessibilityValue;
}) => {
  return (
    <DetailsCardBase
      headerText={headerText}
      accessibilityHint={accessibilityHint}
      accessibilityLabel={accessibilityLabel}
      accessibilityValue={accessibilityValue}
    >
      <BodyContainer>
        {contentDetails.map((entry) => (
          <PensionEntry
            key={`${entry.key}-${entry.value}`}
            leftText={entry.key}
            rightText={entry.value}
          />
        ))}
      </BodyContainer>
    </DetailsCardBase>
  );
};
