import { IconName } from '@aviva/ion-mobile';

export type ActionCardProps = {
  title: string;
  titleAccessibilityLabel?: string;
  showProgress?: boolean;
  bodyText?: string;
  progressSegments?: number;
  progress?: number;
  progressTitle?: string;
  iconLeft: IconName;
  iconRight?: IconName;
  iconRightColor?: string;
};
