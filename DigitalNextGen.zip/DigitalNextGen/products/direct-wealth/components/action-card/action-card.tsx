import {
  Icon,
  Stack,
  TamaguiProgress,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { useCallback } from 'react';

import { ActionCardProps } from './types';

export const ActionCard = ({
  title,
  bodyText,
  showProgress = true,
  progressSegments = 7,
  progress = 0,
  progressTitle = 'Introduction',
  iconLeft = 'alert-triangle-outline',
  iconRight,
  iconRightColor,
}: ActionCardProps) => {
  const progressBar = useCallback(() => {
    const segments = Array.from({ length: progressSegments }, (_, i) => {
      let segmentColour = '$Information';
      if (progressSegments <= progress) {
        segmentColour = '$Success';
      }
      return (
        <Stack key={i} flex={1}>
          <TamaguiProgress
            minWidth={0}
            borderRadius="$2"
            height="$2"
            backgroundColor={segmentColour}
            opacity={i < progress ? 1 : 0.4}
            testID={getTestId('progress-segment')}
          >
            <TamaguiProgress.Indicator
              backgroundColor={segmentColour}
              opacity={i < progress ? 1 : 0.4}
            />
          </TamaguiProgress>
        </Stack>
      );
    });
    return segments;
  }, [progress, progressSegments]);

  return (
    <YStack
      backgroundColor="$White"
      borderRadius="$2"
      borderColor={
        progressSegments <= progress
          ? tokens.color.Success.val
          : tokens.color.Gray200.val
      }
      borderWidth="$xxs"
      padding="$xl"
      marginVertical="$xl"
      testID={getTestId('action-card')}
    >
      <YStack marginBottom={'$sm'}>
        <XStack>
          <Icon
            testID={getTestId(`icon-left-${title}-${iconLeft}`)}
            name={iconLeft}
            color={
              progressSegments <= progress
                ? tokens.color.Success.val
                : tokens.color.Teal600.val
            }
          />
          <Text
            tamaguiTextProps={{
              marginLeft: '$md',
              marginRight: 'auto',
            }}
            fontVariant="body-semibold-Wealth600"
          >
            {title}
          </Text>
          {iconRight && (
            <Icon
              name={iconRight}
              testID={getTestId(`icon-right-${title}`)}
              color={iconRightColor || undefined}
            />
          )}
        </XStack>
      </YStack>
      {bodyText && (
        <Text
          fontVariant="small-regular-WealthBlue"
          tamaguiTextProps={{ marginHorizontal: '$xxxl' }}
        >
          {bodyText}
        </Text>
      )}
      {showProgress && (
        <YStack
          marginTop="$xl"
          marginLeft="$xxxl"
          testID={getTestId('progress-bar-container')}
        >
          <XStack justifyContent="space-between" space="$space.sm">
            {progressBar()}
          </XStack>
          <Text
            fontVariant="overline-regular-Gray800"
            tamaguiTextProps={{ justifyContent: 'space-between', mt: '$sm' }}
          >
            {`${progress} of ${progressSegments} - ${progressTitle}`}
          </Text>
        </YStack>
      )}
    </YStack>
  );
};
