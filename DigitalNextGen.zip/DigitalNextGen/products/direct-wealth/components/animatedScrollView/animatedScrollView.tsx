import { ReactNode, useCallback } from 'react';
import {
  NativeScrollEvent,
  NativeSyntheticEvent,
  ScrollView,
} from 'react-native';

type AnimatedScrollWrapperProps = {
  children: ReactNode;
  setIsOpen: (value: boolean) => void;
  isOpen: boolean;
};

export const AnimatedScrollWrapper = ({
  children,
  setIsOpen,
  isOpen,
}: AnimatedScrollWrapperProps) => {
  const handleScroll = useCallback(
    (event: NativeSyntheticEvent<NativeScrollEvent>) => {
      if (event.nativeEvent.contentOffset.y > 50 && isOpen) {
        setIsOpen(false);
      }
      if (
        event.nativeEvent.contentOffset.y <= 50 &&
        event.nativeEvent.contentOffset.y !== 0 &&
        !isOpen
      ) {
        setIsOpen(true);
      }
    },
    [isOpen, setIsOpen]
  );

  return (
    <ScrollView
      onScrollBeginDrag={(e) => handleScroll(e)}
      onScroll={(e) => handleScroll(e)}
      scrollEventThrottle={1}
      bounces={false}
      testID="animatedScrollView"
      overScrollMode="never"
      showsVerticalScrollIndicator={false}
    >
      {children}
    </ScrollView>
  );
};
