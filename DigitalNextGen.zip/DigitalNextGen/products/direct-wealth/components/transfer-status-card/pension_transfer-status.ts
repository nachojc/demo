import { Transfer } from './types';

export const PENSION_TRANSFER_STATUS: Transfer = {
  EligibleToTransfer: {
    status: 'EligibleToTransfer',
    chipTitle: 'Eligible to transfer',
    iconName: 'tick',
    variant: 'success',
    statusProgress: [0, 0, 0],
  },
  MayLoseBenefits: {
    status: 'MayLoseBenefits',
    chipTitle: 'You may lose benefits',
    iconName: 'info',
    variant: 'information',
    statusProgress: [0, 0, 0],
  },
  InTransfer: {
    status: 'InTransfer',
    chipTitle: 'Transfer in progress',
    iconName: 'clock',
    variant: 'information',
    statusProgress: [100, 100, 30],
    bodyText:
      'We are processing the pension transfer from your Current Provider.',
  },
  NotSpecified: {
    status: 'NotSpecified',
    chipTitle: '',
    iconName: 'alert-circle',
    variant: 'error',
    statusProgress: [0, 0, 0],
  },
  TransferReceived: {
    status: 'TransferReceived',
    chipTitle: 'Transfer received',
    iconName: 'clock',
    variant: 'information',
    statusProgress: [0, 0, 0],
  },
  TransferRequested: {
    status: 'TransferRequested',
    chipTitle: 'Transfer requested',
    iconName: 'clock',
    variant: 'information',
    statusProgress: [100, 0, 0],
    bodyText:
      'We are checking your transfer application details and will shortly request the transfer from your Current Provider.',
  },
  TransferInitiated: {
    status: 'TransferInitiated',
    chipTitle: 'Transfer initiated',
    iconName: 'clock',
    variant: 'information',
    statusProgress: [100, 100, 0],
    bodyText:
      "We have requested the pension transfer from your Current Provider and we're waiting for their response.",
  },
  TransferInProgress: {
    status: 'TransferInProgress',
    chipTitle: 'Transfer in progress',
    iconName: 'clock',
    variant: 'information',
    statusProgress: [100, 100, 30],
    bodyText:
      'We are processing the pension transfer from your Current Provider.',
  },
  Completed: {
    status: 'Completed',
    chipTitle: 'Transfer complete',
    iconName: 'tick',
    variant: 'success',
    statusProgress: [100, 100, 100],
    bodyText:
      "Your money is with Aviva, you may wish to choose your investment options if you haven't already.",
  },
  FurtherInformationRequired: {
    status: 'FurtherInformationRequired',
    chipTitle: 'More information needed',
    iconName: 'info',
    variant: 'warning',
    showProgress: false,
    statusProgress: [0, 0, 0],
    bodyTextWithPhoneNumber:
      "You should have received instruction on what we need you to do before we can proceed. If you haven't received instructions or you’re unsure then please call us on {{phone}}",
    bodyTextWithWebLink:
      'You should have received instruction on what we need you to do before we can proceed. If you haven’t received instructions or you’re unsure then please {{webview}}',
  },
  Cancelled: {
    status: 'Cancelled',
    chipTitle: 'Transfer cancelled',
    iconName: 'alert-circle',
    variant: 'error',
    showProgress: false,
    bodyText:
      'Your pension transfer request has been cancelled. If you change your mind, initiate a new transfer.',
    statusProgress: [0, 0, 0],
  },
} as const;
