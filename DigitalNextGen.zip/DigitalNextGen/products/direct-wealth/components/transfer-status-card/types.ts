import { IconName } from '@aviva/ion-mobile';
import { ChipVariant } from '@aviva/ion-mobile/components/chip/alert-chips';
import { TextWithLinksTemplate } from '@aviva/ion-mobile/components/text-with-links/types';
import {
  TransferInformation,
  TransferStatus,
} from '@direct-wealth/validation/schemas/pension-consolidation-summary';
import { Aviva_Digital_MobileApi_Endpoints_Support_Model_OpenHoursModel } from '@src/api/generated/requests';

type ExtendedTransferStatus = TransferStatus | TransferInformation;

type StatusValues<T extends ExtendedTransferStatus> = {
  status: T;
  chipTitle: string;
  iconName: IconName;
  variant: ChipVariant;
  showProgress?: boolean;
  statusProgress: Readonly<[number, number, number]>;
  bodyText?: string;
  bodyTextWithPhoneNumber?: TextWithLinksTemplate<'phone'>;
  bodyTextWithWebLink?: TextWithLinksTemplate<'webview'>;
  webView?: string | null;
};
export type Transfer = { [K in ExtendedTransferStatus]: StatusValues<K> };
export type StatusCardProps = {
  title: string;
  titleAccessibilityLabel?: string;
  transferStatus: keyof Transfer;
  showSeparator?: boolean;
  phoneNumber?: string | null;
  openHours?:
    | Aviva_Digital_MobileApi_Endpoints_Support_Model_OpenHoursModel[]
    | null;
  navigateToHelpAndSupport?: () => void;
};
