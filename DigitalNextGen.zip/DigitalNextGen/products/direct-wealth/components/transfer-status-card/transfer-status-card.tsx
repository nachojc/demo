import {
  PhoneCallDialog,
  Separator,
  Stack,
  TamaguiProgress,
  Text,
  TextWithLinks,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { AlertChipExtendable } from '@aviva/ion-mobile/components/chip/alert-chips';
import { AlertChipText } from '@aviva/ion-mobile/components/chip/chip.styles';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { callPhoneNumber } from '@src/utils/phone-link';
import { useState } from 'react';

import { PENSION_TRANSFER_STATUS } from './pension_transfer-status';
import { StatusCardProps } from './types';

export const TransferStatusCard = ({
  title,
  titleAccessibilityLabel,
  transferStatus,
  showSeparator = true,
  phoneNumber,
  openHours,
  navigateToHelpAndSupport,
}: StatusCardProps) => {
  const {
    bodyText,
    bodyTextWithPhoneNumber,
    bodyTextWithWebLink,
    chipTitle,
    iconName,
    showProgress = true,
    statusProgress,
    variant,
  } = PENSION_TRANSFER_STATUS[transferStatus];

  const iPadSafeBodyTextWithPhoneNumber = isIpad
    ? bodyTextWithPhoneNumber?.replace('{{phone}}', phoneNumber || '')
    : bodyTextWithPhoneNumber;

  const progressColour =
    statusProgress[2] === 100 ? '$Success' : '$Information';

  const [showCallUsDialog, setShowCallUsDialog] = useState(false);
  const callNumber = () => {
    callPhoneNumber(phoneNumber);
  };

  return (
    <YStack
      backgroundColor="$White"
      borderRadius="$2"
      borderColor={'$Gray200'}
      borderWidth="$xxs"
      padding="$xl"
      marginVertical="$xl"
    >
      <YStack
        accessible
        accessibilityLabel={`${titleAccessibilityLabel ?? title}, ${chipTitle}`}
      >
        <Text fontVariant="heading5-semibold-Wealth600">{title}</Text>
        <YStack
          marginTop="$md"
          marginBottom="$xl"
          flexDirection="column"
          alignItems="flex-start"
          importantForAccessibility="no-hide-descendants"
        >
          <AlertChipExtendable
            name={iconName}
            text={<AlertChipText size={'sm'}>{chipTitle}</AlertChipText>}
            variant={variant}
          />
        </YStack>
        {showProgress && (
          <YStack
            marginTop="$md"
            marginBottom="$xl"
            testID="progress-bar-container"
          >
            <XStack justifyContent="space-between" space="$space.sm">
              <Stack flex={1}>
                <TamaguiProgress
                  minWidth={0}
                  value={statusProgress[0]}
                  borderRadius="$2"
                  height="$2"
                  backgroundColor="$Gray300"
                >
                  <TamaguiProgress.Indicator backgroundColor={progressColour} />
                </TamaguiProgress>
              </Stack>
              <Stack flex={1}>
                <TamaguiProgress
                  minWidth={0}
                  value={statusProgress[1]}
                  borderRadius="$2"
                  height="$2"
                  backgroundColor="$Gray300"
                >
                  <TamaguiProgress.Indicator backgroundColor={progressColour} />
                </TamaguiProgress>
              </Stack>
              <Stack flex={1}>
                <TamaguiProgress
                  minWidth={0}
                  value={statusProgress[2]}
                  borderRadius="$2"
                  height="$2"
                  backgroundColor="$Gray300"
                >
                  <TamaguiProgress.Indicator
                    borderRadius="$2"
                    backgroundColor={progressColour}
                  />
                </TamaguiProgress>
              </Stack>
            </XStack>
            <XStack justifyContent="space-between" marginTop="$sm">
              <Text fontVariant="overline-regular-Gray800">Start Transfer</Text>
              <Text fontVariant="overline-regular-Gray800">
                Transfer Completed
              </Text>
            </XStack>
          </YStack>
        )}
      </YStack>
      {showSeparator && <Separator testID="separator" borderColor="$Gray200" />}
      {bodyText && (
        <YStack marginTop="$xl">
          <Text fontVariant="body-regular-Gray800">{bodyText}</Text>
        </YStack>
      )}
      {phoneNumber && iPadSafeBodyTextWithPhoneNumber ? (
        <YStack marginTop="$xl">
          <PhoneCallDialog
            testID={getTestId('call-us-modal')}
            open={showCallUsDialog}
            phone="ready-to-transfer-screen-phone"
            onCancelPress={() => setShowCallUsDialog(false)}
            onCallPress={() => {
              setShowCallUsDialog(false);
              callNumber();
            }}
          />
          <TextWithLinks<typeof iPadSafeBodyTextWithPhoneNumber>
            fontVariant="body-regular-Gray800"
            tamaguiTextProps={{
              marginTop: '$xl',
            }}
            template={iPadSafeBodyTextWithPhoneNumber}
            links={{
              phone: {
                text: phoneNumber,
                onPress: () => {
                  setShowCallUsDialog(true);
                },
                props: {
                  color: '$Tertiary800',
                  fontWeight: '$bold',
                },
              },
            }}
          />
          {openHours && (
            <Text
              fontVariant="body-regular-Secondary800"
              tamaguiTextProps={{ marginTop: '$xl' }}
            >
              ({openHours[0].day} {openHours[0].time} and {openHours[1].day}{' '}
              {openHours[1].time})
            </Text>
          )}
        </YStack>
      ) : (
        bodyTextWithWebLink && (
          <YStack marginTop="$xl">
            <TextWithLinks<typeof bodyTextWithWebLink>
              fontVariant="body-regular-Gray800"
              template={bodyTextWithWebLink}
              links={{
                webview: {
                  text: 'visit our contact information page',
                  onPress: () => {
                    navigateToHelpAndSupport?.();
                  },
                  props: {
                    color: '$Tertiary800',
                    fontWeight: '$bold',
                  },
                },
              }}
            />
          </YStack>
        )
      )}
    </YStack>
  );
};
