import { FontVariant, Stack, Text as IonText, YStack } from '@aviva/ion-mobile';
import { LoadingSpinner } from '@aviva/ion-mobile/components/loading-spinner';
import { FullScreenLoadingState } from '@aviva/ion-mobile/components/loading-state/fullscreen-loading-state';
import { getTestId } from '@src/utils/get-test-id';
import { ReactNode } from 'react';

type LoadingStateProps = {
  title?: string | null;
  text?: string | null;
};

export const LoadingState = (props: LoadingStateProps) => {
  const { title, text } = props;
  return (
    <FullScreenLoadingState>
      <YStack
        backgroundColor="$White"
        borderRadius={10}
        pt={63}
        pb={text ? 36 : 63}
        px={20}
        alignItems="center"
        width={311}
        maxWidth="95%"
        testID={getTestId('loading-state')}
      >
        <LoadingSpinner />
        {text || title ? (
          <Stack alignSelf="stretch" mt={36} px={20}>
            {title ? (
              <Text fontVariant="small-bold-Gray800">{title}</Text>
            ) : null}
            {text ? (
              <Text fontVariant="small-regular-Gray800">{text}</Text>
            ) : null}
          </Stack>
        ) : null}
      </YStack>
    </FullScreenLoadingState>
  );
};

const Text = ({
  fontVariant,
  children,
}: {
  fontVariant: FontVariant;
  children: ReactNode;
}) => (
  <IonText
    fontVariant={fontVariant}
    tamaguiTextProps={{
      textAlign: 'center',
      lineHeight: 17.6,
    }}
  >
    {children}
  </IonText>
);
