import { styled } from '@aviva/ion-mobile';
import { View } from 'react-native';

export const WebViewContainer = styled(View, {
  position: 'relative',
  height: 100,
  borderWidth: '$xxs',
  borderColor: '$Gray300',
  borderRadius: '$4',
  overflow: 'hidden',
  justifyContent: 'center',
});

export const PlaceholderText = styled(View, {
  position: 'absolute',
  alignSelf: 'center',
});
