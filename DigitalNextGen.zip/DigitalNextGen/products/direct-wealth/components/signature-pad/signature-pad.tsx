import {
  Button,
  CardActionButton,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useRef, useState } from 'react';
import { Dimensions, SafeAreaView } from 'react-native';
import WebView, { WebViewMessageEvent } from 'react-native-webview';

import {
  clearSignatureScript,
  drawingPadScript,
  onLoadEnd,
} from './drawing-pad/drawing-pad.script';
import { drawingPadHtml } from './drawing-pad/drawing-pad-html';
import { PlaceholderText, WebViewContainer } from './styles';

type SignaturePadProps = {
  onClearPress?: () => void;
  onDonePress: (signatureValue: string) => void;
  screenOrientation?: 'landscape' | 'portrait';
};

const screenWidth = Dimensions.get('window').width;
const screenHeight = Dimensions.get('window').height;

export const SignaturePad = ({
  onClearPress,
  onDonePress,
  screenOrientation = 'portrait',
}: SignaturePadProps) => {
  const [signValue, setSignValue] = useState<string>('');
  const [showPlaceholder, setShowPlaceholder] = useState<boolean>(true);
  const webViewRef = useRef<WebView>(null);
  const signaturePadWidth =
    screenOrientation === 'landscape' ? screenHeight : screenWidth;

  const { t } = useTranslationDW({ keyPrefix: 'signaturePad' });

  const clearSignature = () => {
    if (!!signValue && webViewRef?.current) {
      webViewRef.current.injectJavaScript(`${clearSignatureScript}; true;`);
    }

    setShowPlaceholder(true);
    onClearPress?.();
  };

  const onLoad = () => {
    webViewRef?.current?.injectJavaScript(`${onLoadEnd}; true;`);
  };

  const doneHandler = () => {
    onDonePress(signValue);
  };

  const onMessageHandler = (event: WebViewMessageEvent) => {
    event.nativeEvent.data === 'hide placeholder'
      ? setShowPlaceholder(false)
      : setSignValue(event.nativeEvent.data);
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <YStack
        justifyContent="space-between"
        flex={isIpad ? undefined : 1}
        paddingVertical="$md"
        gap={isIpad ? '$xxxl' : undefined}
      >
        <Text
          fontVariant="heading4-semibold-Gray800"
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          {t('message')}
        </Text>
        <WebViewContainer>
          <WebView
            style={{ width: signaturePadWidth }}
            ref={webViewRef}
            source={{ html: drawingPadHtml }}
            injectedJavaScript={drawingPadScript}
            javaScriptEnabled
            onMessage={onMessageHandler}
            accessible
            accessibilityLabel={t('signatureA11YLabel')}
            scalesPageToFit
            androidLayerType="hardware"
            onLoadEnd={onLoad}
          />
          {!signValue && showPlaceholder && (
            <PlaceholderText pointerEvents="none">
              <Text fontVariant="heading5-regular-Gray500">
                {t('placeholderText')}
              </Text>
            </PlaceholderText>
          )}
        </WebViewContainer>
        <XStack justifyContent="space-between">
          <CardActionButton
            text={t('clearButtonText')}
            icon="delete"
            onPress={clearSignature}
            accessibilityHint={t('clearButtonA11YHint')}
            testID={getTestId('clear-button')}
          />
          <Button
            width={340}
            maxWidth={'50%'}
            onPress={doneHandler}
            accessibilityHint={t('continueButtonA11YHint')}
            testID={getTestId('done-button')}
          >
            {t('continueButtonText')}
          </Button>
        </XStack>
      </YStack>
    </SafeAreaView>
  );
};
