import {
  Avatar,
  FocusAwareStatusBar,
  Icon,
  Stack,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { ACTION_WEALTH_PORTFOLIO_SUMMARY_MESSAGE_CENTER_CLICKED } from '@direct-wealth/features/portfolio-summary/analytics';
import { useDirectWealthTabStackNavigation } from '@direct-wealth/navigation/hooks';
import { useAnalytics } from '@hooks/use-analytics';
import { useGreetingMessage } from '@hooks/use-greeting-message';
import { useMessageCenterReadStatus } from '@hooks/use-messages';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { memo, useMemo } from 'react';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { theme } from '../tabs/tabsTheme';

/**
 * @description
 * Global Header component providing greeting message and mail icon
 * navigating to Message Center.
 *
 * @example
 * Intended usage within a navigation stack screen header.
 * <Stack.Screen
      options={{
        header: () => <GlobalHeader />,
        contentStyle: { backgroundColor: headerTheme.bg },
      }}
      name="ExampleScreen"
      getComponent={() => require(<path of the screen file>).ExampleScreen}
  />
 */

export const PortfolioSummaryHeader = () => {
  const { bg, headerTextColor, statusBar } = theme('directWealth');
  const greetingMessage = useGreetingMessage();
  const safeAreaTop = useSafeAreaInsets().top;
  return (
    <YStack paddingTop={tokens.space.lg.val + safeAreaTop} backgroundColor={bg}>
      <FocusAwareStatusBar style={statusBar} backgroundColor={bg} />
      <XStack
        testID="header-content"
        paddingHorizontal="$xl"
        paddingBottom="$lg"
        justifyContent={'space-between'}
        backgroundColor={bg}
      >
        <Text
          testID={getTestId('greeting-message')}
          tamaguiTextProps={{
            accessibilityLabel: greetingMessage,
            accessibilityRole: 'header',
            color: headerTextColor,
          }}
          fontVariant={`heading4-semibold-White`}
        >
          {greetingMessage}
        </Text>
        <NotificationIcon />
      </XStack>
    </YStack>
  );
};

const NotificationIcon = memo(() => {
  const { navigate } = useDirectWealthTabStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const { hasUnreadMessages } = useMessageCenterReadStatus();
  const onIconPress = () => {
    trackUserEvent(ACTION_WEALTH_PORTFOLIO_SUMMARY_MESSAGE_CENTER_CLICKED);
    navigate('app', { screen: 'Messages' });
  };

  const showUnreadMessageIcon = useMemo(
    () => hasUnreadMessages(),
    [hasUnreadMessages]
  );

  return (
    <Stack
      position="relative"
      onPress={onIconPress}
      accessible
      accessibilityRole="button"
      accessibilityLabel={`Message centre, you have ${
        showUnreadMessageIcon ? '' : 'no'
      }new messages.`}
      accessibilityHint={'Navigates to Message Centre'}
      testID={getTestId('email-icon')}
    >
      <Icon name="mail" color={theme('directWealth').text} />
      {showUnreadMessageIcon && (
        <Avatar
          right={'-25%'}
          top={'-20%'}
          position="absolute"
          backgroundColor={'$Primary500'}
          circular
          size={'$4'}
          testID="messages-unread-circle"
        />
      )}
    </Stack>
  );
});
