import { getTokens, getVariableValue, styled, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

export const ErrorMessageContainer = styled(YStack, {
  space: '$xl',
  borderWidth: '$xxs',
  alignItems: 'center',
  tablet: isIpad,
  justifyContent: 'center',
  borderRadius: getVariableValue(getTokens().size[3]),
  paddingHorizontal: getVariableValue(getTokens().size[10]),

  variants: {
    variant: {
      light: {
        backgroundColor: getVariableValue(getTokens().color.White),
        borderColor: getVariableValue(getTokens().color.Gray300),
      },
      dark: {
        backgroundColor: getVariableValue(getTokens().color.DWPrimary500),
        borderColor: getVariableValue(getTokens().color.Gray700),
      },
      transparent: {
        backgroundColor: 'transparent',
        borderColor: getVariableValue(getTokens().color.Gray300),
      },
      'transparent-square': {
        backgroundColor: 'transparent',
        borderColor: getVariableValue(getTokens().color.Gray300),
        borderRadius: 0,
        borderTopColor: 'transparent',
        borderLeftWidth: 0,
        borderRightWidth: 0,
      },
    },
  },
} as const);
