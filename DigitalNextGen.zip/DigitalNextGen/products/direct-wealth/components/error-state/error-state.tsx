import {
  getTokens,
  getVariableValue,
  Icon,
  Link,
  Text,
} from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';

import { ErrorMessageContainer } from './styles';

type ErrorStateProps = {
  variant: 'light' | 'dark' | 'transparent' | 'transparent-square';
  message: string;
  buttonValue: string;
  onRetry: () => void;
  buttonAccessibilityHint: string;
  height?: number;
};

export const ErrorState = ({
  onRetry,
  message,
  variant,
  buttonValue,
  buttonAccessibilityHint,
  height,
}: ErrorStateProps) => {
  const tokens = getTokens();
  const iconSize = getVariableValue(tokens.size[7]);
  const lightStyling =
    variant === 'light' ||
    variant === 'transparent' ||
    variant === 'transparent-square';

  return (
    <ErrorMessageContainer
      variant={variant}
      accessibilityLabel="Error"
      accessibilityHint="Error Message Container"
      height={height ?? 'auto'}
    >
      <Icon
        name="alert-circle-outline"
        color={getVariableValue(
          tokens.color[lightStyling ? 'WealthBlue' : 'White']
        )}
        height={iconSize}
        width={iconSize}
      />
      <Text
        fontVariant={
          lightStyling ? 'body-regular-Gray900' : 'body-regular-White'
        }
        tamaguiTextProps={{ textAlign: 'center' }}
      >
        {message}
      </Text>
      <Link
        variant={lightStyling ? 'link' : 'dwPrimaryLink'}
        onPress={onRetry}
        style={{ alignSelf: 'center' }}
        accessibilityLabel={buttonValue}
        accessibilityHint={buttonAccessibilityHint}
        testID={getTestId('link-container')}
      >
        {buttonValue}
      </Link>
    </ErrorMessageContainer>
  );
};
