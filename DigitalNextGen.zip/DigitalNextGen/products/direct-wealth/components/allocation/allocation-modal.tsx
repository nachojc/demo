import {
  BulletPoint,
  DynamicHeightModal,
  Stack,
  Text,
  XStack,
} from '@aviva/ion-mobile';
import { useTranslationDW } from '@src/i18n/hooks/useTranslationDW';

export type ModalVariant = 'consider' | 'learn';

type ModalProps = {
  isOpen: boolean;
  onClose: () => void;
  variant: ModalVariant;
};

export const AllocationModal = ({ isOpen, onClose, variant }: ModalProps) => {
  const { t } = useTranslationDW({
    keyPrefix: 'allocationModal',
  });

  return (
    <DynamicHeightModal
      isOpen={isOpen}
      onClose={onClose}
      backgroundColor="DWPrimary500"
    >
      <Stack>
        <Text
          fontVariant={'heading3-semibold-White'}
          tamaguiTextProps={{ marginBottom: '$md' }}
        >
          {variant === 'consider'
            ? t('title', { context: 'consider' })
            : t('title', { context: 'learn' })}
        </Text>
        {t('bulletPoints', { returnObjects: true }).map(renderBulletPointItem)}
      </Stack>
    </DynamicHeightModal>
  );
};

const renderBulletPointItem = (item: string) => {
  return (
    <XStack accessible accessibilityLabel={item} key={item}>
      <BulletPoint accessible={false} fontVariant={'body-regular-White'} />
      <Text
        tamaguiTextProps={{ flexWrap: 'wrap', flex: 1 }}
        fontVariant={'body-regular-White'}
      >
        {item}
      </Text>
    </XStack>
  );
};
