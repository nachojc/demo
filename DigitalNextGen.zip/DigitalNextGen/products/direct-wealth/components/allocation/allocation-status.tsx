import { Text } from '@aviva/ion-mobile';

import { ErrorMessage } from '../error-message/error-message';

const RemainingAllocationMessage = ({ percentage }: { percentage: number }) => (
  <Text fontVariant="body-regular-Gray800">
    {`You have `}
    <Text fontVariant="body-semibold-Gray800">{percentage}%</Text>
    {` left to allocate`}
  </Text>
);

export type AllocationStatusProps = {
  totalAllocated: number;
  nonAllocated: number;
  errorCopy: string;
};

export const AllocationStatus = ({
  totalAllocated,
  nonAllocated,
  errorCopy,
}: AllocationStatusProps) =>
  totalAllocated > 100 ? (
    <ErrorMessage copy={errorCopy} />
  ) : (
    <RemainingAllocationMessage percentage={nonAllocated} />
  );
