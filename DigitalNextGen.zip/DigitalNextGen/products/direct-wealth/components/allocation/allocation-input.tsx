import { InputProps } from '@aviva/ion-mobile';
import { NumberInput } from '@aviva/ion-mobile/components/text-input';
import { FieldError } from 'react-hook-form';

export type AllocationInputProps = {
  error?: FieldError;
} & Pick<
  InputProps,
  'maxLength' | 'onFocus' | 'onChangeText' | 'value' | 'testID'
>;

export const AllocationInput = ({
  onChangeText,
  value,
  error,
  maxLength = 3,
  onFocus,
  testID,
}: AllocationInputProps) => {
  return (
    <NumberInput
      required
      symbol="suffix"
      allowDecimal={false}
      tamaguiInputProps={{
        value,
        onChangeText,
        maxLength,
        onFocus,
        testID,
      }}
      containerProps={{ width: '100%' }}
      error={!!error}
      errorText={error?.message}
    />
  );
};
