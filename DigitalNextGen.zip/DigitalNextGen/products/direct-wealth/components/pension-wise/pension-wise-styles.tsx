import { styled, TamaguiText, YStack } from '@aviva/ion-mobile';

export const Container = styled(YStack, {
  marginTop: '$xxl',
});

export const Paragraph = styled(TamaguiText, {
  color: '$Gray750',
  fontWeight: '400',
  fontSize: '$body',
  lineHeight: 24,
  paddingBottom: 24,
});

export const Bold = styled(TamaguiText, {
  fontWeight: '700',
});
