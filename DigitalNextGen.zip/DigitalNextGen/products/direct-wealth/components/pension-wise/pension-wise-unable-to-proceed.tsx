import { YStack } from '@aviva/ion-mobile';

import { PensionWiseLogo } from '../../../../assets/aviva-dw/PensionWiseLogo';
import {
  ConstantsPWCantProceed,
  ConstantsPWUnableProceed,
} from '../../features/sipp-transfer/stronger-nudge/stronger-nudge-constants';
import { Bold, Container, Paragraph } from './pension-wise-styles';

type PensionWiseUnableToProceedProps = {
  hasAppointment?: boolean;
};
export const PensionWiseUnableToProceed = ({
  hasAppointment = false,
}: PensionWiseUnableToProceedProps) => {
  const { PW_INFO, ADVICE, UNABLE_TO_PROCEED } = hasAppointment
    ? ConstantsPWUnableProceed
    : ConstantsPWCantProceed;
  return (
    <YStack>
      <PensionWiseLogo />
      <Container>
        <Paragraph>{PW_INFO}</Paragraph>
        <Paragraph>{ADVICE}</Paragraph>
        <Paragraph>
          <Bold>{UNABLE_TO_PROCEED}</Bold>
        </Paragraph>
      </Container>
    </YStack>
  );
};
