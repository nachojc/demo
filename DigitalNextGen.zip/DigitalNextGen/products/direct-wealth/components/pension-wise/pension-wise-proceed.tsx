import { TextWithLinks } from '@aviva/ion-mobile';

import { PensionWiseLogo } from '../../../../assets/aviva-dw/PensionWiseLogo';
import { ConstantsPWProceed } from '../../features/sipp-transfer/stronger-nudge/stronger-nudge-constants';
import { Bold, Container, Paragraph } from './pension-wise-styles';

export const PensionWiseProceed = ({
  navigateToUnbiased,
}: {
  navigateToUnbiased: () => void;
}) => {
  const {
    PENSION_WISE,
    ENCOURAGE,
    GUIDANCE,
    FROM,
    SERVICE,
    SERVICE_MORE,
    ADVICE,
    VISIT_UNBIASED,
    VISIT_UNBIASED_LINK,
    VISIT_UNBIASED_LINK_HINT,
  } = ConstantsPWProceed;

  return (
    <>
      <PensionWiseLogo />
      <Container>
        <Paragraph>
          {ENCOURAGE}
          <Bold>{GUIDANCE}</Bold>
          {FROM}
          <Bold> {PENSION_WISE}.</Bold>
        </Paragraph>
        <Paragraph>
          <Bold>{PENSION_WISE}</Bold>
          {SERVICE}
          <Bold>{PENSION_WISE}</Bold>
          {SERVICE_MORE}
        </Paragraph>
        <Paragraph>{ADVICE}</Paragraph>
        <TextWithLinks<typeof VISIT_UNBIASED>
          fontVariant="body-regular-Gray750"
          tamaguiTextProps={{
            paddingBottom: 24,
          }}
          template={VISIT_UNBIASED}
          links={{
            website: {
              text: VISIT_UNBIASED_LINK,
              accessibilityHint: VISIT_UNBIASED_LINK_HINT,
              onPress: navigateToUnbiased,
              props: {
                color: '$Tertiary800',
                fontWeight: '700',
                textDecorationLine: 'underline',
              },
            },
          }}
        />
      </Container>
    </>
  );
};
