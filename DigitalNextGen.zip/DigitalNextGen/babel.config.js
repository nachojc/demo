// only use babel-plugin for native:

process.env.TAMAGUI_TARGET = 'native';
module.exports = {
  presets: ['babel-preset-expo'],
  plugins: [
    // ['@babel/plugin-syntax-jsx'],
    ['module:react-native-dotenv'],
    [
      'module-resolver',
      {
        root: ['.'],
        alias: {
          '@aviva': './packages',
          '@src': './src/',
          '@theme': './src/theme/',
          '@hooks': './src/common/hooks',
          '@interfaces': './src/common/interfaces',
          '@constants': './src/common/constants',
          '@logger': './src/common/interfaces/logger',
          '@config': './src/common/config',
          '@utils': './src/utils',
          '@test': './src/jest',
          '@components': './src/components',
          '@api': './src/api/generated',
          '@api-mock': './src/api-mock',
          '@direct-wealth': './products/direct-wealth',
          '@assets': './assets',
          //
          stream: 'stream-browserify',
        },
      },
    ],
    [
      '@tamagui/babel-plugin',
      {
        components: ['tamagui'],
        config: './tamagui.config.ts',
        importsWhitelist: ['constants.js', 'colors.js'],
        logTimings: true,
        disableExtraction: process.env.NODE_ENV === 'development',
      },
    ],
    // be sure to set TAMAGUI_TARGET
    [
      'transform-inline-environment-variables',
      {
        include: 'TAMAGUI_TARGET',
      },
    ],
    ['@babel/plugin-proposal-decorators', { legacy: true }],
    'react-native-reanimated/plugin',
  ],
};
