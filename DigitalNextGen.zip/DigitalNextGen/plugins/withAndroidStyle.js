const { withDangerousMod } = require('@expo/config-plugins');
const chalk = require('chalk');
const fs = require('fs-extra');
const path = require('path');
const xml = require('fast-xml-parser');

/*
 Add following styles into </resources>
 <style name="Qualtrics.Theme.Transparent" parent="AppTheme">
 <style name="AdyenCheckout.Button.Colored" parent="Widget.AppCompat.Button.Colored">
 <style name="AdyenCheckout.PrimaryFlatButton" parent="AdyenCheckout">
*/
const withAndroidStyle = (config) => {
  return withDangerousMod(config, [
    'android',
    async (conf) => {
      const filePath = path.join(
        conf.modRequest.projectRoot,
        'android/app/src/main/res/values/styles.xml'
      );
      let options = {
        ignoreAttributes: false,
        attributeNamePrefix: '@_',
        format: true,
      };
      const parser = new xml.XMLParser(options);
      const builder = new xml.XMLBuilder(options);
      let xmlObject = parser.parse(await fs.readFile(filePath));
      xmlObject.resources['@_xmlns:tools'] = 'http://schemas.android.com/tools';
      // Start of Qualtrics style
      xmlObject.resources.style.push({
        '@_name': 'Qualtrics.Theme.Transparent',
        '@_parent': 'AppTheme',
        item: [
          {
            '@_name': 'android:windowIsTranslucent',
            '#text': 'true',
          },
          {
            '@_name': 'android:windowBackground',
            '#text': '@android:color/transparent',
          },
          {
            '@_name': 'android:windowContentOverlay',
            '#text': '@null',
          },
          {
            '@_name': 'android:backgroundDimEnabled',
            '#text': 'false',
          },
          {
            '@_name': 'windowActionBar',
            '#text': 'true',
          },
          {
            '@_name': 'windowNoTitle',
            '#text': 'false',
          },
          {
            '@_name': 'android:statusBarColor',
            '#text': '#40000000',
          },
        ],
      });
      // Start of Adyen styles
      xmlObject.resources.style.push({
        '@_name': 'AdyenCheckout.Button.Colored',
        '@_parent': 'Widget.AppCompat.Button.Colored',
        item: [
          {
            '@_name': 'android:layout_width',
            '#text': 'match_parent',
          },
          {
            '@_name': 'android:layout_height',
            '#text': '60dp',
          },
          {
            '@_name': 'android:layout_marginStart',
            '#text': '16dp',
          },
          {
            '@_name': 'android:layout_marginEnd',
            '#text': '16dp',
          },
          {
            '@_name': 'android:textColor',
            '#text': '@android:color/black',
          },
          {
            '@_name': 'android:textAllCaps',
            '#text': 'false',
          },
          {
            '@_name': 'android:theme',
            '#text': '@style/AdyenCheckout.PrimaryFlatButton',
          },
        ],
      });
      xmlObject.resources.style.push({
        '@_name': 'AdyenCheckout.PrimaryFlatButton',
        '@_parent': 'AdyenCheckout',
        item: [
          {
            '@_name': 'android:buttonStyle',
            '#text': '@style/Widget.AppCompat.Button.Borderless.Colored',
          },
          {
            '@_name': 'colorAccent',
            //this needs to be the same on DW and MANGA
            '#text': '#FFD900',
          },
        ],
      });
      const xmlContent = builder.build(xmlObject);
      await fs.writeFile(filePath, xmlContent);

      console.log(
        chalk.green('✔') + ' Added Qualtrics and Adyen styles to styles.xml'
      );
      return conf;
    },
  ]);
};

module.exports = withAndroidStyle;
