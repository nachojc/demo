const { withSettingsGradle } = require('@expo/config-plugins');
const chalk = require('chalk');

const withSettingsImport = (config, pkg) => {
  return withSettingsGradle(config, (conf) => {
    if (conf.modResults.language === 'groovy') {
      pkg.forEach(function ({ packageName, packagePath }) {
        if (!conf.modResults.contents.includes(`:${packageName}`)) {
          conf.modResults.contents += `
include(":${packageName}")
project(":${packageName}").projectDir = new File(rootProject.projectDir, "${packagePath}")

`;
          console.log(
            chalk.green('✔') + ` Added ${packageName} to settings.gradle`
          );
        }
      });
    } else {
      throw new Error(`Cannot setup because the settings.gradle is not groovy`);
    }
    return conf;
  });
};

module.exports = withSettingsImport;
