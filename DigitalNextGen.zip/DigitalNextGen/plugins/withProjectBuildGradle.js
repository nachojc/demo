/**
 * This script modifies android/build.gradle. It adds variables in the "ext" block, e.g.:
 *
 * ext {
 *   var1: value1
 *   var2: value2
 * }
 *
 * Pass an Options object to this plugin:
 *
 * type Options = {
 *   ext: {
 *     [key:string]: string
 *   }
 * }
 *
 * Other mods may also be added here in future development.
 *
 * Note: This script was written to work with ES5.
 */

var fs = require('fs');
var assert = require('assert');
var {
  withProjectBuildGradle: withProjectBuildGradleMod,
} = require('@expo/config-plugins');
const chalk = require('chalk');

function findAnchor(c, anchor, offset, endOfMatch = false) {
  var index;
  if (typeof anchor === 'string') {
    index = c.indexOf(anchor, offset);
    if (index > -1 && endOfMatch) {
      index += anchor.length;
    }
  } else if (anchor instanceof RegExp) {
    var mat = c.slice(offset).match(anchor);
    if (!mat) {
      index = -1;
    } else {
      index = mat.index + offset;
      if (endOfMatch) {
        index += mat[0].length;
      }
    }
  }
  if (index === -1) {
    throw new Error('Anchor not found: ' + anchor);
  }
  return index;
}

function extractGradleBlock(text, offset, blockName) {
  var startAnchor = new RegExp(`${blockName}\\s*\\{`);
  var endAnchor = /\s*}/;
  var startIndex = findAnchor(text, startAnchor, offset, true);
  var endIndex = findAnchor(text, endAnchor, startIndex);
  var start = text.substring(0, startIndex);
  var body = text.substring(startIndex, endIndex);
  var end = text.substring(endIndex);
  var lines = body.split('\n');
  var firstNonEmptyLine = lines.find((line) => line.trim()) || '';
  var indent = firstNonEmptyLine.match(/^(\s*)/)[1];
  return {
    start,
    body,
    end,
    indent,
  };
}

function insertVariables(text, vars) {
  if (!vars || Object.keys(vars).length === 0) {
    return text;
  }

  var { start, body, end, indent } = extractGradleBlock(text, 0, 'ext');

  var visited = new Set();
  var newBody = body
    .split('\n')
    .map((line) => {
      // check if the line looks like a comment
      if (line.match(/^\s*#/)) {
        return line;
      }
      // check if the line looks like an assignment statement
      var idx = line.indexOf('=');
      if (idx < 0) {
        return line;
      }
      // split the name and value
      var name = line.substring(0, idx).trim();
      if (name in vars) {
        // replace existing value
        visited.add(name);
        console.log(
          chalk.green('✔') +
            ` Replaced variable ${name} in project build.gradle`
        );
        return line.substring(0, idx) + ' = ' + vars[name];
      } else {
        return line;
      }
    })
    .join('\n');

  var newLines = [];
  for (var name of Object.keys(vars)) {
    // check if variable has been handled
    if (visited.has(name)) {
      continue;
    }
    // add new line
    newLines.push(`${indent}${name} = ${vars[name]}`);
    console.log(
      chalk.green('✔') + ` Added variable ${name} to project build.gradle`
    );
  }
  newBody += '\n' + newLines.join('\n');

  return `${start}${newBody}${end}`;
}

function withProjectBuildGradle(config, options) {
  assert(options, 'Options must be defined');
  return withProjectBuildGradleMod(config, (props) => {
    var { language, contents } = props.modResults;
    if (language !== 'groovy') {
      throw new Error(
        `Cannot modify the project build.gradle because it is not a Groovy script`
      );
    }
    props.modResults.contents = insertVariables(contents, options.ext);
    return props;
  });
}

module.exports = withProjectBuildGradle;
