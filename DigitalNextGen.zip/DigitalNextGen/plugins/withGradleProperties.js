const { withDangerousMod } = require('@expo/config-plugins');
const assert = require('assert');
const chalk = require('chalk');
const fs = require('fs-extra');
const path = require('path');

// Use this improve gradle builds
const withGradleProperties = (config, options) => {
  assert(options, 'gradle.properties must be defined');
  return withDangerousMod(config, [
    'android',
    async (conf) => {
      const filePath = path.join(
        conf.modRequest.projectRoot,
        'android',
        'gradle.properties'
      );
      const contents = await fs.readFile(filePath, 'utf-8');
      const results = [];
      const lines = contents.split('\n');
      for (let line of lines) {
        line = line.trim();
        if (line && !line.startsWith('#')) {
          const eok = line.indexOf('=');
          const keyName = line.slice(0, eok);
          let value;
          if (keyName in options) {
            value = options[keyName];
            delete options[keyName];
          } else {
            value = line.slice(eok + 1, line.length);
          }
          results.push(`${keyName}=${value}`);
        } else {
          results.push(line);
        }
      }

      // Add the remaining options
      for (const [key, value] of Object.entries(options)) {
        results.push(`${key}=${value}`);
      }
      await fs.writeFile(filePath, results.join('\n'));
      console.log(chalk.green('✔') + ' Updated gradle properties');
      return conf;
    },
  ]);
};

module.exports = withGradleProperties;
