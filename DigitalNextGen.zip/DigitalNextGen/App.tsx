import { ACPAnalytics } from '@adobe/react-native-acpanalytics';
import { ACPCore } from '@adobe/react-native-acpcore';
import {
  Instrumentation,
  //  InteractionCaptureMode, //Removed in v23?
  LoggingLevel,
} from '@appdynamics/react-native-agent';
import CampaignClassic from '@aviva/rn-bridge-campaignclassic/src';
import { config, isDevMode } from '@config';
import { getTargetApp, isManga } from '@hooks/use-expo-config';
import { BACKGROUND_NOTIFICATION_TASK } from '@interfaces/push-messaging';
import { bgNotificationMessageAndroid } from '@interfaces/storage';
import messaging from '@react-native-firebase/messaging';
import { useMockServiceWorker } from '@src/api-mock/use-mock-service-worker';
import { FeatureFlags } from '@src/feature-flags';
import { MyDriveSDKListener } from '@src/features/mydrive/myDriveSDKListener';
import { SecuritySplashScreen } from '@src/features/secure-splash/secure-splash-screen';
import { initQualtrics } from '@src/utils';
import { registerTaskAsync } from 'expo-notifications';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { enableLatestRenderer } from 'react-native-maps';

import { Providers } from './src/common/providers';
import { Navigation } from './src/navigation';

enableLatestRenderer();

declare global {
  // eslint-disable-next-line no-var
  var licenseConfig: { key: string; creditLabel: boolean }; //NOSONAR
}

console.log(
  '== App startup info ==',
  JSON.stringify(
    {
      targetApp: getTargetApp(),
      isManga: isManga(),
      isDevMode: isDevMode(),
      'Feature flags': FeatureFlags.get(),
    },
    null,
    2
  )
);

ACPCore.configureWithAppId(config.ANALYTICS_CONFIG_IDENTIFIER.get());
ACPAnalytics.extensionVersion()
  .then((version: string) =>
    console.log('AdobeExperienceSDK: ACPAnalytics version: ' + version)
  )
  .catch(() => null);
ACPAnalytics.getTrackingIdentifier()
  .then((identifier: string) =>
    console.log('AdobeExperienceSDK: Tracking identifier: ' + identifier)
  )
  .catch(() => null);

CampaignClassic.registerExtensionWithAppId(
  config.ANALYTICS_CONFIG_IDENTIFIER.get()
);
ACPAnalytics.getVisitorIdentifier().then((vid) =>
  console.log('AdobeExperienceSDK: Visitor identifier: ' + vid)
);

initQualtrics();

Instrumentation.start({
  appKey: config.AD_APPKEY.get(),
  //  interactionCaptureMode: InteractionCaptureMode.All,
  screenshotsEnabled: false,
  loggingLevel: LoggingLevel.INFO,
  anrDetectionEnabled: true,
});

global.licenseConfig = {
  key: config.FUSION_CHARTS_LICENCE.get(),
  creditLabel: false,
};

registerTaskAsync(BACKGROUND_NOTIFICATION_TASK);

messaging().setBackgroundMessageHandler(
  // handles push received from Firebase in background on android
  async (firebaseRemoteMessage) => {
    bgNotificationMessageAndroid.set(JSON.stringify(firebaseRemoteMessage));
  }
);

export const App = () => {
  /**
   * config.ENV does not change therefore order
   * of hooks rule is preserved and causes no issues to ignore here
   */
  if (config.ENV.get() !== 'production') {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    useMockServiceWorker();
  }

  return (
    <Providers>
      <GestureHandlerRootView style={{ height: '100%' }}>
        <SecuritySplashScreen>
          <MyDriveSDKListener />
          <Navigation />
        </SecuritySplashScreen>
      </GestureHandlerRootView>
    </Providers>
  );
};
