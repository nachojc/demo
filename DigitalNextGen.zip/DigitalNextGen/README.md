# MyAviva Next Gen App (MANGA)

- [Core Capabilities](#core-capabilities)
- [Getting Started](#getting-started)
- [Build and Test](#build-and-test)
  - [iOS](#ios)
  - [Android](#android)
- [Configuring vscode](#configuring-vscode)
- [Configuring git](#configuring-git)
- [Adding absolute imports](#absolute-imports)
- [Pull requests](#pull-requests)
- [Git hooks](#git-hooks)
  - [pre-commit](#pre-commit)
- [Generated code](#generated-code)

<br />

## [Core Capabilities](#core-capabilities)

A set of capabilities within the Aviva mobile application.

- registration
- login
- settings
- multifactor authentication
- profile

<br />

## [Getting Started](#getting-started)

The project also git submodules, do this _before_ running yarn:

```
git submodule update --init --recursive
```

In order to run the app all the dependencies need to be installed:

```
yarn
```

Then an additional prebuild step is needed to build the expo project:

```
yarn prebuild
```

<br />

## [Build and Test](#build-and-test)

### [iOS](#ios)

```
yarn ios
```

This should:

- launch the iOS simulator
- install the application
- open the application
- start the Metro bundler in a new terminal

You may get an error here saying that the iPhone 13 simulator cannot be found. Try using a different iPhone profile:

```
yarn ios -- --simulator "iPhone 14 Pro Max"
```

### [Android](#android)

```
yarn android
```

This should:

- install the application
- open the application
- start the Metro bundler in a new terminal

Before you do that, open the emulator in another terminal with

```
emulator @Pixel_6_API_33
```

<br />

## [Configuring vscode](#configuring-vscode)

This project comes with some recommended plugins which will help you with development. CISO are putting together a list of approved extensions, anything not on that list isn't allowed.

## [Absolute imports](#absolute-imports)

For adding or changing absolute imports - e.g. `@components` - you will need to edit both the 'module-resolver' config in babel.config.js, as well as the `compilerOptions` in tsconfig.json. See how `@aviva/*` imports are defined in both files for an example.

<br />

## [Pull requests](#pull-requests)

Source branches of pull requests will be run by the pipeline.

There are new rules for the PR to be approved:

- the build against the source branch must be successful
- all comments in the PR must be resolved

The option for merging the PR to main is set to "Squash merge".

<br />

## [Git hooks](#git-hooks)

Husky is installed automatically to allow git hooks to run on specific instances. You can see this from the `.husky` folder.

### [Pre-commit](#pre-commit)

- Runs `prettier` on staged files
- Runs `lint-staged` on staged files
  - Runs `eslint` on JavaScript and TypeScript files

<br />

## [Generated code](#generated-code)

There is a script that creates code and types from the BE swagger documentation.

The swagger link: https://myaviva-mobile-api-rwy1.ukd-services.rwy.aws-euw1-np.avivacloud.com/MobileApi/index.html

The JSON is saved as `MobileApi.json` and then generated code lives in `./src/api/generated`.

The library used to generate the code is [openapi-react-query-codegen](https://github.com/7nohe/openapi-react-query-codegen) and the documentation for usage can be found there.

### Note

The swagger documentation currently has a bug with enums, so we have to create our own in `scripts/codegen-patches`.

To find the appropriate enum, you can find it in the BE repo: https://avdigitalweb.visualstudio.com/AvivaDigital/_git/AvivaDigital?path=/MyAvivaMobileAPI/Api/Endpoints
