# Remote feature flags

## Flag Lifecycle

The lifecycle of a feature flag involves several stages:

1. Creation of a new flag
2. Updating a flag
3. Deprecating a flag
4. Archiving a flag
5. Deleting a flag

### Types of Flags

Flags can be categorised into two types based on their intended lifespan and usage:

- Temporary flags:
  These flags have an implicit lifespan. They are designed to be removed once you have rolled out the feature, completed the migration, or finished the user testing.

- Long-lived flags:
  These flags have an indefinite lifespan. These are flags that are around to support business logic or infrastructure operations and safety.

## [Process of adding a new flag](https://docs.launchdarkly.com/home/flags/new)

Suggested reading before creating a flag:

- [Creating flags](https://docs.launchdarkly.com/guides/flags/creating-flags)
- [Creating naming conventions for flags](https://docs.launchdarkly.com/guides/flags/flag-naming)

### Creating a flag in the LaunchDarkly Dashboard

1. Navigate to the flags list.
2. Click "Create flag" at the top-right corner.
3. Enter a unique, human-readable name.
4. [Optional] update the flag key, which will be used in the code.
5. [Optional] enter a description.
6. Choose a flag template in the Configuration section. The options are:

   - Custom: A flag that you can configure exactly how you wish.
   - Release: A temporary flag that initially serves false to all targets, then progressively rolls out to 100%.
   - Kill switch: A permanent flag that enables or disables non-core functionality.
   - Experiment: A flag that you can use to test a hypothesis and improve on your findings.
   - Migration: A temporary flag used to migrate data or systems while keeping your application available.

7. For a kill switch, experiment, or release flag, update the flag variations. See [Creating flag variations](https://docs.launchdarkly.com/home/flags/variations).
8. [Optional] Update the default variations.
9. [Optional] Choose one or more tags from the Tags menu.
10. Check the "SDKs using Mobile key" box in the "Client-side SDK availability" section.

    <img src='https://docs.launchdarkly.com/static/1717458754598.7878536295/21b4d/flag-create-sdk.auto.png' width='640'/>

11. Click "Create flag". The new flag will appear in the flag list.

### Adding and using a flag in the code

1. Add the flag and details to `remoteFlags` in `src/remote-flag/index.ts`.
2. Add the key to `remoteFlags` in `translation.json` along with a short description of the flag.
3. Use the `useRemoteFeatureFlag` hook to get the flag value:

```ts
import { useRemoteFeatureFlag } from '@hooks/use-remote-feature-flag';

const SomeComponent = () => {
  // value will be updated when there is a change
  const { value } = useRemoteFeatureFlag('some-flag-key');
  ...
}
```

## Process of updating a flag

### [Turning flags on and off](https://docs.launchdarkly.com/home/flags/toggle)

When you create a new flag, it is turned Off by default. You can turn the flag On by clicking the flag toggle button in the flags list or the flag's Targeting tab.

When you turn a flag to Off, you disable the targeting rules for that flag. Instead of serving an active variation, you serve the off variation.

If you don't specify an explicit default off variation, LaunchDarkly serves the fallback value for the flag.

### [Environments](https://docs.launchdarkly.com/home/flags/new#configure-the-same-flag-in-different-environments)

All environments within a project have the same set of feature flags. When you create a new feature flag, it is created in every environment in your LaunchDarkly project. That flag is scoped to your entire project.

The majority of flag settings apply to all environments. See [Settings for all environment](https://docs.launchdarkly.com/home/flags/flag-settings#settings-for-all-environments).

Flag configuration settings are specific to each environment. The changes you make in one environment do not apply to the same flag in any other environment. If you want to, you can configure the same flag in a unique way for every environment you have.

To configure a flag in a different environment:

1. Navigate to a flag's configuration page
2. Click the environment name below the flag name at the top. Click the "+" button to add another environment to view if it is not there already.
3. Make and save any changes as needed.

## Process of deprecating, archiving, and deleting a flag

### [Deprecating](https://docs.launchdarkly.com/home/flags/archive-delete#deprecate-flags)

When a flag is still being served to customers, but it is only being served in older or deprecated versions of your application, it may be time to deprecate it. Deprecating a flag hides it from the live flags list. You can restore a deprecated flag if you need it.

To deprecate a flag:

1. Navigate to the flags list.
2. Find the flag you wish to archive (adjust filters if needed), click the overflow menu, choose "Manage flag settings".
3. Click "Deprecate" in the "Deprecate flag" section. The "Deprecate flag" dialog appears.
4. The dialog shows you how the flag has been evaluated recently. Choose the environments your team or customers depend on to confirm you can deprecate the flag without unintended consequences.
5. Click "Deprecate"

### [Archiving](https://docs.launchdarkly.com/home/flags/archive-delete#archive-flags)

When a flag is no longer being served to customers, and it is not a prerequisite of other flags, it may be time to archive it. Archiving a flag retires it from LaunchDarkly without deleting it. You can restore an archived flag if you need it.

To archive a flag:

1. Navigate to the flags list.
2. Find the flag you wish to archive (adjust filters if needed), click the overflow menu, choose "Manage flag settings".
3. Click "Archive" in the "Archive flag" section. The "Archive this flag?" panel appears. (If the flag has dependencies, you cannot archive it)
4. Choose the environments your team or customers depend on to confirm you can archive the flag from those environments without unintended consequences.
5. Type the flag's name in the Archive flag text box.
6. Click "Archive".

### [Deleting](https://docs.launchdarkly.com/home/flags/archive-delete#delete-archived-flags)

You can delete an archived flag after you determine your project no longer needs it.

To delete an archived flag:

1. Navigate to the "Archived feature flags" screen and find the flag you wish to delete.
2. In the overflow menu, choose "Manage flag settings."
3. Click "Delete this flag" in the "Delete flag" section. The "Delete this flag?" dialog appears.
4. Type the flag's name in the confirmation text field to confirm.
5. Click "Delete".

## Test Automation Usage

While each feature flag can be controlled remotely, there are situations where you may need to override a flag to test the application's behavior with different flag values. This can be done locally by following these steps:

1. Navigate to the "Dev Mode" screen in the mobile app.
2. Click "Remote Flags".
3. Select the flag to override. This will open the flag details screen.
4. Toggle on the "Allow override" switch.
5. Set the override value.

Note: the override values are not persisted across app launches.

More about [Integration and end-to-end tests](https://docs.launchdarkly.com/guides/flags/testing-code#integration-and-end-to-end-tests).

Alternatively, [Preconfigure](../Tooling/Preconfigure.md) can be used to set remote feature flags.

## Unit testing usage

When unit testing, you can mock the flag value to test how your application behaves with different flag variations. Here’s an example of how to mock a flag value:

```ts
import { renderHook } from '@src/jest/testing-library';
import { useRemoteFeatureFlag } from '@hooks/use-remote-feature-flag';

// Mock the useRemoteFeatureFlag hook
jest.mock('@hooks/use-remote-feature-flag');

// A utility function to set mock flag values
const { setMockFlagValue } = require('@hooks/use-remote-feature-flag');

describe('Feature Flag Testing', () => {
  it('should use the mocked flag value', () => {
    // Set the mock flag value
    setMockFlagValue('test-bool-flag', true);
    const { result } = renderHook(() => useRemoteFeatureFlag('test-bool-flag'));
    expect(result.current.defaultValue).toBe(true);
  });
});
```

You may also override a flag value instead of mocking:

```ts
import { setRemoteFlagOverride } from '@src/remote-flags';

setRemoteFlagOverride('test-bool-flag', true);
```

More about [Unit tests](https://docs.launchdarkly.com/guides/flags/testing-code#example-unit-test).
