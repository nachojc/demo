# Analytics

Analytics are at the core of the application and uses Adobe's suite of options. They are used to monitor screen journeys, user decisions and detailed API responses.

## Screen (aka. state) and User

A generic wrapper has been created in order to correctly send analytic events regardless of the SDK used. This wrapper consists of two methods which are used for sending page and action tags and should be performed within the **view model**. These tags should be defined within each story, for each screen event and button/action.

### Tag Structure

Each tag should be constructed to match the following format.

**Screen:** `{base}|{screen-tag} - e.g. ukmyaviva|login`

**Action:** `{base}|{screen-tag}|{action} - e.g. ukmyaviva|login|terms-of-use-tapped`

Ensure that an `analytics.ts` file is included with the feature which constructs each tag using the screen route, that should look like the following;

    import { APP_BASE } from '@src/constants/analytics';

    export const PAGE_LOGIN = APP_BASE + 'login';

    export const ACTION_LOGIN_CLICKED = `${PAGE_LOGIN}|login-in-tapped`;
    export const ACTION_LOGIN_TERMS_CLICKED = `${PAGE_LOGIN}|terms-of-use-tapped`;
    export const ACTION_LOGIN_FORGOTTEN_DETAILS_CLICKED = `${PAGE_LOGIN}|forgotten-details-tapped`;

### Screen (aka. state) Events

These occur when the screen is navigated to. The screen event can also contain additional data in the form of `Record<string, string>` . The implementation will ensure that a hook is used to fire the event once per navigation.

    import { useTrackStateEvent } from '@hooks/use-analytics';

    useTrackStateEvent(PAGE_LOGIN);

### Context Data

`use-analytics` is a hook which uses the `useFocusEffect` to automatically send the screen event when the user navigates forward and backwards between screens (_this may change when MVVM is refactored out_), so long as the hook is used.

It also automatically attaches all contextual data to each event. The contextual data is stored within `AnalyticsHistory` `enrichmentContextData`. This class is also responsible for adding the _navigation levels_ as required by the analytics team. So a screen tag such as `ukmyaviva|login|terms-of-use` would produce additional context keys based on the `|` delimiter.

- `navLevel1: "login"`
- `navLevel2: "terms-of-use"`

### User Event

These occur when a use clicks or interacts with a button or UI component we want tracking.

    import { useAnalytics } from '@hooks/use-analytics';
    ...
    const analytics = useAnalytics();
    ...
    const navigateToForgottenDetailsScreen = () => {

    analytics.trackUserEvent(ACTION_LOGIN_FORGOTTEN_DETAILS_CLICKED);
        navigation.navigate('Forgotten Details');
    };

### Additional Data

Additional data can be added to each analytics call, this will be passed in the analytics event as context data and is normally used for more detailed information for that event. These are in the form of key/value. For example;

    import { useAnalytics } from '@hooks/use-analytics';
    ...
    const analytics = useAnalytics();
    ...

    const navigateToForgottenDetailsScreen = () => {
    	analytics.trackUserEvent(ACTION_LOGIN_FORGOTTEN_DETAILS_CLICKED, {
          key1: 'somedata1',
          key2: 'somedata2',
        });
        navigation.navigate('Forgotten Details');
    };

## Service Analytics

Service analytics provide automated analytics that are a product from any API call made, so long as there is a matching interpreter for the intended URI. These will be produced as state tags, not action. For example, sending analytics about the customer API (`/MessagingApi/api/v2/customer`) response when it completes (failed, succeeded with specific information within the tag).

### Adding Service Analytics

To add service analytics you will need to create an additional service analytics class that extends `ServiceAnalytics` which can be found within `api/service-analytics` .

You will then have to:

1.  Override `isKnownUrl` which will be used to check if your interpreter can handle the current API. You can use regex here if required for situations that may include variables within the URI.
2.  Override `mapPropsToStateTag` to provide the correct service tag. For example `service-success` could be derived by looking at `this.context` which should contain everything you need regarding the response.
3.  Add your new service analytics class to the list within `use-service-analytics` . This should be enough to send service analytics so long as the URI matches

### Additional Data

If you need to provide additional data within the analytics event (in this case, context data that gets sent as key-value pairs), you can override `getServiceContextData` to provide these in a similar way to `mapPropsToStateTag`
