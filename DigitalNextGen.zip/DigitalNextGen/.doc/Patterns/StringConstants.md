# String constants

We use [i18next](https://www.i18next.com) for string constants.

Please get familiar with the [documentation](https://www.i18next.com/translation-function/essentials) as they have great examples of things like [interpolation](https://www.i18next.com/translation-function/interpolation), [plurals](https://www.i18next.com/translation-function/plurals) and [context](https://www.i18next.com/translation-function/context).

#### Basic examples

```ts
const { t } = useTranslation();

// "title": "Basic title"
<Text>{t('some.page.title')}</Text>

// With plurals
// "title": "Title with {{count}} items"
<Text>{t('some.page.title', { count: 5 })}</Text>

// With context
// "title": "Title with no matching context"
// "title_loggedin": "Welcome {{name}}"
// "title_banned": "Not welcome"
<Text>{t('some.page.title', { context: 'loggedin', name: 'David' })}</Text>
<Text>{t('some.page.title', { context: 'banned' })}</Text>
```

#### Example with keyPrefix

These examples are identical

```ts
const { t } = useTranslation();
<Text>{t('very.deeply.nested.title')}</Text>;

const { t } = useTranslation(_namespace_, { keyPrefix: 'very.deeply.nested' });
<Text>{t('title')}</Text>;
```

#### Example of Typescript types

This is useful for defining types for components, like this example of `LoadingKeys` is used to restrict the `<LoadingState>` to use only a few states and ensures consistency.

```ts
export type LoadingKeys = I18nKeys<'loading'>;
// LoadingKeys = "loading" | "oneMoment" | "pleaseWait" ...
```

#### Our configuration

i18n has been set up allow us to add multiple namespaces.

`ma` | `dw` are currently the top level namespaces.
We can add more namespaces within the top level namespaces.
As an example `sippTransfer` is a namespace added within `dw`.

This is to allow us to have multiple feature level json files instead of one big file for all constants.

All project level constants should go into `@src/locales/en/translation.json`, we can create more feature level json files with in `ma` namespace for feature level constants.

All direct wealth constants should go into `@src/locales/en/direct-wealth/dw.json`, we can create more feature level json files with in `dw` namespace for feature level constants.

`sippTransfer` has been created as an example namespace within `dw` and all constants related to sipp should go into `@src/locales/en/direct-wealth/sipp-transfer.json`.

### Creating namespaces

- Create a json file in /src/locales/en/
- Add the namespace in /src/i18n/i18n.ts

### Using namespaces

```
// Single namespace
useTranslation('dw')

or

useTranslationDW() //This is a utility hook created for dw namescape

// Multiple namespaces
useTranslation(['manga'], ['dw'])

```

### Naming convention

Keys in the translation jsons should be camelCased.

### Caveat:

We do not want to have tons of json files, and we do not want to have deeply nested namespaces. So the recommendation is to have just one level deep namespaces and only have jsons for bigger features. Anything else should ideally go into `dw` or `ma` jsons. An ideal json splitting would look something like

```
  dw.json
      ---- sipp-transfer.json
      ---- pcs.json
      ---- find-and-combine.json
  ma.json
      ---- pension.json
      ---- another-major-feature.json
```
