# Overview

- [Overview](#overview)
  - [Getting Started](#getting-started)
  - [Transports](#transports)
    - [Console](#console)
    - [App Dynamics](#app-dynamics)
  - [Best Practices](#best-practices)
    - [Naming](#naming)
    - [Choosing a LogLevel](#choosing-a-loglevel)
      - [Debug](#debug)
      - [Info](#info)
      - [Warn](#warn)
      - [Error](#error)

Logging during development is handled via [React Native Logs](https://www.npmjs.com/package/react-native-logs).

It provides us with a factory function to produce structured loggers, with custom levels of logging, and separate tranports to determine where these logs go based on the environment.

The list of Log-Levels in use are:

- Debug
- Info
- Warn
- Error

## Getting Started

Usage is straight forward. If you need to log inside a function you need to import the `getLogger` function, and get a namespaced logger.

```ts
// src/features/biometric/use-biometric-settings-view-model.ts
import { getLogger } from '@src/logger';.

const log = getLogger(useBiometricSettingsViewModel.name);

export function useBiometricSettingsViewModel() {
  // ...
}
```

Note: using a traditional function instead of an arrow function allows us to reference the function before it is defined.

The result of this is that the logs will be structued akin to this, notice the `useBiometricSettingsViewModel` in the statement:

```sh
$ <time> | useBiometricSettingsViewModel | <log-level> : <log-message>
```

> **Note** you _technically_ are able to call `LOG.debug()` directly on the base logger, but it will be missing the prefix for the log message
> (the function name) these are crucial for tracing logs and improving debugging.
>
> Notice the missing context in the below log versus above.
>
> ```sh
> $ <time> | <log-level> : <log-message>
> ```

## Transports

We utilise two types of transports in the logger depending on the deployment environment.

### Console

> Active when: `__DEV__ = true`

The console transport is pretty straight forwards - it will provide some syntax highlighting in your terminal and buffer the logs through to the stdout of the application (aka console in React Native).

![Logs being printed to console in different colors](.images/log-levels.png)

> **Reference**
>
> - [Console Transport](https://www.npmjs.com/package/react-native-logs#consoletransport)

### App Dynamics

> Active when: `__DEV__ = false`

This logger will also automatically handle transit of certain log levels to external logging providers, when we build for non development.

_Currently_ we only ship `logger.error()` reports AppDynamics, in release builds all other log types will no-op.

> **Reference**
>
> - [App Dynamics](https://www.npmjs.com/package/react-native-logs#consoletransport)
> - [Custom Transport](https://www.npmjs.com/package/react-native-logs#consoletransport)
> - [Development Only Logging](https://www.npmjs.com/package/react-native-logs#logs-only-in-development-mode)

## Best Practices

These are guidelines on how to use the logger appropriately based on our design patterns.

```ts
// src/features/biometric/use-biometric-settings-view-model.ts
import { getLogger } from '@src/logger';.

//export function useBiometricSettingsViewModel() { // We changed the name of the function
export function useBiometricSettings() {
  const log = getLogger('useBiometricSettingsViewModel'); // because we didnt use the .name property we have fallen out of sync!
  ...
}
```

### Naming

When getting a namespaced logger, it is encouraged to use the parent calling contexts name property (e.g. `functionName.name`).

Name is a static property on all functions, the primary benefit to using this instead of a string of the name is that as you use any refactoring tools which look at symbols (this is what your editor uses to refactor/rename without updating strings/markdown files etc) the log levels will remain in sync, where they'd otherwise fall out of date.

If you're writing a log in a component, consider the chain of the call-site, e.g. you could prefix with **both** the screen name + component name + method name.

### Choosing a LogLevel

LogLevels are under utilised at the moment, this section aims to shine some light on the area and improve our logging capabilities.

#### Debug

These are full trace logs, and can capture micro detail of an interaction and can be easily suppressed by the log level, meaning important information (as you'd expect of a warning or error) should not be contained within here.

#### Info

Reserve this for useful occasional information, e.g. the formdata when a user submits a form.

#### Warn

Use this to alert developers that something unexpected occurred and that they will likely want to review it.

This will come up often when you have exhaustive checks at the time of writing, but want to make sure they remain exhaustive over time for example in `src/utils/api/access-definition.ts` we added `logger.warn` for unsupported domains, so that when a new domain becomes supported in the app and it was forgotten to add it in the mapping developers would see this feedback swiftly.

#### Error

Reserve this for **unexpected** errors such as catch blocks where we are coding defensively, but don't expect it to occur.

**DO NOT** use `logger.error` if the error is recoverable or expected.

This will result in lots of useless error reports coming through on app dynamics which we don't have to resolve, or which we already track elsewhere, examples to avoid include:

- failed API HTTP status >=400
- Service Analytics - missing interpreter
- Form validation failed

> **Note** Next time you `logger.error`, consider if you saw this error on AppDynamics would it be something you need to 'fix', or whether this should simply be a `warn` statement for next person who sees it.
