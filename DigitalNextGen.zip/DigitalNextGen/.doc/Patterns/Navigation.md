# Overview

This document outlines our current approach to navigation and some guidelines for designing new flows.

The navigation for the app(s) is built around [React Navigation](https://reactnavigation.org/) (version 6) predominantly utilising the [Native Stack](https://reactnavigation.org/docs/native-stack-navigator) and [Bottom Tabs](https://reactnavigation.org/docs/bottom-tab-navigator) navigators.

The start of the navigation routes can be found in the [navigation index file](https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/src/navigation/index.tsx), as mentioned below there are two paths a user can take dependent on whether they have signed in successfully.

[AuthStack](https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/src/navigation/auth/index.tsx): If user is not logged in, we show the AuthStack which is a Native Stack navigator with screens like welcome, login, registration, MFA screens etc.

[AppStack](https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/src/navigation/app/index.tsx): Once a user has successfully logged in they will drop into the AppStack, then depending on which app they are currently using (Direct Wealth v MyAviva) the appropriate nested stack will be conditionally loaded, however both apps share the use of the BottomTabs as detailed below.

[BottomTabs](https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/src/navigation/bottom-tabs/index.tsx): Once a user has successfully logged in we show the BottomTabs which is a Bottom Tab Navigator, it currently has the following tabs

- Summary Tab: This is a stack navigator, which has the DashboardScreen as the first screen. And DashboardScreen is the first screen user sees when they login.
- Offers Tab: This is a stack navigator with offers screen as the first screen.
- Profile Tab: This is a stack navigator with profile screen as the first screen.
- Help Tab: This is a stack navigator with HelpScreen as the first screen.
- More Tab: This is a stack navigator with MoreScreen as the first screen with other options like Privacy, Terms, DeleteAccount etc.

Throughout the navigation stacks we have made extensive use of [Stack Group's](https://reactnavigation.org/docs/group) to organise the screens within the stacks and also reduce duplication within the navigation part of the codebase. One of the main examples of this in use is where we'd like to display a particular header or alternatively hide the header for a number of screens in the stack.

There are some screens which we would like to have custom appearances and behaviours, to do this we have passed an [Options object](https://reactnavigation.org/docs/screen-options), examples of customisations utilising options include custom screen titles, changing the header on a particular screen or even a screen's presentation (see modals).

## Navigating around the app

In order for users to navigate around the app, for example via a button press which takes the user to another screen, extensive use of hooks is made. Each of the Stack Navigators within the app comes with it's own navigation hook, for example the [AppStack hooks](https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/src/navigation/app/hooks.ts). These have been written in such a way that provides Type safety, wrapping the standard React Navigation [useNavigation hook](https://reactnavigation.org/docs/use-navigation) results in the IDE only presenting developers with possible routes within the current stack or its parent stack. Generally examples of these hooks in use can be found in the various Screen Models throughout the app within handlers which are then often passed down via props for use in a screen.

When creating or modifying a Stack within the app it is important that [Route Parameters](https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/src/navigation/app/index.tsx&version=GBdevelop&line=14&lineEnd=15&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) and [Screen Names](https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/src/navigation/app/index.tsx&version=GBdevelop&line=25&lineEnd=26&lineStartColumn=1&lineEndColumn=1&lineStyle=plain&_a=contents) Types are also addressed (for more info [see here](https://reactnavigation.org/docs/typescript/#organizing-types)); when using the hooks mentioned earlier to make a navigation call TypeScript will display a hint in the IDE that will display the possible parameters than can be passed via an argument to a particular screen if any are available.

### Linking

Linking is how deep/universal links are handled in the app, this could also apply to linking in context of push notifications. We wrap our main stack navigator with NavigationContainer which accepts a linking prop that makes it easier to handle incoming links. We use prefixes and config properties on linking to specify which domain names we want to handle and how to handle the links.

### Modals & Webviews

[Modals](https://reactnavigation.org/docs/modal/) & Webviews screens are particular screens within the app which have their presentation mode changed so that they interrupt the main view, you will also notice the transition to these screens differentiates from the others. How this is done within the app is to set the presentation property within the options property in the screen (or sometimes within a group) to modal, Webviews especially often come with a custom header set in the options object too.

### Hiding bottom tab bar

In some screens and sections within the app there is a conscious decision to hide the Bottom Navigation tabs, this has been done by utilising the organisation of stacks and the screens within them. Simply by placing a particular screen outside of the Bottom Tabs navigator this will prevent it from being displayed on that particular screen. This is particulary evident in the App Stack; generally the MANGA app follows a design pattern of having the initial/first level screens display the bottom tabs, however all subsequent screens after do not display the tab bar. In the App Stack you may notice that a number of screens are loaded into the main stack via a function, this is mainly done to help keep the stack a little more organised, though it is important to note that all the screens contained within these functions are all still part of the app stack and should not have a newly created stack navigator of their own.

---

## Navigation Schema

Below is a diagram which gives a full overview of the navigation schema detailing the possible navigation paths throughout both the Direct Wealth and MyAviva apps

![Navigation Schema Venn Diagram](.images/navigation-venn-diagram.png)

See: [Figma file](<https://www.figma.com/file/ZEmQNIdocnPH1Qn93v0Ihd/DigitalNextGen-Navigation-Schema-(for-Devs)?type=whiteboard&node-id=2%3A353&t=mLhPaf7wfh5ThXNO-1>)

---

### Navigation Flow Map (WIP)

This navigation map should be used as reference guide for developers during development to help better define navigation stacks required through MyAviva app.
It should help to define naming conventions for each stack and act as a reference guide and an accurate representation of MyAviva app navigation journeys.

Please note that the stacks for each product are not currently there, we only have a representation of MyHealth and MyPension product navigation and only contains a placeholder to continue mapping out navigation for any other products that will be available in the app.
