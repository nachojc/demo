# Tabs

There are 2 accessible tabs components under the ion-mobile package:

- Tabs
  - **_@aviva/ion-mobile/components/tabs/Tabs.tsx_**
  - Based on [react-native-tab-view](https://reactnavigation.org/docs/tab-view/)
  - Use this when there is a need for a simple tab component
- Collapsible Tabs

  - **_@aviva/ion-mobile/components/collapsible-tabs/collapsible-tabs.tsx_**
  - Based on [react-native-collapsible-tabs](https://github.com/PedroBern/react-native-collapsible-tab-view)
  - Use this for cases when there is a collapsible header
  - Falls back to the Tabs component with an animated header when the screen reader (VoiceOver, Talkback) is enabled

Examples for these tabs can be found by navigating to **_Dev Mode > Components > Tabs_**

❗ AccessibleTabs (**_@aviva/ion-mobile/components/collapsible-tabs/accessible-tabs.tsx_**) is not meant to be used outside of the Collapsible Tabs component.

# Tabs

Example can be found by navigating to **_Dev Mode > Components > Tabs > Tabs Component_**

## Usage

<!-- prettier-ignore-start -->
```tsx
import { TabRoute, Tabs } from '@aviva/ion-mobile/components/tabs';
import { FlashList } from '@shopify/flash-list';
import { FlatList, ScrollView } from 'react-native';

import { ExampleCard, flashListData, listData, ScrollRoute } from './tabs-data';

export const routes: TabRoute[] = [
  {
    key: 'route1',
    title: 'Tab one',
    component: () => (
      <ScrollView>
        <ScrollRoute />
      </ScrollView>
    ),
  },
  {
    key: 'route2',
    title: 'Tab two',
    component: () => (
      <FlatList
        data={listData}
        renderItem={renderItem}
      />
    ),
  },
  {
    key: 'route3',
    title: 'Tab three',
    component: () => (
      <FlashList
        data={flashListData}
        renderItem={renderItem}
        estimatedItemSize={109}
      />
    ),
  },
];

export const TabsScreen = () => (
  <Tabs 
    tabBarScrollEnabled 
    lazy 
    tabRoutes={routes} 
    tabBarVariant="blue" />
);
```

<!-- prettier-ignore-end -->

# Collapsible Tabs

Example can be found by navigating to **_Dev Mode > Components > Tabs > Collapsible Tabs_**

## Usage

<!-- prettier-ignore-start -->
```tsx
import { CollapsibleTabs } from '@aviva/ion-mobile/';
import { TabRoute } from '@aviva/ion-mobile/components/tabs';

export const routes: TabRoute[] = [
  {
    key: 'route1',
    title: 'Tab one',
    component: () => (
      <CollapsibleTabs.ScrollView>
        <ScrollRoute />
      </CollapsibleTabs.ScrollView>
    ),
  },
  {
    key: 'route2',
    title: 'Tab two',
    component: () => (
      <CollapsibleTabs.FlatList
        data={listData}
        renderItem={renderItem}
      />
    ),
  },
  {
    key: 'route3',
    title: 'Tab three',
    component: () => (
      <CollapsibleTabs.FlashList
        data={flashListData}
        renderItem={renderItem}
        estimatedItemSize={...}
      />
    ),
  },
];

export const CollapsibleTabsScreen = () => (
  <CollapsibleTabs
    tabBarScrollEnabled
    lazy
    header={Header}
    tabRoutes={routes}
    tabBarVariant='blue'
  />
);
```
<!-- prettier-ignore-end -->

## Collapsible Tabs Headers wrapper

> Solution based on comment https://github.com/PedroBern/react-native-collapsible-tab-view/issues/361#issuecomment-2079499728

There is a component called **TabsHeaderWrapper** that can be used to wrap your header and enable teh header to be scrollable( usefull for headers that can fill more than 50% of the screen)

There are a few considerations to have in mind when using this wrapper:

- You need to include a header as part of each component in TabRoute and on CollapsibleTabs (see example below). Tabs will use either layoutType = `scrollView` or `flashList`. CollapsibleTabs layoutType = `container`.
- Due to the point above, if you are using a complex component like Fusion Charts, you will need to use a context to keep consistency between all the headers. (See your pension screen)

<!-- prettier-ignore-start -->
```tsx
import { CollapsibleTabs, TabsHeaderWrapper } from '@aviva/ion-mobile/';
import { TabRoute } from '@aviva/ion-mobile/components/tabs';

export const routes: TabRoute[] = [
  {
    key: 'route1',
    title: 'Tab one',
    component: () => (
      <CollapsibleTabs.ScrollView>
        <TabsHeaderWrapper layoutType="scrollView">
          <Header />
        </TabsHeaderWrapper>
        <ScrollRoute />
      </CollapsibleTabs.ScrollView>
    ),
  },
  {
    key: 'route2',
    title: 'Tab two',
    component: () => (
      <CollapsibleTabs.FlatList
        data={listData}
        renderItem={renderItem}
        listHeaderComponenListHeaderComponent={
          <TabsHeaderWrapper layoutType="flashList">
            <Header />
          </TabsHeaderWrapper>
        }
      />
    ),
  },
];

export const CollapsibleTabsScreen = () => (
  <CollapsibleTabs
    tabBarScrollEnabled
    lazy
    header={() => (
        <TabsHeaderWrapper layoutType="container">
          <Header />
        </TabsHeaderWrapper>
      )}
    tabRoutes={routes}
    tabBarVariant='blue'
  />
);
  ```
<!-- prettier-ignore-end -->

# TabBar Styles

Add a new variant type to **_@aviva/ion-mobile/components/tabs/types.ts_**

<!-- prettier-ignore-start -->
```tsx
export type TabBarVariant = 'white' | 'blue' | 'dwBlue' | 'yellow' | 'plain';
  ```
<!-- prettier-ignore-end -->

Add the styles for the new variant to **_@aviva/ion-mobile/components/tabs/theme.ts_**

<!-- prettier-ignore-start -->
```tsx
  white: {
    backgroundColor: tokens.color.White.val,
    indicator: tokens.color.Secondary800.val,
    text: tokens.color.Secondary800.val,
    pressColor: tokens.color.Gray200.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
  },
  ```
<!-- prettier-ignore-end -->

# Best Practices

- Do not nest either of the Tabs components in a ScrollView, FlatList, FlashList or any VirtualizedList.
- Do not pollute tab code with analytics calls or anything that is business logic. These calls should be handled in the parent component.
- Do not roll out your own custom tab components. Tabs and Collapsible Tabs support accessibility and consistent styling.
- For Collapsible Tab 'Headers', try to keep it as simple as possible.
  - In some cases the header needs to be scrollable as well as having links, follow the guidelines described [here](https://github.com/PedroBern/react-native-collapsible-tab-view?tab=readme-ov-file#guides).
