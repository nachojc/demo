# Feature Flags

### What?

Feature flags are a solution for limiting user access to new or existing features, either for business purposes, or for testing in production with controlled rollouts (shift-right testing). Thus, any new code would exist in a production deploy but not be executed and therefore the functionality not released.

It also enables the DevOps teams working in agile methodology to continuously deliver features (disable specific features or functionalities in production but enabled in lower environments) and ability to control on how these features become available to users.

### Lifecycle

The lifespan of a feature flag should be as short as possible and should be associated with a retirement plan.

### Process

- add flag and default value to:
  - `Flags` in `src/feature-flags/index`
  - Each app `feature-flags.json` found within `resources/[app]/feature-flags.json`
- add an appropriate JSDoc comment to the flag
- add the key to `featureFlags` in `translation.json` along with a short description of the flag

**Note**

- once the flag is added to `src/feature-flags/index` it will automatically be included on the Feature Flags screen in DevMode
- Remove the feature flags from `src/feature-flags/index`, `featureFlags` in `translation.json` and the individual `feature-flags.json` folders in `resources`. when the specific feature is released into production and feature flags default value set to true.
