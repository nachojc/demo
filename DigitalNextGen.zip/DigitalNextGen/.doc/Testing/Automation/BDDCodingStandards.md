# BDD Coding Standards

<br>
This document describes the BDD coding standards for the mobile automation project. It mostly replicates the web coding standards with a few exceptions due to differences between the platforms and the softwares used. 
<br><br>
The coding standards can also be viewed here <br>
- [Mobile BDD coding standards](https://confluence.aviva.co.uk/display/DIGT/Mobile+BDD+coding+standards)
- [Web BDD coding standards](https://confluence.aviva.co.uk/display/DIGT/Coding+Standards)
<br><br>
Standards marked with ❗️ are not enforced at this moment in time.

## General coding standards

<br>

|     | Keep methods and classes short                                                                                                                                                                             |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | You need to scroll the text editor to get to the end of a method or 'if' statement. Class contains few hundreds lines of code                                                                              |
| ✅  | Fit the method body on the screen without scrolling (split long methods into smaller, private self-explanatory sub-methods). Extract dependencies to separate, small classes and use dependency injection. |

|     | Do not comment code to disable some functionality |
| --- | ------------------------------------------------- |
| ❌  | `// await loginPage.waitForPageLoad();`           |

|     | Do not write magic numbers or strings                                                                                                                                            |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `if (type != 'I' && type != 'O')`<br>`{`<br>`sampleArray.push(-1 );`<br>`}`                                                                                                      |
| ✅  | `const IncomeType = 'I';`<br>`const OutcomeType = 'O';`<br>`const RootId = -1;`<br>`if (type != IncomeType && type != OutcomeType)`<br>`{`<br>`sampleArray.push(RootId);`<br>`}` |

|     | Use access specifiers explicitly                                                                                                                         |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `export class  SampleClass`<br>`{`<br>`sampleString : string;`<br>`...`<br>`async sampleMethod()`<br>`{`<br>`...`<br>`}`<br>`}`                          |
| ✅  | `export default class  SampleClass`<br>`{`<br>`public sampleString : string;`<br>`...`<br>`private  async  sampleMethod()`<br>`{`<br>`...`<br>`}`<br>`}` |

|     | Opening and closing brackets should be on separate lines (Allman style) |
| --- | ----------------------------------------------------------------------- |
| ❌  | `if (condition) {`<br>`…} else {`<br>`…`<br>`}`                         |
| ✅  | `if (condition`<br>`{`<br>`…`<br>`}`<br>`else`<br>`{`<br>`…`<br>`}`     |

|     | Return from the method immediately when a condition is not satisfied in an if statement                                          |
| --- | -------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `if (condition)`<br>`{`<br>`sampleClass.sampleMethod();`<br>`}`<br>`else`<br>`{`<br>`return false;`<br>`}`<br><br>`return true;` |
| ✅  | `if (!condition)`<br>`{`<br>`return false;`<br>`}`<br><br>`sampleClass.SampleMethod();`<br>`return true;`                        |

|     | Don't use double negation |
| --- | ------------------------- |
| ❌  | `if (!notUsed)`           |
| ✅  | `if (used)`               |

|     | Use spaces before and after comparison and logical operators |
| --- | ------------------------------------------------------------ |
| ❌  | `if(a==b&&x=>y)`                                             |
| ✅  | `if(a == b && x => y)`                                       |

|     | Do not write comments for your code - code should be self-explanatory                                                                 |
| --- | ------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `//EDIT   ID   SHOULD   BE   THE   ID   OF   THE   QUESTIONNAIRERESULTS`<br>`if (id == null)`<br>`{`<br>`return sampleReturn;`<br>`}` |
| ✅  | `if (questionnaireResultsId == null)`<br>`{`<br>`return sampleReturn;`<br>`}`                                                         |

|     | Remove and do not write unnecessary code (YAGNI - you aren't gonna need it)                                                                                                                    |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | Keeping unnecessary code when creating a new template project. Adding code because "we might need a method like this in a future sprint".                                                      |
| ✅  | Remove unnecessary code, create project from scratch. In Agile anything can change, if you are not going to use something right now, do not add it, there is high risk you won't use it at all |

|     | Avoid long switch/case statements                                                         |
| --- | ----------------------------------------------------------------------------------------- |
| ❌  | Long switch/case statements that have become convoluted and difficult to read/understand. |
| ✅  | Move the code from the case block to it's own method.                                     |

|     | Always use brackets in if/else                                                                                                          |
| --- | --------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `if (sampleIndicator == null)`<br>`SampleClass.sampleMethod();`<br>`else`<br>`SampleClass.sampleMethod2();`                             |
| ✅  | `if (sampleIndicator == null)`<br>`{`<br>`SampleClass.SampleMethod();`<br>`}`<br>`else`<br>`{`<br>`SampleClass.SampleMethod2();`<br>`}` |

|     | Don't use single line statements                                              |
| --- | ----------------------------------------------------------------------------- |
| ❌  | `if (sampleIndicator == null) { SampleClass.sampleMethod(); }`                |
| ✅  | `if (sampleIndicator == null)`<br>`{`<br>`SampleClass.sampleMethod();`<br>`}` |

|     | Use string interpolation for composing complex strings                                       |
| --- | -------------------------------------------------------------------------------------------- |
| ❌  | `let sampleString = 'stringPart1' + 'stringPart2' + username + dateOfBirth + 'stringPart3';` |
| ✅  | `let sampleString = 'stringPart1stringPart2${username}${dateOfBirth}stringPart3';`           |

|        | Use AssertionHelper library to perform assertions unless specific message is required                                                                                                                                                                                                                                         |
| ------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Reason | Methods in the AssertionHelper class provide contextual error messages in the event of a failure                                                                                                                                                                                                                              |
| ❌     | `assert.strictEqual(await Actions.isDisplayed((await this.loginScreen).usernameTextbox), true);`<br>`assert.strictEqual(await Actions.isDisplayed((await this.loginScreen).passwordTextbox), true);`<br>`assert.strictEqual(await Actions.getAttribute((await this.loginScreen).usernameTextbox, 'ResourceId'), 'username');` |
| ✅     | `await AssertionHelper.isDisplayed((await this.loginScreen).usernameTextbox);`<br>`await AssertionHelper.isDisplayed((await this.loginScreen).passwordTextbox);`<br>`await AssertionHelper.hasAttribute((await this.loginScreen).usernameTextbox, 'ResourceId', 'username');`                                                 |

|     | Do not use assert module methods without providing failure message                                                                        |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `assert.strictEqual(await Actions.isDisplayed((await this.loginScreen).usernameTextbox), true);`                                          |
| ✅  | `assert.strictEqual(await Actions.isDisplayed((await this.loginScreen).usernameTextbox), true, 'Username textbox could not be located');` |

|          | When you need to do multiple assertions in a single test; wrap it inside an assertion block                                                                                                                                                                                                                                                                                 |
| -------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Resource | It will evaluate all of the assertions inside, rather than throwing an exception at the first failed assertion.                                                                                                                                                                                                                                                             |
| ❌       | `await AssertionHelper.isDisplayed((await this.loginScreen).usernameTextbox);`<br>`await AssertionHelper.isDisplayed((await this.loginScreen).passwordTextbox);`<br>`await AssertionHelper.isNotDisplayed((await this.loginScreen).policyCard);`<br>`assert.strictEqual(1, 4);`                                                                                             |
| ✅       | `await AssertionHelper.assertionBlock(`<br>`async () => await AssertionHelper.isDisplayed((await this.loginScreen).usernameTextbox),`<br>`async () => await AssertionHelper.isDisplayed((await this.loginScreen).passwordTextbox),`<br>`async () => await AssertionHelper.isNotDisplayed((await this.loginScreen).policyCard),`<br>`() => assert.strictEqual(1, 4)`<br>`);` |

|     | Have one step class for each feature file, named the same with ".step" suffix |
| --- | ----------------------------------------------------------------------------- |

|     | Have CommonSteps class for steps that are needed across multiple feature files. Always check for existing steps before writing a new one (DRY - don't repeat yourself) |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------- |

|     | Assertions should not be used outside of Then steps/methods                                                                                                                                                                                                       |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `async navigateToNewSippTransferPage()`<br>`{`<br>`await AssertionHelper.isDisplayed((await this.homeScreen).newSippTransfer);`<br>`await Actions.click((await this.homeScreen).newSippTransfer);`<br>`}`                                                         |
| ✅  | `async shouldSeeNewSippTransfer()`<br>`{`<br>`await AssertionHelper.isDisplayed((await this.homeScreen).newSippTransfer);`<br>`}`<br><br>`async navigateToNewSippTransferPage()`<br>`{`<br>`await Actions.click((await this.homeScreen).newSippTransfer);`<br>`}` |

|     | Then steps/methods should not contain any page interactions                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `async verifyUsingTheAppCategory()`<br>`{`<br>`await Actions.click((await this.faqScreen).whatCanIDoInTheApp);`<br>`await AssertionHelper.isDisplayed((await this.faqScreen).whatCanIDoInTheAppAnswer);`<br>`await Actions.click((await this.faqScreen).notConnectedToInternet);`<br>`await AssertionHelper.isDisplayed((await this.faqScreen).notConnectedToInternetAnswer);`<br>`}`                                                                                                                                                                                  |
| ✅  | `async clickWhatCanIDoInTheApp()`<br>`{`<br>`await Actions.click((await this.faqScreen).whatCanIDoInTheApp);`<br>`}`<br><br>`async verifyWhatCanIDoAnswer()`<br>`{`<br>`await AssertionHelper.isDisplayed((await this.faqScreen).whatCanIDoInTheAppAnswer);`<br>`}`<br><br>`async clickNotConnectedToInternet()`<br>`{`<br>`await Actions.click((await this.faqScreen).notConnectedToInternet);`<br>`}`<br><br>`async verifyNotConnectedToInternetAnswer()`<br>`{`<br>`await AssertionHelper.isDisplayed((await this.faqScreen).notConnectedToInternetAnswer);`<br>`}` |

|     | Only the first assertion should include a wait                                                                                                                                                                                                                                                                                                                                                                             |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `async shouldSeeWarningDialog()`<br>`{`<br>`await AssertionHelper.assertionBlock(`<br>`async () => await Actions.waitForDisplayed((await this.alertScreen).progressNotSavedAlertDialog),`<br>`async () => await Actions.waitForDisplayed((await this.alertScreen).progressNotSavedYesButton),`<br>`async () => await Actions.waitForDisplayed((await this.alertScreen).progressNotSavedCancelButton)`<br>`);`<br>`}`       |
| ✅  | `async shouldSeeWarningDialog()`<br>`{`<br>`await AssertionHelper.assertionBlock(`<br>`async () => await Actions.waitForDisplayed((await this.alertScreen).progressNotSavedAlertDialog),`<br>`async () => await AssertionHelper.isDisplayed((await this.alertScreen).progressNotSavedYesButton),`<br>`async () => await AssertionHelper.isDisplayed((await this.alertScreen).progressNotSavedCancelButton)`<br>`);`<br>`}` |

|     | Avoid explicit waits where possible, identify what is causing need for delay and add appropriate wait                                                                                                                                     |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `await Actions.pause(5000);`                                                                                                                                                                                                              |
| ✅  | `await Actions.waitForDisplayed((await this.samplePage).SampleElement);`<br><br>`await Actions.waitForNotDisplayed((await this.samplePage).SampleElement);`<br><br>`await this.waitUntilCondition(waitForMethod, waitInMS);`<br><br>`etc` |

## Naming conventions

|     | Do not use \_ as prefix for private fields             |
| --- | ------------------------------------------------------ |
| ❌  | `private _remoteDataRepository: RemoteDataRepository;` |
| ✅  | `private remoteDataRepository: RemoteDataRepository;`  |

|     | Do not use Hungary notation                                       |
| --- | ----------------------------------------------------------------- |
| ❌  | `letstrFirstName: string;`<br><br>`let intRetirementAge: number;` |
| ✅  | `let firstName: string;`<br><br>`let retirementAge: number;`      |

|     | Use PascalCase for classes and interfaces                                |
| --- | ------------------------------------------------------------------------ |
| ❌  | `export default class dataRepository`<br><br>`{`<br><br>`...`<br><br>`}` |
| ✅  | `export default class DataRepository`<br><br>`{`<br><br>`...`<br><br>`}` |

|     | Use camelCase for variables/constants and functions/methods                                              |
| --- | -------------------------------------------------------------------------------------------------------- |
| ❌  | `private SampleString: string;`<br><br>`async SampleMethod(SampleString: string)`<br>`{`<br>`...`<br>`}` |
| ✅  | `private sampleString: string;`<br><br>`async sampleMethod(sampleString: string)`<br>`{`<br>`...`<br>`}` |

|     | Use full explanatory names. Avoid abbreviations, acronyms and initialisms, explain the meaning of method, field, property or class whilst keeping the name short |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `let errorMsg = 'Error';`<br>`let dob = '24/06/1996';`<br><br>`async toCRAPage()`<br>`{`<br>`...`<br>`}`                                                         |
| ✅  | `let errorMessage = 'Error';`<br>`let dateOfBirth = '24/06/1996';`<br><br>`async navigateToChangeRetirementAgePage()`<br>`{`<br>`...`<br>`}`                     |

|     | Use 'I' prefix for interfaces       |
| --- | ----------------------------------- |
| ❌  | `export interface SampleInterface`  |
| ✅  | `export interface ISampleInterface` |

|     | Name collection properties with a plural phrase |
| --- | ----------------------------------------------- |
| ❌  | `const existingTestCaseList = [];`              |
| ✅  | `const existingTestCases = [];`                 |

|     | Name bool properties with an affirmative phrase                           |
| --- | ------------------------------------------------------------------------- |
| ❌  | `let hasNoExternalChevron = true;`<br>`let isNotWealthifyAccount = true;` |
| ✅  | `let hasExternalChevron = false;`<br>`let isWealthifyAccount = false;`    |

|     | Use "Page" suffix for page object executor classes |
| --- | -------------------------------------------------- |
| ❌  | `export default class Login`                       |
| ✅  | `export default class LoginPage`                   |

| ❗️ | Use "Locators" suffix for page object locator classes |
| --- | ----------------------------------------------------- |
| ❌  | `export default class LoginScreen`                    |
| ✅  | `export default class LoginPageLocators`              |

| ❗️ | Don't suffix constants with "Error", "Header", etc. if they are in a constants class containing the same                                                                                                                                                                                                                                                                                                                        |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `export default class ErrorMessages`<br>`{`<br>`public static readonly YouAreIneligibleErrorMessage = 'You are ineligible';`<br>`public static readonly PleaseTryAgainLaterErrorMessage = 'Please try again later';`<br>`}`<br><br><br>`export default class Headers`<br>`{`<br>`public static readonly HomePageHeader = 'Pension summary';`<br>`public static readonly SuccessPageHeader = 'You have been successful';`<br>`}` |
| ✅  | `export default class ErrorMessages`<br>`{`<br>`public static readonly YouAreIneligible = 'You are ineligible';`<br>`public static readonly PleaseTryAgainLater = 'Please try again later';`<br>`}`<br><br><br>`export default class Headers`<br>`{`<br>`public static readonly HomePage = 'Pension summary';`<br>`public static readonly SuccessPage = 'You have been successful';`<br>`}`                                     |

## Page object model

|     | Each page in your app should be represented in the code by a page class |
| --- | ----------------------------------------------------------------------- |

|     | Page executor classes should contain methods that mimic the actions user can take in the app |
| --- | -------------------------------------------------------------------------------------------- |

|     | Page executor classes should not contain finding elements of the web page. All web page elements should be placed in separate locator class and inherited into the executor class                                                                                                                                                                            |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| ❌  | `export default class SamplePage`<br>`{`<br><br>`let continue = '//*[@content-desc = "Continue"]');`<br><br>`async clickContinue()`<br>`{`<br>`await Actions.click(this.continue);`<br>`}`<br><br>`}`                                                                                                                                                        |
| ✅  | `export default class SamplePage`<br>`{`<br><br>`/**`<br>`* @returns {Promise<AddBeneficiaryScreen>}`<br>`*/`<br>`private get sampleScreen(): Promise<SampleScreen> {`<br>`return this.getNativeScreen('sampleScreen.screen');`<br>`}`<br><br>`async clickContinue()`<br>`{`<br>`await Actions.click((await this.sampleScreen).continue);`<br>`}`<br><br>`}` |

|     | In locator classes you should store locators as properties, but you can also create methods if you need to pass a parameter to the locator                                                                 |
| --- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ✅  | `this.selectGoalDropDown = AndroidHelper.byResourceId(AndroidViewClassEnum.EDIT_TEXT, 'list-input');`<br>`this.selectGoal = (goal: string) => AndroidHelper.byText(AndroidViewClassEnum.TEXT_VIEW, goal);` |

| ❗️ | Add commonly used locators to CommonLocators class and inherit this into all other page classes. Don't have multiple identical locators in different page classes |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------- |

| ❗️ | When interacting with elements in the CommonLocators class, access it via the page class that inherits it |
| --- | --------------------------------------------------------------------------------------------------------- |

|     | Page classes should not contain instances of other page classes (except CommonPage)                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| ❌  | `const monthlyPaymentPage = new MonthlyPaymentPage();`<br><br>`export default class YourDetailsPage`<br>`{`<br>`/**`<br>`* @returns {Promise<YourDetailsScreen>}`<br>`*/`<br>`private get yourDetailsScreen(): Promise<YourDetailsScreen>`<br>`{`<br>`return this.getNativeScreen('isaApply/yourDetails.screen');`<br>`}`<br><br>`async navigateToEmploymentStatusPage()`<br>`{`<br>`await monthlyPaymentPage.navigateToMonthlyPaymentCollectionPage();`<br>`await monthlyPaymentPage.selectPaymentDay();`<br>`await this.selectContinueButton();`<br>`await this.validateYourDetailsPageExistence();`<br>`}`<br><br>`}`                                                                                                                                                                                                                                                                                                                                                                                                                   |
| ✅  | `export default class MonthlyPaymentPage`<br>`{`<br>`/**`<br>`* @returns {Promise<MonthlyPaymentScreen>}`<br>`*/`<br>`private get monthlyPaymentScreen(): Promise<MonthlyPaymentScreen>`<br>`{`<br>`return this.getNativeScreen('isaApply/monthlyPayment.screen');`<br>`}`<br><br>`async submitForm()`<br><br>`{`<br>`await this.navigateToMonthlyPaymentCollectionPage();`<br>`await this.selectPaymentDay();`<br>`}`<br><br>`}`<br><br><br><br>`export default class YourDetailsPage`<br>`{`<br>`/**`<br>`* @returns {Promise<YourDetailsScreen>}`<br>`*/`<br>`private get yourDetailsScreen(): Promise<YourDetailsScreen>`<br>`{`<br>`return this.getNativeScreen('isaApply/yourDetails.screen');`<br>`}`<br><br>`async submitForm()`<br><br>`{`<br>`await this.selectContinueButton();`<br>`await this.validateYourDetailsPageExistence();`<br>`}`<br><br>`}`<br><br><br><br>`When('I navigate to the Confirm page', async () =>`<br>`{`<br>`await monthlyPaymentPage.submitForm();`<br>`await yourDetailsPage.submitForm();`<br>`});` |

|     | Page locators should not be heavily dependent on page structure. Changes to the page will likely break the locator. Add testIds if no suitable locator exists                                                                                                                                                                                                                 |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `export default class HomeScreen extends BaseHomeScreen {`<br>`constructor()`<br>`{`<br>`super();`<br>`this.learnMoreLink = (product: string) =>`<br>`'${iosHelper.byName(product,'XCUIElementTypeOther')}${iosHelper.byParent('XCUIElementTypeOther')}${iosHelper.byParent('XCUIElementTypeOther')}${iosHelper.byLabel('Learn more', 'XCUIElementTypeStaticText')}';`<br>`}` |
| ✅  | `export default class HomeScreen extends BaseHomeScreen {`<br>`constructor()`<br>`{`<br>`super();`<br>`this.learnMoreLink = (product: string) =>`<br>`iosHelper.byLabel('Learn more', 'XCUIElementTypeStaticText')`<br>`}`                                                                                                                                                    |

|     | Use parameterised locators for radio buttons where possible, with the response passed in as a parameter                                                                                                                                                                                             |
| --- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `this.anyPreviousAddressesYesRadioButton = AndroidHelper.byPartialResourceId(AndroidViewClassEnum.RADIO_BUTTON, 'previous-details-yes-button');`<br>`this.anyPreviousAddressesYesRadioButton = AndroidHelper.byPartialResourceId(AndroidViewClassEnum.RADIO_BUTTON, 'previous-details-no-button');` |
| ✅  | `this.anyPreviousAddressesRadioButton = (type: 'yes' \| 'no') => AndroidHelper.byPartialResourceId(AndroidViewClassEnum.RADIO_BUTTON, 'previous-details-${type}-button');`                                                                                                                          |

| ❗️ | Store headers and element text for locators in constant classes |
| --- | --------------------------------------------------------------- |

| ❗️ | Assertions should not be hidden in methods and page classes |
| --- | ----------------------------------------------------------- |

## Feature files

|     | Use step bindings correctly                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |
| --- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| ✅  | Given - Preconditions and actions that are not specifically under test. For test preparation, generating data, progressing to page under test, etc.<br><br>When - Action(s) under tests<br><br>Then - Asserting on expected result to verify action(s) under test<br><br><br><br>ALL scenarios should follow the following structure:<br><br>Given step(s) => When step(s) => Then step(s)<br><br>Never perform assertions (Then steps), then return to making more actions (Given/When) and then asserting again (Then). This implies your scenario has multiple behaviours per test, when there should only ever be one behaviour under test per scenario. |

|     | All scenarios must have at least one When step (there must be some action under test) and one Then step, but can have no Given steps                                          |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `Scenario: The user can see their details on the personal details page`<br>`Given I navigate to the personal details page`<br>`Then the users personal details are displayed` |
| ✅  | `Scenario: The user can see their details on the personal details page`<br>`When I navigate to the personal details page`<br>`Then the users personal details are displayed`  |

|     | Use Scenario Outline when using Examples tables                                                                                                                                                                                                                 |
| --- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `Scenario: The user can navigate to the success page`<br>`Given I am a '<user>'`<br>`And I am on the landing page`<br>`When I click the continue button`<br>`Then I am taken to the success page`<br><br>`Examples:`<br>`\| user \|`<br>`\| ...     \|`         |
| ✅  | `Scenario Outline: The user can navigate to the success page`<br>`Given I am a '<user>'`<br>`And I am on the landing page`<br>`When I click the continue button`<br>`Then I am taken to the success page`<br><br>`Examples:`<br>`\| user \|`<br>`\| ...     \|` |

|     | Use And or But binding when using consecutive Given, When or Then steps                                                                                                                                                                                  |
| --- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `Given I am a 'sample user'`<br>`Given I am on the landing page`<br>`When I enter employed user details`<br>`When I click the continue button`<br>`Then I can see the employed dynamic message`<br>`Then I cannot see the self employed dynamic message` |
| ✅  | `Given I am a 'sample user'`<br>`And I am on the landing page`<br>`When I enter employed user details`<br>`And I click the continue button`<br>`Then I can see the employed dynamic message`<br>`But I cannot see the self employed dynamic message`     |

|     | Scenario titles should describe the behaviour under test, it should not be required to read the steps to understand the test |
| --- | ---------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `Scenario: Login page`                                                                                                       |
| ✅  | `Scenario: The user is able to login by entering valid credentials`                                                          |

|     | Write steps and scenarios in clear, concise English. Feature files should be usable as documentation for your application                                                                                                                                                                                                                                                                                                                                                                       |
| --- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| ❌  | `Scenario: Broker without approved fga access to household flood risk enquiry application`<br>`Given I am on broker login page`<br>`And I login with 'BrokerNoHRE' credentials`<br>`When I navigate to the 'ConnectHouseHoldFloodRisk' url post login`<br>`Then Household flood risk enquiry is not enabled message is displayed`<br>`And Access household flood risk enquiry cta button is not displayed`<br>`And Breadcrumb links are displayed on household flood risk enquiry landing page` |
| ✅  | `Scenario: A broker without approved FGA access is unable to access the household flood risk enquiry application`<br>`Given I am on the broker login page`<br>`And I login as a 'broker without approved FGA access'`<br>`When I navigate to the 'ConnectHouseHoldFloodRisk' page`<br>`Then the household flood risk enquiry is not enabled message is displayed`<br>`And the access household flood risk enquiry button is not displayed`<br>`And the correct breadcrumb links are displayed`  |

|     | Step do not need to start with capital letters unless that word requires it (e.g. proper nouns) |
| --- | ----------------------------------------------------------------------------------------------- |
| ❌  | `Then The correct breadcrumb links are displayed`                                               |
| ✅  | `Then the correct breadcrumb links are displayed`                                               |
