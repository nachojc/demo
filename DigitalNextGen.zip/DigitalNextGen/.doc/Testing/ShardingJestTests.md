# Sharding JestJS tests on Azure DevOps pipelines.

## SUMMARY:

All the code for the MANGA project is unit tested using the JestJS testing framework.

https://jestjs.io/

As part of this Jira,

https://jira.aviva.co.uk/browse/MANGA-2389

we decided to enable and configure Jest to "shard" the tests to speed up the pipeline runs.

Vendor doc for this is pretty minimal.

https://jestjs.io/docs/cli#--shard

## IMPLEMENTATION:

For Aviva to enable this on the Azure DevOps piplines:

The **"pipelines/steps/unit-tests.yaml"** step template was modified to allow the command the runs the tests to accept a parameter for **"--shard"**.

https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/pipelines/steps/unit-tests.yaml

Then the main pipeline **"pipelines/pr-tests.yaml"** was updated to include a **"job per shard"** definition with each job specifying/passing it's own unique shard number.

https://avdigitalweb.visualstudio.com/_git/DigitalNextGen?path=/pipelines/pr-tests.yaml

## NOTES:

As sharding JestJS causes the tests to be run over multiple runners/agents, it is necessary to run ALL pipeline steps in each job to ensure that all pre requisites have been met on the agent for Jest to find and be test the the JS source code.

This approach has a trade off, the pipelines run quicker as a result, but less pipelines can be run in parallel as the shards use up more of the total available runners/agents.

We are aware that the pipeline code to do this is very repeated/copy&paste, but this is how it works for Azure DevOps pipelines at this time.
