# Overview

There are multiple persistent storage mechanisms at play in the current app.
You will need to decide where to store a given piece of information based on what type it is and what protection/access mechanisms are required.
The following sections will help you understand how to make the correct decision.

- Expo Secure Store

  - This is more secure/encrypted and is where we should save secure strings, it utilises Keychain/Keystore for iOS/Android respectively

- MMKV

  - This allows storing more complex objects and accessing them easier/faster, with a deeper integration into our global state

- SQLite

  - Local file based database

- .env

  - Not technically a runtime storage mechanism - but is a place you may choose to store a piece of information during feature development.

> **Reference**
>
> - [MMKV](https://github.com/mrousavy/react-native-mmkv)
> - [Expo Secure Store](https://docs.expo.dev/versions/latest/sdk/securestore/)
> - [SQLite](https://github.com/Nozbe/sqlite)
> - [.env](https://www.npmjs.com/package/dotenv)

## How to implement storing with each of these mechanisms

### MMKV

Persisting to MMKV is relatively simple.
The following snippet sets up an observable instance in the variable `loginCount`, storing it against the cache identifier `LOGIN_COUNT_KEY`.

```ts
// src/common/interfaces/storage/index.ts
const loginCount = observable<string | null>(null);
persistObservable(loginCount, { local: LOGIN_COUNT_KEY });
```

Now any time that the value to loginCount is changed, e.g. `loginCount.set(10)`, the value will activate an event listener to store the value in MMKV as well.

### expo-secure-store

expo-secure-store doesn't have a persistence plugin in the same manner as MMKV, so we have a hook setup that handles listeners that sync the observable data in the secure store.

Given an observable such as `export const accessToken = observable<string | null>(null);` then you can handle persisting and storing of that with the follow snippet:

```ts
// src/common/hooks/use-app-setup.ts
useSecureStorageObservable(
  accessToken,
  async (token: string) => SecureStore.setItemAsync(ACCESS_TOKEN_KEY, token),
  async () => SecureStore.getItemAsync(ACCESS_TOKEN_KEY)
);
```

### SQLite

Stores large amounts of structured data, right now this is only used for MyDrive, so you should really question when aiming to add data here, there should be a need to store hundreds or more objects

### .env

You should consider using `.env` if you have a requirement to change it per deployment target or build.
A good example is the BASE_URL, note that by default only strings are stored in .env and we have to do some runtime parsing to coerce the types, think whether updating all the areas for .env are needed if you keep the value the same across all envs.
