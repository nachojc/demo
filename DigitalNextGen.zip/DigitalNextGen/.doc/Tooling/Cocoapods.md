# All things Cocoapods

## How it's installed

Generally, you'll want to use install.sh. Under the hood, that does the following things:

- Install rbenv via brew
- Installs Ruby 3.3.0 via rbenv
- Tells Ruby to get gems from https://binaries.avivagroup.com/artifactory/api/gems/manga-gems-remote/
- Installs gems (generally all the latest versions) for
  - cocoapods
  - xcodeproj
  - claide
  - colored2
  - activesupport
- Tells cocoapods to remove the "trunk" repo (which points at the public CDN)
- Tells cocoapods to use https://binaries.avivagroup.com/artifactory/manga-cocoapods-local/ as a CDN called manga-cocoapods-local
  - There used to be a repo called manga-cocapods-remote using a plugin called repos-art but it's a security mess and is no longer supported
- Runs pod update to get a list of the packages stored there

## Why it's used

React Native Apps (in simple terms) generally use 2 types of packages:

- Purely Javascript, and which run inside the JS runtime (Hermes or JSC)
- Packages which have a native component (talk to iOS or Android directly) and have a JS bridge

For the second type, the javascript portion is delivered into the node_modules folder with npm or yarn, and the iOS portion is delivered into the ios folder with pod

Running yarn nuke or yarn ios will do many things, but a few are important to us:

- If we're running locally (on a developer laptop) the ios/Podfile gets patched to use the manga-cocoapods-local repository (which we set up above)
- Apply some patches to the Podfile
- The Podfile.lock is copied out of patches folder into the ios folder
- pod install is run

pod install will do the following things:

- Read through the Podfile, check all the env vars are sensible
- Scan through the node_modules folder looking for other Spec to include (they can be "something.podspec" which is written in Ruby, or "something.podspec.json" which is a JSON equivalent).
- Add any other locally defined pods (like Firebase)
- Check the latest versions of those pods in the repo
- Fetch the pods from the repo if they're not already cached and cache them in ~/Library/Caches/CocoaPods/Pods
- Compile them

## Some technical bits

Repos are registed in ~/.cocoapods/repos, and the Spec files are kept in ~/.cocoapods/repos/\<repo name\>/Specs/X/Y/Z/ where X, Y & Z are the first 3 hex digits of the hash.

In the repo cache are a set of shard files in the format all_pods_versions_X_Y_Z.txt, which contain a series of lines matching the packages in that folder:

JustJson/0.1.0/0.1.1/0.1.2/0.1.3/0.1.4

This would say that in X/Y/Z are the spec files for JustJson versions 0.1.0, 0.1.1, etc.

The Spec files contain typical metadata (name, license, version, etc) along with the deps (name, version) and the location of the pod source. Many pod sources are accessible to the devs, but a small number are not (especially anything hosted in an S3 bucket due to the Auth headers clashing, Onfido and Qualtrics being good example of this) and so the sources will need to be moved into Artifactory and the spec files updated.

## So you're missing a package

Typically this happens when someone upgrades a JS package, it has an embedded Spec file and that has a version bump (or one of the deps does). We'll walk through an example, using Firebase as the upgradable package.

There are 3 errors that you may get:

```
1. [!] No podspec exists at path /Users/imadev/.cocoapods/repos/manga-cocoapods-local/Specs/a/b/c/Banana/1.2.3/Banana.podspec.json`
```

```
2. [!] CocoaPods could not find compatible versions for pod "Banana":`

  In snapshot (Podfile.lock):
    Banana (= 1.2.3, ~> 1.0)

  In Podfile: Banana

None of your spec sources contain a spec satisfying the dependencies: 'Banana, Banana (= 1.2.3, ~> 1.0)'.
```

```
3. Errno::ENOENT - No such file or directory @ rb_sysopen - /Users/imadev/.cocoapods/repos/manga-cocoapods-local/all_pods_versions_a_b_c.txt`
```

**_If you get any of these errors, the first thing to do is run `pod repo update` (or run af.sh). If the error persists, continue..._**

Error 1 means the shard file refers to a Podspec that doesn't exist in the repo.

Error 2 means the shard file doesn't contain a compatible version.

In either case:

`tooling/pod2af.sh --dry-run podname`

This will download the latest shard file from Github, and show you which versions are in Artifactory.

Running the same command without --dry-run will upload the shard and pod files to Artifactory

Error 3 means the shard file isn't available locally. Typically this is because you've introduced a new pod.

`tooling/pod2af.sh --shard abc`

Where abc is from all_pods_versions_a_b_c.txt (no underscores)

This will download the shard to your local repo and list the pods contained within it. From here, you may recognise the missing pod and you can resolve as per above, OR you can now rerun your command, and it will give you a type 1 error as above.

If you get a 401 error from Artifactory, this usually means the repo index is rebuilding. Get a cup of tea, and retry later.

- run pod repo update && pod install
  - either it "just works" at this point, or it will fail to grab the source
  - If so, you'll need to download the source somehow, upload it to AF, update the podspec and re-upload that to AF. This step is left as an exercise for the reader ;)
