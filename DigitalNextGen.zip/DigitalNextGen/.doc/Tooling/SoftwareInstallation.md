# Software Installation

This page describes how to install the necessary software that will support you being able to contribute to the DigitalNextGen repository. These instructions are targeted for a macOS development environment.

Please note, throughout the software installation process, there will be various prompts that you will need to interact with, especially ones that requires you to enter your macOS admin password.

## Pre-Requisites

- **Aviva Laptop:** The development can only be done on an Aviva issued laptop.
- **Minimum macOS Version:** Sonoma 14.3 (as of 1st Feb 2024)
- **Disk Space:** 60GB+ of free disk space. This should be ok on the freshly issued laptops. Contact IT support if you don't have enough space
- **Local Admin Account:** The primary account on your MacBook should have admin permission. Some older setups had 2 different accounts, talk to IT if this is the case.
- **VPN / WSS:** Working Aviva VPN and WSS proxy access if you are working remotely. This should already be sorted out if you can access Aviva's Confluence and Jira spaces.
- **IT Access** - IT Self Service can be accessed [here](https://itselfservice.avivagroup.com/). Access should be requested and granted to the following:

  - **Confluence - MANGA space access** - `ITSS` > `Systems access request` > `I need to add or change system access` > Select `Confluence additional access` > Enter access reason > Select `rol_se_digital_myavivanextgen_confluence_user` from the dropdown list
  - **Confluence - IT user access** - `ITSS` > `Systems access request` > `I need to add or change system access` > Select `Confluence - market groups` > Enter access reason > Select `rol_se_all_confluence_it_user` from the dropdown list.

    For more information on Confluence space access, see [here](https://confluence.aviva.co.uk/display/AtlassianToolsSupport/Confluence+Spaces).

  - **Jira (basic access)** - `ITSS` > `Systems access request` > `I need to add or change system access` > Select `Jira (basic access only)`
  - **Jira (additional access)** - `ITSS` > `Systems access request` > `I need to add or change system access` > Select `Jira (additional access)` > Select `rol_se_digital_myavivanextgen_jira_user` from the dropdown list
  - **ADO (AzureDevOps)** - `ITSS` > `Systems access request` > `I need to add or change system access` > `Digital Next Gen (ADO)` > `Developer` from the dropdown list. If you are unsure of what access you require, please see all Platform AD groups listed [here](https://confluence.aviva.co.uk/x/1iJ4Tg).
  - **Artifactory** - `ITSS` > `Systems access request` > `I need to add or change system access` > `Artifactory` > Select `rol_se_manga_artifactory_users` from the dropdown list
  - **Github** - `ITSS` > `Systems access request` > `I need to add or change system access` > `Developer Tools` > `Download access` > `request to be added to group` > `PSG_UK_CISO_DEVELOPERS`
  - **Checkmarx** - See [Checkmarx ONE Hub](https://confluence.aviva.co.uk/x/qpwVRQ) for access info. Please follow access to project group section and use `acc_se_cxone_uk-digital-myaviva-mobile` for the project name. This requires the `Confluence - IT user access` mentioned above.

  ```
  IMPORTANT: When submitting your request for each of the above, for the justification for usage, use something along these lines: _"I have joined as a <role title, e.g. React Native developer> for the Aviva mobile app project, and require access to <system> at the level <permission level> to work on the project"_.

  As Aviva is working with sensitive customer information, it is important for IT to be aware of the reasons for you having access, so be sure to provide good explanations. If you don't provide a sufficient reason, your request will be rejected.
  ```

- **Third Party Applications** - There may be other applications (e.g. BrowserStack) that you may require access to in order to do your job. This will vary depending on your role, so please see [here](https://confluence.aviva.co.uk/x/IZSvTw) for applications relevant to your role.

- **Training** - For `Jira` and `Confluence`, training needs to be completed by the new starter. This may impact request approval if not completed first but your mileage may vary.
  - [Jira](https://sway.office.com/mhyaIwx12qufhewB?ref=Link)
  - [Confluence](https://sway.office.com/fSCJ9rowDatFipgq?ref=Link)

## Installation

### General Guidance

**IMPORTANT: Please be mindful of the following guidance throughout all stages of the installation process to ensure you can get through the process as seamlessly as possible.**

- **Do not leave your MacBook unattended for this.** The setup will ask you for your admin account password at various steps to proceed. It may even ask for password twice in a row to proceed at some points.
- The script can take a while to complete as it's downloading a lot of files. **Don't try to run other commands or scripts** while this script is running.
- If you want to see the script is actually doing something behind the scenes, Activity Monitor should show lots of activity. If your Terminal shows a permission prompt to read / access directories, approve the prompts.
- **Check the output for any errors.** If there are errors (other than the ones shown below) they need to be addressed before going any further.
- The script may exit with some error messages (see below). This is expected and normal. You can continue as normal.

### Software Access

Ensure you have access to the following:

- [ADO](https://dev.azure.com/avdigitalweb/DigitalNextGen/_git/DigitalNextGen/) - As per the access request for Azure DevOps, this provides you access to clone the repository
- [Artifactory](https://binaries.avivagroup.com/ui/) - As per the access request for Artifactory, this will provide you access to our third party dependencies. You should be able to see several repos here with manga in the name (under Artifacts, on the left menu) - if not, your permissions are wrong.

If you have an issue with access to any of the above, it is likely that you need to verify that all of your access requests have been requested and granted.

### Azure DevOps repo

The workstation build and configuration scripts are held in the same Azure DevOps git repo as the application codebase. To access the scripts:

- Create a ADO Personal Access Token (PAT) at https://dev.azure.com/avdigitalweb/_usersSettings/tokens. If you're unfamiliar with ADO, a guide is [here](https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?toc=%2Fazure%2Fdevops%2Forganizations%2Ftoc.json&view=azure-devops&tabs=Windows#create-a-pat)
- `git clone https://avdigitalweb@dev.azure.com/avdigitalweb/DigitalNextGen/_git/DigitalNextGen` You can use anything for the userid, and the PAT for the password.
- `cd DigitalNextGen`

Run the script:

- `chmod +x tooling/install.sh`
- `tooling/install.sh`

The script may exit if the initial checks fail.

The script can be re-run repeatedly to update and fix any issues. Please ensure that `VSCode` and `Android Studio` are not running while the script is applied.

### Configuring Artifactory access

_IMPORTANT: Due to a firewall issue, access to Artifactory fails if you're in Hoxton and the cable is plugged into the laptop. Pull out the cable and use the Wifi before running any commands such as `yarn` / `pod` / `gradle` / etc._

To be able to use Aviva's mirrored registry you have to go through few steps to gain access to the platform and set up to pull packages from their registry on your machine.

To set up access:

`tooling/af.sh`

Note that the script will ask for the password from your Aviva Group account and local account. Please read the error messages for incorrect password and retry accordingly. If you get an error message, it means something has not worked and you either need to get your permissions checked or follow other steps from troubleshooting.

The script can take a while as it will try and fix anything it sees as incorrect in your setup. **Don't try to run other commands or scripts** while this script is running.

If you don't see something similar to above then it means you don't have appropriate permissions to make the development environment work.

**IMPORTANT: Please note, the `af.sh` script needs to be run every 7 days due to an expiring token.**

### Android Studio Checklist

The first time you open AS you may be directed to input proxy settings. DO NOT DO THIS. WSS will manage the proxy automatically.

### Xcode Checklist

You may need to accept the license on first run, and also register as a developer. Use your aviva.com email address. Do NOT use a personal AppleID!

### Post Installation Checklist

- Start Xcode and accept any license agreements and continue with first time setup
- Setup up your Android emulators (see below)

## Running the app

Be sure to follow the instructions in the [README](../../README.md) file before continuing. This is to ensure that the repo is fully cloned & that dependencies are installed correctly prior to attempting to build the app.

### Instructions for iOS

Running Expo commands in the repo should open Expo Go in your simulator and install the application. To run the app for iOS, follow the instructions in the [README](../../README.md) under the `iOS` section.

### Instructions for Android

You might already have an emulator setup on your Android Studio. To run the app for Android, follow the instructions in the [README](../../README.md) under the `Android` section.

## SourceTree Setup

If you're using SourceTree to commit work to the repository, you'll need to ensure pre-commit hooks are working correctly.

You'll likely need to create this `.huskyrc` file in your user directory, not within the repo itself. This is because you'll likely otherwise get 'command not found' errors when running the pre-commit hook.

Follow the instructions [here](https://typicode.github.io/husky/troubleshooting.html) and add the file contents below:

```
# This loads nvm.sh, sets the correct PATH before running hook, and ensures the project version of Node

export NVM_DIR="$HOME/.nvm"

[ -s "$NVM_DIR/nvm.sh" ] && \. "$NVM_DIR/nvm.sh"

# If you have an .nvmrc file, we use the relevant node version

if [[-f ".nvmrc"]]; then
nvm use
fi
```

There is also a chance you'll run into issues with `tput` throwing an error like:

```
tput: No value for $TERM and no -T specified
To resolve this, I've found including `export TERM="linux"` resolves the issue.
```

You should then be able to use SourceTree without issue.

_You may also need to switch SourceTree to use "System Git" instead of the embedded one - your mileage may vary._

## Troubleshooting

**IMPORTANT: DO NOT TRY TO MODIFY YOUR USER SETUP FOR SUDO OR RUN ELEVATED COMMANDS UNLESS ADVISED TO DO SO. YOUR SETUP WILL FAIL OTHERWISE.**

- If the Android emulators are not working, try removing and re-adding them (Android Studio may ask for a plug-in update on first run. This will only work if proxy is setup from previous steps otherwise you will keep seeing an "Unknown Error" during the Android Studio startup)
- Xcode normally installs with latest iPhone simulators, so other simulators will need to be installed manually (as required)
- Xcode is installed with the current iOS platform and the option to add other versions is disabled. Let the team know if you need other versions to be supported and it will be arranged
- If you prefer to use SourceTree (installed via the setup script), you may need to change the preferences to use "System Git" rather than the integrated version to make it work with ADO
- If your `af.sh` is failing with things like `yarn package <some package> not found`, then it means your Artifactory permissions are not setup properly
- If you are told that you have all the permissions and your setup scripts are still not working then restarting the machine may fix it
- If the `af.sh` script tries to go to `github.com` for `Homebrew`, there is likely a folder(s)/file(s) permission/ownership issue in `/Users/<user>/Library/Caches/Homebrew`

  To fix this, follow the steps below:

  1. Open terminal session
  2. Enter the following command: `su <user>admin`
  3. Enter admin password
  4. Enter the following command: `rm -rf /Users/<user>admin/Library/Caches/Homebrew`
  5. Close all terminal sessions (including any in VS Code etc.)
  6. Start a new session as your normal user
  7. Re-run `toooling/af.sh` script

- Check the terminal output - there should not be any attempts to connect to `github.com`

- If your Git commands start to fail and keep asking for your credentials, then your Azure Git password/token might have expired (Aviva do this on an automated basis). You can generate a new Git password as described [here](https://learn.microsoft.com/en-us/azure/devops/organizations/accounts/use-personal-access-tokens-to-authenticate?view=azure-devops&tabs=Windows)

- After reconnecting to WSS (first thing in the morning, or after connecting to the VPN) to need to go to a website before using a command line tool. It doesn't matter which website - github.com is fine. If not you may get error messages about SAML which look like this:

```
fatal: unable to update url base from redirection:
  asked for: https://avdigitalweb.visualstudio.com/DigitalNextGen/_git/DigitalNextGen/info/refs?service=git-receive-pack
   redirect: https://login.microsoftonline.com/42d0xxx
```
