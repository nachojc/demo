# Connect to lower environments with iOS Simulator and Android emulator

This guide provides support in setting up your iOS Simulators and Android emulator to access third party services (e.g. Qualtrics) in lower environments.

## Pre-Requisites

- Up to date `MacBook Install` folder, as described [here](../Tooling/MacBookInstallFolder.md)

## Setup for iOS

1. Within the `MacBook install` folder (explained [here](../Tooling/MacBookInstallFolder.md), find the `Aviva Group Internal Root CA.cer` file and `CertEmulationCA 3 6.crt` file
2. Drag the certificate directly onto the simulator
3. On the simulator, open **Settings** > **General** > **About** > **Certificate Trust Settings**
4. Enable **full trust** for the installed certificates

## Setup for Android

1. Launch an emulator:
   - Option 1: Via the Android Virtual Device Manager
   - Option 2: Using `yarn android:run:{apiLevel}` (e.g. yarn android:run:28)
2. Within the `MacBook install` folder (explained in [here](../Tooling/MacBookInstallFolder.md), find the `Aviva Group Internal Root CA.cer` file and `CertEmulationCA 3 6.crt` file
3. Drag the certificates directly into the emulator
4. Go to **Settings** > **Security and location** > **Encryption and credentials** > **Install from SD Card** and select the certificate from the download folder and select **Trust for VPN and Apps** (repeat for the other certificate)
5. Go to **Settings** > **Network** > **Internet** and enable WiFi and select AndroidWifi
6. Select **AndroidWifi** > **Edit icon on top right** > **Change Proxy from None to Manual** and enter the details defined in the `Proxy Details - Using Wifi` section at the bottom of this guide and click `Save`

### Using Mobile Data

To login and use the lower environments such as `RWY` and `RWY1`, on the Android emulator, please follow the steps below:

1. Go to **Settings** > **Network** > **Internet**, then disable WiFi
2. Select **Mobile network** > **Advanced** > **Access Point Names**, then select the cross to Add a new APN
3. Enter the details in the `Proxy Details - Using Mobile Data` section
4. Select the overflow menu (top right) and select `Save`. Once this is done, make sure it's selected and active

_Optional: If the emulator has Chrome, then you may be prompted for you Aviva username (RACFID@avivagroup.com) and password_

### Proxy Details

#### Using WiFi

```
   Proxy hostname: ep.threatpulse.net
   Proxy Port: 80
   Bypass proxy for: localhost, 10.0.2.2, [IP of metro bundler]
```

**IMPORTANT: To connect to the lower environments using WiFi and ensure that the Metro bundler stays connected also, you will need to add the Metro IP Address (as shown in the image below).**

![image](.images/metro-ip-address.png)

#### Using Mobile Data

```
   Name: AvivaProxy
   APN: ep.threatpulse.net
   Proxy: ep.threatpulse.net
   Proxy Port: 80
```
