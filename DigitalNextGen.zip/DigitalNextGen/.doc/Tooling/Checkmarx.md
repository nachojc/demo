# Checkmarx

Checkmarx is used to check for security vulnerabilities within our code and our dependencies.

## Access

There are two sets of groups that can view or modify risks within Checkmarx. These groups are explained below:

- `Developer` - day-to-day access, triaging risks and resolving as well as proposing risks as not exploitable.

- `Tech Lead/Risk Manager` - A tech lead/architect who can review a developer proposal and then make a call as to whether they agree or not.

To access Checkmarx and the VSCode extension, you will need to ensure you have requested the correct access, as described [here](https://dev.azure.com/avdigitalweb/DigitalNextGen/_wiki/wikis/Estate%20Documentation/723/SoftwareInstallation?anchor=pre-requisites).

## VSCode Extension

### Installation

See [Checkmarx Developer Plugins](https://confluence.aviva.co.uk/x/Tp1wTw) for guidance.

### Usage

## Developer Workflow

### Local Development

When making changes on your local branch, you can use the Checkmarx VSCode extension to validate that your code does not introduce any new issues.

### Pull Requests

Once a pull request is published, a Checkmarx scan will be initiated. This covers a SAST (Static Application Security Testing) scan only. This is to catch issues early enough, without adding significant execution time to the pull request gate.

### Daily Scans

We perform a daily scan for the DigitalNextGen repository. This will perform a full scan (SAST, SCA and IaC). These pipelines are located within the [Gates](https://dev.azure.com/avdigitalweb/DigitalNextGen/_build?definitionScope=%5CGates) folder and are named with the following naming convention: `RepoName-Checkmarx` (e.g. DigitalNextGen-Checkmarx).

### Resolving Issues

There are a few ways to resolve an issue:

**Fix as per Checkmarx recommendation**

- Checkmarx will provide a recommendation as to how you remediate the risk. For example, you may need to update one or many dependencies. Once this has been merged into the main branch, the next re-scan will pick up the resolution to the risk.

**Mark as 'Proposed Not Exploitable'**

This can be be actioned by a `Developer` or `Tech Lead/Risk Manager`, but more commonly this will be the former.

- If the risk is something that cannot be exploited by a bad actor (e.g. does not impact production code), then mark the risk as `Proposed Not Exploitable`, along with a comment to support.

**Mark as 'Not Exploitable'**

This can be only be actioned by a `Tech Lead/Risk Manager`.

- If the developer's proposal is valid, then mark the risk as `Not Exploitable`.
- If not, bounce back with comment for the developer to fix.

## Useful Links

- [Aviva Checkmarx](https://avivaplc.cxone.cloud/)
- [ADO Gates](https://dev.azure.com/avdigitalweb/DigitalNextGen/_build?definitionScope=%5CGates)
