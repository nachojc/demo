<!--

## <New section Template>

> ❌ **Error**: `<Error message>`
![Screenshot of the error if applicable](./.images/<...>.png)

> ✅ **Solution**

> **Reference**
> # Link to follow up reading material
> []()

> ℹ️ **NOTE**
-->

# Overview

<!--toc:start-->

- [Git](#git-errors)
- [Node Runtime](#node-runtime-errors)
- [Android Compilation](#android-compilation-errors)
- [iOS Compilation](#ios-compilation-errors)
<!--toc:end-->

## Git Errors

> ❌ **Error**: `git: fatal - unable to update url base from redirection`
>
> ![Git fatal error - unable to update url base from redirection](./.images/git-redirect.png)

> ✅ **Solution** If you spot errors with Git relating to some form of redirection, the fix is to visit a page in your browser to renew the session within WSS ([like this one](https://jira.aviva.co.uk/secure/Dashboard.jspa)).

## Node Runtime Errors

> ❌ **Error**: `engine node is incompatible with this module`
>
> ![Node Engine is incompatible with this module](./.images/incompatible-node-version.png)

This one is pretty simple to validate, you should see that the number output doesn't sit within the range specified in the error message output above:

```shell
  $ node -v

  # Outputs: 19.8.1
```

> ✅ **Solution** This happens because your node version is not within a supported range, and as such you will fix this with NVM (Node Version Manager)

You can test out different versions for lifetime of your terminal session with:

```shell
  $ nvm use <correct-version>
```

> NOTE: at the time of writing `<correct-version>` would be 18.12.1, check with your colleagues if you need to update

Once you have found a version that works, you can set it in permanently for future terminal sessions run:

```shell
  $ nvm alias default <correct-version>
```

> **Reference**
>
> [NVM - Node Version Manager](https://github.com/nvm-sh/nvm)

## Android Issues

...

### Compilation Errors

...

## iOS Issues

### Compilation Errors

> ❌ **Error**: `ios/<appname>/AppDelegate.mm - File not found`
>
> ![App Delegate, file not found error](./.images/ims-file-not-found.png)

If you spot native compilation errors relating to, then there is likely an issue with your copy of the submodules:

- FusionCharts
- IMS
- MyDrive
- Geocoder
- CampaignClassic

Run the following command to ensure all submodules registered base repo are installed and up to date for the given `<commitish>` you are on:

> ✅ **Solution**

```shell
  $ git submodule update --recursive --init

  # You should see output akin to the following
  kieranosgood@LT082902 manga-9193-package-documentation % git submodule update --init --recursive

  Cloning into '/DigitalNextGen.git/maintenance/manga-9193-package-documentation/packages/mydrive-test-harness'...
  Cloning into '/DigitalNextGen.git/maintenance/manga-9193-package-documentation/packages/react-native-fusioncharts'...
  Cloning into '/DigitalNextGen.git/maintenance/manga-9193-package-documentation/packages/react-native-geocoder'...
  Cloning into '/DigitalNextGen.git/maintenance/manga-9193-package-documentation/packages/rn-bridge-campaignclassic'...
  Cloning into '/DigitalNextGen.git/maintenance/manga-9193-package-documentation/packages/rn-bridge-ims'...
  Cloning into '/DigitalNextGen.git/maintenance/manga-9193-package-documentation/packages/rn-bridge-nuance'...
  Cloning into '/DigitalNextGen.git/maintenance/manga-9193-package-documentation/products/rn-direct-wealth'...

  Submodule path 'packages/mydrive-test-harness': checked out '53b3a0303fa096978d36204833455aff5fa66cda'
  Submodule path 'packages/react-native-fusioncharts': checked out 'e642f864438f23466d65ccf63938ac54feb3e566'
  Submodule path 'packages/react-native-geocoder': checked out 'f9709aa20efbf6d746bdc9cd0beced91ea5af88a'
  Submodule path 'packages/rn-bridge-campaignclassic': checked out '8d49355cfd1893d4a3cb3832ffe806b961140c19'
  Submodule path 'packages/rn-bridge-ims': checked out 'c29cee847bbf9c5a2ebbd3e07a50a647784c04f5'
  Submodule path 'packages/rn-bridge-nuance': checked out 'd2f4f03e963383ec997a2564e3f7625af2f5a086'
  Submodule path 'products/rn-direct-wealth': checked out 'c7c7e204b6aae438c9be1ce05137073117baecd6'
```

> **Reference**
>
> [Git - Submodules](https://git-scm.com/book/en/v2/Git-Tools-Submodules)

---

### Simulator

> ❌ **Error**:
>
> ```sh
> No iPhone devices available in Simulator.
> Error: xcrun exited with non-zero code: 60
> An error was encountered processing the command (domain=NSPOSIXErrorDomain, code=60):
> Unable to boot the Simulator.
> launchd failed to respond.
> Underlying error (domain=com.apple.SimLaunchHostService.RequestError, code=4):
>       Failed to start launchd_sim: could not bind to session, launchd_sim may have crashed or quit responding
> ```

> ✅ **Solution**
> Ensure you have run mac updates - you may need to reboot your mac a few times to see the prompt

> **Reference**
>
> [Git - Submodules](https://git-scm.com/book/en/v2/Git-Tools-Submodules)
