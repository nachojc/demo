# Overview

Documentation on the packages we rely on, including specifics of (where appropriate) support channels and stakeholder contact details.

## License Owners

Contact details for stakeholders with links to generate new license keys or investigate account level issues.

- FusionCharts
- Onfido
- Nuance
- Adobe

## Migration investigations

- FusionCharts
  - The charting solution FusionCharts provides is not native, and is simply a webview making it very difficult to customise or get performant (the slowest frames to render in a performance run indicated issues with FusionCharts)
- PDF Viewer
  - Discussion of limitations on its ability to provide accessibility on Android
- Tamagui
  - Replace with Restyle - avoid excessive upgrade rate
