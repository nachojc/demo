# Overview

- [Overview](#overview)
  - [Package Managers](#package-managers)
  - [Checking for updates](#checking-for-updates)
  - [Updating libraries](#updating-libraries)
    - [Patch files](#patch-files)
      - [Git Patch Example](#git-patch-example)
      - [Copy Paste Example](#copy-paste-example)
    - [Testing](#testing)
  - [Expo Upgrade - Overview](#expo-upgrade-overview)
    - [Expo Upgrade - Helpful Tips](#expo-upgrade-helpful-tips)
  - [Troubleshooting](#troubleshooting)
    - [Miscellanous](#miscellanous)
    - [Dependency resolution `cannot find version X`](#dependency-resolution-cannot-find-version-x)
    - [Update artifactory access](#update-artifactory-access)
    - [Pods](#pods)

We are reliant on a number of packages to handle functionality we don't wish to take responsibility for maintaining.

When looking at our dependencies you can categorise them into two groups:

- `Pure JS/TS` - these packages are may only consist of `JS`/`TS`, which are suitable for browser/Node environments
- `Native Packages` - More specialised `react-native` packages will include Native Code (Objective-C/Swift on iOS, Java/Kotlin on Android, or C++ if using TurboModules) - these allow us to connect with the Operating Systems API's / hardware through a common Typescript interface.

The steps to correctly install and update these two groups will be more complex on Native Packages due to the backing systems for these differing.

## Package Managers

- **Node**

  `yarn` is used for installing and managing our node dependencies, by proxy depending on whether the dependency is for react-native or not, it may bring in additional Android/iOS dependencies too, the installation of the sub-dependencies of these are in turn managed by their own respective package managers.

  Running `yarn` / `yarn install` will update the `yarn.lock` file to register the version of the dependency installed.

- **Android**

  `gradle` is used for installing and managing Android dependencies, though `yarn` will also include more for us.

  We do not use public gradle repositories such as jcenter or maven, instead we re-write the paths to route all of these via artifactory, as such you'll need to make sure you have [updated your artifactory JWT](#Update-artifactory-access).

- **iOS**

  `Pod` is used for installing and managing iOS dependencies, though `yarn` will also include more podspecs for us `Pods` will dictate the version.

  When adding or updating packages you will also need to update the `patches/Podfile.lock` which acts the same as the `yarn.lock` in ensuring each build uses a common version within the permissable range of versions (minors or patches).

  Podspecs describe the location of the repository to download Pods from, similarly to Android, the podspecs are re-written to point to artifactory - as such you should ensure that you've [updated your artifactory JWT](#Update-artifactory-access).

> **Reference**
>
> - [Yarn](https://yarnpkg.com/)
> - [Pod](https://guides.cocoapods.org/)
> - [Gradle](https://gradle.org/)

## Checking for updates

Whilst we use `yarn` as our package manager, there is a few ways to check for and update packages to be aware of.

- **Expo Install** - `npx expo install --check`
- **Expo Doctor** - `npx expo-doctor`
- **Yarn Upgrade-Interactive** - `yarn upgrade-interactive`

> ℹ️ **NOTE** Each of these commands rely on access to remote repos to check for updates, which currently fails to connect due to the proxy.
>
> You may need to prefix the command with `NODE_TLS_REJECT_UNAUTHORIZED=0`, or `export NODE_TLS_REJECT_UNAUTHORIZED=0` to set it for the terminal session.
> run
> If you wish to run through updating multiple packages/observe what updates are available or recommended, adhere to the following order:

1. Start with **Expo Install**, this will check that the versions of each expo package is in the supported range of the expo SDK installed. This is the most useful first port of call for pointing out issues with versions
2. Then **Expo Doctor** Can assist in diagnosing issues with the project from the setup, configuration and cohesion of packages.
3. Finally **Yarn Upgrade Interactive** will allow you to analyse any dependencies that register upgrades on the remote, skip over any modules with expo in the name (these will have been checked in the previous steps).

> **Reference**
>
> - [Yarn - Upgrade Interactive](https://yarnpkg.com/)
> - [Expo - Cli](https://docs.expo.dev/more/expo-cli/)
> - [Expo - Doctor](https://www.npmjs.com/package/expo-doctor)

## Updating libraries

It's been mentioned in the preceeding sections a few times, but when updating you'll need to be aware of whether its a native or JS only package you're updating. The reason is that native dependencies may have additional steps that you need to perform in order to completely install, these steps may change between versions.

You should inspect the installation steps in the packages `README.md` in order to understand what is required, and compare against previous versions if you're having build issues.

We aim to adhere to the `Config Plugin` architecture, where (ideally idempotent) JS code mods allow us to modify the native directories (`/ios` / `/android`) programmatically.

> **Reference**
>
> - [Config Plugins](https://docs.expo.dev/config-plugins/introduction)

### Patch files

If you're updating a package that has native code changes, you may find that there is a need to update files in the `/patches` directory, due to a legacy approach to updating the native directories, or places where the [Config Plugin](https://docs.expo.dev/config-plugins/introduction) approach was too restrictive.

When making updates to packages its recommended to take a look at the patches directory to understand what patches exist, if you've updated a native dependency you will need to update the `/patches/Podfile.lock` for instance so that we share the same lock file across teams.

If you need to re-create a patch, you will need to check first whether it was a git patch or a full copy and paste of the file:

#### Git Patch Example

Taking an example of the `Podfile`, this is updated via a git patch, so to recreate the patch files you can run:

```shell
 $ git diff --no-index ios/Podfile.orig ios/Podfile > patches/Podfile.patch
```

Testing this you will want to locate the patch script in the `package.json` to execute this, currently for the podfile this looks something like the following:

```json
// package.json - script correct at time of writing
{
...
    "expo:prebuild:52-podfile-patch-adding-pods": "patch -li patches/Podfile.patch ios/Podfile",
...
}
```

Running `yarn expo:prebuild:52-podfile-patch-adding-pods` you can check to see if it applies as you expect.

#### Copy Paste Example

This one is a bit more straight forwards, taking the example of the `AndroidManifest.xml` you will notice we have multiple versions listed based on the app we're building:

- `patches/AndroidManifest.xml`
- `patches/AndroidManifest.xml.debug`
- `patches/AndroidManifest.xml.dw`
- `patches/AndroidManifest.xml.dw.prod`
- `patches/AndroidManifest.xml.pipe`

As such, imagine you need to add another intent, you would need to apply the changes to each of these files, you may not want to do a **full** copy and paste due to overriding other changes, check the diff and ensure you haven't updated something unintentionally.

#### Node Patching

If you wish to patch a file within the `node_modules/` directory the workflow is more straight-forwards, you can utilise `patch-package`.
It runs a `post install` hook (this is already setup), which means after running `yarn` or `yarn add` it applies a git diff patch to the modules, this results in it automatically applying, and doesn't require us to write scripts in the package.json to apply them.
The process for creating these is best described in their ReadMe.
When you bump a package that previously had a patch, it may fail in future if the changes aren't resolvable automatically by git, in this case you will need to re-create and replace the patch with a new one for the appropriate version, you will see a warning about applying patches to versions that don't match what was expected.

> **Reference**
>
> - [Patch Package](https://www.npmjs.com/package/patch-package)

### Testing

Whenever updating dependencies, there is a large possibility that there is going to be some regressions, even when libraries are updated via a patch because semver is open to human error.

We should act cautiously around these upgrades and ensure that there is a clear understanding of the affected domains and what the potential blast radius is for an upgrade.

Engaging with automation and QA to understand where we can be certain 'things still work' will be key to successful upgrades.

It is recommended that you run the optional gates on your PR to start off an iOS and Android build.

## Expo Upgrade - Overview

Upgrading the Expo SDK version is a major activity in the development lifecycle.

Expo releases at a six-monthly cadence, and this should be scheduled in within the same cadence in order to maintain pace with supporting new OS updates for Apple & Android.

> **Reference**
>
> - [Upgrading Expo SDK Walkthrough](https://docs.expo.dev/workflow/upgrading-expo-sdk-walkthrough/)

### Expo Upgrade - Helpful Tips

It is recommended to go one major version at a time, i.e. `48 → 49`.

---

Expo install doctor can help upgrade all expo packages.

> **Reference**
>
> - [Checking for updates](#Checking-for-updates)

---

The `/patches` directory contains a number of manual/static patches that apply to the project, including `node_modules` / `ios` / `android` files. You will need to assess whether all are required/continue to work after the updates to packages.

Where possible reducing the dependency on `/patches`, refactoring to use [Config Plugins](https://docs.expo.dev/config-plugins/introduction/) should be preferred.

---

The blog post for each SDK version will include relevant upgrade info:

| Deprecations                                                                         |                     Regressions                     |
| ------------------------------------------------------------------------------------ | :-------------------------------------------------: |
| ![Deprecations, renamings and removals](.images/deprecations-renamings-removals.png) | ![Known Regressions](.images/known-regressions.png) |

---

If you are struggling to upgrade, you can see what changed between major versions of react native

> **Reference**
>
> - [React Native - Upgrade Helper](https://react-native-community.github.io/upgrade-helper)

---

Refer to the react native docs for general upgrade process, their upgrade cli won't assist in expo, but the process is documented.

> **Reference**
>
> - [React Native - Upgrading](https://reactnative.dev/docs/upgrading)

## Troubleshooting

This is a log of some more common errors involved with dependencies from the project.

### Miscellanous

It is a useful point to understand there is a convention that modules containing native code **typically** contain, or are prefixed with, either `expo-` or `react-native-`.

Use this as an indication (not an absolute rule) as to what kind of package this is when you run through the steps detailed below, when in doubt open the packages source files to confirm (check for iOS/Android directories etc.).

Due to the mixed nature of the dependencies we require, the process of updating packages will differ slightly depending on _what_ you're updating, and you'll need to be aware of these facts to ensure you provide the correct changes.

### Dependency resolution `cannot find version X`

> ❌ **Error**:
> If you're debugging issues where incorrect versions are being picked up during `pod install` or `yarn android`, you might want to investigate the `yarn.lock` for duplicates.

This has been an occasional issue where a package lists a dependency on another package (e.g. react-native-webview), and we're installing a specific version, meaning it checks out multiple versions.

When performing updates, it is recommended to check that there is not multiple versions listed in `yarn.lock`, it's important to de-dupe any packages with native dependencies as they will cause build issues more often than not.

An example below shows an instance of when we had a build error due to `expo-sharing` being duplicated. This is usually not necessarily an issue in Node environments, however if the dependency is one with native code, or core such as expo, react-native etc. then this can lead to significant build errors down the line due to the fact that when Pods attempts to install it then it will cause exceptions in the download process.

![Expo Sharing Duplicate](.images/expo-sharing-duplicate.png)

> ✅ **Solution**

To fix this you can see what is dependent on this package in the `yarn.lock`, and see what versions it requires. Updating the packages requiring it may assist in bringing them up to date (e.g. when updating react-native you'll want a package that supports the version you have).

As a last resort you can utilise node resolutions to pin a specific version, this may have unintended side effects.

> **Reference**
>
> - [Yarn Resolutions](https://classic.yarnpkg.com/lang/en/docs/selective-version-resolutions/)
> - [Resolutions RFC](https://github.com/yarnpkg/rfcs/blob/master/implemented/0000-selective-versions-resolutions.md)

### Update artifactory access

> ❌ **Error**: `installing pod, 401 HTTP response` / `gradle: cannot find version x`
>
> If you have problems running a pod install, or an android build, you may wish to update your token for artifactory.

> ✅ **Solution** Run the following script, you will be prompted for your credentials.

```shell
  $ afscript
```

The reason for this is that you have to be authenticated to access Artifactory (where we store our dependencies), this doesn't last forever and needs to be renewed every so often.

If this was successful you should see the line `Logged into Artifactory...` - you are now okay to re-run your build.

> ⚠️ **Warning** If you enter your password wrong or are locked out it will result in the following error during the afscript: `Artifactory login failed. There are 3 possibilities: a) you typed your password wrong, b) your account is locked or c) you don't have access to Artifactory (you'll need to raise an ITSS request for this). You can log directly into https://binaries.avivagroup.com to check.` You will need to rerun the script or follow the next steps if you're certain you've entered your credentials correctly.

If you still cannot access these files, you can check whether you are locked out from artifactory by visiting this link [Artifactory - Login](https://binaries.avivagroup.com/ui/login/) and attempting to sign in with your usual credentials. If you cannot login you may be locked, contact the `Mac Lockout Channel`.

### Pods

> ❌ **Error**: `Error Installing <SDK> (SDK_Version)` / `curl: (5) Could not resolve`

> ✅ **Solution**
> If you see an error similar to the above, ensure that the url being curled points to artifactory, in the example below you'll notice that `amazonaws` is the domain being connected to.
>
> This indicates an error with your podspecs, removing and re-running afscript should aid in this, but raise it to Solar if this should happen.

```shell
  Installing Qualtrics (2.19.0)

  [!] Error installing Qualtrics
  [!] /usr/bin/curl -f -L -o /var/folders/v0/pgk0q8z14r7_ytm677ttrs580000gp/T/d20240411-2883-1qvcvuk/file.zip https://s3-us-west-2.amazonaws.com/si-mobile-sdks/ios/2.19.0/Qualtrics.zip --create-dirs --netrc-optional --retry 2 -A 'CocoaPods/1.12.1 cocoapods-downloader/1.6.3' --user a202466:<token> --ssl-no-revoke

    % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current Dload  Upload   Total   Spent    Left  Speed

    0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0
    curl: (5) Could not resolve proxy: http
  Warning: Problem : timeout. Will retry in 1 seconds. 2 retries left.

    0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0
    curl: (5) Could not resolve proxy: http
  Warning: Problem : timeout. Will retry in 2 seconds. 1 retries left.

    0     0    0     0    0     0      0      0 --:--:-- --:--:-- --:--:--     0
    curl: (5) Could not resolve proxy: http

```

---
