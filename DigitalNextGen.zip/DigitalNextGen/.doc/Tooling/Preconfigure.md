# Preconfiguring the App Using JSON

This document provides an overview of how to preconfigure the app using JSON. This includes setting feature flags and mock responses.

## How to Preconfigure

1. Navigate to `Dev Mode` -> `Preconfigure`.
2. Paste your configuration into the provided field.
3. Click `Apply`.

If the configuration is successful, a green tick will appear. If there are invalid keys in your configuration, a warning will be displayed.

## Configuration Options

All elements within the JSON configuration are optional. You can provide a list of `featureFlags` (local), `remoteFlags` (LaunchDarkly) and/or `mockResponses`. Only the keys that match the following will be set:

- Local feature flags: [`src/feature-flags/index.ts`](https://avdigitalweb.visualstudio.com/DigitalNextGen/_git/DigitalNextGen?path=%2Fsrc%2Ffeature-flags%2Findex.ts)
- Remote feature flags: [`src/remote-flags/index.ts`](https://avdigitalweb.visualstudio.com/DigitalNextGen/_git/DigitalNextGen?path=/src/remote-flags/index.ts)
- Mock Responses: [`src/api-mock/constants.ts`](https://avdigitalweb.visualstudio.com/DigitalNextGen/_git/DigitalNextGen?path=/src/api-mock/constants.ts)

## JSON Format

The JSON configuration should follow the format shown below:

- The `featureFlags` object holds all local feature flags of `boolean` type.
- The `remoteFlags` object holds all remote feature flags of `boolean`, `string`, `number` or `json` type.
- The `mockResponses` object holds all mock responses, with their key values being strings.

**Note:** For the mock responses, use the key entry instead of the file name.

```json
{
  "mockResponses": {
    "Customer": "Customermydrive eligible AOMPX1 AF003 active",
    "Policies": "Policy AOMPX1"
  },
  "featureFlags": {
    "myDriveEnabled": true,
    "myDriveUseMockData": true
  },
  "remoteFlags": {
    "release-myaviva-direct-wealth-in-manga": true
  }
}
```
