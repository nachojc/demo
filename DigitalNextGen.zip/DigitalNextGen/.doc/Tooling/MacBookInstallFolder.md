The MacBook install folder has been deprecated. Please view [Software Installation](SoftwareInstallation.md) for details on setting your machine up.
