# Debugging on Physical devices - iOS & Android

## Debugging on iOS Device

### Pre-requirements

- You need to have an Apple Developer account within Aviva's Apple Account.
- A physical device registered within Aviva's account. (Please do not register new/personal devices)
- Xcode 15 or later, logged into your apple developer account (this will give you access to Aviva's certificates)
- Laptop must be disconnected from Cisco VPN
- Test user credentials for AppCenter

> **_NOTE:_**
>
> If you don't have Apple Developer Account or a registered device please contact Sam Bailey, Craig Walker, Ross Gilbert, Matt Ball or Daniel Hayes.

### Local Debug Build

1. Plug the physical device using a usb cable.
2. Open `ios/myaviva.xcworkspace` on Xcode (if you can't find it run `yarn nuke`)
3. Ensure on `Signing & Capabilities` that the `Team` selected is `Aviva PLC`
4. Open a terminal and run `yarn start` to initialiase the metro bundler.
5. Open another terminal and run `ifconfig | grep 'inet '` this should show something like this:

```sh
DigitalNextGen % ifconfig | grep 'inet '
	inet 127.0.0.1 netmask 0xff000000  #localhost
	inet 192.168.0.232 netmask 0xffffff00 broadcast 192.168.0.255 #usually wi-fi -> used by default by metro bundler
	inet 10.4.0.102 --> 10.4.0.102 netmask 0xffffffff
	inet 10.240.102.168 --> 10.240.102.168 netmask 0xffffc000
	inet 169.254.229.56 netmask 0xffff0000 broadcast 169.254.255.255 # your physical device usb connection. This ip address will change every time you unplug and plug your device.
```

6. Select the device and run the build.
7. At this point, after the build was installed on the device, you should see an Expo screen with the title `Development servers`. Press `Enter URL manually` and on the input box type `http://169.254.xx.xx:8081` take this ip address for step 5 and the port number `8081` is the port used by metro bundler and connect.
8. Wait for metro bundler to load the app.

**Note:** You might get an error that says The internet connection appears to be offline. Please check your connection and try again . To solved this make sure the app can find and connect devices on your network.

### AppCenter build

1. Open the app center link in browser https://appcenter.ms/apps
2. Login with the test user (use Microsoft Login) and select the specific build and click the download option
3. Go to Settings > Profile > Trust EnterpriseApp
4. Launch app

## Debugging on Android device

### Pre-Requirements

- Device has `Developer mode` enabled
- `Settings > Developer options > USB debugging` enabled
- `Settings > Developer options > Verify apps over USB` disabled
- `Settings > Developer options > Verify bytecode of debuggable apps` disabled
- Test user credentials for AppCenter

### Local Debug Build

1. Plug device to the laptop using a usb cable. (should promt Allow USB debugging? fingerprint...., press OK)
2. Open a terminal on the root of the project and run `yarn android:run:physical` **NOTE** it could take several minutes to build and install the debug build, be patient.
3. At this point, after the build was installed on the device, you should see an Expo screen with the title `Development servers`. Press `Enter URL manually` and on the input box type `http://localhost:8081` and connect.
4. Wait for metro bundler to load the app.

### AppCenter build

1. Open the app center link in browser https://appcenter.ms/apps
2. Login with the test user (use Microsoft Login) and select the specific build and click the download option
3. Launch app
