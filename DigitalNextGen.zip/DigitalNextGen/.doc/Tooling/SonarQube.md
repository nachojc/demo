# SonarQube

SonarQube is used to report on our code quality. This includes info such as code quality issues, code coverage and code duplication.

## VSCode Extension

```
Please note, the use of the VSCode extension is not currently working for developers until AD groups issues have been resolved. This will be removed once resolved.
```

### Access

To access Sonar and the VSCode extension, you will need to ensure you have requested the correct access, as described [here](https://dev.azure.com/avdigitalweb/DigitalNextGen/_wiki/wikis/Estate%20Documentation/723/SoftwareInstallation?anchor=pre-requisites).

### Installation

To install the VSCode SonarLint extension, please see [here](https://docs.sonarsource.com/sonarlint/vs-code/team-features/connected-mode-setup/).

```
https://code-quality.avivagroup.com
// Use the above for the Server URL when requested
```

## Developer Workflow

### Local Development

When making changes on your local branch, you should use the SonarLint VSCode extension to validate that your code does not introduce any new issues.

### Pull Requests

At present, we do not perform any Sonar scans on pull requests.

### Daily Scans

We perform daily scans for our repositories. They are located within the [Gates](https://dev.azure.com/avdigitalweb/DigitalNextGen/_build?definitionScope=%5CGates) folder here and should be named with the following naming convention: `RepoName-Sonar` (e.g. DigitalNextGen-Sonar).

### Resolving Issues

To resolve an issue that is mentioned in a Sonar report, you should consider the following steps:

_1. Review the Issue / Rule_

- You may find the issue is a false positive, or the rule is not one we should be enforcing. In this situation, propose for the rule to be removed via your tech lead or Team Solar.

_2. Resolve the Issue_

- Should the issue require fixing, then go through the standard PR process to fix the issue.

- If you consider this to be a false positive, then reach out to your tech lead so that they can close the issue manually. This option should be used sparingly.

_3. Consider Prevention Measures_

- We would like to prevent any issues from being re-introduced. You should consider whether a lint rule, documentation or other viable options can prevent this issue from appearing again.

## Useful Links

- [Aviva SonarQube](https://code-quality.avivagroup.com/projects)
- [ADO Gates](https://dev.azure.com/avdigitalweb/DigitalNextGen/_build?definitionScope=%5CGates)
- [SonarLint VSCode Extension Setup](https://docs.sonarsource.com/sonarlint/vs-code/team-features/connected-mode-setup/)
