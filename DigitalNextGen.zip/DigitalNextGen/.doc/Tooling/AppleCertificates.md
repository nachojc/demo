# Requesting Apple Certificates

This guide covers how to request a new certificate for deploying to iOS devices, you will need this to create ad-hoc builds for universal linking.

If this is a fresh machine, make sure you haven't requested for your certificate at all, this should be the method in which you create your cert and added to the **Profiles**.
If you are requesting a new one as yours has run out we may need to remove your old one from your machine and from the Apple admin console.

1. Make sure you have Xcode installed
1. Open Xcode and navigate to "**Preference**" -> "**Accounts**"
1. Sign in with your Apple Aviva account
1. Make sure you have "**Aviva PLC**" selected from the list
1. Navigate to "**Manage Certificates**"
1. Click the + button and add a new one under Aviva PLC
1. Let Solar Team know that you need to be added to the profiles
1. After you've been added, go back to Xcode in the same place and click "**Download Manual Profiles**"
