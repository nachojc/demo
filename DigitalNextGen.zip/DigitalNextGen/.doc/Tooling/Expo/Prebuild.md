# Overview

- [Overview](#overview)
  - [Summary / TLDR;](#summary-tldr)
  - [Glossary](#glossary)
  - [Expo Go](#expo-go)
  - [Expo Pre-build](#expo-pre-build)
    - [Expo Config Plugins](#expo-config-plugins)

As we utilise a lot of Expo's features, it can become a question why we use it, or there are questions about what terms it introduces mean such as `prebuild` or `config plugins`, below we give an explanation as to what we use them for.

## Summary / TLDR;

We use Expo Prebuild for our application, Expo Go is **not** in use.
See distinctions below.

> <span style="color:orange">⚠️ Warning</span>
> Do not manually edit the Native Code directories - they are automatically generated

## Glossary

- "Native code" → Code contained within the `ios`/`android` directories
- "Code Mods" → Scripts that modify the contents of a source code file programmatically.

## Expo Go

Expo Go is a small facet of Expo's services, most commonly known for the QR code scanner to load the app over network, and provides a 'fully managed service' around the native application code.

You start by installing the Expo Go application on your device (simulator or physical device) and when you want to run your app in development all that needs to happen is load in the Javascript code to the device, meaning you only wait for the Javascript to bundle because the native code is already built in the Expo Go app (leading to faster startup times when you launch, less dependencies to manage etc.)

At the start we operated within the confines of the Expo Go application due to some of the restrictions around the network access.
This also meant that the only dependencies we needed to request adding to the project were Javascript based (not native Native Code code) meaning less complexity in the initial phase.

## Expo Pre-build

Expo Pre-build is something that comes into play when you need to install dependencies that don't have support within the Expo Go application (i.e. officially supported packages).

We are currently at the point where we wish to install the external SDK's so we need access to the native code, which means we need to generate this, going forwards this will be the approach the codebase will be configured for.

At the point we generate native code, we no longer utilise the Expo Go application meaning you won't need to load the Exponent app onto the emulator/simulator, but otherwise not a lot changes for developers except the scripts that are run, but this does mean that within the repo there will be Native Code directories.

Note: this isn't usually committed to source control as they are generated files, they will temporarily because we still don't have network access - You won't need to run prebuild whilst we have the ios/android code committed, as Frank will perform this.

> <span style="color:orange">⚠️ Warning</span>
> Do not manually edit the Native Code directories - they are automatically generated

> **Reference**
>
> - [Prebuild Benefits](https://docs.expo.dev/workflow/prebuild/#pitch)

### Expo Config Plugins

If you hear the term (expo) config plugin, this is something that comes with working in the Pre-Build flow within Expo's ecosystem.

In this flow, Expo manages generating the Native Code, meaning when you add (or remove) an npm module, you shouldn't ideally need to make any native changes as you used to, this all relies on the config plugin architecture.

Config plugins are simply code-mods (scripts that modify the text files that make up your native directories code), which run whenever you run `expo prebuild`.

The steps in prebuild can 'roughly' be broken down into

- `rm -rf ios android` - (if running force mode, else it will prompt you to do this)
- `unzip node_modules/expo-template-bare-minimum` - (this creates the base files of ios/android)
- run modifications based on `app.config.ts` - e.g. set appName or add permissions we statically declare
- run modifications of config plugins <-- This is what installs our npm packages

[@appdynamics/react-native-agent](https://www.npmjs.com/package/@appdynamics/react-native-agent) is an example of a package that requires installation of android permissions such as: `ACCESS_NETWORK_STATE` which can safely be implemented via config plugins, as soon as we remove the package from our package.json the config plugin will no longer be run which means we remove permissions and packages that we don't need as we go.

> **Reference**
>
> - [Expo Config Plugins](https://docs.expo.dev/config-plugins/introduction/)
