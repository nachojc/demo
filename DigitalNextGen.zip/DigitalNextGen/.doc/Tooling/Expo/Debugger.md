To run the debugger (including breakpoints) against the app please do the following;

1. Run the app
1. In the terminal, press `j`
1. In VS Code (where the app is running), add the line `debugger;` to any point you want the debugger to pause
1. Run the app to your line and it'll pause + open that file in the DevTools. From this point **you can add breakpoints within the DevTools that will work**, you can find more info [here](https://docs.expo.dev/debugging/tools/#debugging-with-chrome-devtools)
1. Make sure to change the code within VSCode, **not** the debugger, this is so changes are bundled!
1. Do not open the debugger **twice**, strange things will happen!

Happy hacking!
