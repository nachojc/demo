## Release Model

We aim to move towards a feature and release isolation branching strategy.

## During app development

- Teams implement `features` and `bugfix` fixes on `develop` with alpha builds produced daily or ad-hoc when required.
- When the team is ready to release a `release` branch is created from `develop`.
- To allow normal development work to continue the current alpha version of the app is incremented and the beta version is set to the version to be released.
- The team stabilizes the `release` with `bugfix` fixes, beta builds are produced on every merge into the `release` branch.
- Each defect/change merged into `release` also has to be merged into `develop` either by a Cherry Pick (within ADO) or manually if needed.
- Once a release has made it into live then the `release` branch is locked and **cannot be pushed or merged into**.

Please see [the branch naming standards](../Engineering/Git/NamingConventions.md) for more information.

**Please note that `main` = `develop`, ADO doesn't support changing it.**

::: mermaid
gitGraph
commit
commit
commit tag: "dw-v7.2.x"
branch release/dw/v7.2
checkout release/dw/v7.2
commit
checkout main
commit
checkout release/dw/v7.2
commit
checkout main
commit tag: "dw-v7.2.x"
commit
checkout release/dw/v7.2
commit tag: "dw-v7.2.x"
checkout main
merge release/dw/v7.2
checkout release/dw/v7.2
commit type: HIGHLIGHT
checkout main
commit tag: "dw-v7.3.x"
commit tag: "dw-v7.3.x"
:::

### Release naming

Release branches should be made with the following structure:

    release/[app]/v[version]

Where `version` represents the major and minor. E.g.

    release/dw/v7.2

For multiple app releases at the same time we can combine the app name e.g.

    release/[app1]-[app2]/v[version]-v[version]

Where `app1` and `app2` are the app names, such as `dw` (Direct Wealth aka. Aviva Wealth) and `ma` (MyAviva) and the versions follow the same structure as above. E.g.

    release/dw-ma/v7.2-v8.1

### Release build process:

- Create a release branch as described previously
- When a release branch has been made we then generate a build from the `[App]-Regression` pipelines. Such as `MyAviva-Regression`. Optional nightly builds can be added to the pipelines if required.
- Any defects are branched from the `release` and merged back in. If needed, a build can be generated from the `Dev` pipeline pointing to the `bugfix` branch to be tested before being merged into `release`, otherwise the `[App]-Regression` pipeline will be needed to generate builds for testers.
- Any defects also have to be cherry picked into `develop` once merged into `release`
- The build numbers on the release branch must be updated/incremented, including the Android and iOS build numbers. These are found in the `[app]-variables`, such as `myaviva-variables`.
  - You will need to bump both the `alphaVersionNumber` and the `betaVersionNumber`. Likely only the minor, e.g. 7.5 to 7.6. Also, this may include things like updates to feature flags found within `resources/[app]/feature-flags.json`.
- When agreed, generate a release build from the `[app]-Prod` pipeline. This will produce appropriate build within BrowserStack. From here, automatic upload to the relevant stores is possible with manual intervention by certain individuals.

### Example Release

This example shows how a developer would create the relevant branch and then assist with release builds.

1.  To create a release branch:

        git checkout develop
        git reset --hard
        git pull
        git checkout -b release/[app]/v[version]
        git push

2.  Next a pull request needs to be made to update the version flags (and possibly the feature flags if required):

        git checkout release/[app]/v[version]
        git pull
        git checkout -b maintenance/MANGA-XXXX-update-versions

    Then add your changes and commit/push to the branch. This will then need merging into the release branch by creating a PR.

3.  Once merged, create a build from the `[App]-Regression` pipeline and provide the build number to the test team.
4.  When a defect is found:

        git checkout release/[app]/v[version]
        git pull
        git checkout -b bugfix/MANGA-XXXX-human-readable-bit

    Then add your changes and commit/push to the branch. This will then need merging into the release branch by creating a PR.

5.  Once all testing is complete, create a beta build from the release pipeline `[App]-Prod`.
6.  Once this is complete, test this build output in BrowserStack (in the Prod bucket) just to be sure.
7.  Ensure the Solar team are aware of the release if they aren't already and that they will need to support with the last step.
8.  If all is well, this can then be uploaded to the store. Within the build the `Deploy iOS` and `Deploy Android` tasks will need to be run, this can only be done by someone who has the right permissions within Solar.
