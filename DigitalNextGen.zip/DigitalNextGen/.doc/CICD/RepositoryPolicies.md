# Repository Policies

The following should apply for main/release branches across all repositories, unless stated otherwise:

## Branch Policies

- **Require a minimum number of reviewers:** Enabled
- **Minimum number of reviewers**: 2
- **Allow requestors to approve their own changes:** Disabled
- **Allow completion even if some reviewers vote to wait or reject**: Disable
- **When new changes are pushed:** Reset all approval votes(does not reset votes to reject or wait)
- **Check for linked work items**: Disabled
- **Check for comment resolution:** Enabled (Required)
- **Limit merge types**: Squash merge only

## Build Validation

You can find out more about build validation / gate pipelines [here](https://dev.azure.com/avdigitalweb/_git/DigitalNextGen?path=/.doc/CICD/Pipelines.md&_a=preview&anchor=pr-gates-and-build-validation).

## Status Checks

We do not use Status Checks for any repositories / branches as it stands.

## Automatically included reviewers

### Main Branch

For main branches, the `NextGen Approvers` group is a required approver for all repositories. This permission group can be found [here](https://dev.azure.com/avdigitalweb/DigitalNextGen/_settings/permissions?subjectDescriptor=vssgp.Uy0xLTktMTU1MTM3NDI0NS03MDk1ODM5OTEtOTE4Mzg3OTgtMjQxNTE1MjI1Mi03OTE3OTkyNDEtMS0zNjczODk0MjE0LTI5NDkwMTgxNzktMjQ3MDA0MDg2NC0yNzk2NzM2NzE0) - _access may be limited depending on your access rights_.

### Release Branch

For release branches (_`DigitalNextGen` only_), the policies remain the same as main. The only addition is that the `MANGA Release Branch Guardians` group is a required approver for pull requests that are merged into a release branch. This permission group can be found [here](https://dev.azure.com/avdigitalweb/DigitalNextGen/_settings/permissions?subjectDescriptor=vssgp.Uy0xLTktMTU1MTM3NDI0NS03MDk1ODM5OTEtOTE4Mzg3OTgtMjQxNTE1MjI1Mi03OTE3OTkyNDEtMS0yMjYzODg1NjUzLTM0ODc5Njc0My0yMzg0NjkzMjg2LTE0MzgyNzM4MDc) - _access may be limited depending on your access rights_.
