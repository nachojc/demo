# Pipelines

## Structure

Pipelines are primarily divided by application. Each application, such as `App A`, has four associated pipelines for daily development and release output. These pipelines include:

- `Dev`: This pipeline is used daily to produce development builds for testing. It can be built from any branch, such as `develop` or a `feature` branch.
- `PenTest`: This pipeline is used occasionally to produce specific builds for penetration testing.
- `Prod`: This pipeline is used for each release. It utilises all the production configurations, including the `.env.prod` config.
- `Regression`: Used within the release cycle for regression testing. It utilises test configurations, including the `.end.stg` config.

You can access all pipelines at the following location: [DigitalNextGen Pipelines](https://avdigitalweb.visualstudio.com/DigitalNextGen/_build?view=folders)

## Usage

## Running Pipelines

To run a pipeline, follow these steps:

1. Click into the pipeline/app you wish to run.
2. Press the `Run pipeline` button located in the top right corner.
3. Leave the `Environment configuration` and `Entitlements` options as default, unless a specific build is required.
4. Hit `Run`, bottom right.
5. Make note of the build number provided on the next screen.

This will initiate the pipeline and perform the necessary tasks based on the selected options.

### Creating Builds

To generate specific builds for different situations, follow these steps:

Please note that the AppCenter bucket names `[App]` translate to;

- MyAviva = MANGA
- DirectWealth = DW

#### Development build from `develop` branch

- Run the `[App]-Dev` pipeline, replacing `App` with the name of your application (e.g. `MyAviva`).
- This will upload a build to the `[App]-iOS` and `[App]-Android` AppCenter buckets.

#### Development build from `feature` branch

- Run the `[App]-Dev` pipeline, replacing `App` with the name of your application (e.g. `MyAviva`).
- This will upload a build to the `[App]-iOS-Feature` and `[App]-Android-Feature` AppCenter buckets.

#### Development build from any branch with specific Ad-Hoc configurations for iOS (used for tasks like push testing)

- Run the `[App]-Dev` pipeline, ensuring that you check the `Entitlements` checkbox.
- This iOS build will be uploaded to the `[App]-iOS-Ad-Hoc-Runway` AppCenter bucket.
- The Android build will be uploaded to the app-specific bucket for Android.

#### Development build using a specific `.env` file

- Run the `[App]-Dev` pipeline, select the specific `Environment configuration` you want to build with.
- This relates directly to the `.env` files found in `resources/[app]/env`. New `.env` files can be added if required.

#### Commissioning build

- Run the `[App]-Dev` pipeline, usually against the `release` branch.
- Select `commissioning` in the `Environment configuration` dropdown.
- If you require entitlements, the iOS build will be uploaded to the `[App]-iOS-Ad-Hoc-Runway` AppCenter bucket. If not, it will be uploaded to the `[App]-iOS` bucket.
- The Android build will be uploaded to the `[App]-Android` AppCenter bucket.

#### Regression build

- Run the `[App]-Regression` pipeline, usually against the `release` branch.
- This will upload a build to the `[App]-iOS-Regression` and `[App]-Android-Regression` AppCenter buckets.
- Dev mode will be disabled.

#### Pen-test build

- Run the `[App]-PenTest` pipeline, usually against the `release` branch.
- This will produce a pipeline-only artifact for pen testing and will not be uploaded to AppCenter.

#### Production build

- Run the `[App]-Prod` pipeline against the `release` branch.
- This will upload a build to the `[App]-iOS-Production` and `[App]-Android-Production` AppCenter buckets.
- Only a [Release Administrator](https://dev.azure.com/avdigitalweb/DigitalNextGen/_settings/permissions?subjectDescriptor=vssgp.Uy0xLTktMTU1MTM3NDI0NS0zODAxMTc4MDE5LTIzNjIyNjA1NTQtMzAxMDM2OTc3Ny01OTA1MDMyOTEtMS0zODc4Mjc3MzUyLTE2MzY0OTI4NzItMjkwOTc1MTkyNi02MzExMjk0MjI) can approve uploads to the app stores.
- These can be used for store submissions.

### Providing Test Builds

Follow the instructions above for the specific build type you need. Usually, a build for one app is sufficient as work is typically targeted to a single app.

When the build is started, the build ID will be within the URL, such as: `#20240304`. You can provide this number to testers as this will be the version for both iOS and Android. The resulting build will look something like `7.1.20240304`.

### Security Scans

- **Checkmarx**: Performs a security scan daily. See [Checkmarx](../Tooling/Checkmarx.md) documentation for more info.
- **Sonar**: Performs a security/code quality scan daily. See [Sonar](../Tooling/SonarQube.md) documentation for more info.

### PR Gates and Build Validation

PR gates are tailored to each repository, but where necessary, we will run a `Pull-Request-Gate` pipeline automatically once a PR has been published (these can also be running manually from a PR). This applies to `DigitalNextGen` and `rn-ion-mobile` repositories as it stands.

In some cases (e.g. `DigitalNextGen`), other pipelines can be optionally included in the PR to help provide additional confidence in the changes.

You can see the existing PR gates [here](https://dev.azure.com/avdigitalweb/DigitalNextGen/_build?definitionScope=%5CGates).

### Production Secrets

The production pipelines contain an additional step in which they inject specific secrets into the production `.env` file. This includes sensitive values like SDK keys. To add a new secret to this process:

- Add the specific secret to the specific app config within the `Variable group` at [Variable Groups](https://avdigitalweb.visualstudio.com/DigitalNextGen/_library?itemType=VariableGroups). For example, `MyAviva Configuration` contains specific key/values for MyAviva.
- Update the production `.env` file, found in `resources/[app]/env` with the following format `KEY_NAME="${KEY_NAME}"`.
- Export the value within `set-env.yaml`, for example `export FUSION_CHARTS_LICENCE='$(FUSION_CHARTS_LICENCE)'`. Other examples already exist.

This will then automatically be picked up within the build process and replace the value provided in the variable group.
