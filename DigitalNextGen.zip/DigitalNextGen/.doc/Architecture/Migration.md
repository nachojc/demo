# Migration

## Pre-requirements

> ❗ Read [SOLID principles](../Engineering/Standards.md) before continuing

In order to migrate current components efficiently away from MVVM to the new architecture there are few parts of the current components logic that will need to be understood, answering the following questions before migrating will help with this task:

- What's the business logic contained in the component? Is there any? Should that live in the component itself?
- Does the component have any standalone or reusable logic?
- Does the component have other smaller components that could be extracted?
- If any logic within the component can be extracted, does it make use of the React lifecycle? Could that logic be turned into a hook or alternatively could it be a helper function (e.g. for processing data, reformatting, .... )?

## Migration plan

- As a first step, start refactoring current screens/components by moving the model which is passed as a prop (Wrapping the screen component) to calling the model hook directly within the screen.
- Focusing on the model:

  1. Move everything from view model to view
  1. Break the screen down into smaller components and move functions extracted from view model to newly created components
  1. Identify any standalone and reusable logic and extract that into custom hooks or helper functions (if it doesn't need to live in a hook)

- Refactor unit tests to test new components and functions/hooks. Note that most likely all `expect` statements that you'll need should already be defined either in `view-model.test` or in `view.test`.
- Possible re-definition of some parts of the folder structure (encapsulating components parts in a feature base folder structure in order to have everything belonging to a component in the same place).
