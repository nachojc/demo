# Table of Contents

- [Table of Contents](#table-of-contents)
  - [Overview](#overview)
  - [Local Development](#local-development)
    - [Testing](#testing)
    - [URL Encoding](#url-encoding)
  - [Environments](#environments)
    - [Development](#development)
      - [Android](#android)
      - [iOS](#ios)
    - [Staging](#staging)
      - [Android](#android)
      - [iOS](#ios)
    - [Production](#production)
      - [Android](#android)
      - [iOS](#ios)
  - [Server Config](#server-config)
  - [Linking Journeys](#linking-journeys)
    - [Reset Password](#reset-password)
    - [Create Account](#create-account)

---

The scope of this documentation will go into the requirements of the MyAviva/Aviva Wealth apps requirements/implementations for Linking, see respective OS (Operating System) documentation here:

- [iOS](https://developer.apple.com/documentation/bundleresources/applinks)
- [Android](https://developer.android.com/training/app-links)

## Overview

Universal links (AppLinks) enables the unification of web and native journeys via a single URI for customers.

This is functionality provided by iOS and Android, and allows us to delegate the determination of whether the user has the native application installed, and they do then we navigate them into some journey, or as a fallback they're sent on to web via their browser instead.

This enables for example sending unique links via email for journeys, such as allowing a user to reset their password should they forget it.

Due to the deep integration with the OS there is a number of requirements of configuration within both the app and server, whilst local development has some not so typical steps to follow in order to get a build configured with them, these will be documented in the below sections to enable you to send builds and test locally.

---

The integration starts from the point of installation, where the platforms OS will handle verification of the domains registered within the application.

::: mermaid
sequenceDiagram
autonumber
participant User
participant Phone
participant RWY

User ->> Phone: Installs app
Phone ->> RWY: OS requests assetlinks.json/apple-app-site-association
Note over Phone,RWY: Verification only happens at install time<br/>Detected by AndroidManifest/Entitlements file

RWY -->> Phone: Returns platform file

Phone ->> Phone: App install Complete<br> verified domains updated in settings
:::

## Local Development

In order to run locally you'll need to create a special kind of build, this is so that the native files in the iOS/Android directories will exist

1. `TARGET_ENV=staging yarn prebuild` - this will adjust the output files of the prebuild command, and is configured within the `app.config.ts`.

   This includes the `/ios/<appname>.entitlements` and `/android/app/src/main/AndroidManifest.xml` - you should note that there will be a list including _some_ of the below domains.

   ```xml
   <data android:host="www.direct.aviva.co.uk"/>
   <data android:host="www.direct.dev-aviva.co.uk"/>
   <data android:host="www.direct.pre-aviva.co.uk"/>
   <data android:host="www.direct.rwy-aviva.co.uk"/>
   <data android:host="www.direct.stg-aviva.co.uk"/>
   <data android:host="www.direct1.rwy-aviva.co.uk"/>
   <data android:host="www.direct2.rwy-aviva.co.uk"/>
   <data android:host="www.direct3.rwy-aviva.co.uk"/>
   ```

2. At this point you'll need to open xcode and set the development team - you should set it to the Aviva PLC team

   ![Xcode signing and capabilities page](.images/linking-xcode-development-team.png)

   > <span style="color:blueviolet"> **Note**</span> -
   > If you don't see the development team above, you must run through the steps in this document [requesting apple certificates](.doc/Tooling/AppleCertificates.md) to gain access to the certificate that contains the team.

3. Build and install the apps as usual

4. **Android Only:** Once the Android app is installed, you'll need to go to the settings for the app - the flow is documented in the image below, the domains you saw in the entitlements file should all be here
   ![Settings for app](.images/linking-android-enable-deep-links.png)

5. After you have done this you should be able to debug universal links locally, with one of the scripts in package.json, e.g. `yarn linking:ios:preactivation`

### Testing

In order to test that the app is correctly picking up links there are some convenience scripts in the package.json.
Run:

- iOS: `yarn linking:ios:preactivation`
<!-- - Android: `yarn linking:ios:preactivation` -->

If the app doesn't open then the build is not correctly configured for Linking.

### URL Encoding

In the convenience scripts noted in [Testing](#Testing) we have an old URL, but take notice of the format.
If you have gained access to the email inbox, or a copy of the password reset email from QA, copying the URL from the email you'll find it is email url encoded, passing this to the linking commands will cause the zod schema parsing to fail.

If you're unsure if this is the case and you're seeing missing query params errors, try running the convenience scripts and confirm if they pass, if so then there is an issue with your URL, if the app doesn't open then the build is not correctly configured for linking.

You can get the url converted by turning off VPN, click the link and it will attempt to open in your browser, as you're off the VPN it'll fail to load the page and forwards you on to the subsequent screen, so you can copy and paste the url back into the commands described in [Testing](#Testing). If you do this whilst on VPN, reset password will forwards you directly to the login screen, so its important to be off the VPN.

## Environments

In the [Local Development](#local-development) section we described the need to set `TARGET_ENV` to make prebuild generate a build that can universal link.
Below we'll describe the other types of builds available and why.

In our case we have three environments with their own configurations.

---

### Development

The default value when you run: `yarn prebuild` (locally or in the pipes) all builds going to browserstack will have this value set.

We do not set any domains for iOS due to browserstack builds not working with entitlement signed builds as they need a wildcard certificate, as such we have `development` which will always be the case for browserstack.

#### Android

```xml
      <!-- AndroidManifest.xml -->
      <data android:host="www.direct.aviva.co.uk"/>
      <data android:host="www.direct.dev-aviva.co.uk"/>
      <data android:host="www.direct.pre-aviva.co.uk"/>
      <data android:host="www.direct.rwy-aviva.co.uk"/>
      <data android:host="www.direct.stg-aviva.co.uk"/>
      <data android:host="www.direct1.rwy-aviva.co.uk"/>
      <data android:host="www.direct2.rwy-aviva.co.uk"/>
      <data android:host="www.direct3.rwy-aviva.co.uk"/>
```

#### iOS

```js
// app.config.ts
case 'development':
  return {};
```

### Staging

This is a unique build target that is only set if you enable it either via the development pipeline or locally when you prebuild (see: [Local Development](#local-development)).

If you need to provide a Universal links testing build to QA's this is the build type you'll have **NOTE: they will need to run this on physical devices as browserstack cannot accept this build type**.
In order to create a build here you can follow the documentation for creating Ad-Hoc builds here: [Pipelines - Running Pipelines](https://avdigitalweb.visualstudio.com/DigitalNextGen/_wiki/wikis/Estate%20Documentation/707/Pipelines?anchor=running-pipelines)

**NOTE** In terms of the domains that are setup, iOS and Android are **exactly the same**.

#### Android

```ts
// app.config.ts
    case 'staging':
    return {
      intentFilters: [
        // Universal links config
        {
          action: 'VIEW',
          // must be true for universal as these paths have backing json on server
          autoVerify: true,
          category: ['DEFAULT', 'BROWSABLE'],
          data: [
            { scheme: 'http' },
            { scheme: 'https' },
            { host: 'direct.dev-aviva.co.uk' },
            { host: 'direct1.rwy-aviva.co.uk' },
            { host: 'direct2.rwy-aviva.co.uk' },
            { host: 'direct.pre-aviva.co.uk' },
            { host: 'direct.stg-aviva.co.uk' },
            { host: 'direct.rwy-aviva.co.uk' },
          ],
        },
      ],
    };
```

#### iOS

```ts
  // app.config.ts
  case 'staging':
    return {
      associatedDomains: [
        'applinks:www.direct.dev-aviva.co.uk?mode=developer',
        'applinks:www.direct1.rwy-aviva.co.uk?mode=developer',
        'applinks:www.direct2.rwy-aviva.co.uk?mode=developer',
        'applinks:www.direct.pre-aviva.co.uk?mode=developer',
        'applinks:www.direct.stg-aviva.co.uk?mode=developer',
        'applinks:www.direct.rwy-aviva.co.uk?mode=developer',
      ],
      entitlements: { 'aps-environment': 'production' },
    };
```

### Production

Builds pointing at production will be configured to have (iOS: Entitled Domains, Android: Intent Filters) pointing to:

#### Android

```ts
  case 'production':
    return {
      intentFilters: [
        // Universal links config
        {
          action: 'VIEW',
          // must be true for universal as these paths have backing json on server
          autoVerify: true,
          category: ['DEFAULT', 'BROWSABLE'],
          data: [
            { scheme: 'http' },
            { scheme: 'https' },
            TARGET === 'pentest' ? { host: 'direct3.rwy-aviva.co.uk' } : { host: 'direct.aviva.co.uk' },
          ],
        },
      ],
    };
```

#### iOS

```ts
  case 'production':
    return {
      associatedDomains: [
        TARGET === 'pentest' ? 'applinks:www.direct3.rwy-aviva.co.uk?mode=developer' : 'applinks:www.direct.aviva.co.uk',
      ],
      entitlements: { 'aps-environment': 'production' },
    };
```

## Server Config

You can view the production files here, these domains are why we have to register them in the native directories:

- [Android - Assetlinks JSON](https://www.direct.aviva.co.uk/.well-known/assetlinks.json)
- [iOS - Apple App Site Association](https://www.direct.aviva.co.uk/.well-known/apple-app-site-association)

The returned file, at present, contains definitions for both DW and MANGA/MyAviva (we shared the same file for the Xamarin app, to be replaced by the MANGA app).
If you view the apple-app-site-association, you will notice that MANGA has three paths registered whilst DW has two, this is because that journey does not exist in the release performed for DW.

On Android you can test these via ADB (Android Debug Bridge, CLI tool) via the command: `adb shell pm get-app-links co.uk.aviva.myaviva`.
This will give some output similar to this that will determine whether it passed verification or not, useful if debugging issues with linking on android failing.

```
com.example.pkg:
    ID: 01234567-89ab-cdef-0123-456789abcdef
    Signatures: [***]
    Domain verification state:
      example.com: verified
      sub.example.com: legacy_failure
      example.net: verified
      example.org: 1026
```

## Linking Journeys

The below is specific documentation on the linking journeys that exists

### Reset Password

URL: `/access/preactivation.do`

Universal linking process for Reset Password. This is a route that we manually handle the linking of, see source: [linking.ts](../../src/navigation/linking.ts). This route is handled manually as we need to verify some details such as whether they require MFA or not, and navigate them to the correct screen as a result.

::: mermaid
sequenceDiagram
autonumber
participant User
participant Phone
participant App

User ->> Phone: Press password reset link in email
Phone ->> Phone: Checks if link is handled as Universal Link
Phone ->> App: App opens

alt path.includes('/access/preactivation.do')
App ->> App: Verify route parameters
alt PARSE_SUCCESS
App->>App: Push to route in Universal Link
alt mfaRequired:
App ->> App: Navigate to [FORGOTTEN_DETAILS_MFA]
else:
App ->> App: Navigate to [SET_NEW_PASSWORD]
end
App->>App: Push to route in Universal Link
else PARSE_FAILURE
alt e instanceof InvalidTokenError:
App ->> App: Navigate to [FORGOTTEN_DETAILS]
else
App ->> App: Navigate to [FORGOTTEN_DETAILS]
else
end
end
else
App ->>App: getStateFromPathDefault() - Default linking behaviour
end
:::

### Create Account

URL: MyAccount/Create/Step1
TODO...
