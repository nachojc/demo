# ❗ DEPRECATED

# MVVM

The current MVVM architecture:

- Encapsulates the logic of the component into a model which can hold a combination of states, handlers, API calls and so on.
- Passes the model as a prop into the screen component.
- Follows a similar pattern to the one adopted in the original Xamarin MyAviva mobile app

![MVVM architectural diagram](./.images/mvvm.png 'MVVM architectural diagram')

For more information on the adopted MVVM pattern please see the [Confluence doc](https://confluence.aviva.co.uk/pages/viewpage.action?pageId=1058119874)
