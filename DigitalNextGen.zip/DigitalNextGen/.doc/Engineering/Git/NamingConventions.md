# Branch Naming Convention

All branches should follow these naming conventions (using kebab-case) depending on the type of ticket :

    <type>/<project ID>-<ticket-number>-<human-readable-bit>

This consist of (do not use special characters such as `/ *` etc).

- **type**: this can be one of the following, `bugfix`, `feature`, `maintenance`, `release`, `spike`, `task`
- **project ID**: MANGA, DW etc. this will be associated with the project you're currently working on and can be found in Jira
- **ticket number**: 145
- **human-readable-bit**: "help-screen"

Resulting in

    feature/MANGA-145-help-screen

## Branch Types

Below are the types and when they should be used;

- `bugfix`: used for fixing defects/bugs found at any point. Usually merged back into develop (or the release branch if it's found as part of a regression). Can also be branched from `release` branches.
- `feature`: used for feature code, work that represents a larger feature set and may contain many `tasks`
- `maintenance`: used for other maintenance tasks such as documentation updates or pipeline changes etc.
- `release`: reserved for release branches. These branches will not be deleted and are used for regression testing and release builds
- `spike`: for investigation into a specific area - usually associated to a spike task and can contain PoC code
- `task`: a smaller amount of work usually branched off and merged back into a `feature`

## Pre-hook

PR's submitted with incorrect branch naming will be declined, so if you need to rename it you can use the following commands to rename it:

    git branch -m old-name new-name
    git push origin --delete old-name (may fail due to permissions)
    git push origin -u new-name

## Pull Request Titles

All pull request titles should be in the following format:

    <project ID>-<story/ticket number>: human readable bit please thank you

Resulting in

    MANGA-1589: human readable bit please thank you

## Branching Approach

Below is an example of each type of branch and how they should interact with each other. Tags represent builds that have been created for testing. **Please note that `main` = `develop`, ADO doesn't support changing it.**

::: mermaid
gitGraph:
commit
commit tag: "alpha v7.2.x"
branch release/dw-v7.2
checkout release/dw-v7.2
commit
checkout main
commit
checkout main
commit tag: "v7.2.x"
commit
checkout release/dw-v7.2
commit tag: "dw-v7.2.x"
checkout main
merge release/dw-v7.2
checkout release/dw-v7.2
commit type: HIGHLIGHT
checkout main
commit tag: "v7.3.x"
commit tag: "v7.3.x"
branch feature/1
checkout feature/1
commit
branch task/1
checkout task/1
commit
checkout feature/1
merge task/1
branch task/2
checkout task/2
checkout main
commit tag: "alpha v7.3.x"
checkout task/2
commit
checkout feature/1
merge task/2
commit
commit tag: "alpha v7.2.x-feature"
checkout main
commit
checkout feature/1
commit
checkout main
merge feature/1 tag: "alpha v7.3.x"
branch maintenance/thing
checkout maintenance/thing
commit
commit
checkout main
commit tag: "alpha 7.3.x"
checkout maintenance/thing
commit
checkout main
merge maintenance/thing
commit
branch spike
checkout spike
commit
commit
checkout main
commit

:::
