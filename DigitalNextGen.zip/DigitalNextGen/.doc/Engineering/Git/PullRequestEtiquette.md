# Pull Request Etiquette

This document outlines the pull request etiquette we'd like you to follow:

## Reviewers

- Each pull request requires a review from specific groups of individuals (NextGen Approvers, MANGA Release Branch Guardians, etc.).
- These are usually lead developers, of which one review is required.
- A second review is also required as a minimum, although this does not have to be from a lead.
- Ensure that the reviewers have the necessary context to understand the changes. Provide a clear and concise description of what the pull request does.

## Comments

- Keep them professional and friendly - we're all on the same team!
- If you don't understand a comment, either reply to it or ask the person directly.
- Do not resolve comments made by others. For instance, a reviewer should not resolve comments made by another reviewer.
- Usually, a comment can be marked as resolved by the reviewer or the owner of the pull request.
- But, if a comment is complex, let the reviewer resolve the comment.
- In all situations, only if you believe the issue has been addressed should you even consider resolving the issue.
- Nudge reviewers directly to re-review when you think you've completed all comments.
- If any comments are raised on a _cherry pick_ pull request, these need fixing and then another pull request made for the other branch.
- **Do not remove individuals from a pull request, especially when they've left comments or a status**. The only time this should be used is when the reviewer is unable to change their status on the PR - e.g., they've gone on holiday. In this situation please talk to a lead.

## General Good Practices

- **Write Clear Descriptions**: Provide a detailed description of what the pull request does, why the changes are necessary, and any additional context that might help reviewers such as screenshots where applicable.
- **Keep Pull Requests Small**: Smaller pull requests are easier to review and less likely to introduce bugs. Try to limit the scope of each pull request to a single feature or bug fix.
- **Use Meaningful Commit Messages**: Each commit message should clearly describe the changes made in that commit. This helps reviewers understand the history of the changes.
- **Follow Coding Standards**: Ensure that your code follows the project's coding [standards](./../Standards.md) and [guidelines](./NamingConventions.md). This includes formatting, naming conventions, and best practices.
- **Test Your Changes**: Before submitting a pull request, make sure to test your changes thoroughly. This includes running unit tests, integration tests, and any other relevant tests.
- **Update Documentation**: If your changes affect the project's documentation, make sure to update the documentation accordingly.
- **Be Responsive**: Be available to respond to comments and questions from reviewers. Address feedback promptly to keep the review process moving smoothly.
- **Acknowledge Reviewers**: Thank reviewers for their time and effort. A positive and respectful attitude helps maintain a collaborative and productive environment.
