# Getting Started

This is by no means a comprehensive guide to GIT and not necessarily the best practice when it comes to GIT via the terminal. These are just the steps I follow and so far, have never strayed too far from the mark.

## Setting up your terminal

The first thing we need to do is point our terminal at the DigitalNextGen repo. When you first load your terminal it will show your Mac username, similar to the below:

    aidenReact ~  $

To get into the DigitalNextGen repo we need to change to that directory using the `cd` command.

    cd Documents/DigitalNextGen/

You should see that you are now in that directory by the below:

    aidenReact ~/Documents/DigitalNextGen ~  $

## Getting the latest Develop

Before branching off **develop** you'll need to make sure you have all the latest changes available which can be achieved by the below\*\*:

    Firstly running: git fetch --all

    And then: git pull

\*\*Disclaimer: as stated above this might not be the best practice of pulling the latest changes due to the actions of `pull` however this will work perfectly fine in 99% of cases.

## Creating our branch

Now we have the latest version we are ready to create our branch. I will not be going into branch naming conventions here because it is available here in detail. But most of the time you will either be creating a `feature` or `bugfix` branch following a similar template below:

    git checkout -b "feature/DW-0000-short-description-of-task-in-kebab-case"

At this point, I also set the upstream of my newly made branch.

    git branch --set-upstream origin feature/DW-0000-short-description-of-task-in-kebab-case

You can avoid having to manually set the upstream every time by setting this `git config --global push.autoSetupRemote true` in your git config.

## Ready to code

We are now ready to code our little hearts out on our new branch!

## Further Info

For more information on the above checkout the below links:

    https://git-scm.com/docs/git-pull

    https://git-scm.com/docs/git-checkout
