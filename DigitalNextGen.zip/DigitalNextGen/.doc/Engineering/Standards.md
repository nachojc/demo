# SOLID

## Single-responsibility principle

> **A class should have one, and only one, reason to change.**<br />A class should only have a single responsibility, that is, only changes to one part of the software’s specification should be able to affect the specification of the class.

Complexity and size are always related to low cohesion, but it’s hard to decide how many responsibilities a component/hook/function should have. A great rule of thumb is: every component/hook/function should solve **ONE** specific problem.

This rule can be applied to many parts of your code: from having separate components doing specific view tasks, to how your application is structured.

### ❗ Read these [React docs](https://react.dev/learn/thinking-in-react) before continuing.

## Open-Closed Principle

> **Entities should be open for extension, but closed for modification.**<br />Entity can be extended by adding what is needed, but it can never be modified. This significantly reduces the risk of breaking existing functionality and provides a looser coupling.

_Unfortunately, truly maintainable, flexible, simple, and reusable components require more thought than: “I need it to do this differently, so I’ll accept a new prop for that.”_

Take the following example:

<!-- prettier-ignore-start -->
```ts
import { Text, View } from "react-native";

type CardProps = {
  title: string;
  body: string;
};

export const Card = ({ title, body }: CardProps) => {
  return (
    <View style={{...}}>
      <Text>{title}</Text>
      <Text>{body}</Text>
    </View>
  );
};
```
<!-- prettier-ignore-end -->

Seems pretty standard right? But this component can grow into something like this:

<!-- prettier-ignore-start -->
```ts
import { ReactNode } from 'react';
import { GestureResponderEvent } from 'react-native/types';
import { GetProps } from 'tamagui';

import { Text } from '../../text';
import {
  ActionsContainer,
  CardContainer,
  ContainerLeft,
  ContainerRight,
  DescriptiveCopyContainer,
  DescriptiveCopyText,
  LabelText,
  LabelTextContainer,
  SubtitleContainer,
  SubtitleText,
  TextContainer,
  TitleText,
  TitleTextContainer,
} from './base-card.style';
import { BaseCardSubtitle } from './base-card-subtitle';

export type BaseCardProps = GetProps<typeof CardContainer> & {
  label?: string;
  title?: ReactNode;
  subtitle?: ReactNode;
  overline?: string;
  descriptiveCopy?: string;
  renderItemLeft?: ReactNode;
  renderItemRight?: ReactNode;
  textContainerProps?: GetProps<typeof TextContainer>;
  labelTextProps?: GetProps<typeof LabelText>;
  titleTextProps?: GetProps<typeof TitleText>;
  subtitleContainerProps?: GetProps<typeof SubtitleContainer>;
  subtitleTextProps?: GetProps<typeof SubtitleText>;
  descriptiveCopyContainerProps?: GetProps<typeof DescriptiveCopyContainer>;
  descriptiveCopyTextProps?: GetProps<typeof DescriptiveCopyText>;
  containerLeftProps?: GetProps<typeof ContainerLeft>;
  containerRightProps?: GetProps<typeof ContainerRight>;
  actions?: ReactNode;
  selectionCard?: boolean;
  link?: ReactNode;
  onLinkPress?: (event: GestureResponderEvent) => void;
};

export const BaseCard = ({
  label,
  title,
  subtitle,
  overline,
  descriptiveCopy,
  selected,
  disabled,
  error,
  subtitleIncluded,
  generic,
  genericSecondary,
  renderItemLeft,
  renderItemRight,
  textContainerProps,
  labelTextProps,
  titleTextProps,
  subtitleContainerProps,
  subtitleTextProps,
  descriptiveCopyContainerProps,
  descriptiveCopyTextProps,
  containerLeftProps,
  containerRightProps,
  notification,
  actions,
  showBorder = true,
  snackbar,
  snackbarSingleLine,
  snackbarSingleLineNoPadding,
  snackbarTwoLine,
  snackbarMultiLine,
  selectionCard,
  link,
  onLinkPress,
  ...cardProps
}: BaseCardProps) => (
  <CardContainer
    showBorder={showBorder}
    selected={selected}
    disabled={disabled}
    error={error}
    subtitleIncluded={subtitleIncluded}
    generic={generic}
    notification={notification}
    genericSecondary={genericSecondary}
    snackbar={snackbar}
    snackbarSingleLine={snackbarSingleLine}
    snackbarSingleLineNoPadding={snackbarSingleLineNoPadding}
    snackbarTwoLine={snackbarTwoLine}
    snackbarMultiLine={snackbarMultiLine}
    testID="container"
    {...cardProps}
  >
    {renderItemLeft && (
      <ContainerLeft
        {...containerLeftProps}
        generic={generic}
        snackbar={snackbar}
        testID="left-container"
      >
        {renderItemLeft}
      </ContainerLeft>
    )}
    <TextContainer
      {...textContainerProps}
      generic={generic}
      notification={notification}
      snackbar={snackbar}
      snackbarMultiLine={snackbarMultiLine}
      testID="text-container"
    >
      {overline && (
        <Text fontVariant="overline-regular-Gray800">{overline}</Text>
      )}
      {label && (
        <LabelTextContainer
          notification={notification}
          testID="label-text-container"
        >
          <LabelText
            {...labelTextProps}
            generic={generic}
            genericSecondary={genericSecondary}
            testID="card-label"
          >
            {label}
          </LabelText>
        </LabelTextContainer>
      )}
      {title && (
        <TitleTextContainer
          notification={notification}
          testID="title-text-container"
        >
          <TitleText
            {...titleTextProps}
            generic={generic}
            genericSecondary={genericSecondary}
            notification={notification}
            snackbar={snackbar}
            selectionCard={selectionCard}
            testID="card-title"
          >
            {title}
          </TitleText>
        </TitleTextContainer>
      )}
      {subtitle && (
        <SubtitleContainer
          {...subtitleContainerProps}
          generic={generic}
          notification={notification}
          testID="subtitle-text-container"
        >
          <BaseCardSubtitle
            subtitle={subtitle}
            link={link}
            onLinkPress={onLinkPress}
            genericSecondary={genericSecondary}
            subtitleTextProps={subtitleTextProps}
          />
        </SubtitleContainer>
      )}
      {descriptiveCopy && (
        <DescriptiveCopyContainer
          {...descriptiveCopyContainerProps}
          generic={generic}
          testID="descriptiveCopy-text-container"
        >
          <DescriptiveCopyText
            {...descriptiveCopyTextProps}
            genericSecondary={genericSecondary}
            testID="card-descriptiveCopy"
          >
            {descriptiveCopy}
          </DescriptiveCopyText>
        </DescriptiveCopyContainer>
      )}
      {actions && (
        <ActionsContainer notification={notification} testID="action-container">
          {actions}
        </ActionsContainer>
      )}
    </TextContainer>
    {renderItemRight && (
      <ContainerRight
        {...containerRightProps}
        subtitleIncluded={subtitleIncluded}
        generic={generic}
        notification={notification}
        snackbar={snackbar}
        snackbarMultiLine={snackbarMultiLine}
        selectionCard={selectionCard}
        testID="right-container"
      >
        {renderItemRight}
      </ContainerRight>
    )}
  </CardContainer>
);
```
<!-- prettier-ignore-end -->

So the right way to start an extensible component is to use [composition](https://legacy.reactjs.org/docs/composition-vs-inheritance.html) or [compound components](https://www.smashingmagazine.com/2021/08/compound-components-react/) from the beginning. This way, the Card component would be closed for modifications and open for extension:

### ❗ Read these [Compound Components docs](https://www.smashingmagazine.com/2021/08/compound-components-react/) before continuing.

<!-- prettier-ignore-start -->
```ts
// before: hard to understand and setup, some props can be useless and only used to override incorrect behavior
<BaseCard
  generic
  subtitle="Subtitle"
  subtitleTextProps={{
    ellipse: true,
    numberOfLines: 2,
    fontSize: tokens.size['4'].val,
    mx: '$lg',
  }}
  descriptiveCopy="DescriptiveCopy"
  descriptiveCopyTextProps={{
    color: '$Tertiary800',
    mx: '$lg',
  }}
  elevationAndroid="$0"
  width={500}
  backgroundColor="transparent"
/>
```
<!-- prettier-ignore-end -->

<!-- prettier-ignore-start -->
```ts
// after: easy to understand and maintain
<Card generic elevationAndroid="$0" backgroundColor="transparent">
  <Card.Subtitle ellipse numberOfLines={2}>
    Subtitle
  </Card.Subtitle>
  <Card.DescriptiveCopy color="$Tertiary800">
    DescriptiveCopy
  </Card.DescriptiveCopy>
</Card>
```
<!-- prettier-ignore-end -->

_this is just an approximate outcome, final result may be different_

3rd party library example [react-native-paper Card component](https://callstack.github.io/react-native-paper/docs/components/Card/)

**Props is only a special case of Open-Closed Principle, the same rules can and should be applied to hooks, utils, etc.**

## Liskov Substitution Principle

> **Subtypes must be substitutable for their base types.**<br />Objects in a program should be replaceable with instances of their subtypes without altering the correctness of that program.

The main takeaway from this principle is to use TypeScript. You can easily swap components if they share the same contract.

In the following example, both components expect the same interface:

<!-- prettier-ignore-start -->
```ts
type CatFact = {
  facts: string[];
  color: string;
};

const CatFactA = ({ facts, color }: CatFact) => {
  return facts.map((fact, index) => (
    <View style={{ backgroundColor: color }}>
      <Text>
        Fact {index}: {fact}
      </Text>
    </View>
  ));
};

const CatFactB = ({ facts, color }: CatFact) => {
  return (
    <View style={{ backgroundColor: color, padding: 16 }}>
      {facts.map((fact) => (
        <Text>{fact}</Text>
      ))}
    </View>
  );
};

export const CatPage = () => {
  const catFactData: CatFact = {
    facts: [
      'Cats make about 100 different sounds.',
      'Domestic cats spend about 70 percent of the day sleeping.',
    ],
    color: 'red',
  };
  const abTest = Math.floor(Math.random() * 2) + 1;

  if (abTest === 1) {
    return <CatFactA {...catFactData} />;
  }

  return <CatFactB {...catFactData} />;
};
```
<!-- prettier-ignore-end -->

A good real life example is [@Shopify/flash-list](https://github.com/Shopify/flash-list), it has the same api as `FlatList` and it makes replacing one with another straightforward for developers. `estimatedItemSize` prop is the only one noticeable difference between `FlashList` and `FlatList`, but at the same time this prop is not required and won't break your app if you forget to use it.

## Interface Segregation Principle

> **Classes that implement interfaces, should not be forced to implement methods they do not use.**<br />Big interfaces should be splitted into smaller ones so there are no methods that are not used implemented. Classes know only about methods related to them providing decoupling and easier modifications. Many client-specific interfaces are better than one general-purpose interface.

Keep your interfaces small and cohesive. It’s not worth reusing the interface from your data mapper just because its easier. A component interface should only have the properties that are relevant for it.

<!-- prettier-ignore-start -->
```ts
type CatFactData = {
  facts: string[];
  color: string;
  link: string;
};

const CatFact = ({ facts }: CatFactData) => {
  return (
    <View>
      {facts.map((fact) => (
        <Text>{fact}</Text>
      ))}
    </View>
  );
};

export const CatPage = () => {
  const catFactData: CatFactData = {
    facts: [
      'Cats make about 100 different sounds.',
      'Domestic cats spend about 70 percent of the day sleeping.',
    ],
    color: 'red',
    link: 'https://github.com/',
  };

  return (
    <View>
      <CatFact {...catFactData} />
    </View>
  );
};
```
<!-- prettier-ignore-end -->

Notice the interface `CatFactData` has both a color and link in the above example, which is not being used by a `CatFact` component. Not destructing it doesn’t mean this component won’t depend on it, an interface shouldn’t have unused properties.

## Dependency Inversion Principle

> **High-level modules should not depend on low-level modules. Both should depend on abstractions. Abstractions should not depend on details. Details should depend on abstractions.**<br />_One should “depend upon abstractions, [not] concretions”._ This reduces dependencies in the code modules. Code is much more easier to maintain if abstractions and details are isolated from each other.

**Props example:**

One component shouldn’t directly depend on another component, but rather they both should depend on some common abstraction. Here, “component” refers to any part of our application, be that a React component, a utility function, a module, or a 3rd party library. This principle might be difficult to grasp in the abstract, so let’s jump straight into an example.

<!-- prettier-ignore-start -->
```ts
import { api } from '../common/api';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async () => {
    await api.login(email, password);
  };

  return (
    <View>
      <Input
        type="email"
        value={email}
        onChangeText={(text) => setEmail(text)}
      />
      <Input
        type="password"
        value={password}
        onChangeText={(text) => setPassword(text)}
      />
      <Button onPress={handleSubmit}>Log in</Button>
    </View>
  );
};
```
<!-- prettier-ignore-end -->

In this piece of code, our LoginForm component directly references the api module, so there’s a tight coupling between them. This is bad because such dependency makes it more challenging to make changes in our code, as a change in one component will impact other components. The dependency inversion principle advocates for breaking such coupling, so let’s see how we can achieve that.

First, we’re going to remove direct reference to the api module from inside the LoginForm, and instead, allow for the required functionality to be injected via props:

<!-- prettier-ignore-start -->
```ts
type LoginFormProps = {
  onSubmit: (email: string, password: string) => Promise<void>;
};

const LoginForm = ({ onSubmit }: LoginFormProps) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async () => {
    await onSubmit(email, password);
  };

  return (
    <View>
      <Input
        type="email"
        value={email}
        onChangeText={(text) => setEmail(text)}
      />
      <Input
        type="password"
        value={password}
        onChangeText={(text) => setPassword(text)}
      />
      <Button onPress={handleSubmit}>Log in</Button>
    </View>
  );
};
```
<!-- prettier-ignore-end -->

With this change, our LoginForm component no longer depends on the api module. The logic for submitting credentials to the API is abstracted away via onSubmit callback, and now it is the responsibility of the parent component to provide the concrete implementation of this logic.

To do that, we’ll create a parent of the LoginForm that will delegate form submission logic to the api module:

<!-- prettier-ignore-start -->
```ts
import { api } from '../common/api';

const LoginPage = () => {
  const handleSubmit = async (email: string, password: string) => {
    await api.login(email, password);
  };

  return <LoginForm onSubmit={handleSubmit} />;
};
```
<!-- prettier-ignore-end -->

LoginPage component serves as a glue between the api and LoginForm, while they themselves remain fully independent of each other. We can iterate on them and test them in isolation without worrying about breaking dependent moving pieces as there are none. And as long as both LoginForm and api adhere to the agreed common abstraction, the application as a whole will continue working as expected.

**Axios example:**

> _Note: refer to [this docs](../Patterns/APIs.md) to see how we work with data fetching, axios, query, etc._

In the example below, we directly refer to axios in a page component, which also directly derives from the axios interface:

<!-- prettier-ignore-start -->
```ts
import axios from 'axios';
import { useEffect, useState } from 'react';

export const App = () => {
  const [fact, setFact] = useState('');

  useEffect(() => {
    axios.get('https://cat-facts.com').then((res) => {
      setFact(res.data[0].text);
    });
  }, []);

  return (
    <View>
      <Text>Cat Facts</Text>
      <Text>{fact}</Text>
    </View>
  );
};
```
<!-- prettier-ignore-end -->

We can avoid directly depending on axios by creating a Factory component. This way our dependency will be an Abstraction which returns the same interface defined by our Service:

<!-- prettier-ignore-start -->
```ts
// App.tsx
import { useEffect, useState } from 'react';
import { RequestCatFactService } from './RequestCatFactService';

export const App = () => {
  const [fact, setFact] = useState('');

  useEffect(() => {
    RequestCatFactService().then((res) => {
      setFact(res);
    });
  }, []);

  return (
    <View>
      <Text>Cat Facts</Text>
      <Text>{fact}</Text>
    </View>
  );
};
```
<!-- prettier-ignore-end -->

<!-- prettier-ignore-start -->
```ts
// RequestCatFactService.tsx
import { RequestFactory } from './RequestFactory';

export const RequestCatFactService = (): Promise<string> => {
  return new Promise((resolve, reject) => {
    RequestFactory('https://cat-facts.com')
      .then((res) => resolve((res as CatFactsResponse)[0].text))
      .catch((error) => reject(error));
  });
};

type CatFactsResponse = { text: string }[];
```
<!-- prettier-ignore-end -->

<!-- prettier-ignore-start -->
```ts
// RequestFactory.ts
import { RequestAxios } from './RequestAxios';
import { RequestFake } from './RequestFake';

export const RequestFactory = (url: string) => {
  return process.env.enableFakeData ? RequestFake(url) : RequestAxios(url);
};
```
<!-- prettier-ignore-end -->

Note that we can also provide fake data, not just dispatch axios.

Our simple Service component, which in this case holds the URL and does some mapping for the sake of simplicity, is casting whatever response it gets to a type, which means we are not deriving its interface from axios in any way.

To conclude, the dependency inversion principle aims to minimize coupling between different components of the application. As you’ve probably noticed, minimizing is somewhat of a recurring theme throughout all SOLID principles - from minimizing the scope of responsibilities for individual components to minimizing cross-component awareness and dependencies between them.

## Conclusion

Despite being born out of problems of the OOP world, SOLID principles have their application well beyond it. We’ve seen how by having some flexibility with interpretations of these principles, we managed to apply them to our React code and make it more maintainable and robust.

It’s important to remember though, that being dogmatic and religiously following these principles may be damaging and lead to over-engineered code, so we should learn to recognize when further decomposition or decoupling of components stands to introduce complexity for little to no benefit.
