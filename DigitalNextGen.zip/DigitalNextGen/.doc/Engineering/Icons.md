# Icons

To work with SVG we use [React Native SVG transformer](https://github.com/kristerkari/react-native-svg-transformer). It allows us to use the original SVG markup without manual conversion from svg to React Native components.

## How to add a new icon to the project?

1. Create a new `.svg` file inside of `assets/icons` folder and give it a name (e.g. `car.svg`)
1. Paste the original SVG code from your source of truth (e.g. `Figma`)
   ```svg
   <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" >
       <!--SVG code-->
   </svg>
   ```
1. Update `assets/icons/index.ts` with a new icon
   ```ts
   import car from './car.svg'; // 1
   // ...
   export const icons = {
     // ...
     car, // 2
   };
   ```
1. That's it! You can use it as RN component and manage it via props:
   ```tsx
   <Icon name="car" width={40} height={40} />
   ```

## Things to keep in mind

1. `xmlns` attribute must be set in `<svg>`
   ```svg
   <svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" >
   ```
1. No need to put `width` and `height` attributes to `<svg>`. We can manage it using `Icon` component and it's props. Also `Icon` component has a default value for `width` and `height` as `tokens.size[6].val`
1. You can manage icon colors by using `fill` and `stroke` attributes. Just set `"currentColor"` to these attributes (check `assets/icons/information-filled.svg` for instance). Once you are done that you can manage colors outside of `svg`:
   ```tsx
   <Icon name="info" color={tokens.color.Warning.val} stroke={tokens.color.Secondary800.val} />
   ```
1. We can set default values for svg icons in `assets/icons/index.ts`, e.g.:
   ```ts
   'x-circle': [xCircle, { color: tokens.color.Error.val }]
   ```
1. We can override default svg values by props:
   ```tsx
   // color will be tokens.color.Warning.val (not tokens.color.Error.val)
   <Icon name="x-circle" color={tokens.color.Warning.val} />
   ```
1. By default `testID` is created from the `name` prop. If you need some other `testID` you can set it by props:
   ```tsx
   // testID will be: "test:id/icon-close" (not test:id/icon-x-circle)
   <Icon name="x-circle" testID="close" />
   ```
