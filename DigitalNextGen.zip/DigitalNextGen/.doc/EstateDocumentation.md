# Estate Documentation

## Architecture

- [Migration](./Architecture/Migration.md)
- [MVVM (current)](./Architecture/Mvvm.md)
- [Universal Linking](./Architecture/UniversalLinking.md)

## CI/CD

- [Build Settings](./CICD/BuildSettings.md)
- [Pipelines](./CICD/Pipelines.md)
- [Release Model](./CICD/ReleaseModel.md)
- [Repository Policies](./CICD/RepositoryPolicies.md)

## Engineering

- [Code Styling](./Engineering/CodeStyles.md)
- [Git](./Engineering/Git)
  - [Getting Started](./Engineering/Git/GettingStarted.md)
  - [Naming Conventions](./Engineering/Git/NamingConventions.md)
  - [Pull Request Etiquette](./Engineering/Git/PullRequestEtiquette.md)
- [Icons](./Engineering/Icons.md)
- [Standards](./Engineering/Standards.md)
- [Tabs](./Engineering/Tabs.md)

## Patterns

- [Analytics](./Patterns/Analytics.md)
- [APIs](./Patterns/APIs.md)
- [Data and State](./Patterns/DataState.md)
- [Dev Mode](./Patterns/DevMode.md)
- [Screens](./Patterns/Screens.md)
- [String Constants](./Patterns/StringConstants.md)
- [Tabs](./Patterns/Tabs.md)

## Testing

- [Automation](./Testing/Automation)
  - [BDD Coding Standards](./Testing/Automation/BDDCodingStandards.md)
- [Sharding Jest Tests](./Testing/ShardingJestTests.md)
- [Unit Testing](./Testing/UnitTesting.md)

## Tooling

- Expo
  - [Prebuild](./Tooling/Expo/Prebuild.md)
  - [Debugger](./Tooling/Expo/Debugger.md)
- [All things Cocoapods](./Tooling/Cocoapods.md)
- [Checkmarx](./Tooling/Checkmarx.md)
- [Debugging On Physical Devices](./Tooling/DebuggingOnPhysicalDevices.md)
- [Lower Environment Simulator/Emulator Setup](./Tooling/LowerEnvironmentsSimulatorEmulatorSetup.md)
- [MacBook Install Folder](./Tooling/MacBookInstallFolder.md)
- [Preconfigure](./Tooling/Preconfigure.md)
- [SonarQube](./Tooling/SonarQube.md)
- [Software and Installation](./Tooling/SoftwareInstallation.md)
- [Troubleshooting](./Tooling/Troubleshooting.md)
- Libraries
  - [Packages Installation and Updates](./Tooling/Libraries/PackageInstallationAndUpdates.md)
  - [Third Parties](./Tooling/Libraries/ThirdParties.md)
