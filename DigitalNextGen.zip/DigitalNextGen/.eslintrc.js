const OFF = 'off';
const WARN = 'warn';
const ERROR = 'error';

const commonNoRestrictedImportsPaths = [
  {
    name: 'react',
    importNames: ['default'],
    message:
      "React is already in the scope automatically. If you need something from react use import with destructuring, e.g.: import { useState, ReactNode } from 'react'",
  },
  {
    name: 'react-native',
    importNames: [
      'ButtonProps',
      'TextProps',
      'TextInputProps',
      'ViewProps',
      'PressableProps',
    ],
    message: 'Prefer ion-mobile imports instead',
  },
  {
    name: 'react-native',
    importNames: ['Image'],
    message: 'Prefer @aviva/ion-mobile Image component instead',
  },
  {
    name: 'react-native',
    importNames: ['FlatList'],
    message: 'Prefer `@src/components/flat-list` Flatlist component instead',
  },
  {
    name: 'react-native',
    importNames: ['StatusBar'],
    message: 'Prefer @aviva/ion-mobile FocusAwareStatusBar component instead',
  },
  {
    name: 'expo-status-bar',
    importNames: ['StatusBar'],
    message: 'Prefer @aviva/ion-mobile FocusAwareStatusBar component instead',
  },
  {
    name: 'axios',
    importNames: ['default'],
    message: 'Prefer @utils/api axios instance instead',
  },
  {
    name: '@testing-library/react-native',
    message: 'Prefer @src/jest/testing-library instead',
  },
  {
    name: 'react-native-device-info',
    message: 'Prefer @src/utils/device-info',
  },
];

const commonNoRestrictedImportPatterns = [
  {
    group: ['msw', 'msw/*', '!@api-mock/msw'],
    message: 'Do not import msw directly, use @api-mock/msw instead.',
  },
];

const getTypeAliasNamingConventionRegex = () => {
  const forbiddenWords = [
    'T',
    'Type',
    'Types',
    'I',
    'Interface',
    'Union',
    'Schema',
  ].join('|');
  let allowedWordsStart = [].join('|');
  let allowedWordsEnd = ['ContextType'].join('|');

  if (allowedWordsStart) {
    allowedWordsStart = `|(${allowedWordsStart})`;
  }
  if (allowedWordsEnd) {
    allowedWordsEnd = `|(${allowedWordsEnd})`;
  }

  return `(^(?!(${forbiddenWords})[A-Z])${allowedWordsStart}).*?(((?<!(${forbiddenWords}))${allowedWordsEnd})$)`;
};

module.exports = {
  root: true,
  env: { browser: true, es2021: true, amd: true, node: true },
  extends: [
    'eslint:recommended',
    'plugin:react/recommended',
    '@react-native',
    'plugin:react/jsx-runtime',
    'plugin:@typescript-eslint/recommended',
    'plugin:react-native-a11y/all',
    'plugin:sonarjs/recommended',
    'plugin:jest/recommended',
    'plugin:testing-library/react',
    'plugin:prettier/recommended',
  ],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module',
    project: true,
    tsconfigRootDir: __dirname,
  },
  plugins: [
    'eslint-local-rules',
    'import',
    'simple-import-sort',
    '@typescript-eslint',
    'communist-spelling',
    'sonarjs',
    'prettier',
    'filename-rules',
    'jest',
    'testing-library',
  ],
  rules: {
    curly: ERROR,
    'prefer-destructuring': [ERROR, { object: true, array: false }],

    /* TypeScript */
    '@typescript-eslint/no-empty-interface': OFF,
    '@typescript-eslint/no-var-requires': OFF,
    '@typescript-eslint/consistent-type-definitions': [ERROR, 'type'],
    '@typescript-eslint/array-type': ERROR,
    '@typescript-eslint/prefer-optional-chain': ERROR,
    '@typescript-eslint/prefer-as-const': ERROR,
    '@typescript-eslint/no-inferrable-types': ERROR,
    '@typescript-eslint/method-signature-style': ERROR,
    '@typescript-eslint/prefer-includes': ERROR,
    '@typescript-eslint/return-await': ERROR,
    '@typescript-eslint/await-thenable': ERROR,
    '@typescript-eslint/consistent-generic-constructors': ERROR,
    '@typescript-eslint/prefer-for-of': ERROR,
    '@typescript-eslint/no-for-in-array': ERROR,
    '@typescript-eslint/no-redundant-type-constituents': ERROR,
    '@typescript-eslint/consistent-type-exports': ERROR,
    '@typescript-eslint/switch-exhaustiveness-check': ERROR,
    '@typescript-eslint/naming-convention': [
      ERROR,
      {
        selector: 'default',
        format: ['camelCase', 'PascalCase', 'UPPER_CASE'],
        leadingUnderscore: 'allow',
        trailingUnderscore: 'forbid',
      },
      { selector: 'objectLiteralProperty', format: null },
      {
        selector: 'objectLiteralMethod',
        modifiers: ['requiresQuotes'],
        format: null,
      },
      {
        selector: 'typeAlias',
        format: ['PascalCase'],
        custom: {
          regex: getTypeAliasNamingConventionRegex(),
          match: true,
        },
      },
      { selector: 'typeProperty', format: null },
    ],
    '@typescript-eslint/consistent-type-imports': [
      ERROR,
      { prefer: 'no-type-imports', disallowTypeAnnotations: false },
    ],

    'eslint-local-rules/missing-test-id': [
      WARN,
      {
        disableDefaultComponents: [],
        enableComponents: [],
      },
    ],

    '@typescript-eslint/no-unnecessary-boolean-literal-compare': [
      ERROR,
      { allowComparingNullableBooleansToTrue: false },
    ],
    '@typescript-eslint/no-confusing-void-expression': [
      ERROR,
      { ignoreArrowShorthand: true },
    ],
    '@typescript-eslint/no-misused-promises': [
      ERROR,
      { checksVoidReturn: false },
    ],
    'no-restricted-syntax': [
      ERROR,
      {
        selector: 'TSEnumDeclaration',
        message:
          "Don't use enums. Use UNION TYPES instead. \nOnly use `as const` if it's actually needed and you can prove it.",
      },
    ],

    /* React */
    'react/default-props-match-prop-types': ERROR,
    'react/sort-prop-types': ERROR,
    'react/jsx-boolean-value': ERROR,
    'react/jsx-key': [
      ERROR,
      {
        checkFragmentShorthand: true,
        checkKeyMustBeforeSpread: true,
        warnOnDuplicates: true,
      },
    ],
    'react/hook-use-state': ERROR,

    /* React hooks */
    'react-hooks/exhaustive-deps': WARN,
    'react-hooks/rules-of-hooks': ERROR,

    /* React native */
    'react-native/no-inline-styles': OFF,

    /* Jest */
    'jest/consistent-test-it': [ERROR, { fn: 'it', withinDescribe: 'it' }],
    'jest/no-conditional-in-test': ERROR,
    'jest/max-nested-describe': [ERROR, { max: 3 }],

    /** Testing Library Overrides*/
    'testing-library/render-result-naming-convention': OFF,

    /* Styling */
    'communist-spelling/communist-spelling': OFF,
    'object-shorthand': ERROR,

    /* A11Y */
    'react-native-a11y/has-accessibility-hint': OFF,
    'react-native-a11y/has-valid-accessibility-descriptors': OFF,
    'react-native-a11y/has-valid-accessibility-ignores-invert-colors': OFF,

    /* Importing */
    'import/first': ERROR,
    'import/newline-after-import': ERROR,
    'import/no-duplicates': ERROR,
    'import/no-default-export': ERROR,
    'simple-import-sort/exports': ERROR,
    'simple-import-sort/imports': ERROR,
    'no-restricted-imports': [
      ERROR,
      {
        paths: [
          ...commonNoRestrictedImportsPaths,
          {
            name: 'tamagui',
            message:
              'Prefer @aviva/ion-mobile component instead, the most used tamagui components had been added to @aviva/ion-mobile',
          },
        ],
        patterns: [
          ...commonNoRestrictedImportPatterns,
          {
            group: ['@tamagui/*'],
            message:
              'Prefer @aviva/ion-mobile component instead, the most used tamagui components had been added to @aviva/ion-mobile',
          },
        ],
      },
    ],

    /**
     * Temporarily disabled errors
     * In an effort to transition to the react-native-community eslint standard
     * and the sonarjs plugin, some rules produce errors and need to be manually
     * migrated. As such, we will be reporting them as warnings here.
     */
    'no-nested-ternary': WARN,
    'sonarjs/prefer-immediate-return': OFF,
    'sonarjs/no-duplicate-string': OFF,
    'sonarjs/cognitive-complexity': WARN,

    /**
     * SonarQube rules
     * These appear as errors in SonarQube, so they are enabled here to catch
     * quickly
     */
    eqeqeq: ERROR,
    'react/jsx-no-constructed-context-values': ERROR,
  },
  settings: { react: { version: 'detect' } },
  overrides: [
    {
      files: ['**/*.test.ts', '**/*.test.tsx', '**/*.spec.ts', '**/*.spec.tsx'],
      rules: {
        'filename-rules/match': [
          ERROR,
          {
            includePath: true,
            pattern: /\/__tests__\/.*\.test\.tsx?$/,
          },
        ],
        'no-restricted-imports': [
          ERROR,
          {
            paths: [
              {
                name: '@testing-library/react-native',
                message: 'Prefer @src/jest/testing-library instead',
              },
            ],
          },
        ],

        'simple-import-sort/imports': [
          ERROR,
          {
            groups: [
              // This is the default sorting with testing-library added
              // found at node_modules/eslint-plugin-simple-import-sort/imports.js
              ['^\\u0000'],
              ['^node:'],
              ['@src/jest/testing-library', '^@?\\w'],
              ['^'],
              ['^\\.'],
            ],
          },
        ],
      },
    },
    {
      files: ['integration-tests/**/*.js'],
      plugins: ['wdio'],
      extends: ['eslint:recommended', 'plugin:wdio/recommended'],
    },
    {
      files: [
        'app.config.ts',
        'jest.config.ts',
        'tamagui.config.ts',
        'src/types/**/*.ts',
      ],
      rules: { 'import/no-default-export': OFF },
    },
    {
      files: [
        'src/types/**/*.ts',
        'tamagui.config.ts',
        'src/navigation/types.ts',
        'src/jest/jest-extensions.ts',
      ],
      rules: { '@typescript-eslint/consistent-type-definitions': OFF },
    },
    {
      files: ['packages/ion-mobile/**/**/*.ts*'],
      rules: {
        'no-restricted-imports': [
          ERROR,
          {
            paths: commonNoRestrictedImportsPaths,
            patterns: commonNoRestrictedImportPatterns,
          },
        ],
      },
    },
    {
      files: ['assets/icons/index.ts'],
      rules: { 'sort-keys': [ERROR, 'asc', { natural: true }] },
    },
  ],
};
