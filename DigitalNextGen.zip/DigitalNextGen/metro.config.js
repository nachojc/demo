// Learn more https://docs.expo.io/guides/customizing-metro
const { getDefaultConfig } = require('@expo/metro-config');
const { mergeConfig } = require('@react-native/metro-config');
const path = require('path');

const optimizeBundle = process.env.OPTIMIZE_BUNDLE === 'true';

const requestResolver = () => {
  if (!optimizeBundle) {
    return undefined;
  }

  return (context, moduleName, platform) => {
    if (/^msw/.test(moduleName)) {
      return {
        filePath: path.join(__dirname, 'src/api-mock/msw/prod-stub.ts'),
        type: 'sourceFile',
      };
    }

    const resolved = context.resolveRequest(context, moduleName, platform);
    if (/src\/api-mock\/use-mock-service-worker\.ts/.test(resolved.filePath)) {
      return {
        filePath: path.join(
          __dirname,
          'src/api-mock/msw/use-mock-service-worker.stub.ts'
        ),
        type: 'sourceFile',
      };
    }
    if (/src\/api-mock\/responses\/.*\.ts/.test(resolved.filePath)) {
      return {
        filePath: path.join(__dirname, 'src/api-mock/msw/prod-stub.ts'),
        type: 'sourceFile',
      };
    }

    if (/src\/api-mock\/responses\/.*\.json$/.test(resolved.filePath)) {
      return {
        filePath: path.join(__dirname, 'src/api-mock/responses/prod-stub.json'),
        type: 'sourceFile',
      };
    }

    return resolved;
  };
};

const config = getDefaultConfig(__dirname);

module.exports = mergeConfig(config, {
  transformer: {
    babelTransformerPath: require.resolve('react-native-svg-transformer'),
    defaultConfig: {
      transform: {
        experimentalImportSupport: false,
        inlineRequires: false,
      },
    },
  },
  resolver: {
    sourceExts: [...(config.resolver.sourceExts ?? []), 'svg'],
    assetExts: [
      ...(config.resolver.assetExts ?? []).filter((ext) => ext !== 'svg'),
      'fcscript',
    ],
    // We don't want to bundle msw and our mock responses in production, so we stub all the files during the bundling phase.
    resolveRequest: requestResolver(),
  },
});
