import { ExpoConfig } from 'expo/config';
import rules = require('./proguard-rules');

/**
 * Currently we only handle the following build types
 *
 * - Development: local developers simulators
 * - Staging:     build to browser stack
 * - Production:  builds to customers
 */
type PrebuildEnvs = 'development' | 'staging' | 'pentest' | 'production';
type TargetApp = 'dw' | 'ma' | 'ma-demo';
// We wouldn't call pebuild with pentest as an option, but it's possible
// for pod install to do it in some circumstances
// If so, set TARGET to prod
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
//@ts-ignore
const TARGET = (process.env.TARGET_ENV ?? 'development') as PrebuildEnvs;
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
//@ts-ignore
const APP = (process.env.TARGET_APP ?? 'ma') as TargetApp;
const isManga = APP === 'ma' || APP === 'ma-demo';
const TGT = TARGET === 'pentest' ? 'production' : TARGET;
const isProduction = TGT === 'production';

const BUNDLE_IDENTIFIER = isManga
  ? 'co.uk.aviva.myaviva'
  : 'co.uk.aviva.directwealth';

const appName = isManga ? 'myaviva' : 'avivawealth';
const displayName = isManga ? 'MyAviva' : 'Aviva Wealth';

const LSApplicationQueriesSchemes = isManga ? ['avivawealth'] : ['myaviva'];
const playServicesLocationVersion = '21.0.1';

/**
 * @description
 * Static config export for configuring the prebuild
 * Contains only non-target specific configuration
 */
export default (): ExpoConfig => {
  return {
    name: appName,
    slug: appName,
    extra: {
      displayName,
      isManga,
      appID: BUNDLE_IDENTIFIER,
      targetApp: APP,
    },
    version: '6666',
    orientation: 'portrait',
    icon: isManga ? './assets/myaviva.png' : './assets/avivawealthblue.png',
    userInterfaceStyle: 'light',
    scheme: appName,
    updates: {
      enabled: false,
      fallbackToCacheTimeout: 0,
    },
    assetBundlePatterns: ['**/*'],
    splash: {
      image: isManga
        ? './assets/myaviva-splash.png'
        : './assets/avivawealthblue-splash.png',
      resizeMode: 'contain',
      backgroundColor: isManga ? '#FFD900' : '#05142D',
    },
    ios: {
      config: {
        usesNonExemptEncryption: false,
      },
      infoPlist: {
        NSAppTransportSecurity: {
          NSAllowsArbitaryLoads: !isProduction,
          NSExceptionDomains: !isProduction
            ? {
                localhost: {
                  NSExceptionAllowsInsecureHTTPLoads: true,
                },
              }
            : undefined,
        },
        LSApplicationQueriesSchemes,
        CFBundleDisplayName: displayName,
        CFBundleSpokenName: displayName,
        UIBackgroundModes: [
          'remote-notification',
          isManga ? 'location' : undefined,
          isManga ? 'fetch' : undefined,
          isManga ? 'processing' : undefined,
          isManga ? 'bluetooth-central' : undefined,
        ],
        BGTaskSchedulerPermittedIdentifiers: [
          'com.ims.heartbeatBgTaskScheduler',
          'com.ims.logUploaderBgTaskScheduler',
        ],
        NSMotionUsageDescription: `${displayName} would like permission to access your motion usage in order to help track your driving.`,
        NSLocationAlwaysAndWhenInUseUsageDescription:
          'Location is used for compliance and is stored with record data',
        NSLocationAlwaysUsageDescription:
          'Location is used for compliance and is stored with record data',
        NSLocationWhenInUseUsageDescription:
          'Location is used for compliance and is stored with record data',
        NSLocationTemporaryUsageDescriptionDictionary: {
          purposeMyDrive:
            'Location is used for compliance and is stored with record data',
        },
        UIFileSharingEnabled: !isProduction,
        LSSupportsOpeningDocumentsInPlace: !isProduction,
        UISupportsDocumentBrowser: !isProduction,
        NSBluetoothAlwaysUsageDescription: `${displayName} would like permission to access your Bluetooth in order to help track your driving`,
        NSMicrophoneUsageDescription: `${displayName} would like permission to access your microphone`,
        NSCameraUsageDescription: `${displayName} would like permission to access your camera`,
        NFCReaderUsageDescription: `${displayName} would like permission to access your NFC contactless reader`,
        NSPhotoLibraryUsageDescription: `${displayName} would like permission to access your photo library so you can upload images and screenshots in live chat support`,
        NSPhotoLibraryAddUsageDescription: `${displayName} would like permission to access your photo library so you can save images and screenshots in live chat support`,
      },
      supportsTablet: isManga,

      bundleIdentifier: BUNDLE_IDENTIFIER,
      googleServicesFile: isManga
        ? './patches/ma/GoogleService-Info.plist'
        : './patches/dw/GoogleService-Info.plist',
      ...createIOSTargetConfig(),
    },
    android: {
      package: BUNDLE_IDENTIFIER,
      jsEngine: 'hermes',
      versionCode: 7,
      permissions: [
        'USE_BIOMETRIC',
        'USE_FINGERPRINT',
        'POST_NOTIFICATIONS',
        'ACCESS_COARSE_LOCATION',
        'ACCESS_FINE_LOCATION',
        'ACCESS_BACKGROUND_LOCATION',
        'com.google.android.gms.permission.ACTIVITY_RECOGNITION',
        'android.permission.ACTIVITY_RECOGNITION',
        'android.permission.READ_PHONE_STATE',
        'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
      ],
      blockedPermissions: isManga
        ? undefined
        : [
            'ACCESS_FINE_LOCATION',
            'ACCESS_BACKGROUND_LOCATION',
            'ACCESS_COARSE_LOCATION',
            'com.google.android.gms.permission.ACTIVITY_RECOGNITION',
            'android.permission.ACTIVITY_RECOGNITION',
            'android.permission.READ_PHONE_STATE',
            'android.permission.REQUEST_IGNORE_BATTERY_OPTIMIZATIONS',
          ],
      adaptiveIcon: {
        foregroundImage: isManga
          ? './assets/myaviva-adaptive.png'
          : './assets/avivawealthblue-adaptive.png',
        backgroundColor: isManga ? '#FFD900' : '#05142D',
      },
      googleServicesFile: isManga
        ? './patches/ma/google-services.json'
        : './patches/dw/google-services.json',
      ...createAndroidTargetConfig(),
    },
    plugins: [
      'expo-font',
      'expo-secure-store',
      '@react-native-firebase/app',
      '@react-native-firebase/messaging',
      [
        'expo-local-authentication',
        {
          faceIDPermission:
            'Enabling Face ID allows you quick and secure access to your account.',
        },
      ],
      [
        'expo-build-properties',
        {
          android: {
            buildToolsVersion: '34.0.0',
            compileSdkVersion: 34,
            enableProguardInReleaseBuilds: isProduction,
            enableShrinkResourcesInReleaseBuilds: isProduction,
            extraMavenRepos: [
              'https://s3-us-west-2.amazonaws.com/si-mobile-sdks/android/',
            ],
            extraProguardRules: rules.proguardRules,
            kotlinVersion: '1.8.10',
            minSdkVersion: 29,
            targetSdkVersion: 34,
            usesCleartextTraffic: false,
          },
          ios: {
            deploymentTarget: '15.0',
          },
        },
      ],
      [
        './plugins/withGradleProperties',
        {
          // Increase default java VM size so it can handle building all the Expo packages.
          'org.gradle.jvmargs':
            '-Xmx3g -Xmx4096m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8',
          'org.gradle.daemon': 'false',
          'android.enableProguardInReleaseBuilds': 'true',
          'android.enableShrinkResourcesInReleaseBuilds': 'true',
        },
      ],
      [
        './plugins/withProjectBuildGradle',
        {
          ext: {
            playServicesLocationVersion: `'${playServicesLocationVersion}'`,
          },
        },
      ],
      [
        // Add new styles into the android/app/src/main/res/values/styles.xml file
        './plugins/withAndroidStyle',
      ],
      [
        // Things which go into settings.gradle. Don't put : before the package name. path is relative to the android folder.
        './plugins/withSettingsImport',
        [
          {
            packageName: 'nuance',
            packagePath: '../node_modules/rn-bridge-nuance/android/nuance',
          },
          {
            packageName: 'campaignclassic',
            packagePath:
              '../node_modules/rn-bridge-campaignclassic/android/campaignclassic',
          },
          {
            packageName: 'ims-common',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-common',
          },
          {
            packageName: 'ims-core-log',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-core-log',
          },
          {
            packageName: 'ims-core-timekeeper',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-core-timekeeper',
          },
          {
            packageName: 'ims-devices',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-devices',
          },
          {
            packageName: 'ims-devices-ble-nordic',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-devices-ble-nordic',
          },
          {
            packageName: 'ims-devices-bluetooth',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-devices-bluetooth',
          },
          {
            packageName: 'ims-devices-core',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-devices-core',
          },
          {
            packageName: 'ims-devices-wedge',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-devices-wedge',
          },
          {
            packageName: 'ims-distracteddriving',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-distracteddriving',
          },
          {
            packageName: 'ims-gateway',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-gateway',
          },
          {
            packageName: 'ims-imsappmisuse',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-imsappmisuse',
          },
          {
            packageName: 'ims-location',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-location',
          },
          {
            packageName: 'ims-portal',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-portal',
          },
          {
            packageName: 'ims-provider',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-provider',
          },
          {
            packageName: 'ims-provider-activity',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-provider-activity',
          },
          {
            packageName: 'ims-sensors',
            packagePath: '../node_modules/rn-bridge-ims/android/ims-sensors',
          },
          {
            packageName: 'ims-tripdetection',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-tripdetection',
          },
          {
            packageName: 'ims-tripdetectionumbrella',
            packagePath:
              '../node_modules/rn-bridge-ims/android/ims-tripdetectionumbrella',
          },
          {
            packageName: 'react-native-qualtrics',
            packagePath: '../node_modules/react-native-qualtrics/android',
          },
        ],
      ],
    ],
  };
};

/**
 * @description
 * Allows overriding the static values in the default config
 * Should be spread last in the ios property of the default config
 * Config shared between targets should be in the static config defined in the default export
 */
function createIOSTargetConfig(): ExpoConfig['ios'] {
  switch (TGT) {
    case 'production':
      return {
        associatedDomains: [
          TARGET === 'pentest'
            ? 'applinks:www.direct3.rwy-aviva.co.uk?mode=developer'
            : 'applinks:www.direct.aviva.co.uk',
        ],
        entitlements: { 'aps-environment': 'production' },
      };
    case 'staging':
      return {
        associatedDomains: [
          'applinks:www.direct.dev-aviva.co.uk?mode=developer',
          'applinks:www.direct1.rwy-aviva.co.uk?mode=developer',
          'applinks:www.direct2.rwy-aviva.co.uk?mode=developer',
          'applinks:www.direct.pre-aviva.co.uk?mode=developer',
          'applinks:www.direct.stg-aviva.co.uk?mode=developer',
          'applinks:www.direct.rwy-aviva.co.uk?mode=developer',
        ],
        entitlements: { 'aps-environment': 'production' },
      };
    case 'development':
      return {};
    default:
      assertNever(TGT);
      throw new Error(`Expo Prebuild environment: ${TARGET} not handled`);
  }
}

/**

* @description
 * Allows overriding the static values in the default config
 * Should be spread last in the android property of the default config
 * Config shared between targets should be in the static config defined in the default export
 */
function createAndroidTargetConfig(): ExpoConfig['android'] {
  switch (TGT) {
    case 'production':
      return {
        intentFilters: [
          // App links config
          {
            action: 'View',
            // must be false for applinks as no backing json on server
            autoVerify: false,
            data: { scheme: 'applinks' },
            category: ['DEFAULT', 'BROWSABLE'],
          },
          // Universal links config
          {
            action: 'VIEW',
            // must be true for universal as these paths have backing json on server
            autoVerify: true,
            category: ['DEFAULT', 'BROWSABLE'],
            data: [
              { scheme: 'http' },
              { scheme: 'https' },
              TARGET === 'pentest'
                ? { host: 'direct3.rwy-aviva.co.uk' }
                : { host: 'direct.aviva.co.uk' },
            ],
          },
        ],
      };
    case 'development':
    case 'staging':
      return {
        intentFilters: [
          // App links config
          {
            action: 'View',
            // must be false for applinks as no backing json on server
            autoVerify: false,
            data: { scheme: 'applinks' },
            category: ['DEFAULT', 'BROWSABLE'],
          },
          // Universal links config
          {
            action: 'VIEW',
            // must be true for universal as these paths have backing json on server
            autoVerify: true,
            category: ['DEFAULT', 'BROWSABLE'],
            data: [
              { scheme: 'http' },
              { scheme: 'https' },
              { host: 'direct.dev-aviva.co.uk' },
              { host: 'direct1.rwy-aviva.co.uk' },
              { host: 'direct2.rwy-aviva.co.uk' },
              { host: 'direct.pre-aviva.co.uk' },
              { host: 'direct.stg-aviva.co.uk' },
              { host: 'direct.rwy-aviva.co.uk' },
            ],
          },
        ],
      };
    default:
      assertNever(TGT);
      throw new Error(`Expo Prebuild environment: ${TARGET} not handled`);
  }
}

const assertNever = (v: never): v is never => v;
