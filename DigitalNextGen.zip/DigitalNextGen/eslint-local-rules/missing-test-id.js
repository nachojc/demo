const defaultComponents = [
  'Pressable',
  'TextInput',
  'TouchableNativeFeedback',
  'TouchableWithoutFeedback',
];

// Credit: https://github.com/frzkn/eslint-plugin-react-native-enforce-testid
module.exports = {
  rules: {
    'missing-test-id': {
      create(context) {
        const options = context.options[0] || {};
        const { disableDefaultComponents = [], enableComponents = [] } =
          options;

        return {
          JSXOpeningElement({ name, attributes }) {
            const componentName = name.name;

            const filteredDefaultComponents = defaultComponents.filter(
              (component) => !disableDefaultComponents.includes(component)
            );
            const mergedAllowedComponents = [
              ...filteredDefaultComponents,
              ...enableComponents,
            ];
            if (mergedAllowedComponents.includes(componentName)) {
              const hasTestIDAttribute = attributes.some(
                (attribute) => attribute.name?.name === 'testID'
              );

              if (!hasTestIDAttribute) {
                context.report({
                  node: name,
                  message: `Missing 'testID' attribute in ${componentName} component.`,
                });
              }
            }
          },
        };
      },
    },
  },
};
