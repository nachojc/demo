#!/bin/zsh
readonly script_version=1.4.2
readonly proxy=http://ep.threatpulse.net:80
readonly manga_home="$HOME/.manga"
readonly manga_cache="$manga_home/cache"
echo "Script version  : $script_version"

load_cache() {
  file_name=$(basename $1)
  if ! [ -f $manga_cache/$file_name ]; then
    printf "Caching %s\n" $file_name
    if ! curl -f -H "Authorization: Bearer ${ARTIFACTORY_JWT}" "$1" -o $manga_cache/$file_name; then
      print -P "%F{red}Error: $1 cannot be downloaded%f\n"
      exit 1
    fi
  fi
}

script_dir="$(dirname $(realpath $0))"
cd $script_dir

#remove any proxy from .curlrc
if [ -f $HOME/.curlrc ]; then sed -i '' -E '/^proxy=.*/d' $HOME/.curlrc; fi

# Get the Artifactory JWT
export no_proxy="binaries.avivagroup.com"

ME=$(whoami)
if id | grep -q "80(admin)"; then
  ADMIN=$(id -un)
  alt_admin=false
else
  ADMIN=$(id -un)admin
  alt_admin=true
fi

if [ -z "${DOMAIN_ID:-}" ]; then
  id=$(security dump-keychain | grep -oE "login_name\": \".*@" | grep -v "LEEFEA" | sort | tail -n 1 | sed -E "s/login_name\": \"(.*)@/\1/g")
  read "domain_id?Enter your Avivagroup username (i.e. bloggsf or A123456) [default=${id}]: "
  export DOMAIN_ID=$(echo "${domain_id:-${id}}" | tr '[:upper:]' '[:lower:]')
fi
printf "Using domain ID: %s\n" $DOMAIN_ID

export EMAIL=$(dscl "/Active Directory/AVIVAGROUP/All Domains" read "/Users/$DOMAIN_ID" "EMailAddress" | cut -d ' ' -f 2)
print -P "%F{red}Avivagroup password (NOT your Mac password)%f\n"
export ARTIFACTORY_JWT=$(curl -fsS -u ${DOMAIN_ID} -X POST "https://binaries.avivagroup.com/artifactory/api/security/token" -d "username=${DOMAIN_ID}" -d "expires_in=604800" | grep access_token | cut -d '"' -f 4)
if [ "$ARTIFACTORY_JWT" != "" ]; then
  print -P "%F{green}Logged into Artifactory...%f\n"
else
  print -P "%F{red}Artifactory login failed. There are 3 possibilities: a) you typed your password wrong, b) your account is locked or c) you don't have access to Artifactory (you'll need to raise an ITSS request for this). You can log directly into https://binaries.avivagroup.com to check.%f\n"
  exit 1
fi
echo "your JWT is $ARTIFACTORY_JWT"

# Add the JWT to .zprofile
cp .zprofile ~
echo "" >>~/.zprofile
echo "export DOMAIN_ID=\"$DOMAIN_ID\"" >>~/.zprofile
echo "export ARTIFACTORY_JWT=\"$ARTIFACTORY_JWT\"" >>~/.zprofile

sed -E -i '' "s#(http_proxy=)#\1$proxy#g" ~/.zprofile

git config --global --replace-all http.proxy $proxy

cat >~/.netrc <<EOF
machine binaries.avivagroup.com
localhost ${DOMAIN_ID}
password ${ARTIFACTORY_JWT}
EOF
chmod 0600 ~/.netrc

. ~/.zprofile

# Load the cache
mkdir -p "$manga_cache"
load_cache https://binaries.avivagroup.com/artifactory/manga-generic-local/gradle/gradle/7.5.1/gradle-7.5.1-all.zip
load_cache https://binaries.avivagroup.com/artifactory/manga-generic-local/gradle/gradle/8.3/gradle-8.3-all.zip
load_cache https://binaries.avivagroup.com/artifactory/manga-generic-local/ExpoGo/Android/2.30.11/Exponent-2.30.11.apk
load_cache https://binaries.avivagroup.com/artifactory/manga-generic-local/ExpoGo/iOS/2.30.10/Exponent-2.30.10.tar.gz

# Set up Ruby -> AF
cat >~/.gemrc <<EOF
---
:backtrace: false
:bulk_threshold: 1000
:sources:
- https://${DOMAIN_ID}:${ARTIFACTORY_JWT}@binaries.avivagroup.com/artifactory/api/gems/manga-gems-remote/
:update_sources: true
:verbose: true
:concurrent_downloads: 8
EOF

# Set up rbenv
export PATH=~/.rbenv/shims:${PATH+:$PATH}

# Unset proxys for next steps
unset all_proxy http_proxy https_proxy ALL_PROXY HTTP_PROXY HTTPS_PROXY

# Clear homebrew cocoapods
if [ -f "/opt/homebrew/bin/pod" ]; then
  echo "Cleaning brew's Cocoapods and forcing Gem one."
  su - $ADMIN -c "cd /opt; HOMEBREW_NO_AUTO_UPDATE=1 HOMEBREW_ARTIFACT_DOMAIN=https://binaries.avivagroup.com/artifactory/manga-homebrew-docker-remote/ HOMEBREW_DOCKER_REGISTRY_TOKEN=$ARTIFACTORY_JWT /opt/homebrew/bin/brew uninstall cocoapods"
else
  echo "No homebrew based pod found"
fi

# Install/update Gems
if find "$(gem env gemdir)" -user root | grep -q .; then
  $alt_admin && su $ADMIN -c "sudo chown -R -H -L $ME $(gem env gemdir)" || sudo chown -R -H -L $ME $(gem env gemdir)
fi

gem install cocoapods xcodeproj claide colored2 activesupport

if gem list cocoapods-art | grep -q cocoapods-art; then
  gem uninstall cocoapods-art --all
fi
if [ -d ~/.cocoapods/repos-art ]; then
  echo "Removing old Cocoapods repo...please be patient, this may take a while."
  rm -Rf ~/.cocoapods/repos-art
fi
if ~/.rbenv/shims/pod repo list | grep -q manga-cocoapods-local; then
  echo Cocoapods set up correctly
else
  pod repo add-cdn manga-cocoapods-local https://binaries.avivagroup.com/artifactory/manga-cocoapods-local/
fi
if pod repo list | grep -q trunk; then
  pod repo remove trunk
fi

~/.rbenv/shims/pod repo update

# Set up npm/yarn -> AF
# ~/.nvm/versions/node/v18.12.1/bin/corepack enable
echo "strict-ssl=false" >~/.npmrc
echo "registry=https://binaries.avivagroup.com/artifactory/api/npm/manga-npm-virtual/" >>~/.npmrc
echo "email=$EMAIL" >>~/.npmrc
echo "always-auth=true" >>~/.npmrc
echo "noproxy=binaries.avivagroup.com" >>~/.npmrc
echo "//binaries.avivagroup.com/artifactory/api/npm/manga-npm-virtual/:_authToken=$ARTIFACTORY_JWT" >>~/.npmrc

echo 'registry "https://binaries.avivagroup.com/artifactory/api/npm/manga-npm-virtual/"' >~/.yarnrc
echo "disable-self-update-check true" >>~/.yarnrc
echo "strict-ssl false" >>~/.yarnrc

echo 'defaultSemverRangePrefix: ""' >~/.yarnrc.yml
echo 'enableHardenedMode: true' >>~/.yarnrc.yml
echo 'enableStrictSsl: false' >>~/.yarnrc.yml
echo 'enableTelemetry: false' >>~/.yarnrc.yml
echo 'npmAlwaysAuth: true' >>~/.yarnrc.yml
echo "npmAuthToken: \"$ARTIFACTORY_JWT\"" >>~/.yarnrc.yml
echo 'npmRegistryServer: "https://binaries.avivagroup.com/artifactory/api/npm/manga-npm-virtual/"' >>~/.yarnrc.yml
echo 'nodeLinker: "node-modules"' >>~/.yarnrc.yml
echo '' >>~/.yarnrc.yml

# Set up Gradle / Maven
mkdir -p /opt/gradleCache/wrapper/dists
rm -Rf ~/.gradle
ln -s /opt/gradleCache ~/.gradle
cp -n $manga_cache/gradle-7.5.1-all.zip /opt/gradleCache/wrapper/dists
cp -n $manga_cache/gradle-8.3-all.zip /opt/gradleCache/wrapper/dists
rm -f /opt/gradleCache/init.gradle
cat >/opt/gradleCache/init.gradle <<EOF
allprojects{
    repositories {
        all { ArtifactRepository repo ->
            // println repo.url.toString()
            if ((repo instanceof MavenArtifactRepository || repo instanceof IvyArtifactRepository) && repo.url.toString().startsWith("http") && !repo.url.toString().startsWith("https://binaries.avivagroup.com")) {
                // project.logger.warn "Repository \${repo.url} removed. Only Artifactory is allowed"
                remove repo
            }
        }
        maven {
            url "https://binaries.avivagroup.com/artifactory/manga-gradle-virtual/"
            credentials {
              username = "$DOMAIN_ID"
              password = "$ARTIFACTORY_JWT"
            }
            authentication {
              basic(BasicAuthentication)
            }
        }
    }
    buildscript {
      repositories {
          all {  ArtifactRepository repo ->
              if ((repo instanceof MavenArtifactRepository || repo instanceof IvyArtifactRepository) && repo.url.toString().startsWith("http") && !repo.url.toString().startsWith("https://binaries.avivagroup.com")) {
                  // project.logger.warn "- Repository \${repo.url} removed. Only Artifactory is allowed"
                  remove repo
              }
          }
          maven {
              url "https://binaries.avivagroup.com/artifactory/manga-gradle-virtual/"
              credentials {
                username = "$DOMAIN_ID"
                password = "$ARTIFACTORY_JWT"
              }
              authentication {
                basic(BasicAuthentication)
              }
          }
      }
    }
}
settingsEvaluated { settings ->
    settings.pluginManagement {
        repositories {
          maven {
              url "https://binaries.avivagroup.com/artifactory/manga-gradle-virtual/"
              credentials {
                username = "$DOMAIN_ID"
                password = "$ARTIFACTORY_JWT"
              }
              authentication {
                basic(BasicAuthentication)
              }
          }
        }
    }
}
EOF

echo OSX is $(sw_vers | grep ProductVersion | cut -d':' -f 2)
echo It needs to be at least 13.6

XCODE_VER=$(xcodebuild -version | grep Build | cut -d ' ' -f 3)
PWD=$(pwd)

$alt_admin && su $ADMIN -c "npm i -g yarn || true" || npm i -g yarn || true

if [ -f "/opt/homebrew/var/run/watchman/$ME-state/log" ]; then
  echo "Watchman permissions are fine, skipping."
else
  echo "Fixing watchman permissions"
  su $ADMIN -c "mkdir -p /opt/homebrew/var/run/watchman || true; sudo chown -R $ME /opt/homebrew/var/run/watchman"
fi

echo "Ignore any permission denied message here"
$alt_admin && su $ADMIN -c "find /opt/homebrew -name cacerts | sudo xargs -I {} cp cacerts {}" || find /opt/homebrew -name cacerts | sudo xargs -I {} cp cacerts {}

rm -rf $HOME/Library/Android/sdk/cmake/cmake-3.22.1-darwin

cp CertEmulationCA.crt $manga_home/CertEmulationCA.crt
export NODE_EXTRA_CA_CERTS=$manga_home/CertEmulationCA.crt
echo "export NODE_EXTRA_CA_CERTS=$manga_home/CertEmulationCA.crt" >>~/.zprofile

#Add cert file to any open simulators
for i in $(xcrun simctl list devices booted | sed -nE '/Booted/ s/.*\((.{36})\).\(Booted\).*/\1/p'); do
  xcrun simctl keychain "$i" add-root-cert $manga_home/CertEmulationCA.crt
done

# Update Android SDKs & Android Studio proxy
$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager --proxy=http --proxy_host=ep.threatpulse.net --proxy_port=80 --no_https "system-images;android-28;google_apis;arm64-v8a" "system-images;android-29;google_apis;arm64-v8a" "system-images;android-30;google_apis;arm64-v8a" "system-images;android-31;google_apis;arm64-v8a" "system-images;android-32;google_apis;arm64-v8a" "system-images;android-33;google_apis;arm64-v8a" "system-images;android-34;google_apis;arm64-v8a" "platforms;android-34" "ndk;25.1.8937393" "build-tools;33.0.1" "build-tools;33.0.3" "build-tools;34.0.0" "emulator" "cmdline-tools;13.0" "cmake;3.22.1" "platform-tools"
mkdir -p "$HOME/Library/Application Support/Google/AndroidStudio2024.1/options"
cp proxy.settings.xml "$HOME/Library/Application Support/Google/AndroidStudio2024.1/options/proxy.settings.xml"

# Enforce VSCode extentions
export https_proxy=$proxy
installed=$(code --list-extensions)
approved=$(awk 'NF {print $1}' vscode-extensions-approved.txt)
recommended=$(awk 'NF {print $1}' vscode-extensions-recommended.txt)

install=$(comm -13 <(echo "${installed}") <(printf "%s" "${recommended}" | sort))
remove=$(comm -23 <(echo "${installed}") <(printf "%s\n%s" "${approved}" "${recommended}" | sort))

if [ -n "$install" ]; then
  while IFS= read -r extension; do
    code --install-extension "$extension" --force
  done <<<"$install"
fi

if [ -n "$remove" ]; then
  print -P "%F{red}VSCode extension checker is in 'dry run' mode:\n%f"
  while IFS= read -r extension; do
    #    code --uninstall-extension "$extension"
    print -P "%F{red}* $extension would have been removed. Contact Solar if you need to keep it\n%f"
  done <<<"$remove"
fi
