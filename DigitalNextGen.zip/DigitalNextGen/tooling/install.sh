#!/bin/zsh
readonly version=1.6.2
readonly proxy_host=$(scutil --proxy | grep 'HTTPSProxy' | sed 's/.*HTTPSProxy : \(.*\)/\1/')
readonly proxy_port=$(scutil --proxy | grep 'HTTPSPort' | sed 's/.*HTTPSPort : \(.*\)/\1/')
readonly proxy="http://"$proxy_host":"$proxy_port
readonly noproxy=avivagroup.com,avivacloud.com,rwy-aviva.co.uk
readonly osx_min_version=14.0

script_dir="$(dirname $(realpath $0))"
cd $script_dir

print -P "%F{yellow}Version $version\n\nThis script assumes that a) this account has sudo access, b) you're using the WSS client, c) you're on the VPN and d) your Artifactory access is correct. We'll do a quick check to validate that, but if any of those aren't true you'll need to get that fixed before re-running.%f\n"

osx_version="$(sw_vers --productVersion)"
if printf "${osx_version}\n${osx_min_version}\n" | sort -V -C; then
  print -P "%F{red}OSX is ${osx_version}. It needs to be at least ${osx_min_version}. Please upgrade and rerun the script.%f\n"
  exit 1
else
  print -P "%F{green}OSX version is ${osx_version}%f\n"
fi

export ME=$(whoami)
if [ "$(id | grep '80(admin)')" != "" ]; then
  print -P "%F{green}You have sudo access...%f\n"
else
  print -P "%F{red}You DON'T have sudo access. You'll need to talk to IT about getting that changed.%f\n"
  exit 1
fi

if [ "$(scutil --proxy | grep threat)" != "" ]; then
  print -P "%F{green}You are using the WSS proxy...%f\n"
else
  print -P "%F{red}You AREN'T using the WSS proxy. You'll need to talk to IT about getting that changed.%f\n"
  exit 1
fi

if curl https://binaries.avivagroup.com >/dev/null 2>&1; then
  print -P "%F{green}Able to connect to Artifactory...%f\n"
else
  print -P "%F{red}Unable to connect to Artifactory. You're probably not on the VPN.%f\n"
  exit 1
fi

if curl -Is google.com | grep -iq "saml.threatpulse.net"; then
  print -P "%F{red}WSS hasn't been authenticated. Please browse to somewhere nice...%f\n"
  exit 1
fi

export DOMAIN_ID=$(security dump-keychain | grep -oE "login_name\": \".*@" | grep -v "LEEFEA" | sort | tail -n 1 | sed -E "s/login_name\": \"(.*)@/\1/g")
if [[ -z "$DOMAIN_ID" ]]; then
  print -P '%F{yellow}What is your RAFID?%f: '
  read DOMAIN_ID
fi

MYGROUPS=$(id $DOMAIN_ID | sed 's/,/\n/g')
if [ $(echo $MYGROUPS | grep -c "PSG_UK_CISO_DEVELOPERS") -gt 0 ]; then
  print -P "%F{green}Group check: in PSG_UK_CISO_DEVELOPERS (Access to github, etc)%f\n"
else
  print -P "%F{red}Group check: NOT in PSG_UK_CISO_DEVELOPERS (Access to github, etc), the script will fail without it. Raise an ITSS request to fix it.%f\n"
  exit 1
fi
if [ $(echo $MYGROUPS | grep -c "manga_artifactory") -gt 0 ]; then
  print -P "%F{green}Group check: in rol_se_manga_artifactory_users (Access to Artifactory)%f\n"
else
  print -P "%F{red}Group check: NOT in rol_se_manga_artifactory_users (Access to Artifactory), the script will fail without it. Raise an ITSS request to fix it.%f\n"
  exit 1
fi
if [ $(echo $MYGROUPS | grep -c "AVDigRepo") -gt 0 ]; then
  print -P "%F{green}Group check: in ACC_ACS_Wealth_UI_VSTS_AVDigRepo_Developer (Access to Azure DevOps)%f\n"
else
  print -P "%F{orange}Group check: NOT in ACC_ACS_Wealth_UI_VSTS_AVDigRepo_Developer (Access to Azure DevOps), the script will continue but you will need this fixed to be able to work. Raise an ITSS request to fix it.%f\n"
fi
if [ $(echo $MYGROUPS | grep -c "myavivanextgen_jira") -gt 0 ]; then
  print -P "%F{green}Group check: in rol_se_digital_myavivanextgen_jira_user (Access to Jira)%f\n"
else
  print -P "%F{orange}Group check: NOT in rol_se_digital_myavivanextgen_jira_user (Access to Jira), the script will continue but you will need this fixed to be able to work. Raise an ITSS request to fix it.%f\n"
fi
if [ $(echo $MYGROUPS | grep -c "myavivanextgen_confluence") -gt 0 ]; then
  print -P "%F{green}Group check: in rol_se_digital_myavivanextgen_confluence_user (Access to Confluence)%f\n"
else
  print -P "%F{orange}Group check: NOT in rol_se_digital_myavivanextgen_confluence_user (Access to Confluence), the script will continue but you will need this fixed to be able to work. Raise an ITSS request to fix it.%f\n"
fi
if [[ -n "$1" ]]; then # People with more than 1 RAFID need to specify as a param to the script
  export DOMAIN_ID=$1
  print -P "%F{green}Took $DOMAIN_ID as your RAFID. If this is wrong then provide it as a parameter to the script.%f\n"
fi
export DOMAIN_ID=$(ECHO $DOMAIN_ID | tr '[:upper:]' '[:lower:]') #ID needs to be lower case for artifactory to work

if [ "$(networksetup -getsecurewebproxy "Wi-fi" | grep ukdmz)" != "" ]; then
  print -P "%F{yellow}You still have the CIA proxy in networksetup. Speak to IT about having it removed. It won't stop the install, but may cause the Sim to behave weirdly. We'll try and disable it now, but it may fail due to permissions.%f\n"
  networksetup -setsecurewebproxy "Wi-Fi" ""
  networksetup -setautoproxyurl "Wi-Fi" ""
  networksetup -setsecurewebproxystate "Wi-fi" off
fi

#remove any proxy from .curlrc
if [ -f $HOME/.curlrc ]; then sed -i '' -E '/^proxy=.*/d' $HOME/.curlrc; fi

git config --global http.proxy $proxy
export http_proxy=$proxy
export https_proxy=$proxy
export ALL_PROXY=$proxy
export no_proxy=$noproxy

export HOMEBREW_INSTALL_SCRIPT=$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)
if [ $(echo $HOMEBREW_INSTALL_SCRIPT | grep -c "Microsoft") -gt 0 ]; then
  print -P "%F{red}WSS isn't authorised. Go to github.com in Chrome, then run this script again.%f\n"
  exit 1
fi
export HOMEBREW_INSTALL_SCRIPT=$(cat brew.sh) #Install even if raw.githubusercontent.com is blocked

print -P "%F{yellow}Enter your network (avivagroup) password (NOT your Mac password)%f\n"
export ARTIFACTORY_JWT=$(curl -u ${DOMAIN_ID} -X POST "https://binaries.avivagroup.com/artifactory/api/security/token" -d "username=${DOMAIN_ID}" -d "expires_in=604800" | grep access_token | cut -d '"' -f 4)
if [ "$ARTIFACTORY_JWT" != "" ]; then
  print -P "%F{green}Logged into Artifactory...%f\n"
else
  print -P "%F{red}Artifactory login failed. There are 3 possibilities: a) you typed your password wrong, b) your account is locked or c) you don't have access to Artifactory (you'll need to raise an ITSS request for this). You can log directly into https://binaries.avivagroup.com to check.%f\n"
  exit 1
fi

print -P "%F{green}Testing sudo. Enter your local account password...%f\n"
sudo echo
if [ $? -eq 1 ]; then
  print -P "%F{red}sudo failed. We've already checked that you're in the right group, so you must have got your password wrong.%f\n"
  exit 1
else
  print -P "%F{green}sudo works...%f\n"
fi

print -P "%F{green}Installing homebrew...%f\n"
export HOMEBREW_NO_AUTO_UPDATE=1
export HOMEBREW_ARTIFACT_DOMAIN=https://binaries.avivagroup.com/artifactory/manga-homebrew-docker-remote/
export HOMEBREW_DOCKER_REGISTRY_TOKEN=$ARTIFACTORY_JWT
export EMAIL=$(dscl "/Active Directory/AVIVAGROUP/All Domains" read "/Users/$DOMAIN_ID" | grep EMailAddress | cut -d ' ' -f 2)
NONINTERACTIVE=1 /bin/bash -c "$HOMEBREW_INSTALL_SCRIPT"
eval "$(/opt/homebrew/bin/brew shellenv)"

# Set up Ruby -> AF. We will need this later.
cat >~/.gemrc <<EOF
---
:backtrace: false
:bulk_threshold: 1000
:sources:
- https://${DOMAIN_ID}:${ARTIFACTORY_JWT}@binaries.avivagroup.com/artifactory/api/gems/manga-gems-remote/
:update_sources: true
:verbose: true
:concurrent_downloads: 8
EOF

# It's possible for XCode to refuse to install (especially on a VPN), so we can force it in this way.
print -P "%F{green}Setting up Xcode...%f\n"
if [ -f "/tmp/Xcode.xip" ]; then
  print -P "%F{green}Already have xcode CLT downloaded, using that...%f\n"
else
  print -P "%F{green}Downloading Xcode CLT...%f\n"
  curl -u${DOMAIN_ID}:${ARTIFACTORY_JWT} -fsSL https://binaries.avivagroup.com/artifactory/manga-generic-local/Apple/command-line-tools-for-xcode/15.3/Command_Line_Tools_for_Xcode_15.3.dmg -o /tmp/Xcode-cmd.dmg
fi

hdiutil attach /tmp/Xcode-cmd.dmg
sudo installer -pkg /Volumes/Command\ Line\ Developer\ Tools/Command\ Line\ Tools.pkg -target /
umount /Volumes/Command\ Line\ Developer\ Tools

if [ -f "/tmp/Xcode.xip" ]; then
  print -P "%F{green}Already have xcode downloaded, using that...%f\n"
else
  print -P "%F{green}Downloading Xcode...%f\n"
  XCODE_VER=$(curl -u${DOMAIN_ID}:${ARTIFACTORY_JWT} -fsSL https://binaries.avivagroup.com/artifactory/manga-generic-local/Apple/xcode/latest)
  curl -u${DOMAIN_ID}:${ARTIFACTORY_JWT} -fsSL https://binaries.avivagroup.com/artifactory/manga-generic-local/Apple/xcode/${XCODE_VER}/Xcode_${XCODE_VER}.xip -o /tmp/Xcode.xip
fi
pushd
cd /tmp
xip --expand Xcode.xip
sudo mv Xcode.app /Applications
popd

print -P "%F{green}Setting up iOS Simulator...%f\n"
if [ -f "/tmp/iOS_Simulator_Runtime.dmg" ]; then
  print -P "%F{green}Already have the simulator downloaded, using that...%f\n"
else
  print -P "%F{green}Downloading iOS Simulator...%f\n"
  SIM_VER=17.4
  #SIM_VER=$(curl -u${DOMAIN_ID}:${ARTIFACTORY_JWT} -fsSL https://binaries.avivagroup.com/artifactory/manga-generic-local/Apple/ios-sim/latest)
  curl -u${DOMAIN_ID}:${ARTIFACTORY_JWT} -fsSL https://binaries.avivagroup.com/artifactory/manga-generic-local/Apple/ios-sim/iOS_${SIM_VER}_Simulator_Runtime.dmg -o /tmp/iOS_Simulator_Runtime.dmg
fi
xcrun simctl runtime delete all
xcrun simctl runtime add "/tmp/iOS_Simulator_Runtime.dmg"
xcrun simctl create iPhone15 com.apple.CoreSimulator.SimDeviceType.iPhone-15-Pro com.apple.CoreSimulator.SimRuntime.iOS-17-4
xcrun simctl boot iPhone15
xcrun simctl keychain iPhone15 add-root-cert CertEmulationCA.crt

# Install everything else. Make sure we're not using the wrong java.
/opt/homebrew/bin/brew update
/opt/homebrew/bin/brew bundle -f
sudo ln -sfn /opt/homebrew/opt/openjdk@17/libexec/openjdk.jdk /Library/Java/JavaVirtualMachines/openjdk-17.jdk
xattr -d com.apple.quarantine /Applications/Flipper.app

export JAVA_HOME=$(ls -d /opt/homebrew/Cellar/openjdk@17/* | sort --version-sort -r | head -n 1)

find /opt/homebrew -name cacerts | sudo xargs -I {} cp cacerts {}

print -P "%F{green}Setting up Android Emulator...%f\n"
# sdkmanager uses Java which ignores proxy config. Setting no_https avoids cert errors.
/opt/homebrew/bin/sdkmanager --proxy=http --proxy_host=ep.threatpulse.net --proxy_port=80 --no_https "system-images;android-28;google_apis;arm64-v8a" "system-images;android-29;google_apis;arm64-v8a" "system-images;android-30;google_apis;arm64-v8a" "system-images;android-31;google_apis;arm64-v8a" "system-images;android-32;google_apis;arm64-v8a" "system-images;android-33;google_apis;arm64-v8a" "system-images;android-34;google_apis;arm64-v8a" "platforms;android-34" "ndk;25.1.8937393" "build-tools;33.0.1" "build-tools;33.0.3" "build-tools;34.0.0" "emulator" "cmdline-tools;13.0" "cmake;3.22.1" "platform-tools"
/opt/homebrew/bin/avdmanager create avd -n "Pixel_6_API_28" -d "pixel_6" -k "system-images;android-28;google_apis;arm64-v8a"
/opt/homebrew/bin/avdmanager create avd -n "Pixel_6_API_29" -d "pixel_6" -k "system-images;android-29;google_apis;arm64-v8a"
/opt/homebrew/bin/avdmanager create avd -n "Pixel_6_API_30" -d "pixel_6" -k "system-images;android-30;google_apis;arm64-v8a"
/opt/homebrew/bin/avdmanager create avd -n "Pixel_6_API_31" -d "pixel_6" -k "system-images;android-31;google_apis;arm64-v8a"
/opt/homebrew/bin/avdmanager create avd -n "Pixel_6_API_32" -d "pixel_6" -k "system-images;android-32;google_apis;arm64-v8a"
/opt/homebrew/bin/avdmanager create avd -n "Pixel_6_API_33" -d "pixel_6" -k "system-images;android-33;google_apis;arm64-v8a"
/opt/homebrew/bin/avdmanager create avd -n "Pixel_6_API_34" -d "pixel_6" -k "system-images;android-34;google_apis;arm64-v8a"

print -P "%F{green}Setting up Node...%f\n"
mkdir ~/.nvm
. /opt/homebrew/opt/nvm/nvm.sh
nvm install lts/hydrogen
nvm use lts/hydrogen

# We may want to drop off the VPN at this point.
print -P "%F{green}Setting up Ruby...%f\n"

mkdir -p "${HOME}/.rbenv/cache"
curl -f -H "Authorization: Bearer ${ARTIFACTORY_JWT}" -o "${HOME}/.rbenv/cache/ruby-3.3.0.tar.gz" "https://binaries.avivagroup.com/artifactory/manga-generic-local/ruby/ruby/3.3.0/ruby-3.3.0.tar.gz"

rbenv install 3.3.0
rbenv global 3.3.0
export PATH="$HOME/.rbenv/shims:${PATH}"
touch $HOME/.rbenv/.and

print -P "%F{green}Setting up Cocoapods... (this may take a while)%f\n"
gem install cocoapods xcodeproj claide colored2 activesupport

cat >~/.netrc <<EOF
machine binaries.avivagroup.com
localhost ${DOMAIN_ID}
password ${ARTIFACTORY_JWT}
EOF
chmod 0600 ~/.netrc

~/.rbenv/shims/pod repo remove trunk --silent >/dev/null 2>&1 || true
#~/.rbenv/shims/pod repo add-cdn manga-cocapods-remote https://binaries.avivagroup.com/artifactory/manga-cocapods-remote/
~/.rbenv/shims/pod repo add-cdn manga-cocoapods-local https://binaries.avivagroup.com/artifactory/manga-cocoapods-local/
~/.rbenv/shims/pod repo update || true

sudo mkdir /opt/gradleCache && sudo chown $ME /opt/gradleCache

# This works fine if we're _not_ on the VPN
#print -P "%F{green}Making sure everything else is up to date...%f\n"
#softwareupdate --all --install --force

print -P "%F{green}All done! You should probably reboot your laptop now, and then run af.sh to update the tokens.%f\n"

#print -P "%F{yellow}We're going to start up Xcode to install a few more things. You will need to create or login to your AppleID as $EMAIL. Do NOT use a personal AppleID!%f\n"
sudo xcode-select -s /Applications/Xcode.app
#xcodebuild -runFirstLaunch
