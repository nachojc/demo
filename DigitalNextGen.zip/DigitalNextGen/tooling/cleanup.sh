#!/bin/zsh
print -P "%F{red}This script will clean out all of the installed programs ready for a clean reinstall. If this isn't what you want, hit Control-C now!%f\n"

# ~ doesn't always expand in scripts, so we need to use $HOME
ME=$(whoami)

sec=10
while [ $sec -ge 0 ]; do
        echo -ne "$sec\033[0K\r"
        let "sec=sec-1"
        sleep 1
done

print -P "%F{yellow}You will need to enter your local password.%f\n"
print -P "%F{green}Removing apps, this may take a while...%f\n"
# Touch a few files so that even if the dir is currently empty, the rm works
sudo touch /Library/Java/JavaVirtualMachines/dummy /Library/Ruby/Gems/dummy /opt/homebrew-dummy

for i in /Applications/Android\ Studio.app /Applications/Docker.app /Applications/Flipper.app /Applications/Postman.app /Applications/Reactotron.app /Applications/Sourcetree.app /Applications/Visual\ Studio\ Code.app /Applications/Visual\ Studio.app /Applications/Xcode.app $HOME/Applications/ $HOME/Library/Android /Library/Java/JavaVirtualMachines/*; do
  print -P "%F{blue}* $i%f\n"
  sudo rm -Rf $i
done
print -P "%F{green}Cleaning out homebrew...%f\n"
# Sometimes you'll get /opt/homebrew2, etc
for i in /opt/homebrew*; do
  print -P "%F{blue}* $i%f\n"
  sudo rm -Rf $i
done
#find /opt -name 'homebrew*' | sudo xargs -I {} rm -Rf {}
print -P "%F{green}Cleaning out the gradle cache...%f\n"
sudo rm -Rf /opt/gradleCache || true
sudo mkdir /opt/gradleCache && sudo chown $ME /opt/gradleCache
print -P "%F{green}Cleaning out user caches...%f\n"
for i in /Library/Ruby/Gems/* $HOME/.android $HOME/.cocoapods $HOME/.expo $HOME/.gem $HOME/.gemrc $HOME/.gradle $HOME/.npm $HOME/.rpmrc $HOME/.nvm $HOME/.rbenv $HOME/.vscode $HOME/.yarn $HOME/.yarnrc $HOME/Library/Caches/CocoaPods/ $HOME/Library/Caches/Homebrew/ $HOME/Library/Developer $HOME/.netrc $HOME/.zprofile; do
  print -P "%F{blue}* $i%f\n"
  sudo rm -Rf $i
done
print -P "%F{green}All done. Now run install.sh%f\n"
