#!/bin/bash
readonly script_version=0.2
readonly repo=https://binaries.avivagroup.com/artifactory/manga-cocoapods-local

opt_dry_run=false
opt_force=false
shard_hash=

while [[ $# -gt 0 ]]; do
    case $1 in
    -d | --dry-run)
        opt_dry_run=true
        shift
        ;;
    -f | --force)
        opt_force=true
        shift
        ;;
    -s | --shard)
        shard_hash=${2:-}
        if [[ ${#shard_hash} -lt 3 ]]; then
            printf "Barf: Shard hash (min 3 digits) must be provided when using --shard\n"
            exit 0
        fi
        shift
        shift
        ;;
    -v | --version)
        printf "Version: %s\n" $script_version
        exit 0
        ;;
    -h | --help)
        printf "\nUsage: %s podname [<args>]
    [-d | --dry-run]            Files aren't pushed to Artifactory
    [-f | --force]              Files are pushed to Artifactory even if they already exist
    [-s | --shard] hash         Store the given shard file locally to assist with debugging
    [-v | --version]            Display version
    [-h | --help]               Display this help\n\n" "$(basename "$0")"

        exit 0
        ;;
    -*)
        echo "Barf: Unknown option $1"
        exit 1
        ;;
    *)
        positional_args+="$1"
        shift
        ;;
    esac
done

# shellcheck disable=SC2086
set -- ${positional_args}

if $opt_dry_run && $opt_force; then
    printf "Barf: You can't force a dry run!\n"
    exit 1
fi

if curl -Is google.com | grep -iq "saml.threatpulse.net"; then
    printf "Barf: WSS hasn't been authenticated. Please browse to somewhere nice...\n"
    exit 1
fi

if [[ -n "$shard_hash" ]]; then
    shard_index="${shard_hash:0:1}_${shard_hash:1:1}_${shard_hash:2:1}"
    shard_file="all_pods_versions_$shard_index.txt"
    if curl -fsSL --compressed "https://cdn.cocoapods.org/$shard_file" -o "$HOME/.cocoapods/repos/manga-cocoapods-local/$shard_file"; then
        printf "%s downloaded to local repo. It contains:\n" "$shard_file"
        sed -E 's/([^\/]*).*/\1/' "$HOME/.cocoapods/repos/manga-cocoapods-local/$shard_file"
        exit 0
    else
        printf "Barf: %s download failed\n" "$shard_file"
        exit 1
    fi
fi

pod_name=${1:-}

if [[ -z "$pod_name" ]]; then
    printf "Barf: podname must be specified\n"
    exit 1
fi

shard_hash=$(md5 -qs "$pod_name")
shard_index="${shard_hash:0:1}_${shard_hash:1:1}_${shard_hash:2:1}"
shard_path=${shard_index//_/\/}
shard_file="all_pods_versions_$shard_index.txt"
temp_file=$(mktemp -t "$shard_file")
printf "\nPod name        : %s
Shard index     : %s
Dry run         : %s
Force           : %s\n\n" "$pod_name" "$shard_index" "$opt_dry_run" "$opt_force"

if ! curl -fsSL --compressed "https://cdn.cocoapods.org/$shard_file" -o "$temp_file"; then
    printf "Barf: %s download failed\n" "$shard_file"
    exit 1
fi

if ! grep -q "$pod_name/" "$temp_file"; then
    printf "Barf: %s cannot be found in %s\n" "$pod_name" "$shard_file"
    exit 1
fi

if ! $opt_dry_run; then
    if ! curl -fsSL -H "Authorization: Bearer ${ARTIFACTORY_JWT}" -XPUT "$repo/$shard_file" -T "$temp_file"; then
        printf "Barf: %s upload to AF failed\n" "$shard_file"
        exit 1
    fi
fi
versions=$(grep "$pod_name/" "$temp_file" | sed 's/\//\n/g' | tail -n +2 | sort -V)

for version in $versions; do
    spec_path="Specs/$shard_path/$pod_name/$version/$pod_name.podspec.json"
    if ! $opt_force && curl -fsLI -o /dev/null -H "Authorization: Bearer ${ARTIFACTORY_JWT}" "$repo/$spec_path"; then
        printf "Podspec version %s already in Artifactory\n" "$version"
    else
        printf "Downloading Podspec version %s\n" "$version"
        temp_file=$(mktemp -t "$pod_name.podspec.json")
        if ! curl -fsSL "https://cdn.cocoapods.org/$spec_path" -o "$temp_file"; then
            printf "Barf: version %s download failed\n" "$version"
            exit 1
        fi
        if ! $opt_dry_run; then
            if ! curl -fsSL -H "Authorization: Bearer ${ARTIFACTORY_JWT}" -XPUT "$repo/$spec_path" -T "$temp_file"; then
                printf "Barf: version %s upload failed\n" "$version"
                exit 1
            fi
        fi
    fi
done
