# Ticket

This pull request completes the following ticket(s):

<https://jira.aviva.co.uk/browse/MANGA-xxx>

# Description

Please provide a description of your pull request

# Screenshots

Please insert screenshots of changes below:

|             Old design              |             New design              |
| :---------------------------------: | :---------------------------------: |
| <img src="file_name" width="300" /> | <img src="file_name" width="300" /> |

## Type of changes

[//]: # 'What types of changes does you code introduce'
[//]: # '_Put an `x`` in the boxes that apply_'

- [ ] I have tested my changes on iOS and Android.
- [ ] I hide my changes behind a feature flag, or they don't need one.
- [ ] I have included screenshots or videos, or I have not changed the UI.
- [ ] I have added tests, or my changes don't require any.
- [ ] I would like at least one of the reviewers to run this PR on the simulator or device.
- [ ] I have checked this change doesn't require regression testing.
- [ ] I have not affected current accessibility or automation.
