import { Config } from 'jest';

const config: Config = {
  preset: 'jest-expo',
  setupFilesAfterEnv: [
    '@testing-library/jest-native/extend-expect',
    './src/jest/jest.setup.js',
    './src/jest/jest.reanimated.setup.js',
  ],
  transformIgnorePatterns: [
    'node_modules/(?!((jest-)?react-native|@react-native(-community)?)|expo(nent)?|@expo(nent)?/.*|@expo-google-fonts/.*|react-navigation|@react-navigation/.*|@unimodules/.*|unimodules|sentry-expo|native-base|react-native-svg|react-native-date-picker|@onfido|decode-uri-component|@tamagui/animations-moti|moti|@launchdarkly/.*)',
  ],
  moduleNameMapper: {
    '\\.svg': '<rootDir>/src/jest/svg-mock.js',
    'react-native-webview':
      '<rootDir>/node_modules/react-native-webview/src/index.ts',
  },
  transform: {
    '\\.[jt]sx?$': 'babel-jest',
  },
  testTimeout: 10000,
  coverageReporters: ['json', 'lcov', 'text', 'clover', 'cobertura'],
  reporters: ['default', 'jest-junit', 'jest-ado-reporter'],
  collectCoverageFrom: [
    'src/**/*.(ts|tsx)',
    'products/**/*.(ts|tsx)',
    'packages/ion-mobile/**/*.(ts|tsx)',
  ],
  coveragePathIgnorePatterns: [
    '<rootDir>/src/features/dev-mode/', // no tests for dev-only dev-mode are expected
    '<rootDir>/src/jest/', // no need to collect testcoverage for Jest configuration
    '<rootDir>/src/api-mock/', // no need to collect test coverage for API mocks
    '<rootDir>/src/common/fonts/', // simple import maps - no need for test coverage
  ],
  cacheDirectory: '.jest-cache',
  workerIdleMemoryLimit: '512MB',
};

export default config;
