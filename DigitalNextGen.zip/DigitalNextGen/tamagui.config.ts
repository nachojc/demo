import { animations } from '@theme/animations';
import { fonts } from '@theme/fonts';
import { media } from '@theme/media';
import { shorthands } from '@theme/shorthands';
import { themes } from '@theme/themes';
import { tokens } from '@theme/tokens';
/**
 * This will be move to ion-mobile when this is extracted to its own package,
 * removing it now crashes the app
 */
// eslint-disable-next-line no-restricted-imports
import { createTamagui as createIonMobile } from 'tamagui';

const config = createIonMobile({
  animations,
  fonts,
  media,
  shorthands,
  shouldAddPrefersColorThemes: false,
  themeClassNameOnRoot: false,
  themes,
  tokens,
});

export type AppConfig = typeof config;

declare module 'tamagui' {
  interface TamaguiCustomConfig extends AppConfig {
    /**
     * Overrides TamaguiCustomConfig so your custom types work everywhere you
     * import `tamagui`
     */
  }
}

export default config;
