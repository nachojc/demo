#!/bin/bash

# Check if necessary arguments are provided
if [ $# -lt 3 ]; then
  echo "Usage: $0 <target_branch1> <target_branch2> <since_date> <optional_prefix>"
  echo "Example: $0 branch1 branch2 2022-01-01"
  echo "With prefix: $0 branch1 branch2 2022-01-01 MANGA"
  exit 1
fi

# Target branches
target_branch1=$1
target_branch2=$2
since_date=$3
prefix=${4:-MANGA}

extract_branches() {
  git log --graph --since=$2 --until="$(date +'%Y-%m-%d %H:%M:%S')" --pretty=format:"%s" $1 | grep -i -Eo "${prefix}-[0-9]+" | awk '{print "https://jira.aviva.co.uk/browse/" $0}' | sort | uniq
}

# Function to find the date of the first commit that is unique to the branch
branch_creation_date() {
  git log --reverse --pretty=format:"%cd" --date=short $1 ^develop | head -n 1
}

sync_branch() {
  git checkout $1
  git pull origin $1
}

current_branch=$(git rev-parse --abbrev-ref HEAD)
sync_branch $target_branch1
sync_branch $target_branch2
sync_branch $current_branch

git checkout $current_branch

echo "Analyzing branches..."
echo "---------------------"
echo "Target branch 1: $target_branch1"
echo "Target branch 2: $target_branch2"
echo "Since date: $since_date"
echo "Prefix: $prefix"
echo "---------------------"

echo "First unique commit date for $target_branch1: $(branch_creation_date $target_branch1)"
echo "First unique commit date for $target_branch2: $(branch_creation_date $target_branch2)"

# Extract branch names
branches1=$(extract_branches $target_branch1 $since_date)
branches2=$(extract_branches $target_branch2 $since_date)

echo "---------------------"
echo "Branches merged into $target_branch1 since $since_date:"
echo "$branches1"
echo "---------------------"
echo "Branches merged into $target_branch2 since $since_date:"
echo "$branches2"
echo "---------------------"

# Save branch names to temporary files
echo "$branches1" > /tmp/branches1.txt
echo "$branches2" > /tmp/branches2.txt

# Sort the files
sort /tmp/branches1.txt -o /tmp/branches1.txt
sort /tmp/branches2.txt -o /tmp/branches2.txt

# Compare the files
echo "Branches merged into $target_branch1 but not into $target_branch2 since $since_date:"
comm -23 /tmp/branches1.txt /tmp/branches2.txt
echo "---------------------"
echo "Branches merged into $target_branch2 but not into $target_branch1 since $since_date:"
comm -13 /tmp/branches1.txt /tmp/branches2.txt
echo "---------------------"

echo "Analysis complete."