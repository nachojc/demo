#!/bin/bash

INPUT_OPENAPI_FILE="./src/api/open-api/MobileApi.json"
GENERATED_DIR="./src/api/generated"
CLIENT="./src/api/adapter/request.ts"

# Remove old generated files
rm -rf $GENERATED_DIR
mkdir -p $GENERATED_DIR/queries $GENERATED_DIR/requests/core

# Generate the new code
node_modules/.bin/openapi-rq --input $INPUT_OPENAPI_FILE --output $GENERATED_DIR --request $CLIENT

# Patch the broken enums in swagger
cp ./scripts/codegen-patches/requests/models/* $GENERATED_DIR/requests/models

touch $GENERATED_DIR/queries/index.ts $GENERATED_DIR/requests/core/request.ts

# Skip typescript and eslint checks for generated files
sed -i.bak -e '1 i\
// @ts-nocheck \
/\* eslint-disable \*/' $GENERATED_DIR/queries/index.ts

sed -i.bak -e '1 i\
// @ts-nocheck \
/\* eslint-disable \*/' $GENERATED_DIR/requests/core/request.ts
