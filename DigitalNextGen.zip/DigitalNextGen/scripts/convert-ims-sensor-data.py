#!/usr/bin/env python3

import csv
from datetime import datetime
import math
import re
import json
import os
import sys

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_DIR_REL = 'src/api-mock/responses/MyDrive/TripSimulation'
OUTPUT_FILENAME_PATTERN = 'trip-ims-{date}_{dur}.json'

def to_float(s, default = None):
  try:
    return float(s)
  except ValueError:
    return default

def parse_date(s):
  return datetime.strptime(s[:-3], "%d/%m/%Y %H.%M.%S.%f")

def date_to_millis(s):
  d = parse_date(s)
  t = d.timestamp()
  return int(t * 1000)

def transform(dict, prop_map):
  ret = {}
  for key, new_key in prop_map.items():
    value = dict.get(key)
    if isinstance(new_key, tuple):
      name, transform = new_key
      ret[name] = transform(value)
    else:
      ret[new_key] = value
  return ret

def bearing_to_magetic_fields(bearing):
  mag_cal_x = -20 * math.sin(bearing)
  mag_cal_y = -40
  mag_cal_z = -20 * math.cos(bearing)
  mag_x = mag_cal_x - 200
  mag_y = mag_cal_y + 80
  mag_z = mag_cal_z - 300
  return mag_x, mag_y, mag_z

def describe_duration(ms):
  t = ms
  t //= 1000 # ms -> seconds
  seconds = t % 60

  t //= 60 # seconds -> minutes
  minutes = t % 60

  t = t // 60 # minutes -> hours
  hours = t

  if hours > 0:
    return f"{hours}h {minutes}m {seconds}s"
  elif minutes > 0:
    return f"{minutes}m {seconds}s"
  else:
    return f"{seconds}s"


def read_trips(input_file):
  trips = []
  trip = []
  last_trip = None
  start_dates = {}

  def push_trip(trip_id, trip):
    d0 = trip[0]
    d1 = trip[-1]
    duration = d1["ts"] - d0["ts"]
    date = start_dates[trip_id]
    name = f"IMS {date.strftime('%d/%m/%Y %H:%M')} - {describe_duration(duration)}"

    trips.append({
      "meta": {
        "id": trip_id,
        "startDate": int(date.timestamp() * 1000),
        "duration": duration,
        "name": name
      },
      "data": trip
    })
    trip = []

  with open(input_file, mode='r', encoding='utf-8') as file:
    reader = csv.reader(file)
    headers = next(reader)
    for row in reader:
      trip_dict = {key: value for key, value in zip(headers, row)}

      trip_id = trip_dict['TRIPSUMMARYID'] # a uuid string
      start_date = parse_date(trip_dict['UTCSTARTDATETIME'])
      ori_x = to_float(trip_dict['X_PHONE'], 0)
      ori_y = to_float(trip_dict['Y_PHONE'], 0)
      ori_z = to_float(trip_dict['Z_PHONE'], 0)
      h_accuracy = to_float(trip_dict['HORIZONTALACCURACY'], 0)
      v_accuracy = to_float(trip_dict['VERTICALACCURACY'], 0)
      date = date_to_millis(trip_dict['UTCDATETIME']) # e.g. 11/03/2024 13.17.47.000000000
      lat = to_float(trip_dict['DEGREESLATITUDE'], None)
      lng = to_float(trip_dict['DEGREESLONGITUDE'], None)
      speed = to_float(trip_dict['SPEED'], 0) / 3.6 # convert value from km per hour to meters per second
      course = to_float(trip_dict['HEADINGDEGREES'], 0)
      mag_x, mag_y, mag_z = bearing_to_magetic_fields(math.radians(course)) # simulate the magnetic fields

      # ignore data point without a location
      if lat is None or lng is None:
        continue

      # each trip has a start date
      if trip_id not in start_dates:
        start_dates[trip_id] = start_date

      # initialise last_trip
      if last_trip is None:
        last_trip = trip_id

      # detect the beginning of another trip
      if last_trip != trip_id:
        push_trip(last_trip, trip)
        trip = []
        last_trip = trip_id

      # append sensor data to current trip
      trip.append({
        "ts": date,
        "location": {
          "latitude": lat,
          "longitude": lng,
          "altitude": 0,
          "speed": speed,
          "hAccuracy": h_accuracy,
          "vAccuracy": v_accuracy,
          "course": course,
          "heading": {
            "magneticHeading": course,
            "trueHeading": course,
            "headingAccuracy": 0,
            "x": ori_x,
            "y": ori_y,
            "z": ori_z
          }
        },
        "motion": {
          "magnetometer": {
            "x": mag_x,
            "y": mag_y,
            "z": mag_z
          }
        },
        "activity": {
          "confidence": 2,
          "automotive": True
        }
      })

  # append the last trip to the trip list
  push_trip(last_trip, trip)

  # convert absolute timestamps to relative timestamps
  for trip in trips:
    data = trip["data"]
    if len(data) > 0:
      t0 = data[0]["ts"]
      for d in data:
        d["ts"] -= t0

  return trips

def read_trip_summaries(input_file):
  with open(input_file, mode='r', encoding='utf-8') as file:
    reader = csv.reader(file)
    headers = next(reader)
    data = [{key: value for key, value in zip(headers, row)} for row in reader]
    return {obj.get('TRIPSUMMARYID'): transform(obj, {
      "ACCELQUALITY": ("accelQuality", lambda x: x == 'true'),
      "DRIVINGDISTANCE": ("drivingDistance", to_float),
      "MAXSPEED": ("maxSpeed", to_float),
      "AVGSPEED": ("avgSpeed", to_float),
      "MEASUREMENTUNIT": "unit",
      "OVERALLSCORE": ("overallScore", to_float),
      "MYD_SCORE_ACCELERATION": ("mydScoreAcceleration", to_float),
      "MYD_SCORE_BRAKING": ("mydScoreBraking", to_float),
      "MYD_SCORE_CORNERING": ("mydScoreCornering", to_float),
      "MYD_SCORE_SPEEDING": ("mydScoreSpeeding", to_float),
      "MYD_SCORE_DISTRACTED_DRIVING": ("mydScoreDistractedDriving", to_float),
    }) for obj in data}

def read_trip_events(input_file):
  with open(input_file, mode='r', encoding='utf-8') as file:
    reader = csv.reader(file)
    headers = next(reader)
    data = [{key: value for key, value in zip(headers, row)} for row in reader]
    trip_ids = set([obj.get('TRIPSUMMARYID') for obj in data])
    return {trip_id: [transform(obj, {
      "UTCDATETIME": ("ts", lambda x: date_to_millis(x) - date_to_millis(obj.get('UTCSTARTDATETIME'))),
      "TELEMETRYEVENTTYPE": "type",
      "TELEMETRYEVENTSEVERITYLEVEL": "severity",
    }) for obj in data if obj.get('TRIPSUMMARYID') == trip_id and obj.get('TELEMETRYEVENTSEVERITYLEVEL') != ""] for trip_id in trip_ids}

def write_trips(trips):
  # create output directory
  output_dir_abs = os.path.normpath(os.path.join(SCRIPT_DIR, '..', OUTPUT_DIR_REL))
  output_dir = os.path.basename(output_dir_abs)
  os.makedirs(output_dir, exist_ok=True)

  code_lines = []

  for index, trip in enumerate(trips):
    # construct the file name
    meta = trip["meta"]
    filename = OUTPUT_FILENAME_PATTERN
    filename = filename.replace("{date}", datetime.fromtimestamp(meta["startDate"] / 1000.0).strftime("%Y-%m-%d_%H.%M"))
    filename = filename.replace("{dur}", describe_duration(meta["duration"]).replace(" ", ""))
    fullpath = os.path.join(output_dir_abs, filename)

    # write json data
    with open(fullpath, 'w') as file:
      print(f"Writing to: {fullpath}")
      file.write(json.dumps(trip, indent=2) + "\n")

    # generate an import statement
    code_lines.append(f"  require('{OUTPUT_DIR_REL}/{filename}'),")

  print('\n\n// add these lines to include the trip files in the app bundle')
  print('addTrips(')
  print('\n'.join(code_lines))
  print(');')

def add_walking_activities(trip):
  data = trip["data"]
  last = data[-1]
  ts = last["ts"]

  for _ in range(0, 30):
    ts += 1000
    data.append({
      **last,
      "ts": ts,
      "location": {
        **last["location"],
        "speed": 0,
      },
      "activity": {
        "confidence": 2,
        "walking": True
      }
    })

def main():
  # get the input file path from command line arguments
  if len(sys.argv) <= 1 or not sys.argv[1].strip():
    print(f"Please provide the path to the source data file")
    sys.exit(1)

  # check if input file exists
  input_file = sys.argv[1].strip()
  if not os.path.exists(input_file):
    print(f"Source data file does not exist")
    sys.exit(1)

  # read, convert and write
  print(f"Convert IMS CSV File: {input_file}")
  trips = read_trips(input_file)

  # add walking activites so that the trip recorder would stop
  for trip in trips:
    add_walking_activities(trip)

  # add summary to meta
  summaries = read_trip_summaries(os.path.join(os.path.dirname(input_file), 'Trip Summary.csv'))
  trips = [{**trip, "meta": {**trip.get("meta"), "summary": summaries[trip["meta"]["id"]]}} for trip in trips]

  # add events to meta
  events = read_trip_events(os.path.join(os.path.dirname(input_file), 'Events.csv'))
  trips = [{**trip, "meta": {**trip["meta"], "events": events[trip["meta"]["id"]]}} for trip in trips]

  # write to output file
  write_trips(trips)

# Main
if __name__ == '__main__':
  main()
