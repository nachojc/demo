from pbxproj import XcodeProject
from pbxproj.pbxsections import PBXShellScriptBuildPhase
import sys
import os
import argparse

def script_exists(project, script, target_name = None):
  for target in project.objects.get_targets(target_name):
    for build_phase_id in target.buildPhases:
      build_phase = project.objects[build_phase_id]
      if not isinstance(build_phase, PBXShellScriptBuildPhase):
        continue

      if build_phase.shellScript == script:
        return True
  return False

parser = argparse.ArgumentParser(description="Add script phase to an Xcode project.")
parser.add_argument('-s', '--script', help='Script content', default='')
parser.add_argument('-p', '--project', help='Project file', default='')
parser.add_argument('-i', '--input', nargs='*', help='List of input files', default=None)
args = parser.parse_args()

if not args.project or not args.script:
  print(f'  Usage is {os.path.basename(__file__)} -p path/to/project.pbxproj -s script_content')
  sys.exit()

# open the project
project = XcodeProject.load(args.project)

# add a run script phase if not there already
if script_exists(project, args.script):
  print('Same script exists already.')
else:
  project.add_run_script(args.script, input_files=args.input)
  project.save()
  print (f'Added a script to {args.project}:\n{args.script}')
