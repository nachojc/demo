#!/bin/bash

# Copy and extract the template
prepare_template() {
  cp -a node_modules/expo-template-bare-minimum node_modules/package
  tar --no-mac-metadata -C node_modules -zcf node_modules/expo-template-bare-minimum.tgz package
  rm -Rf node_modules/expo-template-bare-minimum || true
}

# Add files to the Xcode project
add_files_to_xcodeproj() {
  local project=$1

  echo "iOS: Adding files to Xcode project $project"

  shift
  for file in "$@"; do
    .venv/bin/python3 ./scripts/add-file-to-project.py "$project" "$file"
  done
}

copy_entitlements() {
  local dir=$1
  local app_name=$2
  local target=$3

  echo -e "\n========Entitlements========="
  if [ "$target" = "production" ]; then
    entitlements_in_loc="resources/$dir/Entitlements.plist.prod"
    export_options_in_loc="resources/$dir/ExportOptions.plist.prod"
  elif [ "$target" = "development" ]; then
    entitlements_in_loc="resources/$dir/Entitlements.plist.empty"
    export_options_in_loc="resources/$dir/ExportOptions.plist.wildcard"
  else
    entitlements_in_loc="resources/$dir/Entitlements.plist.adhoc"
    export_options_in_loc="resources/$dir/ExportOptions.plist.adhoc"
  fi

  entitlements_out_loc="ios/$app_name/$app_name.entitlements"
  export_options_out_loc="ios/ExportOptions.plist"

  cp "$entitlements_in_loc" "$entitlements_out_loc"
  cp "$export_options_in_loc" "$export_options_out_loc"

  cat "$entitlements_out_loc"
  echo -e "\n"
  cat "$export_options_out_loc"
}

copy_feature_flags() {
  local dir=$1

  echo -e "\n========Feature Flags========="
  echo "cp resources/""$dir""/feature-flags.json src/feature-flags/feature-flags.json"
  cp resources/"$dir"/feature-flags.json src/feature-flags/feature-flags.json
  cat src/feature-flags/feature-flags.json
}
