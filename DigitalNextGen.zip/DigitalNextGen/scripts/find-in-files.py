import os
import argparse

EXTENSIONS = ['.ts', '.tsx']
KEYWORDS = ['screen', 'view-model']
EXCLUSIONS = ['test', 'mock', 'styles', 'dev-mode', 'node_modules']

def is_valid_file(file_path, search_strings):
    """
    Checks if a file contains any of the search strings.
    Returns True if none of these strings are found.
    """
    with open(file_path, 'r') as file:
        content = file.read()
        return not any(search_string in content for search_string in search_strings)

def is_interesting_file(file_name):
    """
    Checks if a file name ends with a certain extension and contains certain keywords.
    """
    return any(file_name.lower().endswith(ext) for ext in EXTENSIONS) and any(keyword in file_name.lower() for keyword in KEYWORDS)

def process_directory(directory_path, search_strings):
    """
    Recursively processes directories and lists files that meet the criteria.
    """
    matching_directories = []

    print("\nMatching Files:")
    for root, dirs, files in os.walk(directory_path):
        # Exclude directories with names in the exclusions list
        dirs[:] = [d for d in dirs if not any(exclusion in d.lower() for exclusion in EXCLUSIONS)]

        # Check if any file contains the specified strings
        contains = False
        for file in files:
            if is_interesting_file(file):
                file_path = os.path.join(root, file)
                if not is_valid_file(file_path, search_strings):
                    contains = True
                    break

        # If none of the files in the directory contain the specified strings, print the files and add the directory to the list
        if not contains:
            for file in files:
                if is_interesting_file(file):
                    file_path = os.path.join(root, file)
                    if is_valid_file(file_path, search_strings):
                        print(f"{os.path.relpath(file_path)}")
            if any(is_interesting_file(file) for file in files):
                matching_directories.append(os.path.relpath(root))

    # After all files have been processed, print the directories
    print("\nMatching Directories:")
    for directory in matching_directories:
        print(f"{directory}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Search for files in a directory that are missing the certain strings. If the directory contains the term the rest of the files are ignores. This will search in `screen` and `view-model` files')
    parser.add_argument('directory', help='The directory to search in.')
    parser.add_argument('search_strings', nargs='+', help='The strings to search for in the files.')
    args = parser.parse_args()

    process_directory(args.directory, args.search_strings)