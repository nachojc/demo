#!/bin/bash

# Get the directory of the current script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source the build tools
# shellcheck disable=SC1091
source "$SCRIPT_DIR/pre-build-tools.sh"

# Common prebuild steps
common_prebuild_steps() {
  local target_app=$1
  mv .env .tmpenv
  EXPO_NO_GIT_STATUS=1 TARGET_APP=$target_app EXPO_NO_DOTENV=1 expo prebuild --clean --template node_modules/expo-template-bare-minimum.tgz --no-install
  mv .tmpenv .env

  echo "Node: Fixing python"
  rm -rf .venv
  python3 -m venv .venv
  .venv/bin/pip3 install pypkg/* -q -q

  # Define a variable for the check
  is_local=false
  if [[ -f '.local' ]]; then
    is_local=true
  fi

  echo -e "\n===========Android============"
  if $is_local; then
    echo "Android: Patching gradle-wrapper for local"
    sed -i.bak 's^services.gradle.org/distributions^/opt/gradleCache/wrapper/dists^g' android/gradle/wrapper/gradle-wrapper.properties
    sed -i.bak 's^https^file^g' android/gradle/wrapper/gradle-wrapper.properties
  fi
  mkdir -p android/app/src/main/res/xml
  cp patches/network_security_config.xml android/app/src/main/res/xml
  if $is_local; then
    sed -i '' 's^cleartextTrafficPermitted="false"^cleartextTrafficPermitted="true"^g' android/app/src/main/res/xml/network_security_config.xml
  fi
  patch -li patches/app.build.gradle android/app/build.gradle || cat android/app/build.gradle android/app/build.gradle.rej && git checkout -- patches/app.build.gradle patches/MainActivity.kt.patch
  grep multiDexEnabled android/app/build.gradle || patch -li patches/multidex.patch android/app/build.gradle

  echo -e "\n=============iOS=============="
  patch -li patches/Podfile.patch ios/Podfile
  if $is_local; then
    echo "iOS: Running locally, patching podfile for Artifactory"
    patch -li patches/Podfile.af-cdn.patch ios/Podfile
  else
    echo "Running in the pipeline"
  fi
  cp patches/Podfile.lock ios/
  sed -i '' "s^post_install do |installer|^post_install do |installer|\\n    installer.pods_project.targets.each do |target|\\n      target.build_configurations.each do |config|\\n        config.build_settings['IPHONEOS_DEPLOYMENT_TARGET'] = '13.0'\\n      end\\n    end\\n\\n^g" ios/Podfile

  echo -e "\n=============Node=============="
  npm --prefix node_modules/@onfido/react-native-sdk/ run updateBuildGradle
  node node_modules/@appdynamics/react-native-agent/bin/cli.js install
}

# Apply patches and copy files
patch_app() {
  local appNameiOS=$1
  local appNameAndroid=$2
  local dir=$3

  echo -e "\n===========Android============"
  patch -li patches/MainActivity.kt.patch android/app/src/main/java/co/uk/aviva/"$appNameAndroid"/MainActivity.kt
  patch -li patches/"$dir"/MainApplication.kt.patch android/app/src/main/java/co/uk/aviva/"$appNameAndroid"/MainApplication.kt
  cp patches/"$dir"/google-services.json android/app/google-services.json
  cp patches/"$dir"/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
  cp patches/AndroidManifest.xml.debug android/app/src/debug/AndroidManifest.xml

  echo -e "\n=============iOS=============="
  cp patches/"$dir"/GoogleService-Info.plist ios/"$appNameiOS"/GoogleService-Info.plist
  cp colors.json ios/"$appNameiOS"/colors.json
  cp patches/AdyenAppearance.swift ios/"$appNameiOS"/AdyenAppearance.swift
  cp patches/PrivacyInfo.xcprivacy ios
  add_files_to_xcodeproj \
    ios/"$appNameiOS".xcodeproj/project.pbxproj \
    "$appNameiOS"/GoogleService-Info.plist \
    "$appNameiOS"/colors.json \
    "$appNameiOS"/AdyenAppearance.swift \
    PrivacyInfo.xcprivacy

  patch -li patches/AppDelegate.h.patch ios/"$appNameiOS"/AppDelegate.h
  patch -li patches/"$dir"/AppDelegate.mm.patch ios/"$appNameiOS"/AppDelegate.mm

  if [[ ! -f '.local' ]]; then
    .venv/bin/python3 ./scripts/add-script-to-project.py \
      -p ios/"$appNameiOS".xcodeproj/project.pbxproj \
      -s '/bin/sh ${SRCROOT}/../scripts/publish-dSYMs.sh' \
      -i '${DWARF_DSYM_FOLDER_PATH}/${DWARF_DSYM_FILE_NAME}/Contents/Resources/DWARF/${TARGET_NAME}'
  fi
}

# MyAviva prebuild
prebuild_ma() {
  echo "Running prebuild for MyAviva, $1"
  app_dir="ma"
  app_name="myaviva"

  common_prebuild_steps ${app_dir}
  patch_app \
    "$app_name" \
    "$app_name" \
    ${app_dir}

  copy_feature_flags ${app_dir}
  copy_entitlements ${app_dir} ${app_name} "$1"

  sed -i '' 's/myaviva/MyAviva/g' android/app/src/main/res/values/strings.xml
}

# MyAviva Demo prebuild
prebuild_ma_demo() {
  echo "Running prebuild for MyAviva Demo"
  app_name="myavivademo"
  app_dir="ma-demo"

  sed -i '' "/const appName = isManga ?/s/myaviva/${app_name}/" app.config.ts
  sed -i '' '/const displayName = isManga ?/s/MyAviva/MyAviva Demo/' app.config.ts
  sed -i '' "/'co.uk.aviva.myaviva'/s/myaviva/${app_name}/" app.config.ts
  sed -i '' "s/aviva\\.myaviva/aviva\\.${app_name}/g" patches/MainActivity.kt.patch
  
  common_prebuild_steps "ma"

  patch_app \
    ${app_name} \
    ${app_name} \
    ${app_dir}

  copy_feature_flags ${app_dir}
  copy_entitlements ${app_dir} ${app_name} "$1"

  sed -i '' 's/myavivademo/MyAviva Demo/g' android/app/src/main/res/values/strings.xml

  git checkout -- app.config.ts
}

# DirectWealth prebuild
prebuild_dw() {
  echo "Running prebuild for DirectWealth, $1"
  app_dir="dw"

  sed -i.bak 's^aviva\\.myaviva^aviva\\.directwealth^g' patches/MainActivity.kt.patch

  common_prebuild_steps ${app_dir}

  patch_app \
    "avivawealth" \
    "directwealth" \
    ${app_dir}

  copy_feature_flags ${app_dir}
  copy_entitlements ${app_dir} "avivawealth" "$1"

  sed -i '' 's/avivawealth/Aviva Wealth/g' android/app/src/main/res/values/strings.xml
  # Remove location from Info.plist
  sed -i '' 's^<string>location</string>^^g' ios/avivawealth/Info.plist
}

# Pipeline prebuild
prebuild_pipe() {
  echo "Running prebuild for MyAviva (Pipeline), $1"
  app_dir="ma"

  sed -i.bak 's/aviva\.myaviva/aviva\.myavivaapp/g' app.config.ts
  sed -i.bak 's/aviva\.myaviva/aviva\.myavivaapp/g' patches/app.build.gradle
  sed -i.bak 's/aviva\.myaviva/aviva\.myavivaapp/g' patches/MainActivity.kt.patch

  common_prebuild_steps ${app_dir}

  patch_app \
    "myaviva" \
    "myavivaapp" \
    ${app_dir}

  copy_feature_flags ${app_dir}
  copy_entitlements ${app_dir} "myaviva" "$1"

  sed -i '' 's/myaviva/MyAviva/g' android/app/src/main/res/values/strings.xml
  cp patches/pipe/AndroidManifest.xml android/app/src/main/AndroidManifest.xml
}

run_prebuild() {
  local app=${1:-ma}
  local target=${2:-development}
  local platform=${3:-ios}

  prepare_template
  if [ "$app" == "ma" ]; then
    if [[ ! -f '.local' && "$platform" == 'android' ]]; then
      prebuild_pipe "$target"
    else
      prebuild_ma "$target"
    fi
  elif [ "$app" == "dw" ]; then
    prebuild_dw "$target"
  elif [ "$app" == "ma-demo" ]; then
    prebuild_ma_demo "$target"
  else
    echo "Usage: $1 {ma|ma-demo|dw} $2 (optional) {development|staging|pentest|production} $3 (optional) {ios|android}"
    exit 1
  fi
}

run_prebuild "$1" "$2" "$3"