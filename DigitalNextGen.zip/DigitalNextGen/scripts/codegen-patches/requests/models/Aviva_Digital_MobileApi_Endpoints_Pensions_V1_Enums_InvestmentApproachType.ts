/* generated using openapi-typescript-codegen -- do no edit */
/* istanbul ignore file */
/* eslint-disable */

export enum Aviva_Digital_MobileApi_Endpoints_Pensions_V1_Enums_InvestmentApproachType {
  None = 'None',
  Lifestyle = 'Lifestyle',
  Lifestage = 'Lifestage',
  Lifetime = 'Lifetime',
}
