#! /bin/bash

if [[ -z $DWARF_DSYM_FOLDER_PATH || -z $SRCROOT || -z $PROJECT_TEMP_ROOT ]]; then
  echo This script should be run as part of the xcodebuild process.
  exit
fi

if [[ -n $ARTIFACT_DIR ]]; then
  echo Copying dSYM files to the artifact directory
  find $DWARF_DSYM_FOLDER_PATH -type d -name \*.dSYM -exec rsync -rav {} $ARTIFACT_DIR/dSYMs \;
  cd $ARTIFACT_DIR && zip -r ./dSYMs.zip ./dSYMs && cd -
  rm -rf $ARTIFACT_DIR/dSYMs
else
  echo Artifact directory not specified. Skip copying dSYM files.
fi

if [[ -n $ADRUM_ACCOUNT_NAME && -n $ADRUM_LICENSE_KEY ]]; then
  ADRUM_TREAT_UPLOAD_FAILURES_AS_ERRORS=0
  SCRIPT=$(/usr/bin/find "${SRCROOT}/.." -name xcode_build_dsym_upload.sh | head -n 1)
  if [[ -n $SCRIPT ]]; then
    echo Uploading dSYM files to AppDynamics. Account="${ADRUM_ACCOUNT_NAME}"
    /bin/sh "${SCRIPT}"
  else
    echo AppDynamics upload script not found!
  fi
else
  echo Missing ADRUM_ACCOUNT_NAME / ADRUM_LICENSE_KEY. Skip uploading dSYM files to AppDynamics.
fi
