#!/bin/bash

GRADLE_TASK="$1"
export TARGET_APP="$2"

echo "$GRADLE_TASK Android build for $PLATFORM arm64-v8a"

if [ "$GRADLE_TASK" == "assemble" ]; then
  task="assembleDebug"
elif [ "$GRADLE_TASK" == "install" ]; then
  task="installDebug"
else
  echo "Invalid Gradle task"
  exit 1
fi

cd android || exit

KEY_ALIAS=x KEY_PASS=x KEYSTORE_FILE=x KEYSTORE_PASS=x TARGET_ENV=development \
./gradlew --gradle-user-home /opt/gradleCache --build-cache -Dhttp.nonProxyHosts="binaries.avivagroup.com" \
$task -PreactNativeArchitectures=arm64-v8a
