from pbxproj import XcodeProject
import sys

if len(sys.argv) < 3:
  print('  Usage is add_file_to_project.py path/to/project.pbxproj file/to/add.mm')
  sys.exit()
# open the project
project = XcodeProject.load(sys.argv[1])

# add a file to it, force=false to not add it if it's already in the project
project.add_file(sys.argv[2], force=False)

# save the project, otherwise your changes won't be picked up by Xcode
project.save()

print ('Added {} to {}.'.format(sys.argv[2], sys.argv[1]))
