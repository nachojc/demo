from pbxproj import XcodeProject
import sys

if len(sys.argv) < 2:
  print('Usage is exclude-archs-for-sim.py path/to/project.pbxproj')
  sys.exit()
# open the project
project = XcodeProject.load(sys.argv[1])

#remove existing flag
project.remove_project_flags('EXCLUDED_ARCHS[sdk=iphonesimulator*]', "i386")

#add new flag
project.add_project_flags('EXCLUDED_ARCHS[sdk=iphonesimulator*]', "i386 arm64")

project.save()


