import 'react-native-gesture-handler';

import { registerRootComponent } from 'expo';
import { Text, TextInput } from 'react-native';
/**
 * Require used to force setupEnv to resolve synchronously
 * Before App is loaded
 */
const { setupConfig } = require('./src/common/config');

setupConfig();

const { App } = require('./App');

require('./src/i18n/i18n');

TextInput.defaultProps = TextInput.defaultProps || {};
TextInput.defaultProps.allowFontScaling = false;
Text.defaultProps = Text.defaultProps || {};
Text.defaultProps.allowFontScaling = false;

// registerRootComponent calls AppRegistry.registerComponent('main', () => App);
// It also ensures that whether you load the app in Expo Go or in a native build,
// the environment is set up appropriately
registerRootComponent(App);
