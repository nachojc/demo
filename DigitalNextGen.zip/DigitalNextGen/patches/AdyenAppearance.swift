//
// Copyright (c) 2023 Adyen N.V.
//
// This file is open source and available under the MIT license. See the LICENSE file for more info.
//

import Adyen
import adyen_react_native
import Foundation

/// Please make sure that the name of the class exactly matches.
/// SDK will use reflection to find the class with this exact name.
class AdyenAppearance: AdyenAppearanceProvider {
    static func createStyle() -> Adyen.DropInComponent.Style {
      var style = DropInComponent.Style()

      let avivaYellow = UIColor(red: 1.00, green: 0.85, blue: 0.00, alpha: 1.00) // #FFD900

      style.formComponent.mainButtonItem.button.backgroundColor = avivaYellow
      style.formComponent.mainButtonItem.button.title.color = .black

      return style
    }
}
