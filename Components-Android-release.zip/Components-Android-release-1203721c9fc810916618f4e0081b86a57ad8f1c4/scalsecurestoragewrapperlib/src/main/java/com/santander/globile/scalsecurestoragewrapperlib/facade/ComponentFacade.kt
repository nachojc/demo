package com.santander.globile.scalsecurestoragewrapperlib.facade

import android.app.Activity
import android.arch.lifecycle.MutableLiveData
import android.content.Context
import com.globile.santander.mobisec.scal.securestorage.database.SCALDatabaseSecureStorage
import com.globile.santander.mobisec.scal.securestorage.files.SCALFileMode
import com.globile.santander.mobisec.scal.securestorage.files.SCALFilesSecureStorage
import com.globile.santander.mobisec.scal.securestorage.sharedPrefs.SCALSharedPreferencesSecureStorage
import com.globile.santander.mobisec.securestorage.SCALDatabaseSecureStorageDefault
import com.globile.santander.mobisec.securestorage.SCALFilesSecureStorageDefault
import com.globile.santander.mobisec.securestorage.SCALSharedPreferencesSecureStorageDefault
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.santander.globile.scalsecurestoragewrapperlib.facade.callback.SCALDatabaseCallBack
import com.santander.globile.scalsecurestoragewrapperlib.facade.data.*
import java.lang.ClassCastException

class ComponentFacade {

    var liveData: MutableLiveData<String> = MutableLiveData()
    lateinit var gson: Gson

    fun startComponent(args: ArrayList<Any>) {
        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
        val params = args[0] as String
        val context = args[1] as Context

        val scalOperationParam =  gson.fromJson(params, SCALSecureStorageOperationParam::class.java)

        val sharedPreference = SCALSharedPreferencesSecureStorage(SCALSharedPreferencesSecureStorageDefault(context))
        val file = SCALFilesSecureStorage(SCALFilesSecureStorageDefault(context))
        val sqlite = SCALDatabaseSecureStorage(SCALDatabaseSecureStorageDefault(context))

        var result: Any? = null

        if (scalOperationParam.operation != null) {
            try {
                result = when (scalOperationParam.operation) {
                    //Shared Preference
                    SecureStorageOperation.createNewSecureSharedPreference -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.createNewSecureSharedPreferences(scalParams.name)
                    }
                    SecureStorageOperation.clearSecureSharedPreference -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.clearSecureSharedPreferences(scalParams.name)
                    }
                    SecureStorageOperation.deleteSecureSharedPreference -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.deleteSecureSharedPreferences(scalParams.name)
                    }
                    SecureStorageOperation.saveBool -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.setBoolean(scalParams.alias, scalParams.plainData as Boolean, scalParams.name)
                    }
                    SecureStorageOperation.saveString -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.setString(scalParams.alias, scalParams.plainData as String, scalParams.name)
                    }
                    SecureStorageOperation.saveInteger -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.setInteger(scalParams.alias, scalParams.plainData as Int, scalParams.name)
                    }
                    SecureStorageOperation.saveDouble -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.setDouble(scalParams.alias, scalParams.plainData as Double, scalParams.name)
                    }
                    SecureStorageOperation.saveFloat -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.setFloat(scalParams.alias, scalParams.plainData as Float, scalParams.name)
                    }
                    SecureStorageOperation.loadBool -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.getBoolean(scalParams.alias, scalParams.name)
                    }
                    SecureStorageOperation.loadString -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.getString(scalParams.alias, scalParams.name)
                    }
                    SecureStorageOperation.loadInteger -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.getInteger(scalParams.alias, scalParams.name)
                    }
                    SecureStorageOperation.loadDouble -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.getDouble(scalParams.alias, scalParams.name)
                    }
                    SecureStorageOperation.loadFloat -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        sharedPreference.getFloat(scalParams.alias, scalParams.name)
                    }
                    //File
                    SecureStorageOperation.removeSecureFile -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        file.removeSecurefile(scalParams.name)
                    }
                    SecureStorageOperation.clearSecureFile -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        file.clearSecurefile(scalParams.name)
                    }
                    SecureStorageOperation.writeToSecureFile -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        file.writeToSecureFile(
                            scalParams.name,
                            (scalParams.plainData as String).toByteArray(),
                            SCALFileMode.APPEND_MODE
                        )
                    }
                    SecureStorageOperation.readFromSecureFile -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSharedPreferenceParams::class.java)
                        file.readFromSecurefile(scalParams.name)
                    }
                    //BBDD
                    SecureStorageOperation.initDataBase -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSqliteParams::class.java)
                        sqlite.initDatabase(scalParams.name, scalParams.version, SCALDatabaseCallBack())
                    }
                    SecureStorageOperation.removeDataBase -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSqliteParams::class.java)
                        sqlite.removeDatabase()
                    }
                    SecureStorageOperation.executeQuery -> {
                        val scalParams = gson.fromJson(params, SCALSecureStorageSqliteParams::class.java)
                        sqlite.executeQuery(scalParams.query, scalParams.args)
                    }
                }
            }
            catch (e: ClassCastException) {
                "ClassCastException: ${e.message}"
            }
        }
        else {
            result = "Operation invalid"
        }

        liveData.postValue(gson.toJson(result))
    }

}