package com.santander.globile.scalsecurestoragewrapperlib.facade.callback

import com.globile.santander.mobisec.scal.securestorage.listeners.SCALDatabaseSecureStorageCallback
import net.sqlcipher.database.SQLiteDatabase

class SCALDatabaseCallBack : SCALDatabaseSecureStorageCallback {

    override fun onUpgrade(sqLiteDatabase: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun onCreate(sqLiteDatabase: SQLiteDatabase?) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}