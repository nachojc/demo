package com.santander.globile.scalsecurestoragewrapperlib.facade.data

data class SCALSecureStorageSharedPreferenceParams(
    val operation: String,
    val name: String,
    val alias: String,
    val plainData: Any? = null
)