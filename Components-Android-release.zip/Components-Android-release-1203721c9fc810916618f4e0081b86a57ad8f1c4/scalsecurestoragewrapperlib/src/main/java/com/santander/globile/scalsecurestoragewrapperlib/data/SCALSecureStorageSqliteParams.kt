package com.santander.globile.scalsecurestoragewrapperlib.facade.data

data class SCALSecureStorageSqliteParams(
    val operation: String,
    val name: String,
    val version: Int,
    val query: String,
    val args: Array<String>
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as SCALSecureStorageSqliteParams

        if (!args.contentEquals(other.args)) return false

        return true
    }

    override fun hashCode(): Int {
        return args.contentHashCode()
    }
}
