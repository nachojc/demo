package uk.co.santander.contextdetection;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.location.Address;
import android.location.LocationListener;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import com.globile.santander.mobisec.scal.contextdetection.listeners.GeopositionRiskCallback;
import com.google.android.gms.location.*;

abstract class LocationRiskProviderImpl extends LocationProviderImpl {

	
	public static void requestLocationRisk(GeopositionRiskCallback callback, Activity activity) {
		if (isRunning) {
			return;
		}
		
		if (!hasLocationPermissions(activity)) {
			ActivityCompat.requestPermissions(activity, LOCATION_PERMISSIONS, REQUEST_CODE_LOCATION_PERMISSIONS);
			return;
		}
		
		Handler handler = new Handler();
		LocationListener locationListener = getLocationListener(activity);
		
		getGpsLocationRequestRunnable(activity, handler, locationListener, callback.showEnableGpsDialog()).run();
		requestFusedProviderUpdates(callback, locationListener, activity);
	}
	
	/**
	 * Initiate a {@link FusedLocationProviderClient} request. This method cannot be reached
	 * without having the location permissions, hence the SuppressLint annotation.
	 *
	 * @param locationListener
	 * @param callback
	 */
	@SuppressLint("MissingPermission")
	private static void requestFusedProviderUpdates(final GeopositionRiskCallback callback, final LocationListener locationListener,
	                                                @NonNull final Context context) {
		final FusedLocationProviderClient fusedLocationProviderClient =
				LocationServices.getFusedLocationProviderClient(context);
		fusedLocationProviderClient.requestLocationUpdates(
				LocationRequest.create(),
				new LocationCallback() {
					@Override
					public void onLocationResult(LocationResult locationResult) {
						super.onLocationResult(locationResult);
						
						Address address = getGeoAddress(context, locationResult.getLastLocation());
						isRunning = false;
						callback.onGeopositionRiskReady(DeviceDataSyncProvider.getGeopositionRisk(address));
						
						fusedLocationProviderClient.removeLocationUpdates(this);
						if (locationListener != null) {
							getLocationManager(context).removeUpdates(locationListener);
						}
					}
				},
				Looper.getMainLooper());
		isRunning = true;
	}
}
