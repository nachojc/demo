package uk.co.santander.contextdetection;

import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import com.globile.santander.mobisec.scal.contextdetection.listeners.DeviceDataCallback;
import com.globile.santander.mobisec.scal.contextdetection.models.SCALDeviceData;

import java.lang.ref.WeakReference;

class DeviceDataProviderTask extends AsyncTask<Void, Void, SCALDeviceData> {
	
	private WeakReference<DeviceDataCallback> callbackWeakReference;
	private WeakReference<Context> contextWeakReference;
	
	DeviceDataProviderTask(@NonNull DeviceDataCallback callback, @NonNull Context context) {
		this.contextWeakReference = new WeakReference<>(context);
		this.callbackWeakReference = new WeakReference<>(callback);
	}
	
	@Override
	protected SCALDeviceData doInBackground(Void... params) {
		if (contextWeakReference.get() != null) {
			return DeviceDataSyncProvider.getDeviceData(contextWeakReference.get());
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(SCALDeviceData deviceData) {
		if (deviceData != null && callbackWeakReference.get() != null) {
			callbackWeakReference.get().onDeviceDataReady(deviceData);
		}
	}
}
