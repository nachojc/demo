package uk.co.santander.contextdetection;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.LocationListener;
import android.location.*;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.text.TextUtils;
import com.globile.santander.mobisec.scal.contextdetection.listeners.GeopositionDataCallback;
import com.google.android.gms.location.*;

import java.io.IOException;
import java.util.List;

abstract class LocationProviderImpl {
	
	protected static final String[] LOCATION_PERMISSIONS = new String[] {
			Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION
	};
	
	protected static final int REQUEST_CODE_LOCATION_PERMISSIONS = 9999;
	protected static boolean isRunning = false;

	/**
	 * Initiates location requests using both the {@link LocationManager} and {@link FusedLocationProviderClient}.
	 * However, if the location permissions are not granted, this will result in a permissions request instead.
	 *
	 * @param callback
	 */
	static void requestLocation(@NonNull GeopositionDataCallback callback, @NonNull Activity activity) {
		if (isRunning) {
			return;
		}
		
		if (!hasLocationPermissions(activity)) {
			ActivityCompat.requestPermissions(activity, LOCATION_PERMISSIONS, REQUEST_CODE_LOCATION_PERMISSIONS);
			return;
		}
		
		Handler handler = new Handler();
		LocationListener locationListener = getLocationListener(activity);
		
		getGpsLocationRequestRunnable(activity, handler, locationListener, callback.showEnableGpsDialog()).run();
		requestFusedProviderUpdates(callback, locationListener, activity);
	}
	
	/**
	 * @param context
	 * @param handler
	 * @param locationListener
	 * @param showEnableGpsDialog
	 *
	 * @return A {@link Runnable} that tries to request location updates from the {@link LocationManager}
	 * depending on the status of the GPS. If GPS is disabled, this will repeat itself
	 * until the GPS is enabled or the app is terminated.
	 */
	protected static Runnable getGpsLocationRequestRunnable(final Context context,
	                                                      final Handler handler,
	                                                      final LocationListener locationListener,
	                                                      final boolean showEnableGpsDialog) {
		return new Runnable() {
			@SuppressLint("MissingPermission")
			@Override
			public void run() {
				if (isGpsEnabled(context, showEnableGpsDialog)) {
					getLocationManager(context).requestLocationUpdates(
							LocationManager.GPS_PROVIDER, 0, 0, locationListener);
				} else {
					handler.postDelayed(
							getGpsLocationRequestRunnable(context, handler, locationListener, false),
							context.getResources().getInteger(R.integer.location_request_interval_millis));
				}
			}
		};
	}
	
	/**
	 * Initiate a {@link FusedLocationProviderClient} request. This method cannot be reached
	 * without having the location permissions, hence the SuppressLint annotation.
	 *
	 * @param locationListener
	 * @param callback
	 */
	@SuppressLint("MissingPermission")
	private static void requestFusedProviderUpdates(final GeopositionDataCallback callback,
                                                    final LocationListener locationListener,
	                                                @NonNull final Context context) {
		final FusedLocationProviderClient fusedLocationProviderClient =
				LocationServices.getFusedLocationProviderClient(context);
        final LocationCallback locationCallback = new LocationCallback() {

            @Override
            public void onLocationResult(LocationResult locationResult) {
                super.onLocationResult(locationResult);

				if (locationResult == null) {
					return;
				}

				isRunning = false;

				locationResultReady(callback, locationResult, context);

				fusedLocationProviderClient.removeLocationUpdates(this);
				if (locationListener != null) {
					getLocationManager(context).removeUpdates(locationListener);
				}
			}
        };
        fusedLocationProviderClient.requestLocationUpdates(
				LocationRequest.create(),
                locationCallback,
				Looper.getMainLooper());
		isRunning = true;
	}

	private static void locationResultReady(@NonNull GeopositionDataCallback callback, @NonNull LocationResult locationResult, Context context) {
		new GetGeoDataTask(callback, locationResult, context).execute();
	}

	protected static boolean hasLocationPermissions(Context context) {
		for (String permission : LOCATION_PERMISSIONS) {
			if (ActivityCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) {
				return true;
			}
		}
		return false;
	}
	
	protected static LocationManager getLocationManager(Context context) {
		return (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
	}
	
	protected static LocationListener getLocationListener(final Context context) {
		return new LocationListener() {
			@Override
			public void onLocationChanged(Location location) {
				if (location != null) {
					getLocationManager(context).removeUpdates(this);
				}
			}
			
			@Override
			public void onStatusChanged(String provider, int status, Bundle extras) {
			}
			
			@Override
			public void onProviderEnabled(String provider) {
			}
			
			@Override
			public void onProviderDisabled(String provider) {
			}
		};
	}
	
	private static boolean isGpsEnabled(@NonNull Context context, boolean showEnableGpsDialog) {
		boolean isEnabled = false;
		
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) {
			String locationProviders = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.LOCATION_PROVIDERS_ALLOWED);
			isEnabled = !TextUtils.isEmpty(locationProviders);
		} else {
			try {
				int locationMode = Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.LOCATION_MODE);
				isEnabled = locationMode != Settings.Secure.LOCATION_MODE_OFF;
			} catch (Settings.SettingNotFoundException e) {
				e.printStackTrace();
			}
		}
		
		if (!isEnabled && showEnableGpsDialog) {
			getEnableGpsDialog(context).show();
		}
		
		return isEnabled;
	}
	
	private static Dialog getEnableGpsDialog(final Context context) {
		return new AlertDialog.Builder(context)
				.setMessage(R.string.gps_dialog_title)
				.setPositiveButton(R.string.gps_dialog_positive, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
						context.startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
					}
				})
				.setNegativeButton(R.string.gps_dialog_negative, new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						dialog.dismiss();
					}
				})
				.create();
	}
	
	@Nullable
	protected static Address getGeoAddress(Context context, Location location) {
		if (location != null) {
			Geocoder geocoder = new Geocoder(context);
			try {
				List<Address> addresses = geocoder.getFromLocation(
						location.getLatitude(), location.getLongitude(), 1);
				return addresses.get(0);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return null;
	}

}
