package uk.co.santander.contextdetection;

import com.globile.santander.mobisec.scal.contextdetection.models.AppNetworkInfo;
import com.globile.santander.mobisec.scal.contextdetection.models.BluetoothDeviceModel;
import com.globile.santander.mobisec.scal.contextdetection.models.InstalledApplication;

import java.util.List;

class ContextDetectionUtils {
	
	static final String TAG = ContextDetectionUtils.class.getName();
	
	static String parseBooleanToEnable(Boolean isEnabled) {
		String isEnabledStr;
		if (isEnabled) {
			isEnabledStr = "Enabled";
		} else {
			isEnabledStr = "Not enabled";
		}
		return isEnabledStr;
	}
	
	static String parseBooleanToAffirmation(Boolean isEnabled) {
		String isEnabledStr;
		if (isEnabled) {
			isEnabledStr = "Yes";
		} else {
			isEnabledStr = "No";
		}
		return isEnabledStr;
	}
	
	static String parseBooleanToOnOff(Boolean isEnabled) {
		String isEnabledStr;
		if (isEnabled) {
			isEnabledStr = "On";
		} else {
			isEnabledStr = "Off";
		}
		return isEnabledStr;
	}
	
	static String convertListStringsToString(List<String> strList) {
		StringBuilder sb = new StringBuilder();
		
		if (strList.size() == 0) {
			strList.add("N/A");
		} else {
			sb.append("\n");
		}
		for (String account : strList) {
			sb.append("\t");
			sb.append(account);
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
	public static String convertListBluetoothDevicesToString(List<BluetoothDeviceModel> deviceList) {
		StringBuilder sb = new StringBuilder();
		for (BluetoothDeviceModel device : deviceList) {
			sb.append("\t");
			sb.append(device.toString());
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
	public static String convertListConnectionToString(List<AppNetworkInfo> list) {
		StringBuilder sb = new StringBuilder();
		for (AppNetworkInfo obj : list) {
			sb.append("\t");
			sb.append(obj.toString());
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
	public static String convertListApplicationDataToString(List<InstalledApplication> appList) {
		StringBuilder sb = new StringBuilder();
		for (InstalledApplication app : appList) {
			sb.append("\t");
			sb.append(app.toString());
			sb.append("\n");
		}
		
		return sb.toString();
	}
	
}
