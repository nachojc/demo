package uk.co.santander.contextdetection;

import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import com.globile.santander.mobisec.scal.contextdetection.listeners.RiskStructCallback;
import com.globile.santander.mobisec.scal.contextdetection.models.DeviceRiskStruct;

import java.lang.ref.WeakReference;
import java.util.List;

class RiskProviderTask extends AsyncTask<Void, Void, List<DeviceRiskStruct>> {
	
	private WeakReference<RiskStructCallback> callbackWeakReference;
	private WeakReference<Context> contextWeakReference;
	
	RiskProviderTask(@NonNull RiskStructCallback callback, @NonNull Context context) {
		this.contextWeakReference = new WeakReference<>(context);
		this.callbackWeakReference = new WeakReference<>(callback);
	}
	
	@Override
	protected List<DeviceRiskStruct> doInBackground(Void... params) {
		if (contextWeakReference.get() != null) {
			return DeviceDataSyncProvider.getAllRiskData(contextWeakReference.get());
		}
		return null;
	}
	
	@Override
	protected void onPostExecute(List<DeviceRiskStruct> deviceRiskStructs) {
		if (deviceRiskStructs != null && callbackWeakReference.get() != null) {
			callbackWeakReference.get().onRisksReady(deviceRiskStructs);
		}
	}
}
