package uk.co.santander.contextdetection;

import android.util.Base64;

/**
 * Encodes and decodes data using Base64 with NO_WRAP
 */
public class Base64Converter {

    public static String encode(byte[] b) {
        return Base64.encodeToString(b, 0, b.length, Base64.NO_WRAP);
    }

    public static byte[] decode(String s) {
        return Base64.decode(s, Base64.NO_WRAP);
    }
}
