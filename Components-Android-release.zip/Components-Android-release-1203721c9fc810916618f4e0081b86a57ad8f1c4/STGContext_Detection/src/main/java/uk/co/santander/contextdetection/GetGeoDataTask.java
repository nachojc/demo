package uk.co.santander.contextdetection;

import android.content.Context;
import android.location.Address;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.WorkerThread;
import android.util.Log;
import com.globile.santander.mobisec.scal.contextdetection.listeners.GeopositionDataCallback;
import com.globile.santander.mobisec.scal.contextdetection.models.SCALGeoData;
import com.globile.santander.mobisec.scal.contextdetection.models.SCALIpAddress;
import com.google.android.gms.location.LocationResult;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.Scanner;

class GetGeoDataTask extends AsyncTask<Void, Void, SCALGeoData> {

    private WeakReference<GeopositionDataCallback> callbackWeakReference;
    @NonNull
    private final LocationResult locationResult;
    private final WeakReference<Context> contextWeakReference;

    public GetGeoDataTask(@NonNull GeopositionDataCallback callback,
                          @NonNull LocationResult locationResult, Context context) {
        this.callbackWeakReference = new WeakReference<>(callback);
        this.locationResult = locationResult;
        this.contextWeakReference = new WeakReference<>(context);
    }

    @Override
    protected SCALGeoData doInBackground(Void... voids) {
        Address address = LocationProviderImpl.getGeoAddress(contextWeakReference.get(), locationResult.getLastLocation());
        SCALIpAddress addressByIP = getAddressByIP();
        return new SCALGeoData(address, addressByIP);
    }

    @Override
    protected void onPostExecute(SCALGeoData scalGeoData) {
        if (callbackWeakReference != null && callbackWeakReference.get() != null) {
            callbackWeakReference.get().onGeopositionAddressReady(scalGeoData);
        }
    }

    @Nullable
    @WorkerThread
    private static SCALIpAddress getAddressByIP() {// URLConnection GET
        final String[] SERVICES =  new String[]{"http://ip-api.com/json", "https://extreme-ip-lookup.com/json/"};
        SCALIpAddress ipAddress = null;
        int i = 0;
        do {
            String service = SERVICES[i];
            try {
                InputStream response = new URL(service).openStream();
                Scanner scanner = new Scanner(response);
                String responseBody = scanner.useDelimiter("\\A").next();
                if (response != null) response.close();
                Log.i("getAddressByIP", responseBody);
                Gson gson = new Gson();
                ipAddress = gson.fromJson(responseBody, SCALIpAddress.class);
            } catch (IOException e) {
                e.printStackTrace();
            }
            i++;
        } while (ipAddress == null && i < SERVICES.length);
        return ipAddress;
    }
}
