package uk.co.santander.contextdetection;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.annotation.TargetApi;
import android.app.KeyguardManager;
import android.app.admin.DevicePolicyManager;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.nfc.NfcAdapter;
import android.nfc.NfcManager;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.globile.santander.mobisec.scal.contextdetection.models.AppNetworkInfo;
import com.globile.santander.mobisec.scal.contextdetection.models.BluetoothDeviceModel;
import com.globile.santander.mobisec.scal.contextdetection.models.DeviceDataKey;
import com.globile.santander.mobisec.scal.contextdetection.models.InstalledApplication;

import java.io.File;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static android.text.TextUtils.isEmpty;

abstract class DeviceDataProviderImpl {
	
	private static final String TAG = DeviceDataProviderImpl.class.getSimpleName();
	private static final int RESULT_NEGATIVE = -1;
	
	/** DEVICE DATA */
	static Map<DeviceDataKey, String> getDeviceData(Context context) {
		final Map<DeviceDataKey, String> dataMap = new HashMap<>();
		dataMap.put(DeviceDataKey.KEY_BATTERY_LEVEL, String.valueOf(DeviceDataProviderImpl.getBatteryLevel(context)));
		dataMap.put(DeviceDataKey.KEY_OS_VERSION, DeviceDataProviderImpl.getOsVersion());
		dataMap.put(DeviceDataKey.KEY_SECURITY_PATCH, DeviceDataProviderImpl.getSecurityPatchLevel(context));
		dataMap.put(DeviceDataKey.KEY_ROOT, DeviceDataProviderImpl.isRooted() ? "Rooted" : "Unrooted");
		dataMap.put(DeviceDataKey.KEY_DEVICE_VENDOR, DeviceDataProviderImpl.getDeviceVendor());
		dataMap.put(DeviceDataKey.KEY_MODEL_DEVICE, DeviceDataProviderImpl.getDeviceModel());
		dataMap.put(DeviceDataKey.KEY_IMEI, DeviceDataProviderImpl.getIMEI(context));
		dataMap.put(DeviceDataKey.KEY_IMSI, DeviceDataProviderImpl.getIMSI(context));
		dataMap.put(DeviceDataKey.KEY_API_LEVEL, DeviceDataProviderImpl.getApiLevel());
		dataMap.put(DeviceDataKey.KEY_USB_DEBUG, ContextDetectionUtils.parseBooleanToEnable(DeviceDataProviderImpl.isUSBDebugEnabled(context)));
		dataMap.put(DeviceDataKey.KEY_PASSWORD_VISIBLE, ContextDetectionUtils.parseBooleanToEnable(DeviceDataProviderImpl.isShowPasswordSettingEnabled(context)));
		dataMap.put(DeviceDataKey.KEY_CYPHER_DEVICE, ContextDetectionUtils.parseBooleanToAffirmation(DeviceDataProviderImpl.isEncrypted(context)));
		dataMap.put(DeviceDataKey.KEY_DEV_OPTION_ENABLED, ContextDetectionUtils.parseBooleanToEnable(DeviceDataProviderImpl.getDevOptionEnabled(context)));
		dataMap.put(DeviceDataKey.KEY_NOTIFICATION_VISIBLE, ContextDetectionUtils.parseBooleanToAffirmation(DeviceDataProviderImpl.areNotifVisible(context)));
		dataMap.put(DeviceDataKey.KEY_ENROLLED_FINGERPRINT, ContextDetectionUtils.parseBooleanToAffirmation(DeviceDataProviderImpl.hasEnrolledFingerPrints(context)));
		dataMap.put(DeviceDataKey.KEY_DEVICE_LOCK, DeviceDataProviderImpl.getDeviceAuthSettings(context));
		
		return dataMap;
	}
	
	/** APPLICATION DATA */
	
	static Map<DeviceDataKey, String> getApplicationData(Context context) {
		final Map<DeviceDataKey, String> dataMap = new HashMap<>();
		try {
			dataMap.put(DeviceDataKey.KEY_INSTALL_UNKNOWN_SRC, ContextDetectionUtils.parseBooleanToAffirmation(DeviceDataProviderImpl.installUnknownSourcesEnabled(context)));
		} catch (Settings.SettingNotFoundException e) {
			e.printStackTrace();
		}
		
		return dataMap;
	}
	
	static List<InstalledApplication> getInstalledApplicationWithNetworkConnections(Context context) {
		List<AppNetworkInfo> appNetworkInfoList = DeviceDataProviderImpl.getIPConnection(context);
		List<InstalledApplication> appList = DeviceDataProviderImpl.getInstalledApps(context);
		
		for (InstalledApplication applicationData : appList) {
			for (AppNetworkInfo appNetworkInfo : appNetworkInfoList) {
				if (appNetworkInfo.getUID() == applicationData.getKernelUID()) {
					applicationData.addAppNetworkInfo(appNetworkInfo);
					break;
				}
			}
		}
		return appList;
	}
	
	/** COMMUNICATION DATA */
	
	static Map<DeviceDataKey, String> getCommunicationData(Context context) {
		final Map<DeviceDataKey, String> dataMap = new HashMap<>();
		dataMap.put(DeviceDataKey.KEY_IP_V4, DeviceDataProviderImpl.getIPAddress(context, true));
		dataMap.put(DeviceDataKey.KEY_IP_V6, DeviceDataProviderImpl.getIPAddress(context, false));
		dataMap.put(DeviceDataKey.KEY_NETWORK_TYPE, DeviceDataProviderImpl.getNetworkType(context));
		dataMap.put(DeviceDataKey.KEY_NETWORK_SECURITY_TYPE, DeviceDataProviderImpl.getNetworkSecurityType(context));
		dataMap.put(DeviceDataKey.KEY_BLUETOOTH, ContextDetectionUtils.parseBooleanToEnable(DeviceDataProviderImpl.isBluetoothEnabled()));
		dataMap.put(DeviceDataKey.KEY_NFC, ContextDetectionUtils.parseBooleanToEnable(DeviceDataProviderImpl.isNFCEnabled(context)));
		dataMap.put(DeviceDataKey.KEY_VPN_CONNECTED, ContextDetectionUtils.parseBooleanToAffirmation(DeviceDataProviderImpl.isVPNConnected()));
		return dataMap;
	}
	
	/** DATA */
	static int getBatteryLevel(Context context) {
		Intent batteryIntent = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		return batteryIntent != null ?
				batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, RESULT_NEGATIVE) :
				RESULT_NEGATIVE;
	}
	
	static String getOsVersion() {
		return System.getProperty("os.version");
	}
	
	static String getSecurityPatchLevel(Context context) {
		return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ?
				Build.VERSION.SECURITY_PATCH :
				context.getString(R.string.result_none);
	}
	
	static String getIMEI(Context context) {
		TelephonyManager mPhoneManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
			return "N/A";
		}
		return mPhoneManager.getDeviceId();
	}
	
	static String getIMSI(Context context) {
		TelephonyManager mPhoneManager = (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
		if (ActivityCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
			return "N/A";
		}
		return mPhoneManager.getSubscriberId();
	}
	
	/**
	 * Checks if the device is rooted.
	 *
	 * @return <code>true</code> if the device is rooted, <code>false</code> otherwise.
	 */
	static boolean isRooted() {
		
		// get from build info
		String buildTags = android.os.Build.TAGS;
		if (buildTags != null && buildTags.contains("test-keys")) {
			return true;
		}
		
		// check if /system/app/Superuser.apk is present
		try {
			File file = new File("/system/app/Superuser.apk");
			if (file.exists()) {
				return true;
			}
		} catch (Exception e1) {
			// ignore
		}
		
		return findBinary("su");
	}
	
	static boolean findBinary(String binaryName) {
		boolean found = false;
		if (!found) {
			String[] places = {
					"/sbin/", "/system/bin/", "/system/xbin/", "/data/local/xbin/",
					"/data/local/bin/", "/system/sd/xbin/", "/system/bin/failsafe/", "/data/local/"
			};
			for (String where : places) {
				if (new File(where + binaryName).exists()) {
					found = true;
					break;
				}
			}
		}
		return found;
	}
	
	static boolean isBluetoothEnabled() {
		BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter == null) {
			// Device does not support Bluetooth
			return false;
		} else {
			return mBluetoothAdapter.isEnabled();
		}
	}
	
	static boolean isNFCEnabled(Context context) {
		NfcManager manager = (NfcManager) context.getSystemService(Context.NFC_SERVICE);
		if (manager != null) {
			NfcAdapter adapter = manager.getDefaultAdapter();
			if (adapter != null && adapter.isEnabled()) {
				return true;
			}
		}
		return false;
	}
	
	static String getDeviceVendor() {
		return android.os.Build.MANUFACTURER;
	}
	
	static String getDeviceModel() {
		return Build.MODEL;
	}
	
	static String getApiLevel() {
		return String.valueOf(android.os.Build.VERSION.SDK_INT);
	}
	
	static List<String> getDevicesAccount(Context context) {
		List<String> listAccount = new ArrayList<>();
		Account[] accounts = AccountManager.get(context).getAccounts();
		for (Account account : accounts) {
			
			String possibleEmail = account.name;
			String type = account.type;
			
			if (type.equals("com.google")) {
				listAccount.add(possibleEmail);
			}
		}
		return listAccount;
	}
	
	static boolean isUSBDebugEnabled(Context context) {
		if (Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.ADB_ENABLED, 0) == 1) {
			// Debugging enabled
			return true;
		} else {
			// Debugging is not enabled
			return false;
		}
	}
	
	static boolean isShowPasswordSettingEnabled(Context context) {
		if (Settings.Secure.getInt(context.getContentResolver(), Settings.System.TEXT_SHOW_PASSWORD, 0) == 1) {
			// show password enabled
			return true;
		} else {
			// show password is not enabled
			return false;
		}
	}
	
	static boolean isEncrypted(Context context) {
		DevicePolicyManager devicePolicyManager = (DevicePolicyManager) context
				.getSystemService(Context.DEVICE_POLICY_SERVICE);
		
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.HONEYCOMB) {
			int status = devicePolicyManager.getStorageEncryptionStatus();
			if (DevicePolicyManager.ENCRYPTION_STATUS_ACTIVE == status) {
				return true;
			}
		}
		return false;
	}
	
	/** NETWORK DATA */
	
	/**
	 * Get IP address from first non-localhost interface.
	 *
	 * @param context
	 * @param useIPv4 true=return ipv4, false=return ipv6
	 */
	static String getIPAddress(Context context, boolean useIPv4) {
		try {
			List<NetworkInterface> interfaces = Collections.list(NetworkInterface.getNetworkInterfaces());
			for (NetworkInterface netInterface : interfaces) {
				List<InetAddress> addresses = Collections.list(netInterface.getInetAddresses());
				for (InetAddress address : addresses) {
					if (address.isLoopbackAddress()) {
						continue;
					}
					
					String hostAddress = address.getHostAddress();
					//boolean isIPv4 = InetAddressUtils.isIPv4Address(sAddr);
					boolean isIPv4 = hostAddress.indexOf(':') < 0;
					
					if (useIPv4) {
						if (isIPv4) {
							return hostAddress;
						}
					} else if (!isIPv4) {
						int delim = hostAddress.indexOf('%'); // drop ip6 zone suffix
						return (delim < 0 ? hostAddress : hostAddress.substring(0, delim)).toUpperCase();
					}
				}
			}
		} catch (Exception ignored) {
		} // for now eat exceptions
		
		return context.getString(R.string.result_none);
	}
	
	static String getNetworkType(Context context) {
		ConnectivityManager connectivityManager =
				(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivityManager != null) {
			NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
					return context.getString(R.string.network_wifi);
				} else if (networkInfo.getType() == ConnectivityManager.TYPE_MOBILE) {
					return getMobileNetworkType(context, networkInfo.getSubtype());
				}
			}
		}
		
		return context.getString(R.string.result_none);
	}
	
	static String getNetworkSecurityType(Context context) {
		ConnectivityManager connectivityManager =
				(ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (connectivityManager != null) {
			NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
			if (networkInfo != null && networkInfo.isConnected()) {
				if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
					WifiManager wifiManager = (WifiManager) context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
					if (wifiManager != null) {
						WifiInfo info = wifiManager.getConnectionInfo();
						List<WifiConfiguration> configuredNetworks = wifiManager.getConfiguredNetworks();
						if (info != null && configuredNetworks != null && !isEmpty(info.getSSID())) {
							for (WifiConfiguration config : configuredNetworks) {
								if (info.getSSID().equals(config.SSID)) {
									return getSecurityTypeString(wifiManager.getScanResults(), info.getSSID());
								}
							}
						}
					}
				}
			}
		}
		
		return context.getString(R.string.result_none);
	}
	
	@NonNull
	static String getSecurityTypeString(List<ScanResult> networkList, String currentSSID) {
		
		StringBuilder sb = new StringBuilder();
		
		if (networkList != null) {
			for (ScanResult network : networkList) {
				//check if current connected SSID
				if (currentSSID.replace("\"", "").equalsIgnoreCase(network.SSID)) {
					//get capabilities of current connection
					String capabilities = network.capabilities;
					Log.d(ContextDetectionUtils.TAG, network.SSID + " capabilities : " + capabilities);
					
					Pattern p = Pattern.compile("\\[([\\w+-?]+)\\]");
					Matcher m = p.matcher(capabilities);
					if (m.find()) {
						return m.group().replace("[", "").replace("]", "");
					} else {
						return capabilities;
					}
				}
			}
		}
		
		if (sb.length() == 0) {
			sb.append("NOT SECURED");
		}
		
		return sb.toString();
	}
	
	private static String getMobileNetworkType(Context context, Integer subtype) {
		int networkType;
		
		if (subtype != null) {
			networkType = subtype;
		} else {
			TelephonyManager telephonyManager =
					(TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
			if (telephonyManager != null) {
				networkType = telephonyManager.getNetworkType();
			} else {
				return context.getString(R.string.result_none);
			}
		}
		
		switch (networkType) {
			case TelephonyManager.NETWORK_TYPE_1xRTT:
				return "1xRTT";
			case TelephonyManager.NETWORK_TYPE_CDMA:
				return "CDMA";
			case TelephonyManager.NETWORK_TYPE_EDGE:
				return "EDGE";
			case TelephonyManager.NETWORK_TYPE_EHRPD:
				return "eHRPD";
			case TelephonyManager.NETWORK_TYPE_EVDO_0:
				return "EVDO rev. 0";
			case TelephonyManager.NETWORK_TYPE_EVDO_A:
				return "EVDO rev. A";
			case TelephonyManager.NETWORK_TYPE_EVDO_B:
				return "EVDO rev. B";
			case TelephonyManager.NETWORK_TYPE_GPRS:
				return "GPRS";
			case TelephonyManager.NETWORK_TYPE_HSDPA:
				return "HSDPA";
			case TelephonyManager.NETWORK_TYPE_HSPA:
				return "HSPA";
			case TelephonyManager.NETWORK_TYPE_HSPAP:
				return "HSPA+";
			case TelephonyManager.NETWORK_TYPE_HSUPA:
				return "HSUPA";
			case TelephonyManager.NETWORK_TYPE_IDEN:
				return "iDen";
			case TelephonyManager.NETWORK_TYPE_LTE:
				return "LTE";
			case TelephonyManager.NETWORK_TYPE_UMTS:
				return "UMTS";
			default:
				return context.getString(R.string.network_mobile_unknown);
		}
	}
	
	/**
	 * To get device consuming network type is 2g,3g,4g
	 *
	 * @param context
	 *
	 * @return "2g","3g","4g" as a String based on the network type
	 */
	static String getNetworkFormattedType(Context context) {
		TelephonyManager mTelephonyManager = (TelephonyManager)
				context.getSystemService(Context.TELEPHONY_SERVICE);
		int networkType = mTelephonyManager.getNetworkType();
		switch (networkType) {
			case TelephonyManager.NETWORK_TYPE_GPRS:
			case TelephonyManager.NETWORK_TYPE_EDGE:
			case TelephonyManager.NETWORK_TYPE_CDMA:
			case TelephonyManager.NETWORK_TYPE_1xRTT:
			case TelephonyManager.NETWORK_TYPE_IDEN:
				return "2g";
			case TelephonyManager.NETWORK_TYPE_UMTS:
			case TelephonyManager.NETWORK_TYPE_EVDO_0:
			case TelephonyManager.NETWORK_TYPE_EVDO_A:
			case TelephonyManager.NETWORK_TYPE_HSDPA:
			case TelephonyManager.NETWORK_TYPE_HSUPA:
			case TelephonyManager.NETWORK_TYPE_HSPA:
			case TelephonyManager.NETWORK_TYPE_EVDO_B:
			case TelephonyManager.NETWORK_TYPE_EHRPD:
			case TelephonyManager.NETWORK_TYPE_HSPAP:
				return "3g";
			case TelephonyManager.NETWORK_TYPE_LTE:
				return "4g";
			default:
				return "Notfound";
		}
	}
	
	/**
	 * To check device has internet
	 *
	 * @param context
	 *
	 * @return boolean as per status
	 */
	static boolean isNetworkConnected(Context context) {
		ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
		if (cm != null) {
			NetworkInfo netInfo = cm.getActiveNetworkInfo();
			return netInfo != null && netInfo.isConnected();
		}
		return false;
	}
	
	//////////////////////////////////////////// SEC DATA ////////////////////////////////////////////////////
	
	static String getDeviceAuthSettings(Context context) {
		boolean hasEnrolledFingerprints = hasEnrolledFingerPrints(context);
		boolean hasPatternOrPIN = isDeviceScreenLocked(context);
		
		if (hasEnrolledFingerprints) {
			return "Biometric";
		} else if (hasPatternOrPIN) {
			return "PatternOrPIN";
		} else {
			return "NotEnabled";
		}
	}
	
	static boolean areNotifVisible(Context context) {
		int showAll = Settings.Secure.getInt(context.getContentResolver(), "lock_screen_allow_private_notifications", -1);
		int notiEnabled = Settings.Secure.getInt(context.getContentResolver(), "lock_screen_show_notifications", -1);
		
		if (showAll > 0 && notiEnabled > 0) {
			return Boolean.TRUE;
		} else {
			return Boolean.FALSE;
		}
	}
	
	static String getMalwareDetection(Context context) {
		return context.getString(R.string.result_none);
	}
	
	static String getTamperDetection(Context context) {
		return context.getString(R.string.result_none);
	}
	
	static String getPUADetection(Context context) {
		return context.getString(R.string.result_none);
	}
	
	static String getGoodwareVulnApps(Context context) {
		return context.getString(R.string.result_none);
	}
	
	/**
	 * If devOptionEnabled == 1, DevOption is enabled
	 */
	static boolean getDevOptionEnabled(Context context) {
		return Settings.Secure.getInt(context.getContentResolver(),
				Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1;
	}
	
	static boolean installUnknownSourcesEnabled(Context context) throws Settings.SettingNotFoundException {
		return Settings.Secure.getInt(context.getContentResolver(), Settings.Secure.INSTALL_NON_MARKET_APPS) == 1;
	}
	
	static boolean isVPNConnected() {
		List<String> networkList = new ArrayList<>();
		try {
			for (NetworkInterface networkInterface : Collections.list(NetworkInterface.getNetworkInterfaces())) {
				if (networkInterface.isUp()) {
					networkList.add(networkInterface.getName());
				}
			}
		} catch (Exception ex) {
			Log.d("ContextDetectionModule", "isVpnUsing Network List didn't received");
		}
		
		return networkList.contains("tun0");
	}
	
	static boolean hasEnrolledFingerPrints(Context context) {
		boolean hasEnrolledFingerPrint = Boolean.FALSE;
		
		// Check if we're running on Android 6.0 (M) or higher
		if (BiometricUtils.isSdkVersionSupported()) {
			//Fingerprint API only available on from Android 6.0 (M)
			if (BiometricUtils.isFingerprintAvailable(context)) {
				// User has enrolled one or more fingerprints to authenticate with
				hasEnrolledFingerPrint = Boolean.TRUE;
			}
		}
		
		return hasEnrolledFingerPrint;
	}
	
	static boolean isDeviceScreenLocked(Context context) {
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
			return isDeviceLocked(context);
		} else {
			return isPatternSet(context) || isPassOrPinSet(context);
		}
	}
	
	/**
	 * @return true if pattern set, false if not (or if an issue when checking)
	 */
	static boolean isPatternSet(Context context) {
		ContentResolver cr = context.getContentResolver();
		try {
			int lockPatternEnable = Settings.Secure.getInt(cr, Settings.Secure.LOCK_PATTERN_ENABLED);
			return lockPatternEnable == 1;
		} catch (Settings.SettingNotFoundException e) {
			return false;
		}
	}
	
	/**
	 * @return true if pass or pin set
	 */
	static boolean isPassOrPinSet(Context context) {
		KeyguardManager keyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE); //api 16+
		return keyguardManager.isKeyguardSecure();
	}
	
	/**
	 * @return true if pass or pin or pattern locks screen
	 */
	@TargetApi(23)
	static boolean isDeviceLocked(Context context) {
		KeyguardManager keyguardManager = (KeyguardManager) context.getSystemService(Context.KEYGUARD_SERVICE); //api 23+
		return keyguardManager.isDeviceSecure();
	}
	
	static List<BluetoothDeviceModel> getBluetoothDevices() {
		
		List<BluetoothDeviceModel> mBTDevices = new ArrayList<>();
		BluetoothAdapter mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
		if (mBluetoothAdapter != null) {
			Set<BluetoothDevice> devices = mBluetoothAdapter.getBondedDevices();
			
			for (BluetoothDevice device : devices) {
				BluetoothDeviceModel deviceModel = new BluetoothDeviceModel();
				
				String name = device.getName();
				Integer type = -1;
				if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.JELLY_BEAN_MR2) {
					type = device.getType();
				}
				String address = device.getAddress();
				
				deviceModel.setDeviceName(name);
				deviceModel.setAddress(address);
				deviceModel.setType(type);
				
				mBTDevices.add(deviceModel);
			}
		}
		return mBTDevices;
	}
	
	static List<AppNetworkInfo> getIPConnection(Context context) {
		NetworkDataProvider networkDataProvider = new NetworkDataProvider(context);
		networkDataProvider.buildNetstat();
		return networkDataProvider.getAppInfos();
	}
	
	static List<InstalledApplication> getInstalledApps(Context context) {
		List<InstalledApplication> installedApp = new ArrayList<>();
		
		List<PackageInfo> packList = context.getPackageManager().getInstalledPackages(0);
		for (int i = 0; i < packList.size(); i++) {
			PackageInfo packInfo = packList.get(i);
			if ((packInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) == 0) {
				InstalledApplication app = new InstalledApplication();
				app.setName(packInfo.applicationInfo.loadLabel(context.getPackageManager()).toString());
				app.setPackageName(packInfo.applicationInfo.className);
				if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
					app.setCategory(packInfo.applicationInfo.category);//Requires API 26
				}
				app.setKernelUID(packInfo.applicationInfo.uid);
				app.setDescription(packInfo.applicationInfo.loadDescription(context.getPackageManager()) != null
						? packInfo.applicationInfo.loadDescription(context.getPackageManager()).toString() : "Not description found");
				
				installedApp.add(app);
			}
		}
		return installedApp;
	}
}
