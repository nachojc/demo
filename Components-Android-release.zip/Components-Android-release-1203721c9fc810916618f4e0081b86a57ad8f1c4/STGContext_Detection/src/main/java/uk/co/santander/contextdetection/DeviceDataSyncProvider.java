package uk.co.santander.contextdetection;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.location.Address;
import android.provider.Settings;
import android.support.annotation.Nullable;
import com.globile.santander.mobisec.scal.contextdetection.models.*;
import com.globile.santander.mobisec.scal.securestorage.sharedPrefs.SCALSharedPreferencesSecureStorageModule;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class DeviceDataSyncProvider {
	
	public static final String FOOTPRINT = "Footprint";
	private static final String SHA_512 = "SHA-512";
	public static final String ANDROID_ID = "Android_ID";
	public static final String CONTEXT_DECTECTION = "ContextDectection";
	
	public static SCALDeviceData getDeviceData(Context context) {
		return new SCALDeviceData(DeviceDataProviderImpl.getDeviceData(context));
	}
	
	public static SCALApplicationData getApplicationData(Context context) {
		Map<DeviceDataKey, String> dataMap = DeviceDataProviderImpl.getApplicationData(context);
		List<InstalledApplication> installedApplications = DeviceDataProviderImpl.getInstalledApplicationWithNetworkConnections(context);
		List<String> accounts = DeviceDataProviderImpl.getDevicesAccount(context);
		return new SCALApplicationData(dataMap, installedApplications, accounts);
	}
	
	public static SCALCommsData getCommunicationData(Context context) {
		List<BluetoothDeviceModel> bluetoothDevices = DeviceDataProviderImpl.getBluetoothDevices();
		Map<DeviceDataKey, String> dataMap = DeviceDataProviderImpl.getCommunicationData(context);
		return new SCALCommsData(dataMap, bluetoothDevices);
	}
	
	public static SCALContextData getAllSyncData(Context context) {
		SCALDeviceData deviceData = getDeviceData(context);
		SCALCommsData commsData = getCommunicationData(context);
		SCALApplicationData applicationData = getApplicationData(context);
		return new SCALContextData(deviceData, commsData, applicationData);
	}
	
	/**
	 * Call this method in order to obtain all Google Account of the device.
	 *
	 * @param context
	 *
	 * @return List<String> with the Google Device Account List
	 */
	public static List<String> getUserBinding(Context context) {
		return DeviceDataProviderImpl.getDevicesAccount(context);
	}
	
	/*	*//**
	 * Call this method in order to obtain the Fingerprintdata of the device.
	 *
	 * @param context
	 *
	 * @return DeviceFingerprintData which contains IMEI and IMSI device.
	 *//*
	public static DeviceFingerprintData getDeviceFingerprinting(Context context) {
		DeviceFingerprintData deviceFingerprint = new DeviceFingerprintData();
		deviceFingerprint.setIMEI(DeviceDataProviderImpl.getIMEI(context));
		deviceFingerprint.setIMSI(DeviceDataProviderImpl.getIMSI(context));
		return deviceFingerprint;
	}
	*/
	
	/**
	 * Return stored device footprint.
	 *
	 * @param sharedPreferencesImpl
	 * @param footprint
	 */
	public static void setDeviceFootprint(SCALSharedPreferencesSecureStorageModule sharedPreferencesImpl, String footprint) {
		sharedPreferencesImpl.setString(FOOTPRINT, footprint, CONTEXT_DECTECTION);
	}
	
	/**
	 * Returns the device footprint BASE64(SHA-512(SHA-512(SEED)))
	 * The SEED is the ANDROID_ID, which is read only once from the system and then stored in the encrypted prefs.
	 *
	 * If the ANDROID_ID cannot be retrieved, a UUID is used.
	 *
	 * @return the device footprint
	 */
	public static String getDeviceFingerprinting(SCALSharedPreferencesSecureStorageModule sharedPreferencesImpl, ContentResolver contentResolver) {
		String storedFingerprint = sharedPreferencesImpl.getString(FOOTPRINT, CONTEXT_DECTECTION);
		if (storedFingerprint != null && !storedFingerprint.isEmpty()) {
			return storedFingerprint;
		}
		
		try {
			String sSeed = getFootprintSeed(sharedPreferencesImpl, contentResolver);
			byte[] seed = calculateHash(sSeed.getBytes(), SHA_512);
			byte[] hashedData = calculateHash(seed, SHA_512);
			return Base64Converter.encode(hashedData);
		} catch (NoSuchAlgorithmException e) {
			// SHA-512 is supported from Android 1+, this can't happen
			throw new RuntimeException(e);
		}
	}
	
	private static String getFootprintSeed(SCALSharedPreferencesSecureStorageModule sharedPreferences, ContentResolver contentResolver) {
		String seed = sharedPreferences.getString(ANDROID_ID, CONTEXT_DECTECTION);
		if (seed == null) {
			// if the footprint seed was not stored, read it from system and store it now
			seed = readFootprintSeedFromSystem(contentResolver);
			sharedPreferences.setString(ANDROID_ID, seed, CONTEXT_DECTECTION);
		}
		return seed;
	}
	
	@SuppressLint("HardwareIds")
	private static String readFootprintSeedFromSystem(ContentResolver contentResolver) {
		String androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID);
		if (androidId == null || androidId.isEmpty()) {
			androidId = UUID.randomUUID().toString(); // fallback to UUID
		}
		return androidId;
	}
	
	private static byte[] calculateHash(byte[] param, String digest) throws NoSuchAlgorithmException {
		MessageDigest md = MessageDigest.getInstance(digest);
		md.update(param);
		return md.digest();
	}
	
	/** Risk calculations */
	/**
	 * Call this methods in order to obtain the device calculation structure risk.
	 *
	 * @return List<DeviceRiskStruct>, each DeviceRiskStruct contains parameter, valueDetected and riskCalculated.
	 * (e.g. Parameter = "Wifi Type", "Value detected": "WPA", "Risk calculated": 5)
	 */
	public static List<DeviceRiskStruct> getDeviceRiskData(Context context) {
		return DeviceRiskCalculation.getDeviceRiskStruct(context);
	}
	
	/**
	 * Call this methods in order to obtain the application calculation structure risk.
	 *
	 * @return List<DeviceRiskStruct>, each DeviceRiskStruct contains parameter, valueDetected and riskCalculated.
	 * (e.g. Parameter = "Wifi Type", "Value detected": "WPA", "Risk calculated": 5)
	 */
	public static List<DeviceRiskStruct> getApplicationRiskData(Context context) {
		return DeviceRiskCalculation.getApplicationRiskStruct(context);
	}
	
	/**
	 * Call this methods in order to obtain the communication calculation structure risk.
	 *
	 * @return List<DeviceRiskStruct>, each DeviceRiskStruct contains parameter, valueDetected and riskCalculated.
	 * (e.g. Parameter = "Wifi Type", "Value detected": "WPA", "Risk calculated": 5)
	 */
	public static List<DeviceRiskStruct> getCommunicationRiskData(Context context) {
		return DeviceRiskCalculation.getCommunicationRiskStruct(context);
	}
	
	/**
	 * Call this methods in order to obtain the all calculation structure risk.
	 *
	 * @param context
	 *
	 * @return
	 */
	public static List<DeviceRiskStruct> getAllRiskData(Context context) {
		List<DeviceRiskStruct> deviceRiskStructs = new ArrayList<>();
		deviceRiskStructs.addAll(getDeviceRiskData(context));
		deviceRiskStructs.addAll(getApplicationRiskData(context));
		deviceRiskStructs.addAll(getCommunicationRiskData(context));
		return deviceRiskStructs;
	}
	
	public static List<DeviceRiskStruct> getGeopositionRisk(@Nullable Address address) {
		List<DeviceRiskStruct> deviceRiskStructs = new ArrayList<>();
		//TODO: implement geoposition risk with the address provided
		return deviceRiskStructs;
		
	}
}

