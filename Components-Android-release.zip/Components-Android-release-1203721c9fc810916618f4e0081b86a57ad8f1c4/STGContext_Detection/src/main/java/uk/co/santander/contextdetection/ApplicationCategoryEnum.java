package uk.co.santander.contextdetection;

public enum ApplicationCategoryEnum {
    CATEGORY_AUDIO(1),
    CATEGORY_GAME(0),
    CATEGORY_IMAGE(3),
    CATEGORY_MAPS(6),
    CATEGORY_NEWS(5),
    CATEGORY_PRODUCTIVITY(7),
    CATEGORY_SOCIAL(4),
    CATEGORY_UNDEFINED(-1),
    CATEGORY_VIDEO(2);

    private int categoryId;

    ApplicationCategoryEnum(int categoryId){
        this.categoryId = categoryId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public static String getCategoryById(int categoryId){
        for(ApplicationCategoryEnum category : ApplicationCategoryEnum.values()){
            if(category.getCategoryId() == categoryId){
                return category.name();
            }
        }

        return null;
    }
}
