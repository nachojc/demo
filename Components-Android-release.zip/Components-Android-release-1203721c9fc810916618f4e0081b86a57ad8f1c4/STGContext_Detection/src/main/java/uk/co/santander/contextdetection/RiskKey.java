package uk.co.santander.contextdetection;

public enum RiskKey {

    KEY_RISK_OS_VERSION("RD1. OS version"),
    KEY_RISK_DEV_OPTIONS("RD2. Dev options"),
    KEY_RISK_JAILBREAK_ROOT("RD3. Jailbreak/root"),
    KEY_RISK_USB("RD4. USB"),
    KEY_RISK_DEVICE_AUTH_SETTINGS("RD5. Device Auth settings"),
    KEY_RISK_GEOLOCATION("RDa1. Geolocation"),
    KEY_RISK_VISIBLE_NOTIFICATIONS("RDa2. Visible notifications"),
    KEY_RISK_MALWARE_DETECTION("RA1. Malware detection"),
    KEY_RISK_TAMPER_DETECTION("RA2. Tamper detection"),
    KEY_RISK_PUA_DETECTION("RA3. PUA detection"),
    KEY_RISK_GOODWARE_VULN_APPS("RA4. Goodware vulnerable applications"),
    KEY_RISK_OPEN_PORTS("RA5. Apps open ports and connections to remote IPs"),
    KEY_RISK_WIFI_TYPE("RC1. WIFI Type"),
    KEY_RISK_DATA_TRANSMISSION("RC2. Data transmission protocol"),
    KEY_RISK_BLUETOOTH("RC3. Bluetooth"),
    KEY_RISK_NFC("RC4. NFC");

    String nameRiskKey;

    RiskKey(String nameRiskKey){
        this.nameRiskKey = nameRiskKey;
    }

    public String getNameRiskKey() {
        return nameRiskKey;
    }

    public void setNameRiskKey(String nameRiskKey) {
        this.nameRiskKey = nameRiskKey;
    }
}
