# Introduction 
This repository contains all the Globile Architecture Components for Android. Each subdirectory corresponds to one of these components, and has its own README file to explain its use.

# Components
- [Cache](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/cachelib)
- [Card Reader](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/cardreaderlib)
- [Device Info](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/deviceinfolib)
- [Functional Analytics](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/functionalanalyticslib)
- [Local Storage](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/localstoragelib)
- [Secure Storage](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/securelocalstoragelib)
- [Service Invocation](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/serviceinvocationlib)
- [Technical Analytics](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/technicalanalyticslib)
- [UI Components](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/uicomponentslib)
- [Webview Bridge](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib)
