package com.globile.santander.mobisec.scal.biometricvault;

public interface StoreCredentialCallback {

    /**
     * If storeCredentialAuthenticated succeeds, the callback will return a true value.
     * @param isSuccess
     */
    void onStoreAuthenticatedData(Boolean isSuccess);

    /**
     * Triggered when a error becomes.
     * @param message
     */
    void onStoreAuthenticationFailure(String message);
}
