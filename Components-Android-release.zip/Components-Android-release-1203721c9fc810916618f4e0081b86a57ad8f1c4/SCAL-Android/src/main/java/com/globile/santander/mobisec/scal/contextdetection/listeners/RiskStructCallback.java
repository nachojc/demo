package com.globile.santander.mobisec.scal.contextdetection.listeners;

import com.globile.santander.mobisec.scal.contextdetection.models.DeviceRiskStruct;

import java.util.List;

public interface RiskStructCallback extends GeopositionRiskCallback {
	
	/**
	 * Called when all risks calculation are ready including geoposition
	 *
	 * @param deviceRiskStructs list of DeviceRiskStruct
	 */
	void onRisksReady(List<DeviceRiskStruct> deviceRiskStructs);
	
}