package com.globile.santander.mobisec.scal.contextdetection.models;

import java.util.List;
import java.util.Map;

public class SCALCommsData {
	
	private Map<DeviceDataKey, String> commsData;
	private List<BluetoothDeviceModel> bluetoothDeviceModels;
	
	public SCALCommsData(Map<DeviceDataKey, String> commsData, List<BluetoothDeviceModel> bluetoothDeviceModels) {
		this.commsData = commsData;
		this.bluetoothDeviceModels = bluetoothDeviceModels;
	}
	
	public Map<DeviceDataKey, String> getCommsData() {
		return commsData;
	}
	
	public List<BluetoothDeviceModel> getBluetoothDeviceModels() {
		return bluetoothDeviceModels;
	}
}
