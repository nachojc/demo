package com.globile.santander.mobisec.scal.contextdetection.models;

import java.util.ArrayList;
import java.util.List;

public class AppNetworkInfo {
	
	private int UID;
	private String name = "";
	private List<NetworkAddressConnection> tcp = new ArrayList<>();
	private List<NetworkAddressConnection> tcp6 = new ArrayList<>();
	private List<NetworkAddressConnection> udp = new ArrayList<>();
	private List<NetworkAddressConnection> udp6 = new ArrayList<>();
	
	public AppNetworkInfo() {
	}
	
	public AppNetworkInfo(int UID, String name) {
		this.UID = UID;
		this.name = name;
	}
	
	public int getUID() {
		return this.UID;
	}
	
	public String getName() {
		return (this.name == null) ? " " : this.name;
	}
	
	public void addTcp(NetworkAddressConnection tcp) {
		this.tcp.add(tcp);
	}
	
	public void addTcp6(NetworkAddressConnection tcp6) {
		this.tcp6.add(tcp6);
	}
	
	public void addUdp(NetworkAddressConnection udp) {
		this.udp.add(udp);
	}
	
	public void addUdp6(NetworkAddressConnection udp6) {
		this.udp6.add(udp6);
	}
	
	public List<NetworkAddressConnection> getTcp() {
		return this.tcp;
	}
	
	public List<NetworkAddressConnection> getTcp6() {
		return this.tcp6;
	}
	
	public List<NetworkAddressConnection> getUdp() {
		return this.udp;
	}
	
	public List<NetworkAddressConnection> getUdp6() {
		return this.udp6;
	}
	
	public String toString() {
		if (UID == -1) {
			return this.name;
		}
		StringBuilder output = new StringBuilder();
		output.append("" + this.name + ((this.name == null) ? (" UID: " + this.UID) : "") + "\n\n");
		for (NetworkAddressConnection addressConnection : tcp) {
			output.append("\t");
			output.append(addressConnection.toString());
			output.append("\n");
		}
		for (NetworkAddressConnection addressConnection : tcp6) {
			output.append("\t");
			output.append(addressConnection.toString());
			output.append("\n");
		}
		for (NetworkAddressConnection addressConnection : udp) {
			output.append("\t");
			output.append(addressConnection.toString());
			output.append("\n");
		}
		for (NetworkAddressConnection addressConnection : udp6) {
			output.append("\t");
			output.append(addressConnection.toString());
			output.append("\n");
		}
		
		return output.toString();
	}
	
}
