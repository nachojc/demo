package com.globile.santander.mobisec.scal.contextdetection.listeners;

import com.globile.santander.mobisec.scal.contextdetection.models.SCALGeoData;

public interface GeopositionDataCallback extends GeopositionCallback {
	
	/**
	 * Called when the address has been calculated using geocoder
	 *
	 * @param scalGeoData
	 */
	void onGeopositionAddressReady(SCALGeoData scalGeoData);
	
}