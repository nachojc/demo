package com.globile.santander.mobisec.scal.contextdetection.listeners;

import com.globile.santander.mobisec.scal.contextdetection.models.SCALCommsData;

public interface CommsDataCallback {
	
	/**
	 * Called when the data is ready to use
	 *
	 * @param commsData communications information
	 */
	void onCommsDataReady(SCALCommsData commsData);
	
}