package com.globile.santander.mobisec.scal.contextdetection;

import android.app.Activity;
import com.globile.santander.mobisec.scal.contextdetection.listeners.*;
import com.globile.santander.mobisec.scal.contextdetection.models.DeviceRiskStruct;

import java.util.List;

public interface SCALContextDetectionModule {
	
	/**
	 * Call this method in order to obtain all Google Account of the device.
	 *
	 * @return List<String> with the Google Device Account List
	 */
	List<String> getUserBinding();
	
	/**
	 * Call this method in order to obtain the Footprint of the device.
	 *
	 * @return Footprint device data as string which contains hashed ANDROID_ID or a hashed random UUID.
	 */
	String getDeviceFootprint();
	
	/**
	 * Call this method in order to store a custom Footprint, as Footprint of the device.
	 *
	 * @param footprint as an encrypted string which the module are going to store.
	 */
	void setDeviceFootprint(String footprint);
	
	/** Risk calculations */
	/**
	 * Call this methods in order to obtain the device calculation structure risk.
	 */
	List<DeviceRiskStruct> getDeviceRiskData();
	
	/**
	 * Call this methods in order to obtain the application calculation structure risk.
	 */
	List<DeviceRiskStruct> getApplicationRiskData();
	
	/**
	 * Call this methods in order to obtain the communication calculation structure risk.
	 */
	List<DeviceRiskStruct> getCommunicationRiskData();
	
	/**
	 * Call this methods in order to obtain the geoposition calculation structure risk.
	 */
	void getGeopositionRiskData(GeopositionRiskCallback geopositionRiskCallback, Activity activity);
	
	/**
	 * Call this methods in order to obtain all calculation structure risk.
	 *
	 * @param riskCallback callback that will be called when the risks are ready
	 * @param activity     calling activity
	 */
	void getAllRiskData(RiskStructCallback riskCallback, Activity activity);
	
	/** Device, Application and Communication data */
	/**
	 * Call this method in order to obtain available data of the device.
	 *
	 * @param deviceDataCallback callback that will be called when the data is ready
	 */
	void getDeviceData(DeviceDataCallback deviceDataCallback);
	
	/**
	 * Call this method in order to obtain available data of the applications.
	 *
	 * @param applicationDataCallback callback that will be called when the data is ready
	 */
	void getApplicationData(ApplicationDataCallback applicationDataCallback);
	
	/**
	 * Call this method in order to obtain available data of communication.
	 *
	 * @param commsDataCallback callback that will be called when the data is ready
	 */
	void getCommunicationData(CommsDataCallback commsDataCallback);
	
	/**
	 * Call this method in order to obtain available data of geoposition
	 *
	 * @param geopositionDataCallback callback that will be called when the data is ready
	 * @param activity                calling activity
	 */
	void getGeopositionData(GeopositionDataCallback geopositionDataCallback, Activity activity);
	
	/**
	 * Call this method in order to obtain available data.
	 *
	 * Make sure the permissions are granted before calling this method. The list of permissions is: ACCESS_COARSE_LOCATION, ACCESS_FINE_LOCATION,
	 * READ_PHONE_STATE, GET_ACCOUNTS and ACCESS_NETWORK_STATE. If the permissions are denied, the results will be incomplete but it will no fail.
	 *
	 * @param callback                callback that will be called when the data is ready
	 * @param geopositionDataCallback callback that will be called when the geoposition is ready
	 * @param activity                calling activity
	 */
	void getAllData(ContextDataCallback callback, GeopositionDataCallback geopositionDataCallback, Activity activity);
	
}
