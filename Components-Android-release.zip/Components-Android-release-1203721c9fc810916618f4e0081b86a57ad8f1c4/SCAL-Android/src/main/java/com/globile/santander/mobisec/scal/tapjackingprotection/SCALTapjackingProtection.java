package com.globile.santander.mobisec.scal.tapjackingprotection;

import android.view.MotionEvent;

public class SCALTapjackingProtection implements SCALTapjackingProtectionModule {
    private SCALTapjackingProtectionModule tapjackingProtectionImpl;

    public SCALTapjackingProtection(SCALTapjackingProtectionModule tapjackingProtectionImpl) {
        this.tapjackingProtectionImpl = tapjackingProtectionImpl;
    }

    @Override
    public void activeTapjackingProtection(OnTapjackingCallback callback) {
        tapjackingProtectionImpl.activeTapjackingProtection(callback);
    }

    @Override
    public boolean onFilterTouchEventForSecurity(MotionEvent event) {
        return tapjackingProtectionImpl.onFilterTouchEventForSecurity(event);
    }
}
