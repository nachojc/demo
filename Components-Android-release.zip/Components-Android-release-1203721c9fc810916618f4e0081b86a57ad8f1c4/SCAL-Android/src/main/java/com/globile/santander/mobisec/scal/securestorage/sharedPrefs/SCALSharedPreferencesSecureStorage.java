package com.globile.santander.mobisec.scal.securestorage.sharedPrefs;

import android.support.annotation.Nullable;

public class SCALSharedPreferencesSecureStorage implements SCALSharedPreferencesSecureStorageModule {
	
	private SCALSharedPreferencesSecureStorageModule secureStorageImpl;
	
	public SCALSharedPreferencesSecureStorage(SCALSharedPreferencesSecureStorageModule secureStorageImpl) {
		this.secureStorageImpl = secureStorageImpl;
	}
	
	@Override
	public boolean createNewSecureSharedPreferences(String name) {
		return secureStorageImpl.createNewSecureSharedPreferences(name);
	}
	
	@Override
	public boolean clearSecureSharedPreferences(String name) {
		return secureStorageImpl.clearSecureSharedPreferences(name);
	}
	
	@Override
	public boolean deleteSecureSharedPreferences(String name) {
		return secureStorageImpl.deleteSecureSharedPreferences(name);
	}
	
	@Override
	public boolean setBoolean(String key, @Nullable Boolean value, String sharedPreferencesName) {
		return secureStorageImpl.setBoolean(key, value, sharedPreferencesName);
	}
	
	@Override
	public boolean setString(String key, @Nullable String value, String sharedPreferencesName) {
		return secureStorageImpl.setString(key, value, sharedPreferencesName);
	}
	
	@Override
	public boolean setInteger(String key, @Nullable Integer value, String sharedPreferencesName) {
		return secureStorageImpl.setInteger(key, value, sharedPreferencesName);
	}
	
	@Override
	public boolean setLong(String key, @Nullable Long value, String sharedPreferencesName) {
		return secureStorageImpl.setLong(key, value, sharedPreferencesName);
	}
	
	@Override
	public boolean setDouble(String key, @Nullable Double value, String sharedPreferencesName) {
		return secureStorageImpl.setDouble(key, value, sharedPreferencesName);
	}
	
	@Override
	public boolean setFloat(String key, @Nullable Float value, String sharedPreferencesName) {
		return secureStorageImpl.setFloat(key, value, sharedPreferencesName);
	}
	
	@Nullable
	@Override
	public Boolean getBoolean(String key, String sharedPreferencesName) {
		return secureStorageImpl.getBoolean(key, sharedPreferencesName);
	}
	
	@Nullable
	@Override
	public String getString(String key, String sharedPreferencesName) {
		return secureStorageImpl.getString(key, sharedPreferencesName);
	}
	
	@Nullable
	@Override
	public Integer getInteger(String key, String sharedPreferencesName) {
		return secureStorageImpl.getInteger(key, sharedPreferencesName);
	}
	
	@Nullable
	@Override
	public Long getLong(String key, String sharedPreferencesName) {
		return secureStorageImpl.getLong(key, sharedPreferencesName);
	}
	
	@Nullable
	@Override
	public Double getDouble(String key, String sharedPreferencesName) {
		return secureStorageImpl.getDouble(key, sharedPreferencesName);
	}
	
	@Nullable
	@Override
	public Float getFloat(String key, String sharedPreferencesName) {
		return secureStorageImpl.getFloat(key, sharedPreferencesName);
	}
}
