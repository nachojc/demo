package com.globile.santander.mobisec.scal.contextdetection.models;

import java.util.Map;

public class SCALDeviceData {
	
	private Map<DeviceDataKey, String> deviceData;
	
	public SCALDeviceData(Map<DeviceDataKey, String> deviceData) {
		this.deviceData = deviceData;
	}
	
	public Map<DeviceDataKey, String> getDeviceData() {
		return deviceData;
	}
	
}
