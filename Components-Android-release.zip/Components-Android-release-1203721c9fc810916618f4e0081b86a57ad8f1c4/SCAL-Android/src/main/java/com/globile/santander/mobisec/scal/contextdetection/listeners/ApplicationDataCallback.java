package com.globile.santander.mobisec.scal.contextdetection.listeners;

import com.globile.santander.mobisec.scal.contextdetection.models.SCALApplicationData;

public interface ApplicationDataCallback {
	
	/**
	 * Called when the data is ready to use
	 *
	 * @param applicationData applications information
	 */
	void onApplicationDataReady(SCALApplicationData applicationData);
	
}