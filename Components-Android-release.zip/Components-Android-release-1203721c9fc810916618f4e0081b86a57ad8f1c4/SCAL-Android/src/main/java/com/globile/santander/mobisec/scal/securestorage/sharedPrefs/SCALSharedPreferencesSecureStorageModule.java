package com.globile.santander.mobisec.scal.securestorage.sharedPrefs;
import android.support.annotation.Nullable;

public interface SCALSharedPreferencesSecureStorageModule {

	/**
	 * Creates a new editable {@link android.content.SharedPreferences} file.
	 * Will do nothing if the file already exists.
	 *
	 * @param name The name of the preferences file
	 * @return if could create an editable preferences file
	 */
	boolean createNewSecureSharedPreferences(String name);

	/**
	 * Deletes all the entries of a {@link android.content.SharedPreferences} file.
	 * Will create the file if it does not exist.
	 *
	 * @param name The name of the preferences file
	 * @return if could delete all the entries
	 */
	boolean clearSecureSharedPreferences(String name);

	/**
	 * Deletes a {@link android.content.SharedPreferences} file.
	 *
	 * @param name The name of the preferences file
	 * @return if could delete an editable preferences file
	 */
	boolean deleteSecureSharedPreferences(String name);

	/**
	 * Encrypts and stores a {@link Boolean} in a {@link android.content.SharedPreferences} file.
	 * @param key the key to the value. Will be encrypted
	 * @param value the value. Will be encrypted
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return if could encrypt the key and the value
	 */
	boolean setBoolean(String key, @Nullable Boolean value, String sharedPreferencesName);

	/**
	 * Encrypts and stores a {@link String} in a {@link android.content.SharedPreferences} file.
	 * @param key the key to the value. Will be encrypted
	 * @param value the value. Will be encrypted
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return if could encrypt the key and the value
	 */
	boolean setString(String key, @Nullable String value, String sharedPreferencesName);

	/**
	 * Encrypts and stores an {@link Integer} in a {@link android.content.SharedPreferences} file.
	 * @param key the key to the value. Will be encrypted
	 * @param value the value. Will be encrypted
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return if could encrypt the key and the value
	 */
	boolean setInteger(String key, @Nullable Integer value, String sharedPreferencesName);

	/**
	 * Encrypts and stores a {@link Long} in a {@link android.content.SharedPreferences} file.
	 * @param key the key to the value. Will be encrypted
	 * @param value the value. Will be encrypted
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return if could encrypt the key and the value
	 */
	boolean setLong(String key, @Nullable Long value, String sharedPreferencesName);

	/**
	 * Encrypts and stores a {@link Double} in a {@link android.content.SharedPreferences} file.
	 * @param key the key to the value. Will be encrypted
	 * @param value the value. Will be encrypted
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return if could encrypt the key and the value
	 */
	boolean setDouble(String key, @Nullable Double value, String sharedPreferencesName);

	/**
	 * Encrypts and stores a {@link Float} in a {@link android.content.SharedPreferences} file.
	 * @param key the key to the value. Will be encrypted
	 * @param value the value. Will be encrypted
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return if could encrypt the key and the value
	 */
	boolean setFloat(String key, @Nullable Float value, String sharedPreferencesName);

	/**
	 * Retrieves and decrypts an encrypted {@link Boolean} from a {@link android.content.SharedPreferences} file.
	 * @param key the unencrypted key to the value
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return the value, or null if there is no value for the key or could not decrypt the value
	 */
	@Nullable
	Boolean getBoolean(String key, String sharedPreferencesName);

	/**
	 * Retrieves and decrypts an encrypted {@link Boolean} from a {@link android.content.SharedPreferences} file.
	 * @param key the unencrypted key to the value
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return the value, or null if there is no value for the key or could not decrypt the value
	 */
	@Nullable
	String getString(String key, String sharedPreferencesName);

	/**
	 * Retrieves and decrypts an encrypted {@link Integer} from a {@link android.content.SharedPreferences} file.
	 * @param key the unencrypted key to the value
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return the value, or null if there is no value for the key or could not decrypt the value
	 */
	@Nullable
	Integer getInteger(String key, String sharedPreferencesName);

	/**
	 * Retrieves and decrypts an encrypted {@link Boolean} from a {@link android.content.SharedPreferences} file.
	 * @param key the unencrypted key to the value
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return the value, or null if there is no value for the key or could not decrypt the value
	 */
	@Nullable
	Long getLong(String key, String sharedPreferencesName);

	/**
	 * Retrieves and decrypts an encrypted {@link Boolean} from a {@link android.content.SharedPreferences} file.
	 * @param key the unencrypted key to the value
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return the value, or null if there is no value for the key or could not decrypt the value
	 */
	@Nullable
	Double getDouble(String key, String sharedPreferencesName);

	/**
	 * Retrieves and decrypts an encrypted {@link Boolean} from a {@link android.content.SharedPreferences} file.
	 * @param key the unencrypted key to the value
	 * @param sharedPreferencesName the name of the {@link android.content.SharedPreferences} file
	 * @return the value, or null if there is no value for the key or could not decrypt the value
	 */
	@Nullable
	Float getFloat(String key, String sharedPreferencesName);
}
