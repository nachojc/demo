package com.globile.santander.mobisec.scal.securepushnotification;

/**
 * Created by oandujar on 12/03/2019.
 */
public class SCALSecurePushNotification implements SCALSecurePushNotificationModule {

    private SCALSecurePushNotificationModule securePushNotificationImpl;

    public SCALSecurePushNotification(SCALSecurePushNotificationModule securePushNotificationImpl) {
        this.securePushNotificationImpl = securePushNotificationImpl;
    }

    @Override
    public void registerToken(String token) {
        securePushNotificationImpl.registerToken(token);
    }

    @Override
    public void requestNewSecondFactorAuthentication() {
        securePushNotificationImpl.requestNewSecondFactorAuthentication();
    }

    @Override
    public void verifyCode(VerifyCodeCallback verifyCodeCallback, String inputCode) {
        securePushNotificationImpl.verifyCode(verifyCodeCallback, inputCode);
    }

}
