package com.globile.santander.mobisec.scal.tapjackingprotection;

import android.view.MotionEvent;

public interface SCALTapjackingProtectionModule {

    /**
     * Method used to set a callback in order to process data provided by the module.
     * @param callback
     */
    void activeTapjackingProtection(OnTapjackingCallback callback);

    /**
     * Method used to check if there is a layer overlapping the main app.
     * @param event result by the user click on device screen
     * @return false when something is wrong
     */
    boolean onFilterTouchEventForSecurity(MotionEvent event);
}
