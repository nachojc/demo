package com.globile.santander.mobisec.scal.tapjackingprotection;

public interface OnTapjackingCallback {

    /**
     * It will trigger when the module detects a tapjacking attack.
     */
    void onTapjackingDetected();
}
