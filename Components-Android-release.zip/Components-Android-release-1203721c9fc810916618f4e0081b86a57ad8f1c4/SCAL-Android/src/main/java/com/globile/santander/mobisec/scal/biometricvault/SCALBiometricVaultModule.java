package com.globile.santander.mobisec.scal.biometricvault;

public interface SCALBiometricVaultModule {

    /**
     * This function should receive the credential to store securely using biometrics as a String.
     *
     * @param credential in order to store it by a securely way
     * @param key used to store credentials on a secure way
     * @param duration
     */
    void storeCredentialAuthenticated(StoreCredentialCallback callback, String credential, String key, Integer duration);

    /**
     * This function should receive the key of the previously stored credential using biometric
     * authentication. The value of the stored credential should be returned by this callback
     *
     * @param key of the previously stored credential
     */
    void getCredentialAuthenticated(RequestCredentialCallback callback, String key);

}
