package com.globile.santander.mobisec.scal.contextdetection.models;

public enum DeviceDataKey {
	
	KEY_BATTERY_LEVEL("Battery"),
	KEY_IP_V4("IPv4 address"),
	KEY_IP_V6("IPv6 address"),
	KEY_NETWORK_TYPE("Network type"),
	KEY_NETWORK_SECURITY_TYPE("Network security type"),
	KEY_OS_VERSION("OS Version"),
	KEY_SECURITY_PATCH("Security Patch Level"),
	KEY_ROOT("Rooted"),
	KEY_BLUETOOTH("Bluetooth"),
	KEY_NFC("NFC"),
	KEY_INSTALLED_APP("Installed Apps"),
	KEY_OPEN_PORT("Open Port"),
	KEY_IP_CONNECTION("IP Connection"),
	KEY_DEVICE_VENDOR("Vendor Device"),
	KEY_MODEL_DEVICE("Model Device"),
	KEY_IMEI("IMEI"),
	KEY_IMSI("IMSI"),
	KEY_API_LEVEL("API Level"),
	KEY_GOOGLE_ACCOUNT("Google device account"),
	KEY_USB_DEBUG("USB Debug"),
	KEY_CYPHER_DEVICE("Encrypted Device"),
	KEY_BLUETOOTH_PAIRED_DEVICES("Paired devices"),
	//New Phase2
	KEY_VPN_CONNECTED("VPN Connected"),
	KEY_INSTALL_UNKNOWN_SRC("Install Apps from Unknown Sources"),
	KEY_DEV_OPTION_ENABLED("Develop option"),
	KEY_NOTIFICATION_VISIBLE("Notif. Visible"),
	KEY_ENROLLED_FINGERPRINT("Enrolled fingerprint"),
	KEY_DEVICE_LOCK("Device lock"),
	KEY_PASSWORD_VISIBLE("Password visible");
	
	private final String value;
	
	DeviceDataKey(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
}