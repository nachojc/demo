package com.globile.santander.mobisec.scal.contextdetection.models;
public class SCALContextData {
	
	private SCALDeviceData deviceData;
	private SCALCommsData commsData;
	private SCALApplicationData applicationData;
	
	public SCALContextData(SCALDeviceData deviceData, SCALCommsData commsData, SCALApplicationData applicationData) {
		this.deviceData = deviceData;
		this.commsData = commsData;
		this.applicationData = applicationData;
	}
	
	public SCALDeviceData getDeviceData() {
		return deviceData;
	}
	
	public SCALCommsData getCommsData() {
		return commsData;
	}
	
	public SCALApplicationData getApplicationData() {
		return applicationData;
	}
}
