package com.santander.globile.app.views.uicomponentslib.optionselection.dropdown

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.uicomponents.optionselection.dropdown.data.DropDownData
import com.santander.globile.uicomponents.optionselection.dropdown.listener.OnItemSelectedListener
import kotlinx.android.synthetic.main.fragment_dropdown.*

class DropdownFragment: Fragment() {

    companion object {
        fun newInstance(): DropdownFragment {
            return DropdownFragment()
        }
    }

    var companySelected: Company? = null
    var timesSelected: String? = null

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_dropdown, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val item1 = DropDownData("At&T", Company("At&t", 12))
        val item2 = DropDownData("Verizon", Company("Verizon", 34))
        val item3 = DropDownData("Vodafone", Company("Vodafone", 56))
        val item4 = DropDownData("BT Group", Company("BT Group", 67))
        val item5 = DropDownData("Movistar", Company("Movistar", 89))

        val itemsList = listOf(item1, item2, item3, item4, item5)

        setTopDropdownParams(itemsList, -1)

        clear_button.setOnClickListener {
            top_dropdown.hideError()
            setTopDropdownParams(itemsList, -1)
            result_selected_textview.text = ""
            companySelected = null
        }

        submit_button.setOnClickListener {
            if (companySelected == null) {
                top_dropdown.showError()
                result_selected_textview.text = ""
            } else {
                result_selected_textview.text = "Selected: ${companySelected!!.name}"
            }
        }

        val item02 = DropDownData("0-2", "Low")
        val item25 = DropDownData("2-5", "Medium")
        val item510 = DropDownData("5-10", "Hight")
        val item10p = DropDownData("10+", "Top")

        val rangesList = listOf(item02, item25, item510, item10p)
        timesSelected = item25.value
        bottom_dropdown.setGlobileDropdown(rangesList,1, object : OnItemSelectedListener<String>{
            override fun onItemSelected(item: DropDownData<String>) {
                result_selected_textview.text = ""
                timesSelected = item.value
            }

            override fun onNothingSelected() {

            }
        })
    }

    private fun setTopDropdownParams(itemsList: List<DropDownData<Company>>, initialSelection: Int) {
        top_dropdown.setGlobileDropdown(itemsList, initialSelection, object : OnItemSelectedListener<Company> {
            override fun onItemSelected(item: DropDownData<Company>) {
                result_selected_textview.text = ""
                companySelected = item.value
            }

            override fun onNothingSelected() {

            }
        })
    }

    data class Company (val name: String, val id: Int)
}