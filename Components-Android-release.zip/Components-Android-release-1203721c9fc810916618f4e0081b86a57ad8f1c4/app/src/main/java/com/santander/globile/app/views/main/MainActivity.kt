package com.santander.globile.app.views.main

import android.os.Bundle
import com.santander.globile.app.R
import com.santander.globile.app.utils.addFragment
import com.santander.globile.uicomponents.actionbar.GlobileActionBarActivity
import com.santander.globile.uicomponents.actionbar.ToolbarStyle

class MainActivity : GlobileActionBarActivity(ToolbarStyle.STYLE_RED) {
    override fun setLayoutId(): Int {
        return R.layout.activity_main
    }

    override fun setActionIconResource(): Int? {
        return null
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.addFragment(MainFragment.newInstance(),R.id.main_content,null)

    }

}
