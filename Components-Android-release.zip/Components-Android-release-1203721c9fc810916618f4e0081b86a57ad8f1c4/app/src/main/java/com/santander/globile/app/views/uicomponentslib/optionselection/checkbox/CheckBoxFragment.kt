package com.santander.globile.app.views.cachelib

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.santander.globile.app.R
import com.santander.globile.uicomponents.common.GlobileButtonSelectorPosition
import com.santander.globile.uicomponents.optionselection.buttonselector.GlobileButtonSelector
import kotlinx.android.synthetic.main.fragment_button_selection.*

class CheckBoxFragment: Fragment() {

    companion object {
        fun newInstance(): CheckBoxFragment {
            return CheckBoxFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_checkbox, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
    }
}