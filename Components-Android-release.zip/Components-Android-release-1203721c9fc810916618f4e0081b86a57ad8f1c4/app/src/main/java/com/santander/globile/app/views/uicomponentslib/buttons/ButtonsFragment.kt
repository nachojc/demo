package com.santander.globile.app.views.uicomponentslib.buttons

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.fragment_buttons.*

class ButtonsFragment: Fragment() {

    companion object {
        fun newInstance(): ButtonsFragment {
            return ButtonsFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_buttons, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        tertiary_three.setLinkOnClickListener(View.OnClickListener {
            Toast.makeText(context,"Hello World", Toast.LENGTH_LONG).show()
        })

        tertiary_one.setOnClickListener(View.OnClickListener {
            Toast.makeText(context,"Hello World", Toast.LENGTH_LONG).show()
        })

        tertiary_two.setOnClickListener(View.OnClickListener {
            Toast.makeText(context,"Hello World", Toast.LENGTH_LONG).show()
        })
    }


}