package com.santander.globile.app.views.uicomponentslib.list.dummy

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.santander.globile.app.R
import com.santander.globile.uicomponents.list.common.adapter.GlobileGenericRecyclerAdapter
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener
import kotlinx.android.synthetic.main.fragment_recycler_test.*


class RecyclerClassCustom: Fragment() , GlobileRecyclerListener<Any> {

    companion object {
        fun newInstance(): RecyclerClassCustom {
            return RecyclerClassCustom()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_recycler_test, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)


        val dummyList = ArrayList<Any>()
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())



        val customAdapter = object : GlobileGenericRecyclerAdapter<Any>(dummyList,this) {
            override fun getLayoutId(position: Int, obj: Any): Int {
                return R.layout.custom_row
            }

            override fun getViewHolder(view: View, viewType: Int): RecyclerView.ViewHolder {
                return CustomViewHolder(view)
            }
        }

        component_recycler_test.layoutManager = LinearLayoutManager(context)
        component_recycler_test.adapter = customAdapter
    }

    override fun onClickListener(data: Any, v: View, code: Int) {
        when(code){
            0 -> Toast.makeText(context,"click on row",Toast.LENGTH_LONG).show()
            1 -> Toast.makeText(context,"BUTTON 1",Toast.LENGTH_LONG).show()
            2 -> Toast.makeText(context,"BUTTON 2",Toast.LENGTH_LONG).show()
        }
    }
}
