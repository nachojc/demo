package com.santander.globile.app.views.uicomponentslib.buttons

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.santander.globile.app.R
import com.santander.globile.uicomponents.slider.GlobileSliderListener
import kotlinx.android.synthetic.main.fragment_slider.*

class SliderFragment: Fragment() {

    companion object {
        fun newInstance(): SliderFragment {
            return SliderFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_slider, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rangeSeekbar.globileSliderListener = object : GlobileSliderListener {
           override fun onSelectionListener(thumbIndex: Int, value: Int) {
               Toast.makeText(context, "$value $thumbIndex",Toast.LENGTH_SHORT) .show()
               val values = rangeSeekbar.getSliderValues()
           }
       }

        rangeSeekbar.getValue(3)
        rangeSeekbar.maxText = "1000€"
        rangeSeekbar.minText = "1€"
        rangeSeekbar.enableSeparator = false

    }


}