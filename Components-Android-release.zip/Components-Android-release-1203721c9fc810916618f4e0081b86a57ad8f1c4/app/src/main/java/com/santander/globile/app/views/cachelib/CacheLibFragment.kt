package com.santander.globile.app.views.cachelib

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.santander.globile.app.R
import com.santander.globile.cachelib.GlobalFactoryCache
import kotlinx.android.synthetic.main.fragment_cachelib.*

class CacheLibFragment: Fragment() {

    companion object {
        fun newInstance(): CacheLibFragment {
            return CacheLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_cachelib, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        save_permanent_button.setOnClickListener {
            Toast.makeText(activity,"DATA SAVED",Toast.LENGTH_SHORT).show()
            GlobalFactoryCache.saveCacheData("test1",data_edittext.text.toString())
        }

        //Get Data as Any object
        load_permanent_button.setOnClickListener {
           val data = GlobalFactoryCache.getCacheData("test1")
            result_permanent_textview.text = data.toString()?.let {
                it
            }
        }


        save_permanent2_button.setOnClickListener {
            Toast.makeText(activity,"DATA SAVED",Toast.LENGTH_SHORT).show()
            GlobalFactoryCache.saveCacheData("test2",data_edittext.text.toString())
        }

        //Get Data as Any object
        load_permanent2_button.setOnClickListener {
            val data = GlobalFactoryCache.getCacheData("test2")
            result_permanent_textview.text = data.toString()?.let {
                it
            }
        }


        //Expirable data buttons
        save_expirable_button.setOnClickListener {
            GlobalFactoryCache.saveCacheData("tag3",data_edittext.text.toString(),5)
            Toast.makeText(activity,"DATA SAVED, time expiration 5 seconds",Toast.LENGTH_SHORT).show()
        }

        //Get Data Expirable as Any object
        load_expirable_button.setOnClickListener {
            val dataExpirable = GlobalFactoryCache.getCacheData("tag3")
            if(dataExpirable == null){
                result_expirable_textview.text = "data not found"
            }else{
                result_expirable_textview.text = dataExpirable.toString()
            }

        }

        //Expirable data buttons
        save_expirable2_button.setOnClickListener {
            GlobalFactoryCache.saveCacheData("tag4",data_edittext.text.toString(),4)
            Toast.makeText(activity,"DATA SAVED, time expiration 4 seconds",Toast.LENGTH_SHORT).show()
        }

        //Get Data Expirable as Any object
        load_expirable2_button.setOnClickListener {
            val dataExpirable = GlobalFactoryCache.getCacheData("tag4")
            if(dataExpirable == null){
                result_expirable_textview.text = "data not found"
            }else{
                result_expirable_textview.text = dataExpirable.toString()
            }

        }

        endingButton2.setOnClickListener {
            Toast.makeText(activity,"Cache cleared",Toast.LENGTH_LONG).show()
            GlobalFactoryCache.cache.clear()
        }

    }
}