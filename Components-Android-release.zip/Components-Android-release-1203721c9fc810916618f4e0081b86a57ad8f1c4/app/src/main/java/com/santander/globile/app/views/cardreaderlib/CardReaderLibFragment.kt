package com.santander.globile.app.views.cardreaderlib

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.cardreaderlib.callback.CardReaderCallback
import com.santander.globile.cardreaderlib.common.CardInfo
import com.santander.globile.cardreaderlib.handleOnActivityResult
import com.santander.globile.cardreaderlib.scanCard
import kotlinx.android.synthetic.main.activity_cardreaderlib.*

class CardReaderLibFragment : Fragment() {

    companion object {
        const val CARD_READER_REQUEST_CODE = 1
        fun newInstance(): CardReaderLibFragment {
            return CardReaderLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_cardreaderlib, container, false)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result received using callback
        handleOnActivityResult(data, object : CardReaderCallback {

            override fun onCardScanCompleted(cardInfo: CardInfo) {
                cardreader_result_textview.text = cardInfo.cardNumber.toString()
            }

            override fun onCardScanCancelled() {
                cardreader_result_textview.text = getString(R.string.cardreader_scan_incomplete)
            }
        })
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        open_cam_button.setOnClickListener {
            activity?.let {
                scanCard(it.applicationContext, CARD_READER_REQUEST_CODE, "card reader")
            }
        }
    }
}