package com.santander.globile.app.views.serviceinvocationlib.model

import java.util.*

data class ResultsContainer(val results: List<User>? = null)

data class User(
    val gender: String? = null,
    val name: Name? = null,
    val location: Location? = null,
    val email: String? = null,
    val registered: RegisteredDate? = null,
    val picture: Picture? = null,
    val phone: String? = null)

data class Name(
    val first: String? = null,
    val last: String? = null
)

data class Location(
    val street: String? = null,
    val city: String? = null,
    val state: String? = null
)

data class RegisteredDate(
    val date: Date? = null
)

data class Picture(
    val large: String? = null,
    val medium: String? = null
)

data class ErrorMessage(val msg: String? = null)