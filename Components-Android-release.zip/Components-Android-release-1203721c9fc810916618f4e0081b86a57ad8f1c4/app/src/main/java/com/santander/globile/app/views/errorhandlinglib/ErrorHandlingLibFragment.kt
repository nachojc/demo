package com.santander.globile.app.views.errorhandlinglib

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.views.main.MainActivity
import com.santander.globile.uicomponents.errorhandling.common.BUTTON_POSITIVE_CODE
import com.santander.globile.uicomponents.errorhandling.common.ErrorHandlingParams
import com.santander.globile.uicomponents.errorhandling.common.showErrorDialog
import com.santander.globile.uicomponents.errorhandling.dialog.ErrorHandlingDialogFragment
import kotlinx.android.synthetic.main.activity_errorhandlerlib.*

class ErrorHandlingLibFragment: Fragment(), ErrorHandlingDialogFragment.OnClickListener
    , ErrorHandlingDialogFragment.OnDismissListener {

    companion object {
        fun newInstance(): ErrorHandlingLibFragment {
            return ErrorHandlingLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.activity_errorhandlerlib, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        (activity as MainActivity).title = "Error Handling"
        //Show dialog 1
        first_button.setOnClickListener {
            result_dialog_textview.text = getString(R.string.errorhandler_press1_result)
            val params = ErrorHandlingParams(
                title = getString(R.string.errorhandler_dialog1_title),
                subtitle = getString(R.string.errorhandler_dialog1_subtitle),
                message = getString(R.string.errorhandler_dialog1_message),
                positiveButtonText = getString(R.string.errorhandler_dialog1_button_right)
            )

            val paramsss = ErrorHandlingParams("title","subtitle","message","ok");
            showDialog("first_button", params)
        }

        //Show dialog 2
        second_button.setOnClickListener {
            result_dialog_textview.text = getString(R.string.errorhandler_press2_result)
            val params = ErrorHandlingParams(
                title = getString(R.string.errorhandler_dialog2_title),
                subtitle = getString(R.string.errorhandler_dialog2_subtitle),
                message = getString(R.string.errorhandler_dialog2_message),
                positiveButtonText = getString(R.string.errorhandler_dialog2_button_right),
                negativeButtonText = getString(R.string.errorhandler_dialog2_button_left)
            )
            showDialog("second_button", params)
        }

    }

    private fun showDialog(dialogTag: String, params: ErrorHandlingParams) {
        activity?.let {
            showErrorDialog(
                it.supportFragmentManager,
                dialogTag, params, this, this, this
            )
        }

    }

    override fun onDismiss() {
        result_dialog_textview.text = "Dismissed"
    }

    override fun onButtonClick(code: Int) {

        if (code == BUTTON_POSITIVE_CODE) {
            result_dialog_textview.text = "OK pressed"
        } else {
            result_dialog_textview.text = "Cancel pressed"
        }
    }

}
