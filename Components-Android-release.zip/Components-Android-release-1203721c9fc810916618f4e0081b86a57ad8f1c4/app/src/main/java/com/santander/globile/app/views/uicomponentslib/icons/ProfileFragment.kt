package com.santander.globile.app.views.uicomponentslib.icons

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.app.AppCompatDelegate
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.fragment_profile_photo.*

class ProfileFragment: Fragment() {

    companion object {
        fun newInstance(): ProfileFragment {
            return ProfileFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
        return inflater?.inflate(R.layout.fragment_profile_photo, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        profile_photo_1.setProfilePhoto(R.drawable.st)
        profile_initials_1.setInitials("C")

        profile_photo_2.setProfilePhoto(R.drawable.st, 0)
        profile_initials_2.setInitials("CG", 0)

        profile_photo_3.setProfilePhoto(R.drawable.st, 5)
        profile_initials_3.setInitials("CG", 5)

        profile_photo_4.setProfilePhoto(R.drawable.st, 55)
        profile_initials_4.setInitials("CG", 55)

        profile_photo_5.setProfilePhoto(R.drawable.st, 555)
        profile_initials_5.setInitials("CG", 555)
    }
}