package com.santander.globile.app.views.uicomponentslib.pagecontroller

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.fragment_pagecontroller.*

class PageControllerFragment: Fragment() {

    companion object {
        fun newInstance(): PageControllerFragment {
            return PageControllerFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_pagecontroller, container, false)

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Initialize a list of string values
        val numbers = listOf("100,00€","200,00€","300,00€","400,00€","500,00€","600,00€","700,00€","800,00€","900,00€","1000,00€")

        // Initialize a new pager adapter instance with list
        val adapter = PageControllerAdapter(numbers)

        // Data bind the view pager widget with pager adapter
        text_viewPager.adapter = adapter

        // Bind view Pager with page indicator
        text_viewIndicator.setViewPager(text_viewPager)
    }
}