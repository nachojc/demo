package com.santander.globile.app.views.barcodescannerlib

import android.content.Intent
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.barcodescannerlib.callback.BarcodeScannerCallback
import com.santander.globile.barcodescannerlib.common.BarcodeScannerInfo
import com.santander.globile.barcodescannerlib.handleOnActivityResult
import com.santander.globile.barcodescannerlib.scanCode
import kotlinx.android.synthetic.main.fragment_barcodescannerlib.*

class BarcodeScannerLibFragment: Fragment() {

    companion object {
        fun newInstance(): BarcodeScannerLibFragment {
            return BarcodeScannerLibFragment()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_barcodescannerlib, container, false)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result received using callback
        handleOnActivityResult(requestCode, resultCode, data, object : BarcodeScannerCallback {

            override fun onCodeScanCompleted(scannerInfo: BarcodeScannerInfo) {
                if(scannerInfo.content == null) {
                    barcodescanner_result_textview.text = getString(R.string.barcodescanner_scan_error)
                } else {
                    barcodescanner_result_textview.text = "${scannerInfo.content}\n\nData type: ${scannerInfo.formatName}"
                }
            }

            override fun onCodeScanCancelled() {
                barcodescanner_result_textview.text = getString(R.string.barcodescanner_scan_cancelled)
            }
        })

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        open_cam_button.setOnClickListener {
            activity?.let {
                //Open barcode scanner with instructions
                scanCode("Scan product barcode")
            }
        }
    }
}