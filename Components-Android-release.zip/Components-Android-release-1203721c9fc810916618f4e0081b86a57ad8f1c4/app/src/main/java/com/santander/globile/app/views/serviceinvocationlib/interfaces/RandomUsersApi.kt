package com.santander.globile.app.views.serviceinvocationlib.interfaces

import com.santander.globile.app.views.serviceinvocationlib.model.ResultsContainer
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Query

const val DEFAULT_RESULT_SIZE = 10

interface RandomUsersApi {

    @GET("/")
    fun getRandomUsers(@Query("results") numOfResults: Int = DEFAULT_RESULT_SIZE): Call<ResultsContainer>

}