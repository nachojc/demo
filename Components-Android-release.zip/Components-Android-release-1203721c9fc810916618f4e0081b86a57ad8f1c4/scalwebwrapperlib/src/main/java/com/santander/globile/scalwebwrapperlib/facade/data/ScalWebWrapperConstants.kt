package com.santander.globile.scalwebwrapperlib.facade.data

class ScalWebWrapperConstants {
    companion object {
        const val USER_BINDING = 0
        const val DEVICE_FINGERPRINT_DATA = 1
        const val DEVICE_RISK_DATA = 2
        const val APPLICATION_RISK_DATA = 3
        const val COMMUNICATION_RISK_DATA = 4
        const val GEOPOSITION_RISK_DATA = 5
        const val ALL_RISK_DATA = 6
        const val DEVICE_DATA = 7
        const val APPLICATION_DATA = 8
        const val COMMUNICATION_DATA = 9
        const val GEOPOSITION_DATA = 10
    }
}