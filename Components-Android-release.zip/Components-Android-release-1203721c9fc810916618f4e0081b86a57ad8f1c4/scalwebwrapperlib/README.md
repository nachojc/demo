# Introduction 
This component return security data from SCAL library.

# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':scalwebwrapperlib')
```
3. Sync project with Gradle files

# Use
## From Web app
Access this component from web through the `callComponent(args: ArrayList<Any>)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib). Call the function with the following values:

ScalWebWrapperParams:

operation:
USER BINDING DATA = 0
DEVICE FINGERPRINT DATA = 1
DEVICE RISK DATA = 2
APPLICATION RISK DATA = 3
COMMUNICATION RISK DATA = 4
GEOPOSITION RISK DATA = 5
ALL_RISK_DATA = 6
DEVICE DATA = 7
APPLICATION DATA = 8
COMMUNICATION DATA = 9
GEOPOSITION DATA = 10


```
  data class SCALWebWrapperParams(
      val operation: Int = 0
  )  
```

```
{
"operation": "Int" //Operation
}
```

The data responses is the object of SCAL library as json.



# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "scalwebwrapperlib" from the Project sidemenu
4. Select Build -> Make Module 'scalwebwrapperlib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/scalwebwrapperlib/build/outputs/aar/
