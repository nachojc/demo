package com.santander.globile.localstoragelib.facade

import android.arch.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.santander.globile.localstoragelib.LocalStorage
import com.santander.globile.localstoragelib.common.fromJson
import com.santander.globile.localstoragelib.common.toJson


/**
 * This class allows compatibility with WebViewBridge component and Archetype dispatcher in case the app contains
 * at least one web that needs to store data in phone.
 */
class ComponentFacade {


    var liveData: MutableLiveData<String> = MutableLiveData()
    private lateinit var gson: Gson

    /**
     *
     * @param args A ArrayList with data to Use in this component:
     *
     *   args[0] =  params A JSON formatted [String] with three fields:
     *  - operation: "load", "save" or "remove" data.
     *  - alias: the alias associated to the stored data.
     *  - data: data to store in case of "operation" field is "save".
     *
     *   args[1] = context from application
     *   args[2] = activity from application
     *
     *  @return A JSON formated [String] with two fields as live data observed in webviewbridge:
     *  - success: boolean with true value in case of successful operation and false otherwise.
     *  - operation: the name of the operation that was executed (load, save or null if not recognized).
     *  - data: data loaded in case of "load" operation.
     */



    fun startComponent(args: ArrayList<Any>) {
        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
        val localStorageParams = try {
            (args[0] as String).fromJson(LocalStorageParams::class.java)
        } catch (e: Exception) {
            null
        }

        val operation = localStorageParams?.operation?.toLowerCase().let {
            if (it != SAVE && it != LOAD && it != REMOVE)
                null
            else
                it
        }

        var data: Any? = null

        val success = try {
            localStorageParams?.alias?.run {

                when (operation) {
                    SAVE -> {
                        LocalStorage.saveData(this, localStorageParams.data)
                        true
                    }
                    LOAD -> {
                        data = LocalStorage.loadData(this)
                        true
                    }
                    REMOVE -> {
                        LocalStorage.removeData(this)
                        true
                    }
                    else -> {
                        false
                    }
                }
            } ?: false
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }

        liveData.postValue(LocalStorageResult(success, operation, data).toJson())

    }
}

private const val SAVE = "save"
private const val LOAD = "load"
private const val REMOVE = "remove"

private data class LocalStorageParams(
    val operation: String? = null,
    val alias: String? = null,
    val data: Any? = null
)

private data class LocalStorageResult(
    val success: Boolean = false,
    val operation: String? = null,
    val data: Any? = null
)
