package com.santander.globile.uicomponents.optionselection.dropdown.data

data class DropDownData<T>(val key:String, val value:T? = null)
