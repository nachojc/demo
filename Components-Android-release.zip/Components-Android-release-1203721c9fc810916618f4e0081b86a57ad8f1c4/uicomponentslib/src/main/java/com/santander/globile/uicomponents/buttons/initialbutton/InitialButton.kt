package com.santander.globile.uicomponents.buttons.initialbutton

import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Build
import android.support.v4.graphics.drawable.DrawableCompat
import android.support.v7.widget.AppCompatTextView
import android.util.AttributeSet
import android.util.TypedValue
import android.widget.FrameLayout
import android.widget.LinearLayout
import com.santander.globile.uicomponents.R


class InitialButton @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : LinearLayout(context, attrs, defStyleAttr) {

    private val mContext = context
    private var mImagePosition =
        ImagePosition.LEFT
    private var mImageResource: Int?
    private var mButtonText = ""
    private var mTextSize = 16F
    private var mTintColor: Int?
    var globileInitialTextView: AppCompatTextView? = null
    var globileButton: FrameLayout? = null


    init {
        inflate(context, R.layout.initial_button, this)
        orientation = VERTICAL
        globileInitialTextView = findViewById(R.id.initial_button_text)
        globileButton = findViewById(R.id.wrapper_initial_button)
        val typedArray = mContext.obtainStyledAttributes(attrs, R.styleable.InitialButton)
        mImagePosition =
            ImagePosition.positionFromInt(
                typedArray.getInt(R.styleable.InitialButton_imagePosition, 0)
            )
        mButtonText = typedArray.getString(R.styleable.InitialButton_buttonText) ?: ""
        mTextSize = typedArray.getFloat(R.styleable.InitialButton_textSizeInitialButton, 16F)
        mImageResource = typedArray.getResourceId(R.styleable.InitialButton_imageResource, 0)
        mTintColor = typedArray.getResourceId(R.styleable.InitialButton_imageTint, 0)

        setViews()

        typedArray.recycle()
    }

    override fun setOnClickListener(listener: OnClickListener){
        globileButton?.setOnClickListener(listener)
    }

    private fun setViews() {
        globileInitialTextView?.let {
            it.apply {
                setTextSize(TypedValue.COMPLEX_UNIT_SP, mTextSize)
                text = mButtonText
                if (Build.VERSION.SDK_INT < 23) {
                    setTextAppearance(context, R.style.GlobileInitialButtonStyleTextAppearance)
                }
                else {
                    setTextAppearance(R.style.GlobileInitialButtonStyleTextAppearance)
                }
            }
        }

        setDrawableIcon()
    }

    private fun setDrawableWithColor(drawableRes: Int): Drawable {
        var img: Drawable?
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            img = context.resources.getDrawable(drawableRes, null)
            if (mTintColor != null && mTintColor != 0) {
                img?.let {
                    DrawableCompat.setTint(it, resources.getColor(mTintColor!!, null))
                }
            }
        } else {
            img = context.resources.getDrawable(drawableRes)
            if (mTintColor != null && mTintColor != 0) {
                img?.let {
                    DrawableCompat.setTint(it, resources.getColor(mTintColor!!))
                }
            }
        }
        return img
    }

    private fun setDrawableIcon() {

        mImageResource?.let {
            if (it != 0) {
                val drawable = setDrawableWithColor(it)
                when (mImagePosition.position) {
                    0 -> globileInitialTextView?.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null)
                    1 -> globileInitialTextView?.setCompoundDrawablesWithIntrinsicBounds(null, drawable, null, null)
                    2 -> globileInitialTextView?.setCompoundDrawablesWithIntrinsicBounds(null, null, null, drawable)
                    3 -> globileInitialTextView?.setCompoundDrawablesWithIntrinsicBounds(null, null, drawable, null)
                    else -> globileInitialTextView?.setCompoundDrawablesWithIntrinsicBounds(drawable, null, null, null)
                }
            }
        }
    }

    /**
     * Enum class to place icon and text
     *
     * @property position icon relative position respect text, need [String] when is loaded from XML file.
     */
    enum class ImagePosition(val position: Int) {
        LEFT(0),
        TOP(1),
        BOTTOM(2),
        RIGHT(3);

        companion object {
            fun positionFromInt(position: Int?): ImagePosition {
                return values().find { it.position == position } ?: LEFT
            }
        }

    }

}