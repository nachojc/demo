package com.santander.globile.uicomponents.utils

import android.view.View


fun View.enable(enable: Boolean) {
    visibility = if(!enable)
        View.GONE
    else
        View.VISIBLE
}