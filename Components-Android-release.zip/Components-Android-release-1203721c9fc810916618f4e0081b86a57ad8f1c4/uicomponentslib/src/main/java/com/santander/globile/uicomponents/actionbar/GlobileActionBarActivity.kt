package com.santander.globile.uicomponents.actionbar

import android.os.Bundle
import android.support.v4.view.GravityCompat
import android.support.v4.widget.DrawerLayout
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.Toolbar
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.utils.ComponentConstants
import com.santander.globile.uicomponents.utils.enable
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.globile_toolbar.*

/**
 * Abstract Class with some methods to customize a custom [Toolbar] object.
 *
 * @property toolbarStyle : Enum with two posibilities to customize a custom [Toolbar]
 * - [ToolbarStyle.STYLE_RED] : Toolbar with red style and White icons.
 * - [ToolbarStyle.STYLE_WHITE]: Toolbar with white style and red icons.
 *
 */
abstract class GlobileActionBarActivity(private val toolbarStyle: ToolbarStyle) : AppCompatActivity() {

    lateinit var customToolbar: Toolbar
    lateinit var navigationDrawer: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        setStyle(toolbarStyle)
        super.onCreate(savedInstanceState)
        setContentView(setLayoutId())
        customToolbar = globile_toolbar
        navigationDrawer = globile_navigation_drawer
        setSupportActionBar(customToolbar)
        supportActionBar?.setDisplayShowTitleEnabled(false)
        setActionIcon(setActionIconResource())
        globile_drawer_icon.setOnClickListener {
            toggleNavigationDrawer()
        }
    }

    private fun setStyle(toolbarStyle: ToolbarStyle) {
        when (toolbarStyle.styleId) {
            ComponentConstants.WHITE_TOOLBAR_STYLE -> setTheme(R.style.GlobileTheme_White)
            ComponentConstants.RED_TOOLBAR_STYLE -> setTheme(R.style.GlobileTheme_Red)
            else -> {
                setTheme(R.style.GlobileTheme_Red)
            }
        }
    }

    override fun setTitle(stringId: Int) {
        customToolbar.findViewById<TextView>(R.id.globile_toolbar_title)?.let {
            it.text = getString(stringId)
            it.enable(true)
            enableGlobileLogo(false)
        }

    }

    override fun setTitle(title: CharSequence?) {
        customToolbar.findViewById<TextView>(R.id.globile_toolbar_title)?.let {
            it.text = title
            it.enable(true)
            enableGlobileLogo(false)
        }
    }

    /**
     * Enable title and disable globile logo in toolbar
     *
     * @param enabled: true enabled , false disabled.
     */
    fun enableTitle(enabled: Boolean) {
        customToolbar.findViewById<TextView>(R.id.globile_toolbar_title)?.enable(enabled)
        enableGlobileLogo(!enabled)
    }


    /**
     * Enable globile logo and disable title in toolbar.
     *
     * @param enabled: true enabled , false disabled.
     */
    fun enableGlobileLogo(enabled: Boolean) {
        customToolbar.findViewById<ImageView>(R.id.globile_toolbar_logo)?.let {
            it.apply {
                it.enable(enabled)
            }
        }
    }

    /**
     * Add [View.OnClickListener] to action icon (left button).
     *
     * @param onClickListener
     */
    fun addOnClickListenerActionIcon(onClickListener: View.OnClickListener) {
        customToolbar.findViewById<ImageButton>(R.id.globile_action_icon)?.setOnClickListener(onClickListener)
    }

    /**
     * Hide action icon (left button).
     *
     */
    fun hideActionIcon() {
        customToolbar.findViewById<ImageButton>(R.id.globile_action_icon)?.let {
            it.apply {
                it.enable(false)
            }
        }
    }


    /**
     * Enable or Disable Navigation Drawer
     *
     * @param enabled
     */
    fun setDrawerEnabled(enabled: Boolean) {
        val lockMode = if (enabled) {
            DrawerLayout.LOCK_MODE_UNLOCKED
        } else {
            DrawerLayout.LOCK_MODE_LOCKED_CLOSED
        }
        setNavigationDrawerEnabled(enabled)
        navigationDrawer.setDrawerLockMode(lockMode)
    }

    /**
     * Set Action icon in [Toolbar]
     *
     * @param resIconId : Icon id from drawable folder
     */
    fun setActionIcon(resIconId: Int?) {

        customToolbar.findViewById<ImageButton>(R.id.globile_action_icon)?.let {
            it.apply {
                if(resIconId!=null) {
                    it.visibility = View.VISIBLE
                    setImageResource(resIconId)
                }else{
                    it.visibility = View.GONE
                }
            }
        }
    }

    private fun setNavigationDrawerEnabled(enabled: Boolean) {
        customToolbar.findViewById<ImageButton>(R.id.globile_drawer_icon)?.let {
            it.apply {
                it.enable(enabled)
            }
        }
    }

    private fun toggleNavigationDrawer() {
        navigationDrawer.let {
            if (navigationDrawer.isDrawerOpen(GravityCompat.END)) {
                navigationDrawer!!.closeDrawer(GravityCompat.END)
            } else {
                navigationDrawer!!.openDrawer(GravityCompat.END)
            }
        }
    }

    override fun onBackPressed() {
        if (navigationDrawer != null) {
            if (navigationDrawer!!.isDrawerOpen(GravityCompat.END)) {
                navigationDrawer!!.closeDrawer(GravityCompat.END)
            } else {
                super.onBackPressed()
            }
        } else {
            super.onBackPressed()
        }
    }


    abstract fun setLayoutId(): Int

    abstract fun setActionIconResource(): Int?

}

enum class ToolbarStyle(val styleId: Int) {
    STYLE_RED(ComponentConstants.RED_TOOLBAR_STYLE),
    STYLE_WHITE(ComponentConstants.WHITE_TOOLBAR_STYLE)
}