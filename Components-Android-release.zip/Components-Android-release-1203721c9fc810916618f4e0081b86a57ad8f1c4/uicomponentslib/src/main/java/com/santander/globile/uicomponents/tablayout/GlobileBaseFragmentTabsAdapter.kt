package com.santander.globile.uicomponents.tablayout

import android.content.Context
import android.graphics.drawable.Drawable
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import android.support.v4.app.FragmentPagerAdapter
import android.support.v4.content.ContextCompat
import android.view.ViewGroup
import com.santander.globile.uicomponents.tablayout.data.GlobileTabsAdapterData
import java.util.*

/**
 * This class extends to [FragmentPagerAdapter] to create a custom Adapter to set fragments
 * and tab title.
 *
 * @property context : Context of application
 * @property globileTabsAdapterData: Adapter Model who contains Fragments, titles and icons of TabLayout
 * @constructor :  Default constructor in FragmentPageAdapter
 *
 * @param fm : [FragmentManager] from activity.
 */


open class GlobileBaseFragmentTabsAdapter(
    fm: FragmentManager,
    protected var context: Context,
    var globileTabsAdapterData: GlobileTabsAdapterData
) :
    FragmentPagerAdapter(fm) {
    private val mPageReferenceMap = HashMap<Int, Fragment>()

    override fun getItem(position: Int): Fragment? {
        return if (globileTabsAdapterData.tabs.size > position) {
            globileTabsAdapterData.tabs[position].fragment
        } else {
            null
        }
    }
    override fun getCount(): Int {
        return globileTabsAdapterData.tabs.size
    }

    override fun getPageTitle(position: Int): CharSequence? = this.context.getString(globileTabsAdapterData.tabs[position].titleId)


    /**
     * Get [Drawable] icon from TabLayout
     *
     * @param context: Context of application
     * @param position: Tab position.
     */
    fun getPageIcon(context: Context, position: Int): Drawable? =
        globileTabsAdapterData.tabs[position].iconId?.let { ContextCompat.getDrawable(context, it) }

    override fun instantiateItem(container: ViewGroup, position: Int): Any {
        val fragment = super.instantiateItem(container, position) as Fragment
        mPageReferenceMap[position] = fragment
        return fragment
    }

    override fun destroyItem(container: ViewGroup, position: Int, `object`: Any) {
        super.destroyItem(container, position, `object`)
        mPageReferenceMap.remove(position)
    }

    /**
     * Get [Fragment] from Adapter
     *
     * @param key: Fragment key
     */

    fun getFragment(key: Int): Fragment? {
        return mPageReferenceMap[key]
    }

    companion object {
        private val TAG = GlobileBaseFragmentTabsAdapter::class.java.simpleName
    }
}


