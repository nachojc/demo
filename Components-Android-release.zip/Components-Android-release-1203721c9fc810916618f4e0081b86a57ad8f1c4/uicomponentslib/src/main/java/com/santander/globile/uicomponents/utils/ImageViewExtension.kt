package com.santander.globile.uicomponents.utils

import android.support.v4.content.ContextCompat
import android.widget.ImageView

fun ImageView.tintDrawable(color: Int){
    this.setColorFilter(ContextCompat.getColor(context, color), android.graphics.PorterDuff.Mode.SRC_IN)
}