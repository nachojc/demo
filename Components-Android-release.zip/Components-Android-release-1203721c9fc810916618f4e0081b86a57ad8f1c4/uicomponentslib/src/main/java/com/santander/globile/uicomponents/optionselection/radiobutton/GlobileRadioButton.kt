package com.santander.globile.uicomponents.optionselection.radiobutton

import android.annotation.SuppressLint
import android.content.Context
import android.content.res.ColorStateList
import android.support.v7.widget.AppCompatRadioButton
import android.util.AttributeSet
import com.santander.globile.uicomponents.R


class GlobileRadioButton @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : AppCompatRadioButton(context, attrs, defStyleAttr) {

    var radioColor: Int = 0

    init {
        createCustomLayout(attrs)
        checkSelected(isChecked)

        setOnCheckedChangeListener { buttonView, isChecked ->
            checkSelected(isChecked)
        }
    }

    /**
     * Create Layout with custom attributes
     *
     * @param attrs
     */

    @SuppressLint("RestrictedApi")
    private fun createCustomLayout(attrs: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GlobileRadioButton, 0, 0)
        radioColor = attributes.getInt(R.styleable.GlobileRadioButton_default_color, 0)
        attributes.recycle()
    }

    @SuppressLint("RestrictedApi")
    fun changeToSelectedColor() {
        val states = arrayOf(
            intArrayOf(android.R.attr.state_enabled), // enabled
            intArrayOf(-android.R.attr.state_enabled), // disabled
            intArrayOf(-android.R.attr.state_checked), // unchecked
            intArrayOf(android.R.attr.state_checked),// checked
            intArrayOf(android.R.attr.state_pressed)  // pressed
        )

        val colors = if (radioColor == 0) {
              intArrayOf(
                resources.getColor(R.color.santander_red),
                resources.getColor(R.color.santander_red),
                resources.getColor(R.color.santander_red),
                resources.getColor(R.color.santander_red),
                resources.getColor(R.color.santander_red)
            )
        }else{
            intArrayOf(
                resources.getColor(R.color.turquoise),
                resources.getColor(R.color.turquoise),
                resources.getColor(R.color.turquoise),
                resources.getColor(R.color.turquoise),
                resources.getColor(R.color.turquoise)
            )
        }


        val myList = ColorStateList(states, colors)
        supportButtonTintList = myList
    }

    @SuppressLint("RestrictedApi")
    fun changeToNormalColor() {
        val states = arrayOf(
            intArrayOf(android.R.attr.state_enabled), // enabled
            intArrayOf(-android.R.attr.state_enabled), // disabled
            intArrayOf(-android.R.attr.state_checked), // unchecked
            intArrayOf(android.R.attr.state_checked),// checked
            intArrayOf(android.R.attr.state_pressed)  // pressed
        )

        val colors = intArrayOf(
            resources.getColor(R.color.medium_grey),
            resources.getColor(R.color.medium_grey),
            resources.getColor(R.color.medium_grey),
            resources.getColor(R.color.medium_grey),
            resources.getColor(R.color.medium_grey)
        )

        val myList = ColorStateList(states, colors)
        supportButtonTintList = myList

    }

    private fun checkSelected(checked: Boolean) {
        if (checked) {
            changeToSelectedColor()
        } else {
            changeToNormalColor()
        }
    }

}