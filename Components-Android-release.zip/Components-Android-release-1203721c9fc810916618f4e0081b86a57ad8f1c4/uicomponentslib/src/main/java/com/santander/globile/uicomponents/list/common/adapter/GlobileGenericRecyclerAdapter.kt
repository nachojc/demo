package com.santander.globile.uicomponents.list.common.adapter

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.uicomponents.list.common.listener.GlobileRecyclerListener

/**
 * Generic Adapter to create a RecyclerView.Adapter
 *
 * @param T: Generic any type of data.
 */
abstract class GlobileGenericRecyclerAdapter<T> : RecyclerView.Adapter<RecyclerView.ViewHolder> {

    var listItems: List<T>
    var listener: GlobileRecyclerListener<T>? = null

    constructor(listItems: List<T>,listener: GlobileRecyclerListener<T>) {
        this.listItems = listItems
        this.listener = listener
    }

    constructor(listItems: List<T>) {
        this.listItems = listItems
    }

    constructor() {
        listItems = emptyList()
    }

    fun setItems(listItems: List<T>) {
        this.listItems = listItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return getViewHolder(
            LayoutInflater.from(parent.context)
            .inflate(viewType, parent, false)
            , viewType)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        (holder as GlobileGenericBinder<T>).bind(listItems[position],listener)
    }

    override fun getItemCount(): Int {
        return listItems.size
    }

    override fun getItemViewType(position: Int): Int {
        return getLayoutId(position, listItems[position])
    }

    /**
     * Abstract function to set layout id in viewholder
     *
     * @param position : item position
     * @param obj: Generic any type of data.
     */
    protected abstract fun getLayoutId(position: Int, obj: T): Int

    abstract fun getViewHolder(view: View, viewType: Int):RecyclerView.ViewHolder

}