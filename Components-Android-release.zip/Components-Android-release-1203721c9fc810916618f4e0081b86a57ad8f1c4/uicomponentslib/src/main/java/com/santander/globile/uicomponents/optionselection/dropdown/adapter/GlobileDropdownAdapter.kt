package com.santander.globile.uicomponents.optionselection.dropdown.adapter

import android.content.Context
import android.os.Build
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.optionselection.dropdown.data.DropDownData

/**
 * Generic Adapter to create a DropDown.Adapter
 *
 * @param T: Generic any type of data.
 */
abstract class GlobileDropdownAdapter<T>(context: Context, val itemsList: List<DropDownData<T>>) : ArrayAdapter<DropDownData<T>>(context, R.layout.globile_dropdown_item, itemsList) {

    private var mSelectedItem = -1
    private var mInitialValue = -1
    private var adapterInitialized = false

    private var floatingLabel: TextView? = null
    private var selectText: TextView? = null

    private var selectView: View? = null

    var primaryColorInSelected: Int = 0
    var hintText: String? = null
    var floatingText: String? = null

    fun setSelected (position: Int){
        if (adapterInitialized) {
            mSelectedItem = position
        } else {
            mSelectedItem = mInitialValue
            adapterInitialized = true
        }
    }

    fun getSelectedItem() = mSelectedItem

    fun setInitialtValue(position: Int){
        mInitialValue = position
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        return initSelectView(position, convertView)
    }

    private fun initSelectView(position: Int, convertView: View?): View {
        if (adapterInitialized){
            mSelectedItem = position
        }

        selectView = convertView
        if (selectView == null) {
            selectView = View.inflate(
                context,
                R.layout.globile_dropdown_selector, null
            )
        }
        floatingLabel = selectView?.findViewById<View>(R.id.floating_label) as TextView
        selectText = selectView?.findViewById<View>(R.id.selected_text) as TextView

        if (Build.VERSION.SDK_INT < 23) {
            floatingLabel?.setTextAppearance(context, R.style.GlobileDropdownStyleTextAppearance)
            selectText?.setTextAppearance(context, R.style.GlobileDropdownStyleTextAppearance)
        }
        else {
            floatingLabel?.setTextAppearance(R.style.GlobileDropdownStyleTextAppearance)
            selectText?.setTextAppearance(R.style.GlobileDropdownStyleTextAppearance)
        }

        setPlaceholderText()

        return selectView!!
    }

    fun setPlaceholderText() {

        if (mSelectedItem !in 0 until itemsList.size) {
            floatingLabel?.visibility = View.GONE
            selectText?.setTextColor(context.resources.getColor(R.color.medium_grey))
            selectText?.text = hintText
        } else {
            selectText?.setTextColor(context.resources.getColor(R.color.grey))
            selectText?.text = (getItem(mSelectedItem))?.key ?: ""
            if (!floatingText.isNullOrEmpty()){
                floatingLabel?.text = floatingText
                floatingLabel?.visibility = View.VISIBLE
            } else {
                floatingLabel?.visibility = View.GONE
            }
        }

        if (!adapterInitialized && mInitialValue in 0 until itemsList.size) {
            floatingText?.let{
                floatingLabel?.text = it
                floatingLabel?.visibility = View.VISIBLE
            }
            selectText?.setTextColor(context.resources.getColor(R.color.grey))
            selectText?.text = (getItem(mInitialValue))?.key ?: ""
        }
    }

    override fun getDropDownView(
        position: Int, convertView: View?,
        parent: ViewGroup
    ): View {
        return initDropdownView(position, convertView)
    }

    private fun initDropdownView(position: Int, convertView: View?): View {
        var convertView = convertView
        if (convertView ==
            null
        )
            convertView = View.inflate(
                context,
                R.layout.globile_dropdown_item, null
            )
        val tvText1 = convertView!!.findViewById<View>(R.id.dropdown_item_text) as TextView

        if (Build.VERSION.SDK_INT < 23) {
            tvText1.setTextAppearance(context, R.style.GlobileDropdownStyleTextAppearance)
        }
        else {
            tvText1.setTextAppearance(R.style.GlobileDropdownStyleTextAppearance)
        }

        if(position == 0){
            tvText1.text = hintText
        }else {
            tvText1.text = (getItem(position))?.key ?: ""
        }

        if(position == 0){
            tvText1.setBackgroundColor(context.resources.getColor(R.color.dropdown_list_item_background))
            tvText1.setTextColor(context.resources.getColor(R.color.medium_grey))
        }else {
            if (position == mSelectedItem) {
                val backgroundDrawable = if (primaryColorInSelected == 0) {
                    context.resources.getDrawable(R.drawable.dropdown_item_red_background)
                } else {
                    context.resources.getDrawable(R.drawable.dropdown_item_turquoise_background)
                }
                tvText1.setBackground(backgroundDrawable)
                tvText1.setTextColor(context.resources.getColor(R.color.white))

            } else {
                tvText1.setBackgroundColor(context.resources.getColor(R.color.dropdown_list_item_background))
                tvText1.setTextColor(context.resources.getColor(R.color.grey))
            }
        }
        return convertView
    }

}