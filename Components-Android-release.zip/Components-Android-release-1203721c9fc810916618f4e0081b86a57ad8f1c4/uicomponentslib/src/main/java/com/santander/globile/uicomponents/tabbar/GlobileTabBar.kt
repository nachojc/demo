package com.santander.globile.uicomponents.tabbar

import android.content.Context
import android.content.res.ColorStateList
import android.os.Build
import android.support.design.bottomnavigation.LabelVisibilityMode
import android.support.design.internal.BottomNavigationItemView
import android.support.design.internal.BottomNavigationMenuView
import android.support.design.widget.BottomNavigationView
import android.support.v4.graphics.drawable.DrawableCompat
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import com.santander.globile.uicomponents.R
import kotlinx.android.synthetic.main.notification_badge.view.*
import kotlinx.android.synthetic.main.notification_badge_long.view.*


class GlobileTabBar @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : BottomNavigationView(context, attrs, defStyle) {
    init {

        itemBackground = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            DrawableCompat.wrap(context.resources.getDrawable(R.color.white, null))
        } else {
            DrawableCompat.wrap(context.resources.getDrawable(R.color.white))
        }


        labelVisibilityMode = if (menu.size() >= 5) {
            LabelVisibilityMode.LABEL_VISIBILITY_UNLABELED
        } else {
            LabelVisibilityMode.LABEL_VISIBILITY_LABELED
        }

        val colors = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            intArrayOf(resources.getColor(R.color.medium_grey, null), resources.getColor(R.color.santander_red, null))
        } else {
            intArrayOf(resources.getColor(R.color.medium_grey), resources.getColor(R.color.santander_red))
        }

        val states = arrayOf(
            intArrayOf(android.R.attr.state_enabled, -android.R.attr.state_checked),
            intArrayOf(android.R.attr.state_enabled, android.R.attr.state_checked)
        )

        itemTextColor = ColorStateList(states, colors)
        itemIconTintList = ColorStateList(states, colors)

    }

    /**
     * Method to set NotificationBadge in selected Tab by position
     *
     * @param position : Tab Position
     * @param quantity : Badge Quantity
     */

    fun setNotificationBadge(position: Int, quantity: Int) {
        val bottomNavigationMenuView = getChildAt(0) as BottomNavigationMenuView
        val v = bottomNavigationMenuView.getChildAt(position)
        val itemView = v as BottomNavigationItemView
        var quantityText: String
        when (quantity) {
            1 -> {
                addBadgeView(R.layout.notification_badge_empty, itemView)
            }
            in 2..9 -> {
                quantityText = quantity.toString()
                addBadgeView(R.layout.notification_badge, itemView)
                itemView.badge_item.text = quantityText
            }
            in 10..99 ->{
                quantityText = quantity.toString()
                addBadgeView(R.layout.notification_badge_long, itemView)
                itemView.badge_item_long?.text = quantityText
            }
            else -> {
                quantityText = "99+"
                addBadgeView(R.layout.notification_badge_long, itemView)
                itemView.badge_item_long?.text = quantityText
            }
        }
    }

    private fun addBadgeView(resId: Int, itemView: BottomNavigationItemView): View {
        return LayoutInflater.from(context)
            .inflate(resId, itemView, true)
    }
}