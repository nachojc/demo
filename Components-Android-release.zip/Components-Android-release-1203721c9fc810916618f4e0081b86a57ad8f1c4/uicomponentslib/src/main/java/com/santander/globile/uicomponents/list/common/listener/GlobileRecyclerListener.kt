package com.santander.globile.uicomponents.list.common.listener

import android.view.View

/**
 * Interface to handle onclick listener in viewholder.
 *
 * @param T : Generic any type of data.
 */
interface GlobileRecyclerListener<T> {

   /**
    * Function to catch onclicklistener in viewholder
    *
    * @param data: Generic any type of data
    * @param v : View clicked
    * @param code : Code asigned to view
    */
   fun onClickListener(data: T,v: View,code: Int)
}