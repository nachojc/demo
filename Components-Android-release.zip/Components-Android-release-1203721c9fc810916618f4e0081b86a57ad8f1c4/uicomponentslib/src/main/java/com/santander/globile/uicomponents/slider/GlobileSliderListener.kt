package com.santander.globile.uicomponents.slider

interface GlobileSliderListener {
    /**
     * Listener to catch on selection listener in slider
     *
     * @param thumbIndex -> Thumb index - 0 left button 1- right button
     * @param value -> value in slider
     */
    fun onSelectionListener(thumbIndex: Int,value: Int)
}