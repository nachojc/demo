package com.santander.globile.uicomponents.textinputlayout

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.drawable.Drawable
import android.os.Build
import android.support.constraint.Group
import android.support.v4.graphics.drawable.DrawableCompat
import android.support.v7.widget.AppCompatEditText
import android.text.InputFilter
import android.text.InputType
import android.util.AttributeSet
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.utils.setAnimationListener
import kotlinx.android.synthetic.main.globile_text_input_layout.view.*

class GlobileTextInputLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : LinearLayout(context, attrs, defStyle) {

    private var globileBottomTextView: TextView? = null
    private var groupEndView: Group? = null
    private var topLabelView: TextView? = null
    private var bottomTextView: TextView? = null
    private var endIconDrawableView: ImageView? = null
    private var bottomUpAnimation: Animation? = null
    private var bottomDownAnimation: Animation? = null
    private var spaceBarIndicatorView: View? = null
    private var iconRightDrawableTint: Int? = null
    private var iconRightDrawable: Int? = null
    private var iconEndDrawableTint: Int? = null
    private var iconEndDrawable: Int = 0
    private var placeholder : String? = null


    /**
     * Globile EditText
     */
    var globileEditTextView: AppCompatEditText? = null


    /**
     * Placeholder in editText
     */
    var globilePlaceholder: String? = null
        set(value) {
            placeholder = value
            setPlaceHolder(value)
        }

    var text: String?
        get() {
            return globileEditTextView?.text.toString()
        }
        set(value) {
            globileEditTextView?.setText(value)
        }

    /**
     * Error text to show in bottom textview in EditText
     */
    private var errorText: String? = null

    /**
     * Help text to show in bottom textview in EditText
     */
    private var helpText: String? = null


    /**
     * Tint color for RightIcon in EditText
     */
    var globileRightIconBackgroundTint: Int? = null
        set(value) {
            iconRightDrawableTint = value
            setIconRightDrawable(iconRightDrawable, value)
        }

    /**
     *  Right icon background drawable in EditText
     */
    var globileRightIconBackground: Int? = null
        set(value) {
            iconRightDrawable = value
            setIconRightDrawable(value, iconRightDrawableTint)
        }

    /**
     * Tint color for EndIcon in EditText
     */
    var globileEndIconBackgroundTint: Int = 0
        set(value) {
            iconEndDrawableTint = value
            setGlobileEndIconDrawable(iconEndDrawable, value)
        }

    /**
     *  End icon background drawable in EditText
     */
    var globileEndIconBackground: Int = 0
        set(value) {
            iconEndDrawable = value
            setGlobileEndIconDrawable(value,iconEndDrawableTint)
        }
    /**
     *  InputType in EditText
     */
    var inputType: Int? = null
        set(value) {
            setGlobileInputType(value)
        }

    /**
     *  TextSize in EditText
     */
    var textSize: Float? = null
        set(value) {
            setGlobileTextSize(value)
        }

    /**
     *  TextLength in EditText
     */
    var textLength: Int? = null
        set(value) {
            setGlobileTextLength(value)
        }


    init {
        LayoutInflater.from(context)
            .inflate(R.layout.globile_text_input_layout, this, true)
        orientation = VERTICAL
        globileEditTextView = findViewById(R.id.globile_edit_text)
        globileBottomTextView = findViewById(R.id.bottom_text)
        topLabelView = findViewById(R.id.placeholder_top)
        bottomTextView = findViewById(R.id.bottom_text)
        groupEndView = findViewById(R.id.groupEnd)
        spaceBarIndicatorView = findViewById(R.id.edit_text_spacer_indicator)
        endIconDrawableView = findViewById(R.id.globile_input_text_end_icon)
        bottomUpAnimation = AnimationUtils.loadAnimation(context, R.anim.label_up)
        bottomDownAnimation = AnimationUtils.loadAnimation(
            context,
            R.anim.label_down
        )

        globile_edit_text.setOnFocusChangeListener { v, hasFocus ->
            if (hasFocus) {
                showHint()
            } else {
                hideHint()
            }
        }

        createCustomLayout(attrs)

    }


    /**
     * Add onClickListener in Right button.
     *
     * @param listener OnClickListener
     */
    @SuppressLint("ClickableViewAccessibility")
    fun setRightIconClickListener(listener: OnClickListener){
        val view = globileEditTextView
        view?.let {
            globileEditTextView?.setOnTouchListener(object : RightDrawableOnTouchListener(view) {
                override fun onDrawableTouch(event: MotionEvent): Boolean {
                    listener.onClick(view)
                    return true
                }
            })
        }
    }

    /**
     * Add onClickListener in End button.
     *
     * @param listener OnClickListener
     */
    fun setEndIconClickListener(listener: OnClickListener){
        endIconDrawableView?.setOnClickListener {
            listener.onClick(endIconDrawableView)
        }
    }

    fun clear(){
        globileEditTextView?.text?.clear()
    }


    /**
     * Change globileEditText state to change colors
     *
     * @param globileEditTextState enum with two possibilities [GlobileEditTextState.ERROR] and [GlobileEditTextState.NORMAL]
     * @param bottomMessage message to set in bottom textview
     */
    fun changeState(globileEditTextState: GlobileEditTextState,bottomMessage: String? = null) {

        when (globileEditTextState.state) {
            0 -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    spaceBarIndicatorView?.setBackgroundColor(resources.getColor(R.color.dark_sky, null))
                    bottomTextView?.setTextColor(resources.getColor(R.color.grey, null))
                    topLabelView?.setTextColor(resources.getColor(R.color.medium_grey, null))
                    setGlobileEndIconDrawable(iconEndDrawable,iconEndDrawableTint)
                } else {
                    spaceBarIndicatorView?.setBackgroundColor(resources.getColor(R.color.dark_sky))
                    bottomTextView?.setTextColor(resources.getColor(R.color.grey))
                    topLabelView?.setTextColor(resources.getColor(R.color.medium_grey))
                    setGlobileEndIconDrawable(iconEndDrawable,iconEndDrawableTint)
                }
                if(bottomMessage!=null) {
                    setBottomText(bottomMessage)
                }else{
                    setBottomText(helpText)
                }
            }
            1 -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    spaceBarIndicatorView?.setBackgroundColor(resources.getColor(R.color.santander_red, null))
                    bottomTextView?.setTextColor(resources.getColor(R.color.santander_red, null))
                    topLabelView?.setTextColor(resources.getColor(R.color.santander_red, null))
                    setGlobileEndIconDrawable(iconEndDrawable,R.color.santander_red)

                } else {
                    spaceBarIndicatorView?.setBackgroundColor(resources.getColor(R.color.santander_red))
                    bottomTextView?.setTextColor(resources.getColor(R.color.santander_red))
                    topLabelView?.setTextColor(resources.getColor(R.color.santander_red))
                    setGlobileEndIconDrawable(iconEndDrawable,R.color.santander_red)
                }
                if(bottomMessage!=null) {
                    setBottomText(bottomMessage)
                }else{
                    setBottomText(errorText)
                }

            }
        }
    }

    private fun setPlaceHolder(placeholder: String?) {
        placeholder?.let {
            globileEditTextView?.hint = it
            topLabelView?.text = it
        }
    }

    private fun setIconRightDrawable(drawable: Int?, tintColor: Int?) {
        drawable?.let {
            if (it != 0) {
                val img: Drawable?

                if (tintColor != null && tintColor!=0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        img = DrawableCompat.wrap(context.resources.getDrawable(it, null))
                        img?.let {
                            DrawableCompat.setTint(it, resources.getColor(tintColor,null))
                        }
                    } else {
                        img = DrawableCompat.wrap(context.resources.getDrawable(it))
                        img?.let {
                            DrawableCompat.setTint(it, resources.getColor(tintColor))
                        }
                    }
                } else {
                    img = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        context.resources.getDrawable(it, null)
                    } else {
                        context.resources.getDrawable(it)
                    }
                }
                img?.let {
                    globileEditTextView?.setCompoundDrawablesWithIntrinsicBounds(null, null, img, null)
                }

            }
        }
    }

    private fun setGlobileEndIconDrawable(drawable: Int, tintColor: Int?) {
        if (drawable != 0) {
            enableEndIcon(true)
                var img: Drawable?

                if (tintColor != null && tintColor!=0) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        img = DrawableCompat.wrap(context.resources.getDrawable(drawable, null))
                        img?.let {
                            DrawableCompat.setTint(it, resources.getColor(tintColor,null))
                        }
                    } else {
                        img = DrawableCompat.wrap(context.resources.getDrawable(drawable))
                        img?.let {
                            DrawableCompat.setTint(it, resources.getColor(tintColor))
                        }
                    }
                } else {
                    img = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        context.resources.getDrawable(drawable, null)
                    } else {
                        context.resources.getDrawable(drawable)
                    }
                }
                img?.let {
                    endIconDrawableView?.setImageDrawable(img)
                }

        } else {
            enableEndIcon(false)
        }
    }




    private fun createCustomLayout(attrs: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GlobileTextInputLayout, 0, 0)
        globilePlaceholder = attributes.getString(R.styleable.GlobileTextInputLayout_placeholder)
        helpText = attributes.getString(R.styleable.GlobileTextInputLayout_helpText)
        errorText = attributes.getString(R.styleable.GlobileTextInputLayout_errorText)
        globileRightIconBackground = attributes.getResourceId(R.styleable.GlobileTextInputLayout_rightIconBackground, 0)
        globileRightIconBackgroundTint = attributes.getResourceId(R.styleable.GlobileTextInputLayout_rightIconBackgroundTint, 0)
        globileEndIconBackground = attributes.getResourceId(R.styleable.GlobileTextInputLayout_endIconBackground, 0)
        globileEndIconBackgroundTint = attributes.getResourceId(R.styleable.GlobileTextInputLayout_endIconBackgroundTint, 0)
        inputType =  converInputType(attributes.getInt(R.styleable.GlobileTextInputLayout_inputType, 0))
        textSize = attributes.getFloat(R.styleable.GlobileTextInputLayout_textSizeInput, 0f)
        textLength = attributes.getInt(R.styleable.GlobileTextInputLayout_textLength, 0)
        setBottomText(helpText)
        attributes.recycle()
    }

    private fun setBottomText(text: String?) {
        text?.let {
            bottomTextView?.text = it
        }
    }

    private fun converInputType(type: Int): Int =
        when(type){
            1->InputType.TYPE_CLASS_TEXT
            2->InputType.TYPE_CLASS_DATETIME
            3->InputType.TYPE_CLASS_DATETIME or InputType.TYPE_DATETIME_VARIATION_DATE
            4->InputType.TYPE_CLASS_NUMBER
            5->InputType.TYPE_NUMBER_FLAG_DECIMAL
            6->InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            7->InputType.TYPE_CLASS_PHONE
            8->InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            9->InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            10-> InputType.TYPE_TEXT_VARIATION_URI
            else -> InputType.TYPE_CLASS_TEXT
        }


    private fun setGlobileTextSize(textSize: Float?) {
        textSize?.let {
            if (textSize != 0f) {
                globileEditTextView?.setTextSize(TypedValue.COMPLEX_UNIT_SP, it)
            }
        }
    }

    private fun setGlobileTextLength(textLength: Int?) {
        textLength?.let {
            if (textLength != 0) {
                val fArray = arrayOfNulls<InputFilter>(1)
                fArray[0] = InputFilter.LengthFilter(textLength)
                globileEditTextView?.filters = fArray
            }
        }
    }


    private fun setGlobileInputType(inputType: Int?) {
        inputType?.let {
            if (it != 0) {
                globileEditTextView?.inputType = inputType
            }
        }
    }

    private fun showHint() {
        if (placeholder_top.visibility !== View.VISIBLE) {
            bottomUpAnimation?.setAnimationListener {
                onAnimationRepeat {
                }

                onAnimationEnd {

                }

                onAnimationStart {
                    placeholder_top.visibility = View.VISIBLE
                    globile_edit_text.hint = ""
                }
            }
            placeholder_top.startAnimation(bottomUpAnimation)
        }
    }

    private fun hideHint() {
        if (placeholder_top.visibility !== View.INVISIBLE && globile_edit_text.text.toString().isEmpty()) {


            bottomDownAnimation?.setAnimationListener {
                onAnimationRepeat {
                }

                onAnimationEnd {
                    globile_edit_text.hint = placeholder
                }

                onAnimationStart {
                    placeholder_top.visibility = View.INVISIBLE
                }
            }
            placeholder_top.startAnimation(bottomDownAnimation)
        }
    }

    private fun enableEndIcon(enable: Boolean) {
        if (enable) {
            groupEndView?.visibility = View.VISIBLE
        } else {
            groupEndView?.visibility = View.GONE
        }
    }

    enum class GlobileEditTextState(val state: Int) {
        NORMAL(0),
        ERROR(1)

    }

}