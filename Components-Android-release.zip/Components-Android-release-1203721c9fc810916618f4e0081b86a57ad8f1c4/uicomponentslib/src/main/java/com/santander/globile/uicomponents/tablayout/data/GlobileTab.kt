package com.santander.globile.uicomponents.tablayout.data

import android.support.v4.app.Fragment

/**
 *  Component for configure  GlobileBaseFragmentTabsAdapter and GlobileTabLayout
 *
 * @property titleId : Title for tab
 * @property iconId : Icon for tab
 * @property fragment: Fragment in viewpager
 *
 */
data class GlobileTab(val titleId: Int, val iconId: Int? = null,var fragment: Fragment)


