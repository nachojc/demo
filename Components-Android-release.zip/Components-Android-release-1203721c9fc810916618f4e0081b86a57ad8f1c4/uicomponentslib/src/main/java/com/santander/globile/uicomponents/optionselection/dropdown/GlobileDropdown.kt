package com.santander.globile.uicomponents.optionselection.dropdown

import android.animation.ValueAnimator
import android.content.Context
import android.os.Build
import android.support.constraint.ConstraintLayout
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.*
import com.santander.globile.uicomponents.R
import com.santander.globile.uicomponents.optionselection.dropdown.adapter.GlobileDropdownAdapter
import com.santander.globile.uicomponents.optionselection.dropdown.data.DropDownData
import com.santander.globile.uicomponents.optionselection.dropdown.listener.OnItemSelectedListener
import com.santander.globile.uicomponents.optionselection.dropdown.spinner.GlobileSpinner
import kotlinx.android.synthetic.main.globile_dropdown.view.*


class GlobileDropdown @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyle: Int = 0
) : LinearLayout(context, attrs, defStyle) {

    //View elements
    private var mSpinner: Spinner? = null
    private var mDropdownArrow: ImageView? = null
    private var mErrorText: ConstraintLayout? = null
    private var mErrorMessageTextView: TextView? = null
    private var mHelperMessageTextView: TextView? = null

    //User parametrizable values
    private var mPrimaryColorInSelected: Int = 0
    private var mHintText: String? = null
    private var mFloatingLabelText: String? = null
    private var mErrorMessageText: String? = null
    private var mHelperMessageText: String? = null

    /**
     * Set itemsList of options to show un dropdown
     *
     * @param itemsList itemsList of [DropDownData] elements in dropdown
     * @param initialSelectedValue item selected when create component [Int]. Optional, if not declared gets -1 value for no item select
     * @param selectListener listener for item selection
     */
    fun <T> setGlobileDropdown(itemsList : List<DropDownData<T>>, initialSelectedValue: Int = -1, selectListener: OnItemSelectedListener<T>){

        var list = itemsList.toMutableList()

        list.add(0, DropDownData(""))

        val mSpinnerAdapter = object : GlobileDropdownAdapter<T>(context, list){}

        with(component_spinner){
            adapter = mSpinnerAdapter

            onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
                override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
                    if(p2!=0) {
                        hideError()
                        mSpinnerAdapter.setSelected(p2)
                        if (p2 <= itemsList.size) {
                            selectListener.onItemSelected(list[p2])
                        }
                    }else{
                        mSpinnerAdapter.setSelected(-1)
                        mSpinnerAdapter.setPlaceholderText()
                        selectListener.onNothingSelected()
                    }
                }

                override fun onNothingSelected(p0: AdapterView<*>?) {
                    mSpinnerAdapter.setSelected(-1)
                    selectListener.onNothingSelected()
                }
            }

            setSpinnerEventsListener( object : GlobileSpinner.OnSpinnerEventsListener{
                override fun onSpinnerOpened() {
                    mDropdownArrow?.setImageResource(R.drawable.chevron_down_red)
                    rotateArrow()
                }

                override fun onSpinnerClosed() {
                    mDropdownArrow?.setImageResource(R.drawable.chevron_up_red)
                    rotateArrow()
                }
            })

            val selectedPosition = when (initialSelectedValue){
                in 0 until itemsList.size -> initialSelectedValue
                else -> -1
            }
            mSpinnerAdapter.setInitialtValue(selectedPosition)
            mSpinnerAdapter.primaryColorInSelected = mPrimaryColorInSelected
            mSpinnerAdapter?.hintText = mHintText
            mSpinnerAdapter?.floatingText = mFloatingLabelText

            setSelection(0) //Allow listen first element on first selection
        }

        setListViewHeightBasedOnChildren(list.count(),dropdownVisibleItemsCount)

    }


    private fun setListViewHeightBasedOnChildren(itemSize: Int,itemsToShow: Int) {

        val popup = Spinner::class.java.getDeclaredField("mPopup")
        popup.isAccessible = true

        // Get private mPopup member variable and try cast to ListPopupWindow
        val popupWindow = popup.get(mSpinner) as ListPopupWindow


        if(itemsToShow + 1 in 1..itemSize) {
            var totalHeight = 0f

            val count = if (itemSize > itemsToShow) itemsToShow else itemSize
            for (i in 0 until count + 1) {
                totalHeight += context.resources.getDimension(R.dimen.dropdown_item_height)
            }

            popupWindow.height = totalHeight.toInt()
        }
    }


    /**
     * Dropdown visible items by default is 5 elements.
     */

    private var dropdownVisibleItemsCount : Int = 7


    /**
     * Use primary color (red) or secondary (turquoise) on selected item
     */
    var primaryColor: Boolean? = true
        set(value) {
            mPrimaryColorInSelected = if (value != false) 0 else 1
            (component_spinner.adapter as? GlobileDropdownAdapter<*>)?.primaryColorInSelected = if (value != false) 0 else 1
        }

    /**
     * Hint text when no item is selected
     */
    var hintText: String? = null
        set(value) {
            mHintText = value
            (component_spinner.adapter as? GlobileDropdownAdapter<*>)?.hintText = value
        }

    /**
     * Floating label text
     */
    var floatingLabelText: String? = null
        set(value) {
            mFloatingLabelText = value
            (component_spinner.adapter as? GlobileDropdownAdapter<*>)?.floatingText = value
        }


    /**
     * Error message text
     */
    var errorText: String? = null
        set(value) {
            mErrorMessageText = value
            mErrorMessageTextView?.text = value
        }

    /**
     * Show error message
     */
    fun showError(){
        mHelperMessageTextView?.visibility = View.INVISIBLE
        mErrorText?.visibility = View.VISIBLE
    }

    /**
     * Hide error message
     */
    fun hideError(){
        mErrorText?.visibility = View.INVISIBLE
    }

    /**
     * Helper message helper text
     */
    var helperText: String? = null
        set(value) {
            mHelperMessageText = value
            mHelperMessageTextView?.text = value
        }

    /**
     * Show helper message
     */
    fun showHelper(){
        mErrorText?.visibility = View.INVISIBLE
        mHelperMessageTextView?.visibility = View.VISIBLE
    }

    /**
     * Show helper message
     */
    fun hideHelper(){
        mHelperMessageTextView?.visibility = View.INVISIBLE
    }

    init {
        LayoutInflater.from(context)
            .inflate(R.layout.globile_dropdown, this, true)

        mSpinner = findViewById(R.id.component_spinner)
        mDropdownArrow = findViewById(R.id.dropdown_arrow_image)
        mErrorText = findViewById<View>(R.id.error_layout) as ConstraintLayout
        mErrorMessageTextView = findViewById<View>(R.id.error_text) as TextView
        mHelperMessageTextView = findViewById<View>(R.id.dropdown_helper_text) as TextView


        createCustomLayout(attrs)

    }

    private fun createCustomLayout(attrs: AttributeSet?) {
        val attributes = context.obtainStyledAttributes(attrs, R.styleable.GlobileDropdown, 0, 0)
        primaryColor = attributes.getInt(R.styleable.GlobileDropdown_dropdownItemColor, 0) == 0
        hintText = attributes.getString(R.styleable.GlobileDropdown_dropdownHintText)
        floatingLabelText = attributes.getString(R.styleable.GlobileDropdown_dropdownFloatingLabelText)
        errorText = attributes.getString(R.styleable.GlobileDropdown_dropdownErrorMessageText)
        helperText = attributes.getString(R.styleable.GlobileDropdown_dropdownHelperMessageText)
        dropdownVisibleItemsCount = attributes.getInt(R.styleable.GlobileDropdown_dropdownVisibleItemsCount,7)

        if (Build.VERSION.SDK_INT < 23) {
            mErrorMessageTextView?.setTextAppearance(context, R.style.GlobileDropdownStyleTextAppearance)
            mHelperMessageTextView?.setTextAppearance(context, R.style.GlobileDropdownStyleTextAppearance)
        }
        else {
            mErrorMessageTextView?.setTextAppearance(R.style.GlobileDropdownStyleTextAppearance)
            mHelperMessageTextView?.setTextAppearance(R.style.GlobileDropdownStyleTextAppearance)
        }

        if (mHelperMessageText.isNullOrEmpty()){
            hideHelper()
        } else {
            showHelper()
        }

        attributes.recycle()
    }

    private fun rotateArrow(){

        val valueAnimator = ValueAnimator.ofFloat(0f, 180f)
        valueAnimator.addUpdateListener {
            val value = it.animatedValue as Float
            mDropdownArrow?.rotation = value
        }
        valueAnimator.interpolator = LinearInterpolator()
        valueAnimator.duration = 120
        valueAnimator.start()
    }

}