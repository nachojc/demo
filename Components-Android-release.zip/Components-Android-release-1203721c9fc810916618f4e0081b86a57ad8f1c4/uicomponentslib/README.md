# Introduction 
This component provides the native UI components to integrate into an app. The different components are:

* [AlertBar](#alertbar)
* [Cards](#cards)
* [Ending Button](#ending-button)
* [Error Handling](#error-handling)
* [Foundations](#foundations)
* [Initial Button](#initial-button)
* [Icon](#icon)
* [Input](#input)
* [Lists](#lists)
* [Navigation Bar](#navigation-bar)
* [Option Selection Button](#option-selection-button)
* [Option Selection Checkbox](#option-selection-checkbox)
* [Option Selection Dropdown](#option-selection-dropdown)
* [Option Selection Radio Button](#option-selection-radio-button)
* [Page Controller](#page-controller)
* [Profile Photo](#profile-photo)
* [Slider](#slider)
* [Stepper](#stepper)
* [TabBar](#tabbar)
* [Tabs](#tabs)
* [Tertiary Button](#tertiary-button)

# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android.git) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation "com.santander.globile:uicomponentslib:$uicomponents_version"
```
3. Sync project with Gradle files

# Use
## AlertBar

In this example you need a class thats extends from Activity() or from Fragment(), the alert bar will appear at top of that layout:

```kotlin	
// Text to show. Message can have HTML tags. 
// With this tags(<b><font color=#EC0000> Text in bold/red </font></b>) the message follow the Santander style guidelines.
val message = "The <b><font color=#EC0000>AlertBar</font></b> appears at top of <b><font color=#EC0000>Activity</font></b>."
val label = "ACTION"
 
// Show alert bar with a listener interface
showGlobileAlertBar(message, label, object : GlobileAlertBarListener {
    override fun onActionPressed() {
        Toast.makeText(applicationContext, "label pressed", Toast.LENGTH_SHORT).show()
    }
 
    override fun onDismissPressed() {
        Toast.makeText(applicationContext, "close pressed", Toast.LENGTH_SHORT).show()
    }
})
```

If you want to use a custom toolbar you need to add its ID for the alert bar appears below that toolbar:

```kotlin	
// Text to show. Message can have HTML tags. 
// With this tags(<b><font color=#EC0000> Text in bold/red </font></b>) the message follow the Santander style guidelines.
val message = "The <b><font color=#EC0000>AlertBar</font></b> appears below your <b><font color=#EC0000>custom toolbar</font></b>."
val label = "ACTION"
 
// Show alert bar with a listener interface
showGlobileAlertBar(R.id.custom_toolbar, message, label, object : GlobileAlertBarListener {
    override fun onActionPressed() {
        Toast.makeText(applicationContext, "label pressed", Toast.LENGTH_SHORT).show()
    }
 
    override fun onDismissPressed() {
        Toast.makeText(applicationContext, "close pressed", Toast.LENGTH_SHORT).show()
    }
})
```

## Cards

Insert the component view in xml layout:
style="@style/GlobileCardViewAppearance": THIS STYLE IS NECESSARY

```xml
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
                                             xmlns:app="http://schemas.android.com/apk/res-auto"
                                             android:background="#f7fbfc"
                                             android:layout_width="match_parent"
                                             android:layout_height="match_parent">
    <com.santander.globile.uicomponents.cardview.GlobileCardView
            style="@style/GlobileCardViewAppearance"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintBottom_toBottomOf="parent"
            android:layout_marginStart="16dp"
            android:layout_marginTop="16dp"
            android:layout_marginEnd="16dp"
            android:layout_marginBottom="16dp" app:layout_constraintVertical_bias="0.0"
            android:id="@+id/globileCardView">
        <android.support.constraint.ConstraintLayout
                android:layout_width="match_parent"
                android:layout_height="match_parent">
 
            <com.santander.globile.uicomponents.text.SantanderTextView
                    android:text="ES21 9493 5959 4949 3949593922"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:id="@+id/textView2"
                    app:layout_constraintStart_toStartOf="@+id/textView"
                    app:layout_constraintEnd_toEndOf="@+id/textView"
                    app:layout_constraintHorizontal_bias="0.0"
                    android:layout_marginTop="8dp" app:layout_constraintTop_toBottomOf="@+id/textView"/>
            <com.santander.globile.uicomponents.text.SantanderTextView
                    android:text="8.500,00€"
                    android:textSize="30sp"
                    android:textStyle="bold"
                    android:textColor="@color/santander_red"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:id="@+id/textView3"
                    app:layout_constraintStart_toStartOf="@+id/textView2"
                    app:layout_constraintEnd_toEndOf="parent"
                    app:layout_constraintHorizontal_bias="0.0"
                    android:layout_marginTop="50dp" app:layout_constraintTop_toBottomOf="@+id/textView2"
                    android:layout_marginEnd="8dp" android:layout_marginBottom="8dp"
                    app:layout_constraintBottom_toBottomOf="parent" app:layout_constraintVertical_bias="0.0"/>
            <com.santander.globile.uicomponents.text.SantanderTextView
                    android:text="SAVINGS ACCOUNT"
                    android:textStyle="bold"
                    android:layout_width="wrap_content"
                    android:layout_height="wrap_content"
                    android:id="@+id/textView"
                    app:layout_constraintStart_toStartOf="parent"
                    app:layout_constraintEnd_toEndOf="parent"
                    android:layout_marginTop="16dp" app:layout_constraintTop_toTopOf="parent"
                    app:layout_constraintHorizontal_bias="0.0" android:layout_marginStart="16dp"/>
        </android.support.constraint.ConstraintLayout>
 
    </com.santander.globile.uicomponents.cardview.GlobileCardView>
 
</android.support.constraint.ConstraintLayout>
```

## Ending Button

Example of a primary ending button:

```xml	
<com.santander.globile.uicomponents.buttons.endingbutton.EndingButton
                android:id="@+id/primary_button"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="10dp"
                android:paddingRight="10dp"
                android:paddingLeft="10dp"
                android:text="@string/text_primary_button"
                app:buttonType="primary"
                android:enabled="true"/>
```

Example of a secondary ending button:

```xml	
<com.santander.globile.uicomponents.buttons.endingbutton.EndingButton
                android:id="@+id/secondary_button"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="10dp"
                android:paddingRight="10dp"
                android:paddingLeft="10dp"
                android:text="@string/text_secondary_button"
                app:buttonType="secondary"
                android:enabled="true"/>
```


Example of a disabled ending button. In this case only `android:enabled="false"` is necessary. If this attribute is not set, the default value for `android:enable` is true:

```xml	
<com.santander.globile.uicomponents.buttons.endingbutton.EndingButton
                android:id="@+id/secondary_button"
                android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:layout_marginTop="10dp"
                android:paddingRight="10dp"
                android:paddingLeft="10dp"
                android:text="@string/text_secondary_button"
                app:buttonType="secondary"
                android:enabled="false"/>
```

In case is necessary to set the disabled look & feel up programmatically:
	
```kotlin	
setDisabledButton()
```

## Error Handling

Given an any class, calling the error handler component requires a single call to showErrorDialog as it is illustrated in the code example:

```kotlin	
package com.santander.globile.errorhandlinglib
 
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.google.gson.Gson
import com.santander.globile.errorhandlinglib.common.showErrorDialog
import com.santander.globile.errorhandlinglib.common.*
import com.santander.globile.errorhandlinglib.dialog.ErrorhandlingDialogFragment
 
class ErrorhandlingActivity : AppCompatActivity()
    , ErrorhandlingDialogFragment.OnDismissListener, ErrorhandlingDialogFragment.OnClickListener {
 
    override fun onButtonClick(code: Int) {
        setResult(Activity.RESULT_OK, Intent().putExtra(EXTRA_FUNCTION, code))
        finish()
    }
 
    override fun onDismiss() {
        setResult(Activity.RESULT_OK, Intent().putExtra(EXTRA_FUNCTION, BUTTON_DISMISS_CODE))
        finish()
    }
 
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = ""
        showErrorDialog(
            supportFragmentManager, DIALOG_TAG, createErrorhandlingParams()
            , this, this, this
        )
    }
 
    private fun createErrorhandlingParams(): ErrorhandlingParams {
        return ErrorhandlingParams()
  
    }
}
```

## Foundations

An example of setting up a font

```kotlin
setTypeface(ResourcesCompat.getFont(context, R.font.santander_text_regular), style)
```

An example of using a color

```xml
<style name="GlobileSantanderRed">
    <item name="android:textColor">@color/santander_red</item>
</style>
```

## Initial Button

Single button with the icon in the left position:

```xml	
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:layout_width="match_parent"
        android:layout_height="match_parent">
 
    <com.santander.globile.uicomponents.buttons.initialbutton.InitialButton
            android:id="@+id/single_button"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:padding="4dp"
            app:buttonText="Santander Globile"
            app:imagePosition="left"
            app:imageResource="@drawable/ic_add_shopping_cart"
            app:textSize="16"
            app:layout_constraintTop_toTopOf="parent"/>
 
</android.support.constraint.ConstraintLayout>
```


You can add a click listener in the class that contains the button to perform an action:

```kotlin	
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.buttons_layout.*
 
class ButtonsFragment: Fragment() {
 
    companion object {
        fun newInstance(): ButtonsFragment {
            return ButtonsFragment()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_buttons, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
         
        single_button.setOnClickListener {
            //Action
        }
    }
}
```


To place several buttons in a row you have to consider the heights of the different buttons (one or two lines) and adjust the constraints to the higher one, as seen in this example:

```xml	
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:layout_width="match_parent"
        android:layout_height="match_parent">
 
        <android.support.constraint.ConstraintLayout
            android:id="@+id/three_buttons_layout"
            android:layout_width="match_parent"
            android:layout_height="0dp"
            app:layout_constraintTop_toTopOf="parent">
        <com.santander.globile.uicomponents.buttons.initialbutton.InitialButton
                android:id="@+id/button_one"
                android:layout_width="0dp"
                android:layout_height="0dp"
                android:padding="6dp"
                app:buttonText="Help us"
                app:textSize="15"
                app:imagePosition="top"
                app:imageResource="@drawable/ic_add_shopping_cart"
                app:layout_constraintHorizontal_weight="1"
                app:layout_constraintBottom_toBottomOf="@id/button_three"
                app:layout_constraintTop_toTopOf="@id/button_three"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintEnd_toStartOf="@id/button_two"/>
        <com.santander.globile.uicomponents.buttons.initialbutton.InitialButton
                android:id="@+id/button_two"
                android:layout_width="0dp"
                android:layout_height="0dp"
                android:padding="6dp"
                app:buttonText="Renting"
                app:textSize="15"
                app:imagePosition="top"
                app:imageResource="@drawable/ic_add_shopping_cart"
                app:layout_constraintHorizontal_weight="1"
                app:layout_constraintBottom_toBottomOf="@id/button_three"
                app:layout_constraintStart_toEndOf="@id/button_one"
                app:layout_constraintEnd_toStartOf="@id/button_three"
                app:layout_constraintTop_toTopOf="@id/button_three"/>
        <com.santander.globile.uicomponents.buttons.initialbutton.InitialButton
                android:id="@+id/button_three"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                android:padding="6dp"
                app:buttonText="Pay and \n transfers"
                app:textSize="15"
                app:imagePosition="top"
                app:imageResource="@drawable/ic_add_shopping_cart"
                app:layout_constraintHorizontal_weight="1"
                app:layout_constraintBottom_toBottomOf="parent"
                app:layout_constraintStart_toEndOf="@id/button_two"
                app:layout_constraintEnd_toEndOf="parent"
                app:layout_constraintTop_toTopOf="parent"/>
 
    </android.support.constraint.ConstraintLayout>
 
</android.support.constraint.ConstraintLayout>
```

## Icon

To add the icon component in a layout:

```xml	
<LinearLayout
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:orientation="vertical"
        android:layout_weight="1"
        android:gravity="center_horizontal">
 
    <com.santander.globile.uicomponents.image.icon.IconGlobile
            android:id="@+id/icon_1_1"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:layout_marginTop="15dp"/>
 
    <com.santander.globile.uicomponents.image.icon.IconGlobile
            android:id="@+id/icon_1_2"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:layout_marginTop="15dp"/>
 
    <com.santander.globile.uicomponents.image.icon.IconGlobile
            android:id="@+id/icon_1_3"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            android:layout_weight="1"
            android:layout_marginTop="15dp"/>
 
</LinearLayout>
```


Also to set up the icon and the badge, here are some examples:

```kotlin	
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
 
    //Fila 1
    icon_1_1.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.SMALL)
 
    icon_1_2.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.MEDIUM)
 
    icon_1_3.setIcon(R.drawable.ic_documents_doc04, IconColor.BOSTON_RED, IconSize.BIG)
 
 
    icon_2_1.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.SMALL)
    icon_2_1.setBadge(0, BadgeType.PRIMARY, IconSize.SMALL)
 
    icon_2_2.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.MEDIUM)
    icon_2_2.setBadge(0, BadgeType.PRIMARY, IconSize.MEDIUM)   
 
    icon_2_3.setIcon(R.drawable.ic_documents_doc04, IconColor.GREY, IconSize.BIG)
    icon_2_3.setBadge(0, BadgeType.PRIMARY, IconSize.BIG)
 
 
    icon_3_1.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.SMALL)
    icon_3_1.setBadge(12, BadgeType.SECONDARY, IconSize.SMALL)
 
    icon_3_2.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.MEDIUM)
    icon_3_2.setBadge(12, BadgeType.SECONDARY, IconSize.MEDIUM)
 
    icon_3_3.setIcon(R.drawable.ic_documents_doc04, IconColor.WHITE, IconSize.BIG)
    icon_3_3.setBadge(12, BadgeType.SECONDARY, IconSize.BIG)
}
```

## Input

An example of this component from native code:

```kotlin	
package com.santander.globile.app.views.uicomponents.textinputlayout
 
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.santander.globile.app.R
import com.santander.globile.uicomponents.textinputlayout.GlobileTextInputLayout
import kotlinx.android.synthetic.main.fragment_uicomponents_textinputlayout.*
 
class GlobalInputTextLayoutFragment: Fragment() {
    companion object {
        fun newInstance(): GlobalInputTextLayoutFragment {
            return GlobalInputTextLayoutFragment()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_uicomponents_textinputlayout, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
 
         
        errorEditTextView.changeState(GlobileTextInputLayout.GlobileEditTextState.ERROR)
        errorEditTextView.setEndIconClickListener(View.OnClickListener {
            Toast.makeText(context,"Hello World",Toast.LENGTH_LONG).show()
        })
        errorEditTextView.setRightIconClickListener(View.OnClickListener {
            errorEditTextView.clear()
        })
    }
}
```

Also the input component can be added from xml with attributes

```xml	
<com.santander.globile.uicomponents.textinputlayout.GlobileTextInputLayout
        android:id="@+id/errorEditTextView"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        app:placeholder="Recipient"
        app:helpText="Please enter name and surname."
        app:rightIconBackground="@drawable/icn_clear"
        app:endIconBackground="@drawable/ic_account_balance_white_24dp"
        app:endIconBackgroundTint="@color/black"
        android:layout_marginStart="20dp"
        android:layout_marginEnd="20dp"
        app:layout_constraintEnd_toEndOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintHorizontal_bias="0.0"
        android:layout_marginTop="8dp"
        app:layout_constraintTop_toBottomOf="@+id/globileTextInputLayout2"/>
```


## Lists

To use this component you should implement GlobileRecyclerView in your layout.

```xml	
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
	xmlns:app="http://schemas.android.com/apk/res-auto" 	android:layout_width="match_parent"
	android:layout_height="match_parent">
 
   <com.santander.globile.uicomponents.list.common.recycler.GlobileRecyclerView
            android:id="@+id/component_recycler_test"
            android:layout_width="0dp"
            android:layout_height="0dp"
            android:layout_margin="8dp"
            android:visibility="visible"
            app:layout_constraintStart_toStartOf="parent"
            android:layout_marginStart="8dp"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            android:layout_marginEnd="8dp"
            app:layout_constraintBottom_toBottomOf="parent"/>
</android.support.constraint.ConstraintLayout>
```

You can implement different cases of lists with different views:

Simple List:

Example to create a simple list with key value and without click listener:

* Create new fragment with recyclerview in your layout.
* Create a simple Arraylist of SimpleData, SimpleData only contains Key / Value variables.
* Create new instance of GlobileSimpleRecyclerAdapter with your new list of simple data.

```kotlin
class RecyclerClassSimple: Fragment() {
 
    companion object {
        fun newInstance(): RecyclerClassSimple {
            return RecyclerClassSimple()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_recycler_test, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
 
        val list = ArrayList<SimpleData>()
        val simpledata1 = SimpleData("key1", "value1")
        val simpledata2 = SimpleData("key2", "value2")
        val simpledata3 = SimpleData("key3", "value3")
        val simpledata4 = SimpleData("key4", "value4")
 
        list.add(simpledata1)
        list.add(simpledata2)
        list.add(simpledata3)
        list.add(simpledata4)
 
        component_recycler_test.layoutManager = LinearLayoutManager(context)
        component_recycler_test.adapter = GlobileSimpleRecyclerAdapter(list)
 
    }
}
```

Complex List:

Example to create a complex list with custom view and multiple onclick listeners:

* Create a new layout with your cell view.
* Create a new ViewHolder extending of GlobileGenericBinder<T> , T is a type of object that you want to use within your viewholder. For example:  card, user, info etc...
* Create a new GlobileGenericRecyclerAdapter<T> with type of object that you want to use within your viewholder and set list of this object in the main constructor, you can set a GlobileRecyclerListener if you want but is not mandatory.
* GlobileGenericRecyclerAdapter will be implement two methods:
        `getLayoutId`: set layout id from your custom row.
        getViewHolder`: set your custom viewholder.
* Add your custom GlobileGenericRecyclerAdapter to your recyclerview.

ViewHolder:

The code of onClickListener is a descriptive code to catch onclick listener of any element in the view.

For example:

* Code 0 for entire cell.
* Code 1 for close button.
* Code 2 for edit button.

```kotlin
class CustomViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), GlobileGenericBinder<Any> {
    override fun bind(data: Any, listener: GlobileRecyclerListener<Any>?) {
        itemView?.let {view ->
            view.setOnClickListener{
                listener?.onClickListener(data,view,0)
            }
            view.button_edit.setOnClickListener {
                listener?.onClickListener(data,view,1)
            }
            view.button_close.setOnClickListener {
                listener?.onClickListener(data,view,2)
            }
        }
    }
}
```


MainFragment:

By default that list have a default line decorator separator in light_grey color, if you want to remove this decorator you should use: 

* your_recycler_view.removeDecoration()

However if you want to change the color of the separation line you should call:

* your_recycler_view.addDecoration(color:Int)

```kotlin	
class RecyclerClassCustom: Fragment() , GlobileRecyclerListener<Any> {
 
    companion object {
        fun newInstance(): RecyclerClassCustom {
            return RecyclerClassCustom()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_recycler_test, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
 
 
        val dummyList = ArrayList<Any>()
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
 
        val customAdapter = object : GlobileGenericRecyclerAdapter<Any>(dummyList,this) {
            override fun getLayoutId(position: Int, obj: Any): Int {
                return R.layout.custom_row
            }
 
            override fun getViewHolder(view: View, viewType: Int): RecyclerView.ViewHolder {
                return CustomViewHolder(view)
            }
        }
 
        component_recycler_test.layoutManager = LinearLayoutManager(context)
        component_recycler_test.adapter = customAdapter
    }
 
    override fun onClickListener(data: Any, v: View, code: Int) {
        when(code){
            0 -> Toast.makeText(context,"click on row",Toast.LENGTH_LONG).show()
            1 -> Toast.makeText(context,"BUTTON 1",Toast.LENGTH_LONG).show()
            2 -> Toast.makeText(context,"BUTTON 2",Toast.LENGTH_LONG).show()
        }
    }
}
```


Menu List:

This list will be a list inside a GlobileCardView. Its code will be updated with new functionalities soon.

An example to create a menu list with multiple custom view and multiple onclick listeners:

* Create a layout with GlobileRecyclerView inside GlobileCardView view, card view should have:
        style="@style/GlobileCardViewAppearance"
* Create multiple layouts "if you need" with multiple types of cells.
* Create a new ViewHolder extending of GlobileGenericBinder<T> , T is a type of object that you want to use within your viewholder fo example:  card, user, info etc...; This viewholder will control all layouts and all views and buttons.
* Create a new GlobileGenericRecyclerAdapter<T> with type of object that you want to use within your viewholder and set list of this object in the main constructor, you can set a GlobileRecyclerListener if you want but is not mandatory.
* GlobileGenericRecyclerAdapter will implement two methods:
            `getLayoutId`: set layout ids from your custom rows.
            `getViewHolder`: set your custom viewholder.
* Add your custom GlobileGenericRecyclerAdapter to your recyclerview

Layout:

If you want to put menus you should create a new GlobileCardView with GlobileRecyclerView inside.

This GlobileRecyclerView have a new appearance and scroll disabled.

```xml	
<?xml version="1.0" encoding="utf-8"?>
 
<ScrollView
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:layout_width="match_parent"
        android:layout_height="match_parent">
 
    <android.support.constraint.ConstraintLayout android:layout_width="match_parent"
                                                 android:layout_height="match_parent">
 
        <com.santander.globile.uicomponents.cardview.GlobileCardView
                style="@style/GlobileCardViewAppearance"
                android:id="@+id/card1"
                android:layout_width="0dp"
                android:layout_height="wrap_content"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toTopOf="parent"
                app:layout_constraintEnd_toEndOf="parent" android:layout_marginTop="8dp"
                android:layout_marginStart="8dp" android:layout_marginEnd="8dp">
            <com.santander.globile.uicomponents.list.common.recycler.GlobileRecyclerView
                    android:id="@+id/component_recycler_test1"
                    android:layout_width="match_parent"
                    android:layout_height="match_parent"/>
        </com.santander.globile.uicomponents.cardview.GlobileCardView>
 
        <com.santander.globile.uicomponents.cardview.GlobileCardView
                style="@style/GlobileCardViewAppearance"
                android:id="@+id/card2"
                android:layout_width="0dp"
                android:layout_marginTop="30dp"
                android:layout_height="wrap_content"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toBottomOf="@id/card1"
                app:layout_constraintEnd_toEndOf="parent" android:layout_marginStart="8dp"
                android:layout_marginEnd="8dp">
            <com.santander.globile.uicomponents.list.common.recycler.GlobileRecyclerView
                    android:id="@+id/component_recycler_test2"
                    android:layout_width="match_parent"
                    android:layout_height="match_parent"/>
        </com.santander.globile.uicomponents.cardview.GlobileCardView>
 
        <com.santander.globile.uicomponents.cardview.GlobileCardView
                style="@style/GlobileCardViewAppearance"
                android:id="@+id/card3"
                android:layout_width="0dp"
                android:layout_marginTop="30dp"
                android:layout_height="wrap_content"
                app:layout_constraintStart_toStartOf="parent"
                app:layout_constraintTop_toBottomOf="@id/card2"
                app:layout_constraintEnd_toEndOf="parent" android:layout_marginStart="8dp"
                android:layout_marginEnd="8dp" app:layout_constraintBottom_toBottomOf="parent"
                android:layout_marginBottom="8dp">
            <com.santander.globile.uicomponents.list.common.recycler.GlobileRecyclerView
                    android:id="@+id/component_recycler_test3"
                    android:layout_width="match_parent"
                    android:layout_height="match_parent"/>
        </com.santander.globile.uicomponents.cardview.GlobileCardView>
    </android.support.constraint.ConstraintLayout>
</ScrollView>
```

ViewHolder:

The code of onClickListener is a descriptive code to catch onclick listener of any element within the view.

For example:

* Code 0 for entire cell.
* Code 1 for close button.
* Code 2 for edit button.
* Code 3 custom view click.

You should create a data object witch contains complex data to use this viewholder with many views and parameters.

```kotlin	
class ComplexViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView), GlobileGenericBinder<Any> {
    override fun bind(data: Any, listener: GlobileRecyclerListener<Any>?) {
        itemView?.let {view ->
            view.setOnClickListener{
                listener?.onClickListener(data,view,0)
            }
            view.button_edit?.setOnClickListener {
                listener?.onClickListener(data,view,1)
            }
            view.button_close?.setOnClickListener {
                listener?.onClickListener(data,view,2)
            }
            view.customImage?.setOnClickListener {
                listener?.onClickListener(data,view,3)
            }
            view.customButton?.setOnClickListener {
                listener?.onClickListener(data,view,4)
            }
            view.title?.text = data?.title
            view.subTitle?.text = data?.subTitle
        }
    }
}
```


MainFragment:

By default that list have a line decorator separator in light_grey color, if you want to remove this decorator you should use: 

* your_recycler_view.removeDecoration()

However, if you want to change the color of the separation line you should call:

* your_recycler_view.addDecoration(color:Int)

You can create a custom data object o manage layouts. For example:

MenuObject:

* layoutId : Int
* data : Any (you can cast it in viewholder)

You can set this layout ids in getLayoutId function and you will set rows with different views managed by only one viewholder.

```kotlin	
class RecyclerClassComplexCustom: Fragment() , GlobileRecyclerListener<Any> {
 
    companion object {
        fun newInstance(): RecyclerClassComplexCustom {
            return RecyclerClassComplexCustom()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_recycler_cards, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
 
 
        val dummyList = ArrayList<Any>()
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
        dummyList.add(Any())
 
 
        val customAdapter = object : GlobileGenericRecyclerAdapter<Any>(dummyList,this) {
            override fun getLayoutId(position: Int, obj: Any): Int {
               return when(position){
                    0->R.layout.example_row1
                    1->R.layout.example_row2
                    2->R.layout.example_row3
                   else -> R.layout.example_row1
               }
            }
 
            override fun getViewHolder(view: View, viewType: Int): RecyclerView.ViewHolder {
                return ComplexViewHolder(view)
            }
        }
 
        component_recycler_test1.layoutManager = LinearLayoutManager(context)
        component_recycler_test1.adapter = customAdapter
 
        component_recycler_test2.layoutManager = LinearLayoutManager(context)
        component_recycler_test2.adapter = customAdapter
 
        component_recycler_test3.layoutManager = LinearLayoutManager(context)
        component_recycler_test3.adapter = customAdapter
 
 
    }
 
    override fun onClickListener(data: Any, v: View, code: Int) {
    }
}
```

## Navigation Bar


Any Activity extended by Globile ActionBarActivity should include toolbar in layout xml view file:

```Kotlin	
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.santander.globile.uicomponents.actionbar.GlobileActionBarActivity
import com.santander.globile.uicomponents.actionbar.ToolbarStyle
 
 
class MainActivity : GlobileActionBarActivity(ToolbarStyle.STYLE_WHITE) {
 
    override fun setLayoutId(): Int {
       return R.layout.activity_main
    }
 
    override fun setActionIconResource(): Int {
        return R.drawable.ic_shopping
    }
 
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "Hello Title"
        addOnClickListenerActionIcon(View.OnClickListener {
            Toast.makeText(this,"hello world",Toast.LENGTH_SHORT).show()
        })
        hideActionIcon()
        setDrawerEnabled(false)
    }
 
}
```

```xml	
<?xml version="1.0" encoding="utf-8"?>
<android.support.v4.widget.DrawerLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:tools="http://schemas.android.com/tools"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:id="@+id/globile_navigation_drawer"
        android:layout_width="match_parent"
        android:layout_height="match_parent"
        android:fitsSystemWindows="true"
        tools:context=".views.main.MainActivity">
 
    <LinearLayout
            android:layout_width="match_parent"
            android:layout_height="match_parent"
            android:orientation="vertical">
        <include layout="@layout/globile_toolbar"/>
 
    </LinearLayout>
 
    <android.support.design.widget.NavigationView
            android:id="@+id/nav_view"
            android:layout_width="wrap_content"
            android:layout_height="match_parent"
            android:layout_gravity="end"
            app:menu="@menu/nav_items"
            android:fitsSystemWindows="true"/>
 
</android.support.v4.widget.DrawerLayout>
```

Any Activity created in manifest xml should include theme parameter with GlobileTheme:

```xml	
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
          package="com.santander.globile.app">
 
    <application
            android:allowBackup="true"
            android:icon="@mipmap/ic_launcher"
            android:label="@string/app_name"
            android:roundIcon="@mipmap/ic_launcher_round"
            android:supportsRtl="true"
            android:theme="@style/GlobileTheme">
        <activity android:name=".views.main.MainActivity">
            <intent-filter>
                <action android:name="android.intent.action.MAIN"/>
 
                <category android:name="android.intent.category.LAUNCHER"/>
            </intent-filter>
        </activity>
    </application>
 
    <uses-permission android:name="android.permission.INTERNET"/>
 
</manifest>
```

## Option Selection Button

To use the Option Selection from the layout:

```xml	
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
                                             xmlns:tools="http://schemas.android.com/tools" android:layout_width="match_parent"
                                             android:layout_height="match_parent"
                                             xmlns:app="http://schemas.android.com/apk/res-auto">
 
    <com.santander.globile.uicomponents.optionselection.GlobileButtonSelector
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:id="@+id/globile_selector"
            app:optionsCount="three"
            app:buttonRightText="right"
            app:defaultSelector="right"
            app:buttonLeftText="left"
            app:buttonCenterText="center"
            app:layout_constraintStart_toStartOf="parent"
            android:layout_marginStart="8dp"
            app:layout_constraintEnd_toEndOf="parent"
            android:layout_marginEnd="8dp" app:layout_constraintHorizontal_bias="0.0"
            android:layout_marginTop="56dp" app:layout_constraintTop_toBottomOf="@+id/globile_selector2"/>
 
 
    <com.santander.globile.uicomponents.optionselection.GlobileButtonSelector
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:id="@+id/globile_selector2"
            app:optionsCount="two"
            app:buttonRightText="right"
            app:defaultSelector="right"
            app:buttonLeftText="Left"
            app:layout_constraintStart_toStartOf="parent"
            android:layout_marginStart="8dp"
            android:layout_marginTop="8dp"
            app:layout_constraintTop_toTopOf="parent"
            app:layout_constraintEnd_toEndOf="parent"
            android:layout_marginEnd="8dp"/>
 
</android.support.constraint.ConstraintLayout>
```

## Option Selection Checkbox

An example of a layout:

```xml
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
                        xmlns:app="http://schemas.android.com/apk/res-auto"
                        android:layout_width="match_parent"
                        android:layout_height="match_parent">
 
    <com.santander.globile.uicomponents.optionselection.checkbox.GlobileCheckbox
        style="@style/GlobileCheckboxAppearance"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Lorem ipsum dolor"
        app:default_color="red"
        android:id="@+id/globileCheckbox"/>
 
</android.support.constraint.ConstraintLayout>
```

## Option Selection Dropdown

First, insert view in xml layout with the necessary attributes, this code corresponds to first screenshot (default color is red, with floating label):
dropdownVisibleItemsCount : Sets items visible in dropdown, default items visible is 5 if you use 0 you will see all items


```xml
<com.santander.globile.uicomponents.optionselection.dropdown.GlobileDropdown
        android:id="@+id/top_dropdown"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_margin="16dp"
        app:dropdownVisibleItemsCount="7"
        app:dropdownHintText="Select a provider"
        app:dropdownFloatingLabelText="Provider"
        app:dropdownErrorMessageText="Error! Select an option before going on"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toStartOf="parent"/>
```

Then, add the list of options to the component programmatically:

```kotlin	
....
 
var companySelected: Company? = null
 
// Example object class
data class Company (val name: String, val id: Int)
 
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
 
    // Create list of options to GlobileDropdown component, each one has the text of the label and the object that holds
    val item1 = DropDownData("At&T", Company("At&t", 12))
    val item2 = DropDownData("Verizon", Company("Verizon", 34))
    val item3 = DropDownData("Vodafone", Company("Vodafone", 56))
    val item4 = DropDownData("BT Group", Company("BT Group", 67))
    val item5 = DropDownData("Movistar", Company("Movistar", 89))
    val itemsList = listOf(item1, item2, item3, item4, item5)
 
    top_dropdown.setGlobileDropdown(itemsList, selectListener = object : OnItemSelectedListener<Company> { //Add list without a default item selected
        override fun onItemSelected(item: DropDownData<Company>) {  //Returns the same object
            result_textview.text = item.value?.name
            companySelected = item.value
            top_dropdown.hideError()    //Hide error message when item is selected
        }
 
        override fun onNothingSelected() {
 
        }
    })
    // Show error when need to continue and a required option has not been selected.
    submit_button.setOnClickListener {
        if (companySelected == null) {
            top_dropdown.showError()  //Show error
        } else {
            result_textview.text = "Selected: ${companySelected!!.name}"
        }
}
 
....
```


To init the component with a default item selected, add this parameter when list of options is added to the component:

```kotlin
val item02 = DropDownData("0-2", "Low")
val item25 = DropDownData("2-5", "Medium")
val item510 = DropDownData("5-10", "Hight")
val item10p = DropDownData("10+", "Top")
val rangesList = listOf(item02, item25, item510, item10p)
 
bottom_dropdown.setGlobileDropdown(rangesList, 1, object : OnItemSelectedListener<String>{ //Option 1("2-5") will appear selected the first time dropdown is expanded.
    override fun onItemSelected(item: DropDownData<String>) { // Returns String, that is the <T> object in this DropDownData
       
    }
    override fun onNothingSelected() {
       
    }
})
```

## Option Selection Radio Button

To add the radio button into the layout:

```xml	
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
                                             xmlns:tools="http://schemas.android.com/tools" android:layout_width="match_parent"
                                             android:layout_height="match_parent"
                                             xmlns:app="http://schemas.android.com/apk/res-auto">
 
    <RadioGroup android:layout_width="wrap_content" android:layout_height="wrap_content"
                android:layout_marginBottom="8dp"
                app:layout_constraintBottom_toBottomOf="parent" app:layout_constraintEnd_toEndOf="parent"
                android:layout_marginEnd="8dp" app:layout_constraintStart_toStartOf="parent"
                android:layout_marginStart="8dp" android:layout_marginTop="8dp"
                app:layout_constraintTop_toTopOf="parent" app:layout_constraintVertical_bias="0.13"
                android:id="@+id/radioGroup2">
 
        <com.santander.globile.uicomponents.optionselection.radiobutton.GlobileRadioButton
               style="@style/GlobileRadioButtonAppaerance"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                app:default_color="red"
                android:text="option 1"
        />
        <com.santander.globile.uicomponents.optionselection.radiobutton.GlobileRadioButton
                style="@style/GlobileRadioButtonAppaerance"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                app:default_color="red"
                android:text="option 2"
        />
        <com.santander.globile.uicomponents.optionselection.radiobutton.GlobileRadioButton
                style="@style/GlobileRadioButtonAppaerance"
                android:layout_width="wrap_content"
                android:layout_height="wrap_content"
                app:default_color="red"
                android:text="option 3"
        />
    </RadioGroup>
</android.support.constraint.ConstraintLayout>
```

## Page Controller

Add this component below a ViewPager in .xml layout:

```xml	
<android.support.v4.view.ViewPager
	android:id="@+id/viewPager" 
	android:layout_height="100dp" 
	android:layout_width="match_parent"/>
	
<com.santander.globile.uicomponents.pagecontroller.PageControllerIndicator 
	android:id="@+id/textViewIndicator" 
	android:layout_width="wrap_content" 
	android:layout_height="wrap_content" 
	android:layout_marginTop="8dp" 
	app:layout_constraintTop_toBottomOf="@id/viewPager" 
	app:layout_constraintStart_toStartOf="parent" 
	app:layout_constraintEnd_toEndOf="parent"/>
```

Then in your View class initialize and bind an adapter to ViewPager, after that you need to bind the ViewPager to PageController component using setViewPager interface:

```kotlin	
override fun onViewCreated(view: View, savedInstanceState: Bundle?) { 
	super.onViewCreated(view, savedInstanceState) 
	
	// Initialize a list of string values
	val amountList =  listOf("100,00€","200,00€","300,00€","400,00€","500,00€","600,00€","700,00€","800,00€") 
	
	// Initialize a new pager adapter instance with list 
	val adapter = PageControllerAdapter(amountList) 
	
	// Data bind the view pager widget with pager adapter 
	viewPager.adapter = adapter 
	
	// Bind viewPager with page indicator 
	textViewIndicator.setViewPager(viewPager) }
```

## Profile Photo

To add the profile component in a layout:

```xml	
<com.santander.globile.uicomponents.image.profile.GlobileProfilePhoto
        android:id="@+id/profile_photo_1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toStartOf="parent"
        app:layout_constraintEnd_toStartOf="@id/profile_initials_1"
        android:layout_marginTop="15dp"/>
 
<com.santander.globile.uicomponents.image.profile.GlobileProfilePhoto
        android:id="@+id/profile_initials_1"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        app:layout_constraintTop_toTopOf="parent"
        app:layout_constraintStart_toEndOf="@id/profile_photo_1"
        app:layout_constraintEnd_toEndOf="parent"
        android:layout_marginTop="15dp"/>
```

Also to set up the icon and the badge, here are some examples:

It will display "CG" as initials

```kotlin
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
 
    profile_photo_1.setProfilePhoto(R.drawable.st)
    profile_initials_1.setInitials("CG")
}
```

It will display "CG" as initials with a number 5 badge

```kotlin	
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
 
    profile_photo_1.setProfilePhoto(R.drawable.st, 5)
    profile_initials_1.setInitials("CG", 5)
}
```

It will display "PM" as initials with a number 5 badge

```kotlin	
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
 
    profile_photo_1.setProfilePhoto(R.drawable.st, 5)
    profile_initials_1.setInitialsWithName("Pepito Manzano", 5)
}
```


## Slider

To add a slider in the layout
Interval:  Must be divisible with max_number and must have rest zero.	
```xml
<com.santander.globile.uicomponents.slider.GlobileSeparatorSlider
        android:id="@+id/rangeSeekbar"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        app:default_color="red/turquose"
        app:slider_type="normal/range"
        app:min_number="Integer"
        app:max_number="Integer"
        app:interval="integer" 
        app:min_text="text"
        app:max_text="text"
        app:enable_separator="true/false"
        android:layout_marginTop="10dp"
        android:layout_marginBottom="10dp"
        />
```

To manage the slider from native code:
	
```kotlin
class SliderFragment: Fragment() {
 
    companion object {
        fun newInstance(): SliderFragment {
            return SliderFragment()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_slider, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
 
        rangeSeekbar.globileSliderListener = object : GlobileSliderListener {
           override fun onSelectionListener(thumbIndex: Int, value: Int) {
               Toast.makeText(context, "$value $thumbIndex",Toast.LENGTH_SHORT) .show()
               val values = rangeSeekbar.getSliderValues()
           }
       }
 
        rangeSeekbar.getValue(3)
        rangeSeekbar.max_text = "1000€"
        rangeSeekbar.min_text = "1€"
        rangeSeekbar.enableSeparator = false
 
    } 
}
```

## Stepper

First, insert the component view in xml layout with the number of steps:

```xml
<com.santander.globile.uicomponents.stepper.GlobileStepper
        android:id="@+id/stepper_4lines"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        app:numberOfSteps="4"
        android:layout_marginStart="16dp"
        android:layout_marginEnd="16dp"
        android:layout_marginTop="4dp"
        app:layout_constraintTop_toTopOf="parent"/>
```

Then, when is necessary to update the GlobileStepper progress, call setCurrentStep method of the component:

```kotlin	
....
override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
    super.onViewCreated(view, savedInstanceState)
 
    // Set the current step, from 0 to the number of steps minus 1, when user pass to next step
    continue_button.setOnClickListener {
        stepper_4lines.setCurrentStep(2)
    }
     
}
....
```


## TabBar

Create a custom element called GlobileTabBar that extends from BottomNavigationView:

```xml	
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
                                             android:layout_width="match_parent"
                                             android:layout_height="match_parent"
                                             xmlns:app="http://schemas.android.com/apk/res-auto">
 
    <com.santander.globile.uicomponents.tabbar.GlobileTabBar
            android:id="@+id/navigationView"
            android:layout_width="0dp"
            android:layout_height="wrap_content"
            app:menu="@menu/tabs"
            app:layout_constraintBottom_toBottomOf="parent"
            app:layout_constraintLeft_toLeftOf="parent"
            app:layout_constraintRight_toRightOf="parent"
    />
 
</android.support.constraint.ConstraintLayout>
```

Create a resources menu file xml inside menu folder to create tabs in GlobileTabBar:

```xml	
<?xml version="1.0" encoding="utf-8"?>
<menu xmlns:android="http://schemas.android.com/apk/res/android">
 
    <item
            android:id="@+id/navigation_songs"
            android:icon="@drawable/icon_1"
            android:title="Songs"/>
 
    <item
            android:id="@+id/navigation_albums"
            android:icon="@drawable/icon_2"
            android:title="Albums"/>
 
    <item
            android:id="@+id/hello"
            android:icon="@drawable/icon_3"
            android:title="Artists"/>
 
    <item
            android:id="@+id/asdas"
            android:icon="@drawable/icon_4"
            android:title="Artists"/>
 
</menu>
```

Call setNotificationBadge if you need to set badge in custom tab:

```kotlin	
package com.santander.globile.app.views.uicomponentslib.tabbar
 
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.fragment_tabbar.*
 
 
class TabBarFragment: Fragment() {
 
    companion object {
        fun newInstance(): TabBarFragment {
            return TabBarFragment()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_tabbar, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navigationView.setNotificationBadge(0,1)
        navigationView.setNotificationBadge(1,3)
        navigationView.setNotificationBadge(2,47)
        navigationView.setNotificationBadge(3,999)
    }
}
```

## Tabs

To add the tabs into the layoyt

```xml	
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout xmlns:android="http://schemas.android.com/apk/res/android"
                                             android:layout_width="match_parent"
                                             android:layout_height="match_parent"
                                             xmlns:app="http://schemas.android.com/apk/res-auto">
 
    <com.santander.globile.uicomponents.tablayout.GlobileTabLayout
            style="@style/GlobileTabLayoutAppearance"
            android:id="@+id/tabLayout"
            android:layout_marginTop="8dp"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintEnd_toEndOf="parent" app:layout_constraintTop_toTopOf="parent"/>
 
    <android.support.v4.view.ViewPager
            android:id="@+id/viewpager"
            android:layout_width="0dp"
            android:layout_height="0dp"
            android:layout_marginTop="8dp"
            app:layout_constraintTop_toBottomOf="@+id/tabLayout"
            app:layout_constraintEnd_toEndOf="parent"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintBottom_toBottomOf="parent"/>
 
</android.support.constraint.ConstraintLayout>
```

To access the tabs from native code
	
```kotlin
package com.santander.globile.app.views.uicomponentslib.tabs
 
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import com.santander.globile.app.views.uicomponentslib.pagecontroller.PageControllerFragment
import com.santander.globile.app.views.uicomponentslib.tabbar.TabBarFragment
import com.santander.globile.app.views.uicomponentslib.textinputlayout.GlobalInputTextLayoutFragment
import com.santander.globile.uicomponents.tablayout.GlobileBaseFragmentTabsAdapter
import com.santander.globile.uicomponents.tablayout.data.GlobileTab
import com.santander.globile.uicomponents.tablayout.data.GlobileTabsAdapterData
import kotlinx.android.synthetic.main.fragment_tabs.*
 
class TabsLayoutFragment : Fragment() {
    companion object {
        fun newInstance(): TabsLayoutFragment {
            return TabsLayoutFragment()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_tabs, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
 
        val tab1 = GlobileTab(R.string.tabs_tab1, R.drawable.ic_nav, Fragment1.newInstance())
        val tab2 = GlobileTab(R.string.tabs_tab2, null, Fragment2.newInstance())
        val tab3 = GlobileTab(R.string.tabs_tab3, null, Fragment3.newInstance())
 
        val tabList = ArrayList<GlobileTab>()
        tabList.add(tab1)
        tabList.add(tab2)
        tabList.add(tab3)
 
        val tabAdapterData = GlobileTabsAdapterData(tabList)
 
        val adapterTabs =
            activity?.supportFragmentManager?.let {
                GlobileBaseFragmentTabsAdapter(it, context!!, tabAdapterData)
            }
 
        viewpager.adapter = adapterTabs
        tabLayout.setupWithViewPager(viewpager)
 
    }
}
```

## Tertiary Button

This example corresponds to the xml layout:

```xml
<?xml version="1.0" encoding="utf-8"?>
<android.support.constraint.ConstraintLayout
        xmlns:android="http://schemas.android.com/apk/res/android"
        xmlns:app="http://schemas.android.com/apk/res-auto"
        android:layout_width="match_parent"
        android:layout_height="match_parent">
 
        <com.santander.globile.uicomponents.buttons.tertiarybutton.TertiaryButton
            android:id="@+id/tertiary_one"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            app:tertiaryButtonText="icon + text"
            app:tertiaryImageResource="@drawable/ic_add_shopping_cart"
            android:layout_margin="4dp"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/initial_buttons_layout"
    />
 
    <com.santander.globile.uicomponents.buttons.tertiarybutton.TertiaryButton
            android:id="@+id/tertiary_two"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            app:tertiaryButtonText="text + arrow + turquoise"
            app:tertiaryShowArrow="true"
            app:tertiaryPrimaryColor="false"
            android:layout_margin="4dp"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/tertiary_one"
    />
 
    <com.santander.globile.uicomponents.buttons.tertiarybutton.TertiaryButton
            android:id="@+id/tertiary_three"
            android:layout_width="wrap_content"
            android:layout_height="wrap_content"
            app:tertiaryButtonText="text with link"
            app:tertiaryButtonSecondText="in a sentence"
            app:tertiaryShowArrow="false"
            app:tertiaryPrimaryColor="true"
            app:tertiaryIsLink="true"
            android:layout_margin="4dp"
            app:layout_constraintStart_toStartOf="parent"
            app:layout_constraintTop_toBottomOf="@id/tertiary_two"
    />
 
</android.support.constraint.ConstraintLayout>
```


You can add a click listener in the class that contains the button to perform an action:

```kotlin	
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.santander.globile.app.R
import kotlinx.android.synthetic.main.buttons_layout.*
 
class ButtonsFragment: Fragment() {
 
    companion object {
        fun newInstance(): ButtonsFragment {
            return ButtonsFragment()
        }
    }
 
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater?.inflate(R.layout.fragment_buttons, container, false)
    }
 
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
         
        tertiary_one.setOnClickListener {
            //Action for first tertiary button
        }
    }
}
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "uicomponentslib" from the Project sidemenu
4. Select Build -> Make Module 'uicomponentslib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/uicomponents/build/outputs/aar/

# Test
1. Open Components-Android project in Android Studio
2. Open "uicomponentslib" from the Project sidemenu
3. Open each of the components to access every test
4. Click ► icon next to the test class