# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.1] - 2019-04-26
### Changed
- Option Selection Dropdown improvement

## [1.1.0] - 2019-03-29
### Added
- AlertBar
- Cards
- Icon
- Lists
- Profile Photo
- Slider
- Stepper
- TabBar
- Tabs

### Changed
- ErrorHandling as part of UIComponents library

## [1.0.0] - 2019-02-28
### Added
- Ending Button
- Foundations
- Initial Button
- Input
- Navigation Bar
- Option Selection Button
- Option Selection Checkbox
- Option Selection Dropdown
- Option Selection Radio Button
- Page Controller
- Tertiary Button
