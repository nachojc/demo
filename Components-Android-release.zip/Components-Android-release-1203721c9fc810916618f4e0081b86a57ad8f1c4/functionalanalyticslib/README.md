# Introduction 
This component translates Firebase Analytics' interface into a compatible interface.

# Prerequisites

## Firebase Analytics
Google collects analytics through their Firebase platform, so it is necessary to have a Firebase account from which the "google-services.json" should be downloaded and included in the project.

## Google Tag Manager
Collecting analytics events can be done ony with Firebase, but using Google Tag Manager allows more advanced features and real-time configuration. For this, a Google Tag Manager account is required.

# Install

## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':functionalanalyticslib')
```
3. Sync project with Gradle files

# Use

## From Native app

### Initialize component
Initialize the component with `init (context: Context)`:
```kotlin
FunctionalAnalytics.init(this)
```

### Log an event
Send a new analytics event with `logEvent (eventType: String, map: HashMap<String,Any?>)`:
```kotlin
val eventMap = HashMap<String,Any?>()
eventMap.put("screen_name", "login")
logEvent("screen_view", eventMap)
```

### Add user properties
Add information about the current user session to follow their specific journey through the app with `setUserProperty (key: String, value: Any?)`:
```kotlin
setUserProperty("USER_ID", "EFB3F32F784")
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib). Call the function with the following values:

componentName: "functionalanalyticslib"

componentParams:
```javascript
{
    "operation": "String", // "log_event", "set_user_property"
    "eventType": "String", // Used when operation is "log_event" to identufy the event type
    "params": {}           // List of key-value pairs to send as the event's custom parameters
}
```
The returned Promise will be resolved with the following JSON object:
```javascript
{
    "operation": "String", // "log_event", "set_user_property"
    "success": "String"    // "true", "false"
}
```

### Log an event
```javascript
callComponent('functionalanalyticslib', {
    operation: 'log_event',
    eventType: 'screen_view',
    params: {
        screen_name: 'login'
    }
})
```

### Add user properties
```javascript
callComponent('functionalanalyticslib', {
    operation: 'set_user_property',
    params: {
        USER_ID: 'EFB3F32F784'
    }
})
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "functionalanalyticslib" from the Project sidemenu
4. Select Build -> Make Module 'functionalanalyticslib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/functionalanalyticslib/build/outputs/aar/

# Test
Since this component is a wrapper on top of Firebase Analytics, it doesn't include Unit Tests.

# TODO
