package com.santander.globile.functionalanalyticslib.facade

import android.arch.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.internal.LinkedTreeMap
import com.santander.globile.functionalanalyticslib.FunctionalAnalytics
import com.santander.globile.functionalanalyticslib.common.fromJson
import com.santander.globile.functionalanalyticslib.common.toJson
import com.santander.globile.functionalanalyticslib.facade.data.FunctionalAnalyticsParams
import com.santander.globile.functionalanalyticslib.facade.data.FunctionalAnalyticsResult


/**
 * This class allows compatibility with WebViewBridge component and Archetype dispatcher in case the app contains
 * at least one web that needs to add functional analytics from phone.
 */
class ComponentFacade {

    var liveData: MutableLiveData<String> = MutableLiveData()
    private lateinit var gson: Gson

    /**
     *
     * @param args A ArrayList with data to Use in this component:
     *
     *   args[0] = params A JSON formatted [String] with three fields:
     *  - operation: "log_event" or "set_user_property" data.
     *  - eventType: the type associated to analytics event.
     *  - params: Map or dictionary params to send for each event or properties to set to user.
     *
     *   args[1] = context from application
     *   args[2] = activity from application
     *
     * return A JSON formated [String] with two fields in live data observed in webviewbridge:
     *  - success: boolean with true value in case of successful operation and false otherwise.
     *  - operation: the name of the operation that was executed (log_event, set_user_property or null if not recognized).
     */


    fun startComponent(args: ArrayList<Any>){

        var success = false
        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()

        val functionalAnalyticsParams = try {
            (args[0] as String).fromJson(FunctionalAnalyticsParams::class.java)
        } catch (e: Exception) {
            null
        }

        val operation = functionalAnalyticsParams?.operation?.toLowerCase().let {
            if (it != LOG_EVENT && it != SET_USER_PROPERTY)
                null
            else
                it
        }

        if(functionalAnalyticsParams != null) {

            val paramsMap: HashMap<String,Any?> = hashMapOf()
            (functionalAnalyticsParams.params as LinkedTreeMap<String, Any?>).forEach {
                paramsMap[it.key] = it.value
            }

            when (operation) {
                LOG_EVENT -> {
                    functionalAnalyticsParams.eventType?.let {
                        FunctionalAnalytics.logEvent(it, paramsMap)
                        success = true
                    }
                }
                SET_USER_PROPERTY -> {
                    paramsMap.forEach {
                        FunctionalAnalytics.setUserProperty(it.key, it.value)
                    }
                    success = true
                }
            }
        }

        liveData.postValue(FunctionalAnalyticsResult(success, operation).toJson())

    }
}

private const val LOG_EVENT = "log_event"
private const val SET_USER_PROPERTY = "set_user_property"