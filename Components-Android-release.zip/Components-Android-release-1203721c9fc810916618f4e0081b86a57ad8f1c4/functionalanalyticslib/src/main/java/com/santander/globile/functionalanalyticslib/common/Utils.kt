package com.santander.globile.functionalanalyticslib.common

import com.google.gson.Gson

fun <T> T?.toJson(): String = Gson().toJson(this)

fun <T> String.fromJson(parsedClass: Class<T>): T = Gson().fromJson(this, parsedClass)