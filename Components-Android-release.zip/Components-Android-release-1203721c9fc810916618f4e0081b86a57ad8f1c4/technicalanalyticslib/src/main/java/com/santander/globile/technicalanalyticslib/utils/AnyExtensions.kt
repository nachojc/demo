package com.santander.globile.technicalanalyticslib.utils

val Any.TAG: String
    get() = this::class.java.simpleName