package com.santander.globile.technicalanalyticslib.utils

const val SENDLOG = "sendlog"
const val PERSONALIZEDKEY = "personalizedkey"
const val USERID = "userId"
const val EXCEPTION = "exception"
