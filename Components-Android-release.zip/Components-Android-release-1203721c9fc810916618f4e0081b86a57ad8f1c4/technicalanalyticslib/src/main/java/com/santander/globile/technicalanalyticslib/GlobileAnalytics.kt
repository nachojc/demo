package com.santander.globile.technicalanalyticslib

import android.content.Context
import android.util.Log
import com.crashlytics.android.Crashlytics
import io.fabric.sdk.android.Fabric



class GlobileAnalytics {
    companion object {

        /**
         * Send normal log to crashlytics
         * @param msg : Message to use in Crashlytics
         */
        fun sendLog(msg: String){
            Crashlytics.log(msg)
        }

        /**
         * Send [Log] log to crashlytics
         * @param logId: Log id to send Crashlytics [Log.DEBUG],[Log.ASSERT],[Log.ERROR],[Log.VERBOSE],[Log.WARN]
         * @param tag : Tag to identify log in Crashlytics
         * @param msg : Message to use in Crashlytics
         */
        fun sendLog(logId: Int,tag: String, msg: String){
            Crashlytics.log(logId, tag, msg)
        }

        /**
         * Send no Critical Error to crashlytics
         * @param throwable : Exception to use in Crashlytics
         */
        fun sendLogException(throwable: Throwable){
            Crashlytics.logException(throwable)
        }

        /**
         * Set personalized [String] key
         * @param key : Key to identify personalized [String] in Crashlytics
         * @param value : Value for personalized [key] in Crashlytics
         */
        fun setPersonalizedStringKey(key: String, value: String) {
            Crashlytics.setString(key, value)
        }

        /**
         * Set personalized [Boolean] key
         * @param key : Key to identify personalized [Boolean] in Crashlytics
         * @param value : Value for personalized [key] in Crashlytics
         */
        fun setPersonalizedBoolKey(key: String, value: Boolean) {
            Crashlytics.setBool(key, value)
        }

        /**
         * Set personalized [Double] key
         * @param key : Key to identify personalized [Double] in Crashlytics
         * @param value : Value for personalized [key] in Crashlytics
         */
        fun setPersonalizedDoubleKey(key: String, value: Double) {
            Crashlytics.setDouble(key, value)
        }

        /**
         * Set personalized [Float] key
         * @param key : Key to identify personalized [Float] in Crashlytics
         * @param value : Value for personalized [key] in Crashlytics
         */
        fun setPersonalizedFloatKey(key: String, value: Float) {
            Crashlytics.setFloat(key, value)
        }

        /**
         * Set personalized [Int] key
         * @param key : Key to identify personalized [Int] in Crashlytics
         * @param value : Value for personalized [key] in Crashlytics
         */
        fun setPersonalizedIntKey(key: String, value: Int) {
            Crashlytics.setInt(key, value)

        }

        /**
         * Set user identifier for Crashlytics
         * @param userId : userId for Crashlytics
         */
        fun setUserIdentifier(userId: String){
            Crashlytics.setUserIdentifier(userId)
        }

        /**
         * Add in Manifest:  <meta-liveData android:name="firebase_crashlytics_collection_enabled" android:value="false" />
         * Enable integration forms: <meta-liveData android:name="firebase_crashlytics_collection_enabled" android:value="false" />
         *
         * Method to init manual crashlytics
         *
         * @param context: Application context to init Manual Analytics
         *
         */
        fun initManualAnalytics(context: Context){
            Fabric.with(context, Crashlytics())
        }


        /**
         * Add in Manifest: <meta-liveData android:name="firebase_crashlytics_collection_enabled" android:value="false" />
         *
         * Method to enable Debug Mode in Crashlytics
         * @param context : Application context to init Manual Analytics
         *
         */
        fun enableDebugModeAnalytics(context: Context){
            val fabric = Fabric.Builder(context)
                .kits(Crashlytics())
                .debuggable(true)
                .build()
            Fabric.with(fabric)
        }



    }
}