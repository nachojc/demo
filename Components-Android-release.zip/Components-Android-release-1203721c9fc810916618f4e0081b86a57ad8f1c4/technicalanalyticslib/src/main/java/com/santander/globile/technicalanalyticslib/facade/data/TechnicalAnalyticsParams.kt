package com.santander.globile.technicalanalyticslib.facade.data

/**
 * Entity that holds TechnicalAnalyticsParams Params.
 *
 * @param operation can contains: "sendLog", "personalizedKey", "exception" or "userId".
 * @param logId Type of Log:
 *      - Log.Verbose: 2
 *      - Log.Debug: 3
 *      - Log.Info: 4
 *      - Log.Warn: 5
 *      - Log.Error: 6
 *      - Log.Assert: 7
 * @param key: Key of Personalized key or Log Key
 *      - Value: Value of Personalized Key or Log Value
 *      - Value can be Any type of Primitive object in personalized key
 *      - Value only can be [String] in Log type
 * @param userId: Crashlytics UserId
 * @param exceptionMsg Exception Message as String to set in Exception(message:String)
 *
 */
data class TechnicalAnalyticsParams(
    val operation: String? = null,
    val logId: Int? = null,
    val key: String? = null,
    val value: Any? = null,
    val userId: String? = null,
    val exceptionMsg: String? = null
)
