# Introduction 
This component translates Firebase Crashlytics' interface into a compatible interface.

# Prerequisites

## Firebase
Crashlytics works through Google's Firebase platform, so it is necessary to have a Firebase account from which the "google-services.json" should be downloaded and included in the project.

# Install

## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':technicalanalyticslib')
```
3. Sync project with Gradle files

# Use

## From Native app

### Collect crash reports
Crashes are automatically recorded and their stack traces sent to Crashlytics as soon as the component is installed and configured (added pertinent "google-services.json").

### Add custom keys
Associate arbitrary key/value pairs with your crash reports to get the specific state of the app leading up to a crash with `setPersonalizedStringKey (key: String, value: String)`, `setPersonalizedBoolKey (key: String, value: Boolean)`, `setPersonalizedFloatKey (key: String, value: Float)`, `setPersonalizedDoubleKey(key: String, value: Double)`, and `setPersonalizedIntKey (key: String, value: Int)`, depending on the data type of the value stored:
```kotlin
GlobileAnalytics.setPersonalizedStringKey("section", "loans")
GlobileAnalytics.setPersonalizedBoolKey("logged_in", true)
GlobileAnalytics.setPersonalizedFloatKey("balance", 23572.64)
GlobileAnalytics.setPersonalizedDoubleKey("balance", 32626.23)
GlobileAnalytics.setPersonalizedIntKey("year", 2019)
```

### Add custom log messages
Add custom logs to give more context of the events leading up to a crash with `sendLog (msg: String)` (send log with next crash report) or `sendLog(logId: Int, tag: String, msg: String)` (send log with next crash report and write to Android Log):
```kotlin
GlobileAnalytics.sendLog("User has entered card management section")
GlobileAnalytics.sendLog(Log.ERROR, "view_card", "Error retrieving card information")
```

### Set user identifiers
Identify users in the crash reports by assigning each user a unique identifier in the form of an ID number, token, or hashed value with `setUserIdentifier (userId: String)`:
```kotlin
GlobileAnalytics.setUserIdentifier("user123456789")
```

### Log non-fatal exceptions
Log caught exceptions with `sendLogException (throwable: Throwable)`:
```kotlin
try {
} catch (e: Exception) {
    GlobileAnalytics.sendLogException()
}
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/webviewbridgelib). Call the function with the following values:

componentName: "technicalanalyticslib"

componentParams:
```javascript
{
    "operation": "String",   // "personalizedKey", "sendLog", "userId", "exception"
    "logId": int,            // Log level from 2 (Verbose) to 7 (Assert) (optional, only used in "sendLog" operation)
    "key": "String",         // Log tag or custom key (optionally used in "sendLog" operation, necessary for "personalizedKey" operation)
    "value": "String",       // Log message or custom key value (used in "sendLog" and "personalizedKey" operations)
    "userId": "String",      // User identifier (only used in "userId" operation)
    "exceptionMsg": "String" // Controlled exception message (only used in "exception" operation)
}
```
The returned Promise will be resolved with the following JSON object:
```javascript
{
    "operation": "String", // "log_event", "set_user_property"
    "success": "String"    // "true", "false"
}
```

### Add custom keys
```javascript
callComponent('technicalanalyticslib', {
    operation: 'personalizedKey',
    key: 'section',
    value: 'loans'
})
```

### Add custom log message
```javascript
callComponent('technicalanalyticslib', {
    operation: 'sendLog',
    logId: 6,
    key: 'view_card',
    value: 'Error retrieving card information'
})
```

### Set user identifier
```javascript
callComponent('technicalanalyticslib', {
    operation: 'userId',
    userId: 'user123456789'
})
```

### Log non-fatal exceptions
```javascript
callComponent('technicalanalyticslib', {
    operation: 'exception',
    exceptionMsg: 'TypeError: undefined is not an object'
})
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "technicalanalyticslib" from the Project sidemenu
4. Select Build -> Make Module 'technicalanalyticslib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/technicalanalyticslib/build/outputs/aar/

# Test
Since this component is a wrapper on top of Firebase Crashlytics, it doesn't include Unit Tests.

# TODO
1. Add performance monitoring