package com.globile.santander.mobisec.securestorage;

import android.content.Context;

import com.globile.santander.mobisec.cryptocipher.SecureStorage;
import com.globile.santander.mobisec.scal.securestorage.database.SCALDatabaseSecureStorageModule;
import com.globile.santander.mobisec.scal.securestorage.listeners.SCALDatabaseSecureStorageCallback;
import com.globile.santander.mobisec.scal.securestorage.models.SCALDBResult;

import net.sqlcipher.Cursor;
import net.sqlcipher.database.SQLiteDatabase;

import java.util.HashMap;
import java.util.Map;

public class SCALDatabaseSecureStorageDefault implements SCALDatabaseSecureStorageModule {
	
	private SCALDatabaseHelper scalDatabaseHelper;
	private Context context;
	private String databaseName;
	
	public SCALDatabaseSecureStorageDefault(Context context) {
		this.context = context;
	}
	
	@Override
	public synchronized void initDatabase(String databaseName, int version, SCALDatabaseSecureStorageCallback scalDatabaseSecureStorageCallback) {
		this.databaseName = SecureStorage.hash(databaseName);
		SQLiteDatabase.loadLibs(context);
		scalDatabaseHelper = new SCALDatabaseHelper(context, this.databaseName, version, scalDatabaseSecureStorageCallback);
	}
	
	@Override
	public synchronized boolean removeDatabase() {
		return context.deleteDatabase(SecureStorage.hash(databaseName));
	}
	
	@Override
	public synchronized SCALDBResult executeQuery(String query, String[] args) {
		Cursor cursor = scalDatabaseHelper.getReadableDatabase(getPassword()).rawQuery(query, args);
		SCALDBResult scaldbResult = new SCALDBResult();
		while (cursor.moveToNext()) {
			Map<String, Object> resultMap = new HashMap<>();
			for (String columnName : cursor.getColumnNames()) {
				int index = cursor.getColumnIndex(columnName);
				int type = cursor.getType(index);
				resultMap.put(columnName, getDataWithType(cursor, type, index));
			}
			scaldbResult.add(resultMap);
		}
		if (!cursor.isClosed()) {
			cursor.close();
		}
		scalDatabaseHelper.close();
		return scaldbResult;
	}
	
	private Object getDataWithType(Cursor cursor, int type, int index) {
		switch (type) {
			case Cursor.FIELD_TYPE_BLOB:
				return cursor.getBlob(index);
			case Cursor.FIELD_TYPE_INTEGER:
				return cursor.getInt(index);
			case Cursor.FIELD_TYPE_FLOAT:
				return cursor.getFloat(index);
			case Cursor.FIELD_TYPE_STRING:
				return cursor.getString(index);
			case Cursor.FIELD_TYPE_NULL:
			default:
				break;
		}
		
		return null;
	}
	
	@Override
	public synchronized void executeSQL(String sqlStatement, String[] args) {
		if (args != null) {
			scalDatabaseHelper.getWritableDatabase(getPassword()).execSQL(sqlStatement, args);
		} else {
			scalDatabaseHelper.getWritableDatabase(getPassword()).execSQL(sqlStatement);
		}
		scalDatabaseHelper.close();
	}
	
	/**
	 * Create or get the database password
	 *
	 * @return the database password
	 */
	private String getPassword() {
		return new StringBuilder(SecureStorage.hash(databaseName)).reverse().toString();
	}
}
