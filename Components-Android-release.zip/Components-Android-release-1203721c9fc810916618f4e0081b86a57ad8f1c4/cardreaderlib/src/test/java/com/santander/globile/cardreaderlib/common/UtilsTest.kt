package com.santander.globile.cardreaderlib.common

import android.content.Intent
import com.google.common.truth.Truth
import io.card.payment.CardIOActivity
import io.card.payment.CreditCard
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

// To run this test the jvm arg "-noverify" must be set on run configuration.
@RunWith(RobolectricTestRunner::class)
class UtilsTest {

    @Test
    fun `getCardInfoFromIntentData every field is correct`() {
        // Arrange
        val expectedNumber = "00000000000000000000"
        val expectedCardHolderName = "someone"
        val expectedMonth = 12
        val expectedYear = 20
        val expectedCVV = "000"
        val intentData = Intent()
        intentData.putExtra(
            CardIOActivity.EXTRA_SCAN_RESULT,
            CreditCard(
                expectedNumber,
                expectedMonth,
                expectedYear,
                expectedCVV,
                null,
                expectedCardHolderName
            )
        )

        // Act
        val result = getCardInfoFromIntentData(intentData)

        // Assert
        with(result!!) {
            Truth.assertThat(cardNumber).isEqualTo(expectedNumber)
            Truth.assertThat(cardHolder).isEqualTo(expectedCardHolderName)
            Truth.assertThat(expiryMonth).isEqualTo(expectedMonth)
            Truth.assertThat(expiryYear).isEqualTo(expectedYear)
            Truth.assertThat(cvv).isEqualTo(expectedCVV)
        }
    }

    @Test
    fun getCardInfoFromNullIntentData() {

        // Act
        val result = getCardInfoFromIntentData(null)

        // Assert
        Truth.assertThat(result).isNull()
    }

    @Test
    fun `getCardInfoFromIntentData with incorrect month under 1`() {
        // Arrange
        val intentData = Intent()
        // Months start at 1
        intentData.putExtra(
            CardIOActivity.EXTRA_SCAN_RESULT,
            CreditCard(null, 0, 0, null, null, null)
        )

        // Act
        val result = getCardInfoFromIntentData(intentData)

        // Assert
        Truth.assertThat(result?.expiryMonth).isNull()
    }

    @Test
    fun `getCardInfoFromIntentData with incorrect month over 12`() {
        // Arrange
        val intentData = Intent()
        intentData.putExtra(
            CardIOActivity.EXTRA_SCAN_RESULT,
            CreditCard(
                null,
                13, // Months stop at 12
                0,
                null,
                null,
                null
            )
        )

        // Act
        val result = getCardInfoFromIntentData(intentData)

        // Assert
        Truth.assertThat(result?.expiryMonth).isNull()
    }
}