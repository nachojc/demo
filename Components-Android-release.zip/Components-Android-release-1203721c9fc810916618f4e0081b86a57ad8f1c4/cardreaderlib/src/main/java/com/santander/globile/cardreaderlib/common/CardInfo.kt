package com.santander.globile.cardreaderlib.common

/**
 * Entity that holds the credit card scanned info.
 *
 * @param cardNumber
 * @param cardHolder
 * @param expiryMonth
 * @param expiryYear
 * @param cvv
 */
data class CardInfo(
    var cardNumber: String? = null,
    var cardHolder: String? = null,
    var expiryMonth: Int? = null,
    var expiryYear: Int? = null,
    var cvv: String? = null
)