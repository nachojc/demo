package com.santander.globile.cardreaderlib.callback

import com.santander.globile.cardreaderlib.common.CardInfo

/**
 * This interface is used as a callback to receive the result from the credit card scanner.
 */
interface CardReaderCallback {

    /**
     * Card information successfully read.
     *
     * @param cardInfo
     */
    fun onCardScanCompleted(cardInfo: CardInfo)

    /**
     * Card scanner closed or card information unsuccessfully read.
     */
    fun onCardScanCancelled()
}