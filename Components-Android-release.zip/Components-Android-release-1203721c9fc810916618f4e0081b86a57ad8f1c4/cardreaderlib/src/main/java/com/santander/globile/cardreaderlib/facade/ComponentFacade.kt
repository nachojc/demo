package com.santander.globile.cardreaderlib.facade

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.google.gson.Gson
import com.santander.globile.cardreaderlib.common.CardInfo
import com.santander.globile.cardreaderlib.common.getCardInfoFromIntentData
import com.santander.globile.cardreaderlib.intent

/**
 * This class allows compatibility with WebViewBridge component and Archetype dispatcher in case the app contains
 * at least one web that needs to scan a credit card with this component.
 */
class ComponentFacade {

    /**
     * @param context Necessary to create the intent.
     * @param params Data as JSON with CardReader scanInstructions param: a [String] with the text that will be
     * displayed as a hint to the user.
     *
     * @return An [Intent] with the necessary extras to launch the scanner [Activity].
     */
    fun getIntent(context: Context, params: String?): Intent = intent(context, params)

    /**
     * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the scanned data
     * as a JSON [String] from a [CardInfo] object.
     *
     * @param requestCode
     * @param resultCode
     * @param data
     *
     * @return Scanned data from credit card as JSON from a [CardInfo] object.
     */
    fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?): String? =
        getCardInfoFromIntentData(data)?.let {
            Gson().toJson(it)
        }

}