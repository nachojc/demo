package com.santander.globile.cardreaderlib.common

import android.content.Intent
import io.card.payment.CardIOActivity
import io.card.payment.CreditCard

internal val Any.TAG: String
    get() = this::class.java.simpleName

internal fun getCardInfoFromIntentData(data: Intent?): CardInfo? =
    if (data?.hasExtra(CardIOActivity.EXTRA_SCAN_RESULT) == true) {
        (data.getParcelableExtra(CardIOActivity.EXTRA_SCAN_RESULT) as CreditCard?)?.run {
            CardInfo(
                cardNumber,
                cardholderName,
                expiryMonth.takeIf { it in 1..12 },
                expiryYear,
                cvv
            )
        }
    } else {
        null
    }