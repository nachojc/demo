# Introduction 
This component provides credit card scanning using the device's camera to read the data from the card surface.


# Install
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':cardreaderlib')
```
3. Sync project with Gradle files


# Use
## From Native App
### Scan card
Launch the card scanner with `scanCard (context: Context, requestCode: Int, scanInstructions: String? = null)`:

```kotlin
scanCard(it.applicationContext, CARD_READER_REQUEST_CODE, "Scan your card")
```

Then collect the read data with `handleOnActivityResult (requestCode: Int, resultCode: Int, data: Intent?): String?` in the onActivityResult function, using `onCardScanCompleted(cardInfo: CardInfo)` and `onCardScanCancelled()` to handle each case:

```kotlin
override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {

    handleOnActivityResult(data, object : CardReaderCallback {
 
        override fun onCardScanCompleted(cardInfo: CardInfo) {
            cardreader_result_textview.text = cardInfo.cardNumber.toString()
        }
 
        override fun onCardScanCancelled() {
            cardreader_result_textview.text = getString(R.string.cardreader_scan_incomplete)
        }
    })
}
```

## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-android/tree/master/webviewbridgelib). Call the function with the following values:

componentName: "cardreaderlib"

componentParams: "String" //Scan instructions message

The returned Promise will be resolved with the following JSON object:
```javascript
{
    "cardNumber": "String", // Card number
    "cardHolder": "String", // Name of card holder
    "expiryMonth": Int,     // Month of expiration date
    "expiryYear": Int,      // Year of expiration date
    "cvv": "String"         // Card security code
}
```
### Scan card
```javascript
callComponent('cardreaderlib').then((res) => {
    console.log(res.cardNumber)
})
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "cardreaderlib" from the Project sidemenu
4. Select Build -> Make Module 'cardreaderlib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/cardreaderlib/build/outputs/aar/


# Test
1. Open Components-Android project in Android Studio
2. Open "cardreaderlib" from the Project sidemenu
3. Open "java/com.santander.globile.cardreaderlib.common (test)"
4. Open file "UtilsTest"
5. Click ► icon next to "class UtilsTest"

# TODO
1. Add Card.io input parameters as parameters for scanCard