package com.globile.santander.mobisec.cryptocipher;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.crypto.SecretKey;

/**
 * Created by oandujar on 05/03/2019.
 */
public class KeyStorage {
	
	private KeyStorageAndroid keyStorageAndroidImpl;
	
	/**
	 * Constructor to instantiate KeyStorage
	 *
	 * @param context used to initialize file directory, with default name and password on KeyStorage.
	 */
	public KeyStorage(@NonNull Context context) {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
			keyStorageAndroidImpl = new KeyStorageV16(context);
		} else {
			keyStorageAndroidImpl = new KeyStorageV23();
		}
	}
	
	/**
	 * Constructor to instantiate KeyStorage
	 *
	 * @param context  used to initialize file directory
	 * @param name     used to identify current KeyStore
	 * @param password used to store data on KeyStore
	 */
	public KeyStorage(@NonNull Context context, @NonNull String name, char[] password) {
		if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
			keyStorageAndroidImpl = new KeyStorageV16(context, name, password);
		} else {
			keyStorageAndroidImpl = new KeyStorageV23();
		}
	}
	
	private KeyStore createKeyStore()
			throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
		return keyStorageAndroidImpl.createKeyStore();
	}
	
	/**
	 * Create and saves 256 AES SecretKey key using provided alias and password.
	 * <p/>
	 * Saves key to KeyStore. Uses keystore with default type located in application cache on device if API < 23.
	 * Uses AndroidKeyStore if API is >= 23.
	 *
	 * @return KeyPair or null if any error occurs
	 */
	public SecretKey generateSymmetricKey(@NonNull String alias, char[] password, Integer remainingTime, boolean authenticated) {
		return keyStorageAndroidImpl.generateSymmetricKey(alias, password, remainingTime, authenticated);
	}
	
	/**
	 * Create and saves SecretKey key specified in KeyProps.
	 * <p/>
	 * Saves key to KeyStore. Uses keystore with default type located in application cache on device if API < 23.
	 * Uses AndroidKeyStore if API is >= 23.
	 *
	 * @return KeyPair or null if any error occurs
	 */
	public SecretKey generateSymmetricKey(@NonNull KeyProps keyProps, boolean authenticated) {
		return keyStorageAndroidImpl.generateSymmetricKey(keyProps, authenticated);
	}
	
	/**
	 * Getting symmetric key from KeyStore
	 *
	 * @return SecretKey or null if any error occurs
	 */
	public SecretKey getSymmetricKey(@NonNull String alias, char[] password) {
		return keyStorageAndroidImpl.getSymmetricKey(alias, password);
	}
	
	/**
	 * Method to store a existing key in KeyStore.
	 *
	 * @param alias alias to store the key
	 * @param key   the key
	 */
	public void storeSymmetricKey(String alias, SecretKey key, char[] password) throws GeneralSecurityException {
		keyStorageAndroidImpl.storeSymmetricKey(alias, key, password);
	}
	
	/**
	 * Check if a key exist on KeyStore.
	 *
	 * @return true if key with given alias is in keystore
	 */
	public boolean hasKey(@NonNull String alias) {
		return keyStorageAndroidImpl.hasKey(alias);
	}
	
	/**
	 * Remove existing key in KeyStore
	 *
	 * @param alias to be removed
	 */
	public void removeKey(String alias) {
		keyStorageAndroidImpl.removeKey(alias);
	}
	
}
