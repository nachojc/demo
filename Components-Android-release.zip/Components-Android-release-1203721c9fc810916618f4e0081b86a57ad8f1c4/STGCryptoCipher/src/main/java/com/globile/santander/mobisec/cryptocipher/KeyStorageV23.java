package com.globile.santander.mobisec.cryptocipher;

import android.content.Context;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.security.keystore.KeyProtection;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.UnrecoverableEntryException;
import java.security.cert.CertificateException;

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import static java.security.KeyStore.getInstance;

/**
 * Created by oandujar on 05/03/2019.
 */
@RequiresApi(api = Build.VERSION_CODES.M)
class KeyStorageV23 extends KeyStorageAndroid {
	
	static final String TAG = KeyStorageV23.class.getName();
	
	private static final String PROVIDER_ANDROID_KEY_STORE = "AndroidKeyStore";
	private static final String ERROR_GENERATE_KEY = "Error generating Key";
	private static final String ERROR_GETTING_KEY = "Error getting Key";
	private static final String ERROR_SETTING_KEY = "Error setting Key";
	private static final String ERROR_RETRIEVING_KEY = "Error retrieving key";
	
	private KeyStore mAndroidKeyStore;
	
	
	/**
	 * Constructor to instantiate KeyStorage
	 */
	 KeyStorageV23() {
	}
	
	@Override
	protected KeyStore createKeyStore()
			throws KeyStoreException, CertificateException, NoSuchAlgorithmException, IOException {
		if (mAndroidKeyStore == null) {
			mAndroidKeyStore = getInstance(PROVIDER_ANDROID_KEY_STORE);
		}
		mAndroidKeyStore.load(null);
		return mAndroidKeyStore;
	}
	
	
	/**
	 * Create and saves SecretKey key specified in KeyProps.
	 * <p/>
	 * Saves key to KeyStore. Uses keystore with default type located in application cache on device if API < 23.
	 * Uses AndroidKeyStore if API is >= 23.
	 *
	 * @return KeyPair or null if any error occurs
	 */
	 SecretKey generateSymmetricKey(@NonNull KeyProps keyProps, boolean authenticated) {
		return generateAndroidSymmetricKey(keyProps, authenticated);
	}
	
	private SecretKey generateAndroidSymmetricKey(KeyProps keyProps, boolean authenticated) {
		try {
			String provider = PROVIDER_ANDROID_KEY_STORE;
			KeyGenerator keyGenerator = KeyGenerator.getInstance(keyProps.mKeyType, provider);
			KeyGenParameterSpec keySpec = keyPropsToKeyGenParameterSSpec(keyProps, authenticated);
			keyGenerator.init(keySpec);
			return keyGenerator.generateKey();
		} catch (NoSuchAlgorithmException | NoSuchProviderException | InvalidAlgorithmParameterException e) {
			Log.e(TAG, ERROR_GENERATE_KEY, e);
		}
		return null;
	}
	
	/**
	 * Getting symmetric key from KeyStore
	 *
	 * @return SecretKey or null if any error occurs
	 */
	 SecretKey getSymmetricKey(@NonNull String alias, char[] password) {
		return getSymmetricKeyFromAndroidKeyStore(alias, password);
	}
	
	private SecretKey getSymmetricKeyFromAndroidKeyStore(@NonNull String alias, @Nullable char[] password) {
		SecretKey result = null;
		try {
			KeyStore keyStore = createKeyStore();
			result = (SecretKey) keyStore.getKey(SecureStorage.hash(alias), password);
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException | UnrecoverableEntryException e) {
			Log.e(TAG, ERROR_GETTING_KEY, e);
		}
		return result;
	}
	
	/**
	 * Method to store a existing key in KeyStore.
	 *
	 * @param alias alias to store the key
	 * @param key   the key
	 */
	 void storeSymmetricKey(String alias, SecretKey key, char[] password) throws GeneralSecurityException {
		try {
			KeyStore keyStore = createKeyStore();
			keyStore.setEntry(SecureStorage.hash(alias), new KeyStore.SecretKeyEntry(key), new KeyProtection.Builder(KeyProperties.PURPOSE_ENCRYPT
					| KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build());
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException e) {
			Log.e(TAG, ERROR_SETTING_KEY, e);
			throw new GeneralSecurityException("store symmetric key failed", e);
		}
	}
	
	private KeyGenParameterSpec keyPropsToKeyGenParameterSSpec(KeyProps keyProps, boolean authenticated) {
		int purposes = KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT;
		
		//Dont hash the alias again here
		KeyGenParameterSpec.Builder builder = new KeyGenParameterSpec.Builder(keyProps.mAlias, purposes)
				.setKeySize(keyProps.mKeySize)
				.setBlockModes(keyProps.mBlockModes)
				.setEncryptionPaddings(keyProps.mEncryptionPaddings);
		
		if (authenticated) {
			builder.setUserAuthenticationValidityDurationSeconds(keyProps.mRemainingTime)
					.setUserAuthenticationRequired(Boolean.TRUE);
		}
		return builder.build();
	}
	
	/**
	 * Check if a key exist on KeyStore.
	 *
	 * @return true if key with given alias is in keystore
	 */
	 boolean hasKey(@NonNull String alias) {
		boolean result = false;
		try {
			KeyStore keyStore = createKeyStore();
			result = isKeyEntry(alias, keyStore);
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException e) {
			Log.e(TAG, ERROR_RETRIEVING_KEY, e);
		}
		
		return result;
	}
	
	/**
	 * Remove existing key in KeyStore
	 *
	 * @param alias to be removed
	 */
	void removeKey(String alias) {
		try {
			KeyStore keyStore = createKeyStore();
			keyStore.deleteEntry(SecureStorage.hash(alias));
		} catch (KeyStoreException | CertificateException | IOException | NoSuchAlgorithmException e) {
			Log.e(TAG, ERROR_RETRIEVING_KEY, e);
		}
	}
	
	private boolean isKeyEntry(@NonNull String alias, KeyStore keyStore) throws KeyStoreException {
		return keyStore != null && keyStore.isKeyEntry(SecureStorage.hash(alias));
	}
}
