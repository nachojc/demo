# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2019-02-28
### Added
- This CHANGELOG

### Changed
- Webview Bridge

### Removed
- Dependencies and unused code

## [0.3.0] - 2019-01-31
### Added
- Cache
- Error Handler
### Changed
- Service Invocation

## [0.2.0] - 2018-12-31
### Added
- Service Invocation
### Changed
- Webview Bridge

## [0.1.0] - 2018-12-10
### Added
- Webview Bridge
- Secure Storage
- Card Reader
