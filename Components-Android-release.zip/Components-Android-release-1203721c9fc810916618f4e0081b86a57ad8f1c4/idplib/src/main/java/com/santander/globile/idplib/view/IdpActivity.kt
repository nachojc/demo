package com.santander.globile.idplib.view

import android.content.Intent
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import com.santander.globile.idplib.R
import com.santander.globile.idplib.listener.IdpListener
import com.santander.globile.idplib.utils.IDP_REQUEST_CODE
import com.santander.globile.idplib.utils.IDP_RETURN_STRING
import com.santander.globile.idplib.webview.CustomIdpWebViewClient
import kotlinx.android.synthetic.main.layout_main_idp_activity.*


class IdpActivity: AppCompatActivity(), IdpListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.layout_main_idp_activity)

        val url = intent.getStringExtra("URL")

        loadWebView(url)
    }

    private fun loadWebView(url: String?) {

        idpWebView?.let {
            it.settings.javaScriptEnabled = true
            it.settings.domStorageEnabled = true
            it.settings.allowFileAccessFromFileURLs = true
            it.settings.allowUniversalAccessFromFileURLs = true
            it.webViewClient = CustomIdpWebViewClient(this)
            it.loadUrl(url)
        }
    }

    override fun onUrlDetected(token: String) {
        val resultToken = Intent()
        resultToken.putExtra(IDP_RETURN_STRING, token)
        setResult(IDP_REQUEST_CODE, resultToken)
        finish()
    }

    override fun onBackPressed() {
        if (idpWebView.canGoBack()) {
            idpWebView.goBack()
        } else {
            val defaultToken = Intent()
            defaultToken.putExtra(IDP_RETURN_STRING, "Cancelled")
            setResult(IDP_REQUEST_CODE, defaultToken)
            super.onBackPressed()
        }
    }
}