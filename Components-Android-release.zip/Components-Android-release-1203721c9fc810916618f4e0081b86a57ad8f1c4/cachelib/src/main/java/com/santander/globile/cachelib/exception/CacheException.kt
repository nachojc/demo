package com.santander.globile.cachelib.exception

import com.santander.globile.cachelib.utils.CODE_97
import com.santander.globile.cachelib.utils.CODE_98
import com.santander.globile.cachelib.utils.CODE_99
import com.santander.globile.cachelib.utils.DEFAULT

class CacheException(val code: Int) : Exception(codeToMsg(code))


/**
 * @param code [Int] a code to retrieve message to send in [CacheException]
 * @return [String] a message to send in [CacheException]
 */
private fun codeToMsg(code: Int): String =
    when (code) {
        99 ->
            CODE_99
        98 ->
            CODE_98
        97 ->
            CODE_97
        else -> {
            DEFAULT
        }
    }
