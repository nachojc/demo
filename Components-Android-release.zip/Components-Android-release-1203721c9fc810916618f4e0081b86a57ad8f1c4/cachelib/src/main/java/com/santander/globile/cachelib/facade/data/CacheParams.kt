package com.santander.globile.cachelib.facade.data

/**
 * Entity that holds Cache Params.
 *
 * @param operation can contains: "CACHE", "LOAD", "REMOVE" or "REMOVE_ALL".
 * @param jsonObject contains [Any] object to use Cache Library
 * @param key contains [String] key to store or load data from Cache Library
 * @param expiryTime contains [Long] expiryTime in seconds to expiry data in Cache Library.
 *
 */
data class CacheParams(
    val operation: String? = null,
    val jsonObject: Any? = null,
    val key: String? = null,
    val expiryTime: Long? = null
)

