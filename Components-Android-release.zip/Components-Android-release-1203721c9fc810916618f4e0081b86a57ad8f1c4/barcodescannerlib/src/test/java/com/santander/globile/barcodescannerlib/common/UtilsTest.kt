package com.santander.globile.barcodescannerlib.common

import android.content.Intent
import com.google.common.truth.Truth

import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner

// To run this test the jvm arg "-noverify" must be set on run configuration.
@RunWith(RobolectricTestRunner::class)
class UtilsTest {

    @Test
    fun `getCodeInfoFromIntentData every field is correct`() {
        // Arrange
        val expectedContents = "5706991013870"
        val expectedFormatName = "EAN_13"

        val intentData = Intent()
        intentData.putExtra("SCAN_RESULT", expectedContents)
        intentData.putExtra("SCAN_RESULT_FORMAT", expectedFormatName)

        // Act
        val result = getCodeInfoFromIntentData(1,-1, intentData)

        // Assert
        with(result!!) {
            Truth.assertThat(content).isEqualTo(expectedContents)
            Truth.assertThat(formatName).isEqualTo(expectedFormatName)
            Truth.assertThat(scanCancelled).isFalse()
        }
    }

    @Test
    fun `getCodeInfoFromIntentData with canceling scan returns null`() {
        // Arrange
        val intentData = Intent()

        // Act
        val result = getCodeInfoFromIntentData(1,-1, intentData)

        // Assert
        Truth.assertThat(result).isNull()
    }

}