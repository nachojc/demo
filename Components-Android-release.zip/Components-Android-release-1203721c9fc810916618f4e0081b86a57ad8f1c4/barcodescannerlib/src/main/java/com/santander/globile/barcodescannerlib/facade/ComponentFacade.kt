package com.santander.globile.barcodescannerlib.facade

import android.app.Activity
import android.content.Context
import android.content.Intent
import com.google.gson.Gson
import com.santander.globile.barcodescannerlib.common.BarcodeScannerInfo
import com.santander.globile.barcodescannerlib.common.getCodeInfoFromIntentData
import com.santander.globile.barcodescannerlib.intent

class ComponentFacade {
    /**
     * @param context Necessary to create the intent.
     * @param params Data as JSON with Barcode Scanner scan instructions param: a [String] with the text that will be
     * displayed as a hint to the user.
     *
     * @return An [Intent] with the necessary extras to launch the scanner [Activity].
     */
    fun getIntent(context: Context, params: String?): Intent = intent(context, params)

    /**
     * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the scanned data
     * as a JSON [String] from a [BarcodeScannerInfo] object.
     *
     * @param requestCode
     * @param resultCode
     * @param data
     *
     * @return Scanned data from barcode as JSON from a [BarcodeScannerInfo] object.
     */
    fun handleOnActivityResult(requestCode: Int, resultCode: Int, data: Intent?): String? =
        getCodeInfoFromIntentData(resultCode, data)?.let {
            Gson().toJson(it)
        } ?: Gson().toJson(BarcodeScannerInfo(null, null, true))

}