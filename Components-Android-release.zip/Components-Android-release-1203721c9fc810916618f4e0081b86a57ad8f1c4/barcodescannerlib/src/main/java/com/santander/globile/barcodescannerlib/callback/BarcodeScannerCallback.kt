package com.santander.globile.barcodescannerlib.callback

import com.santander.globile.barcodescannerlib.common.BarcodeScannerInfo

interface BarcodeScannerCallback {
    /**
     * Barcode Scanner information successfully read.
     *
     * @param scannerInfo
     */
    fun onCodeScanCompleted(scannerInfo: BarcodeScannerInfo)

    /**
     * Barcode Scanner closed or barcode information unsuccessfully read.
     */
    fun onCodeScanCancelled()
}