package com.santander.globile.serviceinvocationlib.callback

/**
 * This base custom callback receives two generic types:
 * one for OK responses and one for KO responses.
 *
 * It keeps the Http code if necessary
 * @param OKResponseType
 * @param KOResponseType
 */
abstract class IBaseCallback<OKResponseType, KOResponseType> {

    /**
     * ApiResponse HTTP status code.
     */
    var httpStatusCode: Int? = null

    /**
     * Service response success case.
     */
    abstract fun onResponseOK(response: OKResponseType?)

    /**
     * Service response handled error case.
     */
    abstract fun onResponseKO(errorResponse: KOResponseType?)

    /**
     * Service response unhandled error case.
     */
    abstract fun onResponseFail(t: Throwable?)

}