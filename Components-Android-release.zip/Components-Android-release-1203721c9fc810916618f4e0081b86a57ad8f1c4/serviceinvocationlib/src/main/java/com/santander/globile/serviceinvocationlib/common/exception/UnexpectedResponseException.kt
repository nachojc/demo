package com.santander.globile.serviceinvocationlib.common.exception

/**
 * Exception thrown where the response from the server was not expected.
 */
class UnexpectedResponseException(msg: String) : MalformedResponseException(msg)

internal fun unexpectedExceptionMessage(code: Int?) = "Unexpected Http status code${if (code != null) ": $code" else null}."