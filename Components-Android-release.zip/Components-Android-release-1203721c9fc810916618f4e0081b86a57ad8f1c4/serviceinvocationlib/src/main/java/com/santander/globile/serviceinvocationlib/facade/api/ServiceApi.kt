package com.santander.globile.serviceinvocationlib.facade.api

import retrofit2.Call
import retrofit2.http.*

internal interface ServiceApi {

    @POST
    fun post(
        @Url endpoint: String,
        @HeaderMap headers: Map<String?, String?>,
        @QueryMap queries: Map<String?, String?>,
        @Body body: Any?
    ): Call<Any>

    @GET
    fun get(
        @Url endpoint: String,
        @HeaderMap headers: Map<String?, String?>,
        @QueryMap queries: Map<String?, String?>
    ): Call<Any>

    // TODO add the remaining HTTP methods
}