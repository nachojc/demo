package com.santander.globile.serviceinvocationlib.client

/**
 *  Certificate pins
 *  @param hostname Lower-case host name or wildcard pattern such as *.example.com
 *  @param pin Hash of a certificate's Subject Public Key Info, base64-encoded and prefixed with either sha256 or sha1
 */
internal data class CertificatePin(val hostname: String, val pin: String)