package com.santander.globile.serviceinvocationlib.common.exception

/**
 * Exception thrown when there were problems parsing the response from the server
 */
open class MalformedResponseException(msg: String) : Exception(msg)