package com.santander.globile.serviceinvocationlib.facade

import android.arch.lifecycle.MutableLiveData
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.santander.globile.serviceinvocationlib.client.ApiClient
import com.santander.globile.serviceinvocationlib.facade.api.ApiResponse
import com.santander.globile.serviceinvocationlib.facade.api.Request
import com.santander.globile.serviceinvocationlib.facade.api.ServiceApi
import com.santander.globile.serviceinvocationlib.facade.api.toMap

/**
 * This class allows compatibility with WebViewBridge component and Archetype dispatcher in case the app contains
 * at least one web that needs to call services with retrofit.
 */
class ComponentFacade {

    var liveData: MutableLiveData<String> = MutableLiveData()
    lateinit var gson: Gson

    /**
     *
     * @param args A ArrayList with data to Use in this component:
     *
     *   args[0] = params A JSON formatted [String] with five fields:
     *  - method: HTTP method. Required.
     *  - url: Endpoint. Required.
     *  - headers: Array of headers (name-value pairs). It may not be required.
     *  - queries: Array of queries (name-value pairs). It may not be required.
     *  - body: Request body. It may not be required.
     *
     *   args[1] = context from application
     *   args[2] = activity from application
     *
     *  @return A JSON formated [String] with three fields as livedata observed in webviewbridge:
     *  - httpStatusCode: http status code of the service response.
     *  - url: endpoint that was called.
     *  - body: service response as a [String] (JSON)
     */



    fun startComponent(args: ArrayList<Any>){
        gson = GsonBuilder().disableHtmlEscaping().setPrettyPrinting().create()
        val request = try {
            gson.fromJson(args[0] as String, Request::class.java)
        } catch (e: Exception) {
            null
        }

        var httpStatusCode: Int? = null
        var baseUrl :String? = createValidUrl(request?.baseurl)
        var connectTimeout: Long? = request?.connectTimeout
        var basePath :String? = createPathValid(request?.path)
        var url: String? = baseUrl + basePath
        var body: Any? = null



        request?.let {
            it.baseurl.let { baseUrl ->
                createApiClient(baseUrl, connectTimeout)
            }
        }

        when (request?.method?.toLowerCase()) {
            "post" -> {
                basePath?.let {
                    ApiClient.createService(ServiceApi::class.java).post(
                        it,
                        request.headers.toMap(),
                        request.queries.toMap(),
                        request.body
                    )
                }
            }
            "get" -> {
                basePath?.let {
                    ApiClient.createService(ServiceApi::class.java).get(
                        it,
                        request.headers.toMap(),
                        request.queries.toMap()
                    )
                }
            }
            else -> {
                null
            }
        }?.run {
            url = request().url().toString()
            execute()?.run {
                httpStatusCode = code()
                body = body()

            }
        }
        liveData.postValue(gson.toJson(ApiResponse(httpStatusCode, url, body)))

    }

    private fun createApiClient(url: String, connectTimeout: Long?) {
        createValidUrl(url)?.let {
            ApiClient.Builder(it)
                .datePattern("yyyy-MM-dd'T'HH:mm:ss")
                .connectTimeout(connectTimeout)
                .build()
        }?.let {
            ApiClient.init(
                it
            )
        }
    }

    private fun createValidUrl(url: String?): String? {
       return if(url!=null){
           if(!url.endsWith("/")) {
               "$url/"
           }else{
               url
           }
        }else{
            null
        }
    }

    private fun createPathValid(path: String?): String? {
        return if(path!=null){
            if(path.startsWith("/")) {
                path.substring(1)
            }else{
                path
            }
        }else{
            null
        }
    }

}





