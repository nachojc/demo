package com.santander.globile.serviceinvocationlib.common

fun createUrl(baseUrl: String?, relativeEndpoint: String?): String {

    val baseUrlHasSlash = baseUrl?.last() == '/'
    val relativeEndpointHasSlash = relativeEndpoint?.first() == '/'

    val newRelativeEndpoint =
        if (baseUrlHasSlash && relativeEndpointHasSlash)
            relativeEndpoint?.substring(1)
        else if (!baseUrlHasSlash && !relativeEndpointHasSlash)
            "/$relativeEndpoint"
        else
            relativeEndpoint

    return "$baseUrl$newRelativeEndpoint"
}