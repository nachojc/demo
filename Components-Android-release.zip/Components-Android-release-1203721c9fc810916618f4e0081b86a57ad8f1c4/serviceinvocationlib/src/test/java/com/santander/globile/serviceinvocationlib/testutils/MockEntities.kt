package com.santander.globile.serviceinvocationlib.testutils

data class MockEntity(val value: String? = null, val number: Int? = null)

data class MockErrorEntity(val value: String? = null)