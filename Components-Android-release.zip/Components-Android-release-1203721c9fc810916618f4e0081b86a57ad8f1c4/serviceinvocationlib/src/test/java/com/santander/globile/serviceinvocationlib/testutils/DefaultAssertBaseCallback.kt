package com.santander.globile.serviceinvocationlib.testutils

import com.google.common.truth.Truth
import com.santander.globile.serviceinvocationlib.callback.IBaseCallback

//By default every case will fail, the test case must override the expected callback method which will be called
open class MockCall<OKResponseType, KOResponseType> : IBaseCallback<OKResponseType, KOResponseType>() {
    override fun onResponseOK(response: OKResponseType?) {
        Truth.assertThat(true).isEqualTo(false)
    }

    override fun onResponseKO(errorResponse: KOResponseType?) {
        Truth.assertThat(true).isEqualTo(false)
    }

    override fun onResponseFail(t: Throwable?) {
        t?.printStackTrace()
        Truth.assertThat(true).isEqualTo(false)
    }
}