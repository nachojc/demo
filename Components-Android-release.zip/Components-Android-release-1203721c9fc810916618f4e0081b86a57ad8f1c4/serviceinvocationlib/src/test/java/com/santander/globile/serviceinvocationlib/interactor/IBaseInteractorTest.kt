package com.santander.globile.serviceinvocationlib.interactor


import com.google.common.truth.Truth
import com.google.gson.Gson
import com.santander.globile.serviceinvocationlib.common.exception.MalformedResponseException
import com.santander.globile.serviceinvocationlib.common.exception.UnexpectedResponseException
import com.santander.globile.serviceinvocationlib.common.exception.unexpectedExceptionMessage
import com.santander.globile.serviceinvocationlib.testutils.*
import okhttp3.ResponseBody
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4
import retrofit2.Call
import retrofit2.Response
import java.net.HttpURLConnection


@RunWith(JUnit4::class)
class IBaseInteractorTest {

    private val mockedDefaultInteractor = object : IBaseInteractor() {}

    @Before
    fun setUp() {

    }

    @After
    fun tearDown() {

    }

    @Test
    fun testOnResponseOK() {

        //Arrange
        val expectedResponse = "hola"
        val call: Call<MockEntity> =
            OnResponseMockCall<MockEntity>(
                Response.success(MockEntity(expectedResponse))
            )

        //Act
        mockedDefaultInteractor.doRequest(call, object : MockCall<MockEntity, Any>() {
            override fun onResponseOK(response: MockEntity?) {

                //Assert
                Truth.assertThat(httpStatusCode).isEqualTo(HttpURLConnection.HTTP_OK)
                Truth.assertThat(response?.value).isEqualTo(expectedResponse)
            }
        }, Any::class.java)
    }

    @Test
    fun testOnResponseKO() {

        //Arrange
        val expectedErrorResponseMessage = "ko"
        val call: Call<Any> =
            OnResponseMockCall(
                Response.error(
                    HttpURLConnection.HTTP_BAD_REQUEST,
                    ResponseBody.create(
                        null,
                        Gson().toJson(
                            MockErrorEntity(
                                expectedErrorResponseMessage
                            )
                        )
                    )
                )
            )

        //Act
        mockedDefaultInteractor.doRequest(call, object : MockCall<Any, MockErrorEntity>() {
            override fun onResponseKO(errorResponse: MockErrorEntity?) {

                //Assert
                Truth.assertThat(httpStatusCode).isEqualTo(HttpURLConnection.HTTP_BAD_REQUEST)
                Truth.assertThat(errorResponse?.value).isEqualTo(expectedErrorResponseMessage)
            }
        }, MockErrorEntity::class.java)
    }

    @Test
    fun testOnResponseFail() {

        //Arrange
        val expectedExceptionMessage = "Error"
        val call: Call<Any> =
            OnFailureMockCall(Exception(expectedExceptionMessage))

        //Act
        mockedDefaultInteractor.doRequest(call, object : MockCall<Any, Any>() {
            override fun onResponseFail(t: Throwable?) {

                //Assert
                Truth.assertThat(httpStatusCode).isNull()
                Truth.assertThat(t?.message).isEqualTo(expectedExceptionMessage)
            }
        }, Any::class.java)
    }

    @Test
    fun testOnResponseFailCode500() {

        //Arrange
        val expectedErrorResponseMessage = "ko"
        val call: Call<Any> =
            OnResponseMockCall(
                Response.error(
                    HttpURLConnection.HTTP_INTERNAL_ERROR,
                    ResponseBody.create(
                        null,
                        Gson().toJson(
                            MockErrorEntity(
                                expectedErrorResponseMessage
                            )
                        )
                    )
                )
            )

        //Act
        mockedDefaultInteractor.doRequest(call, object : MockCall<Any, Any>() {
            override fun onResponseFail(t: Throwable?) {

                //Assert
                Truth.assertThat(httpStatusCode).isEqualTo(HttpURLConnection.HTTP_INTERNAL_ERROR)
                Truth.assertThat(t).isInstanceOf(UnexpectedResponseException::class.java)
                Truth.assertThat(t?.message)
                    .isEqualTo(unexpectedExceptionMessage(HttpURLConnection.HTTP_INTERNAL_ERROR))
            }
        }, Any::class.java)
    }

    @Test
    fun testOnResponseFailMalformedResponse() {

        //Arrange
        val call: Call<Any> =
            OnResponseMockCall(
                Response.error(
                    HttpURLConnection.HTTP_BAD_REQUEST,
                    ResponseBody.create(null, "malformed message")
                )
            )

        //Act
        mockedDefaultInteractor.doRequest(call, object : MockCall<Any, MockErrorEntity>() {
            override fun onResponseFail(t: Throwable?) {

                //Assert
                Truth.assertThat(t).isInstanceOf(MalformedResponseException::class.java)
            }
        }, MockErrorEntity::class.java)
    }

}