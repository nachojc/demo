# Introduction 
This component provides the device's hardware, software and network connection type.

# Install

## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically add this component to your Android app.

## Manually (from Nexus repository)
1. Add Nexus repository URL to Gradle build file
```gradle
maven {
    url 'https://globile-nexus.alm.gsnetcloud.corp/'
}
```
2. Add dependency in Gradle build file:
```gradle
implementation project(':deviceinfolib')
```
3. Sync project with Gradle files

# Use

## From Native app

### Initialize component
Initialize the component with `init(context: Context)`:
```kotlin
DeviceInfoReader.init(this)
```

### Get device model
Gets the name of the device's model with `getDeviceModel()`:
```kotlin
DeviceInfoReader.getDeviceModel()
```

### Get device platform
Gets the device's operating system name with `getDevicePlatform()`:
```kotlin
DeviceInfoReader. getDevicePlatform()
```

### Get device UUID
Gets the device's Universally Unique Identifier with `getDeviceUUID()`:
```kotlin
DeviceInfoReader. getDeviceUUID()
```

### Get device OS version
Gets the operating system version with `getDeviceOSVersion()`:
```kotlin
DeviceInfoReader. getDeviceOSVersion()
```

### Get device manufacturer
Gets the device's manufacturer with `getDeviceManufacturer()`:
```kotlin
DeviceInfoReader. getDeviceManufacturer()
```

### Get if is virtual device
Get if the device is running on a simulator with `getDeviceIsVirtual()`:
```kotlin
DeviceInfoReader. getDeviceIsVirtual()
```

### Get device serial number from Activity
Gets the device hardware serial number with`getDeviceSerial (activity: FragmentActivity?, listener (String) -> Unit)`:
```kotlin
DeviceInfoReader.getDeviceSerial(this){
     Log.d(TAG, "Serial number = " + it)
}
```
This data needs the READ_PHONE_STATE permission by the user. Automatically requested if this method is called.

### Get device serial number from Fragment
Gets the device hardware serial number with`getDeviceSerial (fragment: Fragment?, listener (String) -> Unit)`:
```kotlin
DeviceInfoReader.getDeviceSerial(this){
     Log.d(TAG, "Serial number = " + it)
}
```
This data needs the READ_PHONE_STATE permission by the user. Automatically requested if this method is called.

### Get device battery level
Gets the battery charge percentage with `getDeviceBatteryLevel(context: Context)`:
```kotlin
DeviceInfoReader.getDeviceBatteryLevel(context)
```

### Get device battery state
A boolean that indicates whether the device is charging with `getDeviceBatteryState(context: Context)`:
```kotlin
DeviceInfoReader.getDeviceBatteryState(context)
```

### Get device network type
Gets the name of the device's model with `getDeviceNetworkType(context: Context)`:
```kotlin
DeviceInfoReader.getDeviceNetworkType(context)
```


## From Web app
Access this component from web through the `callComponent(componentName, componentParams)` JavaScript function included in the [Webview Bridge component](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Components-Android/tree/master/deviceinfolib). Call the function with the following values:

componentName: "deviceinfolib"

componentParams:
Need a list of required params. The params names cloud be "model", "platform",  "uuid", "version", "manufacturer", "isVirtual", "serial", "batteryLevel", "batteryState", "networkType"(networkType returns a String with one of this connection type: "WIFI", "CELL_2G", "CELL_3G", "CELL_4G", "NONE" or "UNKNOWN")
```javascript
{
    "operation": "getDeviceInfo", // Operations "getDeviceInfo" to request a list of certain information
    "deviceInfoRequired": [       // List of information values required
        "manufacturer",
        "batteryLevel",
        "networkType"
    ]
}
```

The returned Promise will be resolved with the following JSON object:
```javascript
{
    "operation":"getDeviceInfo",    // Operation used
    "deviceInfo" : {                // Only returns information requested
        "manufacturer": "Google",
        "batteryLevel": 91,
        "networkType": "WIFI"  
    }
}
```

### Retrieve device information
```javascript
callComponent('deviceinfolib', {
    "operation":"getDeviceInfo",    
    "deviceInfo" : {               
        "manufacturer": "Google",
        "batteryLevel": 91,
        "networkType": "WIFI"  
}).then((res) => {
    console.log(res.deviceInfo)
})
```

# Build
1. Clone the Components-Android repository
2. Open it in Android Studio
3. Select "deviceinfolib" from the Project sidemenu
4. Select Build -> Make Module 'deviceinfolib' from the top menu
5. When the compilation process finishes, you can retrieve the compiled library from Components-Android/deviceinfolib/build/outputs/aar/

# Test
1. Open Components-Android project in Android Studio
2. Open "deviceinfolib" from the Project sidemenu
3. Open "java/com.santander.globile. deviceinfolib.common (test)"
4. Open file "UtilsTest"
5. Click ► icon next to "class UtilsTest"


