package com.santander.globile.deviceinfolib.common

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.support.v4.app.Fragment
import com.santander.globile.deviceinfolib.activity.DeviceInfoActivity
import com.santander.globile.deviceinfolib.callback.DeviceInfoReaderCallback

const val DEVICE_REQUIRED_DATA = "DeviceRequiredData"

/**
 * Launches the device info from a [Fragment].
 *
 * @param context Necessary to create the [Intent]
 * @param requestCode Request code for [Activity.startActivityForResult] method.
 * @param dataRequired data to retrieve from device.
 */
fun Fragment.getDeviceInfo(context: Context, requestCode: Int, dataRequired: String? = null) {
    startActivityForResult(intent(context, dataRequired), requestCode)
}

/**
 * Launches the device info from an [Activity].
 *
 * @param requestCode Request code for [Activity.startActivityForResult] method.
 * @param dataRequired data to retrieve from device.
 */
fun Activity.getDeviceInfo(requestCode: Int, dataRequired: String? = null) {
    startActivityForResult(intent(this, dataRequired), requestCode)
}

/**
 * @param context Necessary to create the [Intent].
 * @param dataRequired data to retrieve from device.
 *
 * @return An [Intent] with the necessary extras to launch device info [Activity].
 */
fun intent(context: Context, dataRequired: String?): Intent =
    Intent(context, DeviceInfoActivity::class.java).apply {
        putExtra(DEVICE_REQUIRED_DATA, dataRequired)
    }

/**
 * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the device data
 * as [DeviceInfo]. Call when [Activity.onActivityResult] is called.
 *
 * @param data Intent data from onActivityResult method.
 * @param deviceInfoCallback The result is returned using an interface of [DeviceInfoReaderCallback] type.
 */
fun handleOnActivityResult(data: Intent?, deviceInfoCallback: DeviceInfoReaderCallback) {

    getDeviceInfoFromIntentData(data)?.let { deviceInfoCallback.onGetInfoCompleted(it) }
        ?: deviceInfoCallback.onGetInfoError()
}

/**
 * This method receives the same parameters as [Activity.onActivityResult] and uses them to return the device data
 * as [DeviceInfo]. Call when [Activity.onActivityResult] is called.
 *
 * @param data Intent data from onActivityResult method.
 * @return [DeviceInfo] instance with device data.
 */
fun handleOnActivityResult(data: Intent?): DeviceInfo? = getDeviceInfoFromIntentData(data)