package com.santander.globile.deviceinfolib

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings.Secure
import android.support.v4.app.Fragment
import android.support.v4.app.FragmentActivity
import android.support.v4.content.ContextCompat
import android.telephony.TelephonyManager
import android.util.Log
import com.tbruyelle.rxpermissions2.RxPermissions


/**
 * Class to get each device data required
 *
 * @param context Necessary context to instantiate singleton [DeviceInfoReader] instance
 */

class DeviceInfoReader (context: Context){

    private var mContentResolver: ContentResolver? = null

    init {
        mContentResolver = context.contentResolver
    }

    fun getDeviceModel(): String = Build.MODEL

    fun getDevicePlatform(): String = "Android"

    fun getDeviceUUID(): String {
        return Secure.getString(mContentResolver, Secure.ANDROID_ID)
    }

    fun getDeviceOSVersion(): String = Build.VERSION.RELEASE

    fun getDeviceManufacturer(): String = Build.MANUFACTURER

    fun getDeviceIsVirtual(): Boolean{
        return Build.FINGERPRINT.startsWith("generic")
                || Build.FINGERPRINT.startsWith("unknown")
                || Build.MODEL.contains("google_sdk")
                || Build.MODEL.contains("Emulator")
                || Build.MODEL.contains("Android SDK built for x86")
                || Build.MANUFACTURER.contains("Genymotion")
                || (Build.BRAND.startsWith("generic") && Build.DEVICE.startsWith("generic"))
                || "google_sdk" == Build.PRODUCT
    }

    fun getDeviceSerial(activity: FragmentActivity?, listener: (String) -> Unit){
        activity?.let {
            val permissionCheck = ContextCompat.checkSelfPermission(
                it,
                Manifest.permission.READ_PHONE_STATE
            )
            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                getSerialWithPermission(listener)
            } else {
                val rxPermissions = RxPermissions(it)
                getPermission(rxPermissions, listener)
            }
        }
    }

    fun getDeviceSerial(fragment: Fragment?, listener: (String) -> Unit){

        fragment?.context?.let {
            val permissionCheck = ContextCompat.checkSelfPermission(
                it,
                Manifest.permission.READ_PHONE_STATE
            )
            if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
                getSerialWithPermission(listener)
            } else {
                val rxPermissions = RxPermissions(fragment)
                getPermission(rxPermissions, listener)
            }
        }
    }

    private fun getPermission(rxPermissions: RxPermissions, listener: (String) -> Unit) {
        // Must be done during an initialization phase like onCreate
        rxPermissions
            .request(Manifest.permission.READ_PHONE_STATE)
            .subscribe { granted ->
                if (granted) { // Always true pre-M
                    Log.d("Request Permission", "Permission has been granted by user")
                    getSerialWithPermission(listener)
                } else {
                    Log.d("Request Permission", "Permission has been denied by user")
                    listener("Permission not granted")
                }
            }
    }

    @SuppressLint("MissingPermission")
    private fun getSerialWithPermission(listener: (String) -> Unit) {
        listener(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Build.getSerial()
            } else {
                Build.SERIAL
            }
        )
    }

    fun getBatteryLevel(context: Context): Int {
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, ifilter)
        val level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val batteryPct = level / scale.toFloat()
        val p = batteryPct * 100

        return Math.round(p)
    }

    fun getBatteryState(context: Context): Boolean {
        val ifilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, ifilter)
        val status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)

        return status == BatteryManager.BATTERY_STATUS_CHARGING
    }

    fun getNetworkType(context: Context): String {
        return getNetworkClass(context)
    }

    private fun getNetworkClass(context: Context): String {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val info = cm.activeNetworkInfo
        if (info == null || !info.isConnected)
            return "NONE" //not connected
        if (info.type == ConnectivityManager.TYPE_WIFI)
            return "WIFI"
        if (info.type == ConnectivityManager.TYPE_MOBILE) {
            return when (info.subtype) {
                TelephonyManager.NETWORK_TYPE_GPRS, TelephonyManager.NETWORK_TYPE_EDGE, TelephonyManager.NETWORK_TYPE_CDMA, TelephonyManager.NETWORK_TYPE_1xRTT, TelephonyManager.NETWORK_TYPE_IDEN //api<8 : replace by 11
                -> "CELL_2G"
                TelephonyManager.NETWORK_TYPE_UMTS, TelephonyManager.NETWORK_TYPE_EVDO_0, TelephonyManager.NETWORK_TYPE_EVDO_A, TelephonyManager.NETWORK_TYPE_HSDPA, TelephonyManager.NETWORK_TYPE_HSUPA, TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_EVDO_B //api<9 : replace by 14
                    , TelephonyManager.NETWORK_TYPE_EHRPD  //api<11 : replace by 12
                    , TelephonyManager.NETWORK_TYPE_HSPAP  //api<13 : replace by 15
                    , TelephonyManager.NETWORK_TYPE_TD_SCDMA  //api<25 : replace by 17
                -> "CELL_3G"
                TelephonyManager.NETWORK_TYPE_LTE    //api<11 : replace by 13
                    , TelephonyManager.NETWORK_TYPE_IWLAN  //api<25 : replace by 18
                    , 19  //LTE_CA
                -> "CELL_4G"
                else -> "UNKNOWN"
            }
        }
        return "UNKNOWN"
    }

    companion object  {

        private var mDeviceInfoReader: DeviceInfoReader? = null

        /**
         * This initialization method must be called using application [Context]
         * to create a [DeviceInfoReader] singleton instance.
         * @param context Necessary context to instantiate singleton [DeviceInfoReader] instance
         */
        fun init(context: Context){
            mDeviceInfoReader = DeviceInfoReader(context)
        }

        /**
         * Get the name of the device's model
         *
         * @return Device Model [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceModel(): String {
            return mDeviceInfoReader?.getDeviceModel()
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Get the device's operating system name.
         *
         * @return Device platform [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDevicePlatform(): String {
            return mDeviceInfoReader?.getDevicePlatform()
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Get the device's Universally Unique Identifier
         *
         * @return Device UUID [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceUUID(): String {
            return mDeviceInfoReader?.getDeviceUUID()
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Get the operating system version.
         *
         * @return Device OS version [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceOSVersion(): String {
            return mDeviceInfoReader?.getDeviceOSVersion()
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Get the device's manufacturer.
         *
         * @return Device manufacturer [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceManufacturer(): String {
            return mDeviceInfoReader?.getDeviceManufacturer()
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Whether the device is running on a simulator.
         *
         * @return Device is virtual [Boolean].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceIsVirtual(): Boolean {
            return mDeviceInfoReader?.getDeviceIsVirtual()
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Get the device hardware serial number.
         *
         * @param activity Needs Activity for permission request.
         * @param listener Listener to get method response
         *
         * @return Device serial number [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceSerial(activity: FragmentActivity?, listener: (String) -> Unit) {
            mDeviceInfoReader?.getDeviceSerial(activity) {
                listener(it)
            } ?: error("DeviceInfoReader must be initialized first.")
        }


        /**
         * Get the device hardware serial number.
         *
         * @param fragment Needs [Fragment] for permission request.
         * @param listener Listener to get method response
         *
         * * @return Device serial number [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceSerial(fragment: Fragment?, listener: (String) -> Unit) {
            mDeviceInfoReader?.getDeviceSerial(fragment) {
                listener(it)
            } ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Get the battery charge percentage.
         *
         * @param context Needs [Context].
         *
         * @return Device battery level percentage [Int].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceBatteryLevel(context: Context): Int {
            return mDeviceInfoReader?.getBatteryLevel(context)
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * A boolean that indicates whether the device is charging.
         *
         * @param context Needs [Context].
         *
         * @return Device is charging [Boolean].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceBatteryState(context: Context): Boolean {
            return mDeviceInfoReader?.getBatteryState(context)
                ?: error("DeviceInfoReader must be initialized first.")
        }

        /**
         * Provides information about the device's cellular and wifi connection.
         *
         * @param context Needs [Context].
         *
         * @return Device network type [String].
         * @throws IllegalAccessException Throws an [IllegalAccessException] when DeviceInfoReader Singleton instance
         * has not been initialized.
         */
        fun getDeviceNetworkType(context: Context): String {
            return mDeviceInfoReader?.getNetworkType(context)
                ?: error("DeviceInfoReader must be initialized first.")
        }
    }

}