package com.santander.globile.deviceinfolib.common

import android.content.Intent
import com.google.gson.Gson
import com.santander.globile.deviceinfolib.activity.DeviceInfoActivity

internal fun getDeviceInfoFromIntentData(data: Intent?): DeviceInfo? =
    if (data?.hasExtra(DeviceInfoActivity.DEVICE_INFO_RESULT) == true) {
        val response = Gson().fromJson(data.extras?.getString(DeviceInfoActivity.DEVICE_INFO_RESULT), DeviceInfoResponse::class.java)
        response?.deviceInfo
    } else {
        null
    }