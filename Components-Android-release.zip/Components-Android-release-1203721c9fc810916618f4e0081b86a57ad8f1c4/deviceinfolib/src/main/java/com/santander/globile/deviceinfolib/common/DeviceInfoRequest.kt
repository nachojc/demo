package com.santander.globile.deviceinfolib.common

/**
 * Entity that holds the device info request variables.
 *
 * @param operation
 * @param deviceInfoRequired
 */
data class DeviceInfoRequest (
    val operation: String? = null,
    val deviceInfoRequired: ArrayList<String>? = null
)
