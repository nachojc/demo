import {NgModule} from '@angular/core';
import {EnumToArrayPipe} from './enumToArray';


@NgModule({
  declarations: [
    EnumToArrayPipe
  ],

  exports: [
    EnumToArrayPipe
  ],

})
export class EnumToArrayModule {
}
