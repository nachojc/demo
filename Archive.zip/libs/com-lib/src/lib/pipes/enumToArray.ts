import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'enumToArray'
})
export class EnumToArrayPipe implements PipeTransform {
  transform(data: Object) {
      return  Object.keys(data).map(id => ({id: id, value: data[id] || id}));
  }
}
