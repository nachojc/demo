export enum Size {
    'Small' = 'small',
    'Medium'= 'medium',
    'Large' = 'large'
}
