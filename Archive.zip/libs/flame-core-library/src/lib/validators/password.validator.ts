import { AbstractControl } from '@angular/forms';

const onlyAlphaRegex = /^[a-zA-Z0-9]+$/;
const lengthRegex = /^(?=.*[0-9])(?=.*[a-zA-Z])([a-zA-Z0-9]+){8}$/;
const repeatRegex = /^(?!.*(.)\1)/;

export function passwordAlphaValidator(control: AbstractControl) {
	if (!onlyAlphaRegex.test(control.value)) {
		return {
			passwordAlpha: true
		};
	}
	return null;
}

export function passwordLengthValidator(control: AbstractControl) {
	if (!lengthRegex.test(control.value)) {
		return {
			passwordLength: true
		};
	}
	return null;
}

export function passwordValidator(control: AbstractControl) {
	const pass = control.value;
	let correct = true;
	if (pass) {
		for (let i = 0; i < pass.length; i++) {
			if (!isNaN(parseInt(pass.charAt(i), 10))) {
				if (
					parseInt(pass.charAt(i), 10) + 1 ===
						parseInt(pass.charAt(i + 1), 10) ||
					parseInt(pass.charAt(i), 10) - 1 === parseInt(pass.charAt(i + 1), 10)
				) {
					correct = false;
				}
			}
		}
	}

	if (!repeatRegex.test(pass) || !correct) {
		return {
			password: true
		};
	}
	return null;
}

export function passwordEqualsValidator(control: AbstractControl) {
	if (control.get('password').value !== control.get('passwordConfirm').value) {
		control.get('passwordConfirm').setErrors({ passwordEquals: true });
	}
	return null;
}
