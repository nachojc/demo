import { AbstractControl } from '@angular/forms';
const lengthRegex = /^(?=[0-9]*$)(?:.{8}|.{15}|.{16})$/;

export function bucAndCreditCardValidator(control: AbstractControl) {
	if (!lengthRegex.test(control.value)) {
		return {
			bucAndCreditCard: true
		};
	}
	return null;
}
