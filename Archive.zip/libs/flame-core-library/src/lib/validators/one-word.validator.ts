import { AbstractControl } from '@angular/forms';
const oneWordRegex = /^\w+$/;

export function oneWordValidator(control: AbstractControl) {
	if (!oneWordRegex.test(control.value)) {
		return {
			oneWord: true
		};
	}
	return null;
}
