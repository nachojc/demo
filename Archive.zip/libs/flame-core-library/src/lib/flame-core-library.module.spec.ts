import { async, TestBed } from '@angular/core/testing';
import { FlameCoreLibraryModule } from './flame-core-library.module';

describe('FlameCoreLibraryModule', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [FlameCoreLibraryModule]
		}).compileComponents();
	}));

	it('should create', () => {
		expect(FlameCoreLibraryModule).toBeDefined();
	});
});
