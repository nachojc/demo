import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'mask'
})
export class MaskPipe implements PipeTransform {
	transform(value: string, visible: number) {
		let maskValue = '';

		for (let count = 0; count < value.length - visible; count++) {
			maskValue = maskValue + '•';
		}
		return maskValue + value.substr(value.length - visible, value.length);
	}
}
