import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({
	name: 'safeImage'
})
export class SafeImage implements PipeTransform {
	constructor(private sanitizer: DomSanitizer) {}

	transform(image: any) {
		return this.sanitizer.bypassSecurityTrustResourceUrl(image);
	}
}
