import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmountFieldComponent } from './amount-field.component';
import { IconModule } from '../../atoms/icon/icon.module';

@NgModule({
	imports: [CommonModule, IconModule],
	declarations: [AmountFieldComponent],
	exports: [AmountFieldComponent]
})
export class AmountFieldModule {}
