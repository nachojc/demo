import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MotiveFieldComponent } from './motive-field.component';

describe('MotiveFieldComponent', () => {
	let component: MotiveFieldComponent;
	let fixture: ComponentFixture<MotiveFieldComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [MotiveFieldComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(MotiveFieldComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
