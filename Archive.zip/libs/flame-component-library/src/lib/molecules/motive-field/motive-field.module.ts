import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../atoms/icon/icon.module';
import { MotiveFieldComponent } from './motive-field.component';

@NgModule({
	imports: [CommonModule, IconModule],
	declarations: [MotiveFieldComponent],
	exports: [MotiveFieldComponent]
})
export class MotiveFieldModule {}
