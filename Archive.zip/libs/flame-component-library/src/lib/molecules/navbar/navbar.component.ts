import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavbarElement } from './navbar.interface';
@Component({
	selector: 'sn-navbar',
	templateUrl: './navbar.component.html',
	styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
	@Input() buttons: NavbarElement[];
	@Input() active = 0;
	@Output() onSelection = new EventEmitter();

	constructor() {}

	selectElement(i: number, route: string) {
		this.active = i;
		this.onSelection.emit(route);
	}
}
