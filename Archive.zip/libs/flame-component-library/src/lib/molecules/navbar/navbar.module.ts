import { NgModule } from '@angular/core';
import { NavbarComponent } from './navbar.component';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../atoms/icon/icon.module';

@NgModule({
	imports: [CommonModule, IconModule],
	declarations: [NavbarComponent],
	exports: [NavbarComponent]
})
export class NavbarModule {}
