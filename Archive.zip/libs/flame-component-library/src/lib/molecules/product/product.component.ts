import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';

@Component({
	selector: 'sn-product',
	templateUrl: './product.component.html',
	styleUrls: ['./product.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class ProductComponent implements OnInit {
	constructor() {}

	@Input() account: string;
	@Input() amount: string;
	@Input() currency: string;
	@Input() displayName: string;
	@Input() type: string;
	@Input() accordion = false;

	ngOnInit() {}

	eventClick() {
		console.log('evento');
	}
}
