import { NgModule } from '@angular/core';
import { ProductComponent } from './product.component';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../atoms/icon/icon.module';

@NgModule({
	imports: [CommonModule, IconModule],
	declarations: [ProductComponent],
	exports: [ProductComponent]
})
export class ProductModule {}
