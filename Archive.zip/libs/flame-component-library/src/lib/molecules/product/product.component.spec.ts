import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductComponent } from './product.component';

describe('ProductComponent', () => {
	let component: ProductComponent;
	let fixture: ComponentFixture<ProductComponent>;
	let p: HTMLElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ProductComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ProductComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		p = fixture.nativeElement.querySelector('p');
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('should acccount product-component', () => {
		component.account = '32**2345';
		expect(component.account).toBe('32**2345');
	});
	it('should amount product-component', () => {
		component.amount = '5800.95';
		expect(component.amount).toBe('5800.95');
	});
	it('should currency product-component', () => {
		component.currency = 'MXN';
		expect(component.currency).toBe('MXN');
	});
	it('should displayName product-component', () => {
		component.displayName = 'Super Nomina';
		expect(component.displayName).toBe('Super Nomina');
	});
	it('should type product-component', () => {
		component.type = './assets/icons/card-basic.svg';
		expect(component.type).toBe('./assets/icons/card-basic.svg');
	});
	it('should display a different test account', () => {
		component.account = '$0';
		fixture.detectChanges();
		expect(p.textContent).toContain('$0');
	});
});
