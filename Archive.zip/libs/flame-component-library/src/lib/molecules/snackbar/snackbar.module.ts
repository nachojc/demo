import { NgModule } from '@angular/core';
import { SnackbarComponent } from './snackbar.component';

@NgModule({
	imports: [],
	declarations: [SnackbarComponent],
	exports: [SnackbarComponent]
})
export class SnackBarModule {}
