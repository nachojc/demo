import { Injectable } from '@angular/core';
import { DialogConfig } from '../../atoms/dialog/dialog.service';
import { OverlayRef, OverlayConfig, Overlay } from '@angular/cdk/overlay';

@Injectable({
	providedIn: 'root'
})
export class OverlayService {
	constructor(private _overlayServiceCDK: Overlay) {}

	public createOverlay(config: any): OverlayRef {
		// TODO: create a interfsace for OverlayConfig
		const overlayConfig: OverlayConfig = this.getOverlayConfig(config);
		return this._overlayServiceCDK.create(overlayConfig);
	}

	private getOverlayConfig(config: DialogConfig): OverlayConfig {
		const positionStrategy = this._overlayServiceCDK
			.position()
			.global()
			.centerHorizontally()
			.bottom();

		const overlayConfig = new OverlayConfig({
			hasBackdrop: config.hasBackdrop,
			backdropClass: config.backdropClass,
			panelClass: config.panelClass,
			scrollStrategy: this._overlayServiceCDK.scrollStrategies.block(),
			positionStrategy
		});

		return overlayConfig;
	}
}
