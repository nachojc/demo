import {
	Component,
	OnInit,
	Input,
	EventEmitter,
	ViewChild,
	OnDestroy,
	ViewEncapsulation,
	AfterViewInit,
	ChangeDetectorRef,
	ElementRef,
	Output,
	ChangeDetectionStrategy,
	Optional
} from '@angular/core';
import { FocusMonitor } from '@angular/cdk/a11y';
import { UniqueSelectionDispatcher } from '@angular/cdk/collections';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { Subject } from 'rxjs';
import { RadioGroupDirective } from './radio-group.directive';
import { RadioButton, SnRadioChange } from './radio-button.interface';

/**
 * Option IDs need to be unique across components, so this counter exists outside of
 * the component definition.
 */
let _uniqueIdCounter = 0;

@Component({
	selector: 'sn-radio-button',
	templateUrl: './radio-button.component.html',
	styleUrls: ['./radio-button.component.scss'],
	encapsulation: ViewEncapsulation.None,
	host: {
		'[attr.id]': 'id',
		'[class.sn-radio-checked]': 'checked',
		'[class.sn-radio-disabled]': 'disabled',
		'(focus)': '_inputElement.nativeElement.focus()'
	},
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class RadioButtonComponent
	implements OnInit, AfterViewInit, OnDestroy, RadioButton {
	private _disabled = false;
	private _checked = false;
	private _required = false;
	private _value: any;
	private radioGroup: RadioGroupDirective;
	private _typeradio = 1;
	/** Emits when the state of the option changes and any parents have to be notified. */
	readonly _stateChanges = new Subject<void>();
	/** The unique ID of the radio button element. */
	@Input() id = `sn-radio-button-${_uniqueIdCounter++}`;
	/** The unique ID of the input of the radio button */
	@Input()
	get inputId() {
		return `${this.id}-input`;
	}
	@ViewChild('input') _inputElement: ElementRef<HTMLInputElement>;
	@Output() readonly change: EventEmitter<SnRadioChange> = new EventEmitter<
		SnRadioChange
	>();
	/** The name of the radio button used to group radios for unique selection. */
	@Input() name: any;
	/** Type of Radio */
	@Input()
	get typeradio(): number {
		return this._typeradio;
	}
	set typeradio(value: number) {
		this._typeradio = parseInt(value.toString(), 10);
	}

	constructor(
		@Optional() radioGroup: RadioGroupDirective,
		private elementRef: ElementRef<HTMLElement>,
		private changeDetectorRef: ChangeDetectorRef,
		private focusMonitor: FocusMonitor,
		private radioDispatcher: UniqueSelectionDispatcher
	) {
		this.radioGroup = radioGroup;
		this._removeUniqueSelectionListener = this.radioDispatcher.listen(
			(id: string, name: string) => {
				if (id !== this.id && name === this.name) {
					this.checked = false;
				}
			}
		);
	}

	private _removeUniqueSelectionListener: () => void = () => {};
	/** The value of the radio button. */
	@Input()
	get value(): any {
		return this._value;
	}
	/** Set value for radio button */
	set value(value: any) {
		if (this._value !== value) {
			this._value = value;
			if (this.radioGroup !== null) {
				if (!this.checked) {
					this.checked = this.radioGroup.value === value;
				}
				if (this.checked) {
					this.radioGroup.selected = this;
				}
			}
		}
	}
	/** The status of the radio button. */
	@Input()
	get checked(): boolean {
		return this._checked;
	}
	/**  */
	set checked(value: boolean) {
		const newState = coerceBooleanProperty(value);
		if (this._checked !== newState) {
			this._checked = newState;
			if (newState && this.radioGroup && this.radioGroup.value !== this.value) {
				this.radioGroup.selected = this;
			} else if (
				!newState &&
				this.radioGroup &&
				this.radioGroup.value === this.value
			) {
				// When unchecking the selected radio button, update the selected radio
				// property on the group.
				this.radioGroup.selected = null;
			}
			if (newState) {
				// Notify all radio buttons with the same name to un-check.
				this.radioDispatcher.notify(this.id, this.name);
			}
			this.changeDetectorRef.markForCheck();
		}
	}
	/** Whether radio button is required. */
	@Input()
	get required(): boolean {
		return this._required || (this.radioGroup && this.radioGroup.required);
	}
	set required(value: boolean) {
		this._required = coerceBooleanProperty(value);
	}

	/** Whether the radio button is disabled. */
	@Input()
	get disabled(): boolean {
		return (
			this._disabled || (this.radioGroup !== null && this.radioGroup.disabled)
		);
	}
	set disabled(value: boolean) {
		const newDisabledState = coerceBooleanProperty(value);
		if (this._disabled !== newDisabledState) {
			this._disabled = newDisabledState;
			this.changeDetectorRef.markForCheck();
		}
	}

	/** Sets name and checked if the radio button belongs to a group */
	ngOnInit(): void {
		if (this.radioGroup) {
			this.radioGroup.addRadio(this);
			this.checked = this.radioGroup.value === this._value;
			this.name = this.radioGroup.name;
		}
	}

	/** Init focus monitor  */
	ngAfterViewInit(): void {
		this.focusMonitor.monitor(this.elementRef, true).subscribe(focusOrigin => {
			if (!focusOrigin && this.radioGroup) {
				this.radioGroup._touch();
			}
		});
	}

	/** Stops focus monitor and remove the unique selection listener  */
	ngOnDestroy(): void {
		this.focusMonitor.stopMonitoring(this.elementRef);
		this._removeUniqueSelectionListener();
	}

	/** Sets focus into this radio button */
	focus(): void {
		this.focusMonitor.focusVia(this._inputElement, 'keyboard');
	}

	/**  */
	_getHostElement(): HTMLElement {
		return this.elementRef.nativeElement;
	}

	/**  */
	_markForCheck(): void {
		this.changeDetectorRef.markForCheck();
	}

	/**
	 * Dispatch change event with current value.
	 */
	_emitChangeEvent(): void {
		this.change.emit(new SnRadioChange(this, this._value));
	}

	/** Stop duplicate propagation beetween click and change from input */
	_onInputClick(event: Event): void {
		event.stopPropagation();
	}

	/**  */
	_onInputChange(event: Event): void {
		event.stopPropagation();
		const groupValueChanged =
			this.radioGroup && this.value !== this.radioGroup.value;
		this.checked = true;
		this._emitChangeEvent();

		if (this.radioGroup) {
			this.radioGroup._controlValueAccessorChangeFn(this.value);
			this.radioGroup._touch();
			if (groupValueChanged) {
				this.radioGroup._emitChangeEvent();
			}
		}
	}
}
