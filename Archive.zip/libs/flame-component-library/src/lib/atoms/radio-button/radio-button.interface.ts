export interface RadioButton {
	id: string;
	inputId: string;
	name: string;
	value: any;
	checked: boolean;
	required: boolean;
	disabled: boolean;

	_markForCheck(): void;
}

export class SnRadioChange {
	constructor(public source: RadioButton, public value: any) {}
}
