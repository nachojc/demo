import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IconButtonComponent } from './icon-button.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { IconModule } from '../icon/icon.module';

describe('IconButtonComponent', () => {
	let component: IconButtonComponent;
	let fixture: ComponentFixture<IconButtonComponent>;
	let iconEl: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [IconButtonComponent],
			imports: [IconModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(IconButtonComponent);
		component = fixture.componentInstance;
		iconEl = fixture.debugElement.query(By.css('#icon'));
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should title', () => {
		component.title = 'Nombre Icon';
		expect(component.title).toBe('Nombre Icon');
	});
	it('should icon', () => {
		component.icon = 'sn-buscar';
		expect(component.icon).toBe('sn-buscar');
	});
	it('should size', () => {
		component.size = 'sm';
		expect(component.size).toBe('sm');
	});

	it('should detonated click', () => {
		component.selectElement('title');
		fixture.detectChanges();
		expect(iconEl.nativeElement.click());
	});
	it('should change icon', () => {
		const slideIconLoad = fixture.debugElement.query(By.css('#icon'));
		fixture.detectChanges();
		expect(slideIconLoad.nativeElement.id).toEqual('icon');
	});
});
