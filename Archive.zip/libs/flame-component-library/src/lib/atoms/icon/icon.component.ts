import { Component, Input } from '@angular/core';

@Component({
	selector: 'sn-icon',
	styleUrls: ['./icon.component.scss'],
	templateUrl: './icon.component.html'
})
export class IconComponent {
	@Input() icon: string;
}
