import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-stepper-marker',
	styleUrls: ['./stepper-marker.component.scss']
})
export class StepperMarkerComponent implements OnInit {
	constructor() {}
	ngOnInit() {}
}
