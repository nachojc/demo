import { Component, ViewChild } from '@angular/core';
import { TestBed, async } from '@angular/core/testing';

import { SnStepDirective } from './step.directive';
import { SnStepGroupDirective } from './step-group.directive';

@Component({
	selector: 'sn-step-group-test',
	template: `
		<div>
			<ul snStepGroup>
				<li snStep></li>
				<li snStep id="secondStep"></li>
				<li snStep></li>
				<li snStep></li>
			</ul>
		</div>
	`
})
class StepGroupTestComponent {
	@ViewChild(SnStepGroupDirective) stepGroup: SnStepGroupDirective;
}

describe('StepGroupDirective', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [
				SnStepGroupDirective,
				SnStepDirective,
				StepGroupTestComponent
			]
		}).compileComponents();
	}));

	it('Debe instanciarse correctamente', () => {
		const fixture = TestBed.createComponent(StepGroupTestComponent);
		expect(fixture.componentInstance.stepGroup).toBeDefined();
	});

	it('Debe recoger los steps correctamente', () => {
		const fixture = TestBed.createComponent(StepGroupTestComponent);
		fixture.detectChanges();
		expect(fixture.componentInstance.stepGroup.steps.length).toEqual(4);
	});

	it('Debe poder recuperar un step por posicion', () => {
		const fixture = TestBed.createComponent(StepGroupTestComponent);
		fixture.detectChanges();

		expect(fixture.componentInstance.stepGroup.get(1).id).toEqual('secondStep');
	});

	it('Debe poder recuperar un step por identificador', () => {
		const fixture = TestBed.createComponent(StepGroupTestComponent);
		fixture.detectChanges();

		expect(fixture.componentInstance.stepGroup.get('secondStep').id).toEqual(
			'secondStep'
		);
	});

	it('Debe devolver undefined si no encuentra el step', () => {
		const fixture = TestBed.createComponent(StepGroupTestComponent);
		fixture.detectChanges();

		expect(fixture.componentInstance.stepGroup.get('testStep')).toBeUndefined();
	});
});
