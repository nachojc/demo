import {
	AfterViewInit,
	ContentChildren,
	Directive,
	QueryList,
	ChangeDetectorRef,
	Renderer2,
	ElementRef,
	Input
} from '@angular/core';
import { SnStepDirective } from './step.directive';
import { Step } from './step.interface';

@Directive({
	selector: '[snStepGroup]',
	exportAs: 'SnStepGroupDirective'
})
export class SnStepGroupDirective implements AfterViewInit {
	@Input() graphicType: string;
	@ContentChildren(SnStepDirective) steps: QueryList<SnStepDirective>;
	constructor(
		private _changeDetection: ChangeDetectorRef,
		private renderer: Renderer2,
		public eRef: ElementRef
	) {}

	ngAfterViewInit() {
		this.steps.forEach((step: SnStepDirective) => {
			step.onActivate.subscribe(this._onStepActivation.bind(this));
			step.onComplete.subscribe(this._onStepCompletation.bind(this));
		});
		this._changeDetection.detectChanges();
		this.generateGraphics();
	}
	generateGraphics() {
		const container = this.renderer.createElement('div');
		this.renderer.addClass(container, 'progress-container');
		let progressBar: any;
		switch (this.graphicType) {
			case 'text':
				progressBar = this.renderer.createText(
					`Paso ${this.getActivedStep().id} de ${this.steps.length}`
				);
				this.renderer.appendChild(container, progressBar);
				this.eRef.nativeElement.appendChild(container);
				break;
			case 'bar':
				progressBar = this.renderer.createElement('progress');
				this.renderer.setAttribute(
					progressBar,
					'value',
					this.getActivedStep().id
				);
				this.renderer.setAttribute(
					progressBar,
					'max',
					this.steps.length.toString()
				);
				this.renderer.appendChild(container, progressBar);
				this.eRef.nativeElement.appendChild(container);
				break;
			case 'dots':
				this.steps.map(step => {
					let text = '';
					progressBar = this.renderer.createElement('div');
					this.renderer.addClass(progressBar, 'circle-stepper');
					step.activated
						? (text = 'current-tab-marker')
						: (text = 'idle-tab-marker');
					this.renderer.addClass(progressBar, text);
					this.renderer.appendChild(container, progressBar);
					this.eRef.nativeElement.appendChild(container);
				});
				break;
			default:
				console.error('type not defined');
				break;
		}
	}
	updateGraphic() {
		switch (this.graphicType) {
			case 'text':
				const container = this.eRef.nativeElement.querySelectorAll(
					'.progress-container'
				);
				this.renderer.removeChild(container, container[0].childNodes[0]);
				const progressBar = this.renderer.createText(
					`Paso ${this.getActivedStep().id} de ${this.steps.length}`
				);
				this.renderer.appendChild(container[0], progressBar);
				break;
			case 'bar':
				const progress = this.eRef.nativeElement.querySelectorAll('progress');
				this.renderer.setAttribute(
					progress[0],
					'value',
					this.getActivedStep().id
				);
				this.renderer.setAttribute(
					progress[0],
					'max',
					this.steps.length.toString()
				);
				break;
			case 'dots':
				const dots = this.eRef.nativeElement.querySelectorAll(
					'.circle-stepper'
				);
				this.steps.map((step, i) => {
					if (step.activated) {
						this.renderer.removeClass(dots[i], 'idle-tab-marker');
						this.renderer.addClass(dots[i], 'current-tab-marker');
					} else {
						this.renderer.removeClass(dots[i], 'current-tab-marker');
						this.renderer.addClass(dots[i], 'idle-tab-marker');
					}
				});
				break;
			default:
				console.error('type not defined');
				break;
		}
	}

	getActivedStep(): Step {
		if (this.steps && this.steps.length > 0) {
			return this.steps
				.toArray()
				.find((step: SnStepDirective) => step.activated);
		} else {
			return null;
		}
	}

	getActivatedStepIndex(): number {
		if (this.steps && this.steps.length > 0) {
			return this.steps
				.toArray()
				.findIndex((step: SnStepDirective) => step.activated);
		} else {
			return -1;
		}
	}

	get(id: number | string): SnStepDirective {
		let step = null;

		if (this.steps && this.steps.length > 0) {
			if (typeof id === 'number') {
				step = this.steps.toArray()[id];
			} else {
				step = this.steps.find((item: SnStepDirective) => item.id === id);
			}
		}
		return step;
	}

	setActiveNextIndex(): void {
		const nextStep = this.getActivatedStepIndex() + 1;
		if (this.steps && this.steps.length > 0 && nextStep < this.steps.length) {
			const step = this.steps.toArray()[nextStep];
			step.activate();
			this.updateGraphic();
		}
	}

	setActivePreviusIndex(): void {
		const nextStep = this.getActivatedStepIndex();
		if (this.steps && this.steps.length > 0 && nextStep > 0) {
			const step = this.steps.toArray()[nextStep - 1];
			step.activate();
			this.updateGraphic();
		}
	}
	private _onStepActivation(activatedStep: Step) {
		this.steps
			.filter((step: SnStepDirective) => step.id !== activatedStep.id)
			.forEach((step: SnStepDirective) => step.deactivate());
	}

	private _onStepCompletation(completedStep: Step) {
		const stepsArray = this.steps.toArray();
		const index = stepsArray.findIndex(
			(step: SnStepDirective) => step.id === completedStep.id
		);

		if (index < stepsArray.length - 1) {
			stepsArray[index + 1].activate();
		}
	}
}
