import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProgressBarComponent } from './progress-bar.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('ProgressBarComponent', () => {
	let component: ProgressBarComponent;
	let fixture: ComponentFixture<ProgressBarComponent>;
	let progressEl: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ProgressBarComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ProgressBarComponent);
		component = fixture.componentInstance;
		progressEl = fixture.debugElement.query(By.css('.sn-progress-bar'));
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should change value', () => {
		component.value = '56';
		fixture.detectChanges();
		expect(progressEl.nativeElement.style.width).toBe('56%');
	});

	it('should set class indeterminate', () => {
		component.indeterminate = true;
		fixture.detectChanges();
		expect(progressEl.nativeElement.classList).toContain(
			'sn-progress-bar-indeterminate'
		);
	});
});
