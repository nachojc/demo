import { Component, OnInit, Input, HostBinding } from '@angular/core';

@Component({
	selector:
		'sn-button, button[sn-button], a[sn-button], button[snButton], a[snButton]',
	template: '<ng-content></ng-content>',
	styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements OnInit {
	constructor() {}

	@Input() class = '';
	@HostBinding('class')
	get hostClasses(): string {
		return [this.class].join(' ');
	}

	ngOnInit() {}
}
