import { NgModule } from '@angular/core';
import { TooltipComponent } from './tooltip.component';
import { OverlayModule } from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import {
	SnTooltipDirective,
	SN_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER
} from './tooltip.directive';

@NgModule({
	imports: [OverlayModule, CommonModule],
	declarations: [TooltipComponent, SnTooltipDirective],
	exports: [TooltipComponent, SnTooltipDirective],
	providers: [SN_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER],
	entryComponents: [TooltipComponent]
})
export class TooltipModule {}
