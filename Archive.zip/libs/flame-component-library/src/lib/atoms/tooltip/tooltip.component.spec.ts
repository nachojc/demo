import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TooltipComponent } from './tooltip.component';
import { By } from '@angular/platform-browser';
import { DebugElement, ChangeDetectorRef } from '@angular/core';

describe('TooltipComponent', () => {
	let component: TooltipComponent;
	let fixture: ComponentFixture<TooltipComponent>;
	let debugElement: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TooltipComponent],
			providers: [TooltipComponent, ChangeDetectorRef]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TooltipComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should be invisible', () => {
		debugElement = fixture.debugElement.query(By.css('div'));
		debugElement.classes.invisible = true;
		expect(debugElement.classes.invisible).toBe(true);
	});

	it('should be visible', () => {
		debugElement = fixture.debugElement.query(By.css('div'));
		debugElement.classes.invisible = false;
		expect(debugElement.classes.invisible).toBe(false);
	});

	it('should be call show', () => {
		spyOn(component, 'show');
		component.show(0);
		fixture.whenStable().then(() => {
			expect(component.show).toHaveBeenCalled();
		});
	});

	it('should be call hide', () => {
		spyOn(component, 'hide');
		component.hide(0);
		fixture.whenStable().then(() => {
			expect(component.hide).toHaveBeenCalled();
		});
	});

	it('should be call toggle', () => {
		spyOn(component, 'toggle');
		component.toggle(0);
		fixture.whenStable().then(() => {
			expect(component.toggle).toHaveBeenCalled();
		});
	});
});
