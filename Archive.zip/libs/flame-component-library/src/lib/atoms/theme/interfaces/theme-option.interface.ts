import { Theme } from './theme.interface';

export interface ThemeOptions {
	themes: Theme[];
	active: string;
}
