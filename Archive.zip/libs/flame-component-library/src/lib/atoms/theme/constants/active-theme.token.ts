import { InjectionToken } from '@angular/core';

export const ACTIVE_THEME = new InjectionToken('ACTIVE_THEME');
