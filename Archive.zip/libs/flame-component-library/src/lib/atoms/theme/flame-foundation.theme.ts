import { Theme } from './interfaces/theme.interface';

export const FlameFoundationTheme: Theme = {
	name: 'flame-foundation',
	properties: {
		'--sn-theme-primary': '#EC0000',
		'--sn-theme-secondary': '#FFFFFF',
		'--sn-theme-background': '#F5F9FB',
		'--sn-theme-disabled': '#D9D9D9',
		'--sn-theme-color__santander-red': '#EC0000',
		'--sn-theme-color__ruby-red': '#990000',
		'--sn-theme-color__boston-red': '#CC0000',
		'--sn-theme-color__black': '#000000',
		'--sn-theme-color__white': '#FFFFFF',
		'--sn-theme-color__grafite': '#6F7779',
		'--sn-theme-color__sky': '#DEEDF2',
		'--sn-theme-color__medium-sky': '#CEDEE7',

		'--sn-theme-color__yellow': '#FFCC33',
		'--sn-theme-color__lime-green': '#63BA68',
		'--sn-theme-color__turquoise': '#1BB3BC',
		'--sn-theme-color__purple': '#9E3667',
		'--sn-theme-color__blue': '#3366FF',

		'--sn-theme-color__brown': '#946F00',
		'--sn-theme-color__green': '#3A8344',
		'--sn-theme-color__dark-turquoise': '#137E84',
		'--sn-theme-color__dark-purple': '#732645',
		'--sn-theme-color__dark-blue': '#0032E6',

		'--sn-theme-shadow1':
			'0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24)',
		'--sn-theme-shadow2':
			'0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22)',
		'--sn-theme-shadow3':
			'0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23)',
		'--sn-theme-shadow4':
			'0 10px 20px rgba(0,0,0,0.19), 0 6px 6px rgba(0,0,0,0.23)',
		'--sn-theme-shadow5':
			'0 14px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22)',
		'--sn-theme-shadow6':
			'0 19px 38px rgba(0,0,0,0.30), 0 15px 12px rgba(0,0,0,0.22)',

		'--sn-theme-shadowTransition':
			'transition: all 0.3s cubic-bezier(.25,.8,.25,1)',

		'--sn-theme-font__sans-serif': `OpenSans, Arial, Helvetica, sans-serif;`,
		'--sn-theme-font__text': `SantanderText-Regular, Arial, Helvetica, serif;`,
		'--sn-theme-font__headline': `SantanderHeadline-Regular, Arial, Helvetica, serif;`,

		'--sn-theme-color__grey': '#F4F4F4'
	}
};
