import {
	Directive,
	DoCheck,
	ElementRef,
	Input,
	HostListener,
	HostBinding,
	Optional,
	Self,
	Inject
} from '@angular/core';
import { NgForm, NgControl, FormGroupDirective } from '@angular/forms';
import { SN_INPUT_VALUE_ACCESSOR } from './input-value-accessor';
import { Subject } from 'rxjs';

import { ErrorStateMatcher } from '../../core/index';

const SN_INPUT_INVALID_TYPES = [
	'button',
	'checkbox',
	'file',
	'hidden',
	'image',
	'radio',
	'range',
	'reset',
	'submit',
	'color'
];

@Directive({
	selector: 'input[sn-input], input[snInput]',
	exportAs: 'sn-input',
	host: {
		class: 'sn-input-element',
		'[attr.id]': 'id',
		'[attr.placeholder]': 'placeholder',
		'[attr.label]': '_label',
		'(blur)': '_focusChanged(false)',
		'(focus)': '_focusChanged(true)'
	}
})
export class InputDirective implements DoCheck {
	public focused = false;
	public invalid = false;
	public _previousNativeValue: any;
	private _inputValueAccessor: { value: any };

	readonly stateChanges: Subject<void> = new Subject<void>();

	constructor(
		public _elementRef: ElementRef<HTMLInputElement | HTMLTextAreaElement>,
		_defaultErrorStateMatcher: ErrorStateMatcher,
		@Optional() @Self() public ngControl: NgControl,
		@Optional() _parentForm: NgForm,
		@Optional() _parentFormGroup: FormGroupDirective,
		@Optional() @Self() @Inject(SN_INPUT_VALUE_ACCESSOR) inputValueAccessor: any
	) {
		const element = this._elementRef.nativeElement;
		this.id = this.id;

		this._inputValueAccessor = inputValueAccessor || element;
		this._previousNativeValue = this.value;
	}

	@Input()
	get disabled(): boolean {
		if (this.ngControl && this.ngControl.disabled !== null) {
			return this.ngControl.disabled;
		}
		return this._disabled;
	}
	set disabled(value: boolean) {
		this._disabled = value;
		if (this.focused) {
			this.focused = false;
			this.stateChanges.next();
		}
	}
	public _disabled = false;

	@Input()
	get id(): string {
		return this._id;
	}
	set id(value: string) {
		this._id = value;
	}
	public _id: string;

	@Input() placeholder: string;

	@Input()
	get required(): boolean {
		return this._required;
	}
	set required(value: boolean) {
		this._required = value;
	}
	public _required = false;

	@Input()
	get label(): string {
		return this._label;
	}
	set label(value: string) {
		this._label = value;
		this.placeholder = this._label;
	}
	public _label = '';

	@Input()
	get type(): string {
		return this._type;
	}
	set type(value: string) {
		this._type = value || 'text';
		this._validateType();
	}
	public _type = 'text';

	@Input()
	get value(): string {
		return this._inputValueAccessor.value;
	}
	set value(value: string) {
		if (value !== this.value) {
			this._inputValueAccessor.value = value;
			this.stateChanges.next();
		}
	}
	@Input() readonly = false;
	@Input() errorStateMatcher: ErrorStateMatcher;

	ngDoCheck() {
		this._dirtyCheckNativeValue();
	}

	focus(): void {
		this._elementRef.nativeElement.focus();
	}

	_focusChanged(isFocused: boolean) {
		if (isFocused !== this.focused) {
			this.focused = isFocused;
		}
	}

	@HostListener('focus')
	onFocus() {
		this.focused = true;
	}

	/** Se ejecuta al momento que el input pierde foco.
	 *  Se asegura de que hay valor insertado para regresar o no la etiqueta a su posición original. */
	@HostListener('blur')
	onBlur() {
		this.focused = false;
		this.invalid = this._isBadInput();
	}

	/** Checa si el tipo seleccionado es soportado por el componente */
	public _validateType() {
		if (SN_INPUT_INVALID_TYPES.indexOf(this._type) > -1) {
			throw new Error(`Input type: ${this._type} not suported`);
		}
	}

	/** Checa si el valor insertado es invalido basado en la validación nativa. */
	public _isBadInput() {
		const validity = (this._elementRef.nativeElement as HTMLInputElement)
			.validity;
		return validity && !validity.valid;
	}

	/** Comprobación manual en la propiedad `value` nativa. */
	public _dirtyCheckNativeValue() {
		const newValue = this._elementRef.nativeElement.value;

		if (this._previousNativeValue !== newValue) {
			this._previousNativeValue = newValue;
			this.stateChanges.next();
		}
	}

	/** Se asegura de que el input tenga un valor */
	get empty(): boolean {
		return !this._elementRef.nativeElement.value && !this._isBadInput();
	}

	/** Sirve para definir la posición del label en la implementación de `sn-form-field` */
	get shouldLabelFloat(): boolean {
		return this.focused || !this.empty;
	}
}
