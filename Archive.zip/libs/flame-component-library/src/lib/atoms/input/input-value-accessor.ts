import { InjectionToken } from '@angular/core';

export const SN_INPUT_VALUE_ACCESSOR = new InjectionToken<{ value: any }>(
	'SN_INPUT_VALUE_ACCESSOR'
);
