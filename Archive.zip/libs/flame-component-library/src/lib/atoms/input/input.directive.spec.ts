import { Component, DebugElement } from '@angular/core';
import { async, TestBed, ComponentFixture } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { InputDirective } from './input.directive';

@Component({
	selector: 'sn-test-app',
	template: `
		<input id="inputOne" sm-input type="text" disabled /> <br />
		<input id="inputTwo" sm-input type="number" required />
	`
})
class TestAppComponent {
	isAutofocus = false;
	isReadOnly = false;
	label = '';
}

describe('InputDirective', () => {
	let component: TestAppComponent;
	let fixture: ComponentFixture<TestAppComponent>;
	let inputElOne: DebugElement;
	let inputElTwo: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [InputDirective, TestAppComponent]
		});

		fixture = TestBed.createComponent(TestAppComponent);
		component = fixture.componentInstance;
		inputElOne = fixture.debugElement.query(By.css('#inputOne'));
		inputElTwo = fixture.debugElement.query(By.css('#inputTwo'));
	}));

	it('is disabled', () => {
		expect(inputElOne.nativeElement.disabled).toBe(true);
	});

	it('is required', () => {
		expect(inputElTwo.nativeElement.required).toBe(true);
	});

	it('is number', () => {
		expect(inputElTwo.nativeElement.type).toBe('number');
	});
});
