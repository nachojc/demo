import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-date-time-picker',
	templateUrl: './date-time-picker.component.html',
	styleUrls: ['./date-time-picker.component.scss']
})
export class DateTimePickerComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
