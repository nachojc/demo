import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlideToggleComponent } from './slide-toggle.component';
import { By } from '@angular/platform-browser';

describe('SlideToggleComponent', () => {
	let component: SlideToggleComponent;
	let fixture: ComponentFixture<SlideToggleComponent>;
	let slideToggleElement: HTMLElement;
	let buttonElement: HTMLButtonElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [SlideToggleComponent]
		})
			.compileComponents()
			.then(() => {
				fixture = TestBed.createComponent(SlideToggleComponent);
				component = fixture.componentInstance;
				fixture.detectChanges();
			});
	}));

	beforeEach(() => {
		buttonElement = fixture.debugElement.query(By.css('button')).nativeElement;
		const slideToggleDebug = fixture.debugElement.query(
			By.css('.toggle-radius')
		);
		slideToggleElement = slideToggleDebug.nativeElement;
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should be off on init', () => {
		expect(slideToggleElement.classList).toContain('focus-off');
		expect(buttonElement.classList).toContain('button-off');
	});

	it('should be on when click element to on', () => {
		buttonElement.click();
		fixture.detectChanges();
		expect(slideToggleElement.classList).toContain('focus-on');
		expect(buttonElement.classList).toContain('button-on');
	});

	it('should be on when click element to off', () => {
		buttonElement.click();
		buttonElement.click();
		fixture.detectChanges();
		expect(slideToggleElement.classList).toContain('focus-off');
		expect(buttonElement.classList).toContain('button-off');
	});

	it('should call onChangeEvent() method', async(() => {
		spyOn(component, 'onChangeEvent');
		buttonElement.click();
		fixture.whenStable().then(() => {
			expect(component.onChangeEvent).toHaveBeenCalled();
		});
	}));
});
