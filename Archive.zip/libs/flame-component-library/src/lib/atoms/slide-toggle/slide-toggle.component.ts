import {
	AfterViewInit,
	ChangeDetectorRef,
	Component,
	EventEmitter,
	forwardRef,
	Input,
	OnChanges,
	Output,
	SimpleChanges
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

let nextUniqueId = 0;

@Component({
	selector: 'sn-slide-toggle',
	templateUrl: './slide-toggle.component.html',
	styleUrls: ['./slide-toggle.component.scss'],
	host: {
		class: 'sn-slide-toggle',
		'[attr.id]': 'id',
		'[attr.name]': 'name',
		'[attr.required]': 'required',
		'[attr.disabled]': '_disabled',
		'[attr.checked]': '_checked',
		'[class.sn-slide-toggle-disabled]': '_disabled',
		'[class.sn-slide-toggle-label-left]': 'labelPosition == "left"'
	},
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			multi: true,
			useExisting: forwardRef(() => SlideToggleComponent)
		}
	]
})
export class SlideToggleComponent
	implements OnChanges, AfterViewInit, ControlValueAccessor {
	constructor(private _changeDetectorRef: ChangeDetectorRef) {}

	private _button;
	private _circle;
	private _rect;
	private _startX = 0;
	private _id: string;
	private _name: string;
	private _required = false;
	private _isDrag = false;
	private _buttonWidth = '2rem';

	public _checked = false;
	public _disabled = false;
	public _buttonUniqueId = `button-${++nextUniqueId}`;
	public _divUniqueId = `div-${nextUniqueId}`;

	@Input()
	get id(): string {
		return this._id;
	}
	set id(value: string) {
		this._id = value;
	}

	@Input()
	get name(): string {
		return this._name;
	}
	set name(value: string) {
		this._name = value;
	}

	@Input()
	get required(): boolean {
		return this._required;
	}
	set required(value: boolean) {
		this._required = value;
	}

	@Input()
	get disabled(): boolean {
		return this._disabled;
	}
	set disabled(value) {
		if (!value) {
			this._disabled = true;
		} else {
			if (value.toString() === 'true') {
				this._disabled = true;
			} else {
				this._disabled = false;
			}
		}
	}

	@Input()
	get checked(): boolean {
		return this._checked;
	}
	set checked(value) {
		if (!value) {
			this._checked = true;
		}
	}

	@Input() labelPosition: 'left' | 'right' = 'right';

	@Output() readonly change: EventEmitter<boolean> = new EventEmitter<
		boolean
	>();

	private _onChange: Function;
	private _onTouched: Function;

	writeValue(val) {
		this._checked = val;
	}

	registerOnChange(fn) {
		this._onChange = fn;
	}

	registerOnTouched(fn) {
		this._onTouched = fn;
	}

	setDisabledState(isDisabled: boolean): void {
		this._disabled = isDisabled;
	}

	private _translateCircle() {
		const circle = document.getElementById(this._divUniqueId) as HTMLElement;

		if (this._checked) {
			circle.style.transform = 'translate(' + this._buttonWidth + ')';
		} else {
			circle.style.transform = 'translate(0)';
		}
	}

	public onChangeEvent() {
		const buttonBounding = this._button.getBoundingClientRect();
		const circle = document.getElementById(this._divUniqueId) as HTMLElement;
		const circleBounding = circle.getBoundingClientRect();

		if (this._checked) {
			this._startX = buttonBounding.width - circleBounding.width;
		} else {
			this._startX = 0;
		}

		this.change.emit(this._checked);
	}

	public onDrag(event) {
		this._isDrag = true;

		const circle = document.getElementById(this._divUniqueId) as HTMLElement;

		const circleBounding = circle.getBoundingClientRect();
		const buttonBounding = this._button.getBoundingClientRect();

		let positionInitialLeft = 0;
		let positionInitialRight = 0;

		if (!this._checked) {
			positionInitialLeft = event.deltaX + buttonBounding.left;
			positionInitialRight =
				event.deltaX + buttonBounding.left + circleBounding.width;
		} else {
			positionInitialLeft =
				event.deltaX + buttonBounding.right - circleBounding.width;
			positionInitialRight = event.deltaX + buttonBounding.right;
		}

		if (event.deltaX < 0) {
			circle.style.transform = 'translate(0)';
		}
		if (positionInitialRight > buttonBounding.right) {
			circle.style.transform = 'translate(' + this._buttonWidth + ')';
		}

		if (
			positionInitialLeft >= buttonBounding.left &&
			positionInitialRight <= buttonBounding.right
		) {
			this._circle.style.transform =
				'translate(' + (event.deltaX + this._startX) + 'px)';
		}
	}

	public onDragEnd() {
		const buttonBounding = this._button.getBoundingClientRect();
		const circle = document.getElementById(this._divUniqueId) as HTMLElement;
		const circleBounding = circle.getBoundingClientRect();
		const circleMiddle = circleBounding.left + circleBounding.width / 2;
		const buttonMiddle = buttonBounding.left + buttonBounding.width / 2;

		if (circleMiddle > buttonMiddle) {
			this._checked = true;
			circle.style.transform = 'translate(' + this._buttonWidth + ')';
			this._startX = buttonBounding.width - circleBounding.width;
		} else {
			this._checked = false;
			circle.style.transform = 'translate(0)';
			this._startX = 0;
		}
		this.onChangeEvent();
	}

	public avoidPropagation(event) {
		if (this._isDrag) {
			this._isDrag = false;
			event.stopPropagation();
		} else {
			return;
		}
	}

	public onClick() {
		this._checked = !this._checked;
		this._translateCircle();
		this.onChangeEvent();
	}

	ngAfterViewInit(): void {
		this._button = document.getElementById(this._buttonUniqueId);
		this._rect = this._button.getBoundingClientRect();
		this._circle = document.getElementById(this._divUniqueId) as HTMLElement;
		const circleBounding = this._circle.getBoundingClientRect();

		if (!this._checked) {
			this._startX = 0;
		} else {
			this._startX = this._rect.width - circleBounding.width;
		}
	}

	ngOnChanges(changes: SimpleChanges): void {
		if (changes.hasOwnProperty('disabled')) {
			if (changes.disabled.currentValue !== '') {
				if (typeof changes.disabled.currentValue === 'boolean') {
					this._disabled = changes.disabled.currentValue;
				} else {
					this._disabled = changes.disabled.currentValue === 'true';
				}
			}
		}

		if (changes.hasOwnProperty('checked')) {
			if (changes.checked.currentValue !== '') {
				if (typeof changes.checked.currentValue === 'boolean') {
					this._checked = changes.checked.currentValue;
				} else {
					this._checked = changes.checked.currentValue === 'true';
				}
			}
		}
	}
}
