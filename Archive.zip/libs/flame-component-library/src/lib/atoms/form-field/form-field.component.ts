import {
	AfterContentInit,
	Component,
	ContentChild,
	HostBinding,
	ViewEncapsulation,
	Input
} from '@angular/core';

import { InputDirective } from '../input/input.directive';
import { NgControl } from '@angular/forms';

@Component({
	selector: 'sn-form-field',
	templateUrl: './form-field.component.html',
	styleUrls: ['./form-field.component.scss'],
	host: {
		'[class.ng-untouched]': '_shouldForward("untouched")',
		'[class.ng-touched]': '_shouldForward("touched")',
		'[class.ng-pristine]': '_shouldForward("pristine")',
		'[class.ng-dirty]': '_shouldForward("dirty")',
		'[class.ng-valid]': '_shouldForward("valid")',
		'[class.ng-invalid]': '_shouldForward("invalid")',
		'[class.ng-pending]': '_shouldForward("pending")'
	},
	encapsulation: ViewEncapsulation.Emulated
})
export class FormFieldComponent implements AfterContentInit {
	public hasText: boolean;
	public _clearBtnVisible: boolean;

	constructor() {}

	@Input() clearable = false;
	@Input() label = '';
	@Input() apparence: string;
	@Input() floatLabelAnimate: string;
	@Input() readOnly = false;
	@Input() autoFocus = false;
	@ContentChild(InputDirective)
	private _input: InputDirective;

	@HostBinding('class.sn-form-field')
	get formField() {
		return true;
	}

	@HostBinding('class.sn-form-field-focused')
	get isInputFocused() {
		return this._input ? this._input.focused : false;
	}

	@HostBinding('class.sn-form-field-disabled')
	get isInputDisabled() {
		return this._input && this._input.disabled !== false ? true : false;
	}

	@HostBinding('class.sn-form-field-should-float')
	get inputShouldFloat() {
		if (this.clearable && this._input.value !== '') {
			this._clearBtnVisible = this._input.shouldLabelFloat;
		}
		return this._input ? this._input.shouldLabelFloat : false;
	}

	@HostBinding('class.sn-form-field-invalid')
	get inputInvalid() {
		return this._input ? this._input.invalid : false;
	}
	@HostBinding('attr.autofocus')
	get inputFocus() {
		return this._input ? this._input.focus : false;
	}

	ngAfterContentInit() {
		if (!this._input) {
			throw new Error(
				`Initialization, you must pass a <input> element with proper attribute 'sn-input' between a <sn-form-field> tag`
			);
		} else {
			if (this._input.placeholder) {
				this.label = this._input.placeholder;
			}
			if (this._input.value) {
				// this._input.focused = true;
				this.hasText = true;
			}
			if (this.clearable && this.hasText) {
				this._clearBtnVisible = true;
			}
		}
	}

	/** Determina si una clase de NgControl debe reenviarse al elemento host. */
	_shouldForward(prop: keyof NgControl): boolean {
		const ngControl = this._input ? this._input.ngControl : null;
		return ngControl && ngControl[prop];
	}

	_clearInputField() {
		if (this._clearBtnVisible) {
			this._clearBtnVisible = false;
			if (this._input.value !== '') {
				this._input.value = '';
				this._input.focus();
			}
		}
	}
}
