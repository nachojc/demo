import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import {
	trigger,
	state,
	style,
	animate,
	transition,
	keyframes,
	AnimationBuilder
} from '@angular/animations';
@Component({
	selector: 'sn-avatar',
	templateUrl: './avatar.component.html',
	styleUrls: ['./avatar.component.scss'],
	animations: [
		trigger('selectedButton', [
			transition('normal => selection', [
				animate(
					'200ms',
					keyframes([
						style({ transform: 'scale3d(1, 1, 1)', offset: 0 }),
						style({ transform: 'scale3d(1.1, 1.1, 1.1)', offset: 0.5 }),
						style({ transform: 'scale3d(1, 1, 1)', offset: 1.0 })
					])
				)
			])
		]),
		trigger('fadeOutComponent', [
			state(
				'normal',
				style({
					opacity: 1
				})
			),
			state(
				'fadeOut',
				style({
					opacity: 0
				})
			),
			transition('normal => fadeOut', [animate('200ms')])
		]),
		trigger('fadeOutName', [
			state(
				'normal',
				style({
					opacity: 1
				})
			),
			state(
				'fadeOut',
				style({
					opacity: 0
				})
			),
			transition('normal => fadeOut', [animate('200ms')])
		]),
		trigger('avatarOneInfoOut', [
			state('in', style({})),
			state(
				'out',
				style({
					opacity: 0,
					transform: 'translateY(150px)'
				})
			),
			transition('in => out', [animate('500ms')])
		]),
		trigger('avatarOneCloseButtonOut', [
			state('in', style({})),
			state(
				'out',
				style({
					opacity: 0
				})
			),
			transition('in => out', [animate('500ms')])
		])
	]
})
export class AvatarComponent implements OnInit {
	// Variables privadas
	private _fullname: string;
	private _imgsrc: string;
	private _typeavatar: number;
	private _id: string;
	private _translation = 'translateX(0px)';
	private _controlAnimationComponent = 'normal';

	// Inputs
	@Input()
	get imgsrc(): string {
		return this._imgsrc;
	}
	set imgsrc(value: string) {
		this._imgsrc = value;
		if (value) {
			this.have_imageavatar = true;
		}
	}

	@Input()
	get fullname(): string {
		return this._fullname;
	}
	set fullname(value: string) {
		this._fullname = value;
		this.render_name =
			value.split(' ').length >= 2 ? `${value.split(' ')[0]}` : value;
		this.render_lastname =
			value.split(' ').length >= 2 ? `${value.split(' ')[1]}` : value;
		this.render_namewithoutavatar =
			value.split(' ').length > 1
				? `${value.split(' ')[0][0]}${value.split(' ')[1][0]}`
				: value;
	}

	@Input() shortname: string;
	@Input() bank: string;
	@Input() accountnumber: number;
	@Input()
	set typeavatar(value: number) {
		if (value < 0 || value > 5) {
			this._typeavatar = 0;
		} else {
			this._typeavatar = value;
		}
	}
	get typeavatar(): number {
		return this._typeavatar;
	}
	@Input() description: string;
	@Input() clientcode: string;
	@Input()
	get id(): string {
		return `avatar-${this._id}`;
	}
	set id(value: string) {
		this._id = value;
	}
	@Input() withCloseEvent = false;
	@Input()
	set translation(value: string) {
		this._translation = `translateX(${value}px)`;
	}
	get translation(): string {
		return this._translation;
	}
	@Input()
	set controlAnimationComponent(value: string) {
		this._controlAnimationComponent = value;
	}
	get controlAnimationComponent(): string {
		return this._controlAnimationComponent;
	}

	// Outputs
	@Output() selectedEvent = new EventEmitter<object>();
	@Output() animationEvent = new EventEmitter<string>();

	// Variables
	public render_name: string;
	public render_lastname: string;
	public render_namewithoutavatar: string;
	private positionelement: Array<Number>;

	// Control
	public have_imageavatar = false;
	public selected = false;
	public dissapearTextName = false;
	public canClose = false;

	// Animation Control
	public animationSelectedButton = 'normal';
	public animationFadeText = 'normal';
	public animationFadeInfo = 'default';

	constructor(private animationBuilder: AnimationBuilder) {}

	ngOnInit() {
		if (this.typeavatar === undefined) {
			this.typeavatar = 0;
			console.warn(
				'Tienes que especificar un tipo de avatar, por defecto es: 0'
			);
		} else {
			if (this.typeavatar === 1) {
				setTimeout(() => {
					this.translation = '0';
					this.animationFadeInfo = 'in';
				});
			}
		}
		if (this.withCloseEvent) {
			this.selected = true;
		}
	}

	endTransitionEvent(evento: Event) {
		this.canClose = true;
		this.animationEvent.emit('canInteract');
	}

	prepareEvent() {
		this.selected = !this.selected;
		this.animationSelectedButton =
			this.selected && this.animationSelectedButton === 'normal'
				? 'selection'
				: 'normal';
		const temporal_rect = document
			.getElementById(this.id)
			.getBoundingClientRect();
		this.selectedEvent.emit({
			id: this.id,
			positionelement: temporal_rect,
			selected: this.selected,
			fullname: this.fullname,
			bank: this.bank,
			accountnumber: this.accountnumber,
			shortname: this.shortname,
			imgsrc: this.imgsrc
		});
	}

	selectedPerson() {
		if (!this.withCloseEvent) {
			if (!this.selected) {
				this.prepareEvent();
			}
		}
	}

	closeEvent() {
		if (this.canClose && this.animationFadeInfo === 'in') {
			this.prepareEvent();
			if (this.typeavatar === 1) {
				this.animationFadeInfo = 'out';
			}
		}
	}

	onSelectionAnimationStart(event: any) {
		if (this.animationFadeInfo === 'out') {
			this.animationEvent.emit('StartOutAvatarOne');
		}
	}

	onSelectionAnimationDone(event: any) {
		if (
			event.triggerName === 'selectedButton' &&
			event.toState === 'selection'
		) {
			this.animationFadeText = 'fadeOut';
			this.animationEvent.emit('fadeComponents');
		} else if (
			event.triggerName === 'fadeOutName' &&
			event.toState === 'fadeOut'
		) {
			this.animationEvent.emit('fadeOutText');
		} else if (
			event.triggerName === 'fadeOutComponent' &&
			event.toState === 'fadeOut'
		) {
			this.animationEvent.emit('ComponentFaded');
		} else if (
			(event.triggerName === 'avatarOneInfoOut' ||
				event.triggerName === 'avatarOneCloseButtonOut') &&
			event.toState === 'out'
		) {
			this.animationEvent.emit('OutAvatarOne');
		}
	}
}
