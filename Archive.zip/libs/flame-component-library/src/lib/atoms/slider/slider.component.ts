import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-slider',
	templateUrl: './slider.component.html',
	styleUrls: ['./slider.component.css']
})
export class SliderComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
