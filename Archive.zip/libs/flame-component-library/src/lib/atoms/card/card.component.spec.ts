import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CardComponent } from './card.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('CardComponent', () => {
	let component: CardComponent;
	let fixture: ComponentFixture<CardComponent>;
	let cardEl: DebugElement;
	let availableEl: HTMLElement;
	let accountEl: HTMLElement;
	let cardComEl: HTMLElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CardComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CardComponent);
		component = fixture.componentInstance;
		// fixture.detectChanges();
		cardEl = fixture.debugElement.query(By.css('sn-card'));
		availableEl = fixture.nativeElement.querySelector('h2');
		accountEl = fixture.nativeElement.querySelector('p');
		cardComEl = fixture.debugElement.query(By.css('div')).nativeElement;
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('should show card for type', () => {
		component.type = 'amex';
		fixture.detectChanges();
		expect(cardComEl.classList).toContain('sn-card');
	});
	it('should flipped', () => {
		expect(component.flipped).toBe(false);
	});
	it('should flipped "true"', () => {
		component.flipped = true;
		fixture.detectChanges();
		expect(component.flipped).toBe(true);
	});
	it('should apply class flipped "true"', () => {
		component.flipped = true;
		fixture.detectChanges();
		expect(cardComEl.classList.contains('flipped'));
	});
	it('should inverse card', () => {
		expect(component.inverse).toBe(false);
	});
	it('should apply class inverse "false"', () => {
		component.inverse = false;
		fixture.detectChanges();
		expect(cardComEl.classList.contains('inverse'));
	});
	it('should apply class inverse "true"', () => {
		component.inverse = true;
		fixture.detectChanges();
		expect(cardComEl.classList.contains('inverse'));
	});
	it('should available card', () => {
		component.available = '578.30';
		expect(component.available).toBe('578.30');
	});
	it('should display a different test amount', () => {
		component.available = '1,299.90';
		fixture.detectChanges();
		expect(availableEl.textContent).toContain('1,299.90');
	});
	it('should currency card', () => {
		component.currency = 'MXN';
		expect(component.currency).toBe('MXN');
	});
	it('should name card', () => {
		component.name = 'American Express';
		expect(component.name).toBe('American Express');
	});
	it('should type card', () => {
		component.type = 'basic';
		expect(component.type).toBe('basic');
	});
	it('should account card', () => {
		component.account = '**** **** **** 4122';
		expect(component.account).toBe('**** **** **** 4122');
	});
	it('should display a different test account', () => {
		component.account = '**** **** **** 4822';
		fixture.detectChanges();
		expect(accountEl.textContent).toContain('**** **** **** 4822');
	});
	it('should dueDate card', () => {
		component.dueDate = '18/22';
		expect(component.dueDate).toBe('18/22');
	});
	it('should dueDate card', () => {
		component.dueDate = '18/22';
		expect(component.dueDate).toBe('18/22');
	});
	it('should cvv card', () => {
		component.dueDate = '900';
		expect(component.dueDate).toBe('900');
	});
});
