import {
	Component,
	OnInit,
	ViewChild,
	TemplateRef,
	Input,
	ViewEncapsulation
} from '@angular/core';

@Component({
	selector: 'sn-card',
	templateUrl: './card.component.html',
	styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
	private _type: string;
	@Input()
	get type(): string {
		return this._type;
	}
	set type(value: string) {
		this._type = value;
	}
	@Input()
	get flipped(): boolean {
		return this._flipped;
	}
	set flipped(value: boolean) {
		this._flipped = value;
	}

	@Input() available: string;
	@Input() name: string;
	@Input() currency: string;
	@Input() account = '**** **** **** 5626';
	@Input() shouldflip: boolean;
	@Input() cvv = '***';
	@Input() dueDate = '**/**';

	public _flipped = false;
	public inverse = false;
	public activeFront: TemplateRef<any>;
	public activeBack: TemplateRef<any>;

	constructor() {}

	ngOnInit() {
		this.shouldflip = this.shouldflip !== undefined;
		this.setTemplate(this._type);
	}

	toggleFlip() {
		if (this.shouldflip) {
			this._flipped = !this._flipped;
		}
	}

	setTemplate(type: string) {
		if (type === 'basic') {
			this.inverse = true;
		}
	}
}
