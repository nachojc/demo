import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-accordion',
	templateUrl: './accordion.component.html',
	styleUrls: ['./accordion.component.scss']
})
export class AccordionComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
