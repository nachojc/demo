import {
	Component,
	AfterViewInit,
	Output,
	EventEmitter,
	Input
} from '@angular/core';

let nextUniqueId = 0;

@Component({
	selector: 'sn-slide-button',
	templateUrl: './slide-button.component.html',
	styleUrls: ['./slide-button.component.scss'],
	host: {
		class: 'sn-slide-button',
		'[attr.id]': 'id',
		'[attr.name]': 'name',
		'[attr.required]': 'required',
		'[attr.disabled]': '_disabled',
		'[class.sn-slide-button-disabled]': '_disabled'
	}
})
export class SlideButtonComponent implements AfterViewInit {
	private _id: string;
	private _name: string;
	private _required = false;
	private _button: any;
	private _div: HTMLElement;
	private _divBounding: ClientRect;
	private _completed = false;
	private _initialWidth: number;
	private _show = true;

	public _disabled = false;
	public buttonUniqueId = `button-${++nextUniqueId}`;
	public divUniqueId = `div-${nextUniqueId}`;

	@Input()
	public get show(): boolean {
		return this._show;
	}
	public set show(value: boolean) {
		this._show = value;
	}

	@Input()
	get id(): string {
		return this._id;
	}
	set id(value: string) {
		this._id = value;
	}

	@Input()
	get name(): string {
		return this._name;
	}
	set name(value: string) {
		this._name = value;
	}

	@Input()
	get required(): boolean {
		return this._required;
	}
	set required(value: boolean) {
		this._required = value;
	}

	@Input()
	get disabled(): boolean {
		return this._disabled;
	}
	set disabled(value) {
		if (!value) {
			this._disabled = true;
		} else {
			if (value.toString() === 'true') {
				this._disabled = true;
			} else {
				this._disabled = false;
			}
		}
	}

	@Output() readonly change: EventEmitter<boolean> = new EventEmitter<
		boolean
	>();

	public setDisabledState(isDisabled: boolean): void {
		this._disabled = isDisabled;
	}

	public onDrag(event) {
		if (!this._completed) {
			const button = document.getElementById(
				this.buttonUniqueId
			) as HTMLElement;
			const buttonBounding = button.getBoundingClientRect();

			const divBounding = this._div.getBoundingClientRect();

			if (event.deltaX < 0) {
				this._button.style.width = this._initialWidth + 'px';
			}

			if (buttonBounding.right > divBounding.right) {
				this._button.style.width = divBounding.width + 'px';
			}

			if (
				buttonBounding.right < divBounding.right &&
				buttonBounding.right >= divBounding.left
			) {
				if (
					event.deltaX + this._initialWidth + buttonBounding.left >=
					buttonBounding.left + this._initialWidth
				) {
					this._button.style.width = event.deltaX + this._initialWidth + 'px';
				}
			}
		}
	}

	public onDragEnd() {
		const buttonBounding = this._button.getBoundingClientRect();

		if (buttonBounding.right === this._divBounding.right) {
			this._completed = true;
			this.change.emit(this._completed);
			this._button = this._show = false;
		} else {
			this._button.style.width = this._initialWidth + 'px';
			this.change.emit(this._completed);
		}
	}

	ngAfterViewInit(): void {
		this._div = document.getElementById(this.divUniqueId);
		this._divBounding = this._div.getBoundingClientRect();

		this._button = document.getElementById(this.buttonUniqueId) as HTMLElement;
		this._initialWidth = this._button.getBoundingClientRect().width;
	}
}
