import { Component, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CarouselModule } from './carousel.module';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

@Component({
	template: `
		<div
			snCarousel
			arrows
			indicators
			swipe
			interval="3000"
			infinity
			autoplay="true"
			#snCarousel="SnCarouselDirective"
			(playing)="onCompleted($event)"
		>
			<div class="row justify-content-center">
				Diapositiva {{ snCarousel.getActivedSlide().id }} de
				{{ snCarousel.slides.length }}
			</div>
			<div snSlide #firstSlide="SnSlideDirective" slideId="1" activated="true">
				<div class="container" *ngIf="firstSlide.activated">
					<div class="row">
						<div class="col-12"><h1>CONTENIDO 1</h1></div>
					</div>
				</div>
			</div>
			<div snSlide slideId="2" #secondSlide="SnSlideDirective">
				<div class="container" *ngIf="secondSlide.activated">
					<div class="row">
						<div class="col-12"><h1>CONTENIDO 2</h1></div>
					</div>
				</div>
			</div>
			<div snSlide slideId="3" #thirdSlide="SnSlideDirective">
				<div class="container" *ngIf="thirdSlide.activated">
					<div class="row">
						<div class="col-12"><h1>CONTENIDO 3</h1></div>
					</div>
				</div>
			</div>
		</div>
		<div class="row justify-content-center">
			<button mr-4 sn-button color="red" (click)="snCarousel.prev()">
				Atrás
			</button>
			<button mr-4 sn-button color="red" (click)="snCarousel.next()">
				Siguiente
			</button>
			<button
				mr-4
				sn-button
				color="red"
				(click)="snCarousel.selectSlide(secondSlide)"
			>
				Seleccionar
			</button>
		</div>
	`
})
class TestSNCarouselComponent {
	arrow: boolean;
	autoplay: boolean;
	indicators: boolean;
	swipe: boolean;
	interval = 3000;
	sendCount = 0;
}

describe('CarouselComponent', () => {
	let component: TestSNCarouselComponent;
	let fixture: ComponentFixture<TestSNCarouselComponent>;
	let buttonElement: HTMLButtonElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [CommonModule, CarouselModule],
			declarations: [TestSNCarouselComponent]
		}).compileComponents();
		fixture = TestBed.createComponent(TestSNCarouselComponent);
		component = fixture.componentInstance;
	}));

	beforeEach(() => {
		buttonElement = fixture.debugElement.query(By.css('button')).nativeElement;
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('should apply autoplay', () => {
		component.autoplay = true;
		fixture.detectChanges();
		expect(component.autoplay).toBeTruthy();
	});
	it('should indicate arrow True', () => {
		component.arrow = true;
		fixture.detectChanges();
		expect(component.arrow).toBeTruthy();
	});
	it('should indicate arrow False', () => {
		component.arrow = false;
		fixture.detectChanges();
		expect(component.arrow).toBeFalsy();
	});
	it('should indicate Indicators', () => {
		component.indicators = true;
		fixture.detectChanges();
		expect(component.indicators).toBeTruthy();
	});
	it('should indicate Swipe', () => {
		component.swipe = false;
		fixture.detectChanges();
		expect(component.swipe).toBe(false);
	});
	it('should apply Interval', () => {
		component.interval = 2000;
		fixture.detectChanges();
		expect(component.interval).toBe(2000);
	});
});
