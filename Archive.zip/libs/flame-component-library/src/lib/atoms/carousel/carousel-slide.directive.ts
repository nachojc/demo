import { Directive, Input, Output, EventEmitter } from '@angular/core';
import { Slide } from './carousel-slide.interface';

@Directive({
	selector: '[snSlide]',
	exportAs: 'SnSlideDirective'
})
export class SnSlideDirective implements Slide {
	public id: string;

	@Input()
	get slideId(): string {
		return this.id;
	}
	set slideId(value: string) {
		this.id = value;
	}

	@Input() activated = false;
	private set _activated(value: boolean) {
		this.activated = value;
	}
	private get _activated(): boolean {
		return this.activated;
	}

	@Input() completed = false;
	private set _completed(value: boolean) {
		this.completed = value;
	}
	private get _completed(): boolean {
		return this.completed;
	}

	@Output() onActivate = new EventEmitter<Slide>();

	@Output() onDeactivate = new EventEmitter<Slide>();

	@Output() onComplete = new EventEmitter<Slide>();

	activate() {
		this.activated = true;
		this.onActivate.emit(this._activeSlide());
	}

	deactivate() {
		this.activated = false;
		this.onDeactivate.emit(this._activeSlide());
	}

	complete() {
		this.completed = true;
		this.onComplete.emit(this._activeSlide());
	}

	private _activeSlide(): Slide {
		return {
			id: this.id,
			activated: this.activated,
			completed: this.completed
		};
	}
}
