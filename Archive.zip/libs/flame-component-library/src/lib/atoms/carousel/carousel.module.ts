import { NgModule } from '@angular/core';
import { SnSlideDirective } from './carousel-slide.directive';
import { CommonModule } from '@angular/common';
import { SnCarouselDirective } from './carousel.directive';

@NgModule({
	imports: [CommonModule],
	declarations: [SnSlideDirective, SnCarouselDirective],
	exports: [SnSlideDirective, SnCarouselDirective]
})
export class CarouselModule {}
