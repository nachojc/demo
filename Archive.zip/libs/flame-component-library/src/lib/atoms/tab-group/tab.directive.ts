import { Directive, Input, Output, EventEmitter } from '@angular/core';
import { Tab } from './tab.interface';

@Directive({
	selector: '[snTab]',
	exportAs: 'SnTabDirective'
})
export class SnTabDirective implements Tab {
	@Input() id: string;
	private set _id(value: string) {
		this.id = value;
	}
	private get _id(): string {
		return this.id;
	}

	@Input() activated = false;
	private set _activated(value: boolean) {
		this.activated = value;
	}
	private get _activated(): boolean {
		return this.activated;
	}

	@Input() disabled = false;
	private set _disabled(value: boolean) {
		this.disabled = value;
	}
	private get _disabled(): boolean {
		return this.disabled;
	}

	@Output() onComplete = new EventEmitter<Tab>();

	@Output() onDecomplete = new EventEmitter<Tab>();

	@Output() onActivate = new EventEmitter<Tab>();

	@Output() onDeactivate = new EventEmitter<Tab>();

	@Output() onEnable = new EventEmitter<Tab>();

	@Output() onDisable = new EventEmitter<Tab>();

	activate(propagate = true) {
		this._activated = true;
		if (propagate) {
			this.onActivate.emit(this._changeTab());
		}
	}

	deactivate(propagate = true) {
		this._activated = false;
		if (propagate) {
			this.onDeactivate.emit(this._changeTab());
		}
	}

	enable(propagate = true) {
		this._disabled = true;
		if (propagate) {
			this.onEnable.emit(this._changeTab());
		}
	}

	disable(propagate = true) {
		this._disabled = false;
		if (propagate) {
			this.onDisable.emit(this._changeTab());
		}
	}

	private _changeTab(): Tab {
		return {
			id: this._id,
			activated: this._activated,
			disabled: this._disabled
		};
	}
}
