import { NgModule } from '@angular/core';
import { SnTabDirective } from './tab.directive';
import { SnTabGroupDirective } from './tab-group.directive';

@NgModule({
	imports: [],
	declarations: [SnTabGroupDirective, SnTabDirective],
	exports: [SnTabGroupDirective, SnTabDirective]
})
export class TabGroupModule {}
