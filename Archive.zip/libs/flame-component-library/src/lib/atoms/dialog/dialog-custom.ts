import { Type, Directive, ViewContainerRef } from '@angular/core';

@Directive({
	selector: '[sn-custom]'
})
export class DialogDirective {
	constructor(public viewContainerRef: ViewContainerRef) {}
}

export class CustomDialog {
	constructor(public component: Type<any>, public data?: any) {}
}

export interface CustomDialogComponent {
	data: any;
}
