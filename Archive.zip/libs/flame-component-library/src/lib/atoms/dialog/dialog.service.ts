import { Injectable, Injector, ComponentRef } from '@angular/core';
import { OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal, PortalInjector } from '@angular/cdk/portal';

import { DialogComponent } from './dialog.component';
import { DialogReference } from './dialog.reference';
import { CustomDialog } from './dialog-custom';
import { OverlayService } from '../../services/overlay/overlay.service';

interface Buttons {
	label: string;
	type?: 'default' | 'secondary' | 'success' | 'warning' | 'alert';
	class?: 'full' | 'strech' | 'border' | 'link';
	disabled?: boolean;
	flat?: boolean;
	action?: (scope: any) => void;
}

export interface DialogConfig {
	title: string;
	body?: string;
	closeLabel?: string;
	hasBackdrop?: boolean;
	backdropClass?: string;
	panelClass?: string;
	buttons?: Buttons[];
	enableHr?: boolean;
	disabledButton?: boolean;
	maxHeight?: number;
}

const DEFAULT_CONFIG = {
	hasBackdrop: true,
	backdropClass: 'dark-backdrop',
	panelClass: 'tm-file-preview-dialog-panel',
	enableHr: false,
	disabledButton: false,
	maxHeight: 450
};

@Injectable({
	providedIn: 'root'
})
export class DialogService {
	constructor(
		private _injector: Injector,
		private overlayService: OverlayService
	) {}

	open(config: DialogConfig, customComponent?: CustomDialog): DialogReference {
		// Override default configuration
		const dialogConfig = { ...DEFAULT_CONFIG, ...config };

		const overlay: OverlayRef = this.overlayService.createOverlay(dialogConfig);

		// Instantiate remote control
		const dialogRef = new DialogReference(overlay);

		const dialogComponent: DialogComponent = this.attachDialogContainer(
			overlay,
			dialogRef
		);

		dialogComponent.heading = dialogConfig.title;
		dialogComponent.closeLabel = dialogConfig.closeLabel
			? dialogConfig.closeLabel
			: '';
		dialogComponent.buttons = dialogConfig.buttons ? dialogConfig.buttons : [];
		dialogComponent.bodyContent = customComponent || dialogConfig.body;
		dialogComponent.enableHr = dialogConfig.enableHr;
		dialogComponent.disabledButton = dialogConfig.disabledButton;
		dialogComponent.maxHeight = dialogConfig.maxHeight;

		dialogRef.componentInstance = dialogComponent;

		overlay.backdropClick().subscribe(_ => dialogRef.close(true));

		return dialogRef;
	}

	private attachDialogContainer(
		overlay: OverlayRef,
		dialogRef: DialogReference
	): DialogComponent {
		const injector: PortalInjector = this.createInjector(dialogRef);

		const containerPortal = new ComponentPortal(
			DialogComponent,
			null,
			injector
		);
		const containerRef: ComponentRef<DialogComponent> = overlay.attach(
			containerPortal
		);

		return containerRef.instance;
	}

	private createInjector(dialogRef: DialogReference): PortalInjector {
		const injectionTokens = new WeakMap();

		injectionTokens.set(DialogReference, dialogRef);

		return new PortalInjector(this._injector, injectionTokens);
	}
}
