import { NgModule } from '@angular/core';
import { RangeComponent } from './range.component';

@NgModule({
	imports: [],
	declarations: [RangeComponent],
	exports: [RangeComponent]
})
export class RangeModule {}
