import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-textarea',
	templateUrl: './textarea.component.html',
	styleUrls: ['./textarea.component.css']
})
export class TextareaComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
