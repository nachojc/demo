# FlameWorkspace

En este repositorio va a contener todos los proyectos relacionados con la nueva arquitectura front del banco **Santander** en México.

# Primeros pasos
Para facilitar el desarrollo y uso de este repositorio se han centralizado en los [scripts de NPM](https://docs.npmjs.com/misc/scripts) todas las posibles acciones que podemos llevar acabo.

## Acciones

### Instalación

```shell
npm install
```

### Arranque de aplicaciones

**SuperMobile**

*Entorno desarrollo:*

```shell
npm run start:app:local
```

*Entorno certificación:*

```shell
npm run start:app:cert
```

**WebCatalog**

```shell
npm run start:catalog
```

### Construcción de librerías/aplicaciones

**flame-component-library**

```shell
npm run build:lib:components
```

**flame-core-library**

```shell
npm run build:lib:core
```

**super-mobile**

```shell
npm run build:app:super-mobile
```

# Proyectos asociados

## Librerías

### *flame-core-library*
Librería de componentes que agrupan lógica común a los nuevos desarrollos del banco Santander en México.

### *flame-component-library*
Librería de componentes visuales diseñados bajo la línea visual del banco Santander en México.

## Aplicaciones

### *flame-documentation*
Catalogo web de los diferentes componentes que conforman la arquitectura front:

* flame-core-library
* flame-component-library

### *super-mobile*
Desarrollo de la nueva aplicación móvil del banco Santander en México.


