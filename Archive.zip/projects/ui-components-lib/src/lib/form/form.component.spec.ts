import { UIFormComponent } from "./form.component";
import { TestBed, ComponentFixture } from "@angular/core/testing";


describe('UIFormComponent', () => {
  let component: UIFormComponent;
  let fixture: ComponentFixture<UIFormComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ UIFormComponent ],
      imports: [ ]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(UIFormComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
