import { NgModule } from '@angular/core';
import { UIComponentsLibComponent } from './ui-components-lib.component';
import { UIFormComponent } from './form/form.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';


@NgModule({
  imports: [],
  declarations: [
    UIComponentsLibComponent,
    UIFormComponent,
    HeaderComponent,
    FooterComponent
  ],
  exports: [
    UIComponentsLibComponent,
    UIFormComponent,
    HeaderComponent,
    FooterComponent
  ]
})
export class UIComponentsLibModule { }
