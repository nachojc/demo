import { Component } from '@angular/core';

@Component({
  selector: 'san-UI-components-lib',
  template: `
      <san-header></san-header>
      <san-form>
        <header>
          <h4>Page Tracker Component</h4>
        </header>
        <p>This is the body.</p>
      </san-form>
  `,
  styles: []
})
export class UIComponentsLibComponent {


}
