/*
 * Public API Surface of ui-components-lib
 */

export * from './lib/ui-components-lib.component';
export * from './lib/ui-components-lib.module';
