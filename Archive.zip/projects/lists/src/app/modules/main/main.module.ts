import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import { HttpClientModule} from '@angular/common/http';
import { MainComponent } from './main.component';
import { MainRoutingModule } from './main.routing';
import { ModalComponent } from '../../components/modal/modal.component';


@NgModule({
  declarations: [
    MainComponent,
    ModalComponent
  ],
  imports: [
    CommonModule,
    MainRoutingModule,
  ],
  exports: [
    MainComponent
  ],
  providers: [
  ]
})
export class MainModule {
}
