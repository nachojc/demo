import { Input } from '@angular/core';

export class BaseComponent {
  protected _value: string;
  @Input('required') _required = false;
  @Input('disabled') _disabled = false;
  @Input('tabindex') _tabIndex: number;
  @Input('error-message') _errMessage = 'This field has an error!';
  @Input('name') _name: string;
  @Input('value')
  set value(param:any) {
    if(!this._disabled){
      this._value = param;
    }
  }
  get value() {
    return this._value
  }

} 