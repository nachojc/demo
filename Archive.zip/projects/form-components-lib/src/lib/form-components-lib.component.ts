import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'san-form-components-lib',
  template: `
      <form [formGroup]="myForm" (ngSubmit)="onSubmitReact(myForm.value)">
        <san-select [options]="options" label="Select Disabled" formControlName="selectedValue" disabled></san-select>
        <san-select [options]="options" label="Select Required" formControlName="selectedValue" required></san-select>
        <san-input label="First Name" [formControl]="myForm.controls.firstName"></san-input>
        <san-input label="Last Name" formControlName="lastName" required></san-input>
        <san-input label="Age" formControlName="age" disabled></san-input>
        <san-input label="Post Code" formControlName="postCode"></san-input>
        <san-checkbox formControlName="isStudent" label="Is this a student bank account application?" optionValue="Yes" required></san-checkbox>
        <br><br>
        {{ myFormReactive | json }}
        <br><br>
        <san-button type="Submit" value="Button"></san-button>
        <san-button type="Submit" value="Validation Button" [attr.disabled]="!myForm.valid"></san-button>
      </form>

      <form #myForm1="ngForm" (ngSubmit)="onSubmitTemp(myForm1.value)">
        <san-select [options]="options" name="select" tabindex="1" label="Select Disabled" disabled ngModel></san-select>
        <san-select [options]="options" name="select" tabindex="2" label="Select Required" required ngModel></san-select>
        <san-input label="Template" name="firstName1" tabindex="3" ngModel></san-input>
        <san-input label="Template text" name="alpha" tabindex="4" value="aaa" required ngModel></san-input>
        <san-checkbox name="isStudent" tabindex="5" label="Is this a student bank account application?" optionValue="Yes" required ngModel></san-checkbox>
        <br><br>
        {{ myFormTemplate | json }}
        <br><br>
        <san-button type="Submit" value="Button"></san-button>
        <san-button type="Submit" value="Validation Button" [attr.disabled]="!myForm1.valid"></san-button>
      </form>
  `,
  styles: []
})
export class FormComponentsLibComponent implements OnInit {
  myForm: FormGroup;
  options = ['', 'this', 'is', 'my', 'only', 'option']
  myFormReactive: any;
  myFormTemplate: any;


  constructor(private form: FormBuilder) {}

  onSubmitReact(myFormValue) {
    this.myFormReactive = myFormValue;
  }

  onSubmitTemp(myFormValue) {
    this.myFormTemplate = myFormValue;
  }

  ngOnInit() {
    this.myForm = this.form.group ({
      firstName: new FormControl('', [Validators.required, Validators.minLength(3)]),
      lastName: '',
      age: '',
      postCode: '',
      isStudent: '',
      selectedValue: ''
    })
  }
}
