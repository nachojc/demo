import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormComponentsLibComponent } from './form-components-lib.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { InputComponent } from './input/input.component';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { SelectComponent } from './select/select.component';
import { ButtonComponent } from './button/button.component';

describe('FormComponentsLibComponent', () => {
  let component: FormComponentsLibComponent;
  let fixture: ComponentFixture<FormComponentsLibComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ 
        FormComponentsLibComponent,
        InputComponent,
        CheckboxComponent,
        SelectComponent,
        ButtonComponent
      ],
      imports: [ReactiveFormsModule, FormsModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormComponentsLibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
