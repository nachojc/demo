import { Component, Input, EventEmitter, Output } from '@angular/core';
import { BaseComponent } from '../base/base.component';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 'san-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: CheckboxComponent, multi: true }
  ]
})
export class CheckboxComponent extends BaseComponent implements ControlValueAccessor {
  @Input('checked') _checked: boolean;
  @Input() optionValue: string;
  @Input('label') _labelValue: string;
  @Output() selectedValue = new EventEmitter<boolean>();

  propagateChange = (_: any) => { };

  checkHandler(event) {
    if (event.target.checked) {
      this._checked = true;
      this.propagateChange(this._checked);
      this.selectedValue.emit(this._checked);
    } else {
      event.stopPropagation();
      this._checked = false;
      this.propagateChange(this._checked);
      this.selectedValue.emit(this._checked);
    }
  }

  // Start ControlValueAccessor
  writeValue(obj: any): void {
    // throw new Error("Method not implemented.");
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {
    // throw new Error("Method not implemented.");
  }
  // End ControlValueAccessor
}
