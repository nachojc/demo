import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckboxComponent } from './checkbox.component';
import { By } from '@angular/platform-browser';

describe('CheckboxComponent', () => {
  let component: CheckboxComponent;
  let fixture: ComponentFixture<CheckboxComponent>;
  let checkboxEl;
  let spanEl;
  let labelEl;
  let errorEl;

  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckboxComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CheckboxComponent);
    component = fixture.componentInstance;
    checkboxEl = fixture.debugElement.query(By.css('input'));
    labelEl = fixture.debugElement.query(By.css('label'));
    spanEl = fixture.debugElement.query(By.css('.option-value'));
    errorEl = fixture.debugElement.query(By.css('.error'));
  
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the following properties by default', () => {
    expect(component.optionValue).not.toBeNull();
    expect(component._checked).not.toBeNull();
    expect(component._labelValue).not.toBeNull();
  });

  it('checkbox element should be checked if property _checked is true', () => {
    component._checked = true;
    fixture.detectChanges();
    expect(checkboxEl.nativeElement.checked).toEqual(true);

    // e2e
    component._checked = false;
    fixture.detectChanges();
    checkboxEl.nativeElement.click();
    fixture.detectChanges();
    expect(checkboxEl.nativeElement.checked).toEqual(true);
  });


  it('checkbox element should be unchecked if property _checked is false', () => {
    component._checked = false;
    fixture.detectChanges();
    expect(checkboxEl.nativeElement.checked).toEqual(false);

    // e2e
    component._checked = true;
    fixture.detectChanges();
    checkboxEl.nativeElement.click();
    fixture.detectChanges();
    expect(checkboxEl.nativeElement.checked).toEqual(false);
  });

  it('should set the value property when checked', () => {
    component.optionValue = 'Jumanji';
    fixture.detectChanges();
    expect(spanEl.nativeElement.innerHTML).toEqual('Jumanji');
  });

  it('emits the right value to the parent', () => {
    component.selectedValue.subscribe((value) => {
      expect(value).toBe(true);
    });
    checkboxEl.nativeElement.click();
    fixture.detectChanges();
  });

  it('should set the label value', () => {
    component._labelValue = 'Jumanji';
    fixture.detectChanges();
    expect(labelEl.nativeElement.textContent).toContain('Jumanji');
  });

  it('should display a default error if no error message has been passed in', () => {
    expect(component._errMessage).toBe('This field has an error!');
    expect(errorEl.nativeElement.textContent).toEqual('This field has an error!')
  });

  it('should display a customer error when passed in as an attribute', () => {
    component._errMessage = "This field is required."
    fixture.detectChanges();
    expect(errorEl.nativeElement.textContent).toEqual('This field is required.')
  });
});
