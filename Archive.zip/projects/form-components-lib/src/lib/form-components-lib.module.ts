import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormComponentsLibComponent } from './form-components-lib.component';
import { InputComponent } from './input/input.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CheckboxComponent } from './checkbox/checkbox.component';
import { SelectComponent } from './select/select.component';
import { ButtonComponent } from './button/button.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    FormComponentsLibComponent,
    InputComponent,
    CheckboxComponent,
    SelectComponent,
    ButtonComponent
  ],
  exports: [
    FormComponentsLibComponent,
    InputComponent,
    CheckboxComponent,
    SelectComponent,
    ButtonComponent
  ]
})
export class FormComponentsLibModule { }
