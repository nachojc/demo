import { Component, Input, Output, EventEmitter } from '@angular/core';
import { fromEvent, Observable } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { BaseComponent } from '../base/base.component';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 'san-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: InputComponent, multi: true }
  ]
})
export class InputComponent extends BaseComponent implements ControlValueAccessor {

  inputEl = document.getElementsByTagName('input');
  @Input() _debounceTime: number = 0;
  @Input('label') _labelValue: string;
  @Input() placeholder = '';

  @Output() emitValue = new EventEmitter<any>();

  // Setting the debounce time on the input element
  _debounce: Observable<any> = fromEvent(this.inputEl, 'input').pipe(
    debounceTime(this._debounceTime)
  );

  onInputChange() {
    if (!this._disabled) {
      this._debounce.subscribe(() => {
        this.propagateChange(this.value);
      })
    }
  }
  onBlur($event){
    if(!this._disabled) {
      this.emitValue.emit(this.value);
      $event.stopPropagation();
    }
  }
  keydownHandler($event) {
    if (!this._disabled && $event.key === "Enter") {
      this.emitValue.emit(this.value);
      $event.stopPropagation();
    }
  }

  propagateChange = (_: any) => {};

  // Start ControlValueAccessor
  writeValue(value: string): void {
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {
    // throw new Error("Method not implemented.");
  }
  // End ControlValueAccessor
}
