import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputComponent } from './input.component';
import { FormsModule, NG_VALUE_ACCESSOR } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';

describe('InputComponent', () => {
  let component: InputComponent;
  let fixture: ComponentFixture<InputComponent>;
  let inputEl;
  let labelEl;
  let errorEl;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputComponent ],
      imports: [ FormsModule, CommonModule ]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(InputComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    labelEl = fixture.debugElement.query(By.css('label'));
    errorEl = fixture.debugElement.query(By.css('.error'));
    fixture.detectChanges();
  }));


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have all the properties on init', () => {
    expect(component._labelValue).not.toBeNull();
    expect(component.placeholder).toEqual('');
  });

  it('should allow the user to set input value', () => {
    component.value = 'done';
    component.propagateChange(component.value);
    fixture.detectChanges();
    expect(inputEl.nativeElement.getAttribute('ng-reflect-model')).toEqual('done');
  });

  it('should set the input tag placeholder', () => {
    component.placeholder = 'Jumanji';
    fixture.detectChanges();

    expect(inputEl.nativeElement.placeholder).toEqual('Jumanji');
  });

  it('should have class required in input when required is set to true', () => {
    component._required = true;
    fixture.detectChanges();
    expect(inputEl.nativeElement.required).toEqual(true);
  });

  it('should set the label value', () => {
    component._labelValue = 'Jumanji';
    fixture.detectChanges();
    expect(labelEl.nativeElement.textContent).toContain('Jumanji');
  });


  it('should disable the input filed if #disable property is true', () => {
    component.value = 'Jumanji'
    fixture.detectChanges();
    component._disabled = true;
    fixture.detectChanges();
    component.value = 'test'
    fixture.detectChanges();
    expect(inputEl.nativeElement.getAttribute('ng-reflect-model')).toContain('Jumanji');
  });

  it('should emit value to the parent on blur event', () => {
    component.value = 'Jumanji';
    fixture.detectChanges();
    component.emitValue.subscribe(res => {
      expect(res).toEqual('Jumanji');
    });
    inputEl.nativeElement.dispatchEvent(new Event('blur'));
  });

  it('should not emit value to the parent when disabled', () => {
    component._disabled = true;
    fixture.detectChanges();
    component.emitValue.subscribe(res => {
      expect(res).toBeNull();
    });
    inputEl.nativeElement.dispatchEvent(new Event('blur'));
  });

  it('should display star for a required input', () => {
    component._required = true;
    fixture.detectChanges();
    expect(labelEl.nativeElement.innerHTML).toContain('*');
  });

  it('should emit the value when user presses enter', () => {
    component.value = 'jumanji';
    fixture.detectChanges();
    component.emitValue.subscribe(res => {
      expect(res).toEqual('jumanji');
    });
    inputEl.nativeElement.dispatchEvent(new KeyboardEvent("keypress", {"key": "Enter"}));
  })

  // TODO, test debounce
  xit('should set delay on user input when debounce is set', async() => {
    component._debounceTime = 100000000000;
    fixture.detectChanges();

    component.value = 'done'
    fixture.detectChanges();

    component._debounce.subscribe(value => {
      expect(component.value).toEqual("jumanji")
    })

    component.onInputChange();
    // component.onInputChange();
    // console.log(inputEl.nativeElement.getAttribute('ng-reflect-model'));
    // component.propagateChange(component.value);
    // expect(inputEl.nativeElement.getAttribute('ng-reflect-model')).toEqual('done');
  });

  it('should display a default error if no error message has been passed in', () => {
    expect(component._errMessage).toBe('This field has an error!');
    expect(errorEl.nativeElement.textContent).toEqual('This field has an error!')
  });

  it('should display a customer error when passed in as an attribute', () => {
    component._errMessage = "This field is required."
    fixture.detectChanges();
    expect(errorEl.nativeElement.textContent).toEqual('This field is required.')
  });
});
