import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectComponent } from './select.component';
import { EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { By } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

describe('SelectComponent', () => {
  let component: SelectComponent;
  let fixture: ComponentFixture<SelectComponent>;
  let selectEl;
  let labelEl;
  let errorEl;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectComponent ],
      imports: [
        CommonModule,
        FormsModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectComponent);
    component = fixture.componentInstance;
    selectEl = fixture.debugElement.query(By.css('select'));
    labelEl = fixture.debugElement.query(By.css('label'));
    errorEl = fixture.debugElement.query(By.css('.error'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the following properties', async(() => {
    expect(component._options).not.toBeNull();
    expect(component.selectedOption).toEqual(jasmine.any(EventEmitter));
  }));

  it('should set the label value', () => {
    component._labelValue = 'Jumanji';
    fixture.detectChanges();
    expect(labelEl.nativeElement.textContent).toContain('Jumanji');
  });

  it('should return the right amount of options on #select', async(() => {
    component._options = [ 'jumanji', 'hat', 'saruman' ];
    fixture.detectChanges();
    expect(selectEl.nativeElement.childElementCount).toEqual(3);
  }));

  it('user can select an option that is displayed on #select', async(() => {
    component._options = [ 'jumanji', 'hat', 'saruman' ];
    fixture.detectChanges();
    selectEl.nativeElement.value = 'hat'
    fixture.detectChanges();
    selectEl.nativeElement.dispatchEvent(new Event('change'));

    expect(component.value).toEqual('hat');    
  }));

  it('emits the right value after selecting an option on #select', () => {
    component._options = [ 'jumanji', 'hat', 'saruman' ];
    fixture.detectChanges();
    selectEl.nativeElement.value = 'saruman'
    fixture.detectChanges();

    component.selectedOption.subscribe(selectedValue => {
      expect(selectedValue).toEqual('saruman');  
    });
    selectEl.nativeElement.dispatchEvent(new Event('change'));
  });

  it('should display a default error if no error message has been passed in', () => {
    expect(component._errMessage).toBe('This field has an error!');
    expect(errorEl.nativeElement.textContent).toEqual('This field has an error!')
  });

  it('should display a customer error when passed in as an attribute', () => {
    component._errMessage = "This field is required."
    fixture.detectChanges();
    expect(errorEl.nativeElement.textContent).toEqual('This field is required.')
  });
});
