import { Component, Input, Output, EventEmitter, HostListener } from '@angular/core';
import { BaseComponent } from '../base/base.component';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';


@Component({
  selector: 'san-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SelectComponent, multi: true }
  ]
})
export class SelectComponent extends BaseComponent implements ControlValueAccessor {
  @Input('options') _options: any[];
  @Input('label') _labelValue: string;
  @Output() selectedOption = new EventEmitter<any>();

  onChange() {
    this.propagateChange(this.value);
    this.selectedOption.emit(this.value);
  }

  propagateChange = (_: any) => { };

  // Start ControlValueAccessor
  writeValue(value: any): void {
    // throw new Error("Method not implemented.");
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {
    // throw new Error("Method not implemented.");
  }
  // End ControlValueAccessor
}
