import { Component, Output, EventEmitter, Input } from '@angular/core';
import { BaseComponent } from '../base/base.component';

@Component({
  selector: 'san-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent extends BaseComponent {
  @Input() type: string;
  @Input() class: string;
  @Output('click') clickEmit: EventEmitter<any> = new EventEmitter();

  onClick(event: Event) {
    this.eventHandler(event);
  }

  onKeypress(event: KeyboardEvent) {
    if (event.key === 'Enter' || event.key === ' ') {
      this.eventHandler(event);
    }
  }

  private eventHandler(event) {
    if (!this._disabled) {
      this.clickEmit.emit(event);
    } else {
      event.preventDefault();
      event.stopPropagation();
    }
  }
}
