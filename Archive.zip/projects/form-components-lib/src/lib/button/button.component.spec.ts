import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtonComponent } from './button.component';

describe('ButtonComponent', () => {
  let component: ButtonComponent;
  let fixture: ComponentFixture<ButtonComponent>;
  let element;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#disableButton should call an event when clicked', async() => {
    component.clickEmit.subscribe(resEvent => {
      expect(resEvent).toBeTruthy();
      expect(resEvent.type).toEqual('click');
    });
    component.onClick(new MouseEvent('click'));
  });

  it('#disableButton should not call an event when the button has property disabled', async() => {
    component._disabled = true;
    component.clickEmit.subscribe(() => {
      expect(null).toBe(true);
    });
    component.onClick(new MouseEvent('click'));
  });

  it('#disableButton should change _disabled value to true after pressing "Spacebar"', async() => {
    component.clickEmit.subscribe(() => {
      expect(component._disabled).toEqual(true);
    });
    element.dispatchEvent(new KeyboardEvent('keydown', { 'key': ' ' }));
  });

  it('#disableButton should change _disabled value to true after pressing "Enter"', async() => {
    component.clickEmit.subscribe(() => {
      expect(component._disabled).toEqual(true);
    });
    element.dispatchEvent(new KeyboardEvent('keydown', { 'key': 'Enter' }));
  });

  it('#disableButton should not change _disabled value to true after pressing a key other than "Enter" or "Space"', async() => {
    component.clickEmit.subscribe(() => {
      expect(null).toBe(true);
    });
    element.dispatchEvent(new KeyboardEvent('keydown', { 'key': 'Alt' }));
  });
});
