/*
 * Public API Surface of form-components-custom-lib
 */

export * from './lib/form-components-custom-lib.component';
export * from './lib/form-components-custom-lib.module';
