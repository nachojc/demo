import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'san-form-components-custom-lib',
  template: `
    <p>
      form-components-custom-lib works!
    </p>
  `,
  styles: []
})
export class FormComponentsCustomLibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
