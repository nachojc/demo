import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormComponentsCustomLibComponent } from './form-components-custom-lib.component';

describe('FormComponentsCustomLibComponent', () => {
  let component: FormComponentsCustomLibComponent;
  let fixture: ComponentFixture<FormComponentsCustomLibComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormComponentsCustomLibComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormComponentsCustomLibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
