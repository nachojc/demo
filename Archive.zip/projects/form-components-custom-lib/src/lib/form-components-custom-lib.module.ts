import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FormComponentsCustomLibComponent } from './form-components-custom-lib.component';
import { FirstNameComponent } from './first-name/first-name.component';



@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule
  ],
  declarations: [
    FormComponentsCustomLibComponent,
    FirstNameComponent,
  ],
  exports: [
    FormComponentsCustomLibComponent,
    FirstNameComponent
  ]
})
export class FormComponentsCustomLibModule { }
