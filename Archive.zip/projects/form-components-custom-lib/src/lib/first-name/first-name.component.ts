import { Component, Input, Output, EventEmitter, ElementRef, AfterViewInit } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '../../../../../node_modules/@angular/forms';
import { BaseComponent } from '../../../../form-components-lib/src/lib/base/base.component';
import { Observable, fromEvent } from 'node_modules/rxjs';
import { debounceTime } from 'node_modules/rxjs/operators';


@Component({
  selector: 'san-first-name',
  templateUrl: './first-name.component.html',
  styleUrls: ['./first-name.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: FirstNameComponent, multi: true }
  ]
})
export class FirstNameComponent extends BaseComponent implements ControlValueAccessor {
  inputEl = document.getElementsByTagName('input');

  @Input() _debounceTime: number = 0;
  @Input('label') _labelValue = "First Name";
  @Input() placeholder = '';

  @Output() emitValue = new EventEmitter<any>();


  // Setting the debounce time on the input element
  _debounce: Observable<any> = fromEvent(this.inputEl, 'input').pipe(
    debounceTime(this._debounceTime)
  );

constructor(private el: ElementRef){
  super();
  el.nativeElement.setAttribute('required','');
  this._required = true;
}


  onInputChange() {
    if (!this._disabled) {
      this._debounce.subscribe(() => {
        this.propagateChange(this.value);
      })
    }
  }
  onBlur($event){
    if(!this._disabled) {
      this.emitValue.emit(this.value);
      $event.stopPropagation();
    }
  }
  keydownHandler($event) {
    if (!this._disabled && $event.key === "Enter") {
      this.emitValue.emit(this.value);
      $event.stopPropagation();
    }
  }

  propagateChange = (_: any) => {};

  // Start ControlValueAccessor
  writeValue(value: string): void {
  }
  registerOnChange(fn: any): void {
    this.propagateChange = fn;
  }
  registerOnTouched(fn: any): void {
    // throw new Error("Method not implemented.");
  }
  // End ControlValueAccessor

}
