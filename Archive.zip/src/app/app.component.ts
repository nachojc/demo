import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  options = ['1', '2', '3']
  formValue: any;

  onSubmit(formValue) {
    this.formValue = formValue;
  }
}
