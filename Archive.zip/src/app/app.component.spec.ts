import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { FormComponentsLibModule } from 'projects/form-components-lib/src/public_api';
import { UIComponentsLibModule } from 'projects/ui-components-lib/src/public_api';
import { FormsModule } from '@angular/forms';

describe('AppComponent', () => {
  let fixture;
  let app;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      imports: [
        FormComponentsLibModule,
        UIComponentsLibModule,
        FormsModule
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    app = fixture.debugElement.componentInstance;
  }));
  
  it('should create the app', async(() => {
    expect(app).toBeTruthy();
  }));
  
  xit('should import the #form-component-lib properly', async(() => {
    expect(fixture.nativeElement.children["0"].nodeName).toEqual('SAN-FORM-COMPONENTS-LIB');
    expect(fixture.nativeElement.children["0"].innerHTML).toEqual('<p> form-components-lib works! </p>');
  }));
});
