import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { AppComponent } from './app.component';
import { FormComponentsLibModule } from 'form-components-lib';
import { UIComponentsLibModule } from 'UI-components-lib';
import { FormComponentsCustomLibModule } from 'projects/form-components-custom-lib/src/public_api';



@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    FormComponentsLibModule,
    UIComponentsLibModule,
    FormComponentsCustomLibModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
