const shelljs = require('shelljs');
const walk = require('fs-walk');
const ora = require('ora');

const regexTSFile = /(?<!spec|module)\.(ts|tsx)$/;

const spinner = ora(`Generating documentation for ${process.argv[2]}`).start();
walk.walkSync('./libs/' + process.argv[2] + '/src/lib', (basedir, filename) => {
	if (filename.search(regexTSFile) > 0 && filename !== 'index.ts') {
		shelljs.exec(
			`./node_modules/.bin/typedoc --mode modules ${basedir}/${filename} --json ./apps/flame-documentation/src/assets/docs/${basedir}/doc.json --tsconfig ./tools/helpers/tsconfig.json --logger none`
		);
	}
});
spinner.succeed();
