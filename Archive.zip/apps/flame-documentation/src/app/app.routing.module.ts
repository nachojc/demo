import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeViewComponent } from './modules/home/home-view.component';

const routes: Routes = [
	{
		path: '',
		component: HomeViewComponent
	},
	{
		path: 'ui-components',
		loadChildren:
			'./modules/ui-components/ui-components.module#UIComponentsModule'
	},
	{
		path: 'guide',
		loadChildren: './modules/guide/guide.module#GuideModule'
	},
	{
		path: 'core',
		loadChildren: './modules/core/core.module#CoreModule'
	}
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule {}
