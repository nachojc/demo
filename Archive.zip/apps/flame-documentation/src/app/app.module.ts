// NPM Deps
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HammerGestureConfig, HAMMER_GESTURE_CONFIG } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, Injectable } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import {
	FlameFoundationTheme,
	ThemeModule,
	DarkTheme,
	CardNumberModule,
	CapitalizeModule,
	DialogContentModule
} from '@santander/flame-component-library';

// Router
import { AppRoutingModule } from './app.routing.module';

//Components
import { AppComponent } from './app.component';
import { HomeViewComponent } from './modules/home/home-view.component';
import { MenuModule } from './components/menu/menu.module';
import { NavbarModule } from './components/navbar/navbar.module';

import { TokenComponent } from './modules/ui-components/views/atoms/views/dialog-content/token-component/token.component';
import { DialogPaymentsNoConnectionComponent } from './modules/ui-components/views/atoms/views/dialog-content/dialog-payments-no-connection/dialog-payments-no-connection.component';


@Injectable()
export class CustomHammerConfig extends HammerGestureConfig  {
	overrides = {
			'pinch': { enable: false },
			'rotate': { enable: false }
	}
}
@NgModule({
	declarations: [AppComponent, HomeViewComponent],
	imports: [
		AppRoutingModule,
		BrowserModule,
		BrowserAnimationsModule,
		CardNumberModule,
		CapitalizeModule,
		DialogContentModule,
		NgbModule,
		NavbarModule,
		MenuModule,
		ThemeModule.forRoot({
			themes: [DarkTheme, FlameFoundationTheme],
			active: 'dark'
		})
	],
	providers: [
		{
				provide: HAMMER_GESTURE_CONFIG,
				useClass: CustomHammerConfig
		}
	],
	schemas: [CUSTOM_ELEMENTS_SCHEMA],
	entryComponents: [TokenComponent, DialogPaymentsNoConnectionComponent],
	bootstrap: [AppComponent]
})
export class AppModule {}
