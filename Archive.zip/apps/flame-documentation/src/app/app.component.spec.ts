import { NO_ERRORS_SCHEMA } from '@angular/core';
import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { NavbarModule, ThemeModule, FlameFoundationTheme, DarkTheme } from '@santander/flame-component-library';
import { ZurichTheme } from './modules/ui-components/views/atoms/views/theme/zurich.theme';

describe('AppComponent', () => {
	let app: AppComponent;
	let fixture: ComponentFixture<AppComponent>

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [AppComponent],
			imports: [
					NavbarModule,
					ThemeModule.forRoot({
					themes: [FlameFoundationTheme, ZurichTheme, DarkTheme],
					active: 'dark'
				})],
			schemas: [NO_ERRORS_SCHEMA]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AppComponent);
		app = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create the app', () => {
		expect(app).toBeTruthy();
	});

	it('menu should have UI Components', () => {
		expect(app.menu[0].title).toEqual('UI');
		expect(app.menu[0].link).toEqual('ui-components/overview');
	});

	it('menu should have Core Components', () => {
		expect(app.menu[1].title).toEqual('Core');
		expect(app.menu[1].link).toEqual('core/interceptors');
	});

	it('menu should have Guide', () => {
		expect(app.menu[2].title).toEqual('Guide');
		expect(app.menu[2].link).toEqual('guide');
	});
});
