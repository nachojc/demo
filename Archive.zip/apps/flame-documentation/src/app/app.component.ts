import { Component, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'sn-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class AppComponent {
	constructor() {}

	show_forms = false;
	public menu = [
		{
			title: 'Flame Theme',
			link: ''
		},
		{
			title: 'UI Components',
			link: 'ui-components'
		},
		{
			title: 'Core Components',
			link: ''
		},
		{
			title: 'Guide',
			link: ''
		}
	];
}
