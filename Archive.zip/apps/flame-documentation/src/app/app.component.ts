import { Component, ViewEncapsulation, AfterViewInit } from '@angular/core';
import { ThemeService } from '@santander/flame-component-library';

@Component({
	selector: 'sn-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class AppComponent implements AfterViewInit {
	constructor(private _snTheme: ThemeService) {}

	public menu = [
		{
			title: 'UI',
			link: 'ui-components/overview'
		},
		{
			title: 'Core',
			link: 'core/interceptors'
		},
		{
			title: 'Guide',
			link: 'guide'
		}
	];

	ngAfterViewInit() {
		const theme = localStorage.getItem('theme');
		if (theme) {
			this._snTheme.setTheme(theme);
		} else {
			localStorage.setItem('theme', 'dark');
		}
	}
}
