import { PageHeaderModule } from './../../components/page-header/page-header.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MenuSideBarModule } from '../../components/menu-sidebar/menu-sidebar.module';
import { MarkdownModule } from 'ngx-markdown';
// Router
import { CoreRoutingModule } from './core-routing.module';

// Components
import { CoreComponent } from './core.component';
import { InterceptorsViewComponent } from './views/interceptors/interceptors-view.component';

@NgModule({
	imports: [
		CommonModule,
		CoreRoutingModule,
		FormsModule,
		ReactiveFormsModule,
		PageHeaderModule,
		MenuSideBarModule,
		NgbModule,
		MarkdownModule.forRoot()
	],
	declarations: [CoreComponent, InterceptorsViewComponent]
})
export class CoreModule {}
