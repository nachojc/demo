import { Component } from '@angular/core';
import { SubMenu } from '../../components/menu-sidebar/models/sub-menu.model';

@Component({
	selector: 'sn-core',
	templateUrl: './core.component.html',
	styleUrls: ['./core.component.scss']
})
export class CoreComponent {
	constructor() {}
	public openMenu: boolean;
	public menu: Array<SubMenu> = [
		{
			groupName: 'atoms',
			menu: [
				{
					routerLink: '/core/interceptors',
					textContent: 'Interceptores'
				}
			]
		}
	];

	menuChange(status: boolean): void {
		this.openMenu = status;
	}

	closeMenu() {
		this.openMenu = false;
	}
}
