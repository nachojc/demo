import { Component } from '@angular/core';

@Component({
	selector: 'sn-interceptors-view',
	templateUrl: 'interceptors-view.component.html',
	styleUrls: ['interceptors-view.component.scss']
})
export class InterceptorsViewComponent {
	constructor() {}
	public markdown;
}
