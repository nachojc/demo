import { Component, OnInit } from '@angular/core';
import {
	DialogService,
	DialogReference
} from '@santander/flame-component-library';

@Component({
	selector: 'sn-overlay-page',
	templateUrl: './overlay-page.component.html',
	styleUrls: ['./overlay-page.component.scss']
})
export class OverlayPageComponent implements OnInit {
	constructor(private dialog: DialogService) {}

	public stepOne = `import { OverlayModule } from '@santander/flame-core-library';

@NgModule({
  imports: [
    ...
    OverlayModule
  ]
})`;

	public stepTwo = `import { OverlayService } from '@santander/flame-core-library';
import { OverlayReference } from '@santander/flame-core-library/lib/overlay/overlay.reference';

constructor(private dialog: OverlayService) { }

openOverlay() {
  const dialogRef: OverlayReference = this.dialog.open({
    title: 'Overlay de Ejemplo',
    body: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>'
  });
}`;

	public stepThree = `.cdk-overlay-backdrop.cdk-overlay-backdrop-showing {
  &.dark-backdrop {
    background: #000;
    opacity: 0.85 !important;
  }
}`;

	public stepFour = `<button snButton (click)="openOverlay()">Abrir Overlay</button>`;

	ngOnInit() {}

	openOverlay() {
		const dialogRef: DialogReference = this.dialog.open({
			title: 'Overlay de Ejemplo',
			body: `<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</p>`
		});
	}
}
