import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-avatar-page',
	templateUrl: './avatar-page.component.html',
	styleUrls: ['./avatar-page.component.scss']
})
export class AvatarPageComponent implements OnInit {
	public language = 'html';
	public caseOneContent = `<sn-avatar snTheme="flame-foundation" global="true" fullname="Genoveva Paola Romero Camacho" bank="Bancomer" accountnumber="1111 2222 3333 4444" shortname="Aaron GFT" [typeavatar]="0" description="Nuestros ejecutivos te atenderán y resolverán cualquier duda." clientcode="7654890"></sn-avatar>`;
	public caseTwoContent = `<sn-avatar fullname="Genoveva Paola Romero Camacho" bank="Bancomer" accountnumber="1111 2222 3333 4444" shortname="Aaron GFT" [typeavatar]="1" clientcode="7654890"></sn-avatar>`;
	public caseThreeContent = `<sn-avatar fullname="Genoveva Paola Romero Camacho"bank="Bancomer" accountnumber="1111 2222 3333 4444" [typeavatar]="2"></sn-avatar>`;
	public caseFourContent = `<sn-avatar fullname="Genoveva Paola Romero Camacho" [typeavatar]="3" description="Nuestros ejecutivos te atenderán y resolverán cualquier duda."></sn-avatar>`;
	public caseFiveContent = `<sn-avatar fullname="Genoveva Paola Romero Camacho" [typeavatar]="5" clientcode="7654890"></sn-avatar>`;
	public caseSixContent = `<sn-avatar fullname="Genoveva Paola Romero Camacho" [typeavatar]="4" clientcode="7654890"></sn-avatar>`;
	public caseSevenContent = `<sn-avatar fullname="Genoveva Paola Romero Camacho" imgsrc="https://upload.wikimedia.org/wikipedia/commons/thumb/3/30/Reuni%C3%B3n_con_el_Presidente_Electo%2C_Andr%C3%A9s_Manuel_L%C3%B3pez_Obrador_8_%28cropped%29.jpg/240px-Reuni%C3%B3n_con_el_Presidente_Electo%2C_Andr%C3%A9s_Manuel_L%C3%B3pez_Obrador_8_%28cropped%29.jpg" [typeavatar]="4" clientcode="7654890"></sn-avatar>`;
	constructor() {}

	ngOnInit() {}
}
