import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-spinner-page',
	templateUrl: './spinner-page.component.html',
	styleUrls: ['./spinner-page.component.scss']
})
export class SpinnerPageComponent implements OnInit {
	constructor() {}

	public language = 'html';
	public caseOneContent = `<sn-spinner></sn-spinner>`;
	public caseTwoContent = `<sn-spinner inverse></sn-spinner>`;
	public caseThreeContent = `<sn-spinner type="small"></sn-spinner>`;
	public caseFourContent = `<sn-spinner type="small" inverse></sn-spinner>`;

	ngOnInit() {}
}
