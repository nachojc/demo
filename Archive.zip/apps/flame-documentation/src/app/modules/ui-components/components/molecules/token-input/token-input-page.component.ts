import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-token-input-page',
	templateUrl: './token-input-page.component.html',
	styleUrls: ['./token-input-page.component.scss']
})
export class TokenInputPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
