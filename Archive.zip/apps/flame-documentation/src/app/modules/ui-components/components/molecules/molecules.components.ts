import { BottomSheetDialogPageComponent } from './bottom-sheet-dialog/bottom-sheet-dialog-page.component';
import { NavbarPageComponent } from './navbar/navbar-page.component';
import { ProductPageComponent } from './product/product-page.component';
import { SelectDialogPageComponent } from './select-dialog/select-dialog-page.component';
import { SideMenuPageComponent } from './side-menu/side-menu-page.component';
import { SnackbarPageComponent } from './snackbar/snackbar-page.component';
import { TokenInputPageComponent } from './token-input/token-input-page.component';
import { TopBarPageComponent } from './top-bar/top-bar-page.component';

export const MOLECULES_COMPONENTS = [
	BottomSheetDialogPageComponent,
	NavbarPageComponent,
	ProductPageComponent,
	SelectDialogPageComponent,
	SideMenuPageComponent,
	SnackbarPageComponent,
	TokenInputPageComponent,
	TopBarPageComponent
];
