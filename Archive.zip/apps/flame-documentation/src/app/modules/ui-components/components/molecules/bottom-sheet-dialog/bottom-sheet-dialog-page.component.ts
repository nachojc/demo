import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-bottom-sheet-dialog-page',
	templateUrl: './bottom-sheet-dialog-page.component.html',
	styleUrls: ['./bottom-sheet-dialog-page.component.scss']
})
export class BottomSheetDialogPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
