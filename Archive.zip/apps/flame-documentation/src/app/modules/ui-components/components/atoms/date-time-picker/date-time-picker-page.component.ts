import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-date-time-picker-page',
	templateUrl: './date-time-picker-page.component.html',
	styleUrls: ['./date-time-picker-page.component.scss']
})
export class DateTimePickerPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
