import { Component } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
	selector: 'sn-switch-page',
	templateUrl: './switch-page.component.html',
	styleUrls: ['./switch-page.component.scss']
})
export class SwitchPageComponent {
	constructor() {}

	public language = 'html';

	public caseOneContent = `<sn-slide-toggle labelPosition="left">Slide me!</sn-slide-toggle>`;

	public caseChecked = `<sn-slide-toggle labelPosition="right" checked>Slide me!</sn-slide-toggle>`;

	public caseDisabled = `<sn-slide-toggle disabled> </sn-slide-toggle>`;

	public caseIdName = `<sn-slide-toggle id="first-toggle" name="notification-toggle"></sn-slide-toggle>`;

	public caseFormDOM = `<form [formGroup]="profileForm">
  <sn-form-field>
    <input sn-input type="text" id="firstname" formControlName="firstName" placeholder="First Name" />
  </sn-form-field>
  <sn-form-field>
    <input sn-input type="text" id="lastName" formControlName="lastName" placeholder="Last Name" />
  </sn-form-field>
  <div class="col-12">
    <sn-slide-toggle formControlName="toggleControl"> Remenber me</sn-slide-toggle>
  </div>
</form>
<button (click)="this.alertOutput('Valid form')" color="red" [disabled]="!profileForm.valid">SEND</button>`;

	public caseForm = `
    profileForm = new FormGroup({
      firstName: new FormControl('', Validators.required),
      lastName: new FormControl('', [Validators.minLength(3), Validators.required]),
      toggleControl: new FormControl(true, Validators.required)
    });
  `;

	public profileForm = new FormGroup({
		firstName: new FormControl('', Validators.required),
		lastName: new FormControl('', [
			Validators.minLength(3),
			Validators.required
		]),
		toggleControl: new FormControl(true, Validators.required)
	});

	public alertOutput(message) {
		alert(message);
	}
}
