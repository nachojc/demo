import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-product-page',
	templateUrl: './product-page.component.html',
	styleUrls: ['./product-page.component.scss']
})
export class ProductPageComponent implements OnInit {
	constructor() {}

	public caseOneContent = `<sn-product
  account="32**2345"
  amount="58.99"
  currency="MXN"
  displayName="Súper Digital"
  type="./assets/icons/card-basic.svg">
</sn-product> `;

	ngOnInit() {}
}
