import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-select-dialog-page',
	templateUrl: './select-dialog-page.component.html',
	styleUrls: ['./select-dialog-page.component.scss']
})
export class SelectDialogPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
