import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
	selector: 'sn-input-page',
	templateUrl: './input-page.component.html',
	styleUrls: ['./input-page.component.scss']
})
export class InputPageComponent implements OnInit {
	constructor() {}

	public language = 'html';
	public languagejs = 'js';

	public caseOneContent = `<sn-form-field>
  <input sn-input type="text" id="firstname" placeholder="Nombre" required autofocus/>
  <div sn-hint>Ingrese solo primer nombre</div>
</sn-form-field>`;

	public caseTwoContent = `<sn-form-field>
  <input sn-input type="text" id="lastname" placeholder="Apellidos" disabled value="Sanchez"/>
  <div sn-hint>Ambos</div>
</sn-form-field>`;

	public caseThreeContent = `<sn-form-field>
  <input sn-input type="number" id="age" placeholder="Edad" max="130" min="18" step="1"/>
  <div sn-hint>No mentir en la edad</div>
</sn-form-field>`;

	public caseFourContent = `<sn-form-field>
  <input sn-input type="email" id="email" label="Email" required/>
</sn-form-field>`;

	public caseFiveContent = `<sn-form-field>
  <input
    sn-input
    type="text"
    id="rfc"
    placeholder="RFC"
    pattern="([A-Z,Ñ,&]{3,4}([0-9]{2})(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])[A-Z|\d]{3})"/>
  <div sn-hint>Con homoclave</div>
</sn-form-field>`;

	public caseSixContent = `<sn-form-field>
  <input sn-input type="password" id="password" placeholder="Password" minlength="6" required/>
  <div sn-hint>Mínimo 6 caracteres</div>
</sn-form-field>`;

	public caseSevenContent = `<form action="" class="" novalidate [formGroup]="simpleForm">
  <sn-form-field>
    <input sn-input id="rftext" label="Nombre Completo" formControlName="name" />
    <div sn-hint>Mínimo 2 caracteres</div>
  </sn-form-field>
</form>`;

	public caseSevenJavascript = `simpleForm: FormGroup;

ngOnInit() {
  this.simpleForm = new FormGroup ({
      name: new FormControl('Jack Sparrow', [Validators.minLength(2), Validators.required])
  });
}`;

	simpleForm: FormGroup;

	ngOnInit() {
		this.simpleForm = new FormGroup({
			name: new FormControl('Jack Sparrow', [
				Validators.minLength(2),
				Validators.required
			])
		});
	}
}
