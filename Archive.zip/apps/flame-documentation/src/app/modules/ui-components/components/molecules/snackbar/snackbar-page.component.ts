import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-snackbar-page',
	templateUrl: './snackbar-page.component.html',
	styleUrls: ['./snackbar-page.component.scss']
})
export class SnackbarPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
