export class CodeStrings {
	public data = {
		one: `<sn-form-field hintLabel="Ingrese solo el primer nombre">
  <input sn-input placeholder="Nombre" required autofocus [formControl]="nameControl" />
  <div sn-error *ngIf="nameControl.hasError('required')">
    Por favor ingrese un nombre.
  </div>
</sn-form-field>`,
		two: `<sn-form-field hintLabel="Ambos">
  <input sn-input id="lastname" placeholder="Apellidos" disabled value="Sanchez" />
</sn-form-field>`,
		three: `<sn-form-field hintLabel="No mentir en la edad">
  <input sn-input type="number" id="age" placeholder="Edad" step="1" min="18" max="130" [formControl]="ageControl" />
  <div sn-error *ngIf="ageControl.hasError('max') || ageControl.hasError('min')">
    Por favor ingrese una edad dentro del rango.
  </div>
</sn-form-field>`,
		four: `<sn-form-field>
  <input sn-input type="email" id="email" placeholder="Email" required [formControl]="emailControl" />
  <div sn-error *ngIf="emailControl.hasError('required')">
    Por favor ingrese una email.
  </div>
</sn-form-field>`,
		five: `<sn-form-field hintLabel="Con homoclave">
  <input
  sn-input
  id="rfc"
  placeholder="RFC"
  [ngModel]="patternModel"
  #rfc="ngModel"
  pattern="([A-Z,Ñ,&]{3,4}([0-9]{2})(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])[A-Z|\d]{3})"
  />
  <div sn-error *ngIf="rfc.errors?.pattern">
    Por favor ingrese una RFC válido.
  </div>
</sn-form-field>`,
		six: `<sn-form-field hintLabel="Mínimo 6 caracteres">
  <input sn-input type="password" id="password" [ngModel]="passModel" placeholder="Password" minlength="6" #pass="ngModel" required />
  <div sn-error *ngIf="pass.errors?.required">
      Por favor ingrese un password.
  </div>
  <div sn-error *ngIf="pass.errors?.minlength">
      Por favor ingrese un password válido.
  </div>
</sn-form-field>`,
		seven: `<form>
  <sn-form-field hintLabel="Mínimo 2 caracteres">
    <input sn-input id="rftext" placeholder="Nombre Completo" [formControl]="nameReactControl" required/>
    <div sn-error *ngIf="nameReactControl.hasError('required')">
      Por favor ingrese un nombre.
    </div>
    <div sn-error *ngIf="nameReactControl.hasError('minlength')">
      Por favor ingrese un nombre válido.
    </div>
  </sn-form-field>
</form>`,
		sevenT: `nameReactControl = new FormControl('', [Validators.required, Validators.minLength(2)]);`
	};
}
