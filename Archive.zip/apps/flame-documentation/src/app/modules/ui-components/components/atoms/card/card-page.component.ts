import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-card-page',
	templateUrl: './card-page.component.html',
	styleUrls: ['./card-page.component.scss']
})
export class CardPageComponent implements OnInit {
	constructor() {}

	public caseOneContent = `<sn-card type="amex" available="1,299.90" account="**** **** **** 3901" name="American Express"></sn-card>`;

	public caseTwoContent = `<sn-card type="aero" available="578.30" account="**** **** **** 4122" name="Basic" flipped="true"></sn-card>`;

	public caseThreeContent = `<sn-card type="pref" available="1.10" account="**** **** **** 1234" name="Basic" shouldflip></sn-card>`;

	ngOnInit() {}
}
