import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-button-page',
	templateUrl: './button-page.component.html',
	styleUrls: ['./button-page.component.scss']
})
export class ButtonPageComponent implements OnInit {
	constructor() {}

	public language = 'html';

	public caseOneContent = `<button sn-button>Enviar</button>`;
	public caseTwoContent = `<button sn-button disabled>Deshabilitado</button>`;
	public caseThreeContent = `<a sn-button href="http://www.google.com" target="_blank">Ir a Google</a>`;
	public caseFourContent = `<sn-button>Ejemplo</sn-button>`;
	public caseFiveContent = `<button sn-button class="small">small</button>
<button sn-button class="full">full</button>
<button sn-button class="large">large</button>
<button sn-button class="strech">strech</button>
<button sn-button class="outlined">outlined</button>`;

	ngOnInit() {}
}
