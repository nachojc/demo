import { AvatarPageComponent } from './avatar/avatar-page.component';
import { ButtonPageComponent } from './button/button-page.component';
import { CardPageComponent } from './card/card-page.component';
import { CarouselPageComponent } from './carousel/carousel-page.component';
import { CheckboxPageComponent } from './checkbox/checkbox-page.component';
import { ChipPageComponent } from './chip/chip-page.component';
import { DateTimePickerPageComponent } from './date-time-picker/date-time-picker-page.component';
import { FormFieldPageComponent } from './form-field/form-field-page.component';
import { IconButtonPageComponent } from './icon-button/icon-button-page.component';
import { IconPageComponent } from './icon/icon-page.component';
import { InputPageComponent } from './input/input-page.component';
import { ProgressBarPageComponent } from './progress-bar/progress-bar-page.component';
import { RadioButtonPageComponent } from './radio-button/radio-button-page.component';
import { RadioPageComponent } from './radio/radio-page.component';
import { RangePageComponent } from './range/range-page.component';
import { SlideButtonPageComponent } from './slide-button/slide-button-page.component';
import { SpinnerPageComponent } from './spinner/spinner-page.component';
import { StepperPageComponent } from './stepper/stepper-page.component';
import { SwitchPageComponent } from './switch/switch-page.component';
import { TabsPageComponent } from './tabs/tabs-page.component';
import { TextareaPageComponent } from './textarea/textarea-page.component';
import { ThemePageComponent } from './theme/theme-page.component';
import { TooltipPageComponent } from './tooltip/tooltip-page.component';

export const ATOMS_COMPONENTS = [
	AvatarPageComponent,
	ButtonPageComponent,
	CardPageComponent,
	CarouselPageComponent,
	CheckboxPageComponent,
	ChipPageComponent,
	DateTimePickerPageComponent,
	FormFieldPageComponent,
	IconButtonPageComponent,
	IconPageComponent,
	InputPageComponent,
	ProgressBarPageComponent,
	RadioButtonPageComponent,
	RadioPageComponent,
	RangePageComponent,
	SlideButtonPageComponent,
	SpinnerPageComponent,
	StepperPageComponent,
	SwitchPageComponent,
	TabsPageComponent,
	TextareaPageComponent,
	ThemePageComponent,
	TooltipPageComponent
];
