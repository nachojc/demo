import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-slide-button-page',
	templateUrl: './slide-button-page.component.html',
	styleUrls: ['./slide-button-page.component.scss']
})
export class SlideButtonPageComponent implements OnInit {
	constructor() {}

	public language = 'html';

	public caseOneContent = `<sn-slide-button></sn-slide-button>`;
	public caseTwoContent = `<sn-slide-button disabled="true"></sn-slide-button>`;

	ngOnInit() {}
}
