import { Component } from '@angular/core';

@Component({
	selector: 'sn-carousel-page',
	templateUrl: './carousel-page.component.html',
	styleUrls: ['./carousel-page.component.scss']
})
export class CarouselPageComponent {
	public language = 'html';

	public caseOneContent = `<div snCarousel
  arrows
  indicators
  swipe
  interval="3000"
  infinity
  autoplay="true"
  #snCarousel="SnCarouselDirective"
  (playing)="onCompleted($event)">
  <div class="row justify-content-center">
    Diapositiva {{ snCarousel.getActivedSlide().id }} de {{ snCarousel.slides.length }}
  </div>
  <div snSlide
  #firstSlide="SnSlideDirective"
  slideId="1"
  activated="true">
    <div class="container" *ngIf="firstSlide.activated">
      <div class="row">
        <div class="col-12">
          <h1>CONTENIDO 1</h1>
        </div>
      </div>
    </div>
  </div>
  <div snSlide
  slideId="2"
  #secondSlide="SnSlideDirective">
    <div class="container" *ngIf="secondSlide.activated">
      <div class="row">
          <div class="col-12">
            <h1>CONTENIDO 2</h1>
          </div>
        </div>
      </div>
  </div>
  <div snSlide
  slideId="3"
  #thirdSlide="SnSlideDirective">
    <div class="container" *ngIf="thirdSlide.activated">
      <div class="row">
          <div class="col-12">
            <h1>CONTENIDO 3</h1>
          </div>
        </div>
    </div>
  </div>
</div>
<div class="row justify-content-center">
    <button mr-4 sn-button color="red" (click)="snCarousel.prev()">Atrás</button>
    <button mr-4 sn-button color="red" (click)="snCarousel.next()">Siguiente</button>
    <button mr-4 sn-button color="red" (click)="snCarousel.selectSlide(secondSlide)">Seleccionar</button>
</div>
</div>`;
}
