import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-progress-bar-page',
	templateUrl: './progress-bar-page.component.html',
	styleUrls: ['./progress-bar-page.component.scss']
})
export class ProgressBarPageComponent implements OnInit {
	constructor() {}

	public language = 'html';
	public languagejs = 'js';

	public caseOneContent = `<sn-progress-bar [value]='randomValue'></sn-progress-bar>`;
	public caseTwoContent = `<sn-progress-bar [value]='progressiveValue'></sn-progress-bar>`;
	public caseThreeContent = `<sn-progress-bar value="0.34"></sn-progress-bar>`;
	public caseFourContent = `<sn-progress-bar indeterminate></sn-progress-bar>`;

	public caseTwoScript = `public progressiveValue: number = 0;
setInterval(() => {
  this.progressiveValue = this.progressiveValue < 100 ? this.progressiveValue + 1 : 0;
}, 500);`;

	public randomValue = 0;
	public progressiveValue: number;

	getRandomValue() {
		this.randomValue = Math.ceil(Math.random() * 99 + 1);
	}

	ngOnInit() {
		this.progressiveValue = 0;
		setInterval(() => {
			this.progressiveValue =
				this.progressiveValue < 100 ? this.progressiveValue + 1 : 0;
		}, 500);
	}
}
