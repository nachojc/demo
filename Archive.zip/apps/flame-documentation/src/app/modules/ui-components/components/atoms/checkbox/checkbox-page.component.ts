import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
	selector: 'sn-checkbox-page',
	templateUrl: './checkbox-page.component.html',
	styleUrls: ['./checkbox-page.component.scss']
})
export class CheckboxPageComponent implements OnInit {
	constructor() {}

	public language = 'html';
	public caseOneContent = `<sm-checkbox>Checkbox</sm-checkbox>`;
	public caseTwoContent = `<sm-checkbox checked>Checkbox</sm-checkbox>`;
	public caseThreeContent = `<sm-checkbox disabled>Checkbox</sm-checkbox>`;
	public caseFourContent = `<form>
  <sn-checkbox [(ngModel)]="myTemplateCheckBox" name="myTemplateCheckBox">Checkbox</sn-checkbox>
</form>`;
	public caseFiveContent = `<form [formGroup]="myForm">
  <sn-checkbox formControlName="myReactiveCheckBox">Checkbox</sn-checkbox>
</form>`;

	public myTemplateCheckBox: any;
	public myForm: FormGroup;

	ngOnInit() {
		this.myForm = new FormGroup({
			myReactiveCheckBox: new FormControl(false)
		});
	}
}
