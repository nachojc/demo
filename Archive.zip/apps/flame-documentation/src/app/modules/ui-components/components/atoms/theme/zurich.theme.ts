import { Theme } from '@santander/flame-component-library';

export const ZurichTheme: Theme = {
	name: 'zurich',
	properties: {
		'--sn-theme-primary': '#4066b3',
		'--sn-theme-secondary': '#B39040',
		'--sn-theme-background': '#FFFFFF'
	}
};
