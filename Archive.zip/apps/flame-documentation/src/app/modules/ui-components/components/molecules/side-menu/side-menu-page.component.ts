import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-side-menu-page',
	templateUrl: './side-menu-page.component.html',
	styleUrls: ['./side-menu-page.component.scss']
})
export class SideMenuPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
