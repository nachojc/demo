import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Views
import { OverlayPageComponent } from './views/overlay/overlay-page.component';

// Components
import { ServicesViewComponent } from './services-view.component';
import { LoaderOverlayPageComponent } from './views/loader-overlay/loader-overlay-page.component';

const routes: Routes = [
	{
		path: '',
    	component: ServicesViewComponent,
		children: [
		  {
			path: '',
			redirectTo: 'loader-overlay'
		  },
		  {
			path: 'loader-overlay',
			component: LoaderOverlayPageComponent
		  },
		  {
			path: 'overlay',
			component: OverlayPageComponent
		  },
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AtomsViewRoutingModule {}
