import { Component, ViewEncapsulation } from '@angular/core';
import { SubMenu } from '../../../../components/menu-sidebar/models/sub-menu.model';

@Component({
	selector: 'sn-atoms-view',
	templateUrl: 'atoms-view.component.html',
	styleUrls: ['atoms-view.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class AtomsViewComponent {
	constructor() {}
	public openMenu: boolean;
	public menu: Array<SubMenu> = [
		{
			groupName: 'atoms',
			menu: [
				{
					routerLink: '/ui-components/atoms/avatar',
					textContent: 'Avatar'
				},
				{
					routerLink: '/ui-components/atoms/button',
					textContent: 'Button'
				},
				{
					routerLink: '/ui-components/atoms/card',
					textContent: 'Card'
				},
				{
					routerLink: '/ui-components/atoms/carousel',
					textContent: 'Carousel'
				},
				{
					routerLink: '/ui-components/atoms/checkbox',
					textContent: 'Checkbox'
				},
				{
					routerLink: '/ui-components/atoms/chip',
					textContent: 'Chip'
				},
				{
					routerLink: '/ui-components/atoms/dialog-content',
					textContent: 'Dialog Content'
				},
				{
					routerLink: '/ui-components/atoms/emoji',
					textContent: 'Emoji'
				},
				{
					routerLink: '/ui-components/atoms/form-field',
					textContent: 'Form Field'
				},
				{
					routerLink: '/ui-components/atoms/hidden-button',
					textContent: 'Hidden Buttons'
				},
				{
					routerLink: '/ui-components/atoms/icon',
					textContent: 'Icon'
				},
				{
					routerLink: '/ui-components/atoms/icon-button',
					textContent: 'Icon Button'
				},
				{
					routerLink: '/ui-components/atoms/input',
					textContent: 'Input'
				},
				{
					routerLink: '/ui-components/atoms/progress-bar',
					textContent: 'Progress Bar'
				},
				{
					routerLink: '/ui-components/atoms/radio-button',
					textContent: 'Radio Button'
				},
				{
					routerLink: '/ui-components/atoms/search-bar',
					textContent: 'Search Bar'
				},
				{
					routerLink: '/ui-components/atoms/slide-toggle',
					textContent: 'Slide Toggle'
				},
				{
					routerLink: '/ui-components/atoms/slide-button',
					textContent: 'Slide Button'
				},
				{
					routerLink: '/ui-components/atoms/snackbar',
					textContent: 'Snackbar'
				},
				{
					routerLink: '/ui-components/atoms/spinner',
					textContent: 'Spinner'
				},
				{
					routerLink: '/ui-components/atoms/tabs',
					textContent: 'Tabs'
				},
				{
					routerLink: '/ui-components/atoms/theme',
					textContent: 'Theme'
				},
				{
					routerLink: '/ui-components/atoms/tooltip',
					textContent: 'Tooltip'
				},
				{
					routerLink: '/ui-components/atoms/tag',
					textContent: 'Tag'
				},
				{
					routerLink: '/ui-components/atoms/icon-button-web',
					textContent: 'Icon Button Web'
				},
				{
					routerLink: '/ui-components/atoms/dialog-web',
					textContent: 'Dialog Web'
				},
				{
					routerLink: '/ui-components/atoms/avatar-web',
					textContent: 'AvatarWeb'
				},
				{
					routerLink: '/ui-components/atoms/icon-badge',
					textContent: 'IconBadge'
				},

				{
					routerLink: '/ui-components/atoms/avatar-badge',
					textContent: 'AvatarBadge'
				}
			]
		}
	];

	menuChange(status: boolean): void {
		this.openMenu = status;
	}

	closeMenu() {
		console.log('close menu');
		this.openMenu = false;
	}
}
