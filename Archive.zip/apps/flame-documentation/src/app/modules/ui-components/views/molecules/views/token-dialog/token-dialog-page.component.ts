import { Component, OnInit } from '@angular/core';
import { TokenDialogService,  CustomToken, CustomDialog} from '@santander/flame-component-library';
import { CustomTokenContentComponent, Custom2TokenContentComponent } from './custom-token-content.component';

@Component({
  selector: 'sn-token-dialog-page',
  templateUrl: './token-dialog-page.component.html',
  styleUrls: ['./token-dialog-page.component.scss']
})
export class TokenDialogPageComponent implements OnInit {

  public hideDialogToken = false;
  public language = 'html';
  public language2 = 'ts';
  public caseDirectiveContentOne = `
  <button
    sn-button 
    smTokendialog 
    [statusSlide]="statusSlide" 
    [closedialog]="hideDialogToken" 
    (dialogstate)="dialogTokenEvent($event)" 
    (confirm)="confirmTokenEvent($event)"
    [title]="'Confirma esta operación'"
    [customBody]="customBody"
  >
    Abrir Token Dialog
  </button>
  `;
  
  public caseDirectiveContentTwo = `
  <button
    sn-button 
    smTokendialog 
    [statusSlide]="statusSlide" 
    [closedialog]="hideDialogToken" 
    (dialogstate)="dialogTokenEvent($event)" 
    (confirm)="confirmTokenEvent($event)"
    [subtitle]="'Transferencia sin costo'"
    [showTokenInput]="true"
    [typeButton]="'basic'"
    [customBody]="customBody"
  >
    Abrir Token confirm
  </button>`;

  public caseDirectiveTS = `
  @Component({
    selector: 'sn-custom-html',
    template: \`
        <style>
        .text {
            font-family: SantanderText;
            font-size: 16px;
            line-height: 1.5;
            color: #000000;
            text-align: left;
          }
        </style>
        <div class="text">
            El sistema está a punto de usar nuevamente la clave SuperToken que ya habías introducido.
        </div>
    \`
  })
  export class CustomTokenContentComponent {
  }
  `;

  public caseDirectiveModel = `
  import { CustomTokenContentComponent } from './Url';
  @NgModule({
    entryComponents: [CustomTokenContentComponent],
    declarations: [
      CustomTokenContentComponent
    ]
  })
  `

  public caseDirectiveOperative = `
    import { CustomTokenContentComponent } from './Url';
    public customBody = CustomTokenContentComponent;
  `
  public caseTwoContent = `<button sn-button (click)="abrirDialogo()" > Abrir Token Dialog con Servicio </button>`
  public caseTwoContentPart1 = `  import { NgModule } from '@angular/core';
  import { CommonModule } from '@angular/common';
  import {
    TokenDialogModule,
    TokenDialogService
  } from '@santander/flame-component-library';

  @NgModule({
    declarations: [],
    imports: [ CommonModule, TokenDialogModule ],
    exports: [],
    providers: [TokenDialogService],
  })
  export class FeatureModule {}`;
  public caseTwoContentPart2 = `  constructor(private tokendialogService: TokenDialogService) {
    tokendialogService.getConfirmEvent().subscribe(res=> this.confirmEvent = res);
    tokendialogService.getStateDialog().subscribe(res=> this.stateDialog = res);
  }`;
  public caseTwoContentPart3 = ` 
  import { CustomToken} from '@santander/flame-component-library';
  import { CustomTokenContentComponent } from './Url';
  abrirDialogo(){
    const params: CustomToken = {
      subtitle: 'Transferencia sin costo',
      showTokenInput: true,
      typeButton: 'basic',
      customBody: CustomTokenContentComponent
    }
    this.tokendialogService.openDialogToken(params);
  }`;
  public caseTwoContentPart4 = `  cerrarDialogo(){
    this.tokendialogService.closeDialogToken();
  }`;
  public caseTwoStatusSlide = `  setStatusSlide(status: string) {
    this.tokendialogService.setStatusSlide(status);
  }`;
  public customBody1 = CustomTokenContentComponent;
  
  public caseCustomDialog = `
    public data = {
      amount : '3,500.00'
    }
    public customBody = new CustomDialog(CustomTokenContentComponent, this.data);
  `;

  public data = {
    amount : '3,500.00'
  }

  public caseDirectiveCustomTS = `
    @Component({
      selector: 'sn-custom-html',
      template: \`
          <div class="amountContainer">
              <label class="amount">$</label>
              <label class="amount">{{amount}}</label>
              <label class="currency"> &nbsp;&nbsp;MXN</label>
          </div>
          <div class="line">
          </div>
          <div class="accounts">
            <div class="destination">
              <label class="title">Cuenta destino</label>
              <label class="name">{{destinationAccount.name}}</label>
              <label class="bank">{{destinationAccount.bank}}</label>
              <label class="clabe">{{destinationAccount.CLABE}}</label>
            </div>
            <div class="origin">
              <label class="title">Cuenta origen</label>
              <label class="name">{{originAccount.name}}</label>
              <label class="bank">{{originAccount.account}}</label>
            </div>
          </div>
        \`,
      styleUrls: ['./token-dialog-page.component.scss']
    })
    export class CustomTokenContentComponent implements OnInit, CustomDialogComponent {
      public data: any;
      public amount: string;
      public destinationAccount = {name: 'Felipe Renta', bank: 'BBVA Bancomer', CLABE: 987654321012345678};
      public originAccount = {name: 'Mi nómina', account: '60*0942'};
      
      ngOnInit() {
        this.amount = this.data.amount;
      }
    }
  `;

  public customBody2 = new CustomDialog(Custom2TokenContentComponent, this.data);
 
  public confirmEvent: any;
  public stateDialog: string;
  public statusSlide: string;

  constructor(private tokendialogService: TokenDialogService) {
    tokendialogService.getConfirmEvent().subscribe( res => {
      setTimeout(()=>{ this.setStatusSlide('success') }, 5000);
    });
    tokendialogService.getStateDialog().subscribe(res=> {
      this.stateDialog = res
    });
  }

  ngOnInit(): void { }

  dialogTokenEvent(event: any){
  }

  confirmTokenEvent(data:any){
    this.asignStatusSlide('success',3000);
  }

  asignStatusSlide(status: string, time: number) {
    setTimeout(()=>{ this.statusSlide = status }, time);
  }

  abrirDialogo(){
    const params: CustomToken = {
      subtitle: 'Transferencia sin costo',
      showTokenInput: true,
      typeButton: 'basic',
      customBody: CustomTokenContentComponent
    }
    this.tokendialogService.openDialogToken(params);
  }

  setStatusSlide(status: string) {
    this.tokendialogService.setStatusSlide(status);
  }
}
