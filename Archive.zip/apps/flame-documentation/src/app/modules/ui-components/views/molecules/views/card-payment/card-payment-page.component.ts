import { Component } from '@angular/core';

@Component({
	selector: 'sn-card-payment-page',
	templateUrl: './card-payment-page.component.html',
	styleUrls: ['./card-payment-page.component.scss']
})
export class CardPaymentPageComponent {
	constructor() {}

	public amount;

	public caseOneContent = `
	<card-select (select)="selectCard($event)">
		<sn-card-payment [amount]="812" currency="MXN"">
			Pago Mínimo
		</sn-card-payment>

		<sn-card-payment [amount]="14304" currency="MXN">
			Pago para no generar intereses
		</sn-card-payment>

		<sn-card-payment [amount]="40000" currency="MXN">
			Deuda total
		</sn-card-payment>
	</card-select>
	`;

	public caseTwoContent = `
	<card-select>
		<sn-card-payment [amount]="1300" currency="MXN">
			Pago para no generar intereses
		</sn-card-payment>

		<sn-card-payment [amount]="900" currency="MXN">
			Deuda total
		</sn-card-payment>
	</card-select>
	`;

	public caseThreeContent = `
	<sn-card-select>
		<sn-card-payment [amount]="812" currency="MXN">
			Pago Mínimo
		</sn-card-payment>

		<sn-card-payment [amount]="14304" currency="MXN" [disabled]="true">
			Pago para no generar intereses
		</sn-card-payment>

		<sn-card-payment [amount]="40000" currency="MXN" [disabled]="false">
			Deuda total
		</sn-card-payment>
	</sn-card-select>
	`;

	/**
	 * Emite un evento cuando se selecciona una tarjeta.
	 *
	 * @param {*} event
	 * @memberof PaymentCardPageComponent
	 */
	selectCard(event: any) {
		this.amount = event;
	}
}
