import { Component } from '@angular/core';

@Component({
    selector: 'sn-inversion-page',
    templateUrl: './inversion-page.component.html',
    styleUrls: ['./inversion-page.component.scss']
})


export class InversionPageComponent {



    public caseOneContent = `<sn-inversion
    [inversion]="inversionOne"
></sn-inversion>`;
    
    public inversionOneContent = `public inversionOne: Inversion[] = [
    {term:'1',rate:'1.01'},
    {term:'7',rate:'1.03'},
    {term:'15',rate:'1.05'},
    {term:'30',rate:'1.1'},
    {term:'90',rate:'1.2'},
    {term:'120',rate:'1.3'},
    {term:'180',rate:'1.35'},
    {term:'230',rate:'1.4'},
    {term:'300',rate:'1.6'},
    {term:'365',rate:'1.67'}
]`;

    public caseTwoContent = `<sn-inversion 
    [inversion]="inversionTwo" 
    termFormat="month"
></sn-inversion>`;

public inversionTwoContent = `public inversionTwo = [
    {term:'1', rate:'1.1'},
    {term:'2', rate:'1.12'},
    {term:'3', rate:'1.15'},
    {term:'4', rate:'1.2'},
    {term:'5', rate:'1.25'},
    {term:'6', rate:'1.3'},
    {term:'7', rate:'1.34'},
    {term:'8', rate:'1.38'},
    {term:'9', rate:'1.43'},
    {term:'10', rate:'1.5'},
    {term:'11', rate:'1.55'},
    {term:'12', rate:'1.6'}
]`;

public caseThreeContent = `<sn-inversion 
    [inversion]="inversionOne" 
    [amount]="200000"
></sn-inversion>`;

public caseFourContent = `<sn-inversion
    [inversion]="inversionTwo"
    termFormat="month"
    term="10"
    tooltipMessage="Mensaje customizable"
></sn-inversion>`;

    public inversionOne = [
        {term:'1',rate:'1.01'},
        {term:'7',rate:'1.03'},
        {term:'15',rate:'1.05'},
        {term:'30',rate:'1.1'},
        {term:'90',rate:'1.2'},
        {term:'120',rate:'1.3'},
        {term:'180',rate:'1.35'},
        {term:'230',rate:'1.4'},
        {term:'300',rate:'1.6'},
        {term:'365',rate:'1.67'}
    ]

    public inversionTwo = [
        {term:'1', rate:'1.1'},
        {term:'2', rate:'1.12'},
        {term:'3', rate:'1.15'},
        {term:'4', rate:'1.2'},
        {term:'5', rate:'1.25'},
        {term:'6', rate:'1.3'},
        {term:'7', rate:'1.34'},
        {term:'8', rate:'1.38'},
        {term:'9', rate:'1.43'},
        {term:'10', rate:'1.5'},
        {term:'11', rate:'1.55'},
        {term:'12', rate:'1.6'}
    ]

}