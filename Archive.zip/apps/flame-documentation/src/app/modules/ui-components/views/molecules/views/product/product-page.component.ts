import { Component, OnInit } from '@angular/core';
import { timer } from 'rxjs';

@Component({
	selector: 'sn-product-page',
	templateUrl: './product-page.component.html',
	styleUrls: ['./product-page.component.scss']
})
export class ProductPageComponent implements OnInit {
	public caseOneContent = `<sn-product
    account="32**2345"
    amount="12341234.5112"
    currency="MXN"
    [selectable]=true
    displayName="Súper Digital"
    imageId="75290302460">
  </sn-product> `;

	public caseTwoContent = `<sn-product
    account="32**2345"
    amount="12341234.5112"
    currency="JPY"
    [selectable]=true
    displayName="Súper Digital"
    imageId="75290302460">
  </sn-product>`;

	public caseThreeContent = `<sn-product
    account="32**2345"
    [selectable]=true
    displayName="Súper Digital"
    imageId="75290302460">
  </sn-product>`;
	public caseFourContent = `<sn-product
    account="32**2345"
    [selectable]="true"
    displayName="Súper Digital"
    imageId="75290302460">
  </sn-product>`;

	public caseOneOtherContent = `
  <sn-product
    account="000000 000000 0000"
    accountName="Nombre completo"
    [selectable]="true"
    bank="bbva">
	</sn-product>`;

	public caseTwoOtherContent = `
  <sn-product
    account="000000 000000 0000"
    accountName="Alias"
    displayName="Nombre completo"
    [selectable]="true"
    bank="bbva">
  </sn-product>`;
	public caseThreeOtherContent = `
  <sn-product
    account="000000 000000 0000"
    accountName="Nombre o alias">
  </sn-product>
  `;

	public account: string;
	public displayName: string;

	public caseSkeletonContentHtml = `<sn-product
    account="account"
    [selectable]="true"
    displayName="displayName"
    imageId="75290302460">
  </sn-product>`;

	public caseSkeletonContentTs = `
    ngOnInit() {
      timer(5000).subscribe(() => {
        this.account = '32**2345';
        this.displayName = 'Súper Digital';
      })
    }
  `;

	ngOnInit() {
		timer(5000).subscribe(() => {
			this.account = '32**2345';
			this.displayName = 'Súper Digital';
		});
	}
}
