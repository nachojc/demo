import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
	selector: 'sn-input-page',
	templateUrl: './input-page.component.html',
	styleUrls: ['./input-page.component.scss']
})
export class InputPageComponent implements OnInit {
	public language = 'html';
	public languagejs = 'js';

	public caseOneContent = `<sn-form-field>
      <input sn-input type="text" id="firstname" placeholder="Nombre" required autofocus/>
    </sn-form-field>`;

	public caseTwoContent = `
    <sn-form-field>
      <input sn-input type="text" id="lastname" placeholder="Apellidos" disabled value="Sanchez"/>
    </sn-form-field>`;

	public caseThreeContent = `<sn-form-field>
      <input sn-input type="number" id="age" placeholder="Edad" max="130" min="18" step="1"/>
    </sn-form-field>`;

	public caseFourContent = `<sn-form-field>
      <input sn-input type="email" id="email" label="Email" required/>
    </sn-form-field>`;

	public caseFiveContent = `<sn-form-field>
      <input
        sn-input
        type="text"
        id="rfc"
        placeholder="RFC"
        pattern="([A-Z,Ñ,&]{3,4}([0-9]{2})(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1])[A-Z|\d]{3})"/>
    </sn-form-field>`;

	public caseSixContent = `<sn-form-field>
      <input sn-input type="password" id="password" placeholder="Password" minlength="6" required/>
    </sn-form-field>`;

	public caseSevenContent = `<form action="" class="" novalidate [formGroup]="simpleForm">
      <sn-form-field>
        <input sn-input id="rftext" label="Nombre Completo" formControlName="name" />
      </sn-form-field>
    </form>`;

	public caseSevenJavascript = `simpleForm: FormGroup;
    ngOnInit() {
      this.simpleForm = new FormGroup ({
          name: new FormControl('Jack Sparrow', [Validators.minLength(2), Validators.required])
      });
    }`;

	public caseEightContent = `<sn-form-field>
      <input sn-input type="text" id="city" placeholder="Ciudad" readonly value="Mexico"/>
    </sn-form-field>`;

	public caseNineJavascript = `validateForm: FormGroup;
    ngOnInit() {
      this.validateForm = new FormGroup({
        input: new FormControl('', [
          Validators.minLength(3),
          Validators.required
        ])
      });
    }
    getErrorMessage() {
      return this.validateForm.controls.input.hasError('required') ? 'Debes ingresar un valor' :
          this.validateForm.controls.input.hasError('minlength') ? 'Debe contener por lo menos 3 caracteres' : '';
    }`;

	public caseNineContent = `<form action="" class="" novalidate [formGroup]="validateForm">
    <sn-form-field>
      <input sn-input type="text" id="validator" placeholder="Label" required formControlName="input"/>
      <div sn-error>{{getErrorMessage()}}</div>
    </sn-form-field>
  </form>`;

	simpleForm: FormGroup;
	validateForm: FormGroup;

	ngOnInit() {
		this.simpleForm = new FormGroup({
			name: new FormControl('Jack Sparrow', [
				Validators.minLength(2),
				Validators.required
			])
		});
		this.validateForm = new FormGroup({
			input: new FormControl('', [Validators.minLength(3), Validators.required])
		});
	}

	getErrorMessage() {
		return this.validateForm.controls.input.hasError('required')
			? 'Debes ingresar un valor'
			: this.validateForm.controls.input.hasError('minlength')
			? 'Debe contener por lo menos 3 caracteres'
			: '';
	}
}
