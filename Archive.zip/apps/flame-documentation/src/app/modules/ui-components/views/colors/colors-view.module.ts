import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
	DialogModule,
	LoaderOverlayService,
	LoaderOverlayModule
} from '@santander/flame-component-library';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PrismModule } from '@ngx-prism/core';
import { ButtonModule } from '@santander/flame-component-library';

// Routing
import { ColorsViewRoutingModule } from './colors-view-routing.module';

import { MenuSideBarModule } from '../../../../components/menu-sidebar/menu-sidebar.module';
import { ComponentDocViewerModule } from '../../../../components/component-doc-viewer/component-doc-viewer.module';
import { ColorsViewComponent } from './colors-view.component';
import { PageHeaderModule } from 'apps/flame-documentation/src/app/components/page-header/page-header.module';

@NgModule({
	imports: [
		ColorsViewRoutingModule,
		CommonModule,
		ComponentDocViewerModule,
		DialogModule,
		FormsModule,
		ReactiveFormsModule,
		MenuSideBarModule,
		NgbModule,
		PrismModule,
		PageHeaderModule,
		ButtonModule,
		LoaderOverlayModule
	],
	declarations: [ColorsViewComponent],
	providers: [LoaderOverlayService]
})
export class ColorsViewModule {}
