import { Component, OnInit } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';

@Component({
	selector: 'sn-custom-html',
	template: `
		<style>
			.text {
				font-family: SantanderText;
				font-size: 16px;
				font-weight: normal;
				font-style: normal;
				font-stretch: normal;
				line-height: 1.5;
				letter-spacing: normal;
				color: var(--sn-color__onix, #000000);
				text-align: left;
			}
		</style>
		<div class="text">
			El sistema está a punto de usar nuevamente la clave SuperToken que ya
			habías introducido.
		</div>
	`
})
export class CustomTokenContentComponent {}

@Component({
	selector: 'sn-custom-html',
	template: `
		<div class="amountContainer">
			<label class="amount">$</label>
			<label class="amount">{{ amount }}</label>
			<label class="currency"> &nbsp;&nbsp;MXN</label>
		</div>
		<div class="line"></div>
		<div class="accounts">
			<div class="destination">
				<label class="title">Cuenta destino</label>
				<label class="name">{{ destinationAccount.name }}</label>
				<label class="bank">{{ destinationAccount.bank }}</label>
				<label class="clabe">{{ destinationAccount.CLABE }}</label>
			</div>
			<div class="origin">
				<label class="title">Cuenta origen</label>
				<label class="name">{{ originAccount.name }}</label>
				<label class="bank">{{ originAccount.account }}</label>
			</div>
		</div>
	`,
	styleUrls: ['./token-dialog-page.component.scss']
})
export class Custom2TokenContentComponent
	implements OnInit, CustomDialogComponent {
	public data: any;
	public amount: string;
	public destinationAccount = {
		name: 'Felipe Renta',
		bank: 'BBVA Bancomer',
		CLABE: 987654321012345678
	};
	public originAccount = { name: 'Mi nómina', account: '60*0942' };

	ngOnInit() {
		this.amount = this.data.amount;
	}
}
