import { Component } from '@angular/core';

@Component({
  selector: 'sn-navbar-page',
  templateUrl: './navbar-page.component.html',
  styleUrls: ['./navbar-page.component.scss']
})
export class NavbarPageComponent {

  public active = 2;
  public navbarButtons = [
    {
      'name': 'Mi vida',
      'icon': 'sn-BAN005',
      'disabled': true
    },
    {
      'name': 'Transferencias',
      'icon': 'sn-BAN055',
    },
    {
      'name': 'Productos',
      'icon': 'sn-SMOV009',
    },
    {
      'name': 'Tienda',
      'icon': 'sn-SERV008',
    },
    {
      'name': 'Más',
      'icon': 'sn-FUNC056'
    }
  ];

  public caseOneScript = `public navbarButtons: NavbarElement[] = [{
      'name': 'Mi vida',
      'icon': 'sn-BAN005',
      'disabled': true
    },
    {
      'name': 'Transferencias',
      'icon': 'sn-BAN055',
    },
    {
      'name': 'Productos',
      'icon': 'sn-SMOV009',
    },
    {
      'name': 'Tienda',
      'icon': 'sn-SERV008',
    },
    {
      'name': 'Más',
      'icon': 'sn-FUNC056'
  }];`;

  public caseOneContent = ` <sn-navbar [buttons]="navbarButtons" [active]="active"></sn-navbar> `;

}

