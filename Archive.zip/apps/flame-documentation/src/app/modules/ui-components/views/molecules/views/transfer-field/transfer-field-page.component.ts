import { Component, OnInit } from '@angular/core';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
    selector: 'sn-tranfer-field-page',
    templateUrl: './transfer-field-page.component.html',
    styleUrls: ['./transfer-field-page.component.scss']
})
export class TransferFieldPageComponent implements OnInit {

    public caseOneContent = `<sn-transfer-field
    label="Motivo o concepto">
        <input
            maxlength="20"
            snAutowidthinput
            snRemoveAccents
            [(ngModel)]="motive"
            type="text"
            placeholder="Transferencia"
        />
</sn-transfer-field>

<sn-transfer-field
    label="Ingresa una cantidad en "
    currencySymbol="$"
    currencyCode="MXN">
        <input
            snAutowidthinput
            snCurrencyMask
            [(ngModel)]="amount"
            type="text"
        />
</sn-transfer-field>

<sn-transfer-field
    label="Ingresa la referencia"
    (cameraClicked)="eventCameraClicked()">
        <input
            maxlength="16"
            [(ngModel)]="reference"
            type="text"
            placeholder="0000000000000000"
        />
</sn-transfer-field>`;

    public caseDisabledContent = `<sn-transfer-field
    label="Motivo o concepto">
        <input
            snAutowidthinput
            snRemoveAccents
            [(ngModel)]="motiveDisabled"
            type="text"
            placeholder="Transferencia"
            disabled
        />
</sn-transfer-field>

<sn-transfer-field
    label="Ingresa una cantidad en "
    currencySymbol="$"
    currencyCode="MXN">
        <input
            snAutowidthinput
            snCurrencyMask
            [(ngModel)]="amountDisabled"
            type="text"
            disabled
        />
</sn-transfer-field>

<sn-transfer-field
    label="Ingresa la referencia">
        <input
            maxlength="16"
            snReference
            [(ngModel)]="referenceDisabled"
            type="text"
            placeholder="0000000000000000"
            disabled
        />
</sn-transfer-field>`;

    public caseReadOnlyContent = `<sn-transfer-field
    label="Motivo o concepto">
        <input
            maxlength="30"
            snAutowidthinput
            snRemoveAccents
            [(ngModel)]="motiveReadOnly"
            type="text"
            placeholder="Transferencia"
            readonly
        />
</sn-transfer-field>

<sn-transfer-field
    label="Ingresa una cantidad en"
    currencySymbol="$"
    currencyCode="MXN">
        <input
            snAutowidthinput
            snCurrencyMask
            [(ngModel)]="amountReadOnly"
            type="text"
            readonly
        />
</sn-transfer-field>
<sn-transfer-field
    label="Ingresa la referencia">
        <input
            maxlength="16"
            snReference
            [(ngModel)]="referenceReadOnly"
            type="text"
            placeholder="0000000000000000"
            readonly
        />
</sn-transfer-field>`;

    public caseReadOnlyContentTs = `public amountReadOnly = 15;
public motiveReadOnly = 'Solo lectura'
public referenceReadOnly = '0123456789012345';`;

    public caseFormContent = `<form [formGroup]="form">
    <sn-transfer-field
        label="Motivo o concepto">
        <input
            snAutowidthinput
            snRemoveAccents
            formControlName="motive"
            type="text"
            placeholder="Transferencia"
        />
        <div snErrors="motive">
            <div snError="minlength">
                El motivo debe contener como mínimo 6 carácteres.
            </div>
            <div snError="required">
                *Campo obligatorio
            </div>
            <div snError="pattern">
                Formato inválido
            </div>
        </div>
    </sn-transfer-field>
    <sn-transfer-field
        label="Ingresa una cantidad en"
        currencySymbol="$"
        currencyCode="MXN"
        [cleanContent]="initialAmount">
        <input
            snAutowidthinput
            snCurrencyMask
            formControlName="amount"
            type="text"
        />
        <div snErrors="amount">
            <div snError="max">
                No tienes suficiente dinero.
            </div>
            <div snError="min">
                La cantidad debe de ser mayor a $10.00 MXN.
            </div>
        </div>
    </sn-transfer-field>
    <sn-transfer-field
        label="Ingresa la referencia">
            <input
                maxlength="16"
                snReference
                formControlName="reference"
                type="text"
                placeholder="0000000000000000"
            />
            <div snErrors="reference">
                <div snError="required">
                    *Campo obligatorio
                </div>
            </div>
    </sn-transfer-field>
</form>`;

public caseFormContentTs=`constructor (private formBuilder: FormBuilder) { }

public initialAmount = 10;
public initialMotive = '';
public initialReference = '';

this.form = this.formBuilder.group({
    motive: [
        this.initialMotive,
        [
            Validators.required,
            Validators.minLength(6),
            Validators.pattern('')
        ]
    ],
    amount: [
        this.initialAmount,
        [
            Validators.required,
            Validators.max(10000),
            Validators.min(this.initialAmount)
        ]
    ],
    reference: [
        this.initialReference,
        [
            Validators.required
        ]
    ]
});`;

    public caseDisabledFormContent = `<form [formGroup]="disabledForm">
    <sn-transfer-field
        label="Motivo o concepto">
            <input
                snAutowidthinput
                snRemoveAccents
                formControlName="motive"
                type="text"
                placeholder="Transferencia"
            />
    </sn-transfer-field>
    <sn-transfer-field
        label="Ingresa una cantidad en"
        currencySymbol="£"
        currencyCode="GBP">
            <input
                snAutowidthinput
                snCurrencyMask
                formControlName="amount"
                type="text"
            />
    </sn-transfer-field>
    <sn-transfer-field
        label="Ingresa la referencia">
            <input
                maxlength="16"
                snReference
                formControlName="reference"
                type="text"
                placeholder="0000000000000000"
            />
    </sn-transfer-field>
</form>`;

    public caseDisabledFormContentTs = `constructor(private formBuilder: FormBuilder) { }

public disabledForm: FormGroup;

this.disabledForm = this.formBuilder.group({
    motive: [
        { value: 'Motive disabled', disabled: true }
    ],
    amount: [
        { value: 100, disabled: true }
    ],
    reference: [
        { value: '0123456789012345', disabled: true }
    ]
});`;

    public form: FormGroup;
    public disabledForm: FormGroup;
    public amount = 0;
    public motive = '';
    public reference = '';
    public amountDisabled = 0;
    public motiveDisabled = '';
    public referenceDisabled = '';
    public amountReadOnly = 15;
    public motiveReadOnly = 'Solo lectura';
    public referenceReadOnly = '0123456789012345';
    public initialAmount = 10;
    public initialMotive = '';
    public initialReference = '';

    constructor(private formBuilder: FormBuilder) { }

    eventCameraClicked() {}

    ngOnInit() {
        this.form = this.formBuilder.group({
            motive: [
                this.initialMotive,
                [Validators.required, Validators.minLength(6), Validators.pattern('')]
            ],
            amount: [
                this.initialAmount,
                [Validators.required, Validators.max(10000), Validators.min(this.initialAmount)]
            ],
            reference: [
                this.initialReference,
                [Validators.required]
            ]
        });


        this.disabledForm = this.formBuilder.group({
            motive: [
                { value: 'Motive disabled', disabled: true }
            ],
            amount: [
                { value: 100, disabled: true }
            ],
            reference: [
                { value: '0123456789012345', disabled: true }
            ]
        });
    }
}
