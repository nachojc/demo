import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
	AccountSelectModule,
	IconButtonModule,
	IconModule,
	NavbarModule,
	NotificationModule,
	ProductModule,
	SliderModule,
	SlideToggleModule,
	ThemeModule,
	TokenInputModule,
	TopBarModule,
	TokenDialogModule,
	DialogSelectModule,
	TokenDialogService,
	ErrorsModule,
	SnCurrencyModule,
	ButtonModule,
	InversionModule,
	AutoWidthInputModule,
	RemoveAccentsModule,
	TransferFieldModule,
	CardPaymentModule,
	RadioButtonModule,
	TokenInputWebModule, AvatarWelcomeWebModule
} from '@santander/flame-component-library';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PrismModule } from '@ngx-prism/core';
import { MoleculesViewComponent } from './molecules-view.component';
import { MoleculesViewRoutingModule } from './molecules-view-routing.module';
import { MenuSideBarModule } from '../../../../components/menu-sidebar/menu-sidebar.module';

// Components
import { MOLECULES_COMPONENTS } from './views/molecules.components';
import { ComponentDocViewerModule } from '../../../../components/component-doc-viewer/component-doc-viewer.module';
import {
	CustomTokenContentComponent,
	Custom2TokenContentComponent
} from './views/token-dialog/custom-token-content.component';
import { PageHeaderModule } from 'apps/flame-documentation/src/app/components/page-header/page-header.module';

const LIBRARY_MODULES = [
	AccountSelectModule,
	DialogSelectModule,
	IconButtonModule,
	IconModule,
	NavbarModule,
	NotificationModule,
	ProductModule,
	SliderModule,
	SlideToggleModule,
	ThemeModule,
	TokenInputModule,
	TokenDialogModule,
	TopBarModule,
	ButtonModule,
	TransferFieldModule,
	InversionModule,
	AutoWidthInputModule,
	RemoveAccentsModule,
	CardPaymentModule,
	RadioButtonModule,
	TokenInputWebModule,
	AvatarWelcomeWebModule
];
// TODO jetl: eliminar los modulos de motive y amount cuando se vayan a limpiar
@NgModule({
	imports: [
		...LIBRARY_MODULES,
		CommonModule,
		ComponentDocViewerModule,
		FormsModule,
		MenuSideBarModule,
		MoleculesViewRoutingModule,
		NgbModule,
		PrismModule,
		ReactiveFormsModule,
		ErrorsModule,
		PageHeaderModule,
		SnCurrencyModule.forRoot({
			align: 'right',
			allowNegative: false,
			allowZero: true,
			decimal: '.',
			precision: 2,
			prefix: '',
			suffix: '',
			thousands: ',',
			nullable: true,
			integers: 1
		})
	],
	declarations: [
		...MOLECULES_COMPONENTS,
		MoleculesViewComponent,
		CustomTokenContentComponent,
		Custom2TokenContentComponent
	],
	providers: [TokenDialogService],
	entryComponents: [CustomTokenContentComponent, Custom2TokenContentComponent]
})
export class MoleculesViewModule {}
