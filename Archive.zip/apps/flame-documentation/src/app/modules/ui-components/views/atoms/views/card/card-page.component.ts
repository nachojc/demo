import { Component, OnInit } from '@angular/core';
import { timer } from 'rxjs';
import { CARDS_IMAGE } from '@santander/flame-component-library';

@Component({
	selector: 'sn-card-page',
	templateUrl: './card-page.component.html',
	styleUrls: ['./card-page.component.scss']
})
export class CardPageComponent implements OnInit{
	public caseOneContent = `<sn-card
	imageId="75290302460"
	[available]="1299.90"
	account="************3901"
	name="American Express"
	currency='MXN'
></sn-card>`;

	public caseOneBlockedContent = `<sn-card
	imageId="75290302460"
	[available]="1299.90"
	account="************3901"
	name="American Express"
	currency='MXN'
></sn-card>`;

	public caseTwoContent = `<sn-card
	imageId="75240502451"
	[available]="578.30"
	account="************4122"
	name="Basic"
	flipped="true"
	currency='MXN'
></sn-card>`;

	public caseThreeContent = `<sn-card
	imageId="73210104701"
	[available]="1.10"
	account="************1234"
	name="Basic"
	[flipped]="flipper"
	currency='MXN'
></sn-card>`;

	public caseThreeContentJs=`public flipper = false;
flipCard() {
	this.flipper = !this.flipper;
}`;

	public caseSkeletonContent=`<sn-card
	imageId="75240102450"
	available="0"
	[account]="account"
	name="Basic"
	[flipped]="flipperSkeleton"
	currency='MXN'
></sn-card>
	`;

	public caseSkeletonContentJs=`
	import { timer } from 'rxjs';
	...
	public statusSkeleton = false;
	flipCardSkeleton() {
		timer(20000).subscribe(()=>{
			this.account = '**** **** **** 1234';
		});
	}`;


	public flipper = false;
	public flipperSkeleton = false;
	public statusSkeleton = false;
	public account: string;

	flipCard() {
		this.flipper = !this.flipper;
	}

	toggleCardSkeleton() {
		this.statusSkeleton = !this.statusSkeleton;
	}

	flipCardSkeleton() {
		this.flipperSkeleton = !this.flipperSkeleton;
	}

	ngOnInit(): void {
		timer(20000).subscribe(()=>{
			this.account = '**** **** **** 1234';
		});
	}

	public getImage(code: string, face:string = 'FRONT') {
		const name = CARDS_IMAGE[code] === undefined ? 'MC_BASICA' : CARDS_IMAGE[code];
		let imgURL: string;
		switch(face) {
		  case 'FRONT':
			  imgURL = `url(assets/cards/${name}.svg)`;
			break;
		  case 'BACK':
			  imgURL = `url(assets/cards/${name}_BACK.svg)`;
			break;
		}
		return imgURL;
	  }
}
