import { Component } from '@angular/core';

@Component({
	selector: 'sn-search-bar-page',
	templateUrl: './search-bar-page.component.html'
})
export class SearchBarPageComponent {

public caseOneContent = `<sn-search-bar
  placeholder="Dirección, ciudad ó código postal"
></sn-search-bar>`

public caseTwoContent = `<sn-search-bar
  value="Aielo"
  placeholder="Dirección, ciudad ó código postal"
></sn-search-bar>
`;
}
