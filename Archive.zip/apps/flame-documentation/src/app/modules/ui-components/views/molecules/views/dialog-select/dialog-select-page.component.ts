import { Component } from '@angular/core';

@Component({
	selector: 'sn-dialog-select-page',
	templateUrl: './dialog-select-page.component.html',
	styleUrls: ['./dialog-select-page.component.scss']
})
export class DialogSelectPageComponent {

	public selectedOption = '';

	public caseOneContent = `<sn-dialog-select title="Buscar" closeLabel="Cancelar" mode="arrow"></sn-dialog-select>`;
	public caseTwoContent = `
	<sn-dialog-select
		title="Título"
		subtitle="Subtítulo"
		closeLabel="Cancelar"
		[value]="selectedOption"
		[placeholder]="placeholder"
		[options]="options"
		(onSelection)="select($event)"
	>
	</sn-dialog-select>`;

	public caseTwoContentTs= `public selectedOption = '';

public placeholder = 'Haga click para seleccionar un banco';

public options = [
	{ value:1, name: 'Santander' },
	{ value:2, name: 'BBVA Bancomer' },
	{ value:3, name: 'Banamex' },
	{ value:4, name: 'Banorte' },
	{ value:5, name: 'Scotiabank' },
	{ value:6, name: 'HSBC' },
	{ value:7, name: 'Banco Azteca' },
	{ value:8, name: 'Banregio' },
	{ value:9, name: 'Inbursa' },
	{ value:10, name: 'Banco del Bajío' }
];

public select(ev: any) {
	this.selectedOption = ev.text.name;
}`;

	public placeholder = 'Haga click para seleccionar un banco';

	public options = [
		{ value:1, name: 'Santander' },
		{ value:2, name: 'BBVA Bancomer' },
		{ value:3, name: 'Banamex' },
		{ value:4, name: 'Banorte' },
		{ value:5, name: 'Scotiabank' },
		{ value:6, name: 'HSBC' },
		{ value:7, name: 'Banco Azteca' },
		{ value:8, name: 'Banregio' },
		{ value:9, name: 'Inbursa' },
		{ value:10, name: 'Banco del Bajío' }
	];

	public select(ev: any) {
		this.selectedOption = ev.text.name;
	}
}
