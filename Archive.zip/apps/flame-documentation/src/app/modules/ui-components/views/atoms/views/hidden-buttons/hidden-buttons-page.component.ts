import { Component } from '@angular/core';
import { Button } from '@santander/flame-component-library';

@Component({
  selector: 'sn-hidden-buttons-page',
  templateUrl: './hidden-buttons-page.component.html',
  styleUrls: ['./hidden-buttons-page.component.scss']
})
export class HiddenButtonsPageComponent implements Button {
  id: string;
  name: string;
  icon: string;

  public button: Button[] = [{
    id: '1',
    name: 'Botón',
    icon: 'sn-FUNC071'
  }];

  public buttons: Button[] = [{
    id: '1',
    name: 'Arriba',
    icon: 'sn-SMOV005'
  },
  {
    id: '2',
    name: 'Abajo',
    icon: 'sn-SMOV007'
  }];

  public caseOneContent = `<sn-hidden-buttons [buttons]="button">
    <span content>
        Un botón
    </span>
  </sn-hidden-buttons>`;

  public buttonContent = `public button: Button[] = [{
      id: '1',
      name: 'Botón',
      icon: 'sn-FUNC071'
    }];`;

  public caseTwoContent = `<sn-hidden-buttons [buttons]="buttons">
    <div content>
        Dos botones
    </div>
  </sn-hidden-buttons>`;

  public buttonsContent = `public buttons: Button[] = [{
      id: '1',
      name: 'Arriba',
      icon: 'sn-SMOV005'
    },
    {
      id: '2',
      name: 'Abajo',
      icon: 'sn-SMOV007'
    }];`;
}
