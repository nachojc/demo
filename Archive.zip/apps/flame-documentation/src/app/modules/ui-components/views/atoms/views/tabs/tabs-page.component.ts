import { Component } from '@angular/core';

@Component({
	selector: 'sn-tabs-page',
	templateUrl: './tabs-page.component.html',
	styleUrls: ['./tabs-page.component.scss']
})
export class TabsPageComponent {
 public content = `<sn-tabs>
 <sn-tab tabTitle="Tab Uno">
	 Contenido de Tab Uno
 </sn-tab>
 <sn-tab tabTitle="Tab Dos" active="true">
	 Contenido de Tab Dos
 </sn-tab>
</sn-tabs>`;
}
