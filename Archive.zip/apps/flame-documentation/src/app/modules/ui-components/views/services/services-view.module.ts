import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
	DialogModule,
	LoaderOverlayService,
	LoaderOverlayModule
} from '@santander/flame-component-library';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PrismModule } from '@ngx-prism/core';
import { ButtonModule } from '@santander/flame-component-library';

// Routing
import { AtomsViewRoutingModule } from './services-view-routing.module';

// Components
import { SERVICES } from './views/services';
import { ServicesViewComponent } from './services-view.component';
import { MenuSideBarModule } from '../../../../components/menu-sidebar/menu-sidebar.module';
import { ComponentDocViewerModule } from '../../../../components/component-doc-viewer/component-doc-viewer.module';
import { PageHeaderModule } from 'apps/flame-documentation/src/app/components/page-header/page-header.module';

@NgModule({
	imports: [
		AtomsViewRoutingModule,
		CommonModule,
		ComponentDocViewerModule,
		DialogModule,
		FormsModule,
		ReactiveFormsModule,
		MenuSideBarModule,
		NgbModule,
		PageHeaderModule,
		PrismModule,
		ButtonModule,
		LoaderOverlayModule
	],
	declarations: [...SERVICES, ServicesViewComponent],
	providers: [LoaderOverlayService]
})
export class ServicesViewModule {}
