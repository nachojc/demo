import { Component, ViewChild, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'sn-tooltip-page',
	templateUrl: './tooltip-page.component.html',
	styleUrls: ['./tooltip-page.component.scss']
})
export class TooltipPageComponent {

	@ViewChild('tooltip') tooltip;

	public language = 'html';

	public caseOneContent = `<button sn-button snTooltip="Message Tooltip">Aceptar</button>`;

	public caseDelay = `<button sn-button snTooltipShowDelay="1000" snTooltipHideDelay="1000" snTooltip="Message Tooltip">Aceptar</button>`;

	public casePosition = `<button sn-button snTooltipPosition="above" snTooltip="Above Tooltip">
	Arriba
</button> &nbsp;
<button sn-button snTooltipPosition="below" snTooltip="Below Tooltip">
	Abajo
</button> &nbsp;
<button sn-button snTooltipPosition="right" snTooltip="Right Tooltip">
	Derecha
</button> &nbsp;
<button sn-button snTooltipPosition="left" snTooltip="Left Tooltip">
	Izquierda
</button> 
	`;

	public caseHideShow = `  <button sn-button (mouseenter)="tooltip.hide()">Ocultar</button>
  <button sn-button (mouseenter)="tooltip.show()">Mostrar</button>
  <button sn-button (mouseenter)="tooltip.toggle()">Toggle</button>

  <button sn-button #tooltip="SnTooltipDirective" snTooltip="Message Tooltip">Aceptar</button>`;
}
