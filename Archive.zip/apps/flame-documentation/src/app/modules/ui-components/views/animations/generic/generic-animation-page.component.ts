import { Component, ElementRef } from '@angular/core';
import {
  AnimationBuilder,
  AnimationPlayer,
  transition,
  useAnimation,
  trigger,
  style,
  query,
  animate} from "@angular/animations";
import {
  rotateScaleUpAnimation,
  rotateScaleUpDiagonalOneAnimation,
  rotateScaleDownAnimation,
  rotateScaleDownDiagonalOneAnimation,
  rotateScaleUpHorizontalAnimation,
  rotateScaleUpDiagonalTwoAnimation,
  rotateScaleDownHorizontalAnimation,
  rotateScaleDownDiagonalTwoAnimation,
  rotateScaleUpVerticalAnimation,
  rotateScaleDownVerticalAnimation,
  rotateCenterAnimation,
  rotateBottomLeftAnimation,
  rotateVerticalCenterAnimation,
  rotateDiagonalBottomRightAnimation,
  rotateTopAnimation,
  rotateLeftAnimation,
  rotateVerticalLeftAnimation,
  rotateDiagonalBLAnimation,
  rotateTopRightAnimation,
  rotateTopLeftAnimation,
  rotateVerticalRightAnimation,
  rotateDiagonalTLAnimation,
  rotateRightAnimation,
  rotateHorizontalCenterAnimation,
  rotateDiagonalOneAnimation,
  rotateBottomRightAnimation,
  rotateHorizontalTopAnimation,
  rotateDiagonalTwoAnimation,
  rotateBottomAnimation,
  rotateHorizontalBottomAnimation,
  rotateDiagonalTRAnimation,
  scaleDownCenterAnimation,
  scaleDownBottomLeftAnimation,
  scaleDownVerticalCenterAnimation,
  scaleDownTopAnimation,
  scaleDownLeftAnimation,
  scaleDownVerticalTopAnimation,
  scaleDownTopRightAnimation,
  scaleDownTopLeftAnimation,
  scaleDownVerticalBottomAnimation,
  scaleDownRightAnimation,
  scaleDownHorizontalCenterAnimation,
  scaleDownBottomRightAnimation,
  scaleDownHorizontalLeftAnimation,
  scaleDownBottomAnimation,
  scaleDownHorizontalRightAnimation,
  scaleUpCenterAnimation,
  scaleUpBottomLeftAnimation,
  scaleUpVerticalCenterAnimation,
  scaleUpTopAnimation,
  scaleUpLeftAnimation,
  scaleUpVerticalTopAnimation,
  scaleUpTopRightAnimation,
  scaleUpTopLeftAnimation,
  scaleUpVerticalBottomAnimation,
  scaleUpRightAnimation,
  scaleUpHorizontalCenterAnimation,
  scaleUpBottomRightAnimation,
  scaleUpHorizontalLeftAnimation,
  scaleUpBottomAnimation,
  scaleUpHorizontalRightAnimation,
  flipInHorBottom,
  flipInDiag2Tl,
  flipInHorTop,
  flipInDiag2Br,
  flipInVerRight,
  flipInVerLeft,
  flipInDiag1Tr,
  flipInDiag1Bl,
  rotateInOptAnimation,
  rotateInOptBRAnimation,
  rotateInOptCAnimation,
  rotateInOptBRCAnimation,
  rotateInOptFWDAnimation,
  rotateInOptBLAnimation,
  rotateInOptBCKAnimation,
  rotateInOptBLCAnimation,
  rotateInOptTRAnimation,
  rotateInOptTLAnimation,
  rotateInOptTRCAnimation,
  rotateInOptTLCAnimation,
  rotateInCenterAnimation,
  rotateInBLAnimation,
  rotateInDiagonalTwoAnimation,
  rotateInTopAnimation,
  rotateInLeftAnimation,
  rotateInTRAnimation,
  rotateInTLAnimation,
  rotateInRightAnimation,
  rotateInHorAnimation,
  rotateInBRAnimation,
  rotateInVerAnimation,
  rotateInBottomAnimation,
  rotateInDiagonalOneAnimation,
  scaleInCenterAnimation,
  scaleInBLAnimation,
  scaleInVertCenterAnimation,
  scaleInTopAnimation,
  scaleInLeftAnimation,
  scaleInVertTopAnimation,
  scaleInTRAnimation,
  scaleInTLAnimation,
  scaleInVerBottomAnimation,
  scaleInRightAnimation,
  scaleInHorCenterAnimation,
  scaleInBRAnimation,
  scaleInHorLeftAnimation,
  scaleInBottomAnimation,
  scaleInHorRightAnimation,
  slideInTopAnimation,
  slideInLeftAnimation,
  slideInTrAnimation,
  slideInTlAnimation,
  slideInRightAnimation,
  slideInBrAnimation,
  slideInBottomAnimation,
  slideInBlAnimation,
  slitInVerticalAnimation,
  slitInHorizontalAnimation,
  slitInDiagonal1Animation,
  slitInDiagonal2Animation,
  swirlInFWDAnimation,
  swirlInRightFWDAnimation,
  swirlInBLFWDAnimation,
  swirlInBackAnimation,
  swirlInRightBCKAnimation,
  swirlInBLBCKAnimation,
  swirlInTopFWDAnimation,
  swirlInBRFWDAnimation,
  swirlInLeftFWDAnimation,
  swirlInTopBCKAnimation,
  swirlInBRBCKAnimation,
  swirlInLeftBCKAnimation,
  swirlInTRFWDAnimation,
  swirlInBottomFWDAnimation,
  swirlInTLFWDAnimation,
  swirlInTRBCKAnimation,
  swirlInBottomBCKAnimation,
  swirlInTLBCKAnimation
 } from '@santander/flame-component-library';

@Component({
  selector: 'sn-generic-animation-page',
  templateUrl: './generic-animation-page.component.html',
  styleUrls: ['./generic-animation-page.component.scss'],
  animations:[
    trigger('listStagger', [
      transition(':enter', [
        style({transform: 'translateX(100%)', opacity: 0}),
        animate('500ms', style({transform: 'translateX(0)', opacity: 1}))
      ]),
      transition(':leave', [
        style({transform: 'translateX(0)', opacity: 1}),
        animate('500ms', style({transform: 'translateX(100%)', opacity: 0}))
      ]),
      transition('* => ready', [
        query('.rotateScaleUpAnimation', [useAnimation(rotateScaleUpAnimation)], {optional: true}),
        query('.rotateScaleUpDiagonalOneAnimation', [useAnimation(rotateScaleUpDiagonalOneAnimation)], {optional: true}),
        query('.rotateScaleDownAnimation', [useAnimation(rotateScaleDownAnimation)], {optional: true}),
        query('.rotateScaleDownDiagonalOneAnimation', [useAnimation(rotateScaleDownDiagonalOneAnimation)], {optional: true}),
        query('.rotateScaleUpHorizontalAnimation', [useAnimation(rotateScaleUpHorizontalAnimation)], {optional: true}),
        query('.rotateScaleUpDiagonalTwoAnimation', [useAnimation(rotateScaleUpDiagonalTwoAnimation)], {optional: true}),
        query('.rotateScaleDownHorizontalAnimation', [useAnimation(rotateScaleDownHorizontalAnimation)], {optional: true}),
        query('.rotateScaleDownDiagonalTwoAnimation', [useAnimation(rotateScaleDownDiagonalTwoAnimation)], {optional: true}),
        query('.rotateScaleUpVerticalAnimation', [useAnimation(rotateScaleUpVerticalAnimation)], {optional: true}),
        query('.rotateScaleDownVerticalAnimation', [useAnimation(rotateScaleDownVerticalAnimation)], {optional: true}),
        query('.rotateCenterAnimation', [useAnimation(rotateCenterAnimation)], {optional: true}),
        query('.rotateBottomLeftAnimation', [useAnimation(rotateBottomLeftAnimation)], {optional: true}),
        query('.rotateVerticalCenterAnimation', [useAnimation(rotateVerticalCenterAnimation)], {optional: true}),
        query('.rotateDiagonalBottomRightAnimation', [useAnimation(rotateDiagonalBottomRightAnimation)], {optional: true}),
        query('.rotateTopAnimation', [useAnimation(rotateTopAnimation)], {optional: true}),
        query('.rotateLeftAnimation', [useAnimation(rotateLeftAnimation)], {optional: true}),
        query('.rotateVerticalLeftAnimation', [useAnimation(rotateVerticalLeftAnimation)], {optional: true}),
        query('.rotateDiagonalBLAnimation', [useAnimation(rotateDiagonalBLAnimation)], {optional: true}),
        query('.rotateTopRightAnimation', [useAnimation(rotateTopRightAnimation)], {optional: true}),
        query('.rotateTopLeftAnimation', [useAnimation(rotateTopLeftAnimation)], {optional: true}),
        query('.rotateVerticalRightAnimation', [useAnimation(rotateVerticalRightAnimation)], {optional: true}),
        query('.rotateDiagonalTLAnimation', [useAnimation(rotateDiagonalTLAnimation)], {optional: true}),
        query('.rotateRightAnimation', [useAnimation(rotateRightAnimation)], {optional: true}),
        query('.rotateHorizontalCenterAnimation', [useAnimation(rotateHorizontalCenterAnimation)], {optional: true}),
        query('.rotateDiagonalOneAnimation', [useAnimation(rotateDiagonalOneAnimation)], {optional: true}),
        query('.rotateBottomRightAnimation', [useAnimation(rotateBottomRightAnimation)], {optional: true}),
        query('.rotateHorizontalTopAnimation', [useAnimation(rotateHorizontalTopAnimation)], {optional: true}),
        query('.rotateDiagonalTwoAnimation', [useAnimation(rotateDiagonalTwoAnimation)], {optional: true}),
        query('.rotateBottomAnimation', [useAnimation(rotateBottomAnimation)], {optional: true}),
        query('.rotateHorizontalBottomAnimation', [useAnimation(rotateHorizontalBottomAnimation)], {optional: true}),
        // query('.rotateDiagonalTRAnimation', [useAnimation(rotateDiagonalTRAnimation)], {optional: true}),
        query('.scaleDownCenterAnimation', [useAnimation(scaleDownCenterAnimation)], {optional: true}),
        query('.scaleDownBottomLeftAnimation', [useAnimation(scaleDownBottomLeftAnimation)], {optional: true}),
        query('.scaleDownVerticalCenterAnimation', [useAnimation(scaleDownVerticalCenterAnimation)], {optional: true}),
        query('.scaleDownTopAnimation', [useAnimation(scaleDownTopAnimation)], {optional: true}),
        query('.scaleDownLeftAnimation', [useAnimation(scaleDownLeftAnimation)], {optional: true}),
        query('.scaleDownVerticalTopAnimation', [useAnimation(scaleDownVerticalTopAnimation)], {optional: true}),
        query('.scaleDownTopRightAnimation', [useAnimation(scaleDownTopRightAnimation)], {optional: true}),
        query('.scaleDownTopLeftAnimation', [useAnimation(scaleDownTopLeftAnimation)], {optional: true}),
        query('.scaleDownVerticalBottomAnimation', [useAnimation(scaleDownVerticalBottomAnimation)], {optional: true}),
        query('.scaleDownRightAnimation', [useAnimation(scaleDownRightAnimation)], {optional: true}),
        query('.scaleDownHorizontalCenterAnimation', [useAnimation(scaleDownHorizontalCenterAnimation)], {optional: true}),
        query('.scaleDownBottomRightAnimation', [useAnimation(scaleDownBottomRightAnimation)], {optional: true}),
        query('.scaleDownHorizontalLeftAnimation', [useAnimation(scaleDownHorizontalLeftAnimation)], {optional: true}),
        query('.scaleDownBottomAnimation', [useAnimation(scaleDownBottomAnimation)], {optional: true}),
        query('.scaleDownHorizontalRightAnimation', [useAnimation(scaleDownHorizontalRightAnimation)], {optional: true}),
        query('.scaleUpCenterAnimation', [useAnimation(scaleUpCenterAnimation)], {optional: true}),
        query('.scaleUpBottomLeftAnimation', [useAnimation(scaleUpBottomLeftAnimation)], {optional: true}),
        query('.scaleUpVerticalCenterAnimation', [useAnimation(scaleUpVerticalCenterAnimation)], {optional: true}),
        query('.scaleUpTopAnimation', [useAnimation(scaleUpTopAnimation)], {optional: true}),
        query('.scaleUpLeftAnimation', [useAnimation(scaleUpLeftAnimation)], {optional: true}),
        query('.scaleUpVerticalTopAnimation', [useAnimation(scaleUpVerticalTopAnimation)], {optional: true}),
        query('.scaleUpTopRightAnimation', [useAnimation(scaleUpTopRightAnimation)], {optional: true}),
        query('.scaleUpTopLeftAnimation', [useAnimation(scaleUpTopLeftAnimation)], {optional: true}),
        query('.scaleUpVerticalBottomAnimation', [useAnimation(scaleUpVerticalBottomAnimation)], {optional: true}),
        query('.scaleUpRightAnimation', [useAnimation(scaleUpRightAnimation)], {optional: true}),
        query('.scaleUpHorizontalCenterAnimation', [useAnimation(scaleUpHorizontalCenterAnimation)], {optional: true}),
        query('.scaleUpBottomRightAnimation', [useAnimation(scaleUpBottomRightAnimation)], {optional: true}),
        query('.scaleUpHorizontalLeftAnimation', [useAnimation(scaleUpHorizontalLeftAnimation)], {optional: true}),
        query('.scaleUpBottomAnimation', [useAnimation(scaleUpBottomAnimation)], {optional: true}),
        query('.scaleUpHorizontalRightAnimation', [useAnimation(scaleUpHorizontalRightAnimation)], {optional: true}),
        query('.flipInHorBottom', [useAnimation(flipInHorBottom)], {optional: true}),
        query('.flipInDiag2Tl', [useAnimation(flipInDiag2Tl)], {optional: true}),
        query('.flipInHorTop', [useAnimation(flipInHorTop)], {optional: true}),
        query('.flipInDiag2Br', [useAnimation(flipInDiag2Br)], {optional: true}),
        query('.flipInVerRight', [useAnimation(flipInVerRight)], {optional: true}),
        query('.flipInVerLeft', [useAnimation(flipInVerLeft)], {optional: true}),
        query('.flipInDiag1Tr', [useAnimation(flipInDiag1Tr)], {optional: true}),
        query('.flipInDiag1Bl', [useAnimation(flipInDiag1Bl)], {optional: true}),
        query('.rotateInOptAnimation', [useAnimation(rotateInOptAnimation)], {optional: true}),
        query('.rotateInOptBRAnimation', [useAnimation(rotateInOptBRAnimation)], {optional: true}),
        query('.rotateInOptCAnimation', [useAnimation(rotateInOptCAnimation)], {optional: true}),
        query('.rotateInOptBRCAnimation', [useAnimation(rotateInOptBRCAnimation)], {optional: true}),
        query('.rotateInOptFWDAnimation', [useAnimation(rotateInOptFWDAnimation)], {optional: true}),
        query('.rotateInOptBLAnimation', [useAnimation(rotateInOptBLAnimation)], {optional: true}),
        query('.rotateInOptBCKAnimation', [useAnimation(rotateInOptBCKAnimation)], {optional: true}),
        query('.rotateInOptBLCAnimation', [useAnimation(rotateInOptBLCAnimation)], {optional: true}),
        query('.rotateInOptTRAnimation', [useAnimation(rotateInOptTRAnimation)], {optional: true}),
        query('.rotateInOptTLAnimation', [useAnimation(rotateInOptTLAnimation)], {optional: true}),
        query('.rotateInOptTRCAnimation', [useAnimation(rotateInOptTRCAnimation)], {optional: true}),
        query('.rotateInOptTLCAnimation', [useAnimation(rotateInOptTLCAnimation)], {optional: true}),
        query('.rotateInCenterAnimation', [useAnimation(rotateInCenterAnimation)], {optional: true}),
        query('.rotateInBLAnimation', [useAnimation(rotateInBLAnimation)], {optional: true}),
        query('.rotateInDiagonalTwoAnimation', [useAnimation(rotateInDiagonalTwoAnimation)], {optional: true}),
        query('.rotateInTopAnimation', [useAnimation(rotateInTopAnimation)], {optional: true}),
        query('.rotateInLeftAnimation', [useAnimation(rotateInLeftAnimation)], {optional: true}),
        query('.rotateInTRAnimation', [useAnimation(rotateInTRAnimation)], {optional: true}),
        query('.rotateInTLAnimation', [useAnimation(rotateInTLAnimation)], {optional: true}),
        query('.rotateInRightAnimation', [useAnimation(rotateInRightAnimation)], {optional: true}),
        query('.rotateInHorAnimation', [useAnimation(rotateInHorAnimation)], {optional: true}),
        query('.rotateInBRAnimation', [useAnimation(rotateInBRAnimation)], {optional: true}),
        query('.rotateInVerAnimation', [useAnimation(rotateInVerAnimation)], {optional: true}),
        query('.rotateInBottomAnimation', [useAnimation(rotateInBottomAnimation)], {optional: true}),
        query('.rotateInDiagonalOneAnimation', [useAnimation(rotateInDiagonalOneAnimation)], {optional: true}),
        query('.scaleInCenterAnimation', [useAnimation(scaleInCenterAnimation)], {optional: true}),
        query('.scaleInBLAnimation', [useAnimation(scaleInBLAnimation)], {optional: true}),
        query('.scaleInVertCenterAnimation', [useAnimation(scaleInVertCenterAnimation)], {optional: true}),
        query('.scaleInTopAnimation', [useAnimation(scaleInTopAnimation)], {optional: true}),
        query('.scaleInLeftAnimation', [useAnimation(scaleInLeftAnimation)], {optional: true}),
        query('.scaleInVertTopAnimation', [useAnimation(scaleInVertTopAnimation)], {optional: true}),
        query('.scaleInTRAnimation', [useAnimation(scaleInTRAnimation)], {optional: true}),
        query('.scaleInTLAnimation', [useAnimation(scaleInTLAnimation)], {optional: true}),
        query('.scaleInVerBottomAnimation', [useAnimation(scaleInVerBottomAnimation)], {optional: true}),
        query('.scaleInRightAnimation', [useAnimation(scaleInRightAnimation)], {optional: true}),
        query('.scaleInHorCenterAnimation', [useAnimation(scaleInHorCenterAnimation)], {optional: true}),
        query('.scaleInBRAnimation', [useAnimation(scaleInBRAnimation)], {optional: true}),
        query('.scaleInHorLeftAnimation', [useAnimation(scaleInHorLeftAnimation)], {optional: true}),
        query('.scaleInBottomAnimation', [useAnimation(scaleInBottomAnimation)], {optional: true}),
        query('.scaleInHorRightAnimation', [useAnimation(scaleInHorRightAnimation)], {optional: true}),
        query('.slideInTopAnimation', [useAnimation(slideInTopAnimation)], {optional: true}),
        query('.slideInLeftAnimation', [useAnimation(slideInLeftAnimation)], {optional: true}),
        query('.slideInTrAnimation', [useAnimation(slideInTrAnimation)], {optional: true}),
        query('.slideInTlAnimation', [useAnimation(slideInTlAnimation)], {optional: true}),
        query('.slideInRightAnimation', [useAnimation(slideInRightAnimation)], {optional: true}),
        query('.slideInBrAnimation', [useAnimation(slideInBrAnimation)], {optional: true}),
        query('.slideInBottomAnimation', [useAnimation(slideInBottomAnimation)], {optional: true}),
        query('.slideInBlAnimation', [useAnimation(slideInBlAnimation)], {optional: true}),
        query('.slitInVerticalAnimation', [useAnimation(slitInVerticalAnimation)], {optional: true}),
        query('.slitInHorizontalAnimation', [useAnimation(slitInHorizontalAnimation)], {optional: true}),
        query('.slitInDiagonal1Animation', [useAnimation(slitInDiagonal1Animation)], {optional: true}),
        query('.slitInDiagonal2Animation', [useAnimation(slitInDiagonal2Animation)], {optional: true}),
        query('.swirlInFWDAnimation', [useAnimation(swirlInFWDAnimation)], {optional: true}),
        query('.swirlInRightFWDAnimation', [useAnimation(swirlInRightFWDAnimation)], {optional: true}),
        query('.swirlInBLFWDAnimation', [useAnimation(swirlInBLFWDAnimation)], {optional: true}),
        query('.swirlInBackAnimation', [useAnimation(swirlInBackAnimation)], {optional: true}),
        query('.swirlInRightBCKAnimation', [useAnimation(swirlInRightBCKAnimation)], {optional: true}),
        query('.swirlInBLBCKAnimation', [useAnimation(swirlInBLBCKAnimation)], {optional: true}),
        query('.swirlInTopFWDAnimation', [useAnimation(swirlInTopFWDAnimation)], {optional: true}),
        query('.swirlInBRFWDAnimation', [useAnimation(swirlInBRFWDAnimation)], {optional: true}),
        query('.swirlInLeftFWDAnimation', [useAnimation(swirlInLeftFWDAnimation)], {optional: true}),
        query('.swirlInTopBCKAnimation', [useAnimation(swirlInTopBCKAnimation)], {optional: true}),
        query('.swirlInBRBCKAnimation', [useAnimation(swirlInBRBCKAnimation)], {optional: true}),
        query('.swirlInLeftBCKAnimation', [useAnimation(swirlInLeftBCKAnimation)], {optional: true}),
        query('.swirlInTRFWDAnimation', [useAnimation(swirlInTRFWDAnimation)], {optional: true}),
        query('.swirlInBottomFWDAnimation', [useAnimation(swirlInBottomFWDAnimation)], {optional: true}),
        query('.swirlInTLFWDAnimation', [useAnimation(swirlInTLFWDAnimation)], {optional: true}),
        query('.swirlInTRBCKAnimation', [useAnimation(swirlInTRBCKAnimation)], {optional: true}),
        query('.swirlInBottomBCKAnimation', [useAnimation(swirlInBottomBCKAnimation)], {optional: true}),
        query('.swirlInTLBCKAnimation', [useAnimation(swirlInTLBCKAnimation)], {optional: true})
      ])
    ])
  ]
})
export class GenericAnimationPageComponent {

  constructor(private _builder: AnimationBuilder, private el: ElementRef) {
   }
  public player: AnimationPlayer;
  public aparecer = false;
  public transition = '';
  public animation: string;
  public caseOneContent = `
  import {
    transition,
    useAnimation,
    trigger,
    style,
    query,
    animate} from "@angular/animations";
  import {
    rotateScaleUpAnimation
  } from '@santander/flame-component-library';
  @Component({
    selector: 'sn-generic-animation-page',
    templateUrl: './generic-animation-page.component.html',
    styleUrls: ['./generic-animation-page.component.scss'],
    animations:[
      trigger('listStagger', [
        transition(':enter', [
          style({transform: 'translateX(100%)', opacity: 0}),
          animate('500ms', style({transform: 'translateX(0)', opacity: 1}))
        ]),
        transition(':leave', [
          style({transform: 'translateX(0)', opacity: 1}),
          animate('500ms', style({transform: 'translateX(100%)', opacity: 0}))
        ]),
        transition('* => ready', [
          useAnimation(rotateScaleUpAnimation)
        ])
      ])
    ]
  })
  export class GenericAnimationPageComponent implements OnInit, AfterViewInit  {
    public transition = '';
    constructor() {
    }
    onAnimationEvent ( event: any ) {
      if (event.phaseName === 'done'){
        this.transition = '';
      }
    }
  }
  `;

  public caseTwoContent = `
    <sn-avatar
    fullname="Mayra Paola Romero"
    [typeavatar]="0"
    [@listStagger]="transition" (@listStagger.start)="onAnimationEvent($event)" (@listStagger.done)="onAnimationEvent($event)"
    ></sn-avatar>
  `;

  public caseThreeContent = `
  import {
    transition,
    useAnimation,
    trigger,
    style,
    query,
    animate} from "@angular/animations";
  import {
    rotateScaleUpAnimation
  } from '@santander/flame-component-library';
  @Component({
    selector: 'sn-generic-animation-page',
    templateUrl: './generic-animation-page.component.html',
    styleUrls: ['./generic-animation-page.component.scss'],
    animations:[
      trigger('listStagger', [
        transition(':enter', [
          style({transform: 'translateX(100%)', opacity: 0}),
          animate('500ms', style({transform: 'translateX(0)', opacity: 1}))
        ]),
        transition(':leave', [
          style({transform: 'translateX(0)', opacity: 1}),
          animate('500ms', style({transform: 'translateX(100%)', opacity: 0}))
        ]),
        transition('* => ready', [
          query('.without-avatar', [useAnimation(rotateScaleUpAnimation)], {optional: true}),
        ])
      ])
    ]
  })
  export class GenericAnimationPageComponent implements OnInit, AfterViewInit  {
    public transition = '';
    constructor() {
    }
    onAnimationEvent ( event: any ) {
      if (event.phaseName === 'done'){
        this.transition = '';
      }
    }
  }
  `;

  public classAnimation = 'rotateScaleUpAnimation';
  public animationsAvailable = [
    'rotateScaleUpAnimation',
    'rotateScaleUpDiagonalOneAnimation',
    'rotateScaleDownAnimation',
    'rotateScaleDownDiagonalOneAnimation',
    'rotateScaleUpHorizontalAnimation',
    'rotateScaleUpDiagonalTwoAnimation',
    'rotateScaleDownHorizontalAnimation',
    'rotateScaleDownDiagonalTwoAnimation',
    'rotateScaleUpVerticalAnimation',
    'rotateScaleDownVerticalAnimation',
    'rotateCenterAnimation',
    'rotateBottomLeftAnimation',
    'rotateVerticalCenterAnimation',
    'rotateDiagonalBottomRightAnimation',
    'rotateTopAnimation',
    'rotateLeftAnimation',
    'rotateVerticalLeftAnimation',
    'rotateDiagonalBLAnimation',
    'rotateTopRightAnimation',
    'rotateTopLeftAnimation',
    'rotateVerticalRightAnimation',
    'rotateDiagonalTLAnimation',
    'rotateRightAnimation',
    'rotateHorizontalCenterAnimation',
    'rotateDiagonalOneAnimation',
    'rotateBottomRightAnimation',
    'rotateHorizontalTopAnimation',
    'rotateDiagonalTwoAnimation',
    'rotateBottomAnimation',
    'rotateHorizontalBottomAnimation',
    'rotateDiagonalTRAnimation',
    'scaleDownCenterAnimation',
    'scaleDownBottomLeftAnimation',
    'scaleDownVerticalCenterAnimation',
    'scaleDownTopAnimation',
    'scaleDownLeftAnimation',
    'scaleDownVerticalTopAnimation',
    'scaleDownTopRightAnimation',
    'scaleDownTopLeftAnimation',
    'scaleDownVerticalBottomAnimation',
    'scaleDownRightAnimation',
    'scaleDownHorizontalCenterAnimation',
    'scaleDownBottomRightAnimation',
    'scaleDownHorizontalLeftAnimation',
    'scaleDownBottomAnimation',
    'scaleDownHorizontalRightAnimation',
    'scaleUpCenterAnimation',
    'scaleUpBottomLeftAnimation',
    'scaleUpVerticalCenterAnimation',
    'scaleUpTopAnimation',
    'scaleUpLeftAnimation',
    'scaleUpVerticalTopAnimation',
    'scaleUpTopRightAnimation',
    'scaleUpTopLeftAnimation',
    'scaleUpVerticalBottomAnimation',
    'scaleUpRightAnimation',
    'scaleUpHorizontalCenterAnimation',
    'scaleUpBottomRightAnimation',
    'scaleUpHorizontalLeftAnimation',
    'scaleUpBottomAnimation',
    'scaleUpHorizontalRightAnimation',
    'flipInHorBottom',
    'flipInDiag2Tl',
    'flipInHorTop',
    'flipInDiag2Br',
    'flipInVerRight',
    'flipInVerLeft',
    'flipInDiag1Tr',
    'flipInDiag1Bl',
    'rotateInOptAnimation',
    'rotateInOptBRAnimation',
    'rotateInOptCAnimation',
    'rotateInOptBRCAnimation',
    'rotateInOptFWDAnimation',
    'rotateInOptBLAnimation',
    'rotateInOptBCKAnimation',
    'rotateInOptBLCAnimation',
    'rotateInOptTRAnimation',
    'rotateInOptTLAnimation',
    'rotateInOptTRCAnimation',
    'rotateInOptTLCAnimation',
    'rotateInCenterAnimation',
    'rotateInBLAnimation',
    'rotateInDiagonalTwoAnimation',
    'rotateInTopAnimation',
    'rotateInLeftAnimation',
    'rotateInTRAnimation',
    'rotateInTLAnimation',
    'rotateInRightAnimation',
    'rotateInHorAnimation',
    'rotateInBRAnimation',
    'rotateInVerAnimation',
    'rotateInBottomAnimation',
    'rotateInDiagonalOneAnimation',
    'scaleInCenterAnimation',
    'scaleInBLAnimation',
    'scaleInVertCenterAnimation',
    'scaleInTopAnimation',
    'scaleInLeftAnimation',
    'scaleInVertTopAnimation',
    'scaleInTRAnimation',
    'scaleInTLAnimation',
    'scaleInVerBottomAnimation',
    'scaleInRightAnimation',
    'scaleInHorCenterAnimation',
    'scaleInBRAnimation',
    'scaleInHorLeftAnimation',
    'scaleInBottomAnimation',
    'scaleInHorRightAnimation',
    'slideInTopAnimation',
    'slideInLeftAnimation',
    'slideInTrAnimation',
    'slideInTlAnimation',
    'slideInRightAnimation',
    'slideInBrAnimation',
    'slideInBottomAnimation',
    'slideInBlAnimation',
    'slitInVerticalAnimation',
    'slitInHorizontalAnimation',
    'slitInDiagonal1Animation',
    'slitInDiagonal2Animation',
    'swirlInFWDAnimation',
    'swirlInRightFWDAnimation',
    'swirlInBLFWDAnimation',
    'swirlInBackAnimation',
    'swirlInRightBCKAnimation',
    'swirlInBLBCKAnimation',
    'swirlInTopFWDAnimation',
    'swirlInBRFWDAnimation',
    'swirlInLeftFWDAnimation',
    'swirlInTopBCKAnimation',
    'swirlInBRBCKAnimation',
    'swirlInLeftBCKAnimation',
    'swirlInTRFWDAnimation',
    'swirlInBottomFWDAnimation',
    'swirlInTLFWDAnimation',
    'swirlInTRBCKAnimation',
    'swirlInBottomBCKAnimation',
    'swirlInTLBCKAnimation'
  ]

  onAnimationEvent ( event: any ) {
    if (event.phaseName === 'done'){
      this.transition = '';
    }
  }

  playAnimation(value: string){
    this.classAnimation = value;
    this.transition = 'ready';
  }
}
