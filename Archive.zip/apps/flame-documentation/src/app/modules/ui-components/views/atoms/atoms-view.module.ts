import { PageHeaderModule } from './../../../../components/page-header/page-header.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {
	AvatarModule,
	ButtonModule,
	CardModule,
	CarouselModule,
	CheckboxModule,
	ChipModule,
	FormFieldModule,
	HiddenButtonsModule,
	IconButtonModule,
	IconModule,
	InputModule,
	ProgressBarModule,
	RadioButtonModule,
	SearchBarModule,
	SlideButtonModule,
	SlideToggleModule,
	SpinnerModule,
	TabModule,
	TabsModule,
	TooltipModule,
	EmojiModule,
	SnackBarModule,
	TagModule,
	HeaderAnimationModule,
	TopBarModule,
	DialogContentModule,
	ThemeModule,
	DarkTheme,
	FlameFoundationTheme,
	IconButtonWebModule,
	DialogWebModule,
	AvatarWebModule,
	IconBadgeModule,
	AvatarBadgeModule
} from '@santander/flame-component-library';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PrismModule } from '@ngx-prism/core';
import { AtomsViewRoutingModule } from './atoms-view-routing.module';

// Components
import { ATOMS_COMPONENTS } from './views/atoms.components';
import { MenuSideBarModule } from '../../../../components/menu-sidebar/menu-sidebar.module';
import { ComponentDocViewerModule } from '../../../../components/component-doc-viewer/component-doc-viewer.module';
import { AtomsViewComponent } from './atoms-view.component';
import { DialogComponent } from 'libs/core/flame-component-library/src/lib/atoms/dialog/dialog.component';
import { TokenComponent } from './views/dialog-content/token-component/token.component';
import { DialogPaymentsNoConnectionComponent } from './views/dialog-content/dialog-payments-no-connection/dialog-payments-no-connection.component';
import { ZurichTheme } from './views/theme/zurich.theme';
import { CustomContentComponent } from './views/dialog-web/custom-content/custom-content.component';
import { IconFilterPipe } from './views/icon/icon-page.pipe';

const LIBRARY_MODULES = [
	AvatarModule,
	ButtonModule,
	CardModule,
	CarouselModule,
	CheckboxModule,
	ChipModule,
	DialogContentModule,
	EmojiModule,
	HttpClientModule,
	IconButtonModule,
	IconModule,
	InputModule,
	ProgressBarModule,
	RadioButtonModule,
	SearchBarModule,
	SnackBarModule,
	SpinnerModule,
	TabModule,
	TooltipModule,
	FormFieldModule,
	HiddenButtonsModule,
	SlideButtonModule,
	SlideToggleModule,
	TabsModule,
	TagModule,
	HeaderAnimationModule,
	TopBarModule,
	IconButtonWebModule,
	DialogWebModule,
	AvatarWebModule,
	IconBadgeModule,
	AvatarBadgeModule
];

@NgModule({
	imports: [
		...LIBRARY_MODULES,
		AtomsViewRoutingModule,
		CommonModule,
		ComponentDocViewerModule,
		FormsModule,
		MenuSideBarModule,
		NgbModule,
		PrismModule,
		ReactiveFormsModule,
		PageHeaderModule,
		ThemeModule.forRoot({
			themes: [DarkTheme, FlameFoundationTheme, ZurichTheme],
			active: 'dark'
		})
	],
	declarations: [
		...ATOMS_COMPONENTS,
		AtomsViewComponent,
		CustomContentComponent,
		IconFilterPipe
	],
	entryComponents: [
		DialogComponent,
		TokenComponent,
		DialogPaymentsNoConnectionComponent,
		CustomContentComponent
	]
})
export class AtomsViewModule {}
