import { Component } from '@angular/core';

@Component({
	selector: 'sn-snackbar-page',
	templateUrl: './snackbar-page.component.html',
	styleUrls: ['./snackbar-page.component.scss']
})
export class SnackbarPageComponent {
  text: string;
  title: string;
  button: boolean;

  public snackInterface: any = {
    title: 'Titulo',
    text : 'Mensaje',
    button : true
  }

  public caseOneContent = `
    <div class="example" [snSnackBar]="snackInterface">
      <div class="text-center">
        <h3>Titulo</h3>
      </div>
      <p class="sn-number lvl-1" #posMarker>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit.
      </p>
    </div>`;

  public messageInterface = `
    public snackInterface: any = {
      title: 'Titulo',
      text : 'Mensaje',
      button : true
    }
  `;
}
