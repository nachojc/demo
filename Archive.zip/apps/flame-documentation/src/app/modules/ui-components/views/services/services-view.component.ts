import { Component } from '@angular/core';
import { SubMenu } from '../../../../components/menu-sidebar/models/sub-menu.model';

@Component({
	selector: 'sn-services-view',
	templateUrl: 'services-view.component.html',
	styleUrls: ['services-view.component.scss']
})
export class ServicesViewComponent {
	constructor() {}
	public openMenu: boolean;

	public menu: Array<SubMenu> = [
		{
			groupName: 'services',
			menu: [
				{
					routerLink: '/ui-components/services/loader-overlay',
					textContent: 'Loader Overlay'
				},
				{
					routerLink: '/ui-components/services/overlay',
					textContent: 'Overlay'
				}
			]
		}
	];
	menuChange(status: boolean): void {
		this.openMenu = status;
	}

	closeMenu() {
		this.openMenu = false;
	}
}
