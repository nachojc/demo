import { AvatarPageComponent } from './avatar/avatar-page.component';
import { ButtonPageComponent } from './button/button-page.component';
import { CardPageComponent } from './card/card-page.component';
import { CarouselPageComponent } from './carousel/carousel-page.component';
import { CheckboxPageComponent } from './checkbox/checkbox-page.component';
import { ChipPageComponent } from './chip/chip-page.component';
import { EmojiPageComponent } from './emoji/emoji-page.component';
import { FormFieldPageComponent } from './form-field/form-field-page.component';
import { HiddenButtonsPageComponent } from './hidden-buttons/hidden-buttons-page.component';
import { IconButtonPageComponent } from './icon-button/icon-button-page.component';
import { IconPageComponent } from './icon/icon-page.component';
import { InputPageComponent } from './input/input-page.component';
import { ProgressBarPageComponent } from './progress-bar/progress-bar-page.component';
import { RadioButtonPageComponent } from './radio-button/radio-button-page.component';
import { RadioPageComponent } from './radio/radio-page.component';
import { RangePageComponent } from './range/range-page.component';
import { SearchBarPageComponent } from './search-bar/search-bar-page.component';
import { SlideButtonPageComponent } from './slide-button/slide-button-page.component';
import { SnackbarPageComponent } from './snackbar/snackbar-page.component';
import { SpinnerPageComponent } from './spinner/spinner-page.component';
import { SlideTogglePageComponent } from './slide-toggle/slide-toggle-page.component';
import { TabsPageComponent } from './tabs/tabs-page.component';
import { ThemePageComponent } from './theme/theme-page.component';
import { TooltipPageComponent } from './tooltip/tooltip-page.component';
import { TagPageComponent } from './tag/tag-page.component';
import { TokenComponent } from './dialog-content/token-component/token.component';
import { DialogPaymentsNoConnectionComponent } from './dialog-content/dialog-payments-no-connection/dialog-payments-no-connection.component';
import { DialogContentPageComponent } from './dialog-content/dialog-content-page.component';
import { IconButtonWebPageComponent } from './icon-button-web/icon-button-web-page.component';
import { DialogWebPageComponent } from './dialog-web/dialog-web-page.component';
import { AvatarWebPageComponent } from './avatar-web/avatar-web-page.component';
import { IconBadgePageComponent } from './icon-badge/icon-badge-page.component';
import { AvatarBadgePageComponent } from './avatar-badge/avatar-badge-page.component';

export const ATOMS_COMPONENTS = [
	AvatarPageComponent,
	ButtonPageComponent,
	CardPageComponent,
	CarouselPageComponent,
	CheckboxPageComponent,
	ChipPageComponent,
	EmojiPageComponent,
	FormFieldPageComponent,
	HiddenButtonsPageComponent,
	IconButtonPageComponent,
	IconPageComponent,
	InputPageComponent,
	ProgressBarPageComponent,
	RadioButtonPageComponent,
	RadioPageComponent,
	RangePageComponent,
	SearchBarPageComponent,
	SlideButtonPageComponent,
	SnackbarPageComponent,
	SpinnerPageComponent,
	SlideTogglePageComponent,
	TabsPageComponent,
	ThemePageComponent,
	TooltipPageComponent,
	DialogContentPageComponent,
	TokenComponent,
	DialogPaymentsNoConnectionComponent,
	TagPageComponent,
	IconButtonWebPageComponent,
	DialogWebPageComponent,
	AvatarWebPageComponent,
	IconBadgePageComponent,
	AvatarBadgePageComponent
];
