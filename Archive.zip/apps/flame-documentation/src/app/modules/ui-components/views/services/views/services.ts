import { OverlayPageComponent } from './overlay/overlay-page.component';
import { LoaderOverlayPageComponent } from './loader-overlay/loader-overlay-page.component';

export const SERVICES = [LoaderOverlayPageComponent, OverlayPageComponent];
