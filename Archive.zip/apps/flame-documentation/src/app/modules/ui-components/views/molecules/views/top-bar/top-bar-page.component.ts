import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sn-top-bar-page',
  templateUrl: './top-bar-page.component.html',
  styleUrls: ['./top-bar-page.component.scss']
})
export class TopBarPageComponent {

  constructor() { }
  public implementation = `<sn-top-bar title="Mis Productos">
  <div sn-left>
    <sn-icon icon="sn-SMOV018"></sn-icon>
  </div>
  <div sn-right>
    <sn-icon icon="sn-FUNC031"></sn-icon>
  </div>
</sn-top-bar>`;

}
