import { Component } from '@angular/core';

@Component({
  selector: 'sn-overview-view',
  templateUrl: 'overview-view.component.html',
  styleUrls: [ 'overview-view.component.scss' ]
})

export class OverviewViewComponent  {
  constructor() { }
}
