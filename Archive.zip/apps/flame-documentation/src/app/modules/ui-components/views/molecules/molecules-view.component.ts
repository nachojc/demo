import { Component } from '@angular/core';
import { SubMenu } from '../../../../components/menu-sidebar/models/sub-menu.model';

@Component({
	selector: 'sn-molecules-view',
	templateUrl: 'molecules-view.component.html',
	styleUrls: ['molecules-view.component.scss']
})
export class MoleculesViewComponent {
	constructor() {}
	public openMenu: boolean;

	public menu: Array<SubMenu> = [
		{
			groupName: 'molecules',
			menu: [
				{
					routerLink: '/ui-components/molecules/accounts-select',
					textContent: 'Accounts Select'
				},
				{
					routerLink: '/ui-components/molecules/nav-bar',
					textContent: 'Navbar'
				},
				{
					routerLink: '/ui-components/molecules/notification',
					textContent: 'Notificaction'
				},
				{
					routerLink: '/ui-components/molecules/product',
					textContent: 'Product'
				},
				{
					routerLink: '/ui-components/molecules/token-input',
					textContent: 'Token Input'
				},
				{
					routerLink: '/ui-components/molecules/dialog-select',
					textContent: 'Dialog Select'
				},
				{
					routerLink: '/ui-components/molecules/token-dialog',
					textContent: 'Token Dialog'
				},
				{
					routerLink: '/ui-components/molecules/top-bar',
					textContent: 'Top Bar'
				},
				{
					routerLink: '/ui-components/molecules/inversion',
					textContent: 'Inversion'
				},
				{
					routerLink: '/ui-components/molecules/transfer-field',
					textContent: 'Transfer Field'
				},
				{
					routerLink: '/ui-components/molecules/card-payment',
					textContent: 'Card Payment'
				},
				{
        routerLink: '/ui-components/molecules/token-input-web',
        textContent: 'Token Input Web'
      	},
				{
        routerLink: '/ui-components/molecules/avatar-welcome-web',
        textContent: 'AvatarWelcomeWeb'
      }
			]
		}
	];

	menuChange(status: boolean): void {
		this.openMenu = status;
	}

	closeMenu() {
		this.openMenu = false;
	}
}
