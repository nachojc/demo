import { Component } from '@angular/core';
import { NotificationService } from '@santander/flame-component-library';

@Component({
	selector: 'sn-notification-page',
	templateUrl: './notification-page.component.html',
	styleUrls: ['./notification-page.component.scss']
})
export class NotificationPageComponent {
	public language = 'html';
	public stepOne = `import { NotificationModule } from 'sn-component-library';
@NgModule({
	imports: [
		NotificationModule
	]
})`;

	public stepTwo = `import { NotificationService } from 'sn-component-library';

constructor(private notification: NotificationService) { }`;
	public stepThreeA = `showNotification() {
	this.notification.open({
		legend: 'Dialogo de Prueba',
		icon: 'sn-DOC007'
	});
}`;

	public stepThreeB = `showNotificationEmoji() {
	this.notification.open({
		legend: 'Dialogo de Prueba Emoji',
		type: 'thumbs_up',
		size: 'small'
	});
}`;

	public stepFourA = `<button sn-button (click)="showNotification()">Mostrar Notificación</button>`;
	public stepFourB = `<button sn-button (click)="showNotificationEmoji()">Mostrar Notificación</button>`;

	constructor( private notification: NotificationService ) { }

	showNotification() {
		this.notification.open({
			legend: 'Dialogo de Prueba',
			icon: 'sn-DOC007'
		});
	}

	showNotificationEmoji() {
		this.notification.open({
			legend: 'Dialogo de Prueba Emoji',
			type: 'thumbs_up',
			size: 'small'
		});
	}
}
