import { Component } from '@angular/core';

@Component({
	selector: 'sn-header-animation-page',
	templateUrl: './header-animation-page.component.html',
	styleUrls: ['./header-animation-page.component.scss']
})
export class HeaderAnimationPageComponent {
	/**
   *
   * variable publica
   * @memberof HeaderAnimationPageComponent
   */
  public language = 'html';

	/**
   * variable publica
   *
   * @memberof HeaderAnimationPageComponent
   */
  public caseOneContent = `<sn-top-bar title="Prueba header" [smHeaderName]="true">
  <div sn-left>
    <sn-icon icon="sn-SMOV004"></sn-icon>
  </div>
  <div sn-right class="mr-2">
    <sn-icon icon="sn-CHAN025"></sn-icon>
  </div>
</sn-top-bar>`;
}
