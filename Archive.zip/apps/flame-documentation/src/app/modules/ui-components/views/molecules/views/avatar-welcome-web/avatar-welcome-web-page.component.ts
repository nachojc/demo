import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-avatar-welcome-web-page',
	templateUrl: './avatar-welcome-web-page.component.html',
	styleUrls: ['./avatar-welcome-web-page.component.scss']
})
export class AvatarWelcomeWebPageComponent implements OnInit {
	constructor() {}
	public language = 'html';
	public languagejs = 'js';
	public caseOneContent = `<sn-avatar-welcome-web name="Alejandro Sánchez" sessionDate="17/ago/2019 - 05:32 h"></sn-avatar-welcome-web>`;

	ngOnInit() {}
}
