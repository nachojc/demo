import { Component, ViewEncapsulation } from '@angular/core';
import { SubMenu } from '../../../../components/menu-sidebar/models/sub-menu.model';

@Component({
	selector: 'sn-animations-view',
	templateUrl: 'animations.component.html',
	styleUrls: ['animations.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class AnimationsViewComponent {
	constructor() {}
	public openMenu: boolean;

	public menu: Array<SubMenu> = [
		{
			groupName: 'animations',
			menu: [
				{
					routerLink: '/ui-components/animations/generics',
					textContent: 'Animations'
				},
				{
					routerLink: '/ui-components/animations/header-animation',
					textContent: 'HeaderAnimation'
				}
			]
		}
	];
	menuChange(status: boolean): void {
		this.openMenu = status;
	}

	closeMenu() {
		this.openMenu = false;
	}
}
