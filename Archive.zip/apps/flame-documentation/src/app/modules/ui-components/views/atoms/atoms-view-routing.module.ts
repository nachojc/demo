import { DialogContentPageComponent } from './views/dialog-content/dialog-content-page.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Views
import { AvatarPageComponent } from './views/avatar/avatar-page.component';
import { ButtonPageComponent } from './views/button/button-page.component';
import { CardPageComponent } from './views/card/card-page.component';
import { CarouselPageComponent } from './views/carousel/carousel-page.component';
import { CheckboxPageComponent } from './views/checkbox/checkbox-page.component';
import { ChipPageComponent } from './views/chip/chip-page.component';
import { EmojiPageComponent } from './views/emoji/emoji-page.component';
import { FormFieldPageComponent } from './views/form-field/form-field-page.component';
import { HiddenButtonsPageComponent } from './views/hidden-buttons/hidden-buttons-page.component';
import { IconButtonPageComponent } from './views/icon-button/icon-button-page.component';
import { IconPageComponent } from './views/icon/icon-page.component';
import { InputPageComponent } from './views/input/input-page.component';
import { ProgressBarPageComponent } from './views/progress-bar/progress-bar-page.component';
import { RadioButtonPageComponent } from './views/radio-button/radio-button-page.component';
import { RadioPageComponent } from './views/radio/radio-page.component';
import { RangePageComponent } from './views/range/range-page.component';
import { SearchBarPageComponent } from './views/search-bar/search-bar-page.component';
import { SlideButtonPageComponent } from './views/slide-button/slide-button-page.component';
import { SnackbarPageComponent } from './views/snackbar/snackbar-page.component';
import { SpinnerPageComponent } from './views/spinner/spinner-page.component';
import { SlideTogglePageComponent } from './views/slide-toggle/slide-toggle-page.component';
import { TabsPageComponent } from './views/tabs/tabs-page.component';
import { ThemePageComponent } from './views/theme/theme-page.component';
import { TooltipPageComponent } from './views/tooltip/tooltip-page.component';
import { TagPageComponent } from './views/tag/tag-page.component';

// Components
import { AtomsViewComponent } from './atoms-view.component';
import { IconButtonWebPageComponent } from './views/icon-button-web/icon-button-web-page.component';
import { DialogWebPageComponent } from './views/dialog-web/dialog-web-page.component';
import { AvatarWebPageComponent } from './views/avatar-web/avatar-web-page.component';
import { IconBadgePageComponent } from './views/icon-badge/icon-badge-page.component';
import { AvatarBadgePageComponent } from './views/avatar-badge/avatar-badge-page.component';

const routes: Routes = [
	{
		path: '',
		component: AtomsViewComponent,
		children: [
			{
				path: 'avatar',
				component: AvatarPageComponent
			},
			{
				path: 'button',
				component: ButtonPageComponent
			},
			{
				path: 'card',
				component: CardPageComponent
			},
			{
				path: 'carousel',
				component: CarouselPageComponent
			},
			{
				path: 'checkbox',
				component: CheckboxPageComponent
			},
			{
				path: 'chip',
				component: ChipPageComponent
			},
			{
				path: 'emoji',
				component: EmojiPageComponent
			},
			{
				path: 'form-field',
				component: FormFieldPageComponent
			},
			{
				path: 'hidden-button',
				component: HiddenButtonsPageComponent
			},
			{
				path: 'icon-button',
				component: IconButtonPageComponent
			},
			{
				path: 'icon',
				component: IconPageComponent
			},
			{
				path: 'input',
				component: InputPageComponent
			},
			{
				path: 'progress-bar',
				component: ProgressBarPageComponent
			},
			{
				path: 'radio-button',
				component: RadioButtonPageComponent
			},
			{
				path: 'radio',
				component: RadioPageComponent
			},
			{
				path: 'range',
				component: RangePageComponent
			},
			{
				path: 'search-bar',
				component: SearchBarPageComponent
			},
			{
				path: 'slide-button',
				component: SlideButtonPageComponent
			},
			{
				path: 'snackbar',
				component: SnackbarPageComponent
			},
			{
				path: 'spinner',
				component: SpinnerPageComponent
			},
			{
				path: 'slide-toggle',
				component: SlideTogglePageComponent
			},
			{
				path: 'tabs',
				component: TabsPageComponent
			},
			{
				path: 'theme',
				component: ThemePageComponent
			},
			{
				path: 'tooltip',
				component: TooltipPageComponent
			},
			{
				path: 'tag',
				component: TagPageComponent
			},
			{
				path: 'dialog-content',
				component: DialogContentPageComponent
			},

			{
				path: 'icon-button-web',
				component: IconButtonWebPageComponent
			},

			{
				path: 'dialog-web',
				component: DialogWebPageComponent
			},
			{
				path: 'avatar-web',
				component: AvatarWebPageComponent
			},
			{
				path: 'icon-badge',
				component: IconBadgePageComponent
			},
			{
				path: 'avatar-badge',
				component: AvatarBadgePageComponent
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AtomsViewRoutingModule {}
