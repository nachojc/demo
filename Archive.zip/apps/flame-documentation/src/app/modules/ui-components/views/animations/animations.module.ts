import { PageHeaderModule } from './../../../../components/page-header/page-header.module';
import { HeaderAnimationPageComponent } from './header-animation/header-animation-page.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PrismModule } from '@ngx-prism/core';

// Components
import { MenuSideBarModule } from '../../../../components/menu-sidebar/menu-sidebar.module';
import { ComponentDocViewerModule } from '../../../../components/component-doc-viewer/component-doc-viewer.module';
import { GenericAnimationPageComponent } from './generic/generic-animation-page.component';
import { AnimationsViewRoutingModule } from './animations-routing.module';
import { AnimationsViewComponent } from './animations.component';
import {
	AvatarModule,
	ButtonModule,
	HeaderAnimationModule,
	IconModule,
	TopBarModule
} from '@santander/flame-component-library';

const LIBRARY_MODULE = [AvatarModule, ButtonModule];

const ANIMATIONS_COMPONENTS = [
	GenericAnimationPageComponent,
	HeaderAnimationPageComponent
];

@NgModule({
	imports: [
		...LIBRARY_MODULE,
		AnimationsViewRoutingModule,
		CommonModule,
		ComponentDocViewerModule,
		FormsModule,
		MenuSideBarModule,
		NgbModule,
		PrismModule,
		PageHeaderModule,
		ReactiveFormsModule,
		HeaderAnimationModule,
		IconModule,
		TopBarModule
	],
	declarations: [...ANIMATIONS_COMPONENTS, AnimationsViewComponent]
})
export class AnimationsViewModule {}
