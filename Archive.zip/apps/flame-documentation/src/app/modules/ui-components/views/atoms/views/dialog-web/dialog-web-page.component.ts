import { Component } from '@angular/core';
import { DialogWebService } from 'libs/core/flame-component-library/src/lib/atoms/dialog-web/dialog-web.service';
import { CustomContentComponent } from './custom-content/custom-content.component';
import { CustomWebDialog } from 'libs/core/flame-component-library/src/lib/atoms/dialog-web/dialog-web-custom';

@Component({
  selector: 'sn-dialog-web-page',
  templateUrl: './dialog-web-page.component.html',
  styleUrls: ['./dialog-web-page.component.scss']
})
export class DialogWebPageComponent {
    constructor(private _dialogService: DialogWebService) {}

    public languageJavascript = 'javascript';
    public exampleCustomComponent = `
      import { CustomContentComponent } from '../your-custom-route';
      import { CustomWebConfig, DialogWebService, CustomWebDialog } from '@santander/flame-component-library';

      ...
      constructor(private _dialogWebService: DialogWebService) {}
      openDialogWeb() {
        const config: any = {
          hasBackdrop: true,
          closeBackdropClick: true
        }
        const customWebDialog = new CustomWebDialog(CustomContentComponent);
        this._dialogWebService.open(config, customWebDialog);
      }
    `
    openDialogWeb() {
      const config: any = {
        hasBackdrop: true,
        closeBackdropClick: true
      }
      const customWebDialog = new CustomWebDialog(CustomContentComponent);
      this._dialogService.open(customWebDialog, config);
    }
}
