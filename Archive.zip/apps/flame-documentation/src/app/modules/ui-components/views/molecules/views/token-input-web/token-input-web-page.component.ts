import { Component } from '@angular/core';

@Component({
  selector: 'sn-token-input-web-page',
  templateUrl: './token-input-web-page.component.html',
  styleUrls: ['./token-input-web-page.component.scss']
})
export class TokenInputWebPageComponent {

    public error = true;
    public labelInfo = 'Escribe el código OTP de 8 dígitos que generaste en tu móvil.';
    public labelError = 'Aún hay un error. ¡Te queda un intento más!';
    public caseEightDigits = `<sn-token-input-web></sn-token-input-web>`;
    public caseFourDigits = `<sn-token-input-web [maxLength]="4" labelButton="Validar"></sn-token-input-web>`;
    public caseDisabled = `<sn-token-input-web [disabled]="true"></sn-token-input-web>`;
    public caseError = `
      <sn-token-input-web
        [error]="error"
        [labelError]="labelError"
        [labelInfo]="labelInfo"
      ></sn-token-input-web>`;
    public caseErrorTS = `
      public error = true;
      public labelInfo = 'Escribe el código OTP de 8 dígitos que generaste en tu móvil.';
      public labelError = 'Aún hay un error. ¡Te queda un intento más!';
    `;
}
