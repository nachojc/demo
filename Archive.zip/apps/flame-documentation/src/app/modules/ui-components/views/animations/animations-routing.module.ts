import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Views
import { AnimationsViewComponent } from './animations.component';

// Components
import { GenericAnimationPageComponent } from './generic/generic-animation-page.component';
import { HeaderAnimationPageComponent } from './header-animation/header-animation-page.component';

const routes: Routes = [
	{
		path: '',
		component: AnimationsViewComponent,
		children: [
			{
				path: 'generics',
				component: GenericAnimationPageComponent
			},
			{
				path: 'header-animation',
				component: HeaderAnimationPageComponent
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class AnimationsViewRoutingModule {}
