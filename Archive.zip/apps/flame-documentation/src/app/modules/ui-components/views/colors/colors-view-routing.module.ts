import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ColorsViewComponent } from './colors-view.component';

const routes: Routes = [
	{
		path: 'generics',
		component: ColorsViewComponent,
		children: []
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class ColorsViewRoutingModule {}
