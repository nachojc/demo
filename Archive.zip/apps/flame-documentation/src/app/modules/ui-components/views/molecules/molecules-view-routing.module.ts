import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Views
import { AccountsSelectPageComponent } from './views/accounts-select/accounts-select-page.component';
import { NavbarPageComponent } from './views/navbar/navbar-page.component';
import { NotificationPageComponent } from './views/notification/notification-page.component';
import { ProductPageComponent } from './views/product/product-page.component';

import { TokenInputPageComponent } from './views/token-input/token-input-page.component';
import { TopBarPageComponent } from './views/top-bar/top-bar-page.component';
import { InversionPageComponent } from './views/inversion/inversion-page.component';

// Components
import { MoleculesViewComponent } from './molecules-view.component';
import { DialogSelectPageComponent } from './views/dialog-select/dialog-select-page.component';
import { TokenDialogPageComponent } from './views/token-dialog/token-dialog-page.component';
import { TransferFieldPageComponent } from './views/transfer-field/transfer-field-page.component';
import { CardPaymentPageComponent } from './views/card-payment/card-payment-page.component';
import { TokenInputWebPageComponent } from './views/token-input-web/token-input-web-page.component';
import { AvatarWelcomeWebPageComponent } from './views/avatar-welcome-web/avatar-welcome-web-page.component';

const routes: Routes = [
	{
		path: '',
		component: MoleculesViewComponent,
		children: [
			{
				path: 'accounts-select',
				component: AccountsSelectPageComponent
			},
			{
				path: 'transfer-field',
				component: TransferFieldPageComponent
			},
			{
				path: 'nav-bar',
				component: NavbarPageComponent
			},
			{
				path: 'notification',
				component: NotificationPageComponent
			},
			{
				path: 'product',
				component: ProductPageComponent
			},
			{
				path: 'token-input',
				component: TokenInputPageComponent
			},
			{
				path: 'top-bar',
				component: TopBarPageComponent
			},
			{
				path: 'dialog-select',
				component: DialogSelectPageComponent
			},
			{
				path: 'token-dialog',
				component: TokenDialogPageComponent
			},
			{
				path: 'inversion',
				component: InversionPageComponent
			},
			{
				path: 'card-payment',
				component: CardPaymentPageComponent
			},
			
    {
      path: 'token-input-web',
      component: TokenInputWebPageComponent
    },
			
    
    {
      path: 'avatar-welcome-web',
      component: AvatarWelcomeWebPageComponent
    }
		]
	}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MoleculesViewRoutingModule { }
