import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sn-avatar-badge-page', 
  templateUrl: './avatar-badge-page.component.html',
  styleUrls: ['./avatar-badge-page.component.scss']
})
export class AvatarBadgePageComponent implements OnInit {
    constructor() {}

    ngOnInit() {

    }
}
