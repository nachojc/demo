import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
	selector: 'sn-radio-button-page',
	templateUrl: './radio-button-page.component.html',
	styleUrls: ['./radio-button-page.component.scss']
})
export class RadioButtonPageComponent implements OnInit {
	constructor() {}

	public language = 'html';
	public caseOneContent = `<sn-radio-button name="radio" value="1">
	Radio button
</sn-radio-button>`;
	public caseTwoContent = `<sn-radio-button name="radioChecked" value="1" checked>
	Radio button checked
</sn-radio-button>`;
	public caseThreeContent = `<sn-radio-button name="radioDisabled" value="1" disabled>
	Radio button disabled
</sn-radio-button>`;
	public caseFourContent = `<sn-radio-group name="radioGroup" >
  <sn-radio-button value="1">Radio button 1</sn-radio-button>
  <sn-radio-button value="2">Radio button 2</sn-radio-button>
  <sn-radio-button value="3">Radio button 3</sn-radio-button>
</sn-radio-group>`;
	public caseFiveContent = `<form [formGroup]="myForm">
  <sn-radio-group name="radioForm" formControlName="radioForm">
    <sn-radio-button value="1">Radio button 1</sn-radio-button>
    <sn-radio-button value="2">Radio button 2</sn-radio-button>
    <sn-radio-button value="3">Radio button 3</sn-radio-button>
  </sn-radio-group>
</form>`;

	public myForm: FormGroup;

	ngOnInit() {
		this.myForm = new FormGroup({
			radioForm: new FormControl(false)
		});
	}
}
