import { CopyTextService } from './../../../../../../../../libs/mobile/summary-operation-library/src/lib/services/copy-text.service';
import { Component } from '@angular/core';

@Component({
	selector: 'sn-colors-view',
	templateUrl: 'colors-view.component.html',
	styleUrls: ['colors-view.component.scss'],
	providers: [CopyTextService]
})
export class ColorsViewComponent {
	constructor(private copyTextService: CopyTextService) {}

	public brand = {
		primary: [
			{
				theme: 'flame-foundation',
				value: '#EC0000'
			},
			{
				theme: 'dark',
				value: '#EC0000'
			}
		],
		secondary: [
			{
				theme: 'flame-foundation',
				value: '#CC0000'
			},
			{
				theme: 'dark',
				value: '#CC0000'
			}
		],
		medium: [
			{
				theme: 'flame-foundation',
				value: '#CEDEE7'
			},
			{
				theme: 'dark',
				value: '#CEDEE7'
			}
		]
	};

	public neutrals = {
		white: [
			{
				theme: 'flame-foundation',
				value: '#FFFFFF'
			},
			{
				theme: 'dark',
				value: '#121212'
			}
		],
		white2: [
			{
				theme: 'flame-foundation',
				value: '#F7F7F7'
			},
			{
				theme: 'dark',
				value: '#212121'
			}
		],
		white3: [
			{
				theme: 'flame-foundation',
				value: '#F5F5F5'
			},
			{
				theme: 'dark',
				value: '#242424'
			}
		],
		white4: [
			{
				theme: 'flame-foundation',
				value: '#F4F4F4'
			},
			{
				theme: 'dark',
				value: '#242424'
			}
		],
		concrete: [
			{
				theme: 'flame-foundation',
				value: '#F2F2F2'
			},
			{
				theme: 'dark',
				value: '#262626'
			}
		],
		concrete2: [
			{
				theme: 'flame-foundation',
				value: '#F3F0F0'
			},
			{
				theme: 'dark',
				value: '#262626'
			}
		],
		concrete3: [
			{
				theme: 'flame-foundation',
				value: '#E9E9E9'
			},
			{
				theme: 'dark',
				value: '#303030'
			}
		],
		mercury: [
			{
				theme: 'flame-foundation',
				value: '#E5E5E5'
			},
			{
				theme: 'dark',
				value: '#333333'
			}
		],
		mercury2: [
			{
				theme: 'flame-foundation',
				value: '#E6E6E6'
			},
			{
				theme: 'dark',
				value: '#333333'
			}
		],
		mercury3: [
			{
				theme: 'flame-foundation',
				value: '#E3E3E3'
			},
			{
				theme: 'dark',
				value: '#363636'
			}
		],
		altoGray: [
			{
				theme: 'flame-foundation',
				value: '#D9D9D9'
			},
			{
				theme: 'dark',
				value: '#404040'
			}
		],
		altoGray2: [
			{
				theme: 'flame-foundation',
				value: '#D3D3D3'
			},
			{
				theme: 'dark',
				value: '#404040'
			}
		],
		lightGray: [
			{
				theme: 'flame-foundation',
				value: '#CCCCCC'
			},
			{
				theme: 'dark',
				value: '#4D4D4D'
			}
		],
		lightGray2: [
			{
				theme: 'flame-foundation',
				value: '#CACACA'
			},
			{
				theme: 'dark',
				value: '#4D4D4D'
			}
		],
		lightGray3: [
			{
				theme: 'flame-foundation',
				value: '#9B9B9B'
			},
			{
				theme: 'dark',
				value: '#7D7D7D'
			}
		],
		dustyGray: [
			{
				theme: 'flame-foundation',
				value: '#999999'
			},
			{
				theme: 'dark',
				value: '#808080'
			}
		],
		dustyGray2: [
			{
				theme: 'flame-foundation',
				value: '#979797'
			},
			{
				theme: 'dark',
				value: '#808080'
			}
		],
		dustyGray3: [
			{
				theme: 'flame-foundation',
				value: '#959595'
			},
			{
				theme: 'dark',
				value: '#858585'
			}
		],
		dustyGray4: [
			{
				theme: 'flame-foundation',
				value: '#828282'
			},
			{
				theme: 'dark',
				value: '#999999'
			}
		],
		dustyGray5: [
			{
				theme: 'flame-foundation',
				value: '#7C7C7C'
			},
			{
				theme: 'dark',
				value: '#9C9C9C'
			}
		],
		mediumGray: [
			{
				theme: 'flame-foundation',
				value: '#767676'
			},
			{
				theme: 'dark',
				value: '#A3A3A3'
			}
		],
		mediumGray2: [
			{
				theme: 'flame-foundation',
				value: '#666666'
			},
			{
				theme: 'dark',
				value: '#B3B3B3'
			}
		],
		scorpionGray: [
			{
				theme: 'flame-foundation',
				value: '#595959'
			},
			{
				theme: 'dark',
				value: '#BFBFBF'
			}
		],
		scorpionGray2: [
			{
				theme: 'flame-foundation',
				value: '#585858'
			},
			{
				theme: 'dark',
				value: '#C2C2C2'
			}
		],
		scorpionGray3: [
			{
				theme: 'flame-foundation',
				value: '#444444'
			},
			{
				theme: 'dark',
				value: '#D9D9D9'
			}
		],
		mineShaftGray: [
			{
				theme: 'flame-foundation',
				value: '#333333'
			},
			{
				theme: 'dark',
				value: '#E6E6E6'
			}
		],
		black: [
			{
				theme: 'flame-foundation',
				value: '#000000'
			},
			{
				theme: 'dark',
				value: '#FFFFFF'
			}
		]
	};
	public semanticColors = {
		attention: [
			{
				theme: 'flame-foundation',
				value: '#FFCC33'
			},
			{
				theme: 'dark',
				value: '#FFCC33'
			}
		],
		success: [
			{
				theme: 'flame-foundation',
				value: '#63B468'
			},
			{
				theme: 'dark',
				value: '#63B468'
			}
		],
		error: [
			{
				theme: 'flame-foundation',
				value: '#990000'
			},
			{
				theme: 'dark',
				value: '#FFA2A2'
			}
		]
	};
	public background = {
		background1: [
			{
				theme: 'flame-foundation',
				value: '#E5E5E5'
			},
			{
				theme: 'dark',
				value: '#000000'
			}
		],
		background2: [
			{
				theme: 'flame-foundation',
				value: '#F1F1F1'
			},
			{
				theme: 'dark',
				value: '#000000'
			}
		],
		surface: [
			{
				theme: 'flame-foundation',
				value: '#FFFFFF'
			},
			{
				theme: 'dark',
				value: '#121212'
			}
		],
		card: [
			{
				theme: 'flame-foundation',
				value: '#FFFFFF'
			},
			{
				theme: 'dark',
				value: '#191919'
			}
		]
	};
	copyColor(color: string) {
		this.copyTextService.copyText(color);
	}
}
