import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sn-token-input-page',
  templateUrl: './token-input-page.component.html',
  styleUrls: ['./token-input-page.component.scss']
})
export class TokenInputPageComponent implements OnInit {
  public caseFourDigits = `<sn-token-input   [maxLength]="4" [message]="'Introduce la clave de 4 digitos de SuperToken'"></sn-token-input>`;
  public caseEightDigits = `<sn-token-input autoFocus="true" [maxLength]="8" [message]="'Introduce la clave de 8 digitos de SuperToken'"></sn-token-input>`;
  public caseWithoutText = `<sn-token-input [maxLength]="4"></sn-token-input>`;
  public caseDisabled = `<sn-token-input [maxLength]="4" [disabled]=true ></sn-token-input>`;
  public caseError = `<sn-token-input [maxLength]="4" [error]=true ></sn-token-input>`;

  constructor() { }

  ngOnInit() {

  }

}
