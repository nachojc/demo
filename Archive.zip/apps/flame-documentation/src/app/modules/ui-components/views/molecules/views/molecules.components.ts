import { NavbarPageComponent } from './navbar/navbar-page.component';
import { ProductPageComponent } from './product/product-page.component';
import { TokenInputPageComponent } from './token-input/token-input-page.component';
import { TopBarPageComponent } from './top-bar/top-bar-page.component';
import { NotificationPageComponent } from './notification/notification-page.component';
import { AccountsSelectPageComponent } from './accounts-select/accounts-select-page.component';
import { TokenDialogPageComponent } from './token-dialog/token-dialog-page.component';
import { DialogSelectPageComponent } from './dialog-select/dialog-select-page.component';
import { InversionPageComponent } from './inversion/inversion-page.component';
import { TransferFieldPageComponent } from './transfer-field/transfer-field-page.component';
import { CardPaymentPageComponent } from './card-payment/card-payment-page.component';
import { TokenInputWebPageComponent } from './token-input-web/token-input-web-page.component';
import { AvatarWelcomeWebPageComponent } from './avatar-welcome-web/avatar-welcome-web-page.component';

export const MOLECULES_COMPONENTS = [
	NavbarPageComponent,
	ProductPageComponent,
	TokenInputPageComponent,
	TopBarPageComponent,
	NotificationPageComponent,
	AccountsSelectPageComponent,
	TokenDialogPageComponent,
	DialogSelectPageComponent,
	InversionPageComponent,
	TransferFieldPageComponent,
	CardPaymentPageComponent,
	TokenInputWebPageComponent,
	AvatarWelcomeWebPageComponent
];
