import { Component, OnInit, AfterContentInit } from '@angular/core';

@Component({
	selector: 'sn-accounts-select-page',
	templateUrl: './accounts-select-page.component.html',
	styleUrls: [ './accounts-select-page.component.scss' ]
})
export class AccountsSelectPageComponent {

  public accounts = [
    {
      alias: null,
      balance:{
        amount: 777777.78,
        currency_code: "MXN",
      },
      card_type: null,
      description: "SUPER NOMINA",
      display_number: "************4122",
      image_url: 75290302460,
      key: "056722751246",
      number: "************4122",
      product:{
        description: "SUPER NOMINA",
      },
      related_phone:{
        company: "TELCEL",
        phone_number: "5510555143",
      },
      status: "AVAILABLE",
      url: null,
    },
    {
      alias: null,
      balance:{
        amount: 1.78,
        currency_code: "MXN",
      },
      card_type: null,
      description: "Cuenta Digital",
      display_number: "************4100",
      image_url: null,
      key: "056700751246",
      number: "************4100",
      product:{
        description: "SUPER NOMINA",
      },
      related_phone:{
        company: "TELCEL",
        phone_number: "5510555143",
      },
      status: "AVAILABLE",
      url: null,
    }
  ];

	public account =this.accounts[0];

	public caseOneContent = `
    <sn-account-select
      title="Cuenta asociada:"
      dialogTitle="Selecciona una cuenta:"
      subtitle="Cuentas de débito"
      [accounts]="accounts"
      [(account)]="account"
    >
    </sn-account-select>
  `;

	public caseOneContentTs = `
  public accounts = [
    {
      alias: null,
      balance:{
        amount: 777777.78,
        currency_code: "MXN",
      },
      card_type: null,
      description: "SUPER NOMINA",
      display_number: "************4122",
      image_url: 75290302460,
      key: "056722751246",
      number: "************4122",
      product:{
        description: "SUPER NOMINA",
      },
      related_phone:{
        company: "TELCEL",
        phone_number: "5510555143",
      },
      status: "AVAILABLE",
      url: null,
    },
    {
      alias: null,
      balance:{
        amount: 1.78,
        currency_code: "MXN",
      },
      card_type: null,
      description: "Cuenta Digital",
      display_number: "************4100",
      image_url: null,
      key: "056700751246",
      number: "************4100",
      product:{
        description: "SUPER NOMINA",
      },
      related_phone:{
        company: "TELCEL",
        phone_number: "5510555143",
      },
      status: "AVAILABLE",
      url: null,
    }
  ];

public account =this.accounts[0];
  `;

  public accountInterface = `{
  alias: string;
  balance:{
    amount: number;
    currency_code: string;
  },
  card_type: string;
  description: string;
  display_number: string;
  image_url: number;
  key: string;
  number: string;
  product:{
    description:string;
  },
  related_phone:{
    company: string;,
    phone_number: number;
  },
  status: string;
  url: string;,
},`

	constructor() {
    this.accounts.forEach((item: any) => {
			item.product = {
				description: item.description
			};
			item.number = item.display_number;
    });
  }

}
