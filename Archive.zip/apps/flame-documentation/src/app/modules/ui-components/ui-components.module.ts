import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// Router
import { UIComponentsRoutingModule } from './ui-components-routing.module';

// Components
import { ComponentDocViewerModule } from '../../components/component-doc-viewer/component-doc-viewer.module';
import { MenuSideBarModule } from '../../components/menu-sidebar/menu-sidebar.module';
import { OverviewViewComponent } from './views/overview/overview-view.component';
import { UIComponentsComponent } from './ui-components.component';

@NgModule({
	imports: [
		CommonModule,
		UIComponentsRoutingModule,
		ComponentDocViewerModule,
		MenuSideBarModule
	],
	declarations: [OverviewViewComponent, UIComponentsComponent]
})
export class UIComponentsModule {}
