import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { PrismModule } from '@ngx-prism/core';
import {
	ButtonModule,
	CheckboxModule,
	FormFieldModule,
	InputModule,
	SpinnerModule,
	SlideToggleModule,
	StepGroupModule,
	ProgressBarModule,
	IconModule,
	TooltipModule,
	CarouselModule,
	ThemeModule,
	FlameFoundationTheme,
	DialogModule,
	NavbarModule,
	TopBarModule,
	CardModule,
	IconButtonModule,
	SlideButtonModule,
	TabGroupModule,
	RadioButtonModule,
	AvatarModule,
	ChipModule,
	ProductModule
} from '@santander/flame-component-library';

// Router
import { UIComponentsRoutingModule } from './ui-components-routing.module';

// Atoms Components
import { ATOMS_COMPONENTS } from './components/atoms/atoms.components';

// Molecules Components
import { MOLECULES_COMPONENTS } from './components/molecules/molecules.components';
// Organisms Components
// Services
import { SERVICES } from './components/services/services';

// Customs Theme
import { ZurichTheme } from './components/atoms/theme/zurich.theme';

// Components
import { UIComponentsComponent } from './ui-components.component';
import { SidebarComponent } from '../../components/sidebar/side.bar.component';
import { ComponentDocViewerComponent } from '../../components/component-doc-viewer/component-doc-viewer.component';
import { ConstructorDocComponent } from '../../components/component-doc-viewer/components/constructor-doc/constructor-doc.component';
import { PropertiesDocComponent } from '../../components/component-doc-viewer/components/properties-doc/properties-doc.component';
import { AccessorsDocComponent } from '../../components/component-doc-viewer/components/accessors-doc/accessors-doc.component';
import { MethodsDocComponent } from '../../components/component-doc-viewer/components/methods-doc/methods-doc.component';

@NgModule({
	imports: [
		ButtonModule,
		AvatarModule,
		CheckboxModule,
		CommonModule,
		UIComponentsRoutingModule,
		FormFieldModule,
		FormsModule,
		IconModule,
		InputModule,
		NavbarModule,
		NgbModule,
		PrismModule,
		ProgressBarModule,
		ReactiveFormsModule,
		SlideButtonModule,
		SlideToggleModule,
		HttpClientModule,
		SpinnerModule,
		StepGroupModule,
		TooltipModule,
		CarouselModule,
		TabGroupModule,
		RadioButtonModule,
		TopBarModule,
		IconButtonModule,
		ChipModule,
		ProductModule,
		ThemeModule.forRoot({
			themes: [FlameFoundationTheme, ZurichTheme],
			active: 'zurich'
		}),
		DialogModule,
		CardModule
	],
	declarations: [
		...ATOMS_COMPONENTS,
		...MOLECULES_COMPONENTS,
		...SERVICES,
		AccessorsDocComponent,
		ComponentDocViewerComponent,
		ConstructorDocComponent,
		MethodsDocComponent,
		PropertiesDocComponent,
		UIComponentsComponent,
		SidebarComponent
	]
})
export class UIComponentsModule {}
