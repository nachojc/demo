import { Component } from '@angular/core';
import { SubMenu } from '../../components/menu-sidebar/models/sub-menu.model';

@Component({
	selector: 'sn-components',
	templateUrl: './ui-components.component.html',
	styleUrls: ['./ui-components.component.scss']
})
export class UIComponentsComponent {
	constructor() {}

	public menu: Array<SubMenu> = [
		{
			groupName: 'atoms',
			menu: [
				{
					routerLink: '/atoms',
					textContent: 'atoms'
				}
			]
		},
		{
			groupName: 'molecules',
			menu: [
				{
					routerLink: '/molecules',
					textContent: 'molecules'
				}
			]
		},
		{
			groupName: 'organism',
			menu: [
				{
					routerLink: '/organism',
					textContent: 'organism'
				}
			]
		},
		{
			groupName: 'services',
			menu: [
				{
					routerLink: '/services',
					textContent: 'Services'
				}
			]
		},
		{
			groupName: 'animations',
			menu: [
				{
					routerLink: '/animations/generics',
					textContent: 'Animations'
				}
			]
		}
	];
}
