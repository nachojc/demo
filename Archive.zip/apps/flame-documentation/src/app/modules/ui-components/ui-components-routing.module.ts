import { OverviewViewComponent } from './views/overview/overview-view.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UIComponentsComponent } from './ui-components.component';

const routes: Routes = [
	{
		path: '',
		component: UIComponentsComponent,
		children: [
			{
				path: 'overview',
				component: OverviewViewComponent
			},
			{
				path: 'atoms',
				loadChildren: './views/atoms/atoms-view.module#AtomsViewModule'
			},
			{
				path: 'molecules',
				loadChildren:
					'./views/molecules/molecules-view.module#MoleculesViewModule'
			},
			{
				path: 'services',
				loadChildren: './views/services/services-view.module#ServicesViewModule'
			},
			{
				path: 'animations',
				loadChildren:
					'./views/animations/animations.module#AnimationsViewModule'
			},
			{
				path: 'colors',
				loadChildren: './views/colors/colors-view.module#ColorsViewModule'
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class UIComponentsRoutingModule {}
