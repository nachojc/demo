import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Atoms Components
import { AvatarPageComponent } from './components/atoms/avatar/avatar-page.component';
import { ButtonPageComponent } from './components/atoms/button/button-page.component';
import { CardPageComponent } from './components/atoms/card/card-page.component';
import { CarouselPageComponent } from './components/atoms/carousel/carousel-page.component';
import { CheckboxPageComponent } from './components/atoms/checkbox/checkbox-page.component';
import { ChipPageComponent } from './components/atoms/chip/chip-page.component';
import { DateTimePickerPageComponent } from './components/atoms/date-time-picker/date-time-picker-page.component';
import { FormFieldPageComponent } from './components/atoms/form-field/form-field-page.component';
import { IconButtonPageComponent } from './components/atoms/icon-button/icon-button-page.component';
import { IconPageComponent } from './components/atoms/icon/icon-page.component';
import { InputPageComponent } from './components/atoms/input/input-page.component';

import { ProgressBarPageComponent } from './components/atoms/progress-bar/progress-bar-page.component';
import { RadioButtonPageComponent } from './components/atoms/radio-button/radio-button-page.component';
import { RadioPageComponent } from './components/atoms/radio/radio-page.component';
import { RangePageComponent } from './components/atoms/range/range-page.component';
import { SlideButtonPageComponent } from './components/atoms/slide-button/slide-button-page.component';
import { SpinnerPageComponent } from './components/atoms/spinner/spinner-page.component';
import { StepperPageComponent } from './components/atoms/stepper/stepper-page.component';
import { SwitchPageComponent } from './components/atoms/switch/switch-page.component';
import { TabsPageComponent } from './components/atoms/tabs/tabs-page.component';
import { TextareaPageComponent } from './components/atoms/textarea/textarea-page.component';
import { ThemePageComponent } from './components/atoms/theme/theme-page.component';
import { TooltipPageComponent } from './components/atoms/tooltip/tooltip-page.component';

// Molecules Components
import { BottomSheetDialogPageComponent } from './components/molecules/bottom-sheet-dialog/bottom-sheet-dialog-page.component';
import { NavbarPageComponent } from './components/molecules/navbar/navbar-page.component';
import { ProductPageComponent } from './components/molecules/product/product-page.component';
import { SelectDialogPageComponent } from './components/molecules/select-dialog/select-dialog-page.component';
import { SideMenuPageComponent } from './components/molecules/side-menu/side-menu-page.component';
import { SnackbarPageComponent } from './components/molecules/snackbar/snackbar-page.component';
import { TokenInputPageComponent } from './components/molecules/token-input/token-input-page.component';
import { TopBarPageComponent } from './components/molecules/top-bar/top-bar-page.component';

// Services
import { OverlayPageComponent } from './components/services/overlay/overlay-page.component';

// Components
import { UIComponentsComponent } from './ui-components.component';

const routes: Routes = [
	{
		path: '',
		component: UIComponentsComponent,
		children: [
			{
				path: 'checkbox',
				component: CheckboxPageComponent
			},
			{
				path: 'input',
				component: InputPageComponent
			},
			{
				path: 'spinner',
				component: SpinnerPageComponent
			},
			{
				path: 'button',
				component: ButtonPageComponent
			},
			{
				path: 'date-time-picker',
				component: DateTimePickerPageComponent
			},
			{
				path: 'form-field',
				component: FormFieldPageComponent
			},
			{
				path: 'progress-bar',
				component: ProgressBarPageComponent
			},
			{
				path: 'radio-button',
				component: RadioButtonPageComponent
			},
			{
				path: 'range',
				component: RangePageComponent
			},
			{
				path: 'side-menu',
				component: SideMenuPageComponent
			},
			{
				path: 'snackbar',
				component: SnackbarPageComponent
			},
			{
				path: 'stepper',
				component: StepperPageComponent
			},
			{
				path: 'tabs',
				component: TabsPageComponent
			},
			{
				path: 'textarea',
				component: TextareaPageComponent
			},
			{
				path: 'theme',
				component: ThemePageComponent
			},
			{
				path: 'tooltip',
				component: TooltipPageComponent
			},
			{
				path: 'chip',
				component: ChipPageComponent
			},
			{
				path: 'top-bar',
				component: TopBarPageComponent
			},
			{
				path: 'nav-bar',
				component: NavbarPageComponent
			},
			{
				path: 'token-input',
				component: TokenInputPageComponent
			},
			{
				path: 'carousel',
				component: CarouselPageComponent
			},
			{
				path: 'icon',
				component: IconPageComponent
			},
			{
				path: 'icon-button',
				component: IconButtonPageComponent
			},
			{
				path: 'slide-button',
				component: SlideButtonPageComponent
			},
			{
				path: 'switch',
				component: SwitchPageComponent
			},
			{
				path: 'ovelay',
				component: OverlayPageComponent
			},
			{
				path: 'card',
				component: CardPageComponent
			},
			{
				path: 'avatar',
				component: AvatarPageComponent
			},
			{
				path: 'bottom-sheet-dialog',
				component: BottomSheetDialogPageComponent
			},
			{
				path: 'radio',
				component: RadioPageComponent
			},
			{
				path: 'select-dialog',
				component: SelectDialogPageComponent
			},
			{
				path: 'overlay',
				component: OverlayPageComponent
			},
			{
				path: 'product',
				component: ProductPageComponent
			}
		]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class UIComponentsRoutingModule {}
