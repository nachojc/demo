import { Component } from '@angular/core';
import { SubMenu } from '../../components/menu-sidebar/models/sub-menu.model';

@Component({
	selector: 'sn-guide',
	templateUrl: './guide.component.html',
	styleUrls: ['./guide.component.scss']
})
export class GuideComponent {
  constructor() {}
}
