import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MenuSideBarModule } from '../../components/menu-sidebar/menu-sidebar.module';
import { MarkdownModule } from 'ngx-markdown';
// Router
import { GuideRoutingModule } from './guide-routing.module';

// Components
import { GuideComponent } from './guide.component';
import { OperationViewComponent } from './views/operation/operation-view.component';

@NgModule({
	imports: [
		CommonModule,
		GuideRoutingModule,
    FormsModule,
		ReactiveFormsModule,
    MenuSideBarModule,
    MarkdownModule.forRoot()
	],
	declarations: [
    GuideComponent,
    OperationViewComponent
	]
})
export class GuideModule {}
