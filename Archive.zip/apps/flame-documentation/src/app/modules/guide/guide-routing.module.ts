import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Components
import { GuideComponent } from './guide.component';
import { OperationViewComponent } from './views/operation/operation-view.component';

const routes: Routes = [
	{
		path: '',
    component: GuideComponent,
    children: [{
      path: 'operation',
      component: OperationViewComponent
    }]
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class GuideRoutingModule {}
