import { Component } from '@angular/core';
import { SubMenu } from '../../../../components/menu-sidebar/models/sub-menu.model';

@Component({
  selector: 'sn-operation-view',
  templateUrl: 'operation-view.component.html',
  styleUrls: [ 'operation-view.component.scss' ]
})

export class OperationViewComponent  {
  constructor() { }
  public markdown = `
  ## Operativas
  \`\`\`shell
  npm run workspace-schematic sn-lib-operation
  \`\`\`

  ### *Librería*
    * Crea la estructura de una operativa dentro de la carpeta *libs*

  ### *App*
    * Modifica el fichero *tsconfig.json* de la aplicación indicada para incluir la carga de la librería en la construcción de la aplicación.
    * Añada la librería al router principal de la aplicación de manera lazy:
      * La ruta añadida corresponde con el nombre de la operativa.
  `;

  public menu: Array<SubMenu> = [
    {
      groupName: 'Schematics',
      menu: [
        {
          routerLink: 'operation',
          textContent: 'Operation'
        }
      ]
    }
  ]
}
