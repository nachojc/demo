# Santander Generator

[Angular CLI](https://cli.angular.io/) y [nrwl Workspace](https://nrwl.io/nx/guide-nx-workspace) nos ofrecen la posibilidad de crear *componentes* y *librerías* a través de línea de comandos, facilitando la generación de ficheros y la actualización de las configuraciones del entorno.

**flame-workspace** esta construido con estas herramientas, pero presenta una serie de características diferentes a las que ofrecen dichas herramientas.

Para incluir las características que tiene **flame-workspace** hemos creado generadores personalizados para la creación de:

## Operativas

```shell
npm run workspace-schematic sn-lib-operation
```

### *Librería*
  * Crea la estructura de una operativa dentro de la carpeta *libs*

### *App*
  * Modifica el fichero *tsconfig.json* de la aplicación indicada para incluir la carga de la librería en la construcción de la aplicación.
  * Añada la librería al router principal de la aplicación de manera lazy:
    * La ruta añadida corresponde con el nombre de la operativa.

## Componentes

```shell
npm run workspace-schematic sn-lib-component
```
### *Librería*
  * Crea la estructura de un componente en la librería de componentes donde se le indique:
    * Atoms.
    * Molecules.
  * Crea el fichero *index.ts* dentro del componente y exporta su módulo.
  * Actualiza el fichero *index.ts* de la librería **flame-component-library** para exportar el componente.

### *Catalogo*
  * Crea la estructura para generar la documentación dentro del proyecto **flame-documentation**.
  * Actualiza el menú para incluir el componente generado.
