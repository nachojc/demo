import { NO_ERRORS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { GuideComponent } from './guide.component';
import {
	FormFieldModule,
	InputModule
} from '@santander/flame-component-library';

describe('GuideComponent', () => {
	let component: GuideComponent;
	let fixture: ComponentFixture<GuideComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [FormFieldModule, InputModule],
			declarations: [GuideComponent],
			schemas: [NO_ERRORS_SCHEMA]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(GuideComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
