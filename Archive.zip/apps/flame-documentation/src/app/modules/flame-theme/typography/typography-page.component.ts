// import { Component, OnInit } from '@angular/core';

// @Component({
// 	selector: 'sn-typography-page',
// 	templateUrl: './typography-page.component.html',
// 	styleUrls: ['./typography-page.component.scss']
// })
// export class TypographyPageComponent implements OnInit {
// 	constructor() {}

// 	public caseOneContent = `<!-- h1 -->
// <h1>Sample Text</h1>

// h2 -->
// <h2>Sample Text</h2>

// <!-- h3 -->
// <h3>Sample Text</h3>

// <!-- h4 -->
// <h4>Sample Text</h4>

// <!-- h5 -->
// <h5>Sample Text</h5>

// <!-- h6 -->
// <h6>Sample Text</h6>

// <!-- p -->
// <p>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>

// <!-- Number Level 1 -->
// <p class="sn-number lvl-1"><span class="sn-symbol">$</span>67,898.99 <span class="sn-currency">MXN</span></p>

// <!-- Number Level 2 -->
// <p class="sn-number lvl-2"><span class="sn-symbol">$</span>67,898.99 <span class="sn-currency">MXN</span></p>

// <!-- Number Level 3 -->
// <p class="sn-number lvl-3"><span class="sn-symbol">$</span>67,898.99 <span class="sn-currency">MXN</span></p>

// <!-- Number Level 4 -->
// <p class="sn-number lvl-4"><span class="sn-symbol">$</span>67,898.99 <span class="sn-currency">MXN</span></p>`;

// 	ngOnInit() {}
// }
