import { Component, EventEmitter, Output, Input } from '@angular/core';

@Component({
	selector: 'sn-page-header',
	templateUrl: './page-header.component.html',
	styleUrls: ['./page-header.component.scss']
})
export class PageHeaderComponent {
	constructor() {}
	@Input() open = false;
	@Output() changeStatusMenu = new EventEmitter<boolean>();

	public toggleMenu(): void {
		this.open = !this.open;
		this.changeStatusMenu.emit(this.open);
	}
}
