import { PageHeaderComponent } from './page-header.component';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconModule } from '@santander/flame-component-library';

@NgModule({
	declarations: [PageHeaderComponent],
	imports: [CommonModule, IconModule],
	exports: [PageHeaderComponent]
})
export class PageHeaderModule {}
