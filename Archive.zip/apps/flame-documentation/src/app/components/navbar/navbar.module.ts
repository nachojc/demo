import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Components
import { NavbarComponent } from './navbar.component';
import {
	NgbDropdownModule,
	NgbTooltipModule,
	NgbTabsetModule
} from '@ng-bootstrap/ng-bootstrap';
import { IconModule } from '@santander/flame-component-library';

@NgModule({
	imports: [
		CommonModule,
		FormsModule,
		ReactiveFormsModule,
		RouterModule,
		NgbDropdownModule,
		NgbTooltipModule,
		IconModule,
		NgbTabsetModule
	],
	declarations: [NavbarComponent],
	exports: [NavbarComponent]
})
export class NavbarModule {}
