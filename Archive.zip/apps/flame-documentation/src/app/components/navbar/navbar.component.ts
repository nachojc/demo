import { Component, Input, ViewEncapsulation } from '@angular/core';

interface MenuItem {
	title: string;
	link: string;
}

@Component({
	selector: 'sn-navbar',
	templateUrl: 'navbar.component.html',
	styleUrls: ['navbar.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class NavbarComponent {
	constructor() {}

	private _logoSrc: string;
	private _title: string;
	private _alignContent: string;
	private _menu: Array<MenuItem>;

	public openMenu = false;

	@Input()
	get logoSrc(): string {
		return this._logoSrc;
	}
	set logoSrc(value: string) {
		this._logoSrc = value;
	}

	@Input()
	get title(): string {
		return this._title;
	}
	set title(value: string) {
		this._title = value;
	}

	@Input()
	get alignContent(): string {
		return this._alignContent;
	}
	set alignContent(value: string) {
		this._alignContent = value;
	}

	@Input()
	get menu(): Array<MenuItem> {
		return this._menu;
	}
	set menu(value: Array<MenuItem>) {
		this._menu = value;
	}

	public toggleMenu() {
		this.openMenu = !this.openMenu;
	}
}
