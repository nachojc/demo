import { Component, Input, ViewEncapsulation, OnInit } from '@angular/core';
import { ThemeService } from '@santander/flame-component-library';

interface MenuItem {
	title: string;
	link: string;
}

@Component({
	selector: 'sn-navbar',
	templateUrl: 'navbar.component.html',
	styleUrls: ['navbar.component.scss']
})
export class NavbarComponent implements OnInit {
	constructor(private _snTheme: ThemeService) {}

	private _logoSrc: string;
	private _title: string;
	private _alignContent: string;
	private _menu: Array<MenuItem>;
	public myTheme: string;
	public openMenu = false;

	@Input()
	get logoSrc(): string {
		return this._logoSrc;
	}
	set logoSrc(value: string) {
		this._logoSrc = value;
	}

	@Input()
	get title(): string {
		return this._title;
	}
	set title(value: string) {
		this._title = value;
	}

	@Input()
	get alignContent(): string {
		return this._alignContent;
	}
	set alignContent(value: string) {
		this._alignContent = value;
	}

	@Input()
	get menu(): Array<MenuItem> {
		return this._menu;
	}
	set menu(value: Array<MenuItem>) {
		this._menu = value;
	}

	ngOnInit() {
		this.myTheme = this._snTheme.getActiveTheme().name;
	}

	public toggleMenu() {
		this.openMenu = !this.openMenu;
	}

	changeTheme(theme: string) {
		this._snTheme.setTheme(theme);
		localStorage.setItem('theme', theme);
	}
}
