import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class DocViewerService {
	constructor(private _httpClient: HttpClient) {}

	getDocData(libryName: string, docUrl: string) {
		return this._httpClient.get(
			`./assets/docs/libs/${libryName}/${docUrl}/doc.json`
		);
	}
}
