import { Component, Input, OnInit } from '@angular/core';
import { Accessor, Property, Method } from './models';
import { DocViewerService } from './services/doc-viewer.service';

const lifecycleHooks = [
	'ngOnChanges',
	'ngOnInit',
	'ngDoCheck',
	'ngAfterContentInit',
	'ngAfterContentChecked',
	'ngAfterViewInit',
	'ngAfterViewChecked',
	'ngOnDestroy'
];

@Component({
	selector: 'sn-component-doc-viewer',
	templateUrl: 'component-doc-viewer.component.html',
	styleUrls: ['component-doc-viewer.component.scss']
})
export class ComponentDocViewerComponent implements OnInit {
	constructor(private _docViewerService: DocViewerService) {}

	public docData: any;
	public groups: Array<number>;
	public constructors: any;
	public properties: any;
	public accessors: any;
	public methods: any;

	@Input() docUrl: string;
	@Input() libraryName: string;

	private getGroupsIds(groups: Array<number>, groupName: string) {
		return groups.filter(group => group['title'].toLowerCase() === groupName);
	}

	private getConstructorInfo(docData: any, groups: Array<number>) {
		const info = [];
    const groupIds = this.getGroupsIds(groups, 'constructors');
    if (groupIds.length > 0) {
      groupIds[0]['children'].forEach((value: any) => {
        docData.children.filter((data: any) => {
          if (data.id === value) {
            info.push(data);
          }
        });
      });
      return info[0];
    } else {
      return null;
    }
	}

	private getPropertiesInfo(docData: any, groups: Array<number>) {
		const info: Array<Property> = [];
    const groupIds = this.getGroupsIds(groups, 'properties');
    if (groupIds.length > 0) {
      groupIds[0]['children'].forEach((value: any) => {
        docData.children.filter((data: any) => {
          if (data.id === value && data.flags.hasOwnProperty('isPublic')) {
            info.push({
              name: data.name,
              type: data.type.name,
              description: data.comment.shortText
            })
          }
        });
      });
      return info;
    } else {
      return null;
    }
	}

	private getAccessorsInfo(docData: any, groups: Array<number>) {
		const info: Array<Accessor> = []
    const groupIds = this.getGroupsIds(groups, 'accessors');
    if (groupIds.length > 0) {
      groupIds[0]['children'].forEach((value: any) => {
        docData.children.filter((data: any) => {
          if (data.id === value) {
            info.push({
              accessorName: `@${data.decorators[0].name}`,
              name: data.name,
              type: data.comment.tags[0].text,
              description: data.comment.shortText
            });
          }
        });
      });
      return info;
    } else {
      return null;
    }
	}

	private getMethodsInfo(docData: any, groups: Array<number>) {
		const info: Array<Method> = [];
    const groupIds = this.getGroupsIds(groups, 'methods');
    if (groupIds.length > 0) {
      groupIds[0]['children'].forEach((value: any) => {
        docData.children.filter((data: any) => {
          if (
            data.id === value &&
            !data.flags.hasOwnProperty('isPrivate') &&
            lifecycleHooks.indexOf(data.name) === -1
          ) {
            info.push({
              name: data.name,
              returns: data.signatures[0].type.name,
              description: data.signatures[0].comment.shortText
            });
          }
        });
      });
      return info;
    } else {
      return null;
    }
	}

	ngOnInit() {
		this._docViewerService
			.getDocData(this.libraryName, this.docUrl)
			.subscribe((res: any) => {
				this.docData = res.children[0].children[0];
				this.groups = this.docData.groups;
				this.constructors = this.getConstructorInfo(this.docData, this.groups);
				this.properties = this.getPropertiesInfo(this.docData, this.groups);
				this.accessors = this.getAccessorsInfo(this.docData, this.groups);
				this.methods = this.getMethodsInfo(this.docData, this.groups);
			});
	}
}
