import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Components
import { ComponentDocViewerComponent } from './component-doc-viewer.component';
import { AccessorsDocComponent } from './components/accessors-doc/accessors-doc.component';
import { ConstructorDocComponent } from './components/constructor-doc/constructor-doc.component';
import { MethodsDocComponent } from './components/methods-doc/methods-doc.component';
import { PropertiesDocComponent } from './components/properties-doc/properties-doc.component';
import { DocViewerService } from './services/doc-viewer.service';

@NgModule({
	imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
  ],
	declarations: [
		ComponentDocViewerComponent,
		AccessorsDocComponent,
		ConstructorDocComponent,
		MethodsDocComponent,
		PropertiesDocComponent
	],
  exports: [ ComponentDocViewerComponent ],
  providers: [DocViewerService]
})
export class ComponentDocViewerModule {}
