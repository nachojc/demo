export interface Accessor {
  accessorName: string;
  name: string;
  type: string;
  description: string
}
