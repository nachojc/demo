export * from './property.interface';
export * from './accessor.interface';
export * from './method.interface';
