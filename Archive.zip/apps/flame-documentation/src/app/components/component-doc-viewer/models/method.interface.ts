export interface Method {
  name: string;
  returns: string;
  description: string;
}
