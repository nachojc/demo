import { Component, Input, OnInit } from '@angular/core';

@Component({
	selector: 'sn-constructor-doc',
	templateUrl: 'constructor-doc.component.html',
	styleUrls: ['constructor-doc.component.scss']
})
export class ConstructorDocComponent implements OnInit {
	constructor() {}

	public arguments: any;

	@Input() constructorData: any;

	ngOnInit() {
		this.arguments = this.constructorData.signatures[0].parameters;
	}
}
