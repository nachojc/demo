import { Component, Input } from '@angular/core';

@Component({
	selector: 'sn-properties-doc',
	templateUrl: 'properties-doc.component.html',
	styleUrls: ['properties-doc.component.scss']
})
export class PropertiesDocComponent {
	constructor() {}

	@Input() propertiesData: any;
}
