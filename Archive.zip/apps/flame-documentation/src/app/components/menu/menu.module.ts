import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


// Components
import { MenuComponent } from './menu.component';

@NgModule({
	imports: [
		CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
	],
	declarations: [
		MenuComponent
  ],
  exports: [
    MenuComponent
  ]
})
export class MenuModule {}
