import { Component, Input } from '@angular/core';

interface MenuItem {
	title: string;
	link: string;
}

@Component({
	selector: 'sn-menu',
	templateUrl: 'menu.component.html',
	styleUrls: ['menu.component.scss']
})
export class MenuComponent {
	constructor() {}

	private _menu: Array<MenuItem>;

	@Input()
	get menu(): Array<MenuItem> {
		return this._menu;
	}
	set menu(value: Array<MenuItem>) {
		this._menu = value;
	}
}
