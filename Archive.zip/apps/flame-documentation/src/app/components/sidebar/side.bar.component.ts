import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-sidebar',
	templateUrl: 'side.bar.component.html',
	styleUrls: ['side.bar.component.scss']
})
export class SidebarComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
