export interface MenuItem {
  routerLink: string;
  textContent: string;
}
