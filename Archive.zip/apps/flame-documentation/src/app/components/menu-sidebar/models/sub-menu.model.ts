import { MenuItem } from './menu-item.model';

export interface SubMenu {
  groupName: string;
  menu: Array<MenuItem>;
}
