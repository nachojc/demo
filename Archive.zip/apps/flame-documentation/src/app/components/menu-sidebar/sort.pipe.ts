import { MenuItem } from './models/menu-item.model';
import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
	name: 'sort'
})
export class SortPipe implements PipeTransform {
	transform(array: Array<MenuItem>, args: string): Array<MenuItem> {
		return array.sort((a, b) => (a.textContent > b.textContent ? 1 : -1));
	}
}
