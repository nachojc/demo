import {
  Component,
  Input
} from '@angular/core';
import { SubMenu } from './models/sub-menu.model';

@Component({
	selector: 'sn-menu-sidebar.',
	templateUrl: 'menu-sidebar.component.html',
	styleUrls: ['menu-sidebar.component.scss']
})
export class MenuSidebarComponent {

  constructor() {}

  @Input() menu: Array<SubMenu>;

}
