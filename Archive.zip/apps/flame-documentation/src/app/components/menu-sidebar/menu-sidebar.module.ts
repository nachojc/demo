import { SortPipe } from './sort.pipe';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


// Components
import { MenuSidebarComponent } from './menu-sidebar.component';

@NgModule({
	imports: [
		CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule
	],
	declarations: [
    MenuSidebarComponent,
    SortPipe
  ],
  exports: [
    MenuSidebarComponent
  ]
})
export class MenuSideBarModule {}
