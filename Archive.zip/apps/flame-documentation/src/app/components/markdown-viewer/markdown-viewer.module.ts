import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Components
import { MarkdownViewerComponent } from './markdown-viewer.component';

@NgModule({
	imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
	declarations: [
		MarkdownViewerComponent
	]
})
export class MarkdownViewerModule {}
