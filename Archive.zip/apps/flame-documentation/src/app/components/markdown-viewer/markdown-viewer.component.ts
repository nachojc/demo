import { Component } from '@angular/core';

@Component({
	selector: 'sn-markdown-viewer',
	templateUrl: 'markdown-viewer.component.html',
	styleUrls: ['markdown-viewer.component.scss']
})
export class MarkdownViewerComponent {
}
