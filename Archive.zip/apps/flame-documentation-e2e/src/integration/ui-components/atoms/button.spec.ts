import {
	navigateAtoms,
	clickComponentByName
} from '../../../support/navigation.po';

describe('Button atom component', function() {
	before(function() {
		navigateAtoms();
	});

	it('should navigate to the ui components page', () => {
		clickComponentByName('Button');
		cy.get('.my-2');
	});
});
