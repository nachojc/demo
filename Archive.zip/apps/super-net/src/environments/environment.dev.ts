export const environment = {
	production: false,
	sm: {
		clientId: 'm_NJTtSdQWQvQPNQrjvL-fL1_EXJEVZ9jt65RX5nOfo'
	},
	idp: {
		url: 'http://localhost:3001/IDPWeb/idp',
		redirectUri: 'https://nsw-front-mx-santander-web-dev.appls.cto1.paas.gsnetcloud.corp/',
		stateLength: 20
	},
	oauth: {
		url: 'http://localhost:3001/oauth2/v1/token',
		scope: 'summary_1.0.0 accounts_1.0.0'
	},
	api: {
		url: 'http://localhost:3001/api',
		version: {
			authentication: '',
			summary: '',
			accounts: '',
			credits: '',
			cards: '',
			transfers: '',
			customers: '',
			insurance: '',
			payments: '',
			policies: '',
			payees: ''
		}
	}
};
