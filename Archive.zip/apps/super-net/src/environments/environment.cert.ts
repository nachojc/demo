export const environment = {
  production: true,
  sm: {
    clientId: 'm_NJTtSdQWQvQPNQrjvL-fL1_EXJEVZ9jt65RX5nOfo'
  },
  idp: {
    url: 'https://wsidttlm1mxr301.cert.mx.corp:1443/IDPWeb/idp',
    redirectUri: 'https://nsw-front-mx-santander-web-dev.appls.cto1.paas.gsnetcloud.corp/',
		stateLength: 20
  },
  oauth: {
    url: 'https://front-grants-bussupport-comsrvc-security-pf-dev.appls.cto1.paas.gsnetcloud.corp/oauth2/v1/token',
    scope: 'Summary_1.0.1 accounts_2.0.1 credits_1.1.0 payments_2.0.0 cards_1.0.0 transfers_1.0.0 customers_1.0.0'
},
  api: {
    url: 'https://webapigateway.dev.mx.corp/santander-mexico/factorias',
    version: {
      authentication: 'v1',
      summary: 'v2',
      accounts: 'v2',
      credits: 'v1',
      cards: 'v1',
      transfers: 'v1',
      insurance: 'v1',
      policies: 'v1',
      customers: 'v1',
      payees: 'v1',
      payments: 'v2'
    }
  }
 };
