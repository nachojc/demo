import { InjectionToken } from '@angular/core';

export interface TokenStep {
	/**
	 * Titulo de la instrucción.
	 *
	 * @type {string}
	 * @memberof TokenStep
	 */
	title: string;

	/**
	 * Mensaje complementario que indica el paso a realizar.
	 *
	 * @type {string}
	 * @memberof TokenStep
	 */
	label: string;
}

export interface TokenAttemp {
	/**
	 * Número del intentos fallidos.
	 *
	 * @type {number}
	 * @memberof TokenAttemp
	 */
	attemp: number;

	/**
	 * Mensaje de aviso para cada intento fallido.
	 *
	 * @type {string}
	 * @memberof TokenAttemp
	 */
	label: string;
}

export const BLOCK: TokenAttemp[] = [
	{ 
		attemp: 1,
		label: 'Parece que hay un error. Aún tienes 2 intentos más.' 
	},
	{
		attemp: 2,
		label: 'Aún hay un error. ¡Te queda un intento más! ' 
	},
	{ 
		attemp: 4,
		label: 'Hay un error. Tienes un intento más antes de un bloqueo temporal' 
	}
];

export const UNLOCK: TokenStep[] = [
	{
		title: '¡Oh no!',
		label: 'Bloqueaste tu SuperToken. Desbloquéalo para hacer cualquier operación'
	},
	{
		title: '¡Desbloquea tu NIP Dinámico!',
		label: 'Ingresa un primer código de 8 dígitos con el SuperToken de tu móvil.'
	},
	{
		title: '¡Ya casi desbloqueas tu NIP!',
		label: 'Ahora ingresa un segundo código con el SuperToken de tu móvil.'
	}
];

export const SYNCHRONIZE: TokenStep[] = [
	{
		title: 'Necesitas sincronizar tu NIP Dinámico',
		label: 'Da click en el botón para continuar ¡sólo son 2 pasos!'
	},
	{
		title: '¡Sincroniza tu NIP Dinámico! ',
		label: 'Ingresa un primer código de 8 dígitos con el SuperToken de tu móvil.'
	},
	{
		title: '¡Ya casi sincronizas tu NIP! ',
		label: 'Ahora ingresa un segundo código con el SuperToken de tu móvil.'
	}
];


export const STEPS_UNLOCK = new InjectionToken('TOKEN_STEPS');
export const STEPS_SYNCHRONIZE = new InjectionToken('TOKEN_STEPS');
export const ATTEMPS_BLOCK = new InjectionToken('TOKEN_ATTEMPS');