import { ErrorDialogComponent } from './../../../super-mobile/src/app/components/error-dialog/error-dialog.component';
import { environment } from '../environments/environment';
import {
	ThemeModule,
	FlameFoundationTheme,
	IconModule,
	EmojiModule,
	AvatarWelcomeWebModule,
	ButtonModule,
	DialogWebModule,
	TokenInputWebModule
} from '@santander/flame-component-library';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';
import { NxModule } from '@nrwl/nx';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import {
	ENV_CONFIG,
	AuthenticationService,
	IdpService,
	CryptoService,
	CustomerService
} from '@santander/flame-core-library';
import { Overlay } from '@angular/cdk/overlay';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { registerLocaleData } from '@angular/common';

import localeEsMX from '@angular/common/locales/es-MX';
import { WELCOME_BAR, RULES_WELCOME_BAR } from './common/rules-welcome-bar';
import { ForceLogoutService } from './services/force-logout.service';
import { HttpClientModule } from '@angular/common/http';
import { SUPER_NET_COMPONENTS, SUPER_NET_ENTRY_COMPONENTS } from './components';
import { SuperTokenDialogService } from './services/super-token-dialog.service';
registerLocaleData(localeEsMX, 'es-MX');

const COMPONENTS = [
	DialogWebModule,
	EmojiModule,
	IconModule,
	AvatarWelcomeWebModule,
	ButtonModule,
	TokenInputWebModule,
	ThemeModule.forRoot({
		themes: [FlameFoundationTheme],
		active: 'flame-foundation'
	})
];
@NgModule({
	declarations: [AppComponent, ErrorDialogComponent, ...SUPER_NET_COMPONENTS],
	imports: [
		AppRoutingModule,
		BrowserModule,
		BrowserAnimationsModule,
		HttpClientModule,
		NxModule.forRoot(),
		...COMPONENTS
	],
	providers: [
		AuthenticationService,
		CustomerService,
		IdpService,
		CryptoService,
		Overlay,
		ForceLogoutService,
		SuperTokenDialogService,
		{
			provide: ENV_CONFIG,
			useValue: environment
		},
		{ provide: LOCALE_ID, useValue: 'es-MX' },
		{
			provide: RULES_WELCOME_BAR,
			useValue: WELCOME_BAR
		}
	],
	bootstrap: [AppComponent],
	entryComponents: [ErrorDialogComponent, ...SUPER_NET_ENTRY_COMPONENTS]
})
export class AppModule { }
