import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IdpFakeViewComponent } from './idp-fake-view.component';
import {
	DialogWebModule,
	ButtonModule,
	DialogWebReference
} from '@santander/flame-component-library';

/**
 * Clase Mock para pruebas de Dialog Reference.
 *
 * @class DialogReferenceMock
 */
class DialogReferenceMock {
	/**
	 * Funcion mock para la prueba
	 *
	 * @param {boolean} result
	 * @returns
	 * @memberof DialogReferenceMock
	 */
	close(result: boolean) {
		return 'closed';
	}
}

describe('IdpFakeViewComponent', () => {
	let component: IdpFakeViewComponent;
	let fixture: ComponentFixture<IdpFakeViewComponent>;
	let reference: DialogReferenceMock;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [IdpFakeViewComponent],
			imports: [DialogWebModule, ButtonModule],
			providers: [
				{
					provide: DialogWebReference,
					useClass: DialogReferenceMock
				}
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(IdpFakeViewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();

		reference = TestBed.get(DialogWebReference);
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should close component with true result', () => {
		spyOn(reference, 'close').and.callThrough();
		component.onClose(true);
		expect(reference.close).toHaveBeenCalled();
	});

	it('should close component with false result', () => {
		spyOn(reference, 'close').and.callThrough();
		component.onClose(false);
		expect(reference.close).toHaveBeenCalled();
	});
});
