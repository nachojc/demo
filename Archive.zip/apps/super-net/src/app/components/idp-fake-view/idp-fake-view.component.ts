import { Component } from '@angular/core';
import { DialogWebReference } from '@santander/flame-component-library';

/**
 * Componente usado para simular el paso por IDP y obtener un code de acceso.
 *
 * @export
 * @class IdpFakeViewComponent
 */
@Component({
	selector: 'nsw-idp-fake-view',
	styleUrls: ['idp-fake-view.scss'],
	template: `
		<div class="text-wrapper"><p>IDP Flow Simulation</p></div>
		<div class="actions">
			<button sn-button (click)="onClose(true)">OK</button>
			<button sn-button-secondary (click)="onClose(false)">ERROR</button>
		</div>
	`
})
export class IdpFakeViewComponent {

	/**
	 * Crea una instancia de IdpFakeViewComponent.
	 * @param {DialogWebReference} dialog
	 * @memberof IdpFakeViewComponent
	 */
	constructor(public dialog: DialogWebReference) {}

	/**
	 * Cierra el dialog
	 *
	 * @param {boolean} result
	 * @memberof IdpFakeViewComponent
	 */
	public onClose(result: boolean) {
		if (result) {
			this.dialog.close(true);
		} else {
			this.dialog.close(false);
		}
	}
}
