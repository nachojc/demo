import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SuperTokenVoucherComponent } from './super-token-voucher.component';
import { IconModule } from '@santander/flame-component-library';

describe('SuperTokenVoucherComponent', () => {
  let component: SuperTokenVoucherComponent;
  let fixture: ComponentFixture<SuperTokenVoucherComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SuperTokenVoucherComponent ],
      imports: [IconModule]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SuperTokenVoucherComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load data', () => {
    const info = {
      title: 'Success',
      date: new Date()
    };
    component.data = info;
    component.ngOnInit();
    expect(component.title).toBe(info.title);
    expect(component.date).toBe(info.date);
  });

  it('should generate new Date', () => {
    const info = {
      title:''
    };
    component.data = info;
    component.ngOnInit();
    expect(component.date).toBeTruthy();
  });
});
