import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'nsw-super-token-voucher',
	templateUrl: './super-token-voucher.component.html',
	styleUrls: ['./super-token-voucher.component.scss']
})
export class SuperTokenVoucherComponent implements OnInit {
	public data: any;
	public title = '¡Desbloqueaste tu NIP Dinámico!';
	public date: string | Date;

	constructor() {}

	ngOnInit() {
		if (this.data) {
			this.title = this.data.title;
			this.date = this.data.date ? this.data.date : new Date();
		}
	}
}
