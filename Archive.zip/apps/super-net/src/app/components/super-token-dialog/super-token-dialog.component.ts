import {
	STEPS_UNLOCK,
	STEPS_SYNCHRONIZE,
	ATTEMPS_BLOCK,
	BLOCK,
	SYNCHRONIZE,
	UNLOCK,
	TokenStep,
	TokenAttemp
} from './../../constants/super-token.constants';
import { CustomDialogComponent } from '@santander/flame-component-library';
import { Component, Inject } from '@angular/core';
import {
	SuperTokenWebService,
	ErrorToken,
	StepInfo
} from '../../services/super-token-web.service';

/**
 * Entry component que se presenta en un dialogo para introducir el OTP.
 * Incluye además los flujos de desbloqueo y sincronización.
 *
 * @export
 * @class TokenDialogComponent
 * @implements {CustomDialogComponent}
 */
@Component({
	selector: 'nsw-super-token-dialog',
	templateUrl: './super-token-dialog.component.html',
	styleUrls: ['./super-token-dialog.component.scss'],
	providers: [
		{
			provide: STEPS_UNLOCK,
			useValue: UNLOCK
		},
		{
			provide: STEPS_SYNCHRONIZE,
			useValue: SYNCHRONIZE
		},
		{
			provide: ATTEMPS_BLOCK,
			useValue: BLOCK
		}
	]
})
export class SuperTokenDialogComponent implements CustomDialogComponent {
	/**
	 * Crea una instancia de SuperTokenDialogComponent.
	 * @param {TokenStep[]} _stepsUnlock
	 * @param {TokenStep[]} _stepsSynchronize
	 * @param {SuperTokenService} _superTokenService
	 * @memberof SuperTokenDialogComponent
	 */
	constructor(
		@Inject(STEPS_UNLOCK) private _stepsUnlock: TokenStep[],
		@Inject(STEPS_SYNCHRONIZE) private _stepsSynchronize: TokenStep[],
		@Inject(ATTEMPS_BLOCK) private _attempsBlock: TokenAttemp[],
		private _superTokenService: SuperTokenWebService
	) {}

	/**
	 * Labels por default para Introducir Token
	 *
	 * @private
	 * @memberof SuperTokenDialogComponent
	 */
	private defaultLabels = {
		header: 'Accede con tu clave dinámica',
		label:
			'Esta operación requiere autorización de un OTP. Ingrese el código generado en su dispositivo móvil.'
	};

	/**
	 * Objeto que contiene un EventEmitter y un mensaje de error de ser necesario.
	 *
	 * @type {*}
	 * @memberof SuperTokenDialogComponent
	 */
	public data: any;

	/**
	 * Emite el valor del OTP introducido en el componente `sn-token-input-web`.
	 *
	 * @param {string} otp
	 * @memberof SuperTokenDialogComponent
	 */
	public sendOtp(otp: string) {
		this.data.error = '';
		if (this._superTokenService.stateSyncToken > 0) {
			this.manageOTP(otp, this._stepsSynchronize);
			return;
		} else if (this._superTokenService.stateUnlockToken > 0) {
			this.manageOTP(otp, this._stepsUnlock, 'unlock');
			return;
		}
		// TODO: Validación Temporal de OTP para iniciar flujo de bloqueo.
		if (otp === '11111111') {
			this.manageValidate();
		} else {
			this.data.tokenEmitter.emit(otp);
		}
	}

	/**
	 * Setea localmente las propiedades que responde el servicio.
	 *
	 * @param {string} otp
	 * @param {TokenStep[]} steps
	 * @param {string} [type]
	 * @memberof SuperTokenDialogComponent
	 */
	public manageOTP(otp: string, steps: TokenStep[], type?: string) {
		const serviceRef = this._superTokenService
			.sendOTP(otp, steps, type)
			.subscribe(
				(response: StepInfo) => {
					this.data.header =
						response.label === '' ? this.defaultLabels.header : response.title;
					this.data.label =
						response.label === '' ? this.defaultLabels.label : response.label;
					this.data.btnLabel = response.labelButton;
					serviceRef.unsubscribe();
				},
				(error: ErrorToken) => {
					this.data.error = error.labelErrorToken;
				}
			);
	}

	/**
	 * Setea localmente las propiedades que responde el servicio.
	 *
	 * @memberof SuperTokenDialogComponent
	 */
	public manageValidate() {
		const infoLabel: any = this._superTokenService.validateAttemps(
			this._stepsUnlock,
			this._stepsSynchronize,
			this._attempsBlock
		);
		if (infoLabel.hasOwnProperty('title')) {
			this.data.header = infoLabel.title;
			this.data.label = infoLabel.label;
			this.data.btnLabel = infoLabel.labelButton;
		} else {
			this.data.error = infoLabel.labelErrorToken;
		}
	}
}
