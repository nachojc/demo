import { Observable, of } from 'rxjs';
import { getTestBed, fakeAsync, flush, tick } from '@angular/core/testing';
import { EventEmitter, Injector } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import {
	TokenInputWebModule,
	DialogWebModule
} from '@santander/flame-component-library';
import { SuperTokenDialogComponent } from './super-token-dialog.component';
import {
	STEPS_UNLOCK,
	STEPS_SYNCHRONIZE,
	ATTEMPS_BLOCK,
	BLOCK,
	SYNCHRONIZE,
	UNLOCK,
	TokenStep,
	TokenAttemp
} from './../../constants/super-token.constants';
import { SuperTokenWebService } from '../../services/super-token-web.service';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('SuperTokenDialogComponent', () => {
	let component: SuperTokenDialogComponent;
	let fixture: ComponentFixture<SuperTokenDialogComponent>;
	let service: SuperTokenWebService;
	let inject: Injector;
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [TokenInputWebModule, DialogWebModule, BrowserAnimationsModule],
			declarations: [SuperTokenDialogComponent],
			providers: [
				{
					provide: STEPS_UNLOCK,
					useValue: UNLOCK
				},
				{
					provide: STEPS_SYNCHRONIZE,
					useValue: SYNCHRONIZE
				},
				{
					provide: ATTEMPS_BLOCK,
					useValue: BLOCK
				},
				SuperTokenWebService
			]
		}).compileComponents();

		inject = getTestBed();
		service = inject.get(SuperTokenWebService);
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(SuperTokenDialogComponent);
		component = fixture.componentInstance;
		component.data = {
			tokenEmitter: new EventEmitter<string>()
		};
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should emit OTP value', () => {
		spyOn(component.data.tokenEmitter, 'emit');
		component.sendOtp('88888888');
		expect(component.data.tokenEmitter.emit).toHaveBeenCalled();
	});

	it('should manage incorrect OTP value', () => {
		component.sendOtp('11111111');
		expect(component.data.error).toBeDefined();
	});

	it('should start to synchronize and unlock SuperToken', fakeAsync(() => {
		component.sendOtp('11111111');
		component.sendOtp('11111111');
		component.sendOtp('11111111');
		// 3 Incorrectos

		component.sendOtp('11111111');
		tick();
		flush();
		expect(component.data.error).toBeDefined();

		expect(component.data.btnLabel).toBe('Sincronizar');
		const title = SYNCHRONIZE[2].title;
		const label = SYNCHRONIZE[2].label;
		component.sendOtp('88888888');
		tick();
		flush();
		expect(component.data.label).toBe(label);
		expect(component.data.header).toBe(title);
		component.sendOtp('88888888');
		tick();
		flush();
		component.sendOtp('11111111');
		component.sendOtp('11111111');
		component.sendOtp('11111111');
		// 5 incorrectos
		const titleU = UNLOCK[2].title;
		const labelU = UNLOCK[2].label;
		component.sendOtp('88888888');
		tick();
		flush();
		expect(component.data.label).toBe(labelU);
		expect(component.data.header).toBe(titleU);
	}));
});
