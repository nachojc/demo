import { SuperTokenDialogComponent } from './super-token-dialog/super-token-dialog.component';
import { SuperTokenVoucherComponent } from './super-token-voucher/super-token-voucher.component';
import { ForceLogoutConfirmComponent } from './force-logout-confirm/force-logout-confirm.component';
import { WelcomeBarComponent } from './welcome-bar/welcome-bar.component';
import { AccessViewComponent } from './access-view/access-view.component';
import { IdpFakeViewComponent } from './idp-fake-view/idp-fake-view.component';

export const SUPER_NET_COMPONENTS = [
	AccessViewComponent,
	ForceLogoutConfirmComponent,
	IdpFakeViewComponent,
	SuperTokenDialogComponent,
	SuperTokenVoucherComponent,
	WelcomeBarComponent
];

export const SUPER_NET_ENTRY_COMPONENTS = [
	ForceLogoutConfirmComponent,
	IdpFakeViewComponent,
	SuperTokenDialogComponent,
	SuperTokenVoucherComponent,
	ForceLogoutConfirmComponent
];
