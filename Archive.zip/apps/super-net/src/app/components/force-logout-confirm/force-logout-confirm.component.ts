import { Component } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';
import { AuthenticationService } from '@santander/flame-core-library';
import { ForceLogoutConfirm } from '../../interfaces/force-logout-confirm.interface';
import { catchError } from 'rxjs/operators';
import { of } from 'rxjs';

/**
 * Entry component para confirmar un cierre de sesión forzado por alguna acción (redirect, etc)
 *
 * @export
 * @class ForceLogoutConfirmComponent
 * @implements {CustomDialogComponent}
 */
@Component({
	selector: 'nsw-force-logout-confirm',
	templateUrl: 'force-logout-confirm.component.html',
	styleUrls: ['force-logout-confirm.component.scss']
})
export class ForceLogoutConfirmComponent implements CustomDialogComponent {
	/**
	 * Crea una instancia de ForceLogoutConfirmComponent.
	 * @param {AuthenticationService} _authenticationService
	 * @memberof ForceLogoutConfirmComponent
	 */
	constructor(private _authenticationService: AuthenticationService) {}

	/**
	 * Información necesaria para mostrar en el componente.
	 *
	 * @type {ForceLogoutConfirm}
	 * @memberof ForceLogoutConfirmComponent
	 */
	public data: ForceLogoutConfirm;

	/**
	 * Realiza el cierre de sesión mediante el AuthenticationService.
	 *
	 * @memberof ForceLogoutConfirmComponent
	 */
	public handleLogout() {
		// TODO: Manejar el error del cierre de sesión.
		this._authenticationService
			.revokeSession()
			.pipe(catchError(err => of([])))
			.subscribe(() => {
				const url = this.data.redirectUrl;
				if (url) {
					this.redirect(url);
				}
			});
	}

	/**
	 * Redirige a una ruta si se proporciona.
	 *
	 * @memberof ForceLogoutConfirmComponent
	 */
	public redirect(url: string) {
		window.location.href = url;
	}
}
