import { getTestBed } from '@angular/core/testing';
import {
	ButtonModule,
	AvatarWelcomeWebModule,
	IconModule
} from '@santander/flame-component-library';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ForceLogoutConfirmComponent } from './force-logout-confirm.component';
import {
	AuthenticationService,
	ENV_CONFIG
} from '@santander/flame-core-library';
import { HttpClientModule } from '@angular/common/http';
import { ForceLogoutConfirm } from '../../interfaces/force-logout-confirm.interface';
import { of } from 'rxjs';

describe('ForceLogoutConfirmComponent', () => {
	let component: ForceLogoutConfirmComponent;
	let fixture: ComponentFixture<ForceLogoutConfirmComponent>;
	let service: AuthenticationService;
	let injector: TestBed;
	const dataDefault: ForceLogoutConfirm = {
		body: '¡Estás por salir de este sitio!',
		title:
			'Se cerrará automáticamente la sesión abierta con Banco Santander México S.A. y se ...',
		imageUrl: './assets/images/force-logout-confirm.png',
		redirectUrl: 'https://www.banxico.org.mx/cep/go?i=40014&s=20150819&d'
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarWelcomeWebModule,
				ButtonModule,
				IconModule,
				HttpClientModule
			],
			declarations: [ForceLogoutConfirmComponent],
			providers: [
				AuthenticationService,
				{
					provide: ENV_CONFIG,
					useValue: {
						sm: {
							clientId: '0KxtKPNZzUIMueEfxeP6x_NKWPJLRREWHEHsyOw1a4w'
						},
						api: {
							url: 'http://localhost:3001/api',
							version: {
								authentication: ''
							}
						}
					}
				}
			]
		}).compileComponents();

		injector = getTestBed();
		service = injector.get(AuthenticationService);
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ForceLogoutConfirmComponent);
		component = fixture.componentInstance;
		component.data = dataDefault;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should handle logout and redirect', () => {
		spyOn(component, 'redirect');
		spyOn(service, 'revokeSession').and.returnValue(of([]));
		component.handleLogout();
		expect(service.revokeSession).toHaveBeenCalled();
		expect(component.redirect).toHaveBeenCalledWith(dataDefault.redirectUrl);
	});
});
