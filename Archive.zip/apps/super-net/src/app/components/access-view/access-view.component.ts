import { switchMap, mergeMap, tap } from 'rxjs/operators';
import { Component, OnInit, Input, Inject } from '@angular/core';
import {
	AuthenticationService,
	OAuthToken,
	IdpService,
	ENV_CONFIG,
	CustomerService
} from '@santander/flame-core-library';
import {
	DialogWebService,
	CustomWebDialog
} from '@santander/flame-component-library';
import { IdpFakeViewComponent } from '../idp-fake-view/idp-fake-view.component';
import { of, iif } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import * as CryptoJS from 'crypto-js';

/**
 * Componente para conectar con IDP
 *
 * @export
 * @class WelcomeBarComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'nsw-access-view',
	templateUrl: 'access-view.component.html',
	styleUrls: ['access-view.component.scss']
})
export class AccessViewComponent implements OnInit {
	/**
	 * Crea una instancia de AccessViewComponent.
	 * @param {*} environment
	 * @param {AuthenticationService} _authenticationService
	 * @param {DialogWebService} _dialog
	 * @param {Router} _router
	 * @param {ActivatedRoute} _activatedRoute
	 * @param {IdpService} _idpService
	 * @memberof AccessViewComponent
	 */
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _authenticationService: AuthenticationService,
		private _dialog: DialogWebService,
		private _router: Router,
		private _activatedRoute: ActivatedRoute,
		private _idpService: IdpService,
		private _customerService: CustomerService
	) {}

	/**
	 * Code default usado para hacer un paso fake por IDP
	 *
	 * @private
	 * @memberof AccessViewComponent
	 */
	private defaultCode = 'cIoCBHooKMMz1nDCuHg7NAW2ZXvlshJ8OtSjphyHjsgNUQ==';

	/**
	 * PartialObserver para mapear la respuesta de Oauth
	 * @todo redireccionar a mi vida cuando este listo el flujo
	 * @private
	 * @memberof AccessViewComponent
	 */
	private partialObserver = {
		next: (response: any) => {
			if (response) {
				sessionStorage.setItem('customer', JSON.stringify(response.data));
				this._router.navigate(['/my-life']);
			}
		},
		error: () => {
			// TODO: Handle error
		}
	};

	/**
	 * Genera un valor opaco aleatorio, recomendado para IDP, se almacena en el sessionStorage para una futura validación
	 *
	 * @private
	 * @returns {string} valor opaco state
	 * @memberof AccessViewComponent
	 */
	private generateRandomState(): string {
		const state = CryptoJS.enc.Base64.stringify(
			CryptoJS.lib.WordArray.random(this.environment.idp.stateLength)
		)
			.replace(/\+/g, '-')
			.replace(/\//g, '-')
			.replace(/\=/g, '');
		sessionStorage.setItem('idp_state', state);
		return state;
	}

	/**
	 * Obtiene el valor opaco generado para asociar la invocación inicial del IDP con la respuesta.
	 * Permite validar la veracidad de la respuesta de IDP.
	 *
	 * @private
	 * @returns
	 * @memberof AccessViewComponent
	 */
	private getState() {
		const state = sessionStorage.getItem('idp_state');
		sessionStorage.removeItem('idp_state');
		return state;
	}

	/**
	 * Simula la recuperación de un code de IDP
	 *
	 * @private
	 * @memberof AccessViewComponent
	 */
	private fakeIdp() {
		this._dialog
			.open(new CustomWebDialog(IdpFakeViewComponent))
			.beforeClose()
			.pipe(
				switchMap(doAttempt =>
					doAttempt ? this.getAccessToken(this.defaultCode) : of(doAttempt)
				),
				switchMap((token: OAuthToken) => this.saveToken(token))
			)
			.subscribe(this.partialObserver);
	}

	private saveToken(token: OAuthToken) {
		if (token) {
			const responseOauth: string = JSON.stringify(token);
			sessionStorage.setItem('oauthToken', responseOauth);
			return this.getCustomer();
		}
	}

	private getCustomer() {
		return this._customerService.getMe();
	}

	/**
	 * Obtiene el access_token de Oauth
	 *
	 * @private
	 * @param {string} code
	 * @returns {Observable<any>} - Llama a Oauth con el code de IDP
	 * @memberof AccessViewComponent
	 */
	private getAccessToken(code: string) {
		return this._authenticationService.getAccessToken(code);
	}

	/**
	 * Obtiene la Url de IDP y coloca la ruta del redirect_uri y el state generado para este inicio de sesión.
	 *
	 * @private
	 * @returns {string}
	 * @memberof AccessViewComponent
	 */
	private getUrl(): string {
		return `${this._idpService.getBaseUrl()}&state=${this.generateRandomState()}`;
	}

	/**
	 * Procesa el code recuperado por queryparams de IDP
	 *
	 * @private
	 * @memberof AccessViewComponent
	 */
	private catchCode() {
		this._activatedRoute.queryParams
			.pipe(
				tap((params: any) => {
					// sino hay un code como queryParam y esta en producción, redirige al login por IDP
					if (!params.code && this.environment.production) {
						// TODO: Mejorar la forma de llamar a IDP
						window.location.href = this.getUrl();
					}
				}),
				mergeMap((params: any) => {
					return iif(
						// Si se tiene el code y el state es el mismo al enviado (para mitigar ataques de tipo CSRF) pasa el code a Oauth
						() => params.code && params.state === this.getState(),
						this.getAccessToken(params.code)
					);
				}),
				switchMap((token: OAuthToken) => this.saveToken(token))
			)
			.subscribe(this.partialObserver);
	}

	/**
	 * Realiza un proceso fake de inicio en IDP
	 *
	 * @memberof AccessViewComponent
	 */
	public idpLoginIntent() {
		this.fakeIdp();
	}

	/**
	 * Subscribe a los cambios de queryparams
	 *
	 * @memberof AccessViewComponent
	 */
	ngOnInit(): void {
		this.catchCode();
	}
}
