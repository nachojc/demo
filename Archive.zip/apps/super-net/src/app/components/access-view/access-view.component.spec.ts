import {
	HttpClientTestingModule,
	HttpTestingController
} from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing';
import {
	ButtonModule,
	DialogWebModule,
	DialogWebService,
	DialogWebReference
} from '@santander/flame-component-library';
import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed
} from '@angular/core/testing';
import { AccessViewComponent } from './access-view.component';
import {
	IdpService,
	AuthenticationService,
	ENV_CONFIG,
	CryptoService,
	CustomerService
} from '@santander/flame-core-library';
import { environment } from 'apps/super-net/src/environments/environment';
import { ActivatedRoute, Router } from '@angular/router';
import { of } from 'rxjs';
import { HttpRequest } from '@angular/common/http';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { IdpFakeViewComponent } from '../idp-fake-view/idp-fake-view.component';

describe('AccessViewComponent', () => {
	let activeRoute: ActivatedRoute;
	let router: Router;

	let injector: TestBed;
	const customersMe = {
		data: {
			key: '4e20fbb243684d9eb19ff33a50ee422e',
			buc: '123456789',
			name: 'Ana Maria',
			second_name: 'Hernandez',
			last_name: 'Gutierrez',
			status: 'ACTIVE',
			personal_identifier: 'MARE921122HJKDLN01',
			bank_segment: null,
			contact_method: 'EMAIL',
			contact_info: [
				{
					type: 'BRANCH_USE',
					phone_number: '(55)-55-46-89-79',
					mobile_number: '(044)-55-46-89-79-12',
					email: 'mail@mail.com',
					status: 'REGISTERED'
				}
			]
		},
		notifications: [
			{
				code: 'SUCCESS',
				message: 'Success',
				timestamp: '2019-02-12T16:39:09.842Z'
			}
		]
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				BrowserAnimationsModule,
				ButtonModule,
				DialogWebModule,
				RouterTestingModule,
				HttpClientTestingModule
			],
			declarations: [AccessViewComponent, IdpFakeViewComponent],
			providers: [
				CustomerService,
				CryptoService,
				IdpService,
				AuthenticationService,
				{
					provide: ENV_CONFIG,
					useValue: environment
				}
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [IdpFakeViewComponent]
			}
		});

		injector = getTestBed();
		activeRoute = injector.get(ActivatedRoute);
		router = injector.get(Router);
	}));

	describe('Component should handle IDP code response', () => {
		let component: AccessViewComponent;
		let fixture: ComponentFixture<AccessViewComponent>;
		let injector: TestBed;
		let httpMock: HttpTestingController;

		const oauthToken = {
			access_token: 'MTQ0NjJkZmQ5OTM2NDE1ZTZjNGZmZjI3',
			token_type: 'Bearer',
			expires_in: 20000000,
			refresh_token: 'IwOGYzYTlmM2YxOTQ5MGE3YmNmMDFkNTVk',
			scope: 'summary_1.0.0 accounts_1.0.0'
		};
		const url = 'http://localhost:3000';
		const urlCustomer = 'http://localhost:3001/api/customers/me';

		beforeEach(() => {
			injector = getTestBed();
			httpMock = injector.get(HttpTestingController);

			const queryParams = {
				code: '123',
				state: 'abc'
			};
			activeRoute.queryParams = of(queryParams);
			sessionStorage.setItem('idp_state', 'abc');
			spyOn(router, 'navigate');

			fixture = TestBed.createComponent(AccessViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			const request = httpMock.expectOne(
				(req: HttpRequest<any>) =>
					req.urlWithParams === `${url}/oauth2/v1/token`
			);
			expect(request.request.method).toEqual('POST');
			expect(request.request.responseType).toEqual('json');
			request.flush(oauthToken);

			const requestCustomers = httpMock.expectOne(urlCustomer);
			expect(requestCustomers.request.method).toEqual('GET');
			expect(requestCustomers.request.responseType).toEqual('json');
			requestCustomers.flush(customersMe);
		});

		afterEach(() => {
			httpMock.verify();
		});

		it('should handle code response from IDP', async(() => {
			expect(component).toBeTruthy();
			expect(router.navigate).toHaveBeenCalled();

			const tokenLocal: any = JSON.parse(sessionStorage.getItem('oauthToken'));
			const customerLocal: any = JSON.parse(sessionStorage.getItem('customer'));

			expect(tokenLocal).toBeDefined();
			expect(tokenLocal.access_token).toBe(oauthToken.access_token);
			expect(customerLocal).toBeDefined();
			expect(customerLocal.buc).toBe(customersMe.data.buc);
		}));
	});

	describe('Component should redirect to IDP', () => {
		let component: AccessViewComponent;
		let fixture: ComponentFixture<AccessViewComponent>;
		let injector: TestBed;
		let environ: any;
		let idpService: IdpService;

		beforeEach(() => {
			injector = getTestBed();
			environ = injector.get(ENV_CONFIG);
			idpService = injector.get(IdpService);

			environ.production = true;
			spyOn(idpService, 'getBaseUrl').and.returnValue('#nop');

			fixture = TestBed.createComponent(AccessViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();
		});

		it('should handle redirect to IDP', () => {
			expect(component).toBeTruthy();
		});
	});

	describe('Component should fake IDP in develop', () => {
		let component: AccessViewComponent;
		let fixture: ComponentFixture<AccessViewComponent>;
		let injector: TestBed;
		let dialog: DialogWebService;

		beforeEach(() => {
			injector = getTestBed();
			dialog = injector.get(DialogWebService);

			fixture = TestBed.createComponent(AccessViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();
		});

		it('should fake idp flow', () => {
			expect(component).toBeTruthy();
			spyOn(dialog, 'open').and.callThrough();
			component.idpLoginIntent();
			expect(dialog.open).toHaveBeenCalled();
		});
	});
});
