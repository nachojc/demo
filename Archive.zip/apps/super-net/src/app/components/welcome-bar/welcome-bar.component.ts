import { Component, OnInit, Input } from '@angular/core';

/**
 * Componente para mostrar notificaciones, barra de busqueda y mensaje de bienvenida.
 *
 * @export
 * @class WelcomeBarComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'nsw-welcome-bar',
	templateUrl: 'welcome-bar.component.html',
	styleUrls: ['welcome-bar.component.scss']
})
export class WelcomeBarComponent {
	/**
	 * Información del cliente
	 *
	 * @type {*}
	 * @memberof WelcomeBarComponent
	 */
	@Input() customer: any = {};
}
