import { InjectionToken } from '@angular/core';

export const WELCOME_BAR = [
  '/summary',
]

export const RULES_WELCOME_BAR = new InjectionToken('RULES_WELCOME_BAR');
