import { OnInit, Inject, OnDestroy } from '@angular/core';
import { ThemeService } from '@santander/flame-component-library';
import { Component, AfterViewInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { RULES_WELCOME_BAR } from './common/rules-welcome-bar';
import { filter, takeUntil, pluck } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { CustomerService } from '@santander/flame-core-library';

@Component({
	selector: 'nsw-root',
	templateUrl: './app.component.html',
	styleUrls: ['./app.component.scss']
})
export class AppComponent implements AfterViewInit, OnInit, OnDestroy {
	/**
	 * Creates an instance of AppComponent.
	 * @param {ThemeService} _snTheme
	 * @memberof AppComponent
	 */
	constructor(
		@Inject(RULES_WELCOME_BAR) private rulesWelcomeBar: any,
		private _snTheme: ThemeService,
		private _router: Router,
		private _customerService: CustomerService
	) {}

	/**
	 * Datos del cliente
	 * @todo implementar correctamente la interrfaz de customers API
	 * @type {*}
	 * @memberof AppComponent
	 */
	public customer: any = {};

	/**
	 * Indica si la barra de bienvenida debe mostrarse o no
	 *
	 * @memberof AppComponent
	 */
	public showWelcome = false;

	/**
	 * Indica si el cliente ha iniciado sesión en IDP
	 * @todo Validar el inicio de sesión por IDP y OAuth
	 * @memberof AppComponent
	 */
	public sessionInit = true;

	/**
	 * Subject para finalizar subscripciones de observables.
	 *
	 * @memberof AppComponent
	 */
	public subject$ = new Subject<boolean>();

	/**
	 * Obtiene la info del cliente desde la api de customers
	 *
	 * @private
	 * @memberof AppComponent
	 */
	private getCustomerInfo() {
		this._customerService
			.getMe()
			.pipe(takeUntil(this.subject$))
			.subscribe((response: any) => {
				sessionStorage.setItem('customer', JSON.stringify(response.data));
				this.setCustomer(response.data);
			});
	}

	/**
	 * Establece los datos del customer
	 *
	 * @private
	 * @param {*} data
	 * @memberof AppComponent
	 */
	private setCustomer(data: any) {
		this.customer = data;
		this.customer.full_name = `${this.customer.name} ${
			this.customer.second_name
		} ${this.customer.last_name}`;
	}

	/**
	 * Verifica si existen datos del customer en local storage, de otra forma los obtiene.
	 *
	 * @private
	 * @memberof AppComponent
	 */
	private customerIsInStorage() {
		const localCustomer = sessionStorage.getItem('customer');
		if (!localCustomer) {
			this.getCustomerInfo();
		} else {
			const customerData = JSON.parse(localCustomer);
			if (customerData.bank_segment === null) {
				this.getCustomerInfo();
			} else {
				this.setCustomer(customerData);
			}
		}
	}

	/**
	 * Revisa si se encuetra un tema activo, en caso de que no tener ninguno
	 * se coloca el tema flame-foundation por default.
	 *
	 * @memberof AppComponent
	 */
	ngAfterViewInit(): void {
		const theme = sessionStorage.getItem('theme');
		if (theme) {
			this._snTheme.setTheme(theme);
		} else {
			sessionStorage.setItem('theme', 'flame-foundation');
		}
	}

	/**
	 * Suscribe al evento del router NavigationEnd
	 *
	 * @memberof AppComponent
	 */
	ngOnInit() {
		// TODO: Validar si el cliente ha iniciado sesión en IDP para ocultar el sidebar
		this._router.events
			.pipe(
				filter((routerEvent: any) => routerEvent instanceof NavigationEnd),
				pluck('urlAfterRedirects'),
				takeUntil(this.subject$)
			)
			.subscribe((url: string) => {
				const url_search = this.rulesWelcomeBar.find((rule: string) =>
					url.includes(rule)
				);
				this.showWelcome = url_search !== undefined;
				if (this.showWelcome) {
					this.customerIsInStorage();
				}
			});
	}

	/**
	 * Termina subscripción del router.
	 *
	 * @memberof AppComponent
	 */
	ngOnDestroy() {
		this.subject$.next(true);
		this.subject$.complete();
	}
}
