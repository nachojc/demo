import { TestBed, getTestBed } from '@angular/core/testing';
import { SuperTokenDialogService } from './super-token-dialog.service';
import {
	DialogWebModule,
	CustomWebDialog,
	TokenInputWebModule
} from '@santander/flame-component-library';
import { SuperTokenDialogComponent } from '../components/super-token-dialog/super-token-dialog.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('SuperTokenDialogService', () => {
	let injector: TestBed;
	let service: SuperTokenDialogService;

	beforeEach(() => {
		TestBed.configureTestingModule({
			imports: [BrowserAnimationsModule, DialogWebModule, TokenInputWebModule],
			declarations: [SuperTokenDialogComponent],
			providers: [SuperTokenDialogService]
		});

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [SuperTokenDialogComponent]
			}
		});

		injector = getTestBed();
		service = injector.get(SuperTokenDialogService);
	});

	it('should create', () => {
		expect(service).toBeTruthy();
	});

	it('should open dialog with entry component', () => {
		service.open({ tokenEmitter: null });
		expect(service.getDialogRef()).toBeDefined();
	});

	it('should close dialog when dialog ref defined', () => {
		service.open({ tokenEmitter: null });
		const reference = service.getDialogRef();
		expect(reference).toBeDefined();
		spyOn(reference, 'close');
		service.close();
		expect(reference.close).toHaveBeenCalled();
	});

	it('should close dialog when dialog ref defined', () => {
		service.open({ tokenEmitter: null });
		const reference = service.getDialogRef();
		expect(reference).toBeDefined();
		spyOn(reference, 'close');
		service.close();
		expect(reference.close).toHaveBeenCalled();
	});

	it('should set error when dialog ref defined', () => {
		service.open({ tokenEmitter: null });
		const reference = service.getDialogRef();
		expect(reference).toBeDefined();
		service.setError('ERROR');
		if (reference.componentInstance.bodyContent instanceof CustomWebDialog) {
			expect(reference.componentInstance.bodyContent.data.error).toBe('ERROR');
		}
	});
});
