import { Injectable } from '@angular/core';
import {
	DialogWebService,
	CustomWebDialog,
	DialogWebReference
} from '@santander/flame-component-library';
import { ForceLogoutConfirmComponent } from '../components/force-logout-confirm/force-logout-confirm.component';
import { ForceLogoutConfirm } from '../interfaces/force-logout-confirm.interface';

/**
 * Servicio que permite abrir un dialogo, para solicitar un OTP.
 *
 * @export
 * @class ForceLogoutService
 */
@Injectable()
export class ForceLogoutService {
	/**
	 * Crea una instancia de ForceLogoutService.
	 * @param {DialogWebService} _dialogWebService
	 * @memberof ForceLogoutService
	 */
	constructor(private _dialogWebService: DialogWebService) {}

	/**
	 * Referencia al dialogo abierto.
	 *
	 * @private
	 * @type {DialogWebReference}
	 * @memberof ForceLogoutService
	 */
	private dialogRef: DialogWebReference;

	/**
	 * Muestra un dialog con el componente de SuperToken.
	 *
	 * @param {*} data
	 * @memberof ForceLogoutService
	 */
	public open(data: ForceLogoutConfirm) {
		this.dialogRef = this._dialogWebService.open(
			new CustomWebDialog(ForceLogoutConfirmComponent, data)
		);
	}

	/**
	 * Cierra el dialogo si existe la referencia.
	 *
	 * @memberof ForceLogoutService
	 */
	public close() {
		if (this.dialogRef) {
			this.dialogRef.close();
		}
	}

	/**
	 * Establece un error que puede obtener del llamado al servicio.
	 *
	 * @param {string} error
	 * @memberof ForceLogoutService
	 */
	public setError(error: string) {
		if (
			this.dialogRef.componentInstance.bodyContent instanceof CustomWebDialog
		) {
			this.dialogRef.componentInstance.bodyContent.data.error = error;
		}
	}

	/**
	 * Obtiene la referencia al dialogo
	 *
	 * @returns
	 * @memberof ForceLogoutService
	 */
	public getDialogRef() {
		return this.dialogRef;
	}
}
