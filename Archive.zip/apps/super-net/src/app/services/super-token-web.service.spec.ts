import { TestBed, fakeAsync, async } from '@angular/core/testing';
import { SuperTokenWebService, ErrorToken, StepInfo } from './super-token-web.service';
import { DialogWebModule } from '@santander/flame-component-library';
import { TokenStep, TokenAttemp } from '../constants/super-token.constants';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('SuperTokenWebervice', () => {
  let service: SuperTokenWebService;
  const stepsUnlock: TokenStep[] = [
    {
      title: '¡Oh no!',
      label: 'Bloqueaste tu SuperToken. Desbloquéalo para hacer cualquier operación'
    },
    {
      title: '¡Desbloquea tu NIP Dinámico!',
      label: 'Ingresa un primer código de 8 dígitos con el SuperToken de tu móvil.'
    },
    {
      title: '¡Ya casi desbloqueas tu NIP!',
      label: 'Ahora ingresa un segundo código con el SuperToken de tu móvil.'
    }
  ];

  const stepsSync: TokenStep[] = [
    {
      title: 'Necesitas sincronizar tu NIP Dinámico',
      label: 'Da click en el botón para continuar ¡sólo son 2 pasos!'
    },
    {
      title: '¡Sincroniza tu NIP Dinámico! ',
      label: 'Ingresa un primer código de 8 dígitos con el SuperToken de tu móvil.'
    },
    {
      title: '¡Ya casi sincronizas tu NIP! ',
      label: 'Ahora ingresa un segundo código con el SuperToken de tu móvil.'
    }
  ];

  const tokenAttemps: TokenAttemp[] = [
    {
      attemp: 1,
      label: 'Parece que hay un error. Aún tienes 2 intentos más.'
    },
    {
      attemp: 2,
      label: 'Aún hay un error. ¡Te queda un intento más! '
    },
    {
      attemp: 4,
      label: 'Hay un error. Tienes un intento más antes de un bloqueo temporal'
    }
  ]

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [DialogWebModule,
        BrowserAnimationsModule]
    });
    service = TestBed.get(SuperTokenWebService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should reset attemps', () => {
    service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    expect(service.getAttemps()).toBe(1);
    service.resetAttemps();
    expect(service.getAttemps()).toBe(0);
  });

  it('should reset Unlock state', () => {
    const typeState = 'unlock';
    const actualState = service.stateUnlockToken;
    service.increaseState(typeState);
    expect(service.stateUnlockToken).toBe(actualState + 1);
    service.resetState(typeState);
    expect(service.stateUnlockToken).toBeFalsy();
  });

  it('should reset Sync state', () => {
    const typeState = 'sync';
    const actualState = service.stateSyncToken;
    service.increaseState(typeState);
    expect(service.stateSyncToken).toBe(actualState + 1);
    service.resetState('');
    expect(service.stateSyncToken).toBeFalsy();
  });

  it('sholud validate error attemps', () => {
    const expectError: ErrorToken = {
      errorToken : true,
      labelErrorToken: tokenAttemps[0].label
    };
    const firstAttemp = service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    expect(firstAttemp).toEqual(expectError);
    expectError.labelErrorToken = tokenAttemps[1].label;
    const secondAttemp = service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    expect(secondAttemp).toEqual(expectError);
  });

  it('should validate sync & unlock attemp', () => {
    const stepSync: StepInfo = {
      title: stepsSync[1].title,
      label: stepsSync[1].label,
      labelButton: 'Sincronizar'
    };
    const stepUnlock: StepInfo = {
      title: stepsUnlock[1].title,
      label: stepsUnlock[1].label,
      labelButton: 'Desbloquear'
    };
    service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    const thirdAttemp = service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    expect(thirdAttemp).toEqual(stepSync);
    service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    const fifthAttemp = service.validateAttemps(stepsUnlock, stepsSync, tokenAttemps);
    expect(fifthAttemp).toEqual(stepUnlock);
  });

  it('should get StepInfo', () => {
    const expectedInfo: StepInfo = {
      title: 'Ingresa tu NIP Dinámico desde tu móvil',
      label: '',
      labelButton: 'Continuar'
    };
    const stepInfo = service.getStepInfo(stepsUnlock);
    expect(stepInfo).toEqual(expectedInfo);
  });

  it('should sendOTP step one', async(() => {
    const subjectError = service.sendOTP('', stepsUnlock, 'unlock');
    const otp = '88888888';
    const initState = 1;
    service.stateSyncToken = initState;
    service.sendOTP(otp, stepsSync, 'sync').subscribe( () => {
      expect(service.stateSyncToken).toBe(initState + 1);
    });
    subjectError.subscribe( () => {}, (error) => {
      expect(error).toBeTruthy();
    });
  }));

  it('should sentOTP Sync step two', async(() => {
    const otp = '88888888';
    const initState = 2;
    service.stateSyncToken = initState;
    service.sendOTP(otp, stepsSync, 'sync').subscribe( () => {
      expect(service.stateSyncToken).toBeFalsy();
    });
  }));
});
