import { Injectable } from '@angular/core';
import {
	DialogWebService,
	CustomWebDialog,
	DialogWebReference
} from '@santander/flame-component-library';
import { SuperTokenDialogComponent } from '../components/super-token-dialog/super-token-dialog.component';

/**
 * Servicio que permite abrir un dialogo, para solicitar un OTP.
 *
 * @export
 * @class SuperTokenDialogService
 */
@Injectable()
export class SuperTokenDialogService {
	/**
	 * Crea una instancia de SuperTokenDialogService.
	 * @param {DialogWebService} _dialogWebService
	 * @memberof SuperTokenDialogService
	 */
	constructor(private _dialogWebService: DialogWebService) {}

	/**
	 * Referencia al dialogo abierto.
	 *
	 * @private
	 * @type {DialogWebReference}
	 * @memberof SuperTokenDialogService
	 */
	private dialogRef: DialogWebReference;

	/**
	 * Muestra un dialog con el componente de SuperToken.
	 *
	 * @param {*} data
	 * @memberof SuperTokenDialogService
	 */
	public open(data: any) {
		this.dialogRef = this._dialogWebService.open(
			new CustomWebDialog(SuperTokenDialogComponent, data)
		);
	}

	/**
	 * Cierra el dialogo si existe la referencia.
	 *
	 * @memberof SuperTokenDialogService
	 */
	public close() {
		if (this.dialogRef) {
			this.dialogRef.close();
		}
	}

	/**
	 * Establece un error que puede obtener del llamado al servicio.
	 *
	 * @param {string} error
	 * @memberof SuperTokenDialogService
	 */
	public setError(error: string) {
		if (
			this.dialogRef.componentInstance.bodyContent instanceof CustomWebDialog
		) {
			this.dialogRef.componentInstance.bodyContent.data.error = error;
		}
	}

	/**
	 * Obtiene la referencia al dialogo
	 *
	 * @returns
	 * @memberof SuperTokenDialogService
	 */
	public getDialogRef() {
		return this.dialogRef;
	}
}
