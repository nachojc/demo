import { Injectable } from '@angular/core';
import { Subject, timer, throwError } from 'rxjs';
import { TokenStep, TokenAttemp } from '../constants/super-token.constants';
import { SuperTokenVoucherComponent } from '../components/super-token-voucher/super-token-voucher.component';
import { DialogWebService, CustomWebDialog,  } from '@santander/flame-component-library';

export interface ErrorToken {
	/**
	 * Indica que existe un error en la petición.
	 *
	 * @type {boolean}
	 * @memberof errorToken
	 */
	errorToken: boolean,

	/**
	 * Indica la descripción del error.
	 *
	 * @type {string}
	 * @memberof errorToken
	 */
	labelErrorToken: string
}

export interface StepInfo {
	/**
	 * Indica el título del paso de desbloqueo/Sincronización.
	 *
	 * @type {string}
	 * @memberof stepInfo
	 */
	title: string;

	/**
	 * Indica la descripción del paso de desbloqueo/Sincronización.
	 *
	 * @type {string}
	 * @memberof stepInfo
	 */
	label: string;

	/**
	 * Indica el texto auxiliar del botón continuar.
	 *
	 * @type {string}
	 * @memberof stepInfo
	 */
	labelButton: string;
}


@Injectable({
	providedIn: 'root'
})
export class SuperTokenWebService {

	constructor( private _dialogWebService: DialogWebService ) {}

	private subjectRef = new Subject();

	/**
	 * Indica el número de intentos acumulados.
	 *
	 * @private
	 * @memberof SuperTokenWebService
	 */
	private attemps = 0;

	/**
	 * Indica el estado actual del proceso de sincronización de superToken.
	 *
	 * @type {string}
	 * @memberof BeneficiaryViewComponent
	 */
	public stateSyncToken: number;


	/**
	 * Indica el estado actual del proceso de desbloqueo de SuperToken.
	 *
	 * @type {number}
	 * @memberof BeneficiaryViewComponent
	 */
	public stateUnlockToken: number;

	/**
	 * Llamada a API desbloqueo de super token.
	 *
	 * @param {string} otp
	 * @param {number} [step]
	 * @returns
	 * @memberof SuperTokenWebService
	 */
	unlocking(otp: string, step?: number) {
		//todo: call API
		return this.fakeAPI(otp);
	}

	/**
	 * Llamada a API de sincronización de super token.
	 *
	 * @param {string} otp
	 * @param {number} [step]
	 * @returns
	 * @memberof SuperTokenWebService
	 */
	synchronize(otp: string, step?: number) {
		//todo: call API
		return this.fakeAPI(otp);
	}

	fakeAPI(otp: string) {
		let response = {};
		timer().subscribe(() => {
			this.subjectRef.next(response);
		});
		switch (otp) {
			case '88888888':
				response = {
					data: {
						status: 'ok',
						date: '2019-12-15T18:02:33.438Z'
					}
				};
				return this.subjectRef;
			default:
				return throwError('ERROR');
		}
	}

	/**
	 * Inicializa el número de intentos a 0.
	 *
	 * @memberof SuperTokenWebService
	 */
	resetAttemps() {
		this.attemps = 0;
	}

	/**
	 * Devuelve el número de intentos acumulados.
	 *
	 * @memberof SuperTokenWebService
	 */
	getAttemps() {
		return this.attemps;
	}

	/**
	 * Inicializa el estado del proceso.
	 *
	 * @param {string} type
	 * @memberof SuperTokenWebService
	 */
	resetState(type: string) {
		if (type === 'unlock') this.stateUnlockToken = null;
		else this.stateSyncToken = null;
	}

	/**
	 * Incrementa la posición(Paso) del estado.
	 *
	 * @param {*} type
	 * @memberof SuperTokenWebService
	 */
	increaseState(type: string) {
		if (type === 'unlock') this.stateUnlockToken++;
		else this.stateSyncToken++;
	}

	/**
	 * Validar los intentos de ingresar superToken.
	 *
	 * @memberof BeneficiaryViewComponent
	 */
	validateAttemps(stepsUnlock: TokenStep[], stepsSync: TokenStep[], attempsList: TokenAttemp[]): StepInfo | ErrorToken {
		//@TODO: Validar con APIS reglas de negocio para número de intentos.
		this.attemps++;
		switch (this.attemps) {
			case 3:
				this.stateSyncToken = 1;
				return this.getStepInfo(stepsSync);
			case 5:
				this.stateUnlockToken = 1;
				return this.getStepInfo(stepsUnlock, 'unlock');
			default:
				return {
					errorToken : true,
					labelErrorToken : attempsList.find( elem => elem.attemp === this.attemps).label
				}
		}
	}

	/**
	 * Obtiene la información (título, label) del paso correspondiente.
	 *
	 * @param {TokenStep[]} steps
	 * @param {string} [type]
	 * @returns {stepInfo}
	 * @memberof SuperTokenWebService
	 */
	getStepInfo(steps: TokenStep[], type?: string): StepInfo {
		const labelStateToken = ( type === 'unlock' ) ? 'Desbloquear' : 'Sincronizar';
		const stateToken = ( type === 'unlock' ) ? this.stateUnlockToken : this.stateSyncToken;
		return {
			title:  stateToken ? steps[stateToken].title :
					'Ingresa tu NIP Dinámico desde tu móvil',
			label: 	stateToken ? steps[stateToken].label : '',
			labelButton: stateToken ? labelStateToken : 'Continuar',
		}
	}

	/**
	 * Envía y recibe el OTP esperando respuesta de back.
	 *
	 * @param {string} otp
	 * @param {TokenStep[]} steps
	 * @param {string} [type]
	 * @returns
	 * @memberof SuperTokenWebService
	 */
	sendOTP(otp: string, steps: TokenStep[], type?: string): Subject<any | StepInfo> {
		const responseRef = new Subject<StepInfo | ErrorToken>();
		const transaction= this.getTypeTransaction(type, otp);
		const synchroRef = transaction.typeTransaction.subscribe( () => {
			if (transaction.stateToken === 1) {
				this.increaseState(type);
			} else if (transaction.stateToken === 2) {
				this.resetState(type);
				const customWebDialog = new CustomWebDialog(
					SuperTokenVoucherComponent, {
						title: `¡${transaction.titleTransaction} tu NIP Dinámico!`
					});
        		this._dialogWebService.open(customWebDialog);
			}
			responseRef.next(this.getStepInfo(steps, type));
			synchroRef.unsubscribe();
		}, (error) => {
			responseRef.error({
				errorToken: true,
				labelErrorToken: error
			});
		});
		return responseRef;
	}

	/**
	 * Obtiene que información corresponde al tipo de transacción
	 * (Sincronización o desbloqueo).
	 *
	 * @param {string} type
	 * @param {string} otp
	 * @returns
	 * @memberof SuperTokenWebService
	 */
	getTypeTransaction(type: string, otp: string) {
		return {
			titleTransaction: (type === 'unlock') ? 'Desbloqueaste' :  'Sincronizaste',
			stateToken:  (type === 'unlock') ? this.stateUnlockToken : this.stateSyncToken,
			typeTransaction: (type === 'unlock') ? this.unlocking(otp) :  this.synchronize(otp)
		}
	}
}
