export interface ForceLogoutConfirm {
  /**
   * Titulo de la confirmación del cierre de sesión
   */
  title: string;

  /**
   * Mensaje informativo del cierre de sesión
   */
  body: string;

  /**
   * Optional: Image url
   */
  imageUrl?: string;

  /**
   * Optional: Url a la que se redirige cuando termina la sesión
   */
  redirectUrl?: string;
}
