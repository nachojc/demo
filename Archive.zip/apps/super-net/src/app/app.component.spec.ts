import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import {
	TestBed,
	async,
	ComponentFixture,
	getTestBed
} from '@angular/core/testing';
import { AppComponent } from './app.component';
import { RouterTestingModule } from '@angular/router/testing';
import { WelcomeBarComponent } from './components/welcome-bar/welcome-bar.component';
import {
	IconModule,
	AvatarWelcomeWebModule,
	ThemeModule,
	FlameFoundationTheme,
	ButtonModule,
	DialogWebModule
} from '@santander/flame-component-library';
import { RULES_WELCOME_BAR, WELCOME_BAR } from './common/rules-welcome-bar';
import { Router, NavigationEnd, RouterEvent, Routes } from '@angular/router';
import { ReplaySubject } from 'rxjs';
import {
	CustomerService,
	ENV_CONFIG,
	CryptoService,
	IdpService,
	AuthenticationService
} from '@santander/flame-core-library';
import { environment } from '../environments/environment';
import { AccessViewComponent } from './components/access-view/access-view.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { IdpFakeViewComponent } from './components/idp-fake-view/idp-fake-view.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonModule, Location } from '@angular/common';

describe('AppComponent', () => {
	const routes: Routes = [
		{
			path: '',
			component: AccessViewComponent
		},
		{
			path: 'summary',
			component: AccessViewComponent
		}
	];
	let component: AppComponent;
	let fixture: ComponentFixture<AppComponent>;
	let router: Router;
	let location: Location;
	let httpMock: HttpTestingController;
	const customer = {
		data: {
			key: '4e20fbb243684d9eb19ff33a50ee422e',
			buc: '123456789',
			name: 'Ana Maria',
			second_name: 'Hernandez',
			last_name: 'Gutierrez',
			status: 'ACTIVE',
			personal_identifier: 'MARE921122HJKDLN01',
			bank_segment: null,
			contact_method: 'EMAIL',
			contact_info: [
				{
					type: 'BRANCH_USE',
					phone_number: '(55)-55-46-89-79',
					mobile_number: '(044)-55-46-89-79-12',
					email: 'mail@mail.com',
					status: 'REGISTERED'
				}
			]
		},
		notifications: [
			{
				code: 'SUCCESS',
				message: 'Success',
				timestamp: '2019-02-12T16:39:09.842Z'
			}
		]
	};
	const urlCustomer = 'http://localhost:3001/api/customers/me';


	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				CommonModule,
				BrowserAnimationsModule,
				ButtonModule,
				DialogWebModule,
				HttpClientTestingModule,
				RouterTestingModule.withRoutes(routes),
				IconModule,
				AvatarWelcomeWebModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				})
			],
			declarations: [
				AppComponent,
				WelcomeBarComponent,
				AccessViewComponent,
				IdpFakeViewComponent
			],
			providers: [
				{
					provide: RULES_WELCOME_BAR,
					useValue: WELCOME_BAR
				},
				CustomerService,
				CryptoService,
				IdpService,
				AuthenticationService,
				{
					provide: ENV_CONFIG,
					useValue: environment
				},
				Location
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [IdpFakeViewComponent]
			}
		});

		router = TestBed.get(Router);
		location = TestBed.get(Location);
		httpMock = TestBed.get(HttpTestingController);

	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AppComponent);
		router.initialNavigation();
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create ', () => {
		expect(component).toBeTruthy();
	});

	afterEach(() => {
		httpMock.verify();
	});

	it('should enabled welcome bar ', () => {
		router.navigate(['/summary']).then(() => {
			expect(location.path()).toBe('/summary');
			expect(component.showWelcome).toBeTruthy();
			const requestCustomers = httpMock.expectOne(urlCustomer);
			expect(requestCustomers.request.method).toEqual('GET');
			expect(requestCustomers.request.responseType).toEqual('json');
			requestCustomers.flush(customer);
		});
	});

	it('should retrieve customers data from sessionStorage ', () => {
		const customerName = {
			name: 'Ana Maria',
			second_name: 'Hernandez',
			last_name: 'Gutierrez',
		};
		sessionStorage.setItem('customer', JSON.stringify(customerName));
		router.navigate(['/summary']).then(() => {
			expect(location.path()).toBe('/summary');
			expect(component.showWelcome).toBeTruthy();
			expect(component.customer.full_name).toBe('Ana Maria Hernandez Gutierrez');
		});
	});
});
