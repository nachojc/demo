import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccessViewComponent } from './components/access-view/access-view.component';

const routes: Routes = [
	{
		path: '',
		component: AccessViewComponent
	},
	{
		path: 'summary',
		loadChildren:
			'../../../../libs/web/summary-operation-library/src/lib/summary-operation-library.module#SummaryOperationLibraryModule'
	},
	{
		path: 'transfers',
		loadChildren: '../../../../libs/web/transfers-operation-library/src/lib/transfers-operation-library.module#TransfersOperationLibraryModule'
    }
];

@NgModule({
	imports: [
		RouterModule.forRoot(routes, {
			scrollPositionRestoration: 'enabled'
		})
	],
	exports: [RouterModule]
})
export class AppRoutingModule {}
