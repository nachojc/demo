module.exports = {
	name: 'super-net',
	preset: '../../jest.config.js',
	coverageDirectory: '../../coverage/apps/super-net/'
};
