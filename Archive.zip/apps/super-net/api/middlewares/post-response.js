const data = require('./data-response');
module.exports = (req, res, next) => {
    if (req.originalUrl.match(/api\/accounts\/\w+\/associated-phone/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.accountsAssociatedPhone
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl === '/oauth2/v1/token' && req.method === 'POST') {
      req.method = 'GET'
      next();
    } else if (req.originalUrl.match(/api\/accounts\/\w+\/alias/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.accountsAlias
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/credits\/\w+\/alias/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.creditsAlias
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initpaymentsOwnCards
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.executepaymentsOwnCards
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/third-parties\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initpaymentsThirdCards
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/third-parties\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.executepaymentsThirdCards
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initializepaymentsBillers
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/\w+\/execute\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.executepaymentsBillers
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.changeBillStatus
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/billers\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.changeBillState
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/recurrent/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initBillCreation
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/recurrent\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.billProgrammedPayment
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/upgrade/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initBillUpdatePayment
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/upgrade\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.executeBillUpdatePayment
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/recurrent\/\w+\/execute\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.executeBillPayment
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/payments\/bill-payments\/\w+\/contracts\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.getContract
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initTransfers
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/\w+\/execute\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.executeTransfers
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/third-parties\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initTransfersThirdParties
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/third-parties\/\w+\/execute\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.executeTransfersThirdParties
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/payees\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.registerPayee
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/payees\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.updatePayee
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/payees\/\w+\/remove\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.removePayee
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/cash-advance\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.initCashAdvance
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/cash-advance\/\w+\/?$/gm)) {
      if (req.method === 'PUT') {
        res.jsonp({
          ...data.createCashAdvance
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/balances\/orders\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.createTranferBalance
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/balances\/orders\/\w+\/operations\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.createTranferBalanceOperation
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/balances\/orders\/\w+\/operations\/\w+\/?$/gm)) {
      if (req.method === 'DELETE') {
        res.jsonp({
          ...data.deleteTranferBalanceOperation
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/balances\/commercial-houses\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.retrieveCommercialHouses
        });
      } else {
        res.sendStatus(404);
      }
    } else if (req.originalUrl.match(/api\/transfers\/balances\/simulator\/?$/gm)) {
      if (req.method === 'POST') {
        res.jsonp({
          ...data.calculateBalance
        });
      } else {
        res.sendStatus(404);
      }
    } else {
      next();
    }
};
