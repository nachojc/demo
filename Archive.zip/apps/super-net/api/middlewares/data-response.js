module.exports = {
  accountsAssociatedPhone: {
    data: {
      account_key: "4e20fbb243684d9eb19ff33a50ee422e",
      phone_number: "5589765423",
      operation_date: "2017-07-21T17:32:28Z",
      company: "TELCEL",
      references: [{
        type: "CHANNEL",
        description: "Supermovil",
        reference: "123456789"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "SUCCESS",
      message: "Something happened.",
      timestamp: "2019-08-26T19:25:00.817Z"
    }]
  },
  accountsAlias: {
    data: {
      alias: "Nuevo alias cuenta de cheques"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-23T17:54:24.575Z"
    }]
  },
  creditsAlias: {
    data: {
      alias: "TARJETA CREDITO VISA"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-23T21:23:04.874Z"
    }]
  },
  initpaymentsOwnCards: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      available_credit_cards: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        alias: "My card fav",
        display_number: "**** **** **** *234",
        bank: "BANCO NACIONAL MEXICANO S.A. de C.V",
        balance: {
          currency_code: "MXN",
          amount: 50000
        },
        minimum_payment: {
          currency_code: "MXN",
          amount: 50000
        },
        statement_balance: {
          currency_code: "MXN",
          amount: 50000
        }
      }],
      available_accounts: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My checking account",
        display_number: "99***234",
        current_balance: {
          currency_code: "MXN",
          amount: 50000
        }
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  executepaymentsOwnCards: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      credit_card: {
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        alias: "My card fav",
        display_number: "**** **** **** *234",
        bank: "BANCO NACIONAL MEXICANO S.A. de C.V"
      },
      current_balance: {
        currency_code: "MXN",
        amount: 50000
      },
      account: {
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My checking account",
        display_number: "99***234",
        current_balance: {
          currency_code: "MXN",
          amount: 50000
        }
      },
      amount: {
        currency_code: "MXN",
        amount: 50000
      },
      payment_option: "Minimum payment",
      concept: "Pago de Tarjeta de Crédito",
      creation_date: "2019-02-16T23:38:45.408Z"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  initpaymentsThirdCards: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      available_payees: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        name: "Jose Ma. Camacho Hernandez",
        display_number: "**** **** **** 1234",
        bank: "BANCO NACIONAL MEXICANO S.A. de C.V",
        alias: "Tarjeta Primo Juan"
      }],
      available_accounts: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My checking account",
        display_number: "99***234",
        current_balance: {
          currency_code: "MXN",
          amount: 50000
        }
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  executepaymentsThirdCards: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      payee: {
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        name: "Jose Ma. Camacho Hernandez",
        display_number: "**** **** **** 1234",
        bank: "BANCO NACIONAL MEXICANO S.A. de C.V",
        alias: "Tarjeta Primo Juan"
      },
      account: {
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My checking account",
        display_number: "99***234",
        current_balance: {
          currency_code: "MXN",
          amount: 50000
        }
      },
      amount: {
        currency_code: "MXN",
        amount: 50000
      },
      concept: "Pago de Tarjeta de Crédito",
      creation_date: "2019-02-16T23:38:45.408Z"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]

  },
  initializepaymentsBillers: {
    data: {
      biller_key: "4e20fbb243684d9eb19ff33a50ee422e",
      name: "TELCEL",
      biller_type: "TELEFONIA MOVIL",
      biller_image_url: "/image.png",
      status: "ACTIVE",
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      accounts: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My checking account",
        display_number: "99***234",
        current_balance: {
          currency_code: "MXN",
          amount: 50000
        }
      }],
      credits: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        alias: "My card fav",
        display_number: "**** **** **** *234",
        bank: "BANCO NACIONAL MEXICANO S.A. de C.V"
      }],
      bill_amount: {
        currency_code: "MXN",
        amount: 50000
      },
      biller_agreement: "0245"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  executepaymentsBillers: {
    data: {
      biller_key: "4e20fbb243684d9eb19ff33a50ee422e",
      name: "TELCEL",
      biller_type: "TELEFONIA MOVIL",
      biller_image_url: "/image.png",
      status: "ACTIVE",
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      biller_agreement: "0245",
      amount: {
        currency_code: "MXN",
        amount: 50000
      },
      reference: "12345",
      display_account_number: "99***234",
      creation_date: "2019-02-16T23:38:45.408Z"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  changeBillStatus: {
    data: {
      folio: "BPR0000000000001"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  changeBillState: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      agreement: "0245",
      name: "TELCEL",
      description: "Servicios de Telecomunicaciones",
      type: "TELEFONIA MOVIL",
      status: "ACTIVE",
      last_operation_date: "14/11/19 15:33:11:01",
      url_logo: "http://host/cfe.jpg",
      url: "http://host/biller/{biller-key}",
      support_payments: [
        "UNIQUE"
      ],
      frequency: "MENSUAL",
      references_type: [{
        type: "REFERENCE",
        pattern: "\\d{10,12}",
        support_scan: false
      }],
      url_receipt_debit: "http://host/cfe_receiptt.jpg"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]

  },
  initBillCreation: {
    data: {
      key: "2ee16498-24d0-4bb9-89f6-1f0589f801ac",
      bill_balance: {
        due_date: "2019-03-02T11:14:54Z",
        balance: {
          currency_code: "MXN",
          amount: 50000
        },
        status: "PENDING"
      },
      required_properties: {
        maximum_amount: true,
        alias: true,
        due_date: true,
        amount_payable: true,
        email: false
      },
      available_cards: [{
        key: "xxx123",
        display_number: "00***384",
        display_account: "00***356",
        alias: "MY CARD",
        url_img_card: "http://{host}/12345.jpg",
        balance: {
          currency_code: "MXN",
          amount: 50000
        }
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  billProgrammedPayment: {
    data: {
      folio: "BPR0000000000001"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  initBillUpdatePayment: {
    data: {
      key: "2ee16498-24d0-4bb9-89f6-1f0589f801ac",
      entitlements: [
        "LOCK",
        "DISABLE"
      ],
      editable_properties: {
        maximum_amount: true,
        alias: true,
        due_date: true,
        amount_payable: true,
        bill_payments_notifications: false
      },
      associated_card: {
        display_number: "00***384",
        display_account: "00***356",
        alias: "MY CARD",
        url_img_card: "http://{host}/12345.jpg",
        balance: {
          currency_code: "MXN",
          amount: 50000
        }
      },
      avaliable_cards: [{
        key: "xxx123",
        display_number: "00***384",
        display_account: "00***356",
        alias: "MY CARD",
        url_img_card: "http://{host}/12345.jpg",
        balance: {
          currency_code: "MXN",
          amount: 50000
        }
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  executeBillUpdatePayment: {
    data: {
      folio: "BPR0000000000001"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  executeBillPayment: {
    data: {
      folio: "BPR0000000000001"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  getContract: {
    data: {
      doc: {
        doc_base64: "",
        doc_type: "image/jpg"
      },
      url: "http://host/docPreview113232.pdf"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-02-16T23:38:45.408Z"
    }]
  },
  initTransfers: {
    data: {
      key: "initTransfers",
      accounts: [{
          key: "4e20fbb243684d9eb19ff33a50ee422e",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT",
          image_url: "2517",
          display_number: "*2384",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 50000.5
          },
          category_name: "DEBIT_ACCOUNTS"
        },
        {
          key: "1234abc",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT 2",
          image_url: "2523",
          display_number: "*8901",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 100.5
          },
          category_name: "DEBIT_ACCOUNTS"
        },
        {
          key: "456abc",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT 3",
          image_url: "74110101010",
          display_number: "*4567",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 1000.5
          },
          category_name: "DEBIT_ACCOUNTS"
        },
        {
          key: "789abc",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT 4",
          image_url: "74110101010",
          display_number: "*1234",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 999999999999.5
          },
          category_name: "DEBIT_ACCOUNTS"
        }
      ],
      transfer_matrix: [{
        from_account_key: "4e20fbb243684d9eb19ff33a50ee422e",
        to_accounts: [{
            account_key: "1234abc",
            max_limit: 1000,
            min_limit: 0
          },
          {
            account_key: "456abc",
            max_limit: 2000,
            min_limit: 0
          },
          {
            account_key: "789abc",
            max_limit: 3000,
            min_limit: 10
          }
        ]
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T18:11:15.786Z"
    }]
  },
  executeTransfers: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      effective_date: "2019-02-16T23:38:45.408Z",
      status: "ACCEPTED",
      from_account: {
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My account fav",
        display_number: "*1234",
        bank: "Banamex",
        name: "Ahorro",
        balance: {
          currency_code: "MXN",
          amount: 123456
        },
        category_name: "DEBIT_ACCOUNTS"
      },
      to_account: {
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My account fav",
        display_number: "*1234",
        bank: "Santander",
        name: "Ahorro",
        balance: {
          currency_code: "MXN",
          amount: 123456
        },
        category_name: "DEBIT_ACCOUNTS"
      },
      amount: {
        currency_code: "MXN",
        amount: 123456
      },
      concept: "Food payment",
      references: [{
        type: "CHANNEL",
        description: "Supermovil",
        reference: "123456789"
      }],
      operation_type: "TRANSFER"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T18:25:00.708Z"
    }]
  },
  initTransfersThirdParties: {
    data: {
      key: "initTransfersThirdParties",
      accounts: [{
          key: "4e20fbb243684d9eb19ff33a50ee422e",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT",
          image_url: "2517",
          display_number: "*2384",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 50000.5
          },
          category_name: "DEBIT_ACCOUNTS"
        },
        {
          key: "1234abc",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT 2",
          image_url: "2523",
          display_number: "*8901",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 100.5
          },
          category_name: "DEBIT_ACCOUNTS"
        },
        {
          key: "456abc",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT 3",
          image_url: "74110101010",
          display_number: "*4567",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 1000.5
          },
          category_name: "DEBIT_ACCOUNTS"
        },
        {
          key: "789abc",
          url: "/accounts/{account-key}",
          type: "CHECKING",
          alias: "MY CHECKING ACCOUNT 4",
          image_url: "74110101010",
          display_number: "*1234",
          bank: "Santander",
          name: "Ahorro",
          balance: {
            currency_code: "MXN",
            amount: 999999999999.5
          },
          category_name: "DEBIT_ACCOUNTS"
        }
      ],
      payees: [{
          "key": "0m29qh0l7xy6oattzh65kq2jgn19fbx6",
          "account": {
            "number": "*8902",
            "account_type": "THIRDPARTY_SANTANDER_ACCOUNT",
            "bank": "Santander"
          },
          "name": "Jack Jacobs",
          "alias": "The Fourth",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        },
        {
          "key": "otmn77lqcc111oblddj1rekjfk52vqe3",
          "account": {
            "number": "*6369",
            "account_type": "CLABE",
            "bank": "SCOTIABANK"
          },
          "name": "Rosie Franklin",
          "alias": "Juris Doctor",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        },
        {
          "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq3",
          "account": {
            "number": "*7890",
            "account_type": "THIRDPARTY_SANTANDER_MOBILE_ACCOUNT",
            "bank": "Santander"
          },
          "name": "Owen Saunders",
          "alias": "The Third",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        },
        {
          "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq4",
          "account": {
            "number": "*8901",
            "account_type": "INTERBANK_MOBILE_ACCOUNT",
            "bank": "Santander"
          },
          "name": "Owen Saunders Maggy",
          "alias": "The Third Maggy",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        },
        {
          "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq5",
          "account": {
            "number": "*8765",
            "account_type": "THIRDPARTY_SANTANDER_DEBIT_CARD",
            "bank": "Santander"
          },
          "name": "Owen Saunders",
          "alias": "The Third Maggy",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        },
        {
          "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq6",
          "account": {
            "number": "*8765",
            "account_type": "INTERBANK_DEBIT_CARD",
            "bank": "HSBC"
          },
          "name": "Owen Saunders Bychy",
          "alias": "The Third Maggy",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        },
        {
          "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq7",
          "account": {
            "number": "*8765",
            "account_type": "THIRDPARTY_SANTANDER_CREDIT_CARD",
            "bank": "Santander"
          },
          "name": "Owen Saunders Master",
          "alias": "The Third March",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        },
        {
          "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq8",
          "account": {
            "number": "*8765",
            "account_type": "INTERBANK_CREDIT_CARD",
            "bank": "Bancomer"
          },
          "name": "Owen Master Maggy",
          "alias": "The March Sim",
          "url": "/beneficiaries/{beneficiary-key}",
          "personal_identifier": "MARE921122HJKDLN01"
        }
      ],
      transfer_matrix: [{
          from_account_key: "4e20fbb243684d9eb19ff33a50ee422e",
          to_payees: [{
            payee_key: "0m29qh0l7xy6oattzh65kq2jgn19fbx6"
          }, {
            payee_key: "otmn77lqcc111oblddj1rekjfk52vqe3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq4"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq5"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq6"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq7"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq8"
          }]
        },
        {
          from_account_key: "1234abc",
          to_payees: [{
            payee_key: "0m29qh0l7xy6oattzh65kq2jgn19fbx6"
          }, {
            payee_key: "otmn77lqcc111oblddj1rekjfk52vqe3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq4"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq5"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq6"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq7"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq38"
          }]
        }, {
          from_account_key: "456abc",
          to_payees: [{
            payee_key: "0m29qh0l7xy6oattzh65kq2jgn19fbx6"
          }, {
            payee_key: "otmn77lqcc111oblddj1rekjfk52vqe3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq4"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq5"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq6"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq7"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq38"
          }]
        }, {
          from_account_key: "789abc",
          to_payees: [{
            payee_key: "0m29qh0l7xy6oattzh65kq2jgn19fbx6"
          }, {
            payee_key: "otmn77lqcc111oblddj1rekjfk52vqe3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq3"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq4"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq5"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq6"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq7"
          }, {
            payee_key: "62k8i7sjq69rvxuueaduwagwnkvr3jjq38"
          }]
        }
      ],
      customer_personal_identifier: "RETM923201",
      operation_type: "SANTANDER_THIRD_PARTIES"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T18:34:54.905Z"
    }]
  },
  executeTransfersThirdParties: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      effective_date: "2019-02-16T23:38:45.408Z",
      status: "ACCEPTED",
      from_account: {
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My account fav",
        display_number: "*1234",
        bank: "Banamex",
        name: "Ahorro",
        balance: {
          currency_code: "MXN",
          amount: 123456
        },
        category_name: "DEBIT_ACCOUNTS"
      },
      to_payee: {
        name: "Jose Ma. Camacho Hernandez",
        alias: "Primo Juan",
        account: {
          number: "*0192",
          bank: "BANCO NACIONAL MEXICANO S.A. de C.V",
          account_type: "THIRDPARTY_SANTANDER_ACCOUNT"
        },
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        personal_identifier: "MARE921122HJKDLN01"
      },
      amount: {
        currency_code: "MXN",
        amount: 123456
      },
      concept: "Food payment",
      creation_date: "2019-02-16T23:38:45.408Z",
      url_receipt: "https://www.example.org.mx/cep/19845",
      customer_personal_identifier: "RETM923201",
      references: [{
        type: "CHANNEL",
        description: "Supermovil",
        reference: "123456789"
      }],
      operation_type: "SANTANDER_THIRD_PARTIES"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T18:37:03.312Z"
    }]
  },
  registerPayee: {
    data: {
      name: "Jose Ma. Camacho Hernandez",
      alias: "Primo Juan",
      account: {
        number: "9876541234569871",
        bank: "Santander",
        account_type: "INTERBANK_DEBIT_CARD"
      },
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      personal_identifier: "MARE921122HJKDLN01",
      creation_date: "2019-12-09T13:36:45.408Z",
      status: "CREATED",
      activation_time: "2019-12-09T14:00:00.408Z",
      references: [{
        type: "CHANNEL",
        description: "Supermovil",
        reference: "123456789"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T19:03:16.758Z"
    }]
  },
  updatePayee: {
    data: {
      name: "Jose Ma. Camacho Hernandez",
      alias: "Primo Juan",
      account: {
        number: "02283020192",
        bank: "BANCO NACIONAL MEXICANO S.A. de C.V",
        account_type: "THIRDPARTY_SANTANDER_ACCOUNT"
      },
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      personal_identifier: "MARE921122HJKDLN01",
      creation_date: "2019-02-16T23:38:45.408Z",
      status: "ACTIVE"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T20:15:35.890Z"
    }]
  },
  removePayee: {
    data: {
      name: "Jose Ma. Camacho Hernandez",
      alias: "Primo Juan",
      account: {
        number: "02283020192",
        bank: "BANCO NACIONAL MEXICANO S.A. de C.V",
        account_type: "THIRDPARTY_SANTANDER_ACCOUNT"
      },
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      personal_identifier: "MARE921122HJKDLN01",
      deleted_date: "2019-02-16T23:38:45.408Z",
      status: "DELETED",
      references: [{
        type: "CHANNEL",
        description: "Supermovil",
        reference: "123456789"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T20:17:58.285Z"
    }]
  },
  initCashAdvance: {
    data: {
      key: "4e20fbb243684d9eb19ff33a50ee422e",
      credits_cards: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        alias: "My card fav",
        display: "**** **** **** *234",
        bank: "Banamex",
        available_credit: {
          currency_code: "MXN",
          amount: 123456
        }
      }],
      accounts: [{
        key: "4e20fbb243684d9eb19ff33a50ee422e",
        url: "/accounts/{account-key}",
        type: "CHECKING",
        alias: "My account fav",
        display_number: "9**1234",
        bank: "Banamex, Santander, Scotiabank, BBVA Bancomer",
        name: "Ahorro",
        balance: {
          currency_code: "MXN",
          amount: 123456
        },
        category_name: "DEBIT_ACCOUNTS"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T20:26:04.836Z"
    }]
  },
  createCashAdvance: {
    data: {
      from_credit_card_key: "4e20fbb243684d9eb19ff33a50ee422e",
      to_account_key: "4e20fbb243684d9eb19ff33a50ee422e",
      amount: {
        currency_code: "MXN",
        amount: 123456
      },
      fee: {
        currency_code: "MXN",
        amount: 123456
      },
      tax: {
        currency_code: "MXN",
        amount: 123456
      },
      status: "APPROVED",
      concept: "Food payment",
      references: [{
        type: "CHANNEL",
        description: "Supermovil",
        reference: "123456789"
      }],
      creation_date: "2019-02-16T23:38:45.408Z"
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T20:29:31.382Z"
    }]
  },
  createTransferBalance: {
    data: {
      key: "xxxxxxxxxx",
      order_number: 723838,
      operation_date: "28/02/2019 10:00:00",
      balance_transfers: [{
        from_card: {
          name: "Aeromexico",
          image: "https://c2simage/aeromexico.png",
          number: "xxxx xxxx xxxx 0000"
        },
        operations: [{
          key: "xxxxxxxxxx",
          to_external_card_number: "xxxx xxxx xxxx 0000",
          balance_amount: {
            currency_code: "MXN",
            amount: 123456
          },
          monthly_payment: {
            currency_code: "MXN",
            amount: 123456
          },
          instalments: 12,
          payment_rate: 20.02,
          cat_rate: 20
        }],
        balances_total_amount: {
          currency_code: "MXN",
          amount: 123456
        }
      }],
      tooltips: [{
        title: "Importe",
        message_toolTip: "El pago por cada 1000 pesos es de 20"
      }],
      agreement_url: "/products/offers/{key}/terms",
      email_origin: "MACROBASE",
      email: "correo@example.com.mx",
      email_info_message: "",
      entitlements: [{
        key: "BALANCE TRANSFER",
        value: "BALANCES"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T20:38:51.006Z"
    }]
  },
  createTransferBalanceOperation: {
    data: {
      key: "xxxxxxxxxx",
      order_number: 723838,
      operation_date: "28/02/2019 10:00:00",
      balance_transfers: [{
        from_card: {
          name: "Aeromexico",
          image: "https://c2simage/aeromexico.png",
          number: "xxxx xxxx xxxx 0000"
        },
        operations: [{
          key: "xxxxxxxxxx",
          to_external_card_number: "xxxx xxxx xxxx 0000",
          balance_amount: {
            currency_code: "MXN",
            amount: 123456
          },
          monthly_payment: {
            currency_code: "MXN",
            amount: 123456
          },
          instalments: 12,
          payment_rate: 20.02,
          cat_rate: 20
        }],
        balances_total_amount: {
          currency_code: "MXN",
          amount: 123456
        }
      }],
      tooltips: [{
        title: "Importe",
        message_toolTip: "El pago por cada 1000 pesos es de 20"
      }],
      agreement_url: "/products/offers/{key}/terms",
      email_origin: "MACROBASE",
      email: "correo@example.com.mx",
      email_info_message: "",
      entitlements: [{
        key: "BALANCE TRANSFER",
        value: "BALANCES"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T20:58:55.488Z"
    }]
  },
  deleteTransferBalanceOperation: {
    data: {
      key: "xxxxxxxxxx",
      order_number: 723838,
      operation_date: "28/02/2019 10:00:00",
      balance_transfers: [{
        from_card: {
          name: "Aeromexico",
          image: "https://c2simage/aeromexico.png",
          number: "xxxx xxxx xxxx 0000"
        },
        operations: [{
          key: "xxxxxxxxxx",
          to_external_card_number: "xxxx xxxx xxxx 0000",
          balance_amount: {
            currency_code: "MXN",
            amount: 123456
          },
          monthly_payment: {
            currency_code: "MXN",
            amount: 123456
          },
          instalments: 12,
          payment_rate: 20.02,
          cat_rate: 20
        }],
        balances_total_amount: {
          currency_code: "MXN",
          amount: 123456
        }
      }],
      tooltips: [{
        title: "Importe",
        message_toolTip: "El pago por cada 1000 pesos es de 20"
      }],
      agreement_url: "/products/offers/{key}/terms",
      email_origin: "MACROBASE",
      email: "correo@example.com.mx",
      email_info_message: "",
      entitlements: [{
        key: "BALANCE TRANSFER",
        value: "BALANCES"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T21:35:29.333Z"
    }]
  },
  retrieveCommercialHouses: {
    data: [{
      key: 1,
      name: "LIVERPOOL"
    }],
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T21:48:02.901Z"
    }]
  },
  calculateBalance: {
    data: {
      card_key: "xxxxxxxxxx",
      card_number: "0000 ** 0000",
      card_image: "https://c2simage/aeromexico.png",
      account_balance: {
        currency_code: "MXN",
        amount: 123456
      },
      account_balance_consulted_date: "04 de Junio",
      transfer_classification: "9 x cada mil",
      balance_transfer: {
        amount: {
          currency_code: "MXN",
          amount: 123456
        },
        monthly_instalment: {
          currency_code: "MXN",
          amount: 123456
        },
        instalment: 12,
        interest_rate: 0.1002,
        interest_rate_percentage: 10.02
      },
      simulator: {
        maximum_amount: {
          currency_code: "MXN",
          amount: 123456
        },
        minimum_amount: {
          currency_code: "MXN",
          amount: 123456
        },
        rate_terms: [{
          instalments: 12,
          saving_percentage: 20.02,
          interest_rate: 0.1002,
          interest_rate_percentage: 10.02
        }]
      },
      entitlements: [{
        key: "BALANCE TRANSFER",
        value: "BALANCES"
      }]
    },
    notifications: [{
      level: "WARNING",
      code: "E422CDNPAYRCPTG001",
      message: "Something happened.",
      timestamp: "2019-09-24T21:49:07.364Z"
    }]
  }
};
