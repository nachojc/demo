module.exports = {
	name: 'personal',
	preset: '../../jest.config.js',
	coverageDirectory: '../../coverage/apps/personal/',
	snapshotSerializers: [
		'jest-preset-angular/AngularSnapshotSerializer.js',
		'jest-preset-angular/HTMLCommentSerializer.js'
	]
};
