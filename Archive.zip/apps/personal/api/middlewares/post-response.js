const data = require('./data');
module.exports = (req, res, next) => {
  setTimeout(() => {}, 500);
};
