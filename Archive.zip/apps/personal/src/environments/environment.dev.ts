export const environment = {
	production: false,
	sm: {
		clientId: '0KxtKPNZzUIMueEfxeP6x_NKWPJLRREWHEHsyOw1a4w'
	},
	idp: {
		url: '',
		redirectUri: ''
	},
	oauth: {
		url: 'http://localhost:3002/oauth2/v1/token',
		scope: ''
	},
	api: {
		url: 'http://localhost:3002/api',
		version: {
			authentication: '',
		}
	}
};
