import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccessViewComponent } from './components/access-view/access-view.component';
import { SummaryComponent } from './components/summary/summary.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';


const routes: Routes = [{
	path: '',
	redirectTo: '/access',
	pathMatch: 'full'
},
{
	path: 'access',
	component: AccessViewComponent
},
{
	path: 'summary',
	component: SummaryComponent,
	children:[
		{
			outlet: 'menu',
			path: 'dashboard',
			component: DashboardComponent
		},
		{
			outlet: 'menu',
			path: 'chat',
			loadChildren: '../../../../libs/web/chat-operation-library/src/lib/chat-operation-library.module#ChatOperationLibraryModule'
		}
	]
},

];

@NgModule({
	imports: [
		RouterModule.forRoot(routes, {
			scrollPositionRestoration: 'enabled',
			useHash:true
		})
	],
	exports: [RouterModule]
})
export class AppRoutingModule {}
