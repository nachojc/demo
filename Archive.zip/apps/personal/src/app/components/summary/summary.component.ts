import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pw-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss']
})
export class SummaryComponent implements OnInit {

  public componentTitle = '';
  public index = 0;

  public date = new Date();

  constructor() { }

  onClickItemMenu(title: string, indexItem: number) {
    this.componentTitle = title;
    this.index = indexItem;
  }


  isSelected(indexItem: number){
    return this.index === indexItem;
  }

  ngOnInit() {
    if(this.componentTitle === ''){
      this.componentTitle = 'Dashboard';
    }
 
  }

}
