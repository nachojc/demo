import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

export class Credentials {
  username: string = null
  password: string = null
}

@Component({
  selector: 'pw-access-view',
  templateUrl: './access-view.component.html',
  styleUrls: ['./access-view.component.scss']
})
export class AccessViewComponent implements OnInit {

  public credentialsForm:FormGroup;

  constructor() {
    this.credentialsForm = this.createCredentialsForm()
  }

  ngOnInit() {
  }

  onSubmitCredentials() {
    const result:Credentials = Object.assign({}, this.credentialsForm.value);
    console.log(result);
  }

  createCredentialsForm() {
    return new FormGroup({
      username: new FormControl(null, [
        Validators.required
      ]),
      password: new FormControl(null, [
        Validators.required
      ])
    });
  }

}
