import { environment } from '../environments/environment';
import {
	ThemeModule,
	FlameFoundationTheme,
	IconModule,
	FormFieldModule,
	InputModule,
	ButtonModule,
	EmojiModule,
	IconBadgeModule,
	AvatarBadgeModule
} from '@santander/flame-component-library';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NxModule } from '@nrwl/nx';
import { AppComponent } from './app.component';
import { AppRoutingModule } from './app.routing.module';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AccessViewComponent } from './components/access-view/access-view.component';
import { ErrorDialogComponent } from './../../../super-mobile/src/app/components/error-dialog/error-dialog.component';
import { SummaryComponent } from './components/summary/summary.component';

const MODULES = [
	EmojiModule,
	FormFieldModule,
	InputModule,
	AvatarBadgeModule,
	ButtonModule,
	IconBadgeModule,
	IconModule
];
@NgModule({
	declarations: [AppComponent, AccessViewComponent,SummaryComponent, DashboardComponent,ErrorDialogComponent],
	imports: [
		AppRoutingModule,
		BrowserModule,
		NxModule.forRoot(),
		FormsModule,
		ReactiveFormsModule,
		ThemeModule.forRoot({
			themes: [FlameFoundationTheme],
			active: 'flame-foundation'
		}),
		...MODULES
	],
	providers: [	
		{
			provide: ENV_CONFIG,
			useValue: environment
		},
	],
	bootstrap: [AppComponent]
})
export class AppModule {}
