const data = require('./data');
module.exports = (req, res, next) => {
	if (req.method === 'POST' && req.originalUrl.search('/IDPWeb') > -1) {
		if (req.originalUrl === '/IDPWeb/idp/authenticationMethods') {
			next();
		}
		if (req.originalUrl === '/IDPWeb/idp/RegistroContrase%C3%B1a') {
			req.body = data.signPassword;
			next();
		}
		if (
			req.method === 'POST' &&
			req.originalUrl === '/IDPWeb/idp/MedioNotificacion'
		) {
			req.body = data.notificationChanel;
			next();
		}
		if (
			req.method === 'POST' &&
			req.originalUrl === '/IDPWeb/idp/EnrollmentRSA'
		) {
			req.body = data.enrollmentRSA;
			next();
		}
		if (
			req.method === 'POST' &&
			req.originalUrl === '/IDPWeb/idp/ConfirmacionDeAfiliacion'
		) {
			req.body = data.confirmAffiliation;
			next();
		}
		if (
			req.method === 'POST' &&
			req.originalUrl === '/IDPWeb/idp/IdentificacionUsuarioConRSA'
		) {
			req.body = data.identificacionUsuarioConRSA;
			next();
		}
		if (
			req.method === 'POST' &&
			req.originalUrl === '/IDPWeb/idp/ExitoAfiliacion'
		) {
			req.body = data.exitoAfiliacion;
			next();
		}
		if (
			req.method === 'POST' &&
			req.originalUrl === '/IDPWeb/idp/IdentificacionUsuarioSinRSA'
		) {
			req.body = data.identificacionUsuarioSinRSA;
			next();
		}
		if (
			req.method === 'POST' &&
			req.originalUrl === '/IDPWeb/idp/VerifiqueSusDatosSendPasswordSinRSA'
		) {
			req.body = data.verifiqueSusDatosSendPasswordSinRSA;
			next();
		}
	} else {
		next();
	}
};
