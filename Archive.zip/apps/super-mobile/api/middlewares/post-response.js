const data = require('./data');
module.exports = (req, res, next) => {
    setTimeout(() => {
        if (req.originalUrl.match(/api\/transfers\/?$/gm)) {
            if (req.method === 'POST') {
                if (req.body.operation_type !== 'TRANSFER') {
                    res.jsonp({
                        ...data.initializeTransfersGrowing
                    });
                } else {
                    res.jsonp({
                        ...data.transfers
                    });
                }
            } else if (req.method === 'GET') {
                res.jsonp({
                    ...data.transfersList
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/transfers\/third-parties/) && req.method === 'POST') {
            if (req.body.operation_type === 'TRANSFER_THIRD_PARTIES') {
                res.jsonp({
                    ...data.transfersThirdPartiesInitial,
                    ... { data: { key: "4e20fbb243684d9eb19ff33a50ee422h" } }
                });
            } else {
                res.jsonp({
                    ...data.transfersThirdPartiesInitial
                });
            }
        } else if (req.originalUrl.match(/api\/transfers\/third-parties\/4e20fbb243684d9eb19ff33a50ee422h\/execute\/?$/gm) && req.method === 'PUT') {
            res.jsonp({
                ...data.transfersThirdPartiesExecute
            });
        } else if (
            req.originalUrl.match(/api\/transfers\/4e20fbb243684d9eb19ff33a50ee422e\/execute\/?$/gm)
        ) {
            // Aqui entra en cuentas propias
            if (req.method === 'POST' || req.method === 'PUT') {
                res.jsonp({...data.transfersExecuteSameAccounts });
            } else {
                res.sendStatus(404);
            }
        } else if (
            req.originalUrl.match(/api\/transfers\/(4e20fbb243684d9eb19ff33a50ee4221|4e20fbb243684d9eb19ff33a50ee4222)\/execute\/?$/gm) || req.originalUrl.match(/api\/transfers\/(056515888546|056515888469)\/execute\/?$/gm)
        ) {
            // Aqui entra en dinero creciente Deposito / Retiro
            if (req.method === 'PUT') {
                res.jsonp({...data.transfersExecuteSameAccounts });
            } else {
                res.sendStatus(404);
            }
        } else if (
            req.originalUrl.match(/api\/transfers\/third-parties\/4e20fbb243684d9eb19ff33a50ee422f\/execute\/?$/gm) && req.method === 'PUT'
        ) {
            // Aqui entra en cuentas mismo banco
            res.jsonp({...data.transfersExecute });
        } else if (req.originalUrl.match(/api\/transfers\/payees\/?$/gm)) {
            if (req.method === 'POST') {
                res.jsonp({
                    ...data.beneficiaryPost
                });
            }
        } else if (req.originalUrl.match(/api\/transfers\/payees\/\w+$/gm)) {
            if (req.method === 'PUT') {
                res.jsonp({
                    ...data.beneficiaryUpdate
                });
            } else if (req.method === 'GET') {
                res.jsonp({
                    ...data.beneficiaryByKey
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/transfers\/payees\/\w+\/remove/gm)) {
            if (req.method === 'PUT') {
                res.jsonp({
                    ...data.beneficiaryDelete
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/transfers\/payees+\/lookup/gm)) {
            if (req.method === 'GET') {
                res.jsonp({
                    ...data.payeesLookup
                });
            } else if (req.method === 'GET') {
                res.jsonp({
                    body: data.getPayeeDetail
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/payments\/?$/gm)) {
            if (req.method === 'POST') {
                res.jsonp({
                    ...data.initpaymentsOwnCards
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/payments\/\w+\/?$/gm)) {
            if (req.method === 'PUT') {
                res.jsonp({
                    ...data.executepaymentsOwnCards
                });
            } else if (req.originalUrl.match(/api\/payments\/billers\/?$/gm) && req.method === 'GET') {
                res.jsonp({
                    ...data.billers
                });
            } else {
                res.sendStatus(404);
            }
        } else if ((req.originalUrl.match(/api\/payments\/billers\/\w+\/?$/gm) && req.method === 'PUT')) {
            res.jsonp({
                ...data.changeStateBiller
            });
        } else if (req.originalUrl.match(/api\/payments\/third-parties\/?$/gm)) {
            if (req.method === 'POST') {
                res.jsonp({
                    ...data.initpaymentsThirdCards
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/payments\/third-parties/gm)) {
            if (req.method === 'PUT') {
                res.jsonp({
                    ...data.executepaymentsThirdCards
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match('/services/clarifications')) {
            if (req.originalUrl.match('categorized-transactions')) {
                res.jsonp(data.clarificationsPut);
            } else if (
                req.originalUrl.match('reposition')
            ) {
                res.jsonp({
                    data: data.repositionPut
                });
            } else if (
                req.originalUrl.match('application')
            ) {
                res.jsonp(data.clarificationApplication);
            } else {
                if (req.method === 'POST') {
                    res.jsonp(data.clarificationsPost);
                } else {
                    res.jsonp(data.clarificationsGet);
                }
            }
        } else if (req.originalUrl.match(/\/services\/\w+\/\application/gm)) {
            if (req.method === 'PUT') {
                res.jsonp({
                    data: data.clarificationApplication
                });
            }
        } else if (req.originalUrl.match(/api\/payments\/bill-payments\/?$/gm)) {
            if (req.method === 'POST') {
                res.jsonp({
                    ...data.initializepaymentsBillers
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/payments\/bill-payments\/\w+\/execute\/?$/gm)) {
            if (req.method === 'PUT') {
                res.jsonp({
                    ...data.executepaymentsBillers
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/accounts\/\w+\/associated-phone/gm)) {
            if (req.method === 'PUT') {
                res.jsonp({
                    ...data.accountsAssociatedPhone
                });
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl === '/oauth2/v1/token' && req.method === 'POST') {
            req.method = 'GET'
            next();
        } else if (req.originalUrl.match(/api\/\w+\/\w+\/alias/gm)) {
            if (req.method === 'PUT') {
                res.jsonp(data.updatedAlias);
            } else {
                res.sendStatus(404);
            }
        } else if (req.originalUrl.match(/api\/transfers\/cash-advance/) && req.method === 'POST') {
            res.jsonp({
                ...data.initCashAdvance
            });
        } else if (req.originalUrl.match(/api\/transfers\/cash-advance\/\w+?$/gm) && req.method === 'PUT') {
            res.jsonp({
                ...data.cashAdvance
            });
        } else if (req.originalUrl.match(/api\/v1\/authentication\/signoff?$/gm) && req.method === 'POST') {
            res.jsonp({
                ...data.signoff
            });
        } else if (req.originalUrl.match(/api\/cards\/\w+\/activation\/?$/gm) && req.method === 'POST') {
            res.jsonp({
                ...data.cardActivation
            });
        } else if (req.originalUrl.match(/api\/cards\/\w+\/temporal-locks\/?$/gm) && req.method === 'PUT') {
            res.jsonp({
                ...data.cardTemporalLock
            });
        } else if (req.originalUrl.match(/api\/cards\/\w+\/selective-locks\/?$/gm) && req.method === 'PUT') {
            res.jsonp({
                ...data.cardSelectiveLock
            });
        } else if (req.originalUrl.match(/api\/cards\/total-locks\/?$/gm) && req.method === 'POST') {
            res.jsonp({
                ...data.getTotalLocks
            });
        } else if (req.originalUrl.match(/api\/cards\/total-locks\/\w+\/reposition\/?$/gm) && req.method === 'PUT') {
            res.jsonp({
                ...data.cardReposition
            });
        } else if(req.originalUrl.match(/api\/investments\/me\/\w+?$/gm)) {
          if(req.method === 'PUT') {
            res.jsonp({
              ...data.updateIntructionInvestment
          });
          } else {
            res.jsonp({
              ...data.getDetailTermInvestment
          });
          }
        } else {
            next();
        }
    }, 500);
};
