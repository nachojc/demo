const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router('./db.json');
const middlewares = jsonServer.defaults();
const port = 3000;

server.use(
	jsonServer.rewriter({
		'/user/1': '/user',
		'/accounts/056722734006/transactions': '/transactions1',
		'/accounts/056722733565/transactions': '/transactions2',
		'/accounts/056722734026/transactions': '/transactions3',
		'/accounts/056722733525/transactions': '/transactions4',
		'/IDPWeb/idp/?applicationId=smov': '/aplicationID',
		'/IDPWeb/idp/authenticationMethods': '/authenticationMethods',
		'/IDPWeb/idp/RegistroContrase%C3%B1a': '/signPassword'
	})
);
server.use(middlewares);
server.use(router);
server.listen(port);
