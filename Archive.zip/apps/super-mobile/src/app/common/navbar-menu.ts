// TODO: Modificar las rutas cuando esten listas
// Array de elementos estaticos o animados del Navbar
export const navbarElements = [
	{
		name: 'Mi vida',
    icon: 'sn-CHAN007',
    animatedIcon: {
      path: 'assets/animations/mi_vida.json',
      renderer: 'svg',
      autoplay: false,
      loop: false
    },
    route: '/my-life',
    animated: true
	},
	{
		name: 'Transferencias',
    icon: 'sn-BAN055',
    route: '/transfers/initial',
    animatedIcon: {
      path: 'assets/animations/transfer.json',
      renderer: 'svg',
      autoplay: false,
      loop: false
    },
    animated: true
	},
	{
    name: 'Productos',
    icon: 'sn-SMOV009',
		animatedIcon: {
      path: 'assets/animations/productos.json',
      renderer: 'svg',
      autoplay: false,
      loop: false
    },
    route: '/summary/global-position',
    animated: true
	},
	// {
	// 	name: 'Tienda',
	// 	icon: 'sn-SERV008',
  //   route: '/no_route',
  //   disabled: true
	// },
	{
    name: 'Más',
    icon: 'sn-FUNC056',
		animatedIcon: {
      path: 'assets/animations/mas.json',
      renderer: 'svg',
      autoplay: false,
      loop: false
    },
    route: '/more-menu',
    animated: true
	}
];
