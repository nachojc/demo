import {
	animate,
	query,
	style,
	transition,
	trigger,
	group,
	animation,
	keyframes
} from '@angular/animations';
import { RouterTransfersAnimations } from 'libs/mobile/transfers-operation-library/src/lib/animations/router.animations';
import { RouterSummaryAnimations } from 'libs/mobile/summary-operation-library/src/lib/animations/router.animations';
import { RouterGrowingAnimations } from 'libs/mobile/growing-operation-library/src/lib/animations/router.animations';
import { RouterPaymentsAnimations } from 'libs/mobile/payments-operation-library/src/lib/animations/router.animations';
import { RouterBeneficiaryAnimations } from 'libs/mobile/beneficiary-operation-library/src/lib/animations/router.animations';

export function routerAnimationGeneric() {
	return trigger('routerAnimation', [
		// Animaciones Beneficiarios
		...RouterBeneficiaryAnimations,

		// Animaciones Payments
		...RouterPaymentsAnimations,

		// Animaciones Growing
		...RouterGrowingAnimations,

		// Animaciones Summary
		...RouterSummaryAnimations,

		// Animaciones Transfers
		...RouterTransfersAnimations
	]);
}
