// Array con Urls que utilizan el navbar
export const RulesRouterNavbar = [
  '/summary/global-position',
  '/summary/products-summary',
  '/my-life',
  '/more-menu',
  '/summary/account-detail',
  '/summary/credit-card-detail'
]
