import { NgModule } from '@angular/core';
import { Routes, RouterModule, RouterLink } from '@angular/router';
import { AccesViewComponent } from './components/access-view/access-view.component';
import { MoreMainMenuViewComponent } from './components/more-main-menu-view/more-main-menu-view.component';
import { BeneficiariesServicesViewComponent } from './components/beneficiaries-services-view/beneficiaries-services-view.component';
import { MyLifeViewComponent } from './components/my-life/my-life-view/my-life-view.component';
import { NgxPermissionsGuard } from 'ngx-permissions';
import { NavigationBackHelperDirective, NavigationBackHelperService } from '@santander/flame-core-library';
// import { DeniedAccessGuardService as DeniedAccessGuard } from '@santander/flame-core-library';

const routes: Routes = [
	{
		path: '',
		redirectTo: '/access',
		pathMatch: 'full'
	},
	{
		path: 'access',
		component: AccesViewComponent
	},
	{
		path: 'beneficiaries-services',
		component: BeneficiariesServicesViewComponent
	},
	{
		path: 'more-menu',
		component: MoreMainMenuViewComponent,
		canActivate: [NgxPermissionsGuard],
		data: {
			permissions: {
				only: ['R1', 'R2', 'R3', 'R4', 'R5']
			}
		}
	},
	{
		path: 'my-life',
		component: MyLifeViewComponent,
		canActivate: [NgxPermissionsGuard],
		data: {
			permissions: {
				only: ['R3']
			}
		}
	},
	{
		path: 'token',
		loadChildren:
			'../../../../libs/mobile/token-operation-library/src/lib/token-operation-library.module#TokenOperationLibraryModule'
	},
	{
		path: 'beneficiary', // animation 40 - 49
		loadChildren:
			'../../../../libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module#BeneficiaryOperationLibraryModule'
	},
	{
		path: 'payments', // animation 50 - 59
		loadChildren:
			'../../../../libs/mobile/payments-operation-library/src/lib/payments-operation-library.module#PaymentsOperationLibraryModule'
	},
	{
		path: 'growing', // animation 60 - 69
		loadChildren:
			'../../../../libs/mobile/growing-operation-library/src/lib/growing-operation-library.module#GrowingOperationLibraryModule'
	},
	{
		path: 'clarifications',
		loadChildren:
			'../../../../libs/mobile/clarifications-operation-library/src/lib/clarifications-operation-library.module#ClarificationsOperationLibraryModule'
	},
	{
		path: 'summary', // animation 70 - 79
		loadChildren:
			'../../../../libs/mobile/summary-operation-library/src/lib/summary-operation-library.module#SummaryOperationLibraryModule'
	},
	{
		path: 'transfers', // animation 80 - 89
		loadChildren:
			'../../../../libs/mobile/transfers-operation-library/src/lib/transfers-operation-library.module#TransfersOperationLibraryModule'
	},
	{
		path: 'investment',
		loadChildren:
			'../../../../libs/mobile/investment-operation-library/src/lib/investment-operation-library.module#InvestmentOperationLibraryModule'
	},
	{
		path: 'my-finances',
		loadChildren:
			'../../../../libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module#MyFinancesOperationLibraryModule'
	},
	{
		path: 'insurance',
    	loadChildren: '../../../../libs/mobile/insurance-operation-library/src/lib/insurance-operation-library.module#InsuranceOperationLibraryModule'
	},
	{
      path: 'superwallet',
      loadChildren: '../../../../libs/mobile/superwallet-operation-library/src/lib/superwallet-operation-library.module#SuperwalletOperationLibraryModule'
    },
	{
		path: 'onepay',
		loadChildren: 
			'../../../../libs/mobile/onepay-operation-library/src/lib/onepay-operation-library.module#OnepayOperationLibraryModule'
    }
];

@NgModule({
	imports: [
		RouterModule.forRoot(routes, {
			scrollPositionRestoration: 'enabled'
		})
	],
	providers: [
		{
			provide: RouterLink,
			useClass: NavigationBackHelperDirective
		}
	],
	exports: [RouterModule]
})
export class AppRoutingModule {}
