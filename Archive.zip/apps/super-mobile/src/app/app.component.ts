import { Component, AfterViewInit, OnInit, Renderer2, TemplateRef, DoCheck, OnDestroy } from '@angular/core';
import { routerAnimationGeneric } from './common/animations-router';
import {
	RouterOutlet,
	Router,
	NavigationEnd
} from '@angular/router';
import { navbarElements } from './common/navbar-menu';
import { RulesRouterNavbar } from './common/rules-navbar';
import {
	LoaderDialogService,
	ThemeService
} from '@santander/flame-component-library';
import { delay, filter, takeUntil } from 'rxjs/operators';
import { AuthenticationService, FlagOperationService, NavigationBackHelperService } from '@santander/flame-core-library';
import { environment } from './../environments/environment';
import { NgxPermissionsService, NgxPermissionsConfigurationService } from 'ngx-permissions';
import { Subject } from 'rxjs';
@Component({
	selector: 'sm-root',
	templateUrl: './app.component.html',
	styleUrls: [`./app.component.scss`],
	animations: [routerAnimationGeneric()]
})
export class AppComponent implements OnInit, DoCheck, OnDestroy {

	/**
	 *Creates an instance of AppComponent.
	 * @param {Router} _router
	 * @param {NavigationBackHelperService} _navigationHelper
	 * @param {LoaderDialogService} _loaderDialogService
	 * @param {NgxPermissionsService} permissionsService
	 * @param {NgxPermissionsConfigurationService} permissionsConfigurationService
	 * @param {AuthenticationService} _authService
	 * @param {FlagOperationService} _flagOperationService
	 * @param {ThemeService} _themeService
	 * @param {Renderer2} renderer2
	 * @memberof AppComponent
	 */
	constructor(
		private _router: Router,
		private _navigationHelper: NavigationBackHelperService,
		private _loaderDialogService: LoaderDialogService,
		private permissionsService: NgxPermissionsService,
		private permissionsConfigurationService: NgxPermissionsConfigurationService,
		private _authService: AuthenticationService,
		private _flagOperationService: FlagOperationService,
		public _themeService: ThemeService,
		private renderer2: Renderer2
	) {
		// scrollTop for navigate routerChild
		this._router.events
			.pipe(filter((routerEvent: any) => routerEvent instanceof NavigationEnd))
			.pipe(takeUntil(this.destroyed$))
			.subscribe(() => {
				window.scrollTo(0, 0)
			});
		// Analizamos con el observable del router events si debemos mostrar o no el navbar
		this._router.events.pipe(takeUntil(this.destroyed$)).subscribe(event => {
			if (event instanceof NavigationEnd) {
				const url_search = this.rulesNavbar.find(urls => event.url.includes(urls));
				const index_url = this.navbarElements.findIndex(index =>
					event.url.includes(index.route)
				);
				if (url_search) {
					this.controlNavbar = true;
					this.active = index_url > -1 ? index_url : this.active;
				} else {
					this.controlNavbar = false;
				}
			}
		});
		// Controlamos cuando debe aparecer el loader
		this._loaderDialogService
			.getEvents()
			.pipe(delay(0))
			.pipe(takeUntil(this.destroyed$))
			.subscribe(res => {
				this.showLoadingOverlay = res;
			});
		//Settear tema por defecto - flame (Quitar esto si queremos preguntar)
		// if (!localStorage.getItem('theme')) localStorage.setItem('theme', 'flame-foundation');
	}
	/**
	 *
	 *
	 * @private
	 * @memberof AppComponent
	 */
	private destroyed$ = new Subject<boolean>()

	/**
	 *
	 *
	 * @private
	 * @memberof AppComponent
	 */
	private blockRefreshTokenRequest = false;

	/**
	 * Array con la configuracion de los iconos del navbar
	 */
	public navbarElements = navbarElements;

	/**
	 * Array con las rutas que deben llevar navbar
	 */
	public rulesNavbar = RulesRouterNavbar;

	/**
	 * Variable de control que permite mostrar u ocultar navbar segun la ruta
	 */
	public controlNavbar = false;

	/**
	 * Variable de control que permite mostrar u ocultar el overlay loader
	 */
	public showLoadingOverlay = false;

	/**
	 * Muestra la pestaña actual en rojo
	 */
	public active = 2;

	/**
	 * Variable de control sobre si se está o no en produccion
	 */
	public isProduction = environment.production;


	public activeTheme: string;

	/**
	 * Metodo que permite navegar entre urls al navbar
	 * @param route
	 */
	public navigateMenu(route: string): void {
		this._navigationHelper.navigate([route]);
	}

	/**
	 * Obtenemos el identificador de la ruta y discriminamos la animacion a mostrar
	 * @param outlet
	 */
	public getRouteAnimation(outlet: RouterOutlet) {
		const res =
			outlet.activatedRouteData.num === undefined
				? -1
				: outlet.activatedRouteData.num;
		return res;
	}

	/**
	 *
	 *
	 * @memberof AppComponent
	 */
	ngOnInit() {
		this.permissionsService.loadPermissions(environment.show);

		this.permissionsConfigurationService.addPermissionStrategy('disable', (templateRef: TemplateRef<any>) => {
			this.renderer2.setAttribute(templateRef.elementRef.nativeElement.nextSibling, 'disabled', 'disabled');
		});

		this.permissionsConfigurationService.addPermissionStrategy('enable', (templateRef: TemplateRef<any>) => {
			this.renderer2.removeAttribute(templateRef.elementRef.nativeElement.nextSibling, 'disabled');
		});



	}

	/**
	 * revisa el tiempo de expiracion del token y refresa el mismo
	 *
	 * @memberof AppComponent
	 */
	ngDoCheck(): void {
		const expire_time = localStorage.getItem('expires_in') ? new Date(localStorage.getItem('expires_in')) : null;
		const current_date = new Date();
		const time_difference = expire_time ? Math.trunc((expire_time.getTime() - current_date.getTime()) / 1000) : -1;
		if (expire_time !== null) {
			if (time_difference <= 60 && time_difference > 10 && !this.blockRefreshTokenRequest) {
				this.blockRefreshTokenRequest = true;
				this._authService.refreshToken()
					.pipe(takeUntil(this.destroyed$))
					.subscribe((response: any) => {
						if (response.status === 200) {
							const temporal_body = typeof response.body === 'string' ? response.body : JSON.stringify(response.body);
							localStorage.setItem('oauthToken', temporal_body);
							this._authService.processDate(temporal_body); // almacenar tiempo en que expirara el nuevo token
							this.blockRefreshTokenRequest = false;
						} else {
							this.blockRefreshTokenRequest = false;
							localStorage.removeItem('code_verifier');
							localStorage.removeItem('customer') // @Todo limpia el localStorage, solo customer
							this._flagOperationService.resetFlags();
							this._router.navigate(['/access'])
						}
					});
			} else if (time_difference <= 0) {
				this.blockRefreshTokenRequest = false;
				localStorage.removeItem('code_verifier');
				localStorage.removeItem('customer') // @Todo limpia el localStorage, solo customer
				this._flagOperationService.resetFlags();
				this._router.navigate(['/access'])
			}
		}

		const theme = localStorage.getItem('theme');
		if (theme) {
			this.activeTheme = theme;
			this._themeService.setTheme(theme);
		}
	}

	/**
	 *
	 *
	 * @memberof AppComponent
	 */
	ngOnDestroy() {
		this.destroyed$.next(true);
		this.destroyed$.complete();
	}

}
