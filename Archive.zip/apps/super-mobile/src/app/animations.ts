import {
	trigger,
	animate,
	transition,
  style,
  state,
	query
} from '@angular/animations';

export const fadeAnimation = trigger('fadeAnimation', [
	transition('* => *', [
		query(':enter', [style({ opacity: 0 })], { optional: true }),
		query(
			':leave',
			[style({ opacity: 1 }), animate('1s', style({ opacity: 0 }))],
			{ optional: true }
		),
		query(
			':enter',
			[style({ opacity: 0 }), animate('1s', style({ opacity: 1 }))],
			{ optional: true }
		)
	])
]);

export const fadeOutManual = trigger('fadeOutManual', [
	state(
		'normal',
		style({
			opacity: 1
		})
	),
	state(
		'fadeOut',
		style({
			opacity: 0
		})
	),
	transition('normal => fadeOut', [animate('200ms')])
]);

export const fadeInManual = trigger('fadeInManual', [
  state(
    'void',
    style({
      opacity: 0
    })
  ),
  state(
    'normal',
    style({
      opacity: 1
    })
  ),
  transition('void => normal', [animate('200ms')])
])

export const contactListIn = trigger('contactListIn', [
  state(
    'void',
    style({
      transform: 'translateY(110px)'
    })
  ),
  state(
    'normal',
    style({
      transform: 'translateY(0px)'
    })
  ),
  transition('void => normal', [animate('200ms')])
])
