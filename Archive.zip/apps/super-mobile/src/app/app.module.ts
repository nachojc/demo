import { NgModule, LOCALE_ID, Injectable } from '@angular/core';
import { CommonModule, CurrencyPipe, registerLocaleData, TitleCasePipe } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
	HttpClientModule,
	XhrFactory,
	HttpXhrBackend,
	HTTP_INTERCEPTORS
} from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	DarkTheme,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	LoaderDialogService,
	DialogContentService,
	TagModule,
	TokenInputModule,
	LoaderOverlayService,
	CheckboxModule,
	HeaderAnimationModule,
	DialogService,
	RadioButtonModule
} from '@santander/flame-component-library';
import { Platform } from '@angular/cdk/platform';
import {
	FlameCoreLibraryModule,
	DataTransferService,
	FlagOperationService,
	ENV_CONFIG,
	AuthenticationService,
	GlobileHttpClient,
	CryptoService,
	IdpService,
	SERVICE_LOADER,
	ApiInterceptor,
	SuperTokenService,
	BackButtonService,
	AUTH_SERVICE,
	CustomerService,
	CardReaderService,
	NavigationBackHelperService,
	NAVIGATION_HELPER,
	DIALOG_SERVICE
} from '@santander/flame-core-library';
import {
	HammerGestureConfig,
	HAMMER_GESTURE_CONFIG
} from '@angular/platform-browser';
import { GlobileHttpXhrBackend } from '@santander/globile-services-library';

import { NgxPermissionsModule } from 'ngx-permissions';

// Router
import { AppRoutingModule } from './app.routing.module';

// Constants
import { environment } from '../environments/environment';

// Components
import { AppComponent } from './app.component';
import { AccesViewComponent } from './components/access-view/access-view.component';
import { MoreMainMenuViewComponent } from './components/more-main-menu-view/more-main-menu-view.component';
import { BeneficiariesServicesViewComponent } from './components/beneficiaries-services-view/beneficiaries-services-view.component';
import { IdpFakeViewComponent } from './components/idp-fake-view/idp-fake-view.component';
import { ErrorDialogComponent } from './components/error-dialog/error-dialog.component';
import { DialogClarificationsComponent } from './components/more-main-menu-view/components/dialog-clarifications/dialog-clarifications.component';
import { DialogErrorMoreComponent } from './components/more-main-menu-view/components/dialog-error-more/dialog-error-more.component';
import { DialogCloseLoginComponent } from './components/more-main-menu-view/components/dialog-close-login/dialog-close-login.component';
import { DialogErrorLogoutComponent } from './components/more-main-menu-view/components/dialog-error-logout/dialog-error-logout.component';
import { ButtonListComponent } from './components/more-main-menu-view/components/button-list/button-list.component';

// Services
import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import { SummaryService } from 'libs/mobile/summary-operation-library/src/lib/services/summary.service';

// Locales
import localeEsMX from '@angular/common/locales/es-MX';
import { MyLifeViewComponent } from './components/my-life/my-life-view/my-life-view.component';
import {
	MyLifeDeclarationComponents,
	MyLifeEntryComponents
} from './components/my-life/components/my-life-components';
import { MyLifeServices } from './components/my-life/services/my-life-services';
import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
import { DatePipe } from '@angular/common';
import { TransactionDateFilterPipe } from './components/my-life/pipes/transactions-date-filter.pipe';
import { LatinEncodePipe } from './components/my-life/pipes/latin1-encode.pipe';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { SuperTokenDialogService } from './components/supertoken-dialog/supertoken-dialog.service';
import { SuperTokenDialogAbstractionComponent } from './components/supertoken-dialog/dialog-abstraction/dialog-abstraction.component';
import { ConfirmSuperTokenService } from './components/supertoken-dialog/dialog-abstraction/confirm-supertoken.service';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { SkeletonViewMoreComponent } from './components/more-main-menu-view/components/skeleton-more-view/skeleton-view-more.component';
import { SuperTokenServiceErrorComponent } from './components/supertoken-dialog/service-error/service-error.component';
import { HeaderAvatarModule } from './components/header-avatar/header-avatar.module';
import { DialogThemeViewModule } from './components/dialog-theme-view/dialog-theme-view.module';
import { SelectThemeComponent } from './components/select-theme/select-theme.component';


registerLocaleData(localeEsMX, 'es-MX');

@Injectable()
export class CustomHammerConfig extends HammerGestureConfig {
	overrides = {
		pinch: { enable: false },
		rotate: { enable: false }
	};
}

// Routing animations
export function globileHttpXhrBackendFactory(factory: XhrFactory, dialog: any, router: Router) {
	console.log(router, dialog, factory);
	const platform = new Platform();
	if (platform.IOS || platform.ANDROID) {
		return new GlobileHttpXhrBackend(router, dialog);
	} else {
		return new HttpXhrBackend(factory);
	}
}
@NgModule({
	declarations: [
		AccesViewComponent,
		AppComponent,
		MoreMainMenuViewComponent,
		BeneficiariesServicesViewComponent,
		IdpFakeViewComponent,
		ErrorDialogComponent,
		DialogClarificationsComponent,
		DialogErrorMoreComponent,
		DialogCloseLoginComponent,
		DialogErrorLogoutComponent,
		SkeletonViewMoreComponent,
		MyLifeViewComponent,
		MyLifeDeclarationComponents,
		SuperTokenDialogAbstractionComponent,
		TransactionDateFilterPipe,
		LatinEncodePipe,
		SuperTokenServiceErrorComponent,
		ButtonListComponent,
		SelectThemeComponent
	],
	imports: [
		HeaderAnimationModule,
		AppRoutingModule,
		AvatarModule,
		BrowserAnimationsModule,
		BrowserModule,
		ButtonModule,
		CardModule,
		CarouselModule,
		ChipModule,
		CommonModule,
		ContactDialogModule,
		FormFieldModule,
		HttpClientModule,
		IconModule,
		InputModule,
		NavbarModule,
		ProductModule,
		RouterModule,
		SearchBarModule,
		SlideToggleModule,
		IconButtonModule,
		RadioButtonModule,
		ReactiveFormsModule,
		SpinnerModule,
		TagModule,
		FlameCoreLibraryModule,
		DialogModule,
		DialogContentModule,
		DialogThemeViewModule,
		TabsModule,
		TabModule,
		HeaderAvatarModule,
		ThemeModule.forRoot({
			themes: [DarkTheme, FlameFoundationTheme],
			active: 'flame-foundation'
		}),
		TopBarModule,
		EmojiModule,
		TokenDialogModule,
		MyFinancesOperationLibraryModule,
		BeneficiaryOperationLibraryModule,
		PaymentsOperationLibraryModule,
		LoaderOverlayModule,
		TagModule,
		NgxSkeletonLoaderModule,
		TokenInputModule,
		CheckboxModule,
		NgxPermissionsModule.forRoot()
	],

	entryComponents: [
		IdpFakeViewComponent,
		ErrorDialogComponent,
		MyLifeEntryComponents,
		DialogClarificationsComponent,
		DialogCloseLoginComponent,
		DialogErrorLogoutComponent,
		SuperTokenDialogAbstractionComponent,
		SuperTokenServiceErrorComponent,
		SelectThemeComponent
	],
	providers: [
		AuthenticationService,
		BeneficiaryService,
		CryptoService,
		GlobileHttpClient,
		IdpService,
		DataTransferService,
		FlagOperationService,
		DatePipe,
		DialogContentService,
		ContactDialogService,
		LoaderDialogService,
		MyLifeServices,
		WINDOW_PROVIDERS,
		TransactionDateFilterPipe,
		LatinEncodePipe,
		SuperTokenDialogService,
		ConfirmSuperTokenService,
		SuperTokenService,
		BackButtonService,
		CustomerService,
		LoaderOverlayService,
		CardReaderService,
		CurrencyPipe,
		TitleCasePipe,
		SummaryService,
		NavigationBackHelperService,
		{
			provide: NAVIGATION_HELPER,
			useExisting: NavigationBackHelperService
		},
		{
			provide: ENV_CONFIG,
			useValue: environment
		},
		{
			provide: SERVICE_LOADER,
			useExisting: LoaderDialogService
		},
		{
			provide: AUTH_SERVICE,
			useExisting: AuthenticationService
		},
		{
			provide: HTTP_INTERCEPTORS,
			useClass: ApiInterceptor,
			multi: true
		},
		{
			provide: DIALOG_SERVICE,
			useExisting: DialogService
		},
		// {
		// 	provide: HTTP_INTERCEPTORS,
		// 	useClass: OauthInterceptor,
		// 	multi: true
		// },
		{
			provide: HttpXhrBackend,
			useFactory: globileHttpXhrBackendFactory,
			deps: [XhrFactory, DIALOG_SERVICE, Router]
		},
		{ provide: LOCALE_ID, useValue: 'es-MX' },
		{
			provide: HAMMER_GESTURE_CONFIG,
			useClass: CustomHammerConfig
		}
	],
	bootstrap: [AppComponent]
})
export class AppModule {}
