import { ENV_CONFIG } from './../../../../../../libs/core/flame-core-library/src/lib/tokens/environment-config.token';
import { SuperTokenServiceErrorComponent } from './service-error/service-error.component';
import { Injectable, Inject } from '@angular/core';
import {
	DialogReference,
	DialogService,
	CustomDialog,
	LoaderOverlayService
} from '@santander/flame-component-library';
import { SuperTokenDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { Subject, Observable, of } from 'rxjs';
import {
	CustomSuperToken,
	SuperTokenErrorService
} from './supertoken-dialog.interface';
import {
	SuperTokenService,
	CustomerService,
	ERROR_CODES,
	ERROR_MESSAGES,
	ERROR_SERVICE,
	ErrorGeneralService
} from '@santander/flame-core-library';
import { Subscription } from 'rxjs';
import { concatMap } from 'rxjs/operators';

@Injectable({
	providedIn: 'root'
})
export class SuperTokenDialogService {
	/**
	 *Creates an instance of SuperTokenDialogService.
	 * @param {*} environment
	 * @param {DialogService} _dialog
	 * @param {SuperTokenService} _superToken
	 * @param {CustomerService} _customerService
	 * @param {LoaderOverlayService} _loaderOverlayService
	 * @param {ErrorGeneralService} _errorGeneralService
	 * @memberof SuperTokenDialogService
	 */
	constructor(
		@Inject(ENV_CONFIG) public environment: any,
		private _dialog: DialogService,
		private _superToken: SuperTokenService,
		private _customerService: CustomerService,
		private _loaderOverlayService: LoaderOverlayService,
		private _errorGeneralService: ErrorGeneralService
	) {}

	/**
	 * Error que se almacena al usar super token y el servicio que lo implementa responde con un error.
	 *
	 * @private
	 * @type {SuperTokenErrorService}
	 * @memberof SuperTokenDialogService
	 */
	private _error: SuperTokenErrorService = { type: 0, title: undefined };

	/**
	 *
	 *
	 * @private
	 * @type {number}
	 * @memberof SuperTokenDialogService
	 */
	private _errorType: number;

	/**
	 * @ignore
	 * Indica la referencia al dialogo.
	 *
	 * @private
	 * @type {DialogReference}
	 * @memberof TokenDialogDirective
	 */
	private _dialogRef: DialogReference;

	/**
	 * @ignore
	 * Indica la referencia al loader overlay.
	 *
	 * @private
	 * @type {*}
	 * @memberof TokenDialogDirective
	 */
	private _overlayRef: any;

	/**
	 * @ignore
	 * Indica la subscrpción al evento ejecutado cuando se desliza el botón.
	 *
	 * @type {Subject<any>}
	 * @memberof TokenDialogDirective
	 */
	private _confirm = new Subject<any>();

	/**
	 * @ignore
	 * Indica la subscripción a los cambios de estado del dialogo.
	 *
	 * @type {Subject<string>}
	 * @memberof TokenDialogDirective
	 */
	private _stateDialog = new Subject<string>();

	/**
	 * Subscripción para el servicio de super token nativo
	 *
	 * @private
	 * @type {Subscription}
	 * @memberof SuperTokenDialogService
	 */
	private _subscription: Subscription = new Subscription();

	/**
	 * variable que almancena el status del token
	 *
	 * @type {string}
	 * @memberof SuperTokenDialogService
	 */
	public checkingToken: any;

	/**
	 * Datos default para mostrar el super token dialog
	 *
	 * @private
	 * @type {CustomSuperToken}
	 * @memberof SuperTokenDialogService
	 */
	private _defaultCustom: CustomSuperToken = {
		subtitle:
			'¡Necesitas tu SuperToken! Utiliza tu dispositivo anterior para generarlo desde tu app. Escribe el código de 8 dígitos',
		title: 'Confirma tu NIP dinámico',
		closeLabel: 'Cancelar',
		tokenInputLength: 8
	};

	/**
	 * otp anterior
	 *
	 * @private
	 * @type {string}
	 * @memberof SuperTokenDialogService
	 */
	private _lastOtp: string

	/**
	 * metodo que muestra mensaje de error del otp duplicado
	 *
	 * @private
	 * @memberof SuperTokenDialogService
	 */
	private errorSimillarOtp() {
		if (this._errorType === 2) this.closeDialogToken();
		this.confirmEvent(400) // evaluar si se incluye para ver el efecto flip en detalle de tdc y tdd
		this.showTokenMessage(ERROR_SERVICE.SIMILAR_OTP)
	}


	/**
	 * Crea y abre un dialogo para introducir manualmente el nip dinámico.
	 *
	 * @memberof SuperTokenDialogService
	 */
	private openDialogToken(data?: CustomSuperToken) {
		const customDialog = new CustomDialog(
			SuperTokenDialogAbstractionComponent,
			{
				confirmEvent: (status: number, otp: string) =>
				this._lastOtp === otp ? this.errorSimillarOtp() : this.confirmEvent(status, otp),
				tokenInputLength:
					data && data.tokenInputLength !== undefined
						? data.tokenInputLength
						: false,
				customBody: data && data.customBody ? data.customBody : null,
				subtitle: data && data.subtitle ? data.subtitle : null,
				error: this.cleanErrorService()
			}
		);
		this._dialogRef = this._dialog.open(
			{
				closeLabel: data && data.closeLabel ? data.closeLabel : 'Cancelar',
				title: data && data.title ? data.title : 'Confirma tu NIP dinámico',
				enableHr: false,
				disabledButton: false,
				showButton: false,
				backdropClass: 'dark-backdrop',
				closeBackdropClick: false
			},
			customDialog
		);
		this._dialogRef.afterClosed().subscribe(() => {
			document.body.style.overflow="auto";
			this._stateDialog.next('closed');
		});
		this._dialogRef.beforeClose().subscribe((evt: any) => {
			if (evt) {
				this.confirmEvent(400);
			}
			this._stateDialog.next('startclose');
		});
	}

	/**
	 * Crea y abre un dialogo para mostrar un mensaje de error por parte del servicio
	 * donde se implementa el SuperToken
	 *
	 * @memberof SuperTokenDialogService
	 */
	openServiceError() {
		const error = this.cleanErrorService();
		const customDialog = new CustomDialog(SuperTokenServiceErrorComponent, {
			typeError: this._errorType,
			icon: './assets/empty_states/Empty_State_Color_015.svg',
			title: error.title,
			message: error.message,
			subtitle: error.subtitle
		});
		this._dialogRef = this._dialog.open(
			this._errorType === 1
				? {
						closeLabel: 'Cerrar',
						title: '',
						enableHr: false,
						disabledButton: false,
						showButton: true,
						buttons: [
							{
								label: 'Aceptar',
								class: 'strech',
								action: () => {
									this._dialogRef.close();
								}
							}
						],
						backdropClass: 'dark-backdrop',
						closeBackdropClick: true
				  }
				: {
						closeLabel: 'Cerrar',
						title: '',
						enableHr: false,
						disabledButton: false,
						showButton: false,
						backdropClass: 'dark-backdrop',
						closeBackdropClick: true
				  },
			customDialog
		);
		this.confirmEvent(500);
	}

	/**
	 * Muestra un mensaje de error al intentar abrir el superToken
	 * @TODO Validar con UX  el flujo que hace falta para mostrar bien el diseño
	 * @memberof SuperTokenDialogService
	 */
	private showTokenMessage(errorMessage: any) {
		const customDialog = new CustomDialog(SuperTokenServiceErrorComponent, {
			icon: './assets/icons/error-1.svg',
			title: errorMessage.subtitle,
			message: errorMessage.message
		});
		this._dialogRef = this._dialog.open(
			{
				closeLabel: 'Cerrar',
				title: errorMessage.title,
				enableHr: false,
				disabledButton: false,
				showButton: false,
				buttons: [
					{
						action: () => {
							this.closeDialogToken();
						},
						label: 'Entendido',
						class: 'strech'
					}
				],
				backdropClass: 'dark-backdrop',
				closeBackdropClick: true
			},
			customDialog
		);
		this.confirmEvent(500);
	}

	/**
	 * Emite la confirmación del dialogo.
	 *
	 * @memberof TokenDialogDirective
	 */
	private confirmEvent(status: number, otp?: string) {
		this._lastOtp = otp;
		this._confirm.next({ status: status, otp: otp });
		this._subscription.unsubscribe();
	}

	/**
	 * Cierra el overlay loader
	 *
	 * @private
	 * @memberof SuperTokenDialogService
	 */
	public closeLoader() {
		this._overlayRef.close();
	}

	/**
	 * Establece el tipo de error del SuperToken
	 * 1 - Error al ingresar clave dinámica
	 * 2 - La clave ya no es válida, intentar de nuevo
	 *
	 * @private
	 * @memberof SuperTokenDialogService
	 */
	public setErrorType(type: number) {
		this._errorType = type;
	}

	/**
	 * Abre el overlay loader
	 *
	 * @private
	 * @memberof SuperTokenDialogService
	 */
	public openLoader() {
		this._overlayRef = this._loaderOverlayService.open(
			'Espera, esta operación puede tardar unos minutos'
		);
	}

	/**
	 * Define la referencia del dialogo.
	 *
	 * @param {DialogReference} dialogRef
	 * @memberof SuperTokenDialogService
	 */
	public setDialogRef(dialogRef: DialogReference) {
		this._dialogRef = dialogRef;
	}

	/**
	 * Devuelve referencia del dialogo
	 *
	 * @param {DialogReference} dialogRef
	 * @memberof SuperTokenDialogService
	 */
	public getDialogRef(): DialogReference {
		return this._dialogRef;
	}

	/**
	 * Devuelve la confirmación del dialogo
	 *
	 * @returns {Subject<any>}
	 * @memberof SuperTokenDialogService
	 */
	public getConfirm(): Subject<any> {
		return this._confirm;
	}

	/**
	 * Devuelve estado del dialogo
	 *
	 * @returns {Subject<any>}
	 * @memberof SuperTokenDialogService
	 */
	public getSubjectStateDialog(): Subject<any> {
		return this._stateDialog;
	}

	/**
	 * Devuelve el dialogo como servicio.
	 *
	 * @returns {DialogService}
	 * @memberof SuperTokenDialogService
	 */
	public getDialog(): DialogService {
		return this._dialog;
	}

	/**
	 * Cierra el Token Dialog
	 *
	 * @memberof SuperTokenDialogService
	 */
	public closeDialogToken() {
		if (this._dialogRef) {
			this._dialogRef.close();
			this._dialogRef.afterClosed().subscribe(resp=>{document.body.style.overflow="auto";});
		}
	}

	/**
	 * Devuelve un observable del evento confirmar.
	 *
	 * @returns {Observable<any>}
	 * @memberof SuperTokenDialogService
	 */
	public getConfirmEvent(): Observable<any> {
		return this._confirm.asObservable();
	}

	/**
	 * Obtiene observable que devuelve un String con los distintos estados de animación del <strong>token-dialog</strong>.
	 *
	 * @returns {Observable<string>}
	 * @memberof SuperTokenDialogService
	 */
	public getStateDialog(): Observable<string> {
		return this._stateDialog.asObservable();
	}

	/**
	 * LLama al superToken nativo para obtener el NIP Dinámico
	 *
	 * @param {CustomSuperToken} [params]
	 * @memberof SuperTokenDialogService
	 */
	public getSuperToken(params?: CustomSuperToken) {
		if (
			(this._error.type === 1 || this._error.type === 2) &&
			this._error.title !== undefined
		) {
			this.openServiceError();
			return;
		}
		// evalua si el ambiente es desarrollo y levanta el nip dinamico
		if (this.environment.develop) {
			this._errorType = 2;
			this.openDialogToken(params ? params : this._defaultCustom);
		} else {
			// evalua la semilla del super token
			this.openLoader();
			this._subscription = this._customerService
				.getMeSettings()
				.pipe(
					concatMap((customerResponse: any) => {
						const tokenStatus = customerResponse.data.token.status;
						this.checkingToken = { checking_token_status: tokenStatus };
						if (
							tokenStatus === 'INACTIVE' ||
							tokenStatus === 'NOT_AVAILABLE' ||
							tokenStatus === 'BLOCKED' ||
							tokenStatus === 'WITHOUT_TOKEN' ||
							tokenStatus === 'TEMPORARY_LOCK'
						) {
							return of(this.checkingToken);
						} else {
							return this._superToken.invokeSuperToken();
						}
					})
				)
				.subscribe(
					(res: any) => {
						if (res.hasOwnProperty('checking_token_status')) {
							if (res.checking_token_status === 'WITHOUT_TOKEN') {
								this.closeLoader();
								this.showTokenMessage(ERROR_MESSAGES.NOT_SUPER_TOKEN);
							} else if (res.checking_token_status === 'INACTIVE') {
								this.closeLoader();
								this.showTokenMessage(ERROR_MESSAGES.NOT_ACTIVE);
							} else if (res.checking_token_status === 'BLOCKED') {
								this.closeLoader();
								this.showTokenMessage(ERROR_MESSAGES.SUPER_TOKEN_BLOCKED);
							} else if (res.checking_token_status === 'TEMPORARY_LOCK') {
								this.closeLoader();
								this.showTokenMessage(
									ERROR_MESSAGES.SUPER_TOKEN_TEMPORARY_LOCK
								);
							} else {
								this.closeLoader();
								this._errorGeneralService.showErrorDialog(
									'img',
									'¡Oh no!',
									'Este servicio no está disponible por ahora. Intenta mas tarde',
									'error-1'
								);
							}
						} else {
							this.closeLoader();
							this._errorType = 1;
							// Tiene la app, tiene supertoken activo, introduce bien su nip
							this._lastOtp === res
								? this.errorSimillarOtp()
								: this.confirmEvent(201, res);
						}
					},
					(error: any) => {
						if (
							error.id === ERROR_CODES.CANCELLED ||
							error.id === ERROR_CODES.CANCELLED_DIALOG ||
							error.id === ERROR_CODES.TEMPORARY_LOCKED ||
							error.id === ERROR_CODES.PERMANENT_LOCKED
						) {
							// Tiene la app, tiene el supertoken activo, pero canceló o se bloqueo su supertoken
							this.confirmEvent(400);
							this.closeLoader();
						} else if (error.id === ERROR_CODES.NOT_INSTALLED) {
							// No tiene la app, revisar en customers, lanzar flujo ingresar token o mensaje de error "Activa tu superToken"
							// @TODO: revisar flujo para validar que se muestre o no el dialog
							this._errorType = 2;
							this.closeLoader();
							if (this.checkingToken.hasOwnProperty('checking_token_status')) {
								if (this.checkingToken.checking_token_status === 'ACTIVE') {
									this.openDialogToken(params ? params : this._defaultCustom);
								} else if (
									this.checkingToken.checking_token_status === 'WITHOUT_TOKEN'
								) {
									this.closeLoader();
									this.showTokenMessage(ERROR_MESSAGES.NOT_SUPER_TOKEN);
								} else if (
									this.checkingToken.checking_token_status === 'INACTIVE'
								) {
									this.closeLoader();
									this.showTokenMessage(ERROR_MESSAGES.NOT_ACTIVE);
								} else if (
									this.checkingToken.checking_token_status === 'BLOCKED'
								) {
									this.closeLoader();
									this.showTokenMessage(ERROR_MESSAGES.SUPER_TOKEN_BLOCKED);
								} else if (
									this.checkingToken.checking_token_status === 'TEMPORARY_LOCK'
								) {
									this.closeLoader();
									this.showTokenMessage(
										ERROR_MESSAGES.SUPER_TOKEN_TEMPORARY_LOCK
									);
								} else {
									this.closeLoader();
									this._errorGeneralService.showErrorDialog(
										'img',
										'¡Oh no!',
										'Este servicio no está disponible por ahora. Intenta mas tarde',
										'error-1'
									);
								}
							}
						} else if (error.id === ERROR_CODES.NOT_ACTIVE) {
							// Tiene la app, paso algo ej. supertoken_not_active o set_up_not_well_configured
							this.showTokenMessage(ERROR_MESSAGES.NOT_ACTIVE);
							this.closeLoader();
						} else {
							this.closeLoader();
							this._errorGeneralService.showErrorDialog(
								'img',
								'¡Oh no!',
								'Este servicio no está disponible por ahora. Intenta mas tarde',
								'error-1'
							);
						}
					}
				);
		}
	}

	/**
	 * Obtiene un error de SuperToken del servicio que lo implemento
	 *
	 * @returns {Promise<any>}
	 * @memberof SuperTokenDialogService
	 */
	public getErrorService(): Promise<any> {
		return new Promise(resolve => {
			resolve(this._error);
		});
	}

	/**
	 * Permite almacenar un error de SuperToken del servicio que lo implemento
	 *
	 * @memberof SuperTokenDialogService
	 */
	public setErrorService() {
		if (this._errorType === 1) {
			// semilla instalada en el dispositivo
			this._error = {
				type: this._errorType,
				title: ERROR_SERVICE.INSTALLED.title,
				message: ERROR_SERVICE.INSTALLED.message,
				subtitle: ERROR_SERVICE.INSTALLED.subtitle
			};
		} else {
			// nip dinamico
			this._error = {
				type: this._errorType,
				title: ERROR_SERVICE.NOT_INSTALLED.title,
				message: ERROR_SERVICE.NOT_INSTALLED.message
			};
		}
	}

	/**
	 * Limpia el error de servicio para no mostrarlo en multiples ocasiones
	 *
	 * @memberof SuperTokenDialogService
	 */
	public cleanErrorService() {
		const lastError = this._error;
		this._error = { type: 0, title: undefined };
		return lastError;
	}

	/**
	 *
	 *
	 * @memberof SuperTokenDialogService
	 */
	public destroyLoader() {
		if (this._overlayRef) {
			this.closeLoader();
		}
	}
}
