
export interface ITokenDialogConfirm {
	token?: string;
	stateDialog: TokenDialogInterfaceParams.StateDialog;
}

export interface ITokenDialogState {
	stateDialog: TokenDialogInterfaceParams.StateDialog;
}

export interface CustomSuperToken {
	title?: string;
	subtitle?: string;
	closeLabel?: string;
	typeButton?: string;
	tokenInputLength?: number;
	customBody?: any;
}
export namespace TokenDialogInterfaceParams {
	export type StateDialog =
		| 'startclose'
		| 'closed'
		| 'awaiting'
		| 'loadingbutton'
		| 'error'
		| 'success';
	export const StateDialog = {
		STARTCLOSE: 'startclose' as StateDialog,
		CLOSED: 'closed' as StateDialog,
		AWAITING: 'awaiting' as StateDialog,
		LOADING: 'loadingbutton' as StateDialog,
		ERROR: 'error' as StateDialog,
		SUCCESS: 'success' as StateDialog,
		LOST: 'lost' as StateDialog
	};
}

export interface SuperTokenErrorService {
	type: number,
	title: string,
	message?: string,
	subtitle?: string
}
