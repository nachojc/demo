import {
	Component
} from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';

/**
 *
 *
 * @export
 * @class SuperTokenServiceErrorComponent
 * @implements {CustomDialogComponent}
 */
@Component({
	selector: 'sm-super-token-service-error',
	templateUrl: './service-error.component.html',
	styleUrls: [ './service-error.component.scss' ]
})
export class SuperTokenServiceErrorComponent implements CustomDialogComponent {
	/**
	 * Crea una instancia de SuperTokenServiceErrorComponent.
	 * @memberof SuperTokenServiceErrorComponent
	 */
	constructor(
	) {}

	/**
	 * data del componente donde se intancia
	 *
	 * @type {*}
	 * @memberof SuperTokenServiceErrorComponent
	 */
	public data: any;

}
