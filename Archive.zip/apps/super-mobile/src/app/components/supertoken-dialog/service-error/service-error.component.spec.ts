import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SuperTokenServiceErrorComponent } from './service-error.component';

describe('SuperTokenServiceErrorComponent', () => {
	let component: SuperTokenServiceErrorComponent;
	let fixture: ComponentFixture < SuperTokenServiceErrorComponent > ;

	beforeEach(async (() => {
		TestBed.configureTestingModule({
			declarations: [SuperTokenServiceErrorComponent],
			imports: []
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(SuperTokenServiceErrorComponent);
		component = fixture.componentInstance;
		component.data = {
			title: '¡Vaya!',
			message: 'Esto es una prueba unitaria'
		};
		fixture.autoDetectChanges();
	});

	// it('should create', () => {
	// 	expect(component).toBeTruthy();
	// });

});


