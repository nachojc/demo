import {
	Component,
	EventEmitter,
	OnInit,
	Output,
	ViewChild,
	ViewContainerRef,
	ComponentFactoryResolver
} from '@angular/core';
import { ConfirmSuperTokenService } from './confirm-supertoken.service';
import {
	CustomDialogComponent,
	CustomDialog
} from '@santander/flame-component-library';
import { FormGroup, FormControl, Validators } from '@angular/forms';

/**
 *
 *
 * @export
 * @class SuperTokenDialogAbstractionComponent
 * @implements {OnInit}
 * @implements {CustomDialogComponent}
 */
@Component({
	selector: 'sm-token-dialog-abstraction',
	templateUrl: './dialog-abstraction.component.html',
	styleUrls: ['./dialog-abstraction.component.scss'],
	providers: [ConfirmSuperTokenService]
})
export class SuperTokenDialogAbstractionComponent
	implements OnInit, CustomDialogComponent {
	/**
	 * Crea una instancia de SuperTokenDialogAbstractionComponent.
	 * @param {ConfirmSuperTokenService} _confirmService
	 * @param {ComponentFactoryResolver} _componentFactoryResolver
	 * @memberof SuperTokenDialogAbstractionComponent
	 */
	constructor(
		private _confirmService: ConfirmSuperTokenService,
		private _componentFactoryResolver: ComponentFactoryResolver
	) {}

	/**
	 * variables publicas
	 *
	 * @type {FormGroup}
	 * @memberof SuperTokenDialogAbstractionComponent
	 */
	public tokenForm: FormGroup;
	public data: any;
	public tokenInput: string;
	public statusSlide: string;
	public tokenInputLength = 0;
	public subtitle = '';

	/**
	 * Referencia a snHost que se encuentre dentro del template.
	 * @type {DialogDirective}
	 * @memberof DialogComponent
	 */
	@ViewChild('snHost', { read: ViewContainerRef })
	public snHost: any;
	/**
	 *
	 *
	 * @type {EventEmitter<any>}
	 * @memberof SuperTokenDialogAbstractionComponent
	 */
	@Output() readonly confirm: EventEmitter<any> = new EventEmitter<any>();

	private setProperty(object: any, name: string) {
		if (object.hasOwnProperty(name) && object[name] !== undefined) {
			this[name] = object[name];
		}
	}

	/**
	 * regresa el valor introducido en el dialgo token
	 *
	 * @memberof SuperTokenDialogAbstractionComponent
	 */
	public confirmationEvent() {
		this._confirmService.confirm();
		this.data.confirmEvent(200, this.tokenForm.get('tokenInput').value);
	}

	/**
	 * muestra mensaje de error 
	 *
	 * @returns
	 * @memberof SuperTokenDialogAbstractionComponent
	 */
	public getErrorMessageTokenInput() {
		return this.tokenForm.controls.tokenInput.hasError('required')
			? '*Campo obligatorio'
			: this.tokenForm.controls.tokenInput.hasError('pattern')
			? '*Sólo caracteres numéricos'
			: this.data.error.title
			? `${this.data.error.title}`
			: '';
	}

	/**
	 *
	 *
	 * @memberof SuperTokenDialogAbstractionComponent
	 */
	ngOnInit() {
		this.tokenForm = new FormGroup({
			tokenInput: new FormControl('', {
				validators: [
					Validators.required,
					Validators.minLength(this.data.tokenInputLength),
					Validators.pattern('[0-9]*')
				],
				updateOn: 'change'
			})
		});
		if (this.data) {
			if (this.data.hasOwnProperty('customBody') && this.data.customBody) {
				let bodyContent: CustomDialog;
				if (this.data.customBody instanceof CustomDialog) {
					bodyContent = this.data.customBody;
				} else {
					bodyContent = new CustomDialog(this.data.customBody);
				}
				const componentFactory = this._componentFactoryResolver.resolveComponentFactory(
					bodyContent.component
				);
				const viewContainerRef = this.snHost;
				viewContainerRef.clear();
				const componentRef = viewContainerRef.createComponent(componentFactory);
				(<CustomDialogComponent>componentRef.instance).data = bodyContent.data;
			}
			this.setProperty(this.data, 'tokenInputLength');
			this.setProperty(this.data, 'subtitle');
		}
	}
}
