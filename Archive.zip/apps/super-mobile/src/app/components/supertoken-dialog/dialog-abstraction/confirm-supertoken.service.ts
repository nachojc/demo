import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable()
export class ConfirmSuperTokenService {
	private statusSlide = new Subject<any>();
	private control = new Subject<any>();

	getStatusSlide(): Subject<any> {
		return this.statusSlide;
	}

	getControl(): Subject<any> {
		return this.control;
	}

	confirm() {
		this.control.next(true);
	}

	getResponse(): Observable<any> {
		return this.control.asObservable();
	}

	setStatusSlide(value: string) {
		this.statusSlide.next(value);
	}

	getObservableStatusSlide(): Observable<any> {
		return this.statusSlide.asObservable();
	}
}
