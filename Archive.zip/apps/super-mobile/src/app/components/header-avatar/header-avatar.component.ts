import { Component, Input } from '@angular/core';
@Component({
	selector: 'sm-header-avatar',
	templateUrl: './header-avatar.component.html',
	styleUrls: ['./header-avatar.component.scss']
})
export class HeaderAvatarComponent {

	/**
	 * Indica el nombre en el avatar
	 * @type {string }
	 * @memberof HeaderAvatarComponent
	 */
	@Input() namePersonal: string;


	/**
	 * Indica la imagen de notificacion que se encuentra en el avatar
	 * @type {string}
	 * @memberof HeaderAvatarComponent
	 */
	@Input() imagePath: string;

	/**
	 * Muestra la informacion que se ingresa en el avatar
	 * @type {string}
	 * @memberof HeaderAvatarComponent
	 */
	@Input() infoContainer: string;


	/**
	 * Genera el Monograma que se mostrara en caso de no existir imagen.
	 *
	 * @private
	 * @param {string} name
	 * @returns
	 * @memberof AvatarComponent
	 */
	private renderMonogram(name: string): string {
		if (name) {
			return name.split(' ').length > 0 ?
				`${name.split(' ')[0][0]}${name.split(' ')[1][0]}` :
				name.substr(0,2);
		} else {
			return '';
		}
	}

}
