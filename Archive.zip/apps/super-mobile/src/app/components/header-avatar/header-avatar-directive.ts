import { Directive, HostListener, ElementRef, Input } from '@angular/core';

/**
 * directiva del avatar header
 *
 * @export
 * @class HeaderAvatarDirective
 */
@Directive({
	selector: '[smHeaderAvatar]'
})
export class HeaderAvatarDirective {
	/**
	 *Creates an instance of HeaderAvatarDirective.
	 * @param {ElementRef} el
	 * @memberof HeaderAvatarDirective
	 */
	constructor(private el: ElementRef) {}

	/**
	 * variables publicas y privadas @Input
	 *
	 * @private
	 * @memberof HeaderAvatarDirective
	 */
	private isScaled = false;
	private isWhite = false;
	private scaleStates = [
		1,
		0.975,
		0.95,
		0.925,
		0.9,
		0.875,
		0.85,
		0.825,
		0.8,
		0.775,
		0.75
	];
	@Input('smHeaderAvatar') active = true;

	/**
	 * muestra animacion cuando se detecta un scroll
	 *
	 * @param {*} event
	 * @memberof HeaderAvatarDirective
	 */
	@HostListener('window:scroll', ['$event'])
	onscroll(event) {
		const top = event.srcElement.children[0].scrollTop;
		if (top >= 10 && top < 120 && this.active) {
			const text = this.el.nativeElement.querySelector('.sn-top-bar-center');
			text.style.transform = `scale(${
				this.scaleStates[Math.floor(top / 10) - 1]
			})`;
		} else if (top < 10 && this.active) {
			if (this.isScaled) {
				const text = this.el.nativeElement.querySelector('.sn-top-bar-center');
				this.isScaled = false;
				text.style.transform = `scale(${this.scaleStates[0]})`;
			}
		} else if (top > 120 && this.active) {
			if (!this.isScaled) {
				const text = this.el.nativeElement.querySelector('.sn-top-bar-center');
				this.isScaled = true;
				text.style.transform = `scale(${this.scaleStates[10]})`;
			}
		}

		// if (top >= 120 && top < 230  && this.active) {
		// 	this.el.nativeElement.style.backgroundColor = this.colorStates[
		// 		Math.floor(top / 10) - 12
		// 	];
		// } else if (top < 120  && this.active) {
		// 	if (this.isWhite) {
		// 		this.isWhite = false;
		// 		this.el.nativeElement.style.backgroundColor = this.colorStates[0];
		// 	}
		// } else if (top > 230 && this.active) {
		// 	if (!this.isWhite) {
		// 		this.isWhite = true;
		// 		this.el.nativeElement.style.backgroundColor = this.colorStates[10];
		// 	}
		// }
	}
}
