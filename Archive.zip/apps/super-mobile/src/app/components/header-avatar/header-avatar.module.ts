
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderAvatarComponent } from './header-avatar.component';
import { HeaderAvatarDirective } from './header-avatar-directive';
import {
	DarkTheme,
	FlameFoundationTheme,
	IconModule,
	ThemeModule
} from '@santander/flame-component-library';

@NgModule({
	imports: [
		CommonModule,
		IconModule,
		ThemeModule.forRoot({
		themes: [DarkTheme, FlameFoundationTheme],
		active: 'flame-foundation'
	})],
	declarations: [HeaderAvatarComponent, HeaderAvatarDirective],
	exports: [HeaderAvatarComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA ]


})
export class HeaderAvatarModule {}
