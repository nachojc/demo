import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	TagModule,
	DialogContentService,
	LoaderDialogService,
	TokenInputModule
} from '@santander/flame-component-library';

import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import {
	FlameCoreLibraryModule,
	CryptoService,
	GlobileHttpClient,
	IdpService,
	DataTransferService,
	ENV_CONFIG,
	AuthenticationService
} from '@santander/flame-core-library';

import { ReactiveFormsModule } from '@angular/forms';
import { environment } from 'apps/super-mobile/src/environments/environment';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
import { AppRoutingModule } from 'apps/super-mobile/src/app/app.routing.module';
import { AppComponent } from 'apps/super-mobile/src/app/app.component';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { NgxPermissionsModule } from 'ngx-permissions';
import { MyLifeServices } from '../my-life/services/my-life-services';
import { AccesViewComponent } from '../access-view/access-view.component';
import { MoreMainMenuViewComponent } from '../more-main-menu-view/more-main-menu-view.component';
import { BeneficiariesServicesViewComponent } from '../beneficiaries-services-view/beneficiaries-services-view.component';
import { IdpFakeViewComponent } from '../idp-fake-view/idp-fake-view.component';
import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
import { DialogClarificationsComponent } from '../more-main-menu-view/components/dialog-clarifications/dialog-clarifications.component';
import { DialogErrorMoreComponent } from '../more-main-menu-view/components/dialog-error-more/dialog-error-more.component';
import { DialogCloseLoginComponent } from '../more-main-menu-view/components/dialog-close-login/dialog-close-login.component';
import { MyLifeViewComponent } from '../my-life/my-life-view/my-life-view.component';
import { MyLifeDeclarationComponents } from '../my-life/components/my-life-components';
import { TransactionDateFilterPipe } from '../my-life/pipes/transactions-date-filter.pipe';
import { SkeletonViewMoreComponent } from '../more-main-menu-view/components/skeleton-more-view/skeleton-view-more.component';
import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { HeaderAvatarComponent } from './header-avatar.component';
import { HeaderAvatarModule } from './header-avatar.module';
import { ButtonListComponent } from '../more-main-menu-view/components/button-list/button-list.component';
describe('HeaderAvatarComponent', () => {
	let fixture: ComponentFixture<HeaderAvatarComponent>;
	let component: HeaderAvatarComponent;


	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AppRoutingModule,
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				HttpClientModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				RouterModule,
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				FlameCoreLibraryModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
        TabModule,
        HeaderAvatarModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				MyFinancesOperationLibraryModule,
				BeneficiaryOperationLibraryModule,
				PaymentsOperationLibraryModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				TokenInputModule,
				NgxPermissionsModule.forRoot()
			],
			declarations: [
				AccesViewComponent,
				AppComponent,
				MoreMainMenuViewComponent,
				BeneficiariesServicesViewComponent,
				IdpFakeViewComponent,
				ErrorDialogComponent,
				DialogClarificationsComponent,
				DialogErrorMoreComponent,
				DialogCloseLoginComponent,
				MyLifeViewComponent,
				MyLifeDeclarationComponents,
				TransactionDateFilterPipe,
        SkeletonViewMoreComponent,
        ButtonListComponent
			],
			providers: [
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				DataTransferService,
				DatePipe,
				DialogContentService,
				ContactDialogService,
				LoaderDialogService,
				MyLifeServices,
				WINDOW_PROVIDERS,
				TransactionDateFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: environment
				},
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(HeaderAvatarComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});


});
