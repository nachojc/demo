
import { Component, OnInit } from '@angular/core';
import { ThemeService } from '@santander/flame-component-library';
import { TemplateModalThemeOverlayRef } from '../dialog-theme-view';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

/**
 * dialogo de seleccion de tema
 *
 * @export
 * @class SelectThemeComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'sm-select-theme',
  templateUrl: './select-theme.component.html',
  styleUrls: ['./select-theme.component.scss']
})
export class SelectThemeComponent implements OnInit{

  /**
   *Creates an instance of SelectThemeComponent.
   * @param {TemplateModalThemeOverlayRef} parent
   * @param {FormBuilder} themeSelectionFormBuilder
   * @param {ThemeService} _snTheme
   * @memberof SelectThemeComponent
   */
  constructor(
    private parent: TemplateModalThemeOverlayRef,
    private themeSelectionFormBuilder: FormBuilder,
    public _snTheme: ThemeService
  ) { }

  /**
   * variables publicas
   *
   * @type {boolean}
   * @memberof SelectThemeComponent
   */
  public verifyRadioLigth: boolean;
  public verifyRadioDark: boolean;
  public selectedTheme:string;
  public themeSelectionForm: FormGroup;

  /**
   * cambia el tema 
   *
   * @param {*} event
   * @memberof SelectThemeComponent
   */
  public changeTheme(event:any): void{
    const newTheme = event.value;
    this._snTheme.setTheme(newTheme);
		localStorage.setItem('theme', newTheme);
  }

  /**
   * cierra el dialogo
   *
   * @memberof SelectThemeComponent
   */
  public submitTheme() {
    this.parent.close();
  }

  /**
   *
   *
   * @memberof SelectThemeComponent
   */
  public ngOnInit(){
    this.selectedTheme = localStorage.getItem('theme');
    this.themeSelectionForm = this.themeSelectionFormBuilder.group({
      themeSelectionRadioGroup: [this.selectedTheme, Validators.required]
    })
  }
}
