import {
  Component,
  OnInit,
  OnDestroy
} from '@angular/core';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { IdpService, CustomerService, NavigationBackHelperService } from '@santander/flame-core-library';
import {
  AuthenticationService
} from '@santander/flame-core-library';
import { DialogService, DialogReference, CustomDialog, DialogContentService, LoaderOverlayService } from '@santander/flame-component-library';
import { IdpFakeViewComponent } from '../idp-fake-view/idp-fake-view.component';
import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
import { environment } from '../../../environments/environment';
import { Subject, } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AccessAnimation } from './animations/access.animation'

/**
 * pantalla de inicio
 *
 * @export
 * @class AccesViewComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'sm-access-view',
  templateUrl: './access-view.component.html',
  styleUrls: ['./access-view.component.scss'],
  animations: [
    AccessAnimation.titleMoveTrigger,
    AccessAnimation.boxUnoGrowTrigger,
    AccessAnimation.boxTreGrowTrigger,
    AccessAnimation.boxDosGrowTrigger,
    AccessAnimation.bottomSideMoveTrigger
  ]
})

export class AccesViewComponent implements OnDestroy {
  /**
   *Creates an instance of AccesViewComponent.
   * @param {NavigationBackHelperService} _router
   * @param {IdpService} _idpService
   * @param {AuthenticationService} _authenticationService
   * @param {DialogContentService} _dialogContentService
   * @param {DialogService} _dialog
   * @param {LoaderOverlayService} _loaderOverlayService
   * @param {CustomerService} _customerService
   * @memberof AccesViewComponent
   */
  constructor(
    private _router: NavigationBackHelperService,
    private _idpService: IdpService,
    private _authenticationService: AuthenticationService,
    private _dialogContentService: DialogContentService,
    private _dialog: DialogService,
    private _loaderOverlayService: LoaderOverlayService,
    private _customerService: CustomerService
  ) {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('customer');
    localStorage.removeItem('expires_in');
    localStorage.removeItem('oauthToken');
    this._customerService.clearCaching();
  }

  /**
   * variables publicas y privadas
   *
   * @private
   * @memberof AccesViewComponent
   */
  private destroyed = new Subject<boolean>();
  private _dialogRef: DialogReference;
  private initialPath: string;
  private _overlayRef: any;
  public ingresarClicked = '';
  public userId: string;
  public isDisabled = false;
  public controlAnimation = false;
  // public buttons = [
  //   {
  //     name: 'Transferir',
  //     icon: 'sn-BAN069',
  //     route: '/transfers/initial'
  //   },
  //   {
  //     name: 'Pagar',
  //     icon: 'sn-BAN047',
  //     route: '/payments/services'
  //   },
  //   {
  //     name: 'Retiro sin Tarjeta',
  //     icon: 'sn-BAN042',
  //     route: ''
  //   },
  //   {
  //     name: 'Token',
  //     icon: 'sn-FUNC041',
  //     route: ''
  //   },
  //   {
  //     name: 'Sucursales',
  //     icon: 'sn-CHAN034',
  //     route: ''
  //   }
  // ];

  /**
   * muestra mensaje de error recuperado por idp o oauth
   *
   * @private
   * @param {*} dataInfo
   * @memberof AccesViewComponent
   */
  private showError(dataInfo: any) {
    this.closeLoader();
    const message = (dataInfo && dataInfo.error_description) ? dataInfo.error_description : ((dataInfo && dataInfo.message && dataInfo.status !== 0) ? dataInfo.message : 'Verifique sus datos. Para cualquier duda o aclaración es necesario que se comunique s Superlínea en México al 51694300 o desde el interior de la República al 01 800 50 10000 a la opción Internet.');
    this._dialogRef = this._dialog.open(
      {
        closeLabel: 'Cerrar',
        title: '',
        enableHr: false,
        disabledButton: true,
        buttons: [
          {
            label: 'Aceptar',
            class: 'full',
            action: scope => {
              this._dialogRef.close();
            }
          }
        ]
      },
      new CustomDialog(ErrorDialogComponent, {
        message: message,
        img_type: 'emoji'
      })
    );
  }

  /**
   * redirecciana de acuerdo al menu bar
   *
   * @param {string} navigationRoute
   * @memberof AccesViewComponent
   */
  public navigateFromNavbar(navigationRoute: string) {
    if (navigationRoute !== '') {
      this.initialPath = navigationRoute;
      this.ingresarAnimationHandler();
    }
  }

  /**
   * obtiene del servicio del oauth loas datos como el acces_token
   *
   * @param {string} code
   * @memberof AccesViewComponent
   */
  public getAccessToken(code: string) {
    this._authenticationService.getAccessToken(code)
      .pipe(takeUntil(this.destroyed))
      .subscribe(
        (response: any) => {
          const responseOauth: string = typeof response === 'string' ? response : JSON.stringify(response);
          localStorage.setItem('oauthToken', responseOauth);
          if (this.initialPath) {
            this._router.navigate([this.initialPath]);
          } else {
            this._router.navigate(['/my-life']);
          }
          this.closeLoader();
        },
        (error: any) => {
          this.showError(error);
          this.ingresarClicked = 'in';
        }
      )
  }

  /**
   * abre el loader
   *
   * @memberof AccesViewComponent
   */
  openLoader() {
    this._overlayRef = this._loaderOverlayService.open('Espera, esta operación puede tardar unos minutos');
  }



  /**
   * cierra el loader
   *
   * @memberof AccesViewComponent
   */
  closeLoader() {
    if (this._overlayRef) {
      this._overlayRef.close();
    }
  }

  public idpComponent() {
    if (environment.production) {
      this._idpService.invokeIdpFlow()
        .pipe(takeUntil(this.destroyed))
        .subscribe((response: any) => {
          const responseIDP = JSON.parse(response);
          if (responseIDP.hasOwnProperty('code')) {
            this.openLoader();
            this.getAccessToken(responseIDP.code);
            localStorage.setItem('accessToken', responseIDP.code);

          } else {
            if (responseIDP.error_type !== 'cancelled')
              this.showError(responseIDP);
            this.ingresarClicked = 'in';
            this.controlAnimation = false;
          }
        }, (error: any) => {
          if (error.error_type === 'cancelled') {
            this.ingresarClicked = 'in'
            this.controlAnimation = false;
          }
          this.showError(error);
          this.ingresarClicked = 'in';
        });
    } else {
      this._dialogContentService.open(IdpFakeViewComponent).afterClosed()
        .pipe(takeUntil(this.destroyed))
        .subscribe(result => {
          this.openLoader();
          if (result) {
            this.getAccessToken('Uk8AD_rr7g5ruzBjLjQenmGm6_Sb9ePtgs0KznsuvZ99A9FWEHQX5cihHi-J5NACAKeYP1iaw5Jfe23OoXQfftlkOryGIsixm4uK8gnokqgY7hlIrSKjpanir21s2U8zujuoE8hVqqoVhaONC8f8DON2k0Q1vQ5GG82HpQeFJNa6og8CefZyVWrKKj6PuIZVNgj8M5lOtjQGn60-QQAWNQQt3GWNUlUXaEdO2RZofV9oNn_1c0m6i3cd7mXvxHfdiH0kK5gEZcGbfTUuhJhA7VIKiM40PTjOQQKpHcT-cIoCBHooKMMz1nDCuHg7NAW2ZXvlshJ8OtSjphyHjsgNUQ==');
          } else {
            this.showError('');
            this.ingresarClicked = 'in';
          }
        });
    }

  }

  /**
   * cambia el estado de la animación
   *
   * @memberof AccesViewComponent
   */
  ingresarAnimationHandler() {
    this.ingresarClicked = 'out';
  }

  /**
   * inicia la animacion y abre el componente de globile IdpLib
   *
   * @param {*} event
   * @memberof AccesViewComponent
   */
  ingresarAnimationHasEnded(event: any) {
    if (!this.controlAnimation && event.toState === 'out' && this.ingresarClicked === 'out') {
      this.idpComponent();
      this.controlAnimation = !this.controlAnimation;
    }
  }

  /**
   *
   *
   * @memberof AccesViewComponent
   */
  ngOnDestroy() {
    this.destroyed.next(true);
    this.destroyed.complete();
  }

}
