// import { MyLifeViewComponent } from './../my-life/my-life-view/my-life-view.component';
// import { MyLifeDeclarationComponents } from './../my-life/components/my-life-components';
// import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
// import { AccesViewComponent } from './access-view.component';
// import {
// 	ButtonModule,
// 	SlideToggleModule,
// 	IconButtonModule,
// 	CardModule,
// 	CarouselModule,
// 	FlameFoundationTheme,
// 	IconModule,
// 	NavbarModule,
// 	SpinnerModule,
// 	ThemeModule,
// 	TopBarModule,
// 	FormFieldModule,
// 	InputModule,
// 	EmojiModule,
// 	TabsModule,
// 	TabModule,
// 	ProductModule,
// 	ChipModule,
// 	AvatarModule,
// 	SearchBarModule,
// 	DialogModule,
// 	TokenDialogModule,
// 	ContactDialogModule,
// 	DialogContentModule,
// 	ContactDialogService,
// 	LoaderOverlayModule,
// 	TagModule,
// 	DialogContentService,
// 	LoaderDialogService,
// 	TokenInputModule,
// 	LoaderOverlayService,
// } from '@santander/flame-component-library';
// import { AppRoutingModule } from '../../app.routing.module';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { BrowserModule, By } from '@angular/platform-browser';
// import { CommonModule, APP_BASE_HREF, DatePipe } from '@angular/common';
// import {
// 	HttpClientModule,
// 	HTTP_INTERCEPTORS,
// 	HttpXhrBackend,
// 	XhrFactory
// } from '@angular/common/http';
// import { RouterModule } from '@angular/router';
// import { ReactiveFormsModule } from '@angular/forms';
// import {
// 	FlameCoreLibraryModule,
// 	AuthenticationService,
// 	CryptoService,
// 	GlobileHttpClient,
// 	IdpService,
// 	DataTransferService,
// 	ENV_CONFIG,
// 	ApiInterceptor,
// 	SuperTokenService,
// 	BackButtonService,
// 	CustomerService,
// 	CardReaderService
// } from '@santander/flame-core-library';
// import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
// import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
// import { AppComponent } from '../../app.component';
// import { MoreMainMenuViewComponent } from '../more-main-menu-view/more-main-menu-view.component';
// import { BeneficiariesServicesViewComponent } from '../beneficiaries-services-view/beneficiaries-services-view.component';
// import { IdpFakeViewComponent } from '../idp-fake-view/idp-fake-view.component';
// import { ErrorDialogComponent } from '../error-dialog/error-dialog.component';
// import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
// import { environment } from 'apps/super-mobile/src/environments/environment';
// import { globileHttpXhrBackendFactory } from '../../app.module';
// import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
// import { DialogClarificationsComponent } from '../more-main-menu-view/components/dialog-clarifications/dialog-clarifications.component';
// import { DialogErrorMoreComponent } from '../more-main-menu-view/components/dialog-error-more/dialog-error-more.component';
// import { DialogCloseLoginComponent } from '../more-main-menu-view/components/dialog-close-login/dialog-close-login.component';
// import { TransactionDateFilterPipe } from '../my-life/pipes/transactions-date-filter.pipe';
// import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
// import { MyLifeServices } from '../my-life/services/my-life-services';
// import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
// import { of } from 'rxjs';
// import { NgModule } from '@angular/core';
// import { SkeletonViewMoreComponent } from '../more-main-menu-view/components/skeleton-more-view/skeleton-view-more.component';
// import { NgxPermissionsModule } from 'ngx-permissions';
// import { SuperTokenDialogService } from '../supertoken-dialog/supertoken-dialog.service';
// import { ConfirmSuperTokenService } from '../supertoken-dialog/dialog-abstraction/confirm-supertoken.service';

// const accessToken = {
// 	data: {

// 			"access_token": "MTQ0NjJkZmQ5OTM2NDE1ZTZjNGZmZjI3",
// 			"token_type": "Bearer",
// 			"expires_in": 60,
// 			"refresh_token": "IwOGYzYTlmM2YxOTQ5MGE3YmNmMDFkNTVk",
// 			"scope": "summary_1.0.0 accounts_1.0.0"
// 	}
// };

// @NgModule({
// 	declarations: [IdpFakeViewComponent],
// 	entryComponents: [IdpFakeViewComponent]
// }) class IdpModule {}

// describe('AccesViewComponent', () => {
// 	let component: AccesViewComponent;
// 	let fixture: ComponentFixture < AccesViewComponent >;
// 	let authenticationS  = AuthenticationService;
// 	let idpServiceTest = IdpService;
// 	let loaderOverlayServiceTest = LoaderOverlayService

// 	beforeEach(async (() => {
// 		TestBed.configureTestingModule({
// 			imports: [
// 				// IdpModule,
// 				AppRoutingModule,
// 				AvatarModule,
// 				BrowserAnimationsModule,
// 				BrowserModule,
// 				ButtonModule,
// 				CardModule,
// 				CarouselModule,
// 				ChipModule,
// 				CommonModule,
// 				ContactDialogModule,
// 				FormFieldModule,
// 				HttpClientModule,
// 				IconModule,
// 				InputModule,
// 				NavbarModule,
// 				ProductModule,
// 				RouterModule,
// 				SearchBarModule,
// 				SlideToggleModule,
// 				IconButtonModule,
// 				ReactiveFormsModule,
// 				SpinnerModule,
// 				TagModule,
// 				FlameCoreLibraryModule,
// 				DialogModule,
// 				DialogContentModule,
// 				TabsModule,
// 				TabModule,
// 				ThemeModule.forRoot({
// 					themes: [FlameFoundationTheme],
// 					active: 'flame-foundation'
// 				}),
// 				TopBarModule,
// 				EmojiModule,
// 				TokenDialogModule,
// 				MyFinancesOperationLibraryModule,
// 				BeneficiaryOperationLibraryModule,
// 				PaymentsOperationLibraryModule,
// 				LoaderOverlayModule,
// 				TagModule,
// 				NgxSkeletonLoaderModule,
// 				TokenInputModule,
// 				NgxPermissionsModule.forRoot()
// 			],
// 			declarations: [
// 				AccesViewComponent,
// 				AppComponent,
// 				MoreMainMenuViewComponent,
// 				BeneficiariesServicesViewComponent,
// 				IdpFakeViewComponent,
// 				ErrorDialogComponent,
// 				DialogErrorMoreComponent,
// 				MyLifeViewComponent,
// 				MyLifeDeclarationComponents,
// 				TransactionDateFilterPipe,
// 				SkeletonViewMoreComponent
// 			],
// 			providers: [
// 				AuthenticationService,
// 				BeneficiaryService,
// 				CryptoService,
// 				GlobileHttpClient,
// 				IdpService,
// 				DataTransferService,
// 				DatePipe,
// 				DialogContentService,
// 				ContactDialogService,
// 				LoaderDialogService,
// 				MyLifeServices,
// 				WINDOW_PROVIDERS,
// 				TransactionDateFilterPipe,
// 				SuperTokenDialogService,
// 				ConfirmSuperTokenService,
// 				SuperTokenService,
// 				BackButtonService,
// 				CustomerService,
// 				LoaderOverlayService,
// 				CardReaderService,
// 				{
// 					provide: ENV_CONFIG,
// 					useValue: environment
// 				},
// 				{
// 					provide: HTTP_INTERCEPTORS,
// 					useClass: ApiInterceptor,
// 					multi: true
// 				},
// 				{
// 					provide: HttpXhrBackend,
// 					useFactory: globileHttpXhrBackendFactory,
// 					deps: [XhrFactory]
// 				},
// 				{
// 					provide: APP_BASE_HREF,
// 					useValue: '/'
// 				}
// 			]
// 		}).compileComponents();
// 	}));

// 	beforeEach(() => {
// 		fixture = TestBed.createComponent(AccesViewComponent);
// 		component = fixture.componentInstance;
// 		fixture.detectChanges();
// 		idpServiceTest = TestBed.get(IdpService)
// 		authenticationS = TestBed.get(AuthenticationService);
// 		loaderOverlayServiceTest = TestBed.get(LoaderOverlayService);
// 	});

// 	it('should create', () => {
// 		expect(component).toBeTruthy();
// 	});

// 	it('Should function deleteUserId', () => {
// 		fixture.componentInstance.deleteUserId();
// 		fixture.detectChanges();
// 	});

// 	it('Should access function ingresarAnimationHandler ', () => {
// 		fixture.componentInstance.ingresarAnimationHandler();
// 		fixture.detectChanges();
// 	});

// 	// it('Should access function openLoader ', () => {
// 	// 	fixture.componentInstance.openLoader();
// 	// 	fixture.autoDetectChanges();
// 	// });

// 	// it('Should access function closeLoader ', () => {
// 	// 	fixture.componentInstance.closeLoader();
// 	// 	fixture.detectChanges();
// 	// });

// 	it('Should get info IDP',
// 	inject([IdpService], (serviceIdp: IdpService) => {
// 		expect(serviceIdp).toBeTruthy();
// 	}));

// 	it('Should get info IDP',
// 	inject([IdpService], (serviceIdp: IdpService) => {
// 		fixture.componentInstance.idpComponent();
// 		fixture.detectChanges();
// 		const btnIdp = fixture.debugElement.query(By.css('.button-container div button'));
// 		spyOn(serviceIdp, 'invokeIdpFlow');
// 		btnIdp.nativeElement.click();
// 		console.log(btnIdp);
// 		// fixture.whenStable().then(() => {
// 		// 	expect(serviceIdp.invokeIdpFlow).toHaveBeenCalledWith('in');
// 		// });
// 	}));

// it('Should get info IDP', () => {
// 	fixture.componentInstance.idpComponent();
// 	fixture.detectChanges();
// 	if (environment.production) {
// 		inject([IdpService], (serviceIdp: IdpService) => {
// 			this.idpServiceTest.invokeIdpFlow().subscribe(
// 				(response) => expect(response.json().toHaveBeenCalledWith())
// 			);
// 			console.log(serviceIdp);
// 			fixture.whenStable().then(() => {
// 					expect(serviceIdp.invokeIdpFlow).toHaveBeenCalledWith('');
// 				 });
// 		})
// 	}
// })

// // it('prueba', () => {
// // 	fixture.componentInstance.openLoader();
// // 	fixture.detectChanges();

// // 		// tslint:disable-next-line:no-shadowed-variable
// // 		inject([LoaderOverlayService], (LoaderOverlayService: LoaderOverlayService) => {
// // 			console.log(LoaderOverlayService);
// // 			fixture.whenStable().then(() => {
// // 					expect(LoaderOverlayService.open).toHaveBeenCalledWith('');
// // 				 });
// // 		})
// // })

// });
