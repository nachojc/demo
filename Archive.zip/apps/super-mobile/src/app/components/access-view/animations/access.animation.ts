import {
    trigger,
    state,
    style,
    transition,
    animate
} from '@angular/animations';

const easing = {
    standard: 'cubic-bezier(0.75, 0, 0.75, 1)',
};

export const AccessAnimation = {
    boxTreGrowTrigger: [
        trigger('boxTreGrow', [
            state('out', style({ height: '100%' })),
            state('in', style({ height: '38px' })),
            transition('* => out', animate('0.5s 0.40s ' + easing.standard)),
            transition('out => *', animate('0.5s 0.40s ' + easing.standard))
        ])
    ],
    boxDosGrowTrigger: [
        trigger('boxDosGrow', [
            state('out', style({ height: '100%' })),
            state('in', style({ height: '19px' })),
            transition('* => out', animate('0.5s 0.45s ' + easing.standard)),
            transition('out => *', animate('0.5s 0.45s ' + easing.standard))
        ])
    ],
    boxUnoGrowTrigger: [
        trigger('boxUnoGrow', [
            state('out', style({ height: '100%' })),
            state('in', style({ height: '0px' })),
            transition('* => out', animate('0.5s 0.50s ' + easing.standard)),
            transition('out => *', animate('0.5s 0.50s ' + easing.standard))
        ])
    ],
    titleMoveTrigger: [
        trigger('titleMove', [
            state('out', style({ transform: 'translateY(-190px)', opacity: 0 })),
            state('in', style({ transform: 'translateY(0px)', opacity: 1 })),
            transition('* => out', animate('0.5s 0.45s ' + easing.standard)),
            transition('out => *', animate('0.5s 0.45s ' + easing.standard))
        ])
    ],
    bottomSideMoveTrigger: [
        trigger('bottomSideMove', [
            state('out', style({ transform: 'translateY(100px)', opacity: 0 })),
            state('in', style({ transform: 'translateY(0px)', opacity: 1 })),
            transition('* => out', animate('0.5s 0.45s ' + easing.standard)),
            transition('out => *', animate('0.5s 0.45s ' + easing.standard))
        ])
    ]
}