export interface ViewSlide {
	id: string;
	activated: boolean;
	index: number;
}
