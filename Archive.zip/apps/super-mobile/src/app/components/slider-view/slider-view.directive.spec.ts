import { SnViewSlideDirective } from './view-slide.directive';
import { SnSliderViewDirective } from './slider-view.directive';
import { Component, ViewChild } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SliderViewModule } from './slider-view.module';
import { By } from '@angular/platform-browser';

@Component({
	template: `
		<div
			smSliderView
			[preview]="preview"
			[minPreview]="minPreview"
			[maxPreview]="maxPreview"
			[widthBreakPoint]="widthBreakPoint"
			[previewScale]="previewScale"
			#smSliderView="SnSliderViewDirective"
		>
			<div smViewSlide slideId="1" activated="true">
				<div class="container" #targetSlide>
					<div class="row">
						<div class="col-12"><h1>CONTENIDO 1</h1></div>
					</div>
				</div>
			</div>
			<div smViewSlide slideId="2">
				<div class="container" #targetSlide>
					<div class="row">
						<div class="col-12"><h1>CONTENIDO 2</h1></div>
					</div>
				</div>
			</div>
		</div>
		<div class="active-slide">{{ snCarousel.getActivatedSlideIndex() }}</div>
	`
})
class TestSNSliderComponent {
	@ViewChild(SnSliderViewDirective) smSliderView: SnSliderViewDirective;
	preview = true;
	minPreview = 25;
	maxPreview = 35;
	widthBreakPoint = 360;
	previewScale = 0.7;
}

describe('SnSliderViewDirective', () => {
	let component: TestSNSliderComponent;
	let fixture: ComponentFixture<TestSNSliderComponent>;
	let instance: SnSliderViewDirective;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [SliderViewModule],
			declarations: [TestSNSliderComponent]
		}).compileComponents();
		fixture = TestBed.createComponent(TestSNSliderComponent);
		component = fixture.componentInstance;
		instance = component.smSliderView;
	}));

	// it('should create', () => {
	// 	expect(component).toBeTruthy();
	// });
});
