import {
	ContentChildren,
	Directive,
	QueryList,
	Output,
	EventEmitter,
	AfterViewInit,
	ElementRef,
	Input,
	Renderer2,
	OnDestroy
} from '@angular/core';
import { SnViewSlideDirective } from './view-slide.directive';
import { ViewSlide } from './view-slide.interface';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

/**
 * Directiva que genera un slider con transición.
 *
 * @export
 * @class SnSliderViewDirective
 * @implements {AfterViewInit}
 */
@Directive({
	selector: '[smSliderView]',
	exportAs: 'SnSliderViewDirective'
})
export class SnSliderViewDirective implements AfterViewInit, OnDestroy {
	/**
	 * Crea una instancia de SnSliderViewDirective.
	 * @param {ElementRef} el
	 * @param {Renderer2} _renderer
	 * @memberof SnSliderViewDirective
	 */
	constructor(public el: ElementRef, private _renderer: Renderer2) {}
	/**
	 * Estilo de la directiva
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private styleHeader = {
		overflow: 'hidden',
		position: 'relative'
	};

	/**
	 * Permite indicar si se esta intentando arrastrar una view
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private _isDrag = false;
	/**
	 * Indica si se debe mostrar una preview de las vistas siguiente y anterior
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private _preview = true;
	/**
	 * El valor minimo que se verá de la siguiente/anterior vista
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private _minPreview = 0;
	/**
	 * El valor máximo que se verá de la siguiente/anterior vista
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private _maxPreview = 0;
	/**
	 * Escala que tendrá el target de la vista siguiente/anterior
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private _previewScale = 0;
	/**
	 * Width en el que se hará el cambio de minPreview a maxPreview
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private _widthBreakPoint = 0;

	/**
	 * Función que escucha el evento click
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private listenerClick: () => void;
	/**
	 * Función que escucha el evento panmove
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private listenerOnDrag: () => void;
	/**
	 * Función que escucha el evento panend
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private listenerOnDragEnd: () => void;
	/**
	 * Valida si el slide se ha movido ya mediante panmove
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private moveSlideAlready = false;

	/**
	 * Parámetro para indicar si se verá una vista previa de las vistas siguiente y anterior
	 *
	 * @readonly
	 * @type {boolean}
	 * @memberof SnSliderViewDirective
	 */
	@Input()
	get preview(): boolean {
		return this._preview;
	}
	set preview(value: boolean) {
		this._preview = coerceBooleanProperty(value);
	}

	/**
	 * Parámetro para establecer el valor minimo que se verá de la siguiente/anterior vista.
	 * Se puede dar en porcentaje (Ej. 25) o en valor decimal (Ej. 0.25)
	 * @readonly
	 * @type {number}
	 * @memberof SnSliderViewDirective
	 */
	@Input()
	get minPreview(): number {
		return this._minPreview;
	}
	set minPreview(value: number) {
		this._minPreview = value > 1 ? value / 100 : value;
	}

	/**
	 * Parámetro para establecer el valor máximo que se verá de la siguiente/anterior vista.
	 * Se puede dar en porcentaje (Ej. 35) o en valor decimal (Ej. 0.35)
	 * @readonly
	 * @type {number}
	 * @memberof SnSliderViewDirective
	 */
	@Input()
	get maxPreview(): number {
		return this._maxPreview;
	}
	set maxPreview(value: number) {
		this._maxPreview = value > 1 ? value / 100 : value;
	}

	/**
	 * Parámetro para establecer el valor de la escala que tendrá el target de la vista siguiente/anterior
	 * Se puede dar en porcentaje (Ej. 35) o en valor decimal (Ej. 0.35)
	 * @readonly
	 * @type {number}
	 * @memberof SnSliderViewDirective
	 */
	@Input()
	get previewScale(): number {
		return this._previewScale;
	}
	set previewScale(value: number) {
		this._previewScale = value > 1 ? value / 100 : value;
	}

	/**
	 * Parámetro para establecer el width en el que se hará el cambio de minPreview a maxPreview
	 * @readonly
	 * @type {number}
	 * @memberof SnSliderViewDirective
	 */
	@Input()
	get widthBreakPoint(): number {
		return this._widthBreakPoint;
	}
	set widthBreakPoint(value: number) {
		this._widthBreakPoint = value;
	}

	/**
	 * Lista de los elementos que se mostrarán en el slider
	 *
	 * @type {QueryList<SnViewSlideDirective>}
	 * @memberof SnSliderViewDirective
	 */
	@ContentChildren(SnViewSlideDirective) slides: QueryList<
		SnViewSlideDirective
	>;

	/**
	 * Emite un evento <strong>ViewSlide</strong> con el elemento activo.
	 *
	 * @memberof SnSliderViewDirective
	 */
	@Output() slide = new EventEmitter<ViewSlide>();

	/**
	 * Implementa los estilos del slide
	 *
	 * @private
	 * @memberof SnSliderViewDirective
	 */
	private styleSetter() {
		const element = this.el.nativeElement;
		for (const key in this.styleHeader) {
			if (this.styleHeader.hasOwnProperty(key)) {
				this._renderer.setStyle(element, key, this.styleHeader[key]);
			}
		}
	}

	/**
	 * Remueve un listener especifico
	 *
	 * @private
	 * @param {string} listener
	 * @memberof SnSliderViewDirective
	 */
	private endListener(listener: string) {
		if (this[listener]) {
			this[listener]();
		}
	}

	/**
	 * Anima la transición entre slides para desplazarlas
	 *
	 * @private
	 * @param {number} activeIndex
	 * @param {*} [moveX]
	 * @memberof SnSliderViewDirective
	 */
	private animateTranslation(activeIndex: number, moveX?: any) {
		if (this._renderer) {
			this.slides.forEach((slide: SnViewSlideDirective, index: number) => {
				const div = slide.el.nativeElement;
				const divBounding = div.getBoundingClientRect();
				const percent =
					divBounding.width >= this._widthBreakPoint
						? this._maxPreview
						: this._minPreview;
				const realInd = index - activeIndex;
				const initX = realInd * divBounding.width;
				const target = slide.target;
				const initScale =
					realInd === 0 ? 1 : Math.abs(this._previewScale / realInd);

				if (moveX) {
					// Se desplaza
					this._renderer.setStyle(div, 'transition', '');
					this._renderer.setStyle(
						div,
						'transform',
						`translate(${moveX + initX}px)`
					);
					if (this._preview && target) {
						const targetInit = initX * percent * -1;
						const increment = moveX / (this._previewScale * 1000);
						let finalScale =
							realInd < 0
								? initScale + increment
								: realInd > 0
								? initScale - increment
								: initScale - Math.abs(increment);
						finalScale =
							finalScale > 1
								? 1
								: finalScale < this._previewScale
								? this._previewScale
								: finalScale;
						finalScale =
							(realInd > 1 || realInd < -1) && finalScale >= this._previewScale
								? this._previewScale
								: finalScale;
						this._renderer.setStyle(
							target.nativeElement,
							'transform',
							`translate(${targetInit -
								moveX * percent}px) scale(${finalScale})`
						);
					}
				} else {
					// Vuelve a su estado normal
					this._renderer.setStyle(
						div,
						'transition',
						'transform 0.3s ease, -webkit-transform 0.3s ease'
					);
					this._renderer.setStyle(div, 'transform', `translate(${initX}px)`);

					if (this._preview && target) {
						const targetInit = initX * percent * -1;
						const scale = initX === 0 ? 1 : 0.7;
						this._renderer.setStyle(
							target.nativeElement,
							'transition',
							'transform 0.3s ease, -webkit-transform 0.3s ease, scale 0.3s ease'
						);
						this._renderer.setStyle(
							target.nativeElement,
							'transform',
							`translate(${targetInit}px) scale(${scale})`
						);
					}
				}
			});
		}
	}

	/**
	 * @ignore
	 * Emite el cambio de slide activo y desactiva los demás
	 * @private
	 * @param {ViewSlide} activatedSlide
	 * @memberof SnSliderViewDirective
	 */
	private _onSlideActivation(activatedSlide: ViewSlide): void {
		this.slide.emit(activatedSlide);
		this.slides
			.filter((slide: SnViewSlideDirective) => {
				this.setZIndex(
					slide.el.nativeElement,
					slide.id === activatedSlide.id ? '0' : '1'
				);
				return slide.id !== activatedSlide.id;
			})
			.forEach((slide: SnViewSlideDirective) => {
				slide.deactivate();
			});
	}

	/**
	 * Evento que se ejecuta cuando se arrastra el target o la vista
	 *
	 * @param {*} event
	 * @memberof SnSliderViewDirective
	 */
	private onDrag(event: any) {
		this._isDrag = true;
		const activeIndex = this.getActivatedSlideIndex();
		const slideActive = this.getActivedSlide();
		const div = slideActive.el.nativeElement;
		const divBounding = div.getBoundingClientRect();
		const divMiddle = divBounding.width / 3;
		const realMove = Math.abs(event.deltaX);
		if (realMove > divMiddle) {
			if (!this.moveSlideAlready){
				this.moveSlideAlready = true;
				this.moveSlide(event.deltaX, divMiddle, activeIndex);
			}
			return;
		}
		if (!this.moveSlideAlready){
			this.animateTranslation(activeIndex, event.deltaX);
		}
	}

	/**
	 * Evento que se ejecuta cuando se termina de arrastrar el target o la vista
	 *
	 * @memberof SnSliderViewDirective
	 */
	private onDragEnd() {
		const activeIndex = this.getActivatedSlideIndex();
		const slideActive = this.getActivedSlide();
		const div = slideActive.el.nativeElement;
		const divBounding = div.getBoundingClientRect();
		const divMiddle = divBounding.width / 3;
		if(!this.moveSlideAlready){
			this.moveSlide(divBounding.left, divMiddle, activeIndex);
		}
		this.moveSlideAlready = false;
	}

	/**
	 * Función que hace que se desplace el slide
	 *
	 * @private
	 * @param {*} moveX
	 * @param {*} middle
	 * @param {*} activeIndex
	 * @memberof SnSliderViewDirective
	 */
	private moveSlide(moveX: any, middle: any, activeIndex: any) {
		const realMove = Math.abs(moveX);
		const totalSlides = this.slides.length - 1;
		if (moveX < 0 && realMove > middle && activeIndex !== totalSlides) {
			// Derecha
			this.selectSlideByIndex(++activeIndex);
		} else if (moveX > 0 && realMove > middle && activeIndex !== 0) {
			// Izquierda
			this.selectSlideByIndex(--activeIndex);
		}
		this.animateTranslation(activeIndex);
	}

	/**
	 * Evita la propagación del evento de drag.
	 *
	 * @param {*} event
	 * @returns
	 * @memberof SnSliderViewDirective
	 */
	private avoidPropagation(event: any) {
		if (this._isDrag) {
			this._isDrag = false;
			event.stopPropagation();
		} else {
			return;
		}
	}

	/**
	 * Establece los eventos para deslizar las slides
	 *
	 * @private
	 * @param {*} element
	 * @memberof SnSliderViewDirective
	 */
	private setListeners(element: any) {
		this.listenerClick = this._renderer.listen(
			element,
			'click',
			this.avoidPropagation.bind(this)
		);
		this.listenerOnDrag = this._renderer.listen(
			element,
			'panmove',
			this.onDrag.bind(this)
		);
		this.listenerOnDragEnd = this._renderer.listen(
			element,
			'panend',
			this.onDragEnd.bind(this)
		);
	}

	/**
	 * Coloca un z-index sobre un slide
	 *
	 * @private
	 * @param {*} element
	 * @param {string} value
	 * @memberof SnSliderViewDirective
	 */
	private setZIndex(element: any, value: string) {
		this._renderer.setStyle(element, 'z-index', value);
	}

	/**
	 * Activa un slide mediante la interfaz ViewSlide
	 *
	 * @param {ViewSlide} slideSelected
	 * @memberof SnSliderViewDirective
	 */
	public selectSlide(slideSelected: ViewSlide): void {
		const slidesArray = this.slides.toArray();
		const index = slidesArray.findIndex(
			(slide: SnViewSlideDirective) => slide.id === slideSelected.id
		);

		slidesArray[index].activate();
	}

	/**
	 * Activa un slide mediante su id
	 *
	 * @param {string} slideSelectedId
	 * @memberof SnSliderViewDirective
	 */
	public selectSlideById(slideSelectedId: string): void {
		const slidesArray = this.slides.toArray();
		const index = slidesArray.findIndex(
			(slide: SnViewSlideDirective) => slide.id === slideSelectedId
		);
		slidesArray[index].activate();
	}

	/**
	 * Activa un slide mediante su index
	 *
	 * @param {number} index
	 * @memberof SnSliderViewDirective
	 */
	public selectSlideByIndex(index: number): void {
		const slidesArray = this.slides.toArray();
		slidesArray[index].activate();
		this.animateTranslation(index);
	}

	/**
	 * Regresa el id del elemento que se encuentra activo en el slider.
	 *
	 * @returns {number}
	 * @memberof SnSliderViewDirective
	 */
	public getActivatedSlideIndex(): number {
		if (this.slides && this.slides.length > 0) {
			return this.slides
				.toArray()
				.findIndex((slide: SnViewSlideDirective) => slide.activated);
		} else {
			return -1;
		}
	}

	/**
	 * Establece como max-height el height del slide actual sobre el slider
	 *
	 * @memberof SnSliderViewDirective
	 */
	public setMaxHeight() {
		const slide = this.getActivedSlide();
		const div = slide.el.nativeElement;
		const divBounding = div.getBoundingClientRect();
		this._renderer.setStyle(
			this.el.nativeElement,
			'max-height',
			divBounding.height + 'px'
		);
	}

	/**
	 * Regresa el elemento que se encuentra activo en el slider.
	 *
	 * @returns {SnViewSlideDirective}
	 * @memberof SnSliderViewDirective
	 */
	public getActivedSlide(): SnViewSlideDirective {
		if (this.slides && this.slides.length > 0) {
			return this.slides
				.toArray()
				.find((slide: SnViewSlideDirective) => slide.activated);
		} else {
			return null;
		}
	}

	/**
	 * @ignore
	 * Genera la lista de slides del slider y las inicializa.
	 * @memberof SnSliderViewDirective
	 */
	ngAfterViewInit() {
		this.styleSetter();
		this.slides.changes.subscribe(newSlides => {
			this.animateTranslation(this.getActivatedSlideIndex());
			newSlides.forEach((slide: SnViewSlideDirective, index: number) => {
				this.setZIndex(
					slide.el.nativeElement,
					index === this.getActivatedSlideIndex() ? '0' : '1'
				);
				if (slide.target) {
					this.setListeners(slide.target.nativeElement);
				} else {
					this.setListeners(this.el.nativeElement);
				}
				slide.index = index;
				slide.onActivate.subscribe(this._onSlideActivation.bind(this));
			});
		});
	}

	/**
	 * Termina los eventos de click, panmove, panend
	 *
	 * @memberof SnSliderViewDirective
	 */
	ngOnDestroy() {
		this.slide.unsubscribe();
		this.endListener('listenerClick');
		this.endListener('listenerOnDrag');
		this.endListener('listenerOnDragEnd');
	}
}
