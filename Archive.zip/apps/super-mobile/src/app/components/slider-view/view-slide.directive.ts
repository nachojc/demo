import {
	Directive,
	Input,
	Output,
	EventEmitter,
	ElementRef,
	ContentChild,
	AfterContentInit,
	Renderer2
} from '@angular/core';
import { ViewSlide } from './view-slide.interface';
import { coerceBooleanProperty } from '@angular/cdk/coercion';

/**
 * Elemento (slide) que se utiliza dentro del slider-view
 *
 * @export
 * @class SnViewSlideDirective
 * @implements {ViewSlide}
 * @implements {AfterContentInit}
 */
@Directive({
	selector: '[smViewSlide]',
	exportAs: 'SnViewSlideDirective'
})
export class SnViewSlideDirective implements ViewSlide, AfterContentInit {
	/**
	 * Crea una instancia de SnViewSlideDirective.
	 * @param {ElementRef} el
	 * @param {Renderer2} _renderer
	 * @memberof SnViewSlideDirective
	 */
	constructor(public el: ElementRef, private _renderer: Renderer2) {}

	/**
	 * Estilo que tendrá por default cada slide para su correcto funcionamiento
	 *
	 * @private
	 * @memberof SnViewSlideDirective
	 */
	private styleHeader = {
		position: 'relative',
		float: 'left',
		width: '100%',
		'margin-right': '-100%',
		'-webkit-backface-visibility': 'hidden',
		'backface-visibility': 'hidden'
	};

	/**
	 * @ignore
	 *  Indica el id del elemento dentro del slider.
	 * @type {string}
	 * @memberof SnViewSlideDirective
	 */
	public id: string;

	/**
	 * Parámetro que indica el id del elemento activo dentro del slider.
	 *
	 * @readonly
	 * @type {string}
	 * @memberof SnViewSlideDirective
	 */
	@Input()
	get slideId(): string {
		return this.id;
	}
	set slideId(value: string) {
		this.id = value;
	}

	/**
	 * Parámetro booleano para definir el elemento que se activará dentro del slider.
	 *
	 * @memberof SnViewSlideDirective
	 */
	@Input() activated = false;
	private set _activated(value: boolean) {
		this.activated = coerceBooleanProperty(value);
	}
	private get _activated(): boolean {
		return this.activated;
	}

	/**
	 * Parametro que indica la posición del elemento dentro del slider
	 *
	 * @memberof SnViewSlideDirective
	 */
	@Input() index = -1;
	private set _index(value: number) {
		this.index = value;
	}
	private get _index(): number {
		return this.index;
	}

	/**
	 * Emite un evento <strong>ViewSlide</strong> cuando el elemento se activa dentro del slider.
	 *
	 * @memberof SnViewSlideDirective
	 */
	@Output() onActivate = new EventEmitter<ViewSlide>();

	/**
	 * Emite un evento <strong>Slide</strong> cuando el elemento activo cambia de estado dentro del carousel.
	 *
	 *
	 * @memberof SnViewSlideDirective
	 */
	@Output() onDeactivate = new EventEmitter<ViewSlide>();

	/**
	 * Elemento que sirve como el target para arrastrar los slides,
	 * sino se implementa se mueve en toda la view.
	 *
	 * @type {*}
	 * @memberof SnViewSlideDirective
	 */
	@ContentChild('targetSlide') target: any;

	/**
	 * Regresa los datos del elemento con estado activo del carousel.
	 *
	 * @private
	 * @returns {ViewSlide}
	 * @memberof SnViewSlideDirective
	 */
	private getActiveSlide(): ViewSlide {
		return {
			id: this.id,
			activated: this.activated,
			index: this.index
		};
	}

	/**
	 * Implementa los estilos del slide
	 *
	 * @private
	 * @memberof SnViewSlideDirective
	 */
	private styleSetter() {
		const element = this.el.nativeElement;
		for (const key in this.styleHeader) {
			if (this.styleHeader.hasOwnProperty(key)) {
				this._renderer.setStyle(element, key, this.styleHeader[key]);
			}
		}
	}

	/**
	 * Activa el elemento y emite el evento con los datos del mismo.
	 *
	 * @memberof SnViewSlideDirective
	 */
	public activate(): void {
		this.activated = true;
		this.onActivate.emit(this.getActiveSlide());
	}

	/**
	 * Desactiva el elemento y emite el evento con los datos del mismo.
	 *
	 * @memberof SnViewSlideDirective
	 */
	public deactivate(): void {
		this.activated = false;
		this.onDeactivate.emit(this.getActiveSlide());
	}

	/**
	 * Establece los estilos.
	 *
	 * @memberof SnViewSlideDirective
	 */
	ngAfterContentInit(): void {
		this.styleSetter();
	}
}
