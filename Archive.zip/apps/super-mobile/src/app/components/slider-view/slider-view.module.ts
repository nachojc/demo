import { NgModule } from '@angular/core';
import { SnViewSlideDirective } from './view-slide.directive';
import { CommonModule } from '@angular/common';
import { SnSliderViewDirective } from './slider-view.directive';

@NgModule({
	imports: [CommonModule],
	declarations: [SnViewSlideDirective, SnSliderViewDirective],
	exports: [SnViewSlideDirective, SnSliderViewDirective]
})
export class SliderViewModule {}
