import { Subscription, timer } from 'rxjs';
import { TOKEN_STATUS, NavigationBackHelperService } from '@santander/flame-core-library';
import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { DialogClarificationsComponent } from './components/dialog-clarifications/dialog-clarifications.component';
import { DialogCloseLoginComponent } from './components/dialog-close-login/dialog-close-login.component';
import {
	DialogContentService,
	ContactDialogService,
	ThemeService
} from '@santander/flame-component-library';
import { TemplateModalOverlayRef } from 'libs/core/flame-component-library/src/lib/atoms/dialog-content/dialog.modal.ref';
import {
	AuthenticationService,
	CustomerService
} from '@santander/flame-core-library';
import { DialogErrorLogoutComponent } from './components/dialog-error-logout/dialog-error-logout.component';
import { ModalConfigInterface } from 'libs/core/flame-component-library/src/lib/atoms/dialog-content/interfaces';

/**
 * Menú más
 *
 * @export
 * @class MoreMainMenuViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-more-main-menu-view',
	templateUrl: './more-main-menu-view.component.html',
	styleUrls: ['./more-main-menu-view.component.scss']
})
export class MoreMainMenuViewComponent implements OnInit, OnDestroy {
	/**
	 * Crea una instancia de MoreMainMenuViewComponent.
	 * @param {DialogContentService} dialogService
	 * @param {Router} _router
	 * @param {AuthenticationService} _authenticationService
	 * @param {ThemeService} _snThemeService
	 * @param {CustomerService} _customerService
	 * @memberof MoreMainMenuViewComponent
	 */
	constructor(
		private dialogService: DialogContentService,
		private contactDialogService: ContactDialogService,
		private _router: NavigationBackHelperService,
		private _authenticationService: AuthenticationService,
		private _snThemeService: ThemeService,
		private _customerService: CustomerService
	) { }

	/**
	 * Suscripción para el llamado del servicio customer/settings
	 *
	 * @private
	 * @type {Subscription}
	 * @memberof MoreMainMenuViewComponent
	 */
	private subscription: Subscription = new Subscription();
	/**
	 * Info del cliente
	 *
	 * @type {*}
	 * @memberof MoreMainMenuViewComponent
	 */
	public customerInfo: any = {};
	/**
	 * Nombre completo del cliente
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	public fullName = '';
	/**
	 * Código del cliente
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	public personalId = '';
	/**
	 * Estatús del SuperToken del cliente
	 *
	 * @type {string}
	 * @memberof MoreMainMenuViewComponent
	 */
	public tokenStatus: string;
	/**
	 * Lista de códigos de estatus de SuperToken
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	public statusList = TOKEN_STATUS;

	/**
	 * Función para abrir el modal de contacto
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	public openPhoneDialog() {
		this.contactDialogService.openDialogContact();
	}

	/**
	 * Función para abrir el modal de aclaraciones
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	public openDialogClarifications(): void {
		const config: ModalConfigInterface = {
			closeLabel: 'Cerrar'
		};
		const ref: TemplateModalOverlayRef = this.dialogService.open(
			DialogClarificationsComponent,
			config
		);
	}

	/**
	 * Función para abrir el modal de Cerrar Login
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	public openDialogCloseLogin(): void {
		const config: ModalConfigInterface = {
			closeLabel: 'Cancelar',
			closeBackdropClick: false,
		};
		const ref: TemplateModalOverlayRef = this.dialogService.open(
			DialogCloseLoginComponent,
			config
		);
		ref.beforeClose().subscribe(result => {
			if (result) {
				this._router.navigate(['/access']);
			} else if (result === null) {
				const dialogErrorRef = this.dialogService.open(
					DialogErrorLogoutComponent,
					config
				);
			}
		});
	}

	/**
	 * navega hacia pago de servicios
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	navigatePayService() {
		this._router.navigate(['/payments/services'], {}, 'isMoreMenu')
	}

	/**
	 * Cambia el tema de la app
	 *
	 * @memberof MoreMainMenuViewComponent
	 */

	/**
	 * cambia de tema
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	public changeTheme() {
		let theme = localStorage.getItem('theme');
		if (theme) {
			theme = theme === 'flame-foundation' ? 'dark' : 'flame-foundation';
			this._snThemeService.setTheme(theme);
			localStorage.setItem('theme', theme);
		}
	}

	/**
	 * revisa el tema
	 *
	 * @returns
	 * @memberof MoreMainMenuViewComponent
	 */
	public checkedTheme() {
		const theme = localStorage.getItem('theme');
		if (theme && theme === 'dark') {
			return 'true';
		}
		return '';
	}

	/**
	 * Obtiene la info del cliente y el estado de su SuperToken
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	ngOnInit() {
		//TODO : se recupera la informacion del local storage
		const dataCustomer = JSON.parse(localStorage.getItem('customer'));
		if (localStorage.getItem('customer')) {
			if (dataCustomer.hasOwnProperty('buc')) {
				this.customerInfo = dataCustomer;
				this.fullName = `${dataCustomer.name} ${dataCustomer.last_name} ${dataCustomer.second_name}`;
				this.personalId = dataCustomer.buc;
			}
		}
		this.subscription = this._customerService.getMeSettings().subscribe(
			(response: any) => {
				this.tokenStatus = response.data.token.status;
			},
			error => {
				this.tokenStatus = 'NOT_AVAILABLE';
			}
		);
	}

	/**
	 * Desuscribe el llamado de customer/settings
	 *
	 * @memberof MoreMainMenuViewComponent
	 */
	ngOnDestroy() {
		this.subscription.unsubscribe();
	}

}
