import { Component } from '@angular/core';
// import { Router } from '@angular/router';
import {
	TemplateModalOverlayRef,
	LoaderOverlayService
} from '@santander/flame-component-library';
import { AuthenticationService, FlagOperationService } from '@santander/flame-core-library';

/**
 *
 *
 * @export
 * @class DialogCloseLoginComponent
 */
@Component({
	selector: 'sm-dialog-close-login',
	templateUrl: './dialog-close-login.component.html',
	styleUrls: ['./dialog-close-login.component.scss']
})
export class DialogCloseLoginComponent {
	/**
	 *Creates an instance of DialogCloseLoginComponent.
	 * @param {TemplateModalOverlayRef} parent
	 * @param {AuthenticationService} _authenticationService
	 * @param {LoaderOverlayService} _overlayLoader
	 * @param {FlagOperationService} _flagOperationService
	 * @memberof DialogCloseLoginComponent
	 */
	constructor(
		private parent: TemplateModalOverlayRef,
		private _authenticationService: AuthenticationService,
		private _overlayLoader: LoaderOverlayService,
		private _flagOperationService: FlagOperationService,
	) { }


	/**
	 * Confirma el cierre de sesión
	 *
	 * @memberof DialogCloseLoginComponent
	 */
	public close() {
		const overlay = this._overlayLoader.open();
		this._authenticationService.revokeSession().subscribe(
			() => {
				overlay.close();
				localStorage.removeItem('code_verifier');
				this._flagOperationService.resetFlags();
				this.parent.close(true);
			},
			() => {
				overlay.close();
				localStorage.removeItem('code_verifier');
				this._flagOperationService.resetFlags();
				this.parent.close(null);
			}
		);
	}
}
