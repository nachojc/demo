import { Component, OnInit } from '@angular/core';
import { TemplateModalOverlayRef } from '@santander/flame-component-library';
import { timer } from 'rxjs';
import { Router } from '@angular/router';
@Component({
  selector: 'sm-dialog-error-logout',
  templateUrl: './dialog-error-logout.component.html',
  styleUrls: ['./dialog-error-logout.component.scss']
})
export class DialogErrorLogoutComponent implements OnInit {

  /**
   *Creates an instance of DialogErrorLogoutComponent.
   * @param {TemplateModalOverlayRef} parent
   * @param {Router} _router
   * @memberof DialogErrorLogoutComponent
   */
  constructor(private parent: TemplateModalOverlayRef, private _router: Router) { }

  /**
   * cierra el modal de error y redirecciona a la pantalla de inicio
   *
   * @memberof DialogErrorLogoutComponent
   */
  ngOnInit() {
    timer(1500).subscribe(()=> {
      this.parent.close();
      this._router.navigate(['/access']);
    })
  }

}
