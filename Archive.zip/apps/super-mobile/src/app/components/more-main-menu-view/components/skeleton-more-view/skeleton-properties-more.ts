const THEME = {
	regularLineIcons: {
		height: '14px',
		'border-radius': '8px',
		'background-color': 'var(--sn-color__mercury, #e5e5e5)',
		'margin-bottom': '0px'
	}
};

export { THEME };
