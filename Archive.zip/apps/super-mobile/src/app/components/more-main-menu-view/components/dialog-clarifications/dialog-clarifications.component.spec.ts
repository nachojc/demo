import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { ErrorDialogComponent } from '../../../error-dialog/error-dialog.component';
import { IdpFakeViewComponent } from '../../../idp-fake-view/idp-fake-view.component';
import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import { BeneficiariesServicesViewComponent } from '../../../beneficiaries-services-view/beneficiaries-services-view.component';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	TagModule,
	DialogContentService,
	LoaderDialogService,
	TemplateModalOverlayRef,
	TokenInputModule
} from '@santander/flame-component-library';

import { CommonModule, DatePipe, APP_BASE_HREF } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { MoreMainMenuViewComponent } from '../../more-main-menu-view.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule, By } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import {
	FlameCoreLibraryModule,
	CryptoService,
	GlobileHttpClient,
	IdpService,
	DataTransferService,
	ENV_CONFIG,
	SERVICE_LOADER,
	AuthenticationService
} from '@santander/flame-core-library';

import { ReactiveFormsModule } from '@angular/forms';
import { environment } from 'apps/super-mobile/src/environments/environment';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { MyLifeViewComponent } from '../../../my-life/my-life-view/my-life-view.component';
import { MyLifeDeclarationComponents } from '../../../my-life/components/my-life-components';
import { DialogErrorMoreComponent } from '../.././components/dialog-error-more/dialog-error-more.component';
import { DialogClarificationsComponent } from '../.././components/dialog-clarifications/dialog-clarifications.component';
import { DialogCloseLoginComponent } from '../.././components/dialog-close-login/dialog-close-login.component';
import { TransactionDateFilterPipe } from '../../../my-life/pipes/transactions-date-filter.pipe';

import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
import { MyLifeServices } from '../../../my-life/services/my-life-services';
import { AppRoutingModule } from 'apps/super-mobile/src/app/app.routing.module';
import { AccesViewComponent } from '../../../access-view/access-view.component';
import { AppComponent } from 'apps/super-mobile/src/app/app.component';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { SkeletonViewMoreComponent } from '../skeleton-more-view/skeleton-view-more.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ListButtonMoreComponent } from '../list-button-more/list-button-more.component';
describe('DialogCloseLoginComponent', () => {
	let fixture: ComponentFixture<DialogClarificationsComponent>;
	let component: DialogClarificationsComponent;
	let dialogService: DialogClarificationsComponent;
	const templateModalOverlayRefSpy = jasmine.createSpyObj(
		'TemplateModalOverlayRef',
		['close', 'afterClosed', 'beforeClosed']
	);

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AppRoutingModule,
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				HttpClientModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				RouterModule,
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				FlameCoreLibraryModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
				TabModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				MyFinancesOperationLibraryModule,
				BeneficiaryOperationLibraryModule,
				PaymentsOperationLibraryModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				TokenInputModule,
				NgxPermissionsModule.forRoot()
			],
			declarations: [
				AccesViewComponent,
				AppComponent,
				MoreMainMenuViewComponent,
				BeneficiariesServicesViewComponent,
				IdpFakeViewComponent,
				ErrorDialogComponent,
				DialogClarificationsComponent,
				DialogErrorMoreComponent,
				DialogCloseLoginComponent,
				MyLifeViewComponent,
				MyLifeDeclarationComponents,
				TransactionDateFilterPipe,
				SkeletonViewMoreComponent,
				ListButtonMoreComponent
			],
			providers: [
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				DataTransferService,
				DatePipe,
				DialogContentService,
				ContactDialogService,
				LoaderDialogService,
				MyLifeServices,
				WINDOW_PROVIDERS,
				TransactionDateFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: environment
				},
				{
					provide: SERVICE_LOADER,
					useExisting: LoaderDialogService
				},
				{
					provide: TemplateModalOverlayRef,
					useValue: templateModalOverlayRefSpy
				}
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogClarificationsComponent);
		component = fixture.componentInstance;
		dialogService = TestBed.get(DialogContentService);
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('Should access function Close', () => {
		fixture.componentInstance.close();
		fixture.detectChanges();
	});
});
