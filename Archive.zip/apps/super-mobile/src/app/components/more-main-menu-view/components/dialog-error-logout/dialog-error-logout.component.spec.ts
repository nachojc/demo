import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogErrorLogoutComponent } from './dialog-error-logout.component';
import { AppRoutingModule } from 'apps/super-mobile/src/app/app.routing.module';
import {
	AvatarModule,
	ButtonModule,
	CardModule,
	CarouselModule,
	ChipModule,
	ContactDialogModule,
	FormFieldModule,
	IconModule,
	InputModule,
	NavbarModule,
	ProductModule,
	SearchBarModule,
	SlideToggleModule,
	IconButtonModule,
	SpinnerModule,
	TagModule,
	DialogModule,
	DialogContentModule,
	TabsModule,
	TabModule,
	ThemeModule,
	FlameFoundationTheme,
	TopBarModule,
	EmojiModule,
	TokenDialogModule,
	LoaderOverlayModule,
	TokenInputModule,
	DialogContentService,
	ContactDialogService,
	LoaderDialogService,
	TemplateModalOverlayRef,
	DarkTheme,
	LoaderOverlayService
} from '@santander/flame-component-library';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import {
	FlameCoreLibraryModule,
	AuthenticationService,
	CryptoService,
	GlobileHttpClient,
	IdpService,
	DataTransferService,
	ENV_CONFIG,
	SERVICE_LOADER,
	SuperTokenService,
	BackButtonService,
	CustomerService,
	CardReaderService
} from '@santander/flame-core-library';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { NgxPermissionsModule } from 'ngx-permissions';
import { AccesViewComponent } from '../../../access-view/access-view.component';
import { AppComponent } from 'apps/super-mobile/src/app/app.component';
import { MoreMainMenuViewComponent } from '../../more-main-menu-view.component';
import { IdpFakeViewComponent } from '../../../idp-fake-view/idp-fake-view.component';
import { DialogClarificationsComponent } from '../dialog-clarifications/dialog-clarifications.component';
import { DialogErrorMoreComponent } from '../dialog-error-more/dialog-error-more.component';
import { DialogCloseLoginComponent } from '../dialog-close-login/dialog-close-login.component';
import { MyLifeViewComponent } from '../../../my-life/my-life-view/my-life-view.component';
import { MyLifeDeclarationComponents } from '../../../my-life/components/my-life-components';
import { TransactionDateFilterPipe } from '../../../my-life/pipes/transactions-date-filter.pipe';
import { SkeletonViewMoreComponent } from '../skeleton-more-view/skeleton-view-more.component';
import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { MyLifeServices } from '../../../my-life/services/my-life-services';
import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
import { environment } from 'apps/super-mobile/src/environments/environment';
import { SuperTokenDialogAbstractionComponent } from '../../../supertoken-dialog/dialog-abstraction/dialog-abstraction.component';
import { SuperTokenServiceErrorComponent } from '../../../supertoken-dialog/service-error/service-error.component';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import { SuperTokenDialogService } from '../../../supertoken-dialog/supertoken-dialog.service';
import { ConfirmSuperTokenService } from '../../../supertoken-dialog/dialog-abstraction/confirm-supertoken.service';
import { ErrorDialogComponent } from '../../../error-dialog/error-dialog.component';
import { BeneficiariesServicesViewComponent } from '../../../beneficiaries-services-view/beneficiaries-services-view.component';
import { ListButtonMoreComponent } from '../list-button-more/list-button-more.component';

describe('DialogErrorLogoutComponent', () => {
	let component: DialogErrorLogoutComponent;
	let fixture: ComponentFixture<DialogErrorLogoutComponent>;
	const templateModalOverlayRefSpy = jasmine.createSpyObj(
		'TemplateModalOverlayRef',
		['close', 'afterClosed', 'beforeClosed']
	);

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AppRoutingModule,
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				HttpClientModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				RouterModule,
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				FlameCoreLibraryModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
				TabModule,
				ThemeModule.forRoot({
					themes: [DarkTheme, FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				MyFinancesOperationLibraryModule,
				BeneficiaryOperationLibraryModule,
				PaymentsOperationLibraryModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				TokenInputModule,
				NgxPermissionsModule.forRoot()
			],
			declarations: [
				AccesViewComponent,
				AppComponent,
				MoreMainMenuViewComponent,
				BeneficiariesServicesViewComponent,
				IdpFakeViewComponent,
				ErrorDialogComponent,
				DialogClarificationsComponent,
				DialogErrorMoreComponent,
				DialogCloseLoginComponent,
				DialogErrorLogoutComponent,
				SkeletonViewMoreComponent,
				MyLifeViewComponent,
				MyLifeDeclarationComponents,
				SuperTokenDialogAbstractionComponent,
				TransactionDateFilterPipe,
				SuperTokenServiceErrorComponent,
				ListButtonMoreComponent
			],
			providers: [
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				DataTransferService,
				DatePipe,
				DialogContentService,
				ContactDialogService,
				LoaderDialogService,
				MyLifeServices,
				WINDOW_PROVIDERS,
				TransactionDateFilterPipe,
				SuperTokenDialogService,
				ConfirmSuperTokenService,
				SuperTokenService,
				BackButtonService,
				CustomerService,
				LoaderOverlayService,
				CardReaderService,
				{
					provide: ENV_CONFIG,
					useValue: environment
				},
				{
					provide: SERVICE_LOADER,
					useExisting: LoaderDialogService
				},
				{
					provide: TemplateModalOverlayRef,
					useValue: templateModalOverlayRefSpy
				}
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogErrorLogoutComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should  access Close', () => {
		fixture.componentInstance.close();
		fixture.detectChanges();
	});
});
