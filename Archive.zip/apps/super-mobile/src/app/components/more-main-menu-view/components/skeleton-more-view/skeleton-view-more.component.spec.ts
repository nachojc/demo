// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { ButtonModule } from '@santander/flame-component-library';
// import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
// import { SkeletonViewMoreComponent } from './skeleton-view-more.component';

// describe('SkeletonViewComponent', () => {
// 	let component: SkeletonViewMoreComponent;
// 	let fixture: ComponentFixture<SkeletonViewMoreComponent>;

// 	beforeEach(async(() => {
// 		TestBed.configureTestingModule({
// 			imports: [ButtonModule, NgxSkeletonLoaderModule],
// 			declarations: [SkeletonViewMoreComponent]
// 		}).compileComponents();
// 	}));

// 	beforeEach(() => {
// 		fixture = TestBed.createComponent(SkeletonViewMoreComponent);
// 		component = fixture.componentInstance;
// 		fixture.detectChanges();
// 	});

// 	it('should create', () => {
// 		expect(component).toBeTruthy();
// 	});
// });
