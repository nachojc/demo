import { Component } from '@angular/core';
import { TemplateModalOverlayRef } from '@santander/flame-component-library';

/**
 *
 * modal de error
 * @export
 * @class DialogErrorMoreComponent
 */
@Component({
  selector: 'sm-dialog-error-more',
  templateUrl: './dialog-error-more.component.html',
  styleUrls: ['./dialog-error-more.component.scss']
})
export class DialogErrorMoreComponent {
  constructor(private parent: TemplateModalOverlayRef) {}

  /**
   * cierra el modal de error
   *
   * @memberof DialogErrorMoreComponent
   */
  close() {
    this.parent.close();
  }

}
