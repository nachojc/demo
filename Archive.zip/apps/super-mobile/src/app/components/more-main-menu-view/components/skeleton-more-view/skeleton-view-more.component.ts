import { Component, Input } from '@angular/core';
import { THEME } from './skeleton-properties-more';

@Component({
	selector: 'sm-skeleton-view-more',
	templateUrl: './skeleton-view-more.component.html',
	styleUrls: ['./skeleton-view-more.component.scss']
})
export class SkeletonViewMoreComponent {
	/**
	 * variable para el tema(estilo)
	 *
	 * @memberof SkeletonViewMoreComponent
	 */
	public theme = THEME;
	/**
	 * type of the skeleton
	 * @type {string}
	 * @memberof SkeletonViewMoreComponent
	 */
	@Input() typeSkeleton: number;

}
