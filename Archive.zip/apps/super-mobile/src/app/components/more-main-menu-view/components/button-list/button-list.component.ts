import {
  Component,
  OnInit,
  Input } from '@angular/core';

/**
 *
 *
 * @export
 * @class ButtonListComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-button-list',
	templateUrl: './button-list.component.html',
	styleUrls: ['./button-list.component.scss']
})
export class ButtonListComponent {

  /**
	 * Indica qué ícono se mostrará en el lado izquierdo
	 *
	 * @memberof ButtonListComponent
	 */
  @Input() icon: string;

  /**
	 * Indica el texto (label) del botón
	 *
	 * @memberof ButtonListComponent
	 */
  @Input() text: string;

  /**
	 * Indica si se muestra una flecha del lado derecho
	 *
	 * @memberof ButtonListComponent
	 */
  @Input() arrow: boolean;

  /**
	 * Deshabilita las acciones del botón
	 *
	 * @memberof ButtonListComponent
	 */
  @Input() disabled: boolean;

}
