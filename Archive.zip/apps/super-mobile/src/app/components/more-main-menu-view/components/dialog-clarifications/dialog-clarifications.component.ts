
import { Component } from '@angular/core';
import { TemplateModalOverlayRef } from '@santander/flame-component-library';

/**
 *
 *
 * @export
 * @class DialogClarificationsComponent
 */
@Component({
  selector: 'sm-dialog-clarifications',
  templateUrl: './dialog-clarifications.component.html',
  styleUrls: ['./dialog-clarifications.component.scss']
})
export class DialogClarificationsComponent {

  /**
   * Creates an instance of DialogClarificationsComponent
   * @param {TemplateModalOverlayRef} parent
   * @memberof DialogClarificationsComponent
   */
  constructor(private parent: TemplateModalOverlayRef) {}

  /**
   * cierra el dialogo
   *
   * @memberof DialogClarificationsComponent
   */
  close() {
    this.parent.close();
  }
}
