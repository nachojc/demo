import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import {
	HttpTestingController,
	HttpClientTestingModule
} from '@angular/common/http/testing';
import {
	async,
	ComponentFixture,
	TestBed,
	inject,
	getTestBed
} from '@angular/core/testing';
import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	TagModule,
	DialogContentService,
	LoaderOverlayService
} from '@santander/flame-component-library';

import { CommonModule, DatePipe } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { MoreMainMenuViewComponent } from './more-main-menu-view.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserModule, By } from '@angular/platform-browser';
import {
	ENV_CONFIG,
	AuthenticationService,
	CustomerService
} from '@santander/flame-core-library';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { DialogErrorMoreComponent } from './components/dialog-error-more/dialog-error-more.component';
import { DialogClarificationsComponent } from './components/dialog-clarifications/dialog-clarifications.component';
import { DialogCloseLoginComponent } from './components/dialog-close-login/dialog-close-login.component';
import { of } from 'rxjs';
import { SkeletonViewMoreComponent } from './components/skeleton-more-view/skeleton-view-more.component';
import { NgModule } from '@angular/core';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ListButtonMoreComponent } from './components/list-button-more/list-button-more.component';

const customerInfo = {
	key: '4e20fbb243684d9eb19ff33a50ee422e',
	buc: '123456789',
	name: 'Ana Maria',
	second_name: 'Hernandez',
	last_name: 'Gutierrez',
	status: 'ACTIVE',
	personal_identifier: 'MARE921122HJKDLN01',
	bank_segment: {
		key: '070',
		name: 'SELECT'
	},
	contact_method: 'EMAIL',
	contact_info: [
		{
			type: 'BRANCH_USE',
			phone_number: '(55)-55-46-89-79',
			mobile_number: '(044)-55-46-89-79-12',
			email: 'mail@mail.com',
			status: 'REGISTERED'
		}
	]
};

describe('MoreMainMenuViewComponent', () => {
	let fixture: ComponentFixture<MoreMainMenuViewComponent>;
	let component: MoreMainMenuViewComponent;
	let httpMock: HttpTestingController;
	let service: CustomerService;
	let injector: TestBed;
	const url = 'http://localhost:3000/api/customers/me/settings';
	const urlLogout = 'http://localhost:3000/api/v1/authentication/signoff';
	const dataService = {
		data: {
			token: {
				status: 'ACTIVE',
				timestamp: '2019-04-26T00:00:00'
			}
		},
		notifications: [
			{
				code: 'E422CDNPAYRCPTG001',
				description: 'Something is happening',
				timestamp: '2019-02-16T23:38:45.408Z'
			}
		]
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				HttpClientTestingModule,
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
				TabModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				NgxPermissionsModule.forRoot(),
				RouterModule.forRoot([])
			],
			declarations: [
				MoreMainMenuViewComponent,
				DialogErrorMoreComponent,
				DialogClarificationsComponent,
				SkeletonViewMoreComponent,
				DialogCloseLoginComponent,
				ListButtonMoreComponent
			],
			providers: [
				DatePipe,
				CustomerService,
				LoaderOverlayService,
				ContactDialogService,
				AuthenticationService,
				{
					provide: ENV_CONFIG,
					useValue: {
						sm: {
							clientId: '0KxtKPNZzUIMueEfxeP6x_NKWPJLRREWHEHsyOw1a4w'
						},
						api: {
							url: 'http://localhost:3000/api',
							version: {
								customers: '',
								authentication: 'v1'
							}
						}
					}
				}
			]
		}).compileComponents();
		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [
					DialogErrorMoreComponent,
					DialogClarificationsComponent,
					DialogCloseLoginComponent
				]
			}
		});
		injector = getTestBed();
		service = injector.get(CustomerService);
		httpMock = injector.get(HttpTestingController);
		localStorage.setItem('oauthToken', '{"access_token":"123"}');
	}));

	afterEach(() => {
		httpMock.verify();
	});

	describe('Service data token', () => {
		beforeEach(() => {
			localStorage.setItem('customer', JSON.stringify(customerInfo));
			fixture = TestBed.createComponent(MoreMainMenuViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			const request = httpMock.expectOne(url);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(dataService);
			fixture.detectChanges();
		});

		it('should create', () => {
			expect(component).toBeTruthy();
		});

		it('Should get info in localStorage of Customer', () => {
			const nameInfo = `${customerInfo.name} ${customerInfo.last_name} ${
				customerInfo.second_name
			} `;
			const perId = `${customerInfo.personal_identifier}`;
			component.fullName = nameInfo;
			component.personalId = perId;
			fixture.detectChanges();
		});

		it('Should open contact phone dialog', inject(
			[ContactDialogService],
			(contactDialog: ContactDialogService) => {
				const btnContact = fixture.debugElement.query(By.css('div .phone'));
				spyOn(contactDialog, 'openDialogContact');
				btnContact.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(contactDialog.openDialogContact).toHaveBeenCalled();
				});
				fixture.detectChanges();
			}
		));
	});

	// describe('Service data token failed', () => {
	// 	beforeEach(() => {
	// 		const mockErrorResponse = {
	// 			status: 400,
	// 			statusText: 'Bad Request'
	// 		};

	// 		localStorage.setItem('customer', JSON.stringify(customerInfo));
	// 		fixture = TestBed.createComponent(MoreMainMenuViewComponent);
	// 		component = fixture.componentInstance;
	// 		fixture.detectChanges();

	// 		const request = httpMock.expectOne(url);
	// 		expect(request.request.method).toEqual('GET');
	// 		expect(request.request.responseType).toEqual('json');
	// 		request.flush(dataService, mockErrorResponse);
	// 		fixture.detectChanges();
	// 	});

	// 	it('should create', () => {
	// 		expect(component.tokenStatus).toBe('NOT_AVAILABLE');
	// 		expect(component).toBeTruthy();
	// 	});
	// });
});
