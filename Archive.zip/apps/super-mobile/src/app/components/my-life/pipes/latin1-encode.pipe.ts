import { Pipe, PipeTransform } from '@angular/core';
import { Platform } from '@angular/cdk/platform';

@Pipe({name: 'latin1encode'})
export class LatinEncodePipe implements PipeTransform {
  transform(value: any): any {
    const platform = new Platform();
    if (platform.IOS) {
      return decodeURIComponent(escape(value));
    }else{
      return value;
    }
  }
}
