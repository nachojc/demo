import { Pipe, PipeTransform } from '@angular/core';

/**
 * Pipe para ordenar un arreglo de movimientos mediante su fecha.
 *
 * @export
 * @class TransactionDateFilterPipe
 * @implements {PipeTransform}
 */
@Pipe({
	name: 'transactionFilter',
	pure: false
})
export class TransactionDateFilterPipe implements PipeTransform {
	/**
	 * Ordena las fechas de mayor a menor
	 *
	 * @private
	 * @param {*} dateOne
	 * @param {*} dateTwo
	 * @returns {number}
	 * @memberof TransactionDateFilterPipe
	 */
	private orderBy(dateOne: any, dateTwo: any): number {
		if (dateOne > dateTwo) {
			return -1;
		} else if (dateOne < dateTwo) {
			return 1;
		} else {
			return 0;
		}
	}

	/**
	 * Transforma un arreglo de movimientos y los ordena por fecha de mayor a menor
	 *
	 * @param {*} transactions
	 * @returns {*}
	 * @memberof TransactionDateFilterPipe
	 */
	transform(transactions: any): any {
		if (!transactions) return [];
		transactions.sort((a: any, b: any) => {
			// Los movimientos de TDC pueden tener posted_date o creation_date pero no ambos
			if (a.hasOwnProperty('posted_date') || b.hasOwnProperty('posted_date')) {
				// Se hacen multiples validaciones para los casos en que se compara la fecha por posted_date
				if (a.posted_date && b.posted_date) {
					return this.orderBy(a.posted_date, b.posted_date);
				} else if (a.posted_date) {
					return this.orderBy(a.posted_date, b.creation_date);
				} else if (b.posted_date) {
					return this.orderBy(a.creation_date, b.posted_date);
				} else {
					return this.orderBy(a.creation_date, b.creation_date);
				}
			} else {
				return this.orderBy(a.creation_date, b.creation_date);
			}
		});
		return transactions;
	}
}
