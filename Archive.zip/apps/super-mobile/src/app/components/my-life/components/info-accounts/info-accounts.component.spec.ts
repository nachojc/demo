import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { AppComponent } from './../../../../app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from 'apps/super-mobile/src/environments/environment.pre';
import { ErrorDialogComponent } from './../../../error-dialog/error-dialog.component';
import { IdpFakeViewComponent } from './../../../idp-fake-view/idp-fake-view.component';
import { MoreMainMenuViewComponent } from './../../../more-main-menu-view/more-main-menu-view.component';
import { AccesViewComponent } from './../../../access-view/access-view.component';
import { AppRoutingModule } from './../../../../app.routing.module';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	TagModule,
	DialogContentService,
	LoaderDialogService,
	TokenInputModule
} from '@santander/flame-component-library';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import {
	HttpClientModule,
	HTTP_INTERCEPTORS,
	HttpXhrBackend,
	XhrFactory
} from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import {
	FlameCoreLibraryModule,
	AuthenticationService,
	CryptoService,
	GlobileHttpClient,
	IdpService,
	DataTransferService,
	ENV_CONFIG,
	ApiInterceptor,
	SERVICE_LOADER
} from '@santander/flame-core-library';
import { BrowserModule, By } from '@angular/platform-browser';
import { CommonModule, APP_BASE_HREF, DatePipe } from '@angular/common';
import { globileHttpXhrBackendFactory } from '../../../../app.module';
import { InfoAccountsComponent } from './info-accounts.component';
import { MyLifeServices } from '../../services/my-life-services';
import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
import { LOCALE_ID, inject } from '@angular/core';
import { MyLifeViewComponent } from '../../my-life-view/my-life-view.component';
import { BeneficiariesServicesViewComponent } from '../../../beneficiaries-services-view/beneficiaries-services-view.component';
import { MyLifeDeclarationComponents } from '../my-life-components';
import { of } from 'rxjs';
import { AccountLyfeService } from '../../services/accounts-lyfe.service';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { DialogClarificationsComponent } from '../../../more-main-menu-view/components/dialog-clarifications/dialog-clarifications.component';
import { DialogErrorMoreComponent } from '../../../more-main-menu-view/components/dialog-error-more/dialog-error-more.component';
import { DialogCloseLoginComponent } from '../../../more-main-menu-view/components/dialog-close-login/dialog-close-login.component';
import { TransactionDateFilterPipe } from '../../pipes/transactions-date-filter.pipe';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { SkeletonViewMoreComponent } from '../../../more-main-menu-view/components/skeleton-more-view/skeleton-view-more.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ListButtonMoreComponent } from '../../../more-main-menu-view/components/list-button-more/list-button-more.component';

const summaryChekingAccount = {
	data: [
		{
			key: '056722751246',
			display_number: '00*384',
			alias: 'MI SUPER NOMINA',
			url: '/accounts/{key}',
			image_url: '2517',
			balance: {
				amount: 98918.5,
				currency_code: 'MXN'
			}
		},
		{
			key: '056722733565',
			display_number: '0*484',
			alias: 'MI CUENTA PRINCIPAL',
			url: '/accounts/{key}',
			image_url: '2523',
			balance: {
				amount: 12122.5,
				currency_code: 'MXN'
			}
		}
	],
	paging: {
		next_cursor_key: '10'
	}
};

const summaryCredits = {
	data: [
		{
			key: '4e20fbb243684d9eb19ff33a50ee422e',
			name: 'Aeromexico Blanca',
			alias: 'Tarjeta de Crédito Aeromexico',
			status: 'ACTIVE',
			due_date: '2019-02-16T23:38:45.408Z',
			url: '/credits/{credit-key}',
			balance: {
				amount: 3000,
				currency_code: 'MXN'
			},
			available_credit: {
				amount: 5000,
				currency_code: 'MXN'
			},
			minimum_payment: {
				amount: 300,
				currency_code: 'MXN'
			},
			statement_balance: {
				amount: 600,
				currency_code: 'MXN'
			},
			related_cards: [
				{
					display_number: '************1234',
					relation_type: 'MAIN',
					expiration_date: '12/19',
					url: '/cards/{card-key}',
					image_url: '74110101010'
				}
			]
		},
		{
			key: '4e20fbb243684d9eb19ff33a50ee422e',
			name: 'Aeromexico roja',
			alias: 'Tarjeta de Crédito Santander',
			status: 'ACTIVE',
			due_date: '2019-02-16T23:38:45.408Z',
			url: '/credits/{credit-key}',
			balance: {
				amount: 5000,
				currency_code: 'MXN'
			},
			available_credit: {
				amount: 10000,
				currency_code: 'MXN'
			},
			minimum_payment: {
				amount: 5000,
				currency_code: 'MXN'
			},
			statement_balance: {
				amount: 50000,
				currency_code: 'MXN'
			},
			related_cards: [
				{
					display_number: '*8767',
					relation_type: 'MAIN',
					expiration_date: '12/19',
					url: '/cards/{card-key}',
					image_url: '2517'
				}
			]
		}
	],
	notifications: [
		{
			code: 'E422CDNPAYRCPTG001',
			message: 'Something happened.',
			timestamp: '2019-08-05T14:31:20.779Z'
		}
	],
	paging: {
		next_cursor_key: '10'
	}
};

const customerInfo = {
	data: {
		key: '4e20fbb243684d9eb19ff33a50ee422e',
		buc: '123456789',
		name: 'Ana Maria',
		second_name: 'Hernandez',
		last_name: 'Gutierrez',
		status: 'ACTIVE',
		bank_segment: 'PERSONAL_BANKING',
		personal_identifier: 'MARE921122HJKDLN01',
		contact_info: [
			{
				type: 'BRANCH_USE',
				phone_number: '(55)-55-46-89-79',
				mobile_number: '(044)-55-46-89-79-12',
				email: 'mail@mail.com',
				status: 'REGISTERED'
			}
		]
	},
	notifications: [
		{
			code: 'E422CDNPAYRCPTG001',
			description: 'Something is happening',
			timestamp: '2019-02-16T23:38:45.408Z'
		}
	]
};

const cardInfo = {
	data: [
		{
			key: '4e20fbb243684d9eb19ff33a50ee422e',
			name: 'Aeromexico Azul',
			display_number: '1*12312',
			holder_name: 'Raul J. Hernandez C.',
			relation_type: 'MAIN, ADDITIONAL',
			expiration_date: '11/19',
			type: 'DEBIT_CARD',
			status: 'ACTIVE',
			url: '/cards/{card-key}',
			image_url: '2517'
		}
	]
};

describe('InfoAccountsComponent', () => {
	let component: InfoAccountsComponent;
	let fixture: ComponentFixture<InfoAccountsComponent>;
	let infoAccountService: AccountLyfeService;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AppRoutingModule,
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				HttpClientModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				RouterModule,
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				FlameCoreLibraryModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
				TabModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				MyFinancesOperationLibraryModule,
				BeneficiaryOperationLibraryModule,
				PaymentsOperationLibraryModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				TokenInputModule,
				NgxPermissionsModule.forRoot()
			],
			declarations: [
				AccesViewComponent,
				AppComponent,
				MoreMainMenuViewComponent,
				BeneficiariesServicesViewComponent,
				IdpFakeViewComponent,
				ErrorDialogComponent,
				DialogClarificationsComponent,
				DialogErrorMoreComponent,
				DialogCloseLoginComponent,
				MyLifeViewComponent,
				MyLifeDeclarationComponents,
				TransactionDateFilterPipe,
				SkeletonViewMoreComponent,
				ListButtonMoreComponent
			],
			providers: [
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				DataTransferService,
				DatePipe,
				DialogContentService,
				ContactDialogService,
				LoaderDialogService,
				MyLifeServices,
				WINDOW_PROVIDERS,
				TransactionDateFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: environment
				},
				{
					provide: SERVICE_LOADER,
					useExisting: LoaderDialogService
				},
				// {
				// 	provide: HTTP_INTERCEPTORS,
				// 	useClass: OauthInterceptor,
				// 	multi: true
				// },
				{
					provide: HttpXhrBackend,
					useFactory: globileHttpXhrBackendFactory,
					deps: [XhrFactory]
				},
				{ provide: LOCALE_ID, useValue: 'es-MX' },
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				{
					provide: HttpXhrBackend,
					useFactory: globileHttpXhrBackendFactory,
					deps: [XhrFactory]
				},
				{
					provide: APP_BASE_HREF,
					useValue: '/'
				}
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(InfoAccountsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should get info services', () => {
		infoAccountService = TestBed.get(AccountLyfeService);
		spyOn(infoAccountService, 'getStatusCard').and.returnValue(of(cardInfo));
		spyOn(infoAccountService, 'getAccountsCards').and.returnValue(
			of(summaryChekingAccount)
		);
		spyOn(infoAccountService, 'getCreditsCard').and.returnValue(
			of(summaryCredits)
		);
		fixture.detectChanges();
		component.ngOnInit();
		expect(infoAccountService.getStatusCard).toHaveBeenCalled();
		expect(infoAccountService.getAccountsCards).toHaveBeenCalled();
		expect(infoAccountService.getCreditsCard).toHaveBeenCalled();
	});
});
