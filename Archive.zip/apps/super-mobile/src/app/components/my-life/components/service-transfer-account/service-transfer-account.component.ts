import { SuperTokenErrorService } from './../../../supertoken-dialog/supertoken-dialog.interface';
import { state } from '@angular/animations';
import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { PaymentsCardsAndServicesService } from '../../services/payments-cards-services.service';
import { NavigationBackHelperService } from '@santander/flame-core-library';
import { PaymentsDataTransferService } from 'libs/mobile/payments-operation-library/src/lib/services/payments-data-transfer.service';
import {
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { ActivateServiceComponent } from 'libs/mobile/payments-operation-library/src/lib/views/payment-services-view/activate-service/activate-service.component';
import { DialogPaymentsServiceComponent } from 'libs/mobile/payments-operation-library/src/lib/views/payment-services-view/dialog-payments-service/dialog-payments-service.component';
import { PaymentsService } from 'libs/mobile/payments-operation-library/src/lib/services/payments.service';
import { SuperTokenDialogService } from '../../../supertoken-dialog/supertoken-dialog.service';
import { takeUntil, shareReplay, publishReplay, refCount } from 'rxjs/operators';
import { Subject, timer } from 'rxjs';
import { NgxPermissionsService } from 'ngx-permissions';
import { AccountLyfeService } from '../../services/accounts-lyfe.service';
import { DatePipe } from '@angular/common';

declare var require: any;
let FREQUENT_SERVICES = require('./frequent-services.json');
const BACKGROUND_SERVICES = require('./background-services.json');

@Component({
	selector: 'sm-service-transfer-account',
	templateUrl: './service-transfer-account.component.html',
	styleUrls: ['./service-transfer-account.component.scss']
})
export class ServiceTransferAccountComponent implements OnInit, OnDestroy {
	/**
	 *Creates an instance of ServiceTransferAccountComponent.
	 * @param {DialogService} _dialog
	 * @param {PaymentsCardsAndServicesService} _paymentsCardsAndServicesService
	 * @param {NavigationBackHelperService} _router
	 * @param {PaymentsDataTransferService} _paymentsDataTransferService
	 * @param {PaymentsService} _billerService
	 * @param {SuperTokenDialogService} _superTokenDialogService
	 * @param {NgxPermissionsService} _permissionsService
	 * @param {AccountLyfeService} _accountLyfeService
	 * @param {DatePipe} _datePipe
	 * @memberof ServiceTransferAccountComponent
	 */
	constructor(
		private _dialog: DialogService,
		private _paymentsCardsAndServicesService: PaymentsCardsAndServicesService,
		private _router: NavigationBackHelperService,
		private _paymentsDataTransferService: PaymentsDataTransferService,
		private _billerService: PaymentsService,
		private _superTokenDialogService: SuperTokenDialogService,
		private _permissionsService: NgxPermissionsService,
		private _accountLyfeService: AccountLyfeService,
		private _datePipe: DatePipe
	) { }
	/**
	 * variables
	 *
	 * @memberof ServiceTransferAccountComponent
	 */
	private dialogRef: DialogReference;
	private minutesPendingService = 30;
	private viewHasServices = false;
	private _destroy$ = new Subject();
	private payees: any;

	public showSkeleton = true;
	public showSkeletonPayee = true;
	public isEmptyContact = false;
	public dataPayeeFrecuents = [];
	public payeesAndServices = [];
	public accounts = [];
	private availablePayees = 0;

	/**
	 * Permite activar un servicio
	 *
	 * @private
	 * @param {*} data
	 * @param {string} otp
	 * @memberof ServiceTransferAccountComponent
	 */
	private activateBiller(data: any, otp: string) {
		this._billerService.activateBiller(data.key, otp).subscribe(
			(res2: any) => {
				this._router.navigate(['/biller/voucher']);
			},
			(error: any) => {
				// error
			}
		);
	}

	/**
	 * Muestra un mensaje de error de OTP al ocurrir
	 *
	 * @private
	 * @memberof ServiceTransferAccountComponent
	 */
	private getSuperTokenError(): void {
		this._superTokenDialogService
			.getErrorService()
			.then((error: SuperTokenErrorService) => {
				if (error.title) {
					this._superTokenDialogService.getSuperToken();
				}
			});
	}

	/**
	 * Da formato al arreglo de servicios y tarjetas
	 *
	 * @private
	 * @memberof ServiceTransferAccountComponent
	 */
	private formatDataServices() {
		const result = [];
		this.payeesAndServices.forEach(element => {
			if (element.agreement) {
				const fullname = element.name.split('|')[0];
				let shortName = fullname.toLocaleUpperCase();

				if (shortName.length > 12) {
					const longName = shortName.split(" ");
					if (longName.length === 1) {
						shortName = shortName.substr(0, 2);
					} else {
						let name = "";
						longName.forEach((billName) => {
							if ((billName !== 'DE') && (billName !== 'EL') && (billName !== 'LA'))
								name = name + billName.substr(0, 1);
						});
						shortName = name;
					}
				}
				element.name = shortName;
				element.label = fullname.length > 20 ? fullname.substr(0, 20) : fullname;
			}
			result.push({
				agreement: element.agreement,
				key: element.key,
				name: element.name,
				alias: element.alias,
				bank: element.bank,
				display_number: element.display_number,
				status: element.status,
				image_url: element.image_url,
				color: element.color,
				type: element.type,
				label: element.agreement ? element.label : element.alias
			});
		});
		// if (this.viewHasServices) {
		// 	for (let i = 0, pos = 0; i < this.availablePayees; i++, pos += 2) {
		// 		const element = result.splice(3 + i, 1)[0];
		// 		result.splice(pos, 0, element);
		// 	}
		// }
		this.payeesAndServices = result;
	}

	/**
	 * Ordena ascendentemente en base a la propiedad
	 *
	 * @private
	 * @param {*} json_obj
	 * @param {*} prop
	 * @returns
	 * @memberof ServiceTransferAccountComponent
	 */
	private ordenarAsc(json_obj, prop) {
		json_obj.sort((a, b) => a[prop] > b[prop] ? 1 : a[prop] === b[prop] ? 0 : -1);
		return json_obj;
	}

	/**
	 * Método que obtiene las respuesta del servicio getPayeesfrequent
	 *
	 * @returns void
	 * @memberof ServiceTransferAccountComponent
	 */
	private getPaymentsCardsAndServices() {
		let isDataAccount = true;
		const permissions = this._permissionsService.getPermissions();
		if (permissions.hasOwnProperty('R4')) {
			if (!this._paymentsCardsAndServicesService.payeeFrequents$) {
				this._paymentsCardsAndServicesService.payeeFrequents$ = this._paymentsCardsAndServicesService
					.getPayeesfrequent()
					.pipe(publishReplay(1),
						refCount());
			}

			this._paymentsCardsAndServicesService.payeeFrequents$.subscribe(
				(response: any) => {
					this.dataPayeeFrecuents = response.data.length <= 6 ? response.data : response.data.slice(0, 7);
					this.showSkeletonPayee = false;
				},
				error => {
					this.showSkeletonPayee = false;
				}
			);
			this._accountLyfeService.account$.subscribe(
				(response: any) => {
					this.accounts = this.accounts.concat(response.data);
					this.accounts = this.accounts.filter(item => {
						if (item.balance.currency_code === 'MXN') {
							return item;
						}
					})
					this.accounts.forEach((item: any) => {
						item.product = {
							description: item.alias ? item.alias : item.name
						};
						item.number = item.display_number;
					});
					isDataAccount = false;
				});
			timer(1000).subscribe(() => {
				if (this.dataPayeeFrecuents && this.accounts) {
					if (!this.showSkeletonPayee && !isDataAccount) {
						if (this.dataPayeeFrecuents.length === 0 && this.accounts.length === 0) this.isEmptyContact = true;
					}
				}
			})
		}
	}

	/**
	 * Método que obtiene las respuesta del servicio getPaymentsAndServices
	 *
	 * @returns void
	 * @memberof ServiceTransferAccountComponent
	 */
	private getPaymentsAndServices() {
		if (!this._paymentsCardsAndServicesService.services$) {
			this._paymentsCardsAndServicesService.services$ = this._paymentsCardsAndServicesService
				.getPaymentsAndServices()
				.pipe(publishReplay(1),
					refCount());
		}

		this._paymentsCardsAndServicesService.services$.subscribe(responses => {
			const services: any = responses[0];
			const payments: any = responses[1];

			if (payments.data) {
				this.payees = payments.data.available_payees;
				if (this.payees) {
					this.payees.forEach((element: any) => {
						const bank = element.bank.split('|');
						element.bank = bank.length > 1 ? bank[1] : bank[0];
						switch (true) {
							case element.bank.toLowerCase().includes('inbursa'):
								element.image_url = 'INBURSA';
								break;
							case element.bank.toLowerCase().includes('hsbc'):
								element.image_url = 'HSBC';
								break;
							case element.bank.toLowerCase().includes('bbva'):
								element.image_url = 'BBVA_BANCOMER';
								break;
							case element.bank.toLowerCase().includes('banregio'):
								element.image_url = 'BANREGIO';
								break;
							case element.bank.toLowerCase().includes('banorte'):
								element.image_url = 'BANORTE';
								break;
							case element.bank.toLowerCase().includes('banamex'):
								element.image_url = 'BANAMEX';
								break;
							case element.bank.toLowerCase().includes('azteca'):
								element.image_url = 'AZTECA';
								break;
							case element.bank.toLowerCase().includes('american'):
								element.image_url = 'AMERICAN_EXPRESS';
								break;
							case element.bank.toLowerCase().includes('santander'):
								element.image_url = 'SANTANDER';
								break;
							default:
								element.image_url = 'GENERIC';
								break;
						}
					});
					this.availablePayees =
						this.payees.length >= 1 ? 2 : 0;
					this.payeesAndServices = this.payees.slice(0, this.availablePayees); // 0,1 || 1 || 0
				}
			}
			if (services.data) {
				const filterServices = [];
				if (services.data.length > 0) {
					const orderBillers = this.ordenarAsc(services.data, 'type');
					orderBillers.forEach(service => {
						if (filterServices.length === 0)
							filterServices.push(service);
						else {
							const serviceFound = filterServices.find(element => element.agreement === service.agreement);
							if (!serviceFound)
								filterServices.push(service);
							else {
								if (service.status !== 'CANCELED') {
									const position = filterServices.indexOf(serviceFound);
									filterServices[position] = service;
								}
							}
						}
					})
				}
				const actives = filterServices.filter(service => {
					if (service.status === 'ACTIVE') {
						const backService = BACKGROUND_SERVICES.find(
							back => back.agreement === service.agreement
						);
						service.color = service.color ? service.color : backService.color;
						return true;
					}
					return false;
				});
				const canceled = filterServices.filter(
					service => service.status === 'CANCELED'
				);
				const totalActive = actives.length; // 8x
				const subTotal = 7 - this.availablePayees; // 4,5,6,7
				this.payeesAndServices.push(
					...actives.slice(
						0,
						totalActive >= subTotal ? subTotal : totalActive
					)
				);
				// 7 o ninguno dado de alta
				if (this.payeesAndServices.length < 7) {
					actives.forEach((res: any) => {
						FREQUENT_SERVICES = FREQUENT_SERVICES.filter((item: any) => {
							if (res.agreement !== item.agreement) {
								return item;
							}
						})
					})
					for (let i = 0; i < (7 - actives.length); i++) {
						if (this.payeesAndServices.length === 7) {
							break;
						}
						const service = FREQUENT_SERVICES[i];
						const frecuentService = BACKGROUND_SERVICES.find(
							frecuent => frecuent.agreement === service.agreement
						);
						if (frecuentService) {
							service.color = frecuentService.color;
							service.alias = frecuentService.name;
							this.payeesAndServices.push(service);
						}
					}
				}
			}
			// No hay data que mostrar
			if (!payments.data && !services.data) {
				this.payeesAndServices = [];
			} else {
				this.formatDataServices();
			}
			this.showSkeleton = false;
		}, error => {
			this.showSkeleton = false;
		});
	}

	/**
	 * Permite visualizar el bottom sheet de confirmación para alta de servicio
	 *
	 * @param {Biller} data
	 * @memberof SectionServiceComponent
	 */
	private openOverlayActiveService(data: any) {
		this.dialogRef = this._dialog.open(
			{
				closeLabel: 'Cancelar',
				title: 'Alta de servicio',
				enableHr: false,
				disabledButton: true,
				buttons: [
					{
						label: 'Confirmar',
						class: 'strech',
						action: scope => {
							this._billerService.dataBiller = data;
							this._superTokenDialogService.getSuperToken();
							this.dialogRef.close();
						}
					}
				]
			},
			new CustomDialog(ActivateServiceComponent, { data })
		);
	}

	/**
	 * Función que suma a la fecha los minutos que recibe en los parámetros
	 *
	 * @private
	 * @param {string} date
	 * @param {number} minutes
	 * @returns
	 * @memberof SectionServiceComponent
	 */
	private addTimeMinute(date: string, minutes: number) {
		const time = new Date(date);
		return new Date(time.getTime() + minutes * 60000);
	}

	/**
	 * Permite visualizar el bottom sheet de notificación de servicio pendiente
	 *
	 * @private
	 * @param {*} data
	 * @memberof ServiceTransferAccountComponent
	 */
	private openOverlayPendingService(data: any) {
		const message =
			'El alta de tu servicio de ' +
			data.name +
			' está pendiente. Podrás hacer tu primer pago a partir de las ' +
			`${this._datePipe.transform(data.last_operation_date, 'HH:mm', 'UTC')}` +
			' hrs.';
		this.dialogRef = this._dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Alta pendiente',
				enableHr: true,
				showButton: false
			},
			new CustomDialog(DialogPaymentsServiceComponent, {
				message: message,
				subTitle: 'Inténtalo más tarde'
			})
		);
	}

	/**
	 * Método para redireccionar al cliente a la acción deseada
	 *
	 * @param {*} service
	 * @param {string} type
	 * @memberof ServiceTransferAccountComponent
	 */
	public navigateAction(service: any, type: string) {
		switch (type) {
			case 'Payee':
			case 'Account':
				this._router.navigate(['/transfers/initial'], {}, {
					type: type,
					value: service,
					screen: 'my-life'
				});
				break;
			case 'Service':
				if (service.status === 'ACTIVE') {
					this._router.navigate(['/payments/services/pay'], {
						queryParams: {
							key: service.key,
							color: service.color,
							agreement: service.agreement,
							name: service.name,
							status: service.status
						}
					});
				} else if (service.status === 'PENDING') {
					this.openOverlayPendingService(service);
				} else {
					this.openOverlayActiveService(service);
				}
				break;
			case 'Card':
				this._paymentsDataTransferService.sendData({
					shortname: service.alias,
					fullname: service.name,
					bank: service.bank,
					accountnumber: service.display_number,
					id: service.key,
					image_url: service.image_url
				});
				this._router.navigate(['/payments/select-account-tdc-others'], {
					queryParams: {
						redirectTwo: false
					}
				});
				break;
		}
	}

	/**
	 * Susbscribe la respuesta del SuperToken y obtiene los datos
	 *
	 * @memberof ServiceTransferAccountComponent
	 */
	ngOnInit() {
		this.getPaymentsCardsAndServices();
		this.getPaymentsAndServices();

		this._superTokenDialogService
			.getConfirmEvent()
			.pipe(takeUntil(this._destroy$))
			.subscribe(res => {
				if (res.status === 200 || res.status === 201) {
					if (res.status === 200) {
						this._superTokenDialogService.closeDialogToken();
					}
					this.activateBiller(this._billerService.dataBiller, res.otp);
				}
			});
	}

	/**
	 * Desuscribe supertoken y servicios al salir de la pantalla
	 *
	 * @memberof ServiceTransferAccountComponent
	 */
	ngOnDestroy() {
		this._destroy$.next();
		this._destroy$.complete();
		this._superTokenDialogService.destroyLoader();
	}
}
