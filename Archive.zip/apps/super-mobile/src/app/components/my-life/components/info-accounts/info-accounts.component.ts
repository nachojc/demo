import {
	Component,
	OnInit,
	Output,
	EventEmitter,
	Input,
	OnDestroy,
	AfterContentInit
} from '@angular/core';
import { AccountLyfeService } from '../../services/accounts-lyfe.service';
import { SummaryService } from 'libs/mobile/summary-operation-library/src/lib/services/summary.service';
import { SummaryResponse } from '../../models/summary-response';
import { Money } from 'libs/mobile/summary-operation-library/src/lib/models/money';
import {
	ContactDialogService,
	DialogReference,
	DialogService,
	CustomDialog,
	ThemeService
} from '@santander/flame-component-library';
import { DialogMessageComponent } from '../dialog-message/dialog-message.component';
import { NgxPermissionsService } from 'ngx-permissions';
import { CustomerService, NavigationBackHelperService } from '@santander/flame-core-library';
import { takeUntil, publishReplay, refCount, shareReplay } from 'rxjs/operators';
import { Subject, Observable, timer } from 'rxjs';
import { FlagOperationService } from '@santander/flame-core-library';
import { element } from '@angular/core/src/render3';
import { TemplateModalThemeOverlayRef, DialogThemeViewService } from '../../../dialog-theme-view';
import { ModalThemeConfigInterface } from '../../../dialog-theme-view/models/modal-theme-config.interface';
import { SelectThemeComponent } from '../../../select-theme/select-theme.component';

/**
 * Componente que muestra en "Mi vida" una sección con el resumén de las cuentas del cliente
 * y los quick action disponibles para él.
 *
 * @export
 * @class InfoAccountsComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-info-accounts',
	templateUrl: './info-accounts.component.html',
	styleUrls: ['./info-accounts.component.scss']
})
export class InfoAccountsComponent implements OnInit, OnDestroy {
	/**
	 *Creates an instance of InfoAccountsComponent.
	 * @param {AccountLyfeService} _accountLyfeService
	 * @param {ContactDialogService} _contactDialogService
	 * @param {NavigationBackHelperService} _router
	 * @param {DialogService} _dialog
	 * @param {NgxPermissionsService} _permissionsService
	 * @param {CustomerService} _customerService
	 * @param {SummaryService} _summaryService
	 * @param {FlagOperationService} _flagOperationService
	 * @memberof InfoAccountsComponent
	 */
	constructor(
		private _accountLyfeService: AccountLyfeService,
		private _contactDialogService: ContactDialogService,
		private _router: NavigationBackHelperService,
		private _dialog: DialogService,
		private _permissionsService: NgxPermissionsService,
		private _customerService: CustomerService,
		private _summaryService: SummaryService,
		private _flagOperationService: FlagOperationService,
		private _dialogThemeViewService: DialogThemeViewService,
		private _themeService: ThemeService
	) {
		this.emitAccounts.emit({});
		this.emitCredits.emit({});
		this.emitCustomers.emit({});
	}
	/**
	 *
	 * variables
	 * @type {*}
	 * @memberof InfoAccountsComponent
	 */
	private _dialogRef: DialogReference;
	private customerInfo: any = {
		data: {
			name: '',
			second_name: '',
			last_name: ''
		}
	};
	// @TODO - No se tiene de donde obtenerlo
	public accountComplete = new Subject<any>()
	public skeletonCustomer = true;
	public lastAccess: string; // Setear cuando customers tenga el dato
	public fullName = '';
	public totalProduct: number;
	public isShowTotal = false;
	public withOutCredits = false;
	public withOutTdd = false;
	public showSkeleton = true;
	public summaryAllAccounts: any = [0, 1, 2, 3];
	public cardInfoArray = [];
	public activationArray = [];
	public mapResult: any = [];
	private destroyed$ = new Subject<boolean>();
	public summaryData: any = [];
	public messageError = 'Parece que algo salió mal aquí. Inténtalo de nuevo más tarde';
	public errorSummary = false;
	public showNoGrowingMoney = false;
	public messageTitle: string;
	public totalBalance: Money = {
		amount: 0,
		currency_code: 'MXN'
	};
	private activationCategories = ["CREDIT_CARDS", "CHECKING_ACCOUNTS"];
	/**
	 * Parámetro con el total de dinero pendiente para una TDC (Suma de movimientos sin posted_date)
	 *
	 * @type {*}
	 * @memberof InfoAccountsComponent
	 */
	@Input() public pendingTDC: any = { amount: 0, currency_code: 'MXN' };
	/**
	 * Emite los datos de accounts
	 *
	 * @memberof InfoAccountsComponent
	 */
	@Output() emitAccounts = new EventEmitter<any>();
	/**
	 * Emite los datos de credits
	 *
	 * @memberof InfoAccountsComponent
	 */
	@Output() emitCredits = new EventEmitter<any>();
	/**
	 * Emite los datos del cliente
	 *
	 * @memberof InfoAccountsComponent
	 */
	@Output() emitCustomers = new EventEmitter<any>();

	/**
	 * Valida que el data de los servicios no sea nulo
	 *
	 * @private
	 * @param {*} data
	 * @returns
	 * @memberof InfoAccountsComponent
	 */
	private validateDataNull(data) {
		return data === null ? [] : data;
	}

	/**
	 * obtiene las tarjetas pendiente por activar
	 *
	 * @private
	 * @memberof InfoAccountsComponent
	 */
	private callCardService() {
		if (this._flagOperationService.getMyLifeFlag()) {
			this._accountLyfeService.statusCards$ = this._accountLyfeService.getStatusCard('0')
				.pipe(
					publishReplay(1),
					refCount()
				);
		}
		this._accountLyfeService.statusCards$.subscribe((response: any) => { this.callCardServiceSuccess(response); });
	}

	/**
	 * valida si es servicio fue exitoso y recupera la informacion
	 *
	 * @private
	 * @memberof InfoAccountsComponent
	 */
	private callCardServiceSuccess = (response: any) => {
		this.summaryAllAccounts[1] = response;
		this.cardInfoArray = this.summaryAllAccounts[1]
			? this.validateDataNull(this.summaryAllAccounts[1].data)
			: [];
	};

	/**
	 * Obtiene las cuentas de cheques
	 *
	 * @private
	 * @memberof InfoAccountsComponent
	 */
	private callAccountsService() {
		if (this._flagOperationService.getMyLifeFlag()) {
			this._accountLyfeService.account$ = this._accountLyfeService
				.getAccountsCards('0', '10')
				.pipe(publishReplay(1),
					refCount());
		}
		this._accountLyfeService.account$.subscribe(
			(response: any) => {
				this.accountComplete.next(true)
				this.accountComplete.complete();
				this.callAccountsServiceSuccess(response);
			},
			error => {
				this.accountComplete.next(true)
				this.accountComplete.complete();
				this._flagOperationService.resetFlags();
				this.sendAccounts([]);
			});
	}

	getObservableCompleteAccount(): Observable<any> {
		return this.accountComplete.asObservable();
	}

	/**
	 * recupera la informacion cuando el servicio fue exitoso
	 *
	 * @private
	 * @memberof InfoAccountsComponent
	 */
	private callAccountsServiceSuccess = (response: any) => {
		this.summaryAllAccounts[2] = response;
		if (this.summaryAllAccounts[2]) {
			// Filtra para obtener solo las cuentas en MXN
			const checkingAccounts = this.validateDataNull(
				this.summaryAllAccounts[2].data
			).filter(input => input.balance.currency_code === 'MXN');
			this.summaryAllAccounts[2].data = checkingAccounts;
			this.sendAccounts(this.summaryAllAccounts[2].data).then(() => this.showSkeleton = false)
		}
	};

	/**
	 * obtiene las cuentas de credito
	 *
	 * @private
	 * @memberof InfoAccountsComponent
	 */
	private callCreditsService() {
		if (this._flagOperationService.getMyLifeFlag()) {
			this._accountLyfeService.creditCards$ = this._accountLyfeService
				.getCreditsCard('0', '10')
				.pipe(
					publishReplay(1),
					refCount(),
				);
		}
		this._accountLyfeService.creditCards$.subscribe(
			(response: any) => {
				this.callCreditsServiceSuccess(response);
			},
			error => {
				this._flagOperationService.resetFlags();
				this.sendCredits([]);
			});
	}

	/**
	 * obtiene la informacion de las tarjetas de creditos cuando el servcio fue exitoso
	 *
	 * @private
	 * @memberof InfoAccountsComponent
	 */
	private callCreditsServiceSuccess = (response: any) => {
		this.summaryAllAccounts[3] = response;
		if (this.summaryAllAccounts[3]) {
			this.summaryAllAccounts[3].data = this.validateDataNull(
				this.summaryAllAccounts[3].data
			);
			this.sendCredits(this.summaryAllAccounts[3].data).then(() => {
				if(this.showSkeleton) this.showSkeleton = false;
			})
		}
	};


	/**
	 *
	 * Abre el dialogo para seleccion de tema de la app
	 *
	 * @memberof SummaryViewComponent
	 */

	public openDialogTheme(): void {
		const configDialogTheme: ModalThemeConfigInterface = {
			title:'Selecciona un modo'
		};
		const ref: TemplateModalThemeOverlayRef = this._dialogThemeViewService.open(
			SelectThemeComponent,
			configDialogTheme
		);
	}


	public showsDialog(){
		// Settear flame por defecto y evitar el dark
		// localStorage.setItem('theme', 'flame-foundation');
		const theme = localStorage.getItem('theme');
		const customer = JSON.parse(localStorage.getItem('customer'));
		console.log(customer);
		const permissions = this._permissionsService.getPermissions();
		if (theme) {
			this._themeService.setTheme(theme);
			localStorage.setItem('theme', theme);
		} else {
			if (customer.university_enabled) {
				this.openDialogTheme();
			} else {
				this._themeService.setTheme('flame-foundation');
				localStorage.setItem('theme', 'flame-foundation');
			}
		}
	}

	/**
	 * obtien la informacion del usuario
	 *
	 * @returns
	 * @memberof InfoAccountsComponent
	 */
	getCustomerInfo() {
		return this._customerService
			.getMe()
			.pipe(takeUntil(this.destroyed$))
			.subscribe((response: any) => {
				this.skeletonCustomer = false;
				localStorage.setItem('customer', JSON.stringify(response.data));
				this.sendCustomers(JSON.parse(localStorage.getItem('customer')));
				this.showsDialog();
			}, error => this.skeletonCustomer = false);
	}

	/**
	 *
	 * setea la informacion el usuario en el local storage
	 * @memberof InfoAccountsComponent
	 */
	setLocalStorageCustomer() {
		if (!localStorage.getItem('customer')) {
			this.getCustomerInfo();
		} else if (
			JSON.parse(localStorage.getItem('customer')).bank_segment === null
		) {
			this.getCustomerInfo();
		} else {
			this.sendCustomers(JSON.parse(localStorage.getItem('customer')));
			this.skeletonCustomer = false;
		}
	}

	/**
	 * Método que obtiene la información de los servicios de summary accounts y summary credits
	 *
	 * @memberof InfoAccountsComponent
	 */
	private getInfoAccount() {
		const permissions = this._permissionsService.getPermissions();

		this.setLocalStorageCustomer();
		if (permissions.hasOwnProperty('R6')) {
			this.callCardService();
		}

		this.summaryAllAccounts[0] = JSON.parse(localStorage.getItem('customer'));
		this.callAccountsService();
		this.getObservableCompleteAccount().subscribe(() => {
			this.callCreditsService();
		})
	}

	/**
	 * emite las cuentas de cheques
	 *
	 * @private
	 * @param {*} products
	 * @returns
	 * @memberof InfoAccountsComponent
	 */
	private sendAccounts(products) {
		let totalTdd = 0;
		/// TDD
		if (products.length !== 0) {
			this.totalProduct = products.length;
			this.summaryAllAccounts[2].data.forEach(element => {
				totalTdd += element.balance.amount;
			});
			this.mapResult[0] = {
				total_balance: {
					amount: totalTdd,
					currency_code: 'MXN'
				},
				category_name: 'CHECKING_ACCOUNTS',
				keys: this.summaryAllAccounts[2].data.map(item => item.key),
				products: this.summaryAllAccounts[2].data.map(item => {
					return {
						key: item.key,
						image_url: item.image_url,
						alias: item.alias,
						display_number: item.display_number,
						balance: item.balance
					};
				})
			};
		} else {
			this.mapResult[0] = {
				total_balance: {
					amount: 0,
					currency_code: 'MXN'
				},
				category_name: 'CHECKING_ACCOUNTS',
				keys: [],
				products: []
			};
			this.withOutTdd = true;
		}
		this.emitAccounts.emit(this.mapResult[0]);
		return Promise.resolve(true)
	}

	/**
	 * emite las tarjetas de credito
	 *
	 * @private
	 * @param {*} products
	 * @returns
	 * @memberof InfoAccountsComponent
	 */
	private sendCredits(products) {
		/// TDC
		let totalAvaibleCredits = 0;
		if (products.length !== 0) {
			this.totalProduct = !this.withOutTdd
				? (this.totalProduct += products.length)
				: products.length;
			this.summaryAllAccounts[3].data.forEach(element => {
				if (element.balance.amount > 0) {
					element.available_credit.amount += element.balance.amount
				}
				totalAvaibleCredits += element.available_credit
					? element.available_credit.amount
					: 0;
			});
			this.mapResult[1] = {
				total_balance: {
					amount: totalAvaibleCredits,
					currency_code: 'MXN'
				},
				category_name: 'CREDIT_CARDS',
				keys: this.summaryAllAccounts[3].data.map(item => item.key),
				totalAvaibleCredits: totalAvaibleCredits,
				products: this.summaryAllAccounts[3].data.map(item => {
					let main_card = { image_url: '', display_number: '' };
					item.related_cards.forEach(card => {
						if (card.relation_type === 'Primary') {
							main_card = card;
						}
					});
					return {
						key: item.key,
						alias: item.alias ? item.alias : item.name,
						image_url: main_card.image_url,
						display_number: main_card.display_number,
						balance: item.balance,
						available_credit: item.available_credit,
						due_date: item.due_date,
						statement_date: item.statement_date
					};
				})
			};
		} else {
			this.mapResult[1] = {
				total_balance: {
					amount: 0,
					currency_code: 'MXN'
				},
				category_name: 'CREDIT_CARDS',
				keys: [],
				totalAvaibleCredits: 0,
				products: []
			};
			this.withOutCredits = true;
		}
		this.emitCredits.emit(this.mapResult[1]);
		return Promise.resolve(true)
	}

	/**
	 * Método que emite el objeto con los keys y productos de summary accounts y summary credits
	 *
	 * @param {*} valuesTdd
	 * @param {*} valuesTdc
	 * @memberof InfoAccountsComponent
	 */
	private sendCustomers(data) {
		this.customerInfo = data;
		this.fullName = `${this.customerInfo.name} ${this.customerInfo.last_name} ${
			this.customerInfo.second_name
			}`
		this.emitCustomers.emit(data);
	}

	/**
	 * obtiene la informacion de los estatus de las tarjetas
	 *
	 * @private
	 * @memberof InfoAccountsComponent
	 */
	private callSummaryService() {
		this._summaryService
			.getSummary()
			.pipe(takeUntil(this.destroyed$))
			.subscribe(
				(response: SummaryResponse) => {
					this.summaryData = response.data.reduce((result, currentValue: any) => {
						(result[currentValue.category] = result[currentValue.category] || []).push(
							currentValue
						);
						return result;
					}, {});
					this.lookForDollars();
					this.validateData();
					this.activationCategories.forEach(category => {
						this.activationPendingData(category);
					})
					//this.showSkeleton = false;
				},
				error => {
					this.messageError = error.notifications
						? error.notifications[0].message
						: this.messageError;
					this.errorSummary = true;
				}
			);
	}

	/**
	 * Valida los datos de los productos en las categorias para flujos alternos
	 *
	 * @TODO Temporal hasta que se resuelva lo de las imagenes.
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private validateData(): void {
		/* Remueve una categoria con ningun producto, en caso de que en CHECKING_ACCOUNTS solo
			se encontraran cuentas en dolares. Establece imagenes para GROWING_MONEY
		*/

		if (this.summaryData['GROWING_MONEY']) {
			this.summaryData['GROWING_MONEY'].forEach(element => {
				if (element.related_cards && element.related_cards.length > 0) {
					element.related_cards.forEach(growing_related_card => {
						growing_related_card.image_url = 'growing';
					});
				} else {
					element.image_url = 'growing';
				}
			});
		}

		if (this.summaryData['INVESTMENTS']) {
			this.summaryData['INVESTMENTS'].forEach(element => {
				if (element.related_cards && element.related_cards.length > 0) {
					element.related_cards.forEach(growing_related_card => {
						growing_related_card.image_url = 'INVERSION';
					});
				} else {
					element.image_url = 'INVERSION';
				}
			});
		}
		if (this.summaryData['CHECKING_ACCOUNTS']) {
			this.showNoGrowingMoney = false;
			this.messageTitle =
				this.summaryData['CHECKING_ACCOUNTS'].length === 1
					? 'Total de dinero en tu cuenta en pesos:'
					: 'Total de dinero en tus cuentas en pesos:';
		} else if (this.summaryData['CREDIT_CARDS']) {
			this.summaryData['CREDIT_CARDS'].forEach(element => {
				this.totalBalance.amount += element.balance.amount < 0 ? element.balance.amount : 0;
			});
			this.messageTitle = 'Tu deuda actual es:';
		} else if (this.summaryData['CHECKING_ACCOUNTS_USD']) {
			this.summaryData['CHECKING_ACCOUNTS_USD'].forEach(element => {
				this.totalBalance.amount += element.balance.amount;
			});
			this.totalBalance.currency_code = 'USD';
			this.messageTitle =
				this.summaryData['CHECKING_ACCOUNTS_USD'].length === 1
					? 'Total de dinero en tu cuenta en dólares:'
					: 'Total de dinero en tus cuentas en dólares:';
		}
	}

	/**
	 * Busca una cuenta en dolares para separarla de la categoría
	 * CHECKING_ACCOUNTS y pase a ser parte de la categoría CHECKING_ACCOUNTS_USD.
	 *
	 * @TODO Temporal hasta que BAAS regrese las categorías divididas.
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private lookForDollars(): void {
		for (let i = 0; i < this.summaryData['CHECKING_ACCOUNTS'].length; i++) {
			if (this.summaryData['CHECKING_ACCOUNTS'][i].balance.currency_code === 'USD') {
				(this.summaryData['CHECKING_ACCOUNTS_USD'] = this.summaryData['CHECKING_ACCOUNTS_USD'] || []).push(
					this.summaryData['CHECKING_ACCOUNTS'][i]
				);
				this.summaryData['CHECKING_ACCOUNTS'].splice(i, 1);
				i--;
			} else {
				this.totalBalance.amount += this.summaryData['CHECKING_ACCOUNTS'][i].balance.amount;
			}
		}
		if (this.summaryData['CHECKING_ACCOUNTS'].length === 0) {
			delete this.summaryData.CHECKING_ACCOUNTS;
		}
	}

	/**
	 * metodo que permite buscar las tarjetas pendientes por activar
	 *
	 * @private
	 * @param {*} category
	 * @memberof InfoAccountsComponent
	 */
	private activationPendingData(category) {
		let related_cards = [];
		let cards_names = [];
		let current_description = { name: '' };
		let n = 0;
		this.summaryData[category].forEach(element => {
			current_description = element.description;
			element['name'] = current_description;
			related_cards.push(element.related_cards);
			cards_names.push(current_description)
		});
		related_cards.forEach(element1 => {
			let i;
			for (i = 0; i < element1.length; i++) {
				if (element1[i].relation_type == 'PRIMARY' && element1[i].status == 'ACTIVATION_PENDING') {
					element1[i]["name"] = cards_names[n];
					this.activationArray.push(element1[i]);
				}
			}
			n++;
		});
	}

	/**
	 * Método que redirecciona a wallet, se le puede pasar toda la información de la tarjeta seleccionada
	 *
	 * @memberof InfoAccountsComponent
	 */
	activeCardWallet(cardSelected): void {
		const card = cardSelected;
		this._router.navigate(['/superwallet/activation'],
			{
				queryParams: {
					key: card.key,
					display_number: card.display_number,
					cardType: card.image_url
				},
				queryParamsHandling: 'merge'
			});
	}

	/**
	 * Método que muestra el modal de contacto
	 *
	 * @memberof InfoAccountsComponent
	 */
	public openModalContact() {
		this._contactDialogService.openDialogContact(1);
	}

	/**
	 *
	 *
	 * @returns
	 * @memberof InfoAccountsComponent
	 */
	public getLengthAmount() {
		let length = 0;
		if (!this.withOutTdd) {
			if (this.mapResult[0].hasOwnProperty('total_balance')) {
				let amount =
					this.mapResult[0].products.length !== 1
						? this.mapResult[0].total_balance.amount
						: this.mapResult[0].products[0].balance.amount;
				amount = Math.round(amount);
				length = amount.toString().length;
			}
		} else {
			if (this.mapResult[1].hasOwnProperty('total_balance')) {
				let amount =
					this.mapResult[1].products.length !== 1
						? this.mapResult[1].total_balance.amount
						: this.mapResult[1].products[0].available_credit.amount;
				amount = Math.round(amount);
				length = amount.toString().length;
			}
		}

		return {
			md: length >= 8 && length < 10,
			sm: length >= 10 && length < 12,
			xs: length >= 12 && length < 15,
			xxs: length >= 15
		};
	}

	/**
	 * Método para redireccionar con los quick actions
	 *
	 * @param {string} button
	 * @param {*} path
	 * @memberof InfoAccountsComponent
	 */
	public actionButtonIcon(button: string, path) {
		switch (button) {
			case 'dispose':
			case 'transfer':
			case 'payService':
				// case 'international':
				if (path) {
					this._router.navigate([path], {}, 'isMyLife');
				}
				break;
			case 'payCard':
				if (this.withOutTdd) {
					this._dialogRef = this._dialog.open(
						{
							closeLabel: 'Cerrar',
							title: '',
							enableHr: false,
							disabledButton: true,
							buttons: [
								{
									label: 'La quiero',
									class: 'full',
									action: scope => {
										this._dialogRef.close();
										this._router.navigate([path]);
									}
								}
							]
						},
						new CustomDialog(DialogMessageComponent, {
							title: '¡Necesitas una cuenta SuperDigital!',
							message: 'Ábre una cuenta de débito y disfruta de sus beneficios'
						})
					);
				} else if (
					this.summaryAllAccounts[3].data.length === 1 &&
					!this.withOutTdd
				) {
					let number, image;
					this.summaryAllAccounts[3].data[0].related_cards.forEach(element => {
						if (element.relation_type === 'Primary') {
							number = element.display_number;
							image = element.image_url;
						}
					});
					const card = {
						key: this.summaryAllAccounts[3].data[0].key,
						amount: this.summaryAllAccounts[3].data[0].balance.amount,
						currency: this.summaryAllAccounts[3].data[0].balance.currency_code,
						display_number: number,
						name: this.summaryAllAccounts[3].data[0].name,
						alias: this.summaryAllAccounts[3].data[0].alias,
						image_url: image
					};
					this._router.navigate(['/payments/card-payments'], {
						queryParams: card
					});
				} else {
					this._router.navigate(['/payments/card-payments-others']);
				}
				break;
		}
	}

	/**
	 * Obtiene la info de cuentas/tarjetas
	 *
	 * @memberof InfoAccountsComponent
	 */
	ngOnInit() {
		this.getInfoAccount();
		this.callSummaryService();
	}

	ngOnDestroy() {
		this.destroyed$.next(true);
		this.destroyed$.complete();
	}
}
