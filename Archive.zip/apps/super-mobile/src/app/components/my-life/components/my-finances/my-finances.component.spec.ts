import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { AppComponent } from './../../../../app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from 'apps/super-mobile/src/environments/environment.pre';
import { ErrorDialogComponent } from './../../../error-dialog/error-dialog.component';
import { IdpFakeViewComponent } from './../../../idp-fake-view/idp-fake-view.component';
import { MoreMainMenuViewComponent } from './../../../more-main-menu-view/more-main-menu-view.component';
import { AccesViewComponent } from './../../../access-view/access-view.component';
import { AppRoutingModule } from './../../../../app.routing.module';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	TagModule,
	DialogContentService,
	LoaderDialogService,
	TokenInputModule
} from '@santander/flame-component-library';
import {
	async,
	ComponentFixture,
	TestBed,
	inject
} from '@angular/core/testing';

import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import {
	HttpClientModule,
	HTTP_INTERCEPTORS,
	HttpXhrBackend,
	XhrFactory
} from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import {
	FlameCoreLibraryModule,
	AuthenticationService,
	CryptoService,
	GlobileHttpClient,
	IdpService,
	DataTransferService,
	ENV_CONFIG,
	ApiInterceptor,
	SERVICE_LOADER
} from '@santander/flame-core-library';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, APP_BASE_HREF, DatePipe } from '@angular/common';
import { globileHttpXhrBackendFactory } from '../../../../app.module';
import { MyFinancesComponent } from './my-finances.component';
import { MyLifeServices } from '../../services/my-life-services';
import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
import { LOCALE_ID, SimpleChange } from '@angular/core';
import { MyLifeViewComponent } from '../../my-life-view/my-life-view.component';
import { BeneficiariesServicesViewComponent } from '../../../beneficiaries-services-view/beneficiaries-services-view.component';
import { MyLifeDeclarationComponents } from '../my-life-components';
import { FinancesService } from '../../services/finances.service';
import { of } from 'rxjs';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { TransactionDateFilterPipe } from '../../pipes/transactions-date-filter.pipe';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { DialogClarificationsComponent } from '../../../more-main-menu-view/components/dialog-clarifications/dialog-clarifications.component';
import { DialogErrorMoreComponent } from '../../../more-main-menu-view/components/dialog-error-more/dialog-error-more.component';
import { DialogCloseLoginComponent } from '../../../more-main-menu-view/components/dialog-close-login/dialog-close-login.component';
import { SkeletonViewMoreComponent } from '../../../more-main-menu-view/components/skeleton-more-view/skeleton-view-more.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('MyFinancesComponent', () => {
	let component: MyFinancesComponent;
	let fixture: ComponentFixture<MyFinancesComponent>;
	let financeService: FinancesService;
	const changes = {
		keys: {
			currentValue: [
				{
					total_balance: {
						currency_code: 'MXN',
						amount: 69827.78
					},
					category_name: 'CHECKING_ACCOUNTS',
					keys: ['056722751246', '056722733565'],
					products: [
						{
							key: '056722751246',
							image_url: null,
							description: 'SUPER NOMINA',
							alias: null,
							display_number: '56*5124'
						},
						{
							key: '056722733565',
							image_url: '2517',
							description: 'SUPER NOMINA',
							alias: null,
							display_number: '56*3356'
						}
					]
				},
				{
					total_balance: {
						currency_code: 'MXN',
						amount: 85399.66
					},
					category_name: 'CREDIT_CARDS',
					keys: [
						'4e20fbb243684d9eb19ff33a50ee422e',
						'1b10lop243683d9eb19ff33a50ee345a'
					],
					products: [
						{
							key: '4e20fbb243684d9eb19ff33a50ee422e',
							image_url: '74110101010',
							description: 'BLACK',
							alias: null,
							display_number: '*3699'
						},
						{
							key: '1b10lop243683d9eb19ff33a50ee345a',
							image_url: '2517',
							description: 'SUPER NOMINA',
							alias: null,
							display_number: '*9981'
						}
					]
				}
			],
			firstChange: false
		}
	};

	const emptyCredits = {
		data: []
	};

	const emptyTransactions = {
		data: []
	};

	const credits = {
		data: [
			{
				key: '4e20fbb243684d9eb19ff33a50ee422e',
				name: 'Aeromexico Blanca',
				alias: 'Rosa Marias Olvera/BPYTE',
				status: 'ACTIVE',
				balance: {
					amount: 1812.1,
					currency_code: 'MXN'
				},
				related_cards: [
					{
						display_number: '**** **** **** 3699',
						relation_type: 'Primary',
						expiration_date: '05/22',
						url: '/cards/{card-key}'
					}
				],
				statement_balance: {
					amount: 50000,
					currency_code: 'MXN'
				},
				minimum_payment: {
					amount: 0,
					currency_code: 'MXN'
				},
				due_date: '2019-04-08T00:00:00'
			},
			{
				key: '1b10lop243683d9eb19ff33a50ee345a',
				name: 'Mastercard Empresarial',
				alias: 'Rosa Marias Olvera/BPYTE',
				status: 'BLOCKED',
				balance: {
					amount: -22038.1,
					currency_code: 'MXN'
				},
				related_cards: [
					{
						display_number: '**** **** **** 9981',
						relation_type: 'Primary',
						expiration_date: '08/22',
						url: '/card/{card-key}'
					}
				],
				statement_balance: {
					amount: 8000,
					currency_code: 'MXN'
				},
				minimum_payment: {
					amount: 310,
					currency_code: 'MXN'
				},
				due_date: '2019-04-08T00:00:00'
			}
		],
		notifications: [
			{
				code: 'E422CDNPAYRCPTG001',
				message: 'Something is invalid',
				timestamp: '2019-02-12T20:07:18.639Z'
			}
		],
		paging: {
			next_cursor_key: '10'
		}
	};

	const transactions = {
		data: [
			{
				key: '10',
				transaction_origin: 'OLIVE GARDEN REFORMA',
				creation_date: '2017-10-09T00:00:00',
				posted_date: null,
				url: null,
				amount: {
					amount: 756.39,
					currency_code: 'MXN'
				}
			},
			{
				key: '09',
				transaction_origin: 'CINEPOLIS',
				creation_date: '2017-10-01T00:00:00',
				posted_date: null,
				url: null,
				amount: {
					amount: 160.39,
					currency_code: 'MXN'
				}
			},
			{
				key: '08',
				transaction_origin: 'LA COMER',
				creation_date: '2017-09-23T00:00:00',
				posted_date: null,
				url: null,
				amount: {
					amount: -741.39,
					currency_code: 'MXN'
				}
			},
			{
				key: '07',
				transaction_origin: 'SANBORNS',
				creation_date: '2017-09-10T00:00:00',
				posted_date: null,
				url: null,
				amount: {
					amount: -256.39,
					currency_code: 'MXN'
				}
			},
			{
				key: '06',
				transaction_origin: 'TICKETMASTER MX',
				creation_date: '2017-08-20T00:00:00',
				posted_date: null,
				url: null,
				amount: {
					amount: 1656.39,
					currency_code: 'MXN'
				}
			}
		],
		notifications: [
			{
				code: 'E422CDNPAYRCPTG001',
				message: 'OK',
				timestamp: '2019-02-15T18:02:33.438Z'
			}
		],
		paging: {}
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			schemas: [CUSTOM_ELEMENTS_SCHEMA],
			imports: [
				AppRoutingModule,
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				HttpClientModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				RouterModule,
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				FlameCoreLibraryModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
				TabModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				MyFinancesOperationLibraryModule,
				BeneficiaryOperationLibraryModule,
				PaymentsOperationLibraryModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				TokenInputModule,
				NgxPermissionsModule.forRoot()
			],
			declarations: [
				AccesViewComponent,
				AppComponent,
				MoreMainMenuViewComponent,
				BeneficiariesServicesViewComponent,
				IdpFakeViewComponent,
				ErrorDialogComponent,
				DialogClarificationsComponent,
				DialogErrorMoreComponent,
				DialogCloseLoginComponent,
				MyLifeViewComponent,
				MyLifeDeclarationComponents,
				TransactionDateFilterPipe,
				SkeletonViewMoreComponent
			],
			providers: [
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				DataTransferService,
				DatePipe,
				DialogContentService,
				ContactDialogService,
				LoaderDialogService,
				MyLifeServices,
				WINDOW_PROVIDERS,
				TransactionDateFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: environment
				},
				{
					provide: SERVICE_LOADER,
					useExisting: LoaderDialogService
				},
				{
					provide: HTTP_INTERCEPTORS,
					useClass: ApiInterceptor,
					multi: true
				},
				// {
				// 	provide: HTTP_INTERCEPTORS,
				// 	useClass: OauthInterceptor,
				// 	multi: true
				// },
				{
					provide: HttpXhrBackend,
					useFactory: globileHttpXhrBackendFactory,
					deps: [XhrFactory]
				},
				{
					provide: LOCALE_ID,
					useValue: 'es-MX'
				},
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				{
					provide: HttpXhrBackend,
					useFactory: globileHttpXhrBackendFactory,
					deps: [XhrFactory]
				},
				{
					provide: APP_BASE_HREF,
					useValue: '/'
				}
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(MyFinancesComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		financeService = TestBed.get(FinancesService);
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should call ngOnChanges', () => {
		spyOn(financeService, 'getTransactions').and.returnValue(
			of(emptyTransactions)
		);
		spyOn(financeService, 'getCredits').and.returnValue(of(emptyCredits));
		fixture.detectChanges();
		component.ngOnChanges({
			keys: new SimpleChange(undefined, changes.keys.currentValue, false)
		});
		expect(financeService.getTransactions).toHaveBeenCalled();
		expect(financeService.getCredits).toHaveBeenCalled();
	});

	it('should call creditCards', () => {
		spyOn(financeService, 'getTransactions').and.returnValue(
			of(emptyTransactions)
		);
		spyOn(financeService, 'getCredits').and.returnValue(of(credits));
		fixture.detectChanges();
		component.ngOnChanges({
			keys: new SimpleChange(undefined, changes.keys.currentValue, false)
		});
		expect(financeService.getTransactions).toHaveBeenCalled();
		expect(financeService.getCredits).toHaveBeenCalled();
	});

	// it('should call transactions', () => {
	// 	spyOn(financeService, 'getTransactions').and.returnValue( of (transactions));
	// 	spyOn(financeService, 'getCredits').and.returnValue( of (credits));
	// 	fixture.autoDetectChanges();
	// 	component.ngOnChanges({
	// 		keys: new SimpleChange(undefined, changes.keys.currentValue, false)
	// 	});
	// });

	it('Should get info in localStorage of Customer', () => {
		const nameInfo = transactions;
		fixture.detectChanges();
	});

	it('should validates empty values', () => {
		spyOn(financeService, 'getTransactions').and.returnValue(
			of(emptyTransactions)
		);
		spyOn(financeService, 'getCredits').and.returnValue(of(credits));
		fixture.detectChanges();

		const emptyTotalChanges = {
			...changes
		};
		emptyTotalChanges.keys.currentValue[0].total_balance = null;
		emptyTotalChanges.keys.currentValue[1].total_balance = null;

		component.ngOnChanges({
			keys: new SimpleChange(
				undefined,
				emptyTotalChanges.keys.currentValue,
				false
			)
		});

		emptyTotalChanges.keys.currentValue = [];
		component.ngOnChanges({
			keys: new SimpleChange(
				undefined,
				emptyTotalChanges.keys.currentValue,
				false
			)
		});
		expect(component.keys.length).toEqual(0);
	});

	// it('should prueba', () => {
	// 	fixture.componentInstance.filterTransaction();
	// 	fixture.detectChanges();
	// });
});
