import { Component } from '@angular/core';

/**
 * mensaje 
 *
 * @export
 * @class DialogMessageComponent
 */
@Component({
	selector: 'sm-dialog-message',
	templateUrl: './dialog-message.component.html',
	styleUrls: ['./dialog-message.component.scss']
})
export class DialogMessageComponent {
	/**
	 * data del componente
	 *
	 * @type {*}
	 * @memberof DialogMessageComponent
	 */
	public data: any;
}
