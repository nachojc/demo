import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { DialogMessageComponent } from './dialog-message.component';

describe('DialogMessageComponent', () => {
	let component: DialogMessageComponent;
	let fixture: ComponentFixture<DialogMessageComponent>;

	const dataFake = {
		title: 'titulo',
		message: 'mensaje'
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			declarations: [DialogMessageComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogMessageComponent);
		component = fixture.componentInstance;
		component.data = dataFake;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});
});
