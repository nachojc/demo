import {
	Component,
	Input,
	OnChanges,
	Output,
	EventEmitter,
	SimpleChanges,
	SimpleChange
} from '@angular/core';
import { Transaction } from 'libs/mobile/summary-operation-library/src/lib/models';
import { FinancesService } from '../../services/finances.service';
import { TransactionDateFilterPipe } from '../../pipes/transactions-date-filter.pipe';
import { FlagOperationService } from '@santander/flame-core-library';
import { Subject, of, from, Observable } from 'rxjs';
import { shareReplay, publishReplay, refCount } from 'rxjs/operators';

/**
 *
 *
 * @export
 * @class MyFinancesComponent
 * @implements {OnChanges}
 */
@Component({
	selector: 'sm-my-finances',
	templateUrl: './my-finances.component.html',
	styleUrls: ['./my-finances.component.scss']
})
export class MyFinancesComponent implements OnChanges {
	/**
	 *Creates an instance of MyFinancesComponent.
	 * @param {FinancesService} _financesService
	 * @param {TransactionDateFilterPipe} _filterPipe
	 * @param {FlagOperationService} _flagOperationService
	 * @memberof MyFinancesComponent
	 */
	constructor(
		private _financesService: FinancesService,
		private _filterPipe: TransactionDateFilterPipe,
		private _flagOperationService: FlagOperationService
	) {}

	/**
	 * variables publica, privadas, @Input @Output
	 *
	 * @private
	 * @memberof MyFinancesComponent
	 */
	private pendingTDC = { amount: 0, currency_code: 'MXN' };
	private flagTdd: boolean;
	private flagTdc: boolean;
	private movements: any[] = [];
	private productsKeys: any[] = [];
	private lastAccountKey: any = {};
	private lastCreditKey: any = {};
	private viewTransactions: Transaction[] = [];
	private totalBalanceTdd = {};
	private totalBalanceTdc = {};
	public viewOnlyTreeTransactions: Transaction[] = [];
	public income = 0;
	public expense = 0;
	public monthName: any = new Date();
	public showSkeleton = true;
	@Input() public customers: any = {};
	@Input() public accounts: any[];
	@Input() public credits: any[];
	@Output() initialFinance: any = new EventEmitter();
	@Output() showComponent: any = new EventEmitter();
	@Output() setPendingTDC: any = new EventEmitter();

	/**
	 * Recorre las credit cards para traer sus movimientos
	 *
	 * @private
	 * @memberof MyFinancesComponent
	 */
	private getCredits() {
		const cards: any = this.credits;
		this.lastCreditKey = cards.keys[cards.keys.length - 1];
		cards.products.forEach((product: any) => {
			this.addProductKeys(
				product.key,
				'CREDIT_CARDS',
				product,
				product.due_date
			);
			this.getTransactions(product.key, false, '', product.statement_date);
		});
	}

	/**
	 * Recorre las cuentas en pesos para traer sus movimientos
	 *
	 * @private
	 * @memberof MyFinancesComponent
	 */
	private getAccounts() {
		const accounts: any = this.accounts;
		this.lastAccountKey = accounts.keys[accounts.keys.length - 1];
		accounts.keys.forEach((key: string) => {
			const product = accounts.products.find((item: any) => item.key === key);
			this.addProductKeys(key, 'CHECKING_ACCOUNTS', product);
			this.getTransactions(key, true, '', '');
		});
	}

	/**
	 * Obtiene todas las transacciones de un producto por su key
	 * hasta terminar su paginación.
	 *
	 * @param {string} key
	 * @param {boolean} isAccount
	 * @param {string} cursor
	 * @param {string} due_date
	 * @memberof MyFinancesViewComponent
	 */
	private getTransactions(
		key: string,
		isAccount: boolean,
		cursor: string,
		due_date: string
	) {
		
		if(!this._flagOperationService.getMyLifeFlag()){
			this._financesService.transfers$.subscribe( (data) => {
				this.income = data.income;
				this.expense = data.expense;
				this.pendingTDC = data.pendingTDC;
				this.movements = data.movements;
				if (this.pendingTDC.amount) {
					if(this.pendingTDC.amount > 0)
						this.setPendingTDC.emit(this.pendingTDC);
				}
				this.flagTdc = true;
				this.flagTdd = true;
				this.filterTransaction(); 
			});
		
		} else{
			this._financesService
			.getTransactions(
				key,
				'50',
				isAccount,
				String(cursor),
				'sm-chip-actual',
				due_date
			).subscribe(
				(transactionResponse: any) => {
					if (transactionResponse.data.length > 0) {
						transactionResponse.data.map(
							transaction => (transaction.product_key = key)
						);
						this.movements = this.movements.concat(transactionResponse.data);
						transactionResponse.data.forEach((transactions: Transaction) => {
							if (transactions.amount.amount > 0) {
								this.income += transactions.amount.amount;
							} else {
								this.expense += transactions.amount.amount;
							}
							if (!isAccount) {
								this.pendingTDC.amount += transactions.creation_date
									? transactions.amount.amount
									: 0;
								if (this.pendingTDC.amount > 0) {
									this.setPendingTDC.emit(this.pendingTDC);
								}
							}
						});

						if (transactionResponse.paging !== null) {
							this.getTransactions(
								key,
								isAccount,
								transactionResponse.paging.next_cursor_key,
								due_date
							);
						} else {
							if (this.lastCreditKey === key) {
								this.flagTdc = true;
							}
							if (this.lastAccountKey === key) {
								this.flagTdd = true;
							}
							this._flagOperationService.setMyLifeFlag(false);
							const cache = {movements:this.movements, income: this.income, expense:this.expense, pendingTDC: this.pendingTDC.amount }
							this._financesService.transfers$ = of(cache); //almacenar en memoria
							this.filterTransaction(); 
						}
					} else {
						this.showSkeleton = false;
					}
				},
				error => {
					if (this.lastCreditKey === key) {
						this.flagTdc = true;
						this.filterTransaction();
					}
					if (this.lastAccountKey === key) {
						this.flagTdd = true;
						this.filterTransaction();
					}
				}
			);
		}
	}

	/**
	 * Agrega un producto al arreglo
	 *
	 * @private
	 * @param {string} key
	 * @param {string} category_name
	 * @param {*} product
	 * @param {string} [due_date]
	 * @memberof MyFinancesComponent
	 */
	private addProductKeys(
		key: string,
		category_name: string,
		product: any,
		due_date?: string
	) {
		this.productsKeys.push({ ...product, key, category_name, due_date });
	}

	/**
	 * Filtra los movimientos para ordenarlos por fecha
	 *
	 * @private
	 * @memberof MyFinancesComponent
	 */
	private filterTransaction() {
		this.viewTransactions = this._filterPipe.transform(this.movements);
		this.viewOnlyTreeTransactions = this.viewTransactions.slice(0, 3);
		this.showSkeleton = false;
	}

	/**
	 * Muestra la vista completa de mis finanzas
	 *
	 * @memberof MyFinancesComponent
	 */
	public showMoreMovements() {
		const movementsParams = {
			customer: this.customers
				? this.customers
				: { name: '', second_name: '', last_name: '' },
			products: this.productsKeys,
			movements: this.viewTransactions,
			movements_income: this.income,
			movements_expenses: this.expense * -1,
			tdd_balance: this.totalBalanceTdd,
			tdc_balance: this.totalBalanceTdc
		};
		this.initialFinance.emit(movementsParams);
		this.showComponent.emit(true);
	}

	/**
	 *
	 *
	 * @returns
	 * @memberof MyFinancesComponent
	 */
	public getSizeAmount() {
		const lIncome = Math.round(this.income).toString().length;
		const lExpense = Math.round(this.expense).toString().length;

		return {
			md: (lIncome > 5 && lIncome < 7) || (lExpense > 5 && lExpense < 7),
			sm: (lIncome > 7 && lIncome < 10) || (lExpense > 7 && lExpense < 10),
			xs: lIncome >= 10 || lExpense >= 10
		};
	}

	/**
	 * Manejo de datos para los input
	 *
	 * @param {SimpleChanges} changes
	 * @memberof MyFinancesComponent
	 */
	ngOnChanges(changes: SimpleChanges) {
		const credits: SimpleChange = changes.credits;
		const accounts: SimpleChange = changes.accounts;

		if (credits) {
			if (credits.currentValue) {
				this.totalBalanceTdc = credits.currentValue
					? credits.currentValue.total_balance
					: 0;
					
				if (credits.currentValue.keys.length !== 0) this.getCredits();
				this.flagTdd = credits.currentValue.keys.length === 0;
			}
		}

		if (accounts) {
			if (accounts.currentValue) {
				this.totalBalanceTdd = accounts.currentValue
					? accounts.currentValue.total_balance
					: 0;
				if (accounts.currentValue.keys.length !== 0) this.getAccounts();
				this.flagTdd = accounts.currentValue.keys.length === 0;
			}
		}
	}
}
