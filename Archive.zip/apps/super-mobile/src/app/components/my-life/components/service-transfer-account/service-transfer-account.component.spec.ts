import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { AppComponent } from './../../../../app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from 'apps/super-mobile/src/environments/environment.pre';
import { ErrorDialogComponent } from './../../../error-dialog/error-dialog.component';
import { IdpFakeViewComponent } from './../../../idp-fake-view/idp-fake-view.component';
import { MoreMainMenuViewComponent } from './../../../more-main-menu-view/more-main-menu-view.component';
import { AccesViewComponent } from './../../../access-view/access-view.component';
import { AppRoutingModule } from './../../../../app.routing.module';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	TagModule,
	DialogContentService,
	LoaderDialogService,
	TokenInputModule
} from '@santander/flame-component-library';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import {
	HttpClientModule,
	HTTP_INTERCEPTORS,
	HttpXhrBackend,
	XhrFactory
} from '@angular/common/http';
import { RouterModule, Router } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import {
	FlameCoreLibraryModule,
	AuthenticationService,
	CryptoService,
	GlobileHttpClient,
	IdpService,
	DataTransferService,
	ENV_CONFIG,
	ApiInterceptor,
	SERVICE_LOADER
} from '@santander/flame-core-library';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, APP_BASE_HREF, DatePipe } from '@angular/common';
import { globileHttpXhrBackendFactory } from '../../../../app.module';
import { MyLifeServices } from '../../services/my-life-services';
import { WINDOW_PROVIDERS } from 'libs/mobile/summary-operation-library/src/lib/services';
import { LOCALE_ID, SimpleChanges, SimpleChange } from '@angular/core';
import { MyLifeViewComponent } from '../../my-life-view/my-life-view.component';
import { BeneficiariesServicesViewComponent } from '../../../beneficiaries-services-view/beneficiaries-services-view.component';
import { MyLifeDeclarationComponents } from '../my-life-components';
import { of, throwError } from 'rxjs';
import { PaymentsCardsAndServicesService } from '../../services/payments-cards-services.service';
import { ServiceTransferAccountComponent } from './service-transfer-account.component';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { DialogClarificationsComponent } from '../../../more-main-menu-view/components/dialog-clarifications/dialog-clarifications.component';
import { DialogErrorMoreComponent } from '../../../more-main-menu-view/components/dialog-error-more/dialog-error-more.component';
import { DialogCloseLoginComponent } from '../../../more-main-menu-view/components/dialog-close-login/dialog-close-login.component';
import { TransactionDateFilterPipe } from '../../pipes/transactions-date-filter.pipe';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { SkeletonViewMoreComponent } from '../../../more-main-menu-view/components/skeleton-more-view/skeleton-view-more.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { ListButtonMoreComponent } from '../../../more-main-menu-view/components/list-button-more/list-button-more.component';

describe('ServiceTransferAccountComponent', () => {
	let component: ServiceTransferAccountComponent;
	let fixture: ComponentFixture<ServiceTransferAccountComponent>;
	let _paymentsCardsAndServicesService: any;
	let _dataTransferService: any;
	let _router: any;
	const changes = {
		inputKeyCardTdc: {
			currentValue: [
				{
					total_balance: {
						currency_code: 'MXN',
						amount: 69827.78
					},
					category_name: 'CHECKING_ACCOUNTS',
					keys: ['056722751246', '056722733565'],
					products: [
						{
							key: '056722751246',
							image_url: null,
							description: 'SUPER NOMINA',
							alias: null,
							display_number: '56*5124'
						},
						{
							key: '056722733565',
							image_url: '2517',
							description: 'SUPER NOMINA',
							alias: null,
							display_number: '56*3356'
						}
					]
				},
				{
					total_balance: {
						currency_code: 'MXN',
						amount: 85399.66
					},
					category_name: 'CREDIT_CARDS',
					keys: [
						'4e20fbb243684d9eb19ff33a50ee422e',
						'1b10lop243683d9eb19ff33a50ee345a'
					],
					products: [
						{
							key: '4e20fbb243684d9eb19ff33a50ee422e',
							image_url: '74110101010',
							description: 'BLACK',
							alias: null,
							display_number: '*3699'
						},
						{
							key: '1b10lop243683d9eb19ff33a50ee345a',
							image_url: '2517',
							description: 'SUPER NOMINA',
							alias: null,
							display_number: '*9981'
						}
					]
				}
			],
			firstChange: false
		}
	};
	const payeesFrequents = {
		data: [
			{
				key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
				account: {
					number: '5179921863843075',
					account_type: 'THIRDPARTY_DEBIT_CARD',
					bank: 'SCOTIABANK'
				},
				name: 'Jack Jacobs',
				alias: 'The Fourth',
				url: '/beneficiaries/{beneficiary-key}',
				personal_identifier: 'MARE921122HJKDLN01'
			},
			{
				key: 'otmn77lqcc111oblddj1rekjfk52vqe3',
				account: {
					number: '363042688497206369',
					account_type: 'CLABE',
					bank: 'SCOTIABANK'
				},
				name: 'Rosie Franklin',
				alias: 'Juris Doctor',
				url: '/beneficiaries/{beneficiary-key}',
				personal_identifier: ''
			},
			{
				key: '62k8i7sjq69rvxuueaduwagwnkvr3jjq',
				account: {
					number: '926321303849798078',
					account_type: 'CLABE',
					bank: 'SCOTIABANK'
				},
				name: 'Owen Saunders',
				alias: 'The Third',
				url: '/beneficiaries/{beneficiary-key}',
				personal_identifier: 'MARE921122HJKDLN01'
			},
			{
				key: '62k8i7sjq69rvxuueaduwagwnkvr3jjq',
				account: {
					number: '23456789045',
					account_type: 'SANTANDER_ACCOUNT',
					bank: 'SANTANDER'
				},
				name: 'Owen Saunders Maggy',
				alias: 'The Third Maggy',
				url: '/beneficiaries/{beneficiary-key}',
				personal_identifier: 'MARE921122HJKDLN01'
			}
		],
		notifications: [
			{
				level: 'WARNING',
				code: 'E422CDNPAYRCPTG001',
				message: 'Something happened.',
				timestamp: '2019-05-31T16:26:26.534Z'
			}
		],
		paging: {
			next_cursor_key: '10'
		}
	};
	const paymentServices = {
		data: [
			{
				key: '4e20fbb243684d9eb19ff33a50ee422e',
				agreement: '0245',
				name: 'TELCEL',
				type: 'TELEFONIA MOVIL',
				status: 'ACTIVE',
				image_url: '/image.png',
				last_operation_date: '14/11/19 15:33:11:01'
			},
			{
				key: 'f8wyl2o8didi3uvf104s1tksfi22bwwa',
				name: 'CFE',
				type: 'LUZ',
				status: 'ACTIVE',
				agreement: 4263,
				image_url: '/image.png',
				last_operation_date: '4/21/2100 6:25:42:602'
			},
			{
				key: 'b4s6u1r2akchmdfd9izkph4ru7lyzlii',
				name: 'Oriflame Mexico',
				type: 'GAS',
				status: 'ACTIVE',
				agreement: 1071,
				image_url: '/image.png',
				last_operation_date: '4/3/2064 23:54:1:413'
			},
			{
				key: 'px0s0urb2n44fs8d3vblsi2chyvut7xi',
				name: 'Axtel',
				type: 'CABLE, TELEFONO E INTERNET',
				status: 'ACTIVE',
				agreement: 4055,
				image_url: '/image.png',
				last_operation_date: '4/13/2026 19:54:50:308'
			}
		],
		notifications: [
			{
				code: 'E422CDNPAYRCPTG001',
				message: 'Something happened.',
				timestamp: '2019-02-16T23:38:45.408Z'
			}
		]
	};
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AppRoutingModule,
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				HttpClientModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				RouterModule,
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				FlameCoreLibraryModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
				TabModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				MyFinancesOperationLibraryModule,
				BeneficiaryOperationLibraryModule,
				PaymentsOperationLibraryModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				TokenInputModule,
				NgxPermissionsModule.forRoot()
			],
			declarations: [
				AccesViewComponent,
				AppComponent,
				MoreMainMenuViewComponent,
				BeneficiariesServicesViewComponent,
				IdpFakeViewComponent,
				ErrorDialogComponent,
				DialogClarificationsComponent,
				DialogErrorMoreComponent,
				DialogCloseLoginComponent,
				MyLifeViewComponent,
				MyLifeDeclarationComponents,
				TransactionDateFilterPipe,
				SkeletonViewMoreComponent,
				ListButtonMoreComponent
			],
			providers: [
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				DataTransferService,
				DatePipe,
				DialogContentService,
				ContactDialogService,
				LoaderDialogService,
				MyLifeServices,
				WINDOW_PROVIDERS,
				TransactionDateFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: environment
				},
				{
					provide: SERVICE_LOADER,
					useExisting: LoaderDialogService
				},
				{
					provide: HTTP_INTERCEPTORS,
					useClass: ApiInterceptor,
					multi: true
				},
				// {
				//  provide: HTTP_INTERCEPTORS,
				//  useClass: OauthInterceptor,
				//  multi: true
				// },
				{
					provide: HttpXhrBackend,
					useFactory: globileHttpXhrBackendFactory,
					deps: [XhrFactory]
				},
				{
					provide: LOCALE_ID,
					useValue: 'es-MX'
				},
				AuthenticationService,
				BeneficiaryService,
				CryptoService,
				GlobileHttpClient,
				IdpService,
				{
					provide: HttpXhrBackend,
					useFactory: globileHttpXhrBackendFactory,
					deps: [XhrFactory]
				},
				{
					provide: APP_BASE_HREF,
					useValue: '/'
				}
			]
		}).compileComponents();
	}));
	beforeEach(() => {
		fixture = TestBed.createComponent(ServiceTransferAccountComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		_paymentsCardsAndServicesService = TestBed.get(
			PaymentsCardsAndServicesService
		);
		_dataTransferService = TestBed.get(DataTransferService);
		_router = TestBed.get(Router);
	});
	it('should create', () => {
		expect(component).toBeTruthy();
	});
	// it('should call ngOnChanges', () => {
	// 	spyOn(
	// 		_paymentsCardsAndServicesService,
	// 		'getPayeesfrequent'
	// 	).and.returnValue( of ({}));
	// 	fixture.detectChanges();
	// 	component.ngOnChanges({
	// 		inputKeyCardTdc: new SimpleChange(
	// 			undefined,
	// 			changes.inputKeyCardTdc,
	// 			false
	// 		)
	// 	});
	// 	expect(_paymentsCardsAndServicesService.getPayeesfrequent).toBeTruthy();
	// });
	// it('should call services ', () => {
	// 	spyOn(
	// 		_paymentsCardsAndServicesService,
	// 		'getPayeesfrequent'
	// 	).and.returnValue( of (payeesFrequents));
	// 	spyOn(
	// 		_paymentsCardsAndServicesService,
	// 		'getPaymentsServices'
	// 	).and.returnValue( of (paymentServices));
	// 	fixture.detectChanges();
	// 	component.ngOnChanges({
	// 		inputKeyCardTdc: new SimpleChange(
	// 			undefined,
	// 			changes.inputKeyCardTdc,
	// 			false
	// 		)
	// 	});
	// 	expect(_paymentsCardsAndServicesService.getPayeesfrequent).toBeTruthy();
	// });

	it('should fail frequents ', () => {
		spyOn(
			_paymentsCardsAndServicesService,
			'getPayeesfrequent'
		).and.returnValue(
			throwError({
				status: 404
			})
		);
		fixture.detectChanges();
		component.ngOnChanges({
			inputKeyCardTdc: new SimpleChange(
				undefined,
				changes.inputKeyCardTdc,
				false
			)
		});
		expect(_paymentsCardsAndServicesService.getPayeesfrequent).toBeTruthy();
	});
	it('should fail getPaymentsServices ', () => {
		spyOn(
			_paymentsCardsAndServicesService,
			'getPayeesfrequent'
		).and.returnValue(of(payeesFrequents));
		spyOn(
			_paymentsCardsAndServicesService,
			'getPaymentsServices'
		).and.returnValue(
			throwError({
				status: 404
			})
		);
		fixture.detectChanges();
		component.ngOnChanges({
			inputKeyCardTdc: new SimpleChange(
				undefined,
				changes.inputKeyCardTdc,
				false
			)
		});
		expect(_paymentsCardsAndServicesService.getPayeesfrequent).toBeTruthy();
	});
	it('should select frecuente ', () => {
		spyOn(_dataTransferService, 'sendData').and.callThrough();
		const routerSpy = spyOn(_router, 'navigate').and.callFake(() => {});
		let infoObject = {};
		component.selectedFrecuent(infoObject, 'Payee');
		expect(routerSpy).toHaveBeenCalledWith(['/transfers/initial']);
		infoObject = {
			key: '1',
			color: '#ffffff',
			agreement: 'test',
			name: 'ServiceName',
			status: true
		};
		component.selectedFrecuent(infoObject, 'Service');
		expect(routerSpy).toHaveBeenCalledWith(['/payments/services/pay'], {
			queryParams: infoObject
		});
		infoObject = {};
		component.selectedFrecuent(infoObject, 'Card');
		expect(routerSpy).toHaveBeenCalledWith(['/payments/card-payments']);
	});
	it('should not call services', () => {
		spyOn(
			_paymentsCardsAndServicesService,
			'getPayeesfrequent'
		).and.returnValue(of({}));
		fixture.detectChanges();
		let newChanges = {
			...changes
		};
		newChanges.inputKeyCardTdc.currentValue = null;
		component.ngOnChanges({
			inputKeyCardTdc: new SimpleChange(
				undefined,
				newChanges.inputKeyCardTdc.currentValue,
				false
			)
		});
		newChanges = {
			...changes
		};
		newChanges.inputKeyCardTdc.currentValue = [];
		component.ngOnChanges({
			inputKeyCardTdc: new SimpleChange(
				undefined,
				newChanges.inputKeyCardTdc,
				false
			)
		});
		expect(component.showPayee).toBeFalsy();
	});
});
