import { InfoAccountsComponent } from './info-accounts/info-accounts.component';
import { ServiceTransferAccountComponent } from './service-transfer-account/service-transfer-account.component';
import { MyFinancesComponent } from './my-finances/my-finances.component';
import { DialogMessageComponent } from './dialog-message/dialog-message.component';

export const MyLifeDeclarationComponents = [
	InfoAccountsComponent,
	ServiceTransferAccountComponent,
	MyFinancesComponent,
	DialogMessageComponent
];

export const MyLifeEntryComponents = [DialogMessageComponent];
