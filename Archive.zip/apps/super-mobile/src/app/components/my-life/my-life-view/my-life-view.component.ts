import { Component, AfterViewInit, AfterContentInit } from '@angular/core';
import { TemplateModalThemeOverlayRef, DialogThemeViewService } from '../../dialog-theme-view';
import { SelectThemeComponent } from '../../select-theme/select-theme.component';
import { NgxPermissionsService } from 'ngx-permissions';
import { ThemeService } from '@santander/flame-component-library';
import { ModalThemeConfigInterface } from '../../dialog-theme-view/models/modal-theme-config.interface';

@Component({
	selector: 'sm-my-life-view',
	templateUrl: './my-life-view.component.html',
	styleUrls: ['./my-life-view.component.scss']
})
export class MyLifeViewComponent {
	constructor(
		private _dialogThemeViewService:DialogThemeViewService,
		private _permissionsService:NgxPermissionsService,
		private _themeService:ThemeService
	) {}
	keysAccounts: any;
	customers: any;
	credits: any;
	accounts: any;
	movements: any;
	showComponent: boolean;
	public pendingTDC: any = { amount: 0, currency_code: 'MXN' };

	setCustomers(evt: any) {
		this.customers = evt;
	}

	setCredits(evt: any) {
		this.credits = evt;
	}

	setAccounts(evt: any) {
		this.accounts = evt;
	}

	getMovements(evt: any) {
		this.movements = evt;
	}

	getPendingTDC(evt: any) {
		this.pendingTDC = evt;
	}

	onShowComponent(evt: any) {
		this.showComponent = evt;
	}

	/**
	 *
	 * Abre el dialogo para seleccion de tema de la app
	 *
	 * @memberof SummaryViewComponent
	 */

	// public openDialogTheme(): void {
	// 	const configDialogTheme: ModalThemeConfigInterface = {
	// 		title:'Selecciona un modo'
	// 	};
	// 	const ref: TemplateModalThemeOverlayRef = this._dialogThemeViewService.open(
	// 		SelectThemeComponent,
	// 		configDialogTheme
	// 	);
	// }


	// public ngAfterContentInit(){
	// 	// Settear flame por defecto y evitar el dark
	// 	// localStorage.setItem('theme', 'flame-foundation');
	// 	const theme = localStorage.getItem('theme');
	// 	const customer = JSON.parse(localStorage.getItem('customer'));
	// 	console.log(customer);
	// 	const permissions = this._permissionsService.getPermissions();
	// 	if (theme) {
	// 		this._themeService.setTheme(theme);
	// 		localStorage.setItem('theme', theme);
	// 	} else {
	// 		if (permissions.hasOwnProperty('R5')) {
	// 			this.openDialogTheme();
	// 		} else {
	// 			this._themeService.setTheme('flame-foundation');
	// 			localStorage.setItem('theme', 'flame-foundation');
	// 		}
	// 	}
	// }
}
