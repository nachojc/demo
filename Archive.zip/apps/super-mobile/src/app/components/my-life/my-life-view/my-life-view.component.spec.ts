import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TransactionDateFilterPipe } from './../pipes/transactions-date-filter.pipe';
import {
	ProductModule,
	AvatarModule,
	IconButtonModule,
	CardModule,
	DialogModule,
	ContactDialogService,
	TokenInputModule
} from '@santander/flame-component-library';
import { MyLifeViewComponent } from './my-life-view.component';
import { ServiceTransferAccountComponent } from '../components/service-transfer-account/service-transfer-account.component';
import { MyFinancesViewComponent } from '../../../../../../../libs/mobile/my-finances-operation-library/src/lib/views/my-finances-view/my-finances-view.component';
import { MyFinancesComponent } from '../components/my-finances/my-finances.component';
import { DialogMessageComponent } from '../components/dialog-message/dialog-message.component';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { MyLifeServices } from '../../my-life/services/my-life-services';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { environment } from 'apps/super-mobile/src/environments/environment.pre';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { DatePipe } from '@angular/common';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { NgxPermissionsModule } from 'ngx-permissions';
describe('MyLifeViewComponent', () => {
	let component: MyLifeViewComponent;
	let fixture: ComponentFixture<MyLifeViewComponent>;

	const infoAccount = {
		total_balance: 100,
		category_name: 'CHECKING_ACCOUNT',
		keys: ['12312321'],
		products: [
			{
				key: '12312321',
				image_url: '123',
				description: 'Santander',
				alias: 'Mi cuenta',
				display_number: '231*12'
			}
		]
	};

	const financesParams = {
		customer: {
			name: 'Juan',
			second_name: 'Perez',
			last_name: 'Lopez'
		},
		movements: [
			{
				amount: {
					amount: 10000,
					currency_code: 'MXN'
				},
				creation_date: '2017-11-10T11:02:44.00001',
				description: 'OTROS ABONOS',
				display_number: '56722733565',
				key: '101',
				product_key: '056722751246'
			}
		],
		products: [
			{
				alias: null,
				category_name: 'CHECKING_ACCOUNTS',
				description: 'SUPER NOMINA',
				display_number: '56*5124',
				due_date: undefined,
				image_url: null,
				key: '056722751246'
			}
		],
		movements_expenses: -5827.2699999999995,
		movements_income: 21983.160000000003,
		tdc_balance: {
			currency_code: 'MXN',
			amount: 85399.66
		},
		tdd_balance: {
			currency_code: 'MXN',
			amount: 69827.78
		}
	};
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			imports: [
				ProductModule,
				AvatarModule,
				IconButtonModule,
				CardModule,
				NgxSkeletonLoaderModule,
				HttpClientModule,
				DialogModule,
				RouterModule.forRoot([]),
				TokenInputModule,
				NgxPermissionsModule.forRoot()
			],
			declarations: [
				MyLifeViewComponent,
				ServiceTransferAccountComponent,
				MyFinancesComponent,
				MyFinancesViewComponent,
				DialogMessageComponent
			],
			providers: [
				MyLifeServices,
				DatePipe,
				ContactDialogService,
				TransactionDateFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: environment
				}
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(MyLifeViewComponent);
		component = fixture.componentInstance;

		fixture.detectChanges();
	});

	it('should create the component', () => {
		expect(component).toBeTruthy();
	});

	it('should access function', () => {
		component.setInfo(infoAccount);
		expect(component.keysAccounts).toBeTruthy();
		component.getMovements(financesParams);
		expect(component.movements).toBeTruthy();
		component.onShowComponent(true);
		expect(component.showComponent).toBeTruthy();
	});
});
