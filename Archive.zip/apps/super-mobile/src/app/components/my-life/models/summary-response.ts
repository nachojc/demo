/* tslint:disable */
import { Summary } from 'libs/mobile/summary-operation-library/src/lib/models/summary';
import { NotificationWrapper } from 'libs/mobile/summary-operation-library/src/lib/models/notification-wrapper';
import { Cursor } from 'libs/mobile/summary-operation-library/src/lib/models/cursor';
export interface SummaryResponse {
  data?: Array<Summary>;
  notifications?: Array<NotificationWrapper>;
  paging?: Cursor;
}