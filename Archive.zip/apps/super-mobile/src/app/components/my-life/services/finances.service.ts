import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { DatePipe } from '@angular/common';
import { Observable, of } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

@Injectable()
export class FinancesService {
	public transfers$: Observable<any> = null;
	public financesTransfers$: Observable<any> = null;

	public dates: any;
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient,
		private _datePipe: DatePipe
	) {}
	/**
	 * Obtiene la url con la versión correcta del servicio dependiendo del enviroment
	 *
	 * @private
	 * @returns string - url_base + '/' + version + '/'
	 * @memberof CreditsService
	 */
	private getUrlVersion(accounts = false) {
		if (accounts) {
			return this.environment.api.version.accounts === ''
				? `${this.environment.api.url}/`
				: `${this.environment.api.url}/${
						this.environment.api.version.accounts
				  }/`;
		}
		return this.environment.api.version.credits === ''
			? `${this.environment.api.url}/`
			: `${this.environment.api.url}/${this.environment.api.version.credits}/`;
	}

	/**
	 * Crea el periodo de fechas para consultar las transacciones de una tdc
	 * de acuerdo con la fecha de corte de la tarjeta
	 *
	 * @private
	 * @param {string} period
	 * @param {Date} today
	 * @param {string} dueDate
	 * @returns {*}
	 * @memberof CreditsService
	 */
	private transformPeriodCredit(
		period: string,
		today: Date,
		dueDate: string
	): any {
		//console.log(dueDate);

		const dateDue = new Date(dueDate);
		const dateDueCopy = new Date(dueDate);
		switch (period) {
			case 'sm-chip-actual': // Corte - 1 mes + 1 dia ---> Hoy ´
				// if (dateDue > today) {
				// }
				return {
					fromDate:
						// si la fecha de corte es la misma fecha que la del dia en que se consulta no se le suma un dia habil
						this._datePipe.transform(dueDate, 'yyyy-MM-dd') ===
						this._datePipe.transform(today, 'yyyy-MM-dd')
							? this._datePipe.transform(
									new Date(
										dateDue.getFullYear(),
										dateDue.getMonth() - 1,
										dateDue.getDate()
									),
									'yyyy-MM-ddTHH:mm:ss.SSSSSS',
									'UTC'
							  )
							: // la fecha es diferente a la fecha en la que se consulta; se le suma 1 dia
							  this._datePipe.transform(
									new Date(
										dateDue.getFullYear(),
										dateDue.getMonth() - 1,
										dateDue.getDate() + 1
									),
									'yyyy-MM-ddTHH:mm:ss.SSSSSS',
									'UTC'
							  ),
					toDate: this._datePipe.transform(
						today,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS',
						'UTC'
					)
				};
			case 'sm-chip-past': // Corte - 2 meses + 1 dia ---> Corte - 1 meses
				dateDueCopy.setMonth(dateDueCopy.getMonth() - 1);
				return {
					fromDate: this._datePipe.transform(
						new Date(
							dateDue.getFullYear(),
							dateDue.getMonth() - 2,
							dateDue.getDate() + 1
						),
						'yyyy-MM-ddTHH:mm:ss.SSSSSS',
						'UTC'
					),
					toDate: this._datePipe.transform(
						dateDueCopy,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS',
						'UTC'
					)
				};
			case 'sm-chip-previous': // Corte - 3 meses + 1 dia---> Corte - 2 meses
				dateDueCopy.setMonth(dateDueCopy.getMonth() - 2);
				return {
					fromDate: this._datePipe.transform(
						new Date(
							dateDue.getFullYear(),
							dateDue.getMonth() - 3,
							dateDue.getDate() + 1
						),
						'yyyy-MM-ddTHH:mm:ss.SSSSSS',
						'UTC'
					),
					toDate: this._datePipe.transform(
						dateDueCopy,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS',
						'UTC'
					)
				};
			default:
				return {
					fromDate: 2,
					toDate: 2
				};
		}
	}

	/**
	 * Crea el periodo de fechas para consultar las transacciones de una cuenta
	 *
	 * @private
	 * @param {string} period
	 * @param {Date} fromDate
	 * @param {Date} toDate
	 * @returns {*}
	 * @memberof CreditsService
	 */
	private transformPeriod(period: string, fromDate: Date, toDate: Date): any {
		switch (period) {
			case 'sm-chip-actual':
				const _to_date = new Date(toDate.getFullYear(), toDate.getMonth() + 1, 0)
				_to_date.setDate(_to_date.getDate() +1);
				_to_date.getDay() === 0 ? _to_date.setDate(_to_date.getDate() +1): _to_date.getDay() === 6 ? _to_date.setDate(_to_date.getDate()+2) : _to_date;
				return {
					fromDate: new Date(fromDate.getFullYear(), fromDate.getMonth(), 1),
					toDate: _to_date
				};
			case 'sm-chip-past':
				const _to_date_past = new Date(toDate.getFullYear(), toDate.getMonth(), 0)
				_to_date_past.setDate(_to_date_past.getDate() +1);
				_to_date_past.getDay() === 0 ? _to_date_past.setDate(_to_date_past.getDate() +1): _to_date_past.getDay() === 6 ? _to_date_past.setDate(_to_date_past.getDate()+2) : _to_date_past;
				return {
					fromDate: new Date(
						fromDate.getFullYear(),
						fromDate.getMonth() - 1,
						1
					),
					toDate: _to_date_past
				};
			case 'sm-chip-previous':
				const _to_date_previous = new Date(toDate.getFullYear(), toDate.getMonth() -1 , 0)
				_to_date_previous.setDate(_to_date_previous.getDate() +1);
				_to_date_previous.getDay() === 0 ? _to_date_previous.setDate(_to_date_previous.getDate() +1): _to_date_previous.getDay() === 6 ? _to_date_previous.setDate(_to_date_previous.getDate()+2) : _to_date_previous;	
				return {
					fromDate: new Date(
						fromDate.getFullYear(),
						fromDate.getMonth() - 2,
						1
					),
					toDate: _to_date_previous
				};
			default:
				return {
					fromDate: fromDate,
					toDate: toDate
				};
		}
	}

	/**
	 * Obtiene el summary de credits con los datos que necesita
	 * el resumen de TDC
	 * Interfaz que implementa para la respuesta - `ResponseListCredits`
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getCredits(limit: string = '10') {
		const params = new HttpParams().set('limit', limit);
		return this._httpClient
			.get(`${this.getUrlVersion()}credits`, { params })
			.pipe(
				mergeMap((response: any) => {
					response.data = response.data.filter((itemResponse: any) => {
						return itemResponse.related_cards[0].relation_type === 'Primary';
					});
					response.data.forEach(item => {
						// se multiplica por -1 para invertir los signos
						item.balance.amount = item.balance.amount * -1;
					});
					return of(response);
				})
			);
	}

	/**
	 * Obtiene los movimientos de una cuenta o de una TDC
	 * Interfaz que implementa para la respuesta - `TransactionsResponse`
	 *
	 * @param {string} key - Key de la TDC
	 * @param {string} [limit='5'] - Parametro opcional, por default = 5
	 * @param {boolean} isAccount - Indica si es una cuenta o una tdc
	 * @param {string} [cursor] - Cursor de paginación para obtener más
	 * @param {string} [period] - Periodo (actual, pasado, anterior)
	 * @param {string} [dueDate] - Fecha de corte de la tarjeta
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getTransactions(
		key: string,
		limit: string = '5',
		isAccount: boolean,
		cursor?: string,
		period?: string,
		dueDate?: string
	) {
		let params = new HttpParams();

		if (period !== undefined && cursor !== undefined) {
			this.dates = isAccount
				? this.transformPeriod(period, new Date(), new Date())
				: this.transformPeriodCredit(period, new Date(), dueDate);
			if (isAccount) {
				params = params
					.set('cursor', cursor)
					.set('limit', limit)
					.set('from_date', this.dates.fromDate.toISOString().slice(0, 10))
					.set('to_date', this.dates.toDate.toISOString().slice(0, 10));
			}
		}
		return this._httpClient.get(
			isAccount
				? `${this.getUrlVersion(true)}accounts/${key}/transactions`
				: `${this.getUrlVersion()}credits/${key}/transactions`,
			{
				params: isAccount
					? params
					: {
							cursor: cursor,
							limit: limit,
							from_date: this.dates.fromDate,
							to_date: this.dates.toDate
					  }
			}
		);
	}

	/**
	 * Obtiene el detalla de un movimiento de una cuenta de debito
	 * Interfaz que implementa para la respuesta - `TransactionDetailResponse`
	 * @param {string} key
	 * @param {string} transactionKey
	 * @returns
	 * @memberof FinancesService
	 */
	getDebitTransactionDetail(key: string, transactionKey: string) {
		return this._httpClient.get(
			`${this.getUrlVersion(
				true
			)}accounts/${key}/transactions/${transactionKey}`
		);
	}

	/**
	 * Obtiene el detalle de un movimiento de una TDC
	 * Interfaz que implementa para la respuesta - `TransactionDetailResponse`
	 * @param key - Key de una TDC
	 * @param keyTrans - Key del movimiento a obtener
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof FinancesService
	 */
	getTransactionDetail(key: string, keyTrans: string) {
		return this._httpClient.get(
			`${this.getUrlVersion()}credits/${key}/transactions/${keyTrans}`
		);
	}

	/**
	 * Cambia el estado de los observables a null
	 * @memberof FinancesService
	 */
	public resetObservables() {
		this.financesTransfers$ = null;
		this.transfers$ = null;
	}
}
