import { Injectable, Inject } from '@angular/core';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { mergeMap } from 'rxjs/operators';

@Injectable()
export class AccountLyfeService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient
	) {}

	public account$: Observable<any> = null;
	public statusCards$: Observable<any> = null;
	public creditCards$: Observable<any> = null;

	private _urlCards =
				this.environment.api.version.cards === ''
				? `${this.environment.api.url}/cards`
				: `${this.environment.api.url}/${this.environment.api.version.cards}/cards`;
	private _urlAccounts =
				this.environment.api.version.accounts === ''
				? `${this.environment.api.url}/accounts`
				: `${this.environment.api.url}/${this.environment.api.version.accounts}/accounts`;
	private _urlCredits =
				this.environment.api.version.credits === ''
				? `${this.environment.api.url}/credits`
				: `${this.environment.api.url}/${this.environment.api.version.credits}/credits`;

	/**
	 * obtiene todas las tarjetas de debito
	 *
	 * @memberof AccountLyfeService
	 */
	getAccountsCards(cursor: any, limit: any): Observable<any> {
		const params = new HttpParams()
		.set('cursor', cursor ? cursor.toString(): '0')
    .set('limit', limit ? limit.toString() : '10');
		return this._httpClient.get(this._urlAccounts, {
			params: params
		});
	}

	/**
	 * obtiene todas las tarjetas de credito
	 *
	 * @memberof AccountLyfeService
	 */
	getCreditsCard(cursor?: any, limit?: any) {
		const params = new HttpParams()
		.set('cursor', cursor ? cursor.toString(): '0')
    .set('limit', limit ? limit.toString() : '10');
		return this._httpClient.get(this._urlCredits, {
			params: params
		}).pipe(
			mergeMap((response: any)=> {
				response.data = response.data.filter((itemResponse: any) => {
					return itemResponse.related_cards[0].relation_type === 'Primary';
				});
				response.data.forEach(item => {
					// se multiplica por -1 para invertir los signos
					item.balance.amount = item.balance.amount * -1
				})
				return of(response)
			})
		)
	}

	getStatusCard(cursor: string) {
		const params = new HttpParams().set('cursor', cursor).set('limit', '10');
		return this._httpClient.get(this._urlCards, {
			params: params
		});
	}
}
