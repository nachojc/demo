import { AccountLyfeService } from './accounts-lyfe.service';
import { PaymentsCardsAndServicesService } from './payments-cards-services.service';
import { FinancesService } from './finances.service';

export const MyLifeServices = [
	AccountLyfeService,
	PaymentsCardsAndServicesService,
	FinancesService
];
