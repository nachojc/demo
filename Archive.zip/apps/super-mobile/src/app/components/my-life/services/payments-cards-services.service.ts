import { catchError, mergeMap } from 'rxjs/operators';
import { forkJoin, of, Observable, throwError, EMPTY } from 'rxjs';
import { Injectable, Inject } from '@angular/core';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';

@Injectable()
export class PaymentsCardsAndServicesService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient
	) { }

	public payeeFrequents$: Observable<any> = null;
	public services$: Observable<any> = null;

	private _urlPayments =
		this.environment.api.version.payments === ''
			? `${this.environment.api.url}/payments`
			: `${this.environment.api.url}/${
			this.environment.api.version.payments
			}/payments`;
	private _urlBeneficiary =
		this.environment.api.version.transfers === ''
			? `${this.environment.api.url}/transfers/payees`
			: `${this.environment.api.url}/${
			this.environment.api.version.transfers
			}/transfers/payees`;
	private _urlBillers =
		this.environment.api.version.payments === ''
			? `${this.environment.api.url}/payments/billers`
			: `${this.environment.api.url}/${
			this.environment.api.version.payments
			}/payments/billers`;

	/**
	 * Obtiene todos los servicios disponibles para el cliente
	 *
	 * @returns
	 * @memberof PaymentsCardsAndServicesService
	 */
	getPaymentsServices() {
		return this._httpClient.get(this._urlBillers);
	}

	getPayeesfrequent(cursor?: any, limit?: any) {
		const params = new HttpParams()
			.set('cursor', cursor ? cursor.toString() : '0')
			.set('limit', limit ? limit.toString() : '10');
		return this._httpClient.get(this._urlBeneficiary, {
			params: params
		}).pipe(
			mergeMap((response: any) => {
				response.data = response.data.filter((item: any) => {
					// se filtra para retornar solo cuenta, tdd, numero de telefono y clabe
					// se discrimina TDC(mismo banco-otros bancos)
					return item.account.account_type !== 'THIRDPARTY_SANTANDER_CREDIT_CARD' && item.account.account_type !== 'INTERBANK_CREDIT_CARD'
				})
				return of(response);
			}),
			catchError((error) => {
				this.payeeFrequents$ = undefined;
				return throwError(error)
			})
		);
	}

	/**
	 * Obtiene las tarjetas de terceros dadas de alta.
	 *
	 * @param {*} body
	 * @returns
	 * @memberof PaymentsCardsAndServicesService
	 */
	public initializePaymentThirdsTDC(body: any = { payee_key: '' }) {
		let headers = new HttpHeaders();
		headers = headers.set('Content-Type', 'application/json');
		return this._httpClient.post(
			`${this._urlPayments}/third-parties`,
			JSON.stringify({ body }),
			{ headers: headers }
		);
	}

	/**
	 * Une las llamadas de los 2 servicios en un forkJoin
	 *
	 * @returns
	 * @memberof PaymentsCardsAndServicesService
	 */
	public getPaymentsAndServices() {
		const services = this.getPaymentsServices().pipe(
			catchError(error => {
				this.services$ = undefined
				return of({})
			})
		);
		const payments = this.initializePaymentThirdsTDC().pipe(
			catchError(error => {
				this.services$ = undefined
				return of({})
			})
		);

		return forkJoin([services, payments]);
	}
}
