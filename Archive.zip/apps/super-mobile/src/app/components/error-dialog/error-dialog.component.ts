import { Component } from '@angular/core';

/**
 * cuerpo del dialog de error
 *
 * @export
 * @class ErrorDialogComponent
 */
@Component({
	selector: 'sm-error-dialog',
	templateUrl: './error-dialog.component.html',
	styleUrls: ['./error-dialog.component.scss']
})
export class ErrorDialogComponent {
	/**
	 * data de componte donde se intancia.
	 *
	 * @type {*}
	 * @memberof ErrorDialogComponent
	 */
	public data: any;
}
