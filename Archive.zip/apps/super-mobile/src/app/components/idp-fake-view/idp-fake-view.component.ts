import { Component } from '@angular/core';
import { TemplateModalOverlayRef } from '@santander/flame-component-library';

@Component({
	selector: 'sm-idp-fake-view',
	templateUrl: './idp-fake-view.component.html',
	styleUrls:['./idp-fake-view.component.scss']
})

export class IdpFakeViewComponent {
	constructor(public dialog: TemplateModalOverlayRef) {}
	public onClose(result: boolean) {
		if (result) {
			this.dialog.close(true);
		} else {
			this.dialog.close(false);
		}
	}
}
