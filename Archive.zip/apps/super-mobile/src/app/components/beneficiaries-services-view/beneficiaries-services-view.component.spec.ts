import { BillersResponse } from 'libs/mobile/payments-operation-library/src/lib/models';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { MyLifeViewComponent } from './../my-life/my-life-view/my-life-view.component';
import { MyLifeDeclarationComponents } from './../my-life/components/my-life-components';
import { BeneficiaryService } from 'libs/mobile/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { AppComponent } from './../../app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { environment } from 'apps/super-mobile/src/environments/environment.pre';
import { ErrorDialogComponent } from './../error-dialog/error-dialog.component';
import { IdpFakeViewComponent } from './../idp-fake-view/idp-fake-view.component';
import { MoreMainMenuViewComponent } from './../more-main-menu-view/more-main-menu-view.component';
import { AccesViewComponent } from './../access-view/access-view.component';
import { AppRoutingModule } from './../../app.routing.module';
import { BeneficiaryOperationLibraryModule } from 'libs/mobile/beneficiary-operation-library/src/lib/beneficiary-operation-library.module';
import {
	ButtonModule,
	SlideToggleModule,
	IconButtonModule,
	CardModule,
	CarouselModule,
	FlameFoundationTheme,
	IconModule,
	NavbarModule,
	SpinnerModule,
	ThemeModule,
	TopBarModule,
	FormFieldModule,
	InputModule,
	EmojiModule,
	TabsModule,
	TabModule,
	ProductModule,
	ChipModule,
	AvatarModule,
	SearchBarModule,
	DialogModule,
	TokenDialogModule,
	ContactDialogModule,
	DialogContentModule,
	ContactDialogService,
	LoaderOverlayModule,
	DarkTheme,
	TagModule,
	TokenInputModule,
	LoaderOverlayService,
	CardNumberModule,
	HiddenButtonsModule
} from '@santander/flame-component-library';
import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed,
	inject
} from '@angular/core/testing';
import { BeneficiariesServicesViewComponent } from './beneficiaries-services-view.component';
import { PaymentsOperationLibraryModule } from 'libs/mobile/payments-operation-library/src/lib/payments-operation-library.module';
import {
	HTTP_INTERCEPTORS,
	HttpXhrBackend,
	XhrFactory,
	HttpRequest
} from '@angular/common/http';
import { RouterModule, ActivatedRoute } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import {
	FlameCoreLibraryModule,
	AuthenticationService,
	CryptoService,
	GlobileHttpClient,
	IdpService,
	DataTransferService,
	ENV_CONFIG,
	ApiInterceptor,
	SuperTokenService,
	CustomerService
} from '@santander/flame-core-library';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { globileHttpXhrBackendFactory } from '../../app.module';
import { ScrollMovementsDirective } from '../../../../../../libs/mobile/my-finances-operation-library/src/lib/directives/scroll-movements-directive';
import { ChartDirective } from '../../../../../../libs/mobile/my-finances-operation-library/src/lib/directives/chart-directive';
import { NgxSkeletonLoaderModule } from 'ngx-skeleton-loader';
import { MyFinancesOperationLibraryModule } from 'libs/mobile/my-finances-operation-library/src/lib/my-finances-operation-library.module';
import { TransactionDateFilterPipe } from '../my-life/pipes/transactions-date-filter.pipe';
import { SkeletonViewMoreComponent } from '../more-main-menu-view/components/skeleton-more-view/skeleton-view-more.component';
import { NgxPermissionsModule } from 'ngx-permissions';
import { SuperTokenDialogService } from '../supertoken-dialog/supertoken-dialog.service';
import { InitialServicesViewComponent } from 'libs/mobile/payments-operation-library/src/lib/views/payment-services-view/payment-services-process/initial-view/initial-services-view.component';
import { PayeesContainerComponent } from 'libs/mobile/beneficiary-operation-library/src/lib/views/payees-container/payees-container.component';
import { BeneficiaryFilterPipe } from 'libs/mobile/beneficiary-operation-library/src/lib/pipes/beneficiary-filter.pipe';
import { PayeesPipe } from 'libs/mobile/payments-operation-library/src/lib/pipes/filter-payees-search.pipe';
import { PaymentRecieptComponent } from 'libs/mobile/payments-operation-library/src/lib/views/payment-reciept/payment-reciept.component';
import { SuperTokenDialogAbstractionComponent } from '../supertoken-dialog/dialog-abstraction/dialog-abstraction.component';
import { ConfirmPayeeDialogViewComponent } from 'libs/mobile/beneficiary-operation-library/src/lib/components/confirm-dialog-view/confirm-dialog-view.component';
import { SummaryService } from 'libs/mobile/summary-operation-library/src/lib/services';
import { PaymentsService } from 'libs/mobile/payments-operation-library/src/lib/services/payments.service';
import { ServiceAvatarComponent } from 'libs/mobile/payments-operation-library/src/lib/components/service-avatar/service-avatar.component';
import { SubFilterPipe } from 'libs/mobile/payments-operation-library/src/lib/pipes/sub-filter.search.pipe';
import { SectionServiceComponent } from 'libs/mobile/payments-operation-library/src/lib/components/section-service/section-service.component';
import { FilterPipe } from 'libs/mobile/payments-operation-library/src/lib/pipes/filter-search.pipe';
import { CardNumberPipe } from 'libs/core/flame-component-library/src/lib/pipes/card-number/card-number.pipe';
import { SkeletonPayeeViewComponent } from 'libs/mobile/beneficiary-operation-library/src/lib/components/skeleton-payee-view/skeleton-payee-view.component';
import { NgxMaskModule } from 'ngx-mask';
import { DialogPaymentsNoConnectionComponent } from 'libs/mobile/payments-operation-library/src/lib/views/payment-services-view/dialog-payments-no-connection/dialog-payments-no-connection.component';
import { DialogPaymentsServiceComponent } from 'libs/mobile/payments-operation-library/src/lib/views/payment-services-view/dialog-payments-service/dialog-payments-service.component';
import { DialogPaymentsLowServiceComponent } from 'libs/mobile/payments-operation-library/src/lib/views/payment-services-view/dialog-payments-low-service/dialog-payments-low-service.component';
import {
	HttpTestingController,
	HttpClientTestingModule
} from '@angular/common/http/testing';
import { Injector } from '@angular/core';
import { of } from 'rxjs';

const dataService: BillersResponse = {
	data: [
		{
			key: 'pdtacvdomclxrbtjpzccff4d1xis3w9i',
			name: 'Agua y Dre de Mty|Company S.A. de C.V.',
			type: 'AGUA',
			status: 'ACTIVE',
			agreement: '1266',
			image_url: '/image.png',
			last_operation_date: '7/31/2037 17:23:17:10',
			color: '#003d75'
		},
		{
			key: 'b4s6u1r2akchmdfd9izkph4ru7lyzlii',
			name: 'Oriflame Mexico|',
			type: 'GAS',
			status: 'ACTIVE',
			agreement: '1071',
			image_url: '/image.png',
			last_operation_date: '4/3/2064 23:54:1:413',
			color: '#ffc72c'
		},
		{
			key: 'yxrn7fucr57e3bkqa7yavhpp90stu9fn1',
			name: 'Metrogas|',
			type: 'LUZ',
			status: 'CANCELED',
			agreement: '2605',
			image_url: '/image.png',
			last_operation_date: '1/31/2070 0:55:26:804',
			color: '#e57200'
		},
		{
			key: 'g7pu3klpulaiyvefbsfp9gyzry1fs04v',
			name: 'Maxcom|Company S.A. de C.V.',
			type: 'CABLE, TELEFONO E INTERNET',
			status: 'CANCELED',
			agreement: '1859',
			image_url: '/image.png',
			last_operation_date: '4/3/2078 10:30:20:812',
			color: '#e31d19'
		},
		{
			key: '2m1sp1yp3f6znenoyx8orxgubd4klssy',
			name: 'Sky|Company S.A. de C.V.',
			type: 'ESTABLECIMIENTOS',
			status: 'PENDING',
			agreement: '6030',
			image_url: '/image.png',
			last_operation_date: '2/10/2094 6:15:18:126',
			color: '#274a88'
		},
		{
			key: '2m1sp1yp3f6znenoyx8orxgubd4klssy1',
			name: 'ATT (IUSA)|',
			type: 'TELEFONIA MOVIL',
			status: 'PENDING',
			agreement: '6000',
			image_url: '/image.png',
			last_operation_date: '2/10/2094 6:15:18:126',
			color: '#0568AE'
		},
		{
			key: '2m1sp1yp3f6znenoyx8orxgubd4klssy1',
			name: 'ATT (IUSA)|',
			type: 'SIN CATEGORIA',
			status: 'PENDING',
			agreement: '6000',
			image_url: '/image.png',
			last_operation_date: '2/10/2094 6:15:18:126',
			color: '#0568AE'
		}
	],
	notifications: [
		{
			code: 'SUCCESS',
			message: 'Something is happening',
			timestamp: '2019-02-16T23:38:45.408Z'
		}
	]
};

const mockSummaryList = {
	data: [
		{
			key: '056722751246',
			display_number: '00*384',
			alias: 'MI SUPER NOMINA',
			url: '/accounts/{key}',
			image_url: '2517',
			balance: {
				amount: 98918.5,
				currency_code: 'MXN'
			}
		},
		{
			key: '056722733565',
			display_number: '0*484',
			alias: 'MI CUENTA PRINCIPAL',
			url: '/accounts/{key}',
			image_url: '2523',
			balance: {
				amount: 12122.5,
				currency_code: 'MXN'
			}
		},
		{
			key: '056722733565',
			display_number: '0*484',
			alias: 'MI CUENTA PRINCIPAL',
			url: '/accounts/{key}',
			image_url: '74110101010',
			balance: {
				amount: 12423.5,
				currency_code: 'MXN'
			}
		},
		{
			key: '056722751246',
			display_number: '00*384',
			alias: 'MI SUPER NOMINA',
			url: '/accounts/{key}',
			image_url: '2517',
			balance: {
				amount: 0,
				currency_code: 'MXN'
			}
		},
		{
			key: '056722751246',
			display_number: '00*384',
			alias: 'MI SUPER NOMINA',
			url: '/accounts/{key}',
			image_url: '2517',
			balance: {
				amount: 12,
				currency_code: 'USD'
			}
		}
	],
	paging: {
		next_cursor_key: '10'
	}
};
const creditsSummary = {
	data: [
		{
			key: '4e20fbb243684d9eb19ff33a50ee422e',
			name: 'Aeromexico Blanca',
			alias: 'Rosa Marias Olvera/BPYTE',
			status: 'ACTIVE',
			balance: {
				amount: 1812.1,
				currency_code: 'MXN'
			},
			related_cards: [
				{
					display_number: '************3699',
					relation_type: 'Primary',
					expiration_date: '05/22',
					url: '/cards/{card-key}'
				}
			],
			display_number: '************3699',
			statement_balance: {
				amount: 50000,
				currency_code: 'MXN'
			},
			minimum_payment: {
				amount: 0,
				currency_code: 'MXN'
			},
			due_date: '2019-04-08T00:00:00'
		},
		{
			key: '1b10lop243683d9eb19ff33a50ee345a',
			name: 'Mastercard Empresarial',
			alias: 'Rosa Marias Olvera/BPYTE',
			status: 'BLOCKED',
			balance: {
				amount: -22038.1,
				currency_code: 'MXN'
			},
			related_cards: [
				{
					display_number: '************9981',
					relation_type: 'Primary',
					expiration_date: '08/22',
					url: '/card/{card-key}'
				}
			],
			display_number: '************9981',
			statement_balance: {
				amount: 8000,
				currency_code: 'MXN'
			},
			minimum_payment: {
				amount: 310,
				currency_code: 'MXN'
			},
			due_date: '2019-04-08T00:00:00'
		}
	],
	notifications: [
		{
			code: 'E422CDNPAYRCPTG001',
			message: 'Something is invalid',
			timestamp: '2019-02-12T20:07:18.639Z'
		}
	],
	paging: {
		next_cursor_key: '10'
	}
};

const mockBeneficiaryList = {
	data: [
		{
			key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
			account: {
				number: '56*5124',
				account_type: 'THIRDPARTY_SANTANDER_MOBILE_ACCOUNT',
				bank: 'SCOTIABANK'
			},
			name: 'Jack Jacobs',
			alias: 'The Fourth',
			url: '/beneficiaries/{beneficiary-key}',
			personal_identifier: 'MARE921122HJKDLN01',
			account_type: 'THIRDPARTY_SANTANDER_MOBILE_ACCOUNT'
		},
		{
			key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
			account: {
				number: '56*5124',
				account_type: 'INTERBANK_DEBIT_CARD',
				bank: 'SCOTIABANK'
			},
			name: 'Jack Jacobs',
			alias: 'The Fourth',
			url: '/beneficiaries/{beneficiary-key}',
			personal_identifier: 'MARE921122HJKDLN01'
		}
	],
	notifications: [
		{
			level: 'WARNING',
			code: 'E422CDNPAYRCPTG001',
			message: 'Something happened.',
			timestamp: '2019-05-31T16:26:26.534Z'
		}
	],
	paging: {
		next_cursor_key: '10'
	}
};

describe('BeneficiariesServicesViewComponent', () => {
	let component: BeneficiariesServicesViewComponent;
	let fixture: ComponentFixture<BeneficiariesServicesViewComponent>;
	let httpMock: HttpTestingController;
	let injector: TestBed;
	let route: ActivatedRoute;
	const urlBillers = 'http://localhost:3000/api/payments/billers';
	const urlPayees = 'http://localhost:3000/api/transfers/payees';
	const urlSettings = 'http://localhost:3000/api/customers/me/settings';
	const urlCredits = 'http://localhost:3000/api/credits';
	const urlAccounts = 'http://localhost:3000/api/accounts';
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				BrowserAnimationsModule,
				BrowserModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				ChipModule,
				CommonModule,
				ContactDialogModule,
				FormFieldModule,
				HttpClientTestingModule,
				IconModule,
				InputModule,
				NavbarModule,
				ProductModule,
				RouterModule.forRoot([]),
				SearchBarModule,
				SlideToggleModule,
				IconButtonModule,
				ReactiveFormsModule,
				SpinnerModule,
				TagModule,
				DialogModule,
				DialogContentModule,
				TabsModule,
				TabModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TopBarModule,
				EmojiModule,
				TokenDialogModule,
				LoaderOverlayModule,
				TagModule,
				NgxSkeletonLoaderModule,
				TokenInputModule,
				NgxPermissionsModule.forRoot(),
				NgxMaskModule.forRoot(),
				CardNumberModule,
				HiddenButtonsModule,
				RouterModule
			],
			declarations: [
				BeneficiariesServicesViewComponent,
				InitialServicesViewComponent,
				PayeesContainerComponent,
				BeneficiaryFilterPipe,
				ConfirmPayeeDialogViewComponent,
				SuperTokenDialogAbstractionComponent,
				PaymentRecieptComponent,
				PayeesPipe,
				ServiceAvatarComponent,
				SubFilterPipe,
				SectionServiceComponent,
				FilterPipe,
				SkeletonPayeeViewComponent,
				DialogPaymentsNoConnectionComponent,
				DialogPaymentsServiceComponent,
				DialogPaymentsLowServiceComponent
			],
			providers: [
				PaymentsService,
				CustomerService,
				LoaderOverlayService,
				SummaryService,
				BeneficiaryService,
				DataTransferService,
				ContactDialogService,
				SuperTokenService,
				SuperTokenDialogService,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api',
							version: {
								summary: '',
								accounts: '',
								credits: '',
								cards: '',
								transfers: '',
								payments: '',
								customers: ''
							}
						}
					}
				},
				{ provide: Injector, useValue: {} },
				{ provide: APP_BASE_HREF, useValue: '/' }
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [
					ConfirmPayeeDialogViewComponent,
					SuperTokenDialogAbstractionComponent,
					DialogPaymentsNoConnectionComponent,
					DialogPaymentsServiceComponent,
					DialogPaymentsLowServiceComponent
				]
			}
		});

		injector = getTestBed();
		httpMock = injector.get(HttpTestingController);
		route = injector.get(ActivatedRoute);
		route.queryParams = of({ showPayeesTab: 'true' });
	}));

	beforeEach(done => {
		fixture = TestBed.createComponent(BeneficiariesServicesViewComponent);
		component = fixture.componentInstance;

		const requestPay = httpMock.expectOne(urlBillers);
		expect(requestPay.request.method).toEqual('GET');
		expect(requestPay.request.responseType).toEqual('json');
		requestPay.flush(dataService);
		fixture.detectChanges();

		const requestPayees = httpMock.expectOne(
			(req: HttpRequest<any>) =>
				req.urlWithParams === `${urlPayees}?cursor=0&limit=10`
		);
		expect(requestPayees.request.method).toEqual('GET');
		expect(requestPayees.request.responseType).toEqual('json');
		requestPayees.flush(mockBeneficiaryList);
		fixture.detectChanges();

		const request = httpMock.expectOne(
			(req: HttpRequest<any>) =>
				req.urlWithParams === `${urlAccounts}?cursor=0&limit=10`
		);
		expect(request.request.method).toEqual('GET');
		expect(request.request.responseType).toEqual('json');
		request.flush(mockSummaryList);

		const requestCredits = httpMock.expectOne(
			(req: HttpRequest<any>) =>
				req.urlWithParams === `${urlCredits}?cursor=0&limit=10`
		);
		expect(requestCredits.request.method).toEqual('GET');
		expect(requestCredits.request.responseType).toEqual('json');
		requestCredits.flush(creditsSummary);

		fixture.detectChanges();

		done();
	});

	afterEach(() => {
		httpMock.verify();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('Should open contact phone dialog', inject(
		[ContactDialogService],
		(contactDialog: ContactDialogService) => {
			spyOn(contactDialog, 'openDialogContact');
			component.openPhoneDialog();
			fixture.whenStable().then(() => {
				expect(contactDialog.openDialogContact).toHaveBeenCalled();
			});
			fixture.detectChanges();
		}
	));

	it('should change tabs ', () => {
		component.checkClickedTab('Servicios');
		expect(component.showPayeesTab).toBe(false);
		component.checkClickedTab('Contactos');
		expect(component.showPayeesTab).toBe(true);
	});
});
