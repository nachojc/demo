import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { ContactDialogService } from '@santander/flame-component-library';
import { BackButtonService, NavigationBackHelperService } from '@santander/flame-core-library';

@Component({
	selector: 'sm-beneficiaries-services-view',
	templateUrl: './beneficiaries-services-view.component.html',
	styleUrls: ['./beneficiaries-services-view.component.scss']
})
export class BeneficiariesServicesViewComponent implements OnInit, OnDestroy {
	/**
	 *Creates an instance of BeneficiariesServicesViewComponent.
	 * @param {ContactDialogService} _contactDialogService
	 * @param {NavigationBackHelperService} _router
	 * @param {ActivatedRoute} _route
	 * @param {Location} _location
	 * @param {BackButtonService} _backButtonService
	 * @memberof BeneficiariesServicesViewComponent
	 */
	constructor(
		private _contactDialogService: ContactDialogService,
		private _router: NavigationBackHelperService,
		private _route: ActivatedRoute,
		private _location: Location,
		private _backButtonService: BackButtonService
	) {
		this._backButtonService.manageBackButtonEvent( () =>
			this.navigateBack()
		);
	}

	/**
	 * variable privada
	 *
	 * @private
	 * @type {Subscription}
	 * @memberof BeneficiariesServicesViewComponent
	 */
	private subscription: Subscription = new Subscription();

	/*
	 * Variables publicas
	 */
	public isOpenContact: boolean;
	public isConfirmedToken = false;
	public showPayeesTab = true;

	/**
	 * Permite seleccionar un tab para abrir el token si se selecciona la opción Contactos
	 *
	 * @param {string} textTab
	 * @memberof BeneficiariesServicesViewComponent
	 */
	public checkClickedTab(textTab: string): void {
		// Valida por medio del texto
		const showTab =
			textTab === 'Contactos'
				? true
				: textTab === 'Servicios'
				? false
				: this.showPayeesTab;
		if (showTab !== this.showPayeesTab) { // Se actualiza solo si hay un cambio
			this.showPayeesTab = showTab;
			const urlTree = this._router.createUrlTree([], {
				queryParams: { showPayeesTab: this.showPayeesTab },
				queryParamsHandling: 'merge',
				preserveFragment: true
			});
			this._location.go(urlTree.toString());
		}
	}

	/**
	 * Abre el dialogo de contacto.
	 *
	 * @memberof BeneficiariesServicesViewComponent
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(1);
	}

	/**
	 * Navigation back
	 *
	 * @memberof BeneficiariesServicesViewComponent
	 */
	public navigateBack(): void {
		this._router.navigateBack();
	}
	/**
	 * Obtiene por queryParams el ultimo valor de showPayeesTab
	 *
	 * @memberof BeneficiariesServicesViewComponent
	 */
	ngOnInit(): void {
		this.subscription.add(
			this._route.queryParams.subscribe(params => {
				if (params.hasOwnProperty('showPayeesTab')) {
					this.showPayeesTab = params.showPayeesTab === 'true';
				}
			})
		);
	}

	/**
	 * Unsubscribe de los servicios y de los dialogos
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	ngOnDestroy() {
		this.subscription.unsubscribe();
		this._backButtonService.closeEvent();
	}
}
