import { FlameFoundationTheme } from 'libs/core/flame-component-library/src/lib/atoms/theme/flame-foundation.theme';
import { DarkTheme } from 'libs/core/flame-component-library/src/lib/atoms/theme/dark.theme';
import { ThemeModule } from 'libs/core/flame-component-library/src/lib/atoms/theme/sn-theme.module';
import {
	OverlayModule as OverlayModuleCDK
} from '@angular/cdk/overlay';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { DialogThemeViewDirective } from './dialog-theme-view.directive';
import { DialogThemeViewComponent } from './dialog-theme-view.component';
import { DialogThemeViewService } from './dialog-theme-view.service';
import { OverlayService } from '@santander/flame-component-library';



@NgModule({
	imports: [
		CommonModule,
		OverlayModuleCDK,
		ThemeModule.forRoot({
			themes: [DarkTheme, FlameFoundationTheme],
			active: 'flame-foundation'
		})
	],
	declarations: [DialogThemeViewComponent, DialogThemeViewDirective],
	providers: [
		DialogThemeViewService,
		OverlayService
	],
	entryComponents: [DialogThemeViewComponent]
})
export class DialogThemeViewModule {}
