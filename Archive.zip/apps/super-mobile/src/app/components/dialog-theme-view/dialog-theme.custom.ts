import { Type } from '@angular/core';

export class CustomThemeDialog {
  /**
   *Creates an instance of CustomThemeDialog.
   * @param {Type<any>} component
   * @param {*} [data]
   * @memberof CustomThemeDialog
   */
  constructor(public component: Type<any>, public data?: any) {}
}
