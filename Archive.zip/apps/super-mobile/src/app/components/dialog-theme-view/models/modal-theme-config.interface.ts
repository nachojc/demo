export interface ModalThemeConfigInterface {
	title?: string;
	closeLabel?: string;
	closeBackdropClick?: boolean;
	height?: string;
}