import { OverlayRef } from '@angular/cdk/overlay';
import { Subject, Observable } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import { DialogThemeViewComponent } from './dialog-theme-view.component';
export class TemplateModalThemeOverlayRef {
	/**
	 *Creates an instance of TemplateModalThemeOverlayRef.
	 * @param {OverlayRef} overlay
	 * @memberof TemplateModalThemeOverlayRef
	 */
	constructor(private overlay: OverlayRef) {}

	/**
	 * variables publicas y privadas
	 *
	 * @private
	 * @memberof TemplateModalThemeOverlayRef
	 */
	private _beforeClose = new Subject<boolean>();
	private _afterClosed = new Subject<void>();
	public componentInstance: DialogThemeViewComponent
	;

	/**
	 * cierra dialogo
	 *
	 * @param {*} [value]
	 * @memberof TemplateModalThemeOverlayRef
	 */
	close(value?: any): void {
		this.componentInstance.animationStateChanged
			.pipe(
				filter((event: any) => event.phaseName === 'start'),
				take(1)
			)
			.subscribe(() => {
				this._beforeClose.next(value);
				this._beforeClose.complete();
				this.overlay.detachBackdrop();
			});

		this.componentInstance.animationStateChanged
			.pipe(
				filter(
					(event: any) =>
						event.phaseName === 'done' && event.toState === 'leave'
				),
				take(1)
			)
			.subscribe(() => {
				this.overlay.dispose();
				this._afterClosed.next(value);
				this._afterClosed.complete();
				this.componentInstance = null;
			});

		// Start exit animation
		this.componentInstance.startExitAnimation();
	}

	/**
	 *
	 * recupera el resultado de observable
	 * @returns {Observable<any>}
	 * @memberof TemplateModalThemeOverlayRef
	 */
	afterClosed(): Observable<any> {
		return this._afterClosed.asObservable();
	}

	/**
	 * recupera el resultado del observable
	 *
	 * @returns {Observable<any>}
	 * @memberof TemplateModalThemeOverlayRef
	 */
	beforeClose(): Observable<any> {
		return this._beforeClose.asObservable();
	}
}
