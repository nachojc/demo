import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[ad-host]',
})
export class DialogThemeViewDirective {
  /**
   *Creates an instance of DialogThemeViewDirective.
   * @param {ViewContainerRef} viewContainerRef
   * @memberof DialogThemeViewDirective
   */
  constructor(public viewContainerRef: ViewContainerRef) { }
}
