import {
	animate,
	state,
	style,
	transition,
	trigger
} from '@angular/animations';
import {
	Component,
	ComponentFactoryResolver,
	EventEmitter,
	Input,
	OnInit,
	Type,
	ViewChild
} from '@angular/core';
import { TemplateModalThemeOverlayRef } from './dialog.modal.ref'
import { DialogThemeViewDirective } from './dialog-theme-view.directive';

/**
 * dialogo de seleccion de tema
 *
 * @export
 * @class DialogThemeViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-dialog-theme-view',
	templateUrl: './dialog-theme-view.component.html',
	styleUrls: ['./dialog-theme-view.component.scss'],
	animations: [
		trigger('slideContent', [
			state('void', style({ transform: 'translate3d(0, 50%, 0)', opacity: 0 })),
			state('enter', style({ transform: 'none', opacity: 1 })),
			state('leave', style({ transform: 'translate3d(0, 100%, 0)' })),
			transition('* => *', animate('400ms cubic-bezier(0.25, 0.8, 0.25, 1)'))
		])
	]
})
export class DialogThemeViewComponent implements OnInit {
	/**
	 *Creates an instance of DialogThemeViewComponent.
	 * @param {ComponentFactoryResolver} componentFactoryResolver
	 * @param {TemplateModalThemeOverlayRef} dialogRef
	 * @memberof DialogThemeViewComponent
	 */
	constructor(
		private componentFactoryResolver: ComponentFactoryResolver,
		private dialogRef: TemplateModalThemeOverlayRef
	) {
		this.theme = localStorage.getItem('theme');
	}

	public theme = 'flame-foundation';

	/**
	 * Emits an <strong>AnimationEvent</strong> with information with the animation
	 * @type {EventEmitter<AnimationEvent>}
	 * @memberof DialogThemeViewComponent
	 */

	public animationStateChanged = new EventEmitter<AnimationEvent>();

	/**
	 * Defines the status of the dialog animation
	 * @type {string}
	 * @memberof DialogComponent
	 */
	public animationState: 'void' | 'enter' | 'leave' = 'enter';

	/**
	 * Defines the status of the dialog animation
	 * @type {string}
	 * @memberof DialogComponent
	 */

	@Input() myComponent: Type<any>;

	/**
	 * The text that is going to be displayed at the top left of the dialog to close it. If not supplied,
	 * a red cross X is shown
	 * @type {string}
	 * @memberof DialogThemeViewComponent
	 */
	@Input() title: string;

	/**
	 * The text that is going to be displayed at the top left of the dialog to close it. If not supplied,
	 * a red cross X is shown
	 * @type {string}
	 * @memberof DialogThemeViewComponent
	 */
	@Input() closeLabel: string;

	/**
	 *  Indicates the height property of the dialog. It will be bounded to the dialog component,
	 *  it can be a valid css property in px or in vh. It will never exceed the max-height of
	 *  max-height: 95vh;
	 * @type {string}
	 * @memberof DialogThemeViewComponent
	 */
	@Input() height: string;

	/**
	 * This is the directive used to point out the dom portal host. That is the DOM element on
	 * the dialog to wich we want to render our content.
	 *
	 * @type DialogThemeViewDirective
	 * @memberof DialogThemeViewComponent
	 */
	@ViewChild(DialogThemeViewDirective) dialogDirective: DialogThemeViewDirective;

	/**
	 * Emite an event when some animation transition starts
	 * @param {AnimationEvent} event
	 * @memberof DialogThemeViewComponent
	 */
	public onAnimationStart(event: AnimationEvent): void {
		this.animationStateChanged.emit(event);
	}

	/**
	 * Emite an event when some animation transition ends
	 * @param {AnimationEvent} event
	 * @memberof DialogThemeViewComponent
	 */
	public onAnimationDone(event: AnimationEvent): void {
		this.animationStateChanged.emit(event);
	}

	/**
	 * If the gesture of drag-in down is triggered over the top of the dialog, it is closed.
	 * @memberof DialogThemeViewComponent
	 */
	public onPanMove(event: any): void {
		if (event.deltaY > 30) {
			this.closeModal();
		}
	}

	/**
	 * Closes the modal, it accepts a value parmeter to distinguish between close events.
	 * @param {value} any returned value and exposed through the afterClose and beforeClose of the dialog ref
	 * @memberof DialogThemeViewComponent
	 */
	public closeModal(value?: any): void {
		this.dialogRef.close(value);
	}

	/**
	 * set the animation state to leave to start the exit animation
	 */
	public startExitAnimation(): void {
		this.animationState = 'leave';
	}

	/**
	 *
	 *
	 * @memberof DialogThemeViewComponent
	 */
	ngOnInit() {
		if (this.myComponent) {
			const componentFactory = this.componentFactoryResolver.resolveComponentFactory(
				this.myComponent
			);
			const viewContainerRef = this.dialogDirective.viewContainerRef;
			viewContainerRef.clear();
			const componentRef = viewContainerRef.createComponent(componentFactory);
			(<any>componentRef.instance).data = this.dialogDirective['data'];
		}
	}
}
