import { Injectable,  Injector, ComponentRef, Type } from '@angular/core';
import { ComponentPortal, PortalInjector } from '@angular/cdk/portal';

import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplateModalThemeOverlayRef } from './dialog.modal.ref';
import { DialogThemeViewComponent } from './dialog-theme-view.component';
import { ModalThemeConfigInterface } from './models/modal-theme-config.interface';


const DEFAULT_CONFIG = {
	title: '',
	closeLabel: '',
	closeBackdropClick: true,
	heigth: ''
};

@Injectable({
	providedIn: 'root'
})
export class DialogThemeViewService {
	// constructor(
	// 	private _injector: Injector,
	// 	private overlayService: OverlayService
	// ) {}
	// open(config: ModalThemeConfig, customComponent?: CustomThemeDialog): TemplateModalThemeOverlayRef {
	// 	const dialogConfig = { ...DEFAULT_CONFIG, ...config };
	// 	const overlay: OverlayRef = this.overlayService.createOverlay(dialogConfig);
	// 	const dialogRef = new TemplateModalThemeOverlayRef(overlay);
	// 	const dialogComponent: DialogThemeViewComponent = this.attachDialogContainer(
	// 		overlay,
	// 		dialogRef
	// 	);
	// 	dialogComponent.myComponent = customComponent.component;
	// 	dialogRef.componentInstance = dialogComponent;
	// 	if (dialogConfig.closeBackdropClick) {
	// 		overlay.backdropClick().subscribe(_ => dialogRef.close(true));
	// 	}
	// 	return dialogRef;
	// }
	// private attachDialogContainer(
	// 	overlay: OverlayRef,
	// 	dialogRef: TemplateModalThemeOverlayRef
	// ): DialogThemeViewComponent {
	// 	const injector: PortalInjector = this.createInjector(dialogRef);
	// 	const containerPortal = new ComponentPortal(
	// 		DialogThemeViewComponent,
	// 		null,
	// 		injector
	// 	);
	// 	const containerRef: ComponentRef<DialogThemeViewComponent> = overlay.attach(
	// 		containerPortal
	// 	);
	// 	return containerRef.instance;
	// }
	// private createInjector(dialogRef: TemplateModalThemeOverlayRef): PortalInjector {
	// 	const injectionTokens = new WeakMap();
	// 	injectionTokens.set(TemplateModalThemeOverlayRef, dialogRef);
	// 	return new PortalInjector(this._injector, injectionTokens);
	// }

	constructor(private overlay: Overlay, private injector: Injector) {}

	private componentInstance;
	private overlayRef: OverlayRef;
	private dialogRef: any;

	/**
	 * it creates an injector to dispose the dialogRef within the Dialog Component (Portal)
	 * so we can access its API (close)
	 *
	 * @param TemplateModalOverlayRef dialogRef
	 * @memberof DialogContentService
	 */
	private createInjector(dialogRef: TemplateModalThemeOverlayRef): PortalInjector {
		const injectionTokens = new WeakMap();
		injectionTokens.set(TemplateModalThemeOverlayRef, dialogRef);
		return new PortalInjector(this.injector, injectionTokens);
	}

	/**
	 * Opens a new dialog that renders the @param componentType within a Portal Host.
	 * it accepts an optional configuration @param ModalConfig @type ModalConfig
	 *
	 * @param Type<T> componentType
	 * @param ModalConfig config
	 * @memberof DialogContentService
	 */
	public open<T>(
		componentType: Type<T>,
		config?: ModalThemeConfigInterface
	): TemplateModalThemeOverlayRef {
		const dialogConfig = { ...DEFAULT_CONFIG, ...config };

		this.overlayRef = this.overlay.create({
			hasBackdrop: true,
			disposeOnNavigation: true,
			backdropClass: 'dark-backdrop',
			...dialogConfig
		});
		this.dialogRef = new TemplateModalThemeOverlayRef(this.overlayRef);

		if (dialogConfig.closeBackdropClick) {
			this.overlayRef.backdropClick().subscribe(_ => this.dialogRef.close());
		}

		const injector = this.createInjector(this.dialogRef);
		const userProfilePortal = new ComponentPortal(
			DialogThemeViewComponent,
			null,
			injector
		);
		this.componentInstance = this.overlayRef.attach(userProfilePortal).instance;
		this.dialogRef.componentInstance = this.componentInstance;

		this.componentInstance.closeLabel = dialogConfig.closeLabel
			? dialogConfig.closeLabel
			: '';
		this.componentInstance.title = dialogConfig.title;
		this.componentInstance.height = dialogConfig.height;
		this.componentInstance.myComponent = componentType;

		return this.dialogRef;
	}


}
