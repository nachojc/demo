// This function identifies the device type (Android/iOS)
function getMobileOperatingSystem() {
  var userAgent = navigator.userAgent || navigator.vendor || window.opera;
  // Windows Phone must come first because its UA also contains "Android"
  if (/windows phone/i.test(userAgent)) return "Windows Phone";
  if (/android/i.test(userAgent)) return "Android";
  // iOS detection from: http://stackoverflow.com/a/9039885/177710
  if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) return "iOS";
  return "unknown";
}

//Send the answer message through valid handler according to the operating system of the device.
function callComponent(componentName, componentParams) {
  // Create a unique name for the callback event
  var cb = componentName + Date.now();
  // This function returns a Promise
  return new Promise(function (resolve) {
      // Identify device type for native handling
      var device = getMobileOperatingSystem();
      if (device === 'iOS') webkit.messageHandlers.callbackHandler.postMessage(JSON.stringify({
          component: componentName,
          params: componentParams,
          callbackName: cb
      }));
      else if (device === 'Android') javascriptObject.nativeCode(componentName, componentParams, cb);
      else console.log('Error calling native code. Am I running on a device?');
      // Event handler that will be executed on component return
      var eventHandler = function eventHandler(event) {
          window.removeEventListener(cb, eventHandler);
          resolve(event.detail);
      };
      window.addEventListener(cb, eventHandler);
  });
}

function takeScreenshot(save) {

  var cb = "takeScreenshot" + Date.now();
  // This function returns a Promise

  var device = getMobileOperatingSystem();
  if (device === 'Android') {
      return new Promise (function (resolve) {
              javascriptObject.takeScreenshot(save,cb);

              // Event handler that will be executed on component return
              var eventHandler = function eventHandler(event) {
                  window.removeEventListener(cb, eventHandler);
                  resolve(event.detail);
              }
              window.addEventListener(cb, eventHandler);
      });
  } else if (device === 'iOS') {
      return callComponent("takeScreenshot", "{\"save\":"+save+"}")
  } else console.log('Error calling native code. Am I running on a device?');
}

function keyboardOpeniOS(scrollYTo){
    var device = getMobileOperatingSystem();
    return new Promise (function (resolve) {
      var eventHandler = function eventHandler(event) {
        console.log(event.detail);
        window.removeEventListener('iOSKeyBoardWillShowEvent', eventHandler);
        if (device === 'iOS'){
          window.scrollTo(0, scrollYTo ? scrollYTo : 100);
          resolve(event.detail);
        }
      }
      window.addEventListener('iOSKeyBoardWillShowEvent', eventHandler);
    });
}

function keyboardCloseiOS(destroy){
    var device = getMobileOperatingSystem();
    return new Promise (function (resolve) {
      var eventHandler = function eventHandler(event) {
        console.log(event.detail);
        window.removeEventListener('iOSKeyBoardWillHideEvent', eventHandler);
        if (device === 'iOS'){
          window.scrollTo(0, 0);
          resolve(event.detail);
        }
      };
      window.addEventListener('iOSKeyBoardWillHideEvent', eventHandler);
    });
}

function share(componentParams) {

  var cb = "share" + Date.now();
  // Identify device type for native handling
  var device = getMobileOperatingSystem();
  if (device === 'iOS') webkit.messageHandlers.callbackHandler.postMessage(JSON.stringify({
      component: "share",
      params: componentParams,
      callbackName: cb
  }));
  else if (device === 'Android') javascriptObject.share(componentParams);
  else console.log('Error calling native code. Am I running on a device?');
}


function manageOnBackPressed(condition,observer){
  var device = getMobileOperatingSystem();
  if (device === 'Android') javascriptObject.manageOnBackPressed(condition);
          else console.log('Error calling native code. Am I running on a device?');
      if(condition){
          var eventHandler = function eventHandler(event) {
              observer.next(event.detail);
          }
          window.addEventListener("backPressed", eventHandler);
      }else{
          window.removeEventListener("backPressed", eventHandler);
          observer.complete();
      }
}
