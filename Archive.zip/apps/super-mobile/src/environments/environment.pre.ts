export const environment = {
  production: true,
  develop: false,
  show: ['R1', 'R2', 'R3', 'R4', 'R5'],
  sm: {
    clientId: 's6kSZsSrrQfxmx4i4rrdqdq-BV518aYCpXKu_C_HL90'
  },
	idp: {
		url: 'https://idppre.santander.com.mx/IDPWeb/idp',
		redirectUri: 'http://www.santander.com.mx/mx/home'
	},
	oauth: {
		url: 'https://front-grants-bussupport-comsrvc-security-pf-pre.appls.cto1.paas.gsnetcloud.com/oauth2/v1/token',
    scope: 'summary_1.0.0 accounts_2.0.1 credits_1.1.0 payments_2.0.0 transfers_1.0.0 customers_1.0.0 services_1.0.0 Cards_1.0.0'
  },
  api: {
    url: 'https://apicorppre.santander.com.mx/santander-mexico/private-pre',
    version: {
      authentication: 'v1',
      summary: 'v1',
      accounts: 'v2',
      credits: 'v1',
      cards: 'v1',
      transfers: 'v1',
			customers: 'v1',
			insurance: '',
      policies: '',
      payments: 'v2',
      claims: 'v1',
      onepay: ''
    }
  }
};
