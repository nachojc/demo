export const environment = {
  production: true,
  develop: false,
  show: ['R1', 'R2', 'R3', 'R4', 'R5'],
  sm: {
    clientId: 'KTseytsjJW2QZC1KSIWCoWrnQf9vELLXBqyRSKBiwBE'
  },
	idp: {
		url: 'https://idp.santander.com.mx/IDPWeb/idp',
		redirectUri: 'http://www.santander.com.mx/mx/home'
	},
	oauth: {
		url: 'https://front-grants-bussupport-comsrvc-security-pf-pro.appls.cto1.paas.gsnetcloud.com/oauth2/v1/token',
    scope: 'summary_1.0.0 accounts_2.0.1 credits_1.1.0 payments_2.0.0 transfers_1.0.0 customers_1.0.0'
  },
  api: {
    url: 'https://apicorp.santander.com.mx/santander-mexico/private',
    version: {
      authentication: 'v1',
      summary: 'v1',
      accounts: 'v2',
      credits: 'v1',
      cards: 'v1',
      transfers: 'v1',
			customers: 'v1',
			insurance: '',
      policies: '',
      payments: 'v2',
      claims: 'v1',
      onepay: ''
    }
  }
};

/**
 * https://idp.santander.com.mx/IDPWeb/idp?client_id=KTseytsjJW2QZC1KSIWCoWrnQf9vELLXBqyRSKBiwBE&redirect_uri=http://www.santander.com.mx/mx/home/&response_type=code&state=absgetrgdushdgrusjdhfrdchfgvhdss&code_challenge=RsL8SMoFX6fWcgXi-W6Md6En-gHoLPaafL2JJrDI3Io=
 */
