export const environment = {
	production: false,
	develop: true,
	show: ['R0', 'R1', 'R2', 'R3', 'R4', 'R5', 'UV', 'INV'], // Todos los Releases R0, R1, R2, R3, R4, R5, RA y RB
	sm: {
		clientId: '0KxtKPNZzUIMueEfxeP6x_NKWPJLRREWHEHsyOw1a4w'
	},
	idp: {
		url: 'http://localhost:3000/IDPWeb/idp',
		redirectUri: 'http://www.santander.com.mx/mx/home'
	},
	oauth: {
		url: 'http://localhost:3000/oauth2/v1/token',
		scope: 'summary_1.0.0 accounts_1.0.0'
	},
	api: {
		url: 'http://localhost:3000/api',
		version: {
			authentication: 'v1',
			summary: '',
			accounts: '',
			credits: '',
			cards: '',
			transfers: '',
			customers: '',
			insurance: '',
			payments: '',
			policies: '',
			payees: '',
			claims: '',
			onepay: '',
			investments: ''
		}
	}
};
