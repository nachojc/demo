export const environment = {
  production: true,
  develop: false,
  show: ['R1', 'R2', 'R3', 'R4', 'R5'],
  sm: {
    clientId: 'VWJDAKN2IIJLGLFYNNHQAWPVN1CYJ8-MBWBPQ11NUKC'
  },
	idp: {
		url: 'https://wsidttlm1mxr301.cert.mx.corp:1443/IDPWeb/idp',
		redirectUri: 'https://mxadmqai40.cert.mx.corp/idp.php'
	},
	oauth: {
		url: 'https://front-grants-bussupport-comsrvc-security-pf-int-dev.appls.cto1.paas.gsnetcloud.corp/oauth2/v1/token',
    scope: 'Summary_1.0.1 accounts_2.0.1 credits_1.1.0 payments_2.0.0 transfers_1.0.0 customers_1.0.0'
  },
  api: {
    url: 'https://api.cert.mx.corp/santander-mexico/private-cert',
    version: {
      authentication: 'v1',
      summary: 'v2',
      accounts: 'v2',
      credits: 'v1',
      cards: 'v1',
      transfers: 'v1',
      insurance: 'v1',
      policies: 'v1',
      customers: 'v1',
      payees: 'v1',
      payments: 'v2',
      claims: 'v1',
      onepay: ''
    }
  }
};
