import { Component } from '@angular/core';

@Component({
  selector: 's-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  host: {
    role: 'header'
  }
})
export class HeaderComponent {}
