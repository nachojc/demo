import { Component, DebugElement } from '@angular/core';
import { async, TestBed, ComponentFixture } from '@angular/core/testing';

import { ButtonModule } from './button.module';
import { By } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

@Component({
    template: `
        <button
            sn-button
            (click)="increment()"
            class="{{classButton}}"
            [ngClass]="classButton"
            [disabled]="isDisabled"
        >
            {{ classButton }}
        </button>
        <a
            sn-button
            href="http://www.google.com"
            target="_blank"
            [attr.disabled]="isDisabled"
        >
            Ir a Google
        </a>
    `
})
class TestSNButtonComponent {
    sendCount = 0;
    isDisabled = false;
    classButton = 'small';

    increment() {
        this.sendCount++;
    }
}

describe('ButtonComponent', () => {
    let component: TestSNButtonComponent;
    let fixture: ComponentFixture<TestSNButtonComponent>;
    let buttonEl: DebugElement;
    let anchorDebugElement: DebugElement;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, ButtonModule],
            declarations: [TestSNButtonComponent]
        }).compileComponents();
        fixture = TestBed.createComponent(TestSNButtonComponent);
        component = fixture.componentInstance;
        buttonEl = fixture.debugElement.query(By.css('button[sn-button]'));
        anchorDebugElement = fixture.debugElement.query(By.css('a[sn-button]'));
    }));

    it('Should create a button', () => {
        expect(component).toBeTruthy();
    });

    it('should apply class based on attribute', () => {
        component.isDisabled = false;
        component.classButton = 'full';
        fixture.detectChanges();
        expect(buttonEl.nativeElement.classList.contains('full')).toBe(true);

        component.classButton = 'large';
        fixture.detectChanges();
        expect(buttonEl.nativeElement.classList.contains('large')).toBe(true);

        component.classButton = 'strech';
        fixture.detectChanges();
        expect(buttonEl.nativeElement.classList.contains('strech')).toBe(true);

        component.classButton = null;
        fixture.detectChanges();
        expect(buttonEl.nativeElement.classList).not.toContain('strech');
    });

    it('should not increment if disabled', () => {
        component.isDisabled = true;
        fixture.detectChanges();

        buttonEl.nativeElement.click();

        expect(component.sendCount).toBe(0);
    });

    it('should disable the native button element', () => {
        const buttonNative = fixture.nativeElement.querySelector('button');
        expect(buttonNative.disabled).toBeFalsy('Expected button to be enabled');

        component.isDisabled = true;
        fixture.detectChanges();
        expect(buttonNative.disabled).toBeTruthy('Expected button to be disabled');
    });

    /** @TODO : Hacer que el anchor no redirija si se deshabilita el botón */
    it('anchor should not redirect if disabled', () => {
        component.isDisabled = true;
        fixture.detectChanges();
        anchorDebugElement.nativeElement.click();
    });
});
