import { NgModule } from '@angular/core';
import { HeaderModule, ButtonModule } from './lib';


@NgModule({
  exports: [
    HeaderModule,
    ButtonModule
  ]
})

export class SCommonModule { }
