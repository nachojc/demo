# demo-angular
Angular Project example to pipelines
