package uk.co.santander.ola.status;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by c0252867 on 06/02/2018.
 */
@Controller
public class OLAScannerStatus {

    @RequestMapping("/status")
    @ResponseBody
    String home() {
        return "Hello World!";
    }
}
