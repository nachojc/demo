package uk.co.santander.ola;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;

/**
 * Created by c0252867 on 06/02/2018.
 */

@EnableAutoConfiguration
public class OLAScannerStart {

    public static void main(String[] args) throws Exception {
        SpringApplication.run(OLAScannerStart.class, args);
    }
}
