import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';

import { CommonModule } from '@angular/common';

import {FileuploadUIComponent} from './fileupload/fileupload.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule      
  ],
  declarations: [
    FileuploadUIComponent
  ],
  exports:[
    FileuploadUIComponent

  ],
  providers: []
})
export class UICommonModule { }