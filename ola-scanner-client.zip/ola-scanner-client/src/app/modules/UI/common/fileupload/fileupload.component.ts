import { Component, Input, Output, EventEmitter} from '@angular/core';
import { ComunicationService } from '../../../../services/comunication/comunication.service';


@Component({
  selector: 'san-fileupload-ui',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.scss']
})
export class FileuploadUIComponent{
    fileLoaded:any=[];
    private fileInput:any;
    @Input() status = 1;
    
    @Output() uploaded = new EventEmitter<object>();
    openFile(fileInput){
        this.fileInput = fileInput;
        this.fileInput.click();
        console.log('fileInput: ' + fileInput.value);
    }

    fileUploaded(e,img){
        let elem = e.currentTarget;
        let file = elem.files[0];
        let that=this;

        if (file.type && file.type.startsWith('image/')){
            let reader = new FileReader();
            reader.onload = (
                function() {
                    return function(e) {
                        that.fileLoaded.push({src:e.target.result,dateClient:Date.now()});
                        that.fileInput.value = "";
                    }; 
                })();
            reader.readAsDataURL(file);
        }


    }

    removeFile(file) {
        this.fileLoaded = this.fileLoaded.filter((obj)=>obj.src!==file.src || obj.dateClient!==file.dateClient);
    }

    sendFile(){
        let filesToSend = this.fileLoaded.filter((obj)=>obj.verify&&!obj.sended);
        filesToSend.forEach(element => {
            element.sended = true;
        });
        this.uploaded.emit(filesToSend);
    }
    isVerify(){
        return  this.fileLoaded.filter((obj)=>obj.verify&&!obj.sended).length && this.fileLoaded.length && this.status==1;
        
    }
    
}