import { Component, OnInit, OnDestroy } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ComunicationService } from '../../services/comunication/comunication.service';

@Component({
  selector: 'san-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit, OnDestroy {
    private param:string;
    private sub: any;
    private sendedFiles:any;
    private errorMsg:any;
    status:number=1;

    data:any={name:null,phone:null};

    constructor(private route: ActivatedRoute, private http: ComunicationService) {
    }
    
    ngOnInit(){
        this.sub = this.route.params.subscribe((parameter)=>{
            this.param = parameter['idToken'];
            console.log(this.param);
            this.http.initComunication(this.param).then((res:any)=>{
                this.data = res.data;
            },
            (err)=>{
                this.errorMsg = err;
            }
        );
        })

    }
    ngOnDestroy(){
        this.sub.unsubscribe();
    }

    sendDocument(vals){
        this.status = 2;
        this.errorMsg = 'sending...--';
        let params = {
            ID : this.data.id,
            files: vals
        };
        this.http.sendFile(params).then((res:any)=>{
            this.sendedFiles=res.data;
            this.errorMsg ='';
            this.status = 1;
        },
    (err)=>{
        this.errorMsg = JSON.stringify(err);
        this.status = 1;
    });
    }
}