import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from 'rxjs/Observable';
import { Promise } from "q";

import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/mergeMap';

@Injectable()
export class ComunicationService {
    private HOST:string='/api';
    private URL:any={};
    private token:string;

    constructor( private http: HttpClient ){
        this.URL = {
            token:this.HOST +  '/checktoken',
            send:this.HOST + '/upload'
        };
    }


    initComunication(idToken: string) {
        this.token=idToken;

        return this.http.get(this.URL.token + '?token=' + idToken).toPromise();
    }

    sendFile(params: any) {
        return this.http.put(this.URL.send, params).toPromise();
    }

}