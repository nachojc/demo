import { Routes } from '@angular/router';
import { MainComponent } from './components/main/main.component';

export const appRoutes: Routes = [
    { path: ':idToken', component: MainComponent }
    // {
    //   path: 'heroes',
    //   component: HeroListComponent,
    //   data: { title: 'Heroes List' }
    // },
    // { path: '',
    //   redirectTo: '/heroes',
    //   pathMatch: 'full'
    // },
    // { path: '**', component: PageNotFoundComponent }
    
  ];
