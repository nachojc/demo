(function () {
    const express = require('express');
    const router = express.Router();


    router.all('/', (req, res) => {

        res.json({id:3});
    })

    module.exports = router;
}());