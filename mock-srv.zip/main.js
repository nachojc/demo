(function () {
    'use strict';
    const express = require('express');
    const fs = require('fs');
    const path = require('path');
    const app = express();
    const config = require('./tools/config');
    const list = require('./tools/routes');
    const rewrite = require('./tools/rewrite-routes');
    
    const port = process.env.PORT || config.srv.port;
    const www = process.env.WWW || config.srv.base;
    const host = process.env.HOST || config.srv.host;
    const baseJson = process.env.JSON || config.srv.baseJson || './src/json';

    app.use(express.static(www));
    app.host = host;
    console.log(`serving from: ${www}`);
    



    app.all('*', (req, res, next) => {
        if (req.url == '/healthz') {
            return res.status(200).end('UP');
        }
        req.url = rewrite(req.url, req.method);

        let file = req.path + '-' + req.method;
        const path = baseJson + file + '.json';
        try{
            if (fs.existsSync(path)) {
                console.log(`sending ${path} to ${req.get('origin')}`);
                res.status(200).end(fs.readFileSync(path));
            }else{
                next();
            }
        }
        catch(e){
            console.log(e);
            
        }
    });
    config.srv.baseRoutes.forEach(r => {
        app.use('/',list.loadRoutes(path.join(__dirname, r)));
    })

    app.listen(port, () => console.log(`listening on http://${host}:${port}`));
    
    

}());
