(function () {
    const fs = require('fs');
    const path = require('path');
    
    // let routes = [];
    // const methods = ['get','post','put','delete', 'options', 'patch', 'head'];
    
    function loadRoutesFn(pathBase) {
        let i = 0;
        const express = require('express');
        const router = express.Router();

        try {
            const files = fs.readdirSync(pathBase);
            files.forEach(f =>{
                const fileName = path.join(pathBase, f);
                const stat = fs.lstatSync(fileName);
                if (stat.isDirectory()){
                    const newRoutes = loadRoutesFn(fileName);
                    if (!!newRoutes){
                        i++;
                        router.use('/'+ f, newRoutes);
                    }
                    const routing = require(fileName);
                    if(!!routing && typeof routing === "function" ) {
                        i++;
                        router.use('/'+ f, routing);
                    }
                }
                
            });
        }catch(err) {
            console.error(err);
        }   

        return !!i ? router : null;
    }
    




    // function storeRoutesFn(app) {
    //     const elements = app._router.stack
    //             .filter(r => r.route);

    //     elements.forEach(r => {
    //         methods.forEach(m =>{
    //             if (r.route.methods[m]){
    //                 routes.push(r.route.path + '-' + m.toUpperCase());
    //             }
    //         })
    //     });
    // }

    // function isInRoutesFn(path, method) {
    //     return !!routes[path + '-' + method.toUpperCase()];
    // }

    module.exports = {
        loadRoutes: loadRoutesFn
    }
}());