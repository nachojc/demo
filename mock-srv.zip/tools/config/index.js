(function () {
    'use strict';

    const configSrv = {
        srv:{
            port: 8080,
            host: 'localhost',
            base: './src/www/',
            baseJson: './src/static-json',
            baseRoutes: ['./src/routes']
        }
    }

    module.exports =  configSrv;
}());
