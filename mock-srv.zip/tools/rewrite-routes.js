(function () {
  let list = [
        {url:"/list", route: "/main", method: "get"},
        {url:"/index", route: "/index", method: "post"},
        {url:"/log", route: "/main/login", method: "*"},
];
  let rewriteFn = function (route) {
        const method = arguments[1] ? arguments[1].toLowerCase():null;
        const lists = getRoutes(route);
        
        if (typeof route === 'string' && lists.length ){
            if (!method){
                lists = [lists[0]];
            }
            if ( lists.length === 1){
                return getRoute(route, method, lists[0]);
            }else{
                for(let i=0; lists.length > i;i++){
                    const result = getRoute(route, method, lists[i]);
                    if ( result !== route) {
                        return result 
                    };
                }
            }
        }
        return route 
  }
  function setListFn(newList) {
      if ( Array.isArray(newList)){
          list = newList;
      }
  }


  function getRoute(url, method, opt){
    if ( opt.method &&
        ((!Array.isArray(opt.method) && (opt.method === '*' || opt.method === method)) ||
        (Array.isArray(opt.method) && opt.method.includes(method)))
    ) {
        return opt.route[0] === '/' ? opt.route : '/' + opt.route;
    }
    return url; 
  }
  function getRoutes(url){
      return list.filter(l => l.url === url || '/' + l.url === url);
  } 

  rewriteFn.setList = setListFn;
  module.exports = rewriteFn;
}());
