var gitbook = gitbook || [];
gitbook.push(function() {
  gitbook.page.hasChanged({
    page: {
      title: "Device Registration API",
      level: "2.12",
      depth: 1,
      next: {
        title: "Admin API",
        level: "2.13",
        depth: 1,
        path: "developer-guide/minibank-admin.md",
        ref: "developer-guide/minibank-admin.md",
        articles: []
      },
      previous: {
        title: "User Management API",
        level: "2.11",
        depth: 1,
        path: "developer-guide/usermanagement.md",
        ref: "developer-guide/usermanagement.md",
        articles: []
      },
      dir: "ltr"
    },
    config: {
      plugins: [
        "insert-logo",
        "anchors",
        "hide-published-with",
        "back-to-top-button",
        "copy-code-button",
        "downloadpdf",
        "-sharing",
        "-fontsettings"
      ],
      styles: {
        website: "styles/website.css",
        pdf: "styles/pdf.css",
        epub: "styles/epub.css",
        mobi: "styles/mobi.css",
        ebook: "styles/ebook.css",
        print: "styles/print.css"
      },
      pluginsConfig: {
        search: {},
        downloadpdf: {
          label: "Download PDF",
          multilingual: false,
          base: "mybook.pdf"
        },
        lunr: { maxIndexSize: 1000000, ignoreSpecialCharacters: false },
        "hide-published-with": {},
        highlight: {},
        "back-to-top-button": {},
        "copy-code-button": {},
        "theme-default": {
          styles: {
            website: "styles/website.css",
            pdf: "styles/pdf.css",
            epub: "styles/epub.css",
            mobi: "styles/mobi.css",
            ebook: "styles/ebook.css",
            print: "styles/print.css"
          },
          showLevel: false
        },
        anchors: {},
        "insert-logo": {
          style: "background: none; width: 200px;",
          url: "/documentation/gitbook/assets/sanlabs.png"
        }
      },
      theme: "default",
      pdf: {
        pageNumbers: true,
        fontSize: 12,
        fontFamily: "Arial",
        paperSize: "a4",
        chapterMark: "pagebreak",
        pageBreaksBefore: "/",
        margin: { right: 62, left: 62, top: 56, bottom: 56 }
      },
      structure: {
        langs: "LANGS.md",
        readme: "README.md",
        glossary: "GLOSSARY.md",
        summary: "SUMMARY.md"
      },
      variables: {},
      title: "Santander Labs Documentation",
      gitbook: "*"
    },
    file: {
      path: "developer-guide/deviceregistration.md",
      mtime: "2019-05-29T16:10:44.000Z",
      type: "markdown"
    },
    gitbook: { version: "3.2.3", time: "2019-05-29T21:33:33.166Z" },
    basePath: "..",
    book: { language: "" }
  });
});
