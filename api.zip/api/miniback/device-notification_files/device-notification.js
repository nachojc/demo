var gitbook = gitbook || [];
gitbook.push(function() {
  gitbook.page.hasChanged({
    page: {
      title: "Device Notification API",
      level: "2.3",
      depth: 1,
      next: {
        title: "ATMs API",
        level: "2.4",
        depth: 1,
        path: "developer-guide/atms.md",
        ref: "developer-guide/atms.md",
        articles: []
      },
      previous: {
        title: "MyPersonas API",
        level: "2.2",
        depth: 1,
        path: "developer-guide/mypersonas.md",
        ref: "developer-guide/mypersonas.md",
        articles: []
      },
      dir: "ltr"
    },
    config: {
      plugins: [
        "insert-logo",
        "anchors",
        "hide-published-with",
        "back-to-top-button",
        "copy-code-button",
        "downloadpdf",
        "-sharing",
        "-fontsettings"
      ],
      styles: {
        website: "styles/website.css",
        pdf: "styles/pdf.css",
        epub: "styles/epub.css",
        mobi: "styles/mobi.css",
        ebook: "styles/ebook.css",
        print: "styles/print.css"
      },
      pluginsConfig: {
        search: {},
        downloadpdf: {
          label: "Download PDF",
          multilingual: false,
          base: "mybook.pdf"
        },
        lunr: { maxIndexSize: 1000000, ignoreSpecialCharacters: false },
        "hide-published-with": {},
        highlight: {},
        "back-to-top-button": {},
        "copy-code-button": {},
        "theme-default": {
          styles: {
            website: "styles/website.css",
            pdf: "styles/pdf.css",
            epub: "styles/epub.css",
            mobi: "styles/mobi.css",
            ebook: "styles/ebook.css",
            print: "styles/print.css"
          },
          showLevel: false
        },
        anchors: {},
        "insert-logo": {
          style: "background: none; width: 200px;",
          url: "/documentation/gitbook/assets/sanlabs.png"
        }
      },
      theme: "default",
      pdf: {
        pageNumbers: true,
        fontSize: 12,
        fontFamily: "Arial",
        paperSize: "a4",
        chapterMark: "pagebreak",
        pageBreaksBefore: "/",
        margin: { right: 62, left: 62, top: 56, bottom: 56 }
      },
      structure: {
        langs: "LANGS.md",
        readme: "README.md",
        glossary: "GLOSSARY.md",
        summary: "SUMMARY.md"
      },
      variables: {},
      title: "Santander Labs Documentation",
      gitbook: "*"
    },
    file: {
      path: "getting-started/device-notification.md",
      mtime: "2019-03-01T15:06:29.000Z",
      type: "markdown"
    },
    gitbook: { version: "3.2.3", time: "2019-03-18T14:32:43.476Z" },
    basePath: "..",
    book: { language: "" }
  });
});
