var NGXSTORE_CONFIG = {
  prefix: "sanlabs_" + window.location.hostname + "_",
  mutateObjects: false
};
var global = global || window;
