(function(window) {
  window.__san_minbank_env = {
    baseURL:
      "https://www.santanderlabs.io/API" ,
    appClientAndSecret:
      "cFM3S1VFSjMySVR3YnFNaE9EVnFSa1FmQjYwYTpseVJEYjlTdVNqck0xNktDSDlvNGtrUHI0Y0Fh",
    authScope:
      "aggregator_read aggregator_write onepayfx_read onepayfx_write personas_read payguarantee instantpay acclist_read acctran_read accdet_read _payments accounts_read apim:subscribe device_notifications_read device_notifications_write devices_read devices_write devportal_admin myprofile_read payments_read personas_read personas_write twostepauth_confirm",
    authWhiteList: [
      "/(\/developer\/oauth2\/token)$/",
      "/(\/developers)$/",
      "/(\/active)/"
    ],
    strict: true,
    basePath: "/developer-portal/1.0.3"
  };
})(this);