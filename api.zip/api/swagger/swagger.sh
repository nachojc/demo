## declare an array variable

declare -a arr=("account-service" "bank-accounts-service" "admin-account-service" "auth-service" "bank-auth-service" "company-search-service" "consent-service" "content-templating-service" "core-banking-service" "credit-affordability-service" "credit-rating-service" "credit-score-service" "document-storage-service" "finance-drawdown-calculator" "lending-api-service" "lending-dashboard-service" "lending-document-service"  "ocr-api-service" "postcode-lookup-service" "verification-service" )

## now loop through the above array
for i in "${arr[@]}"
do
   echo "Getting swagger doc for $i"
   # or do whatever with individual element of the array
   curl http://internal-api.prod.astoapp.co.uk/$i/v2/api-docs | jq . >> $i.json
done
