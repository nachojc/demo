import Constants from 'expo-constants';

// Jest won't use app.config.ts, so expoConfig ends up undefined.

type Extra = {
  displayName?: string;
  appID?: string;
  targetApp?: string;
};

type SafeExpoConfig = {
  extra?: Extra;
};

type ReturnValue = Extra[keyof Extra] | string;

const safeExpoConfig: SafeExpoConfig = Constants.expoConfig || {};

export const displayName = (): ReturnValue => {
  return safeExpoConfig.extra?.displayName || 'MyAviva';
};

export const getAppID = (): ReturnValue => {
  return safeExpoConfig.extra?.appID || 'co.uk.aviva.myaviva';
};

export const getTargetApp = (): ReturnValue => {
  return safeExpoConfig.extra?.targetApp || 'ma';
};

export const isManga = (): boolean => {
  return getTargetApp() === 'ma' || getTargetApp() === 'ma-demo';
};
