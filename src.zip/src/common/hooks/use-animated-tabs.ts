import { useRef, useState } from 'react';

import { useTabAnimation } from './use-tab-animation';

/**
 * Hook to handle tab selection - returns animated-styles that can be used to animate an indicator for the selected tab
 * @param {number} initialTabIndex - The index of the tab that should be selected initially
 */
export const useAnimatedTabs = (initialTabIndex = 0) => {
  const [selectedTabIndex, setSelectedTabIndex] = useState(initialTabIndex);
  const tabWidth = useRef(0);
  const { animatedStyles, animateTabSelection } = useTabAnimation(
    initialTabIndex,
    tabWidth?.current
  );

  const handleTabSelect = (index: number) => {
    setSelectedTabIndex(index);
    animateTabSelection(index);
  };

  return {
    animatedStyles,
    selectedTabIndex,
    tabWidth,
    handleTabSelect,
  };
};
