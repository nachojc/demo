import { MyDriveModel } from '@src/models/mydrive';
import { useMutation } from '@tanstack/react-query';

export const useDeactivateMyDrive = () =>
  useMutation({
    mutationKey: ['deactivateMyDrive'],
    mutationFn: () => new MyDriveModel().deactivateMyDrive(),
  });
