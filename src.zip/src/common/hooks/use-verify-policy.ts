import { RegistrationModel } from '@src/models';
import { PolicyRouteParams } from '@src/navigation/auth';
import { convertGBDateToISO } from '@src/utils';
import { useMutation } from '@tanstack/react-query';

type PolicyDetails = PolicyRouteParams & {
  policyNumber: string;
};

export const useVerifyPolicy = () =>
  useMutation({
    mutationKey: ['verifyPolicy'],
    mutationFn: ({
      firstName,
      lastName,
      dateOfBirth,
      postcode,
      policyNumber,
      offers,
    }: PolicyDetails) =>
      new RegistrationModel().verifyPolicy({
        FirstName: firstName,
        LastName: lastName,
        DateOfBirth: convertGBDateToISO(dateOfBirth),
        Postcode: postcode,
        PolicyNumber: policyNumber,
        EmailMarketingOptIn: offers,
      }),
  });
