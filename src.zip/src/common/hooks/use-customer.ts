import { UseQueryOptionsGenerics } from '@src/common/types/react-query';
import { useQuery } from '@tanstack/react-query';

import { CustomerModel } from '../../models';
import { getLogger } from '../interfaces/logger';
import { useAuth } from './use-auth';

export const CUSTOMER_QUERY_KEY = 'customer';

type UseCustomerOptions = UseQueryOptionsGenerics<
  InstanceType<typeof CustomerModel>['fetchCustomer'],
  'customer'
>;

const log = getLogger(useCustomer.name);

export function useCustomer(options?: UseCustomerOptions) {
  const { isSignedIn } = useAuth();

  return useQuery({
    queryFn: new CustomerModel().fetchCustomer,
    queryKey: [CUSTOMER_QUERY_KEY],
    onError: (e) => {
      log.apiError(e);
    },
    enabled: isSignedIn,
    ...options,
  });
}
