import { getLogger } from '@interfaces/logger';
import { AdjustNavigatorQuestionnaireServiceAnalytics } from '@src/utils/api/service-analytics/adjust-navigator-questionnaire-service-analytics';
import { BeneficiariesServiceAnalytics } from '@src/utils/api/service-analytics/beneficiaries-form-values-service-analytics';
import { BeneficiariesAnalytics } from '@src/utils/api/service-analytics/beneficiaries-service-analytics';
import { ChangeRetirementDateCaveatsAnalytics } from '@src/utils/api/service-analytics/change-retirement-date-caveats-analytics';
import { ChangeRetirementDateServiceAnalytics } from '@src/utils/api/service-analytics/change-retirement-date-service-analytics';
import { CustomerServiceAnalytics } from '@src/utils/api/service-analytics/customer-service-analytics';
import { DefaultFundServiceAnalytics } from '@src/utils/api/service-analytics/default-fund-service-analytics';
import { DirectWealthAccountServiceAnalytics } from '@src/utils/api/service-analytics/direct-wealth-account-service-analytics';
import { DocumentRetrievalAnalytics } from '@src/utils/api/service-analytics/document-retrieval-service-analytics';
import { DocumentsListRetrievalAnalytics } from '@src/utils/api/service-analytics/documents-list-retrieval-service-analytics';
import { EditorialContentServiceAnalytics } from '@src/utils/api/service-analytics/editorial-content-service-analytics';
import { FastTrackRegisterServiceAnalytics } from '@src/utils/api/service-analytics/fast-track-register-service-analytics';
import { FastTrackValidationServiceAnalytics } from '@src/utils/api/service-analytics/fast-track-validation-service-analytics';
import { FinancialAdvicePaymentServiceAnalytics } from '@src/utils/api/service-analytics/financial-advice-payment-service-analytics';
import { FindAndCombineCustomerDetailsAnalytics } from '@src/utils/api/service-analytics/find-and-combine-customer-details-analytics';
import { FindAndCombinePensionProvidersAnalytics } from '@src/utils/api/service-analytics/find-and-combine-pension-providers-analytics';
import { FormValuesServiceAnalytics } from '@src/utils/api/service-analytics/form-values-service-analytics';
import { IdverificationServiceAnalytics } from '@src/utils/api/service-analytics/idverification-service-analytics';
import { InvestmentAssetDetailsServiceAnalytics } from '@src/utils/api/service-analytics/investment-asset-details-service-analytics';
import { InvestmentProductPerformanceAnalytics } from '@src/utils/api/service-analytics/investment-product-performance-analytics';
import { IsaAllowanceAnalytics } from '@src/utils/api/service-analytics/isa-allowance-analytics';
import { IsaApplyBankAccountDetailsServiceAnalytics } from '@src/utils/api/service-analytics/isa-apply-bank-account-details-service-analytics';
import { IsaApplyChargesIllustrationIdServiceAnalytics } from '@src/utils/api/service-analytics/isa-apply-charges-illustration-id';
import { IsaApplyChargesIllustrationSearchServiceAnalytics } from '@src/utils/api/service-analytics/isa-apply-charges-illustration-search';
import { IsaApplyFormValuesServiceAnalytics } from '@src/utils/api/service-analytics/isa-apply-form-values-service-analytics';
import { IsaApplyReviewServiceAnalytics } from '@src/utils/api/service-analytics/isa-apply-review-service-analytics';
import { IsaApplySubmitServiceAnalytics } from '@src/utils/api/service-analytics/isa-apply-submit-service-analytics';
import { IsaApplyValidateBankDetailsServiceAnalytics } from '@src/utils/api/service-analytics/isa-apply-validate-bank-details-service-analytics';
import { LoginServiceAnalytics } from '@src/utils/api/service-analytics/login-service-analytics';
import { MessagesServiceAnalytics } from '@src/utils/api/service-analytics/messages-service-analytics';
import { MfaServiceAnalytics } from '@src/utils/api/service-analytics/mfa/mfa-service-analytics';
import { UpdateMfaPreferenceServiceAnalytics } from '@src/utils/api/service-analytics/mfa/update-mfa-preference-service-analytics';
import { NativeSinglePaymentAnalytics } from '@src/utils/api/service-analytics/native-single-payment-services-tags';
import { NavigatorGetServiceAnalytics } from '@src/utils/api/service-analytics/navigator-get-service-analytics';
import { OpenAnIsaFaqAnalytics } from '@src/utils/api/service-analytics/open-an-isa-faq-analytics';
import { PaymentMethodsAnalytics } from '@src/utils/api/service-analytics/payment-methods-analytics';
import { PensionConsolidationDetailsServiceAnalytics } from '@src/utils/api/service-analytics/pension-consolidation-details-service-analytics';
import { PensionConsolidationSummaryServiceAnalytics } from '@src/utils/api/service-analytics/pension-consolidation-summary-service-analytics';
import { PensionIllustrationStatusServiceAnalytics } from '@src/utils/api/service-analytics/pension-illustration-status-service-analytics';
import { PerformanceOverTimeServiceAnalytics } from '@src/utils/api/service-analytics/performance-over-time-service-analytics';
import { PersonalInformationServiceAnalytics } from '@src/utils/api/service-analytics/personal-information-service-analytics';
import { PhoneNumbersServiceAnalytics } from '@src/utils/api/service-analytics/phone-numbers-service-analytics';
import { PostcodeLookupServiceAnalytics } from '@src/utils/api/service-analytics/postcode-lookup-service-analytics';
import { ProductDetailsCashTransactionHistoryAnalytics } from '@src/utils/api/service-analytics/product-details-cash-transaction-history';
import { ProductDetailsInvestmentTransactionHistoryAnalytics } from '@src/utils/api/service-analytics/product-details-investment-transaction-history-analytics';
import { ProductDetailsPaymentHistoryAnalytics } from '@src/utils/api/service-analytics/product-details-payment-history-analytics';
import { ProductRetrieveAnalytics } from '@src/utils/api/service-analytics/product-retrieve-analytics';
import { TailoredOfferSyncServiceAnalytics } from '@src/utils/api/service-analytics/recommendations-analytics';
import { SecurePolicyAnalytics } from '@src/utils/api/service-analytics/secure-policy-analytics';
import { SelfRegistrationServiceAnalytics } from '@src/utils/api/service-analytics/self-registration-service-analytics';
import { ServiceAnalytics } from '@src/utils/api/service-analytics/service-analytics';
import { SinglePaymentAnalytics } from '@src/utils/api/service-analytics/single-payment-services-tags';
import { SippTransferFundPerformanceAnalytics } from '@src/utils/api/service-analytics/sipp-transfer-fund-performance-analytics';
import { SippTransferFundsAnalytics } from '@src/utils/api/service-analytics/sipp-transfer-funds-analytics';
import { SippTransferInSubmissionServiceAnalytics } from '@src/utils/api/service-analytics/sipp-transfer-in-submission-service-analytics';
import { StrongerNudgeServiceAnalytics } from '@src/utils/api/service-analytics/stronger-nudge-service-analytics';
import { StrongerNudgeUpdateServiceAnalytics } from '@src/utils/api/service-analytics/stronger-nudge-update-service-analytics';
import { SubmitNavigatorQuestionnaireServiceAnalytics } from '@src/utils/api/service-analytics/submit-navigator-questionnaire-service-analytics';
import { TransferServiceAnalytics } from '@src/utils/api/service-analytics/transfer-service-analytics';
import { VisualisationServiceAnalytics } from '@src/utils/api/service-analytics/visualisation-service-analytics';
import { AxiosApiError } from '@src/utils/api/types';
import { Api200WithErrorsSchema } from '@src/validation/schemas/error';
import { PDFResponse } from '@src/validation/schemas/registration';
import { AxiosError, AxiosResponse, isAxiosError } from 'axios';

import { AnalyticsHistory } from './analytics-history';
import { trackStateEvent } from './use-analytics';
import { BiometricErrorTags } from './use-biometrics';

const loginServiceAnalytics = new LoginServiceAnalytics();
export const serviceAnalyticsInterpreters: ServiceAnalytics[] = [
  loginServiceAnalytics,
  new AdjustNavigatorQuestionnaireServiceAnalytics(),
  new BeneficiariesAnalytics(),
  new CustomerServiceAnalytics(),
  new DefaultFundServiceAnalytics(),
  new DirectWealthAccountServiceAnalytics(),
  new DocumentsListRetrievalAnalytics(),
  new DocumentRetrievalAnalytics(),
  new BeneficiariesServiceAnalytics(),
  new EditorialContentServiceAnalytics(),
  new FastTrackValidationServiceAnalytics(),
  new FastTrackRegisterServiceAnalytics(),
  new FinancialAdvicePaymentServiceAnalytics(),
  new FormValuesServiceAnalytics(),
  new IdverificationServiceAnalytics(),
  new InvestmentAssetDetailsServiceAnalytics(),
  new InvestmentProductPerformanceAnalytics(),
  new IsaAllowanceAnalytics(),
  new MessagesServiceAnalytics(),
  new MfaServiceAnalytics(),
  new SinglePaymentAnalytics(),
  new NativeSinglePaymentAnalytics(),
  new PaymentMethodsAnalytics(),
  new PensionConsolidationDetailsServiceAnalytics(),
  new PensionConsolidationSummaryServiceAnalytics(),
  new PensionIllustrationStatusServiceAnalytics(),
  new PensionIllustrationStatusServiceAnalytics(),
  new PerformanceOverTimeServiceAnalytics(),
  new PersonalInformationServiceAnalytics(),
  new PhoneNumbersServiceAnalytics(),
  new PostcodeLookupServiceAnalytics(),
  new ProductDetailsCashTransactionHistoryAnalytics(),
  new ProductDetailsInvestmentTransactionHistoryAnalytics(),
  new ProductDetailsPaymentHistoryAnalytics(),
  new ProductRetrieveAnalytics(),
  new SecurePolicyAnalytics(),
  new SelfRegistrationServiceAnalytics(),
  new SippTransferFundPerformanceAnalytics(),
  new SippTransferFundsAnalytics(),
  new SippTransferInSubmissionServiceAnalytics(),
  new SippTransferInSubmissionServiceAnalytics(),
  new StrongerNudgeServiceAnalytics(),
  new StrongerNudgeUpdateServiceAnalytics(),
  new SubmitNavigatorQuestionnaireServiceAnalytics(),
  new TransferServiceAnalytics(),
  new TailoredOfferSyncServiceAnalytics(),
  new UpdateMfaPreferenceServiceAnalytics(),
  new ChangeRetirementDateCaveatsAnalytics(),
  new ChangeRetirementDateServiceAnalytics(),
  new FindAndCombineCustomerDetailsAnalytics(),
  new FindAndCombinePensionProvidersAnalytics(),
  new NavigatorGetServiceAnalytics(),
  new IsaApplyBankAccountDetailsServiceAnalytics(),
  new IsaApplyFormValuesServiceAnalytics(),
  new IsaApplyValidateBankDetailsServiceAnalytics(),
  new IsaApplyChargesIllustrationSearchServiceAnalytics(),
  new IsaApplyChargesIllustrationIdServiceAnalytics(),
  new IsaApplyReviewServiceAnalytics(),
  new VisualisationServiceAnalytics(),
  new IsaApplySubmitServiceAnalytics(),
  new OpenAnIsaFaqAnalytics(),
];

const getData = (
  responseOrError: AxiosApiError | AxiosResponse<unknown, unknown>
) => {
  if (isAxiosError(responseOrError)) {
    return undefined;
  }

  if (Api200WithErrorsSchema.safeParse(responseOrError.data).success) {
    return undefined;
  }

  return responseOrError.data;
};

const getError = (
  responseOrError: AxiosApiError | AxiosResponse<unknown, unknown>
) => {
  if (isAxiosError(responseOrError)) {
    return responseOrError;
  }

  const apiWith200Error = Api200WithErrorsSchema.safeParse(
    responseOrError.data
  );

  if (apiWith200Error.success) {
    const err: AxiosApiError = new AxiosError(
      apiWith200Error.data.errorMessage,
      apiWith200Error.data.errorCode,
      responseOrError.config
    );
    return err;
  }

  return undefined;
};

const log = getLogger(trackApiAnalytics.name);

export async function trackApiAnalyticsSinglePdf(response: PDFResponse) {
  const currentInterpreter = serviceAnalyticsInterpreters.find((interpreter) =>
    interpreter.isKnownUrl(response.url, 'GET')
  );

  if (!currentInterpreter) {
    log.debug(`No Interpreter found for service analytics ${response.url}`);
    return;
  }

  currentInterpreter.setContext({
    data: response,
    error: undefined,
    statusCode: response.status,
    httpMethod: 'GET',
    url: response.url,
  });

  trackStateEvent(
    currentInterpreter.getServiceStateTag(),
    await currentInterpreter.getServiceContextData()
  );
}

export async function trackApiAnalytics(
  responseOrError: AxiosApiError | AxiosResponse<unknown, unknown>
) {
  try {
    const url = responseOrError.config?.url;
    if (!url) {
      log.debug('No URL found for service analytics', url);
      return;
    }

    const currentInterpreter = serviceAnalyticsInterpreters.find(
      (interpreter) =>
        interpreter.isKnownUrl(url, responseOrError.config?.method)
    );
    if (!currentInterpreter) {
      log.debug('No interpreter found for service analytics', url);
      return;
    }

    let data = getData(responseOrError);
    const error = getError(responseOrError);

    if (currentInterpreter.getServiceName() === 'policy') {
      data = currentInterpreter.getProduct(url, data);
    }
    currentInterpreter.setContext({
      data,
      error,
      statusCode: isAxiosError(responseOrError)
        ? responseOrError.response?.status
        : responseOrError.status,
      httpMethod: responseOrError.config?.method,
      url,
    });

    trackStateEvent(
      currentInterpreter.getServiceStateTag(),
      await currentInterpreter.getServiceContextData()
    );

    // Add enrichment context data
    const enrichmentData = currentInterpreter.getEnrichmentContextData();
    if (enrichmentData) {
      AnalyticsHistory.enrichmentContextData = new Map([
        ...AnalyticsHistory.enrichmentContextData,
        ...enrichmentData,
      ]);
    }
  } catch (e) {
    log.error(e);
  }
}

export const trackBiometricEvent = async (
  biometricError: BiometricErrorTags
) => {
  loginServiceAnalytics.setContext({
    error: new AxiosError(biometricError),
  });
  trackStateEvent(
    loginServiceAnalytics.getServiceStateTag(),
    await loginServiceAnalytics.getServiceContextData()
  );
};
