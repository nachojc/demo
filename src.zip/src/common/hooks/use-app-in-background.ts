import { useCallback, useEffect, useRef, useState } from 'react';
import { AppState } from 'react-native';

// this hook is used to determine or set whether the secure splash screen should be shown
// it can also be used to determine if the app is backgrounded or in the foreground
export const useAppInBackground = () => {
  const showSecurityScreenFromAppState = (appState: string) =>
    ['background', 'inactive'].includes(appState);

  const appState = useRef(AppState.currentState);

  const [showSecurityScreen, setShowSecurityScreen] = useState(
    showSecurityScreenFromAppState(appState.current)
  );

  const onChangeAppState = useCallback((nextAppState: string) => {
    setShowSecurityScreen(showSecurityScreenFromAppState(nextAppState));
  }, []);

  useEffect(() => {
    const appStateSubscription = AppState.addEventListener(
      'change',
      (nextAppState) => {
        onChangeAppState(nextAppState);
      }
    );

    return () => {
      appStateSubscription.remove();
    };
  }, [onChangeAppState]);

  return {
    showSecurityScreen,
    setShowSecurityScreen,
  };
};
