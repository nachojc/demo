import { getLogger } from '@interfaces/logger';
import { biometricPreference } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import * as LocalAuthentication from 'expo-local-authentication';
import { useCallback, useMemo } from 'react';
import { Platform } from 'react-native';
import { PERMISSIONS, request, RESULTS } from 'react-native-permissions';

import { BiometricResult } from './use-auth';
import { trackBiometricEvent } from './use-service-analytics';

export type BiometricErrorTags =
  | 'user-cancelled-biometric'
  | 'invalid-credentials-biometric'
  | 'biometrics-locked';

const log = getLogger(useBiometrics.name);

export function useBiometrics() {
  const isEnabled = useSelector(() => !!biometricPreference.get());
  const hasBeenSet = useSelector(() => biometricPreference.get() !== null);

  const isTouchID = useCallback(async () => {
    const result =
      await LocalAuthentication.supportedAuthenticationTypesAsync();
    return result[0] === LocalAuthentication.AuthenticationType.FINGERPRINT;
  }, []);

  const requestPermission = useCallback(async () => {
    return Platform.select({
      ios: Boolean(
        (await request(PERMISSIONS.IOS.FACE_ID)) === RESULTS.GRANTED ||
          (await isTouchID())
      ),
      android: true,
      default: false,
    });
  }, [isTouchID]);

  const authenticate = useCallback(async (): Promise<BiometricResult> => {
    try {
      const result = await LocalAuthentication.authenticateAsync({
        promptMessage: 'Confirm biometrics to continue',
        disableDeviceFallback: true,
        cancelLabel: 'Use credentials',
        fallbackLabel: '',
      });

      if (!result.success) {
        switch (result.error) {
          case 'user_cancel':
            await trackBiometricEvent('user-cancelled-biometric');
            return 'UserCancel';
          case 'authentication_failed':
            await trackBiometricEvent('invalid-credentials-biometric');
            return 'Fail';
          case 'not_available':
          case 'invalid_context':
          case 'not_enrolled':
            biometricPreference.set(false);
            return 'Changed';
          case 'lockout':
            await trackBiometricEvent('biometrics-locked');
            biometricPreference.set(false);
            return 'Lockout';
          case 'timeout':
            return 'Timeout';
          case 'system_cancel':
            return 'SystemCancel';
          default:
            log.debug('Unknown bio response: ' + result.error);
            return 'Fail';
        }
      }

      return 'Success';
    } catch (error) {
      log.debug('Unexpected authentication error: ', error);
      return 'Fail';
    }
  }, []);

  const enable = useCallback(() => biometricPreference.set(true), []);
  const disable = useCallback(() => biometricPreference.set(false), []);

  const shouldShowSetup = useCallback(
    async () =>
      (await LocalAuthentication.isEnrolledAsync()) &&
      (await LocalAuthentication.hasHardwareAsync()),
    []
  );

  return useMemo(
    () => ({
      authenticate,
      disable,
      enable,
      isEnabled,
      requestPermission,
      shouldShowSetup,
      hasBeenSet,
      isTouchID,
    }),
    [
      authenticate,
      disable,
      enable,
      isEnabled,
      requestPermission,
      shouldShowSetup,
      hasBeenSet,
      isTouchID,
    ]
  );
}
