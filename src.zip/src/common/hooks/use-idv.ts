import { IdvModel } from '@src/models/idv';
import {
  IdvPostRequestBody,
  IdvPutRequestBodyData,
} from '@src/validation/schemas/idv';
import { useMutation, useQuery } from '@tanstack/react-query';

/**
 * @description postIDV retrieves the sdkToken required to start ONFIDO sdk
 */
export const usePostIDVerification = () =>
  useMutation({
    mutationKey: ['postIDV'] as const,
    mutationFn: async (data: {
      securePartyId: string;
      postData: IdvPostRequestBody;
    }) => new IdvModel().idvCustomer(data.securePartyId, data.postData),
  });

/**
 *  @description putIDV after Onfido is complete and user has submitted
 *  his documents use this to let the backend that result of Onfido SDK
 */
export const usePutIDVerification = () =>
  useMutation({
    mutationKey: ['putIDV'] as const,
    mutationFn: async (data: {
      securePartyId: string;
      requestBody: IdvPutRequestBodyData;
    }) =>
      new IdvModel().idvCompleteVerification(
        data.securePartyId,
        data.requestBody
      ),
  });

/**
 *  @description getIDV to check whether the user is allow to use onfido.
 */
export const useGetIDVerification = (securePartyId?: string) =>
  useQuery({
    queryKey: ['getIDV', securePartyId],
    queryFn: () => new IdvModel().idvGetCustomerAllowed(securePartyId),
    enabled: !!securePartyId,
  });
