import { useEffect } from 'react';
import { BackHandler } from 'react-native';

export const useDisableGoBack = (shouldDisable: boolean) => {
  useEffect(() => {
    const backHandler = BackHandler.addEventListener(
      'hardwareBackPress',
      () => shouldDisable
    );

    return () => backHandler.remove();
  }, [shouldDisable]);
};
