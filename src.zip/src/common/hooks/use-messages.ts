import { Storage } from '@interfaces/storage';
import { MessagesModel } from '@src/models/messages';
import { QuoteModel } from '@src/models/quote';
import { Message, Messages } from '@src/validation/schemas/messages';
import { QuoteMessage, QuotesResponse } from '@src/validation/schemas/quotes';
import { useQuery } from '@tanstack/react-query';
import { useCallback } from 'react';

import { useCustomer } from './use-customer';

export const MessagesQueryKey = 'messages';
const READ_STATUS_KEY = 'readMessage';

export type MixedMessage = Message | QuoteMessage;
export type MixedMessages = MixedMessage[];

export const useGetMessages = (enabled = true) => {
  const { data, ...rest } = useQuery({
    // since it has more than one API calls, all fails if one fail
    // with Promise.allSettled, it prevents this to happen
    queryFn: async () => {
      const messages = await Promise.allSettled([
        new MessagesModel().getMessages(),
        QuoteModel.fetchQuotes(),
      ]);

      const getMessagesRejected = messages?.[0].status === 'rejected';

      // QuoteModel.fetchQuotes will fail for Enquirer users but we still want them to see messages
      // which is why we're not guarding against QuoteModel.fetchQuotes failure here
      if (getMessagesRejected) {
        throw new Error('Failed to fetch messages');
      }

      if (!messages?.length) {
        return [];
      }

      const fulfilledMessages = messages.filter(
        (m) => m.status === 'fulfilled'
      );

      if (!fulfilledMessages.length) {
        throw new Error('Both Messages and Quote API failed');
      }

      return fulfilledMessages
        .map((m) => {
          const { value } = m as PromiseFulfilledResult<
            Messages | QuotesResponse
          >;

          if (value) {
            if ('Messages' in value) {
              return value.Messages;
            }

            if ('messages' in value) {
              return value.messages;
            }
          }

          return undefined;
        })
        .filter((m) => !!m)
        .flat() as MixedMessages;
    },
    queryKey: [MessagesQueryKey],
    cacheTime: Infinity,
    staleTime: Infinity,
    networkMode: 'always',
    enabled,
  });
  return [data ?? [], rest] as const;
};

export const useMessage = (messageID: string) => {
  const [messages] = useGetMessages();
  return messages?.find((m) => m.id === messageID);
};

export function useMessageCenterReadStatus(enabled = true) {
  const { data: customer } = useCustomer();

  const readMessage = (id: string) => {
    Storage.set(`${READ_STATUS_KEY}.${customer?.PartyId}.${id}`, true);
  };

  const checkMessageReadStatus = (id: string) => {
    return Storage.contains(`${READ_STATUS_KEY}.${customer?.PartyId}.${id}`);
  };

  const [messages] = useGetMessages(enabled);

  const hasUnreadMessages = useCallback(
    () =>
      messages?.some((message) => {
        const isRead = checkMessageReadStatus(message.id);
        return !isRead;
      }) ?? false,
    [messages]
  );

  return {
    hasUnreadMessages,
    readMessage,
    checkMessageReadStatus,
  };
}
