import { ACPCore } from '@adobe/react-native-acpcore';
import {
  BreadcrumbVisibility,
  Instrumentation,
} from '@appdynamics/react-native-agent';
import { getLogger } from '@interfaces/logger';
import { analyticsDebugging } from '@interfaces/storage';
import { useFocusEffect } from '@react-navigation/native';
import { getAppInfoAnalytics } from '@src/utils/api/service-analytics/app-info-service-analytics';
import { APP_LANGUAGE } from '@src/utils/api/service-analytics/service-context-analytics-keys';
import { isDev } from '@src/utils/is-dev';
import { useCallback } from 'react';

import { usePoliciesContextKeys } from '../../../products/direct-wealth/common/hooks/use-policies-context-keys';
import { AnalyticsHistory } from './analytics-history';
import { useMotorsContextKeys } from './use-motor-context-keys';

export const screenLogger = createAnalyticsLogger(trackStateEvent.name);
/**
 * Used to track any screen event
 * @example
 * - navigation to a screen
 */
export function trackStateEvent(
  state: string,
  contextData?: Record<string, string>
) {
  if (isDev() && analyticsDebugging.get()) {
    screenLogger.debug(formatLog(state, recordToString(contextData)));
  }

  if (!isDev()) {
    // AppDynamics
    Instrumentation.leaveBreadcrumb(
      state,
      BreadcrumbVisibility.CRASHES_AND_SESSIONS
    );
    ACPCore.trackState(state, contextData);
  }
}

export const eventLogger = createAnalyticsLogger(trackUserEvent.name);
/**
 * Used to track any user event
 * @example
 * - button press
 */
export function trackUserEvent(
  action: string,
  contextData?: Record<string, string>
) {
  // Added this check, so if someone passes undefined by mistake it doesn't crash the app.
  // string.split would crash if run on undefined.
  if (action === undefined) {
    return;
  }

  if (isDev() && analyticsDebugging.get()) {
    eventLogger.debug(formatLog(action, recordToString(contextData)));
  }

  if (!isDev()) {
    // App Dynamics
    // The user event comes in the form
    // pension|details|your-retirement-age|change-retirement-age
    // So we strip off the last 3 items and asign them like this:
    // screenName: pension-details
    // eventName: your-retirement-age
    // className: change-retirement-age
    const eventArray = action.split('|');
    const cn = eventArray.pop() || '';
    const en = eventArray.pop() || '';
    const sn = eventArray.pop() || '';
    Instrumentation.trackUIEvent({
      screenName: sn,
      eventName: en,
      className: cn,
    });
    ACPCore.trackAction(action, contextData);
  }
}

/**
 * Adobe exports ACPCore as a global, so no instances needed
 * Instead: Import trackStateEvent/trackUserEvent directly
 */
export function useAnalytics() {
  const { policiesContextKeysRef } = usePoliciesContextKeys();
  const { motorsContextKeysRef } = useMotorsContextKeys();

  if (!AnalyticsHistory.enrichmentContextData.has(APP_LANGUAGE)) {
    AnalyticsHistory.enrichmentContextData = new Map([
      ...AnalyticsHistory.enrichmentContextData,
      ...getAppInfoAnalytics(),
    ]);
  }

  const trackStateEventHandler = useCallback(
    (state: string, contextData?: Record<string, string>) => {
      trackStateEvent(state, {
        ...contextData,
        ...policiesContextKeysRef.current,
        ...motorsContextKeysRef.current,
      });
    },
    [motorsContextKeysRef, policiesContextKeysRef]
  );

  const trackUserEventHandler = useCallback(
    (state: string, contextData?: Record<string, string>) =>
      trackUserEvent(state, {
        ...contextData,
        ...policiesContextKeysRef.current,
        ...motorsContextKeysRef.current,
        ...Object.fromEntries(AnalyticsHistory.enrichmentContextData),
      }),
    [motorsContextKeysRef, policiesContextKeysRef]
  );

  return {
    trackStateEvent: trackStateEventHandler,
    trackUserEvent: trackUserEventHandler,
  };
}

export const useTrackStateEvent = (
  pageTag: string | null,
  contextData?: Record<string, string>
) => {
  const { policiesContextKeysRef } = usePoliciesContextKeys();
  const { motorsContextKeysRef } = useMotorsContextKeys();

  useFocusEffect(
    useCallback(() => {
      if (pageTag === null) {
        return;
      }
      AnalyticsHistory.setPageTag(pageTag);
      const contextDataWithNavLevels =
        AnalyticsHistory.getAdditionalContextData(contextData);

      trackStateEvent(pageTag, {
        ...contextDataWithNavLevels,
        ...policiesContextKeysRef.current,
        ...motorsContextKeysRef.current,
      });
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [policiesContextKeysRef, pageTag])
  );
};

export const recordToString = (p?: Record<string, string>): string =>
  Object.entries(p ?? {})
    .map(([key, value]) => `${key} : ${value}`)
    .join('\n');

export const formatLog = (event: string, contextData: string) => `
 event: ${event}
 contextData: ${contextData}`;

export function createAnalyticsLogger(fnName: string) {
  return getLogger(useAnalytics.name + ' | ' + fnName);
}

/** Useful for screens with dynamic tags based on content, where a tag is not always used. */
export const useConditionalTrackStateEvent = (
  pageTag?: string,
  contextData?: Record<string, string>
) => {
  const { policiesContextKeysRef } = usePoliciesContextKeys();
  const { motorsContextKeysRef } = useMotorsContextKeys();

  useFocusEffect(
    useCallback(() => {
      if (pageTag) {
        AnalyticsHistory.setPageTag(pageTag);
        const contextDataWithNavLevels =
          AnalyticsHistory.getAdditionalContextData(contextData);
        trackStateEvent(pageTag, {
          ...contextDataWithNavLevels,
          ...policiesContextKeysRef.current,
          ...motorsContextKeysRef.current,
        });
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [policiesContextKeysRef])
  );
};
