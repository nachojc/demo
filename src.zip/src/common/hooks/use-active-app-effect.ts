import { useEffect } from 'react';
import { AppState } from 'react-native';

/**
 * Triggers a callback when the app becomes active, i.e. after app returns from background
 * @example
 * ```
 *useActiveAppEffect(
    useCallback(() => {
      doSomething();
    }, [doSomething])
  );
  ```
 */

export const useActiveAppEffect = (callback: () => void) => {
  // run after app is restored from background
  useEffect(() => {
    const appStateSubscription = AppState.addEventListener(
      'change',
      (nextAppState) => {
        if (nextAppState === 'active') {
          callback();
        }
      }
    );

    return () => {
      appStateSubscription.remove();
    };
  }, [callback]);
};
