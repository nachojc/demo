import { useSelector } from '@legendapp/state/react';
import { useState } from 'react';

import { FeatureFlags } from '../../feature-flags';
import { useAuth } from './use-auth';
import { useMyDriveClearDatabase } from './use-mydrive-clear-database';

export const useResetSignOut = () => {
  const { signOut } = useAuth();
  const isMyDriveMockDataEnabled = useSelector(FeatureFlags.myDriveUseMockData);
  const { clearMyDriveDB } = useMyDriveClearDatabase();
  const [logoutDialogVisible, setLogoutDialogVisible] = useState(false);

  const resetSignOut = (isLogoutDialogVisible: boolean) => {
    if (isMyDriveMockDataEnabled) {
      clearMyDriveDB();
    }
    setLogoutDialogVisible(isLogoutDialogVisible);
    signOut();
  };

  return { resetSignOut, logoutDialogVisible };
};
