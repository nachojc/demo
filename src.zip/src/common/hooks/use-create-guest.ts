import {
  RegistrationModel,
  ValidateCustomerRequest,
} from '@src/models/registration';
import { useMutation } from '@tanstack/react-query';

export type CreateUserPayload = {
  firstName: string;
  lastName: string;
  emailAddress: string;
  password: string;
};

export const useGuestCustomer = () => {
  const { mutateAsync: createNewGuest } = useMutation({
    mutationKey: ['createGuest'] as const,
    mutationFn: async (customerDetails: CreateUserPayload) =>
      new RegistrationModel().createGuest(customerDetails),
  });

  const { mutateAsync: validateGuest } = useMutation({
    mutationKey: ['validateGuest'] as const,
    mutationFn: async (customerDetails: ValidateCustomerRequest) =>
      new RegistrationModel().validateCustomer(customerDetails),
  });

  return { createNewGuest, validateGuest };
};
