import { useSelector } from '@legendapp/state/react';
import { UseQueryOptionsGenerics } from '@src/common/types/react-query';
import { MfaModel } from '@src/models';
import { accessToken } from '@src/utils/api';
import { useQuery } from '@tanstack/react-query';

export const useMfaPreferences = (
  options?: UseQueryOptionsGenerics<
    InstanceType<typeof MfaModel>['getMfaPreference'],
    'Mfa Preferences'
  >
) => {
  const enabled = useSelector(() => typeof accessToken.get() === 'string');
  return useQuery({
    queryFn: new MfaModel().getMfaPreference,
    queryKey: ['Mfa Preferences'],
    enabled,
    retry: 0,
    staleTime: 30000,
    /**
     * When error occurs with status codes [401, 403, 404, 423], app was triggering analytics tags from all the irrelevant screens since this is being used in other hooks.
     * to fix this added 'retryOnMount: false' which will prevent it calling multiple times more succinctly https://tanstack.com/query/v4/docs/framework/react/reference/useQuery
     */
    retryOnMount: false,
    refetchOnMount: false,
    ...options,
  });
};
