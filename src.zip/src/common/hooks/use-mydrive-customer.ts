import { useCustomer } from './use-customer';

export const useMyDriveCustomer = () => {
  const { data: customer } = useCustomer();

  const myDriveVas = customer?.ValueAddedServices?.find(
    (vas) => vas.Name === 'MyDrive'
  );
  const myDriveVasStatus = myDriveVas?.Status;

  const isMyDriveActive = myDriveVasStatus === 'Active';

  const isMyDrivePending = myDriveVasStatus === 'Pending';

  const isMyDriveEligible = !!customer?.Eligibilities?.find(
    (eligibility) => eligibility.Type === 'MyDrive'
  )?.Value;

  const myDriveVasReference = myDriveVas?.Reference;

  const myDriveVasStartDate = myDriveVas?.StartDate;

  return {
    isMyDriveActive,
    isMyDrivePending,
    isMyDriveEligible,
    myDriveVasReference,
    myDriveVasStartDate,
  };
};
