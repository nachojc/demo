import { getLogger } from '@interfaces/logger';
import {
  Aviva_Digital_MobileApi_Endpoints_Support_Model_OpenHoursModel,
  Aviva_Digital_MobileApi_Endpoints_Support_Model_PhoneNumberModel,
} from '@src/api/generated/requests';
import { SupportInfoModel } from '@src/models/support-info';
import {
  PensionProduct,
  PensionProviderEnum,
} from '@src/validation/schemas/product/pension-product';
import { useQuery } from '@tanstack/react-query';
import { t } from 'i18next';

const log = getLogger(useSupportInfo.name);

export function useSupportInfo(
  pensionProvider: PensionProduct['PensionProvider'],
  ...args: Parameters<InstanceType<typeof SupportInfoModel>['fetchSupportInfo']>
) {
  return useQuery({
    queryKey: ['useSupportInfo', ...Object.values(args)],
    queryFn: async () => {
      try {
        const data = await new SupportInfoModel().fetchSupportInfo(...args);
        const supportDataWithBankHolidays = {
          ...data,
          openHours: [
            ...(data.openHours ?? []),
            {
              day: 'Bank holidays',
              time: 'Closed',
            } as Aviva_Digital_MobileApi_Endpoints_Support_Model_OpenHoursModel,
          ],
        };

        return {
          content: data.content,
          openHours:
            pensionProvider !== 'MyMoney'
              ? supportDataWithBankHolidays.openHours
              : data.openHours,
        };
      } catch (error) {
        return parseSupportData(pensionProvider);
      }
    },
    select: (data) => {
      return parseSupportData(pensionProvider, data);
    },
    onError: log.error,
  });
}

const parseSupportData = (
  pensionProvider?: PensionProduct['PensionProvider'],
  data?: Aviva_Digital_MobileApi_Endpoints_Support_Model_PhoneNumberModel
) => {
  switch (pensionProvider) {
    case PensionProviderEnum.Unisure:
      return {
        phoneNumber: data?.content || t('supportInfo.unisure.phone'),
        openHours:
          data?.openHours ||
          t('supportInfo.unisure.openingHours', { returnObjects: true }),
      };
    case PensionProviderEnum.MyMoney:
      return {
        phoneNumber: data?.content || t('supportInfo.myMoney.phone'),
        openHours:
          data?.openHours ||
          t('supportInfo.myMoney.openingHours', { returnObjects: true }),
      };
    default:
      return {
        phoneNumber: data?.content || t('supportInfo.bancs.phone'),
        openHours:
          data?.openHours ||
          t('supportInfo.bancs.openingHours', { returnObjects: true }),
      };
  }
};
