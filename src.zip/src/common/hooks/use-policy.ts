import { getLogger } from '@interfaces/logger';
import { PolicyModel } from '@src/models/policy/policy-model';
import { POLICY_RETRY_COUNT, policyRetryDelay } from '@src/utils/api';
import { useQuery, UseQueryOptions } from '@tanstack/react-query';

const log = getLogger(usePolicy.name);

export function usePolicy(
  securePolicyNumber: string,
  opts?: UseQueryOptions<
    Awaited<ReturnType<InstanceType<typeof PolicyModel>['fetchPolicy']>>
  >
) {
  const { data, ...rest } = useQuery({
    queryKey: ['policy', securePolicyNumber],
    queryFn: () => new PolicyModel().fetchPolicy(securePolicyNumber),
    onError: (e) => log.apiError(e),
    retry: POLICY_RETRY_COUNT,
    retryDelay: policyRetryDelay,
    ...opts,
  });

  return [data, rest] as const;
}
