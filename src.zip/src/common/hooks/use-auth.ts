import { useCustomerQuery } from '@hooks/use-customer-query';
import { refreshToken } from '@interfaces/secure-store';
import {
  dpaUnlockResultShowLogout,
  loginCount,
  mfaShownThisSession,
  username as Username,
} from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import {
  LoginMethodStore,
  LoginMethodTypes,
} from '@src/utils/api/service-analytics/login-service-analytics';
import { AuthResponse } from '@src/validation/schemas/auth';
import { FastTrackSignUpForm } from '@src/validation/schemas/fast-track-signup-form';
import { MfaCredentials } from '@src/validation/schemas/mfa';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { deleteUserCacheDir } from '@utils/user-files';
import { Mutex } from 'async-mutex';
import { useContext } from 'react';

import { usePoliciesContextKeys } from '../../../products/direct-wealth/common/hooks/use-policies-context-keys';
import { AuthenticationModel } from '../../models';
import { FastTrackRegistrationModel } from '../../models/fast-track-signup';
import { accessToken } from '../../utils/api';
import { Credentials } from '../../validation/schemas/credentials';
import { AuthContext } from '../providers/auth';
import { useBiometrics } from './use-biometrics';
import { useMfaPreferences } from './use-mfa-preferences';

export type BiometricResult =
  | 'Success'
  | 'UserCancel'
  | 'Fail'
  | 'Changed'
  | 'Lockout'
  | 'Timeout'
  | 'SystemCancel';

type SignInResponse = {
  biometricResult?: BiometricResult;
  requiresMfa?: boolean;
};

const signInMutex = new Mutex();

export const useAuth = () => {
  const queryClient = useQueryClient();
  const {
    isSignedIn,
    setIsSignedIn,
    hasSignedInThisSession,
    setHasSignedInThisSession,
  } = useContext(AuthContext);
  const { deletePoliciesContextKeysObservable } = usePoliciesContextKeys();
  const biometric = useBiometrics();
  const mfaPreference = useMfaPreferences();
  const { fetchCustomerToQueryCache } = useCustomerQuery();
  const { mutateAsync: authenticate } = useMutation({
    mutationKey: ['authenticate'] as const,
    mutationFn: (credentials: Credentials) =>
      new AuthenticationModel().authenticate(credentials),
  });

  const { mutateAsync: authenticateWithRefreshToken } = useMutation({
    mutationKey: ['authenticateWithRefreshToken'] as const,
    mutationFn: (token: string) =>
      new AuthenticationModel().authenticateWithRefreshToken(token),
  });

  const { mutateAsync: authenticateWithMfaCode } = useMutation({
    mutationKey: ['authenticateWithMfaCode'] as const,
    mutationFn: (mfaCredentials: { mfaCode: string; username: string }) =>
      new AuthenticationModel().authenticateWithMfaCode(mfaCredentials),
  });

  const { mutateAsync: signUp } = useMutation({
    mutationKey: ['signUp'] as const,
    mutationFn: async (data: {
      formValues: FastTrackSignUpForm;
      activationCode: string;
    }) =>
      new FastTrackRegistrationModel().signup(
        data.formValues,
        data.activationCode
      ),
  });

  const { mutateAsync: recordLogin } = useMutation({
    mutationKey: ['recordLogin'] as const,
    mutationFn: async () => new AuthenticationModel().recordLogin(),
  });

  const signIn = async (credentials: Credentials) => {
    if (!LoginMethodStore.get()) {
      LoginMethodStore.set(LoginMethodTypes.UsernameAndPassword);
    }

    const data = await authenticate(credentials);

    return handleSignInAttempt(credentials.username, data);
  };

  const lockedSignInWithRefreshToken = async (
    username: string,
    biometricResult?: BiometricResult
  ) => {
    return signInMutex.runExclusive(async () => {
      const token = refreshToken.get() ?? '';
      const data = await authenticateWithRefreshToken(token);
      return handleSignInAttempt(username, data, biometricResult);
    });
  };

  const biometricSignIn = async () => {
    LoginMethodStore.set(LoginMethodTypes.Biometric);

    const biometricResult = await biometric.authenticate();

    return { biometricResult };
  };

  const signInWithRefreshToken = async (
    username: string,
    biometricResult: BiometricResult
  ) => {
    LoginMethodStore.set(LoginMethodTypes.Biometric);

    if (biometricResult === 'Success') {
      return lockedSignInWithRefreshToken(username, biometricResult);
    }
    return { biometricResult };
  };

  const signInForBackgroundService = async (username: string) => {
    return lockedSignInWithRefreshToken(username);
  };

  const signInWithMfa = async (mfaCode: MfaCredentials['mfaCode']) => {
    const usernameValue = Username.get();
    if (!usernameValue) {
      throw new Error('Username cannot be null');
    }

    LoginMethodStore.set(LoginMethodTypes.MfaCode);

    await authenticateWithMfaCode({
      mfaCode,
      username: usernameValue,
    });

    await fetchCustomerToQueryCache(queryClient);
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    await recordLogin().catch(() => {});
  };

  const handleSignInAttempt = async (
    username: string,
    data: AuthResponse,
    bioResult?: BiometricResult
  ): Promise<SignInResponse> => {
    Username.set(username);

    if (data?.errorCode === 'mfa.required') {
      await mfaPreference.refetch();
      return { requiresMfa: true };
    }

    await fetchCustomerToQueryCache(queryClient);
    // eslint-disable-next-line @typescript-eslint/no-empty-function
    await recordLogin().catch(() => {});

    setHasSignedInThisSession(true);

    return { biometricResult: bioResult, requiresMfa: false };
  };

  const authenticateGuestCustomer = async (credentials: Credentials) => {
    await authenticate(credentials);
  };

  const signOut = async () => {
    deletePoliciesContextKeysObservable();
    accessToken.set(null);
    await deleteUserCacheDir();
    // TODO: remove cookies. Use either clearAll() or removeSessionCookies(), from https://github.com/react-native-cookies/cookies
    await setIsSignedIn(false);
    dpaUnlockResultShowLogout.set(false);
    mfaShownThisSession.set(false);
    queryClient.clear();
  };

  const incrementLoginCount = () => {
    const currentCount = loginCount.get() ?? 0;
    loginCount.set(currentCount + 1);
  };

  const hasSetUsername = useSelector(() => Username.get() !== null);

  return {
    isSignedIn,
    signIn,
    biometricSignIn,
    signInWithRefreshToken,
    signInForBackgroundService,
    authenticateGuestCustomer,
    signInWithMfa,
    signOut,
    signUp,
    hasSignedInThisSession,
    setIsSignedIn,
    setHasSignedInThisSession,
    incrementLoginCount,
    hasSetUsername,
    authenticate,
  };
};
