import { AppName, appStore } from '@constants/app-store';
import { Linking, Platform } from 'react-native';

export const useAppStore = () => {
  const openAppStore = (appName: AppName) => {
    const appUrl = appStore[Platform.OS]?.[appName];
    if (appUrl) {
      Linking.openURL(appUrl);
    }
  };

  return { openAppStore };
};
