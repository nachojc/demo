import { PensionProjectionModel } from '@src/models/pension-projection';
import { useQuery } from '@tanstack/react-query';

import { getLogger } from '../interfaces/logger';

const log = getLogger(usePensionProjection.name);

export function usePensionProjection(
  ...args: Parameters<
    InstanceType<typeof PensionProjectionModel>['fetchProjections']
  >
) {
  return useQuery({
    queryKey: ['projections', ...Object.values(args)],
    queryFn: () => new PensionProjectionModel().fetchProjections(...args),
    onError: log.error,
  });
}
