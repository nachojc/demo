import { ProfileModel } from '@src/models';
import { useMutation, useQuery } from '@tanstack/react-query';

import { queryClient } from '../providers/react-query';

export const usePutCommunicationPreferences = () =>
  useMutation({
    mutationKey: ['putCommunicationPreferences'],
    mutationFn: new ProfileModel().putCommunicationPreferences,
    onSuccess: (_, data) => {
      queryClient.setQueryData(['getCommunicationPreferences'], {
        paperlessPolicyDocuments: data.paperlessPolicyDocuments.map(
          ({ documentType, isPaperless }) => ({
            DocumentType: documentType,
            IsPaperless: isPaperless,
          })
        ),
      });
    },
  });

export const useGetCommunicationPreferences = () =>
  useQuery({
    queryKey: ['getCommunicationPreferences'],
    queryFn: new ProfileModel().getCommunicationPreferences,
  });
