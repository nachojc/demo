import { getLogger } from '@interfaces/logger';
import { firebase } from '@react-native-firebase/remote-config';
import { FeatureFlags } from '@src/feature-flags';
import { useEffect, useState } from 'react';

const log = getLogger(useRemoteConfig.name);

/**
 * @description
 * useRemoteConfig will update the {@link FeatureFlags} values with firebase config values
 * In Development this no-ops and is set to true on mount
 *
 * @returns
 * true - Config has been loaded, either from remote or from defaults
 *
 * false - Config is still loading, and defaults are not yet available
 */
export function useRemoteConfig(isDev = __DEV__) {
  const [isRemoteConfigInitialised, setIsRemoteConfigInitialised] =
    useState(false);

  useEffect(() => {
    if (isDev) {
      setIsRemoteConfigInitialised(true);
    } else {
      (async () => {
        try {
          const config = firebase.remoteConfig();

          await config.setDefaults({ is_eol: false });
          await config.fetchAndActivate();

          const isEol = config.getBoolean('is_eol');
          FeatureFlags.dwEOLEnabled.set(isEol);

          log.info(
            `Configs were retrieved from the backend and activated. EOL=${isEol}`
          );
        } catch (error) {
          log.warn('Remote config failed, falling back to defaults.');
        } finally {
          setIsRemoteConfigInitialised(true);
        }
      })();
    }
  }, []);

  return isRemoteConfigInitialised;
}
