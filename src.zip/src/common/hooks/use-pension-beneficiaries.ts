import { getLogger } from '@interfaces/logger';
import { PensionBeneficiaries } from '@src/models/pension-beneficiaries';
import { generateUUID } from '@src/utils/uuid';
import { useQuery } from '@tanstack/react-query';

type Args = Parameters<
  InstanceType<typeof PensionBeneficiaries>['pensionBeneficiaries']
>;

export const getQueryKey = (...args: Args) =>
  ['pensionBeneficiaries', ...Object.values(args)] as const;

const log = getLogger(usePensionBeneficiaries.name);

export function usePensionBeneficiaries(isMyMoney: boolean, ...args: Args) {
  return useQuery({
    queryKey: getQueryKey(...args),
    queryFn: async () => {
      const data = await new PensionBeneficiaries().pensionBeneficiaries(
        ...args
      );

      return data.beneficiaries?.map((beneficiary) => ({
        __id: generateUUID(),
        ...beneficiary,
      }));
    },
    onError: log.error,
    enabled: !isMyMoney,
  });
}
