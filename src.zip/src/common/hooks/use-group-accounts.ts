import { getLogger } from '@interfaces/logger';
import { GroupAccountModel } from '@src/models/group-account';
import { useQueries } from '@tanstack/react-query';

const log = getLogger(useGroupAccounts.name);

/**
 * Gets the group account list given the account numbers.
 * @param accountNumbers list of account numbers used to load the group account data.
 * @returns the list of @GroupAccount data associated with the each account number in list
 */
export function useGroupAccounts(
  accountNumbers: (string | undefined | null)[]
) {
  const results = useQueries({
    queries: accountNumbers
      .filter((item) => !!item)
      .map((accountNumber) => ({
        queryKey: ['groupAccounts', accountNumber],
        queryFn: () =>
          new GroupAccountModel().fetchGroupAccount(accountNumber as string),
        onError: (e: unknown) => {
          log.error({ accountNumber, e });
        },
        enabled: !!accountNumber,
      })),
  });

  return {
    data: results.map((result) => result.data),
    isLoading: results.some((result) => result.isLoading),
    isError: results.some((result) => result.error),
  };
}
