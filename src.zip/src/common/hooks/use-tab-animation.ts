import {
  useAnimatedStyle,
  useDerivedValue,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';

export const useTabAnimation = (initialTabIndex: number, tabWidth: number) => {
  const position = useSharedValue(initialTabIndex);

  const selectedTabIndicatorPosition = useDerivedValue(() => {
    return position.value * tabWidth;
  }, [tabWidth]);

  const animateTabSelection = (index: number, duration?: number) => {
    position.value = withTiming(index, {
      duration: duration ?? 300,
    });
  };

  const animatedStyles = useAnimatedStyle(() => {
    return {
      width: tabWidth,
      transform: [{ translateX: selectedTabIndicatorPosition.value }],
    };
  }, [tabWidth]);

  return {
    animatedStyles,
    animateTabSelection,
  };
};
