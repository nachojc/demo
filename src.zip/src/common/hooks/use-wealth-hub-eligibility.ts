import { getLogger } from '@interfaces/logger';
import { WealthHubEligibilityModel } from '@src/models/wealth-hub-eligibility';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

type FetchWealthHubEligibilityResult = Awaited<
  ReturnType<
    InstanceType<typeof WealthHubEligibilityModel>['fetchWealthHubEligibility']
  >
>;

type WealthHubEligibilityQueryResult = UseQueryResult<
  FetchWealthHubEligibilityResult,
  unknown
>;

type WealthHubEligibilityReturn = [
  data: WealthHubEligibilityQueryResult['data'],
  queryResults: Omit<WealthHubEligibilityQueryResult, 'data'>
];

const log = getLogger(useWealthHubEligibility.name);

export function useWealthHubEligibility(
  enabled = true
): WealthHubEligibilityReturn {
  const { data, ...rest } = useQuery({
    queryKey: ['wealthHubEligibility'],
    queryFn: new WealthHubEligibilityModel().fetchWealthHubEligibility,
    onError: (e) => {
      log.apiError(e);
    },
    enabled,
  });
  return [data, rest];
}
