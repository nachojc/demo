import { Aviva_Digital_MobileApi_Endpoints_CustomerProfileChange_V1_Model_ChangeAddressModel as ChangeAddress } from '@src/api/generated/requests';
import { ProfileModel } from '@src/models';
import { useMutation } from '@tanstack/react-query';

export const useChangeAddress = () => {
  const { mutateAsync: changeAddress, isLoading } = useMutation({
    mutationKey: ['changeAddress'] as const,
    mutationFn: async (newAddress: ChangeAddress) => {
      return new ProfileModel().changeAddress(newAddress);
    },
  });
  return { changeAddress, isLoading };
};
