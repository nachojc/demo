import { getLogger } from '@interfaces/logger';
import { IdvModel } from '@src/models/idv';
import { Customer } from '@src/validation/schemas/customer';
import { useQuery, UseQueryResult } from '@tanstack/react-query';

type IdvGetCustomerAllowedResult = Awaited<
  ReturnType<InstanceType<typeof IdvModel>['idvGetCustomerAllowed']>
>;

type IdvGetCustomerAllowedQueryResult = UseQueryResult<
  IdvGetCustomerAllowedResult,
  unknown
>;

export type PhotoIdvStatusProp = 'inProgress' | 'allowed' | undefined;

type UserPhotoIdvStatusReturn = [
  queryResults: Omit<IdvGetCustomerAllowedQueryResult, 'data'>,
  photoIdvStatus?: PhotoIdvStatusProp
];

const log = getLogger(useUserPhotoIdvStatus.name);

export function useUserPhotoIdvStatus(
  customer?: Customer
): UserPhotoIdvStatusReturn {
  const enabled = !!customer && customer?.CustomerDPALevel === '1';

  const { data, ...rest } = useQuery({
    queryKey: [['idverification']] as const,
    queryFn: () =>
      new IdvModel().idvGetCustomerAllowed(customer?.SecurePartyId),
    onError: (e) => {
      log.apiError(e);
    },
    enabled,
  });
  const photoIdvStatus = data?.photoIdvStatus as PhotoIdvStatusProp;

  return [rest, photoIdvStatus];
}
