import CampaignClassic from '@aviva/rn-bridge-campaignclassic/src';
import { getLogger } from '@interfaces/logger';
import {
  notificationAppPreference,
  notificationDevicePreference,
  notificationsPermissionsBlockedCount,
} from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { useCallback, useEffect, useMemo } from 'react';
import { Platform } from 'react-native';
import {
  checkNotifications,
  requestNotifications,
} from 'react-native-permissions';

import { useActiveAppEffect } from './use-active-app-effect';
import { useChat } from './use-chat';
import { useCustomer } from './use-customer';
import { usePushNotification } from './use-push-notifications';

const log = getLogger(useNotifications.name);

export function useNotifications() {
  const { getFCMToken, getPushNotificationTokenForAdobe } =
    usePushNotification();
  const { initChat, setNuanceFCMToken } = useChat();
  const { data: customer } = useCustomer();

  const isEnabledOnApp = useSelector(() => !!notificationAppPreference.get());

  const hasBeenSet = useSelector(
    () => notificationAppPreference.get() !== null
  );

  const hasUserEnabledNotificationsOnDevice = useSelector(
    () => !!notificationDevicePreference.get()
  );

  const canRequestPermissions = async () =>
    (await checkNotifications()).status === 'denied';

  const requestPermission = useCallback(async () => {
    try {
      const request = await requestNotifications(['alert', 'badge']);
      const isGranted = request.status === 'granted';
      return isGranted;
    } catch (error) {
      log.debug(error);
      return false;
    }
  }, []);

  const shouldShowSetup = useCallback(async () => {
    const isAndroid = Platform.OS === 'android';
    const isAndroid13Plus = isAndroid && (Platform.Version as number) >= 33;
    const androidNotifications =
      isAndroid && !hasBeenSet && hasUserEnabledNotificationsOnDevice;

    if (androidNotifications) {
      return true;
    }
    const allPlatforms = Platform.OS === 'ios' || isAndroid13Plus;
    return allPlatforms && (await canRequestPermissions());
  }, [hasBeenSet, hasUserEnabledNotificationsOnDevice]);

  const getPermissionStatus = useCallback(
    async () => ({
      result: (await checkNotifications()).status,
    }),
    []
  );

  const registerTokens = useCallback(async () => {
    const { result } = await getPermissionStatus();
    const tokenForAdobe = await getPushNotificationTokenForAdobe(
      result === 'granted'
    );
    const tokenForNuance = await getFCMToken(result === 'granted');
    if (tokenForAdobe && customer?.PartyId) {
      CampaignClassic.registerDevice(tokenForAdobe, customer?.PartyId);
    }

    if (tokenForNuance) {
      initChat();
      setNuanceFCMToken(tokenForNuance);
    }
  }, [
    customer?.PartyId,
    getFCMToken,
    getPushNotificationTokenForAdobe,
    initChat,
    setNuanceFCMToken,
    getPermissionStatus,
  ]);

  const enable = useCallback(async () => {
    const isGranted = await requestNotifications(['alert', 'badge']);
    if (isGranted.status === 'blocked') {
      notificationsPermissionsBlockedCount.set(
        notificationsPermissionsBlockedCount.get() + 1
      );
    }

    if (isGranted.status === 'granted') {
      notificationAppPreference.set(true);
      registerTokens();
    }
  }, [registerTokens]);

  const disable = useCallback(() => notificationAppPreference.set(false), []);

  const openRequestNotificationsPermission = useCallback(async () => {
    try {
      if (
        (!hasBeenSet && hasUserEnabledNotificationsOnDevice) ||
        (await requestPermission())
      ) {
        const { result } = await getPermissionStatus();
        if (result === 'granted') {
          await enable();
        }
      } else {
        disable();
      }
    } catch (error) {
      log.debug(error);
    }
  }, [
    disable,
    enable,
    getPermissionStatus,
    hasBeenSet,
    hasUserEnabledNotificationsOnDevice,
    requestPermission,
  ]);

  return useMemo(
    () => ({
      hasUserEnabledNotificationsOnDevice,
      isEnabledOnApp,
      shouldShowSetup,
      requestPermission,
      hasBeenSet,
      registerTokens,
      enable,
      disable,
      getPermissionStatus,
      openRequestNotificationsPermission,
      shouldListenPushNotifications:
        isEnabledOnApp && hasUserEnabledNotificationsOnDevice,
    }),
    [
      hasUserEnabledNotificationsOnDevice,
      isEnabledOnApp,
      registerTokens,
      requestPermission,
      shouldShowSetup,
      hasBeenSet,
      enable,
      disable,
      getPermissionStatus,
      openRequestNotificationsPermission,
    ]
  );
}

export const useCheckDeviceNotificationPermissions = () => {
  const { getPermissionStatus, hasBeenSet, registerTokens } =
    useNotifications();

  useEffect(() => {
    const checkDeviceSettings = async () => {
      if (!hasBeenSet) {
        const { result } = await getPermissionStatus();
        if (result === 'granted') {
          notificationDevicePreference.set(true);
        }
      }
    };
    checkDeviceSettings();
  }, [getPermissionStatus, hasBeenSet]);

  const updateToggleStatus = async () => {
    const { result: deviceSettings } = await getPermissionStatus();
    const isAndroid13Plus =
      Platform.OS === 'android' && (Platform.Version as number) >= 33;

    if (deviceSettings === 'granted') {
      if (isAndroid13Plus || Platform.OS === 'ios') {
        notificationAppPreference.set(true);
      }
      notificationDevicePreference.set(true);
      registerTokens();
    } else {
      notificationDevicePreference.set(false);
    }
  };

  useActiveAppEffect(() => {
    updateToggleStatus();
  });
};
