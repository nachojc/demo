import { getLogger } from '@interfaces/logger';
import {
  activityRecognitionPermissionsBlockedCount,
  activityRecognitionPermissionsResponded,
} from '@interfaces/storage';
import { useCallback } from 'react';
import {
  check,
  PERMISSIONS,
  PermissionStatus,
  request,
} from 'react-native-permissions';

import { useGoToSettings } from './use-go-to-settings';

const log = getLogger(useActivityRecognition.name);

export function useActivityRecognition() {
  const maxBlockedCount = 1;

  const { goToSettings } = useGoToSettings();

  const checkPermission = async () => {
    try {
      const status = await check(PERMISSIONS.ANDROID.ACTIVITY_RECOGNITION);
      return status;
    } catch (error) {
      return 'unavailable' as PermissionStatus;
    }
  };

  const requestPermission = useCallback(async () => {
    try {
      const result = await request(PERMISSIONS.ANDROID.ACTIVITY_RECOGNITION);

      // android only returns blocked from 'request' calls so we can't use 'check'. We need to track how many
      // times a user denies the permissions so that we can send them to settings when request limit is exceeded
      if (result === 'blocked') {
        const blockedCount = activityRecognitionPermissionsBlockedCount.get();
        if (blockedCount >= maxBlockedCount) {
          goToSettings();
        } else {
          activityRecognitionPermissionsBlockedCount.set(blockedCount + 1);
        }
      }
    } catch (error) {
      log.error(error);
    }
  }, [goToSettings]);

  const getCanRequestActivityRecognitionPermissions = async () => {
    const result = await checkPermission();
    const permissionDenied = result === 'denied';

    const canRequestActivityRecognition =
      permissionDenied && !activityRecognitionPermissionsResponded.get();
    return { canRequestActivityRecognition };
  };

  return {
    checkPermission,
    requestPermission,
    getCanRequestActivityRecognitionPermissions,
  };
}
