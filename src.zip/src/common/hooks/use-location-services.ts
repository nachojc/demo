import {
  locationKeepApproxBlockedCount,
  locationPermissionsBlockedCount,
  locationPermissionsResponded,
} from '@interfaces/storage';
import { getSystemVersion } from '@src/utils/device-info';
import { useCallback } from 'react';
import { Platform } from 'react-native';
import {
  check,
  checkLocationAccuracy,
  PERMISSIONS,
  PermissionStatus,
  request,
} from 'react-native-permissions';

import { useGoToSettings } from './use-go-to-settings';
import { PermissionsScreenSource } from './use-next-mydrive-screen';

type LocationAccuracy = 'full' | 'reduced' | 'unknown';

export function useLocationServices() {
  const maxBlockedCount = 1;

  const { goToSettings } = useGoToSettings();

  const checkLocationPermissions = async () => {
    const locationWhenInUseStatus =
      Platform.OS === 'ios'
        ? await check(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE)
        : await check(PERMISSIONS.ANDROID.ACCESS_COARSE_LOCATION);

    const locationAlwaysStatus =
      Platform.OS === 'ios'
        ? await check(PERMISSIONS.IOS.LOCATION_ALWAYS)
        : await check(PERMISSIONS.ANDROID.ACCESS_BACKGROUND_LOCATION);

    const locationPreciseStatus = await getLocationPreciseStatus(
      locationWhenInUseStatus
    );

    return {
      locationWhenInUseStatus,
      locationAlwaysStatus,
      locationPreciseStatus,
    };
  };

  const getLocationPreciseStatus = async (
    locationWhenInUseStatus: PermissionStatus
  ) => {
    const unknownLocationAccuracy: LocationAccuracy = 'unknown';
    if (
      locationWhenInUseStatus === 'blocked' ||
      locationWhenInUseStatus === 'denied'
    ) {
      return unknownLocationAccuracy;
    } else if (Platform.OS === 'ios') {
      try {
        return await checkLocationAccuracy();
      } catch (error) {
        return unknownLocationAccuracy;
      }
    } else {
      return check(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
    }
  };

  const requestPermission = useCallback(async () => {
    try {
      const whenInUseStatusCheck =
        Platform.OS === 'ios'
          ? await check(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE)
          : await check(PERMISSIONS.ANDROID.ACCESS_COARSE_LOCATION);

      const fineLocationCheck =
        Platform.OS === 'ios'
          ? 'unknown'
          : await check(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
      const whenInUseGrantedAndFineLocationDenied =
        whenInUseStatusCheck === 'granted' && fineLocationCheck === 'denied';

      const systemVersion = Number.parseInt(getSystemVersion(), 10);

      // blocked status from 'check' is iOS specific
      if (
        ((Platform.OS === 'ios' ||
          (Platform.OS === 'android' && systemVersion < 12)) &&
          (whenInUseStatusCheck === 'blocked' ||
            whenInUseStatusCheck === 'granted')) ||
        (Platform.OS === 'android' &&
          systemVersion >= 12 &&
          whenInUseStatusCheck === 'granted' &&
          fineLocationCheck === 'granted')
      ) {
        goToSettings();
        return;
      }

      const result =
        Platform.OS === 'ios'
          ? await request(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE)
          : await request(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);

      const resultBlocked = result === 'blocked';
      // For Android 12+ we have a precise location native dialog to show if they selected approx
      // location on first permission request. Keep Approx can be selected twice max after which
      // user must be sent to settings.
      const keepApprox = whenInUseGrantedAndFineLocationDenied && resultBlocked;
      if (keepApprox) {
        locationKeepApproxBlockedCount.set(
          locationKeepApproxBlockedCount.get() + 1
        );
      }
      const keepApproxBlockedCountExceededMax =
        locationKeepApproxBlockedCount.get() > maxBlockedCount;

      // android only returns blocked from 'request' calls so we need to track how many times a user
      // denies the permissions so that we can send them to settings when request limit is exceeded
      if (
        Platform.OS === 'android' &&
        resultBlocked &&
        (!keepApprox || (keepApprox && keepApproxBlockedCountExceededMax))
      ) {
        const blockedCount = locationPermissionsBlockedCount.get();
        if (blockedCount >= maxBlockedCount) {
          goToSettings();
          return;
        } else {
          locationPermissionsBlockedCount.set(blockedCount + 1);
        }
      }

      const whenInUseStatus =
        Platform.OS === 'ios'
          ? await check(PERMISSIONS.IOS.LOCATION_WHEN_IN_USE)
          : await check(PERMISSIONS.ANDROID.ACCESS_COARSE_LOCATION);

      const alwaysStatus =
        Platform.OS === 'ios'
          ? await check(PERMISSIONS.IOS.LOCATION_ALWAYS)
          : await check(PERMISSIONS.ANDROID.ACCESS_BACKGROUND_LOCATION);

      return {
        result,
        whenInUseStatus,
        alwaysStatus,
      };
    } catch (error) {
      const resultUnavailable: {
        result: PermissionStatus;
        whenInUseStatus: PermissionStatus;
        alwaysStatus: PermissionStatus;
      } = {
        result: 'unavailable',
        whenInUseStatus: 'unavailable',
        alwaysStatus: 'unavailable',
      };
      return resultUnavailable;
    }
  }, []);

  const getCanRequestLocationPermissions = async (
    currentScreenType: PermissionsScreenSource
  ) => {
    const {
      locationWhenInUseStatus,
      locationAlwaysStatus,
      locationPreciseStatus,
    } = await checkLocationPermissions();
    const LOCATION_ALWAYS: PermissionsScreenSource = 'LOCATION_ALWAYS';
    const LOCATION_SERVICES: PermissionsScreenSource = 'LOCATION_SERVICES';
    const locationPermissionsRespondedByUser =
      locationPermissionsResponded.get();

    const locationWhenInUseStatusDenied = locationWhenInUseStatus === 'denied';
    const locationWhenInUseBlocked = locationWhenInUseStatus === 'blocked';
    const locationWhenInUseStatusDeniedOrBlocked =
      locationWhenInUseStatusDenied || locationWhenInUseBlocked;
    const preciseLocationDenied = locationPreciseStatus === 'denied'; // android only
    const preciseLocationDeniedAndNotOnLocationServicesScreen =
      preciseLocationDenied && currentScreenType !== LOCATION_SERVICES;

    const currentScreenLocationAlways = currentScreenType === LOCATION_ALWAYS;
    const canRequestLocationWhenInUse =
      (locationWhenInUseStatusDeniedOrBlocked ||
        preciseLocationDeniedAndNotOnLocationServicesScreen) &&
      !locationPermissionsRespondedByUser &&
      !currentScreenLocationAlways;

    const locationWhenInUseGranted = locationWhenInUseStatus === 'granted';
    const locationAlwaysBlocked = locationAlwaysStatus === 'blocked';
    const locationAlwaysGranted = locationAlwaysStatus === 'granted';
    const locationAlwaysDenied = locationAlwaysStatus === 'denied';
    const preciseLocationReduced = locationPreciseStatus === 'reduced'; // iOS only
    const locationWhenInUseGrantedAndLocationAlwaysBlockedOrDenied =
      locationWhenInUseGranted &&
      (locationAlwaysBlocked || locationAlwaysDenied);
    const locationWhenInUseGrantedAndLocationAlwaysGrantedPreciseReduced =
      locationWhenInUseGranted &&
      locationAlwaysGranted &&
      (Platform.OS === 'ios' ? preciseLocationReduced : preciseLocationDenied);
    const locationWhenInUseDeniedAndLocationAlwaysDeniedCurrentScreenLocationAlways =
      locationWhenInUseStatusDenied &&
      locationAlwaysDenied &&
      currentScreenLocationAlways;

    const canRequestLocationAlways =
      (locationWhenInUseBlocked ||
        locationWhenInUseGrantedAndLocationAlwaysBlockedOrDenied ||
        locationWhenInUseGrantedAndLocationAlwaysGrantedPreciseReduced ||
        locationWhenInUseDeniedAndLocationAlwaysDeniedCurrentScreenLocationAlways) &&
      !locationPermissionsRespondedByUser;

    return { canRequestLocationWhenInUse, canRequestLocationAlways };
  };

  return {
    checkLocationPermissions,
    requestPermission,
    goToSettings,
    getCanRequestLocationPermissions,
    getLocationPreciseStatus,
  };
}
