import { useMutation } from '@tanstack/react-query';

import { MyDriveModel } from '../../models/mydrive';

export const useActivateMyDrive = () =>
  useMutation({
    mutationKey: ['activateMyDrive'] as const,
    mutationFn: () => new MyDriveModel().activateMyDrive(),
  });
