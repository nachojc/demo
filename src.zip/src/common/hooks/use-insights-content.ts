import { MyDriveModel } from '@src/models/mydrive';
import { useQuery } from '@tanstack/react-query';

export const useInsightsContent = () =>
  useQuery({
    queryKey: ['insightsContent'],
    queryFn: new MyDriveModel().getInsightsContent,
  });
