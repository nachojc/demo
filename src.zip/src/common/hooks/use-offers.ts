import { OfferModel } from '@src/models/offer';
import { Offer } from '@src/validation/schemas/offers';
import { useQuery } from '@tanstack/react-query';

type OffersResult = {
  offers: Offer[] | undefined;
  isLoading: boolean;
  isError: boolean;
  isFinanciallyAdvised: boolean;
};

export const useOffers = (): OffersResult => {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['offers'],
    queryFn: new OfferModel().fetchOffers,
  });
  const offers = data?.offers;
  const status = data?.status;

  return {
    offers,
    isLoading,
    isError,
    isFinanciallyAdvised: status === 204,
  };
};
