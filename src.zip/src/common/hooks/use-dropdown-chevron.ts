import { useCallback, useLayoutEffect, useRef } from 'react';
import { Animated } from 'react-native';

export function useRotation(startingValue = 0) {
  const spinValue = useRef(new Animated.Value(startingValue));

  const toggle = useCallback((isOn: boolean) => {
    Animated.timing(spinValue.current, {
      toValue: isOn ? 0 : 1,
      duration: 300,
      useNativeDriver: true,
    }).start();
  }, []);

  const value = spinValue.current.interpolate({
    inputRange: [0, 1],
    outputRange: ['-180deg', '0deg'],
  });

  return { value, toggle } as const;
}

export function useDropdownChevron(isExpanded: boolean) {
  const rotation = useRotation(1);
  const { toggle } = rotation;

  useLayoutEffect(() => {
    toggle(isExpanded);
  }, [isExpanded, toggle]);

  return rotation;
}
