import { getLogger } from '@interfaces/logger';
import { observable } from '@legendapp/state';
import { persistObservable } from '@legendapp/state/persist';
import { useMount } from '@legendapp/state/react';

import { ConfigSchema, getConfig } from './config';
import { Config } from './types';

const log = getLogger('env');

// Note: 'isDevMode' is true for browserstack builds
export const isDevMode = () => config.ENV.get() === 'development';

export const isMockBuild = () => config.IS_MOCK_BUILD.get();

export const isDemoBuild = () => config.IS_DEMO_BUILD.get();

export const setupConfig = () => {
  const configParsed = ConfigSchema.safeParse(getConfig());
  if (!configParsed.success) {
    log.error(
      new Error(
        '❌ Invalid environment variables: ' +
          JSON.stringify(configParsed.error.format(), null, 4)
      )
    );
    throw configParsed.error;
  }

  config.set(configParsed.data);
};

export const config = observable<Config>(
  // const assertion here as we enforce it to be true in ./setup.ts
  {} as Config
);

export const CONFIG_PERSIST = 'CONFIG';

/**
 * @description
 * E2E testing want to persist BASE_URL/Mock API Enabled
 * to remove Arrange steps from each test run on reload.
 *
 * This hook only runs on dev mode or CI test mode, and stores
 * it in a separate MMKV instance to ensure production builds aren't affected
 */
export function usePersistConfig() {
  useMount(() => {
    if (isDevMode() || isMockBuild()) {
      persistObservable(config, {
        local: {
          /**
           * MMKV is set to separate storage instance instead of default
           * We don't want this persisted to production or regression
           */
          mmkv: { id: 'IS_MOCK_BUILD_MMKV' },
          name: CONFIG_PERSIST,
        },
      });
    }
  });
}
