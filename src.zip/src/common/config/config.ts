import {
  ACCOUNT_SYNC_RETRY_MILLISECONDS_MAX,
  ACCOUNT_SYNC_RETRY_MILLISECONDS_MIN,
  AD_APPKEY,
  AD_IS_LOGGING_ENABLED,
  AD_TOOL,
  ANALYTICS_BASETAG,
  ANALYTICS_BRAND,
  ANALYTICS_CONFIG_IDENTIFIER,
  ANALYTICS_COUNTRY,
  AUTHENTICATION_TIMEOUT_SECONDS,
  AVIVA_BASE_URL,
  BASE_URL,
  CHANGE_RETIREMENT_AGE_TIMEOUT_SECONDS,
  CHAT_AGENT_GROUP_ID,
  CHAT_APP_DOMAIN,
  CHAT_AUTH_DOMAIN,
  CHAT_AUTOMATION_ID,
  CHAT_BUSINESS_RULES_ATTRIBUTES,
  CHAT_BUSINESS_RULES_ID,
  CHAT_BUSINESS_UNIT_ID,
  CHAT_CLIENT_ID,
  CHAT_CLIENT_SECRET,
  CHAT_DATA_CENTRE,
  CHAT_FILE_UPLOAD_SERVER,
  CHAT_SITE_ID,
  CHAT_TAG_SERVER,
  CHAT_TAG_SERVER_NAME,
  CONTENT_BASE_URL,
  DEFAULT_RETRY_COUNT,
  DEFAULT_TIMEOUT_SECONDS,
  DIG_BASE_URL,
  ENV,
  EXPONENTIAL_RETRY_INITIAL_MILLISECONDS,
  EXPONENTIAL_RETRY_MAX_MILLISECONDS,
  FIREBASE_API_KEY,
  FIREBASE_APP_ID,
  FIREBASE_DEFAULT_SENDER_ID,
  FIREBASE_LATEST_APP_VERSION,
  FIREBASE_MINIMUM_OS_VERSION,
  FIREBASE_RELEASE_NOTES,
  FUSION_CHARTS_LICENCE,
  INACTIVITY_TIMEOUT_SECONDS,
  IS_MOCK_BUILD,
  IS_SECURE,
  IS_WIREMOCK_BUILD,
  LAUNCH_DARKLY_MOBILE_KEY,
  LAUNCHES_WITH_PENDING_UPDATE_LIMIT,
  MAX_REVIEW_PROMPTS,
  MFA_ACTIVATION_PROMPT_DELAY_DATE_DAYS_DURATION,
  MFA_ACTIVATION_PROMPT_LIMIT,
  MFA_DISENROL_SCOPE,
  MFA_ENROL_SCOPE,
  MFA_PASSWORD_RESET_SCOPES,
  MFA_PATH,
  MIN_CONSECUTIVE_SUCCESSFUL_SYNCS,
  MOBILE_API_URL,
  MYDRIVE_API_KEY,
  MYDRIVE_DATA_SYNC_ENABLED,
  MYDRIVE_INSIGHT_PERIOD_HOURS,
  MYDRIVE_MILESTONE_DAYS,
  MYDRIVE_MILESTONE_MILES,
  MYDRIVE_OVERALL_SCORE_DAYS,
  NAVIGATOR_PAYMENT_ADYEN_ENV,
  NAVIGATOR_PAYMENT_ADYEN_RETURN_URL,
  NAVIGATOR_PAYMENT_ADYEN_RETURN_URL_ANDROID,
  OAUTH_ACCESS_DEFINITION,
  OAUTH_CLIENT_ID,
  OAUTH_SCOPES,
  PENSION_SINGLE_PAYMENT_ADYEN_ENV,
  PENSION_SINGLE_PAYMENT_ADYEN_RETURN_URL,
  PENSION_SINGLE_PAYMENT_DESCRIPTIONS_CONTENT_AREA,
  QUALTRICS_BRAND_ID,
  QUALTRICS_INTERCEPT_ID,
  QUALTRICS_ZONE_ID,
  SECURITY_ACCOUNT_PATH,
} from '@env';
import { StringToBoolean } from '@src/validation/schemas/string-to-boolean';
import { z } from 'zod';

export const getConfig = () => ({
  BASE_URL,
  AD_APPKEY,
  ENV,
  ACCOUNT_SYNC_RETRY_MILLISECONDS_MAX,
  ACCOUNT_SYNC_RETRY_MILLISECONDS_MIN,
  AD_IS_LOGGING_ENABLED,
  AD_TOOL,
  ANALYTICS_BASETAG,
  ANALYTICS_BRAND,
  ANALYTICS_CONFIG_IDENTIFIER,
  ANALYTICS_COUNTRY,
  AUTHENTICATION_TIMEOUT_SECONDS,
  AVIVA_BASE_URL,
  CHANGE_RETIREMENT_AGE_TIMEOUT_SECONDS,
  CHAT_AGENT_GROUP_ID,
  CHAT_AUTOMATION_ID,
  CHAT_BUSINESS_RULES_ATTRIBUTES,
  CHAT_BUSINESS_RULES_ID,
  CHAT_BUSINESS_UNIT_ID,
  CHAT_CLIENT_ID,
  CHAT_AUTH_DOMAIN,
  CHAT_APP_DOMAIN,
  CHAT_TAG_SERVER,
  CHAT_FILE_UPLOAD_SERVER,
  CHAT_CLIENT_SECRET,
  CHAT_DATA_CENTRE,
  CHAT_SITE_ID,
  CHAT_TAG_SERVER_NAME,
  CONTENT_BASE_URL,
  DEFAULT_RETRY_COUNT,
  DEFAULT_TIMEOUT_SECONDS,
  DIG_BASE_URL,
  EXPONENTIAL_RETRY_INITIAL_MILLISECONDS,
  EXPONENTIAL_RETRY_MAX_MILLISECONDS,
  FIREBASE_API_KEY,
  FIREBASE_APP_ID,
  FIREBASE_DEFAULT_SENDER_ID,
  FIREBASE_LATEST_APP_VERSION,
  FIREBASE_MINIMUM_OS_VERSION,
  FIREBASE_RELEASE_NOTES,
  FUSION_CHARTS_LICENCE,
  INACTIVITY_TIMEOUT_SECONDS,
  IS_MOCK_BUILD,
  IS_SECURE,
  IS_WIREMOCK_BUILD,
  LAUNCH_DARKLY_MOBILE_KEY,
  LAUNCHES_WITH_PENDING_UPDATE_LIMIT,
  MAX_REVIEW_PROMPTS,
  MFA_ACTIVATION_PROMPT_DELAY_DATE_DAYS_DURATION,
  MFA_ACTIVATION_PROMPT_LIMIT,
  MFA_DISENROL_SCOPE,
  MFA_ENROL_SCOPE,
  MFA_PASSWORD_RESET_SCOPES,
  MFA_PATH,
  MIN_CONSECUTIVE_SUCCESSFUL_SYNCS,
  MOBILE_API_URL,
  MYDRIVE_API_KEY,
  MYDRIVE_DATA_SYNC_ENABLED,
  MYDRIVE_INSIGHT_PERIOD_HOURS,
  MYDRIVE_MILESTONE_DAYS,
  MYDRIVE_MILESTONE_MILES,
  MYDRIVE_OVERALL_SCORE_DAYS,
  NAVIGATOR_PAYMENT_ADYEN_ENV,
  NAVIGATOR_PAYMENT_ADYEN_RETURN_URL,
  NAVIGATOR_PAYMENT_ADYEN_RETURN_URL_ANDROID,
  OAUTH_ACCESS_DEFINITION,
  OAUTH_CLIENT_ID,
  OAUTH_SCOPES,
  PENSION_SINGLE_PAYMENT_ADYEN_ENV,
  PENSION_SINGLE_PAYMENT_ADYEN_RETURN_URL,
  PENSION_SINGLE_PAYMENT_DESCRIPTIONS_CONTENT_AREA,
  QUALTRICS_BRAND_ID,
  QUALTRICS_INTERCEPT_ID,
  QUALTRICS_ZONE_ID,
  SECURITY_ACCOUNT_PATH,
});

/**
 * @description
 * We're ignoring the noUnusedLocals warning on the type imports
 * They are used within the jsdoc comments for linking to the files
 *
 * This warning can be resolved once we migrate to TS 5.5
 * @see Typescript-5.5 https://devblogs.microsoft.com/typescript/announcing-typescript-5-5-beta/#type-imports-in-jsdoc
 */

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - See above jsdoc explanation
// eslint-disable-next-line @typescript-eslint/no-unused-vars
type Config = typeof import('./index.ts');

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - See above jsdoc explanation
// eslint-disable-next-line @typescript-eslint/no-unused-vars
type UserInactivity =
  typeof import('../providers/user-inactivity/user-inactivity');

// TODO: When removing deprecated fields check against https://dev.azure.com/avdigitalweb/DigitalNextGen/_git/DigitalNextGen/pullrequest/253015?path=/resources/dw/env/.env.commissioning to confirm they are valid
export const ConfigSchema = z.object({
  /**
   * @description
   * `BASE_URL` is the domain name and a valid URL, which can be subpathed to
   * access REST endpoints
   *
   * `BASE_URL` is set by default per build environment but is configurable in
   * the dev mode for QA to use
   *
   * You can safely construct an URL encoded object with the following classes:
   * @example
   * // URL will url encode and escape the strings passed in to construct it
   * const url = new URL(config.ACCOUNT_DELETION_PATH.get(), config.BASE_URL.get())
   *
   * // You can then modify the URL object with parameters via a Map
   * url.searchParams.set('username', 'Super man')
   *
   * // Now when you convert this to a string, username is correctly encoded for requests
   * // i.e. the space in 'Super man' becomes 'Super+man'
   * url.toString() // 'https://www.direct.aviva.co.uk/MessagingApi/api/v1/account/requestAccountDeletion?username=Super+man'
   *
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/URL}
   */
  BASE_URL: z.string().url(),

  /**
   * @description
   * App dynamics instrumentation key.
   * This will be one of two values, for development (browserstack) and production.
   *
   * This is generally used once to initialise near the start of the application
   * It is passed into the Instrumentation class
   * @example
   * ```tsx
   * // App.tsx
   * Instrumentation.start({
   *   appKey: config.AD_APPKEY.get(),
   *   //  interactionCaptureMode: InteractionCaptureMode.All,
   *   screenshotsEnabled: false,
   *   loggingLevel: LoggingLevel.INFO,
   *   anrDetectionEnabled: true,
   * });
   * ```
   *
   * @see {@link https://www.npmjs.com/package/@appdynamics/react-native-agent}
   */
  AD_APPKEY: z.string(),

  /**
   * @summary
   * Describes the intended deployment environment
   *
   * This should be used when targeting features or fixes for a specific environment
   * (e.g. we don't want mock service worker to be enabled on production)
   *
   * @description
   * This is a supertype of `process.env.NODE_ENV`, adding values:
   *  - 'staging
   *
   * The value of this is set based on the intended deployment target
   * for the build (develop/browserstack/adhoc/production).
   * This is decided in the pipeline config
   * @see {Pipelines pipeline/builds/apps}
   *
   * When we build on the pipeline, the build tool is configured to `release`
   *
   * This enables production style optimisations (e.g. minification/treekshaking)
   * even on browserstack, but **does not** mean its for production users.
   * These optimisations will exist on browserstack builds too, for example.
   *
   * With the build process mapping `release` to always have a
   * `process.env.NODE_ENV` value of `production`
   * this environment variable is used in addition to allow targeting fixes
   * and features within release builds for non-production users
   *
   * @see {@link Config.isDevMode isDevMode} is a helper to coerce a boolean from this setting
   */
  ENV: z.enum(['development', 'staging', 'production', 'test'] as const),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  ACCOUNT_SYNC_RETRY_MILLISECONDS_MAX: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  ACCOUNT_SYNC_RETRY_MILLISECONDS_MIN: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  AD_IS_LOGGING_ENABLED: z.enum(['false', 'true'] as const),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  AD_TOOL: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  ANALYTICS_BASETAG: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  ANALYTICS_BRAND: z.string(),
  ANALYTICS_CONFIG_IDENTIFIER: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  ANALYTICS_COUNTRY: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  AUTHENTICATION_TIMEOUT_SECONDS: z.string(),

  /**
   * @description
   * `AVIVA_BASE_URL` is the domain name and a valid URL, which can be subpathed to
   * access resource on the website (web pages)
   *
   * @important
   * These URL's specifically require SSO sign on to access
   *
   * @see {ConfigSchema.BASE_URL} - for example on how to construct safe URL's
   */
  AVIVA_BASE_URL: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  CHANGE_RETIREMENT_AGE_TIMEOUT_SECONDS: z.string(),

  CHAT_AGENT_GROUP_ID: z.string(),
  CHAT_AUTOMATION_ID: z.string(),
  CHAT_BUSINESS_RULES_ATTRIBUTES: z.string(),
  CHAT_BUSINESS_RULES_ID: z.string(),
  CHAT_BUSINESS_UNIT_ID: z.string(),

  /**
   * @description
   * Nuance Client ID
   * Used to initialise the SDK
   *
   * @alias `clientID` - from nuance docs
   *
   * @see {@link https://docs-sdk-ios.nod-glb.nuance.com/quickstart.html#launch}
   */
  CHAT_CLIENT_ID: z.string(),

  /**
   * @description
   * Nuance Client Secret
   * Used to initialise the SDK
   *
   * @alias `clientSecret` - from nuance docs
   *
   * @see {@link https://docs-sdk-ios.nod-glb.nuance.com/quickstart.html#launch}
   */
  CHAT_CLIENT_SECRET: z.string(),

  /**
   * @description
   * Name of the data center where your messaging session is processed.
   *
   * @alias `dc` - from nuance docs
   *
   * @see {@link https://docs-sdk-ios.nod-glb.nuance.com/quickstart.html#launch}
   */
  CHAT_DATA_CENTRE: z.string(),

  CHAT_SITE_ID: z.string(),

  /**
   * @description
   * Nuance Tag Server Name
   * Used to initialise the SDK
   *
   * @alias `tagServerName` - from nuance docs
   *
   * @see {@link https://docs-sdk-ios.nod-glb.nuance.com/quickstart.html#launch}
   */
  CHAT_TAG_SERVER_NAME: z.string(),
  CHAT_AUTH_DOMAIN: z.string(),
  CHAT_APP_DOMAIN: z.string(),
  CHAT_TAG_SERVER: z.string(),
  CHAT_FILE_UPLOAD_SERVER: z.string(),

  /**
   * @description
   *
   * @see {@link }
   */
  CONTENT_BASE_URL: z.string().url(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  DEFAULT_RETRY_COUNT: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  DEFAULT_TIMEOUT_SECONDS: z.string(),

  /**
   * @description
   * This url maps to the domain to route ESEC api calls to
   * DIG endpoints **do not** work on RWY 1/2/3 currently
   * This interceptor routes all requests to esec API's by replacing the baseURL
   *     in development -> (direct.rwy-aviva.co.uk)
   *     in production  -> (direct.aviva.co.uk) // same as production
   *
   * @see {@link src/utils/api/interceptors/reroute-esec.interceptor.ts} - mapped endpoints listed here
   */
  DIG_BASE_URL: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  EXPONENTIAL_RETRY_INITIAL_MILLISECONDS: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  EXPONENTIAL_RETRY_MAX_MILLISECONDS: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */ FIREBASE_API_KEY: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */ FIREBASE_APP_ID: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */ FIREBASE_DEFAULT_SENDER_ID: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */ FIREBASE_LATEST_APP_VERSION: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */ FIREBASE_MINIMUM_OS_VERSION: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */ FIREBASE_RELEASE_NOTES: z.string(),

  /**
   * @description
   *
   * @see {@link }
   */
  FUSION_CHARTS_LICENCE: z.string(),

  /**
   * @description
   * This value represents the time (in seconds) of no user activity that will
   * initiate an automatic logout, this is interruptible by user interacting with
   * the app again.
   *
   * Defaults: 900s (15 minutes)
   *
   * This may change in future, and be used in conjunction with the expiry of the
   * accessToken potentially being reduced.
   *
   * @see {@link UserInactivity.UserInactivityProvider UserInactivityProvider}
   */
  INACTIVITY_TIMEOUT_SECONDS: z.string(),

  /**
   * @description
   * Indicates if the build is for demo purposes. Uses mock data and hides the dev menu.
   *
   * @see {@link Config.isDemoBuild isDemoBuild} - Wrapper method
   */
  IS_DEMO_BUILD: StringToBoolean,

  /**
   * @description
   * When enabled this will enable by default:
   * - Mock API turned on (for first launch)
   * - Persist the config for dev mode e.g. changing `BASE_URL`
   * via devmode persists app closure
   *
   * `IS_MOCK_BUILD` === TRUE when:
   * - local (simulator) builds
   * - dailies (browserstack)
   *
   * `IS_MOCK_BUILD` === FALSE when:
   * - regression
   * - pentest
   * - production
   *
   *
   * @see {@link Config.isMockBuild isMockBuild} - Wrapper method
   */
  IS_MOCK_BUILD: StringToBoolean,

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  IS_SECURE: z.enum(['false', 'true'] as const),

  /**
   * @description
   * When enabled, the app will do the following:
   * - Bypass calls to eSec as we do not have Wiremock responses for eSec / DIG endpoints
   * - Based on inputs in the WiremockConfigScreen, provides a Bearer token
   * in a specific format that includes OAN, Roles, Client and Username. This will
   * ensure the Dev (Wiremock) environment returns a matched response.
   */
  IS_WIREMOCK_BUILD: StringToBoolean,

  /**
   * @description
   * This is used to initialise the LaunchDarkly SDK and is required
   * before being able to retrieve any data from LaunchDarkly.
   */
  LAUNCH_DARKLY_MOBILE_KEY: z.string().nullish(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  LAUNCHES_WITH_PENDING_UPDATE_LIMIT: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MAX_REVIEW_PROMPTS: z.string(),
  MFA_ACTIVATION_PROMPT_DELAY_DATE_DAYS_DURATION: z.string(),
  MFA_ACTIVATION_PROMPT_LIMIT: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MFA_DISENROL_SCOPE: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MFA_ENROL_SCOPE: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MFA_PASSWORD_RESET_SCOPES: z.string(),
  MFA_PATH: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MIN_CONSECUTIVE_SUCCESSFUL_SYNCS: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MOBILE_API_URL: z.string().url(),
  MYDRIVE_API_KEY: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MYDRIVE_DATA_SYNC_ENABLED: z.enum(['false', 'true'] as const),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MYDRIVE_INSIGHT_PERIOD_HOURS: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MYDRIVE_MILESTONE_DAYS: z.string(),
  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MYDRIVE_MILESTONE_MILES: z.string(),
  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  MYDRIVE_OVERALL_SCORE_DAYS: z.string(),

  NAVIGATOR_PAYMENT_ADYEN_ENV: z.enum([
    'test',
    'live-eu',
    'live-us',
    'live-au',
    'live-apse',
    'live-in',
  ] as const),
  NAVIGATOR_PAYMENT_ADYEN_RETURN_URL: z.string(),
  NAVIGATOR_PAYMENT_ADYEN_RETURN_URL_ANDROID: z.string(),

  OAUTH_ACCESS_DEFINITION: z.string(),

  /**
   * @description
   * `OAUTH_CLIENT_ID` varies per app type but not per environment
   *
   * Possible values include:
   * - myavivanextgenoauth (MyAviva)
   * - directwealthmoboauth (DirectWealth)
   *
   * Used to correctly authenticate with the ESEC oauth endpoints and uniquely
   * identify the application signing a user in. If the wrong ID is used then
   * each app (MyAviva & Aviva Wealth for example) will not be able to concurrently
   * login reusing their refresh token, as each will expire the other.
   * @see {@link }
   */
  OAUTH_CLIENT_ID: z.string(),

  /**
   * @description
   *
   * @see {@link }
   */
  OAUTH_SCOPES: z.string(),

  PENSION_SINGLE_PAYMENT_ADYEN_ENV: z.enum([
    'test',
    'live-eu',
    'live-us',
    'live-au',
    'live-apse',
    'live-in',
  ] as const),
  PENSION_SINGLE_PAYMENT_ADYEN_RETURN_URL: z.string(),

  /**
   * @description
   * Appears to have been added as part of the Xamarin migration
   * Currently not in use within the codebase - marked as deprecated
   *
   * @deprecated
   */
  PENSION_SINGLE_PAYMENT_DESCRIPTIONS_CONTENT_AREA: z.string(),

  // https://www.npmjs.com/package/react-native-qualtrics
  QUALTRICS_BRAND_ID: z.string(),
  QUALTRICS_INTERCEPT_ID: z.string(),
  QUALTRICS_ZONE_ID: z.string(),

  SECURITY_ACCOUNT_PATH: z.string(),
});
