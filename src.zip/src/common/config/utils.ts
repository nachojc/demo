import { getLogger } from '@interfaces/logger';
import { config } from '@src/common/config/';

import { ReplaceValues } from './generated-types';
import { BaseValues, Config, CreateOptions } from './types';

const log = getLogger('env');

/**
 * @description
 * replaces matching replace keys with replace values in string
 */
export const replaceValues = (
  str: string,
  values: { [key: string]: string }
) => {
  Object.entries(values).forEach(([k, v]) => {
    if (str.includes(k)) {
      str = str.replace(k, v);
    } else {
      log.error(new Error(`key ${k} not found in ${str}`));
    }
  });

  return str;
};

/**
 * @description
 * creates a URL object from Config values (base and/or path) with required formatting applied
 */
export const createURL = <T extends keyof ReplaceValues>(
  baseKey: BaseValues,
  pathKey?: T,
  options?: CreateOptions<T>
) => {
  const baseValue = config[baseKey].get();
  const pathValue = pathKey ? config[pathKey as keyof Config].get() : undefined;
  const values =
    options && 'replaceValues' in options ? options.replaceValues : undefined;

  const formattedBaseValue = typeof baseValue === 'string' ? baseValue : '';
  let formattedPathValue = typeof pathValue === 'string' ? pathValue : '';

  if (!values) {
    return new URL(formattedPathValue, formattedBaseValue);
  }

  if (pathValue) {
    formattedPathValue = replaceValues(formattedPathValue, values);
  }

  return new URL(formattedPathValue, formattedBaseValue);
};

/**
 * @description
 * creates a URL object where base is the BASE_URL Config value
 *
 * @see {@link createURL} for further information.
 */
export const createBaseURL = <T extends keyof ReplaceValues>(
  pathKey?: T,
  options?: CreateOptions<T>
) => createURL('BASE_URL', pathKey, options);
