import { z } from 'zod';

import { ConfigSchema } from './config';
import { ReplaceValues } from './generated-types';

export type Config = z.infer<typeof ConfigSchema>;

export type CreateOptions<T extends keyof ReplaceValues> = {
  replaceValues: ReplaceValues[T];
};

export type BaseValues = keyof Pick<Config, 'BASE_URL' | 'DIG_BASE_URL'>;
