import { UseQueryOptions } from '@tanstack/react-query';

/**
 * This is a utility type that can be used to enable consumers
 * of your custom hooks to override the values that you have defined
 * By default we exclude queryFn and queryKey as non overridable
 * @example
 *	export const useMfaPreferences = (
 *	options?: UseQueryOptionsGenerics<
 *		InstanceType<typeof MfaPreferencesModel>['fetchPreferences'],
 *		'Mfa Preferences'
 *	>
 *	) => {
 *	return useQuery({
 *		queryFn: new MfaPreferencesModel().fetchPreferences,
 *		queryKey: ['Mfa Preferences'],
 *		enabled: false,
 *		retry: 0,
 *		...options,
 *	});
 *	};
 */
export type UseQueryOptionsGenerics<T extends () => unknown, Key> = Omit<
  UseQueryOptions<
    ReturnType<T>,
    Error,
    T extends () => Promise<infer U> ? U : T,
    [Key]
  >,
  'queryFn' | 'queryKey'
>;
