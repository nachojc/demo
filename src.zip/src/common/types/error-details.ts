import { Action } from '@aviva/ion-mobile';

export type ErrorDetails = {
  title: string;
  text: string;
  action?: Action[];
  isConnectionError?: boolean;
  showConnectionError: boolean;
};
