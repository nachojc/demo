export type Flat<T> = T extends object ? { [K in keyof T]: Flat<T[K]> } : T;
