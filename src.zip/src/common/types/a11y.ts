import { StackProps } from '@aviva/ion-mobile';

export type A11yProps = Pick<
  StackProps,
  'accessibilityLabel' | 'accessibilityHint' | 'accessibilityRole'
>;
