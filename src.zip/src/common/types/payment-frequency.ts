import { ValueOf } from 'type-fest';

export type PaymentFrequency = ValueOf<typeof PaymentFrequency>;
export const PaymentFrequency = {
  Unknown: 0,
  Monthly: 1,
  Quarterly: 2,
  Termly: 3,
  HalfYearly: 4,
  Yearly: 5,
  LunarMonthly: 6,
  BiAnnually: 7,
  Fortnightly: 8,
  Weekly: 9,
} as const;
