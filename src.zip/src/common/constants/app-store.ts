import { Platform } from 'react-native';

export type AppName = 'MidLife';
type URL = string;

export const appStore: Record<
  Platform['OS'],
  Record<AppName, URL> | undefined
> = {
  android: {
    MidLife:
      'https://play.google.com/store/apps/details?id=uk.co.aviva.midlife',
  },
  ios: {
    MidLife: 'https://itunes.apple.com/gb/app/mid-life-mot/id1533084885?mt=8',
  },
  windows: undefined,
  macos: undefined,
  web: undefined,
};
