export const NO_NETWORK_ERROR_MSG =
  'You need to be connected to the internet to continue. Please check your connection and try again.';
export const PDF_ERROR_DIALOG_TITLE_MSG = `We're sorry, something went wrong.`;
export const PDF_ERROR_DIALOG_BODY_MSG = `Please try again.`;
