export const UK_DATE_FORMAT = 'dd/MM/yyyy';
export const UK_DATE_SHORT_FORMAT = 'dd/MM/yy';
export const UK_DATE_TIME_FORMAT = 'dd/MM/yyyy - H:mm';
export const DAY_MONTH_DATE_FORMAT = 'dd/MM';
export const MONTH_YEAR_DASH_DATE_FORMAT = 'MM-yyy';
export const ISO_8601_DATE_FORMAT = 'yyyy-MM-dd';
