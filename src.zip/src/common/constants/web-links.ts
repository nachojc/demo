import { CONTENT_BASE_URL } from '@env';
import { isEsecStagingDomain } from '@src/utils/api/constants';

import { config } from '../config';

const base = config.BASE_URL.get();
const avivaBase = config.AVIVA_BASE_URL.get();
// When the environments return back to normal we can remove this entirely.
const digBase = isEsecStagingDomain(base) ? config.DIG_BASE_URL.get() : base;

export const webLinks = {
  sso: (token: string, redirurl: string) =>
    `${digBase}/avivasecurityauthservice/v2/device/websso?token=${token}&redirurl=${redirurl}&accessdef=UKDMOB_ALL_2` as const,

  mfaSettings: `${base}/MyAccount/Mfa/Settings`,
  addressEdit: `${base}/MyProfile/Address/Edit`,
  addressTransfer: `${base}/MyPortfolio/Bamboo/Transfer/ADDRESS`,
  profile: `${base}/MyPortfolio/Profile`,
  paperlessDocs: `${base}/MyPortfolio/Profile/EditPaperlessDocumentPreferences`,
  missingPolicy: `${base}/MyPortfolio/PoliciesNotOnMyAviva`,
  changeUsername: `${base}/MyAccount/ChangeYourUserName`,
  changePassword: `${base}/MyAccount/ChangeYourPassword`,
  unlockPolicy: (reDirectUrl: string) =>
    `${base}/MyAccount/Unlock/DecideJourney?isMobileApp=true%26redirectScheme=${reDirectUrl}` as const,

  wealthifyDashboard: `${base}/MyPortfolio/Wealthify/Transfer/Dashboard`,
  wealthifyRegular: `${base}/MyPortfolio/Wealthify/Transfer/Dashboard?cmp=app-ukmyaviva-dashboard-regular-plan`,
  wealthifyISA: `${base}/MyPortfolio/Wealthify/Transfer/Dashboard?cmp=app-ukmyaviva-dashboard-isa-plan`,
  wealthifySipp: `${base}/MyPortfolio/Wealthify/Transfer/Dashboard?cmp=app-ukmyaviva-dashboard-sipp-plan`,

  fundsList: `${base}/wealth/FundChoice/SelfSelectFundsList`,

  contactUs: `${avivaBase}/help-and-support/contact-us/` as const,

  // Fnz
  wrapPolicy: (id?: string) =>
    `${base}/MyPortfolio/Public/FnzWrapPolicies?s=${id}` as const,
  managePayment: (id: string, deepLinking?: boolean) =>
    `${base}/MyPortfolio/Public/FnzWrapPolicies?s=${id}${
      deepLinking ? '%26pt=ManagePayments' : ''
    }` as const,
  buyFunds: (id: string, deepLinking?: boolean) =>
    `${base}/MyPortfolio/Public/FnzWrapPolicies?s=${id}${
      deepLinking ? '%26pt=BuyFunds' : ''
    }` as const,
  buyShares: (id: string, deepLinking?: boolean) =>
    `${base}/MyPortfolio/Public/FnzWrapPolicies?s=${id}${
      deepLinking ? '%26pt=BuyShares' : ''
    }` as const,
  myMoneySipp: (id?: string) =>
    `${base}/MyPortfolio/MyMoneySipp/FnzTransfer/${id}/Investment?fromMobile=true` as const,
  myMoneyPayment: (id?: string) =>
    `${base}/MyPortfolio/MyMoneySipp/FnzTransfer/${id}/Payments?fromMobile=true` as const,
  myMoneyRetire: (id?: string | null) =>
    `${base}/MyPortfolio/MyMoneySipp/FnzTransfer/${id}/Retirement?fromMobile=true` as const,

  // Portfolio
  portfolio: `${base}/MyPortfolio`,
  portfolioHome: (id: string) =>
    `${base}/MyPortfolio/Home/ViewDetail/${id}` as string,
  portfolioMyMoneySipp: (id: string) =>
    `${base}/MyPortfolio/MyMoneySipp/FnzTransfer/${id}/Details?fromMobile=true` as string,

  uklcp: (id: string) => `${base}/uklcp/Details/${id}` as const,
  protection: (id: string) => `${base}/MyProtection/Details/${id}` as const,

  equinity: (id: string) =>
    `${base}/MyPortfolio/Equinity/TransferId/${id}?fromMobile%3Dtrue` as const,
  wealth: (id?: string | null) =>
    `${base}/MyPortfolio/uk/WrapAccount/WrapPolicies?subAccounId=${id}` as const,

  // Documents
  portfolioDocs: (id: string) =>
    `${base}/MyPortfolio/ViewDocuments?id=${id}` as const,
  motorDocs: (id?: string | null) =>
    id
      ? (`${base}/AvivaPlus/Motor/Details/${id}` as const)
      : (`${base}/AvivaPlus/Motor/Details` as const),
  directDocs: (id: string) => `${base}/direct/Document/${id}/List` as const,
  pensionDocs: (id: string) =>
    `${base}/uklcp/secure/Pension/Document/List/${id}` as const,
  homeDocs: (id: string) => `${base}/MyPortfolio/Home/Documents/${id}` as const,

  // Pension
  pensionSummary: (id?: string) =>
    `${base}/uklcp/secure/Pension/Summary/${id}` as const,
  transferIn: (id?: string) =>
    `${base}/uklcp/secure/Pension/TransferIn/TransferAPension/${id}` as const,
  transferSummary: (id?: string) =>
    `${base}/uklcp/secure/Pension/Summary/${id}#transfer-a-pension` as const,

  retirementAge: (id?: string) =>
    `${base}/uklcp/secure/Pension/RetirementAge/Index/${id}` as const,
  beneficiaries: (id: string) =>
    `${base}/MyPortfolio/MyMoneySipp/FnzTransfer/${id}/Beneficiaries?fromMobile=true` as const,
  documents: (id: string) =>
    `${base}/MyPortfolio/MyMoneySipp/FnzTransfer/${id}/Documents?fromMobile=true` as const,
  singlePayment: (id?: string) =>
    `${base}/uklcp/secure/Pension/SinglePayment/Index/${id}` as const,
  future: (id?: string) =>
    `${base}/uklcp/secure/Pension/FutureOfYourPensionOptions/${id}` as const,
  amendPayments: (id: string) =>
    `${base}/uklcp/secure/Pension/ChangePayment/AmendPayments/${id}` as const,
  estimatedMaturity: (id?: string) =>
    `${base}/uklcp/secure/Pension/EstimatedMaturityValue/${id}` as const,
  education: (id?: string) =>
    `${base}/uklcp/secure/Pension/Education/Basics/${id}` as const,
  onepot: (id?: string) =>
    `${base}/uklcp/secure/Pension/Education/PensionsIntoOnePot/${id}` as const,
  contribution: (id?: string) =>
    `${base}/uklcp/secure/Pension/ContributionHistory/${id}` as const,
  tracking: `${base}/MyPortfolio/TransactionTracking`,
  tridion: `${base}/tridion/documents/view/fe3725.pdf`,

  // Motor
  motorTransfer: (id?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/DETAILS/${id}` as const,
  motorClaim: `${base}/MyClaims/Public/Motor/`,
  motorAdd: (id?: string) => `${base}/MyMotor/Driver/Add/${id}/1` as const,
  motorTransferDocs: (id?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/DOCUMENTS/${id}` as const,
  motorReplace: (id?: string) =>
    `${base}/MyMotor/ReplaceVehicle/${id}/1` as const,
  motoroRenewal: (id?: string) =>
    `${base}/MyPortfolio/ViewRenewal/${id}` as const,
  motorRetrieve: (id?: string) =>
    `${base}/direct/Motor/${id}/Retrieve` as const,
  motorAddDriver: (id?: string, date?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/ADD_DRIVER/${id}?changeEffectiveDate=${date}` as const,
  motorReplaceDriver: (id?: string, date?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/REPLACE_VEHICLE/${id}?changeEffectiveDate=${date}` as const,
  motorEditPolicy: (id?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/EDIT_POLICY/${id}` as const,
  motorAmend: (id?: string, exceedId?: string, vehicleId?: string) =>
    `${base}/direct/Account/Transfer/${id}/AmendVehicleCovers/${exceedId}/${vehicleId}` as const,
  motorHelp: (id?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/HELPCENTRE/${id}` as const,
  motorContact: `https://www.aviva.co.uk/help-and-support/contact-us/motor-insurance/`,
  motorCancel: (id?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/CANCEL_POLICY/${id}`,
  motorEditPolicyPaymentDetails: (id?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/EDIT_POLICY_PAYMENT_DETAILS/${id}` as const,
  motorAddressTransfer: (id?: string) =>
    `${base}/MyPortfolio/Bamboo/Transfer/ADDRESS/${id}` as const,
  motorViewClaims: `${base}/MyClaimsSummary/CarClaims/`,
  motorPrivacyPolicy:
    `${avivaBase}/services/about-our-business/products-and-services/privacy-policy/motor-privacy-policy/` as const,

  // Health
  healthDetails: (id?: string, member?: string | null) =>
    `${base}/MyHealth/Individual/PolicyDetails/${id}/${member}` as const,
  healthDetailsCorporate: (id?: string, member?: string | null) =>
    `${base}/MyHealth/Corporate/PolicyDetails/${id}/${member}` as const,
  healthClaims: (id: string, member: string) =>
    `${base}/MyHealth/Claims/${id}/${member}` as const,
  healthClaimsAlt: (id: string, member: string) =>
    `${base}/MyHealth/HealthClaims/${id}/${member}` as const,
  healthGetDoc: (id: string) =>
    `${base}/MyDocuments/GetDocuments/${id}` as const,
  healthcarezone:
    `${CONTENT_BASE_URL}/content/dam/document-library/health/gen2318.pdf` as const,

  // Home
  claimOnline: `${base}/MyClaims/Household/claimonline`,
  docsError: (id: string) =>
    `${base}/MyPortfolio/Home/ViewDocuments/${id}` as const,

  // Transfer
  transferRetrieve: (id: string, exceedId: string) =>
    `${base}/direct/Account/Transfer/${id}/Retrieve/${exceedId}` as const,
  transferAmendHome: (id: string, exceedId: string) =>
    `${base}/direct/Account/Transfer/${id}/AmendHomePolicy/${exceedId}` as const,
} as const;
