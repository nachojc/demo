//Constant based on Figma design
export const IPAD_THANK_YOU_TEXT_WIDTH = 327;
export const THANK_YOU_SCREEN_TOP_PADDING = 60;
