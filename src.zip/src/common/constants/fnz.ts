export const uriToInterceptFnZWebJourney =
  'fnzc.co.uk/sso/ReturnToAppProductView';
