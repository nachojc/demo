export const APP_BASE = 'ukmyaviva|';
export const MYDRIVE_BASE = `${APP_BASE}mydrive|`;
export const PAGE_WEALTH = `${APP_BASE}wealth`;
