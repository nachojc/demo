import { launchDarklyConnectionMode } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { ReactNode } from 'react';

import { AccessibilityProvider } from './accessibility';
import { AuthProvider } from './auth';
import { DatabaseProvider } from './database/database-provider';
import { IonMobileProvider } from './ion-mobile';
import { ModalDialogProvider } from './modal';
import { NavbarProvider } from './nav-control';
import { NavigationProvider } from './navigation/navigation-provider';
import { ReactQueryProvider } from './react-query';
import { LaunchDarklyProvider } from './remote-flags';
import { SafeAreaProvider } from './safe-area';
import { SplashScreenProvider } from './splash-screen';

type ProvidersProps = { children: ReactNode };

export const Providers = ({ children }: ProvidersProps) => {
  const connectionMode = useSelector(launchDarklyConnectionMode);

  return (
    <SplashScreenProvider>
      <DatabaseProvider>
        <ReactQueryProvider>
          <ModalDialogProvider>
            <AuthProvider>
              <LaunchDarklyProvider connectionMode={connectionMode}>
                <NavigationProvider>
                  <AccessibilityProvider>
                    <IonMobileProvider>
                      <NavbarProvider>
                        <SafeAreaProvider>{children}</SafeAreaProvider>
                      </NavbarProvider>
                    </IonMobileProvider>
                  </AccessibilityProvider>
                </NavigationProvider>
              </LaunchDarklyProvider>
            </AuthProvider>
          </ModalDialogProvider>
        </ReactQueryProvider>
      </DatabaseProvider>
    </SplashScreenProvider>
  );
};
