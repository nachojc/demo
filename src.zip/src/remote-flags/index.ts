import { observable } from '@legendapp/state';

const remoteFlags = [
  {
    type: 'boolean',
    flagKey: 'release-myaviva-test',
    defaultValue: true,
  },
  {
    type: 'string',
    flagKey: 'custom-myaviva-version-supported',
    defaultValue: 'LatestVersion',
  },
  {
    type: 'boolean',
    flagKey: 'release-myaviva-ifp-sectorbreakdown-day2-enabled',
    defaultValue: true,
  },
  {
    type: 'boolean',
    flagKey: 'release-myaviva-direct-wealth-in-manga',
    defaultValue: false,
  },
] as const;

export type RemoteFlagKey = (typeof remoteFlags)[number]['flagKey'];

// eslint-disable-next-line @typescript-eslint/no-redundant-type-constituents
export type RemoteFlagValue = boolean | number | string | unknown;

type FromTypeName<T> = T extends 'boolean'
  ? boolean
  : T extends 'string'
  ? string
  : T extends 'number'
  ? number
  : unknown;

export type RemoteFlagValueForKey<K extends RemoteFlagKey> = FromTypeName<
  Extract<(typeof remoteFlags)[number], { flagKey: K }>['type']
>;

export type RemoteFlag = {
  flagKey: RemoteFlagKey;
} & (
  | {
      type: 'boolean';
      defaultValue: boolean;
    }
  | {
      type: 'number';
      defaultValue: number;
    }
  | {
      type: 'string';
      defaultValue: string;
    }
  | {
      type: 'json';
      defaultValue: unknown;
    }
);

// eslint-disable-next-line @typescript-eslint/naming-convention
export type RemoteFlagValueType = RemoteFlag['type'];

export const RemoteFlags = remoteFlags as readonly RemoteFlag[];

export const RemoteFlagsMap = new Map<RemoteFlagKey, RemoteFlag>(
  RemoteFlags.map((f) => [f.flagKey, f])
);

export type RemoteFlagOverride = {
  enabled: boolean;
  value: RemoteFlagValue;
};

const OverrideValues: { [key: string]: RemoteFlagOverride } = {};

export const RemoteFlagOverrides = observable(OverrideValues);

export const setRemoteFlagOverride = (
  key: RemoteFlagKey,
  value: RemoteFlagValue
) => {
  RemoteFlagOverrides[key].set({
    enabled: true,
    value,
  });
};

export const removeRemoteFlagOverride = (key: RemoteFlagKey) => {
  RemoteFlagOverrides[key].delete();
};
