import {
  Button,
  ButtonVariant,
  Dialog,
  DialogProps,
  FocusAwareStatusBar,
  Icon,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { tokens } from '@src/theme/tokens';
import { useTranslation } from 'react-i18next';

type ErrorDialogProps = {
  buttonText?: string;
  buttonLabel?: string;
  buttonHint?: string;
  onPress: () => void;
  dialogAnalyticsTag?: string;
} & Partial<DialogProps>;

export const ErrorDialog = ({
  title = "We're sorry, something went wrong.",
  copy = 'Please try again.',
  buttonText,
  buttonLabel,
  buttonHint,
  onPress,
  dialogAnalyticsTag,
  ...dialogProps
}: ErrorDialogProps) => {
  const { t } = useTranslation();
  const { trackStateEvent } = useAnalytics();

  if (!dialogProps.open) {
    return null;
  }

  dialogAnalyticsTag && trackStateEvent(dialogAnalyticsTag);
  return (
    <>
      <FocusAwareStatusBar translucent />
      <Dialog
        icon={<Icon name="alert-circle" color={tokens.color.Error.val} />}
        title={title}
        copy={copy}
        {...dialogProps}
      >
        {dialogProps.children ?? (
          <Button
            variant={ButtonVariant.BRAND}
            mt="$xl"
            height={tokens.size[8].val}
            onPress={onPress}
            {...(buttonLabel ? { accessibilityLabel: buttonLabel } : {})}
            {...(buttonHint ? { accessibilityHint: buttonHint } : {})}
          >
            {buttonText ?? t('common.buttons.ok')}
          </Button>
        )}
      </Dialog>
    </>
  );
};
