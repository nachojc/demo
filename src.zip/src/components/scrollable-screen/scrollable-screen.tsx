import { ScrollView, styled } from '@aviva/ion-mobile';
import { useHeaderHeight } from '@react-navigation/elements';
import { ReactNode } from 'react';
import { KeyboardAvoidingView, Platform } from 'react-native';

type ScrollableScreenProps = {
  bg?: string;
  children: ReactNode;
};

export const ScrollableScreen = ({ children, bg }: ScrollableScreenProps) => {
  const headerHeight = useHeaderHeight();
  return (
    <KeyboardAvoidingView
      keyboardVerticalOffset={headerHeight}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      style={{ flex: 1 }}
    >
      <Container bg={bg}>{children}</Container>
    </KeyboardAvoidingView>
  );
};

export const Container = styled(ScrollView, {
  backgroundColor: '$Gray050',
  flex: 1,

  /**
   * App crashes when tamagui tokens are used below,
   * either as '$spaceToken' or with getVariableValue()
   */
  contentContainerStyle: {
    flexGrow: 1,
    paddingVertical: 24,
    justifyContent: 'space-between',
  },
});
