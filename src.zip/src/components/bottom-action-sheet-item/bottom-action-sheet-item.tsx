import { getTokens, Icon, Text, XStack } from '@aviva/ion-mobile';

import { DisplayOptions } from './../../../products/direct-wealth/features/product-view/investments-tab';

export const BottomActionSheetItem = ({
  icon,
  title,
  onOptionPress,
  accessibilityLabel = title,
  accessibilityHint = '',
}: DisplayOptions) => {
  const tokens = getTokens();
  return (
    <XStack
      alignItems="center"
      space={18}
      padding={18}
      onPress={onOptionPress}
      accessible
      accessibilityRole="button"
      accessibilityLabel={accessibilityLabel}
      accessibilityHint={accessibilityHint}
    >
      <Icon name={icon} color={tokens.color.Secondary800.val} />
      <Text fontVariant="body-semibold-Gray800">{title}</Text>
    </XStack>
  );
};
