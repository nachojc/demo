import { APP_BASE } from '@constants/analytics';

export const DISMISS_WEBVIEW_TAPPED = `${APP_BASE}web-view-closed-tapped`;
