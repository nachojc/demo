import { WebViewComponent } from '@src/components/web-view';
import {
  useAppStackNavigation,
  useAppStackRoute,
} from '@src/navigation/app/hooks';

export const InterceptClosingWebView = () => {
  const { uri, interceptUri } =
    useAppStackRoute<'Intercept Closing Webview'>().params;

  const navigation = useAppStackNavigation();

  const onUriIntercepted = () => {
    navigation.goBack();
  };

  return (
    <WebViewComponent
      testID="intercept-closing-webview"
      ssoEnabled
      source={{
        uri,
      }}
      onIntercept={onUriIntercepted}
      interceptUri={interceptUri}
    />
  );
};
