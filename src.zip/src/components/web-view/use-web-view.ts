import { ACPIdentity } from '@adobe/react-native-acpcore';
import { webLinks } from '@constants/web-links';
import { getLogger } from '@interfaces/logger';
import { config } from '@src/common/config';
import { AuthenticationModel } from '@src/models';
import { isEsecStagingDomain } from '@src/utils/api';
import { useMutation } from '@tanstack/react-query';
import { useCallback, useEffect, useState } from 'react';

type WebViewHookProps = {
  redirectUrl: string;
  ssoEnabled?: boolean;
  appendVisitorInfoEnabled?: boolean;
};

const log = getLogger(useWebView.name);

export function useWebView({
  redirectUrl,
  ssoEnabled = true,
  appendVisitorInfoEnabled = true,
}: WebViewHookProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [url, setUrl] = useState<string>();

  if (ssoEnabled && isEsecStagingDomain(redirectUrl)) {
    redirectUrl = redirectUrl.replace(
      config.BASE_URL.get(),
      config.DIG_BASE_URL.get()
    );
  }

  const { mutateAsync: getSSOToken } = useMutation({
    mutationKey: ['getSSOToken'] as const,
    mutationFn: async () => new AuthenticationModel().getSSOToken(),
  });

  const appendVisitorInfoForRedirectUrl = useCallback(
    async () =>
      (await ACPIdentity.appendVisitorInfoForURL(redirectUrl)) ?? redirectUrl,
    [redirectUrl]
  );

  const formatURL = useCallback(
    async (ssoToken: string) => {
      const redirurl = encodeURIComponent(
        await appendVisitorInfoForRedirectUrl()
      );
      return webLinks.sso(ssoToken, redirurl);
    },
    [appendVisitorInfoForRedirectUrl]
  );

  const getTokenAndGenerateLink = useCallback(async () => {
    try {
      setIsLoading(true);
      const { access_token: accessToken } = await getSSOToken();

      formatURL(accessToken).then(setUrl);
    } catch (e) {
      log.error(e);
    } finally {
      setIsLoading(false);
    }
  }, [getSSOToken, formatURL]);

  useEffect(() => {
    if (ssoEnabled) {
      getTokenAndGenerateLink();
    } else if (appendVisitorInfoEnabled) {
      appendVisitorInfoForRedirectUrl().then(setUrl);
      setIsLoading(false);
    } else {
      setUrl(redirectUrl);
      setIsLoading(false);
    }
  }, [
    ssoEnabled,
    getTokenAndGenerateLink,
    redirectUrl,
    appendVisitorInfoForRedirectUrl,
    appendVisitorInfoEnabled,
  ]);

  return {
    isLoading,
    url,
  };
}
