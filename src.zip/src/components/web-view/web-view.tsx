import {
  Button,
  LoadingState,
  Progress,
  Stack,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import CookieManager from '@react-native-cookies/cookies';
import { useNavigation } from '@react-navigation/native';
import { config } from '@src/common/config';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect, useState } from 'react';
import { WebView, WebViewProps } from 'react-native-webview';
import { WebViewSourceUri } from 'react-native-webview/lib/WebViewTypes';
import { RequireAllOrNone } from 'type-fest';

import { DISMISS_WEBVIEW_TAPPED } from './analytics';
import { useWebView } from './use-web-view';

type WebViewOnCloseProps = {
  onIntercept: () => void;
  interceptUri: string;
};

export type WebViewComponentProps = WebViewProps &
  RequireAllOrNone<WebViewOnCloseProps, keyof WebViewOnCloseProps> & {
    ssoEnabled?: boolean;
    useProgressBar?: boolean;
    appendVisitorInfoEnabled?: boolean;
  };

/**
 * @description
 * WebViewComponent opens a URL with an in-app webview.
 * If the URL requires SSO, you can enabled it with `ssoEnabled`.
 * If `interceptUri` is provided, the webview can intercept redirects and call the `onClose` function provided.
 * The consumer should dismiss/goBack when onClose is called and could refresh the screen if needed.
 * appendVisitorInfoEnabled = false prevents ACPIdentity from '@adobe/react-native-acpcore' from been applied to url
 * @example
 * Public URL
 * <WebViewComponent source={{uri: 'https://...'}}/>
 * Authenticated URL
 * <WebViewComponent ssoEnabled source={{uri: '/...'}}/>
 * Back to app handling
 * <WebViewComponent
 *   ssoEnabled
 *   source={{uri: '/...'}}
 *   onClose={() => navigation.goBack()}
 *   interceptUri="BackToProvider"
 *
 * />
 */

export const WebViewComponent = ({
  ssoEnabled = false,
  onIntercept,
  interceptUri,
  useProgressBar = true,
  appendVisitorInfoEnabled = true,
  ...props
}: WebViewComponentProps) => {
  const uri = (props.source as WebViewSourceUri)?.uri;
  const { url } = useWebView({
    redirectUrl: uri,
    ssoEnabled,
    appendVisitorInfoEnabled,
  });

  const { addListener, goBack } = useNavigation();
  const analytics = useAnalytics();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const unsubscribe = addListener('beforeRemove', () => {
      analytics.trackUserEvent(DISMISS_WEBVIEW_TAPPED);
      CookieManager.removeSessionCookies();
    });

    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <>
      {useProgressBar && progress < 100 && (
        <Progress
          testID="webview-progress"
          value={progress}
          containerProps={{ py: '$0' }}
        />
      )}

      <WebView
        {...props}
        // https://github.com/react-native-webview/react-native-webview/issues/811
        style={{ opacity: 0.99, overflow: 'hidden' }}
        source={{ uri: url ?? uri }}
        webviewDebuggingEnabled={config.ENV.get() !== 'production'}
        startInLoadingState
        onLoadProgress={(e) => setProgress(e.nativeEvent.progress * 100)}
        // https://github.com/react-native-webview/react-native-webview/issues/1031
        renderLoading={() => (
          <Stack
            pos="absolute"
            w="100%"
            h="100%"
            jc="center"
            bc="$White"
            testID="WebView-Spinner"
          >
            <LoadingState fullscreen={false} text="oneMoment" />
          </Stack>
        )}
        renderError={() => (
          <Stack pos="absolute" w="100%" h="100%" jc="center" bc="$Gray700">
            <YStack tabletNarrow={isIpad} bc="$White" m="$xl" p="$xl" br="$1">
              <Text
                fontVariant="heading4-semibold-Secondary800"
                tamaguiTextProps={{ mb: '$xs' }}
              >
                Unable to load
              </Text>
              <Text fontVariant="body-regular-Secondary800">
                {`We're sorry, something went wrong.`}
              </Text>
              <Text fontVariant="body-regular-Secondary800">
                Please try again.
              </Text>
              <YStack tabletNarrow={isIpad}>
                <Button width="100%" mt="$xl" onPress={goBack}>
                  OK
                </Button>
              </YStack>
            </YStack>
          </Stack>
        )}
        onShouldStartLoadWithRequest={(request) => {
          if (
            interceptUri &&
            request?.url.includes(interceptUri) &&
            onIntercept
          ) {
            onIntercept();
            return false;
          }
          return true;
        }}
      />
    </>
  );
};
