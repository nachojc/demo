import { ScrollView, YStack, YStackProps } from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';
import { FC, ReactNode, useEffect, useRef, useState } from 'react';
import { AppState, PixelRatio } from 'react-native';

export const isEnableTextSize = (size: number, textRatio: number) =>
  size > textRatio;

type YStackSizeProps = YStackProps & {
  children: ReactNode;
  textRatio?: number;
};

export const YStackPixelRatio: FC<YStackSizeProps> = ({
  textRatio = 1,
  children,
  ...props
}) => {
  const appState = useRef(AppState.currentState);
  const [enableTextSize, setEnableTextSize] = useState(
    isEnableTextSize(PixelRatio.getFontScale(), textRatio)
  );

  useEffect(() => {
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      if (
        appState.current.match(/inactive|background/) &&
        nextAppState !== 'active'
      ) {
        setEnableTextSize(
          isEnableTextSize(PixelRatio.getFontScale(), textRatio)
        );
      }
    });

    return () => subscription.remove();
  }, []);

  return enableTextSize ? (
    <ScrollView testID={getTestId('scroll-view')}>
      <YStack {...props}>{children}</YStack>
    </ScrollView>
  ) : (
    <YStack testID={getTestId('stack-view')} {...props}>
      {children}
    </YStack>
  );
};
