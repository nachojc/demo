import {
  FormattedValue,
  getTokens,
  getVariableValue,
  Icon,
  Stack,
  Text,
  TrendValue,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { formatCurrencyValue } from '@src/utils/format-currency-value';
import { formatPensionFunds } from '@src/utils/format-pension-data';
import { getTestId } from '@src/utils/get-test-id';
import { Color } from '@theme/tokens';
import { useTranslation } from 'react-i18next';

type FundValueProps = {
  colorMain: Color;
  colorNegative: Color;
  colorZero: Color;
  colorPositive: Color;
  colorSecondary: Color;
  gainOrLoss: FormattedValue;
  gainOrLossPercentage: FormattedValue;
  showTrendValue?: boolean;
  onPress?: () => void;
  valuation: number;
};

export const FundValue = ({
  colorMain,
  colorNegative,
  colorZero,
  colorPositive,
  colorSecondary,
  gainOrLoss,
  gainOrLossPercentage,
  onPress,
  showTrendValue = true,
  valuation,
}: FundValueProps) => {
  const tokens = getTokens();
  const { t } = useTranslation();

  const isPositive = (gainOrLoss.raw ?? 0) > 0;

  return (
    <>
      <YStack
        testID="fundValue"
        accessible
        accessibilityLabel={t('pension.performance.headingValuation', {
          valuation: formatCurrencyValue(valuation),
        })}
        alignItems="center"
      >
        <XStack>
          <Text
            fontVariant={`overline-regular-${colorSecondary}`}
            testID={getTestId('CurrentAccountValue')}
            tamaguiTextProps={{
              letterSpacing: getVariableValue(tokens.space.xs),
            }}
          >
            {t('pension.performance.currentAccountValue')}
          </Text>
        </XStack>
        <YStack>
          <Text
            fontVariant={`heading0-semibold-${colorMain}`}
            tamaguiTextProps={{
              letterSpacing: getVariableValue(tokens.space.xs),
              lineHeight: getVariableValue(tokens.size[9]),
            }}
            testID={getTestId('FundValueCopy')}
          >
            {formatPensionFunds(valuation)}
          </Text>
        </YStack>
      </YStack>

      {showTrendValue && (
        <XStack alignSelf="center">
          <Stack
            accessibilityLabel={t(
              `pension.performance.change_${isPositive ? 'gain' : 'loss'}`,
              {
                changeAmount: formatCurrencyValue(gainOrLoss.raw ?? 0),
                changePercentage: gainOrLossPercentage.raw,
              }
            )}
            accessible
          >
            <TrendValue
              colorNegative={colorNegative}
              colorPositive={colorPositive}
              colorZero={colorZero}
              gainOrLoss={gainOrLoss}
              gainOrLossPercentage={gainOrLossPercentage}
            />
          </Stack>
          <Stack
            marginLeft={-getVariableValue(tokens.size[2])}
            marginRight={-getVariableValue(tokens.size[4])}
            marginTop={-getVariableValue(tokens.size[4])}
            padding={getVariableValue(tokens.size[4])}
          >
            <XStack
              accessible
              accessibilityRole="button"
              accessibilityLabel={t('pension.performance.gainloss.tooltip')}
              testID="GainLossButton"
              onPress={onPress}
            >
              <Icon
                name="info"
                color={getVariableValue(tokens.color.Primary500)}
                stroke={getVariableValue(tokens.color.Gray900)}
                height={getVariableValue(tokens.size[4])}
                width={getVariableValue(tokens.size[4])}
              />
            </XStack>
          </Stack>
        </XStack>
      )}
    </>
  );
};
