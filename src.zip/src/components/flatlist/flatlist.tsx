import { FlashList, FlashListProps } from '@shopify/flash-list';
import { View } from 'react-native';

/*
 Explanation for fixing MANGA-3544:

 There is an intermittent problem on iOS when using a horizontal list without specifying a height.
 The problem is caused when an item in the list changes its height internally, which causes an
 infinite render loop.

 These problems are solved when specifying a fixed height for the FlashList as the component no longer
 has to calculate its height based on its contents.

 We think this fix will be amiable because horizontal lists should never have an unknown height
 as their items will always have a uniform height, and this will protect us from future issues,
 even if the list's contents dynamically change their height.

 The change to the api is small: When passing in `horizontal={true}`, we now must specify
 a height `listHeight={150}`.

 Note: to explain why we wrap the list in a view and can't just set style.height:
 https://shopify.github.io/flash-list/docs/known-issues/
 */

export type HorizontalFlashListProps = {
  horizontal: true;
  listHeight: number;
};

export type VerticalFlashListProps = {
  horizontal?: false | null;
};

export function FlatList<T>(
  props: FlashListProps<T> & (HorizontalFlashListProps | VerticalFlashListProps)
) {
  return props.horizontal ? (
    <View testID="flat-list-wrapper" style={{ height: props.listHeight }}>
      <FlashList {...props} />
    </View>
  ) : (
    <FlashList {...props} />
  );
}
