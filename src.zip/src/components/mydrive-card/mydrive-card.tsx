import { Card, LoadingState, Text, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useMyDriveOnwardJourney } from '@hooks/use-mydrive-onward-journey-creator';
import { myDriveOnboardingCompleted } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { MyDriveNotEnabledDialog } from '@src/features/mydrive/components/dialogues';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { MyDriveScreen } from '@src/navigation/app/summary/stack-groups/mydrive';
import { NoHeaderScreen } from '@src/navigation/app/summary/stack-groups/no-header';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { Dispatch, SetStateAction, useState } from 'react';

import {
  ACTION_ACTIVE_TAPPED_AO_MOTOR,
  ACTION_ACTIVE_TAPPED_YOUR_TOOLS,
  ACTION_IPAD_CARD_TAPPED_AO_MOTOR,
  ACTION_IPAD_CARD_TAPPED_YOUR_TOOLS,
  ACTION_IPAD_INELIGIBLE_CLOSE_TAPPED_AO_MOTOR,
  ACTION_IPAD_INELIGIBLE_CLOSE_TAPPED_YOUR_TOOLS,
  ACTION_NOT_ACTIVE_TAPPED_AO_MOTOR,
  ACTION_NOT_ACTIVE_TAPPED_YOUR_TOOLS,
} from './analytics';

const imageMyDrive = require('assets/your-tools/mydrive.png');

type MyDriveCardProps = {
  isMyDriveActive?: boolean;
  setShowInternetDialog?: Dispatch<SetStateAction<boolean>>;
  screenVariant: 'ao-motor' | 'your-tools';
};

export const MyDriveCard = ({
  isMyDriveActive,
  setShowInternetDialog,
  screenVariant,
}: MyDriveCardProps) => {
  const { navigate } = useAppStackNavigation();
  const { getOnwardJourney, isLoading } = useMyDriveOnwardJourney();
  const { trackUserEvent } = useAnalytics();
  const [showDialog, setShowDialog] = useState(false);
  const myDriveOnboardingCompletedValue = useSelector(
    myDriveOnboardingCompleted
  );

  const onNavToMyDriveOnboarding = async () => {
    if (!myDriveOnboardingCompleted.get()) {
      navigate(MyDriveScreen.Onboarding);
      return;
    }

    const nextScreen = await getOnwardJourney();

    switch (nextScreen) {
      case NoHeaderScreen.Dashboard:
        return;
      case 'NetworkError':
        if (setShowInternetDialog) {
          setShowInternetDialog(true);
        }
        return;
      default:
        navigate(nextScreen);
        return;
    }
  };

  const tags = {
    'your-tools': {
      actionActiveTapped: ACTION_ACTIVE_TAPPED_YOUR_TOOLS,
      actionIPadCardTapped: ACTION_IPAD_CARD_TAPPED_YOUR_TOOLS,
      actionNotActiveTapped: ACTION_NOT_ACTIVE_TAPPED_YOUR_TOOLS,
      actionIPadInEligibilityCloseCardTapped:
        ACTION_IPAD_INELIGIBLE_CLOSE_TAPPED_YOUR_TOOLS,
    },
    'ao-motor': {
      actionActiveTapped: ACTION_ACTIVE_TAPPED_AO_MOTOR,
      actionIPadCardTapped: ACTION_IPAD_CARD_TAPPED_AO_MOTOR,
      actionNotActiveTapped: ACTION_NOT_ACTIVE_TAPPED_AO_MOTOR,
      actionIPadInEligibilityCloseCardTapped:
        ACTION_IPAD_INELIGIBLE_CLOSE_TAPPED_AO_MOTOR,
    },
  };

  const {
    actionActiveTapped,
    actionIPadCardTapped,
    actionNotActiveTapped,
    actionIPadInEligibilityCloseCardTapped,
  } = tags[screenVariant];

  const fireTagAndNavigate = () => {
    if (isIpad) {
      setShowDialog(true);
      trackUserEvent(actionIPadCardTapped);
      return;
    }
    trackUserEvent(
      isMyDriveActive && myDriveOnboardingCompletedValue
        ? actionActiveTapped
        : actionNotActiveTapped
    );
    onNavToMyDriveOnboarding();
  };

  const onClose = () => {
    trackUserEvent(actionIPadInEligibilityCloseCardTapped);
    setShowDialog(false);
  };

  const copy = () => {
    const eligibilityVariant =
      isMyDriveActive && myDriveOnboardingCompletedValue
        ? 'onboarded'
        : 'eligible';
    const variant = isIpad ? 'ipad' : eligibilityVariant;

    switch (variant) {
      case 'ipad':
        return {
          title: 'MyDrive',
          subtitle:
            'To access your MyDrive dashboard, journeys and scores, please use your mobile device.',
        };
      case 'eligible':
        return {
          title: 'MyDrive',
          subtitle:
            'You could get a discount on your Aviva Online or Aviva Premium motor insurance renewal simply by driving safely thanks to our new feature, MyDrive.',
        };
      case 'onboarded':
        return {
          title: 'See your MyDrive score',
          subtitle:
            'Check your driving score regularly to see how you can become a safer driver and your progress to a potential renewal discount.',
        };
    }
  };

  const { title, subtitle } = copy();

  return (
    <YStack minWidth={isIpad ? '100%' : undefined}>
      {isLoading && <LoadingState text="oneMoment" />}
      <Card onPress={fireTagAndNavigate} testID={getTestId('mydrive-card')}>
        <Card.Generic.Content
          right={<Card.Generic.Image mode="big" source={imageMyDrive} />}
        >
          <Text
            fontVariant="body-semibold-Secondary800"
            tamaguiTextProps={{ mb: '$sm' }}
          >
            {title}
          </Text>
          <Text
            fontVariant="small-regular-Secondary800"
            tamaguiTextProps={{ lineHeight: tokens.size[5].val }}
          >
            {subtitle}
          </Text>
        </Card.Generic.Content>
      </Card>
      {isIpad && (
        <MyDriveNotEnabledDialog isOpen={showDialog} onCancelPress={onClose} />
      )}
    </YStack>
  );
};
