import { MYDRIVE_BASE } from '@constants/analytics';
import { PAGE_AO_MOTOR_DETAILS } from '@src/features/policy/motor/analytics';

//AO-MOTOR
export const ACTION_ACTIVE_TAPPED_AO_MOTOR = `${PAGE_AO_MOTOR_DETAILS}|mydrive-card-active-tapped`;
export const ACTION_NOT_ACTIVE_TAPPED_AO_MOTOR = `${PAGE_AO_MOTOR_DETAILS}|mydrive-card-tapped`;
export const ACTION_IPAD_CARD_TAPPED_AO_MOTOR = `${PAGE_AO_MOTOR_DETAILS}|mydrive-ipad-card-tapped`;
export const ACTION_IPAD_INELIGIBLE_CLOSE_TAPPED_AO_MOTOR = `${PAGE_AO_MOTOR_DETAILS}|mydrive-ipad-ineligibility|close-tapped`;

//YOUR_TOOLS
export const ACTION_ACTIVE_TAPPED_YOUR_TOOLS = `${MYDRIVE_BASE}card-active-tapped`;
export const ACTION_NOT_ACTIVE_TAPPED_YOUR_TOOLS = `${MYDRIVE_BASE}card-tapped`;
export const ACTION_IPAD_CARD_TAPPED_YOUR_TOOLS = `${MYDRIVE_BASE}ipad-card-tapped`;
export const ACTION_IPAD_INELIGIBLE_CLOSE_TAPPED_YOUR_TOOLS = `${MYDRIVE_BASE}ipad-ineligibility|close-tapped`;
