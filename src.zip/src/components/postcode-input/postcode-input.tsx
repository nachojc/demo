import { ButtonVariant, Dialog, LoadingState, YStack } from '@aviva/ion-mobile';
import {
  PostcodeSearchForm,
  PostcodeSearchSchema,
} from '@aviva/ion-mobile/components/address-input/address-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { usePostcodeLookup } from '@hooks/use-postcode-lookup';
import NetInfo from '@react-native-community/netinfo';
import { Aviva_Digital_MobileApi_Endpoints_PostcodeLookup_V1_Model_PostcodeLookupModel as PostcodeLookup } from '@src/api/generated/requests';
import { FormInput } from '@src/components/forms/form-input';
import { getTestId } from '@src/utils/get-test-id';
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';

import { ErrorDialog } from '../error-dialog';

const is400Error = (err: unknown) =>
  err && typeof err === 'object' && 'status' in err && err.status === 400;

type AddressInputProps = {
  header?: string;
  onPostcodeLookupCompletion: (addresses: PostcodeLookup) => void;
  onSearch?: () => void;
};

export const PostcodeInput = ({
  header,
  onSearch,
  onPostcodeLookupCompletion,
}: AddressInputProps) => {
  const { t } = useTranslation();

  const { control, setError, handleSubmit } = useForm<PostcodeSearchForm>({
    resolver: zodResolver(PostcodeSearchSchema),
  });

  const { mutateAsync, isLoading, isError, error, reset } = usePostcodeLookup();

  const [isInternetErrorDialogOpen, setIsInternetErrorDialogOpen] =
    useState(false);
  const onClose = () => setIsInternetErrorDialogOpen(false);

  const onSubmit = async ({ postcodeSearch }: PostcodeSearchForm) => {
    try {
      const { isConnected } = await NetInfo.fetch();
      if (!isConnected) {
        setIsInternetErrorDialogOpen(true);
        return;
      }

      const addressData = await mutateAsync(postcodeSearch);

      if (addressData.Addresses?.length === 0) {
        setError('postcodeSearch', {
          message: t('postcodeLookup.manga.invalidPostcodeOtherError'),
        });
        return;
      }
      onPostcodeLookupCompletion(addressData);
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <YStack>
      {isLoading && <LoadingState fullscreen />}
      <FormInput
        type="search"
        onSearch={() => {
          onSearch?.();
          handleSubmit(onSubmit)();
        }}
        name="postcodeSearch"
        label={header}
        control={control}
        buttonVariant={ButtonVariant.BRAND}
        buttonTestID={getTestId('searchPostcode')}
        placeholder={t('postcodeLookup.placeholder')}
        buttonText={t('postcodeLookup.header')}
        maxLength={8}
      />

      <ErrorDialog
        open={isError}
        onPress={reset}
        title={t(
          is400Error(error)
            ? 'postcodeLookup.manga.invalidPostcodeApiErrorTitle'
            : 'common.apiError.title'
        )}
        copy={t(
          is400Error(error)
            ? 'postcodeLookup.manga.invalidPostcodeApiErrorCopy'
            : 'common.apiError.copy'
        )}
      />
      <Dialog
        open={isInternetErrorDialogOpen}
        title={t('common.noInternetConnectionDialog.title')}
        copy={t('common.noInternetConnectionDialog.copy')}
        actions={[
          {
            title: 'Retry',
            actionOnPress: () => {
              setIsInternetErrorDialogOpen(false);
              handleSubmit(onSubmit)();
            },
          },
        ]}
        cancelButton
        onPressCancel={onClose}
      />
    </YStack>
  );
};
