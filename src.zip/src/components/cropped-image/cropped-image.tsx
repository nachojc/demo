import {
  getTokens,
  getVariableValue,
  LinearGradient,
  LinearGradientProps,
  Stack,
} from '@aviva/ion-mobile';
import MaskedView from '@react-native-masked-view/masked-view';
import { Color } from '@theme/tokens';
import { Image, ImageSourcePropType } from 'react-native';
import Svg, { Path } from 'react-native-svg';

type CroppedImageProps = {
  backgroundColor?: Color;
  cropDegree: number;
  height: number;
  source: ImageSourcePropType;
  width: number;
  linearGradient?: LinearGradientProps;
};

export const CroppedImage = ({
  backgroundColor,
  cropDegree,
  height,
  source,
  width,
  linearGradient,
}: CroppedImageProps) => {
  const tokens = getTokens();
  const radians = (Math.PI / 180) * cropDegree;
  const xCoordinate = height * Math.tan(radians);

  return (
    <Stack
      alignSelf="center"
      height={height}
      width={width}
      testID="CroppedImage.Container"
      backgroundColor={
        backgroundColor
          ? getVariableValue(tokens.color[backgroundColor])
          : undefined
      }
    >
      <MaskedView
        testID="CroppedImage.Mask"
        maskElement={
          <Svg height={height} width={width} viewBox={`0 0 ${width} ${height}`}>
            <Path
              d={`M0,0 L${xCoordinate},${height} H${width} V0 Z`}
              fill="black"
            />
          </Svg>
        }
      >
        <>
          <Image
            accessibilityIgnoresInvertColors
            testID="CroppedImage.Image"
            resizeMode="cover"
            source={source}
            style={{ width, height }}
          />
          {linearGradient ? (
            <LinearGradient
              position="absolute"
              width={width}
              height={height}
              {...linearGradient}
            />
          ) : null}
        </>
      </MaskedView>
    </Stack>
  );
};
