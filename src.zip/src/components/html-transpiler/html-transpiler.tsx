import {
  FontVariant,
  getVariableValue,
  ScrollView,
  SpaceTokens,
  styled,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { tokens } from '@theme/tokens';
import { ReactNode } from 'react';

type UnorderedList = { type: 'Unordered List' };
type OrderedList = { type: 'Ordered List'; ordinal: number };
type ListVariant = UnorderedList | OrderedList;
type ListElement = { id: string; content: string };

export const Container = styled(ScrollView, {
  paddingVertical: '$md',
  paddingHorizontal: '$xl',
  backgroundColor: '$Gray050',
});

/**
 * @description Unordered (bulleted) list <ul>, a wrapper for LITag's.
 */
export const ULTag = styled(YStack, {
  paddingLeft: tokens.size[2],
});

/**
 * @description List item <li>.
 * Takes level as parameter for nested ul/li's (2 levels at the moment).
 */
export const LITagSpaced = ({
  children,
  level = 1,
}: {
  children: ReactNode;
  level?: 1 | 2;
}) => {
  return (
    <LI mb="$lg" level={level}>
      {children}
    </LI>
  );
};

export const LITag = ({
  children,
  level = 1,
}: {
  children: ReactNode;
  level?: 1 | 2;
}) => {
  return (
    <LI mb="$0" level={level}>
      {children}
    </LI>
  );
};

const LI = ({
  children,
  level,
  mb,
  listVariant = { type: 'Unordered List' },
  fontVariant = 'heading4-semibold-Secondary800',
}: {
  children: ReactNode;
  mb: SpaceTokens;
  listVariant?: ListVariant;
  level?: 1 | 2;
  fontVariant?: FontVariant;
}) => {
  const icon: string = level === 1 ? `\u2022` : `\u25E6`;
  return (
    <XStack>
      <YStack paddingRight={getVariableValue(tokens.size[2])}>
        <Text fontVariant={fontVariant}>
          {listVariant.type === 'Unordered List'
            ? icon
            : listVariant.ordinal + '.'}
        </Text>
      </YStack>
      <YStack flex={1} mb={mb}>
        {children}
      </YStack>
    </XStack>
  );
};

export const OLTag = ({
  elements,
  fontVariant,
  renderItem,
}: {
  elements: ListElement[];
  fontVariant: FontVariant;
  renderItem: (listElement: ListElement) => ReactNode;
}) => {
  return (
    <ULTag>
      {elements.map((elem, idx) => (
        <LI
          key={elem.id}
          mb="$0"
          level={1}
          listVariant={{ type: 'Ordered List', ordinal: idx + 1 }}
          fontVariant={fontVariant}
        >
          {renderItem(elem)}
        </LI>
      ))}
    </ULTag>
  );
};

/**
 * @description Bordered Table Header
 */
export const TableHeader = styled(XStack, {
  borderWidth: tokens.size['0.25'],
});

/**
 * @description Bordered Table <tr>
 */
export const TableTR = styled(XStack, {
  borderWidth: tokens.size['0.25'],
  borderTopWidth: 0,
});

export const TableTDStyled = styled(XStack, {
  flex: 1,
  padding: tokens.size[1],
  variants: {
    hideBorderRight: {
      true: {
        borderRightWidth: 0,
      },
      false: {
        borderRightWidth: tokens.size['0.25'],
      },
    },
  },
});

/**
 * @description Bordered Table <td>
 * Takes parameter noBorderRight - used for the last <td> in <tr>
 */
export const TableTD = ({
  children,
  header,
  noBorderRight,
}: {
  children: ReactNode;
  header?: boolean;
  noBorderRight?: boolean;
}) => {
  return (
    <TableTDStyled hideBorderRight={!!noBorderRight}>
      <Text
        fontVariant={
          header ? 'body-semibold-Secondary800' : 'body-regular-Secondary800'
        }
      >
        {children}
      </Text>
    </TableTDStyled>
  );
};
