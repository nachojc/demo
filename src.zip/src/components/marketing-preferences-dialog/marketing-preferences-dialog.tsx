import { Button, ButtonVariant, Dialog } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { marketingPreferenceShown } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { HelpScreenNames } from '@src/navigation/app/help-screens';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { useTranslation } from 'react-i18next';

import {
  MARKETING_PREFERENCES_OK_TAPPED,
  MARKETING_PREFERENCES_PRIVACY_POLICY_TAPPED,
} from './analytics';

export const MarketingPreferencesDialog = () => {
  const { t } = useTranslation();
  const { trackUserEvent } = useAnalytics();
  const { navigate } = useAppStackNavigation();
  const showMarketingPreferenceDialog = useSelector(
    () => !marketingPreferenceShown.get()
  );

  const onMarketingOKPress = () => {
    trackUserEvent(MARKETING_PREFERENCES_OK_TAPPED);
    marketingPreferenceShown.set(true);
  };

  const onMarketingPrivacyPolicyPress = () => {
    trackUserEvent(MARKETING_PREFERENCES_PRIVACY_POLICY_TAPPED);
    marketingPreferenceShown.set(true);
    navigate(HelpScreenNames.PrivacyPolicy);
  };

  return (
    <Dialog
      open={showMarketingPreferenceDialog}
      title={t('marketingPreferences.dialog.title')}
      copy={t('marketingPreferences.dialog.copy')}
      center={false}
    >
      <Button mt="$md" onPress={onMarketingOKPress}>
        {t('common.buttons.ok')}
      </Button>
      <Button
        mt="$md"
        variant={ButtonVariant.LINK_TEXT}
        onPress={onMarketingPrivacyPolicyPress}
      >
        {t('marketingPreferences.dialog.privacyPolicy')}
      </Button>
    </Dialog>
  );
};
