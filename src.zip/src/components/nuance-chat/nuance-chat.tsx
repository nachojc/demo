import { APP_BASE } from '@constants/analytics';
import { useAnalytics } from '@hooks/use-analytics';
import { NuanceMetadata, useChat } from '@hooks/use-chat';
import { useModalState } from '@hooks/use-modal-state';
import { asyncOnboardingComplete } from '@interfaces/storage';
import {
  ComponentType,
  createContext,
  ReactNode,
  useCallback,
  useMemo,
  useState,
} from 'react';

import {
  CHATBOT_TAPPED,
  CHATBOT_WINDOW,
  CHATBOT_WINDOW_CLOSE_TAPPED,
  CHATBOT_WINDOW_MINIMISED,
  ONBOARDING_CLOSE_TAPPED,
  ONBOARDING_CONTINUE_TAPPED,
  ONBOARDING_MODAL,
} from './analytics';
import {
  NuanceChatOnboardingProps,
  NuanceChatOnboardingScreen,
} from './nuance-onboarding/nuance-onboarding';

/**
 * Nuance Chat component
 * @param createMetadataFunction Param to generate appropriate Metadata
 * @param analyticsData Param to create Analytics tags  e.g. *ukmyaviva|wealth|${analyticsData}|chatbot-window*
 * @param onboardingScreen `Optional` Param to provide custom onboarding screen
 * @returns
 */
type NuanceChatInitialisation = {
  createMetadataFunction: () => NuanceMetadata;
  analyticsData: string;
  onboardingScreen?: ComponentType<NuanceChatOnboardingProps>;
};

const defaultNuancePayloadValues: NuanceChatInitialisation = {
  createMetadataFunction: (): NuanceMetadata =>
    ({} as unknown as NuanceMetadata),
  analyticsData: '',
};

type NuanceChatContextValue = {
  handleOpenChat: () => void;
  setNuancePayload: (arg0: NuanceChatInitialisation) => void;
};

const defaultNuanceContextValues: NuanceChatContextValue = {
  handleOpenChat: () => {
    /* no-op */
  },
  setNuancePayload: () => {
    /* no-op */
  },
};

export const NuanceChatContext = createContext<NuanceChatContextValue>(
  defaultNuanceContextValues
);

export const NuanceChatProvider = ({ children }: { children: ReactNode }) => {
  const [nuancePayload, setNuancePayload] = useState<NuanceChatInitialisation>(
    defaultNuancePayloadValues
  );
  const { modalState, modalDispatch } = useModalState();

  const analytics = useAnalytics();
  const analyticsTag = `${APP_BASE}${nuancePayload.analyticsData}`;
  const chat = useChat();

  const openChat = useCallback(
    (action: string) => {
      chat.initChat();
      chat.openChat(
        nuancePayload.createMetadataFunction(),
        () => {
          modalDispatch({ type: 'CLOSE', target: 'nuanceChat' });
          analytics.trackUserEvent(
            `${analyticsTag}${CHATBOT_WINDOW_MINIMISED}`
          );
        },
        () => {
          modalDispatch({ type: 'CLOSE', target: 'nuanceChat' });
          analytics.trackUserEvent(
            `${analyticsTag}${CHATBOT_WINDOW_CLOSE_TAPPED}`
          );
        }
      );
      analytics.trackUserEvent(`${analyticsTag}${action}`);
      analytics.trackStateEvent(`${analyticsTag}${CHATBOT_WINDOW}`);
    },
    [analytics, analyticsTag, chat, nuancePayload]
  );

  const openOnboardingScreen = useCallback(() => {
    analytics.trackUserEvent(`${analyticsTag}${CHATBOT_TAPPED}`);
    analytics.trackStateEvent(`${analyticsTag}${ONBOARDING_MODAL}`);
    modalDispatch({ type: 'OPEN', target: 'nuanceChat' });
  }, [analytics, analyticsTag]);

  const handleOpenChat = useCallback(() => {
    asyncOnboardingComplete.get()
      ? openChat(CHATBOT_TAPPED)
      : openOnboardingScreen();
  }, [openChat, openOnboardingScreen]);

  const closeOnboarding = () => {
    asyncOnboardingComplete.set(true);
    modalDispatch({ type: 'CLOSE', target: 'nuanceChat' });
    analytics.trackUserEvent(`${analyticsTag}${ONBOARDING_CLOSE_TAPPED}`);
  };

  const completeOnboarding = () => {
    asyncOnboardingComplete.set(true);
    openChat(ONBOARDING_CONTINUE_TAPPED);
  };

  const OnboardingScreen = nuancePayload?.onboardingScreen
    ? nuancePayload.onboardingScreen
    : NuanceChatOnboardingScreen;

  const payload: NuanceChatContextValue = useMemo(
    () => ({
      handleOpenChat,
      setNuancePayload,
    }),
    [handleOpenChat]
  );

  return (
    <NuanceChatContext.Provider value={payload}>
      {children}
      <OnboardingScreen
        isModalVisible={modalState.nuanceChat}
        onClose={closeOnboarding}
        onPress={completeOnboarding}
        theme="light"
      />
    </NuanceChatContext.Provider>
  );
};
