export const CHATBOT_TAPPED = '|chatbot-tapped';
export const ONBOARDING_MODAL = '|chatbot|onboarding-modal';
export const ONBOARDING_CONTINUE_TAPPED = `${ONBOARDING_MODAL}|continue-tapped`;
export const ONBOARDING_CLOSE_TAPPED = `${ONBOARDING_MODAL}|close-tapped`;
export const CHATBOT_WINDOW = '|chatbot-window';
export const CHATBOT_WINDOW_CLOSE_TAPPED = `${CHATBOT_WINDOW}-closed-tapped`;
export const CHATBOT_WINDOW_MINIMISED = `${CHATBOT_WINDOW}-minimise-tapped`;
