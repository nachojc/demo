import { Image } from '@aviva/ion-mobile';
import { Dimensions, Text, View } from 'react-native';

import { styles } from './splash-screen.styles';

// React Native components are used as Tamagui provider is not available for the SplashScreen
export const DirectWealthSplashScreenView = () => {
  const dimensions = Dimensions.get('window');
  //Maintains 1:1 ratio
  const imageSize = dimensions.width;

  return (
    <View style={styles.containerDW}>
      <View style={{ flex: 1 }} />
      <View style={styles.imageContainerDW}>
        <Image
          style={{
            width: imageSize,
            height: imageSize,
          }}
          accessibilityIgnoresInvertColors
          source={require('assets/avivawealthblue-splash.png')}
          resizeMode={'contain'}
        />
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.textStyleDW}>Aviva Wealth</Text>
      </View>
    </View>
  );
};
