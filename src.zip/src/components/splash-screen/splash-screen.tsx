import { isManga } from '@hooks/use-expo-config';
import { ReactNode } from 'react';

import { DirectWealthSplashScreenView } from './direct-wealth-splash-screen-view';
import { SplashScreenView } from './splash-screen-view';

type SplashScreenProps = {
  children: ReactNode;
  showSplashScreen: boolean;
  appIsReady: boolean;
  fontsLoaded: boolean;
};

export const SplashScreen = ({
  children,
  showSplashScreen,
  appIsReady,
  fontsLoaded,
}: SplashScreenProps) => {
  return (
    <>
      {appIsReady && children}
      {fontsLoaded &&
        showSplashScreen &&
        (isManga() ? <SplashScreenView /> : <DirectWealthSplashScreenView />)}
    </>
  );
};
