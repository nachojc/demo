export * from './splash-screen';
