import { Image } from '@aviva/ion-mobile';
import { Text, useWindowDimensions, View } from 'react-native';
import Animated from 'react-native-reanimated';

import { styles } from './splash-screen.styles';

// React Native components are used as Tamagui provider is not available for the SplashScreen
export const SplashScreenView = () => {
  //Maintains 1:1 ratio
  const { width: imageSize } = useWindowDimensions();

  return (
    <View style={styles.container}>
      <View style={{ flex: 1 }} />
      <Animated.View style={styles.imageContainer}>
        <Image
          source={require('assets/myaviva-splash.png')}
          style={{ width: imageSize, height: imageSize }}
          accessibilityIgnoresInvertColors
          resizeMode={'contain'}
          testID="test:id/myaviva-splash"
        />
      </Animated.View>
      <View style={styles.textContainer}>
        <Text style={styles.textStyle}>MyAviva</Text>
      </View>
    </View>
  );
};
