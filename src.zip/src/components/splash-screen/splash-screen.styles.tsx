import { StyleSheet } from 'react-native';

// React Native styling is used as Tamagui provider is not available for the SplashScreen
export const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    zIndex: 1000,
    backgroundColor: '#FFD900',
  },
  containerDW: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    zIndex: 1000,
    backgroundColor: '#05142D',
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  imageContainerDW: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  textContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  textStyleDW: {
    marginBottom: 24,
    fontSize: 24,
    fontWeight: '400',
    color: '#FFFFFF',
  },
  textStyle: {
    marginBottom: 50,
    fontSize: 22,
    fontWeight: '400',
    color: '#191D64',
    fontFamily: 'SourceSansPro-Regular',
  },
});
