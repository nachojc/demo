import Clipboard from '@react-native-clipboard/clipboard';
import { useState } from 'react';

export const useCopyToClipboardSnackbar = () => {
  type OnCopyPressedProps = {
    stringToCopy: string;
  };
  const [displaySnackbar, setDisplaySnackbar] = useState(false);

  let snackbarTimeout: NodeJS.Timeout;

  const onCopyPressed = ({ stringToCopy }: OnCopyPressedProps) => {
    clearTimeout(snackbarTimeout);
    Clipboard.setString(stringToCopy);

    setDisplaySnackbar(true);
    snackbarTimeout = setTimeout(() => {
      setDisplaySnackbar(false);
    }, 5000);
  };

  return { displaySnackbar, onCopyPressed };
};
