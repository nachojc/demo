import { Snackbar, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

type StyledSnackbarProps = {
  title: string;
};

export const StyledSnackbar = ({ title }: StyledSnackbarProps) => {
  return (
    <YStack
      tablet={isIpad}
      position="absolute"
      bottom={'$xxl'}
      width={'100%'}
      paddingHorizontal={'$xl'}
      zIndex={999}
    >
      <Snackbar
        snackbar
        snackbarSingleLine
        showBorder={false}
        enterTime={1000}
        exitTime={5000}
        title={title}
        borderRadius={5}
      />
    </YStack>
  );
};
