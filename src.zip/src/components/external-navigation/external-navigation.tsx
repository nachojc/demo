import { LoadingState } from '@aviva/ion-mobile';
import { getLogger } from '@interfaces/logger';
import { useWebView } from '@src/components/web-view/use-web-view';
import { useEffect } from 'react';
import { Linking } from 'react-native';

import { ErrorDialog } from '../error-dialog';

const log = getLogger(ExternalNavigation.name);

export function ExternalNavigation({
  onEnd,
  webLink,
  ssoEnabled = false,
}: {
  onEnd: () => void;
  webLink: string;
  ssoEnabled: boolean;
}) {
  const { isLoading, url } = useWebView({ redirectUrl: webLink, ssoEnabled });

  useEffect(() => {
    if (!isLoading && url) {
      try {
        Linking.openURL(url);
      } catch (e) {
        log.error(e);
      } finally {
        onEnd();
      }
    }
  }, [isLoading, onEnd, url]);

  if (isLoading) {
    return <LoadingState fullscreen />;
  }

  if (!isLoading && !url) {
    return <ErrorDialog open onPress={onEnd} />;
  }

  return null;
}
