import { tokens } from '@src/theme/tokens';
import { ReactNode, useEffect } from 'react';
import Animated, {
  SharedValue,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';

type HeaderProps = {
  component: ReactNode;
  openContainer?: boolean;
  componentHeight?: number;
  duration?: number;
};

export const AnimatedHeader = ({
  component,
  openContainer = true,
  componentHeight = 73,
  duration = 500,
}: HeaderProps) => {
  const opacity = useSharedValue(1);
  const height = useSharedValue(componentHeight);

  const reanimatedStyle = useAnimatedStyle(() => {
    return {
      opacity: opacity.value,
      height: height.value,
    };
  }, []);

  const animateControl = (
    progress: SharedValue<number>,
    toValue: number,
    animatedDuration: number
  ) => {
    progress.value = withTiming(toValue, { duration: animatedDuration });
  };

  useEffect(() => {
    const openStep = () => {
      animateControl(height, componentHeight, duration);
      animateControl(opacity, 1, duration - duration * 5);
    };

    const closeStep = () => {
      animateControl(height, 0, duration);
      animateControl(opacity, 0, duration + duration * 5);
    };

    openContainer ? openStep() : closeStep();
  }, [componentHeight, duration, height, opacity, openContainer]);

  return (
    <Animated.View
      testID="animated-header"
      style={[
        { backgroundColor: tokens.color.WealthBlue.val },
        reanimatedStyle,
      ]}
    >
      {component}
    </Animated.View>
  );
};
