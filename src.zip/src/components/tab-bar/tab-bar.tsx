import { getTokenValue, styled, XStack, YStack } from '@aviva/ion-mobile';
import { useDashboardTheme } from '@src/features/dashboard/hooks/use-dashboard-theme';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { ReactNode } from 'react';
import Animated from 'react-native-reanimated';

const TAB_BAR_PADDING = isIpad ? 0 : getTokenValue('$xl', 'space');
const TAB_PILL_PADDING = getTokenValue('$xs', 'space');
const TAB_BAR_IPAD_MAX_WIDTH = getTokenValue('$19.5');

export const tabWidthCalculator = (screenWidth: number, count: number) => {
  return (
    ((isIpad ? Math.min(screenWidth, TAB_BAR_IPAD_MAX_WIDTH) : screenWidth) -
      TAB_BAR_PADDING * 2 -
      TAB_PILL_PADDING * 2) /
    count
  );
};

type PillTabBarProps = {
  animatedStyles: {
    width: number;
    transform: { translateX: number }[];
  };
  children: ReactNode;
};

export const PillTabBar = ({ animatedStyles, children }: PillTabBarProps) => {
  const { tabAnimatedStyle } = useDashboardTheme();

  return (
    <TabBarContainer
      accessibilityRole="tablist"
      paddingHorizontal={TAB_BAR_PADDING}
      paddingVertical={12}
      style={tabAnimatedStyle}
    >
      <TabBar padding={TAB_PILL_PADDING}>
        <TabIndicator animatedStyles={animatedStyles} />
        {children}
      </TabBar>
    </TabBarContainer>
  );
};

type TabIndicatorProps = {
  animatedStyles: {
    transform: { translateX: number }[];
    width: number;
  };
};
const TabIndicator = ({ animatedStyles }: TabIndicatorProps) => {
  return (
    <Animated.View
      testID={getTestId('active-tab-indicator')}
      style={[
        animatedStyles,
        {
          position: 'absolute',
          height: '100%',
          margin: getTokenValue('$xs', 'space'),
          backgroundColor: getTokenValue('$Primary500'),
          borderRadius: getTokenValue('$12', 'radius'),
        },
      ]}
    />
  );
};

export const TabBarContainer = Animated.createAnimatedComponent(YStack);

export const TabBar = styled(XStack, {
  flex: 1,
  backgroundColor: '$WhiteOpacity67',
  borderRadius: 32,
  tablet: isIpad,
});
