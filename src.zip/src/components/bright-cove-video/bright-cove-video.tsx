import { styled, XStack } from '@aviva/ion-mobile';
import {
  WebViewComponent,
  WebViewComponentProps,
} from '@src/components/web-view';
import * as ScreenOrientation from 'expo-screen-orientation';
import { Platform } from 'react-native';
import { WebViewMessageEvent } from 'react-native-webview';

const VideoContainer = styled(XStack, {
  marginTop: '$xl',
  aspectRatio: 1.5,
  width: '100%',
  borderTopLeftRadius: 5,
  borderTopRightRadius: 5,
});

type BrightCoveVideoProps = WebViewComponentProps;
type FullscreenMessage = {
  fullscreen: boolean;
};

const hookUpFullscreenEvent = `
document.addEventListener('fullscreenchange', (event) => {
  window.ReactNativeWebView.postMessage(JSON.stringify({ fullscreen: document.fullscreenElement !== null }));
});

true;
`;

const handleFullscreenMessage = async (event: WebViewMessageEvent) => {
  const data: FullscreenMessage = JSON.parse(event.nativeEvent.data);
  if (Platform.OS === 'ios') {
    return;
  }

  if (data.fullscreen) {
    await ScreenOrientation.lockAsync(
      ScreenOrientation.OrientationLock.LANDSCAPE
    );
  } else {
    await ScreenOrientation.unlockAsync();
  }
};

export const BrightCoveVideo = (props: BrightCoveVideoProps) => {
  return (
    <VideoContainer testID={`${props.testID}-container`}>
      <WebViewComponent
        {...props}
        javaScriptEnabled
        automaticallyAdjustContentInsets={false}
        injectedJavaScript={hookUpFullscreenEvent}
        scrollEnabled={false}
        allowsFullscreenVideo
        useProgressBar={false}
        onMessage={handleFullscreenMessage}
      />
    </VideoContainer>
  );
};
