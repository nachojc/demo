import { useAnalytics } from '@hooks/use-analytics';
import { ErrorDialog } from '@src/components/error-dialog';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import {
  NETWORK_ERROR,
  NETWORK_ERROR_CLOSE_TAPPED,
  NETWORK_ERROR_RETRY_TAPPED,
  TECHNICAL_ERROR,
  TECHNICAL_ERROR_CLOSE_TAPPED,
  TECHNICAL_ERROR_RETRY_TAPPED,
} from './analytics';

type ApiErrorDialogProps = {
  title?: string;
  copy?: string;
  isError: boolean;
  onRetry: () => void;
  onCancel?: () => void;
  error: string | null | string[];
  pageTag: string;
};

export const ApiErrorDialog = ({
  title,
  copy,
  isError,
  onRetry,
  onCancel,
  error,
  pageTag,
}: ApiErrorDialogProps) => {
  const [isVisible, setIsVisible] = useState(false);

  const { trackUserEvent, trackStateEvent } = useAnalytics();

  const { t } = useTranslation(undefined, {
    keyPrefix: 'common',
  });

  type RequestError = 'technicalError' | 'networkError';

  const networkErrorConditions = [
    'Network Error',
    'Request Timeout',
    'Request timed out',
  ];

  const requestError: RequestError = networkErrorConditions.some((condition) =>
    error?.toString().includes(condition)
  )
    ? 'networkError'
    : 'technicalError';

  const errorTitle =
    title ??
    (requestError === 'networkError'
      ? t('networkError.title')
      : t('technicalError.title'));

  const errorText =
    copy ??
    (requestError === 'networkError'
      ? t('networkError.copy')
      : t('technicalError.copy'));

  const errorPageTag =
    requestError === 'networkError'
      ? `${pageTag}${NETWORK_ERROR}`
      : `${pageTag}${TECHNICAL_ERROR}`;

  const closeTag =
    requestError === 'networkError'
      ? `${pageTag}${NETWORK_ERROR_CLOSE_TAPPED}`
      : `${pageTag}${TECHNICAL_ERROR_CLOSE_TAPPED}`;

  const retryTag =
    requestError === 'networkError'
      ? `${pageTag}${NETWORK_ERROR_RETRY_TAPPED}`
      : `${pageTag}${TECHNICAL_ERROR_RETRY_TAPPED}`;

  useEffect(() => {
    if (isError) {
      setIsVisible(true);
      trackStateEvent(errorPageTag);
    }
  }, [isError, errorPageTag, trackStateEvent]);

  const handleClose = useCallback(() => {
    trackUserEvent(closeTag);
    setIsVisible(false);
    onCancel?.();
  }, [trackUserEvent, closeTag, onCancel]);

  const handleRetry = useCallback(() => {
    trackUserEvent(retryTag);
    setIsVisible(false);
    onCancel?.();
    onRetry();
  }, [onRetry, trackUserEvent, retryTag, onCancel]);

  return (
    <ErrorDialog
      open={isVisible}
      title={errorTitle}
      copy={errorText}
      buttonText={t('apiErrorDialog.buttonText')}
      buttonLabel={t('apiErrorDialog.buttonText')}
      buttonHint=""
      onPress={handleRetry}
      cancelButton
      cancelButtonText={t('apiErrorDialog.cancelButtonText')}
      cancelButtonHint={t('apiErrorDialog.cancelButtonHint')}
      onPressCancel={handleClose}
      center
    />
  );
};
