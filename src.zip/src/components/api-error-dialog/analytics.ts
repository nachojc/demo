export const TECHNICAL_ERROR = `|technical-error-dialog`;
export const TECHNICAL_ERROR_RETRY_TAPPED = `${TECHNICAL_ERROR}|try-again-tapped`;
export const TECHNICAL_ERROR_CLOSE_TAPPED = `${TECHNICAL_ERROR}|dismiss-tapped`;
export const NETWORK_ERROR = `|network-error-dialog`;
export const NETWORK_ERROR_RETRY_TAPPED = `${NETWORK_ERROR}|try-again-tapped`;
export const NETWORK_ERROR_CLOSE_TAPPED = `${NETWORK_ERROR}|dismiss-tapped`;
