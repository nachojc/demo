import {
  getTokens,
  getVariableValue,
  Image,
  Separator,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { Pressable } from 'react-native';

type MessageItemProps = {
  hasRead: boolean;
  iconUrl?: string | null;
  header: string | null;
  body?: string | null;
  onPress: () => void;
  id: string;
};
export const MessageItem = ({
  hasRead,
  iconUrl,
  header,
  body,
  onPress,
  id,
}: MessageItemProps) => {
  const tokens = getTokens();
  return (
    <Pressable
      accessibilityRole="button"
      testID={getTestId(`${id}-message-item`)}
      onPress={onPress}
      style={{
        flexDirection: 'row',
        paddingTop: getVariableValue(tokens.space.$xl),
        backgroundColor: 'white',
      }}
    >
      <YStack
        paddingHorizontal={'$xl'}
        marginHorizontal={isIpad ? '$xl' : ''}
        width={isIpad ? '10%' : '20%'}
      >
        <Image
          accessibilityIgnoresInvertColors
          testID={getTestId('message-image')}
          style={{
            height: getVariableValue(getTokens().size['8']),
            width: getVariableValue(getTokens().size['8']),
          }}
          source={
            iconUrl
              ? {
                  uri: iconUrl,
                }
              : require('assets/closed-envelope/closed-envelope.png')
          }
        />
      </YStack>

      <YStack
        width={isIpad ? '90%' : '80%'}
        paddingRight={isIpad ? '$xxxxl' : '$xl'}
      >
        <Text
          tamaguiTextProps={{ paddingBottom: '$sm' }}
          fontVariant={
            hasRead ? 'body-regular-Secondary800' : 'body-semibold-Secondary800'
          }
        >
          {header}
        </Text>

        <Text
          tamaguiTextProps={{
            paddingBottom: '$xl',
            numberOfLines: 2,
            ellipsizeMode: 'tail',
          }}
          fontVariant={
            hasRead ? 'body-regular-Secondary800' : 'body-semibold-Secondary800'
          }
        >
          {body}
        </Text>

        <Separator borderColor="$Gray200" width={'110%'} />
      </YStack>
    </Pressable>
  );
};
