import { XStack, XStackProps } from '@aviva/ion-mobile';
import { ColumnMap, useColumnCount } from '@hooks/use-column-count';
import { distributedChunks } from '@src/utils';
import { ReactNode } from 'react';

export const formmatItems = <T,>(items: T[]) =>
  items.map((item, index) => ({
    ...item,
    originalIndex: index,
    originalLength: items.length,
  }));

export type FormattedItem<T> = T & {
  originalIndex: number;
  originalLength: number;
};

export const TabletMosaicStack = <T,>({
  items,
  renderItem,
  renderSection,
  columnMapOverride,
  stackProps: StackProps,
}: {
  items: T[];
  renderItem: (item: T, index: number, columnIndex: number) => ReactNode;
  renderSection: (children: React.ReactNode, index: number) => React.ReactNode;
  columnMapOverride?: Partial<ColumnMap>;
  stackProps?: XStackProps;
}) => {
  const columnCount = useColumnCount(columnMapOverride);
  const columns = distributedChunks(items, columnCount);
  return (
    <XStack gap="$xl" {...StackProps}>
      {columns.map((column, columnIndex) =>
        renderSection(
          column.map((item, internalColumnIndex) =>
            renderItem(item, internalColumnIndex, columnIndex)
          ),
          columnIndex
        )
      )}
    </XStack>
  );
};
