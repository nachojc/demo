import { Stack } from '@aviva/ion-mobile';

export const ItemSeparator = () => <Stack mx="$sm" />;
