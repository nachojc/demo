import { SetupServerApi } from '@api-mock/msw';
import { isDevMode, isMockBuild } from '@config';
import { Storage } from '@interfaces/storage';
import { observable } from '@legendapp/state';
import { persistObservable } from '@legendapp/state/persist';
import { useSelector } from '@legendapp/state/react';
import { useEffect, useRef } from 'react';

import { createServer } from './server';

const MSW_ENABLED_KEY = '@msw_enabled';

const getMswEnabledInitialValue = (): boolean => {
  if (isMockBuild()) {
    return true;
  }

  if (isDevMode()) {
    const value = Storage.getBoolean(MSW_ENABLED_KEY);

    if (typeof value === 'boolean') {
      return value;
    }
  }

  return false;
};

export const MockServiceWorkerEnabled = observable(getMswEnabledInitialValue());
persistObservable(MockServiceWorkerEnabled, { local: MSW_ENABLED_KEY });

export function useMockServiceWorkerEnabled() {
  return useSelector(MockServiceWorkerEnabled);
}

export const useMockServiceWorker = () => {
  const mswEnabled = useMockServiceWorkerEnabled();
  const server = useRef<SetupServerApi | null>(null);

  useEffect(() => {
    if (mswEnabled) {
      server.current = createServer();
      server.current?.listen({ onUnhandledRequest: 'bypass' });
    } else {
      server.current?.close();
    }
  }, [mswEnabled]);

  return { mswEnabled, server };
};
