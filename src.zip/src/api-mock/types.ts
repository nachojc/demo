import { DEFAULT_RESPONSES, mockResponseMaps } from './constants';

export type MockSettings = { status_code: number; delay?: number };

export type MockResponse = {
  content:
    | string
    | Blob
    | BufferSource
    | FormData
    | ReadableStream<any>
    | { [key: string]: unknown };
  pollCount?: number;
  pollContent?: { [key: string]: unknown };
};

export type AllMocks = typeof mockResponseMaps;
export type DefaultResponses = typeof DEFAULT_RESPONSES;

export type AllMocksKey = keyof AllMocks;
export type AllMocksValueKey<T extends AllMocksKey> = keyof AllMocks[T];
export type DefaultExtras = Record<AllMocksKey, MockSettings>;
export type EndpointsWithContent = {
  [key in AllMocksKey]: AllMocksValueKey<key> | MockResponse;
};
