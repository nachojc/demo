import { observable } from '@legendapp/state';
import {
  AllMocksKey,
  AllMocksValueKey,
  DefaultExtras,
  DefaultResponses,
  EndpointsWithContent,
  MockResponse,
  MockSettings,
} from '@src/api-mock/types';
import { Entries } from 'type-fest';

import { DEFAULT_RESPONSES } from './constants';

const defaultEntries = Object.entries(
  DEFAULT_RESPONSES
) as Entries<DefaultResponses>;

const DEFAULT_EXTRAS = defaultEntries.reduce(
  (acc, [endpoint]) => ({ ...acc, [endpoint]: { status_code: 200 } }),
  {} as DefaultExtras
);

// The observables that store the selected mocks and settings
const obsResponses = observable<EndpointsWithContent>(DEFAULT_RESPONSES);
const obsExtras = observable<DefaultExtras>(DEFAULT_EXTRAS);

/**
 * Gets the current content of the mock (name of mock or data)
 * @function
 * @param {string} endpoint - Name of the endpoint, ie 'Customer'
 */
export const getMock = (endpoint: AllMocksKey) => obsResponses[endpoint].get();

/**
 * Gets the current options of the mock, ie `status_code`, `delay`
 * @function
 * @param {string} endpoint - Name of the endpoint, ie 'Customer'
 */
export const getMockExtras = (endpoint: AllMocksKey) =>
  obsExtras[endpoint].get();

/**
 * Sets the mock
 *
 * See src/api-mock/__tests__/api-mock.test.ts for examples
 * @function
 * @param {AllMocksKey} endpoint - Name of the endpoint, ie 'Customer'
 * @param {string|AllMocksValueKey<T> | MockResponse | MockSettings} data - Either the name of the JSON mock, a custom object, or the settings (ie status_code/delay)
 * @param {MockSettings} [opts] - The settings object (ie status_code/delay)
 */
export const setMock = <T extends AllMocksKey>(
  endpoint: T,
  data: AllMocksValueKey<T> | MockResponse | MockSettings,
  opts?: MockSettings
) => {
  // Set the extras first
  if (typeof data === 'object' && 'status_code' in data) {
    obsExtras[endpoint].set({
      status_code: data.status_code,
      delay: data.delay,
    });
  }

  if (opts) {
    obsExtras[endpoint].set(opts);
  }

  // Set the main response
  if (typeof data === 'object' && 'content' in data) {
    // @ts-expect-error This has an error of too complex to represent
    obsResponses[endpoint].set({
      content: data.content,
      pollCount: data.pollCount,
      pollContent: data.pollContent,
    });
  } else if (typeof data === 'string') {
    obsResponses[endpoint].set(data); // One of the JSON mocks
  }
};

/**
 * Resets the mocks to defaults.
 *
 */
export const resetMocks = () => {
  defaultEntries.forEach(([endpoint, defaultResponse]) => {
    obsResponses[endpoint].set(defaultResponse);
    obsExtras[endpoint].set({ status_code: 200 });
  });
};
