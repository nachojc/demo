// This module enables requests interception in React Native
// using the same request handlers as in tests.
import { setupServer } from '@api-mock/msw';

import { handlers } from './handlers';

export const createServer = () => {
  return setupServer(...handlers);
};
