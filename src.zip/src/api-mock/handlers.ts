import {
  DefaultBodyType,
  MockedRequest,
  rest,
  RestHandler,
} from '@api-mock/msw';
import { IllustrationStatusPollHelper } from '@api-mock/responses/DirectWealth/IllustrationStatus/illustration-status-poll-helper';
import { omit } from '@src/utils/object';
import { MessagesSchema } from '@src/validation/schemas/messages';

import { mockResponseMaps } from './constants';
import { getMock, getMockExtras, setMock } from './helpers';
import {
  GroupAccountsResponseMap as GroupAccountsResponse,
  PlatformAccountsResponseMap,
  PoliciesResponseMap,
} from './responses';
import { DirectWealthResponseMap } from './responses/DirectWealth';
import { dynamicPerformanceOverTime } from './responses/Pension/PerformanceOverTime/v2/dynamic-performanceOverTime';
import { AllMocks } from './types';

// Taken from https://github.com/mswjs/msw/blob/main/src/core/delay.ts
const getRealisticResponseTime = () => {
  const MIN_SERVER_RESPONSE_TIME = 100;
  const MAX_SERVER_RESPONSE_TIME = 400;

  return Math.floor(
    Math.random() * (MAX_SERVER_RESPONSE_TIME - MIN_SERVER_RESPONSE_TIME) +
      MIN_SERVER_RESPONSE_TIME
  );
};

const getMockResponse = async (endpoint: keyof AllMocks) => {
  const mockExtras = getMockExtras(endpoint);
  const mock = getMock(endpoint) as unknown as {
    content: unknown;
    pollContent?: unknown;
    pollCount?: number;
  };

  const availableJSONmocks = mockResponseMaps[endpoint];

  const data =
    typeof mock === 'string'
      ? availableJSONmocks[mock as keyof typeof availableJSONmocks]
      : mock;

  const defaultDelay =
    process.env.NODE_ENV !== 'test' ? getRealisticResponseTime() : 0;

  return {
    content:
      typeof data.content === 'string'
        ? data.content
        : JSON.stringify(data.content),
    status: mockExtras.status_code ?? 200,
    delay: mockExtras.delay ?? defaultDelay,
    poll: data?.pollContent
      ? {
          count: data.pollCount ?? 0,
          content: JSON.stringify(data.pollContent),
        }
      : null,
  };
};

export const simpleRes: (
  endpoint: keyof AllMocks
) => Parameters<typeof rest.get>[1] = (endpoint) => async (_req, res, ctx) => {
  const { content, status, delay } = await getMockResponse(endpoint);
  //this is just matches how the real api behaves in this status
  if (status === 204) {
    return res(ctx.body('{}'), ctx.status(status), ctx.delay(delay));
  }
  return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
};

/**
 * @description MSW handlers to provide mock responses for various endpoints. To add responses for a new endpoint,
 * add a directory to `api-mock/responses` with mock JSON files. Inside index.ts, export a map of readable labels to JSON files.
 * Add this to `mockResponseMaps` inside mock-response-settings.tsx. Finally, add a new handler here to return the mock response
 * for the endpoint. See `OAuthLogin` for an example.
 */
export const handlers: RestHandler<MockedRequest<DefaultBodyType>>[] = [
  rest.post(
    '*/MessagingApi/api/v1/account/requestAccountDeletion',
    simpleRes('AccountDeletion')
  ),
  rest.post('*/oauthaccess/token', simpleRes('OAuthLogin')),
  rest.get('*MessagingApi/api/v1/address/*', simpleRes('PostcodeLookup')),
  rest.put(
    '*MessagingApi/api/v1/customer/profileChange/changeAddress',
    simpleRes('ProfileChangeAddressResponse')
  ),
  rest.get('*/MessagingApi/api/v2/customer', simpleRes('Customer')),
  rest.put(
    '*/MessagingApi/api/v2/profile/communicationPreferences',
    simpleRes('PaperlessPreferencesUpdate')
  ),
  rest.get(
    '*/MessagingApi/api/*/profile/communicationPreferences',
    simpleRes('PaperlessPreferences')
  ),
  rest.post(`*/MessagingApi/api/v1/recordLogin`, simpleRes('RecordLogin')),
  rest.get(
    '*/MessagingApi/api/v2/customers/*/idverification',
    simpleRes('Idv')
  ),
  rest.post(
    '*/MessagingApi/api/v2/customers/*/idverification',
    simpleRes('IdvPost')
  ),
  rest.put(
    '*/Messaging/public/api/v1/account/forgotpassword',
    simpleRes('ForgottenPassword')
  ),
  rest.post(
    '*/Messaging/public/api/v1/account/forgotusername',
    simpleRes('ForgottenUsername')
  ),
  rest.put(
    '*/avivasecurityaccountservice/v1/account/password',
    simpleRes('UpdatePassword')
  ),
  rest.get('*/MessagingApi/api/v2/policies/*', async (req, res, ctx) => {
    const securePolicyNumber = req.params[1]?.toString();

    const selectedCustomerMock = getMock('Customer');
    const isDynamicCustomerMock = `${selectedCustomerMock}`.startsWith('_');

    if (isDynamicCustomerMock) {
      const validPolicies = omit(PoliciesResponseMap, 'Policy out of hours');

      const matchingMock = Object.entries(validPolicies).find(
        ([_mockName, data]) =>
          data.content.policy.SecurePolicyNumber === securePolicyNumber
      );

      if (matchingMock?.length && matchingMock[0] in PoliciesResponseMap) {
        setMock(
          'Policies',
          matchingMock[0] as keyof typeof PoliciesResponseMap
        );
      }
    }

    const { content, status, delay } = await getMockResponse('Policies');
    return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
  }),
  rest.get(
    '*/MessagingApi/api/v1/pensions/*/beneficiaries',
    simpleRes('Beneficiaries')
  ),
  rest.post(
    '*/MessagingApi/api/v1/pensions/*/beneficiaries',
    simpleRes('BeneficiariesPost')
  ),
  rest.get(
    '*/MessagingApi/api/v1/pensions/*/beneficiaries/formValues',
    simpleRes('BeneficiariesFormValues')
  ),
  rest.get(
    '*/MessagingApi/api/v*/funds/*/investmentAssetDetails/*',
    simpleRes('FundFactsAndPerformance')
  ),
  rest.get(
    '*/MessagingApi/api/v1/pensions/*/performanceOverTime',
    simpleRes('PerformanceOverTime')
  ),
  rest.get(
    '*/MessagingApi/api/v2/pensions/*/performanceOverTime',
    async (req, res, ctx) => {
      const mockName = getMock('PerformanceOverTimeV2');
      if (mockName === 'Performance Over Time - Dynamic') {
        const startDate = req.url.searchParams.get('startDate');
        const endDate = req.url.searchParams.get('endDate');

        try {
          const { content } = await getMockResponse('Policies');
          const data = dynamicPerformanceOverTime(
            startDate,
            endDate,
            JSON.parse(content).policy.FundValue
          );

          const { status, delay } = await getMockResponse(
            'PerformanceOverTimeV2'
          );

          return await res(
            ctx.json(data),
            ctx.status(status),
            ctx.delay(delay)
          );
        } catch (err) {
          console.log(err);
        }
      }
      const { content, status, delay } = await getMockResponse(
        'PerformanceOverTimeV2'
      );
      return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
    }
  ),
  rest.get(
    '*/MessagingApi/api/v1/pensions/*/projection',
    simpleRes('Projection')
  ),
  rest.get('*/avivasecurityauthservice/v1/mfa', simpleRes('MFAPreference')),
  rest.post(
    '*/avivasecurityauthservice/v1/mfa',
    simpleRes('GenerateMfaFactor')
  ),
  rest.put('*/avivasecurityauthservice/v1/mfa', simpleRes('VerifyMfaFactor')),
  rest.post(
    '*/avivasecurityauthservice/v1/mfa/trust',
    simpleRes('AddTrustedDevice')
  ),
  rest.patch(
    '*/avivasecurityaccountservice/v1/account',
    simpleRes('UpdateMFAPreference')
  ),
  rest.get(
    '*/Messaging/public/api/v1/fasttrack/validate/*',
    simpleRes('FastTrack')
  ),
  rest.get(
    '*/MessagingApi/api/v2/support/phoneNumbers/*',
    simpleRes('SupportInfo')
  ),
  rest.post(
    '*/MessagingApi/api/v1/pensions/*/ChangeRetirementDate',
    simpleRes('ChangeRetirementDate')
  ),
  rest.get(
    '*/MessagingApi/api/v1/pensions/*/ChangeRetirementDate/Caveats',
    simpleRes('Caveats')
  ),
  rest.get(
    '*/MessagingApi/api/v1/customer/profileChange/eligibility',
    simpleRes('ProfileChangeEligibility')
  ),
  rest.get('*/MessagingApi/api/v1/documents/*', simpleRes('Documents')),
  rest.get(
    '*/Messaging/public/api/v2/register/validateEmail/*',
    simpleRes('ValidateEmail')
  ),
  rest.post(
    '*/Messaging/public/api/v2/register/createGuest',
    simpleRes('RegisterGuestUser')
  ),
  rest.post(
    '*/MessagingApi/api/v2/register/validateCustomer',
    simpleRes('ValidateCustomer')
  ),
  rest.post(
    '*/MessagingApi/api/v2/register/validatePolicy',
    simpleRes('ValidatePolicy')
  ),
  rest.post(
    '*/Messaging/public/api/v1/fasttrack/register',
    simpleRes('FastTrackRegister')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/account/*',
    async (req, res, ctx) => {
      const accountNumber = req.params[1]?.toString();

      const JSONresponse = DirectWealthResponseMap[accountNumber];
      const { content, status, delay } = await getMockResponse(
        'DirectWealthAccount'
      );

      if (JSONresponse && 'content' in JSONresponse) {
        const {
          content: contentJson,
          status_code: statusJson,
          delay: delayJson,
        } = JSONresponse as {
          content: any;
          status_code: number;
          delay: number;
        };

        return res(
          ctx.body(contentJson),
          ctx.status(statusJson || status),
          ctx.delay(delayJson || delay)
        );
      }
      return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
    }
  ),

  rest.get(
    /\/MessagingApi\/api\/v1\/directWealth\/subAccount\/[A-z0-9-~]*$/,
    simpleRes('DirectWealthSubaccount')
  ),
  rest.get('*/MessagingApi/api/v3/messages', async (_req, res, ctx) => {
    const { content, status, delay } = await getMockResponse('Messages');
    if (getMock('Messages') === 'Error refetch') {
      return res.once(ctx.body(content), ctx.status(200), ctx.delay(delay));
    }
    return res.once(ctx.body(content), ctx.status(status), ctx.delay(delay));
  }),
  rest.get('*/MessagingApi/api/v3/messages', async (_req, res, ctx) => {
    const { content, status, delay } = await getMockResponse('Messages');
    if (getMock('Messages') === 'Messages Success refetch') {
      const newContent = MessagesSchema.parse(JSON.parse(content)) ?? {
        messages: [],
      };
      const message = {
        ...newContent?.messages[newContent.messages.length - 1],
        id: newContent?.messages[newContent.messages.length - 1].id + '1',
        header:
          newContent?.messages[newContent.messages.length - 1].header +
          'new title',
      };
      const messages = [...newContent.messages, message];
      return res(
        ctx.body(JSON.stringify({ messages })),
        ctx.status(status),
        ctx.delay(delay)
      );
    }
    return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
  }),
  rest.get(
    '*/MessagingApi/api/v1/content/en-GB/myaviva-new-business/offers/v1',
    simpleRes('Offers')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/subAccount/*/investmentProductPerformance',
    simpleRes('InvestmentProductPerformance')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/subAccount/*/isaAllowance',
    simpleRes('DirectWealthSubaccountISAAllowance')
  ),
  rest.get('*/MessagingApi/api/v2/pensions/*/funds', simpleRes('PensionFunds')),
  rest.get(
    '*/Messaging/public/api/v1/content/en-GB/myaviva-single-payment/payment_descriptions/v1',
    simpleRes('PaymentDescriptions')
  ),
  rest.get(
    '*/MessagingApi/api/v1/pensions/*/monetarytransactiontotals*',
    simpleRes('MonetaryTransactionTotals')
  ),
  rest.post(
    '*/api/v1/directWealth/isa/bankAccountDetails',
    simpleRes('IsaApplyBankAccountDetailsSubmission')
  ),
  rest.post(
    '*/api/v1/directWealth/isa/submit',
    simpleRes('IsaApplySubmitApplication')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/subAccount/*/paymentHistory',
    simpleRes('PaymentHistory')
  ),
  rest.get(
    '*/MessagingApi/api/v1/content/en-GB/direct-wealth/editorial_content/v1/*',
    simpleRes('EditorialContent')
  ),
  rest.get(
    '*/MessagingApi/api/v1/content/en-GB/direct-wealth/isa_faqs/v1',
    simpleRes('OpenAnIsaFAQs')
  ),
  rest.get(
    '*/MessagingApi/api/v1/content/en-GB/direct-wealth/faqs/v1/*',
    simpleRes('FAQs')
  ),
  rest.post('*/avivasecurityauthservice/v1/revoke', simpleRes('RevokeToken')),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/subAccount/*/investmentTransactionHistory',
    async (_req, res, ctx) => {
      const pageParam = _req.url.searchParams.get('Page');
      const filterParam = _req.url.searchParams.get('Filter');

      let mockResponse: keyof AllMocks;

      if (filterParam === 'Purchase|Sale' || filterParam === 'Sale|Purchase') {
        mockResponse = 'ProductTransactionHistoryWithAllFilters';
      } else if (filterParam === 'Purchase') {
        mockResponse = 'ProductTransactionHistoryWithPurchaseFilter';
      } else if (filterParam === 'Sale') {
        mockResponse = 'ProductTransactionHistoryWithSaleFilter';
      } else if (pageParam === '1') {
        mockResponse = 'ProductTransactionHistory';
      } else {
        mockResponse = 'ProductTransactionHistoryPage2';
      }

      const { content, status, delay } = await getMockResponse(mockResponse);
      if (status === 666) {
        res.networkError('No Network');
        return;
      }
      return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
    }
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/subAccount/*/cashTransactionHistory',
    async (_req, res, ctx) => {
      const pageParam = _req.url.searchParams.get('Page');
      const { content, status, delay } = await getMockResponse(
        pageParam === '1'
          ? 'CashTransactionHistory'
          : 'CashTransactionHistoryPage2'
      );
      if (status === 666) {
        res.networkError('No Network');
        return;
      }

      return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
    }
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/*/strongerNudge',
    simpleRes('StrongerNudge')
  ),
  rest.put(
    '*/MessagingApi/api/v1/directWealth/*/strongerNudge',
    simpleRes('StrongerNudgeUpdate')
  ),
  rest.get(
    '*/api/v1/directWealth/personalInformation',
    simpleRes('PersonalDetails')
  ),
  rest.get(
    '*/api/v1/directWealth/isa/formValues',
    simpleRes('IsaApplyFormValues')
  ),
  rest.post(
    '*/api/v1/directWealth/isa/validateBankAccountDetails',
    simpleRes('IsaApplyBankAccountValidation')
  ),
  rest.post('*/api/v1/directWealth/isa/review', simpleRes('IsaApplyReview')),
  rest.get(
    '*/api/v1/directWealth/sippTransferIn/formValues',
    simpleRes('SIPPTransferDropDownValues')
  ),
  rest.get(
    '*/api/v1/directWealth/isaDocument/search',
    async (_req, res, ctx) => {
      const { content, status, delay, poll } = await getMockResponse(
        'IllustrationStatus'
      );

      if (!poll) {
        return res(
          ctx.json(JSON.parse(content)),
          ctx.status(status),
          ctx.delay(delay)
        );
      }
      const helper = IllustrationStatusPollHelper.instance;
      if (helper.pollCount === poll.count) {
        return res(
          ctx.json(JSON.parse(content)),
          ctx.status(status),
          ctx.delay(delay)
        );
      } else {
        helper.incrementPollCount();
        return res(
          ctx.json(JSON.parse(poll.content)),
          ctx.status(status),
          ctx.delay(delay)
        );
      }
    }
  ),
  rest.get(
    '*/api/v1/directWealth/isaDocument/*',
    simpleRes('ChargesDocumentId')
  ),
  rest.get('*/v3/support/phoneNumbers', async (_req, res, ctx) => {
    const helpDeskNameParam = _req.url.searchParams.get('HelpDeskName');

    let mockResponse: keyof AllMocks = 'SupportPhoneNumbersRetirementSolutions';

    switch (helpDeskNameParam) {
      case 'UKL.RetirementSolutions':
        mockResponse = 'SupportPhoneNumbersRetirementSolutions';
        break;
      case 'External.PensionWise.BookAppointment':
        mockResponse = 'SupportPhoneNumbersPensionWise';
        break;
      case 'Direct.Wealth.Support.Contact':
        mockResponse = 'SupportPhoneNumbersDirectWealth';
        break;
      default:
        mockResponse = 'SupportPhoneNumbersRetirementSolutions';
    }

    const { content, status, delay } = await getMockResponse(mockResponse);
    return res(
      ctx.json(JSON.parse(content)),
      ctx.status(status),
      ctx.delay(delay)
    );
  }),
  rest.post(
    '*/api/v1/directWealth/SippTransferIn',
    simpleRes('SippTransferInSubmission')
  ),

  rest.get(
    '*/MessagingApi/api/v1/directWealth/sippTransferIn/readyMadeFunds',
    simpleRes('SippTransferFunds')
  ),
  rest.post(
    '*/MessagingApi/api/v1/directWealth/sippTransferIn/universalRetirementFund',
    simpleRes('SippUniversalFund')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/illustration/*/status',
    async (_req, res, ctx) => {
      const { content, status, delay, poll } = await getMockResponse(
        'IllustrationStatus'
      );

      if (!poll) {
        return res(
          ctx.json(JSON.parse(content)),
          ctx.status(status),
          ctx.delay(delay)
        );
      }
      const helper = IllustrationStatusPollHelper.instance;
      if (helper.pollCount === poll.count) {
        return res(
          ctx.json(JSON.parse(content)),
          ctx.status(status),
          ctx.delay(delay)
        );
      } else {
        helper.incrementPollCount();
        return res(
          ctx.json(JSON.parse(poll.content)),
          ctx.status(status),
          ctx.delay(delay)
        );
      }
    }
  ),
  rest.post(
    '*/MessagingApi/api/v1/directWealth/navigator/factFindQuestionnaire',
    simpleRes('SubmitNavigatorQuestionnaire')
  ),
  rest.put(
    '*/MessagingApi/api/v1/directWealth/navigator/factFindQuestionnaire',
    simpleRes('AdjustNavigatorContributions')
  ),
  rest.post(
    '*/MessagingApi/api/v1/directWealth/navigator/financialAdvicePayment',
    simpleRes('FinancialAdvicePayment')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/navigator',
    simpleRes('NavigatorServiceGet')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/navigator/suitabilityReport/*',
    simpleRes('NavigatorSuitabilityReport')
  ),
  rest.post(
    '*/MessagingApi/api/v1/directWealth/navigator/account',
    async (_req, res, ctx) => {
      const { content, status, delay } = await getMockResponse(
        'NavigatorServicePost'
      );
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      //@ts-ignore
      const isRunByJest = process.env.JEST_WORKER_ID !== undefined;
      const adjustedDelay = isRunByJest ? 0 : delay;
      return res(
        ctx.body(content),
        ctx.status(status),
        ctx.delay(adjustedDelay)
      );
    }
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/sippTransferIn/fundPerformance/*',
    simpleRes('SIPPTransferFundPerformance')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/*/transfer',
    simpleRes('ConfirmSIPPTransfer')
  ),
  rest.post(
    '*/MessagingApi/api/v1/mydrive/activate',
    simpleRes('MyDriveActivation')
  ),
  rest.post(
    '*/MessagingApi/api/v1/mydrive/deactivate',
    async (_req, res, ctx) => {
      const { content, status, delay } = await getMockResponse(
        'MyDriveDeactivation'
      );
      // do not use artificial delay in unit tests
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      //@ts-ignore
      const isRunByJest = process.env.JEST_WORKER_ID !== undefined;
      const adjustedDelay = isRunByJest ? 0 : delay;

      return res(
        ctx.body(content),
        ctx.status(status),
        ctx.delay(adjustedDelay)
      );
    }
  ),
  rest.get(
    '*/Messaging/public/api/v1/content/en-GB/mydrive/mydrive_insights/v1',
    simpleRes('MyDriveInsightsContent')
  ),
  rest.post(
    '*/MessagingApi/api/v1/mydrive/session/create',
    async (_req, res, ctx) => {
      const { content, status, delay } = await getMockResponse(
        'MyDriveTokenSigning'
      );
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      //@ts-ignore
      const isRunByJest = process.env.JEST_WORKER_ID !== undefined;
      const adjustedDelay = isRunByJest ? 0 : delay;
      return res(
        ctx.body(content),
        ctx.status(status),
        ctx.delay(adjustedDelay)
      );
    }
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/pensionConsolidationDetails/*',
    simpleRes('PensionConsolidationDetails')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/pensionConsolidationSummary',
    simpleRes('PensionConsolidationSummary')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/findAndCombine/details',
    simpleRes('FindAndCombineCustomerDetails')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/findAndCombine/pensionProviders',
    simpleRes('FindAndCombinePensionProviders')
  ),
  rest.post(
    '*/MessagingApi/api/v1/directWealth/findAndCombine/application',
    simpleRes('FindAndCombineApplicationInSubmission')
  ),
  rest.get(
    '*/MessagingApi/api/v1/platformaccounts/*',
    async (req, res, ctx) => {
      const securePolicyNumber = req.params[1]?.toString();

      const matchingMock = Object.entries(PlatformAccountsResponseMap).find(
        ([_mockName, data]) =>
          data.content.secureAccountNumber === securePolicyNumber
      );

      if (
        matchingMock?.length &&
        matchingMock[0] in PlatformAccountsResponseMap
      ) {
        setMock(
          'PlatformAccounts',
          matchingMock[0] as keyof typeof PlatformAccountsResponseMap
        );
      }

      const { content, status, delay } = await getMockResponse(
        'PlatformAccounts'
      );
      return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
    }
  ),
  rest.post(
    '*/MessagingApi/api/v1/pensions/*/SinglePayment',
    simpleRes('SinglePayment')
  ),
  rest.post(
    '*/MessagingApi/api/v1/pensions/*/nativeSinglePayment',
    simpleRes('SinglePaymentNative')
  ),
  rest.post(
    '*/MessagingApi/api/v1/payment/methods',
    simpleRes('SinglePaymentMethods')
  ),
  rest.get(
    '*/MessagingApi/api/v1/pensions/*/singlePayments/validationRules',
    simpleRes('SinglePaymentValidationRules')
  ),
  rest.post(
    '*/MessagingApi/api/v1/pensions/*/SinglePayments/validateBankAccountDetails',
    simpleRes('SinglePaymentBankValidation')
  ),
  rest.get(
    '*/MessagingApi/api/v3/recommendations/*',
    simpleRes('Recommendations')
  ),
  rest.get(
    '*/Messaging/public/api/v1/content/en-GB/myaviva-prospect/offers/*',
    simpleRes('ProspectOffers')
  ),
  rest.get('*/MessagingApi/api/v1/groupaccounts/*', async (req, res, ctx) => {
    const accountNumber = req.params[1]?.toString();

    const JSONresponse = GroupAccountsResponse[accountNumber];
    const { content, status, delay } = await getMockResponse('GroupAccounts');

    if (JSONresponse && 'content' in JSONresponse) {
      const {
        content: contentJson,
        status_code: statusJson,
        delay: delayJson,
      } = JSONresponse as {
        content: any;
        status_code: number;
        delay: number;
      };

      return res(
        ctx.body(contentJson),
        ctx.status(statusJson || status),
        ctx.delay(delayJson || delay)
      );
    }

    return res(ctx.body(content), ctx.status(status), ctx.delay(delay));
  }),
  rest.get(
    '*/MessagingApi/api/v1/reports/*/pensionssnapshot/v1',
    simpleRes('PensionsSnapshot')
  ),
  rest.get(
    '*/MessagingApi/api/v1/policies/wealth/visualisation*',
    simpleRes('WealthVisualisation')
  ),
  rest.get(
    '*/MessagingApi/api/v1/directWealth/eligibility',
    simpleRes('WealthHubEligibility')
  ),
  rest.get('*/MessagingApi/api/v1/quotes', simpleRes('Quotes')),
  rest.post('*/MessagingApi/api/v1/exchange/*/*', simpleRes('DataExchange')),
];
