import { resources } from '@src/i18n/i18n';
import { ParseKeys, TOptions } from 'i18next';

export type I18nKeys<
  T,
  ns extends keyof (typeof resources)['en'] = 'ma'
> = ParseKeys<ns, TOptions, T>;
