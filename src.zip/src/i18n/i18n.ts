import 'intl-pluralrules';

import translationDW from '@src/locales/en/direct-wealth/dw.json';
import findAndCombine from '@src/locales/en/direct-wealth/find-and-combine.json';
import isaApply from '@src/locales/en/direct-wealth/isa-apply.json';
import navigator from '@src/locales/en/direct-wealth/navigator.json';
import sippTransfer from '@src/locales/en/direct-wealth/sipp-transfer.json';
import ma from '@src/locales/en/translation.json';
import i18next from 'i18next';
import { initReactI18next } from 'react-i18next';

export const defaultNS = 'ma';
export const resources = {
  en: {
    ma,
    dw: {
      ...translationDW,
      sippTransfer,
      findAndCombine,
      isaApply,
      navigator,
    },
  },
} as const;

i18next.use(initReactI18next).init({
  lng: 'en',
  defaultNS,
  ns: ['ma', 'dw'],
  resources,
  interpolation: { escapeValue: false },
});

export const i18n = i18next;
