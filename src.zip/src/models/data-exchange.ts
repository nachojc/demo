import { getLogger } from '@interfaces/logger';
import { axios } from '@utils/api';

import {
  DataExchangeResponse,
  DataExchangeResponseSchema,
} from '../validation/schemas/data-exchange';

export class DataExchangeModel {
  log = getLogger(DataExchangeModel.name);

  async dataExchangeWithPayload(
    schemaName: string,
    schemaVersion: string,
    payload: unknown
  ): Promise<DataExchangeResponse> {
    const endpoint = '/MessagingApi/api/v1/exchange/{0}/{1}'
      .replace('{0}', schemaName)
      .replace('{1}', schemaVersion);

    const { data } = await axios.post(endpoint, payload);

    if (data?.ExchangeId) {
      const exchangeId = data.ExchangeId.replaceAll('-', '');
      data.ExchangeId = exchangeId;
    }

    const result = DataExchangeResponseSchema.safeParse(data);
    if (!result.success) {
      this.log.zodError(result.error);
      throw result.error;
    }

    return result.data;
  }

  async dataExchangeWithPartyId(
    partyId: string,
    sourceCode: string,
    schemaName: string,
    schemaVersion: string
  ) {
    return this.dataExchangeWithPayload(schemaName, schemaVersion, {
      customer: {
        id: partyId,
      },
      sourceCode,
    });
  }

  async dataExchangeUri(
    uri: string, // uri with placeholder marker "{0}" to be replaced with the ExchangeId
    schemaName: string | null | undefined,
    schemaVersion: string | null | undefined,
    payload: unknown
  ) {
    if (!schemaName || !schemaVersion) {
      return null;
    }

    let exchangeId: string | null = null;
    try {
      const result = await this.dataExchangeWithPayload(
        schemaName.toLowerCase(),
        schemaVersion,
        payload
      );
      exchangeId = result.ExchangeId;
    } catch (e) {}

    return uri.replace('{0}', exchangeId ?? '');
  }
}
