import { CreateUserPayload } from '@hooks/use-create-guest';
import { base64Converter } from '@src/utils';
import {
  FastTrackResponseSchema,
  GenericResponseSchema,
  VerifyEmailSchema,
  VerifyPolicySchema,
} from '@src/validation/schemas/registration';
import { axios } from '@utils/api';

type VerifyFastTrackCodeSuccessResponse = {
  Status: 'Valid' | 'Expired' | 'Locked' | 'Used' | 'Invalid';
};

type VerifyFastTrackCodeResponse = VerifyFastTrackCodeSuccessResponse;

export type ValidateCustomerRequest = {
  FirstName: string;
  LastName: string;
  DateOfBirth: string;
  Postcode: string;
};

type ValidatePolicyNumberRequest = ValidateCustomerRequest & {
  PolicyNumber: string;
  EmailMarketingOptIn: boolean;
};

export const FASTTRACK_CODE_VALIDATION_PATH =
  '/Messaging/public/api/v1/fasttrack/validate/';

export const CREATE_GUEST_USER_PATH =
  '/Messaging/public/api/v2/register/createGuest';

export const VALIDATE_CUSTOMER_PATH =
  '/MessagingApi/api/v2/register/validateCustomer';

export const VALIDATE_EMAIL_PATH =
  '/Messaging/public/api/v2/register/validateEmail/';

export const VALIDATE_POLICY_PATH =
  '/MessagingApi/api/v2/register/validatePolicy';

export class RegistrationModel {
  async verifyFastTrackCode(fastTrackCode: string) {
    const { data } = await axios.get<VerifyFastTrackCodeResponse>(
      `${FASTTRACK_CODE_VALIDATION_PATH}${fastTrackCode}`
    );
    const parsedData = FastTrackResponseSchema.parse(data);
    if (parsedData.Status !== 'Valid') {
      throw parsedData.Status;
    }

    return parsedData;
  }

  async createGuest(customerDetails: CreateUserPayload) {
    const { data } = await axios.post(CREATE_GUEST_USER_PATH, customerDetails);

    return GenericResponseSchema.parse(data);
  }

  async validateCustomer(customerDetails: ValidateCustomerRequest) {
    const { data } = await axios.post(VALIDATE_CUSTOMER_PATH, customerDetails);

    return GenericResponseSchema.parse(data);
  }

  async verifyEmail(email: string) {
    const { data } = await axios.get<VerifyFastTrackCodeResponse>(
      `${VALIDATE_EMAIL_PATH}${base64Converter(email)}`
    );
    return VerifyEmailSchema.parse(data);
  }

  async verifyPolicy(payload: ValidatePolicyNumberRequest) {
    const { data } = await axios.post(VALIDATE_POLICY_PATH, payload);

    return VerifyPolicySchema.parse(data);
  }
}
