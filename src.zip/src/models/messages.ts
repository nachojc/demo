import { getLogger } from '@interfaces/logger';
import { axios } from '@src/utils/api';

import {
  Message,
  Messages,
  MessagesSchema,
} from '../validation/schemas/messages';

export const MESSAGES_PATH = '/MessagingApi/api/v3/messages';

export class MessagesModel {
  log = getLogger(MessagesModel.name);

  async getMessages(): Promise<Messages> {
    const { data } = await axios.get(MESSAGES_PATH);
    if (data?.messages) {
      data.messages = data?.messages.filter(
        (message: Message) => message.header !== null
      );
    }
    const result = MessagesSchema.safeParse(data);
    if (!result.success) {
      this.log.zodError(result.error);
      throw result.error;
    }

    return result.data;
  }
}
