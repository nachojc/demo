import { axios } from '@src/utils/api';
import { Device, DeviceList } from '@src/validation/schemas/device';
import { z } from 'zod';

export class DeviceManagementModel {
  async getDeviceManagement(): Promise<DeviceList> {
    const { data } = await axios.get('/riskevent/v1/device');
    return DeviceList.parse(data);
  }

  async removeDeviceManagement(trustedDeviceId: string): Promise<Device> {
    const { data } = await axios.delete(
      `/avivasecurityaccountservice/v1/account/trustedDevice/${trustedDeviceId}`
    );

    return Device.parse(data);
  }

  private static revokeTokenSchema = z.object({
    device_identifier: z.string(),
    token_type_hint: z.literal('refresh_token'),
    token: z.string().min(1),
  });

  async revokeToken(
    _body: z.infer<typeof DeviceManagementModel.revokeTokenSchema>
  ): Promise<unknown> {
    const body = DeviceManagementModel.revokeTokenSchema.parse(_body);
    const { data } = await axios.post(
      `/avivasecurityauthservice/v1/revoke`,
      body
    );

    return data;
  }
}
