import { UserRecommendationsMap } from '@src/api-mock/responses';
import { RecommendationsModel } from '@src/models/recommendations';
import { axios } from '@utils/api';

const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn().mockResolvedValue({ data: {}, status: 204 }),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('RecommendationsModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('fetchRecommendations sends correct request', async () => {
    mockedAxios.get.mockResolvedValue({
      data: UserRecommendationsMap['User recommendations'].content,
    });

    await RecommendationsModel.fetchRecommendations();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v3/recommendations/?CreativeCount=25'
    );
  });

  it('should throw an error when fetch fails', async () => {
    mockedAxios.get.mockResolvedValue({
      data: {
        Status: 500,
      },
    });

    await expect(RecommendationsModel.fetchRecommendations()).rejects.toThrow(
      'Recommendations schema parse error'
    );
  });
});
