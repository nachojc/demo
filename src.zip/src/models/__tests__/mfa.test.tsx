import { axios } from '@src/utils/api';
import { AxiosError, AxiosHeaders } from 'axios';
import { ZodError } from 'zod';

import { MfaModel, ServerUnderMaintenanceError } from '../mfa';

const mfaModel = new MfaModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  const module = jest.requireActual('axios');
  return {
    ...module,
    create: jest.fn(() => ({
      post: jest.fn(),
      get: jest.fn(),
      put: jest.fn(),
      patch: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

const validFactor = 'f-f-f-factor';
const validEnrolledFactor = 'SMS';
const validPhoneNumber = '85CALL-MEEE';
const deviceName = 'cheekyiPhone';
const deviceId = 'CD00BC3E-3894-4672-9F1A-290980D45F6A'; //should be a GUID
const trustToken = "tokin'";

type BodyEntry = {
  key: string;
  value: string | number | boolean;
};

const getMfaPreferenceResponseBody: BodyEntry[] = [
  { key: 'factorcontactdetail', value: validFactor },
  { key: 'enrolledFactor', value: validEnrolledFactor },
];

const generateMfaResponseBody: BodyEntry[] = [
  { key: 'generateOtpLifetimeinSeconds', value: 50 },
  { key: 'generateOtpQuietWindowRemaining', value: 50 },
  { key: 'factorgenerated', value: 'factorgenerated' },
  { key: 'factorcontactdetail', value: validFactor },
];

const verifyCodeResponseBody: BodyEntry[] = [
  { key: 'code_verified', value: true },
  { key: 'access_token', value: 'somevalidtoken' },
];

const verifyCodeInvalidResponseBody: BodyEntry[] = [
  { key: 'code_verified', value: false },
  { key: 'failure_reason', value: 'Bad device, no!' },
];

const trustedDeviceResponseBody: BodyEntry[] = [
  { key: 'trustToken', value: trustToken },
];

describe('MfaModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  describe('getMfaPreference', () => {
    it('sends correct request', async () => {
      setUpResponse(getMfaPreferenceResponseBody, 'get');

      await mfaModel.getMfaPreference();

      expect(mockedAxios.get).toHaveBeenNthCalledWith(
        1,
        '/avivasecurityauthservice/v1/mfa'
      );
    });

    it('returns correct response', async () => {
      setUpResponse(getMfaPreferenceResponseBody, 'get');

      const response = await mfaModel.getMfaPreference();

      expect(response.enrolledFactor).toEqual(validEnrolledFactor);
      expect(response.factorcontactdetail).toEqual(validFactor);
    });

    it('throws with bad response', async () => {
      setUpInvalidResponse();

      await expect(async () => {
        await mfaModel.getMfaPreference();
      }).rejects.toBeInstanceOf(ZodError);
    });

    it('throws ServerUnderMaintenance with 503 response', async () => {
      setUpMfaErrorResponse();

      await expect(async () => {
        await mfaModel.getMfaPreference();
      }).rejects.toBeInstanceOf(ServerUnderMaintenanceError);
    });
  });

  describe('generateMfaCode', () => {
    it('sends correct request', async () => {
      setUpResponse(generateMfaResponseBody, 'post');

      const body = {
        securityPhoneNumber: validPhoneNumber,
      };

      await mfaModel.generateMfaCode({ securityPhoneNumber: validPhoneNumber });

      expect(mockedAxios.post).toHaveBeenNthCalledWith(
        1,
        '/avivasecurityauthservice/v1/mfa',
        body
      );
    });

    it('returns correct response', async () => {
      setUpResponse(generateMfaResponseBody, 'post');

      const result = await mfaModel.generateMfaCode({
        securityPhoneNumber: validPhoneNumber,
      });

      expect(result.factorcontactdetail).toEqual(validFactor);
    });

    it('throws with bad response', async () => {
      setUpInvalidResponse();

      await expect(async () => {
        await mfaModel.generateMfaCode({
          securityPhoneNumber: validPhoneNumber,
        });
      }).rejects.toBeInstanceOf(ZodError);
    });
  });

  describe('verifyCode', () => {
    it('sends correct request', async () => {
      setUpResponse(verifyCodeResponseBody, 'put');

      const body = {
        factor: validFactor,
        trustDevice: true,
        scopes: ['mfa_enrol'],
      };

      await mfaModel.verifyCode({ factor: validFactor, trustDevice: true }, [
        'mfa_enrol',
      ]);

      expect(mockedAxios.put).toHaveBeenNthCalledWith(
        1,
        '/avivasecurityauthservice/v1/mfa',
        body
      );
    });

    it('returns correct response', async () => {
      setUpResponse(verifyCodeResponseBody, 'put');

      const result = await mfaModel.verifyCode(
        { factor: validFactor, trustDevice: true },
        ['mfa_enrol']
      );

      expect(result.code_verified).toEqual(true);
    });

    it('throws with bad response', async () => {
      setUpInvalidResponse();

      await expect(async () => {
        await mfaModel.verifyCode({ factor: validFactor, trustDevice: true }, [
          'mfa_enrol',
        ]);
      }).rejects.toBeInstanceOf(ZodError);
    });

    it('throws with non code valid', async () => {
      setUpResponse(verifyCodeInvalidResponseBody, 'put');

      await expect(async () => {
        await mfaModel.verifyCode({ factor: validFactor, trustDevice: true }, [
          'mfa_enrol',
        ]);
      }).rejects.toStrictEqual(new AxiosError('Bad device, no!'));
    });
  });

  describe('addTrustedDevice', () => {
    it('sends correct request', async () => {
      setUpResponse(trustedDeviceResponseBody, 'post');

      const body = {
        deviceName,
        trustedDeviceId: deviceId,
      };

      await mfaModel.addTrustedDevice({
        deviceName,
        trustedDeviceId: deviceId,
      });

      expect(mockedAxios.post).toHaveBeenNthCalledWith(
        1,
        '/avivasecurityauthservice/v1/mfa/trust',
        body
      );
    });

    it('returns correct response', async () => {
      setUpResponse(trustedDeviceResponseBody, 'post');

      const result = await mfaModel.addTrustedDevice({
        deviceName,
        trustedDeviceId: deviceId,
      });

      expect(result.trustToken).toEqual(trustToken);
    });

    it('throws with bad response', async () => {
      setUpInvalidResponse();

      await expect(async () => {
        await mfaModel.addTrustedDevice({
          deviceName,
          trustedDeviceId: deviceId,
        });
      }).rejects.toBeInstanceOf(ZodError);
    });

    it('updateMfaPreference sends correct request', async () => {
      const body = {
        mfaPreference: 'SMS',
        securityPhoneNumber: '0800001066',
      } as const;
      const accessToken = 'somevalidtoken';

      await mfaModel.updateMfaPreference(body, accessToken);

      expect(mockedAxios.patch).toHaveBeenNthCalledWith(
        1,
        '/avivasecurityaccountservice/v1/account',
        body,
        { headers: { Authorization: 'Bearer somevalidtoken' } }
      );
    });
  });

  const setUpResponse = (
    body: BodyEntry[],
    method: 'post' | 'get' | 'put' | 'patch'
  ) => {
    const bod = body.reduce(
      (previous, value) => ({ ...previous, [value.key]: value.value }),
      {}
    );

    switch (method) {
      case 'post':
        mockedAxios.post.mockImplementation(() =>
          Promise.resolve({
            data: bod,
          })
        );
        break;
      case 'get':
        mockedAxios.get.mockImplementation(() =>
          Promise.resolve({
            data: bod,
          })
        );
        break;
      case 'put':
        mockedAxios.put.mockImplementation(() =>
          Promise.resolve({
            data: bod,
          })
        );
        break;
      case 'patch':
        mockedAxios.patch.mockImplementation(() =>
          Promise.resolve({
            data: bod,
          })
        );
        break;
    }
  };

  const setUpMfaErrorResponse = () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.reject(
        new AxiosError(
          'Expired',
          'ERR_NETWORK',
          { headers: new AxiosHeaders(undefined) },
          '',
          {
            data: { errorCode: 503 },
            status: 503,
            statusText: '',
            headers: {},
            config: { headers: new AxiosHeaders(undefined) },
          }
        )
      )
    );
  };

  const setUpInvalidResponse = () => {
    mockedAxios.get.mockImplementation(() =>
      Promise.resolve({
        data: {
          invalidKey: validFactor,
        },
      })
    );
    mockedAxios.post.mockImplementation(() =>
      Promise.resolve({
        data: {
          invalidKey: validFactor,
        },
      })
    );
    mockedAxios.put.mockImplementation(() =>
      Promise.resolve({
        data: {
          invalidKey: validFactor,
        },
      })
    );
  };
});
