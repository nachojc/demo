import { CustomerIdvMap, CustomerIdvPostMap } from '@src/api-mock/responses';
import { axios } from '@utils/api';

import { IdvModel } from '../idv';

const mockedAxios = axios as jest.Mocked<typeof axios>;
jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

const securePartyId = 'SECURE-PARTY-ID';

describe('IdvModel', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('idvGetCustomerAllowed sends correct request', async () => {
    mockedAxios.get.mockResolvedValue({
      data: CustomerIdvMap['Customer IDV'].content,
    });

    await new IdvModel().idvGetCustomerAllowed(securePartyId);

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v2/customers/SECURE-PARTY-ID/idverification'
    );
  });

  it('idvCustomer sends correct request', async () => {
    mockedAxios.post.mockResolvedValue({
      data: CustomerIdvPostMap['Customer IDV Post'].content,
    });

    const expectedBody = {
      tokenid: 'TOKENID',
      platform: 'PLATFORM',
      policyNumber: 'POLICY-NUMBER',
    };

    await new IdvModel().idvCustomer(securePartyId, expectedBody);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v2/customers/SECURE-PARTY-ID/idverification',
      {
        ...expectedBody,
      }
    );
  });

  it('idvCompleteVerification sends correct request', async () => {
    mockedAxios.put.mockResolvedValue({
      data: CustomerIdvPostMap['Customer IDV Post'].content,
    });

    const expectedBody = {
      tokenid: 'TOKEN-ID',
      platform: 'PLATFORM',
      policyNumber: 'POLICY-NUMBER',
      applicantId: 'APPLICANT-ID',
      imageUploadStatus: 'IMAGE-UPLOAD-STATUS',
    };

    await new IdvModel().idvCompleteVerification(securePartyId, expectedBody);

    expect(mockedAxios.put).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v2/customers/SECURE-PARTY-ID/idverification',
      {
        ...expectedBody,
      }
    );
  });
});
