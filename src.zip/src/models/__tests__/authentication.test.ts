import { config } from '@config';
import { refreshToken, removeStoredTrustToken } from '@interfaces/secure-store';
import { getAccessDefinition } from '@src/utils/api/access-definition';
import { isZodError } from '@src/utils/is-zod-error';
import { accessToken, axios } from '@utils/api';
import { AxiosError } from 'axios';

import {
  AuthenticationErrorMessages,
  AuthenticationModel,
  mapAuthenticationAxiosError,
} from '../authentication';

type RegistrationError = {
  responseErrorMessage: AuthenticationErrorMessages;
  message: string;
};

const CREDENTIALS_ERRORS: RegistrationError[] = [
  {
    responseErrorMessage: 'AV_OAUTH_ERR_00010_UNKNOWN_USER',
    message:
      'Your username and password combination is incorrect, please try again.',
  },
  {
    responseErrorMessage: 'AV_OAUTH_ERR_00012_INVALID_CLIENTCREDS',
    message:
      'Your username and password combination is incorrect, please try again.',
  },
  {
    responseErrorMessage: 'AV_OAUTH_ERR_00035_ERROR_ACCOUNT_LOGIN_FAILURE',
    message:
      'Your username and password combination is incorrect, please try again.',
  },
  {
    responseErrorMessage: 'AV_OAUTH_ERR_00025_ERROR_ACCOUNT_IN_CHANGE_PWD',
    message: 'Please reset in order to continue using the MyAviva app.',
  },
  {
    responseErrorMessage:
      'AV_OAUTH_ERR_00032_ERROR_ACCOUNT_IN_JIT_PENDING_TEMPORARY_PASSWORD',
    message: 'Please reset in order to continue using the MyAviva app.',
  },
  {
    responseErrorMessage:
      'AV_OAUTH_ERR_00036_ERROR_ACCOUNT_IN_TEMP_PWD_EXPIRED',
    message: 'Please reset in order to continue using the MyAviva app.',
  },
];

const ACCOUNT_ERRORS: RegistrationError[] = [
  ...CREDENTIALS_ERRORS,
  {
    responseErrorMessage: 'Request timed out',
    message:
      'You need to be connected to the internet to continue. Please check your connection and try again.',
  },
  {
    responseErrorMessage: 'canceled',
    message:
      'You need to be connected to the internet to continue. Please check your connection and try again.',
  },
  {
    responseErrorMessage: 'Network Error',
    message:
      'You need to be connected to the internet to continue. Please check your connection and try again.',
  },
];

const authModel = new AuthenticationModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  const module = jest.requireActual('axios');
  return {
    ...module,
    create: jest.fn(() => ({
      ...module.create(),
      post: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

const setUpResponse = () => {
  mockedAxios.post.mockImplementation(() =>
    Promise.resolve({
      data: {
        refresh_token: validRefreshToken,
        access_token: validAccessToken,
        id_token: validTrustToken,
      },
    })
  );
};

const setUpMfaErrorResponse = () => {
  mockedAxios.post.mockImplementation(() =>
    Promise.resolve({
      data: {
        errorMessage: 'somemessag',
        errorCode: 'notmfa',
      },
    })
  );
};

const setUpInvalidResponse = () => {
  mockedAxios.post.mockImplementation(() =>
    Promise.resolve({
      data: {
        cheesy: 'brie',
        beefy: 'viel',
      },
    })
  );
};

const validUsername = 'beefy@beeferson.com';
const validPassword = 'imavalidpassword';
const validRefreshToken = 'refreshboy';
const validTrustToken = 'trustboy';
const validAccessToken = 'accessboy';
const validMfaCode = 'anmfacode';

describe('AuthenticationModel', () => {
  afterEach(() => {
    jest.resetModules();
    jest.clearAllMocks();
    accessToken.set(null);
    refreshToken.set(null);
    removeStoredTrustToken();
  });

  it.each(ACCOUNT_ERRORS)(
    'returns the correct error message for $responseErrorMessage',
    ({ responseErrorMessage, message }) => {
      expect(mapAuthenticationAxiosError(responseErrorMessage).message).toEqual(
        message
      );
    }
  );

  it.each(CREDENTIALS_ERRORS)(
    'should set property shouldReportOpened to true for credential error: $responseErrorMessage',
    ({ responseErrorMessage }) => {
      expect(
        mapAuthenticationAxiosError(responseErrorMessage).shouldReportOpened
      ).toEqual(true);
    }
  );

  it('authenticate sends correct request', async () => {
    const expectedBody = {
      username: validUsername,
      password: validPassword,
      grant_type: 'password',
      avivaAccDef: getAccessDefinition(),
      client_id: config.OAUTH_CLIENT_ID.get(),
      device_id: 'GiWDQhjYsuUBcljLrRsZmlLekBz3DKcBIqKOA5suqIg=',
      trust_token: undefined,
      scope: config.OAUTH_SCOPES.get(),
    };

    setUpResponse();

    await authModel.authenticate({
      username: validUsername,
      password: validPassword,
    });

    expect(mockedAxios.post).toHaveBeenNthCalledWith(1, '/oauthaccess/token', {
      ...expectedBody,
    });
  });

  it('authenticate fails with error code throws', async () => {
    setUpMfaErrorResponse();

    await expect(async () => {
      await authModel.authenticate({
        username: validUsername,
        password: validPassword,
      });
    }).rejects.toThrow(new AxiosError('notmfa'));
  });

  it('authenticateWithRefreshToken sends correct request', async () => {
    const expectedBody = {
      grant_type: 'refresh_token',
      refresh_token: validRefreshToken,
      client_id: config.OAUTH_CLIENT_ID.get(),
      device_id: '0d158b17-f666-4655-bbbd-d4d298ba9d9b',
      risk_id: 'E811AE7B-0DE1-4286-92F9-BCE74A2C994D',
      trust_token: undefined,
    };

    setUpResponse();

    await authModel.authenticateWithRefreshToken(validRefreshToken);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(1, '/oauthaccess/token', {
      ...expectedBody,
    });
  });

  it('authenticateWithMfaCode sends correct request', async () => {
    const expectedBody = {
      mfaCode: validMfaCode,
      username: validUsername,
      grant_type: 'mfa_password',
      client_id: config.OAUTH_CLIENT_ID.get(),
      avivaAccDef: getAccessDefinition(),
      device_id: 'GiWDQhjYsuUBcljLrRsZmlLekBz3DKcBIqKOA5suqIg=',
    };

    setUpResponse();

    await authModel.authenticateWithMfaCode({
      mfaCode: validMfaCode,
      username: validUsername,
    });

    expect(mockedAxios.post).toHaveBeenNthCalledWith(1, '/oauthaccess/token', {
      ...expectedBody,
    });
  });

  it('getSSOToken sends correct request', async () => {
    const expectedBody = {
      accessdef: getAccessDefinition(),
    };

    setUpResponse();

    await new AuthenticationModel().getSSOToken();

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/avivasecurityauthservice/v2/device/oauthssotoken',
      {
        ...expectedBody,
      }
    );
  });

  it('getSSOToken returns correct data', async () => {
    setUpResponse();

    const response = await new AuthenticationModel().getSSOToken();

    expect(response).toEqual({
      access_token: 'accessboy',
      id_token: 'trustboy',
      refresh_token: 'refreshboy',
    });
  });

  it('recordLogin sends correct request', async () => {
    const expectedBody = {
      appName: 'co.uk.aviva.myaviva',
    };

    setUpResponse();

    await authModel.recordLogin();

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/recordLogin',
      {
        ...expectedBody,
      }
    );
  });

  it('authenticate with success stores access token', async () => {
    setUpResponse();

    await authModel.authenticate({
      username: validUsername,
      password: validPassword,
    });

    expect(accessToken.get()).toEqual(validAccessToken);
  });

  it('authenticate with success stores refresh token', async () => {
    setUpResponse();

    await authModel.authenticate({
      username: validUsername,
      password: validPassword,
    });

    expect(refreshToken.get()).toEqual(validRefreshToken);
  });

  it('authenticate with failure throws ZodError', async () => {
    setUpInvalidResponse();

    const e = await (async () => {
      jest.resetModules();
      try {
        await authModel.authenticate({
          username: validUsername,
          password: validPassword,
        });

        return null;
      } catch (err) {
        return err;
      }
    })();

    expect(isZodError(e)).toEqual(true);
  });
});
