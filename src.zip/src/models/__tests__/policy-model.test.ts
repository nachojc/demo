import { PoliciesResponseMap } from '@src/api-mock/responses';
import { axios } from '@src/utils/api';
import { BaseProduct } from '@src/validation/schemas/product/schemas/base-product';
import { ZodError } from 'zod';

import { PolicyModel } from '../policy/policy-model';

const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

const minimumParseableProduct = {
  __tag: 'Unknown',
  PolicyNumber: '',
  SecurePolicyNumber: '',
  ProductType: 'AccidentalDeath',
  DisplayName: '',
  IsLoaded: false,
} satisfies BaseProduct;

describe('PolicyMode.fetchPolicy()', () => {
  const securePolicyNumber = '';

  describe('success', () => {
    it('should send correct request', async () => {
      const {
        content: { policy },
      } = PoliciesResponseMap['Pension policy payment less than year'];

      mockedAxios.get.mockImplementation(() =>
        Promise.resolve({ data: { policy } })
      );

      const model = new PolicyModel();
      await model.fetchPolicy('POLICY-NUMBER');

      expect(mockedAxios.get).toHaveBeenCalledWith(
        '/MessagingApi/api/v2/policies/POLICY-NUMBER'
      );
    });

    it('parses valid responses appropriately', async () => {
      const {
        content: { policy },
      } = PoliciesResponseMap['Pension policy payment less than year'];

      mockedAxios.get.mockImplementation(() =>
        Promise.resolve({ data: { policy } })
      );
      const model = new PolicyModel();
      const result = await model.fetchPolicy(securePolicyNumber);
      expect(result).toStrictEqual({ __tag: 'PensionProduct', ...policy });
    });

    it('Maps AO Motor differently Product handlers', async () => {
      const {
        content: { policy },
      } = PoliciesResponseMap['Aviva canary online autorenew motor policy'];
      mockedAxios.get.mockImplementation(() =>
        Promise.resolve({ data: { policy } })
      );

      const model = new PolicyModel();
      const result = await model.fetchPolicy(securePolicyNumber);
      expect(result).toStrictEqual({
        __tag: 'AvivaOnlineMotorProduct',
        ...policy,
      });
    });
  });

  describe('throws', () => {
    /**
     * This correctly parses out unknown product types to unknown
     * @see {@link ../ } to see tests that confirm MinDataProduct mapper is used
     */
    it('logs a warning and throws an error if unsuppored productHandler productType returned', async () => {
      mockedAxios.get.mockImplementation(() =>
        Promise.resolve({
          data: {
            policy: {
              ...minimumParseableProduct,
              ProductType:
                'A product type that will never match and should be minimum data card',
            },
          },
        })
      );
      const model = new PolicyModel();
      const result = await model.fetchPolicy(securePolicyNumber);
      expect(result).toStrictEqual({
        DisplayName: '',
        IsLoaded: false,
        PolicyNumber: '',
        ProductType:
          'A product type that will never match and should be minimum data card',
        SecurePolicyNumber: '',
        __tag: 'Unknown',
      });
    });

    it('throws zod error if parsing fails', async () => {
      mockedAxios.get.mockImplementation(() =>
        Promise.resolve({ data: { policy: { gobbledegook: 'was here' } } })
      );
      const model = new PolicyModel();
      await expect(async () =>
        model.fetchPolicy(securePolicyNumber)
      ).rejects.toBeInstanceOf(ZodError);
    });
  });
});
