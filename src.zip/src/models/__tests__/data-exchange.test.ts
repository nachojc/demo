import { axios } from '@utils/api';

import { DataExchangeModel } from '../data-exchange';

const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      post: jest.fn().mockResolvedValue(
        Promise.resolve({
          data: {
            ExchangeId: 'result-exchange-id',
          },
        })
      ),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('DataExchangeModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('dataExchangeWithPayload correctly sends request and parses result', async () => {
    const result = await new DataExchangeModel().dataExchangeWithPayload(
      'schemaName',
      'schemaVersion',
      {
        mock: 'payload',
      }
    );

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/exchange/schemaName/schemaVersion',
      {
        mock: 'payload',
      }
    );

    expect(result).toEqual({
      ExchangeId: 'resultexchangeid',
    });
  });

  it('dataExchangeWithPartyId correctly sends request and parses result', async () => {
    const expectedBody = {
      customer: {
        id: 'partyId',
      },
      sourceCode: 'sourceCode',
    };

    const result = await new DataExchangeModel().dataExchangeWithPartyId(
      'partyId',
      'sourceCode',
      'schemaName',
      'schemaVersion'
    );

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/exchange/schemaName/schemaVersion',
      {
        ...expectedBody,
      }
    );

    expect(result).toEqual({
      ExchangeId: 'resultexchangeid',
    });
  });

  it('dataExchangeUri returns correct uri', async () => {
    const result = await new DataExchangeModel().dataExchangeUri(
      'https://example.com/path/{0}',
      'schemaName',
      'schemaVersion',
      {
        mock: 'payload',
      }
    );

    expect(result).toEqual('https://example.com/path/resultexchangeid');
  });
});
