import { FastTrackRegisterResponseMap } from '@src/api-mock/responses';
import { FastTrackSignUpForm } from '@src/validation/schemas/fast-track-signup-form';
import { axios } from '@utils/api';

import { FastTrackRegistrationModel } from '../fast-track-signup';

const mockedAxios = axios as jest.Mocked<typeof axios>;
jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

const activationCode = 'ACTIVATION-CODE';

describe('FastTrackRegistrationModel', () => {
  it('signup sends correct request', async () => {
    mockedAxios.post.mockResolvedValue({
      data: FastTrackRegisterResponseMap['Fast Track Register Valid'].content,
    });

    const formData: FastTrackSignUpForm = {
      emailInputs: {
        email: 'email@email.com',
        confirmEmail: 'email@email.com',
      },
      dob: '24/11/1992',
      password: 'pa55word',
      offers: 'Yes',
    };

    const expectedBody = {
      EmailAddress: formData.emailInputs.email,
      Password: formData.password,
      DateOfBirth: '1992-11-24',
      EmailMarketingOptOut: true,
      Code: activationCode,
    };

    await new FastTrackRegistrationModel().signup(formData, activationCode);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v1/fasttrack/register',
      {
        ...expectedBody,
      }
    );
  });
});
