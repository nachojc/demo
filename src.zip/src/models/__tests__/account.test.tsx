import { getAccessDefinition } from '@src/utils/api/access-definition';
import { axios } from '@utils/api';

import { AccountModel, mapAccountAxiosError } from '../account';

type AccountErrors = {
  responseCode: number;
  message: string;
}[];

const ACCOUNT_ERRORS: AccountErrors = [
  {
    responseCode: 400,
    message: `Please try again or call our support team on 0800 148 8665 if you need help.`,
  },
  {
    responseCode: 401,
    message:
      'Please submit another request in the app or get in touch with our support team on 0800 148 8665 if you need help.',
  },
  {
    responseCode: 406,
    message:
      'Please choose a different password or contact us on 0800 148 8665.',
  },
  {
    responseCode: 429,
    message: `We've sent you an email with instructions. Please check all folders in your email account. If it does not arrive within a few minutes, you can request another.`,
  },
];

const accountModel = new AccountModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      put: jest.fn().mockResolvedValue({}),
      post: jest.fn().mockResolvedValue({
        UsernameStatus: 'thing',
        UserName: 'username',
        Instance: 'instance?',
        Status: 'status',
        Type: 'type',
        CorrelationId: 'correlation',
      }),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('AccountModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it.each(ACCOUNT_ERRORS)(
    'returns the correct error message for $responseCode',
    ({ responseCode, message }) => {
      expect(mapAccountAxiosError(responseCode).message).toEqual(message);
    }
  );

  it('sendChangePassword sends correct request', async () => {
    const expectedBody = {
      accessDefinition: getAccessDefinition(),
      activationToken: 'token',
      newPassword: 'password',
    };

    await accountModel.sendChangePassword({
      newPassword: 'password',
      ActivationCode: 'token',
    });

    expect(mockedAxios.put).toHaveBeenNthCalledWith(
      1,
      '/avivasecurityaccountservice/v1/account/password',
      expectedBody
    );
  });

  it('sendResetPasswordEmail sends correct request', async () => {
    const expectedBody = {
      username: 'ausername',
      dateOfBirth: 'adateofbirth',
      appName: 'co.uk.aviva.myaviva',
    };

    await accountModel.sendForgottenPassword({
      username: 'ausername',
      dateOfBirth: 'adateofbirth',
    });

    expect(mockedAxios.put).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v1/account/forgotpassword',
      expectedBody
    );
  });

  it('recoverUsername sends correct request', async () => {
    mockedAxios.post.mockImplementation(() =>
      Promise.resolve({
        data: {
          UsernameStatus: 'thing',
          UserName: 'username',
          Instance: 'instance?',
          Status: 200,
          Type: 'type',
          CorrelationId: 'correlation',
        },
      })
    );

    const expectedBody = {
      firstName: 'afirstname',
      lastName: 'alastname',
      dateOfBirth: 'apostcode',
      postcode: 'adateofbirth',
      appName: 'co.uk.aviva.myaviva',
    };

    await accountModel.sendRecoverUsername({
      firstName: 'afirstname',
      lastName: 'alastname',
      dateOfBirth: 'apostcode',
      postcode: 'adateofbirth',
    });

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v1/account/forgotusername',
      {
        ...expectedBody,
      }
    );
  });
});
