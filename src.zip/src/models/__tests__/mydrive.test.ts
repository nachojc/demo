import {
  MyDriveActivationResponseMap,
  MyDriveDeactivationResponseMap,
  MyDriveInsightsContentResponseMap,
  MyDriveTokenContentResponseMap,
} from '@src/api-mock/responses';
import { SignTokenRequest } from '@src/validation/schemas/mydrive';
import { axios } from '@utils/api';

import { MyDriveModel } from '../mydrive';

const mockedAxios = axios as jest.Mocked<typeof axios>;
jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      post: jest.fn(),
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('MyDriveModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('activateMyDrive uses correct endpoint', async () => {
    mockedAxios.post.mockResolvedValue({
      data: MyDriveActivationResponseMap['MyDrive Activation AF003'].content,
    });

    await new MyDriveModel().activateMyDrive();

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/mydrive/activate'
    );
  });

  it('deactivateMyDrive uses correct endpoint', async () => {
    mockedAxios.post.mockResolvedValue({
      data: MyDriveDeactivationResponseMap['MyDrive Deactivation Success']
        .content,
    });

    await new MyDriveModel().deactivateMyDrive();

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/mydrive/deactivate'
    );
  });

  it('getInsightsContent uses correct endpoint', async () => {
    mockedAxios.get.mockResolvedValue({
      data: MyDriveInsightsContentResponseMap[
        'MyDrive Insights Content Success'
      ].content,
    });

    await new MyDriveModel().getInsightsContent();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v1/content/en-GB/mydrive/mydrive_insights/v1'
    );
  });

  it('signMyDriveToken uses correct endpoint', async () => {
    mockedAxios.post.mockResolvedValue({
      data: MyDriveTokenContentResponseMap['MyDrive Token Signing Success']
        .content,
    });

    const tokenRequest: SignTokenRequest = {
      unsignedJwt: 'UNSIGNED-JWT',
    };

    await new MyDriveModel().signMyDriveToken(tokenRequest);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/mydrive/session/create',
      tokenRequest
    );
  });
});
