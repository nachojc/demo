import { renderHook, waitFor } from '@src/jest/testing-library';
import { ISO_8601_DATE_FORMAT } from '@constants/string-formats';
import { usePensionPerformanceOvertime } from '@hooks/use-pension-performance-overtime';
import { setMock } from '@src/api-mock/helpers';
import { format, subMonths } from 'date-fns';

describe('usePensionPerformanceOvertime', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return data', async () => {
    setMock('PerformanceOverTimeV2', 'Performance Over Time 1 year');

    const { result } = renderHook(() =>
      usePensionPerformanceOvertime(
        'securePolicyNumber',
        format(subMonths(new Date(), 6), ISO_8601_DATE_FORMAT),
        format(new Date(), ISO_8601_DATE_FORMAT)
      )
    );

    await waitFor(() => {
      expect(result.current.isSuccess).toBe(true);
    });
    expect(result.current.data).toBeDefined();
  });

  it('should stay idle (enabled=false), used with `ViewPensionToday`', async () => {
    const { result } = renderHook(() =>
      usePensionPerformanceOvertime(
        'securePolicyNumber',
        format(subMonths(new Date(), 2), ISO_8601_DATE_FORMAT),
        format(new Date(), ISO_8601_DATE_FORMAT),
        {
          enabled: false,
        }
      )
    );

    await waitFor(() => {
      expect(result.current.fetchStatus).toBe('idle');
    });
  });

  it('should handle behaviour of status 204 / undefined', async () => {
    setMock(
      'PerformanceOverTimeV2',
      {
        content: undefined!,
      },
      { status_code: 204 }
    );

    const { result } = renderHook(() =>
      usePensionPerformanceOvertime(
        'securePolicyNumber',
        format(subMonths(new Date(), 2), ISO_8601_DATE_FORMAT),
        format(new Date(), ISO_8601_DATE_FORMAT)
      )
    );

    await waitFor(() => {
      expect(result.current.isSuccess).toBe(true);
    });

    expect(result.current.data?.ValuationPoints).toBeDefined();
    expect(result.current.data?.ValuationPoints?.length).toEqual(0);
  });
});
