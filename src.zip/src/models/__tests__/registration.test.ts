import { CreateUserPayload } from '@hooks/use-create-guest';
import {
  FastTrackResponseMap,
  RegisterGuestUserResponseMap,
  ValidateCustomerResponseMap,
  ValidateEmailResponseMap,
  ValidatePolicyResponseMap,
} from '@src/api-mock/responses';
import { axios } from '@utils/api';

import { RegistrationModel, ValidateCustomerRequest } from '../registration';

const mockedAxios = axios as jest.Mocked<typeof axios>;
jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      post: jest.fn(),
      put: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('RegistrationModel', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('verifyFastTrackCode sends correct request', async () => {
    mockedAxios.get.mockResolvedValue({
      data: FastTrackResponseMap['Fast Track Valid'].content,
    });

    const fastTrackCode = 'FAST-TRACK-CODE';

    await new RegistrationModel().verifyFastTrackCode(fastTrackCode);

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v1/fasttrack/validate/FAST-TRACK-CODE'
    );
  });

  it('createGuest sends correct request', async () => {
    mockedAxios.post.mockResolvedValue({
      data: RegisterGuestUserResponseMap.Valid.content,
    });

    const customerDetails: CreateUserPayload = {
      firstName: 'FIRST',
      lastName: 'LAST',
      emailAddress: 'email@email.com',
      password: 'pa55word',
    };

    await new RegistrationModel().createGuest(customerDetails);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v2/register/createGuest',
      {
        ...customerDetails,
      }
    );
  });

  it('validateCustomer sends correct request', async () => {
    mockedAxios.post.mockResolvedValue({
      data: ValidateCustomerResponseMap.Valid.content,
    });

    const customerDetails: ValidateCustomerRequest = {
      FirstName: 'FIRST',
      LastName: 'LAST',
      DateOfBirth: '1992-11-24',
      Postcode: 'NR17 2BL',
    };

    await new RegistrationModel().validateCustomer(customerDetails);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v2/register/validateCustomer',
      {
        ...customerDetails,
      }
    );
  });

  it('verifyEmail sends correct request', async () => {
    mockedAxios.get.mockResolvedValue({
      data: ValidateEmailResponseMap['Valid Email'].content,
    });

    const email = 'email@email.com';

    await new RegistrationModel().verifyEmail(email);

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v2/register/validateEmail/ZW1haWxAZW1haWwuY29t'
    );
  });

  it('verifyPolicy sends correct request', async () => {
    mockedAxios.post.mockResolvedValue({
      data: ValidatePolicyResponseMap.Valid.content,
    });

    const policyDetails = {
      FirstName: 'FIRST',
      LastName: 'LAST',
      DateOfBirth: '1992-11-24',
      Postcode: 'NR17 2BL',
      PolicyNumber: '0818118181',
      EmailMarketingOptIn: true,
    };

    await new RegistrationModel().verifyPolicy(policyDetails);

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v2/register/validatePolicy',
      {
        ...policyDetails,
      }
    );
  });
});
