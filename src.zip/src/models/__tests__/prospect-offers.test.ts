import { axios } from '@utils/api';

import { ProspectOffersModel } from '../prospect-offers';

const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn().mockResolvedValue({ data: {}, status: 204 }),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

const mockProspectOffers = {
  Content: {
    offers: [
      {
        imageUrl:
          'https://cdn.aviva.com/shared/images/myaviva-app/classic-motor-insurance-v1.jpg',
        headline: 'Motor',
        summary: 'Cover that keeps your car on the road.',
        ctaUrl:
          'https://www.direct.aviva.co.uk/quote/direct/motor?source=CAPC%26cmp=welcome-view-motor-quote',
        ctaText: 'Get a quote',
        ctaActionTag: 'ukmyaviva|welcome|motor-tapped',
      },
      {
        imageUrl:
          'https://cdn.aviva.com/shared/images/myaviva-app/classic-home-insurance-v1.jpg',
        headline: 'Home',
        summary: 'Protect your home and belongings.',
        ctaUrl:
          'https://www.direct.aviva.co.uk/quote/direct/home?source=CAPH%26cmp=welcome-view-home-quote',
        ctaText: 'Get a quote',
        ctaActionTag: 'ukmyaviva|welcome|home-tapped',
      },
      {
        imageUrl:
          'https://cdn.aviva.com/shared/images/myaviva-app/multi-vehicle-v1.jpg',
        headline: 'MultiCar',
        summary: 'Save 10% when you insure more than one vehicle.',
        ctaUrl:
          'https://www.direct.aviva.co.uk/quote/direct/motor?source=CAPC%26cmp=welcome-view-multi-vehicle-quote',
        ctaText: 'Get a quote',
        ctaActionTag: 'ukmyaviva|welcome|multi-vehicle-tapped',
      },
      {
        imageUrl:
          'https://cdn.aviva.com/shared/images/myaviva-app/travel-insurance-v1.jpg',
        headline: 'Travel Cover',
        summary:
          'If you need medical assistance, your money is stolen or you miss your connection.',
        ctaUrl:
          'https://www.direct.aviva.co.uk/quote/Direct/Travel/?source=ZVC4%26cmp=app-ukmyaviva-welcome-travel-quote',
        ctaText: 'Get a quote',
        ctaActionTag: 'ukmyaviva|welcome|travel-quote-tapped',
      },
      {
        imageUrl:
          'https://cdn.aviva.com/shared/images/myaviva-app/life-insurance-v1.jpg',
        headline: 'Life insurance',
        summary:
          'Financial protection if you pass away within the policy term.',
        ctaUrl:
          'https://www.direct.aviva.co.uk/protection/direct/pagesFw/quoteInputPage.xhtml?OTLMYA%26cmp=app-ukmyaviva-welcome-life-quote',
        ctaText: 'Get a quote',
        ctaActionTag: 'ukmyaviva|welcome|life-quote-tapped',
      },
    ],
    Links: {
      Self: {
        href: 'http://myaviva-mobile-api.ukd-services.rwy.aws-euw1-np.avivacloud.com/Messaging/public/api/v1/content/en-GB/myaviva-prospect/offers/v1',
      },
      Env: {
        href: 'DEBUG',
      },
    },
    Detail: 'Mobile_ContentController_Get',
    Instance:
      'Aviva.UKD.Services.Api, Version=2019.10.2110.6, Culture=neutral, PublicKeyToken=null',
    Status: 200,
    Type: 'ContentModel',
  },
};

describe('ProspectOffersModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('fetchProspectOffers sends correct request', async () => {
    mockedAxios.get.mockResolvedValue({ data: mockProspectOffers });

    await new ProspectOffersModel().fetchProspectOffers();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/Messaging/public/api/v1/content/en-GB/myaviva-prospect/offers/v2'
    );
  });

  it('should throw an error when fetch fails', async () => {
    mockedAxios.get.mockResolvedValue({
      data: {
        Status: 500,
      },
    });

    await expect(
      new ProspectOffersModel().fetchProspectOffers()
    ).rejects.toThrow('Prospect offers schema parse error');
  });
});
