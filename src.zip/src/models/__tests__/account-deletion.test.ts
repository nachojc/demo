import { axios } from '@utils/api';

import { AccountDeletionModel } from '../account-deletion';

const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      post: jest.fn().mockResolvedValue({}),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('AccountDeletionModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('sendDeleteAccountRequest sends correct request', async () => {
    const expectedBody = {
      ContactNumber: '01111 111111',
      CustomerAvailability: 'Any time',
    };

    await new AccountDeletionModel().sendDeleteAccountRequest(
      '01111 111111',
      'Any time'
    );

    expect(mockedAxios.post).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v1/account/requestAccountDeletion',
      {
        ...expectedBody,
      }
    );
  });
});
