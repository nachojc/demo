import { renderHook, waitFor } from '@src/jest/testing-library';
import { usePensionPaymentDescriptions } from '@hooks/use-payment-description';
import { setMock } from '@src/api-mock/helpers';

import { PensionFundsModel } from '../pension-funds';

describe('Payment descriptions', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should return payment descriptions data', async () => {
    setMock('PaymentDescriptions', 'Payment Descriptions');
    const data = await new PensionFundsModel().fetchPaymentDescriptions();

    expect(data).toBeDefined();
  });

  it('should return payment descriptions with correct data', async () => {
    setMock('PaymentDescriptions', {
      content: {
        Content: {
          caveatDescriptions: [
            {
              caveat: 'Cash',
              content:
                'Some of your pension is invested in cash. If you want to invest some or all of your payment to cash, please call us.',
            },
          ],
          fundRiskLevelsDescriptions: [
            {
              riskScore: 1,
              content: '1 of 7: The historical performance of funds',
            },
          ],
        },
      },
    });

    const data = await new PensionFundsModel().fetchPaymentDescriptions();

    expect(data.Content.fundRiskLevelsDescriptions[0].riskScore).toEqual(1);
    expect(data.Content.fundRiskLevelsDescriptions[0].content).toEqual(
      '1 of 7: The historical performance of funds'
    );

    expect(data.Content.caveatDescriptions[0].caveat).toEqual('Cash');
    expect(data.Content.caveatDescriptions[0].content).toEqual(
      'Some of your pension is invested in cash. If you want to invest some or all of your payment to cash, please call us.'
    );
  });

  it('should return payment descriptions error', async () => {
    const { result } = renderHook(() => usePensionPaymentDescriptions());
    setMock('PaymentDescriptions', {
      status_code: 500,
    });

    await waitFor(() => {
      expect(result.current.isSuccess).toBe(false);
    });

    await waitFor(() => {
      expect(result.current.isError).toBe(true);
    });
  });
});
