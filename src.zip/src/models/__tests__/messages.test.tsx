import { axios } from '@utils/api';

import { MessagesModel } from '../messages';

const messagesModel = new MessagesModel();
const mockedAxios = axios as jest.Mocked<typeof axios>;

const mockMessages = {
  messages: [
    {
      id: 'id-1',
      header: 'header2',
      body: null,
      type: 'information',
    },
    {
      id: 'id-2',
      header: 'header3',
      body: 'body3',
      type: 'information',
    },
    {
      id: 'id-3',
      body: null,
      header: null,
      type: 'information',
    },
    {
      id: 'id-4',
      header: null,
      body: 'body4',
      type: 'information',
    },
  ],
} as const;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn(),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('MessagesModel', () => {
  beforeEach(() => {
    mockedAxios.get.mockResolvedValue({ data: mockMessages });
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  it('getMessages sends correct request', async () => {
    await messagesModel.getMessages();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      '/MessagingApi/api/v3/messages'
    );
  });

  it('should not have value with null header', async () => {
    const result = await messagesModel.getMessages();

    expect(result?.messages).toHaveLength(2);

    expect(result?.messages).not.toContainEqual(mockMessages.messages[2]);
    expect(result?.messages).not.toContainEqual(mockMessages.messages[3]);
  });
});
