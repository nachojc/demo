import { currentCustomerDate } from '@interfaces/storage';
import { axios } from '@utils/api';

import { CustomerModel } from '../customer';

jest.mock('@utils/api');
jest.mock('@src/common/config');

const mockedAxios = axios as jest.Mocked<typeof axios>;

const mockCustomer = {
  SecurePartyId: 'MTkxNjQ5NDUzMjE5NjYxNg==',
  PartyId: '1916494532196616',
  PersistentCustomerId: 'LW4gDwenzDfe9OZeO6Zs7eNHvgz65aWMyuIIjbNUhFed0bkK',
  Firstname: 'Commission',
  Surname: 'Test4',
  Email: '017571746@aviva.com',
  Address: {
    Address1: '37-43 Surrey Street',
    County: 'Norfolk',
    City: 'Norwich',
    Postcode: 'NR1 3UY',
    Country: '',
  },
  Gender: 'Male',
  CustomerDPALevel: '2',
  DateOfBirth: '01/01/1945',
  CurrentUtcDateTime: '2022-05-10T09:39:49Z',
  Products: [
    {
      ProductType: 'Pension',
      StartDate: '10/06/2020',
      LastDateOfCover: '15/12/2021',
      PolicyNumber: 'TRA111111111',
      SecurePolicyNumber: '__unknown-SecurePolicyNumber-2',
      ProductCode: '11111',
      IsLoaded: true,
      DisplayName: 'Pension',
    },
    {
      CoverType: 'Annual multi-trip',
      ProductType: 'Motor',
      StartDate: '10/06/2020',
      LastDateOfCover: '15/12/2021',
      PolicyNumber: 'TRA111111111',
      SecurePolicyNumber: '__unknown-SecurePolicyNumber-2',
      ProductCode: '82007',
      IsLoaded: true,
      DisplayName: 'Motor insurance',
    },
    {
      CoverType: 'Single trip',
      ProductType: 'Home',
      StartDate: '10/06/2020',
      LastDateOfCover: '15/12/2021',
      PolicyNumber: 'MTV111111111',
      SecurePolicyNumber: '__unknown-SecurePolicyNumber-1',
      ProductCode: '82011',
      IsLoaded: true,
      DisplayName: 'Home insurance',
    },
    {
      PolicyNumber: 'MOT111111111',
      SecurePolicyNumber: '__unknown-SecurePolicyNumber-2',
      ProductType: 'Motorcycle',
      ProductCode: '82038',
      IsLoaded: true,
      DisplayName: 'Motorcycle insurance',
    },
    {
      PolicyNumber: 'MOT111111111',
      SecurePolicyNumber: '__unknown-SecurePolicyNumber-2',
      ProductType: 'Pet',
      ProductCode: '82038',
      IsLoaded: true,
      DisplayName: 'Pet insurance',
    },
  ],
  GroupAccounts: [
    {
      AccountNumber: 'AVP00131789',
      AccountType: 'AvivaPlus',
      DisplayName: 'AvivaPlus',
      IsLoaded: true,
    },
    {
      AccountNumber: 'AVP00131780',
      AccountType: 'NotAvivaPlus',
      DisplayName: 'NotAvivaPlus',
      IsLoaded: true,
    },
  ],
  DirectWealth: [],
  ValueAddedServices: [
    {
      Name: 'MyDrive',
      StartDate: '10/05/2022',
      EndDate: '10/10/2023',
      Reference: '',
      Status: 'Active',
      EmployerName: 'Bobby',
      EmployerCode: '23432',
    },
  ],
  Eligibilities: [
    { Type: 'MarketingContentFlag', Value: true },
    { Type: 'AplEligibility', Value: false },
  ],
  Links: {
    Self: {
      href: 'https://direct.aviva.co.uk/Messaging/api/v2/customer/',
    },
    Env: { href: 'RW' },
  },
  Detail: 'Mobile_CustomerV2_Get',
  Instance:
    'Aviva.UKD.Services.Api, Version=2018.1018.1.2534, Culture=neutral, PublicKeyToken=null',
  Status: 200,
  Title: 'Mr.',
};

const mockErrorCustomer = {
  Status: 500,
};

const customerModel = new CustomerModel();

describe('CustomerModel', () => {
  beforeEach(() => {
    mockedAxios.get.mockResolvedValue({ data: mockCustomer });
    currentCustomerDate.set('');
  });

  afterEach(() => {
    jest.resetAllMocks();
  });

  it('should send correct request', async () => {
    await customerModel.fetchCustomer();

    expect(mockedAxios.get).toHaveBeenCalledWith(
      '/MessagingApi/api/v2/customer'
    );
  });

  it('should throw an error when fetch fails', async () => {
    const mockError = new Error('Fetch failed');
    mockedAxios.get.mockRejectedValue(mockError);

    await expect(customerModel.fetchCustomer()).rejects.toThrow(mockError);
  });

  it('should handle no products gracefully', async () => {
    const mockData = { ...mockCustomer, Products: [] };
    mockedAxios.get.mockResolvedValue({ data: mockData });

    const result = await customerModel.fetchCustomer();

    expect(result.Products.length).toEqual(0);
  });

  it('should not filter products when flag is disabled', async () => {
    const result = await customerModel.fetchCustomer();

    expect(result.Products.length).toEqual(5);
  });

  it('should filter out AvivaPlus group accounts', async () => {
    const result = await customerModel.fetchCustomer();
    expect(
      result.GroupAccounts?.find(
        (groupAccount) => groupAccount.AccountType === 'AvivaPlus'
      )
    ).toBeUndefined();
  });

  it('should set currentCustomerDate', async () => {
    expect(currentCustomerDate.get()).toEqual('');

    await customerModel.fetchCustomer();

    expect(currentCustomerDate.get()).toEqual('2022-05-10T09:39:49Z');
  });
});

describe('CustomerModel - throw with new message', () => {
  beforeEach(() => {
    mockedAxios.get.mockResolvedValue({ data: mockErrorCustomer });
    currentCustomerDate.set('');
  });

  afterEach(() => {
    jest.resetAllMocks();
  });

  it('should throw an error when fetch fails', async () => {
    await expect(customerModel.fetchCustomer()).rejects.toThrow(
      'Customer schema parse error'
    );
  });
});
