import { axios } from '@utils/api';

import { OfferModel } from '../offer';

const mockedAxios = axios as jest.Mocked<typeof axios>;

jest.mock('axios', () => {
  return {
    create: jest.fn(() => ({
      get: jest.fn().mockResolvedValue({ data: {}, status: 204 }),
      interceptors: {
        request: { use: jest.fn(), eject: jest.fn() },
        response: { use: jest.fn(), eject: jest.fn() },
      },
    })),
  };
});

describe('OfferModel', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('fetchOffers sends correct request', async () => {
    await new OfferModel().fetchOffers();

    expect(mockedAxios.get).toHaveBeenNthCalledWith(
      1,
      'MessagingApi/api/v1/content/en-GB/myaviva-new-business/offers/v1'
    );
  });

  it('should throw an error when fetch fails', async () => {
    mockedAxios.get.mockResolvedValue({
      data: {
        Status: 500,
      },
    });

    await expect(new OfferModel().fetchOffers()).rejects.toThrow(
      'Offers schema parse error'
    );
  });
});
