import {
  WealthHubEligibility,
  WealthHubEligibilitySchema,
} from '@src/validation/schemas/wealth-hub-eligibility';
import { axios } from '@utils/api';

export class WealthHubEligibilityModel {
  async fetchWealthHubEligibility(): Promise<WealthHubEligibility> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/directWealth/eligibility`
    );
    const result = WealthHubEligibilitySchema.safeParse(data);
    if (!result.success) {
      throw result.error;
    }
    return result.data;
  }
}
