import { axios } from '@utils/api';

export type NewRetirementAgePostData = {
  NewRetirementDate: string;
};

export class ChangeRetirementAgeModel {
  async changeRetirementAge(
    securePolicyNumber: string,
    newRetirementAgeData: NewRetirementAgePostData
  ) {
    return axios.post(
      `/MessagingApi/api/v1/pensions/${securePolicyNumber}/ChangeRetirementDate`,
      newRetirementAgeData
    );
  }
}
