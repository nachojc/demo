import { LOG } from '@interfaces/logger';
import { axios } from '@utils/api';

import { Offer, OffersSchema } from '../validation/schemas/offers';

export class OfferModel {
  logger = LOG.extend(OfferModel.name);

  async fetchOffers(): Promise<{ offers: Offer[]; status: number }> {
    const { data, status } = await axios.get(
      'MessagingApi/api/v1/content/en-GB/myaviva-new-business/offers/v1'
    );

    // When user is financially advised API returns 204 with empty response body
    if (status === 204) {
      return { offers: [], status };
    }

    const result = OffersSchema.safeParse(data);
    if (!result.success) {
      this.logger.error(result);

      throw new Error(`Offers schema parse error`);
    }

    return { offers: result.data.Content.offers, status };
  }
}
