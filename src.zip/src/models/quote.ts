import {
  QuotesResponse,
  QuotesResponseSchema,
} from '@src/validation/schemas/quotes';
import { axios } from '@utils/api';

const QUOTE_RETRIEVAL_PATH = '/MessagingApi/api/v1/quotes';

export class QuoteModel {
  static async fetchQuotes(): Promise<QuotesResponse> {
    const { data } = await axios.get(QUOTE_RETRIEVAL_PATH);
    const quotes = QuotesResponseSchema.safeParse(data);
    if (!quotes.success) {
      throw quotes.error;
    }

    return quotes.data;
  }
}
