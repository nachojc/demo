import { UK_DATE_FORMAT } from '@constants/string-formats';
import { FastTrackSignUpForm } from '@src/validation/schemas/fast-track-signup-form';
import { axios } from '@utils/api';
import { formatISO, parse } from 'date-fns';

import { AuthResponse } from '../validation/schemas/auth';

export const FASTTRACK_REGISTRATION_PATH =
  '/Messaging/public/api/v1/fasttrack/register';

export class FastTrackRegistrationModel {
  async signup(
    form: FastTrackSignUpForm,
    activationCode: string
  ): Promise<AuthResponse> {
    const body = {
      EmailAddress: form.emailInputs.email,
      Password: form.password,
      DateOfBirth: formatISO(parse(form.dob, UK_DATE_FORMAT, new Date()), {
        representation: 'date',
      }),
      EmailMarketingOptOut: form.offers === 'Yes',
      Code: activationCode,
    };
    const { data } = await axios.post(FASTTRACK_REGISTRATION_PATH, body);

    return data;
  }
}
