import { AlertProps } from '@aviva/ion-mobile/components/alert';
import { getAppID } from '@hooks/use-expo-config';
import { getGenericErrorMessage } from '@src/utils';
import { getAccessDefinition } from '@src/utils/api/access-definition';
import { ForgottenDetails } from '@src/validation/schemas/forgotten-details';
import {
  RecoverUsernameDetails,
  RecoverUsernameResponseSchema,
} from '@src/validation/schemas/recover-username';
import { SetPasswordRequest } from '@src/validation/schemas/set-password';
import { axios } from '@utils/api';

const ERROR_MESSAGE_MAP: { [key: number]: AlertProps } = {
  400: {
    title: `Sorry, we didn't recognise those details.`,
    message: `Please try again or call our support team on 0800 148 8665 if you need help.`,
  },
  401: {
    title: `Your password reset request has expired.`,
    message: `Please submit another request in the app or get in touch with our support team on 0800 148 8665 if you need help.`,
  },
  406: {
    title: `The password you've chosen doesn't meet our security standards.`,
    message: `Please choose a different password or contact us on 0800 148 8665.`,
  },
  429: {
    title: `A password reset request is in progress.`,
    message: `We've sent you an email with instructions. Please check all folders in your email account. If it does not arrive within a few minutes, you can request another.`,
  },
};

const forgottenUsernamePath = '/Messaging/public/api/v1/account/forgotusername';
const forgottenPasswordPath = '/Messaging/public/api/v1/account/forgotpassword';
const updatePasswordPath = '/avivasecurityaccountservice/v1/account/password';

export const mapAccountAxiosError = (error?: number): AlertProps => {
  const genericErrorMessage = getGenericErrorMessage();
  return ERROR_MESSAGE_MAP[error ?? 1] ?? genericErrorMessage;
};

export class AccountModel {
  async sendForgottenPassword(
    resetPwdDetails: ForgottenDetails
  ): Promise<number> {
    const body = {
      ...resetPwdDetails,
      /**
       * Currently co.uk.aviva.directwealth isn't a supported value and as such
       * we can't use getAppId() to dynamically set this
       *
       * It was agreed to hard code this until the Mobile API team confirm
       * if it will be feasible to make this change before August code complete
       */
      appName: 'co.uk.aviva.myaviva',
    };
    const { status } = await axios.put(forgottenPasswordPath, body);

    return status;
  }

  async sendChangePassword({
    newPassword,
    ActivationCode,
  }: {
    newPassword: string;
    ActivationCode: string;
  }): Promise<number> {
    const body: SetPasswordRequest = {
      accessDefinition: getAccessDefinition(),
      activationToken: ActivationCode,
      newPassword,
    };
    const { status } = await axios.put(updatePasswordPath, body);

    return status;
  }

  async sendRecoverUsername(
    recoverUsernameDetails: RecoverUsernameDetails
  ): Promise<string> {
    const body = {
      ...recoverUsernameDetails,
      appName: getAppID(),
    };
    const { data } = await axios.post(forgottenUsernamePath, body);

    return RecoverUsernameResponseSchema.parse(data).UserName;
  }
}
