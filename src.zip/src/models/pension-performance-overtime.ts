import { PensionPerformanceOvertime } from '@src/validation/schemas/pension-performance-overtime';
import { axios } from '@utils/api';

export class PensionPerformanceOvertimeModel {
  async fetchPensionPerformanceOvertime(opts: {
    securePolicyNumber: string;
    startDate?: string;
    endDate?: string;
  }) {
    const { data, status } = await axios.get<PensionPerformanceOvertime>(
      `/MessagingApi/api/v2/pensions/${opts.securePolicyNumber}/performanceOverTime`,
      {
        params: {
          startDate: opts.startDate,
          endDate: opts.endDate,
        },
      }
    );

    if (status === 204) {
      return {
        ValuationPoints: [],
        ...data,
      };
    }

    return data;
  }
}
