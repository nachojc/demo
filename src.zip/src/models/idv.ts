import { replaceValues } from '@src/common/config/utils';
import {
  Idv,
  IdvPost,
  IdvPostRequestBody,
  IdvPostSchema,
  IdvPutRequestBodyData,
  IdvPutResponseData,
  IdvPutResponseSchema,
  IdvSchema,
} from '@src/validation/schemas/idv';
import { axios } from '@utils/api';

const customerIdVerificationPath =
  '/MessagingApi/api/v2/customers/{0}/idverification';

export class IdvModel {
  async idvCompleteVerification(
    securePartyId: string,
    requestBody: IdvPutRequestBodyData
  ): Promise<IdvPutResponseData> {
    const { data } = await axios.put(
      replaceValues(customerIdVerificationPath, { '{0}': securePartyId }),
      requestBody
    );
    return IdvPutResponseSchema.parse(data);
  }

  async idvCustomer(
    securePartyId: string,
    idvData: IdvPostRequestBody
  ): Promise<IdvPost> {
    const { data } = await axios.post(
      replaceValues(customerIdVerificationPath, { '{0}': securePartyId }),
      idvData
    );

    return IdvPostSchema.parse(data);
  }

  async idvGetCustomerAllowed(securePartyId?: string): Promise<Idv> {
    const { data } = await axios.get(
      replaceValues(customerIdVerificationPath, { '{0}': securePartyId || '' })
    );

    return IdvSchema.parse(data);
  }
}
