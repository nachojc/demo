import { axios } from '@utils/api';

import { PensionSnapshotSchema } from '../validation/schemas/pension-snapshot-schema';

export class SnapshotModel {
  async fetchPensionSnapshot(opts: { securePolicyNumber: string }) {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/reports/${opts.securePolicyNumber}/pensionssnapshot/v1`
    );

    return PensionSnapshotSchema.parse(data);
  }
}
