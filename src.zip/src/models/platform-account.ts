import { getLogger } from '@interfaces/logger';
import { PlatformAccountService } from '@src/api/generated/requests';
import { MyMoneyAccount } from '@src/validation/schemas/customer';
import {
  PlatformAccount,
  PlatformAccountSchema,
} from '@src/validation/schemas/platform-account';

export class PlatformAccountModel {
  log = getLogger(PlatformAccountModel.name);

  async fetchPlatformAccount(
    secureAccountNumber: MyMoneyAccount['SecureAccountNumber']
  ): Promise<PlatformAccount> {
    const data = await PlatformAccountService.getApiV1Platformaccounts(
      secureAccountNumber
    );

    const result = PlatformAccountSchema.safeParse(data);
    if (!result.success) {
      this.log.zodError(result.error);
      throw result.error;
    }

    return result.data;
  }
}
