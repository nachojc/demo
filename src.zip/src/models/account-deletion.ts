import { AccountDeletionRequest } from '@src/validation/schemas/account-deletion';
import { axios } from '@utils/api';

export class AccountDeletionModel {
  async sendDeleteAccountRequest(
    contactNumber: string,
    customerAvailability: string
  ): Promise<number> {
    const body: AccountDeletionRequest = {
      ContactNumber: contactNumber,
      CustomerAvailability: customerAvailability,
    };

    const { status } = await axios.post(
      '/MessagingApi/api/v1/account/requestAccountDeletion',
      body
    );

    return status;
  }
}
