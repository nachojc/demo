import { LOG } from '@interfaces/logger';
import { Offer, RecommendationsSchema } from '@src/validation/schemas/offers';
import { axios } from '@utils/api';

export abstract class RecommendationsModel {
  static async fetchRecommendations(): Promise<{
    recommendations: {
      DashboardRecommendations: Offer[];
      ExploreRecommendations: Offer[];
    };
  }> {
    const { data } = await axios.get(
      '/MessagingApi/api/v3/recommendations/?CreativeCount=25'
    );

    const result = RecommendationsSchema.safeParse(data);
    if (!result.success) {
      LOG.error(result);

      throw new Error('Recommendations schema parse error');
    }

    return { recommendations: result.data.Recommendations };
  }
}
