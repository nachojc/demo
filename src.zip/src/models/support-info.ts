import { PhoneNumbersService } from '@src/api/generated/requests';

export class SupportInfoModel {
  async fetchSupportInfo(
    ...args: Parameters<typeof PhoneNumbersService.getApiV3SupportPhoneNumbers>
  ) {
    return PhoneNumbersService.getApiV3SupportPhoneNumbers(...args);
  }
}
