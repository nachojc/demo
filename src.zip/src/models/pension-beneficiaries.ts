import { BeneficiariesService } from '@src/api/generated/requests';
import { CommonBeneficiary } from '@src/navigation/types';
import { BeneficiarySharesPostSchema } from '@src/validation/schemas/pension-beneficiaries-share-percentage';
import { axios } from '@utils/api';

export class PensionBeneficiaries {
  async pensionBeneficiaries(securePolicyNumber: string) {
    const data = await BeneficiariesService.getApiV1PensionsBeneficiaries(
      securePolicyNumber
    );

    return data;
  }

  async pensionBeneficiariesPost(
    securePolicyNumber: string,
    beneficiariesPostData: CommonBeneficiary[]
  ) {
    const { data } = await axios.post(
      `/MessagingApi/api/v1/pensions/${securePolicyNumber}/beneficiaries`,
      beneficiariesPostData
    );

    const parsed = BeneficiarySharesPostSchema.parse(data);

    if (parsed.RoleResponse.Status !== 'Success') {
      throw new Error('Could not save the beneficiaries');
    }

    return parsed;
  }
}
