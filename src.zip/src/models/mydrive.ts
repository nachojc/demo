import { getLogger } from '@interfaces/logger';
import { axios } from '@src/utils/api';
import {
  InsightContent,
  InsightsContentResponseSchema,
} from '@src/validation/schemas/insights-content';
import {
  SignTokenRequest,
  SignTokenResponse,
  SignTokenResponseSchema,
} from '@src/validation/schemas/mydrive';
import { z } from 'zod';

const MYDRIVE_ACTIVATION_PATH = '/MessagingApi/api/v1/mydrive/activate';
const MYDRIVE_DEACTIVATION_PATH = '/MessagingApi/api/v1/mydrive/deactivate';
const MYDRIVE_INSIGHTS_PATH =
  '/Messaging/public/api/v1/content/en-GB/mydrive/mydrive_insights/v1';
const MYDRIVE_TOKEN_PATH = '/MessagingApi/api/v1/mydrive/session/create';

export class MyDriveModel {
  log = getLogger(MyDriveModel.name);

  async activateMyDrive() {
    const { data } = await axios.post(MYDRIVE_ACTIVATION_PATH);

    const result = ActivateMyDriveSchema.safeParse(data);

    if (!result.success) {
      this.log.zodError(result.error);
      throw result.error;
    }

    return result.data;
  }

  async deactivateMyDrive() {
    const { status } = await axios.post(MYDRIVE_DEACTIVATION_PATH);

    return status;
  }

  async getInsightsContent() {
    const { data } = await axios.get(MYDRIVE_INSIGHTS_PATH);

    return InsightsContentResponseSchema.parse(data).Content
      .insights as InsightContent[];
  }

  async signMyDriveToken(
    signTokenRequest: SignTokenRequest
  ): Promise<SignTokenResponse> {
    const { data } = await axios.post(MYDRIVE_TOKEN_PATH, signTokenRequest);
    return SignTokenResponseSchema.parse(data);
  }
}

const ActivateMyDriveSchema = z.object({
  ActivationId: z.string(),
});
