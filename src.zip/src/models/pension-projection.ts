import { PensionProjectionSchema } from '@src/validation/schemas/pension-projection';
import { axios } from '@utils/api';

export class PensionProjectionModel {
  async fetchProjections(opts: { securePolicyNumber: string }) {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/pensions/${opts.securePolicyNumber}/projection`
    );

    return PensionProjectionSchema.parse(data);
  }
}
