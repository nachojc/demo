import { getProductHandler } from '@hooks/use-product/product-handlers';
import { getLogger } from '@interfaces/logger';
import { Products } from '@src/validation/schemas/product/products';
import { axios } from '@utils/api';

const getPolicyPath = '/MessagingApi/api/v2/policies/';

export class PolicyModel {
  log = getLogger(PolicyModel.name);
  async fetchPolicy(securePolicyNumber: string): Promise<Products> {
    const { data } = await axios.get(`${getPolicyPath}${securePolicyNumber}`);

    const productType = data?.policy?.ProductType;
    const isAvivaOnlineMotor = data?.policy?.IsAoMotorProduct;

    // Safely parse API response, with corresponding Product's schema (i.e. Home, Motor, Illness, etc.)
    let productHandler = getProductHandler(productType);
    if (isAvivaOnlineMotor) {
      productHandler = getProductHandler('AvivaOnlineMotor');
    }

    if (!productHandler) {
      const error = new Error(`ProductType missing from productHandlers.
See: 'src/common/hooks/use-product/product-handlers.ts' to add a handler for this ProductType.`);
      this.log.warn(error);
      throw error;
    }

    return productHandler.schema.parse(data.policy);
  }
}
