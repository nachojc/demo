import { DocumentsSchema } from '@src/validation/schemas/documents';
import { axios } from '@utils/api';

export class DocumentsModel {
  async fetchDocuments(opts: { securePolicyNumber: string }) {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/documents/${opts.securePolicyNumber}`
    );
    return DocumentsSchema.parse(data);
  }
}
