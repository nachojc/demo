import { PensionFundsSchema } from '@src/validation/schemas/pension-funds';
import { PensionFundsPaymentDescriptionsSchema } from '@src/validation/schemas/pension-payment-descriptions';
import { axios } from '@utils/api';

export class PensionFundsModel {
  async fetchPensionFunds(opts: { securePolicyNumber: string }) {
    const { data } = await axios.get(
      `/MessagingApi/api/v2/pensions/${opts.securePolicyNumber}/funds`
    );

    return PensionFundsSchema.parse(data);
  }

  async fetchPaymentDescriptions() {
    const { data } = await axios.get(
      `/Messaging/public/api/v1/content/en-GB/myaviva-single-payment/payment_descriptions/v1`
    );

    const result = PensionFundsPaymentDescriptionsSchema.safeParse(data);

    if (!result.success) {
      throw result.error;
    }

    return result.data;
  }
}
