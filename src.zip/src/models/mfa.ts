import {
  AddTrustedDeviceRequest,
  AddTrustedDeviceResponse,
  AddTrustedDeviceResponseSchema,
  GenerateMfaRequest,
  GenerateMfaResponse,
  GenerateMfaResponseSchema,
  GetMfaPreferenceResponse,
  GetMfaPreferenceResponseSchema,
  UpdateMfaPreferenceRequest,
  VerifyMfaRequest,
  VerifyMfaResponse,
  VerifyMfaResponseSchema,
} from '@src/validation/schemas/mfa';
import { axios } from '@utils/api';
import { AxiosError } from 'axios';

export class MfaModel {
  async getMfaPreference(): Promise<GetMfaPreferenceResponse> {
    try {
      const { data } = await axios.get(`/avivasecurityauthservice/v1/mfa`);
      return GetMfaPreferenceResponseSchema.parse(data);
    } catch (error) {
      if (error instanceof AxiosError && error.response?.status === 503) {
        throw new ServerUnderMaintenanceError('MFA Server Under Maintenance');
      }

      throw error;
    }
  }

  async generateMfaCode(
    generateMfaCodeRequest?: GenerateMfaRequest
  ): Promise<GenerateMfaResponse> {
    const body = { ...generateMfaCodeRequest };

    const { data } = await axios.post('/avivasecurityauthservice/v1/mfa', body);

    return GenerateMfaResponseSchema.parse(data);
  }

  async verifyCode(
    verifyMfaRequest: VerifyMfaRequest,
    scopes: string[],
    activationCode?: string
  ): Promise<VerifyMfaResponse> {
    const body = {
      ...verifyMfaRequest,
      scopes,
      activationToken: activationCode,
    };

    const { data } = await axios.put('/avivasecurityauthservice/v1/mfa', body);

    if (data.code_verified === false) {
      throw new AxiosError(data.failure_reason);
    }

    return VerifyMfaResponseSchema.parse(data);
  }

  async addTrustedDevice(
    trustDeviceRequest: AddTrustedDeviceRequest
  ): Promise<AddTrustedDeviceResponse> {
    const body = { ...trustDeviceRequest };
    const { data } = await axios.post(
      '/avivasecurityauthservice/v1/mfa/trust',
      body
    );
    return AddTrustedDeviceResponseSchema.parse(data);
  }

  async updateMfaPreference(
    setMfaPreferenceRequest: UpdateMfaPreferenceRequest,
    accessToken: string
  ): Promise<void> {
    await axios.patch(
      '/avivasecurityaccountservice/v1/account',
      setMfaPreferenceRequest,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );
  }
}

export class ServerUnderMaintenanceError extends Error {}
