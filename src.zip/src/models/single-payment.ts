import { MyMoneySinglePaymentParams } from '@src/navigation/types';
import { getReadableVersion } from '@src/utils/device-info';
import {
  PaymentMethodSchema,
  PspSchema,
} from '@src/validation/schemas/pension-payment-methods';
import { SinglePaymentNative } from '@src/validation/schemas/pension-payment-native';
import { BankDetailsSchema } from '@src/validation/schemas/single-payment';
import { axios, isAxiosError } from '@utils/api';
import { Platform } from 'expo-modules-core';
import { RequireAllOrNone } from 'type-fest';

export type SinglePaymentRequest = {
  employmentStatus?: string;
  residentialStatus?: string;
  sourceOfFunds?: string;
  funds?: {
    name: string;
    allocation: number;
  }[];
  otherSourceOfFunds?: string;
  otherSourceOfFund?: string;
  amount: number;
  occupation?: string;
  income?: number;
} & RequireAllOrNone<
  MyMoneySinglePaymentParams,
  'sortCode' | 'accountNumber' | 'accountName'
>;

export type SinglePaymentNativeRequest = {
  payment: {
    idempotentKey: string;
    transactionId?: string | null;
    requestType: 'CardDetails' | 'ThreeDS2';
    redirectUrl: string;
    psp: string;
    pspData: string;
    previousPspResponseData?: string | null;
  };
  hasCustomerSelectedInvestmentAssets: boolean;
} & SinglePaymentRequest;

export class SinglePaymentModel {
  async singlePayment(securePolicyNumber: string, body: SinglePaymentRequest) {
    const { data } = await axios.post(
      `/MessagingApi/api/v1/pensions/${securePolicyNumber}/SinglePayment`,
      body
    );

    return BankDetailsSchema.parse(data);
  }

  async singlePaymentNative(
    securePolicyNumber: string,
    body: SinglePaymentNativeRequest
  ) {
    try {
      const { data } = await axios.post(
        `/MessagingApi/api/v1/pensions/${securePolicyNumber}/nativeSinglePayment`,
        {
          ...body,
          payment: {
            ...body.payment,
            channel: Platform.OS === 'ios' ? 'iOS' : 'Android',
          },
        }
      );
      try {
        const parsed = SinglePaymentNative.parse(data);
        const pspData = JSON.parse(parsed.payment.pspData ?? '{}');
        return { ...parsed, pspData: PspSchema.parse(pspData) };
      } catch (err) {
        throw data;
      }
    } catch (error) {
      if (isAxiosError(error)) {
        throw JSON.parse(error.request.response);
      }
      throw error;
    }
  }

  async singlePaymentMethods(body: {
    amount: number;
    journey: 'None' | 'PensionSinglePayment' | 'AvivaOnlineMotorRenewal';
    journeyContext?: string | null;
  }) {
    const { data } = await axios.post('/MessagingApi/api/v1/payment/methods', {
      ...body,
      channel: Platform.OS === 'ios' ? 'iOS' : 'Android',
      appVersion: getReadableVersion(),
    });

    const parsed = PaymentMethodSchema.parse(data);
    const pspData = JSON.parse(parsed.pspData);

    return { ...parsed, pspData: PspSchema.parse(pspData) };
  }

  async singlePaymentBankValidation(
    securePolicyNumber: string,
    requestBody: {
      AccountNumber: string;
      SortCode: string;
    }
  ) {
    return axios.post(
      `/MessagingApi/api/v1/pensions/${securePolicyNumber}/SinglePayments/validateBankAccountDetails`,
      requestBody
    );
  }
}
