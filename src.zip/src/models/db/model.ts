import { Model } from '@nozbe/watermelondb';
import { field, json } from '@nozbe/watermelondb/decorators';
import {
  MyDriveEvents,
  Point,
  TransportMode,
  TripScore,
} from '@src/validation/schemas/mydrive';

import { TableName } from './schema';

const sanitizer = (source: unknown) => source;

export class Journey extends Model {
  static override table = TableName.Journey;

  @field('journeyId') journeyId!: string;
  @field('partyId') partyId!: string;
  @field('startDate') startDate!: string;
  @field('endDate') endDate!: string;
  @field('distance') distance!: number;
  @field('duration') duration!: number;
  @field('overallScore') overallScore!: number;
  @field('transportMode') transportMode!: TransportMode;
  @json('events', sanitizer) events!: MyDriveEvents;
  @json('componentScores', sanitizer) componentScores!: TripScore;
  @json('geometry', sanitizer) geometry!: Point[];
}

class ScoreSummaryBase extends Model {
  @field('partyId') partyId!: string;
  @field('startDate') startDate!: string;
  @field('endDate') endDate!: string;
  @field('overallScore') overallScore!: number;
  @field('accelerationScore') accelerationScore!: number;
  @field('brakingScore') brakingScore!: number;
  @field('corneringScore') corneringScore!: number;
  @field('distractedDrivingScore') distractedDrivingScore!: number;
  @field('speedingScore') speedingScore!: number;
  @field('distance') distance!: number;
  @field('duration') duration!: number;
  @field('numberOfTrips') numberOfTrips!: number;
}

export class ScoreSummary extends ScoreSummaryBase {
  static override table = TableName.ScoreSummary;
}

export class WeeklyScoreSummary extends ScoreSummaryBase {
  static override table = TableName.WeeklyScoreSummary;
}

export class DataMigration extends Model {
  static override table = TableName.DataMigration;

  @field('name') name!: string;
}
