import { appSchema, ColumnSchema, tableSchema } from '@nozbe/watermelondb';

export const TableName = {
  DataMigration: 'DataMigration',
  ScoreSummary: 'ScoreSummary',
  Journey: 'Journey',
  WeeklyScoreSummary: 'WeeklyScoreSummary',
} as const;

const scoreSummaryColumns = [
  { name: 'partyId', type: 'string' },
  { name: 'startDate', type: 'string' },
  { name: 'endDate', type: 'string' },
  { name: 'overallScore', type: 'number' },
  { name: 'accelerationScore', type: 'number' },
  { name: 'brakingScore', type: 'number' },
  { name: 'corneringScore', type: 'number' },
  { name: 'distractedDrivingScore', type: 'number' },
  { name: 'speedingScore', type: 'number' },
  { name: 'distance', type: 'number' },
  { name: 'duration', type: 'number' },
  { name: 'numberOfTrips', type: 'number' },
] satisfies ColumnSchema[];

export const schema = appSchema({
  version: 2,
  tables: [
    tableSchema({
      name: TableName.DataMigration,
      columns: [{ name: 'name', type: 'string' }],
    }),
    tableSchema({
      name: TableName.ScoreSummary,
      columns: scoreSummaryColumns,
    }),
    tableSchema({
      name: TableName.WeeklyScoreSummary,
      columns: scoreSummaryColumns,
    }),
    tableSchema({
      name: TableName.Journey,
      columns: [
        { name: 'journeyId', type: 'string' },
        { name: 'partyId', type: 'string' },
        { name: 'startDate', type: 'string' },
        { name: 'endDate', type: 'string' },
        { name: 'distance', type: 'number' },
        { name: 'duration', type: 'number' },
        { name: 'overallScore', type: 'number' },
        { name: 'transportMode', type: 'string' }, //TransportMode
        { name: 'events', type: 'string' }, //MyDriveEvent[]
        { name: 'componentScores', type: 'string' }, //JourneyComponentScores[]
        { name: 'geometry', type: 'string' }, //Point[]
      ],
    }),
  ],
});
