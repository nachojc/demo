import { LOG } from '@interfaces/logger';
import { ProspectOffersSchema } from '@src/validation/schemas/prospect-offers';
import { axios } from '@utils/api';

export class ProspectOffersModel {
  logger = LOG.extend(ProspectOffersModel.name);

  async fetchProspectOffers() {
    const { data } = await axios.get(
      `/Messaging/public/api/v1/content/en-GB/myaviva-prospect/offers/v2`
    );

    const result = ProspectOffersSchema.safeParse(data);
    if (!result.success) {
      this.logger.error(result);

      throw new Error(`Prospect offers schema parse error`);
    }

    return result.data.Content.offers;
  }
}
