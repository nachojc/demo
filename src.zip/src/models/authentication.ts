import { config } from '@config';
import { getAppID } from '@hooks/use-expo-config';
import { getStoredTrustToken, refreshToken } from '@interfaces/secure-store';
import { displayName } from '@src/common/hooks/use-expo-config';
import { LoginAlertProps } from '@src/features/login/common';
import { getGenericErrorMessage } from '@src/utils';
import { getAccessDefinition } from '@src/utils/api/access-definition';
import { TIMEOUT_ERROR } from '@src/utils/api/constants';
import {
  getHashedDeviceId,
  getRiskId,
  getUniqueDeviceId,
} from '@src/utils/get-device-id';
import { Api200WithErrorsSchema } from '@src/validation/schemas/error';
import { MfaCredentials } from '@src/validation/schemas/mfa';
import { accessToken, axios } from '@utils/api';
import { AxiosError } from 'axios';

import { AuthResponse, AuthResponseSchema } from '../validation/schemas/auth';
import { Credentials } from '../validation/schemas/credentials';

const SIGNAL_CANCELED_ERROR = 'canceled';
const NO_NETWORK_ERROR = 'Network Error';
const RECORD_LOGIN_PATH = '/MessagingApi/api/v1/recordLogin';

/**
 * Maps Error responses to a user friendly error message
 * @key response.errorCode
 * @value An error message to be displayed to the user
 */
const ERROR_MESSAGE_MAP: { [key: string]: LoginAlertProps } = {
  AV_OAUTH_ERR_00010_UNKNOWN_USER: {
    title: 'Login unsuccessful',
    message:
      'Your username and password combination is incorrect, please try again.',
    shouldReportOpened: true,
  },
  AV_OAUTH_ERR_00012_INVALID_CLIENTCREDS: {
    title: 'Login unsuccessful',
    message:
      'Your username and password combination is incorrect, please try again.',
    shouldReportOpened: true,
  },
  AV_OAUTH_ERR_00035_ERROR_ACCOUNT_LOGIN_FAILURE: {
    title: 'Login unsuccessful',
    message:
      'Your username and password combination is incorrect, please try again.',
    shouldReportOpened: true,
  },
  AV_OAUTH_ERR_00025_ERROR_ACCOUNT_IN_CHANGE_PWD: {
    title: 'The password is no longer valid.',
    message: 'Please reset in order to continue using the MyAviva app.',
    shouldReportOpened: true,
  },
  AV_OAUTH_ERR_00032_ERROR_ACCOUNT_IN_JIT_PENDING_TEMPORARY_PASSWORD: {
    title: 'The password is no longer valid.',
    message: `Please reset in order to continue using the ${displayName()} app.`,
    shouldReportOpened: true,
  },
  AV_OAUTH_ERR_00036_ERROR_ACCOUNT_IN_TEMP_PWD_EXPIRED: {
    title: 'The password is no longer valid.',
    message: `Please reset in order to continue using the ${displayName()} app.`,
    shouldReportOpened: true,
  },
  [TIMEOUT_ERROR]: {
    title: 'Network connection error',
    message:
      'You need to be connected to the internet to continue. Please check your connection and try again.',
  },
  [SIGNAL_CANCELED_ERROR]: {
    title: 'Network connection error',
    message:
      'You need to be connected to the internet to continue. Please check your connection and try again.',
  },
  [NO_NETWORK_ERROR]: {
    title: 'Network connection error',
    message:
      'You need to be connected to the internet to continue. Please check your connection and try again.',
  },
};

export type AuthenticationErrorMessages = keyof typeof ERROR_MESSAGE_MAP;

export const OAUTH_TOKEN_ENDPOINT = '/oauthaccess/token';

export const mapAuthenticationAxiosError = (
  error: keyof typeof ERROR_MESSAGE_MAP
): LoginAlertProps => {
  const genericErrorMessage = getGenericErrorMessage();
  return ERROR_MESSAGE_MAP[error] ?? genericErrorMessage;
};

export class AuthenticationModel {
  async authenticate(credentials: Credentials): Promise<AuthResponse> {
    const deviceHash = await getHashedDeviceId();
    let body: Record<string, string | null> | null = {
      ...credentials,
      grant_type: 'password',
      avivaAccDef: getAccessDefinition(),
      client_id: config.OAUTH_CLIENT_ID.get(),
      device_id: deviceHash,
      scope: config.OAUTH_SCOPES.get(),
      trust_token: await getStoredTrustToken(),
    };

    const { data } = await axios.post(OAUTH_TOKEN_ENDPOINT, body);
    body = null; // Wipe this out until GC gets a chance to clean it up
    return this.handleAuthenticationRequest(data);
  }

  async authenticateWithRefreshToken(rToken: string): Promise<AuthResponse> {
    const deviceID = await getUniqueDeviceId();
    const riskID = await getRiskId();
    let body: Record<string, string | null> | null = {
      grant_type: 'refresh_token',
      client_id: config.OAUTH_CLIENT_ID.get(),
      device_id: deviceID,
      refresh_token: rToken,
      risk_id: riskID,
      trust_token: await getStoredTrustToken(),
    };

    const { data } = await axios.post('/oauthaccess/token', body);
    body = null;
    return this.handleAuthenticationRequest(data);
  }

  async authenticateWithMfaCode(
    mfaCredentials: MfaCredentials
  ): Promise<AuthResponse> {
    const deviceHash = await getHashedDeviceId();
    let body: Record<string, string | null> | null = {
      ...mfaCredentials,
      grant_type: 'mfa_password',
      avivaAccDef: getAccessDefinition(),
      client_id: config.OAUTH_CLIENT_ID.get(),
      device_id: deviceHash,
    };

    const { data } = await axios.post(OAUTH_TOKEN_ENDPOINT, body);
    body = null;
    return this.handleAuthenticationRequest(data);
  }

  handleAuthenticationRequest(data: unknown) {
    // Handle responses with errors that have a status code of 200 (!)

    const errorCheck = Api200WithErrorsSchema.safeParse(data);
    if (errorCheck.success && errorCheck.data.errorCode !== 'mfa.required') {
      throw new AxiosError(errorCheck.data.errorCode);
    }

    const parsedData = AuthResponseSchema.parse(data);

    accessToken.set(parsedData.access_token);
    if (parsedData.refresh_token) {
      refreshToken.set(parsedData.refresh_token);
    }

    return parsedData;
  }

  async getSSOToken() {
    const { data } = await axios.post(
      '/avivasecurityauthservice/v2/device/oauthssotoken',
      {
        accessdef: getAccessDefinition(),
      }
    );

    return data;
  }

  async recordLogin() {
    const body = { appName: getAppID() };
    // Don't await, this is fire and forget.
    axios.post(RECORD_LOGIN_PATH, body);
  }
}
