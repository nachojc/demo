import { getLogger } from '@interfaces/logger';
import { GroupAccountService } from '@src/api/generated/requests';
import {
  GroupAccount,
  GroupAccountSchema,
} from '@src/validation/schemas/group-account/group-account';

export class GroupAccountModel {
  log = getLogger(GroupAccountModel.name);

  async fetchGroupAccount(accountNumber: string): Promise<GroupAccount> {
    const data = await GroupAccountService.getApiV1Groupaccounts(accountNumber);

    const result = GroupAccountSchema.safeParse(data);

    if (!result.success) {
      this.log.zodError(result.error);
      throw result.error;
    }

    return result.data;
  }
}
