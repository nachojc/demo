import { getLogger } from '@interfaces/logger';
import { Aviva_Digital_MobileApi_Endpoints_CustomerProfileChange_V1_Model_ChangeAddressModel as ChangeAddress } from '@src/api/generated/requests';
import {
  CommunicationRequest,
  CommunicationResponse,
  CommunicationResponseSchema,
  ProfileChangeEligibilityResponseSchema,
} from '@src/validation/schemas/profile';
import { axios } from '@utils/api';
import { AxiosError } from 'axios';

export class ProfileModel {
  log = getLogger(ProfileModel.name);

  async fetchProfileChangeEligibility() {
    const { data } = await axios.get(
      '/MessagingApi/api/v1/customer/profileChange/eligibility'
    );
    return ProfileChangeEligibilityResponseSchema.parse(data);
  }

  async getCommunicationPreferences(): Promise<CommunicationResponse> {
    const { data } = await axios.get(
      '/MessagingApi/api/v3/profile/communicationPreferences'
    );

    return CommunicationResponseSchema.parse({
      paperlessPolicyDocuments: data.PaperlessPolicyDocuments,
    });
  }

  async putCommunicationPreferences(payload: CommunicationRequest) {
    await axios.put('/MessagingApi/api/v2/profile/communicationPreferences', {
      paperlessPolicyDocuments: payload.paperlessPolicyDocuments,
    });
  }

  async changeAddress(payload: ChangeAddress) {
    const { status } = await axios.put(
      '/MessagingApi/api/v1/customer/profileChange/changeAddress',
      {
        ...payload,
      }
    );

    if (status !== 204) {
      this.log.error(new Error(`Invalid status: ${status}`));
      throw new AxiosError();
    }
  }
}
