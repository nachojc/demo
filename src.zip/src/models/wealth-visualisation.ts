import { getLogger } from '@interfaces/logger';
import { WealthVisualisationSchema } from '@src/validation/schemas/wealth-visualisation';
import { axios } from '@utils/api';

type WealthVisualisation = {
  value: number;
  breakdown: {
    name: string;
    policyNumber: string;
    percentage: number;
  }[];
};

export class WealthVisualisationModel {
  log = getLogger(WealthVisualisationModel.name);

  async fetchWealthVisualisation(): Promise<WealthVisualisation> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/policies/wealth/visualisation`
    );

    const result = WealthVisualisationSchema.safeParse(data);

    if (!result.success) {
      this.log.zodError(result.error);
      throw result.error;
    }

    return result.data;
  }
}
