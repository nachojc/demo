import { Aviva_Digital_MobileApi_Endpoints_IndividualFundPerformance_V1_Model_IndividualFundPerformanceResponseModel as IndividualFundPerformanceResponseModel } from '@src/api/generated/requests';
import { axios } from '@utils/api';

export class PensionFundsPerformanceModel {
  async fetchPensionFundsPerformance(ops: {
    fundsLibraryReference?: string | null;
    investmentAssetBusinessContext?: string | null;
  }): Promise<IndividualFundPerformanceResponseModel> {
    const { data } = await axios.get(
      `/MessagingApi/api/v1/funds/${ops.fundsLibraryReference}/investmentAssetDetails/${ops.investmentAssetBusinessContext}`
    );
    return data;
  }
}
