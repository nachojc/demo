import { getLogger } from '@interfaces/logger';
import { currentCustomerDate } from '@interfaces/storage';
import { axios } from '@utils/api';

import { Customer, CustomerSchema } from '../validation/schemas/customer';

export const GET_CUSTOMER_PATH = '/MessagingApi/api/v2/customer';

export class CustomerModel {
  log = getLogger(CustomerModel.name);

  async fetchCustomer(): Promise<Customer> {
    const { data } = await axios.get(GET_CUSTOMER_PATH);

    const result = CustomerSchema.safeParse(data);
    if (!result.success) {
      this.log.zodError(result.error);

      throw new Error(`Customer schema parse error`);
    }

    // Set an observable date that can be used around the app
    currentCustomerDate.set(result.data.CurrentUtcDateTime);

    // Filter out groupAccountProducts
    result.data.GroupAccounts = result.data.GroupAccounts?.filter(
      (groupAccount) => groupAccount.AccountType !== 'AvivaPlus'
    );

    return result.data;
  }
}
