import { APP_BASE } from '@constants/analytics';

const PAGE_DASHBOARD = `${APP_BASE}homepage`;
const PAGE_HOMEDASHBOARD = `${APP_BASE}home-dashboard`;

const RETIREMENT_TAB_TAPPED = `${PAGE_DASHBOARD}|retirement-tapped`;
const WEALTH_TAB_TAPPED = `${PAGE_DASHBOARD}|wealth-tapped`;
const INSURANCE_TAB_TAPPED = `${PAGE_DASHBOARD}|insurance-tapped`;
const MESSAGE_CENTER_TAPPED = `${PAGE_DASHBOARD}|messagecentre-tapped`;
const CANT_SEE_MY_RETIREMEMENT_POLICY_TAPPED = `${PAGE_DASHBOARD}|retirement|icantseemypolicy-tapped`;
const CANT_SEE_MY_INSURANCE_TAPPED = `${PAGE_DASHBOARD}|insurance|icantseemypolicy-tapped`;
const CANT_SEE_MY_WEALTH_POLICY_TAPPED = `${PAGE_DASHBOARD}|wealth|icantseemypolicy-tapped`;
const LOGOUT_TAPPED = `${APP_BASE}navigation-menu|log-out-tapped`;
const CONFIRM_LOGOUT_TAPPED = `${APP_BASE}navigation-menu|log-out-confirmation-tapped`;
const CANCEL_LOGOUT_TAPPED = `${APP_BASE}navigation-menu|log-out-cancel-tapped`;

//MORE FOR YOU
const COMMUNITY_FUND_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|avivacommunityfund-tapped`;
const AVIVA_SCORE_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|avivascore-tapped`;
const DAY_INSURE_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|day-insure-tapped`;
const IT_TAKES_AVIVA_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|ittakesaviva-tapped`;
const MID_LIFE_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|midlife-tapped`;
const INFLATION_CALCULATOR_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|inflationcalculator-tapped`;
const FINANCIAL_PUZZLES_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|financial-puzzles-tapped`;
const PENSION_INVESTED_TAPPED = `${PAGE_HOMEDASHBOARD}|proposition-card|where-pension-invested-tapped`;

export {
  AVIVA_SCORE_TAPPED,
  CANCEL_LOGOUT_TAPPED,
  CANT_SEE_MY_INSURANCE_TAPPED,
  CANT_SEE_MY_RETIREMEMENT_POLICY_TAPPED,
  CANT_SEE_MY_WEALTH_POLICY_TAPPED,
  COMMUNITY_FUND_TAPPED,
  CONFIRM_LOGOUT_TAPPED,
  DAY_INSURE_TAPPED,
  FINANCIAL_PUZZLES_TAPPED,
  INFLATION_CALCULATOR_TAPPED,
  INSURANCE_TAB_TAPPED,
  IT_TAKES_AVIVA_TAPPED,
  LOGOUT_TAPPED,
  MESSAGE_CENTER_TAPPED,
  MID_LIFE_TAPPED,
  PAGE_DASHBOARD,
  PAGE_HOMEDASHBOARD,
  PENSION_INVESTED_TAPPED,
  RETIREMENT_TAB_TAPPED,
  WEALTH_TAB_TAPPED,
};
