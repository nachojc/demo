import {
  Button,
  ButtonVariant,
  Dialog as LogoutDialog,
  ScrollView,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useAuth } from '@hooks/use-auth';
import { useFocusEffect } from '@react-navigation/native';
import { MarketingPreferencesDialog } from '@src/components/marketing-preferences-dialog/marketing-preferences-dialog';
import { MyDriveIntroductionModal } from '@src/features/mydrive/components/modals';
import { getTestId } from '@src/utils/get-test-id';
import { t } from 'i18next';
import { useCallback, useState } from 'react';
import { BackHandler } from 'react-native';

import {
  CANCEL_LOGOUT_TAPPED,
  CONFIRM_LOGOUT_TAPPED,
  LOGOUT_TAPPED,
} from './analytics';
import { dashboardTabIndexMap, initialDashboardTab } from './constants';
import { createDashboardTabNavigator } from './dashboard-tab-navigator';

export type DashboardTabs = {
  Retirement: undefined;
  Wealth: undefined;
  Insurance: undefined;
};

export type DashboardTabNames = keyof DashboardTabs;
const Tabs = createDashboardTabNavigator<DashboardTabs>();

export const DashboardScreen = () => {
  const [showLogoutDialog, setShowLogoutDialog] = useState(false);
  const { trackUserEvent } = useAnalytics();
  const { signOut } = useAuth();

  const handleBackButtonPress = () => {
    setShowLogoutDialog(true);
    trackUserEvent(LOGOUT_TAPPED);
    return true;
  };

  const handleLogoutPress = () => {
    trackUserEvent(CONFIRM_LOGOUT_TAPPED);
    setShowLogoutDialog(false);
    signOut();
  };

  const handleCancelLogoutPress = () => {
    trackUserEvent(CANCEL_LOGOUT_TAPPED);
    setShowLogoutDialog(false);
  };

  useFocusEffect(
    useCallback(() => {
      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        handleBackButtonPress
      );
      return () => backHandler.remove();
    }, [])
  );

  return (
    <ScrollView scrollEnabled showsVerticalScrollIndicator={false}>
      <Tabs.Navigator
        initialRouteName={
          dashboardTabIndexMap[initialDashboardTab.get()].screenName
        }
      >
        <Tabs.Screen
          name="Insurance"
          getComponent={() => require('./screen/insurance').InsuranceScreenView}
        />
        <Tabs.Screen
          name="Wealth"
          getComponent={() => require('./screen/wealth').WealthScreenView}
        />
        <Tabs.Screen
          name="Retirement"
          getComponent={() =>
            require('./screen/retirement').RetirementScreenView
          }
        />
      </Tabs.Navigator>
      <LogoutDialog
        open={showLogoutDialog}
        title={t('logout.confirmationDialog.dialogTitle')}
        copy={t('logout.confirmationDialog.dialogMessage')}
      >
        <Button
          testID={getTestId('logout-confirm')}
          variant={ButtonVariant.BRAND}
          mt="$xl"
          onPress={handleLogoutPress}
        >
          {t('logout.confirmationDialog.confirmButtonLabel')}
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={handleCancelLogoutPress}
          testID={getTestId('logout-cancel')}
        >
          {t('logout.confirmationDialog.cancelButtonLabel')}
        </Button>
      </LogoutDialog>

      <MarketingPreferencesDialog />
      <MyDriveIntroductionModal />
    </ScrollView>
  );
};
