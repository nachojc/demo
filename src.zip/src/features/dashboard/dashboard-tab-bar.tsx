import { getTokens, getVariableValue, Text } from '@aviva/ion-mobile';
import { tabAccessibilityLabel } from '@aviva/ion-mobile/components/tabs';
import { useAnalytics } from '@hooks/use-analytics';
import { useTabAnimation } from '@hooks/use-tab-animation';
import { useSelector } from '@legendapp/state/react';
import { TabNavigationState } from '@react-navigation/native';
import { PillTabBar, tabWidthCalculator } from '@src/components/tab-bar';
import { useDashboardTabsNavigation } from '@src/features/dashboard/hooks/use-dashboard-tabs';
import { useTranslation } from 'react-i18next';
import { Pressable, useWindowDimensions } from 'react-native';

import { dashboardTabIndexMap, initialDashboardTab } from './constants';
import { DashboardTabs } from './dashboard-screen';

type TabState = TabNavigationState<DashboardTabs>;
type RouteName = TabState['routes'][number]['name'];

type DashboardTabBarProps = {
  state: TabState;
  onTabPress: () => void;
};

export const DashboardTabBar = ({
  state,
  onTabPress,
}: DashboardTabBarProps) => {
  const { trackUserEvent } = useAnalytics();
  const initialTabIndex = useSelector(initialDashboardTab);
  const { width: windowWidth } = useWindowDimensions();
  const { animatedStyles, animateTabSelection } = useTabAnimation(
    initialTabIndex,
    tabWidthCalculator(windowWidth, 3)
  );

  const { t } = useTranslation();
  const { navigate } = useDashboardTabsNavigation();

  const { routes, index: selectedIndex } = state;
  const routesLength = routes.length;

  const handleTabSelect = (tabIndex: number, routeName: RouteName) => {
    onTabPress();
    animateTabSelection(tabIndex);
    navigate(routeName);
    trackUserEvent(dashboardTabIndexMap[tabIndex].analyticsEvent);
  };

  return (
    <PillTabBar animatedStyles={animatedStyles}>
      {routes.map(({ key, name }, index) => {
        const handlePress = () => handleTabSelect(index, name);
        return (
          <Pressable
            accessible
            accessibilityRole="tab"
            accessibilityLabel={tabAccessibilityLabel(
              t,
              index + 1,
              name,
              routesLength
            )}
            accessibilityState={{ selected: selectedIndex === index }}
            key={key}
            testID={`${name} tab`}
            onPress={handlePress}
            style={{
              flex: 1,
              alignItems: 'center',
              justifyContent: 'center',
              padding: getVariableValue(getTokens().space.lg),
            }}
          >
            <Text
              tamaguiTextProps={{ numberOfLines: 1 }}
              fontVariant="body-semibold-Secondary900"
            >
              {name}
            </Text>
          </Pressable>
        );
      })}
    </PillTabBar>
  );
};
