import { observable } from '@legendapp/state';

import {
  INSURANCE_TAB_TAPPED,
  RETIREMENT_TAB_TAPPED,
  WEALTH_TAB_TAPPED,
} from './analytics';
import { DashboardTabs } from './dashboard-screen';

export const initialDashboardTab = observable(0);
export const dashboardCantSeeMyPolicyShown = observable<boolean>(false);

export const dashboardTabIndexMap: {
  [key in number]: {
    analyticsEvent: string;
    screenName: keyof DashboardTabs;
  };
} = {
  0: { analyticsEvent: INSURANCE_TAB_TAPPED, screenName: 'Insurance' },
  1: { analyticsEvent: WEALTH_TAB_TAPPED, screenName: 'Wealth' },
  2: { analyticsEvent: RETIREMENT_TAB_TAPPED, screenName: 'Retirement' },
} as const;

export const DIRECT_WEALTH_PRODUCT_CODES = ['80103', '80105', '80106', '80107'];
