import {
  Dialog,
  getTokens,
  getVariableValue,
  ScrollView,
  Stack,
  YStack,
} from '@aviva/ion-mobile';
import { LinkWithIcon } from '@aviva/ion-mobile/components/link-with-icon';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useAnalytics } from '@hooks/use-analytics';
import { useMyDriveCustomer } from '@hooks/use-mydrive-customer';
import { useMyDriveOnwardJourney } from '@hooks/use-mydrive-onward-journey-creator';
import { useRecommendations } from '@hooks/use-recommendations';
import { useRemoteFeatureFlag } from '@hooks/use-remote-feature-flag';
import { useScrollToPosition } from '@hooks/use-scroll-to-position';
import { useSelector } from '@legendapp/state/react';
import {
  createNavigatorFactory,
  DefaultNavigatorOptions,
  TabActionHelpers,
  TabNavigationState,
  TabRouter,
  TabRouterOptions,
  useNavigationBuilder,
} from '@react-navigation/native';
import { useAccessibility } from '@src/common/providers/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Platform, Pressable } from 'react-native';
import Animated from 'react-native-reanimated';
import { SafeAreaView } from 'react-native-safe-area-context';

import {
  CANT_SEE_MY_INSURANCE_TAPPED,
  CANT_SEE_MY_RETIREMEMENT_POLICY_TAPPED,
  CANT_SEE_MY_WEALTH_POLICY_TAPPED,
} from './analytics';
import { DashboardHeader } from './components/dashboard-header';
import { MoreForYou } from './components/more-for-you';
import { PromotionalOffers } from './components/promotional-offers';
import { YourTools } from './components/your-tools/your-tools';
import { dashboardCantSeeMyPolicyShown } from './constants';
import { DashboardTabs } from './dashboard-screen';
import { DashboardTabBar } from './dashboard-tab-bar';
import { useDashboardTheme } from './hooks/use-dashboard-theme';
import { useMoreForYouData } from './hooks/use-more-for-you';
import { TakeControlOfYourWealth } from './screen/wealth/components/take-control-of-your-wealth';

type TabNavigationOptions = {
  title?: string;
};

type TabNavigationEventMap = {
  tabPress: {
    data: { isAlreadyFocused: boolean };
    canPreventDefault: true;
  };
};

type DashboardTabNavigatorProps = DefaultNavigatorOptions<
  DashboardTabs,
  TabNavigationState<DashboardTabs>,
  TabNavigationOptions,
  TabNavigationEventMap
>;

const DashboardTabNavigator = ({
  initialRouteName,
  children,
}: DashboardTabNavigatorProps) => {
  const tokens = getTokens();
  const { elementRef, focus } = useA11yFocus();
  const { data, isSuccess } = useRecommendations();
  const { headerAnimatedStyle, tabAnimatedStyle } = useDashboardTheme();
  const moreForYouData = useMoreForYouData();
  const { state, descriptors, NavigationContent, navigation } =
    useNavigationBuilder<
      TabNavigationState<DashboardTabs>,
      TabRouterOptions,
      TabActionHelpers<DashboardTabs>,
      TabNavigationOptions,
      TabNavigationEventMap
      // @ts-expect-error TabRouter expects a string, we're specifying DashboardTabs
    >(TabRouter, {
      children,
      initialRouteName,
    });
  const cantSeeMyPolicyTagMap: Record<number, string> = {
    0: CANT_SEE_MY_RETIREMEMENT_POLICY_TAPPED,
    1: CANT_SEE_MY_WEALTH_POLICY_TAPPED,
    2: CANT_SEE_MY_INSURANCE_TAPPED,
  } as const;
  const showCantSeeMyPolicy = useSelector(dashboardCantSeeMyPolicyShown);
  const [showNotifications, setShowNotifications] = useState<boolean>(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { t } = useTranslation();
  const { trackUserEvent } = useAnalytics();
  const { getOnwardJourney } = useMyDriveOnwardJourney();
  const { isScreenReaderEnabled } = useAccessibility();
  const { scrollToRef, scrollToPosition } = useScrollToPosition();
  const { isMyDriveActive, isMyDriveEligible } = useMyDriveCustomer();

  const { value: dwInMangaEnabled } = useRemoteFeatureFlag(
    'release-myaviva-direct-wealth-in-manga'
  );

  const handleOnToggleNotifications = () => {
    setShowNotifications(!showNotifications);
  };

  const handleSetShowNotifications = () => {
    setShowNotifications(false);
    focus();
  };

  const onPress = () => {
    trackUserEvent(cantSeeMyPolicyTagMap[state.index]);
    navigation.navigate(`Missing Product Screen`);
  };

  const closeDialog = () => setIsDialogOpen(false);

  const stickyHeaderIndices = !isScreenReaderEnabled ? [2] : undefined;

  return (
    <>
      <NavigationContent>
        <AnimatedSafeAreaView edges={['top']} style={headerAnimatedStyle} />

        <ScrollView
          ref={scrollToRef}
          bounces={false}
          stickyHeaderIndices={stickyHeaderIndices}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{
            backgroundColor: getVariableValue(tokens.color.$Gray100),
            paddingBottom:
              Platform.OS === 'android' ? getTokens().size[8].val : 0,
          }}
        >
          <DashboardHeader
            showNotifications={showNotifications}
            setShowNotifications={handleSetShowNotifications}
          />
          <Pressable
            ref={elementRef}
            accessibilityRole="button"
            accessibilityLabel={
              showNotifications
                ? t('productDashboard.hideNotifications')
                : t('productDashboard.showNotifications')
            }
            onPress={handleOnToggleNotifications}
            testID={getTestId('toggle-notifications')}
          >
            <AnimatedStack
              style={tabAnimatedStyle}
              pt="$lg"
              pb="$md"
              ai="center"
            >
              <Stack bc="$Gray050" o={0.3} h={4} w={40} br="$12" />
            </AnimatedStack>
          </Pressable>
          <DashboardTabBar state={state} onTabPress={scrollToPosition} />

          {state.routes.map((route, index) => {
            const isCurrentRoute = index === state.index;

            return (
              <Stack key={route.key} display={isCurrentRoute ? 'flex' : 'none'}>
                {descriptors[route.key].render()}
              </Stack>
            );
          })}

          {showCantSeeMyPolicy && (
            <LinkWithIcon
              linkText={t('common.cantSeePolicy')}
              accessibilityHint={t(
                'dashboardTabNavigator.linkWithIcon.accessibilityHint'
              )}
              onPress={onPress}
              mx="$xl"
              mt={0}
              mb="$xxl"
            />
          )}
          {!!dwInMangaEnabled && state.routeNames[state.index] === 'Wealth' && (
            <YStack marginTop={showCantSeeMyPolicy ? undefined : '$xl'}>
              <TakeControlOfYourWealth isWealthHub={false} />
            </YStack>
          )}

          {state.routeNames[state.index] === 'Insurance' &&
            isMyDriveEligible && (
              <YourTools
                isMyDriveActive={isMyDriveActive}
                setShowInternetDialog={setIsDialogOpen}
              />
            )}

          {isSuccess && (
            <PromotionalOffers
              offers={data.recommendations.DashboardRecommendations}
              tab={state.routeNames[state.index]}
            />
          )}
          <MoreForYou data={moreForYouData} />
        </ScrollView>
      </NavigationContent>
      <Dialog
        open={isDialogOpen}
        title={t('common.noInternetConnectionDialog.title')}
        copy={t('common.noInternetConnectionDialog.copy')}
        actions={[
          {
            title: 'Retry',
            actionOnPress: () => {
              getOnwardJourney();
            },
          },
        ]}
        cancelButton
        onPressCancel={closeDialog}
      />
    </>
  );
};

export const createDashboardTabNavigator = createNavigatorFactory<
  TabNavigationState<DashboardTabs>,
  TabNavigationOptions,
  TabNavigationEventMap,
  typeof DashboardTabNavigator
>(DashboardTabNavigator);
const AnimatedSafeAreaView = Animated.createAnimatedComponent(SafeAreaView);

const AnimatedStack = Animated.createAnimatedComponent(Stack);
