import { webLinks } from '@constants/web-links';
import { WebViewComponent } from '@src/components/web-view';

export const MissingProductScreen = () => {
  return (
    <WebViewComponent ssoEnabled source={{ uri: webLinks.missingPolicy }} />
  );
};
