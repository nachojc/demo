import { Stack, styled } from '@aviva/ion-mobile';

const DeleteConfirmationContainer = styled(Stack, {
  px: '$lg',
  py: '$xxxl',
  bc: '$Gray100',
  jc: 'space-between',
  h: '100%',
});

export { DeleteConfirmationContainer };
