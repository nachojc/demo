import { LoadingKeys } from '@aviva/ion-mobile';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAccount } from '@hooks/use-account';
import { useAnalytics } from '@hooks/use-analytics';
import { isManga } from '@hooks/use-expo-config';
import { useMyDriveCustomer } from '@hooks/use-mydrive-customer';
import { useResetSignOut } from '@hooks/use-reset-sign-out';
import { useMyDriveDeactivation } from '@src/features/mydrive/deactivation/use-mydrive-deactivation';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { MoreScreenNames } from '@src/navigation/app/summary/more-screen-names';
import {
  DeleteAccountForm,
  DeleteAccountFormSchema,
} from '@src/validation/schemas/deleteAccount';
import { useCallback, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Alert } from 'react-native';

import {
  PAGE_SETTINGS_DELETE_ACCOUNT_BUFFER_DELETE_ACCOUNT_TAPPED,
  PAGE_SETTINGS_DELETE_ACCOUNT_NO_TAPPED,
  PAGE_SETTINGS_DELETE_ACCOUNT_REQUEST_SENT_CLOSE_TAPPED,
  PAGE_SETTINGS_DELETE_ACCOUNT_SUBMIT_TAPPED,
  PAGE_SETTINGS_DELETE_ACCOUNT_YES_TAPPED,
} from './analytics';

type DefaultFormValues = Omit<DeleteAccountForm, 'hasPreferredTime'> & {
  hasPreferredTime?: boolean;
};

export const useDeleteAccountViewModel = () => {
  const { sendDeleteAccountRequest } = useAccount();
  const { resetSignOut } = useResetSignOut();
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const submitLockRef = useRef(false);
  const { deactivateMyDrive } = useMyDriveDeactivation();
  const { isMyDriveActive } = useMyDriveCustomer();

  const [loadingDialog, setLoadingDialog] = useState({
    show: false,
    message: 'oneMoment' as LoadingKeys,
  });

  const defaultValues: DefaultFormValues = {
    phoneNumber: {
      number: '',
      country: {
        code: '+44',
        name: 'United Kingdom',
      },
    },
    hasPreferredTime: undefined,
    message: '',
  };

  const form = useForm<DeleteAccountForm>({
    resolver: zodResolver(DeleteAccountFormSchema),
    defaultValues,
  });

  const handleModalNavigation = () => {
    trackUserEvent(PAGE_SETTINGS_DELETE_ACCOUNT_BUFFER_DELETE_ACCOUNT_TAPPED);
    navigate(MoreScreenNames.DeleteModal);
  };

  const handleConfirmationNavigation = () => {
    trackUserEvent(PAGE_SETTINGS_DELETE_ACCOUNT_SUBMIT_TAPPED);
    navigate(MoreScreenNames.DeleteConfirmation);
  };

  const handleCloseNavigation = () => {
    trackUserEvent(PAGE_SETTINGS_DELETE_ACCOUNT_REQUEST_SENT_CLOSE_TAPPED);
    resetSignOut(false);
  };

  const optionYesCommand = () => {
    trackUserEvent(PAGE_SETTINGS_DELETE_ACCOUNT_YES_TAPPED);
  };

  const optionNoCommand = () => {
    trackUserEvent(PAGE_SETTINGS_DELETE_ACCOUNT_NO_TAPPED);
  };

  const changeLoadingDialog = useCallback(
    (show?: boolean, message?: LoadingKeys) => {
      setLoadingDialog({
        show: show ?? loadingDialog.show,
        message: message ?? loadingDialog.message,
      });
    },
    [loadingDialog]
  );

  const onSubmit = async (formData: DeleteAccountForm) => {
    //lock user to prevent multiple taps on submit button
    if (submitLockRef.current) {
      return;
    }

    submitLockRef.current = true;
    changeLoadingDialog(true);

    try {
      if (isManga() && isMyDriveActive) {
        await deactivateMyDrive();
      }

      if (!formData.hasPreferredTime) {
        await sendDeleteAccountRequest.mutateAsync({
          phoneNumber: formData.phoneNumber,
          hasPreferredTime: false,
          message: '',
        });
      } else {
        await sendDeleteAccountRequest.mutateAsync(formData);
      }
      handleConfirmationNavigation();
    } catch (e) {
      Alert.alert(
        'Delete online account',
        "We're sorry, something went wrong. Please try again.",
        [
          {
            text: 'OK',
            style: 'cancel',
          },
        ]
      );
    } finally {
      changeLoadingDialog(false);
      submitLockRef.current = false;
    }
  };

  return {
    form,
    onSubmit,
    handleModalNavigation,
    handleConfirmationNavigation,
    handleCloseNavigation,
    optionYesCommand,
    optionNoCommand,
    loadingDialog,
    isSubmitting: loadingDialog.show || form.formState.isSubmitting,
    isMyDriveActive,
    isManga,
  };
};
