import { Button, Image, Text, YStack } from '@aviva/ion-mobile';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { tokens } from '@theme/tokens';

import { PAGE_SETTINGS_DELETE_ACCOUNT_REQUEST_CALLBACK_REQUEST_SENT } from './analytics';
import { DeleteConfirmationContainer } from './styles';
import { useDeleteAccountViewModel } from './use-delete-account-view-model';

type DeleteConfirmationModelProps = {
  model: ReturnType<typeof useDeleteAccountViewModel>;
};

export const DeleteConfirmationView = ({
  model,
}: DeleteConfirmationModelProps) => {
  const { handleCloseNavigation } = model;

  useOnPageLoad({
    pageTag: PAGE_SETTINGS_DELETE_ACCOUNT_REQUEST_CALLBACK_REQUEST_SENT,
  });

  return (
    <DeleteConfirmationContainer>
      <YStack tablet={isIpad} jc={'center'} flex={1} space="$xxl">
        <Image
          accessibilityIgnoresInvertColors
          source={require('assets/envelope.png')}
          resizeMode="contain"
          style={{
            height: tokens.size[12].val,
            width: tokens.size[12].val,
            alignSelf: 'center',
          }}
        />
        <Text
          fontVariant="heading5-semibold-Secondary800"
          tamaguiTextProps={{
            alignSelf: 'center',
            testID: getTestId('sipp-delete-account-delete-confirmation'),
          }}
        >
          We&apos;ve got your request.
        </Text>
        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{
            textAlign: 'center',
          }}
          testID={getTestId('sipp-delete-account-delete-confirmation-two')}
        >
          We&apos;ll be in touch soon to complete it.
        </Text>
      </YStack>
      <YStack tabletNarrow={isIpad} pb={isIpad ? '$xxxxl' : undefined}>
        <Button
          onPress={handleCloseNavigation}
          testID={getTestId('sipp-delete-account-close-nav')}
        >
          Close
        </Button>
      </YStack>
    </DeleteConfirmationContainer>
  );
};

export const DeleteConfirmationScreen = () => {
  const model = useDeleteAccountViewModel();
  return <DeleteConfirmationView model={model} />;
};
