import {
  Button,
  LoadingState,
  ScrollView,
  styled,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect } from 'react';
import { Dimensions, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import {
  PAGE_SETTINGS_DELETE_ACCOUNT_BACK_TAPPED,
  PAGE_SETTINGS_DELETE_ACCOUNT_REQUEST_CALLBACK,
} from './analytics';
import {
  DeletePageTitle,
  DeleteTextArea,
  HasPreferredTimeToggle,
  PhoneNumberInput,
} from './delete-account-modal/index';
import { useDeleteAccountViewModel } from './use-delete-account-view-model';

type DeleteAccountModalProps = {
  model: ReturnType<typeof useDeleteAccountViewModel>;
};

export const DeleteAccountModalView = ({ model }: DeleteAccountModalProps) => {
  const { form, onSubmit, optionYesCommand, optionNoCommand, isSubmitting } =
    model;
  const { handleSubmit, control, watch, trigger } = form;
  const { addListener } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();

  //TODO: Currently we are unable to test this due to how ReactNative mocks the navigation. Issue for this raised in MANGA-3469.
  useEffect(() => {
    const unsubscribe = addListener('beforeRemove', (e) => {
      if (e.data.action.type === 'GO_BACK') {
        trackUserEvent(PAGE_SETTINGS_DELETE_ACCOUNT_BACK_TAPPED);
      }
    });
    return unsubscribe;
  }, [addListener, trackUserEvent]);

  useOnPageLoad({ pageTag: PAGE_SETTINGS_DELETE_ACCOUNT_REQUEST_CALLBACK });

  const [hasPreferredTime, message] = watch(['hasPreferredTime', 'message']);

  const screenHeight =
    Dimensions.get('window').height - useSafeAreaInsets().top - 35;

  return (
    <KeyboardAvoidingView style={{ flex: 1 }}>
      <ScrollView automaticallyAdjustKeyboardInsets>
        <YStack height={isIpad ? screenHeight : undefined} tablet={isIpad}>
          <ContainerView>
            <YStack>
              {isSubmitting && (
                <LoadingState text={model.loadingDialog.message} />
              )}
              <DeletePageTitle />
              <PhoneNumberInput control={control} />
              <HasPreferredTimeToggle
                control={control}
                optionYesCommand={optionYesCommand}
                optionNoCommand={optionNoCommand}
              />
              {hasPreferredTime && (
                <DeleteTextArea
                  control={control}
                  message={message}
                  trigger={trigger}
                />
              )}
            </YStack>
            {
              <YStack pb={isIpad ? '$xxxxl' : undefined} tabletNarrow={isIpad}>
                <Button
                  onPress={handleSubmit(onSubmit)}
                  testID={getTestId('sipp-delete-account-submit-btn')}
                >
                  Submit
                </Button>
              </YStack>
            }
          </ContainerView>
        </YStack>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const ContainerView = styled(YStack, {
  px: '$lg',
  space: '$xxl',
  py: '$xxl',
  flex: 1,
  jc: 'space-between',
});

export const DeleteAccountModal = () => {
  const model = useDeleteAccountViewModel();
  return <DeleteAccountModalView model={model} />;
};
