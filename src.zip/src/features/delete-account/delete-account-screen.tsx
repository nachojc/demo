import { Button, NotificationCard, Text, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { ScrollableScreen } from '@src/components/scrollable-screen';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect } from 'react';

import {
  PAGE_SETTINGS_DELETE_ACCOUNT,
  PAGE_SETTINGS_DELETE_ACCOUNT_BUFFER_BACK_TAPPED,
} from './analytics';
import { useDeleteAccountViewModel } from './use-delete-account-view-model';

type DeleteAccountViewProps = {
  model: ReturnType<typeof useDeleteAccountViewModel>;
};

const DisableMyDriveNotificationContent = () => {
  return (
    <YStack>
      <Text fontVariant="body-regular-Gray800" tamaguiTextProps={{ mb: '$xl' }}>
        We notice you have MyDrive active on your account. If you delete your
        online account, we’ll also have to disable MyDrive. This will mean you
        won’t be able to see your previous journeys and driving scores, and if
        you haven’t met the discount eligibility requirements, we won’t be able
        to give you a potential renewal discount.
      </Text>
      <Text fontVariant="body-regular-Gray800">
        Once disabled, we will no longer be able to record your journeys or
        monitor your driving behaviours, even if your in-app tracking
        permissions are still enabled. However, if you wish to remove your
        in-app tracking permissions, you can do this in your device’s settings
        by clicking on the MyAviva app &gt; Privacy.
      </Text>
    </YStack>
  );
};

export const DeleteAccountView = ({ model }: DeleteAccountViewProps) => {
  const { handleModalNavigation } = model;
  const { addListener } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();

  //TODO: Currently we are unable to test this due to how ReactNative mocks the navigation. Issue for this raised in MANGA-3469.
  useEffect(() => {
    const unsubscribe = addListener('beforeRemove', () => {
      trackUserEvent(PAGE_SETTINGS_DELETE_ACCOUNT_BUFFER_BACK_TAPPED);
    });
    return unsubscribe;
  }, [addListener, trackUserEvent]);

  useOnPageLoad({ pageTag: PAGE_SETTINGS_DELETE_ACCOUNT });

  return (
    <ScrollableScreen>
      <YStack
        jc={isIpad ? 'space-between' : undefined}
        flex={1}
        tablet={isIpad}
        px="$xl"
      >
        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{ mb: '$lg' }}
          testID={getTestId('sipp-delete-account-deletion-text')}
        >
          You&apos;ll no longer be able to view or make changes to your policies
          online. Instead, you&apos;ll get your policy information by post, or
          email if you prefer, and you&apos;ll need to call us to make any
          changes.
        </Text>
        {model.isManga() && model.isMyDriveActive && (
          <NotificationCard
            iconVariant="error"
            subtitle={DisableMyDriveNotificationContent()}
          />
        )}
        <YStack pb={isIpad ? '$xxxxl' : undefined} tabletNarrow={isIpad}>
          <Button
            onPress={handleModalNavigation}
            testID={getTestId('sipp-delete-account-deletion-btn')}
            mt="$lg"
          >
            Delete online account
          </Button>
        </YStack>
      </YStack>
    </ScrollableScreen>
  );
};

export const DeleteAccountScreen = () => {
  const model = useDeleteAccountViewModel();
  return <DeleteAccountView model={model} />;
};
