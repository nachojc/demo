import {
  Button,
  ButtonVariant,
  LoadingState,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { Alert } from '@aviva/ion-mobile/components/alert';
import { FormInput } from '@components/forms/form-input';
import { YStackPixelRatio } from '@src/components/ystack-text-ratio';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect } from 'react';
import { Pressable } from 'react-native';

import { DialogTimeout } from './components/dialogs/dialog-timeout';
import { useLoginViewModel } from './use-login-view-model';

type LoginScreenViewProps = { model: ReturnType<typeof useLoginViewModel> };

export const LoginScreenView = ({ model }: LoginScreenViewProps) => {
  const { handleSubmit, control, formState, setFocus } = model.form;

  const loginDisabled = !formState.isValid || model.isSigningIn;

  useEffect(() => model.removeSessionCookies, [model.removeSessionCookies]);

  return (
    <>
      <Alert {...model.showAlertError} />
      <YStackPixelRatio
        px={'$xl'}
        py={'$xxxl'}
        jc="space-between"
        h="100%"
        tablet={isIpad}
      >
        {model.isSigningIn && <LoadingState fullscreen text="loggingIn" />}
        <YStack>
          <FormInput
            control={control}
            name="username"
            label="Email address or username"
            placeholder="Enter username"
            type="text"
            disableErrors
            tamaguiInputProps={{
              returnKeyType: 'next',
              onSubmitEditing: () => setFocus('password'),
              autoCapitalize: 'none',
            }}
          />
          <FormInput
            control={control}
            name="password"
            label="Password"
            placeholder="Enter password"
            type="password"
            disableErrors
            textContentType="password"
            tamaguiInputProps={{
              autoComplete: !model.hasAlertPreviouslyOpened
                ? 'current-password'
                : 'new-password',
            }}
          />
        </YStack>
        <YStack px="$xl" tabletNarrow={isIpad}>
          <XStack alignContent="center" alignItems="baseline">
            <Text
              fontVariant="small-regular-Gray800"
              tamaguiTextProps={{ marginBottom: '$xl' }}
            >
              By logging in you agree to our{' '}
            </Text>
            <Pressable
              hitSlop={12}
              accessibilityRole="link"
              onPress={model.navigateToTermsOfUseScreen}
              testID={getTestId('terms-of-use-link')}
            >
              <Text fontVariant="small-semibold-Tertiary800">terms of use</Text>
            </Pressable>
          </XStack>
          <YStack tabletNarrow={isIpad} pb={isIpad ? '$xxl' : undefined}>
            <Button
              disabled={loginDisabled}
              onPress={handleSubmit(model.onSubmit)}
              accessibilityLabel="log in"
              testID={getTestId('login-button')}
            >
              {'Log in'}
            </Button>
            <Button
              variant={ButtonVariant.LINK_TEXT}
              onPress={model.navigateToForgottenDetailsScreen}
              accessibilityLabel="forgot your details"
            >
              {'Forgot your details?'}
            </Button>
          </YStack>
        </YStack>
      </YStackPixelRatio>
      <DialogTimeout />
    </>
  );
};

export const LoginScreen = () => {
  const model = useLoginViewModel();
  return <LoginScreenView model={model} />;
};
