import { APP_BASE } from '@constants/analytics';

export const PAGE_LOGIN = APP_BASE + 'login';

export const ACTION_LOGIN_CLICKED = PAGE_LOGIN + '|login-in-tapped';
export const ACTION_LOGIN_TERMS_CLICKED =
  APP_BASE + 'register|terms-of-use-tapped';
export const ACTION_LOGIN_FORGOTTEN_DETAILS_CLICKED =
  PAGE_LOGIN + '|forgotten-details-tapped';
