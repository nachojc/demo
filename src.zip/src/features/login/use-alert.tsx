import { AlertProps } from '@aviva/ion-mobile/components/alert';
import { useRef, useState } from 'react';

import { LoginAlertProps } from './common';

type SetAlertError = (loginAlertProps: LoginAlertProps) => void;

type UseAlertReturn = {
  alertError?: AlertProps;
  /**
   * hasAlertPreviouslyOpened is set to false by default
   *
   * Tracks if an Alert has ever opened.
   * Currently used on the Login screen to change the autoComplete prop
   * for errors relating to credentials
   */
  hasAlertPreviouslyOpened: boolean;
  setAlertError: SetAlertError;
};

/**
 * Hook to handle Alerts
 * @returns {UseAlertReturn}
 */
export const useAlert = (): UseAlertReturn => {
  const previouslyOpenedRef = useRef(false);
  const [alert, setAlert] = useState<AlertProps>();

  const setAlertError: SetAlertError = ({
    shouldReportOpened,
    ...alertProps
  }) => {
    if (shouldReportOpened) {
      previouslyOpenedRef.current = true;
    }

    setAlert(alertProps);
  };

  return {
    alertError: alert,
    hasAlertPreviouslyOpened: previouslyOpenedRef.current,
    setAlertError,
  };
};
