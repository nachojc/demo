import { AlertProps } from '@aviva/ion-mobile/components/alert';
import { webLinks } from '@constants/web-links';
import { zodResolver } from '@hookform/resolvers/zod';
import { useActiveAppEffect } from '@hooks/use-active-app-effect';
import { useAnalytics } from '@hooks/use-analytics';
import { useAuth } from '@hooks/use-auth';
import { useAutoSignInGuestUser } from '@hooks/use-auto-sign-in-guest-user';
import { useBiometrics } from '@hooks/use-biometrics';
import { CUSTOMER_QUERY_KEY } from '@hooks/use-customer';
import { useDisableGoBack } from '@hooks/use-disable-go-back';
import { isManga } from '@hooks/use-expo-config';
import { useMfa } from '@hooks/use-mfa';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useRemoteFeatureFlag } from '@hooks/use-remote-feature-flag';
import { useStartUpAction } from '@hooks/use-startup-action';
import { getLogger } from '@interfaces/logger';
import { refreshToken } from '@interfaces/secure-store';
import { username as usernameObs } from '@interfaces/storage';
import { useObserve, useSelector } from '@legendapp/state/react';
import CookieManager from '@react-native-cookies/cookies';
import { handleCustomerError } from '@src/features/login/utils/handle-customer-error';
import { handleLoginError } from '@src/features/login/utils/handle-login-error';
import { GET_CUSTOMER_PATH } from '@src/models/customer';
import {
  NewPassword,
  ShouldNotAutoSignIn,
  Timeout,
} from '@src/navigation/auth';
import {
  useAuthStackNavigation,
  useAuthStackRoute,
} from '@src/navigation/auth/hooks';
import { getGenericErrorMessage } from '@src/utils';
import {
  Credentials,
  CredentialsSchema,
} from '@src/validation/schemas/credentials';
import { Customer } from '@src/validation/schemas/customer';
import { useQueryClient } from '@tanstack/react-query';
import { isAxiosError } from 'axios';
import { useCallback, useEffect, useRef, useState } from 'react';
import { useForm } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { AppState, Platform } from 'react-native';

import {
  ACTION_LOGIN_CLICKED,
  ACTION_LOGIN_FORGOTTEN_DETAILS_CLICKED,
  ACTION_LOGIN_TERMS_CLICKED,
  PAGE_LOGIN,
} from './analytics';
import { useAlert } from './use-alert';

const log = getLogger(useLoginViewModel.name);
const LoginFormResolver = zodResolver(CredentialsSchema);

const useCredentialsForm = useForm<Credentials>;
export type UseCredentialsForm = ReturnType<typeof useCredentialsForm>;

export function useLoginViewModel() {
  const analytics = useAnalytics();
  const { navigate, reset } = useAuthStackNavigation();
  const [isSigningIn, setIsSigningIn] = useState(false);
  const { signIn, biometricSignIn, signInWithRefreshToken, signOut } =
    useAuth();
  const { isMfaUnderMaintenance } = useMfa();
  const startUpAction = useStartUpAction();
  const queryClient = useQueryClient();
  const { t } = useTranslation(undefined, {
    keyPrefix: 'welcome.enquirerErrorDialog',
  });
  const form = useCredentialsForm({
    resolver: LoginFormResolver,
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const { alertError, hasAlertPreviouslyOpened, setAlertError } = useAlert();

  useObserve(usernameObs, ({ value }) => {
    if (value) {
      form.setValue('username', value);
    }
  });

  useDisableGoBack(isSigningIn);

  useOnPageLoad({ pageTag: PAGE_LOGIN });

  const navigateToForgottenDetailsScreen = () => {
    analytics.trackUserEvent(ACTION_LOGIN_FORGOTTEN_DETAILS_CLICKED);
    navigate('Forgotten your details');
  };

  const navigateToAccountLockedScreen = () => {
    navigate('Account Locked');
  };

  const navigateToDeceasedCustomerScreen = () => {
    navigate('Deceased customer');
  };

  const onSubmit = async (formValues: Credentials) => {
    handleSignIn(formValues, false);
  };

  const navigateToTermsOfUseScreen = () => {
    analytics.trackUserEvent(ACTION_LOGIN_TERMS_CLICKED);
    navigate('Terms of Use');
  };

  /**
   * @description
   * In biometrics we only want to show the loading spinner after
   * signInWithRefreshToken initiates the native biometrics prompt
   * @see {@link https://jira.aviva.co.uk/browse/MANGA-10763}
   */
  const sendSignInRequest = async (
    formValues: Credentials,
    isUsingBiometrics?: boolean
  ) => {
    if (isUsingBiometrics) {
      return biometricSignIn().then((res) => {
        setIsSigningIn(true);
        return signInWithRefreshToken(formValues.username, res.biometricResult);
      });
    }

    setIsSigningIn(true);
    return signIn(formValues);
  };

  const { value: dwInMangaEnabled } = useRemoteFeatureFlag(
    'release-myaviva-direct-wealth-in-manga'
  );

  const handleSignIn = async (
    formValues: Credentials,
    isUsingBiometrics?: boolean
  ) => {
    try {
      const signInRequest = await sendSignInRequest(
        formValues,
        isUsingBiometrics
      );

      const currentCustomer = queryClient.getQueryData<Customer>([
        CUSTOMER_QUERY_KEY,
      ]);

      const isCustomerDPALevel2 = currentCustomer?.CustomerDPALevel === '2';

      if (currentCustomer?.IsEnquirer) {
        if (!isManga() && !isCustomerDPALevel2) {
          navigateToDeceasedCustomerScreen();
          setIsSigningIn(false);
          await signOut();
          return;
        } else if (isManga() && (!dwInMangaEnabled || !isCustomerDPALevel2)) {
          setAlertError({
            open: true,
            title: t('title'),
            message: t('description'),
          });
          return;
        }
      }

      analytics.trackUserEvent(ACTION_LOGIN_CLICKED, {
        accounttype: 'myaviva',
      });

      switch (signInRequest.biometricResult) {
        case 'Lockout':
          setAlertError({
            open: true,
            title: 'Biometric authentication has been disabled on your device.',
            message:
              'Please lock and then unlock your device to reset. You can still log in using your username and password.',
            sendAnalytics: true,
          });
          return;
        case 'Changed':
          setAlertError({
            open: true,
            title:
              'The credentials associated with your biometrics are out of date',
            message: 'Please log in using your current username and password.',
            sendAnalytics: true,
          });
          return;
        case 'Fail':
          setAlertError({
            open: true,
            title: 'Biometric fail',
            message: 'Please log in using your current username and password.',
            sendAnalytics: true,
          });
          return;
        case 'UserCancel':
        case 'SystemCancel':
        case 'Timeout':
          return;
        default:
          break;
      }

      if (signInRequest.requiresMfa && !isMfaUnderMaintenance) {
        log.debug('Requires MFA login');
        navigate('Log in - MFA');
        return;
      }

      await startUpAction.navigateToNextStartUpAction();
    } catch (error) {
      if (isAxiosError(error)) {
        let err: AlertProps | undefined | void;
        if (error?.config?.url === GET_CUSTOMER_PATH) {
          err = handleCustomerError({
            error,
            navigation: { navigate, reset },
            credentials: formValues,
          });
        } else {
          err = handleLoginError({ error, navigate });
        }
        setAlertError(
          err ? { ...err, open: true, sendAnalytics: true } : { open: false }
        );
      } else {
        const genericError = getGenericErrorMessage();
        setAlertError({
          ...genericError,
          open: true,
          sendAnalytics: true,
          buttons: [
            { text: 'OK' },
            {
              variant: 'linkText',
              text: 'Contact Us',
              onPress: () => navigate('Web View', { url: webLinks.contactUs }),
            },
          ],
        });
      }

      log.zodError(error);
    } finally {
      setIsSigningIn(false);
    }
  };

  useAutoSignInUser({ form, handleSignIn });
  useAutoSignInGuestUser({ handleSignIn });

  const removeSessionCookies = useCallback(() => {
    if (Platform.OS === 'android') {
      /* async */ CookieManager.removeSessionCookies();
    }
  }, []);

  return {
    handleSignIn,
    hasAlertPreviouslyOpened,
    onSubmit,
    isSigningIn: isSigningIn || form.formState.isSubmitting,
    form,
    navigateToForgottenDetailsScreen,
    navigateToAccountLockedScreen,
    navigateToDeceasedCustomerScreen,
    navigateToTermsOfUseScreen,
    removeSessionCookies,
    showAlertError: {
      onClose: () => {
        setAlertError({ open: false });
      },
      ...alertError,
    },
  };
}

export function useAutoSignInUser({
  form,
  handleSignIn,
}: {
  form: UseCredentialsForm;
  handleSignIn: (
    credentials: Credentials,
    isUsingBiometrics?: boolean
  ) => Promise<void>;
}) {
  const { params = { newPassword: '', hasRecoveredUsername: false } } =
    useAuthStackRoute<'Log in'>();
  const { newPassword } = params as NewPassword;
  const { isTimeout } = params as Timeout;
  const { shouldNotAutoSignIn } = params as ShouldNotAutoSignIn;
  const hasCalledAutoSignIn = useRef(false);
  const biometrics = useBiometrics();

  const username = useSelector(usernameObs);

  const attemptSignIn = useCallback(async () => {
    hasCalledAutoSignIn.current = true;
    if (!username) {
      form.setValue('username', '');
      return;
    }

    form.setValue('username', username);

    if (newPassword) {
      // Handle change password
      await handleSignIn({ username, password: newPassword });
    } else if (biometrics.isEnabled && refreshToken.get()) {
      // Handle biometric login
      await handleSignIn({ username, password: '' }, biometrics.isEnabled);
    }
  }, [biometrics.isEnabled, form, handleSignIn, newPassword, username]);

  const login = useCallback(() => {
    if (
      isTimeout ||
      hasCalledAutoSignIn.current ||
      AppState.currentState !== 'active' ||
      shouldNotAutoSignIn
    ) {
      return;
    }
    attemptSignIn();
  }, [attemptSignIn, isTimeout, shouldNotAutoSignIn]);

  //To handle if the app has been awoken in the background and therefore the app has not attempted a login yet
  useActiveAppEffect(() => {
    login();
  });

  useEffect(() => {
    login();
  }, [login]);
}
