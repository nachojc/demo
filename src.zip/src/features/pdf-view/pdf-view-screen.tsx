import {
  Button,
  ButtonVariant,
  Dialog,
  getTokens,
  getVariableValue,
  LoadingState,
  Stack,
  TopAppBarDW,
  TopAppBarManga,
} from '@aviva/ion-mobile';
import {
  PDF_ERROR_DIALOG_BODY_MSG,
  PDF_ERROR_DIALOG_TITLE_MSG,
} from '@constants/error-messages';
import { useAnalytics } from '@hooks/use-analytics';
import { getLogger } from '@interfaces/logger';
import { RouteProp, useNavigation, useRoute } from '@react-navigation/native';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { sharePdfHeaderActionIcons } from '@src/navigation/app/summary/share-pdf-header-action/share-pdf-header-action';
import { AppStackSummaryRouteParams } from '@src/navigation/app/summary/summary-screens';
import { getTestId } from '@src/utils/get-test-id';
import { PdfAnalytics } from '@utils/download-pdf/pdf-analytics';
import { PdfSource } from '@utils/download-pdf/pdf-source';
import { useLayoutEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Platform } from 'react-native';
import RNPdf from 'react-native-pdf';

import { ACTION_PENSION_DOCUMENTS_ERROR_MSG_OK } from '../pension/your-documents/analytics';
import { usePDF } from './use-pdf';

export type PdfViewScreenRouteParams = {
  pdfSource: PdfSource;
  pdfAnalytics?: PdfAnalytics;
  name?: string | null;
  isDW?: boolean;
};

const log = getLogger(PDFViewScreen.name);

const LayoutHeader = (
  props: NativeStackHeaderProps,
  actionIcons: JSX.Element[],
  name: string,
  isDW: boolean
) => {
  return isDW ? (
    <TopAppBarDW {...props} textLabel={name} actionIcons={actionIcons} />
  ) : (
    <TopAppBarManga {...props} textLabel={name} actionIcons={actionIcons} />
  );
};

export function PDFViewScreen() {
  const tokens = getTokens();
  const navigation = useNavigation();
  const { trackUserEvent } = useAnalytics();
  const [showErrorDialog, setShowErrorDialog] = useState(false);

  const { t } = useTranslation(undefined, { keyPrefix: 'pdfView' });

  const routeParams =
    useRoute<RouteProp<AppStackSummaryRouteParams, 'Pdf View'>>();

  const isDW = routeParams?.params?.isDW || false;
  const { isLoading, name, fileUrl } = usePDF({
    pdfSource: routeParams?.params?.pdfSource,
    name: routeParams?.params?.name,
    pdfAnalytics: routeParams?.params?.pdfAnalytics,
  });
  const showPdfActions = !isLoading && !!fileUrl;

  const iconColor = getVariableValue(
    tokens.color[isDW ? 'White' : 'Secondary800']
  );

  useLayoutEffect(() => {
    const actionIcons = showPdfActions
      ? sharePdfHeaderActionIcons(
          fileUrl,
          name || 'download',
          iconColor,
          setShowErrorDialog
        )
      : [];
    navigation.setOptions({
      header: (props: NativeStackHeaderProps) =>
        LayoutHeader(props, actionIcons, name, isDW),
    });
  }, [showPdfActions, name, navigation, isDW, fileUrl, tokens.color.White]);

  if (isLoading) {
    return <LoadingState fullscreen={false} text="oneMoment" />;
  }

  return (
    <Stack
      width={'100%'}
      height={'100%'}
      accessibilityLabel={
        Platform.OS === 'android' ? t('accessibilityLabel') : undefined
      }
      testID={getTestId('pdf-view')}
    >
      <RNPdf
        source={{
          uri: fileUrl,
        }}
        onLoadComplete={(numberOfPages: number) => {
          log.debug(`PDF load complete, number of pages: ${numberOfPages}`);
        }}
        onError={(error) => {
          log.debug(`PDF load error: ${error}`);
          setShowErrorDialog(true);
        }}
        style={{ flex: 1 }}
      />
      <Dialog
        open={showErrorDialog}
        title={PDF_ERROR_DIALOG_TITLE_MSG}
        copy={PDF_ERROR_DIALOG_BODY_MSG}
      >
        <Button
          variant={ButtonVariant.BRAND}
          mt="$xl"
          onPress={() => {
            trackUserEvent(ACTION_PENSION_DOCUMENTS_ERROR_MSG_OK);
            setShowErrorDialog(false);
            navigation.goBack();
          }}
        >
          OK
        </Button>
      </Dialog>
    </Stack>
  );
}
