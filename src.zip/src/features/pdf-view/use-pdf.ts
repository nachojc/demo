import { useMockServiceWorkerEnabled } from '@api-mock/use-mock-service-worker';
import { useAnalytics } from '@hooks/use-analytics';
import {
  MswPdfDownloader,
  NetworkPdfDownloader,
} from '@src/utils/download-pdf';
import { ellipsing } from '@src/utils/ellipsing';
import { isIpad } from '@src/utils/is-ipad';
import {
  makePdfAnalyticsErrorContext,
  makePdfAnalyticsErrorState,
  makePdfAnalyticsSuccessState,
  PdfAnalytics,
} from '@utils/download-pdf/pdf-analytics';
import { PdfSource } from '@utils/download-pdf/pdf-source';
import { useEffect, useState } from 'react';
import { Platform } from 'react-native';

type UsePdfProps = {
  name?: string | null;
  pdfSource?: PdfSource;
  pdfAnalytics?: PdfAnalytics;
};

export const usePDF = ({ name, pdfSource, pdfAnalytics }: UsePdfProps) => {
  const [isLoading, setIsLoading] = useState(true);
  const [fileUrl, setFileUrl] = useState<string | undefined>();
  const mswEnabled = useMockServiceWorkerEnabled();

  let truncatePosition = 22;
  if (isIpad) {
    truncatePosition = 80;
  } else if (Platform.OS === 'ios') {
    truncatePosition = 25;
  }
  const formattedName = name ? ellipsing(name, truncatePosition) : 'download';
  const { trackStateEvent } = useAnalytics();

  const trackSuccess = () =>
    pdfAnalytics && trackStateEvent(makePdfAnalyticsSuccessState(pdfAnalytics));
  const trackError = (error: unknown) =>
    pdfAnalytics &&
    makePdfAnalyticsErrorContext(error, pdfAnalytics).then((context) => {
      trackStateEvent(makePdfAnalyticsErrorState(pdfAnalytics), context);
    });

  useEffect(() => {
    if (!pdfSource) {
      setFileUrl(undefined);
      return;
    }
    setIsLoading(true);
    const fileName = name || 'download';
    const downloader = mswEnabled
      ? new MswPdfDownloader({ pdfSource, fileName })
      : new NetworkPdfDownloader({ pdfSource, fileName });

    downloader
      .download()
      .then((url) => {
        trackSuccess();
        setFileUrl(url);
      })
      .catch((error) => {
        // We don't need to worry about errors caught here - they are
        // handled in pdf-view-screen.tsx because the PDF will be
        // missing when rendering is attempted after loading stops
        trackError(error);
      })
      .finally(() => {
        setIsLoading(false);
      });
    return () => {
      downloader.cancel();
    };
    // We only want to refetch if the url changes
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pdfSource?.url]);

  return {
    isLoading,
    name: formattedName,
    fileUrl,
  };
};
