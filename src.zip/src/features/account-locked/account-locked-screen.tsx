import {
  Button,
  getTokens,
  getVariableValue,
  Image,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useAuthStackNavigation } from '@src/navigation/auth/hooks';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

export const AccountLockedScreen = () => {
  const navigation = useAuthStackNavigation();
  const tokens = getTokens();
  const { t } = useTranslation();

  const navigateToResetPasswordScreen = () => {
    navigation.navigate('Forgotten your details');
  };

  return (
    <YStack px={'$xl'} py={'$xxxl'} jc="space-between" h="100%" tablet={isIpad}>
      {isIpad && <YStack />}
      <YStack pt={getVariableValue(tokens.size[12])} ai={'center'}>
        <Image
          accessibilityIgnoresInvertColors
          testID="account-locked-img"
          style={{
            width: getVariableValue(tokens.size[12]),
            height: getVariableValue(tokens.size[12]),
          }}
          source={require('assets/account-locked.png')}
        />
        <Text
          fontVariant={'heading5-semibold-Secondary800'}
          tamaguiTextProps={{
            pb: '$xl',
            pt: '$xxl',
            testID: 'account-locked-txt',
            accessibilityLabel: 'account-locked-txt',
          }}
        >
          {t('accountLocked.title')}
        </Text>
        <Text
          tamaguiTextProps={{
            textAlign: 'center',
            pb: '$xl',
            testID: 'account-locked-sub-txt',
            accessibilityLabel: 'account-locked-sub-txt',
          }}
          fontVariant={'body-regular-Gray800'}
        >
          {t('accountLocked.copy')}
        </Text>
      </YStack>

      <YStack tabletNarrow={isIpad} pb={isIpad ? '$xxxxl' : undefined}>
        <Button onPress={navigateToResetPasswordScreen}>
          {t('accountLocked.resetPassword')}
        </Button>
      </YStack>
    </YStack>
  );
};
