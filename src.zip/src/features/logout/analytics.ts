import { APP_BASE } from '@constants/analytics';

export const PAGE_LOGGED_OUT = APP_BASE + 'log-out';
