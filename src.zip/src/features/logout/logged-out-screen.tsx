import { Button, Text, YStack } from '@aviva/ion-mobile';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { MESSAGE_CENTRE_DEEPLINK } from '@hooks/use-push-notification-deeplinks';
import { pushNotificationDeeplink } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { useAuthStackNavigation } from '@src/navigation/auth/hooks';
import { isIpad } from '@src/utils/is-ipad';
import { useCallback, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import { PAGE_LOGGED_OUT } from './analytics';

export const LoggedOutScreen = () => {
  const { reset } = useAuthStackNavigation();
  const pushNotificationDeeplinkValue = useSelector(pushNotificationDeeplink);
  const { t } = useTranslation();

  const navigateToLoginScreen = useCallback(() => {
    reset({
      index: 0,
      routes: [{ name: 'Log in' }],
    });
  }, [reset]);

  useOnPageLoad({ pageTag: PAGE_LOGGED_OUT });

  useEffect(() => {
    if (pushNotificationDeeplinkValue === MESSAGE_CENTRE_DEEPLINK) {
      navigateToLoginScreen();
    }
  }, [pushNotificationDeeplinkValue, navigateToLoginScreen]);

  return (
    <YStack
      flex={1}
      justifyContent="center"
      margin="$xxxl"
      alignItems="center"
      tabletNarrow={isIpad}
    >
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ mb: '$xxl' }}
      >
        {t('loggedOut.youAreLoggedOut')}
      </Text>
      <Button
        accessibilityLabel="Log in"
        onPress={navigateToLoginScreen}
        w="100%"
        pos={isIpad ? 'absolute' : undefined}
        bottom={isIpad ? '$xxxxl' : undefined}
      >
        {t('loggedOut.logIn')}
      </Button>
    </YStack>
  );
};
