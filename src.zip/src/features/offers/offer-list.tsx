import {
  CollapsibleTabs,
  OfferCard,
  Separator,
  TabsHeaderWrapper,
  YStack,
} from '@aviva/ion-mobile';
import { useColumnCount } from '@hooks/use-column-count';
import { useAccessibility } from '@src/common/providers/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { Offer } from '@src/validation/schemas/offers';
import { useTranslation } from 'react-i18next';

import { OffersHeaderExtension } from './offers-header-extension';

export type OfferListProps = {
  offers: Offer[];
  onOfferPress: (offer: Offer) => void;
  isOfferAtRisk?: (offer: Offer) => boolean;
};

const RowsSeparator = () => <Separator height="$4" />;

export const OfferList = ({
  offers,
  onOfferPress,
  isOfferAtRisk,
}: OfferListProps) => {
  const columnCount = useColumnCount({ tabletLandscapeLarge: 4 });
  const { t } = useTranslation();
  const { isScreenReaderEnabled } = useAccessibility();

  return (
    <CollapsibleTabs.MasonryFlashList
      data={offers}
      numColumns={columnCount}
      estimatedItemSize={130}
      ListHeaderComponent={
        <TabsHeaderWrapper
          accessibilityEnabled={isScreenReaderEnabled}
          layoutType="flashList"
        >
          <OffersHeaderExtension />
        </TabsHeaderWrapper>
      }
      ListFooterComponent={RowsSeparator}
      keyExtractor={({ Title, Subtitle }, index) =>
        `${Title}-${Subtitle}-${index}`
      }
      renderItem={({ item, columnIndex }) => {
        const isFirstCol = columnIndex === 0;
        const isLastCol = columnIndex === columnCount - 1;

        return (
          <YStack
            f={1}
            pt="$xl"
            pl={isFirstCol ? '$xl' : '$md'}
            pr={isLastCol ? '$xl' : '$md'}
          >
            <OfferCard
              testID={getTestId(`offer-card-${item.CreativeId}`)}
              offer={item}
              note={
                isOfferAtRisk?.(item) ? t('isCapitalAtRisk.label') : undefined
              }
              onPress={() => onOfferPress(item)}
            />
          </YStack>
        );
      }}
    />
  );
};
