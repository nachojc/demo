import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { useOffers } from '@hooks/use-offers';
import { useRiskOffer } from '@hooks/use-risk-offer';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { useSurvey } from '@src/utils/qualtrics/use-survey';
import { Offer } from '@src/validation/schemas/offers';
import { useMemo } from 'react';

import { offerTagMap, PAGE_EXPLORE_OFFERS, PAGE_OFFERS } from './analytics';
import { fetchErrorWarningText, financiallyAdvisedWarningText } from './copy';

export const useOffersScreen = () => {
  const { offers, isError, isLoading, isFinanciallyAdvised } = useOffers();
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const { isCapitalAtRisk } = useRiskOffer();
  useSurvey(PAGE_EXPLORE_OFFERS);
  useTrackStateEvent(PAGE_OFFERS);
  /** Groups up the result of useOffers by its Group field. */
  const groupOffers = () => {
    type GroupedOffers = Record<string, Offer[]>;
    const byGroupName = (accOffers: GroupedOffers, offer: Offer) => {
      if (offer.Group && !accOffers[offer.Group]) {
        accOffers[offer.Group] = [];
      }
      offer.Group && accOffers[offer.Group].push(offer);
      return accOffers;
    };

    return offers
      ? offers.reduce(byGroupName, { All: offers } as GroupedOffers)
      : undefined;
  };
  const groupedOffers = useMemo(groupOffers, [offers]);

  const createItems = (list: (offers: Offer[]) => JSX.Element) =>
    isError || !groupedOffers
      ? []
      : Object.entries(groupedOffers).map(([label, listOffers]) => ({
          key: label,
          title: label,
          component: () => list(listOffers),
        }));

  const warning =
    (isFinanciallyAdvised && financiallyAdvisedWarningText) ||
    ((isError || groupedOffers?.All.length === 0) && fetchErrorWarningText);

  const calculateAtRiskStatus = (
    offersList: Offer[]
  ): Record<string, boolean> => {
    const atRiskStatus: Record<string, boolean> = {};
    offersList.forEach((offer) => {
      atRiskStatus[offer.CreativeId] = isCapitalAtRisk(offer);
    });
    return atRiskStatus;
  };

  const atRiskStatus = useMemo(
    () => (groupedOffers ? calculateAtRiskStatus(groupedOffers.All) : {}),
    [groupedOffers]
  );

  const offerIsDirectWebLink = (offer: Offer) =>
    offer.Actions.length === 1 &&
    offer.Actions[0].Type === 'Link' &&
    offer.Actions[0].Uri;

  const onOfferPress = (offer: Offer) => {
    const tag = offerTagMap[offer.Title];
    if (tag) {
      trackUserEvent(tag);
    }

    if (offerIsDirectWebLink(offer) && offer.Actions[0].Uri) {
      navigate('Offer Web Journey', {
        uri: offer.Actions[0].Uri,
        isDeepLink: offer.Actions[0].IsDeepLink ?? false,
      });
      return;
    }

    navigate('Offer Buffer', { offer, isBackTitleVisible: false });
  };

  return {
    groupedOffers,
    warning,
    isLoading,
    createItems,
    onOfferPress,
    atRiskStatus,
  };
};
