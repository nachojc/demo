import { APP_BASE } from '@constants/analytics';

export const PAGE_EXPLORE_OFFERS = APP_BASE + 'explore';
export const PAGE_OFFERS = APP_BASE + 'offers';
export const ACTION_EXPLORE_RETRIEVE_QUOTE_TAPPED =
  PAGE_EXPLORE_OFFERS + '|retrieve-quote-tapped';

export const offerTagMap: Record<string, string> = {
  'Home insurance': 'ukmyaviva|explore|home-offer-tapped',
  'Car insurance': 'ukmyaviva|explore|car-offer-tapped',
  'MultiCar insurance': 'ukmyaviva|explore|multicar-offer-tapped',
  'Health insurance': 'ukmyaviva|explore|health-offer-tapped',
  Pension: 'ukmyaviva|explore|pension-offer-tapped',
  'Stocks & shares ISA': 'ukmyaviva|explore|stocks-and-shares-isa-offer-tapped',
  'Aviva Stocks & Shares ISA':
    'ukmyaviva|explore|stocks-and-shares-isa-offer-tapped',
  'Aviva Investment Account': 'ukmyaviva|explore|investment-offer-tapped',
  'Equity release': 'ukmyaviva|explore|equity-release-offer-tapped',
  'Flexible income': 'ukmyaviva|explore|income-drawdown-offer-tapped',
  'Pension annuity': 'ukmyaviva|explore|annuity-offer-tapped',
  'Life Insurance Plan': 'ukmyaviva|explore|life-offer-tapped',
  'Critical Illness Plan': 'ukmyaviva|explore|critical-illness-offer-tapped',
  'Travel insurance': 'ukmyaviva|explore|travel-offer-tapped',
  'Personal Accident Insurance':
    'ukmyaviva|explore|personal-accident-offer-tapped',
  'Income Protection Insurance':
    'ukmyaviva|explore|income-protection-offer-tapped',
  'Free parent life insurance':
    'ukmyaviva|explore|free-parent-life-cover-offer-tapped',
  'Van insurance': 'ukmyaviva|explore|van-offer-tapped',
  'Breakdown cover': 'ukmyaviva|explore|breakdown-offer-tapped',
  'Pet insurance': 'ukmyaviva|explore|pet-insurance-offer-tapped',
  // these four tags don't have known offer titles to associate with
  cancer: 'ukmyaviva|explore|cancer-essentials-offer-tapped',
  physio: 'ukmyaviva|explore|physio-essentials-offer-tapped',
  heating: 'ukmyaviva|explore|heating-and-boiler-offer-tapped',
  wealthify: 'ukmyaviva|explore|wealthify-tapped',
};

type ExternalPage = {
  pageTag: string;
  ctaTags: string[];
};

type OfferBufferTags = Record<
  string,
  {
    page: string;
    action?: string;
    coverOptions?: ExternalPage;
    extendedCriteria?: ExternalPage;
  }
>;

export const bufferPageTag: OfferBufferTags = {
  'Car insurance': {
    page: 'ukmyaviva|explore|car-offer',
    action: 'ukmyaviva|explore|car-offer|get-a-quote-tapped',
  },
  'MultiCar insurance': {
    page: 'ukmyaviva|explore|multicar-offer',
    action: 'ukmyaviva|explore|multicar-offer|get-a-quote-tapped',
  },
  'Home insurance': {
    page: 'ukmyaviva|explore|home-offer',
    action: 'ukmyaviva|explore|home-offer|get-a-quote-tapped',
  },
  'Health insurance': {
    page: 'ukmyaviva|explore|health-offer',
    action: 'ukmyaviva|explore|health-offer|get-a-quote-tapped',
  },
  'Life Insurance Plan': {
    page: 'ukmyaviva|explore|life-offer',
    action: 'ukmyaviva|explore|life-offer|get-a-quote-tapped',
  },
  'Travel insurance': {
    page: 'ukmyaviva|explore|travel-offer',
    action: 'ukmyaviva|explore|travel-offer|get-a-quote-tapped',
  },
  'Critical Illness Plan': {
    page: 'ukmyaviva|explore|critical-illness-offer',
    action: 'ukmyaviva|explore|critical-illness|get-a-quote-tapped',
  },
  'Free parent life insurance': {
    page: 'ukmyaviva|explore|free-parent-life-cover-offer',
    action: 'ukmyaviva|explore|free-parent-life-cover-offer|apply-now-tapped',
    extendedCriteria: {
      pageTag:
        'ukmyaviva|explore|free-parent-life-cover-offer|eligibility-criteria',
      ctaTags: [],
    },
  },
  'Van insurance': {
    page: 'ukmyaviva|explore|van-offer',
    coverOptions: {
      pageTag: 'ukmyaviva|explore|van-offer|continue-tapped',
      ctaTags: [
        'ukmyaviva|explore|van-offer|continue-tapped|private-van-get-a-quote-tapped',
        'ukmyaviva|explore|van-offer|continue-tapped|sole-trader-van-get-a-quote-tapped',
        'ukmyaviva|explore|van-offer|continue-tapped|company-van-get-a-quote-tapped',
      ],
    },
  },
};
