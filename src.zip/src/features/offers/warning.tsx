import { Icon, Stack, Text } from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';

export type WarningProps = { text: string };

export const Warning = ({ text }: WarningProps) => {
  const iconSize = tokens.size[7].val;

  return (
    <Stack f={1} jc="center" ai="center" px="$xl">
      <Icon name="alert-circle-outline" height={iconSize} width={iconSize} />
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{
          marginTop: tokens.size[3].val,
          textAlign: 'center',
          width: tokens.size[17].val,
        }}
      >
        {text}
      </Text>
    </Stack>
  );
};
