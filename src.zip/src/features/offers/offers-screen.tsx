import {
  CollapsibleTabs,
  LoadingState,
  TabsHeaderWrapper,
} from '@aviva/ion-mobile';
import { useAccessibility } from '@src/common/providers/accessibility';
import { Offer } from '@src/validation/schemas/offers';

import { OfferList } from './offer-list';
import { OffersHeaderExtension } from './offers-header-extension';
import { useOffersScreen } from './use-offers';
import { Warning } from './warning';

export const OffersScreen = () => {
  const { isLoading, createItems, onOfferPress, warning, atRiskStatus } =
    useOffersScreen();
  const { isScreenReaderEnabled } = useAccessibility();

  const isOfferAtRisk = (offer: Offer) => {
    return atRiskStatus[offer.CreativeId] ?? false;
  };

  const items = createItems((offers) => (
    <OfferList
      offers={offers}
      onOfferPress={onOfferPress}
      isOfferAtRisk={isOfferAtRisk}
    />
  ));

  if (isLoading) {
    return <LoadingState fullscreen={false} />;
  }

  if (warning) {
    return (
      <>
        <OffersHeaderExtension />
        <Warning text={warning} />
      </>
    );
  }
  const collapsibleTab = () => {
    return (
      <TabsHeaderWrapper
        accessibilityEnabled={isScreenReaderEnabled}
        layoutType="container"
      >
        <OffersHeaderExtension />
      </TabsHeaderWrapper>
    );
  };

  return (
    <CollapsibleTabs
      tabBarScrollEnabled
      header={collapsibleTab}
      tabRoutes={items}
    />
  );
};
