import { config } from '@config';
import { WebViewComponent } from '@src/components/web-view';

export const RetrieveQuoteWebScreen = () => {
  return (
    <WebViewComponent
      ssoEnabled
      source={{
        uri:
          config.AVIVA_BASE_URL.get() + '/help-and-support/retrieve-a-quote/',
      }}
    />
  );
};
