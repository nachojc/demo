import { config } from '@config';
import { WebViewComponent } from '@src/components/web-view';
import { useAppStackRoute } from '@src/navigation/app/hooks';

export const OfferWebJourneyScreen = () => {
  const {
    params: { uri, isDeepLink },
  } = useAppStackRoute<'Offer Web Journey'>();

  const sanitizeUri = (url: string) => url.replace('{0}&', '?');

  const baseDomain = isDeepLink
    ? config.BASE_URL.get()
    : config.AVIVA_BASE_URL.get();
  const baseUrl = uri.includes('https') ? '' : baseDomain;

  const link = `${baseUrl}${sanitizeUri(uri)}`;

  return (
    <WebViewComponent
      ssoEnabled={isDeepLink}
      source={{
        uri: link,
      }}
    />
  );
};
