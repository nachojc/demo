export const financiallyAdvisedWarningText =
  'If you got financial advice or bought a product from a third party, our product catalogue isn’t available right now.';
export const fetchErrorWarningText =
  'Unfortunately we are unable to show you any offers';
