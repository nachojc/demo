import { Card, Icon, Text, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';

import { ACTION_EXPLORE_RETRIEVE_QUOTE_TAPPED } from './analytics';

export const OffersHeaderExtension = () => {
  const { navigate } = useAppStackNavigation();
  const analytics = useAnalytics();

  return (
    <YStack px="$xl" py="$xl" bg="$Primary500">
      <Card
        accessibilityLabel="Quote card"
        onPress={() => {
          navigate('RetrieveQuoteWeb');
          analytics.trackUserEvent(ACTION_EXPLORE_RETRIEVE_QUOTE_TAPPED);
        }}
      >
        <Card.Generic.Content
          right={<Icon name="chevron-right" color={tokens.color.Gray400.val} />}
        >
          <Text fontVariant="body-semibold-Secondary800">
            Already have a quote?
          </Text>
          <Text fontVariant="small-regular-Gray800">Retrieve it here</Text>
        </Card.Generic.Content>
      </Card>
    </YStack>
  );
};
