import { useAnalytics } from '@hooks/use-analytics';
import { myAvivaOnboardingComplete } from '@interfaces/storage';

import {
  ACTION_CLOSE_ONBOARDING_SCREEN_ONE,
  ACTION_CLOSE_ONBOARDING_SCREEN_THREE,
  ACTION_CLOSE_ONBOARDING_SCREEN_TWO,
  ACTION_LOGIN_ONBOARDING_SCREEN_THREE,
  ACTION_NEXT_ONBOARDING_SCREEN_ONE,
  ACTION_NEXT_ONBOARDING_SCREEN_TWO,
  PAGE_ONBOARDING_SCREEN_ONE,
  PAGE_ONBOARDING_SCREEN_THREE,
  PAGE_ONBOARDING_SCREEN_TWO,
} from './analytics';

type TagProps = {
  key: number;
  pageTag: string;
  closeTag: string;
  nextTag: string;
};

const screenTags: TagProps[] = [
  {
    key: 0,
    pageTag: PAGE_ONBOARDING_SCREEN_ONE,
    closeTag: ACTION_CLOSE_ONBOARDING_SCREEN_ONE,
    nextTag: ACTION_NEXT_ONBOARDING_SCREEN_ONE,
  },
  {
    key: 1,
    pageTag: PAGE_ONBOARDING_SCREEN_TWO,
    closeTag: ACTION_CLOSE_ONBOARDING_SCREEN_TWO,
    nextTag: ACTION_NEXT_ONBOARDING_SCREEN_TWO,
  },
  {
    key: 2,
    pageTag: PAGE_ONBOARDING_SCREEN_THREE,
    closeTag: ACTION_CLOSE_ONBOARDING_SCREEN_THREE,
    nextTag: ACTION_LOGIN_ONBOARDING_SCREEN_THREE,
  },
];

export const useMyAvivaOnboardingCarouselAnalytics = () => {
  const { trackUserEvent, trackStateEvent } = useAnalytics();

  const handleClose = (index: number) => {
    trackUserEvent(screenTags[index].closeTag);
    myAvivaOnboardingComplete.set(true);
  };

  const handleLogin = () => {
    myAvivaOnboardingComplete.set(true);
    handleNext(screenTags[screenTags.length - 1].key);
  };

  const handleNext = (index: number) => {
    trackUserEvent(screenTags[index].nextTag);
  };

  const firePageTag = (index: number) => {
    trackStateEvent(screenTags[index].pageTag);
  };

  return {
    handleClose,
    handleNext,
    firePageTag,
    handleLogin,
  };
};
