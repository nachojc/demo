export const Introduction = 'Welcome to MyAviva, carousel, screen';
export const CloseButton = 'Close, button.';
