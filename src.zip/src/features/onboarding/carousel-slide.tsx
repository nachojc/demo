import {
  getTokens,
  getVariableValue,
  Image,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { Source } from 'react-native-fast-image';

type MyAvivaOnboardingCarouselSlideProps = {
  image: Source;
  headingText: string;
  bodyText: string;
  key: number;
};

export const MyAvivaOnboardingCarouselSlide = ({
  image,
  headingText,
  bodyText,
}: MyAvivaOnboardingCarouselSlideProps) => {
  const { size } = getTokens();
  return (
    <YStack
      ai={'center'}
      paddingTop="$xxxl"
      accessible
      accessibilityLabel={`${headingText}, ${bodyText}`}
    >
      <Image
        testID="carousel-screen-image"
        accessibilityIgnoresInvertColors
        source={image}
        resizeMode="contain"
        style={{
          width: getVariableValue(size[17]),
          height: getVariableValue(size[17]),
          padding: 0,
        }}
      />
      <Text
        fontVariant={'heading5-semibold-Secondary800'}
        tamaguiTextProps={{
          textAlignVertical: 'center',
          marginBottom: '$xl',
          color: 'white',
          textAlign: 'center',
          width: 320,
          accessibilityLabel: headingText,
        }}
      >
        {headingText}
      </Text>
      <Text
        fontVariant={'body-regular-Gray800'}
        tamaguiTextProps={{
          marginBottom: '$xl',
          textAlign: 'center',
          color: 'white',
          width: 320,
        }}
      >
        {bodyText}
      </Text>
    </YStack>
  );
};
