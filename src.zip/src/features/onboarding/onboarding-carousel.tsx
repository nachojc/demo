import {
  FocusAwareStatusBar,
  FullScreenCarouselModal,
  Stack,
  Theme,
} from '@aviva/ion-mobile';
import { Source } from 'react-native-fast-image';

import { Introduction } from './accessibilityText';
import { MyAvivaOnboardingCarouselSlide } from './carousel-slide';
import { useMyAvivaOnboardingCarouselAnalytics } from './use-onboarding-carousel-analytics';

export type MyAvivaOnboardingScreenProps = {
  key: number;
  image: Source;
  headingText: string;
  bodyText: string;
  bg: string;
};

const screens: MyAvivaOnboardingScreenProps[] = [
  {
    key: 0,
    image: require('assets/insurance-tab/insurance-tab.png'),
    headingText: 'Insurance',
    bodyText:
      'Protect the things you love.\nView all your policy details and start a claim.',
    bg: '$Teal900',
  },
  {
    key: 1,
    image: require('assets/wealth-tab/wealth-tab.png'),
    headingText: 'Wealth',
    bodyText:
      'Make better financial decisions.\nManage your savings and investments in one place.',
    bg: '$WealthBlue',
  },
  {
    key: 2,
    image: require('assets/retirement-tab/retirement-tab.png'),
    headingText: 'Retirement',
    bodyText:
      'Get the most out of your retirement.\nPlan for the future to make things easier tomorrow.',
    bg: '$PlumDark',
  },
];

const bgScreens = screens.map((item) => ({ key: item.key, bg: item.bg }));

export const MyAvivaOnboardingView = () => {
  const { handleClose, handleNext, firePageTag, handleLogin } =
    useMyAvivaOnboardingCarouselAnalytics();

  return (
    <>
      <FocusAwareStatusBar style="light" />
      <Theme name="wealth">
        <Stack flex={1}>
          <FullScreenCarouselModal
            headerIconVariant="light"
            leftLabel="Back"
            rightLabel="Next"
            lastRightLabel="Login"
            items={screens.map((screen) => (
              <MyAvivaOnboardingCarouselSlide {...screen} key={screen.key} />
            ))}
            onClose={handleClose}
            onRightLabelPress={handleNext}
            onPageLoad={firePageTag}
            onLastRightLabelPress={handleLogin}
            carouselAccessibilityTitle={Introduction}
            bgScreens={bgScreens}
          />
        </Stack>
      </Theme>
    </>
  );
};

export const MyAvivaOnboardingScreen = () => {
  return <MyAvivaOnboardingView />;
};
