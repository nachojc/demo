import { RouteProp } from '@react-navigation/native';
import { WebViewComponent } from '@src/components/web-view';
import { AppStackRouteParams } from '@src/navigation/app';

export const WebViewScreen = ({
  route,
}: {
  route: RouteProp<AppStackRouteParams, 'Web View'>;
}) => {
  const {
    url: uri,
    ssoEnabled = true,
    appendVisitorInfoEnabled,
  } = route.params;

  return (
    <WebViewComponent
      ssoEnabled={ssoEnabled}
      source={{ uri }}
      appendVisitorInfoEnabled={appendVisitorInfoEnabled}
    />
  );
};
