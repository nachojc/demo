import {
  Button,
  ButtonVariant,
  Checkbox,
  ChecksList,
  Dialog,
  List,
  LoadingState,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { ScrollableScreen } from '@src/components/scrollable-screen';
import { isIpad } from '@src/utils/is-ipad';
import { tokens } from '@theme/tokens';
import {
  Control,
  Controller,
  ControllerRenderProps,
  FieldValues,
} from 'react-hook-form';

import { PaperlessPreferencesErrorView } from './paperless-preferences-error';
import {
  Paperless,
  usePaperlessPreferencesViewModel,
  VoidCallback,
} from './paperless-preferences-view-model';

const checksListItems = [
  'Help the environment',
  'Reduce the paperwork',
  'Check your documents on the go',
];

const OptionsComponent = (
  field: ControllerRenderProps<FieldValues, string>,
  option: Paperless,
  onCheck: (option: ControllerRenderProps<FieldValues, string>) => VoidCallback
) => {
  return (
    <XStack
      key={field.name}
      testID="CheckboxParent"
      space={'$sm'}
      borderWidth={2}
      padding={'$md'}
      margin={'$md'}
      borderRadius={'$2'}
      borderColor={field.value ?? option.IsPaperless ? '$Success' : '$Gray300'}
    >
      <Checkbox
        onValueChange={onCheck(field)}
        value={field.value ?? option.IsPaperless}
        testID={field.name}
        accessibilityLabel={field.name}
        hitSlop={{ left: tokens.size[6].val, right: tokens.size[6].val }}
        marginTop={tokens.size[0.5].val}
      />
      <Text
        tamaguiTextProps={{ marginLeft: '$md' }}
        fontVariant="body-regular-Gray800"
      >
        {field.name}
      </Text>
    </XStack>
  );
};

const Checkboxes = ({
  options,
  control,
  onCheck,
}: {
  options: Paperless[];
  control: Control<FieldValues>;
  onCheck: (option: ControllerRenderProps<FieldValues, string>) => VoidCallback;
}) => {
  return (
    <YStack>
      {options.map((option) => (
        <Controller
          key={option.DocumentType}
          control={control}
          name={option.DocumentType}
          render={({ field }) => OptionsComponent(field, option, onCheck)}
        />
      ))}
    </YStack>
  );
};

type PaperlessPreferencesViewProps = {
  model: ReturnType<typeof usePaperlessPreferencesViewModel>;
};

export const PaperlessPreferencesView = ({
  model,
}: PaperlessPreferencesViewProps) => {
  const {
    form,
    selectOptions,
    paperlessPreferences,
    onSubmit,
    isLoading,
    isOpen,
    setIsOpen,
    feedback,
    navigateToPaperlessPreferencesOnline,
    navigateToPaperlessPreferencesDocuments,
    navigateBack,
    customerData: { FNZCustomer, canaryCustomer },
    isFnz,
    isCanary,
  } = model;
  const { handleSubmit, control } = form;
  const action =
    feedback.title === 'Unsaved changes' ? 'Discard & Continue' : 'Go online';

  const onClose = () => setIsOpen(false);

  return (
    <ScrollableScreen>
      {isLoading && (
        <LoadingState
          fullscreen
          text={paperlessPreferences.length > 0 ? 'saveChanges' : 'preferences'}
        />
      )}
      {feedback.showErrorView && (
        <PaperlessPreferencesErrorView model={model} />
      )}
      {!feedback.showErrorView && (
        <YStack tablet={isIpad}>
          <YStack>
            <YStack padding="$xl">
              <Text
                fontVariant="body-regular-Gray800"
                tamaguiTextProps={{ marginBottom: '$xxl' }}
              >
                We’re on a journey to make all your documents securely available
                online, so you can view them anytime, anywhere.
              </Text>

              <Text
                fontVariant="body-semibold-Secondary800"
                tamaguiTextProps={{ marginBottom: '$xl' }}
              >
                Why choose paperless?
              </Text>

              <ChecksList
                items={checksListItems}
                icon="tick"
                width={16}
                height={16}
                typography="small-regular-Gray800"
                space="$lg"
                itemsSpace="$md"
              />

              <Text
                fontVariant="body-semibold-Secondary800"
                tamaguiTextProps={{ marginBottom: '$xl', marginTop: '$xxl' }}
              >
                Go paperless
              </Text>
              <Text
                fontVariant="body-regular-Gray800"
                tamaguiTextProps={{
                  marginBottom: '$md',
                  accessibilityHint: 'Required',
                }}
              >
                Select which policies you want to go paperless:
              </Text>

              <Checkboxes
                onCheck={selectOptions}
                control={control}
                options={paperlessPreferences}
              />
            </YStack>

            {(isFnz || FNZCustomer) && (
              <YStack>
                <List
                  listTitleFontVariant="body-regular-Gray900"
                  listProps={{
                    borderTopColor: '$Gray300',
                    borderTopWidth: '$xxs',
                    borderBottomColor: '$Gray300',
                    borderBottomWidth: '$xxs',
                    backgroundColor: '$White',
                  }}
                  listItemProps={{
                    backgroundColor: '$White',
                  }}
                  items={[
                    {
                      title: 'Investments bought through an adviser',
                      subTitle:
                        'Your preference for your investments can’t be changed in the app yet, so to make changes please go online.',
                      onPress: navigateToPaperlessPreferencesDocuments('fnz'),
                    },
                  ]}
                />
              </YStack>
            )}
            {isCanary && (
              <YStack>
                <List
                  listTitleFontVariant="body-regular-Gray900"
                  listProps={{
                    borderTopColor: '$Gray300',
                    borderTopWidth: '$xxs',
                    borderBottomColor: '$Gray300',
                    borderBottomWidth: '$xxs',
                    backgroundColor: '$White',
                  }}
                  listItemProps={{
                    backgroundColor: '$White',
                  }}
                  items={[
                    {
                      title: 'Investments bought direct',
                      subTitle:
                        'Your preference for your investments can’t be changed in the app yet, so to make changes please click here.',
                      onPress:
                        navigateToPaperlessPreferencesDocuments('canary'),
                    },
                  ]}
                />
              </YStack>
            )}
            {canaryCustomer && (
              <YStack>
                <YStack padding="$xl">
                  <Text
                    fontVariant={'body-regular-Gray800'}
                    tamaguiTextProps={{ marginBottom: '$xl' }}
                  >
                    Going paperless with Aviva online
                  </Text>
                  <Text fontVariant={'overline-regular-Gray800'}>
                    If you change your preferences here, or you’ve already
                    changed it, you’ll also need to update your Aviva Online
                    policy.
                  </Text>
                </YStack>
                <List
                  listTitleFontVariant="body-regular-Gray900"
                  listProps={{
                    borderTopColor: '$Gray300',
                    borderTopWidth: '$xxs',
                    borderBottomColor: '$Gray300',
                    borderBottomWidth: '$xxs',
                    backgroundColor: '$White',
                  }}
                  listItemProps={{
                    backgroundColor: '$White',
                  }}
                  items={[
                    {
                      title: 'Change preferences online',
                      onPress: navigateToPaperlessPreferencesOnline('online'),
                    },
                  ]}
                />
              </YStack>
            )}

            <YStack paddingVertical="$xxl" paddingHorizontal="$xl">
              <Text fontVariant="overline-regular-Gray800">
                You may still get some of your documents in the post as not all
                documents are available online only yet. We’ll switch you over
                as soon as it becomes available. Any changes may take 24 hours
                to occur.
              </Text>
            </YStack>
          </YStack>
          <YStack tabletNarrow={isIpad} padding="$xl">
            <Button
              disabled={!form?.formState.isDirty}
              onPress={handleSubmit(onSubmit)}
              accessibilityLabel="Save preferences"
            >
              Save preferences
            </Button>
          </YStack>

          <Dialog
            open={isOpen}
            title={feedback.title}
            copy={feedback.text}
            actions={feedback?.action}
            cancelButton={feedback.isConnectionError}
            onPressCancel={onClose}
          >
            {feedback.hasError && !feedback.isConnectionError && (
              <YStack tabletNarrow={isIpad}>
                <Button
                  mt="$xl"
                  onPress={
                    action === 'Discard & Continue'
                      ? navigateBack
                      : navigateToPaperlessPreferencesOnline('online')
                  }
                >
                  {action}
                </Button>

                <Button
                  variant={ButtonVariant.LINK_TEXT}
                  mt="$xl"
                  onPress={onClose}
                >
                  Cancel
                </Button>
              </YStack>
            )}
            {!feedback.hasError && (
              <YStack tabletNarrow={isIpad}>
                <Button mt="$xl" onPress={onClose}>
                  OK
                </Button>
              </YStack>
            )}
          </Dialog>
        </YStack>
      )}
    </ScrollableScreen>
  );
};

export const PaperlessPreferencesScreen = () => {
  const model = usePaperlessPreferencesViewModel();
  return <PaperlessPreferencesView model={model} />;
};
