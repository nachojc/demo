import { webLinks } from '@constants/web-links';
import { WebViewComponent } from '@src/components/web-view';

export const ChangePaperlessOnlineScreen = () => {
  return (
    <WebViewComponent ssoEnabled source={{ uri: webLinks.addressTransfer }} />
  );
};
