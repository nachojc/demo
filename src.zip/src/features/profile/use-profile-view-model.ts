import { useAnalytics } from '@hooks/use-analytics';
import { useCustomer } from '@hooks/use-customer';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useProfileChangeEligibility } from '@hooks/use-profile-change-eligibility';
import { username as usernameObs } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { useCallback, useMemo } from 'react';

import {
  ACTION_PROFILE_CHANGE_ADDRESS_CLOSE_TAPPED,
  ACTION_PROFILE_CHANGE_DETAILS_TAPPED,
  ACTION_PROFILE_PAPERLESS_PREFERENCE_TAPPED,
  PAGE_PROFILE,
} from './analytics';

export type ProfileListItem = {
  title: string;
  value?: (string | null | undefined)[];
  editable?: boolean;
  navigation?: boolean;
  action?: () => void;
};

export type ProfileSectionListData = {
  title: string;
  data: ProfileListItem[];
};

type ProfileSectionList = {
  title: string;
  data: {
    title: string;
    value: (string | null | undefined)[];
    editable?: boolean;
    action?: () => void;
  }[];
}[];

export function useProfileViewModel() {
  const { data: customer } = useCustomer();
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const username = useSelector(() => usernameObs.get());

  const navigateToChangePersonalDetails = useCallback(() => {
    trackUserEvent(ACTION_PROFILE_CHANGE_DETAILS_TAPPED);
    navigate('Change personal details');
  }, [navigate, trackUserEvent]);

  const navigateToPaperlessPreferences = useCallback(() => {
    trackUserEvent(ACTION_PROFILE_PAPERLESS_PREFERENCE_TAPPED);
    navigate('Paperless preferences');
  }, [navigate, trackUserEvent]);

  const backToProfilePage = useCallback(() => {
    trackUserEvent(ACTION_PROFILE_CHANGE_ADDRESS_CLOSE_TAPPED);
    navigate('Bottom tabs', {
      screen: 'Profile Tab',
    });
  }, [navigate, trackUserEvent]);

  const navigateToChangeAddressApp = useCallback(() => {
    navigate('Change address App', { onClose: backToProfilePage });
  }, [navigate, backToProfilePage]);

  const navigateToChangeAddressWeb = useCallback(() => {
    navigate('Change address Web');
  }, [navigate]);

  useOnPageLoad({ pageTag: PAGE_PROFILE });

  const { data, isSuccess, isLoading } = useProfileChangeEligibility();
  const isAnAppJourney = data?.AddressChange.Channel === 'App';
  const isAddressChangeable =
    isSuccess && /web|app/i.test(data.AddressChange.Channel);

  const profileSectionListData: ProfileSectionList = useMemo(() => {
    if (!customer) {
      return [];
    }
    const { Title, Firstname, Surname, Email, Address, DateOfBirth } = customer;

    const { Address1, City, Town, Postcode } = Address || {};

    return [
      {
        title: 'Personal details',
        data: [
          {
            title: 'Full name',
            value: [`${Title} ${Firstname} ${Surname}`],
          },
          { title: 'Date of birth', value: [DateOfBirth] },
          {
            title: 'Correspondence address',
            value: [Address1, City || Town, Postcode].filter((n) => n),
            editable: isAddressChangeable,
            action: () => {
              isAnAppJourney
                ? navigateToChangeAddressApp()
                : navigateToChangeAddressWeb();
            },
          },
          { title: 'Correspondence email', value: [Email] },
          { title: 'Username', value: [username] },
          {
            title: 'Change personal details',
            navigation: true,
            action: () => navigateToChangePersonalDetails(),
            value: [],
          },
        ],
      },
      {
        title: 'Preferences',
        data: [
          {
            title: '',
            value: ['Paperless preferences'],
            editable: true,
            action: () => navigateToPaperlessPreferences(),
          },
        ],
      },
    ];
  }, [
    customer,
    isAddressChangeable,
    username,
    isAnAppJourney,
    navigateToChangeAddressApp,
    navigateToChangeAddressWeb,
    navigateToChangePersonalDetails,
    navigateToPaperlessPreferences,
  ]);

  return {
    profileSectionListData,
    isLoading,
    navigateToChangePersonalDetails,
  };
}
