import { webLinks } from '@constants/web-links';
import { WebViewComponent } from '@src/components/web-view';

export const ChangePersonalDetailsScreen = () => {
  return <WebViewComponent ssoEnabled source={{ uri: webLinks.profile }} />;
};
