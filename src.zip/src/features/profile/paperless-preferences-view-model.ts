import { Action } from '@aviva/ion-mobile';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAnalytics } from '@hooks/use-analytics';
import {
  useGetCommunicationPreferences,
  usePutCommunicationPreferences,
} from '@hooks/use-communication-preferences';
import { useCustomer } from '@hooks/use-customer';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { getLogger } from '@interfaces/logger';
import NetInfo from '@react-native-community/netinfo';
import { EventArg } from '@react-navigation/native';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import {
  PaperlessForm,
  PaperlessFormSchema,
} from '@src/validation/schemas/profile';
import { t } from 'i18next';
import { useCallback, useEffect, useState } from 'react';
import { ControllerRenderProps, FieldValues, useForm } from 'react-hook-form';

import {
  ACTION_PROFILE_PAPERLESS_PREFERENCE_AVIVA_ONLINE_CHANGE_TAPPED,
  ACTION_PROFILE_PAPERLESS_PREFERENCE_BACK_TAPPED,
  ACTION_PROFILE_PAPERLESS_PREFERENCE_FNZ_ADVISOR_CHANGE_TAPPED,
  ACTION_PROFILE_PAPERLESS_PREFERENCE_FNZ_DIRECT_CHANGE_TAPPED,
  ACTION_PROFILE_PAPERLESS_PREFERENCE_LOAD_FAIL_ONLINE_TAPPED,
  ACTION_PROFILE_PAPERLESS_PREFERENCE_SAVE_TAPPED,
  PAGE_PROFILE_PAPERLESS_PREFERENCE,
  productDeselected,
  productSelected,
} from './analytics';

export type VoidCallback = (val: boolean) => void;

export type Paperless = {
  DocumentType: string;
  IsPaperless: boolean | null;
};

export type PaperlessReq = {
  documentType: string;
  isPaperless: boolean | null;
};

const SELECT_ALL = 'Select all';

type PaperlessData<T> = T extends 'post' ? PaperlessReq[] : Paperless[];

export type Feedback = {
  title: string;
  text: string;
  hasError: boolean;
  showErrorView?: boolean;
  action?: Action[];
  isConnectionError?: boolean;
};

export const reduceToMap = (data: Paperless[]) => {
  return data.reduce((obj, item) => {
    return { ...obj, [item.DocumentType]: item.IsPaperless };
  }, {});
};

type BeforeRemoveEvent = EventArg<
  'beforeRemove',
  true,
  {
    action: Readonly<{
      type: string;
      payload?: object;
      source?: string;
      target?: string;
    }>;
  }
>;

const log = getLogger(usePaperlessPreferencesViewModel.name);

export function usePaperlessPreferencesViewModel() {
  const { navigate, addListener, dispatch } = useAppStackNavigation();
  const { mutateAsync: putCommunicationPreferences } =
    usePutCommunicationPreferences();
  const {
    data: communicationPreferences,
    isSuccess,
    isError,
  } = useGetCommunicationPreferences();
  const { data: customer } = useCustomer();
  const { trackUserEvent } = useAnalytics();

  const [paperlessPreferences, setPaperlessPreferences] = useState<Paperless[]>(
    []
  );
  const [isLoading, setIsLoading] = useState(false);
  const [event, setEvent] = useState<BeforeRemoveEvent>();
  const [isOpen, setIsOpen] = useState(false);
  const [isFnz, setIsFnz] = useState(false);
  const [isCanary, setIsCanary] = useState(false);

  const [feedback, setFeedback] = useState<Feedback>({
    title: '',
    text: '',
    hasError: false,
    showErrorView: false,
    action: [],
    isConnectionError: false,
  });

  const form = useForm({
    resolver: zodResolver(PaperlessFormSchema),
  });

  const FNZCustomer = customer?.Products.find(
    (product) => product.ProductSubType === 'MyMoney'
  );

  const canaryCustomer = customer?.Products.find(
    (product) => product.__tag === 'AvivaOnlineMotorProduct'
  );

  const customerData = { FNZCustomer, canaryCustomer };

  useOnPageLoad({ pageTag: PAGE_PROFILE_PAPERLESS_PREFERENCE });

  const goingBackAlert = useCallback(
    (e: BeforeRemoveEvent) => {
      trackUserEvent(ACTION_PROFILE_PAPERLESS_PREFERENCE_BACK_TAPPED);
      if (!form.formState.isDirty) {
        // If we don't have unsaved changes, then we don't need to do anything
        return;
      }

      e?.preventDefault();

      if (isOpen) {
        setIsOpen(false);
      } else {
        setEvent(e);
        setIsOpen(true);
        setFeedback({
          title: 'Unsaved changes',
          text: 'Your unsaved changes will be lost if you continue. Do you wish to continue or go back and save?',
          hasError: true,
          showErrorView: false,
        });
      }
    },
    [form.formState.isDirty, isOpen, trackUserEvent]
  );

  useEffect(() => {
    const unsubscribe = addListener('beforeRemove', goingBackAlert);

    return unsubscribe;
  }, [addListener, goingBackAlert]);

  useEffect(() => {
    async function fetchData() {
      try {
        setIsLoading(true);

        if (isError) {
          setFeedback({
            title: '',
            text: 'Sorry, we can’t load your paperless preferences at the moment. You may still be able to on our website',
            hasError: false,
            showErrorView: true,
          });
          return;
        }
        if (!isSuccess) {
          return;
        }

        const investmentsByAdviser =
          communicationPreferences.paperlessPolicyDocuments.find(
            (policy) =>
              policy.DocumentType === 'Investments bought through an adviser'
          );
        if (investmentsByAdviser?.IsPaperless === null) {
          setIsFnz(true);
          return;
        }
        const investmentsDirect =
          communicationPreferences.paperlessPolicyDocuments.find(
            (policy) => policy.DocumentType === 'Investments bought direct'
          );
        if (investmentsDirect?.IsPaperless === null) {
          setIsCanary(true);
          return;
        }

        if (communicationPreferences.paperlessPolicyDocuments.length) {
          const allSelected =
            communicationPreferences.paperlessPolicyDocuments.every(
              (v) => v.IsPaperless
            );

          setPaperlessPreferences([
            { DocumentType: SELECT_ALL, IsPaperless: allSelected },
            ...communicationPreferences.paperlessPolicyDocuments,
          ]);

          const formValues = reduceToMap([
            { DocumentType: SELECT_ALL, IsPaperless: allSelected },
            ...communicationPreferences.paperlessPolicyDocuments,
          ]);

          form.reset(formValues);
        }
      } catch (error) {
        log.debug(error);
        setFeedback({
          title: '',
          text: 'Sorry, we can’t load your paperless preferences at the moment. You may still be able to on our website',
          hasError: false,
          showErrorView: true,
        });
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [
    form,
    isError,
    communicationPreferences?.paperlessPolicyDocuments,
    isSuccess,
  ]);

  const constructPaperlessData = <T extends 'post' | 'get'>(
    data: Paperless[],
    formValues: Record<string, boolean | null>,
    method: T
  ): PaperlessData<T> =>
    data.map((policy) =>
      method === 'post'
        ? {
            documentType: policy.DocumentType,
            isPaperless: formValues[policy.DocumentType],
          }
        : {
            DocumentType: policy.DocumentType,
            IsPaperless: formValues[policy.DocumentType],
          }
    ) as PaperlessData<T>;

  const onSubmit = async (formValues: PaperlessForm) => {
    trackUserEvent(ACTION_PROFILE_PAPERLESS_PREFERENCE_SAVE_TAPPED);
    try {
      const response = await NetInfo.fetch();

      if (!response.isConnected) {
        setIsOpen(true);
        setFeedback({
          title: t('common.noInternetConnectionDialog.title'),
          text: t('common.noInternetConnectionDialog.copy'),
          hasError: true,
          action: [
            { title: 'Retry', actionOnPress: () => onSubmit(formValues) },
          ],
          isConnectionError: true,
        });
        return;
      }

      setIsLoading(true);

      const dataToSend = constructPaperlessData(
        paperlessPreferences,
        formValues,
        'post'
      ).filter((option) => option.documentType !== SELECT_ALL);

      await putCommunicationPreferences({
        paperlessPolicyDocuments: dataToSend,
      });
      form.reset(formValues);
      setIsOpen(true);
      setFeedback({
        title: 'Paperless preferences saved!',
        text: 'Thank you, your paperless preferences have been updated successfully. Please note, any changes could take up to 24 hours to take effect. ',
        hasError: false,
        showErrorView: false,
      });
    } catch (error) {
      setIsOpen(true);
      setFeedback({
        title: 'Something went wrong',
        text: 'Sorry, we can’t update your paperless preferences at the moment. You may still be able to on our website.',
        hasError: true,
        showErrorView: false,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const selectOptions = (field: ControllerRenderProps<FieldValues, string>) => {
    return (value: boolean) => {
      const fieldName = field.name.toLocaleLowerCase().replaceAll(' ', '-');
      if (value) {
        trackUserEvent(productSelected(fieldName));
      } else {
        trackUserEvent(productDeselected(fieldName));
      }
      field.onChange(value);
      const formValues = form.getValues();

      if (field.name !== SELECT_ALL && value) {
        const fieldValues = form.watch();

        const allSelected = Object.entries(fieldValues).every(
          ([formKey, formValue]) => formKey === SELECT_ALL || formValue
        );

        form.setValue(SELECT_ALL, allSelected);
      }

      if (field.name !== SELECT_ALL && !value) {
        form.setValue(SELECT_ALL, false, {
          shouldDirty: true,
        });
      }

      if (field.name === SELECT_ALL) {
        Object.keys({ ...formValues }).forEach((key) =>
          form.setValue(key, value, {
            shouldDirty: true,
          })
        );
      }

      const updatedPaperlessPreferences = constructPaperlessData(
        paperlessPreferences,
        formValues,
        'get'
      );
      setPaperlessPreferences(updatedPaperlessPreferences);
    };
  };

  const sendAnalyticsBasedOnUserType = (type: string) => {
    const options = {
      fnz: ACTION_PROFILE_PAPERLESS_PREFERENCE_FNZ_ADVISOR_CHANGE_TAPPED,
      canary: ACTION_PROFILE_PAPERLESS_PREFERENCE_FNZ_DIRECT_CHANGE_TAPPED,
      online: ACTION_PROFILE_PAPERLESS_PREFERENCE_AVIVA_ONLINE_CHANGE_TAPPED,
      online_error: ACTION_PROFILE_PAPERLESS_PREFERENCE_LOAD_FAIL_ONLINE_TAPPED,
    };
    trackUserEvent(options[type as keyof typeof options]);
  };

  const navigateToPaperlessPreferencesDocuments =
    (type: string) => async () => {
      const response = await NetInfo.fetch();

      if (!response.isConnected) {
        setIsOpen(true);
        setFeedback({
          title: t('common.noInternetConnectionDialog.title'),
          text: t('common.noInternetConnectionDialog.copy'),
          hasError: true,
          action: [
            {
              title: 'Retry',
              actionOnPress: () =>
                navigateToPaperlessPreferencesDocuments(type),
            },
          ],
          isConnectionError: true,
        });
        return;
      }
      if (isOpen) {
        setIsOpen(false);
      }
      sendAnalyticsBasedOnUserType(type);

      navigate('Paperless preferences documents');
    };

  const navigateToPaperlessPreferencesOnline = (type: string) => async () => {
    const response = await NetInfo.fetch();

    if (!response.isConnected) {
      setIsOpen(true);
      setFeedback({
        title: t('common.noInternetConnectionDialog.title'),
        text: t('common.noInternetConnectionDialog.copy'),
        hasError: true,
        action: [
          {
            title: 'Retry',
            actionOnPress: () => navigateToPaperlessPreferencesOnline(type),
          },
        ],
        isConnectionError: true,
      });
      return;
    }
    if (isOpen) {
      setIsOpen(false);
    }
    sendAnalyticsBasedOnUserType(type);

    navigate('Paperless preferences online');
  };

  const navigateBack = () => {
    trackUserEvent(ACTION_PROFILE_PAPERLESS_PREFERENCE_BACK_TAPPED);
    setIsOpen(false);
    if (event) {
      dispatch(event.data.action);
    }
  };

  return {
    selectOptions,
    paperlessPreferences,
    form,
    onSubmit,
    isLoading,
    isOpen,
    setIsOpen,
    feedback,
    navigateToPaperlessPreferencesOnline,
    navigateToPaperlessPreferencesDocuments,
    navigateBack,
    customerData,
    isFnz,
    isCanary,
  };
}
