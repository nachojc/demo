import { webLinks } from '@constants/web-links';
import { WebViewComponent } from '@src/components/web-view';

export const PaperlessDocumentPreferencesScreen = () => {
  return (
    <WebViewComponent ssoEnabled source={{ uri: webLinks.paperlessDocs }} />
  );
};
