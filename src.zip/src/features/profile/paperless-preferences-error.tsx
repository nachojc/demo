import { Text, YStack } from '@aviva/ion-mobile';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { ScrollableScreen } from '@src/components/scrollable-screen';
import { isIpad } from '@src/utils/is-ipad';

import { PAGE_PROFILE_PAPERLESS_PREFERENCE_LOAD_FAIL } from './analytics';
import { usePaperlessPreferencesViewModel } from './paperless-preferences-view-model';

type PaperlessPreferencesErrorViewProps = {
  model: ReturnType<typeof usePaperlessPreferencesViewModel>;
};

export const PaperlessPreferencesErrorView = ({
  model,
}: PaperlessPreferencesErrorViewProps) => {
  const { feedback, navigateToPaperlessPreferencesOnline } = model;
  useOnPageLoad({ pageTag: PAGE_PROFILE_PAPERLESS_PREFERENCE_LOAD_FAIL });

  return (
    <ScrollableScreen>
      <YStack tablet={isIpad} padding="$xl">
        <Text fontVariant="body-regular-Gray800">
          {feedback.text}{' '}
          <Text
            tamaguiTextProps={{
              onPress: navigateToPaperlessPreferencesOnline('online_error'),
            }}
            fontVariant="body-regular-Tertiary800"
            decoration="underline"
          >
            here
          </Text>
        </Text>
      </YStack>
    </ScrollableScreen>
  );
};
