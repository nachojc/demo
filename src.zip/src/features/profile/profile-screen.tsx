import {
  Button,
  ButtonVariant,
  Link,
  LoadingState,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';
import { SectionList } from 'react-native';

import {
  BorderLine,
  Divider,
  DividerContainer,
  ListItem,
  ListItemContainer,
} from './profile-screen.styles';
import {
  ProfileListItem,
  ProfileSectionListData,
  useProfileViewModel,
} from './use-profile-view-model';

type ProfileScreenViewProps = {
  model: ReturnType<typeof useProfileViewModel>;
};

const noFullyUnderlinedSectionsAtEnd = 2;

const renderListItem = ({
  item,
  index,
  section,
}: {
  item: ProfileListItem;
  index: number;
  section: ProfileSectionListData;
}) => {
  if (item.navigation) {
    return (
      <YStack tabletNarrow={isIpad}>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          marginBottom="$0"
          onPress={item.action}
        >
          {item.title}
        </Button>
      </YStack>
    );
  }

  return (
    <YStack tablet={isIpad}>
      {index === 0 && <BorderLine />}
      <ListItemContainer>
        <ListItem {...(item.editable ? { onPress: item.action } : {})}>
          <YStack>
            {!!item.title && (
              <Text
                fontVariant="body-semibold-Secondary800"
                tamaguiTextProps={{
                  marginBottom: '$sm',
                }}
                testID={`item-title-${item.title}`}
              >
                {item.title}
              </Text>
            )}
            {item.value?.map((value, i) => {
              return (
                <Text
                  fontVariant="small-regular-Gray800"
                  testID={`item-value-${value}`}
                  key={value ?? '' + i.toString()}
                >
                  {value}
                </Text>
              );
            })}
          </YStack>

          {item.editable && (
            <Link onPress={item.action} height="$6" accessibilityLabel="Edit">
              Edit
            </Link>
          )}
        </ListItem>
      </ListItemContainer>
      {/* Last 2 list items should have full width underline */}
      {index >= section.data.length - noFullyUnderlinedSectionsAtEnd ? (
        <BorderLine />
      ) : (
        <DividerContainer>
          <Divider />
        </DividerContainer>
      )}
    </YStack>
  );
};

export const ProfileScreenView = ({ model }: ProfileScreenViewProps) => {
  const { profileSectionListData, isLoading } = model;

  return (
    <>
      {isLoading && <LoadingState fullscreen text="oneMoment" />}
      <SectionList
        sections={profileSectionListData}
        renderSectionHeader={({ section: { title } }) => (
          <YStack tablet={isIpad}>
            <Text
              fontVariant="heading5-semibold-Secondary800"
              tamaguiTextProps={{
                marginTop: '$xxxl',
                marginBottom: '$lg',
                marginLeft: '$xl',
                testID: `section-header-${title}`,
              }}
            >
              {title}
            </Text>
          </YStack>
        )}
        renderItem={renderListItem}
        contentContainerStyle={{
          justifyContent: 'center',
        }}
        stickySectionHeadersEnabled={false}
        keyExtractor={(item, index) => item.title + index}
      />
    </>
  );
};

export const ProfileScreen = () => {
  const model = useProfileViewModel();
  return <ProfileScreenView model={model} />;
};
