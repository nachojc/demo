import { Stack, styled, XStack } from '@aviva/ion-mobile';

export const ListItemContainer = styled(Stack, {
  name: 'ProfileContainer',
  backgroundColor: '$White',
});

export const ListItem = styled(XStack, {
  name: 'Section',
  backgroundColor: '$White',
  padding: '$xl',
  justifyContent: 'space-between',
});

export const DividerContainer = styled(Stack, {
  backgroundColor: '$White',
});

export const Divider = styled(Stack, {
  height: '$0.25',
  backgroundColor: '$Gray200',
  marginLeft: '$xl',
});

export const BorderLine = styled(Stack, {
  height: '$0.25',
  backgroundColor: '$Gray300',
});
