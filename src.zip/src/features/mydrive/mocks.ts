import {
  Journey,
  MyDriveScoringAverage,
  MyDriveTrip,
  ScoreSummary,
} from '@src/validation/schemas/mydrive';
import { AvivaOnlineMotorProduct } from '@src/validation/schemas/product/motor/aviva-online-motor-product';
import { sub } from 'date-fns';

export const mockStartDateString = '1995-12-17T00:00:00.000Z';
export const mockEndDateString = '1995-12-17T01:01:01.000Z';

export const mockUseJourneysTabResponse = {
  textEmptyState: 'a',
  journeys: [
    {
      journeyId: 'an-id-of-a-great-journey',
      distance: 666,
      duration: 123,
      overallScore: 55,
      transportMode: 'Driver',
      startDate: mockStartDateString,
      endDate: mockEndDateString,
      events: {},
      partyId: '',
      points: [
        { latitude: 2, longitude: 3 },
        { latitude: 102, longitude: 356 },
      ],
      reconstructedStartGeometry: [{ latitude: 10, longitude: 11 }],
      componentScores: {
        acceleration: 1,
        braking: 2,
        cornering: 3,
        distractedDriving: 1,
        speeding: 2,
      },
    },
  ],
  journeyCardTapped: jest.fn(),
  serverError: {
    title: '',
    copy: '',
    action: [],
    isOffline: false,
  },
};

export const mockbaseAoMotorProduct: AvivaOnlineMotorProduct = {
  DisplayName: 'Motor',
  ProductType: 'Motor',
  PolicyNumber: '720546022',
  SecurePolicyNumber: 'AOMPX1',
  IsLoaded: true,
  StartDate: '10/05/2022',
  RenewalDate: '10/05/2023',
  MyDriveMileageCutoff: '29/05/2023',
  TotalAnnualPremium: 100,
  PaymentFrequency: 'Yearly',
  AutomaticRenewal: true,
  IsAoMotorProduct: true,
  DPALevel: '1',
  CanAcquireMyDriveScoreBeforeRenewal: true,
  Vehicles: [
    {
      Registration: 'SK15 9EK',
      CoverTypeName: 'Comprehensive',
      Make: 'Toyota',
      Model: 'AVENSIS EXCEL D-4D',
      MainDriver: {
        FirstName: 'David',
        LastName: 'Joe',
        DateOfBirth: '01/07/1981',
        NoClaimDiscount: {
          NoClaimsDiscountType: 'Protected',
          NumberOfYears: 10,
        },
      },
      AdditionalDrivers: [
        {
          FirstName: 'Maria',
          LastName: 'Johnson',
          DateOfBirth: '01/02/1980',
          NoClaimDiscount: {
            NoClaimsDiscountType: 'Unprotected',
            NumberOfYears: 2,
          },
        },
        {
          FirstName: 'Arnold',
          LastName: 'Limper',
          DateOfBirth: '01/04/1980',
          NoClaimDiscount: {
            NoClaimsDiscountType: 'Protected',
            NumberOfYears: 5,
          },
        },
      ],
      VehicleUsage: 'Social',
      OvernightLocation: 'Garage',
      AnnualMileage: '10,000',
      AdditionalCoverDetails: [
        {
          AddOnType: 'Liability Car (NL)',
          AddOnTypeName: 'Liability Car (NL)',
          AddOnTypeCategory: 'No breakdown cover',
          AddOnCostAnnual: 5000,
          StartDate: '10/05/2022',
          EndDate: '10/05/2023',
          IsIncludedInCover: true,
        },
        {
          AddOnType: 'RentalCarsExcessCover',
          AddOnTypeName: 'Rental cars excess cover',
          AddOnTypeCategory: null,
          AddOnCostAnnual: 0.0,
          StartDate: '22/02/2022',
          EndDate: '22/02/2023',
          IsIncludedInCover: true,
        },
        {
          AddOnType: 'CarPersonalBelongings',
          AddOnTypeName: 'Car personal belongings',
          AddOnTypeCategory: null,
          AddOnCostAnnual: 0.0,
          StartDate: '22/02/2022',
          EndDate: '22/02/2023',
          IsIncludedInCover: true,
        },
        {
          AddOnType: 'CourtesyCar',
          AddOnTypeName: 'Courtesy car',
          AddOnTypeCategory: null,
          AddOnCostAnnual: 0.0,
          StartDate: '22/02/2022',
          EndDate: '22/02/2023',
          IsIncludedInCover: false,
        },
        {
          AddOnType: 'DrivingOtherPeoplesCars',
          AddOnTypeName: 'Driving other peoples cars',
          AddOnTypeCategory: null,
          AddOnCostAnnual: 0.0,
          StartDate: '22/02/2022',
          EndDate: '22/02/2023',
          IsIncludedInCover: false,
        },
      ],
      Excess: {
        VoluntaryExcess: 100,
        WindscreenRepairExcess: 100,
        WindscreenReplacementExcess: 100,
        NonApprovedRepairerExcess: 100,
        CarTypeExcess: 100,
        TotalExcess: 100,
        YoungDriverExcess: 100,
        NonApprovedWindScreenRepairExcess: 100,
        NonApprovedWindscreenReplacementExcess: 100,
        CompulsoryExcess: 100,
        HighRiskExcess: 100,
      },
    },
  ],
  __tag: 'AvivaOnlineMotorProduct',
};

export const mockAoProductWithMissingDates: AvivaOnlineMotorProduct = {
  ...mockbaseAoMotorProduct,
  RenewalDate: '',
  MyDriveMileageCutoff: '',
};

export const mockCustomerAoProduct: AvivaOnlineMotorProduct = {
  ...mockbaseAoMotorProduct,
  IsLoaded: true,
  SecurePolicyNumber: 'CustomerProduct',
};
export const mockPolicyAoProduct: AvivaOnlineMotorProduct = {
  ...mockbaseAoMotorProduct,
  IsLoaded: true,
  SecurePolicyNumber: 'PolicyProduct',
};

export const initialScore = {
  overallScore: 0,
  accelerationScore: 0,
  brakingScore: 0,
  corneringScore: 0,
  distractedDrivingScore: 0,
  speedingScore: 0,
  numberOfTrips: 0,
  distance: 0,
  duration: 0,
};

export const mockStartOfToday = new Date(mockStartDateString);
export const mockThirtyDaysInPastFromTodayStart = sub(mockStartOfToday, {
  days: 30,
});
export const baseMyDriveScoreSummary: Pick<
  ScoreSummary,
  'startDate' | 'endDate' | 'partyId'
> = {
  startDate: mockThirtyDaysInPastFromTodayStart.toISOString(),
  endDate: mockStartOfToday.toISOString(),
  partyId: 'P4rty',
};

export const mockScoringAverage: MyDriveScoringAverage = {
  averageScore: 69,
  tripScoringAverage: {
    componentScore: {
      braking: 69,
      acceleration: 69,
      cornering: 69,
      distractedDriving: 69,
      speeding: 69,
    },
  },
};

export const mockMyDriveScoreSummary: ScoreSummary = {
  ...baseMyDriveScoreSummary,
  overallScore: 69,
  accelerationScore: 10,
  brakingScore: 20,
  corneringScore: 30,
  distractedDrivingScore: 40,
  speedingScore: 50,
  distance: 30024,
  duration: 60000,
  numberOfTrips: 420,
};

export const mockEmptyScoreSummary: ScoreSummary = {
  ...baseMyDriveScoreSummary,
  overallScore: 0,
  accelerationScore: 0,
  brakingScore: 0,
  corneringScore: 0,
  distractedDrivingScore: 0,
  speedingScore: 0,
  distance: 0,
  duration: 0,
  numberOfTrips: 0,
};

export const mockTrip: MyDriveTrip = {
  dateStarted: mockStartDateString,
  dateEnded: mockEndDateString,
  duration: 420,
  distance: 420,
  events: {},
  geometry: [],
  id: 'R4ceR',
  score: 69,
  scores: {
    overall: 69,
    subScores: {
      acceleration: 69,
      braking: 69,
      cornering: 69,
      distractedDriving: 69,
      speeding: 69,
    },
  },
  status: 'G00D',
  transportMode: 'Honda civic',
};

export const journeyId = '12345';
export const mockJourney: Journey = {
  journeyId,
  partyId: 'P4rty',
  startDate: mockStartDateString,
  endDate: mockEndDateString,
  distance: 420,
  duration: 420,
  overallScore: 69,
  transportMode: 'unknown',
  events: {},
  geometry: [],
  componentScores: {
    acceleration: 69,
    braking: 69,
    cornering: 69,
    speeding: 69,
    distractedDriving: 69,
  },
};

export const mockJourneys = ((idList: string[]) =>
  idList.map((id) => ({
    ...mockJourney,
    journeyId: id,
  })))(['1', '2', '3']);

export const mockInsightWeek = {
  partyId: '',
  overallScore: 69,
  distance: 69,
  duration: 69,
  numberOfTrips: 69,
  startDate: 'timestampStart',
  endDate: 'timestampEnd',
  accelerationScore: 10,
  brakingScore: 20,
  corneringScore: 30,
  distractedDrivingScore: 40,
  speedingScore: 50,
};

export const mockInsightsData = {
  overallScore: 10,
  accelerationScore: 10,
  brakingScore: 10,
  corneringScore: 10,
  distractedDrivingScore: 10,
  speedingScore: 10,
  distance: 100000,
  duration: 36000,
  numberOfTrips: 11,
};
