export const MetresToMilesCoefficient = 0.000621371192;

export const MaxFailedAttempts = 2;
