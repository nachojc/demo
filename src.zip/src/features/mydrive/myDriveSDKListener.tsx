import { setSignedToken, tokenEventEmitter } from '@aviva/rn-bridge-ims/src';
import { useAuth } from '@hooks/use-auth';
import { myDriveActivationId, username } from '@interfaces/storage';
import { useObserve } from '@legendapp/state/react';
import {
  LoginMethodStore,
  LoginMethodTypes,
} from '@src/utils/api/service-analytics/login-service-analytics';
import * as Location from 'expo-location';
import * as TaskManager from 'expo-task-manager';
import { PropsWithChildren, useCallback, useEffect, useState } from 'react';

import { useMyDriveSDK } from './utils/mydrive-sdk';

export const MyDriveSDKListener = ({ children }: PropsWithChildren) => {
  const { printInImsLogs, signToken } = useMyDriveSDK();
  const { signInForBackgroundService, hasSignedInThisSession } = useAuth();
  const [activationId, setActivationId] = useState(myDriveActivationId.get());

  const usernameForLogin = username.get();
  const locationListenerKey = 'locationUpdated';
  const signTokenListenerKey = 'signToken';

  //To sign the token the user has to be authenticated, so we need to check if we need to login
  //when signing the token.
  const shouldLogin = useCallback(async () => {
    if (
      !hasSignedInThisSession &&
      myDriveActivationId.get() &&
      usernameForLogin
    ) {
      try {
        printInImsLogs(
          '[MyDriveSDKListener] Logging user in for background session'
        );
        LoginMethodStore.set(LoginMethodTypes.MyDriveRefreshToken);
        await signInForBackgroundService(usernameForLogin);
      } catch (error) {
        printInImsLogs('[MyDriveSDKListener] Login error: ' + error);
      }
    }
  }, [
    hasSignedInThisSession,
    printInImsLogs,
    signInForBackgroundService,
    usernameForLogin,
  ]);

  //Listener for the signToken event coming from IMS SDK.
  //When this event fires, will need to take the token, sign it and return it to the IMS SDK.
  const setupSignTokenListener = useCallback(() => {
    if (tokenEventEmitter.listenerCount(signTokenListenerKey) === 0) {
      printInImsLogs('[MyDriveSDKListener] Sign token listener setup');

      tokenEventEmitter.addListener(signTokenListenerKey, async (event) => {
        if (myDriveActivationId.get()) {
          await shouldLogin();

          printInImsLogs('[MyDriveSDKListener] Signing token from RN');
          await signToken({
            unsignedJwt: event,
          })
            .then((signedToken) => {
              setSignedToken(signedToken.signedJwt);
            })
            .catch(() => {
              setSignedToken('');
            });
        } else {
          setSignedToken('');
        }
      });
    }
  }, [printInImsLogs, shouldLogin, signToken]);

  //Listener to check for location updates, this will ensure that if location is being
  //updated RN is awoken to listen for the sign token request.
  const setupLocationListener = useCallback(async () => {
    const backgroundPermission = await Location.getBackgroundPermissionsAsync();
    const foregroundPermission = await Location.getForegroundPermissionsAsync();

    if (
      !backgroundPermission.granted ||
      !foregroundPermission.granted ||
      TaskManager.isTaskDefined(locationListenerKey)
    ) {
      printInImsLogs(
        '[MyDriveSDKListener] Location listener cannot be setup. ' +
          'backgroundPermission.granted: ' +
          backgroundPermission.granted +
          ' foregroundPermission.granted: ' +
          foregroundPermission.granted +
          ' TaskManager.isTaskDefined: ' +
          TaskManager.isTaskDefined(locationListenerKey)
      );

      return;
    }

    printInImsLogs('[MyDriveSDKListener] Setting up location listener');

    await Location.startLocationUpdatesAsync(locationListenerKey, {
      accuracy: Location.Accuracy.Highest,
      pausesUpdatesAutomatically: true,
    }).catch((e) => {
      console.warn('Error starting location update', e);
    });

    TaskManager.defineTask(locationListenerKey, ({ data, error }) => {
      if (error) {
        printInImsLogs(
          '[MyDriveSDKListener] Error when executing location update task: ' +
            error
        );
        return;
      }
      if (data) {
        setupSignTokenListener();
      }
    });
  }, [printInImsLogs, setupSignTokenListener]);

  //We need to listen to myDriveActivationId changes to ensure we set up these listeners
  //when a user activates MyDrive.
  useObserve(myDriveActivationId, ({ value }) => setActivationId(value ?? ''));

  useEffect(() => {
    if (activationId) {
      setupLocationListener();
      setupSignTokenListener();
    }
  }, [setupSignTokenListener, setupLocationListener, activationId]);

  return <>{children}</>;
};
