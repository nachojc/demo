import { WebViewComponent } from '@src/components/web-view';

export const IcoOrgUkScreen = () => {
  return (
    <WebViewComponent
      source={{
        uri: 'https://www.ico.org.uk',
      }}
    />
  );
};
