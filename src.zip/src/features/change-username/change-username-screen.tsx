import { webLinks } from '@constants/web-links';
import { WebViewComponent } from '@src/components/web-view';

export const ChangeUsernameScreen = () => {
  return (
    <WebViewComponent ssoEnabled source={{ uri: webLinks.changeUsername }} />
  );
};
