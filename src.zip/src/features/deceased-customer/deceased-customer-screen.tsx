import {
  getTokens,
  getVariableValue,
  Image,
  PhoneCallBox,
  Stack,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { webLinks } from '@constants/web-links';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useAuthStackNavigation } from '@src/navigation/auth/hooks';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

import {
  CALL_US_TAPPED,
  CONTACT_US_TAPPED,
  PAGE_DECEASED_CUSTOMER_CONTACT_US,
} from './analytics';

export const DeceasedCustomerScreen = () => {
  const tokens = getTokens();
  const { t } = useTranslation(undefined, { keyPrefix: 'deceasedCustomer' });
  const { trackUserEvent } = useAnalytics();
  const { navigate } = useAuthStackNavigation();

  useOnPageLoad({ pageTag: PAGE_DECEASED_CUSTOMER_CONTACT_US });

  const openContactUsWebLink = () => {
    trackUserEvent(CONTACT_US_TAPPED);
    navigate('Web View', { url: webLinks.contactUs });
  };

  return (
    <YStack
      justifyContent="center"
      space={'$xxl'}
      height="100%"
      tablet={isIpad}
    >
      <Stack alignItems="center" space={'$xl'} px="$xxxl">
        <Image
          accessibilityIgnoresInvertColors
          testID="DeceasedCustomerScreenView.PotPlantImage"
          style={{
            width: getVariableValue(tokens.size[12]),
            height: getVariableValue(tokens.size[12]),
          }}
          source={require('assets/plant-pot/plant-pot.png')}
        />
        <Text
          fontVariant={'heading5-semibold-Secondary800'}
          tamaguiTextProps={{
            accessibilityLabel: 'policy not shown',
          }}
        >
          {t('title')}
        </Text>
        <Text
          tamaguiTextProps={{ textAlign: 'center' }}
          fontVariant={'body-regular-Gray800'}
        >
          {t('contactInfo')}
          <Text fontVariant={'body-semibold-Gray800'}>
            {t('supportNumber')}
          </Text>
          {t('contactInfo1')}
          <Text
            decoration="underline"
            tamaguiTextProps={{
              onPress: openContactUsWebLink,
            }}
            fontVariant={'body-regular-Tertiary800'}
          >
            {t('contactInfo2')}
          </Text>
          {t('contactInfo3')}
        </Text>
      </Stack>
      <PhoneCallBox
        phone={t('supportNumber')}
        containerProps={{ paddingHorizontal: '$xl' }}
        tags={{
          onOpen: CALL_US_TAPPED,
        }}
      />
      <Stack px="$xl">
        <Text fontVariant={'body-semibold-Gray800'}>{t('weekDay')}</Text>
        <Text
          tamaguiTextProps={{ mb: '$xl' }}
          fontVariant={'body-regular-Gray800'}
        >
          {t('weekTiming')}
        </Text>
        <Text fontVariant={'small-regular-Gray800'}>{t('protectionInfo')}</Text>
      </Stack>
    </YStack>
  );
};
