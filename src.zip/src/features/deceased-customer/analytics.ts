import { APP_BASE } from '@constants/analytics';

const PAGE_DECEASED_CUSTOMER_CONTACT_US = `${APP_BASE}log-out|deceased-customer-contact`;
const CONTACT_US_TAPPED = `${PAGE_DECEASED_CUSTOMER_CONTACT_US}|contact-us-tapped`;
const CALL_US_TAPPED = `${PAGE_DECEASED_CUSTOMER_CONTACT_US}|call-us-tapped`;

export { CALL_US_TAPPED, CONTACT_US_TAPPED, PAGE_DECEASED_CUSTOMER_CONTACT_US };
