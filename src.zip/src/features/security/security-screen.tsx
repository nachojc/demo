import { Dialog, List, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

import { useSecurity } from './use-security';

export const SecurityScreen = () => {
  const { t } = useTranslation(undefined, { keyPrefix: 'security' });

  const {
    errorDialog,
    handleMfaPreferences,
    navigateToBiometricSettingsScreen,
    onChangePassword,
    openChangeUsernameScreen,
    openDeviceManagementScreen,
    showBiometricSection,
  } = useSecurity();

  const listItems = [
    ...(showBiometricSection
      ? [
          {
            title: t('biometricLogin'),
            onPress: navigateToBiometricSettingsScreen,
          },
        ]
      : []),
    {
      title: t('twoStepVerification'),
      onPress: handleMfaPreferences,
    },
    {
      title: t('changeUsername'),
      onPress: openChangeUsernameScreen,
    },
    {
      title: t('changePassword'),
      onPress: onChangePassword,
    },
    {
      title: t('deviceManagement'),
      onPress: openDeviceManagementScreen,
    },
  ];

  return (
    <YStack tablet={isIpad} flex={1}>
      <Dialog
        open={errorDialog.show}
        title={errorDialog.title}
        copy={errorDialog.message}
        actions={[
          {
            title: 'Retry',
            actionOnPress: () => {
              errorDialog.action();
              handleMfaPreferences();
            },
          },
        ]}
        cancelButton
        onPressCancel={errorDialog.action}
      />
      <List
        listTitleFontVariant="body-regular-Gray900"
        listProps={{
          marginTop: '$xxl',
          borderTopColor: '$Gray300',
          borderTopWidth: '$xxs',
          borderBottomColor: '$Gray300',
          borderBottomWidth: '$xxs',
          backgroundColor: '$White',
        }}
        listItemProps={{
          backgroundColor: '$White',
        }}
        items={listItems}
      />
    </YStack>
  );
};
