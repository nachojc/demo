import { APP_BASE } from '@constants/analytics';

export const PAGE_SETTINGS_SECURITY = `${APP_BASE}settings|security`;

export const PAGE_SETTINGS_SECURITY_2SV_TAPPED = `${PAGE_SETTINGS_SECURITY}|2sv-tapped`;
export const PAGE_SETTINGS_SECURITY_BIOMETRIC_TAPPED = `${PAGE_SETTINGS_SECURITY}|biometrics-tapped`;
export const PAGE_SETTINGS_SECURITY_CHANGE_USERNAME_TAPPED = `${PAGE_SETTINGS_SECURITY}|change-username-tapped`;
export const PAGE_SETTINGS_SECURITY_CHANGE_PASSWORD_TAPPED = `${PAGE_SETTINGS_SECURITY}|change-password-tapped`;
export const PAGE_SETTINGS_SECURITY_DEVICE_MANAGEMENT_TAPPED = `${PAGE_SETTINGS_SECURITY}|device-management-tapped`;
export const PAGE_SETTINGS_SECURITY_BACK_TAPPED = `${PAGE_SETTINGS_SECURITY}|back-tapped`;
