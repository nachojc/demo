import { useAnalytics } from '@hooks/use-analytics';
import { useBiometrics } from '@hooks/use-biometrics';
import { useMfaPreferences } from '@hooks/use-mfa-preferences';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import NetInfo from '@react-native-community/netinfo';
import { ServerUnderMaintenanceError } from '@src/models';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { MoreScreenNames } from '@src/navigation/app/summary/more-screen-names';
import { useCallback, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import {
  PAGE_SETTINGS_SECURITY,
  PAGE_SETTINGS_SECURITY_2SV_TAPPED,
  PAGE_SETTINGS_SECURITY_BACK_TAPPED,
  PAGE_SETTINGS_SECURITY_BIOMETRIC_TAPPED,
  PAGE_SETTINGS_SECURITY_CHANGE_PASSWORD_TAPPED,
  PAGE_SETTINGS_SECURITY_CHANGE_USERNAME_TAPPED,
  PAGE_SETTINGS_SECURITY_DEVICE_MANAGEMENT_TAPPED,
} from './analytics';

export const useSecurity = () => {
  const { trackUserEvent } = useAnalytics();
  const { navigate, addListener } = useAppStackNavigation();
  const biometric = useBiometrics();
  const [showBiometricSection, setShowBiometricSection] = useState(false);
  const { t } = useTranslation();
  useOnPageLoad({ pageTag: PAGE_SETTINGS_SECURITY });

  const closeDialog = () => {
    setErrorDialog((prev) => ({ ...prev, show: false }));
  };
  const [errorDialog, setErrorDialog] = useState({
    title: t('security.serverMaintenance.title'),
    message: t('security.serverMaintenance.copy'),
    action: closeDialog,
    show: false,
  });

  useEffect(() => {
    const getShouldShowBiometric = async () => {
      setShowBiometricSection(await biometric.shouldShowSetup());
    };
    getShouldShowBiometric();
  }, [biometric]);

  useEffect(() => {
    const unsubscribe = addListener('beforeRemove', () => {
      trackUserEvent(PAGE_SETTINGS_SECURITY_BACK_TAPPED);
    });

    return unsubscribe;
  }, [addListener, trackUserEvent]);

  const changeErrorDialog = useCallback(
    (show?: boolean, title?: string, message?: string, action?: () => void) => {
      setErrorDialog({
        show: show ?? errorDialog.show,
        message: message ?? errorDialog.message,
        title: title ?? errorDialog.title,
        action: action ?? errorDialog.action,
      });
    },
    [errorDialog]
  );

  const mfaPreferences = useMfaPreferences();

  const navigateToBiometricSettingsScreen = () => {
    trackUserEvent(PAGE_SETTINGS_SECURITY_BIOMETRIC_TAPPED);
    navigate(MoreScreenNames.BiometricLogin);
  };

  const handleMfaPreferences = async () => {
    const response = await NetInfo.fetch();
    if (!response.isConnected) {
      changeErrorDialog(
        true,
        t('common.noInternetConnectionDialog.title'),
        t('common.noInternetConnectionDialog.copy')
      );
      return;
    }
    trackUserEvent(PAGE_SETTINGS_SECURITY_2SV_TAPPED);
    try {
      const { data } = await mfaPreferences.refetch({
        cancelRefetch: false,
        throwOnError: true,
      });
      if (data !== null) {
        const webMfaLink =
          data?.enrolledFactor === 'SMS'
            ? 'MyAccount/Mfa/Settings'
            : 'MyAccount/Mfa/Setup';
        navigate(MoreScreenNames.TwoStepVerification, {
          webMfaLink,
        });
      } else {
        navigate(MoreScreenNames.TwoStepVerification, {
          webMfaLink: 'MyAccount/ManageMyAccount',
        });
      }
    } catch (error) {
      if (error instanceof ServerUnderMaintenanceError) {
        changeErrorDialog(
          true,
          t('security.serverMaintenance.title'),
          t('security.serverMaintenance.copy')
        );
      }
    }
  };

  const onChangePassword = () => {
    trackUserEvent(PAGE_SETTINGS_SECURITY_CHANGE_PASSWORD_TAPPED);
    navigate(MoreScreenNames.ChangePassword);
  };

  const openChangeUsernameScreen = () => {
    trackUserEvent(PAGE_SETTINGS_SECURITY_CHANGE_USERNAME_TAPPED);
    navigate(MoreScreenNames.ChangeUsername);
  };

  const openDeviceManagementScreen = () => {
    trackUserEvent(PAGE_SETTINGS_SECURITY_DEVICE_MANAGEMENT_TAPPED);
    navigate(MoreScreenNames.DeviceManagement);
  };

  return {
    handleMfaPreferences,
    navigateToBiometricSettingsScreen,
    showBiometricSection,
    onChangePassword,
    openChangeUsernameScreen,
    openDeviceManagementScreen,
    errorDialog,
  };
};
