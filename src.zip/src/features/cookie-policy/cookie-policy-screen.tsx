import { config } from '@config';
import { WebViewComponent } from '@src/components/web-view';

export const CookiePolicyScreen = () => {
  return (
    <WebViewComponent
      source={{
        uri: config.AVIVA_BASE_URL.get() + '/legal/aviva-cookie-policy.html',
      }}
    />
  );
};
