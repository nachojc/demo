import { useAnalytics } from '@hooks/use-analytics';
import { useLocationServices } from '@hooks/use-location-services';
import {
  useCheckDeviceNotificationPermissions,
  useNotifications,
} from '@hooks/use-notifications';
import { notificationAppPreference } from '@interfaces/storage';
import { useEffect, useState } from 'react';
import { Platform } from 'react-native';

import {
  ACTION_PAGE_NOTIFICATIONS_DISABLE,
  ACTION_PAGE_NOTIFICATIONS_ENABLE,
} from './analytics';

export const useNotificationToggle = () => {
  useCheckDeviceNotificationPermissions();
  const { trackUserEvent } = useAnalytics();
  const [isOpen, setIsOpen] = useState(false);
  const { goToSettings } = useLocationServices();
  const {
    isEnabledOnApp,
    hasBeenSet,
    registerTokens,
    getPermissionStatus,
    enable,
    shouldListenPushNotifications: switcherState,
  } = useNotifications();

  const isIOS = Platform.OS === 'ios';

  const navigateToSettings = () => {
    setIsOpen(false);
    goToSettings();
  };

  useEffect(() => {
    const registerDeviceToken = async () => {
      const { result: deviceSettings } = await getPermissionStatus();

      if (switcherState && deviceSettings === 'granted') {
        registerTokens();
      }
    };
    registerDeviceToken();
  }, [getPermissionStatus, registerTokens, switcherState]);

  const dismissModal = () => {
    setIsOpen(false);
  };

  const onSwitchingValue = async (value: boolean) => {
    const { result: deviceSettings } = await getPermissionStatus();
    //iOS requires at least one request to show Notification on Device Settings
    if (isIOS && deviceSettings === 'denied') {
      await enable();
    } else if (deviceSettings === 'granted' && !isEnabledOnApp) {
      notificationAppPreference.set(true);
    } else {
      setIsOpen(true);
    }

    trackUserEvent(
      value
        ? ACTION_PAGE_NOTIFICATIONS_ENABLE
        : ACTION_PAGE_NOTIFICATIONS_DISABLE
    );
  };

  return {
    onSwitchingValue,
    switcherState,
    isEnabledOnApp,
    navigateToSettings,
    dismissModal,
    isOpen,
    hasBeenSet,
  };
};
