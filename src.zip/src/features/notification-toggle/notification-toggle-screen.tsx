import {
  Button,
  ButtonVariant,
  Dialog,
  Switch,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { isManga } from '@hooks/use-expo-config';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

import { PAGE_SETTINGS_NOTIFICATIONS } from './analytics';
import { useNotificationToggle } from './use-notification-toggle';

export const NotificationToggleScreen = () => {
  const {
    navigateToSettings,
    dismissModal,
    isOpen,
    switcherState,
    onSwitchingValue,
  } = useNotificationToggle();
  const { t } = useTranslation();

  const displayName = isManga()
    ? t('notificationToggle.my_aviva')
    : t('notificationToggle.aviva_wealth');

  const popupText = {
    toEnable: t('notificationToggle.popup_enable', { displayName }),
    toDisable: t('notificationToggle.popup_disable', { displayName }),
  };

  useOnPageLoad({ pageTag: PAGE_SETTINGS_NOTIFICATIONS });

  return (
    <YStack tablet={isIpad} padding="$xl" jc="center">
      <Text
        tamaguiTextProps={{ paddingVertical: '$lg' }}
        fontVariant="body-regular-Secondary800"
      >
        {t('notificationToggle.copy_one')}
      </Text>
      <Text
        tamaguiTextProps={{ paddingVertical: '$lg', marginBottom: '$xl' }}
        fontVariant="body-regular-Secondary800"
      >
        {t('notificationToggle.copy_two')}
      </Text>
      <XStack justifyContent="space-between" marginTop="$xl">
        <Text fontVariant="body-regular-Gray900">
          {t('notificationToggle.copy_three')}
        </Text>
        <Switch
          accessibilityLabel="Toggle app notifications"
          value={switcherState}
          onValueChange={onSwitchingValue}
        />
      </XStack>

      <Dialog
        open={isOpen}
        title={`${switcherState ? 'Disable' : 'Enable'} notifications`}
        copy={switcherState ? popupText.toDisable : popupText.toEnable}
      >
        <Button
          variant={ButtonVariant.BRAND}
          mt="$xl"
          onPress={navigateToSettings}
        >
          Go to settings
        </Button>
        <Button variant={ButtonVariant.LINK_TEXT} onPress={dismissModal}>
          Cancel
        </Button>
      </Dialog>
    </YStack>
  );
};
