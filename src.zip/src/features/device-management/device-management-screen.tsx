import {
  Button,
  ButtonVariant,
  Dialog,
  Icon,
  LoadingState,
  Stack,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { webLinks } from '@constants/web-links';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

import { useDeviceManagementViewModel } from './hooks/use-device-management-view-model';

const pageWidth = '$xl' as const;
const borderWidth = '$xxs' as const;

type DeviceManagementViewProps = {
  model: ReturnType<typeof useDeviceManagementViewModel>;
};
export const DeviceManagementView = ({ model }: DeviceManagementViewProps) => {
  const { t } = useTranslation();
  const { navigate } = useAppStackNavigation();
  return (
    <>
      {model.dialogManager.state.loading && <LoadingState />}
      <YStack tablet={isIpad} flex={1} pt={'$xl'}>
        <XStack
          bg="white"
          w={'100%'}
          justifyContent="space-between"
          alignItems="center"
          px={pageWidth}
          borderColor={'$Gray300'}
          borderTopWidth={borderWidth}
          borderBottomWidth={borderWidth}
        >
          <Stack
            width={40}
            height={40}
            br={20}
            bc="$Gray100"
            jc="center"
            ai="center"
          >
            <Icon name="smartphone" />
          </Stack>

          <Text
            fontVariant={'small-regular-Gray900'}
            tamaguiTextProps={{
              px: '$xl',
              flexGrow: 1,
              testID: getTestId('device-name'),
            }}
          >
            {model.device.name}
            {'\n'}
            {model.device.os}
          </Text>

          <Button
            testID={getTestId('remove-device-btn')}
            variant={ButtonVariant.LINK_TEXT}
            onPress={model.handleOpenDialog}
            pr="$xxl"
          >
            Remove
          </Button>
        </XStack>

        <Text
          fontVariant={'body-regular-Gray900'}
          tamaguiTextProps={{
            px: pageWidth,
            pt: '$xxl',
            testID: getTestId('remove-device-explanation-text'),
          }}
        >
          Reset the app and disconnect this device from your Aviva account. This
          will clear all device details from the app. You will need to log in
          with your security credentials if you want to use the app again.
        </Text>
      </YStack>

      <Dialog
        open={model.dialogManager.state.confirmation}
        title="Remove this device?"
        copy={`Are you sure you want to reset the app and remove this device from your Aviva account?
This will clear all device details from the app.
You will need to log in with your security credentials if you want to use the app again.`}
      >
        <Button
          testID={getTestId('ok-device-deletion-btn')}
          variant={ButtonVariant.BRAND}
          mt="$xl"
          onPress={model.handleDialogRemoveDeviceOk}
        >
          OK
        </Button>
        <Button
          testID={getTestId('remove-device-cancel-btn')}
          variant={ButtonVariant.LINK_TEXT}
          onPress={model.handleDialogRemoveDeviceCancel}
        >
          Cancel
        </Button>
      </Dialog>

      <Dialog
        open={model.dialogManager.state.error}
        // TODO: confirm title here
        title={t('common.genericError.title')}
        copy={t('common.genericError.copy')}
      >
        <Button
          variant={ButtonVariant.BRAND}
          onPress={model.handleCloseErrorDialog}
          mt="$xl"
        >
          OK
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={() => {
            model.handleCloseErrorDialog();
            navigate('Web View', { url: webLinks.contactUs });
          }}
          mt="$xl"
        >
          Contact Us
        </Button>
      </Dialog>
    </>
  );
};

export const DeviceManagementScreen = () => {
  const model = useDeviceManagementViewModel();

  return <DeviceManagementView model={model} />;
};
