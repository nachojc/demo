import { APP_BASE } from '@constants/analytics';

export const PAGE_DEVICE_MANAGEMENT =
  APP_BASE + 'settings|security|device-management';

export const PAGE_DEVICE_MANAGEMENT_REMOVE_DEVICE =
  PAGE_DEVICE_MANAGEMENT + '|remove-device-tapped';

export const PAGE_DEVICE_MANAGEMENT_REMOVE_DEVICE_OK =
  PAGE_DEVICE_MANAGEMENT + '|remove-device-confirmation|ok-tapped';

export const PAGE_DEVICE_MANAGEMENT_REMOVE_DEVICE_CANCEL =
  PAGE_DEVICE_MANAGEMENT + '|remove-device-confirmation|cancel-tapped';
