import {
  Button,
  ButtonVariant,
  getTokens,
  getVariableValue,
  Image,
  PhoneCallBox,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useAuthStackNavigation } from '@src/navigation/auth/hooks';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

import { OpeningTimes } from '../registration';

export const AccountLockedFraudScreen = () => {
  const navigation = useAuthStackNavigation();
  const tokens = getTokens();
  const { t } = useTranslation();

  const times = [
    {
      day: t('accountLocked.weekDay'),
      hours: t('accountLocked.weekTiming'),
    },
    {
      day: t('accountLocked.saturday'),
      hours: t('accountLocked.closed'),
    },
    {
      day: t('accountLocked.sunday'),
      hours: t('accountLocked.closed'),
    },
  ];

  const navigateToLoginScreen = () => {
    navigation.reset({
      index: 0,
      routes: [{ name: 'Log in' }],
    });
  };

  return (
    <YStack flex={1} justifyContent="space-between" tablet={isIpad}>
      <YStack />
      <YStack>
        <YStack space={'$md'} px={'$xxxl'} alignItems="center">
          <Image
            accessibilityIgnoresInvertColors
            testID="AccountLockedFraudScreenView.Padlock"
            style={{
              width: getVariableValue(tokens.size['12']),
              height: getVariableValue(tokens.size['12']),
            }}
            source={require('../../../assets/account-locked.png')}
          />
          <Text
            testID="account-locked-txt"
            fontVariant="heading5-semibold-Secondary800"
          >
            {t('accountLocked.title')}
          </Text>
          <Text
            fontVariant={'body-regular-Gray800'}
            testID="account-locked-sub-txt"
            tamaguiTextProps={{
              textAlign: 'center',
            }}
          >
            {t('accountLocked.fraudCopyOne')}
          </Text>
          <Text
            fontVariant={'body-regular-Gray800'}
            testID="unclock-account-txt"
            tamaguiTextProps={{
              mb: '$xxxl',
              textAlign: 'center',
            }}
          >
            {t('accountLocked.fraudCopyTwo')}
          </Text>
        </YStack>
        <YStack mt="$xxl">
          <PhoneCallBox
            phone={'0800 404 9971'}
            containerProps={{ paddingHorizontal: '$xl' }}
          />
          <OpeningTimes times={times} />
          <Text
            tamaguiTextProps={{ mx: '$xl' }}
            fontVariant={'small-regular-Gray800'}
          >
            {t('accountLocked.jointProtection')}
          </Text>
        </YStack>
      </YStack>
      <Button
        variant={ButtonVariant.LINK_TEXT}
        onPress={navigateToLoginScreen}
        mb="$xxxxl"
      >
        {t('accountLocked.backToLogin')}
      </Button>
    </YStack>
  );
};
