import {
  getTokens,
  getVariableValue,
  Switch,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useBiometrics } from '@hooks/use-biometrics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { getLogger } from '@interfaces/logger';
import { useTranslation } from 'react-i18next';

import {
  PAGE_BIOMETRIC_SETTINGS,
  PAGE_BIOMETRIC_TURN_OFF_BIOMETRICS,
  PAGE_BIOMETRIC_TURN_ON_BIOMETRICS,
} from './analytics';

export const BiometricSettingsScreen = () => {
  const log = getLogger(BiometricSettingsScreen.name);
  const analytics = useAnalytics();
  const biometrics = useBiometrics();
  const tokens = getTokens();
  const { t } = useTranslation();

  useOnPageLoad({ pageTag: PAGE_BIOMETRIC_SETTINGS });

  const toggleBiometrics = () =>
    biometrics.isEnabled ? turnOffBiometrics() : turnOnBiometrics();

  const turnOnBiometrics = async () => {
    analytics.trackUserEvent(PAGE_BIOMETRIC_TURN_ON_BIOMETRICS);

    return biometrics
      .requestPermission()
      .then((permission) => {
        if (permission) {
          biometrics.enable();
        }
      })
      .catch((error) =>
        log.debug(`biometric request permission returned: ${error}`)
      );
  };

  const turnOffBiometrics = () => {
    analytics.trackUserEvent(PAGE_BIOMETRIC_TURN_OFF_BIOMETRICS);
    biometrics.disable();
  };

  return (
    <YStack px={'$xl'} py={'$xxl'} ai="center" h={'100%'}>
      <Text
        fontVariant={'small-regular-Gray900'}
        testID="title"
        tamaguiTextProps={{
          my: getVariableValue(tokens.size[6]),
          w: '100%',
        }}
      >
        {t('biometricSettings.title')}
      </Text>
      <XStack ai="center" jc={'space-between'} w={'100%'}>
        <Text
          fontVariant={'body-semibold-Gray900'}
          tamaguiTextProps={{
            my: getVariableValue(tokens.size[6]),
          }}
        >
          {t('biometricSettings.switchTitle')}
        </Text>
        <Switch value={biometrics.isEnabled} onValueChange={toggleBiometrics} />
      </XStack>
    </YStack>
  );
};
