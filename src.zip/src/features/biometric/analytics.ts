import { APP_BASE } from '@constants/analytics';

export const PAGE_BIOMETRIC_SETTINGS =
  APP_BASE + 'settings|biometrics-settings';

export const PAGE_BIOMETRIC_TURN_ON_BIOMETRICS =
  PAGE_BIOMETRIC_SETTINGS + '|turn-on-biometrics-tapped';

export const PAGE_BIOMETRIC_TURN_OFF_BIOMETRICS =
  PAGE_BIOMETRIC_SETTINGS + '|turn-off-biometrics-tapped';
