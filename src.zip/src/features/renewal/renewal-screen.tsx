import { Stack, Text } from '@aviva/ion-mobile';

export const RenewalScreen = () => {
  /* Refacter the view renewal screen component as common component */
  // Path: /src/features/policy/common/view-renewal/view-renewal-screen.tsx
  // Ticket No: MANGA-5281
  return (
    <Stack ai="center">
      <Text fontVariant="body-bold-BottleDark">Renewal Coming Soon</Text>
    </Stack>
  );
};
