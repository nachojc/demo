import { getTokens, List, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { isManga } from '@hooks/use-expo-config';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { HelpScreenNames } from '@src/navigation/app/help-screens';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { PAGE_HELP_GLOBALNAV } from '@src/navigation/bottom-tabs/analytics';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

import { HELP_FAQS_TAPPED } from '../app-faqs/analytics';
import { HELP_CONTACT_US_TAPPED } from '../contact-us/analytics';

export const HelpScreen = () => {
  useOnPageLoad({ pageTag: PAGE_HELP_GLOBALNAV });
  const { t } = useTranslation();
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const navigateTo = (
    path: typeof HelpScreenNames.ContactUs | typeof HelpScreenNames.AppFaqs,
    analyticsTag: string
  ) => {
    trackUserEvent(analyticsTag);
    navigate(path);
  };
  const tokens = getTokens();
  const contactUs = {
    title: t('help.contactUs'),
    onPress: () =>
      navigateTo(HelpScreenNames.ContactUs, HELP_CONTACT_US_TAPPED),
  };
  const items = isManga()
    ? [
        contactUs,
        {
          title: t('help.appFaqs'),
          onPress: () => navigateTo(HelpScreenNames.AppFaqs, HELP_FAQS_TAPPED),
        },
      ]
    : [contactUs];

  return (
    <YStack tablet={isIpad}>
      <List
        listTitleFontVariant="body-regular-Gray900"
        listProps={{
          marginTop: tokens.space.xxl,
          borderTopColor: '$Gray300',
          borderTopWidth: tokens.space.xxs,
          borderBottomColor: '$Gray300',
          borderBottomWidth: tokens.space.xxs,
          backgroundColor: '$White',
          px: isIpad ? '$xl' : undefined,
        }}
        listItemProps={{
          backgroundColor: '$White',
        }}
        items={items}
      />
    </YStack>
  );
};
