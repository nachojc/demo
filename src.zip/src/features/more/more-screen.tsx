import {
  Button,
  ButtonVariant,
  Dialog as LogoutDialog,
  List,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { getReadableVersion } from '@src/utils/device-info';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';

import { useMore } from './use-more';

export const MoreScreen = () => {
  const { t } = useTranslation();
  const { logoutCancel, isLogoutDialogVisible, handleSignOut, items } =
    useMore();

  return (
    <>
      <YStack f={1} tablet={isIpad}>
        <List
          listTitleFontVariant="body-regular-Gray900"
          listProps={{
            marginTop: '$xxl',
            borderTopColor: '$Gray300',
            borderTopWidth: '$xxs',
            borderBottomColor: '$Gray300',
            borderBottomWidth: '$xxs',
            backgroundColor: '$White',
          }}
          listItemProps={{
            backgroundColor: '$White',
          }}
          items={items}
        />
        <YStack marginLeft={'$xl'} marginTop={'$xxl'}>
          <Text fontVariant={'body-regular-Gray400'}>
            {'Version ' + getReadableVersion()}
          </Text>
        </YStack>
      </YStack>
      <LogoutDialog
        open={isLogoutDialogVisible}
        title="Log out"
        copy={`Are you sure you want to log out?`}
      >
        <Button
          testID={getTestId('logout-confirm')}
          variant={ButtonVariant.BRAND}
          mt="$xl"
          onPress={handleSignOut}
        >
          {t('common.buttons.yes')}
        </Button>
        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={logoutCancel}
          testID={getTestId('logout-cancel')}
        >
          {t('common.buttons.cancel')}
        </Button>
      </LogoutDialog>
    </>
  );
};
