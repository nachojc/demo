import { useAnalytics } from '@hooks/use-analytics';
import { useMyDriveCustomer } from '@hooks/use-mydrive-customer';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { useResetSignOut } from '@hooks/use-reset-sign-out';
import { myDriveOnboardingCompleted } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { isDevMode } from '@src/common/config';
import { FeatureFlags } from '@src/feature-flags';
import { HelpScreenNames } from '@src/navigation/app/help-screens';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { MoreScreenNames } from '@src/navigation/app/summary/more-screen-names';
import { useEffect, useState } from 'react';

import {
  ACTION_MORE_DELETE_ONLINE_ACCOUNT_TAPPED,
  ACTION_MORE_LOGOUT_TAPPED,
  ACTION_MORE_MYDRIVE_SETTINGS_TAPPED,
  ACTION_MORE_PRIVACY_POLICY_TAPPED,
  ACTION_MORE_SECURITY_TAPPED,
  ACTION_MORE_TERMS_OF_USE_TAPPED,
  PAGE_MORE,
} from './analytics';

export const useMore = () => {
  const { logoutDialogVisible, resetSignOut } = useResetSignOut();
  const { isMyDriveEligible } = useMyDriveCustomer();
  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const [isLogoutDialogVisible, setIsLogoutDialogVisible] = useState(false);
  const [items, setItems] = useState<
    {
      title: string;
      onPress: () => void;
    }[]
  >([]);
  const indexOfMyDrive = 4;

  const openSecurityScreen = () => {
    trackUserEvent(ACTION_MORE_SECURITY_TAPPED);
    navigate(MoreScreenNames.Security);
  };

  const openTermsOfUseScreen = () => {
    trackUserEvent(ACTION_MORE_TERMS_OF_USE_TAPPED);
    navigate(HelpScreenNames.TermsOfUse);
  };

  const openPrivacyPolicyScreen = () => {
    trackUserEvent(ACTION_MORE_PRIVACY_POLICY_TAPPED);
    navigate(HelpScreenNames.PrivacyPolicy);
  };

  const navigateToDeleteAccountScreen = () => {
    trackUserEvent(ACTION_MORE_DELETE_ONLINE_ACCOUNT_TAPPED);
    navigate(MoreScreenNames.DeleteAccount);
  };

  const openMyDriveSettingsScreen = () => {
    trackUserEvent(ACTION_MORE_MYDRIVE_SETTINGS_TAPPED);
    navigate(MoreScreenNames.MyDriveSettings);
  };

  const openNotificationsToggleScreen = () => {
    navigate(MoreScreenNames.NotificationToggle);
  };

  const logoutPress = () => {
    trackUserEvent(ACTION_MORE_LOGOUT_TAPPED);
    setIsLogoutDialogVisible(true);
  };

  const openDevMode = () => {
    navigate(MoreScreenNames.DevMode);
  };

  const handleSignOut = () => {
    resetSignOut(false);
    setIsLogoutDialogVisible(logoutDialogVisible);
  };

  const logoutCancel = () => {
    setIsLogoutDialogVisible(false);
  };

  const myDriveOnboardingComplete = useSelector(myDriveOnboardingCompleted);
  const myDriveOnboardingCompleteFeatureFlag = useSelector(
    FeatureFlags.myDriveOnboardingComplete
  );

  const myDriveItem = {
    title: 'MyDrive',
    onPress: openMyDriveSettingsScreen,
  };
  const devModeItem = { title: 'Dev mode', onPress: openDevMode };

  const commonItems = [
    { title: 'Security', onPress: openSecurityScreen },
    { title: 'Terms of use', onPress: openTermsOfUseScreen },
    { title: 'Privacy policy', onPress: openPrivacyPolicyScreen },
    {
      title: 'Delete online account',
      onPress: navigateToDeleteAccountScreen,
    },
    { title: 'Notifications', onPress: openNotificationsToggleScreen },
    { title: 'Log out', onPress: logoutPress },
  ];

  const mydriveItems = [...commonItems];
  mydriveItems.splice(indexOfMyDrive, 0, myDriveItem);

  useEffect(() => {
    const isMyDriveEnabled =
      isMyDriveEligible &&
      (myDriveOnboardingCompleteFeatureFlag || myDriveOnboardingComplete);

    const selectedItems = isMyDriveEnabled ? mydriveItems : commonItems;
    isDevMode() && selectedItems.push(devModeItem);
    setItems(selectedItems);
  }, [myDriveOnboardingComplete, myDriveOnboardingCompleteFeatureFlag]);

  useOnPageLoad({ pageTag: PAGE_MORE });

  return {
    openSecurityScreen,
    openTermsOfUseScreen,
    openPrivacyPolicyScreen,
    navigateToDeleteAccountScreen,
    openMyDriveSettingsScreen,
    logoutPress,
    logoutCancel,
    isLogoutDialogVisible,
    handleSignOut,
    items,
  };
};
