import { APP_BASE } from '@constants/analytics';

export const PAGE_MORE = `${APP_BASE}settings`;

export const ACTION_MORE_SECURITY_TAPPED = `${PAGE_MORE}|security-tapped`;
export const ACTION_MORE_TERMS_OF_USE_TAPPED = `${PAGE_MORE}|terms-of-use-tapped`;
export const ACTION_MORE_PRIVACY_POLICY_TAPPED = `${PAGE_MORE}|privacy-policy-tapped`;
export const ACTION_MORE_DELETE_ONLINE_ACCOUNT_TAPPED = `${PAGE_MORE}|delete-online-account-tapped`;
export const ACTION_MORE_MYDRIVE_SETTINGS_TAPPED = `${PAGE_MORE}|mydrive-settings-tapped`;
export const ACTION_MORE_LOGOUT_TAPPED = `${PAGE_MORE}|logout-tapped`;
