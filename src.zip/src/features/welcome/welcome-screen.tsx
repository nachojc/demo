import { Button, ButtonVariant, YStack } from '@aviva/ion-mobile';
import { ScreenReaderOnly } from '@aviva/ion-mobile/components/ScreenReaderOnly';
import { config } from '@config';
import { useAnalytics } from '@hooks/use-analytics';
import { isManga } from '@hooks/use-expo-config';
import { useGetFeatureCards } from '@hooks/use-get-feature-cards';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { loginCount } from '@interfaces/storage';
import { useFocusEffect } from '@react-navigation/native';
import { useAuthStackNavigation } from '@src/navigation/auth/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { useCallback } from 'react';
import { useTranslation } from 'react-i18next';
import { Linking, ScrollView } from 'react-native';

import {
  LOGIN_BUTTON_TAPPED,
  REGISTER_BUTTON_TAPPED,
  RETRIEVE_QUOTE_LINK_TAPPED,
  WELCOME_PAGE,
} from './analytics';
import { FeatureCard } from './components/feature-cards-carousel';
import {
  ActionsContainer,
  AvivaIconImg,
  BackgroundContainer,
  BackgroundImg,
} from './welcome-screen.styles';

const retrieveQuoteWebViewUrl =
  config.AVIVA_BASE_URL.get() +
  '/help-and-support/retrieve-a-quote/?cmp%3Dwelcome-view-retrieve-quote%26adobe_mc%3DTS%3D1682087577%257CMCMID%3D56755601804139096104734309684642191557%257CMCORGID%3D5F8B76DA5233876B0A490D4D%40AdobeOrg';

export const WelcomeScreen = () => {
  const { t } = useTranslation();

  const { navigate } = useAuthStackNavigation();
  const { trackUserEvent } = useAnalytics();

  useOnPageLoad({ pageTag: WELCOME_PAGE });

  const { data, isSuccess, refetch } = useGetFeatureCards();

  useFocusEffect(
    useCallback(() => {
      refetch();
    }, [refetch])
  );

  const navigateToLoginScreen = useCallback(() => {
    trackUserEvent(LOGIN_BUTTON_TAPPED);
    navigate('Log in');
  }, [navigate, trackUserEvent]);

  const navigateToRegisterScreen = useCallback(() => {
    trackUserEvent(REGISTER_BUTTON_TAPPED);
    navigate('Register', { regcodeskip: '' });
  }, [navigate, trackUserEvent]);

  const openRetrieveQuoteWebLink = useCallback(() => {
    trackUserEvent(RETRIEVE_QUOTE_LINK_TAPPED);
    Linking.openURL(retrieveQuoteWebViewUrl);
  }, [trackUserEvent]);

  return (
    <YStack flex={1}>
      <BackgroundContainer firstLogin={loginCount.get() === 0 && isManga()}>
        <BackgroundImg testID={getTestId('WelcomeScreenView.BackgroundImg')}>
          <AvivaIconImg
            testID={getTestId('WelcomeScreenView.AvivaIconImg')}
            firstLogin={loginCount.get() === 0 && isManga()}
          />
        </BackgroundImg>
      </BackgroundContainer>

      <ScrollView bounces={false} style={{ flex: 1 }}>
        <ScreenReaderOnly accessibilityLabel={t('welcome.pageTitle')} />
        <ActionsContainer>
          <Button onPress={navigateToLoginScreen}>{t('welcome.login')}</Button>
          <Button
            onPress={navigateToRegisterScreen}
            variant={ButtonVariant.OUTLINED}
          >
            {t('common.buttons.register')}
          </Button>
          {isManga() && (
            <Button
              onPress={openRetrieveQuoteWebLink}
              variant={ButtonVariant.LINK_TEXT}
            >
              {t('welcome.quote')}
            </Button>
          )}
        </ActionsContainer>
        {isManga() && (
          <FeatureCard
            showCard={loginCount.get() === 0}
            data={data}
            isSuccess={isSuccess}
          />
        )}
      </ScrollView>
    </YStack>
  );
};
