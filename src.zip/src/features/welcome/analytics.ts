import { APP_BASE } from '@constants/analytics';

export const WELCOME_PAGE = APP_BASE + 'welcome';
export const LOGIN_BUTTON_TAPPED = WELCOME_PAGE + '|login-tapped';
export const REGISTER_BUTTON_TAPPED = WELCOME_PAGE + '|register-tapped';
export const RETRIEVE_QUOTE_LINK_TAPPED =
  WELCOME_PAGE + '|retrieve-quote-tapped';
