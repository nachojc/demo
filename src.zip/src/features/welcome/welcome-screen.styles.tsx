import { getAppIcon, getIpadAppIcon } from '@assets';
import { Image, Stack, styled, YStack } from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

export const BackgroundContainer = styled(Stack, {
  display: 'flex',
  justifyContent: 'center',
  alignItems: 'center',
  variants: {
    firstLogin: {
      true: { flex: 0.3 },
      false: { flex: 1.5 },
    },
  },
});

export const AvivaIconImg = styled(Image, {
  source: isIpad ? getIpadAppIcon() : getAppIcon(),
  alignSelf: 'center',
  resizeMode: 'contain',
  height: 145,
  width: 200,
  variants: {
    firstLogin: {
      true: isIpad ? { height: '75%', width: 300 } : { height: 20, width: 110 },
    },
  },
});

export const BackgroundImg = styled(Image, {
  source: require('assets/welcome-background.png'),
  width: '100%',
  height: '100%',
  resizeMode: 'stretch',
  justifyContent: 'center',
});

export const ActionsContainer = styled(YStack, {
  tabletNarrow: isIpad,
  space: '$xl',
  marginTop: '$xxxl',
  marginBottom: '$xxl',
  height: 140,
  paddingHorizontal: '$xl',
});
