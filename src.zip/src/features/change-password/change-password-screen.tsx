import { webLinks } from '@constants/web-links';
import { WebViewComponent } from '@src/components/web-view';

export const ChangePasswordScreen = () => {
  return (
    <WebViewComponent ssoEnabled source={{ uri: webLinks.changePassword }} />
  );
};
