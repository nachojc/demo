import { config } from '@config';
import { WebViewComponent } from '@src/components/web-view';

export const PrivacyPolicyScreen = () => {
  return (
    <WebViewComponent
      source={{
        uri:
          config.AVIVA_BASE_URL.get() +
          '/services/about-our-business/products-and-services/privacy-policy/',
      }}
    />
  );
};
