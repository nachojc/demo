import { Text, YStack } from '@aviva/ion-mobile';
import { ExpansionPanel } from '@aviva/ion-mobile/components/expansion-panel';
import { faqsData } from '@constants/app-faqs/app-faqs';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import { ScrollableScreen } from '@src/components/scrollable-screen';
import { HelpScreenNames } from '@src/navigation/app/help-screens';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useSurvey } from '@src/utils/qualtrics/use-survey';
import { useCallback, useState } from 'react';

import {
  ACTION_HELP_FAQS_PRIVACY_POLICY_TAPPED,
  ACTION_HELP_FAQS_TERMS_OF_USE_TAPPED,
  HELP_FAQS,
  PAGE_HELP_APP_FAQS,
} from './analytics';

const HyperlinkedContent = ({
  navigateToTermsOfUse,
  navigateToPrivacyPolicy,
}: {
  navigateToTermsOfUse: () => void;
  navigateToPrivacyPolicy: () => void;
}) => {
  return (
    <Text fontVariant="small-regular-Gray800">
      No. Your biometrics will not be stored in the MyAviva app or kept within
      Aviva. For more details please refer to the app{' '}
      <Text
        fontVariant="small-regular-Tertiary800"
        tamaguiTextProps={{
          onPress: navigateToTermsOfUse,
        }}
        decoration="underline"
      >
        Terms of Use{' '}
      </Text>
      and{' '}
      <Text
        fontVariant="small-regular-Tertiary800"
        tamaguiTextProps={{
          onPress: navigateToPrivacyPolicy,
        }}
        decoration="underline"
      >
        Privacy Policy
      </Text>
      .
    </Text>
  );
};

export const AppFaqsScreen = () => {
  const { navigate } = useAppStackNavigation();
  const analytics = useAnalytics();
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  useOnPageLoad({ pageTag: PAGE_HELP_APP_FAQS });
  useSurvey(HELP_FAQS);

  const expandQuestion = useCallback(
    (index: number) => {
      const selectedquestion = selectedIndex === index ? null : index;
      setSelectedIndex(selectedquestion);
    },
    [selectedIndex, setSelectedIndex]
  );

  const navigateToTermsOfUse = () => {
    analytics.trackUserEvent(ACTION_HELP_FAQS_TERMS_OF_USE_TAPPED);
    navigate(HelpScreenNames.TermsOfUse);
  };

  const navigateToPrivacyPolicy = () => {
    analytics.trackUserEvent(ACTION_HELP_FAQS_PRIVACY_POLICY_TAPPED);
    navigate(HelpScreenNames.PrivacyPolicy);
  };

  return (
    <ScrollableScreen>
      <YStack tablet={isIpad}>
        {faqsData.map((item, i) => {
          return (
            <ExpansionPanel
              key={item.title}
              index={i}
              selectedIndex={i}
              isExpanded={selectedIndex === i}
              heading={item.heading}
              title={item.title}
              containerStyle={{
                px: isIpad ? '$xl' : undefined,
              }}
              headingStyle={{
                px: isIpad ? '$xxxl' : undefined,
              }}
              content={
                item.content.includes('Terms of Use and Privacy Policy.') ? (
                  <HyperlinkedContent
                    navigateToTermsOfUse={navigateToTermsOfUse}
                    navigateToPrivacyPolicy={navigateToPrivacyPolicy}
                  />
                ) : (
                  <Text fontVariant={'small-regular-Gray800'}>
                    {item.content}
                  </Text>
                )
              }
              onPress={expandQuestion}
              testID={getTestId(`expansion-panel-${i}`)}
            />
          );
        })}
      </YStack>
    </ScrollableScreen>
  );
};
