import { APP_BASE } from '@constants/analytics';

export const PAGE_VERIFICATION_CODE_ENTRY =
  APP_BASE + 'activation-at-login|2sv|enter-verification-code';
export const PAGE_SUCCESS = APP_BASE + 'activation-at-login|2sv|done';
export const PAGE_ERROR = APP_BASE + 'activation-at-login|2sv|technical-issues';
export const PAGE_NEED_HELP = APP_BASE + 'activation-at-login|2sv|need-help';

export const PAGE_ACTIVATION_PROMPT =
  APP_BASE + 'activation-at-login|2sv|prompt';

export const PAGE_MOBILE_ENTRY =
  APP_BASE + 'activation-at-login|2sv|enter-mobile-number';

export const ACTION_SET_UP_CLICKED =
  PAGE_ACTIVATION_PROMPT + '|set-up-2sv-tapped';
export const ACTION_LATER_CLICKED = PAGE_ACTIVATION_PROMPT + '|later-tapped';
export const ACTION_CLOSE_CLICKED_PROMPT_SCREEN =
  PAGE_ACTIVATION_PROMPT + '|close-tapped';

export const ACTION_NEXT_CLICKED = PAGE_MOBILE_ENTRY + '|next-tapped';
export const ACTION_CLOSE_CLICKED_MOBILE_ENTRY_SCREEN =
  PAGE_MOBILE_ENTRY + '|close-tapped';

export const ACTION_OK_CLICKED_MOBILE_ENTRY_SCREEN_API_ERROR =
  PAGE_MOBILE_ENTRY + '|tech-error-ok-tapped';
export const ACTION_CONTACT_US_CLICKED_MOBILE_ENTRY_SCREEN_API_ERROR =
  PAGE_MOBILE_ENTRY + '|tech-error-contact-us-tapped';

export const ACTION_CLOSE_CLICKED_VERIFICATION_CODE_ENTRY_SCREEN =
  PAGE_VERIFICATION_CODE_ENTRY + '|close-tapped';
export const ACTION_CHANGE_NUMBER =
  PAGE_VERIFICATION_CODE_ENTRY + '|change-tapped';
export const ACTION_REQUEST_NEW_CODE =
  PAGE_VERIFICATION_CODE_ENTRY + '|request-a-new-code-tapped';
export const ACTION_NEED_HELP =
  PAGE_VERIFICATION_CODE_ENTRY + '|need-help-tapped';
export const ACTION_CLOSE_CLICKED_NEED_HELP_SCREEN =
  PAGE_NEED_HELP + '|close-tapped';
export const ACTION_SUBMIT = PAGE_VERIFICATION_CODE_ENTRY + '|submit-tapped';
export const ACTION_OPEN_MY_AVIVA_ERROR_SCREEN =
  PAGE_ERROR + '|open-myaviva-tapped';
export const ACTION_CLOSE_CLICKED_ERROR_SCREEN = PAGE_ERROR + '|close-tapped';
export const ACTION_OPEN_MY_AVIVA_SUCCESS_SCREEN =
  PAGE_SUCCESS + '|open-myaviva-tapped';
export const ACTION_CLOSE_CLICKED_SUCCESS_SCREEN = PAGE_SUCCESS + '|done';
