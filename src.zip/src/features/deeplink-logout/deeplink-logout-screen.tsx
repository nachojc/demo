import { LoadingState } from '@aviva/ion-mobile';
import { useResetSignOut } from '@hooks/use-reset-sign-out';
import { useEffect } from 'react';

export const DeeplinkLogoutScreen = () => {
  const { resetSignOut } = useResetSignOut();

  useEffect(() => {
    resetSignOut(false);
  }, []);

  return <LoadingState fullscreen />;
};
