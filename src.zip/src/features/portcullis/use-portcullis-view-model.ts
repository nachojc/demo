import { webLinks } from '@constants/web-links';
import { useAnalytics } from '@hooks/use-analytics';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import {
  useAuthStackNavigation,
  useAuthStackRoute,
} from '@src/navigation/auth/hooks';

export const usePortcullisViewModel = () => {
  const analytics = useAnalytics();
  const { navigate, goBack } = useAuthStackNavigation();
  const route = useAuthStackRoute<'Portcullis'>();

  useOnPageLoad({ pageTag: route.params.pageTag });

  const onContactUs = () => {
    analytics.trackUserEvent(route.params.actionTag);
    dismissPortcullisScreen();
    navigate('Web View', { url: webLinks.contactUs });
  };

  const dismissPortcullisScreen = () => {
    goBack();
  };

  return {
    onContactUs,
    dismissPortcullisScreen,
  };
};
