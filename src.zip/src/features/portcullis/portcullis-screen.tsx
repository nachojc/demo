import {
  Button,
  CloseButton,
  FocusAwareStatusBar,
  getTokens,
  getVariableValue,
  Image,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { displayName } from '@src/common/hooks/use-expo-config';
import { isIpad } from '@src/utils/is-ipad';

import { usePortcullisViewModel } from './use-portcullis-view-model';

type PortcullisScreenViewProps = {
  model: ReturnType<typeof usePortcullisViewModel>;
};
export const PortcullisView = ({ model }: PortcullisScreenViewProps) => {
  const tokens = getTokens();
  return (
    <>
      <FocusAwareStatusBar style="dark" />
      <YStack
        px="$xxxl"
        py="$xxxl"
        jc={'center'}
        h="100%"
        backgroundColor={getVariableValue(tokens.color.White)}
      >
        <YStack pt="$xl" alignItems="flex-end">
          <CloseButton
            onPress={model.dismissPortcullisScreen}
            hitSlop={{ bottom: 24, top: 24, left: 24, right: 24 }}
            iconProps={{
              color: getVariableValue(tokens.color.Secondary800),
              width: getVariableValue(tokens.size['4']),
              height: getVariableValue(tokens.size['4']),
            }}
          />
        </YStack>
        <YStack tablet={isIpad} flex={1} jc={'center'}>
          <YStack ai={'center'}>
            <Image
              accessibilityIgnoresInvertColors
              testID="PortcullisView.WorkersImage"
              style={{
                width: getVariableValue(tokens.size[16]),
                height: getVariableValue(tokens.size[16]),
              }}
              source={require('assets/portcullis-workers/portcullis-workers.png')}
            />
            <Text
              fontVariant="body-semibold-Secondary800"
              tamaguiTextProps={{ pb: '$lg', pt: '$xxl' }}
            >
              {"We're sorry"}
            </Text>
            <Text
              fontVariant="body-regular-Gray800"
              tamaguiTextProps={{
                pb: '$xxl',
                px: '$md',
                textAlign: 'center',
              }}
            >
              {`We're doing some planned work on our systems right now. If you're looking to get a quote or use ${displayName()}, please check back soon. If you need to make a new claim or have an urgent service request please call us.`}
            </Text>
          </YStack>
        </YStack>
        <YStack tabletNarrow={isIpad} pb={isIpad ? '$xxxxl' : undefined}>
          <Button onPress={model.onContactUs}>Contact us</Button>
        </YStack>
      </YStack>
    </>
  );
};

export const PortcullisScreen = () => {
  const model = usePortcullisViewModel();
  return <PortcullisView model={model} />;
};
