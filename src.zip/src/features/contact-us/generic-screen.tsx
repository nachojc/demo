import {
  Button,
  Icon,
  Stack,
  styled,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { Divider } from '@aviva/ion-mobile/components/list/clipboardable-list.style';
import { PhoneCallBox } from '@aviva/ion-mobile/components/phone-call-box';
import {
  NuanceChatContext,
  NuanceChatProvider,
} from '@src/components/nuance-chat';
import { ScrollableScreen } from '@src/components/scrollable-screen';
import { convertToKebabCase } from '@src/utils';
import { isIpad } from '@src/utils/is-ipad';
import { useSurvey } from '@src/utils/qualtrics/use-survey';
import { ReactNode, useContext, useEffect, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { View } from 'react-native';

import { OpeningTimes } from '../registration/help/help-screen';
import { HELP_CONTACT_US } from './analytics';
import { useGenericScreen } from './use-generic-screen';

const StyledText = ({ children }: { children: ReactNode }) => (
  <Text
    fontVariant="body-regular-Gray800"
    tamaguiTextProps={{
      marginLeft: '$xl',
      marginRight: '$xxl',
      marginBottom: '$xl',
      marginTop: '$3',
    }}
  >
    {children}
  </Text>
);

const StyledTextBold = ({ children }: { children: ReactNode }) => (
  <Text
    fontVariant="body-semibold-Gray800"
    tamaguiTextProps={{
      marginLeft: '$xl',
      marginRight: '$xxl',
      marginBottom: '$xl',
    }}
  >
    {children}
  </Text>
);

const ChatContainer = styled(XStack, {
  justifyContent: 'space-between',
  padding: '$xl',
  backgroundColor: '$White',
  borderColor: '$Gray300',
  borderBottomWidth: 1,
  borderTopWidth: 1,
  marginHorizontal: '$-xl',
});
export const GenericScreen = () => {
  const { t } = useTranslation();
  const {
    currentProductsData,
    openActionButtonUrl,
    setAnalyticsTag,
    product,
    openEmail,
    metaData,
    chatButtonAnalyticsTag,
  } = useGenericScreen();

  const { setNuancePayload, handleOpenChat } = useContext(NuanceChatContext);
  const [nuanceChatInitialised, setNuanceChatInitialised] = useState(false);
  useSurvey(
    currentProductsData
      ? `${HELP_CONTACT_US}${convertToKebabCase(currentProductsData.title)}`
      : null
  );
  useEffect(() => {
    if (metaData && chatButtonAnalyticsTag) {
      setNuancePayload({
        analyticsData: chatButtonAnalyticsTag,
        createMetadataFunction: () => metaData,
      });
      setNuanceChatInitialised(true);
    }
  }, [metaData, setNuancePayload, chatButtonAnalyticsTag]);

  const ScreenContent = useMemo(() => {
    const selectedProductDetails = currentProductsData.data.contactDetails;
    return selectedProductDetails.map((item, i) => {
      const key = item.key || item.value || 'key' + i;
      switch (item.type) {
        case 'heading-text':
          return (
            <Text
              key={key}
              fontVariant="heading5-semibold-Secondary800"
              tamaguiTextProps={{
                marginLeft: '$xl',
                marginTop: '$7',
                marginBottom: '$xl',
              }}
            >
              {item.value}
            </Text>
          );
        case 'phone':
          return (
            <PhoneCallBox
              key={key}
              phone={item.value ?? t('contactUs.phone')}
              containerProps={{ ...item.styles, paddingHorizontal: '$xl' }}
              tags={{
                onOpen: setAnalyticsTag(product)(item.analytics),
              }}
            />
          );
        case 'opening-times':
          return item.data && <OpeningTimes key={key} times={item.data} />;
        case 'footer-text':
          return <StyledText key={key}>{item.value}</StyledText>;
        case 'footer-text-centre-section-bold':
          return (
            <StyledText key={key}>
              {item.value} <StyledTextBold>{item.valueBold}</StyledTextBold>
              {item.valueTwo}
            </StyledText>
          );
        case 'email-address':
          return (
            <View key={key}>
              <StyledText>
                {item.value}{' '}
                <Text
                  fontVariant="body-regular-Tertiary800"
                  tamaguiTextProps={{
                    onPress: openEmail(item.email ?? ''),
                  }}
                >
                  {item.email}
                </Text>
              </StyledText>
            </View>
          );
        case 'action':
          return (
            <YStack px="$xl" tabletNarrow={isIpad} key={key}>
              <Button
                marginTop="$xl"
                marginBottom="$xxxl"
                marginHorizontal="$xl"
                onPress={() =>
                  item.url
                    ? openActionButtonUrl(item.url, item.analytics)
                    : null
                }
              >
                {item.value}
              </Button>
            </YStack>
          );
        case 'divider':
          return <Divider bg="$Gray050" marginVertical="$md" />;
        case 'chat':
          return (
            <>
              {nuanceChatInitialised && (
                <ChatContainer key={key} onPress={handleOpenChat}>
                  <Text
                    fontVariant="body-semibold-Gray800"
                    tamaguiTextProps={{ ml: '$xl', f: 1 }}
                  >
                    {item.value}
                  </Text>
                  <Stack marginRight="$xl">
                    <Icon name="chat" />
                  </Stack>
                </ChatContainer>
              )}
            </>
          );
        default:
          return null;
      }
    });
  }, [
    currentProductsData,
    setAnalyticsTag,
    product,
    openEmail,
    handleOpenChat,
    nuanceChatInitialised,
    openActionButtonUrl,
  ]);

  return (
    <NuanceChatProvider>
      <ScrollableScreen>
        <YStack f={1} tablet={isIpad} px={isIpad ? '$xxxl' : undefined}>
          <YStack>{ScreenContent}</YStack>
        </YStack>
      </ScrollableScreen>
    </NuanceChatProvider>
  );
};
