export type ContactProduct =
  | 'Annuity'
  | 'AvivaPlus home'
  | 'AvivaPlus motor'
  | 'Breakdown'
  | 'Complaints'
  | 'Corporate health'
  | 'Critical illness'
  | 'Direct wealth pension'
  | 'Distinct home insurance'
  | 'Distinct motor insurance'
  | 'Equity release'
  | 'Family personal accident insurance'
  | 'General enquiries'
  | 'Home'
  | 'Income drawdown'
  | 'Income protection'
  | 'Investment account'
  | 'Investment bond'
  | 'Investment portfolio'
  | 'ISA'
  | 'Life insurance'
  | 'Motor'
  | 'Motorcycle insurance'
  | 'Pension drawdown'
  | 'Pension'
  | 'Personal accident insurance'
  | 'Private health'
  | 'Travel insurance';

export type ContactUsProductContactDetails = {
  [key: string]: ContactUsProductContactDetail;
};
export type ContactUsProductContactDetail = {
  title: string;
  data: {
    contactDetails: {
      type: string;
      analytics?: string;
      value?: string;
      valueTwo?: string;
      valueBold?: string;
      key?: string;
      email?: string;
      data?: {
        day: string;
        hours: string;
      }[];
      url?: string;
      styles?: { [key: string]: number };
    }[];
  };
};

export type ContactUsSection = {
  title: 'Insurance' | 'Retirement' | 'Investment' | 'General';
  data: ContactProduct[];
};
