import { SectionList, Stack, Text, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { isManga } from '@hooks/use-expo-config';
import { ScrollableScreen } from '@src/components/scrollable-screen';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect } from 'react';
import { useTranslation } from 'react-i18next';

import {
  HELP_CONTACT_US_BACK_TAPPED,
  HELP_CONTACT_US_WEALTH_BACK_TAPPED,
} from './analytics';
import { useContactUsScreen } from './use-contact-us-screen';

export const ContactUsScreen = () => {
  const { t } = useTranslation();
  const { addListener } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();

  const { items } = useContactUsScreen();
  useEffect(() => {
    const unsubscribe = addListener('beforeRemove', () => {
      trackUserEvent(
        isManga()
          ? HELP_CONTACT_US_BACK_TAPPED
          : HELP_CONTACT_US_WEALTH_BACK_TAPPED
      );
    });

    return unsubscribe;
  }, [addListener, trackUserEvent]);

  return (
    <ScrollableScreen>
      <YStack tablet={isIpad}>
        <Text
          fontVariant="body-regular-Gray900"
          tamaguiTextProps={{
            marginLeft: '$xl',
            marginBottom: '$lg',
            marginTop: '$6',
          }}
        >
          {t('contactUs.text')}
        </Text>
        <Stack testID={getTestId('contact-section-heading')} f={1}>
          <SectionList
            listTitleFontVariant="body-regular-Gray900"
            listProps={{
              backgroundColor: '$White',
              paddingLeft: isIpad ? '$xl' : undefined,
            }}
            listItemProps={{
              backgroundColor: '$White',
            }}
            titleProps={{ px: isIpad ? '$xl' : undefined }}
            items={items}
          />
        </Stack>
      </YStack>
    </ScrollableScreen>
  );
};
