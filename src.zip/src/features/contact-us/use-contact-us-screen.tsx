import { useDirectWealthAccount } from '@direct-wealth/common/hooks';
import { Account } from '@direct-wealth/features/portfolio-summary/types';
import { DirectWealthProduct } from '@direct-wealth/validation/schemas/direct-wealth-account';
import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { useCustomer } from '@hooks/use-customer';
import { isManga } from '@hooks/use-expo-config';
import { HelpScreenNames } from '@src/navigation/app/help-screens';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { dwProductTypes } from '@src/utils';
import { useSurvey } from '@src/utils/qualtrics/use-survey';
import { removeStringAddHyphens } from '@src/utils/string-manipulation';
import { Products } from '@src/validation/schemas/product/products';
import { StatableInsuranceProduct } from '@src/validation/schemas/product/schemas/statable-insurance-product';
import { useCallback, useMemo } from 'react';

import {
  HELP_CONTACT_US,
  HELP_CONTACT_US_WEALTH,
  PAGE_HELP_SUPPORT_CONTACT_US,
} from './analytics';
import SectionsDataJSON from './data.json';
import { ContactProduct, ContactUsSection } from './model';

const SectionsData = SectionsDataJSON as ContactUsSection[];

type ProductDetails = {
  productType: Products['ProductType'];
  subscriptionRequired?: boolean;
};

const productDetailsMap: Partial<Record<ContactProduct, ProductDetails>> = {
  'AvivaPlus home': { productType: 'Home', subscriptionRequired: true },
  'AvivaPlus motor': { productType: 'Motor', subscriptionRequired: true },
  'Corporate health': { productType: 'CorporateMedicalInsurance' },
  'Direct wealth pension': { productType: 'SIPP' },
  'Distinct home insurance': { productType: 'DistinctHome' },
  'Distinct motor insurance': { productType: 'DistinctMotor' },
  'Equity release': { productType: 'EquityRelease' },
  'Family personal accident insurance': {
    productType: 'FamilyPersonalAccident',
  },
  'Investment account': { productType: 'GIA' },
  ISA: { productType: 'StocksAndSharesISA' },
  'Pension drawdown': { productType: 'Drawdown' },
  'Personal accident insurance': { productType: 'AccidentalDeath' },
  'Private health': { productType: 'PrivateMedicalInsurance' },
};

export const useContactUsScreen = () => {
  const { navigate } = useAppStackNavigation();
  const { data: customer } = useCustomer();
  const { trackUserEvent } = useAnalytics();
  useSurvey(HELP_CONTACT_US);
  useTrackStateEvent(PAGE_HELP_SUPPORT_CONTACT_US);
  const navigateAndTrack = (title: ContactProduct) => {
    navigate(HelpScreenNames.ContactUsBuffer, { product: title });

    trackUserEvent(
      `${
        !dwProductTypes.includes(title)
          ? HELP_CONTACT_US
          : HELP_CONTACT_US_WEALTH
      }${removeStringAddHyphens(title, '-insurance')}-tapped`
    );
  };

  const navigateTo = useCallback(navigateAndTrack, [navigate, trackUserEvent]);

  const dwProductDetailsMapping = useCallback(
    (product: DirectWealthProduct, item: ContactProduct) => {
      const { accountType, displayName } = product;
      const { productType } = productDetailsMap[item] || {};

      const dwProducts = dwProductTypes.includes(item);

      return (
        ((dwProducts && (productType as Account) === accountType) ||
          item === displayName ||
          item === accountType) &&
        !isSippDrawdown(accountType, displayName)
      );
    },
    []
  );

  const productDetailsMapping = useCallback(
    (product: Products, item: ContactProduct) => {
      // TODO: This needs refactoring
      const { ProductType, SubscriptionNumber, DisplayName } =
        product as StatableInsuranceProduct;

      if ((item === 'Home' || item === 'Motor') && SubscriptionNumber) {
        return false;
      }

      const { productType, subscriptionRequired } =
        productDetailsMap[item] || {};

      return (
        ((productType === ProductType &&
          (!subscriptionRequired ||
            (subscriptionRequired && SubscriptionNumber))) ||
          item === DisplayName ||
          item === ProductType) &&
        !isSippDrawdown(ProductType, DisplayName)
      );
    },
    []
  );

  const isDwCustomer =
    customer?.DirectWealth && customer?.DirectWealth.length > 0;

  const dwSecureAccountNumber =
    customer?.DirectWealth?.[0]?.SecureAccountNumber;

  const { data: directWealthAccount } = useDirectWealthAccount(
    dwSecureAccountNumber
  );
  const dwProducts = directWealthAccount?.products;

  const filteredByContactUsName = useCallback(
    (title: ContactUsSection['title'], item: ContactProduct) => {
      if (title === 'General') {
        return isManga();
      }
      if (isDwCustomer && dwProducts && !isManga()) {
        return dwProducts.find((dwProduct: DirectWealthProduct) => {
          if (isSippDrawdown(dwProduct.accountType, dwProduct.displayName)) {
            dwProduct.accountType = 'Drawdown' as Account;
          } else if (
            isInvestmentPortfolio(dwProduct.accountType, dwProduct.displayName)
          ) {
            dwProduct.accountType = 'GIA' as Account;
          }
          return dwProductDetailsMapping(dwProduct, item);
        });
      }
      return customer?.Products.find((product: Products) => {
        if (isSippDrawdown(product.ProductType, product.DisplayName)) {
          product.ProductType = 'Drawdown';
        } else if (
          isInvestmentPortfolio(product.ProductType, product.DisplayName)
        ) {
          product.ProductType = 'GIA';
        }

        return productDetailsMapping(product, item);
      });
    },
    [
      customer?.Products,
      dwProductDetailsMapping,
      dwProducts,
      isDwCustomer,
      productDetailsMapping,
    ]
  );

  const isSippDrawdown = (
    productType: string,
    displayName: string | undefined | null
  ) => {
    // SIPP is a special case. A SIPP pension can also be drawdown, for
    // the contact screen we just need to treat as drawdown. This isn't
    // particularly nice, but any other change would require a large refactor
    return (
      productType.toLocaleLowerCase() === 'sipp' &&
      displayName?.toLocaleLowerCase() === 'pension drawdown'
    );
  };

  const isInvestmentPortfolio = (
    productType: string,
    displayName: string | undefined | null
  ) => {
    // Another hack to avoid refactoring. The customer API does not return
    // the correct product type we need for the investment account.
    return (
      productType.toLocaleLowerCase() === 'generalinvestmentaccount' &&
      displayName?.toLocaleLowerCase() === 'investment portfolio'
    );
  };

  const addNavigation = useCallback(
    (title: ContactProduct) => ({
      title: title === 'Direct wealth pension' ? 'Pension' : title,
      onPress: () => navigateTo(title),
    }),
    [navigateTo]
  );

  const readyData = useCallback(
    ({ data, title }: ContactUsSection) => {
      const mappedData = data
        .filter((item) => filteredByContactUsName(title, item))
        .map(addNavigation);

      return { title, data: mappedData };
    },

    [addNavigation, filteredByContactUsName]
  );

  const filteredItems = useMemo(() => {
    return SectionsData.map(readyData).filter(
      (section) => section.data.length !== 0
    );
  }, [readyData]);

  return { items: filteredItems, navigateAndTrack };
};
