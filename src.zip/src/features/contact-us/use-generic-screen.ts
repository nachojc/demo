import { useAnalytics } from '@hooks/use-analytics';
import { createHealthMetadata } from '@hooks/use-chat';
import { useCustomer } from '@hooks/use-customer';
import { usePolicy } from '@hooks/use-policy';
import { HelpScreenNames } from '@src/navigation/app/help-screens';
import {
  useAppStackNavigation,
  useAppStackRoute,
} from '@src/navigation/app/hooks';
import { getPolicyType } from '@src/utils/chat';
import { removeStringAddHyphens } from '@src/utils/string-manipulation';
import { Customer } from '@src/validation/schemas/customer';
import { useCallback, useEffect } from 'react';
import { Linking } from 'react-native';

import ProductContactDetailsData from './generic-screen-data.json';
import { ContactProduct, ContactUsProductContactDetails } from './model';
import {
  getProductInfo,
  getTag,
  setProductPath,
} from './use-generic-screen-utils';

export const useGenericScreen = () => {
  const { navigate, addListener } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const productsData: ContactUsProductContactDetails =
    ProductContactDetailsData;
  const {
    params: { product: bufferProduct },
  } = useAppStackRoute<typeof HelpScreenNames.ContactUsBuffer>();
  const {
    params: { url: actionURL, product: webViewProduct },
  } = useAppStackRoute<typeof HelpScreenNames.ContactUsWebView>();
  const product = bufferProduct ?? webViewProduct;
  const currentProductsData = productsData[product];

  const { data: customer } = useCustomer();
  const { productInfo, showAsyncChat: tmpShowAsyncChat } = getProductInfo(
    currentProductsData,
    customer as Customer
  );
  let showAsyncChat = tmpShowAsyncChat || false;

  const [policyInfo] = usePolicy(productInfo?.SecurePolicyNumber || '', {
    enabled: productInfo ? !productInfo?.IsLoaded : false,
  });
  let chatButtonAnalyticsTag = '';

  let metaData;
  if (policyInfo && policyInfo.__tag === 'HealthProduct') {
    const policyType = getPolicyType(
      policyInfo.ProductType,
      policyInfo.PolicyNumber
    );
    showAsyncChat = policyType !== 'ThirdPartyManaged';
    metaData =
      policyType &&
      createHealthMetadata(
        policyInfo.MemberNumber,
        policyInfo.PolicyNumber,
        'health-contactus',
        policyType
      );
    chatButtonAnalyticsTag = getTag(currentProductsData.title);
  }

  if (showAsyncChat && metaData) {
    const msgSection = {
      type: 'heading-text',
      value: 'Message Us',
    };
    const chatSection = {
      type: 'chat',
      value: 'Start chat',
    };
    const valueCheck = currentProductsData?.data.contactDetails.find(
      (element) => element.value === 'Message Us'
    );
    if (!valueCheck) {
      currentProductsData.data.contactDetails.push(msgSection, chatSection);
    }
  }

  const openActionButtonUrl = (url: string, tag = 'contact-online-tapped') => {
    trackUserEvent(setProductPath(product, '|' + tag));
    navigate(HelpScreenNames.ContactUsWebView, { url, product });
  };

  const openEmail = (email: string) => () => {
    trackUserEvent(setProductPath(product, '|email-tapped'));
    Linking.openURL(`mailto:${email}`);
  };

  const setAnalyticsTag = useCallback(
    (prod: ContactProduct) =>
      (value = 'dial-tapped') => {
        if (value.includes('GI-complaint')) {
          return setProductPath(prod, `|${value.replaceAll(' ', '')}`);
        }
        const event = value.toLowerCase().replaceAll(' ', '');
        return setProductPath(prod, `|${event}`);
      },
    []
  );

  const handleClose = useCallback(() => {
    const tag = setAnalyticsTag(
      removeStringAddHyphens(product, '-insurance') as ContactProduct
    );

    trackUserEvent(`${tag('back-tapped')}`);
  }, [trackUserEvent, setAnalyticsTag, product]);

  useEffect(() => {
    const unsubscribe = addListener('beforeRemove', handleClose);

    return unsubscribe;
  }, [addListener, handleClose]);

  return {
    currentProductsData,
    setProductPath,
    openActionButtonUrl,
    url: actionURL,
    setAnalyticsTag,
    handleClose,
    product,
    openEmail,
    metaData,
    chatButtonAnalyticsTag,
  };
};
