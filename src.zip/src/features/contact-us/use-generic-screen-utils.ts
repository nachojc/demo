import { dwProductTypeStrings } from '@src/utils';
import { removeStringAddHyphens } from '@src/utils/string-manipulation';
import { Customer } from '@src/validation/schemas/customer';

import {
  HELP_CONTACT_US,
  HELP_CONTACT_US_WEALTH,
  SUPPORT_DETAILS_CONTACT_US_CORPORATE_PMI,
  SUPPORT_DETAILS_CONTACT_US_PRIVATE_MEDICAL_INSURANCE,
} from './analytics';
import { ContactUsProductContactDetail } from './model';

export const setProductPath = (prod: string, path: string) =>
  `${
    !dwProductTypeStrings.includes(prod)
      ? HELP_CONTACT_US
      : HELP_CONTACT_US_WEALTH
  }${removeStringAddHyphens(prod, '-insurance')}${path}`;

export const getTag = (productType: string) => {
  switch (productType) {
    case 'Corporate health':
      return SUPPORT_DETAILS_CONTACT_US_CORPORATE_PMI;
    case 'Private health':
      return SUPPORT_DETAILS_CONTACT_US_PRIVATE_MEDICAL_INSURANCE;
    default:
      return '';
  }
};

export const getProductInfo = (
  currentProductsData: ContactUsProductContactDetail,
  customer: Customer
) => {
  let productInfo;
  let showAsyncChat = false;
  if (currentProductsData) {
    if (currentProductsData.title === 'Private health') {
      productInfo = customer?.Products.find(
        (product) => product.ProductType === 'PrivateMedicalInsurance'
      );
      showAsyncChat = true;
    }
    if (currentProductsData.title !== 'Private health') {
      showAsyncChat = false;
    }
    if (currentProductsData.title === 'Corporate health') {
      productInfo = customer?.Products.find(
        (product) => product.ProductType === 'CorporateMedicalInsurance'
      );
      showAsyncChat = true;
    }
  }
  return { productInfo, showAsyncChat };
};
