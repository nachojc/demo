import { WebViewComponent } from '@src/components/web-view';

import { useGenericScreen } from './use-generic-screen';

export const ContactUsWebViewScreen = () => {
  const { url: uri } = useGenericScreen();
  return (
    <WebViewComponent
      source={{
        uri,
      }}
    />
  );
};
