import { config } from '@config';
import { WebViewComponent } from '@src/components/web-view';

export const ContactUsWebViewNoAuth = () => {
  return (
    <WebViewComponent
      source={{
        uri: `${config.AVIVA_BASE_URL.get()}/help-and-support/contact-us/`,
      }}
    />
  );
};
