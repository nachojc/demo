import { APP_BASE } from '@constants/analytics';

export const INVESTMENTS_ACTION_BASE = `${APP_BASE}investments`;

export const PAGE_ACCOUNTS_GROUPS_DASHBOARD_WEALTHIFY = `${INVESTMENTS_ACTION_BASE}|wealthify`;
export const PAGE_ACCOUNTS_GROUPS_DASHBOARD_NON_WEALTHIFY = `${INVESTMENTS_ACTION_BASE}|investment-portfolio`;

export const ACTION_GENERAL_INVESTMENT_TAPPED = `${PAGE_ACCOUNTS_GROUPS_DASHBOARD_WEALTHIFY}|general-investment|dashboard-tapped`;
export const ACTION_ISA_TAPPED = `${PAGE_ACCOUNTS_GROUPS_DASHBOARD_WEALTHIFY}|isa|dashboard-tapped`;
export const ACTION_SIP_TAPPED = `${PAGE_ACCOUNTS_GROUPS_DASHBOARD_WEALTHIFY}|sipp|dashboard-tapped`;

const JISA_BASE = `${INVESTMENTS_ACTION_BASE}|jisa|`;
export const ACTION_JISA_MATURITY_FIND_OUT_MORE_TAPPED = `${JISA_BASE}maturity-tapped`;
export const ACTION_JISA_MATURITY_CLOSE_TAPPED = `${JISA_BASE}maturity-dismiss`;

export const ACTION_GROUP_ACCOUNT_TAPPED = `ukmyaviva|home-dashboard|wealthify|view-details-tapped`;
