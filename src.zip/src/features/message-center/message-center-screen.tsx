import {
  Button,
  ButtonVariant,
  Dialog,
  getTokens,
  getVariableValue,
  Icon,
  Image,
  LoadingState,
  Stack,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { MixedMessages } from '@hooks/use-messages';
import { FlatList } from '@src/components/flatlist';
import { MessageItem } from '@src/components/message-item';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect, useState } from 'react';

import { useMessageCenterViewModel } from './use-message-centre-view-model';

type MessageCenterScreenViewProps = {
  model: ReturnType<typeof useMessageCenterViewModel>;
};

const MessageCenterBodyView = (props: {
  checkMessageReadStatus: (id: string) => boolean;
  isLoading: boolean;
  isFetching: boolean;
  isRefetching: boolean;
  messages: MixedMessages | undefined;
  navigateToMessageScreen: (id: string) => void;
  refetchMessages: () => void;
  selectedMessageId: string | null;
}) => {
  const {
    checkMessageReadStatus,
    messages,
    isFetching,
    isRefetching,
    navigateToMessageScreen,
    refetchMessages,
    selectedMessageId,
  } = props;

  const tokens = getTokens();

  if (messages && messages.length !== 0) {
    return (
      <FlatList
        testID={getTestId('messages-list')}
        refreshing={isRefetching}
        onRefresh={refetchMessages}
        showsVerticalScrollIndicator
        estimatedItemSize={15}
        data={messages}
        extraData={selectedMessageId}
        keyExtractor={(item) => item?.id}
        renderItem={({ item }) => {
          return (
            <MessageItem
              onPress={() => navigateToMessageScreen(item.id)}
              header={item.header}
              body={item.body}
              iconUrl={item.iconUrl}
              hasRead={checkMessageReadStatus(item.id)}
              id={item.id}
            />
          );
        }}
        ListFooterComponent={
          <Text
            tamaguiTextProps={{
              textAlign: 'center',
              paddingVertical: getVariableValue(tokens.space.$xxl),
            }}
            fontVariant={'body-semibold-Gray500'}
            testID={getTestId('no-more-messages')}
          >
            No more messages
          </Text>
        }
      />
    );
  } else if (isFetching) {
    return (
      <LoadingState
        testID={getTestId('loading-state')}
        fullscreen={false}
        text="oneMoment"
      />
    );
  } else {
    return (
      <Stack
        space={'$xl'}
        h={'100%'}
        ai="center"
        jc="center"
        marginHorizontal={'$xxxl'}
      >
        <Image
          accessibilityIgnoresInvertColors
          style={{
            height: getVariableValue(tokens.size['12']),
            width: getVariableValue(tokens.size['12']),
          }}
          source={require('assets/empty-envelope/empty-envelope.png')}
        />
        <Text
          tamaguiTextProps={{ textAlign: 'center' }}
          fontVariant={'body-regular-Gray800'}
          testID={getTestId('no-messages-text')}
        >
          You currently don’t have any messages. Your messages will be displayed
          here for you to view.
        </Text>
      </Stack>
    );
  }
};

const ErrorDialog = ({
  isError,
  isLoading,
  onRetry,
}: {
  isError: boolean;
  isLoading: boolean;
  onRetry: () => void;
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const tokens = getTokens();

  useEffect(() => {
    if (!isError || isLoading) {
      setIsOpen(false);
    } else {
      setIsOpen(true);
    }
  }, [isError, isLoading]);

  return (
    <Dialog
      center
      open={isOpen}
      icon={
        <Icon
          color={getVariableValue(tokens.color.$Error)}
          name={'alert-circle'}
        />
      }
      title={'Error'}
      copy={'Sorry, we were unable to refresh. Please try again.'}
    >
      <Stack mt={'$xl'}>
        <Button onPress={onRetry}>Retry</Button>

        <Button
          variant={ButtonVariant.LINK_TEXT}
          onPress={() => setIsOpen(false)}
        >
          Cancel
        </Button>
      </Stack>
    </Dialog>
  );
};

export const MessageCenterScreenView = ({
  model,
}: MessageCenterScreenViewProps) => {
  const {
    checkMessageReadStatus,
    isError,
    isLoading,
    isFetching,
    isRefetching,
    messages,
    navigateToMessageScreen,
    refetchMessages,
    selectedMessageId,
  } = model;
  return (
    <YStack height={'100%'} width={'100%'} px={0} tablet={isIpad}>
      <MessageCenterBodyView
        checkMessageReadStatus={checkMessageReadStatus}
        isLoading={isLoading}
        isRefetching={isRefetching}
        messages={messages}
        navigateToMessageScreen={navigateToMessageScreen}
        refetchMessages={refetchMessages}
        selectedMessageId={selectedMessageId}
        isFetching={isFetching}
      />
      <ErrorDialog
        isError={isError}
        isLoading={isRefetching}
        onRetry={refetchMessages}
      />
    </YStack>
  );
};

export const MessageCenterScreen = () => {
  const model = useMessageCenterViewModel();

  return <MessageCenterScreenView model={model} />;
};
