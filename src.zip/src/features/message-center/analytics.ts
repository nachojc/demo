import { isManga } from '@hooks/use-expo-config';

export const APP_BASE = isManga() ? 'ukmyaviva|' : 'ukmyaviva|wealth|';
export const ACTION_MESSAGE_TAPPED = (messageId: string) =>
  APP_BASE + 'message-centre|' + messageId + '-tapped';
export const ACTION_MESSAGE_EXIT_TAPPED =
  APP_BASE + 'message-centre|exit-tapped';

export const PAGE_MESSAGE_CENTER = APP_BASE + 'message-centre';
export const PAGE_MESSAGE_CENTER_NO_MESSAGE =
  APP_BASE + '|message-centre-empty';
export const ACTION_MESSAGE_DETAILS = (messageId: string) =>
  PAGE_MESSAGE_CENTER + '|message-expanded|' + messageId;
