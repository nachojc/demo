import { LoadingState, Stack, Text } from '@aviva/ion-mobile';
import { useDataExchangeUri } from '@hooks/use-data-exchange';
import { WebViewComponent } from '@src/components/web-view';
import { useAppStackRoute } from '@src/navigation/app/hooks';
import { TopAppBarMangaHeaderScreen } from '@src/navigation/app/summary/stack-groups/top-app-bar-manga-header';
import { getTestId } from '@src/utils/get-test-id';

export const MessageActionScreen = () => {
  const { params: action } =
    useAppStackRoute<typeof TopAppBarMangaHeaderScreen.MessageAction>();

  const withDataExchange = action.actionType === 'WebWithDataExchange';
  const ssoEnabled =
    action.actionType === 'WebAuthenticated' || withDataExchange;

  const { data: dataExchangeUri, isLoading } = useDataExchangeUri(
    action.uri,
    action.dexSchemaName,
    action.dexSchemaVersion,
    action.dexPayload,
    withDataExchange
  );

  const uri = withDataExchange ? dataExchangeUri : action.uri;

  if (withDataExchange && isLoading) {
    return <LoadingState fullscreen={false} text="oneMoment" />;
  }

  if (!uri) {
    return (
      <Stack jc="space-evenly" h={'100%'}>
        <Text
          fontVariant={'body-regular-Gray800'}
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          Invalid URL
        </Text>
      </Stack>
    );
  }

  return (
    <WebViewComponent
      testID={getTestId('message-action-screen')}
      ssoEnabled={ssoEnabled}
      source={{
        uri,
      }}
    />
  );
};
