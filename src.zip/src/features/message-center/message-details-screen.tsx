import {
  Button,
  ButtonVariant,
  getTokens,
  getVariableValue,
  Image,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { isIpad } from '@src/utils/is-ipad';

import { useMessageDetailsViewModel } from './use-message-details-view-model';

type MessageDetailsScreenViewProps = {
  model: ReturnType<typeof useMessageDetailsViewModel>;
};

const MessageDetailsScreenView = ({ model }: MessageDetailsScreenViewProps) => {
  const tokens = getTokens();

  return (
    <YStack
      tablet={isIpad}
      px={'$xl'}
      py={'$xxl'}
      jc="space-evenly"
      ai="center"
      h={'100%'}
    >
      <YStack ai={'center'} f={1} jc="center">
        <Image
          source={
            model.iconUrl
              ? {
                  uri: model.iconUrl,
                }
              : require('assets/closed-envelope/closed-envelope.png')
          }
          accessibilityLabel="Message-icon"
          accessibilityIgnoresInvertColors
          accessibilityHint="Message center notification"
          resizeMode={'contain'}
          style={{
            width: getVariableValue(getTokens().size[12]),
            height: getVariableValue(getTokens().size[12]),
          }}
        />

        <Text
          fontVariant={'heading5-semibold-Secondary800'}
          tamaguiTextProps={{
            my: getVariableValue(tokens.space.$xl),
            textAlign: 'center',
          }}
        >
          {model.header}
        </Text>
        {model.body && (
          <Text
            fontVariant={'body-regular-Gray800'}
            tamaguiTextProps={{ textAlign: 'center' }}
          >
            {model.body}
          </Text>
        )}
      </YStack>
      <YStack
        w={'100%'}
        jc={'flex-end'}
        space="$space.md"
        pb={isIpad ? '$xxxxl' : undefined}
      >
        {model.actions.map((action, index) => (
          <YStack key={`${action.actionType}-${index}`} tabletNarrow={isIpad}>
            <Button
              onPress={action.onPress}
              variant={
                index === 0 ? ButtonVariant.BRAND : ButtonVariant.LINK_TEXT
              }
            >
              {action.text ?? action.title}
            </Button>
          </YStack>
        ))}
      </YStack>
    </YStack>
  );
};

export const MessageDetailsScreen = () => {
  const model = useMessageDetailsViewModel();
  return <MessageDetailsScreenView model={model} />;
};
