import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import {
  useGetMessages,
  useMessageCenterReadStatus,
} from '@hooks/use-messages';
import { MESSAGE_CENTRE_DEEPLINK } from '@hooks/use-push-notification-deeplinks';
import { pushNotificationDeeplink } from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { useAppStackNavigation } from '@src/navigation/app/hooks';
import { TopAppBarMangaHeaderScreen } from '@src/navigation/app/summary/stack-groups/top-app-bar-manga-header';
import { useCallback, useEffect, useRef, useState } from 'react';

import {
  ACTION_MESSAGE_TAPPED,
  PAGE_MESSAGE_CENTER,
  PAGE_MESSAGE_CENTER_NO_MESSAGE,
} from './analytics';

export const useMessageCenterViewModel = () => {
  const [
    messages,
    { error, isError, isLoading, isFetching, isRefetching, refetch },
  ] = useGetMessages();

  const [selectedMessageId, setSelectedMessageId] = useState<null | string>(
    null
  );
  const { navigate } = useAppStackNavigation();
  const { readMessage, checkMessageReadStatus } = useMessageCenterReadStatus();
  const pushNotificationDeeplinkValue = useSelector(pushNotificationDeeplink);
  const refetchCounter = useRef(0);
  const { trackUserEvent } = useAnalytics();

  const pageTag = messages?.length
    ? PAGE_MESSAGE_CENTER
    : PAGE_MESSAGE_CENTER_NO_MESSAGE;
  useTrackStateEvent(pageTag);

  const navigateToMessageScreen = (messageId: string) => {
    trackUserEvent(ACTION_MESSAGE_TAPPED(messageId));
    navigate(TopAppBarMangaHeaderScreen.MessageDetails, {
      MessageId: messageId,
    });
    setSelectedMessageId(messageId);
    readMessage(messageId);
  };

  const refetchMessages = useCallback(async () => {
    if (refetchCounter.current >= 3) {
      return;
    }
    try {
      await refetch({ throwOnError: true });
      refetchCounter.current++;
    } catch (e) {
      // error is handled in ApiErrorDialog
    }
  }, [refetch]);

  useEffect(() => {
    if (pushNotificationDeeplinkValue === MESSAGE_CENTRE_DEEPLINK) {
      refetchMessages();
    }
  }, [pushNotificationDeeplinkValue, refetchMessages]);

  return {
    checkMessageReadStatus,
    error,
    isError,
    isLoading,
    isFetching,
    isRefetching,
    messages,
    navigateToMessageScreen,
    pageTag,
    refetchMessages,
    selectedMessageId,
  };
};
