import { useAnalytics, useTrackStateEvent } from '@hooks/use-analytics';
import { useMessage } from '@hooks/use-messages';
import { useOnPageLoad } from '@hooks/use-on-page-load';
import {
  useAppStackNavigation,
  useAppStackRoute,
} from '@src/navigation/app/hooks';
import { TopAppBarMangaHeaderScreen } from '@src/navigation/app/summary/stack-groups/top-app-bar-manga-header';
import { MessageAction } from '@src/validation/schemas/messages';

import { ACTION_MESSAGE_DETAILS } from './analytics';

type ActionButton = MessageAction & {
  onPress: () => void | Promise<void>;
};

function createActionButton(
  navigate: ReturnType<typeof useAppStackNavigation>['navigate'],
  trackUserEvent: ReturnType<typeof useAnalytics>['trackUserEvent'],
  action: MessageAction
) {
  let onPress = () => {
    // no-op
  };

  switch (action.actionType) {
    case 'WebAuthenticated':
    case 'WebUnauthenticated':
    case 'WebWithDataExchange':
    case 'Unknown': {
      onPress = () => {
        if (action.tag) {
          trackUserEvent(action.tag);
        }
        navigate(TopAppBarMangaHeaderScreen.MessageAction, action);
      };
      break;
    }
    default: {
      break;
    }
  }

  return {
    ...action,
    onPress,
  };
}

export const useMessageDetailsViewModel = () => {
  const {
    params: { MessageId },
  } = useAppStackRoute<typeof TopAppBarMangaHeaderScreen.MessageDetails>();

  const { navigate } = useAppStackNavigation();
  const { trackUserEvent } = useAnalytics();
  const message = useMessage(MessageId);
  const { iconUrl, header, body, tag } = message ?? {};
  useTrackStateEvent(ACTION_MESSAGE_DETAILS(MessageId));

  useOnPageLoad({ pageTag: tag ?? null });

  const actions: ActionButton[] = [];
  if (
    message &&
    'action' in message &&
    message.action &&
    // Phone dialer and in app journeys not yet supported
    message.action.actionType !== 'AppJourney' &&
    message.action.actionType !== 'AppPhoneDialer'
  ) {
    actions.push(createActionButton(navigate, trackUserEvent, message.action));
  }
  if (message && 'actions' in message && message.actions) {
    message.actions
      .filter(
        (action) =>
          // Phone dialer and in app journeys not yet supported
          action.actionType !== 'AppJourney' &&
          action.actionType !== 'AppPhoneDialer'
      )
      .forEach((action) => {
        actions.push(createActionButton(navigate, trackUserEvent, action));
      });
  }

  return { iconUrl, header, body, actions };
};
