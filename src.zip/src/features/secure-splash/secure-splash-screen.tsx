import { useAppInBackground } from '@hooks/use-app-in-background';
import { isManga } from '@hooks/use-expo-config';
import { DirectWealthSplashScreenView } from '@src/components/splash-screen/direct-wealth-splash-screen-view';
import { PropsWithChildren } from 'react';
import { Platform } from 'react-native';

import { SecuritySplashScreenView } from './secure-splash-screen-view';

const SecuritySplashScreenIOS = ({ children }: PropsWithChildren) => {
  const { showSecurityScreen } = useAppInBackground();
  return (
    <>
      {showSecurityScreen &&
        (isManga() ? (
          <SecuritySplashScreenView />
        ) : (
          <DirectWealthSplashScreenView />
        ))}
      {children}
    </>
  );
};

const SecuritySplashScreenAndroid = ({ children }: PropsWithChildren) => (
  <>{children}</>
);

export const SecuritySplashScreen = ({ children }: PropsWithChildren) =>
  Platform.OS === 'ios' ? (
    <SecuritySplashScreenIOS>{children}</SecuritySplashScreenIOS>
  ) : (
    <SecuritySplashScreenAndroid>{children}</SecuritySplashScreenAndroid>
  );
