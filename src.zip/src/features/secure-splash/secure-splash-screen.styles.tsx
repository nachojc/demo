import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    zIndex: 1000,
    backgroundColor: '#FFD900',
  },
  imageContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  textContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  textStyle: {
    marginBottom: 50,
    fontSize: 22,
    fontWeight: '400',
    color: '#191D64',
    fontFamily: 'SourceSansPro-Regular',
  },
});
