import { Image } from '@aviva/ion-mobile';
import { Text, useWindowDimensions, View } from 'react-native';

import { styles } from './secure-splash-screen.styles';

export const SecuritySplashScreenView = () => {
  //Maintains 1:1 ratio
  const { width: imageSize } = useWindowDimensions();

  return (
    <View style={styles.container}>
      <View style={{ flex: 1 }} />
      <View style={styles.imageContainer}>
        <Image
          source={require('assets/myaviva-splash.png')}
          style={{ width: imageSize, height: imageSize }}
          accessibilityIgnoresInvertColors
          resizeMode={'contain'}
          testID="test:id/myaviva-splash"
        />
      </View>
      <View style={styles.textContainer}>
        <Text style={styles.textStyle}>MyAviva</Text>
      </View>
    </View>
  );
};
