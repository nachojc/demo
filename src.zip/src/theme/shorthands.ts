/**
 * This will be move to ion-mobile when this is extracted to its own package,
 * removing it now crashes the app
 */
// eslint-disable-next-line no-restricted-imports
import { shorthands as tamaguiShorthands } from '@tamagui/shorthands';

export const shorthands = {
  ...tamaguiShorthands,
};
