import { FlagsSchema } from '@src/validation/schemas/feature-flags';

import featureFlags from '../../../resources/ma/feature-flags.json';
import { FeatureFlags } from '..';

jest.mock('fs', () => ({
  existsSync: jest.fn().mockReturnValueOnce(true),
}));

jest.mock(
  '../feature-flags.json',
  () => ({
    dwEOLEnabled: false,
    dwFAQsEnabled: false,
    dwFindAndCombineEnabled: true,
    dwSimpleWealthEnabled: true,
    dwSimpleWealthDigitalAdviceEnabled: true,
    dwIsaApplyDirectNativeFlowEnabled: false,
    dwIsaApplySimpleWealthNativeFlowEnabled: true,
    dwIsaApplySimpleWealthIgnoreCIDocFail: false,
    dwIsaApplySimpleWealthIgnoreEligibility: false,
    dwIsaApplyBypassSubmitApiLogic: false,
    dwPCSAllowMultiSelect: false,
    dwSIPPPensionEditEnabled: true,
    dwVirtualAssistantEnabled: true,
    myDriveOnboardingComplete: false,
    myDriveUseMockData: false,
    simpleWealthPopupEnabled: false,
  }),
  { virtual: true }
);

describe('Feature Flags', () => {
  it('should read and parse feature flags from JSON file', () => {
    const parsedFlags = FlagsSchema.parse(featureFlags);
    expect(FeatureFlags.dwEOLEnabled.get()).toEqual(parsedFlags.dwEOLEnabled);
    expect(FeatureFlags.dwFAQsEnabled.get()).toEqual(parsedFlags.dwFAQsEnabled);
    expect(FeatureFlags.dwFindAndCombineEnabled.get()).toEqual(
      parsedFlags.dwFindAndCombineEnabled
    );
    expect(FeatureFlags.dwSimpleWealthEnabled.get()).toEqual(
      parsedFlags.dwSimpleWealthEnabled
    );
    expect(FeatureFlags.dwSimpleWealthDigitalAdviceEnabled.get()).toEqual(
      parsedFlags.dwSimpleWealthDigitalAdviceEnabled
    );
    expect(FeatureFlags.dwIsaApplyDirectNativeFlowEnabled.get()).toEqual(
      parsedFlags.dwIsaApplyDirectNativeFlowEnabled
    );
    expect(FeatureFlags.dwIsaApplySimpleWealthNativeFlowEnabled.get()).toEqual(
      parsedFlags.dwIsaApplySimpleWealthNativeFlowEnabled
    );
    expect(FeatureFlags.dwIsaApplySimpleWealthIgnoreCIDocFail.get()).toEqual(
      parsedFlags.dwIsaApplySimpleWealthIgnoreCIDocFail
    );
    expect(FeatureFlags.dwIsaApplySimpleWealthIgnoreEligibility.get()).toEqual(
      parsedFlags.dwIsaApplySimpleWealthIgnoreEligibility
    );
    expect(FeatureFlags.dwIsaApplyBypassSubmitApiLogic.get()).toEqual(
      parsedFlags.dwIsaApplyBypassSubmitApiLogic
    );
    expect(FeatureFlags.dwPCSAllowMultiSelect.get()).toEqual(
      parsedFlags.dwPCSAllowMultiSelect
    );
    expect(FeatureFlags.dwSIPPPensionEditEnabled.get()).toEqual(
      parsedFlags.dwSIPPPensionEditEnabled
    );
    expect(FeatureFlags.dwVirtualAssistantEnabled.get()).toEqual(
      parsedFlags.dwVirtualAssistantEnabled
    );
    expect(FeatureFlags.myDriveOnboardingComplete.get()).toEqual(
      parsedFlags.myDriveOnboardingComplete
    );
    expect(FeatureFlags.myDriveUseMockData.get()).toEqual(
      parsedFlags.myDriveUseMockData
    );
    expect(FeatureFlags.simpleWealthPopupEnabled.get()).toEqual(
      parsedFlags.simpleWealthPopupEnabled
    );
  });

  it('should throw an error when JSON file contains invalid data', () => {
    jest.mock('./feature-flags.json', () => 'invalid json', { virtual: true });

    expect(() => {
      require('./index');
    }).toThrow();
  });
});
