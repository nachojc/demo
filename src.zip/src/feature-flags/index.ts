import { observable } from '@legendapp/state';
import { Flags, FlagsSchema } from '@src/validation/schemas/feature-flags';

const featureFlagsPath = './feature-flags.json';
const featureFlags = require(featureFlagsPath);

let flags: Flags = FlagsSchema.parse({
  /**
   * dwEOLEnabled is set to false by default and is controlled remotely in the Firebase Remote Config
   *
   * When enabled this will disable the Log In screen for Direct Wealth users.
   * The Log In screen is replaced with the End Of Life screen and a custom header
   */
  dwEOLEnabled: false,
  /**
   * dwFAQsEnabled is set to false by default
   *
   * When enabled this will make visible the Pension Consolidation Service FAQs
   * on the Direct Wealth Dashboard screen
   */
  dwFAQsEnabled: false,
  /**
   * dwFindAndCombineEnabled is set to true by default
   *
   * When enabled this will allow Direct Wealth users with DPA2 Unlocked to navigate to the
   * Find & Combine Landing screen when pressing the Find & Combine entry card
   * from the Wealth Control card list
   */
  dwFindAndCombineEnabled: true,
  /**
   * dwNavigatorEnabled is set to true by default
   *
   * When enabled for Direct Wealth users that are eligible for the simple wealth journey,
   * will allow access to the simple wealth screen from Portfolio Summary and Product View screens
   */
  dwSimpleWealthEnabled: false,
  /**
   * dwSimpleWealthDigitalAdviceEnabled is set to false by default
   *
   * When enabled for Direct Wealth users that are eligible for the simple wealth journey,
   * will allow access to the Digital Advice flow from the Post Payment Hub
   */
  dwSimpleWealthDigitalAdviceEnabled: true,
  /**
   * dwIsaApplyDirectNativeFlowEnabled is set to false by default
   *
   * Default navigates to web journey. When enabled it will navigate users to the native ISA apply journey
   *
   */
  dwIsaApplyDirectNativeFlowEnabled: false,
  /**
   * dwIsaApplySimpleWealthNativeFlowEnabled is set to false by default
   *
   * Default navigates to web journey. When enabled it will navigate users to the native ISA apply journey
   *
   */
  dwIsaApplySimpleWealthNativeFlowEnabled: true,
  /**
   * dwIsaApplySimpleWealthIgnoreEligibility is set to false by default
   *
   * When true, simple wealth Hub entry point will be shown regardless of the value of Simple Wea;th Service API isEligibleForNavigatorJourney
   *
   */
  dwIsaApplySimpleWealthIgnoreCIDocFail: false,
  /**
   *  dwIsaApplySimpleWealthIgnoreCIDocFail is set to false by default
   *
   * When true, Isa apply important information screen will enable the continue button regardless of whether the charges illustration document API call has failed
   *
   */
  dwIsaApplySimpleWealthIgnoreEligibility: false,
  /**
   * dwIsaApplyBypassSubmitApiLogic is set to false by default
   *
   * When submitting the Isa Apply application, the submit API call will be bypassed and navigate the user out of the journey
   *
   */
  dwIsaApplyBypassSubmitApiLogic: false,
  /**
   * dwPCSAllowMultiSelect is set to false by default
   *
   * When enabled for Direct Wealth users will make visible the Ready to Transfer view
   * under the Pension Consolidation Service screen
   */
  dwPCSAllowMultiSelect: false,
  /**
   * dwSIPPPensionEditEnabled is set to true by default
   *
   * When enabled this will allows users to edit their pension from the SIPP Transfer screen
   */
  dwSIPPPensionEditEnabled: true,
  /**
   * dwVirtualAssistantEnabled is set to true by default
   *
   * When enabled for Direct Wealth users will allow access to Nuance Live Assist
   */
  dwVirtualAssistantEnabled: true,
  /**
   * myDriveOnboardingComplete is set to false by default
   *
   * When enabled for My Drive eligible users, will make visible a My Drive item on the More screen
   */
  myDriveOnboardingComplete: false,
  /**
   * myDriveUseMockData is set to false by default
   *
   * When enabled this will populate mock My Drive data on the My Drive screen
   * and clear mock My Drive data in the useResetSignOut hook
   */
  myDriveUseMockData: false,
  /**
   * simpleWealthPopEnabled is set to false by default
   *
   * When enabled this will show the Simple Wealth Navigator pop up modal on the MANGA wealth tab dashboard
   */
  simpleWealthPopupEnabled: false,
});

try {
  flags = FlagsSchema.parse(featureFlags);
  console.log('Parsed feature flags:', flags);
} catch (error) {
  console.error('Error parsing the feature flags:', error);
  // We need all of the feature flags to be present in the JSON file
  throw error;
}

export const FeatureFlags = observable(flags);
