import { MixedStyleDeclaration } from 'react-native-render-html';

export type HTMLStyles = Readonly<Record<string, MixedStyleDeclaration>>;
