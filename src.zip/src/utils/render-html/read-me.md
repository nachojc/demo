# Render HTML

Package: https://www.npmjs.com/package/react-native-render-html

We are using `react-native-render-html` to enable us to render HTML chunks directly inside JSX.

You will pass a HTMLSource to the component, when passing in the HTMLSource avoid using pre styled tags like `<p> <h1> <h2>` etc as we want to do all styling using out own styles in JS.

We have our default styles (listed below), if you need to add additional styles you can either pass this in as a prop or add to the default styles object.

> > _Think before adding to the master component and If you do this remember to add to the tests and docs._

## Default Styles

Styles are applied to the HTML in the JSX file using their class name, you can add multiple class names to each tag in HTML so we want to keep each style small so they can be combined. You can add styles using the tag property or ID, however we want to avoid this please and use class styling.

> > When using the HTML text tags (`<p>, <h1>, <h2>` etc) there is a margin automatically applied, this is removed in the main component using tags styles. Please do not remove this.

#### Example HTML

```
<span class="text bold underline">meow</span>
```

#### Example Styles

```
  text: {
    fontFamily: 'SourceSansPro-Regular',
    color: '#333333',
    fontSize: 24,
  },
  bold: { fontFamily: 'SourceSansPro-Bold' },
  underline: { textDecorationLine: 'underline' },
```

As you can see the `<span>` has three classes: _text, bold and underline_ you can then see three styles with matching names. This applies those matching styles to the span.

<br />

## Pressables

When adding pressables to you HTML use the `<a>` tag. We don't have a default onPress action, we shall simply render a warning to the console. When rendering the RenderHtml component you will have an onPress call that exposes the url - using the url you can check what you want to do with that pressable in your parent component.
