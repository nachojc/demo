import { Dimensions } from 'react-native';
import { GestureResponderEvent } from 'react-native-modal';
import {
  default as ReactNativeRenderHtml,
  defaultSystemFonts,
  HTMLSource,
} from 'react-native-render-html';

import { HTMLStyles } from './types';

const systemFonts = [
  'SourceSansPro-Regular',
  'SourceSansPro-Bold',
  ...defaultSystemFonts,
];

const nativeWidth = Dimensions.get('window').width;

export function RenderHtml({
  onPress,
  source,
  styles,
  width = nativeWidth,
}: {
  onPress?: (url: string) => void;
  source: HTMLSource;
  styles?: HTMLStyles;
  width?: number;
}) {
  const renderersProps = {
    a: {
      onPress(_: GestureResponderEvent, url: string) {
        if (onPress) {
          // if the href is just a string "about:///" is added but the library
          // removing this here to keep it cleaner in the parent components.
          const trimmedUrl = url.replace('about:///', '');
          onPress(trimmedUrl);
        } else {
          console.warn(
            'No onPress provided to RenderHtml but an Anchor tag was found.'
          );
        }
      },
    },
  };

  return (
    <ReactNativeRenderHtml
      classesStyles={{ ...classStyles, ...styles }}
      contentWidth={width}
      renderersProps={renderersProps}
      source={source}
      systemFonts={systemFonts}
      tagsStyles={tagStyles}
    />
  );
}

const classStyles: HTMLStyles = {
  text: {
    fontFamily: 'SourceSansPro-Regular',
    color: '#333333',
    fontSize: 16,
  },
  link: { color: '#004FB6' },
  bold: { fontFamily: 'SourceSansPro-Bold' },
  underline: { textDecorationLine: 'underline' },
  strikethrough: { textDecorationLine: 'line-through' },
};

const tagStyles: HTMLStyles = {
  p: { margin: 0 },
  h1: { margin: 0 },
  h2: { margin: 0 },
  h3: { margin: 0 },
  h4: { margin: 0 },
  h5: { margin: 0 },
  h6: { margin: 0 },
  li: { margin: 0 },
  ul: { margin: 0 },
};
