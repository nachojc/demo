import { TextStyle } from 'react-native';

type HighlightedText = {
  text: string;
  style?: TextStyle;
}[];

export const makeHighlightedText = (
  text: string,
  options: {
    matcher: string;
    style: TextStyle;
  }
): HighlightedText => {
  const { matcher, style } = options;
  const regex = new RegExp(matcher, 'g');
  const matches = text.matchAll(regex);
  const result: HighlightedText = [];

  let lastIndex = 0;
  let next = matches.next();
  while (next.value) {
    const { index } = next.value;
    const matchEndIndex = index + next.value[0].length;
    if (index !== matchEndIndex) {
      result.push({ text: text.slice(lastIndex, index) });
      result.push({ text: text.slice(index, matchEndIndex), style });
      lastIndex = matchEndIndex;
    }
    next = matches.next();
  }
  result.push({ text: text.slice(lastIndex) });
  return result.filter((item) => item.text !== '');
};
