import { HealthProduct } from '@src/validation/schemas/product/health-product';

import { exhaustive } from '../exhaustive';

type CorporateHealthPolicy =
  | 'SME'
  | 'Corporate'
  | 'Trust'
  | 'ThirdPartyManaged';

export type HealthPolicy = CorporateHealthPolicy | 'Individual';

const resolveCorporatePolicyType = (
  policyNumber: string
): CorporateHealthPolicy | undefined => {
  const policyTypeIndicator = parseInt(policyNumber.substring(0, 2), 10);

  if (Number.isNaN(policyTypeIndicator)) {
    return undefined;
  }

  if (policyTypeIndicator >= 50 && policyTypeIndicator <= 94) {
    return 'SME';
  } else if (policyTypeIndicator >= 95 && policyTypeIndicator <= 96) {
    return 'Corporate';
  } else if (policyTypeIndicator === 98) {
    return 'Trust';
  } else if (policyTypeIndicator === 99) {
    return 'ThirdPartyManaged';
  } else {
    return undefined;
  }
};

export const getPolicyType = (
  healthProductType: HealthProduct['ProductType'],
  policyNumber: string
): HealthPolicy | undefined => {
  switch (healthProductType) {
    case 'PrivateMedicalInsurance':
      return 'Individual';
    case 'CorporateMedicalInsurance':
      return resolveCorporatePolicyType(policyNumber);
    default:
      exhaustive(healthProductType);
  }
};
