export const setUTCHoursToZero = (date: Date) => {
  const pivot = new Date(date);
  pivot.setUTCHours(0, 0, 0, 0);
  return pivot;
};
