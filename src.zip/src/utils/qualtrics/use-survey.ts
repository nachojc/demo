import { isManga } from '@hooks/use-expo-config';
import { useFocusEffect } from '@react-navigation/native';
import { useCallback } from 'react';
import Qualtrics from 'react-native-qualtrics';

import { evalQualtricsInitProject, isQualtricsInitialised } from './qualtrics';

const runQualtrics = async (screenName: string) => {
  if (await isQualtricsInitialised()) {
    Qualtrics.setString('screenName', screenName);
    Qualtrics.registerViewVisit(screenName);
    evalQualtricsInitProject();
  }
};

export const useSurvey = (screenName: string | null, hideSurvey = false) => {
  useFocusEffect(
    useCallback(() => {
      if (isManga() && screenName && !hideSurvey) {
        runQualtrics(screenName);
      }
    }, [hideSurvey, screenName])
  );
};
