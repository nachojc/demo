import { getLogger } from '@interfaces/logger';
import { config } from '@src/common/config';
import Qualtrics from 'react-native-qualtrics';

const interceptId = config.QUALTRICS_INTERCEPT_ID.get();

const log = getLogger('Qualtrics');

// Initialise the Qualtrics RN SDK
export const initQualtrics = () => {
  log.info('Initialising...');
  Qualtrics.initializeProjectWithExtRefId(
    config.QUALTRICS_BRAND_ID.get(),
    config.QUALTRICS_ZONE_ID.get(),
    '',
    (initializationResults) => {
      if (initializationResults) {
        log.info('Initialisation complete');
      } else {
        log.warn('Initialisation incomplete');
      }
    }
  );
};

export const resetQualtricsTimer = () => {
  log.info('Reset timer');
  Qualtrics.resetTimer();
};

export const isQualtricsInitialised = async (): Promise<boolean> => {
  const interceptIds = await Qualtrics.getInitializedIntercepts();

  const hasIntercept = interceptIds.find(
    (interceptID) => interceptID === interceptId
  );

  return hasIntercept ? true : false;
};

// Evaluate and display our initialised survey
export const evalQualtricsInitProject = async () => {
  log.info('Evaluating project...');
  try {
    Qualtrics.evaluateIntercept(interceptId, (targetingResults) => {
      log.info('Evaluation result: ', targetingResults);
      if (targetingResults.passed) {
        log.info(
          `Targetting results passed, displaying survey for intercept ID ${interceptId}`
        );
        Qualtrics.displayIntercept(interceptId);
      }
    });
  } catch (error) {
    log.error(new Error(`Evaluation error: ${error}`, { cause: error }));
  }
};
