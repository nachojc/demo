import ReactNativeBlobUtil from 'react-native-blob-util';

export const userCacheDir = () =>
  `${ReactNativeBlobUtil.fs.dirs.CacheDir}/user-files`;

export const deleteUserCacheDir = () =>
  ReactNativeBlobUtil.fs.unlink(userCacheDir()).catch(() => {
    /* ignoring because throws when does not exist */
  });
