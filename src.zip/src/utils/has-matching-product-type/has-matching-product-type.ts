import { Customer } from '@src/validation/schemas/customer';
import { Products } from '@src/validation/schemas/product/products';

import { productTypeMap } from './product-type-map';

export const hasMatchingProductType = (
  customer: Customer,
  category: keyof typeof productTypeMap
) =>
  customer?.Products.some((product) => {
    const matchedProductTypes = Object.values(
      productTypeMap[category]
    ) as Partial<Products['ProductType']>[];

    return matchedProductTypes.includes(product.ProductType);
  });
