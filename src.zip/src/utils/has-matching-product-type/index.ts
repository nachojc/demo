export * from './has-matching-product-type';
