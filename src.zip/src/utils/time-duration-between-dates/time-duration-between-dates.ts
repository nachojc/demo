import { UK_DATE_FORMAT } from '@constants/string-formats';
import {
  differenceInDays,
  differenceInMonths,
  differenceInYears,
  parse,
} from 'date-fns';

export const timeDurationBetweenDates = (
  startDate: string,
  endDate: string | undefined,
  format?: 'days' | 'months' | 'years'
) => {
  if (!endDate) {
    return;
  }

  const parsedStartDate = parse(startDate, UK_DATE_FORMAT, new Date());
  const parsedEndDate = parse(endDate, UK_DATE_FORMAT, new Date());

  switch (format) {
    case 'days':
      return differenceInDays(parsedEndDate, parsedStartDate);
    case 'months':
      return differenceInMonths(parsedEndDate, parsedStartDate);
    case 'years':
      return differenceInYears(parsedEndDate, parsedStartDate);
    default:
      return differenceInYears(parsedEndDate, parsedStartDate);
  }
};
