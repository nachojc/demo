export const isNumber = (valueStr: string) => {
  return !!/^\d+$/.test(valueStr);
};
