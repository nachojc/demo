// getValues(Customer) /=> ['John', 'Smith']
import { ValueOf } from 'type-fest';

export const getValues = Object.values as <T extends object>(
  obj: T
) => ValueOf<T>;
// getKeys(Customer) /=> ['firstName', 'lastName']
export const getKeys = Object.keys as <T extends object>(obj: T) => (keyof T)[];

// omit(Customer, 'firstName', 'lastName')
export const omit = <T extends object, K extends keyof T>(
  obj: T,
  ...keys: K[]
): Omit<T, K> => {
  const _ = { ...obj };
  keys.forEach((key) => delete _[key]);
  return _;
};

export const deepEqual = (x: unknown, y: unknown): boolean => {
  return x && y && typeof x === 'object' && typeof y === 'object'
    ? Object.keys(x).length === Object.keys(y).length &&
        Object.keys(x).reduce(function (isEqual, key: unknown) {
          return isEqual && deepEqual(x[key], y[key]);
        }, true)
    : x === y;
};

/**
 * Traverses a nested object structure to find and update a specific value based on a condition.
 * @param obj The object to traverse.
 * @param condition A function that takes an object and returns true if the object should be modified.
 * @param updateFunction A function that takes an object and returns an updated object.
 * @returns The updated object.
 */
type AnyObject = {
  [key: string]: unknown;
};

export const traverseAndUpdate = (
  obj: AnyObject,
  condition: (current: AnyObject) => boolean,
  updateFunction: (current: AnyObject) => AnyObject
): AnyObject | AnyObject[] => {
  function traverse(current: AnyObject): AnyObject | AnyObject[] {
    if (Array.isArray(current)) {
      return current.map((item) => traverse(item)) as AnyObject[];
    } else if (typeof current === 'object' && current !== null) {
      if (condition(current)) {
        return updateFunction(current);
      }
      return Object.keys(current).reduce((acc: AnyObject, key: string) => {
        acc[key] = traverse(current[key] as AnyObject);
        return acc;
      }, {});
    }
    return current;
  }

  return traverse(obj) as AnyObject;
};
