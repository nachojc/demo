export const getPaymentMethodContextValue = (
  paymentMethod?: 'Bank transfer (BACS)' | 'Debit card' | ''
) => {
  if (paymentMethod === 'Bank transfer (BACS)') {
    return paymentMethod.toUpperCase();
  }

  if (paymentMethod === 'Debit card') {
    return 'CARD';
  }

  return '';
};
