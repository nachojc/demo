/**
 * Used to format a 6 digit number to contain dashed, this is the
 * traditional sort code format a user would be expecting.
 *
 * Example: formatSortCode(123456) would be show as 12-34-56
 */

export const formatSortCode = (sortCode: string | undefined) =>
  sortCode ? sortCode.replace(/(\d{2})(\d{2})(\d{2})/, '$1-$2-$3') : '';
