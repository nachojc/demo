export const repeatArrayToLength = (arr: string[], num: number) => {
  const result = [];

  for (let i = 0; i < num; i++) {
    result.push(arr[i % arr.length]);
  }

  return result;
};
