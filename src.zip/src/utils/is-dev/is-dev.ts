/**
 * @description This only works on builds locally to simulators
 * It will be false for ALL QA builds due to configuration -Release
 * being how we build to browserstack
 */
export const isDev = () => __DEV__;
