import { getLogger } from '@interfaces/logger';

const log = getLogger(formatPath.name);

/**
 * @description
 * formatPath takes a path as a string and any number of
 * variables(string or number) and replaces placeholders with variables.
 *
 * This is used to formatPath from .env file specifically.
 * And would only work if placeholders are of the format {0} or {1} so on and so forth
 *
 * If you pass lesser number of variables than needed in the path it would return null.
 *
 * @example
 * formatPath('/MessagingApi/api/v2/support/phoneNumbers/{0}/{1}/', 'hello', 'world')
 * result: '/MessagingApi/api/v2/support/phoneNumbers/hello/world/'
 */

export function formatPath(
  path: string,
  ...variables: (string | number)[]
): string | null {
  const regex = /\{\d+\}/g;
  const requiredVariablesCount = (path.match(regex) || []).length;
  if (variables.length < requiredVariablesCount) {
    log.warn(
      `Not enough variables provided. Expected ${requiredVariablesCount}, but got ${variables.length}.`
    );
    return null;
  }
  return path.replace(regex, (match) => {
    const placeholderIndex = parseInt(match.slice(1, -1), 10);
    return variables[placeholderIndex] as string;
  });
}
