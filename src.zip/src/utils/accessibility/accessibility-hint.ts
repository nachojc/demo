import { spellOutString } from './spell-out-string';

type Options = {
  spellOutString?: boolean;
};
type CreateAccessibilityRoleHint = (text: string, options?: Options) => string;

const formatText = (text: string, options?: Options) => {
  if (options?.spellOutString) {
    return spellOutString(text);
  }

  return text;
};

export const createRoleLinkOpenHint: CreateAccessibilityRoleHint = (
  text,
  options
) => `Opens ${formatText(text, options)}`;

export const createRoleLinkShareHint: CreateAccessibilityRoleHint = (text) =>
  `Shares ${text}`;

export const createRoleLinkSaveHint: CreateAccessibilityRoleHint = (text) =>
  `Saves ${text}`;
