/**
 * When a string has an ellipsis ('Once upon a time...') it is read out by screen readers on Andorid
 * in an unexpted way, so "Once upon a time..." is read out like "Once upon a time 3 period". This function
 * removes the periods so the screen reader can read as expected.
 *
 * The result of this function is designed to be placed in the accessibilityLabel
 * or accessibilityValue of the element.
 */
export const removeEllipsis = (text: string) => text.replaceAll('...', '');
