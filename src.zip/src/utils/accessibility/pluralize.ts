export const pluralize = (count: number, noun: string, sufix = 's'): string =>
  count > 1 ? `${noun + sufix}` : noun;
