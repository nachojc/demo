export const generateObjectFieldBreakdown = <T extends object>(
  obj: T[],
  field: keyof T
): Record<string, number> => {
  const breakdown = new Map<string, number>();

  obj.forEach((e) => {
    if (typeof e === 'object' && field in e) {
      const value = e[field] as unknown as string; // returns TypeOfProducts = Pensions etc
      if (value) {
        const currentCount = breakdown.get(value) || 0;
        breakdown.set(value, currentCount + 1);
      }
    }
  });
  return Object.fromEntries(breakdown);
};
