import { Platform } from 'react-native';

/**
 * When using the voice Daniel English (UK) in VoiceOver on iOS, the word 'to' will
 * be pronounced incorrectly if it's followed by a punctuation.
 * Temporary solution is to change the word 'to' to 'too'.
 */
export const screenReaderTranslate = (text: string) => {
  if (Platform.OS === 'ios') {
    let fixedText = text;
    fixedText = fixedText.replaceAll(/\bto\b(?=[.,:;!?])/g, 'too'); // 'to' pronunciation fix
    fixedText = fixedText.replaceAll(
      /\b(\w+(?:[’']ve| have| has| had)) read\b/g,
      '$1 red'
    ); // 'read' pronunciation fix
    return fixedText;
  } else {
    return text;
  }
};
