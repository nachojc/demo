/* eslint-disable @typescript-eslint/no-explicit-any */
import { Platform } from 'react-native';

/**
 * When using the voice over on iOS, the '/' is being read out
 * as 'slash'. This function removes the '/' from the string.
 */
export const removeSlash = (text: any) => {
  if (typeof text === 'string' && Platform.OS === 'ios') {
    return text.replace('/', ' ');
  }
  return text;
};
