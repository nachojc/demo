/**
 * Some time estimates in strings written like: "1-6 weeks" are read wrong by screen readers.
 * This function replaces the "-" for " to " to ensure the string is read correctly, it only replaces
 * the dash between numbers and not words so we dont replace "Self-Invested Personal Pension" to
 * "Self to Invested Personal Pension"
 *
 * The result of this function is designed to be placed in the accessibilityLabel
 * or accessibilityValue of the element.
 *
 * Example: "1-6 weeks" may be read out as 'one dash six weeks' and we want
 * it to read out 'one to six weeks'
 */
export const replaceDashesInNumberStrings = (text: string) =>
  text.replaceAll(/(?<=\d)-(?=\d)/g, ' to ');
