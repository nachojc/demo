export const convertBreakdownToA11yValue = (
  breakdown: Record<string, number>,
  intro = 'List breakdown: '
): string => {
  let value = intro;
  let totalCount = 0;

  Object.entries(breakdown).forEach(([type, count]) => {
    value += `${type}: ${count}, `;
    totalCount += count;
  });

  value = value.slice(0, -2);
  value += `. Total: ${totalCount}.`;

  return value;
};
