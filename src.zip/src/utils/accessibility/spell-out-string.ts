/**
 * Some strings such as ids are read wrong by screen readers. This function
 * places a space between each letter or number to ensure the string is spelled out.
 *
 * The result of this function is designed to be placed in the accessibilityLabel
 * or accessibilityValue of the element.
 *
 * Example: TOK123 may be read out as 'tok one hundred and twenty-three' and we want
 * it to read out 'T O K one two three'
 */
export const spellOutString = (text: string) =>
  text
    .replaceAll(/[^A-z0-9]/g, '')
    .split('')
    .join(' ');

export const spellOutInnerStrings = (
  innerStrings: string[] | string,
  fullString: string
) => {
  const receivedStrings =
    typeof innerStrings === 'string' ? [innerStrings] : innerStrings;
  return receivedStrings.reduce(
    (total, current) => total.replaceAll(current, spellOutString(current)),
    fullString
  );
};
