/**
 * If a phone number if formatted like 0800 123 1234, screen readers can read this as:
 * zero, eight, zero, zero, one hundred and twenty-three, one thousand two hundred and thirty-four.
 *
 * This function is designed to remove the spaces from the phone number to pass
 * into the `accessibilityLabel`.
 */
export const removePhoneNumberFormatting = (phoneNumber: string) =>
  phoneNumber.replaceAll(
    /\(?(\+)?(\d{2,})\)?\s+\(?(\d{2,})\)?(\s+(\d{2,}))?(\s+(\d{2,}))?/g,
    '$1$2$3$5$7'
  );
