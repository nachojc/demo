import { convertGBDateToISO } from '@src/utils';
import { Documents } from '@src/validation/schemas/documents';

type Document = Documents['CurrentDocuments'][number];

export const getDateObjFromGBDate = (date: string) =>
  new Date(convertGBDateToISO(date));

export const isDocumentInCurrentYear = (document: Document): boolean => {
  if (!document?.EffectiveDate) {
    return false;
  }
  return (
    getDateObjFromGBDate(document.EffectiveDate).getFullYear() ===
    new Date().getFullYear()
  );
};

export const getAllYearsFromDocuments = (documents: Document[]) => [
  ...new Set(
    documents.map((d) =>
      getDateObjFromGBDate(d.EffectiveDate ?? '').getFullYear()
    )
  ),
];

export const sortDocumentsByDate = (documents: Document[] = []) =>
  [...documents].sort(
    (a: Document, b: Document) =>
      getDateObjFromGBDate(b.EffectiveDate ?? '').getTime() -
      getDateObjFromGBDate(a.EffectiveDate ?? '').getTime()
  );

export const getCurrentYearDocuments = (documents: Document[]): Document[] =>
  documents.filter((d) => isDocumentInCurrentYear(d));

export const getPastDocuments = (documents: Document[]): Document[] =>
  documents.filter((d) => !isDocumentInCurrentYear(d));

export const groupDocumentsByYear = (documents: Document[]) => {
  const groupedDocs: { [key: string]: Document[] } = {};
  getAllYearsFromDocuments(documents).forEach((d) => (groupedDocs[d] = []));

  documents.forEach((d) =>
    groupedDocs[getDateObjFromGBDate(d.EffectiveDate ?? '').getFullYear()].push(
      d
    )
  );

  return groupedDocs;
};
