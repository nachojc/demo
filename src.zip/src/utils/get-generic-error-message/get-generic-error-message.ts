import { i18n } from '@src/i18n/i18n';

export const getGenericErrorMessage = () => {
  const errorMessage = {
    title: i18n.t('common.genericError.title'),
    message: i18n.t('common.genericError.copy'),
  };
  return errorMessage;
};
