import { isDevMode } from '@config';
import { getLogger } from '@interfaces/logger';
import { PhoneNumberType, PhoneNumberUtil } from 'google-libphonenumber';

const log = getLogger(isValidPhoneNumber.name);
const phoneUtil = PhoneNumberUtil.getInstance();
const validPhoneNumberTypes = [
  PhoneNumberType.FIXED_LINE,
  PhoneNumberType.MOBILE,
  PhoneNumberType.FIXED_LINE_OR_MOBILE,
];

export function isValidPhoneNumber(phoneNumber: string): boolean {
  if (phoneNumber === '+44000' && isDevMode()) {
    return true;
  }

  try {
    const parsedNumber = phoneUtil.parse(phoneNumber);
    const countryRegionCode = phoneUtil.getRegionCodeForNumber(parsedNumber);

    if (countryRegionCode === null) {
      throw Error('Not a valid country code or Number');
    }

    const numberType = phoneUtil.getNumberType(parsedNumber);
    if (!validPhoneNumberTypes.includes(numberType)) {
      throw Error(`Not a valid number type, phone type is ${numberType}`);
    }

    return true;
  } catch (error) {
    log.info(error);
    return false;
  }
}
