import { ContactProduct } from '@src/features/contact-us/model';

export const dwProductTypes: ContactProduct[] = [
  'Direct wealth pension',
  'Pension drawdown',
  'ISA',
  'Investment account',
];

export const dwProductTypeStrings: string[] = [
  'direct-wealth-pension',
  'pension-drawdown',
  'isa',
  'investment-account',
].concat(dwProductTypes);
