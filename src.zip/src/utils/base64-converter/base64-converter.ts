import Base64 from 'crypto-js/enc-base64';
import Utf8 from 'crypto-js/enc-utf8';

export const base64Converter = (value: string) =>
  Base64.stringify(Utf8.parse(value));
