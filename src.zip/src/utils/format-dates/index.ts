import { format } from 'date-fns';
import { enGB } from 'date-fns/locale';

export const formatDates = (input: string) => {
  const dateRegex = /(\d{1,2})\/(\d{1,2})\/(\d{4})/g;

  return input.replace(dateRegex, (_, day, month, year) =>
    format(
      new Date(parseInt(year, 10), parseInt(month, 10) - 1, parseInt(day, 10)),
      'd MMM yyyy',
      { locale: enGB }
    )
  );
};
