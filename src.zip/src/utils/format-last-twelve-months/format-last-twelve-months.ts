import { format, setMonth } from 'date-fns';

export const formatLastTwelveMonths = (month: number, year: number) => [
  format(setMonth(new Date(), month - 1), 'LLLL'),
  (year - 1).toString(),
  format(setMonth(new Date(), month - 2), 'LLLL'),
  month === 1 ? (year - 1).toString() : year.toString(),
];
