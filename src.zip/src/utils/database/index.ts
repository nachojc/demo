import { getLogger } from '@interfaces/logger';
import { Database } from '@nozbe/watermelondb';
import SQLiteAdapter from '@nozbe/watermelondb/adapters/sqlite';
import { migrations } from '@src/models/db/migrations/schema-migrations';
import {
  DataMigration,
  Journey,
  ScoreSummary,
  WeeklyScoreSummary,
} from '@src/models/db/model';
import { schema } from '@src/models/db/schema';

const log = getLogger('database');

const adapter = new SQLiteAdapter({
  schema,
  migrations,
  dbName: 'myAviva',
  jsi: true,
  onSetUpError: (error) => {
    log.error(error);
  },
});

export const database = new Database({
  adapter,
  modelClasses: [DataMigration, ScoreSummary, WeeklyScoreSummary, Journey],
});
