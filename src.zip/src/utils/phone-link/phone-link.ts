import { Linking } from 'react-native';

export const callPhoneNumber = async (
  phoneNumber: string | undefined | null
) => {
  if (!phoneNumber) {
    return;
  }

  const url = `tel:${phoneNumber.replace(/\s+/g, '')}`;

  try {
    const canOpen = await Linking.canOpenURL(url);
    if (canOpen) {
      await Linking.openURL(url);
    } else {
      throw new Error('Cant open that url');
    }
  } catch {
    throw new Error('Cant open that url');
  }
};
