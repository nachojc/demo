import EncryptedStorage from '@aviva/react-native-encrypted-storage/src';
import {
  refreshToken,
  removeStoredAccessToken,
  removeStoredDeviceId,
  removeStoredRefreshToken,
  removeStoredTrustedDeviceId,
  removeStoredTrustToken,
  setStoredDeviceId,
  setStoredTrustedDeviceId,
  setStoredTrustToken,
} from '@interfaces/secure-store';
import { useEffect, useState } from 'react';

import * as Storage from '../../common/interfaces/storage';

const REFRESH_TOKEN_KEY = 'aviva.refreshTokenValue';
const MIGRATION_VALUES_KEY = 'aviva.migrationValues';
class MigrationUserData {
  private migrationRefreshToken: string | null = null;
  migrationValues: MigrationData | null = null;

  private async clearAll() {
    return Promise.all([
      EncryptedStorage.removeItem(REFRESH_TOKEN_KEY),
      EncryptedStorage.removeItem(MIGRATION_VALUES_KEY),
    ]).catch(() => null);
  }
  private async getRefreshToken() {
    this.migrationRefreshToken = await EncryptedStorage.getItem(
      REFRESH_TOKEN_KEY
    ).catch(() => null);
    return this.migrationRefreshToken;
  }
  private async getMigrationValues() {
    try {
      this.migrationValues = JSON.parse(
        (await EncryptedStorage.getItem(MIGRATION_VALUES_KEY)) ?? ''
      );
    } catch (error) {
      this.migrationValues = null;
    }
  }
  async startMigration() {
    await this.getRefreshToken();
    await this.getMigrationValues();
    await this.migrateAllData();
  }
  private async migrateAllData() {
    if (this.migrationValues === null) {
      return;
    }
    await Promise.all([
      removeStoredTrustedDeviceId(),
      removeStoredDeviceId(),
      removeStoredRefreshToken(),
      removeStoredTrustToken(),
      removeStoredAccessToken(),
    ]).catch(() => null);
    Storage.username.set(null);
    Storage.myAvivaOnboardingComplete.set(null);
    Storage.biometricPreference.set(null);

    if (this.migrationRefreshToken) {
      refreshToken.set(this.migrationRefreshToken);
    }
    if (this.trustToken) {
      await setStoredTrustToken(this.trustToken);
    }
    if (this.trustedDeviceId) {
      await setStoredTrustedDeviceId(this.trustedDeviceId);
    }
    if (this.deviceId) {
      await setStoredDeviceId(this.deviceId);
    }
    if (this.migrationValues?.username) {
      Storage.username.set(this.migrationValues.username);
    }
    Storage.biometricPreference.set(this.biometricsLoginPreference ?? null);
    Storage.myDriveActivationId.set(
      this.migrationValues?.myDriveActivationId ?? null
    );
    Storage.loginCount.set(
      (this.getMigrationUserActivity('LoginCount') as number) ?? 0
    );
    Storage.mfaActivationPromptCount.set(
      (this.getMigrationUserActivity('MfaActivationPromptCount') as number) ?? 0
    );
    Storage.mfaPromptDelayDate.set(
      this.getMigrationUserActivity('MfaActivationPromptDelayDate') as string
    );
    Storage.myAvivaOnboardingComplete.set(
      this.getMigrationUserActivity('OnboardingCompleted') as boolean
    );
    Storage.dpaCheckResult.set(
      this.getMigrationUserActivity('DpaCheckResult') as string
    );
    Storage.dpaUnlockResultShowLogout.set(
      this.getMigrationUserActivity('DpaUnlockResultShowLogout') as boolean
    );
    Storage.myDriveActivationFailureShownCount.set(
      this.getMigrationAppUserActivity(
        'MyDriveActivationFailureShownCount'
      ) as number
    );
    Storage.myDriveActivationFailed.set(
      this.getMigrationAppUserActivity('MyDriveActivationFailed') as boolean
    );
    Storage.myDriveSuccessShown.set(
      this.getMigrationAppUserActivity('MyDriveSuccessShown') as boolean
    );
    Storage.myDriveDisabledShown.set(
      this.getMigrationAppUserActivity('MyDriveDisabledShown') as boolean
    );
    await this.clearAll();
  }
  get username() {
    return this.migrationValues?.username ?? null;
  }
  get refreshToken() {
    return this.migrationRefreshToken;
  }
  get trustToken() {
    return this.migrationValues?.trustToken ?? null;
  }
  get deviceId() {
    return this.migrationValues?.deviceId ?? null;
  }
  get trustedDeviceId() {
    return this.migrationValues?.trustedDeviceId ?? null;
  }
  get biometricsLoginPreference() {
    return (
      ((this.getMigrationUserDecisions(
        'BiometricsLoginPreference'
      ) as number) ?? 0) > 1
    );
  }
  get notificationsAccepted() {
    return !!this.getMigrationUserDecisions('NotificationsAccepted');
  }
  get fingerprintEnabled() {
    return !!this.getMigrationUserDecisions('FingerprintEnabled');
  }
  private getMigrationUserActivity(key?: keyof UserActivity) {
    return key
      ? this.migrationValues?.userActivity?.[key]
      : this.migrationValues?.userActivity;
  }
  private getMigrationAppUserActivity(key?: keyof AppUserActivity) {
    return key
      ? this.migrationValues?.appUserActivity?.[key]
      : this.migrationValues?.appUserActivity;
  }
  private getMigrationUserDecisions(key?: keyof UserDecisions) {
    return key
      ? this.migrationValues?.userDecisions?.[key]
      : this.migrationValues?.userDecisions;
  }
}
export const migrationUserData = new MigrationUserData();

export const usePerformMigration = () => {
  const [migrationDone, setMigrationDone] = useState(false);
  useEffect(() => {
    migrationUserData.startMigration().then(() => setMigrationDone(true));
  }, [setMigrationDone]);
  return {
    migrationDone,
  };
};

type AppUserActivity = {
  AppReviewPromptMtaAccepted: boolean;
  RegisterWellbeingClicked: boolean;
  SecurityFeatureOnboardingCompleted: boolean;
  DateOfFirstMyDriveOverlayShown: string | null;
  DateOfSecondMyDriveOverlayShown: string | null;
  MyDriveOverlayShown: boolean;
  MyDriveRenewal: string | null;
  MyDriveRenewalPopupShown: boolean;
  MyDriveTimePopupShown: boolean;
  MyDriveMilesPopupShown: boolean;
  MyDriveCompletePopupShown: boolean;
  MyDriveSuccessShown: boolean;
  MyDriveActivationFailed: boolean;
  AsyncChatOnboardingShown: boolean;
  MyDriveActivationFailureShownCount: number;
  MyDriveDisabledShown: boolean;
  MyDriveHasAllHistoricData: boolean;
};

type UserActivity = {
  OnboardingCompleted: boolean;
  LoginCount: number;
  GeneralDataProtectionRegulationShown: boolean;
  NotificationsPermissionShown: boolean;
  LastReviewPromptAppVersion: string | null;
  AppReviewPromptCount: number;
  AppReviewPromptAccepted: boolean;
  PensionJourneysAppReviewPromptCount: number;
  PensionJourneysAppReviewPromptAccepted: boolean;
  ConsecutiveAccountSyncCount: number;
  ConsecutiveCrashFreeSessionCount: number;
  ConsecutivePendingUpdateLaunchesCount: number;
  UpdateAvailable: boolean;
  DpaCheckResult: string | null;
  DpaUnlockResultShowLogout: boolean;
  BackgroundLocationPermissionRequested: boolean;
  MyDriveOnboardingCompleted: boolean;
  MfaActivationPromptDelayDate: string;
  MfaActivationPromptCount: number;
  AsyncChatOnboardingSeen: boolean;
  TripDetectionActive: boolean;
  MessagesUserPullToRefreshCount: number;
  AppActivity?: string;
};

type UserDecisions = {
  NotificationsAccepted: boolean;
  FingerprintEnabled: boolean;
  BiometricsLoginPreference: number;
};

export type MigrationData = {
  username: string;
  deviceId: string;
  trustedDeviceId: string;
  trustToken: string | null;
  myDriveActivationId: string | null;
  appUserActivity: AppUserActivity;
  userActivity: UserActivity;
  userDecisions: UserDecisions;
};
