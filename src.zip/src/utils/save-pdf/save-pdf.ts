import { sharePdf } from '@src/utils/share-pdf';
import {
  EncodingType,
  readAsStringAsync,
  StorageAccessFramework,
} from 'expo-file-system';
import { Platform } from 'react-native';

/**
 * Saving external pdf or a base64 content uri
 * @param fileUrl - the file url of the pdf
 * @param name - The name of the pdf file
 */
export const savePdf = async (fileUrl: string, name: string): Promise<void> => {
  if (Platform.OS !== 'android') {
    await sharePdf(fileUrl);
    return;
  }

  if (!fileUrl.startsWith('file://')) {
    throw new Error("Expected a url starting with 'file://'");
  }

  const permissions =
    await StorageAccessFramework.requestDirectoryPermissionsAsync();
  if (!permissions.granted) {
    await sharePdf(fileUrl);
    return;
  }

  await copyFileToSaf({
    fileUrl,
    name,
    directoryUri: permissions.directoryUri,
  });
};

// Note: this is not performant because we are passing large strings across the native bridge.
// Unfortunately, there is currently no way to directly copy files to StorageAccessFramework using expo-file-system.
const copyFileToSaf = async ({
  fileUrl,
  name,
  directoryUri,
}: {
  fileUrl: string;
  name: string;
  directoryUri: string;
}) => {
  const base64 = await readAsStringAsync(fileUrl, {
    encoding: EncodingType.Base64,
  });
  const formattedPdfName = name.replace(/ /g, '_');
  const destinationUri = await StorageAccessFramework.createFileAsync(
    directoryUri,
    formattedPdfName,
    'application/pdf'
  );
  await StorageAccessFramework.writeAsStringAsync(destinationUri, base64, {
    encoding: EncodingType.Base64,
  });
};
