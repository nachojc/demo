import { Platform } from 'react-native';
// eslint-disable-next-line no-restricted-imports
import { getReadableVersion as getReadableVersionInternal } from 'react-native-device-info';

// eslint-disable-next-line no-restricted-imports
export * from 'react-native-device-info';

let cachedVersion: string | null = null;

// In iOS we get X.X.XXXX.7.0.2629895
// In Android we get 7.0.2629895.XXXX`
export const getReadableVersion = () => {
  if (cachedVersion) {
    return cachedVersion;
  }

  let readableVersion = getReadableVersionInternal();
  const parts = readableVersion.split('.');

  if (parts.length > 3) {
    if (Platform.OS === 'ios') {
      readableVersion = parts.slice(-3).join('.');
    } else if (Platform.OS === 'android') {
      readableVersion = parts.slice(0, 3).join('.');
    }
  }

  cachedVersion = readableVersion;
  return cachedVersion;
};
