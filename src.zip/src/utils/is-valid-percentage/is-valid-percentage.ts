export const isValidPercentage = (percentage: string): boolean => {
  return /^(?:[1-9]\d?$|^100)$/.test(percentage);
};
