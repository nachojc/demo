import { getLogger } from '@interfaces/logger';
import { config } from '@src/common/config';

const log = getLogger('API/AccessDefinition');

export const accessDefinitionMap = [
  ['direct.dev-aviva', 'UKDCP_DEV_2'],
  ['direct.rwy-aviva', 'UKDCP_SIT_2'],
  ['direct1.rwy-aviva', 'UKDCP_SIT_2'],
  ['direct2.rwy-aviva', 'UKDCP_UAT_2'],
  ['direct3.rwy-aviva', 'UKDCP_UAT_2'],
  ['direct.stg-aviva', 'UKDCP_UAT_2'],
  ['direct.pre-aviva', 'UKDCP_PPD_2'],
  ['direct-commissioning', 'UKDCP_PRD_2'],
  ['direct.aviva', 'UKDCP_PRD_2'],
] as const;

type AccessDefinitionMap = (typeof accessDefinitionMap)[number];
type AccessDefinition<T extends AccessDefinitionMap = AccessDefinitionMap> = {
  urls: T[0];
  values: T[1];
};

/**
 * @param {string} url - The BASE_URL, should contain a substring of: {@link AccessDefinitionBaseUrls}.
 *
 * @description
 * Access Definition will change depending on BASE_URL.
 * Environment will change for each BASE_URL
 * eSec advised that this may also be affected by UserType (e.g. guest, enquirer, DPA2)
 * However this doesn't appear to be implemented in Xamarin and is therefore omitted here
 */
export const getAccessDefinition = (
  url: string = config.BASE_URL.get()
): AccessDefinition['values'] => {
  const accessDef = config.OAUTH_ACCESS_DEFINITION.get();
  const matchingDef = accessDefinitionMap.find(
    ([_, value]) => value === accessDef
  );

  // If we have a matching access def, return that without matching against URL
  if (typeof matchingDef !== 'undefined') {
    return matchingDef[1];
  }

  const res = accessDefinitionMap.find(([urlEnvironment]) =>
    url.includes(urlEnvironment)
  );

  if (typeof res === 'undefined') {
    log.warn(
      `${getAccessDefinition.name} Unknown accessDefinition for URL: ${url}`
    );
    return 'UKDCP_PRD_2';
  }

  return res[1];
};
