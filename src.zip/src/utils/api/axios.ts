import { OpenAPI } from '@api/requests/core/OpenAPI';
import { config } from '@config';
import { accessToken, TIMEOUT, TIMEOUT_ERROR } from '@src/utils/api/constants';
import * as Interceptors from '@src/utils/api/interceptors';
import { isDev } from '@src/utils/is-dev';
// eslint-disable-next-line no-restricted-imports
import Axios, { AxiosInstance, CreateAxiosDefaults } from 'axios';

import {
  getAuthorizationHeader,
  headers,
  setHeadersOnAxiosInstance,
} from './headers';

const BASE_URL_DEV = 'https://www.direct.dev-aviva.co.uk';

/**
 * @summary
 * Factory function allows for creating instance of axios without the interceptors, primarily used for testing
 */
export const createAxiosInstance = (
  options: CreateAxiosDefaults = {}
): AxiosInstance => {
  return Axios.create({
    baseURL: config.BASE_URL.get(),
    headers: headers.get(),
    timeout: TIMEOUT,
    timeoutErrorMessage: TIMEOUT_ERROR,
    ...options,
  });
};

/**
 * @summary
 * App wide axios instance, for interfacing with MobileApi
 *
 * @description
 * Used within models, react-query and OpenApi generated hooks
 *
 * If the user has gone through login, then each
 * request will have an Authorization header attached
 */
export let axios = attachListeners(createAxiosInstance());

/**
 * @summary
 * Registers the interceptors. This will dynamically register interceptors
 * based on the environment and the configuration of the app.
 */
export const registerInterceptors = () => {
  const attachWiremock =
    config.BASE_URL.get().includes(BASE_URL_DEV) && config.IS_MOCK_BUILD.get();
  // We need to make sure we remove any existing interceptors before adding new ones
  axios = attachListeners(createAxiosInstance());
  Interceptors.register(axios, [
    isDev() ? Interceptors.apiLoggerInterceptor : null,
    Interceptors.rerouteEsecInterceptor,
    Interceptors.analyticsInterceptor,
    attachWiremock ? Interceptors.wiremockInterceptor : null,
  ]);
};

export const getCancelSource = () => Axios.CancelToken.source();

/**
 * @summary
 * Synchronises the values of {@link accessToken} & {@link headers } into the
 * instance of {@link axios } for authentication, and {@link OpenAPI } for code generation
 *
 * @author Kieran Osgood
 * @date 15/02/2024
 */
export function attachListeners(_axios: AxiosInstance): AxiosInstance {
  accessToken.onChange(({ value }) => {
    /**
     * This will trigger headers.onChange
     * updating the axios instance with latest headers
     */
    headers.Authorization.set(getAuthorizationHeader(value));
  });
  headers.onChange(setHeadersOnAxiosInstance(_axios));

  /**
   * TODO: Check whether this just wants to be placed within the accessToken.onChange
   */
  OpenAPI.TOKEN = async () => {
    return accessToken.get() ?? '';
  };
  OpenAPI.BASE = `${config.BASE_URL.get()}/MessagingApi`;

  /**
   * Synchronises the axios instance with the values from config
   * As Dev mode can change this value
   */
  config.BASE_URL.onChange(({ value }) => {
    OpenAPI.BASE = `${value}/MessagingApi`;
    _axios.defaults.baseURL = value;
  });

  return _axios;
}
