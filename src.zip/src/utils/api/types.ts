import { AxiosError } from 'axios';

type AxiosErrorData = {
  errorMessage?: string;
  errorCode?: string;
  responseCode?: string;
  responseMessage?: string;
  message?: string;
  response?: { data: { message: string } };
};

export type AxiosApiError = AxiosError<AxiosErrorData, unknown>;
