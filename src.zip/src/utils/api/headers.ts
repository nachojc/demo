import { getAppID } from '@hooks/use-expo-config';
import { observable } from '@legendapp/state';
import { accessToken } from '@src/utils/api/constants';
import { AxiosInstance, RawAxiosRequestHeaders } from 'axios';
import { Platform } from 'react-native';

import {
  getManufacturerSync,
  getModel,
  getReadableVersion,
} from '../device-info';

export type Headers = RawAxiosRequestHeaders;

// eslint-disable-next-line @typescript-eslint/no-unused-vars
type Axios = typeof import('./axios');
/**
 * @summary
 * Map of HTTP headers, including Authorization and Device specs
 *
 * @description
 * These are dynamically applied to the {@link Axios.axios Axios} instance
 * on every request, see {@link Axios.attachListeners attachListeners} for
 * listener
 *
 * @see {@link Axios.axios axios.ts}
 */
export const headers = observable({
  'X-Device-Manufacturer': getManufacturerSync(),
  'X-Device-Model': getModel(),
  'X-OS-Version': Platform.Version,
  'X-App-Name': getAppID(),
  'X-OS-Platform': Platform.OS === 'ios' ? 'iOS' : 'Android',
  'X-App-Version': getReadableVersion(),
  'Content-Type': 'application/json',
  'Cache-Control': 'no-store', // Stops URLSession from keeping a copy of all responses on the filesystem
  Authorization: getAuthorizationHeader(null),
} satisfies Headers);

/**
 * @description
 * Formats the provided token into the Bearer format, or uses the accessToken
 * observable if null provided
 *
 * @date 12/02/2024
 * @param token - defaults to {@link accessToken}
 */
export function getAuthorizationHeader(token: string | null) {
  const _token = token ?? accessToken.get();

  if (!_token) {
    return null;
  }

  return `Bearer ${_token}`;
}

export type HeadersChangeEvent = { value: Headers };
/**
 * @summary
 * Synchronises the headers from an event into the axios instance provided
 *
 * @description
 * Listener attached to the {@link headers} observable within {@link Axios.attachListeners attachListeners}
 * during the creation of the {@link Axios.axios axios } instance.
 *
 * Merges the instance headers with the observable values
 * (observable properties take precendence over existing conflicting keys)
 *
 * @see {@link Axios.axios axios.ts}
 */
export const setHeadersOnAxiosInstance =
  (axios: AxiosInstance) => (event: HeadersChangeEvent) => {
    axios.defaults.headers.common = {
      ...axios.defaults.headers.common,
      ...event.value,
    };
  };
