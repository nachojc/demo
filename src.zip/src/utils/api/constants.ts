import { observable } from '@legendapp/state';

export const accessToken = observable<string | null>(null);

export const TIMEOUT = 30000;
export const TIMEOUT_ERROR = 'Request timed out';

const esecApiPaths = [
  '/oauthaccess',
  '/avivasecuritysearchservice',
  '/avivasecurityapi',
  '/avivasecurityauthservice', // revoke token
  '/avivasecurityaccountservice',
];

const esecStagingDomains = [
  'direct2.rwy-aviva.co.uk',
  'direct3.rwy-aviva.co.uk',
];

export const isEsecApi = (url: string) =>
  esecApiPaths.some((s) => url.includes(s));

export const isEsecStagingDomain = (url: string) =>
  esecStagingDomains.some((ending) => url.includes(ending));

export const shouldRerouteUrl = (url: string) =>
  isEsecApi(url) && isEsecStagingDomain(url);
