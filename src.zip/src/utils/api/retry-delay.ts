export const POLICY_RETRY_COUNT = 3;

export const policyRetryDelay = (retryCount: number) => (retryCount + 1) * 5000;
