import { CommonBeneficiary } from '@src/navigation/types';

import { formatCurrencyValue } from '../format-currency-value';

export const formatPensionFunds = (
  value: number | null,
  leadingPlus?: true | undefined
) => {
  if (value == null) {
    return value;
  }

  const valuePrefix = leadingPlus && value >= 0 ? '+' : '';

  const formattedValue = formatCurrencyValue(value);

  return `${valuePrefix}${formattedValue}`;
};

export const formatPostalAddress = (
  postalAddress: NonNullable<CommonBeneficiary['postalAddress']>
) => {
  const addressArray = Object.values(postalAddress);
  const uniqAddressValues = [...new Set(addressArray)];
  const filterAddressValues = uniqAddressValues.filter(
    (element) => typeof element !== 'boolean' && element && element !== '-'
  );

  return filterAddressValues.join(', ');
};
