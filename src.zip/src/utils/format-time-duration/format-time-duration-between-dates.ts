import { UK_DATE_FORMAT } from '@constants/string-formats';
import { getLogger } from '@interfaces/logger';
import {
  differenceInDays,
  differenceInMonths,
  differenceInYears,
  formatDuration,
  parse,
} from 'date-fns';

const log = getLogger(formatTimeDurationBetweenDates.name);

/**
 * @description
 * Formats the time duration between 2 dates into a specified format
 *
 * @example
 * formatTimeDurationBetweenDates('21/11/2000','11/11/2020','yearsAndMonths') === '19 years 11 months';
 *
 * @param string startDate - the start date of the duration
 * @param string endDate - the end date of the duration
 * @param string format - the date fns format for the duration.
 **/
export function formatTimeDurationBetweenDates(
  startDate: string,
  endDate: string,
  format: 'yearsAndMonths' | 'days' | 'months' | 'years'
) {
  let parsedStartDate: Date;
  let parsedEndDate: Date;
  try {
    parsedStartDate = parse(startDate, UK_DATE_FORMAT, new Date());
    parsedEndDate = parse(endDate, UK_DATE_FORMAT, new Date());
  } catch (error) {
    log.error(
      new Error(
        `Date string is incorrect, should be in dd/MM/yyyy format: ${error}`,
        { cause: error }
      )
    );
    return;
  }
  switch (format) {
    case 'days':
      return formatDuration(
        {
          days: differenceInDays(parsedEndDate, parsedStartDate),
        },
        { format: ['days'] }
      );
    case 'months':
      return formatDuration(
        {
          months: differenceInMonths(parsedEndDate, parsedStartDate),
        },
        { format: ['months'] }
      );
    case 'years':
      return formatDuration(
        {
          years: differenceInYears(parsedEndDate, parsedStartDate),
        },
        { format: ['years'] }
      );
    case 'yearsAndMonths': {
      const durationInMonths = differenceInMonths(
        parsedEndDate,
        parsedStartDate
      );

      return formatDuration(
        {
          years: Math.floor(durationInMonths / 12),
          months: durationInMonths % 12,
        },
        { format: ['years', 'months'] }
      );
    }
    default: {
      return;
    }
  }
}
