import { PaymentFrequency } from '@src/common/types/payment-frequency';

const frequencyText = {
  halfYearly: 'half yearly',
  fourWeekly: 'four weekly',
};

/**
 * @description
 * a constants which is mapping the frequencytype correctly with it's number
 * on motor, paymentfrequency comes back as a text like Yearly, but on pension it is number, like 5
 */
export const FrequencyType: { [key: string]: PaymentFrequency } = {
  Unknown: 0,
  Monthly: 1,
  Quarterly: 2,
  Termly: 3,
  HalfYearly: 4,
  Yearly: 5,
  LunarMonthly: 6,
  BiAnnually: 7,
  Fortnightly: 8,
  Weekly: 9,
};

/**
 * @description
 * Converts frequency type which is coming back from api as a number string
 *
 * @example
 * frequency:
 * 0
 */
export const convertFrequency = (frequency?: PaymentFrequency): string => {
  if (frequency === undefined || frequency === FrequencyType.Unknown) {
    return '';
  } else if (frequency === FrequencyType.HalfYearly) {
    return frequencyText.halfYearly;
  } else if (frequency === FrequencyType.LunarMonthly) {
    return frequencyText.fourWeekly;
  } else {
    return (
      Object.keys(FrequencyType)
        .find((key) => FrequencyType[key] === frequency)
        ?.toString()
        .toLowerCase() ?? ''
    );
  }
};
