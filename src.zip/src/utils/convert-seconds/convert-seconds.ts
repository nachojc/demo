export const convertSeconds = (durationSeconds: number) => {
  const seconds = durationSeconds % 60;
  const minutes = ((durationSeconds - seconds) % 3600) / 60;
  const hours = (durationSeconds - minutes * 60 - seconds) / 3600;

  return {
    hours,
    minutes,
    seconds,
  };
};
