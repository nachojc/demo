export const USDateFormat = (UKDate: string) => {
  const [day, month, year] = UKDate.split('/');
  return month + '/' + day + '/' + year;
};
