import { format, subYears } from 'date-fns';

export const formatDateAYearAgo = () => {
  const date = new Date();
  const dateAYearAgo = subYears(date, 1);
  const formattedDateYearAgo = format(dateAYearAgo, 'yyyy-MM-dd');

  return formattedDateYearAgo;
};
