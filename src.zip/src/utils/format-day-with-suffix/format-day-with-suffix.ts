export const formatDayWithSuffix = function (day: string) {
  const d = Number(day);
  if (d > 3 && d < 21) {
    return `${d}TH`;
  }
  switch (d % 10) {
    case 1:
      return `${d}ST`;
    case 2:
      return `${d}ND`;
    case 3:
      return `${d}RD`;
    default:
      return `${d}TH`;
  }
};
