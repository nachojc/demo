/**
 * @description
 * Formats a raw number value returning a string
 * to 2 decimal places with a trailing % sign.
 *
 * @example
 * formatPercentageValue(1) === '1.00%'
 * @params  value: number | null  the actual value
 * @params decimalPlace : The number of digits to appear after the decimal point; should be a value between 0 and 100, inclusive.
 */

export const formatPercentageValue = (
  value: number | null,
  decimalPlace: number
) => {
  if (value == null) {
    return value;
  }
  return `${value.toFixed(decimalPlace)}%`;
};
