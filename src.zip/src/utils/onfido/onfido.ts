import { OnfidoError } from '@onfido/react-native-sdk';

export const isUserExit = (error: OnfidoError) => {
  return (
    Object.hasOwn(error, 'code') &&
    (error.code === 'userExit' || error.code === 'USER_LEFT_ACTIVITY')
  );
};
