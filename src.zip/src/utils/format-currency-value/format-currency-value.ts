/**
 * @description
 * Formats a raw number value returning a string
 * with leading £ sign defaults to 2 decimal places.
 *
 * * @example
 * formatCurrencyValue(12345) === £12,345.00
 * formatCurrencyValue(12345, 0) === £12,345
 * formatCurrencyValue(-12345) === -£12,345
 */
export const formatCurrencyValue = (
  value: number | string,
  fractionalDigits = 2
) => {
  const num = Number(value);
  const formattedNum = num
    .toFixed(fractionalDigits)
    .replace(/\B(?=(\d{3})+(?!\d))/g, ',');

  if (num < 0) {
    return `-£${formattedNum.slice(1)}`;
  }
  return `£${formattedNum}`;
};
