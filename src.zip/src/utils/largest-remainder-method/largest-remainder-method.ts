export const largestRemainderMethod = (arr: number[], desiredTotal: number) => {
  const sortedArray = arr
    .map((number, index) => {
      const numFloor = Math.floor(number);
      return {
        floor: numFloor,
        remainder: number - numFloor,
        index,
      };
    })
    .sort((a, b) => b.remainder - a.remainder);

  const floorTotal = sortedArray.reduce((a, b) => a + b.floor, 0);

  if (sortedArray.length > 0) {
    for (let i = 0; i < desiredTotal - floorTotal; i++) {
      sortedArray[i].floor++;
    }
  }

  return [...sortedArray]
    .sort((a, b) => a.index - b.index)
    .map((item) => item.floor);
};
