export const convertToKebabCase = (str: string | undefined | null) => {
  if (str === null || str === undefined) {
    return '';
  }

  return str
    .replace(/([a-z])([A-Z])/g, '$1-$2')
    .replace(/[\s_]+/g, '-')
    .toLowerCase();
};

export const toKebabCaseWithoutSpecialCharecter = (
  str: string | undefined | null
) => {
  if (str === null || str === undefined) {
    return '';
  }

  return str
    .toLowerCase()
    .replace(/[^a-z0-9 ]/g, '')
    .replace(/[\s_]+/g, '-')
    .replace(/-$/, '');
};
