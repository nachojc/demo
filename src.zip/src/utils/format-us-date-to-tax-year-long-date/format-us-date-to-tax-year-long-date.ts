import { UK_DATE_FORMAT } from '@constants/string-formats';
import { format, parse } from 'date-fns';

export const formatUsDateToTaxYearLongDate = (
  USDate: string,
  formatString = 'MMMM do yyyy'
) => {
  try {
    const date = parse(USDate, 'yyyy-MM-dd', new Date());
    return format(date, formatString);
  } catch {
    return '';
  }
};

export const formatDateToFormat = (
  dateString: string,
  toFormat: string,
  fromFormat = UK_DATE_FORMAT
) => {
  try {
    const date = parse(dateString, fromFormat, new Date());
    return format(date, toFormat);
  } catch {
    return '';
  }
};
