/**
 * @description
 * Formats a url to it's root
 *
 * @example
 * https://www.gov.uk/find-a-job => gov.uk
 */

export const formatURL = (url: string) => {
  const regex =
    /([A-Za-z0-9-]+\.([A-Za-z]{3,}|[A-Za-z]{2}\.[A-Za-z]{2}|[A-Za-z]{2}))(?!\.([A-Za-z]{3,}|[A-Za-z]{2}\.[A-Za-z]{2}|[A-Za-z]{2}))\b/;
  const match = url.match(regex) ?? '';
  const avivaLink = url.includes('aviva.co.uk');

  if (avivaLink) {
    return 'aviva.co.uk';
  } else {
    return match[0];
  }
};
