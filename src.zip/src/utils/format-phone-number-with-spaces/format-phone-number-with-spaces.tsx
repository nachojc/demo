/**
 * Used to format a phone number with spacing, this takes a phone number as a sting
 * and an optional pattern that is a string of hashtags in the pattern required.
 *
 * Example: formatPhoneNumberWithSpaces('08001111111') would be show as 0800 111 1111
 * Example: formatPhoneNumberWithSpaces('08001111111', '## ### ### ###') would be show as 08 001 111 111
 */
export function formatPhoneNumberWithSpaces(
  phoneNumber: string,
  pattern = '#### ### ####'
) {
  let i = 0;
  return pattern.replace(/#/g, (_) => phoneNumber[i++]);
}
