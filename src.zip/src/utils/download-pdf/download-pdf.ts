import { trackApiAnalyticsSinglePdf } from '@hooks/use-service-analytics';
import { getLogger } from '@logger';
import MockPdfJson from '@src/api-mock/responses/Document/pdf-base64.json';
import { PdfSource } from '@utils/download-pdf/pdf-source';
import { userCacheDir } from '@utils/user-files';
import ReactNativeBlobUtil, {
  FetchBlobResponse,
  StatefulPromise,
} from 'react-native-blob-util';

export class NetworkError extends Error {
  readonly status: number | null;
  readonly timeout: boolean;
  constructor({
    status,
    timeout,
  }: {
    status: number | null;
    timeout: boolean;
  }) {
    super(`[NetworkError] status: ${status}, timeout: ${timeout}`);
    this.status = status;
    this.timeout = timeout;
  }
}

export abstract class BasePdfDownloader {
  protected isCancelled = false;
  static readonly cancelError: Readonly<Error> = new Error('cancel');

  constructor(
    private readonly options: {
      pdfSource: PdfSource;
      fileName: string;
    }
  ) {}

  async download() {
    const { pdfSource, fileName } = this.options;
    const formattedFileName = fileName.replaceAll(' ', '_');
    const cacheDir = userCacheDir();
    const path = `${cacheDir}/${formattedFileName}.pdf`;

    await ReactNativeBlobUtil.fs.mkdir(cacheDir).catch(() => {
      /* ignoring because throws when directory already exists */
    });
    if (this.isCancelled) {
      throw BasePdfDownloader.cancelError;
    }
    await this.loadPdf({ path, pdfSource });
    return `file://${path}`;
  }

  protected abstract loadPdf({
    path,
    pdfSource,
  }: {
    path: string;
    pdfSource: PdfSource;
  }): Promise<void>;

  cancel() {
    this.isCancelled = true;
  }
}

export class NetworkPdfDownloader extends BasePdfDownloader {
  private downloadPromise: StatefulPromise<FetchBlobResponse> | null = null;

  protected async loadPdf({
    path,
    pdfSource,
  }: {
    path: string;
    pdfSource: PdfSource;
  }): Promise<void> {
    this.downloadPromise = ReactNativeBlobUtil.config({ path }).fetch(
      'GET',
      pdfSource.url,
      pdfSource.headers ?? {}
    );

    const response = await this.downloadPromise.catch((error) => {
      if (error instanceof Error && error.message.includes('timed out')) {
        trackApiAnalyticsSinglePdf({
          status: 408,
          url: pdfSource.url,
          timeout: true,
        });
        throw new NetworkError({ status: 408, timeout: true });
      }
      trackApiAnalyticsSinglePdf({
        status: error.status,
        url: pdfSource.url,
        timeout: false,
      });
      throw error;
    });

    if (response.respInfo.status >= 400 || response.respInfo.timeout) {
      trackApiAnalyticsSinglePdf({
        url: pdfSource.url,
        status: response.respInfo.status,
        timeout: response.respInfo.timeout,
      });
      throw new NetworkError({ ...response.respInfo });
    }

    trackApiAnalyticsSinglePdf({
      url: pdfSource.url,
      status: 200,
      timeout: false,
    });
  }

  override cancel() {
    super.cancel();
    this.downloadPromise?.cancel();
  }
}

export class MswPdfDownloader extends BasePdfDownloader {
  log = getLogger(MswPdfDownloader.name);

  protected async loadPdf({
    path,
    pdfSource,
  }: {
    path: string;
    pdfSource: PdfSource;
  }): Promise<void> {
    if (pdfSource.url.endsWith('document')) {
      await this.writeMockPdf({ path });
    } else if (pdfSource.url.endsWith('delay')) {
      await new Promise((resolve, reject) => {
        setTimeout(() => {
          this.writeMockPdf({ path }).then(resolve).catch(reject);
        }, 3000);
      });
    } else if (pdfSource.url.endsWith('error')) {
      throw new NetworkError({ status: 404, timeout: false });
    } else {
      this.log.warn(
        'Unknown document id for mock service worker',
        pdfSource.url
      );
      await this.writeMockPdf({ path });
    }
  }

  private async writeMockPdf({ path }: { path: string }) {
    await ReactNativeBlobUtil.fs.writeFile(path, MockPdfJson.base64, 'base64');
  }
}
