import { config } from '@config';
import { accessToken } from '@src/utils/api/constants';

export type PdfSource = {
  url: string;
  headers?: { [key: string]: string };
};

export const PdfSourceFactory = {
  fromDocumentId: (documentId: string): PdfSource => ({
    url: `${baseUrl()}/MessagingApi/api/v1/document/${documentId}`,
    headers: authHeaders(),
  }),
  fromIsaDocumentId: (encryptedDocumentId: string): PdfSource => ({
    url: `${baseUrl()}/MessagingApi/api/v1/directWealth/isaDocument/${encryptedDocumentId}`,
    headers: authHeaders(),
  }),
  fromIllustrationEncryptedTransferId: (
    encryptedTransferId: string
  ): PdfSource => ({
    url: `${baseUrl()}/MessagingApi/api/v1/directWealth/illustration/${encryptedTransferId}`,
    headers: authHeaders(),
  }),
};

const baseUrl = () => config.BASE_URL.get();

const authHeaders = () => ({
  Authorization: `Bearer ${accessToken.get()}`,
  Accept: '*/*',
});
