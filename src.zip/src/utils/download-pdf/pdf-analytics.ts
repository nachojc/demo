import { getLogger } from '@logger';
import NetInfo from '@react-native-community/netinfo';
import { NetworkError } from '@src/utils';

const log = getLogger('pdf-analytics');

export type PdfAnalytics = {
  appBase: string;
  serviceNameTags: string[];
  successTagSuffix: string;
  errorTagSuffix: string;
};

export const makePdfAnalytics = (serviceNameTag: string, ...tags: string[]) => {
  return {
    appBase: 'ukmyaviva',
    serviceNameTags: [serviceNameTag, ...tags],
    errorTagSuffix: 'service-error',
    successTagSuffix: 'success',
  } satisfies PdfAnalytics;
};

export const makePdfAnalyticsSuccessState = ({
  appBase,
  serviceNameTags,
  successTagSuffix,
}: PdfAnalytics) => [appBase, ...serviceNameTags, successTagSuffix].join('|');

export const makePdfAnalyticsErrorState = ({
  appBase,
  serviceNameTags,
  errorTagSuffix,
}: PdfAnalytics) => [appBase, ...serviceNameTags, errorTagSuffix].join('|');

export const makePdfAnalyticsErrorContext = async (
  error: unknown,
  { appBase, serviceNameTags, errorTagSuffix }: PdfAnalytics
): Promise<Record<string, string>> => {
  if (!error) {
    log.error(new Error('Expected an error to be passed'));
    return {};
  }
  return {
    pageError: [
      appBase,
      ...serviceNameTags,
      errorTagSuffix,
      await getErrorTag(error),
    ].join('|'),
  };
};

const getErrorTag = async (error: unknown) => {
  if (error instanceof NetworkError) {
    if (error.timeout) {
      return 'timeout';
    } else if (error.status === 404) {
      return 'not-found';
    } else if (error.status === 500) {
      return 'invalid-server-error';
    }
  }
  const { isConnected } = await NetInfo.fetch();
  if (!isConnected) {
    return 'unknown-connection-error';
  }
  return 'invalid-server-response';
};
