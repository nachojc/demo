import {
  CryptoDigestAlgorithm,
  CryptoEncoding,
  digestStringAsync,
} from 'expo-crypto';

export const getSHA256Hash = async (data: string) =>
  digestStringAsync(CryptoDigestAlgorithm.SHA256, data, {
    encoding: CryptoEncoding.BASE64,
  });
