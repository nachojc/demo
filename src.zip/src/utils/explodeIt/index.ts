/**
 *
 * @param explodeIn string
 * @param toExplode string
 * @returns string
 * @description it looks for the `toExplode` and explode it by inserting space
 * then returns the new version of the `explodeIn` where the `toExplode` could be there
 * otherwise just return the explodeIn as is
 *
 * this allows the reader reading policy number as 1 2 3 4 5 instead of twelve thousand three hundred fourty five
 */

export const explodeIt = (toExplode: string, explodeIn: string) =>
  explodeIn.replace(
    new RegExp(toExplode.split('').join('\\s*'), 'gi'),
    (match) => match.split('').join(' ')
  );
