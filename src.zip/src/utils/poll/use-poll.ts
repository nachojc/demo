import { useEffect, useRef, useState } from 'react';

import { poll, PollArguments } from './poll';

type UsePollArguments = {
  condition: boolean;
  timeout: number;
} & Pick<PollArguments, 'act' | 'frequency'>;

export const usePoll = (args: UsePollArguments) => {
  const [isTimedOut, setIsTimedOut] = useState(false);
  const refetch = () => {
    setIsTimedOut(false);
    poll(propsRef.current);
  };
  const propsRef = useRef({ ...args, onTimeout: () => setIsTimedOut(true) });
  propsRef.current.act = args.act;
  propsRef.current.frequency = args.frequency;
  propsRef.current.timeout = args.timeout;

  useEffect(() => {
    if (!args.condition) {
      return;
    }
    setIsTimedOut(false);
    const { cancel } = poll(propsRef.current);

    return cancel;
  }, [args.condition]);

  return { isTimedOut, refetch };
};
