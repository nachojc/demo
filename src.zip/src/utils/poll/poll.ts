export type PollArguments = {
  act: () => Promise<unknown>;
  frequency: number;
  timeout: number;
  onTimeout: () => void;
};

export const poll = ({ act, frequency, timeout, onTimeout }: PollArguments) => {
  const startTime = Date.now();
  let isCancelled = false;
  const doPoll = () => {
    setTimeout(async () => {
      if (isCancelled) {
        return;
      }
      if (Date.now() - startTime > timeout) {
        onTimeout();
        return;
      }
      await act();
      doPoll();
    }, frequency);
  };
  doPoll();

  return {
    cancel: () => {
      isCancelled = true;
    },
  };
};
