export const ellipsing = (originalText: string, ellipsingAfter: number) => {
  return originalText.length > ellipsingAfter
    ? originalText.slice(0, ellipsingAfter) + '…'
    : originalText;
};
