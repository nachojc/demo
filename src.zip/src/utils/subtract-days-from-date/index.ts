import { UK_DATE_FORMAT } from '@constants/string-formats';
import { format, parse, subDays } from 'date-fns';

export const subtractDaysFromDate = (dateString = '', daysToSubtract = 1) => {
  const dateFormatRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  if (!dateFormatRegex.test(dateString)) {
    console.log(
      'Invalid date format. Please provide the date in the format "dd/MM/yyyy"'
    );
    return '';
  }

  try {
    const date = parse(dateString, UK_DATE_FORMAT, new Date());
    const newDate = subDays(date, daysToSubtract);
    return format(newDate, UK_DATE_FORMAT);
  } catch {
    console.log(
      'Operation failed. Make sure to provide a correct format "dd/MM/yyyy"'
    );
    return '';
  }
};
