/**
 * exhaustive
 *
 * This function should be called as the default case in any switch statement
 * over enums that should not have a default fallback.
 * See https://www.typescriptlang.org/docs/handbook/advanced-types.html#exhaustiveness-checking
 *
 */
export function exhaustive(x: never): never {
  throw new TypeError(
    `Failed exhaustiveness check: Missing case for "${JSON.stringify(x)}".`
  );
}
