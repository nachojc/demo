/**
 * Distributes elements of an array into a given number of chunks
 * @param {Array} array - the array to be chunked
 * @param {number} numChunks - the target number of chunks
 * @returns {Array<Array>} An array containing the distributed chunks
 * @example
 * // Example usage:
 * const array = [1, 2, 3, 4, 5, 6, 7, 8, 9];
 * const targetChunks = 3;
 * const results = distributedChunks(array, targetChunks);
 * console.log(result) // [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
 */
export function distributedChunks<T>(array: T[], numChunks: number): T[][] {
  const result: T[][] = Array.from({ length: numChunks }, () => []);
  for (let i = 0; i < array.length; i++) {
    const chunkIndex = i % numChunks;
    result[chunkIndex].push(array[i]);
  }
  return result;
}
