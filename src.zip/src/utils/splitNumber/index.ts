/**
 * @description
 * created for accessibility label reading XX122 as XX one hundred twenty two
 * this function splits the numbers within the input so it can be read as XX 1 2 2
 *
 * @param input string
 * @returns string
 */

export const splitNumbers = (input: string) => {
  return input.replace(/\d/g, '$& ').trim();
};
