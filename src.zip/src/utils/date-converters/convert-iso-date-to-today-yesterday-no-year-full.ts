// Rules:
// - date is returned as DD Mon YYYY (no 1st, no 2nd, month name in 3 letters (Oct, not October), days with 0 prefix (01, 02, ... ,09, 10)
// - for current year we are not showing year (01 Jan)
// - for Today (same date) - "Today" instead of the date
// - for Yesterday - "Yesterday" instead of the date

import { format } from 'date-fns';
import { enGB } from 'date-fns/locale';

const ddMonYYYYOptions = 'dd MMM yyyy';

const ddMonOptions = 'dd MMM';

export const convertISODateToTodayYesterdayNoYearFull = (
  inputDate: string,
  todayDate?: Date | undefined
) => {
  todayDate = todayDate ?? new Date();

  const paymentDate = new Date(inputDate);
  const yesterdayDate = new Date(todayDate);
  yesterdayDate.setDate(yesterdayDate.getDate() - 1);

  const paymentDateStr = format(paymentDate, ddMonYYYYOptions, {
    locale: enGB,
  });
  const todayDateStr = format(todayDate, ddMonYYYYOptions, {
    locale: enGB,
  });
  const yesterdayDateStr = format(yesterdayDate, ddMonYYYYOptions, {
    locale: enGB,
  });
  const paymentDateShortStr = format(paymentDate, ddMonOptions, {
    locale: enGB,
  });

  const sameYear = paymentDate.getFullYear() === todayDate.getFullYear();

  if (paymentDateStr === todayDateStr) {
    return 'Today';
  } else if (paymentDateStr === yesterdayDateStr) {
    return 'Yesterday';
  } else if (sameYear) {
    return paymentDateShortStr;
  } else {
    return paymentDateStr;
  }
};
