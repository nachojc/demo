export const convertISODateToDotFormat = (date: string) => {
  const values = date.split('-');
  return `${values[2]}.${values[1]}.${values[0]}`;
};
