// Converts DD/MM/YYYY to YYYY-MM-DD
export const convertGBDateToISO = (date: string) =>
  date.split('/').reverse().join('-');
