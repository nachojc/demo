/**
 * @description
 * Converts YYYY-MM-DD to DD MONTH YYYY or DD Month YYYY
 *
 * @example
 * 2000-01-08 => 08 January 2000 when capitalize
 * 2000-01-08 => 08 JANUARY 2000 when uppercase
 */
export const convertISODateToLongFormat = (
  inputDate: string,
  textTransform?: 'uppercase' | 'capitalize'
) => {
  const longFormatDate = new Date(inputDate).toLocaleString('en-GB', {
    year: 'numeric',
    month: 'long',
    day: '2-digit',
  });

  switch (textTransform) {
    case 'uppercase':
      return longFormatDate.toUpperCase();
    case 'capitalize':
      return longFormatDate;
    default:
      return longFormatDate.toUpperCase();
  }
};
