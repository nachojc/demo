import {
  MONTH_YEAR_DASH_DATE_FORMAT,
  UK_DATE_FORMAT,
  UK_DATE_SHORT_FORMAT,
} from '@constants/string-formats';
import { format, parseISO } from 'date-fns';

type DateFormat =
  | typeof UK_DATE_SHORT_FORMAT
  | typeof MONTH_YEAR_DASH_DATE_FORMAT
  | typeof UK_DATE_FORMAT;

export const convertIsoDate = (
  isoDate: string,
  dateFormat: DateFormat
): string => {
  try {
    const dateObj = parseISO(isoDate);
    return format(dateObj, dateFormat);
  } catch (error) {
    return '';
  }
};
