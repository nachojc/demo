import { format } from 'date-fns';
import { enGB } from 'date-fns/locale';

export const convertISODateToShortMonthFormat = (inputDate: string) => {
  return format(new Date(inputDate), 'd MMM yyyy', {
    locale: enGB,
  });
};
