import * as Sharing from 'expo-sharing';
import ReactNativeBlobUtil from 'react-native-blob-util';

/**
 * Sharing external pdf or a base64 content uri
 * @param fileUrl - the file url of the pdf
 */
export const sharePdf = async (fileUrl: string): Promise<void> => {
  const fileProtocol = 'file://';
  if (!fileUrl.startsWith(fileProtocol)) {
    throw new Error("Expected a url starting with 'file://'");
  }

  const fileExists = await ReactNativeBlobUtil.fs.exists(
    fileUrl.slice(fileProtocol.length)
  );
  if (!fileExists) {
    throw new Error('PDF file does not exist');
  }

  const isAvailable = await Sharing.isAvailableAsync();
  if (!isAvailable) {
    throw new Error('Sharing is not available on this platform');
  }

  await Sharing.shareAsync(fileUrl, {
    UTI: 'com.adobe.pdf',
    mimeType: 'application/pdf',
  }).catch((err) => {
    throw new Error(err);
  });
};
