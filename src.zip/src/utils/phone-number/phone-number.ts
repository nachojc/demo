import { MobileNumber } from '@direct-wealth/features/isa-apply/navigation/provider/state/personal-details';
import { z } from 'zod';

// TODO: move other phone-number utils into here
export const maskPhoneNumber = (phoneNumber: string) =>
  z
    .string()
    .transform((num) => {
      // clean up the phone number, and then mask it all apart from the final 3 characters
      const trimmed = num.replace(/[\s+]/g, '');
      return trimmed.slice(trimmed.length - 3).padStart(trimmed.length, '*');
    })
    .parse(phoneNumber);

/**
 * @description
 * separate country code from phone number when country code is separated by space e.g. 44 07123 456 789 -> 07123 456 789.
 * Phone number can contain multiple spaces but country code must appear before the first space
 * \+?(\d{1,3})\s?                      matches an optional '+' followed by the country code
 * (0\d{9,}|0\d{2,}(\s?\d+)+|\d{9,})$   matches the local number
 *
 * @param input string
 * @returns string
 */
export const extractCountryCodeAndNumber = (
  phoneNumber: string
): MobileNumber => {
  const match = phoneNumber.match(
    /^\+?(\d{1,3})\s?(0\d{9,}|0\d{2,}(\s?\d+)+|\d{9,})$/
  );
  if (match) {
    return {
      number: match[2],
      code: '+' + match[1],
    };
  } else {
    return {
      number: phoneNumber,
    };
  }
};

/**
 * @description
 * created for phone number reading where callUs function is disabled and phone number is presented instead
 * this function splits the phone number so it can be read as XXXX XXX XXXX
 *
 * @param input string
 * @returns string
 */

export const splitPhoneNumber = (input: string) => {
  return input.replace(/(\d{4})(\d{3})(\d{4})/, '$1 $2 $3');
};
