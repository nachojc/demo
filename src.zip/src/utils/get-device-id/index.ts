export * from './get-device-id';
