import {
  getStoredDeviceId,
  getStoredTrustedDeviceId,
} from '@interfaces/secure-store';
import { produceDeviceId } from '@interfaces/storage';
import Base64 from 'crypto-js/enc-base64';
import sha256 from 'crypto-js/sha256';
// eslint-disable-next-line no-restricted-imports
import DeviceInfo from 'react-native-device-info';

const Sha256LengthMultiplier = 4;
const Sha256PaddingCharacter = '=';

export const getRiskId = async () =>
  (await getStoredTrustedDeviceId()) ?? (await DeviceInfo.getInstanceId());

export const getUniqueDeviceId = async () =>
  (await getStoredDeviceId()) ?? (await produceDeviceId());

// What's going on here? RFC7636 says that we should
// base64url((bytes)sha256(code_verifier))
// In our case, the code_verifier is the DUID
// base64url is similar to base64, with + and / swapped out
// and changes to the padding
// crypto-js 4.1.0 has a function for this, but breaks other stuff :(
export const getHashedDeviceId = async () => {
  let hashedString = sha256(await getUniqueDeviceId()).toString(Base64);

  hashedString = hashedString
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replaceAll('=', '');

  while (hashedString.length % Sha256LengthMultiplier !== 0) {
    hashedString = hashedString.padEnd(
      hashedString.length + 1,
      Sha256PaddingCharacter
    );
  }

  return hashedString;
};
