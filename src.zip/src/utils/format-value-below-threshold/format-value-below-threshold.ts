export const formatValueBelowThreshold = (
  value: number,
  threshold: number
): number | string => {
  return value < threshold ? `<${threshold}%` : value;
};
