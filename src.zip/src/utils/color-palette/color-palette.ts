import { tokens } from '@src/theme/tokens';

import { exhaustive } from '../exhaustive';

export type Palette = 'common' | 'tabs' | 'allTime' | '12months' | 'snapshot';

export const getPalette = (palette: Palette) => {
  switch (palette) {
    case 'common':
      return [
        tokens.color.Pension02.val,
        tokens.color.Pension08.val,
        tokens.color.Pension06.val,
        tokens.color.Pension07.val,
        tokens.color.Pension09.val,
        tokens.color.Pension04.val,
        tokens.color.Pension01.val,
        tokens.color.Pension05.val,
        tokens.color.Pension11.val,
        tokens.color.Pension03.val,
      ];
    case 'tabs':
      return [
        tokens.color.Pension12.val,
        tokens.color.Pension15.val,
        tokens.color.Pension13.val,
        tokens.color.Pension16.val,
        tokens.color.Pension14.val,
        tokens.color.Pension09.val,
      ];
    case 'allTime':
      return [
        tokens.color.Pension02.val,
        tokens.color.Pension08.val,
        tokens.color.Pension06.val,
        tokens.color.Pension07.val,
        tokens.color.Pension09.val,
        tokens.color.White.val,
      ];
    case '12months':
      return [
        tokens.color.Pension12.val,
        tokens.color.Pension15.val,
        tokens.color.Pension13.val,
        tokens.color.Pension16.val,
        tokens.color.Pension14.val,
        tokens.color.White.val,
      ];
    case 'snapshot':
      return [
        tokens.color.Pension12.val,
        tokens.color.Pension14.val,
        tokens.color.Pension04.val,
        tokens.color.Pension16.val,
        tokens.color.Pension13.val,
        tokens.color.Pension11.val,
        tokens.color.Pension15.val,
        tokens.color.Pension06.val,
        tokens.color.Pension10.val,
        tokens.color.RoseLight.val,
        tokens.color.Success.val,
        tokens.color.GoldDark.val,
        tokens.color.Pension01.val,
        tokens.color.Pension09.val,
        tokens.color.WarningTint.val,
        tokens.color.PlumMain.val,
        tokens.color.RedOnPlum.val,
      ];
    default:
      exhaustive(palette);
  }
};

export const getColor = (palette: Palette, i: number) => {
  return getPalette(palette)[i % getPalette(palette).length];
};
