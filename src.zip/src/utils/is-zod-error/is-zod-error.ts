import { ZodError } from 'zod';

export const isZodError = (error: unknown): error is typeof ZodError => {
  return error instanceof ZodError;
};
