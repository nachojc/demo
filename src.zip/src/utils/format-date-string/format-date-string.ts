import { UK_DATE_FORMAT } from '@constants/string-formats';
import { parse } from 'date-fns';

export const formatDateString = (date: string) =>
  parse(date, UK_DATE_FORMAT, new Date());
