const isNullOrUndefined = (value: unknown) =>
  value === undefined || value === null;

const isEmptyString = (value: string | undefined) =>
  value === null ||
  value === undefined ||
  (typeof value === 'string' && value.trim().length === 0);

export { isEmptyString, isNullOrUndefined };
