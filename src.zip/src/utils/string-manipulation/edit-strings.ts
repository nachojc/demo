import { convertToKebabCase } from '../convert-to-kebab-case';

const removeStringAddHyphens = (str: string, stringToRemove: string) =>
  convertToKebabCase(str).replace(stringToRemove, '');

const removeSpecialCharacters = (str: string) =>
  str.replace(/[^a-zA-Z0-9 ]/g, '');

const removeNonNumericValues = (str: string, precision: number) => {
  const numericOnly = str.replace(/[^\d.]+/g, '');

  return numericOnly.replace(
    new RegExp(`^(\\d+\\.\\d{${precision}})\\d*$`),
    '$1'
  );
};

const replaceSpacesWithDashesAndLowerCase = (str: string) =>
  str.replace(/\s+/g, '-').toLowerCase();

const removeLastChar = (str: string) => str.slice(0, -1);

const removeLeadingZeroNonNumericNonIntegerValues = (str: string) =>
  str.replace(/\b(0(?!\b))+|\.\d+|\D/g, '');

export {
  removeLastChar,
  removeLeadingZeroNonNumericNonIntegerValues,
  removeNonNumericValues,
  removeSpecialCharacters,
  removeStringAddHyphens,
  replaceSpacesWithDashesAndLowerCase,
};
