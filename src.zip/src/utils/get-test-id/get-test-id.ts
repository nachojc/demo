import { convertToKebabCase } from '../convert-to-kebab-case/convert-to-kebab-case';

export const getTestId = (testId: string, routeName?: string) => {
  return routeName
    ? `test:id/${convertToKebabCase(routeName + testId)}`
    : `test:id/${convertToKebabCase(testId)}`;
};
