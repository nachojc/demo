declare module '@appdynamics/react-native-agent' {
  function startTimer(): undefined;
  function stopTimer(): undefined;
  function reportError(): undefined;
  function leaveBreadcrumb(): undefined;
  function trackUIEvent(): undefined;

  const ErrorSeverityLevel = string;
  const BreadcrumbVisibility = string;
  const Instrumentation = string;
  const LoggingLevel = string;
}
