import { AvivaOnlineMotorProduct } from '@src/validation/schemas/product/motor/aviva-online-motor-product';
import { MotorProduct } from '@src/validation/schemas/product/motor/motor-product';

export type MotorPolicy = AvivaOnlineMotorProduct | MotorProduct;
