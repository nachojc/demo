declare module 'react-native-battery-optimization-check' {
  function BatteryOptEnabled(): Promise<boolean>;
  function RequestDisableOptimization(): undefined;
  function OpenOptimizationSettings(): undefined;
}
