import { setUpTests } from 'node_modules/react-native-reanimated/lib/module/reanimated2/jestUtils.js';

setUpTests();
