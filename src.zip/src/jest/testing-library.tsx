/* eslint-disable no-restricted-imports  */
import { IonMobileProvider } from '@src/common/providers/ion-mobile';
import { NavbarProvider } from '@src/common/providers/nav-control';
import { LaunchDarklyProvider } from '@src/common/providers/remote-flags';
import { i18n } from '@src/i18n/i18n';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  render,
  renderHook,
  RenderHookOptions,
  RenderOptions,
} from '@testing-library/react-native';
import { FunctionComponent, ReactElement, ReactNode } from 'react';
import { I18nextProvider } from 'react-i18next';
import { Dimensions } from 'react-native';

export const MockProviders = ({ children }: { children: ReactNode }) => {
  // These settings align with the current app setup
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
        cacheTime: Infinity,
        staleTime: Infinity,
      },
      mutations: {
        retry: false,
        cacheTime: Infinity,
      },
    },
    logger: {
      log: console.log,
      warn: console.warn,
      // eslint-disable-next-line @typescript-eslint/no-empty-function
      error: process.env.NODE_ENV === 'test' ? () => {} : console.error,
    },
  });
  return (
    <I18nextProvider i18n={i18n}>
      <QueryClientProvider client={queryClient}>
        <LaunchDarklyProvider connectionMode="offline">
          <IonMobileProvider>
            <NavbarProvider>{children}</NavbarProvider>
          </IonMobileProvider>
        </LaunchDarklyProvider>
      </QueryClientProvider>
    </I18nextProvider>
  );
};

const customRender = (component: ReactElement, options?: RenderOptions) =>
  render(component, {
    wrapper: MockProviders, // TODO: we may want to make this optional to avoid long test times
    ...options,
  });

const customRenderHook = <TProps, TResult>(
  callback: (props: TProps) => TResult,
  options?: RenderHookOptions<TProps>
) =>
  renderHook(callback, {
    wrapper: MockProviders as FunctionComponent<TProps>, // TODO: we may want to make this optional to avoid long test times
    ...options,
  });

export * from '@testing-library/react-native';
export { customRender as render, customRenderHook as renderHook };

export function createNavigationMock<T>(): T {
  return {
    state: { params: {} },
    dispatch: jest.fn(),
    goBack: jest.fn(),
    dismiss: jest.fn(),
    navigate: jest.fn(),
    openDrawer: jest.fn(),
    closeDrawer: jest.fn(),
    toggleDrawer: jest.fn(),
    getParam: jest.fn(),
    setParams: jest.fn(),
    addListener: jest.fn(),
    push: jest.fn(),
    replace: jest.fn(),
    reset: jest.fn(),
    pop: jest.fn(),
    popToTop: jest.fn(),
    isFocused: jest.fn(),
  } as T;
}

const { height } = Dimensions.get('window');
export const scrollSettings = {
  nativeEvent: {
    contentOffset: {
      y: height, // distance to scroll
    },
    contentSize: {
      // Dimensions of the scrollable content
      height,
    },
    layoutMeasurement: {
      // Dimensions of the device
      height,
    },
  },
};

export const mockTrackStateEvent = jest.fn();
export const mockTrackUserEvent = jest.fn();

jest.mock('@hooks/use-analytics', () => ({
  useAnalytics: () => ({
    trackUserEvent: mockTrackUserEvent,
    trackStateEvent: mockTrackStateEvent,
  }),
  useTrackStateEvent: (
    pageTag: string,
    contextData?: Record<string, string>
  ) => {
    if (contextData) {
      mockTrackStateEvent(pageTag, contextData);
    } else {
      mockTrackStateEvent(pageTag);
    }
  },
  useConditionalTrackStateEvent: (tag: string) => mockTrackStateEvent(tag),
}));

export const mockOnPageLoadEvent = jest.fn();

jest.mock('@hooks/use-on-page-load', () => ({
  useOnPageLoad: (
    tag: string,
    contextData: Record<string, string> | undefined,
    hideSurvey: boolean | undefined
  ) => {
    if (hideSurvey) {
      return mockOnPageLoadEvent(tag, contextData, hideSurvey);
    } else {
      contextData
        ? mockOnPageLoadEvent(tag, contextData)
        : mockOnPageLoadEvent(tag);
    }
  },
}));

export const mockUseSurvey = jest.fn();

jest.mock('@utils/qualtrics/use-survey', () => ({
  useSurvey: (tag: string, hideSurvey: boolean | undefined) =>
    hideSurvey ? mockUseSurvey(tag, hideSurvey) : mockUseSurvey(tag),
}));
