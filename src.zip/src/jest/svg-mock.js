import Svg from 'react-native-svg';

const SvgMock = (props) => <Svg {...props} />;

// eslint-disable-next-line import/no-default-export
export default SvgMock;
