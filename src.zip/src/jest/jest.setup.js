import '@testing-library/jest-native';
import 'react-native-gesture-handler/jestSetup';
import 'react-native-url-polyfill/auto';
import './jest-extensions';

import mockRNCNetInfo from '@react-native-community/netinfo/jest/netinfo-mock.js';
import { handlers } from '@src/api-mock/handlers';
import { resetMocks } from '@src/api-mock/helpers';
// eslint-disable-next-line no-restricted-imports
import { setupServer } from 'msw/node';
import {
  FlatList as MockFlatList,
  ScrollView as MockScrollView,
  Text as MockText,
  TextInput as MockTextInput,
  View as MockView,
} from 'react-native';
import mockRNDeviceInfo from 'react-native-device-info/jest/react-native-device-info-mock';
import mockRNPermissionsMock from 'react-native-permissions/mock';
import mockSafeAreaContext from 'react-native-safe-area-context/jest/mock';

import { mockConfig } from './config-mock';

export const server = setupServer(...handlers);

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'warn' });
});

beforeEach(() => {
  resetMocks();
});

afterAll(() => {
  server.resetHandlers();
  server.restoreHandlers();
  server.close();
});

// setUpTests();
//enableLegendStateReact();

jest.mock('react-native', () => {
  const RN = jest.requireActual('react-native');

  RN.NativeModules.SettingsManager = {
    settings: {
      AppleLocale: 'en-GB',
      AppleLanguages: ['en-GB'],
    },
  };
  return RN;
});

jest.mock('react-native/Libraries/Animated/NativeAnimatedHelper');
jest.mock('react-native/Libraries/EventEmitter/NativeEventEmitter');
jest.mock('react-native/Libraries/Animated/animations/TimingAnimation.js');
jest.mock(
  'react-native/Libraries/Components/Switch/SwitchNativeComponent.js',
  () => {
    const { View } = require('react-native');
    const { forwardRef } = require('react');
    const Switch = forwardRef((props, ref) => <View {...props} ref={ref} />);

    return { default: Switch, __esModule: true };
  }
);
jest.mock('react-native-device-info', () => mockRNDeviceInfo);
jest.mock('react-native-safe-area-context', () => mockSafeAreaContext);
jest.mock('@react-native-community/netinfo', () => mockRNCNetInfo);
jest.mock('react-native-permissions', () => mockRNPermissionsMock);
jest.mock('react-native-fusioncharts', () => () => <MockView />);
jest.mock('react-native-blob-util', () => ({}));
jest.mock('@aviva/react-native-encrypted-storage/src', () => ({
  getItem: jest.fn(),
  setItem: jest.fn(),
}));

jest.mock('@src/common/providers/accessibility', () => ({
  useAccessibility: () => ({ isScreenReaderEnabled: false }),
}));

jest.mock('@src/common/hooks/use-a11y-focus', () => ({
  useA11yFocus: () => ({ elementRef: jest.fn(), focus: jest.fn() }),
}));

jest.mock('@aviva/ion-mobile/components/focus-aware-status-bar', () => ({
  FocusAwareStatusBar: MockView,
}));

jest.mock('@hooks/use-service-analytics', () => ({
  trackApiAnalytics: jest.fn(),
  trackBiometricEvent: jest.fn(),
  trackApiAnalyticsSinglePdf: jest.fn(),
}));

jest.mock('@legendapp/state/persist', () => ({
  persistObservable: jest.fn(),
  configureObservablePersistence: jest.fn(),
}));

jest.mock('@react-native-clipboard/clipboard', () => ({
  setString: jest.fn(),
  getString: jest.fn(),
}));

jest.mock('@react-navigation/elements', () => ({
  ...jest.requireActual('@react-navigation/elements'),
  useHeaderHeight: () => 0,
}));

jest.mock('@config', () => ({
  config: mockConfig,
  setupConfig: jest.fn(),
  isDevMode: jest.fn(),
  isMockBuild: jest.fn(),
}));

jest.mock('@react-navigation/native', () => ({
  ...jest.requireActual('@react-navigation/native'),
  useRoute: jest.fn(),
  useNavigation: () => ({
    navigate: jest.fn(),
    dispatch: jest.fn(),
    setOptions: jest.fn(),
    addListener: jest.fn(),
    goBack: jest.fn(),
  }),
  useFocusEffect: jest.fn,
  useIsFocused: jest.fn().mockReturnValue(true),
}));

jest.mock('react-native-reanimated', () => {
  const Reanimated = require('react-native-reanimated/mock');
  Reanimated.default.call = () => ({});
  Reanimated.useEvent = jest.fn();
  Reanimated.useHandler = jest.fn(() => ({
    context: jest.fn(),
    doDependenciesDiffer: false,
  }));
  return Reanimated;
});

jest.mock('react-native-collapsible-tab-view', () => ({
  useTabsContext: () => ({
    indexDecimal: { value: 10 },
    headerHeight: 30,
    tabBarHeight: 30,
    headerTranslateY: 30,
  }),
  useFocusedTab: () => true,
  Tabs: {
    Container: ({ renderHeader, renderTabBar, children }) => (
      <MockView>
        {renderHeader()}
        {renderTabBar()}
        {children}
      </MockView>
    ),
    ScrollView: MockScrollView,
    FlatList: MockFlatList,
    FlashList: MockFlatList,
    MasonryFlashList: MockFlatList,
    Tab: ({ name, children }) => (
      <MockView>
        <MockText>{name}</MockText>
        {children}
      </MockView>
    ),
  },
  MaterialTabBar: (props) => (
    <MockScrollView testID="MaterialTabBar" {...props} />
  ),
}));

jest.mock('@aviva/ion-mobile/components/collapsible-tabs', () => ({
  ...jest.requireActual('@aviva/ion-mobile/components/collapsible-tabs'),
  TabsHeaderWrapper: (data) => {
    if (data.layoutType === 'flashList' || data.layoutType === 'scrollView') {
      return null;
    }

    // eslint-disable-next-line testing-library/no-node-access
    return data.children;
  },
}));

jest.mock('react-native-date-picker', () => (props) => (
  <MockTextInput
    testID={props.testID}
    onChange={props.onConfirm}
    value={props.date.toString()}
  />
));

jest.mock('@react-native-cookies/cookies', () => ({
  set: jest.fn(),
  setFromResponse: jest.fn(),
  get: jest.fn(),
  getAll: jest.fn(),
  clearAll: jest.fn(),
  clearByName: jest.fn(),
  flush: jest.fn(),
  removeSessionCookies: jest.fn(),
}));

jest.mock('@adobe/react-native-acpanalytics', () => ({
  ACPAnalytics: {
    extensionVersion: jest.fn(),
    getTrackingIdentifier: jest.fn(),
    getQueueSize: jest.fn(),
    clearQueue: jest.fn(),
    sendQueuedHits: jest.fn(),
    getVisitorIdentifier: jest.fn(),
    setVisitorIdentifier: jest.fn(),
  },
}));

jest.mock('../utils/get-device-id/get-device-id.ts', () => ({
  getHashedDeviceId: jest
    .fn()
    .mockResolvedValue('GiWDQhjYsuUBcljLrRsZmlLekBz3DKcBIqKOA5suqIg='),
  getUniqueDeviceId: jest
    .fn()
    .mockResolvedValue('0d158b17-f666-4655-bbbd-d4d298ba9d9b'),
  getRiskId: jest
    .fn()
    .mockResolvedValue('E811AE7B-0DE1-4286-92F9-BCE74A2C994D'),
}));

jest.mock('@appdynamics/react-native-agent', () => ({
  ErrorSeverityLevel: { WARNING: 'WARNING' },
  BreadcrumbVisibility: { CRASHES_ONLY: 0, CRASHES_AND_SESSIONS: 1 },
  Instrumentation: {
    startTimer: jest.fn(),
    stopTimer: jest.fn(),
    reportError: jest.fn(),
    leaveBreadcrumb: jest.fn(),
    trackUIEvent: jest.fn(),
  },
}));

// https://github.com/Shopify/flash-list/issues/557#issuecomment-1219383137
jest.mock('@shopify/flash-list', () => {
  const ActualFlashList = jest.requireActual('@shopify/flash-list').FlashList;
  const MockFlashList = require('react').forwardRef((props, ref) => (
    <ActualFlashList
      {...props}
      ref={ref}
      estimatedListSize={{ height: 1000, width: 400 }}
      horizontal={false}
    />
  ));

  return {
    ...jest.requireActual('@shopify/flash-list'),
    FlashList: MockFlashList,
    // Mocking with the FlashList due to it not rendering accessible elements in RNTL
    MasonryFlashList: MockFlashList,
  };
});

jest.mock('@adobe/react-native-acpcore', () => ({
  ACPCore: {
    extensionVersion: jest.fn(),
    configureWithAppId: jest.fn(),
    updateConfiguration: jest.fn(),
    setLogLevel: jest.fn(),
    log: jest.fn(),
    setPrivacyStatus: jest.fn(),
    getPrivacyStatus: jest.fn(),
    getSdkIdentities: jest.fn(),
    dispatchEvent: jest.fn(),
    dispatchEventWithResponseCallback: jest.fn(),
    dispatchResponseEvent: jest.fn(),
    trackAction: jest.fn(),
    trackState: jest.fn(),
    setAdvertisingIdentifier: jest.fn(),
    setPushIdentifier: jest.fn(),
    collectPii: jest.fn(),
    setSmallIconResourceID: jest.fn(),
    setLargeIconResourceID: jest.fn(),
    setAppGroup: jest.fn(),
    downloadRules: jest.fn(),
  },
  ACPIdentity: {
    extensionVersion: jest.fn(),
    syncIdentifiers: jest.fn(),
    syncIdentifiersWithAuthState: jest.fn(),
    syncIdentifier: jest.fn(),
    appendVisitorInfoForURL: jest.fn(),
    getUrlVariables: jest.fn(),
    getIdentifiers: jest.fn(),
    getExperienceCloudId: jest.fn(),
  },
}));

jest.mock('react-native-webview', () => {
  const { View } = require('react-native');
  const WebView = (props) => <View {...props} />;

  return { WebView, default: WebView, __esModule: true };
});

jest.mock('react-native-fast-image', () => {
  const { View } = require('react-native');
  const FastImage = (props) => <View {...props} />;

  return { default: FastImage, __esModule: true };
});

jest.mock('@adyen/react-native', () => ({
  AdyenActionComponent: jest.fn(),
  AdyenCheckout: ({ children }) => children,
  PaymentMethodData: jest.fn(),
  useAdyenCheckout: jest.fn(() => ({ start: jest.fn(), paymentMethods: [] })),
}));

jest.mock(
  '../feature-flags/feature-flags.json',
  () => ({
    dwEOLEnabled: false,
    dwFAQsEnabled: false,
    dwFindAndCombineEnabled: true,
    dwSimpleWealthEnabled: true,
    dwSimpleWealthDigitalAdviceEnabled: true,
    dwIsaApplyDirectNativeFlowEnabled: false,
    dwIsaApplySimpleWealthNativeFlowEnabled: true,
    dwIsaApplySimpleWealthIgnoreCIDocFail: false,
    dwIsaApplySimpleWealthIgnoreEligibility: false,
    dwIsaApplyBypassSubmitApiLogic: false,
    dwPCSAllowMultiSelect: false,
    dwSIPPPensionEditEnabled: true,
    dwVirtualAssistantEnabled: true,
    myDriveOnboardingComplete: false,
    myDriveUseMockData: false,
    simpleWealthPopupEnabled: false,
  }),
  { virtual: true }
);
