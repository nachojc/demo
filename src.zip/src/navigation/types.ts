import { Product } from '@hooks/use-product/product-helpers';
import {
  Aviva_Digital_MobileApi_Endpoints_Pensions_V1_Model_PensionBeneficiaryModel as PensionBeneficiary,
  Aviva_Digital_MobileApi_Endpoints_Pensions_V1_Model_PensionRoleModel as AddedPensionBeneficiary,
} from '@src/api/generated/requests';
import { MotorProduct } from '@src/features/policy/motor/helpers';
import { RootStackParamList } from '@src/navigation';
import { PensionFund } from '@src/validation/schemas/pension-funds';
import { AvivaOnlineMotorVehicle } from '@src/validation/schemas/product/motor/aviva-online-motor-product';
import { MotorVehicle } from '@src/validation/schemas/product/motor/motor-product';
import { PensionProduct } from '@src/validation/schemas/product/pension-product';
import { BankDetailsSchema } from '@src/validation/schemas/single-payment';
import { CamelCasedPropertiesDeep, RequireAllOrNone } from 'type-fest';
import { z } from 'zod';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace ReactNavigation {
    interface RootParamList extends RootStackParamList {}
  }
}

export type MotorParams = {
  securePolicyNumber: string;
  vehicle?: AvivaOnlineMotorVehicle | MotorVehicle;
  title?: string;
  backAnalyticsTag?: string;
  isAoMotorProduct?: boolean;
  subscriptionNumber?: string;
  isPlus?: boolean;
};

export type HomePolicyParams = {
  securePolicyNumber: string;
  productType: Product | MotorProduct | undefined;
};

export type RenewalParams = HomePolicyParams & { backAnalyticsTag?: string };

export type HealthPolicyParams = {
  securePolicyNumber: string;
  secureMemberNumber: string;
  isCorporate: boolean;
  documentsReference: string;
};

export type CommonBeneficiary = PensionBeneficiary &
  CamelCasedPropertiesDeep<
    Omit<
      AddedPensionBeneficiary,
      'FirstName' | 'LastName' | 'PostalAddress'
    > & {
      postalAddress?: AddedPensionBeneficiary['PostalAddress'];
    }
  > & { __id: string }; // Internal ID used to edit on the FE;

export type PensionParams = {
  securePolicyNumber: string;
  platformAccountNumber: string | null;
};

export type PensionSnapshotParams = { products: PensionProduct[] };
export type PensionPerformanceParams = {
  fund: PensionFund;
};
export type PreviousPolicyParams = { securePolicyNumber: string; year: string };

export type BankDetails = z.infer<typeof BankDetailsSchema>;

export type BaseSinglePaymentParams = {
  residentialStatus:
    | 'I live permanently in the UK'
    | 'I am a crown servant or the husband, wife or civil partner of a crown servant'
    | 'I do not live in the UK';
  employmentStatus:
    | 'Employed (Full or part-time)'
    | 'Self employed'
    | 'Unemployed (Not working)';
  originalSource:
    | 'Inheritance'
    | 'Salary'
    | 'Gift'
    | 'Divorce Settlement'
    | 'Lottery/Betting Win'
    | 'House Sale'
    | 'Profits from a company/shares'
    | 'Redundancy'
    | 'Retirement Fund'
    | 'Other';
  paymentAmount: number;
  taxRelief: number;
  accountType: string;
  fundSource: string;
  occupation?: string;
  salary?: number;
};

export type UnisureSinglePaymentParams = {
  paymentMethod: 'Debit card' | 'Bank transfer (BACS)';
};

export type MyMoneySinglePaymentParams = {
  sortCode: string;
  accountName: string;
  accountNumber: string;
  buildingSocietyRollNumber?: string;
};

export type SinglePaymentParams = PensionParams &
  BaseSinglePaymentParams &
  (UnisureSinglePaymentParams | MyMoneySinglePaymentParams);

export type SinglePaymentStepThree = PensionParams &
  BaseSinglePaymentParams &
  (UnisureSinglePaymentParams | MyMoneySinglePaymentParams) &
  Pick<
    SinglePaymentParams,
    'paymentAmount' | 'fundSource' | 'employmentStatus' | 'taxRelief'
  > &
  Partial<UnisureSinglePaymentParams>;

export type SinglePaymentStepFour = PensionParams &
  Pick<
    SinglePaymentParams,
    'paymentAmount' | 'fundSource' | 'employmentStatus' | 'taxRelief'
  > &
  Partial<UnisureSinglePaymentParams> &
  BankDetails;

export type SinglePaymentSuccess = PensionParams &
  RequireAllOrNone<
    BankDetails &
      Pick<BaseSinglePaymentParams, 'fundSource' | 'employmentStatus'> &
      Partial<UnisureSinglePaymentParams> &
      Pick<SinglePaymentParams, 'paymentAmount' | 'taxRelief'>,
    keyof BankDetails | 'paymentAmount'
  >;

export type ConfirmBeneficiariesSuccess = PensionParams;

export type WebViewParams = {
  url: string;
  title?: string;
  ssoEnabled?: boolean;
  appendVisitorInfoEnabled?: boolean;
};
