import { Icon, TopAppBarManga, TopAppBarMangaProps } from '@aviva/ion-mobile';
import {
  Aviva_Digital_MobileApi_Endpoints_PostcodeLookup_V1_Model_AddressModel as AddressModel,
  Aviva_Digital_MobileApi_Endpoints_PostcodeLookup_V1_Model_PostcodeLookupModel as PostcodeLookup,
} from '@src/api/generated/requests';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import {
  ChangeAddressErrorScreen,
  ChangePaperlessOnlineScreen,
  PaperlessDocumentPreferencesScreen,
} from '@src/features';
import { ChangeAddressScreenApp } from '@src/features/profile/change-address/change-address-screen-app';
import { ChangeAddressScreenWeb } from '@src/features/profile/change-address/change-address-screen-web';
import { ConfirmAddressScreen } from '@src/features/profile/change-address/confirm-new-address/confirm-new-address';
import { ChangeAddressHelpScreen } from '@src/features/profile/change-address/help-screen/change-address-help-screen';
import { ShowAddressListScreen } from '@src/features/profile/change-address/select-address/show-address-list-screen';
import { ChangeAddressSuccessScreen } from '@src/features/profile/change-address/success-screen/change-address-success-screen';
import { topAppHeader } from '@src/navigation/app/summary/headers/headers';

import { MainAppStack } from './main-app-stack';

type ProfileParams = {
  onClose: () => void;
  postcodeLookup?: PostcodeLookup;
  addressModal?: AddressModel;
};

export type AppStackProfileRouteParams = {
  ['Change address help']: ProfileParams;
  ['Change address App']: ProfileParams;
  ['Confirm address']: ProfileParams;
  ['Show Address List']: ProfileParams;
  ['Address change error']: undefined;
  ['Address change success']: undefined;
  ['Paperless preferences']: undefined;
  ['Paperless preferences documents']: undefined;
  ['Paperless preferences online']: undefined;
  ['Change address Web']: undefined;
  ['Change personal details']: undefined;
};

export const ProfileScreens = () => {
  return (
    <>
      <MainAppStack.Screen
        name="Paperless preferences"
        options={{ header: TopAppBarManga, headerShown: true }}
        getComponent={() =>
          require('@src/features/profile/paperless-preferences-screen')
            .PaperlessPreferencesScreen
        }
      />
      <MainAppStack.Group screenOptions={{ headerShown: false }}>
        <MainAppStack.Screen
          name="Address change error"
          component={ChangeAddressErrorScreen}
        />

        <MainAppStack.Screen
          name="Address change success"
          component={ChangeAddressSuccessScreen}
        />
      </MainAppStack.Group>
      <MainAppStack.Group
        screenOptions={({ route }) => ({
          headerShown: true,
          header: (props: TopAppBarMangaProps) =>
            topAppHeader({
              actionIcons: [
                <Icon
                  name="close"
                  onPress={() => (route?.params as ProfileParams)?.onClose()}
                  key="close"
                />,
              ],
              ...props,
            }),
        })}
      >
        <MainAppStack.Screen
          name="Change address App"
          component={ChangeAddressScreenApp}
          options={{
            title: 'Change address',
          }}
        />

        <MainAppStack.Screen
          name="Change address help"
          component={ChangeAddressHelpScreen}
          options={{
            title: 'Change address',
          }}
        />

        <MainAppStack.Screen
          name="Show Address List"
          component={ShowAddressListScreen}
          options={{
            title: 'Select address',
          }}
        />

        <MainAppStack.Screen
          name="Confirm address"
          component={ConfirmAddressScreen}
          options={{
            title: 'Confirm address',
          }}
        />
      </MainAppStack.Group>
      <MainAppStack.Group
        screenOptions={{
          header: AvivaWebViewTopAppBar,
          headerShown: true,
        }}
      >
        <MainAppStack.Screen
          name="Paperless preferences documents"
          component={PaperlessDocumentPreferencesScreen}
        />

        <MainAppStack.Screen
          name="Paperless preferences online"
          component={ChangePaperlessOnlineScreen}
        />
        <MainAppStack.Screen
          name="Change address Web"
          component={ChangeAddressScreenWeb}
          options={{
            title: 'Change address',
          }}
        />

        <MainAppStack.Screen
          name="Change personal details"
          getComponent={() =>
            require('@src/features/profile/change-personal-details-screen')
              .ChangePersonalDetailsScreen
          }
        />
      </MainAppStack.Group>
    </>
  );
};
