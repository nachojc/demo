import { TopAppBarDW } from '@aviva/ion-mobile';
import { isManga } from '@hooks/use-expo-config';
import { useRemoteFeatureFlag } from '@hooks/use-remote-feature-flag';
import { NavigatorScreenParams } from '@react-navigation/native';
import { PdfViewScreenRouteParams } from '@src/features/pdf-view';
import { MessageAction } from '@src/validation/schemas/messages';

import { BottomTabsRouteParams } from '../bottom-tabs';
import { LinkingAlertScreen } from '../linking-alert-screen/linking-alert-screen';
import { WebViewParams } from '../types';
import {
  AppStackDWRouteParams,
  DirectWealthScreens,
} from './direct-wealth-screens';
import { AppStackHelpRouteParams, HelpScreens } from './help-screens';
import { MainAppStack } from './main-app-stack';
import { MoreScreens } from './more-screens';
import { AppStackOffersRouteParams, OffersScreens } from './offers-screens';
import { AppStackProfileRouteParams, ProfileScreens } from './profile-screens';
import {
  AppStackSummaryRouteParams,
  SummaryScreens,
  TopAppBarIDV,
  TopAppBarMessages,
} from './summary';
import { WebViewScreens } from './summary/stack-groups/web-view-screens';

export type AppStackRouteParams = {
  ['Bottom tabs']: NavigatorScreenParams<BottomTabsRouteParams>;
  ['Messages']: undefined;
  ['Message Details']: { MessageId: string };
  ['Message Action']: MessageAction;
  ['LinkingAlertScreen']: undefined;
  ['IDV Success Screen']: undefined;
  ['IDV Error Screen']: undefined;
  ['IDV With Questions']: undefined;
  ['Pdf View']: PdfViewScreenRouteParams;
  ['Web View']: WebViewParams;
};

export type AppStackScreenNames =
  | keyof AppStackRouteParams
  | keyof AppStackDWRouteParams
  | keyof AppStackOffersRouteParams
  | keyof AppStackProfileRouteParams
  | keyof AppStackHelpRouteParams
  | keyof AppStackSummaryRouteParams;

export const AppStack = () => {
  const { value: dwInMangaEnabled } = useRemoteFeatureFlag(
    'release-myaviva-direct-wealth-in-manga'
  );

  // Direct Wealth navigation stack
  if (!isManga()) {
    return (
      <MainAppStack.Navigator screenOptions={{ headerShown: false }}>
        <MainAppStack.Screen
          name="Bottom tabs"
          getComponent={() => require('../bottom-tabs').BottomTabs}
        />
        <MainAppStack.Screen
          name="LinkingAlertScreen"
          component={LinkingAlertScreen}
          options={{
            presentation: 'fullScreenModal',
          }}
        />
        <MainAppStack.Screen
          name="IDV With Questions"
          getComponent={() =>
            require('@src/features/idv').UnlockPolicyWithQuestionsScreen
          }
          options={{
            gestureEnabled: false,
            header: (props) => TopAppBarIDV(props, 'aviva.co.uk'),
          }}
        />

        <MainAppStack.Screen
          name="IDV Success Screen"
          getComponent={() => require('@src/features/idv').IDVSuccessScreen}
          options={{ gestureEnabled: false, title: 'Identity verification' }}
        />

        <MainAppStack.Screen
          name="IDV Error Screen"
          getComponent={() => require('@src/features/idv').IDVErrorScreen}
          options={{ gestureEnabled: false, title: 'Identity verification' }}
        />
        <MainAppStack.Screen
          name="Pdf View"
          getComponent={() => require('@src/features/pdf-view').PDFViewScreen}
          options={{ headerShown: true }}
        />

        <MainAppStack.Group
          screenOptions={{ headerShown: true, header: TopAppBarDW }}
        >
          <MainAppStack.Screen
            name="Messages"
            options={{
              header: (props) => TopAppBarMessages(props),
            }}
            getComponent={() => require('@src/features').MessageCenterScreen}
          />
          <MainAppStack.Screen
            name="Message Details"
            getComponent={() => require('@src/features').MessageDetailsScreen}
          />
          <MainAppStack.Screen
            name="Message Action"
            options={{
              title: '',
            }}
            getComponent={() => require('@src/features').MessageActionScreen}
          />
        </MainAppStack.Group>
        {ProfileScreens()}
        {HelpScreens()}
        {MoreScreens()}
        {DirectWealthScreens()}
        {WebViewScreens()}
      </MainAppStack.Navigator>
    );
  }

  return (
    <MainAppStack.Navigator
      screenOptions={{ headerShown: false, animation: 'slide_from_right' }}
    >
      <MainAppStack.Screen
        name="Bottom tabs"
        getComponent={() => require('../bottom-tabs').BottomTabs}
      />
      {WebViewScreens()}
      {SummaryScreens()}
      {ProfileScreens()}
      {OffersScreens()}
      {HelpScreens()}
      {MoreScreens()}
      {!!dwInMangaEnabled && DirectWealthScreens()}
    </MainAppStack.Navigator>
  );
};
