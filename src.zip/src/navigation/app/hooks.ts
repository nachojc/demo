import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { RootStackParamList } from '..';
import { AppStackRouteParams, AppStackScreenNames } from '.';
import { AppStackDWRouteParams } from './direct-wealth-screens';
import { AppStackHelpRouteParams } from './help-screens';
import { AppStackMoreRouteParams } from './more-screens';
import { AppStackOffersRouteParams } from './offers-screens';
import { AppStackProfileRouteParams } from './profile-screens';
import { AppStackSummaryRouteParams } from './summary';

export type AppStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<
    AppStackRouteParams &
      AppStackDWRouteParams &
      AppStackProfileRouteParams &
      AppStackOffersRouteParams &
      AppStackHelpRouteParams &
      AppStackMoreRouteParams &
      AppStackSummaryRouteParams
  >,
  NativeStackNavigationProp<RootStackParamList>
>;

/**
 * @description A typed wrapper around useNavigation
 *
 * For use within the App navigation stack
 */
export function useAppStackNavigation() {
  return useNavigation<AppStackNavigation>();
}

export type AppStackRoute<
  T extends
    | keyof AppStackRouteParams
    | keyof AppStackDWRouteParams
    | keyof AppStackProfileRouteParams
    | keyof AppStackOffersRouteParams
    | keyof AppStackHelpRouteParams
    | keyof AppStackMoreRouteParams
    | keyof AppStackSummaryRouteParams
> = RouteProp<
  AppStackRouteParams &
    AppStackDWRouteParams &
    AppStackProfileRouteParams &
    AppStackHelpRouteParams &
    AppStackOffersRouteParams &
    AppStackMoreRouteParams &
    AppStackSummaryRouteParams,
  T
>;

/**
 * @description A typed wrapper around useRoute
 *
 * @T
 * T is the name of the screen from which you're calling this hook
 * It must be a key of AppStackRouteParams or AppStackDWRouteParams
 */
export function useAppStackRoute<T extends AppStackScreenNames>() {
  return useRoute<AppStackRoute<T>>();
}
