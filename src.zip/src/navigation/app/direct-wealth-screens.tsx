import { getTokens, getVariableValue, TopAppBarDW } from '@aviva/ion-mobile';
import { ErrorViewProps } from '@direct-wealth/components/error-view/error-view';
import { FindAndCombineStackRouteParams } from '@direct-wealth/features/find-and-combine/navigation/types';
import { IsaApplyStackRouteParams } from '@direct-wealth/features/isa-apply/navigation';
import { HoldingNavigationData } from '@direct-wealth/features/product-view/investments-tab';
import { SimpleWealthStackRouteParams } from '@direct-wealth/features/simple-wealth/navigation';
import { SIPPStackRouteParams } from '@direct-wealth/features/sipp-transfer/navigation';
import { SubaccountAccount } from '@direct-wealth/validation/schemas/direct-wealth-subaccount';
import { TransferInformation } from '@direct-wealth/validation/schemas/pension-consolidation-summary';
import { NavigatorScreenParams } from '@react-navigation/native';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import { closeNavButtonWithProps } from '@src/navigation/buttons/close-nav-button';
import {
  CashTransactionDetailsParams,
  ProductTransactionDetailsParams,
} from 'products/direct-wealth/validation/schemas/transaction-history';

import { MainAppStack } from './main-app-stack';
import {
  AnimatedTopAppBarDW,
  MotorProductHeader,
} from './summary/headers/headers';

export const SIPP_TRANSFER = 'SIPP Transfer';
export const FIND_AND_COMBINE = 'Find And Combine';
export const ISA_APPLY = 'ISA Apply';

export type AppStackDWRouteParams = {
  ['OnboardingInformationScreen']: undefined;
  ['SimpleWealthStack']: NavigatorScreenParams<SimpleWealthStackRouteParams>;
  ['ProductDashboard']: { securePolicyNumber: string };
  ['PCS Dashboard']: undefined;
  ['Pension Details']: {
    secureId: string;
    transferInformation: TransferInformation;
  };
  ['Manage Debit']: { securePolicyNumber: string };
  ['Holding']: { data: HoldingNavigationData };

  ['Video Player']: { title: string; uri: string; transcript: string };
  ['Transaction History']: {
    securePolicyNumber: string;
    accountType: SubaccountAccount;
  };
  ['Intercept Closing Webview']: { uri: string; interceptUri: string };
  [SIPP_TRANSFER]: NavigatorScreenParams<SIPPStackRouteParams>;
  ['Transaction Details']:
    | CashTransactionDetailsParams
    | ProductTransactionDetailsParams;
  ['AsyncChatOnboarding']: undefined;
  ['Valid Appointment']: { when: 'future' | 'past' } | undefined;
  ['Error Screen']: ErrorViewProps;
  [FIND_AND_COMBINE]: NavigatorScreenParams<FindAndCombineStackRouteParams>;
  [ISA_APPLY]: NavigatorScreenParams<IsaApplyStackRouteParams>;
};

export const DirectWealthScreens = () => {
  const tokens = getTokens();

  return (
    <>
      <MainAppStack.Group
        screenOptions={{ headerShown: true, header: TopAppBarDW }}
      >
        <MainAppStack.Screen
          options={{
            header: (props) => AnimatedTopAppBarDW(props),
            contentStyle: {
              backgroundColor: getVariableValue(tokens.color.White),
            },
          }}
          name="ProductDashboard"
          getComponent={() =>
            require('@direct-wealth/features/product-view/product-dashboard')
              .ProductDashboardScreen
          }
        />
        <MainAppStack.Screen
          name="SimpleWealthStack"
          getComponent={() =>
            require('@direct-wealth/features/simple-wealth/navigation')
              .SimpleWealthStack
          }
          options={{ headerShown: false }}
        />
        <MainAppStack.Screen
          name="PCS Dashboard"
          getComponent={() =>
            require('@direct-wealth/features/pension-consolidation/')
              .DashboardScreen
          }
          options={{
            title: 'Find and Combine',
          }}
        />
        <MainAppStack.Screen
          name="Pension Details"
          getComponent={() =>
            require('@direct-wealth/features/pension-consolidation')
              .PensionDetailsScreen
          }
          options={{
            title: 'Pension details',
          }}
        />
        <MainAppStack.Screen
          name="Manage Debit"
          getComponent={() =>
            require('@direct-wealth/features/product-view/performance-tab/manage-direct-debit-screen')
              .ManageDirectDebitScreen
          }
          options={{
            title: 'Manage Direct Debit',
          }}
        />
        <MainAppStack.Screen
          name="Holding"
          getComponent={() =>
            require('@direct-wealth/features/product-view/individual-holding-screen')
              .IndividualHoldingScreen
          }
          options={{
            title: 'Holding',
          }}
        />
        <MainAppStack.Screen
          name="Transaction History"
          getComponent={() =>
            require('@direct-wealth/features/transaction-history')
              .TransactionHistoryScreen
          }
          options={() => ({
            title: 'Transactions',
          })}
        />
        <MainAppStack.Screen
          name="Transaction Details"
          getComponent={() =>
            require('@direct-wealth/features/transaction-history/transaction-details-screen')
              .TransactionDetailsScreen
          }
          options={{
            title: 'Transaction',
          }}
        />

        <MainAppStack.Screen
          name="Video Player"
          getComponent={() =>
            require('@direct-wealth/common/utils/video-player')
              .VideoPlayerScreen
          }
          options={{
            title: 'Video',
          }}
        />
        <MainAppStack.Screen
          name={SIPP_TRANSFER}
          getComponent={() =>
            require('@direct-wealth/features/sipp-transfer/navigation')
              .SIPPStack
          }
          options={{ headerShown: false }}
        />
        <MainAppStack.Screen
          name={FIND_AND_COMBINE}
          getComponent={() =>
            require('@direct-wealth/features/find-and-combine/navigation')
              .FindAndCombineStack
          }
          options={{ headerShown: false, gestureEnabled: false }}
        />
        <MainAppStack.Screen
          name={ISA_APPLY}
          getComponent={() =>
            require('@direct-wealth/features/isa-apply/navigation')
              .IsaApplyScreens
          }
          options={{ headerShown: false }}
        />
      </MainAppStack.Group>
      <MainAppStack.Screen
        name="Error Screen"
        getComponent={() =>
          require('../../../products/direct-wealth/components/error-view/error-screen')
            .ErrorScreen
        }
        options={{
          headerShown: true,
          presentation: 'fullScreenModal',
          headerRight: closeNavButtonWithProps({ color: 'white' }),
          headerTransparent: true,
          headerTitle: '',
        }}
      />

      <MainAppStack.Group
        screenOptions={{
          headerShown: true,
          header: (props) => MotorProductHeader(props),
        }}
      >
        <MainAppStack.Screen
          name="Intercept Closing Webview"
          getComponent={() =>
            require('@src/components/web-view/intercept-closing-webview')
              .InterceptClosingWebView
          }
          initialParams={{
            uri: 'https://www.aviva.co.uk',
            interceptUri: 'iDontWantUriToBeIntercepted',
          }}
          options={{
            header: AvivaWebViewTopAppBar,
            title: 'aviva.co.uk',
          }}
        />
      </MainAppStack.Group>
    </>
  );
};
