import { createNativeStackNavigator } from '@react-navigation/native-stack';

import { AppStackRouteParams } from '../app';
import { AppStackDWRouteParams } from './direct-wealth-screens';
import { AppStackHelpRouteParams } from './help-screens';
import { AppStackMoreRouteParams } from './more-screens';
import { AppStackOffersRouteParams } from './offers-screens';
import { AppStackProfileRouteParams } from './profile-screens';
import { AppStackSummaryRouteParams } from './summary';

export const MainAppStack = createNativeStackNavigator<
  AppStackRouteParams &
    AppStackDWRouteParams &
    AppStackProfileRouteParams &
    AppStackHelpRouteParams &
    AppStackOffersRouteParams &
    AppStackMoreRouteParams &
    AppStackSummaryRouteParams
>();
