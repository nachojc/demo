import { TopAppBarManga } from '@aviva/ion-mobile';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import { ACTION_PAGE_NOTIFICATIONS_BACK } from '@src/features/notification-toggle/analytics';

import { DevModeStack } from '../dev-mode';
import { MainAppStack } from './main-app-stack';
import { MoreScreenNames } from './summary/more-screen-names';

export type AppStackMoreRouteParams = {
  [MoreScreenNames.More]: undefined;
  [MoreScreenNames.DeleteAccount]: undefined;
  [MoreScreenNames.DeleteModal]: undefined;
  [MoreScreenNames.DeleteConfirmation]: undefined;
  [MoreScreenNames.Security]: undefined;
  [MoreScreenNames.BiometricLogin]: undefined;
  [MoreScreenNames.TwoStepVerification]: { webMfaLink: string };
  [MoreScreenNames.ChangeUsername]: undefined;
  [MoreScreenNames.ChangePassword]: undefined;
  [MoreScreenNames.DeviceManagement]: undefined;
  [MoreScreenNames.MyDriveSettings]: undefined;
  [MoreScreenNames.DisableMyDrive]: undefined;
  [MoreScreenNames.NotificationToggle]: undefined;
  [MoreScreenNames.DevMode]: undefined;
};

type TopBarProps = NativeStackHeaderProps & {
  backEnabled: boolean;
  backAnalyticsTag?: string;
};

const TopBar = ({ backEnabled, ...rest }: TopBarProps) => {
  return (
    <TopAppBarManga
      {...rest}
      back={backEnabled ? { title: 'Previous' } : undefined}
      textLabel="Delete online account"
    />
  );
};

export const MoreScreens = () => {
  return (
    <>
      {/* Screens that use the TopAppBarManga Header */}
      <MainAppStack.Group
        screenOptions={{ header: TopAppBarManga, headerShown: true }}
      >
        <MainAppStack.Screen
          name={MoreScreenNames.More}
          getComponent={() => require('@src/features').MoreScreen}
        />
        <MainAppStack.Screen
          name={MoreScreenNames.DevMode}
          component={DevModeStack}
          options={{ headerShown: false }}
        />
        <MainAppStack.Screen
          name={MoreScreenNames.Security}
          getComponent={() =>
            require('@src/features/security/security-screen').SecurityScreen
          }
        />
        <MainAppStack.Screen
          name={MoreScreenNames.MyDriveSettings}
          getComponent={() =>
            require('@src/features/mydrive/settings/settings-screen')
              .SettingsScreen
          }
          options={{ title: 'MyDrive' }}
        />
        <MainAppStack.Screen
          name={MoreScreenNames.NotificationToggle}
          getComponent={() => require('@src/features').NotificationToggleScreen}
          options={{
            title: 'Notifications',
            header: header(true, ACTION_PAGE_NOTIFICATIONS_BACK),
          }}
        />
        <MainAppStack.Screen
          name={MoreScreenNames.DeleteAccount}
          getComponent={() => require('@src/features').DeleteAccountScreen}
          options={{ title: 'Delete online account' }}
        />
        <MainAppStack.Screen
          name={MoreScreenNames.DeviceManagement}
          getComponent={() =>
            require('@src/features/device-management').DeviceManagementScreen
          }
        />

        <MainAppStack.Screen
          name={MoreScreenNames.DeleteModal}
          options={{
            // Loading spinner is covered if this is a modal
            header: header(true),
          }}
          getComponent={() => require('@src/features').DeleteAccountModal}
        />
        <MainAppStack.Screen
          options={{
            presentation: 'fullScreenModal',
            header: header(false),
          }}
          name={MoreScreenNames.DeleteConfirmation}
          getComponent={() => require('@src/features').DeleteConfirmationScreen}
        />
        <MainAppStack.Screen
          name={MoreScreenNames.BiometricLogin}
          getComponent={() =>
            require('@src/features/biometric').BiometricSettingsScreen
          }
        />
        <MainAppStack.Screen
          name={MoreScreenNames.DisableMyDrive}
          getComponent={() =>
            require('@src/features/mydrive/deactivation/').DisableMyDriveScreen
          }
        />
      </MainAppStack.Group>

      {/* Screens that use the AvivaWebViewTopAppBar Header in Modal presentation */}
      <MainAppStack.Group
        screenOptions={{
          header: AvivaWebViewTopAppBar,
          headerShown: true,
        }}
      >
        <MainAppStack.Screen
          name={MoreScreenNames.TwoStepVerification}
          getComponent={() =>
            require('@src/features/two-step-verification')
              .TwoStepVerificationScreen
          }
        />
        <MainAppStack.Screen
          name={MoreScreenNames.ChangeUsername}
          getComponent={() =>
            require('@src/features/change-username').ChangeUsernameScreen
          }
        />
        <MainAppStack.Screen
          name={MoreScreenNames.ChangePassword}
          getComponent={() =>
            require('@src/features/change-password').ChangePasswordScreen
          }
        />
      </MainAppStack.Group>
    </>
  );
};

const header =
  (backEnabled: boolean, backAnalyticsTag?: string) =>
  (props: NativeStackHeaderProps) =>
    (
      <TopBar
        {...props}
        backEnabled={backEnabled}
        backAnalyticsTag={backAnalyticsTag}
      />
    );
