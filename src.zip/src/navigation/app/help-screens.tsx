import { TopAppBarManga, TopAppBarMangaProps } from '@aviva/ion-mobile';
import { RouteProp } from '@react-navigation/native';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import { ContactProduct } from '@src/features/contact-us/model';
import { topAppHeader } from '@src/navigation/app/summary/headers/headers';

import { AppStackNavigation } from './hooks';
import { MainAppStack } from './main-app-stack';

export const HelpScreenNames = {
  Help: 'Help',
  ContactUs: 'Contact Us',
  AppFaqs: 'App FAQs',
  TermsOfUse: 'Terms of Use',
  PrivacyNotice: 'Privacy Notice',
  CookiePolicy: 'Cookie Policy',
  PrivacyPolicy: 'Privacy Policy',
  AvivaCoUk: 'Aviva Co Uk',
  IcoOrgUk: 'Ico Org Uk',
  ContactUsBuffer: 'Contact Us Buffer',
  ContactUsWebView: 'Contact Us WebView',
} as const;

export type AppStackHelpRouteParams = {
  [HelpScreenNames.Help]: undefined;
  [HelpScreenNames.ContactUs]: undefined;
  [HelpScreenNames.AppFaqs]: undefined;
  [HelpScreenNames.TermsOfUse]: undefined;
  [HelpScreenNames.PrivacyNotice]: undefined;
  [HelpScreenNames.CookiePolicy]: undefined;
  [HelpScreenNames.PrivacyPolicy]: undefined;
  [HelpScreenNames.AvivaCoUk]: undefined;
  [HelpScreenNames.IcoOrgUk]: undefined;
  [HelpScreenNames.ContactUsBuffer]: { product: ContactProduct };
  [HelpScreenNames.ContactUsWebView]: { url: string; product: ContactProduct };
};

const contactUsHeaderOptions = ({
  route,
}: {
  route: RouteProp<
    AppStackHelpRouteParams,
    typeof HelpScreenNames.ContactUsBuffer
  >;
  navigation: AppStackNavigation;
}) => ({
  headerShown: true,
  header: (props: NativeStackHeaderProps) => (
    <TopAppBarManga
      {...props}
      options={{
        title:
          route.params.product === 'Direct wealth pension'
            ? 'Pension'
            : route.params.product,
      }}
    />
  ),
});

export const HelpScreens = () => {
  return (
    <>
      <MainAppStack.Group
        screenOptions={{ header: TopAppBarManga, headerShown: true }}
      >
        <MainAppStack.Screen
          name={HelpScreenNames.Help}
          getComponent={() =>
            require('@src/features/help/help-screen').HelpScreen
          }
        />
        <MainAppStack.Screen
          name={HelpScreenNames.ContactUs}
          getComponent={() =>
            require('@src/features/contact-us/contact-us-screen')
              .ContactUsScreen
          }
        />
        <MainAppStack.Screen
          name={HelpScreenNames.AppFaqs}
          getComponent={() =>
            require('@src/features/app-faqs/app-faqs-screen').AppFaqsScreen
          }
        />
        <MainAppStack.Screen
          name={HelpScreenNames.TermsOfUse}
          getComponent={() => require('@src/features').TermsOfUseScreen}
          options={{
            title: 'Terms of use',
          }}
        />
        <MainAppStack.Screen
          name={HelpScreenNames.PrivacyNotice}
          getComponent={() => require('@src/features').PrivacyNoticeScreen}
          options={{
            title: 'Privacy Notice',
          }}
        />
      </MainAppStack.Group>
      <MainAppStack.Group
        screenOptions={{
          header: AvivaWebViewTopAppBar,
          headerShown: true,
        }}
      >
        <MainAppStack.Screen
          name={HelpScreenNames.PrivacyPolicy}
          getComponent={() => require('@src/features').PrivacyPolicyScreen}
        />
        <MainAppStack.Screen
          name={HelpScreenNames.CookiePolicy}
          getComponent={() => require('@src/features').CookiePolicyScreen}
        />

        <MainAppStack.Screen
          name={HelpScreenNames.AvivaCoUk}
          getComponent={() => require('@src/features').AvivaCoUkScreen}
        />
        <MainAppStack.Screen
          name={HelpScreenNames.ContactUsWebView}
          getComponent={() => require('@src/features').ContactUsWebViewScreen}
          options={() => ({
            title: 'Contact Us',
          })}
        />
      </MainAppStack.Group>
      <MainAppStack.Screen
        name={HelpScreenNames.IcoOrgUk}
        getComponent={() => require('@src/features').IcoOrgUkScreen}
        options={{
          headerShown: true,
          header: (props: TopAppBarMangaProps) =>
            topAppHeader({ webView: true, textLabel: 'ico.org.uk', ...props }),
        }}
      />
      <MainAppStack.Screen
        name={HelpScreenNames.ContactUsBuffer}
        getComponent={() => require('@src/features').GenericScreen}
        options={contactUsHeaderOptions}
      />
    </>
  );
};
