import { TopAppBarManga } from '@aviva/ion-mobile';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { OfferDetail } from '@src/features/offers/components/offer-buffer/offer-details-type';
import {
  Offer,
  OfferDetailExtendedCriteria,
} from '@src/validation/schemas/offers';

import { MainAppStack } from './main-app-stack';

export type AppStackOffersRouteParams = {
  ['Offers']: undefined;
  ['RetrieveQuoteWeb']: undefined;
  ['Offer Buffer']: {
    offer: Offer;
    fromSummary?: boolean;
    isBackTitleVisible?: boolean;
  };
  ['Extended Cover Options']: {
    offerExtendedCoverOptions: OfferDetail;
    offerTitle: string;
  };
  ['Extended Criteria']: {
    extendedCriteria: OfferDetailExtendedCriteria;
    offerTitle: string;
  };
  ['Offer Web Journey']: { uri: string; isDeepLink?: boolean };
};

export const OffersScreens = () => {
  return (
    <MainAppStack.Group
      screenOptions={() => ({
        headerShown: true,
      })}
    >
      <MainAppStack.Screen
        name="RetrieveQuoteWeb"
        getComponent={() => require('@src/features').RetrieveQuoteWebScreen}
        options={{
          header: topBarManga,
          headerShown: true,
        }}
      />
      <MainAppStack.Screen
        name="Offer Buffer"
        getComponent={() =>
          require('@src/features/offers/components/offer-buffer/offer-buffer-screen')
            .OfferBufferScreen
        }
        options={({ route }) => ({
          title: 'Offer',
          headerBackTitleVisible: route.params?.isBackTitleVisible,
        })}
      />
      <MainAppStack.Screen
        name="Extended Cover Options"
        getComponent={() =>
          require('@src/features/offers/extended-cover-options-screen')
            .ExtendedCoverOptionsScreen
        }
        options={{ title: 'Offer' }}
      />
      <MainAppStack.Screen
        name="Extended Criteria"
        getComponent={() =>
          require('@src/features/offers/extended-criteria-screen')
            .ExtendedCriteriaScreen
        }
        options={{ title: 'Eligibility criteria' }}
      />
      <MainAppStack.Screen
        name="Offer Web Journey"
        getComponent={() =>
          require('@src/features/offers/offer-web-journey-screen')
            .OfferWebJourneyScreen
        }
        options={{
          header: topBarManga,
        }}
      />
    </MainAppStack.Group>
  );
};

const topBarManga = (props: NativeStackHeaderProps) => (
  <TopAppBarManga webView textLabel="aviva.co.uk" {...props} />
);
