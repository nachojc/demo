import { useAuth } from '@hooks/use-auth';
import { useCheckDeviceNotificationPermissions } from '@hooks/use-notifications';
import { usePushNotificationHandler } from '@hooks/use-push-notification-handler';
import { usePushNotificationListeners } from '@hooks/use-push-notification-listeners';
import { NavigatorScreenParams } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AuthContextType } from '@src/common/providers/auth';
import { UserInactivityProvider } from '@src/common/providers/user-inactivity/user-inactivity';

import { AppStackRouteParams } from './app';
import { AuthStackRouteParams } from './auth';

export type RootStackParamList = {
  app: NavigatorScreenParams<AppStackRouteParams>;
  auth: NavigatorScreenParams<AuthStackRouteParams>;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

const useNavigationViewModel = (): Pick<AuthContextType, 'isSignedIn'> => {
  const { isSignedIn } = useAuth();

  return { isSignedIn };
};

export const Navigation = () => {
  useCheckDeviceNotificationPermissions();
  const { isSignedIn } = useNavigationViewModel();
  const { remoteMessage } = usePushNotificationListeners();

  usePushNotificationHandler(remoteMessage);

  return (
    <UserInactivityProvider>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isSignedIn ? (
          <Stack.Screen
            name="app"
            getComponent={() => require('./app').AppStack}
          />
        ) : (
          <Stack.Screen
            name="auth"
            getComponent={() => require('./auth').AuthStack}
          />
        )}
      </Stack.Navigator>
    </UserInactivityProvider>
  );
};
