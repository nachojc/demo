import {
  CloseButton,
  getTokens,
  getVariableValue,
  TopAppBarDW,
  TopAppBarManga,
  TopAppBarMangaProps,
  TopAppBarProps,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useAuth } from '@hooks/use-auth';
import { isManga } from '@hooks/use-expo-config';
import { useMfa } from '@hooks/use-mfa';
import {
  dwOnboardingComplete,
  myAvivaOnboardingComplete,
} from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import { FeatureFlags } from '@src/feature-flags';
import { WebViewScreen } from '@src/features';
import {
  ACTION_CLOSE_CLICKED_ERROR_SCREEN,
  ACTION_CLOSE_CLICKED_MOBILE_ENTRY_SCREEN,
  ACTION_CLOSE_CLICKED_NEED_HELP_SCREEN,
  ACTION_CLOSE_CLICKED_PROMPT_SCREEN,
  ACTION_CLOSE_CLICKED_SUCCESS_SCREEN,
  ACTION_CLOSE_CLICKED_VERIFICATION_CODE_ENTRY_SCREEN,
} from '@src/features/mfa/analytics';
import { Credentials } from '@src/validation/schemas/credentials';
import { useTranslation } from 'react-i18next';

import { WebViewParams } from '../types';

export type PolicyRouteParams = {
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  postcode: string;
  offers: boolean;
  username: string;
  password: string;
};

export type NewPassword = {
  newPassword: string;
};

export type HasRecoveredUsername = {
  hasRecoveredUsername: boolean;
};

export type ShouldNotAutoSignIn = {
  shouldNotAutoSignIn: boolean;
};

export type Timeout = {
  /**
   * When passed as a param to the log-in screen, renders with a DialogTimeout component
   * autoSignIn then only occurs when this dialog is dismissed
   * */
  isTimeout: boolean;
};

type SetNewPasswordScreenParams = {
  ActivationCode: string;
  token?: string;
  HOSTNAME?: string;
  URL?: string;
  appname?: string;
};

type ForgottenDetailsMfaScreenParams = {
  ActivationCode: string;
};

export type AuthStackRouteParams = {
  ['Welcome']: undefined;
  ['Register']: { regcodeskip: string | undefined };
  ['DirectWealth Onboarding']: undefined;
  ['MyAviva Onboarding']: undefined;
  ['Log in']?:
    | NewPassword
    | Credentials
    | Timeout
    | HasRecoveredUsername
    | ShouldNotAutoSignIn;
  ['Log in - MFA']: undefined;
  ['Log in - MFA Need Help']: undefined;
  ['Forgotten your details']: undefined;
  ['Recover Username']: undefined;
  ['Recover Username Success']: undefined;
  ['Reset Password Email Sent']: {
    formValues: { username: string; dateOfBirth: string };
  };
  ['Set New Password']: SetNewPasswordScreenParams;
  ['Forgotten Details - MFA']: ForgottenDetailsMfaScreenParams;
  ['Forgotten Details - MFA Need Help']: undefined;
  ['Logged out']: undefined;
  ['Create an account']: { activationCode: string };
  ['Help Registration']: undefined;
  ['Find Policy']: PolicyRouteParams;
  ['Registration']: undefined;
  ['About yourself']: { username: string; password: string; offers: boolean };
  ['Dev Mode']: undefined;
  ['Account Locked']: undefined;
  ['Account locked fraud']: undefined;
  ['Portcullis']: { pageTag: string; actionTag: string };
  ['Allow notifications']: undefined;
  ['Enable Biometric']: undefined;
  ['Deceased customer']: undefined;
  ['Mfa - Activation Intro']: undefined;
  ['Mfa - Activation Step 1']: undefined;
  ['Mfa - Activation Step 2']: { securityPhoneNumber: string };
  ['Mfa - Success']: undefined;
  ['Mfa - Help']: undefined;
  ['Mfa - Activation Error']: undefined;
  ['Terms of Use']: undefined;
  ['Privacy Notice']: undefined;
  ['Cookie Policy']: undefined;
  ['Ico Org Uk']: undefined;
  ['Aviva Co Uk']: undefined;
  ['Privacy Policy']: undefined;
  ['Web View']: WebViewParams;
};
export type AuthStackScreenNames = keyof AuthStackRouteParams;

const Stack = createNativeStackNavigator<AuthStackRouteParams>();

const screenActionMap: Partial<Record<AuthStackScreenNames, string>> = {
  'Mfa - Activation Intro': ACTION_CLOSE_CLICKED_PROMPT_SCREEN,
  'Mfa - Activation Step 1': ACTION_CLOSE_CLICKED_MOBILE_ENTRY_SCREEN,
  'Mfa - Activation Step 2':
    ACTION_CLOSE_CLICKED_VERIFICATION_CODE_ENTRY_SCREEN,
  'Mfa - Activation Error': ACTION_CLOSE_CLICKED_ERROR_SCREEN,
  'Mfa - Help': ACTION_CLOSE_CLICKED_NEED_HELP_SCREEN,
  'Mfa - Success': ACTION_CLOSE_CLICKED_SUCCESS_SCREEN,
};

type CloseIconProps = {
  onPress?: () => void;
};

const CloseIcon = ({ onPress }: CloseIconProps) => {
  const { dismissMfaPrompt } = useMfa();
  const tokens = getTokens();
  return (
    <CloseButton
      onPress={onPress ?? dismissMfaPrompt}
      iconProps={{
        color: getVariableValue(tokens.color.Secondary800),
        width: getVariableValue(tokens.size['4']),
        height: getVariableValue(tokens.size['4']),
      }}
    />
  );
};

type MfaTopAppBarProps = TopAppBarMangaProps & {
  shouldDismissMfaPrompt?: boolean;
};

const MfaTopAppBar = (props: MfaTopAppBarProps) => {
  const { dismissMfaPrompt } = useMfa();
  const analytics = useAnalytics();
  const screenName = (props.route?.name ?? '') as AuthStackScreenNames;
  const action = screenActionMap[screenName];

  const closeAction = () => {
    if (action) {
      analytics.trackUserEvent(action);
    } else {
      console.log('Analytics tag not registered');
    }
    if (props.shouldDismissMfaPrompt) {
      dismissMfaPrompt();
    } else {
      props.navigation?.goBack();
    }
  };

  return (
    <TopAppBarManga
      actionIcons={[<CloseIcon key="close" onPress={closeAction} />]}
      {...props}
    />
  );
};

export const AuthStack = () => {
  const { t } = useTranslation();
  const { hasSignedInThisSession, hasSetUsername } = useAuth();
  const isDwOnboardingComplete = useSelector(dwOnboardingComplete);
  const isMyAvivaOnboardingComplete = useSelector(myAvivaOnboardingComplete);
  const isDwEOL = useSelector(FeatureFlags.dwEOLEnabled);

  if (
    //TODO: This will need to be moved as part of the 'Great DW & MANGA merge'
    !isManga() &&
    !hasSignedInThisSession &&
    !isDwOnboardingComplete &&
    !isDwEOL
  ) {
    return (
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen
          name="DirectWealth Onboarding"
          getComponent={() =>
            require('../../../products/direct-wealth/features/onboarding/onboarding-carousel')
              .DwOnboardingScreen
          }
        />
      </Stack.Navigator>
    );
  } else if (
    isManga() &&
    !hasSignedInThisSession &&
    !isMyAvivaOnboardingComplete
  ) {
    return (
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen
          name="MyAviva Onboarding"
          getComponent={() =>
            require('@src/features/onboarding/onboarding-carousel')
              .MyAvivaOnboardingScreen
          }
        />
      </Stack.Navigator>
    );
  }

  const getInitialRouteName = (): keyof AuthStackRouteParams => {
    if (hasSignedInThisSession) {
      return 'Logged out';
    }

    if (hasSetUsername) {
      return 'Log in';
    }

    return 'Welcome';
  };

  return (
    <Stack.Navigator
      screenOptions={{
        header: (props: MfaTopAppBarProps) =>
          mangaHeader({ showDevMode: true, ...props }),
      }}
      initialRouteName={getInitialRouteName()}
    >
      <Stack.Screen
        name="Welcome"
        getComponent={() => require('@src/features').WelcomeScreen}
        options={{ title: '' }}
      />
      {/*
       * When DW is EOL the Log In screen specifically is disabled, and replaced with the EOL
       * Due to behaviour with the header we are overriding the component for "Log in"
       * */}
      {!isManga() && isDwEOL ? (
        <Stack.Screen
          name="Log in"
          getComponent={() =>
            require('@direct-wealth/features/end-of-life/end-of-life-screen')
              .EndOfLifeScreen
          }
          options={{
            header: (props: TopAppBarProps) =>
              topHeader({
                ...props,
                textLabel: '',
                showDevMode: true,
                theme: 'dwEndOfLife',
                back: undefined,
              }),
          }}
        />
      ) : (
        <Stack.Screen
          name="Log in"
          getComponent={() => require('@src/features').LoginScreen}
          options={{
            title: 'Log in',
            header: (props: MfaTopAppBarProps) =>
              mangaHeader({
                ...props,
                back: hasSetUsername ? undefined : { title: 'Welcome' },
                showDevMode: true,
              }),
          }}
        />
      )}
      <Stack.Screen
        name="Log in - MFA"
        options={{ title: 'Log in' }}
        getComponent={() => require('@src/features').LoginWithMfaScreen}
      />
      <Stack.Screen
        options={{
          headerShown: false,
        }}
        name="Log in - MFA Need Help"
        getComponent={() => require('@src/features').NeedHelpMfaLoginScreen}
      />
      <Stack.Screen
        name="Account Locked"
        options={{
          title: 'Log in',
          header: (props: TopAppBarProps) =>
            topHeader({ ...props, back: undefined }),
        }}
        getComponent={() => require('@src/features').AccountLockedScreen}
      />
      <Stack.Screen
        name="Deceased customer"
        options={{
          title: '',
        }}
        getComponent={() => require('@src/features').DeceasedCustomerScreen}
      />
      <Stack.Screen
        name="Forgotten your details"
        getComponent={() => require('@src/features').ForgottenDetailsScreen}
        options={{ title: t('navTitles.forgottenDetails') }}
      />
      <Stack.Screen
        options={{ title: t('navTitles.forgottenDetails') }}
        name="Reset Password Email Sent"
        getComponent={() =>
          require('@src/features').ResetPasswordEmailSentScreen
        }
      />
      <Stack.Screen
        name="Privacy Policy"
        getComponent={() => require('@src/features').PrivacyPolicyScreen}
        options={{
          header: AvivaWebViewTopAppBar,
        }}
      />
      <Stack.Screen
        name="Cookie Policy"
        getComponent={() => require('@src/features').CookiePolicyScreen}
        options={{
          header: AvivaWebViewTopAppBar,
        }}
      />
      <Stack.Screen
        name="Privacy Notice"
        getComponent={() => require('@src/features').PrivacyNoticeScreen}
      />
      <Stack.Screen
        name="Aviva Co Uk"
        getComponent={() => require('@src/features').AvivaCoUkScreen}
        options={{
          header: AvivaWebViewTopAppBar,
          title: 'aviva.co.uk',
        }}
      />
      <Stack.Screen
        name="Ico Org Uk"
        getComponent={() => require('@src/features').IcoOrgUkScreen}
        options={{
          title: 'ico.org.uk',
          header: AvivaWebViewTopAppBar,
        }}
      />
      <Stack.Screen
        name="Terms of Use"
        getComponent={() => require('@src/features').TermsOfUseScreen}
        options={{
          title: 'Terms of use',
        }}
      />
      <Stack.Screen
        name="Create an account"
        getComponent={() => require('@src/features').CreateAccountScreen}
      />
      {hasSignedInThisSession && (
        <Stack.Screen
          options={{
            header: (props: MfaTopAppBarProps) =>
              mangaHeader({
                ...props,
                showDevMode: true,
                image: require('assets/aviva-inline/aviva-inline.png'),
              }),
          }}
          name="Logged out"
          getComponent={() => require('@src/features').LoggedOutScreen}
        />
      )}
      <Stack.Screen
        name="Register"
        getComponent={() => require('@src/features').ActivationCodeScreen}
      />
      <Stack.Screen
        name="Help Registration"
        getComponent={() => require('@src/features').HelpRegistrationScreen}
        options={{
          title: 'Help',
        }}
      />
      <Stack.Screen
        name="Registration"
        getComponent={() => require('@src/features').SetUpAccountScreen}
      />
      <Stack.Screen
        name="Find Policy"
        getComponent={() => require('@src/features').FindPolicyScreen}
        options={{
          title: 'Registration',
        }}
      />
      <Stack.Screen
        name="About yourself"
        getComponent={() => require('@src/features').AboutYourselfScreen}
        options={{
          title: 'Tell us about yourself',
        }}
      />
      <Stack.Screen
        options={{ title: t('navTitles.forgottenDetails') }}
        name="Set New Password"
        getComponent={() => require('@src/features').SetNewPasswordScreen}
      />
      <Stack.Screen
        options={{ title: t('navTitles.forgottenDetails') }}
        name="Forgotten Details - MFA"
        getComponent={() => require('@src/features').ForgottenDetailsMfaScreen}
      />
      <Stack.Screen
        options={{
          headerShown: false,
        }}
        name="Forgotten Details - MFA Need Help"
        getComponent={() =>
          require('@src/features').NeedHelpMfaForgottenDetailsScreen
        }
      />
      <Stack.Screen
        options={{ title: t('navTitles.forgottenUsername') }}
        name="Recover Username"
        getComponent={() => require('@src/features').RecoverUsernameScreen}
      />
      <Stack.Screen
        name="Account locked fraud"
        getComponent={() => require('@src/features').AccountLockedFraudScreen}
        options={{ title: 'Log in' }}
      />

      <Stack.Screen
        options={{ headerShown: false }}
        name="Recover Username Success"
        getComponent={() =>
          require('@src/features').RecoverUsernameSuccessScreen
        }
      />
      <Stack.Screen
        name="Dev Mode"
        getComponent={() => require('@src/navigation/dev-mode').DevModeStack}
        options={{
          headerShown: false,
        }}
      />
      <Stack.Screen
        name="Allow notifications"
        getComponent={() => require('@src/features').AllowNotificationsScreen}
        options={{
          header: (props: MfaTopAppBarProps) =>
            mangaHeader({ ...props, back: undefined }),
          gestureEnabled: false,
        }}
      />
      <Stack.Screen
        name="Enable Biometric"
        getComponent={() => require('@src/features').EnableBiometricScreen}
        options={{
          title: 'Enable biometric login',
          header: (props: MfaTopAppBarProps) =>
            mangaHeader({ ...props, back: undefined }),
          gestureEnabled: false,
        }}
      />
      <Stack.Screen
        name="Portcullis"
        getComponent={() => require('@src/features').PortcullisScreen}
        options={{
          headerShown: false,
          presentation: 'fullScreenModal',
        }}
      />
      <Stack.Screen
        options={{
          title: 'Set up two-step verification',
          header: (props: MfaTopAppBarProps) =>
            mfaHeader({ ...props, shouldDismissMfaPrompt: true }),
        }}
        name="Mfa - Activation Intro"
        getComponent={() =>
          require('@src/features').MfaActivationSetupIntroScreen
        }
      />
      <Stack.Screen
        options={{
          title: 'Set up two-step verification',
        }}
        name="Mfa - Activation Step 1"
        getComponent={() => require('@src/features').MfaAvticationStepOneScreen}
      />
      <Stack.Screen
        options={{
          title: 'Set up two-step verification',
        }}
        name="Mfa - Activation Step 2"
        getComponent={() =>
          require('@src/features').MfaActivationSetupStepTwoScreen
        }
      />
      <Stack.Screen
        options={{
          title: 'Set up two-step verification',
          header: (props: MfaTopAppBarProps) =>
            mfaHeader({
              ...props,
              shouldDismissMfaPrompt: true,
              back: undefined,
            }),
          gestureEnabled: false,
        }}
        name="Mfa - Success"
        getComponent={() => require('@src/features').MfaSuccessScreen}
      />
      <Stack.Screen
        options={{
          title: 'Need help?',
          header: (props: MfaTopAppBarProps) =>
            mfaHeader({ ...props, shouldDismissMfaPrompt: false }),
        }}
        name="Mfa - Help"
        getComponent={() => require('@src/features').MfaHelpScreen}
      />
      <Stack.Screen
        options={{
          title: 'Set up two-step verification',
          header: (props: MfaTopAppBarProps) =>
            mfaHeader({ ...props, shouldDismissMfaPrompt: true }),
        }}
        name="Mfa - Activation Error"
        getComponent={() => require('@src/features').MfaErrorScreen}
      />
      <Stack.Screen
        name={'Web View'}
        component={WebViewScreen}
        options={({ route }) => ({
          header: AvivaWebViewTopAppBar,
          title: route?.params?.title ?? undefined,
        })}
      />
    </Stack.Navigator>
  );
};

const topHeader = (props: TopAppBarProps) => <TopAppBarDW {...props} />;

const mangaHeader = (props: MfaTopAppBarProps) => <TopAppBarManga {...props} />;

const mfaHeader = (props: MfaTopAppBarProps) => <MfaTopAppBar {...props} />;
