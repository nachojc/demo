import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { AuthStackRouteParams } from '@src/navigation/auth';

import { RootStackParamList } from '..';
import { AuthStackScreenNames } from './index';

export type AuthStackNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<AuthStackRouteParams>,
  NativeStackNavigationProp<RootStackParamList>
>;

export type AuthStackRoute<T extends keyof AuthStackRouteParams> = RouteProp<
  AuthStackRouteParams,
  T
>;

/**
 * @description A typed wrapper around useRoute
 *
 * @T
 * T is the name of the screen from which you're calling this hook
 * It must be a key of BottomTabsRouteParams
 */
export function useAuthStackRoute<T extends AuthStackScreenNames>() {
  return useRoute<AuthStackRoute<T>>();
}

/**
 * @description A typed wrapper around useNavigation
 *
 * For use within the Auth navigation stack
 */
export function useAuthStackNavigation() {
  return useNavigation<AuthStackNavigation>();
}
