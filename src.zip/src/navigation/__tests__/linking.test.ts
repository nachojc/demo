import { renderHook, waitFor } from '@src/jest/testing-library';
import { AuthStackRouteNames } from '@constants/route-names/auth-stack-routes';
import { config } from '@src/common/config';
import { Platform } from 'react-native';

import { FIND_AND_COMBINE, SIPP_TRANSFER } from '../app/direct-wealth-screens';

const mockOpenUrl = jest.fn();
const url = 'https://openlink.com';
config.BASE_URL.set(url);

const mockUseUrl = jest.fn();
jest.mock<typeof import('expo-linking')>('expo-linking', () => ({
  ...jest.requireActual('expo-linking'),
  createURL: jest.fn(),
  useURL: mockUseUrl,
  openURL: mockOpenUrl,
}));

const {
  getLinkingConfig,
  getStateFromPath,
  SavedDeepLink,
  UnhandledUniversalLink,
  useUnhandledUniversalLink,
} = require('../linking');

let mockIsManga = false;
jest.mock('@hooks/use-expo-config', () => ({
  ...jest.requireActual('@hooks/use-expo-config'),
  isManga: () => mockIsManga,
  getAppID: () => 'co.uk.aviva.myaviva',
}));

const tokenWithMfa =
  'eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiJvYXV0aC10b2tlbi0zZGZhYzM1ZC00M2ZhLTQ2OGEtYWNjZi1jZDkwMjE2MWI4Y2UiLCJpYXQiOjE2MzAzOTg2MzMsInN1YiI6IntkZWNyeXB0fVZndE9ObUx4SkZqVnk5UEEvc0JabFlJb3VFOUp0YTQxREV5bnZKV3Zham89Iiwic2NwIjoibWZhX2dlbmVyYXRlLG1mYV9yZXNldF92ZXJpZnkiLCJjaWQiOiJ7ZGVjcnlwdH1vTVo2S1hZeFYvcXpuOWtyNFYyd2JZdm9uNjNGZlhzRlB1a1IwZVVrY2FZY0FnY3pLeHhPclI2N1dGbEpTRCtlIiwiaXNzIjoiaHR0cHM6Ly9kaXJlY3Qucnd5LWF2aXZhLmNvLnVrIiwiaXZfZ3JvdXBzIjoie2RlY3J5cHR9T0xLMVpzZy9qTEV0ZlRvcUZuT0V5VWVtbGRHVklqNjNxais4dUpJUHVpKzlEUlZzdlpQNmIxdGk5dUxnL2FrZyIsInVzZXJuYW1lIjoie2RlY3J5cHR9d3dJYU5kdDlETDcyb3lUMkZaRUh3Y01Wd0REc2FSTmdCcWwyazluNCtLbGRDSit4dUhMTFltZU55SkJNOXBqSyIsImV4cCI6MTYzMTAwMzQzM30.TtnsvS5wU3kLWUSTVi-s6y0A4ETuJ-FgqhNscZKP_JhilJAthmGPO3J5QYRqOlzcDlJha2OTvrpZICRw6kZ5HF6neq2k-4Tfkb0qxjHE5Hd0lNhG9t2PgJ7xGDSSjhysLNZ7Jmau8CQnDRTExgN0ExbJck2fzmwkkcIZCl92Uxg9vHDNlsXU94SUG3yxmwmrbsQ-a0vaMJoZPJYdBRsALrNbhl6UDOWfw4peZGTqSNw-cm4GQCGCCVFOxSqyOqglytR3w3HPDYd-4WFnnoRJL5bdpyFrzRHK96w4Gm9K-XNC9Gp4DX4GDqGIqBtIgnk_loB8Yf3Spg8vrZFrJ9IabA';
const tokenWithoutMfa =
  'eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiJvYXV0aC10b2tlbi1iM2Q4NDZhOC0zOGZlLTQ0OTAtODk1Yy0wMDZhMzlmNWE3YzgiLCJpYXQiOjE1OTc5OTk4OTcsInN1YiI6IntkZWNyeXB0fWpSbjJ0MDVEMEZwSDlBa2Z3cGhoR1FoSEJidkwxVnhoS3Z4ZDNnRURqbk09Iiwic2NwIjoiZGlnX3VwZGF0ZTpyZXNldCIsImNpZCI6IntkZWNyeXB0fW9NWjZLWFl4Vi9xem45a3I0VjJ3Yll2b242M0ZmWHNGUHVrUjBlVWtjYVljQWdjekt4eE9yUjY3V0ZsSlNEK2UiLCJpc3MiOiJodHRwczovL2RpcmVjdC5zeXMtYXZpdmEuY28udWsiLCJpdl9ncm91cHMiOiJ7ZGVjcnlwdH1PTEsxWnNnL2pMRXRmVG9xRm5PRXlVZW1sZEdWSWo2M3FqKzh1SklQdWkrOURSVnN2WlA2YjF0aTl1TGcvYWtnIiwidXNlcm5hbWUiOiJ7ZGVjcnlwdH16b0EyUUJzNnFuNkZGNDJ6Z3RUc0JZNU92V3hVeHJ4VmNLYk1lWm5LUkhnPSIsImV4cCI6MTU5ODA4NjI5N30.UU8CE0nVh2mDzOcqzzwN81DuEGPsNCzEQg3nh3JRkZ0hndzZCReN4c_QEDbtwyvdmIcrwQnYhbEsf3KnknnybHKDMqFHJhxky4f7StLkTbds17QztNi6h_A7ZXzSIFZj-pQXnOu9D0tjnHkSA2W2n3pTjA8SgRhgXjZh5ZHGctmoFzuBJ2GPQPoq-Pd6FuDx3wIgdM9I8N9fqNNHFuzbP2lKFXNoPY2U1cD4Ig6iyhlKKvEZCqI3Y0HW8H1VskV8lalAa-K3-6uD5OZl9oH4coNEuRriowOn5sa4XHq3T2H10oitt6EZb5VWjvYx_a518kd3x1ZJjdCKHhfuv57lrw';
const invalidToken = 'invalid_jwt';

const code = 'WWl2aGk5R21IZFN6ZnFQS0NOWnd0WG9ZbkNyT2NUR1RiN2o0M0dHR3lFcz0=';
const redirectURL = 'about:blank';

const validUrlWithMfa =
  'https://direct.stg-aviva.co.uk/access/preactivation.do?ActivationCode=' +
  code +
  '&token=' +
  tokenWithMfa +
  '&HOSTNAME=https://direct.stg-aviva.co.uk&URL=%2F';

const validUrlWithoutMfa =
  'https://direct.stg-aviva.co.uk/access/preactivation.do?ActivationCode=' +
  code +
  '&token=' +
  tokenWithoutMfa +
  '&HOSTNAME=https://direct.stg-aviva.co.uk&URL=%2F';

const invalidUrl =
  'https://direct.stg-aviva.co.uk/access/preactivation.do?ActivationCode=' +
  code +
  '&token=' +
  invalidToken +
  '&HOSTNAME=https://direct.stg-aviva.co.uk&URL=' +
  redirectURL;

//Base URL not needed here as the OS strips them when passing them to the app, so we append it manually in code.
const urlWithMissingActivationCode =
  '/access/preactivation.do?ActivationCode=' +
  '' +
  '&token=' +
  tokenWithoutMfa +
  '&HOSTNAME=https://direct.stg-aviva.co.uk&URL=' +
  redirectURL;

//Base URL not needed here as the OS strips them when passing them to the app, so we append it manually in code.
const urlWithMissingToken =
  '/access/preactivation.do?ActivationCode=' +
  code +
  '&token=' +
  '' +
  '&HOSTNAME=https://direct.stg-aviva.co.uk&URL=' +
  redirectURL;

const validUrlWithoutQueryParams =
  'https://direct1.rwy-aviva.co.uk/access/preactivation.do';

const regCodeSkip = 'FST1234JED';

const validUrlWithFastTrack =
  'https://direct.stg-aviva.co.uk/MyAccount/Create/Step1?regcodeskip=' +
  regCodeSkip;

const marketingLinkUrl =
  'https://www.direct.aviva.co.uk/app-login?source=MANG&cmp=eml-mul-mva--mang';

const productdashboardState = {
  routes: [
    {
      name: 'app',
      state: {
        routes: [
          { name: 'Bottom tabs' },
          {
            name: 'ProductDashboard',
            params: { securePolicyNumber: '123' },
          },
        ],
      },
    },
  ],
};

const pcsdashboardState = {
  routes: [
    {
      name: 'app',
      state: {
        routes: [
          { name: 'Bottom tabs' },
          {
            name: 'PCS Dashboard',
          },
        ],
      },
    },
  ],
};

const linkingAlertStateSipp = {
  routes: [
    {
      name: 'app',
      state: {
        routes: [{ name: 'SIPP Transfer' }, { name: 'LinkingAlertScreen' }],
      },
    },
  ],
};

const linkingAlertStateFindAndCombine = {
  routes: [
    {
      name: 'app',
      state: {
        routes: [{ name: 'Find And Combine' }, { name: 'LinkingAlertScreen' }],
      },
    },
  ],
};

const marketingLinkState = {
  routes: [
    {
      name: 'auth',
      state: {
        routes: [
          {
            name: 'Log in',
            path: '/app-login',
            params: { source: 'MANG', cmp: 'eml-mul-mva--mang' },
          },
        ],
      },
    },
  ],
};

const mockSippRef = {
  current: {
    routes: [
      {
        state: {
          routes: [
            {
              name: SIPP_TRANSFER,
            },
          ],
        },
      },
    ],
  },
};

const mockFindAndCombineRef = {
  current: {
    routes: [
      {
        state: {
          routes: [
            {
              name: FIND_AND_COMBINE,
            },
          ],
        },
      },
    ],
  },
};

const validProductDashBoardUrl = 'productdashboard/123';
const validPCSDashBoardUrl = 'pcsdashboard';

beforeEach(() => {
  mockIsManga = false;
  Platform.OS = 'ios';
  mockOpenUrl.mockReset();
});

describe('getLinkingConfig', () => {
  it('should return correct prefixes when on android and on DW app', () => {
    Platform.OS = 'android';
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    const config = getLinkingConfig(false, undefined);
    expect(config.prefixes.includes('directwealth://')).toBe(true);
  });
  it('should return correct prefixes when on MANGA', () => {
    mockIsManga = true;
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    const config = getLinkingConfig(false, undefined);
    expect(config.prefixes.includes('directwealth://')).toBe(false);
  });
});

describe('getStateFromPath', () => {
  it('should return the correct state for a valid url with mfa', async () => {
    const state = getStateFromPath(false, undefined, validUrlWithMfa);

    expect(state).toEqual({
      routes: [
        {
          name: 'auth',
          state: {
            routes: [
              {
                name: AuthStackRouteNames.FORGOTTEN_DETAILS_MFA,
                params: {
                  ActivationCode: code,
                  HOSTNAME: 'https://direct.stg-aviva.co.uk',
                  URL: '/',
                  token: tokenWithMfa,
                },
              },
            ],
          },
        },
      ],
    });
  });

  it('should return the correct state for a valid url with fast track', async () => {
    const state = getStateFromPath(false, undefined, validUrlWithFastTrack);

    expect(state).toEqual({
      routes: [
        {
          name: 'auth',
          state: {
            routes: [
              {
                name: AuthStackRouteNames.REGISTER,
                params: {
                  regcodeskip: regCodeSkip,
                },
              },
            ],
          },
        },
      ],
    });
  });

  it('should return the correct state for a valid url without mfa', async () => {
    const state = getStateFromPath(false, undefined, validUrlWithoutMfa);

    expect(state).toEqual({
      routes: [
        {
          name: 'auth',
          state: {
            routes: [
              {
                name: AuthStackRouteNames.SET_NEW_PASSWORD,
                params: {
                  ActivationCode: code,
                  HOSTNAME: 'https://direct.stg-aviva.co.uk',
                  URL: '/',
                  token: tokenWithoutMfa,
                },
              },
            ],
          },
        },
      ],
    });
  });

  it('should return the correct state for a valid url without activation code', async () => {
    const state = getStateFromPath(
      false,
      undefined,
      urlWithMissingActivationCode
    );

    expect(state).toEqual({
      routes: [
        {
          name: 'auth',
          state: {
            routes: [
              {
                name: AuthStackRouteNames.LOG_IN,
                params: {
                  shouldNotAutoSignIn: true,
                },
              },
              {
                name: 'Web View',
                params: {
                  url: 'https://openlink.com/access/preactivation.do?ActivationCode=&token=eyJhbGciOiJSUzI1NiJ9.eyJqdGkiOiJvYXV0aC10b2tlbi1iM2Q4NDZhOC0zOGZlLTQ0OTAtODk1Yy0wMDZhMzlmNWE3YzgiLCJpYXQiOjE1OTc5OTk4OTcsInN1YiI6IntkZWNyeXB0fWpSbjJ0MDVEMEZwSDlBa2Z3cGhoR1FoSEJidkwxVnhoS3Z4ZDNnRURqbk09Iiwic2NwIjoiZGlnX3VwZGF0ZTpyZXNldCIsImNpZCI6IntkZWNyeXB0fW9NWjZLWFl4Vi9xem45a3I0VjJ3Yll2b242M0ZmWHNGUHVrUjBlVWtjYVljQWdjekt4eE9yUjY3V0ZsSlNEK2UiLCJpc3MiOiJodHRwczovL2RpcmVjdC5zeXMtYXZpdmEuY28udWsiLCJpdl9ncm91cHMiOiJ7ZGVjcnlwdH1PTEsxWnNnL2pMRXRmVG9xRm5PRXlVZW1sZEdWSWo2M3FqKzh1SklQdWkrOURSVnN2WlA2YjF0aTl1TGcvYWtnIiwidXNlcm5hbWUiOiJ7ZGVjcnlwdH16b0EyUUJzNnFuNkZGNDJ6Z3RUc0JZNU92V3hVeHJ4VmNLYk1lWm5LUkhnPSIsImV4cCI6MTU5ODA4NjI5N30.UU8CE0nVh2mDzOcqzzwN81DuEGPsNCzEQg3nh3JRkZ0hndzZCReN4c_QEDbtwyvdmIcrwQnYhbEsf3KnknnybHKDMqFHJhxky4f7StLkTbds17QztNi6h_A7ZXzSIFZj-pQXnOu9D0tjnHkSA2W2n3pTjA8SgRhgXjZh5ZHGctmoFzuBJ2GPQPoq-Pd6FuDx3wIgdM9I8N9fqNNHFuzbP2lKFXNoPY2U1cD4Ig6iyhlKKvEZCqI3Y0HW8H1VskV8lalAa-K3-6uD5OZl9oH4coNEuRriowOn5sa4XHq3T2H10oitt6EZb5VWjvYx_a518kd3x1ZJjdCKHhfuv57lrw&HOSTNAME=https://direct.stg-aviva.co.uk&URL=about:blank',
                  title: 'aviva.co.uk',
                  ssoEnabled: false,
                },
              },
            ],
          },
        },
      ],
    });
  });

  it('should return the correct state for a valid url without token', async () => {
    const state = getStateFromPath(false, undefined, urlWithMissingToken);

    expect(state).toEqual({
      routes: [
        {
          name: 'auth',
          state: {
            routes: [
              {
                name: AuthStackRouteNames.LOG_IN,
                params: {
                  shouldNotAutoSignIn: true,
                },
              },
              {
                name: 'Web View',
                params: {
                  url: 'https://openlink.com/access/preactivation.do?ActivationCode=WWl2aGk5R21IZFN6ZnFQS0NOWnd0WG9ZbkNyT2NUR1RiN2o0M0dHR3lFcz0=&token=&HOSTNAME=https://direct.stg-aviva.co.uk&URL=about:blank',
                  title: 'aviva.co.uk',
                  ssoEnabled: false,
                },
              },
            ],
          },
        },
      ],
    });
  });

  it('should return the correct state for a valid product dashboard url when user is loggedIn', async () => {
    const state = getStateFromPath(true, undefined, validProductDashBoardUrl);
    expect(state).toEqual(productdashboardState);
  });

  it('should return the correct state and save the correct deeplink for a valid product dashboard url when user is not loggedIn', async () => {
    const state = getStateFromPath(false, undefined, validProductDashBoardUrl);
    expect(state).toEqual({
      routes: [{ name: 'auth', state: { routes: [{ name: 'Log in' }] } }],
    });

    expect(JSON.stringify(SavedDeepLink.get())).toBe(
      JSON.stringify(productdashboardState)
    );
  });

  it('should return the correct state when user is in the middle of SIPP journey', async () => {
    const state = getStateFromPath(true, mockSippRef, validProductDashBoardUrl);

    expect(state).toEqual(linkingAlertStateSipp);
    expect(JSON.stringify(SavedDeepLink.get())).toBe(
      JSON.stringify(productdashboardState)
    );
  });

  it('should return the correct state when user is in the middle of Find and Combine journey', async () => {
    const state = getStateFromPath(
      true,
      mockFindAndCombineRef,
      validProductDashBoardUrl
    );

    expect(state).toEqual(linkingAlertStateFindAndCombine);
    expect(JSON.stringify(SavedDeepLink.get())).toBe(
      JSON.stringify(productdashboardState)
    );
  });

  it('should return the correct state for a valid pcs dashboard url when user is loggedIn', async () => {
    const state = getStateFromPath(true, undefined, validPCSDashBoardUrl);
    expect(state).toEqual(pcsdashboardState);
  });

  it('should return the correct state for a valid marketing link url to app', async () => {
    const { config } = getLinkingConfig(false, undefined);

    const state = getStateFromPath(false, undefined, marketingLinkUrl, config);
    expect(state).toEqual(marketingLinkState);
  });

  it('should set unhandledURL to false, if URL does not contain an activation code', () => {
    getStateFromPath(false, undefined, validUrlWithoutQueryParams);

    expect(UnhandledUniversalLink.get()).toBe(false);
  });

  it('should set UnhandledUniversalLink=false if error occurs', () => {
    getStateFromPath(false, undefined, invalidUrl);

    expect(UnhandledUniversalLink.get()).toBe(false);
  });
});

describe('useUnhandledUniversalLink', () => {
  describe('should call Linking.openUrl', () => {
    it('Given: UnhandledUniversalLink=true, useUrl=url', async () => {
      UnhandledUniversalLink.set(true);
      mockUseUrl.mockReturnValue(url);
      renderHook(useUnhandledUniversalLink);

      await waitFor(() => {
        expect(mockOpenUrl).toHaveBeenCalledWith(url);
      });
      expect(UnhandledUniversalLink.get()).toBe(false);
    });
  });

  describe('should *not* call Linking.openUrl', () => {
    it('Given: UnhandledUniversalLink=true, useUrl=null', async () => {
      UnhandledUniversalLink.set(true);
      mockUseUrl.mockReturnValue(null);
      renderHook(useUnhandledUniversalLink);

      expect(mockOpenUrl).not.toHaveBeenCalled();
      expect(UnhandledUniversalLink.get()).toBe(true);
    });

    it('Given: UnhandledUniversalLink=false, useUrl=url', async () => {
      UnhandledUniversalLink.set(false);
      mockUseUrl.mockReturnValue(url);
      renderHook(useUnhandledUniversalLink);

      expect(mockOpenUrl).not.toHaveBeenCalled();
      expect(UnhandledUniversalLink.get()).toBe(false);
    });
  });
});
