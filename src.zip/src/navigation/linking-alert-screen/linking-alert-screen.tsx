import {
  Button,
  ButtonVariant,
  getTokens,
  getVariableValue,
  Icon,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import { useNavigation } from '@react-navigation/native';
import { useTranslation } from 'react-i18next';

import { SavedDeepLink } from '../linking';

export const LinkingAlertScreen = () => {
  const { reset, goBack } = useNavigation();
  const deepLink = SavedDeepLink.get();
  const tokens = getTokens();
  const { t } = useTranslation(undefined, {
    keyPrefix: 'linking.alert',
  });

  return (
    <YStack
      flex={1}
      ai={'center'}
      jc={'center'}
      backgroundColor={'$Gray900Opacity80'}
    >
      <YStack
        backgroundColor={'$White'}
        padding={'$xl'}
        marginHorizontal={'$xl'}
        borderRadius={5}
      >
        <YStack ai="center">
          <Icon
            accessible={false}
            color={getVariableValue(tokens.color.$Error)}
            name={'alert-circle'}
          />
        </YStack>
        <Text
          fontVariant="heading4-semibold-Secondary800"
          tamaguiTextProps={{
            textAlign: 'center',
            marginTop: '$md',
          }}
        >
          {t('title')}
        </Text>
        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{
            textAlign: 'center',
            marginTop: '$md',
            marginBottom: '$md',
          }}
        >
          {t('description')}
        </Text>
        <YStack marginTop="$xl">
          <Button
            onPress={() => {
              if (deepLink) {
                // eslint-disable-next-line
                // @ts-ignore
                reset(deepLink);
                SavedDeepLink.delete();
                return;
              }
              goBack();
            }}
          >
            {t('yesUnderstand')}
          </Button>
          <Button
            variant={ButtonVariant.LINK_TEXT}
            onPress={() => {
              SavedDeepLink.delete();
              goBack();
            }}
          >
            {t('cancel')}
          </Button>
        </YStack>
      </YStack>
    </YStack>
  );
};
