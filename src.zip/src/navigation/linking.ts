import { AuthStackRouteNames } from '@constants/route-names/auth-stack-routes';
import { isManga } from '@hooks/use-expo-config';
import { getLogger } from '@interfaces/logger';
import { observable } from '@legendapp/state';
import { useSelector } from '@legendapp/state/react';
import {
  getStateFromPath as getStateFromPathDefault,
  LinkingOptions,
  NavigationState,
  PartialRoute,
  Route,
} from '@react-navigation/native';
import { config } from '@src/common/config';
import { formatURL, traverseAndUpdate } from '@src/utils';
import { accessToken } from '@src/utils/api/constants';
import * as Linking from 'expo-linking';
import decodeJwt, { InvalidTokenError } from 'jwt-decode';
import { MutableRefObject, useEffect } from 'react';
import { Platform } from 'react-native';
import { z, ZodError } from 'zod';

import { RootStackParamList } from '.';
import { FIND_AND_COMBINE, SIPP_TRANSFER } from './app/direct-wealth-screens';

const prefix = Linking.createURL('/');
const log = getLogger('linking');
const baseUrl = config.BASE_URL.get();

const DW_PRODUCT_DETAILS_PATH = 'productdashboard';
const DW_PCS_DASHBOARD_PATH = 'pcsdashboard';
const OPEN_APP_PATHS = ['launchapp', 'app-login', ''];

const authenticatedPaths = isManga()
  ? []
  : [DW_PRODUCT_DETAILS_PATH, DW_PCS_DASHBOARD_PATH];
const linkBlockingRoutes = [SIPP_TRANSFER, FIND_AND_COMBINE];

export const SavedDeepLink = observable<GetStateFromPathReturn | undefined>(
  undefined
);

/**
 * This value is a listener for when we unsuccessfully parse an incoming URI
 * If this is set to true, useUnhandledUniversalLink will push the user to web
 */
export const UnhandledUniversalLink = observable<boolean>(false);
export const useUnhandledUniversalLink = () => {
  const url = Linking.useURL();
  const unhandledUniversalLink = useSelector(UnhandledUniversalLink);

  useEffect(() => {
    /**
     * Android doesn't allow opening to browser
     * openUrl will *always* open the app associated
     * https://github.com/facebook/react-native/issues/27486
     */

    if (Platform.OS === 'android') {
      return;
    }

    /**
     *  Linking.useURL starts off as null on first render
     * so we need to navigate once its loaded
     */
    if (url && unhandledUniversalLink) {
      UnhandledUniversalLink.set(false);
      Linking.canOpenURL(url)
        .then(() => Linking.openURL(url))
        .catch(() => log.error(new Error(`Failed to open web: ${url}`)));
    }
  }, [url, unhandledUniversalLink]);
};

export const getLinkingConfig = (
  isSignedIn: boolean,
  navigationStateRef: MutableRefObject<NavigationState | undefined>
): LinkingOptions<RootStackParamList> => {
  const prefixForDWAndroid =
    Platform.OS === 'android' && !isManga() ? ['directwealth://'] : [];

  return {
    getStateFromPath: (...args) =>
      getStateFromPath(isSignedIn, navigationStateRef, ...args),
    prefixes: [
      prefix,
      // TODO: only use direct.aviva.co.uk for PROD
      ...prefixForDWAndroid,
      'https://www.direct.aviva.co.uk',
      'https://www.direct.rwy-aviva.co.uk',
      'https://www.direct.stg-aviva.co.uk',
      'https://www.direct.pre-aviva.co.uk',
      'https://www.direct1.rwy-aviva.co.uk',
      'https://www.direct2.rwy-aviva.co.uk',
      'https://www.direct3.rwy-aviva.co.uk',
      'https://www.direct.dev-aviva.co.uk',
    ],
    config: {
      screens: {
        app: {
          screens: {
            'Bottom tabs': {
              screens: {
                'Summary Tab': {
                  screens: { Summary: { path: 'webredirect' } },
                },
              },
            },
          },
        },
        auth: {
          screens: {
            // TODO: confirm this is the correct screen for this path
            'Log in': {
              path: 'app-login',
            },
            // TODO: confirm this is the correct screen for this path
            'Create an account': {
              path: 'MyAccount/Create/Step1',
            },
          },
        },
      },
    },
  };
};

type GetStateFromPath = typeof getStateFromPathDefault<RootStackParamList>;
type GetStateFromPathParams = Parameters<GetStateFromPath>;
type GetStateFromPathReturn = ReturnType<GetStateFromPath>;

export const getStateFromPath = (
  isSignedIn: boolean,
  navigationStateRef: MutableRefObject<NavigationState | undefined>,
  path: GetStateFromPathParams[0],
  options?: GetStateFromPathParams[1]
): GetStateFromPathReturn => {
  let pathName = path;
  if (OPEN_APP_PATHS.some((openPath) => openPath === path)) {
    pathName = 'app-login';
  }

  if (pathName.includes('/access/preactivation.do')) {
    return getPreactivationState(pathName);
  }

  if (pathName.includes('MyAccount/Create/Step1')) {
    return getFastTrackState(pathName);
  }

  if (pathName.includes('webredirect?logout=true')) {
    return getDeeplinkLogoutScreenState();
  }

  /**
   * If a user is not logged in and the path is one that needs authentication, we want to save the link and send them to login screen to authenticate.
   * Once the user has authenticated the save path will be played again so the user can be taken to the right place.
   */
  if (
    authenticatedPaths.some((authenticatedPath) =>
      pathName.includes(authenticatedPath)
    ) &&
    !isSignedIn
  ) {
    SavedDeepLink.set(getCustomStateFromPath(pathName, options));
    return getLoggedOutState();
  }

  const routes = navigationStateRef?.current?.routes[0]?.state
    ?.routes as PartialRoute<Route<string, object | undefined>>[];

  if (routes?.some((route) => linkBlockingRoutes.includes(route.name))) {
    SavedDeepLink.set(getCustomStateFromPath(path, options));
    return getLinkingAlertScreenState(routes);
  }

  return getCustomStateFromPath(pathName, options);
};

const getLoggedOutState = () => ({
  routes: [
    {
      name: 'auth',
      state: {
        routes: [{ name: AuthStackRouteNames.LOG_IN }],
      },
    },
  ],
});

const getDeeplinkLogoutScreenState = () => ({
  routes: [
    {
      name: 'app',
      state: {
        routes: [
          {
            name: 'Deeplink logout',
          },
        ],
      },
    },
  ],
});

const getLinkingAlertScreenState = (
  routes: PartialRoute<Route<string, object | undefined>>[]
) => ({
  routes: [
    {
      name: 'app',
      state: {
        routes: [
          ...routes,
          {
            name: 'LinkingAlertScreen',
          },
        ],
      },
    },
  ],
});

const getFastTrackState = (
  path: GetStateFromPathParams[0]
): GetStateFromPathReturn => {
  const url = new URL(path, baseUrl);
  const searchParams = new URLSearchParams(url.searchParams);
  const params = Object.fromEntries(searchParams.entries());

  return {
    routes: [
      {
        name: 'auth',
        state: {
          routes: [{ name: AuthStackRouteNames.REGISTER, params }],
        },
      },
    ],
  };
};

/**
 * getCustomStateFromPath will return custom state depending on the path
 */
const getCustomStateFromPath = (
  path: GetStateFromPathParams[0],
  options?: GetStateFromPathParams[1]
): GetStateFromPathReturn => {
  const url = new URL(path, baseUrl);
  const { pathname } = url;
  const searchParams = new URLSearchParams(url.searchParams);
  const params = Object.fromEntries(searchParams.entries());

  if (!isManga() && path.includes(DW_PRODUCT_DETAILS_PATH)) {
    const parts = path.split('/');
    const securePolicyNumber = parts.length > 1 ? parts[1] : undefined;
    return {
      routes: [
        {
          name: 'app',
          state: {
            routes: [
              { name: 'Bottom tabs' },
              {
                name: 'ProductDashboard',
                params: { securePolicyNumber },
              },
            ],
          },
        },
      ],
    };
  }
  if (!isManga() && path.includes(DW_PCS_DASHBOARD_PATH)) {
    return {
      routes: [
        {
          name: 'app',
          state: {
            routes: [
              { name: 'Bottom tabs' },
              {
                name: 'PCS Dashboard',
              },
            ],
          },
        },
      ],
    };
  }

  const state = getStateFromPathDefault(pathname, options) || {};
  const stateWithParams = traverseAndUpdate(
    state,
    (item) => item.path === pathname,
    (item) => ({ ...item, params })
  );

  return stateWithParams as GetStateFromPathReturn;
};

const getResetPasswordWebJourney = (url: string) => {
  return {
    routes: [
      {
        name: 'auth',
        state: {
          routes: [
            {
              name: AuthStackRouteNames.LOG_IN,
              params: {
                shouldNotAutoSignIn: true,
              },
            },
            {
              name: 'Web View',
              params: {
                url,
                title: formatURL(url),
                ssoEnabled: false,
              },
            },
          ],
        },
      },
    ],
  };
};

export const getPreactivationState = (
  path: GetStateFromPathParams[0]
): GetStateFromPathReturn => {
  const url = new URL(path, baseUrl);
  const formattedUrl = url.toString();
  const searchParams = new URLSearchParams(url.searchParams);
  const params = Object.fromEntries(searchParams.entries());

  try {
    const PreActivationQueryParamsSchema = z.object({
      ActivationCode: z.string(),
      token: z.string(),
    });

    const { token, ActivationCode } =
      PreActivationQueryParamsSchema.parse(params);

    // getStateFromPath has to be sync, so we setup state/observables directly
    accessToken.set(token);

    const DecodedToken = z.object({
      scp: z.string().optional(),
      exp: z
        .number()
        .transform((expiryDate) => new Date() >= new Date(expiryDate)),
    });

    const _decodedToken = decodeJwt(token);

    // TODO: provide dialog when accessToken has expired
    const { scp: scopes } = DecodedToken.parse(_decodedToken);

    const mfaRequired =
      scopes?.includes('mfa_generate') && scopes?.includes('mfa_reset_verify');

    if (mfaRequired) {
      return {
        routes: [
          {
            name: 'auth',
            state: {
              routes: [
                {
                  name: AuthStackRouteNames.FORGOTTEN_DETAILS_MFA,
                  params,
                },
              ],
            },
          },
        ],
      };
    }

    if (token && ActivationCode) {
      return {
        routes: [
          {
            name: 'auth',
            state: {
              routes: [{ name: AuthStackRouteNames.SET_NEW_PASSWORD, params }],
            },
          },
        ],
      };
    }

    return getResetPasswordWebJourney(formattedUrl);
  } catch (e) {
    if (e instanceof InvalidTokenError) {
      log.error(new Error(`InvalidTokenError: ${e}`));
    }

    if (e instanceof ZodError) {
      log.zodError(e);
    }

    log.error(e);
    return getResetPasswordWebJourney(formattedUrl);
  }
};
