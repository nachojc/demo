import {
  CompositeNavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import {
  BottomTabsRouteParams,
  BottomTabsScreenNames,
} from '@src/navigation/bottom-tabs';

import { AppStackRouteParams } from '../app';

export type BottomTabsNavigation = CompositeNavigationProp<
  NativeStackNavigationProp<BottomTabsRouteParams>,
  NativeStackNavigationProp<AppStackRouteParams>
>;

export type BottomTabsRoute<T extends keyof BottomTabsRouteParams> = RouteProp<
  BottomTabsRouteParams,
  T
>;

/**
 * @description A typed wrapper around useRoute
 *
 * @T
 * T is the name of the screen from which you're calling this hook
 * It must be a key of BottomTabsRouteParams
 */
export function useBottomTabsRoute<T extends BottomTabsScreenNames>() {
  return useRoute<BottomTabsRoute<T>>();
}

/**
 * @description A typed wrapper around useRoute
 *
 * For use within the BottomTabs navigation stack
 */
export function useBottomTabsNavigation() {
  return useNavigation<BottomTabsNavigation>();
}
