import { Icon, IconName, TopAppBarMangaProps } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useAuth } from '@hooks/use-auth';
import { isManga } from '@hooks/use-expo-config';
import { useMyDriveCustomer } from '@hooks/use-mydrive-customer';
import { usePushNotificationDeeplinks } from '@hooks/use-push-notification-deeplinks';
import {
  dpaCheckResult,
  dpaUnlockResultShowLogout,
  myDriveDisabledShown,
  myDriveOnboardingCompleted,
} from '@interfaces/storage';
import { useSelector } from '@legendapp/state/react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import {
  DialogFailure,
  DialogSuccess,
  DialogSuccessWithLogout,
} from '@src/features/idv/components/dialogues-alerts';
import { MyDriveDisabledDialog } from '@src/features/mydrive/components/dialogues';
import { getTestId } from '@src/utils/get-test-id';
import { tokens } from '@theme/tokens';
import { Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

import { topAppHeader } from '../app/summary/headers/headers';
import {
  ACTION_HELP_GLOBALNAV_TAPPED,
  OFFERS_GLOBALNAV_TAPPED,
  PROFILE_GLOBALNAV_TAPPED,
  SETTINGS_GLOBALNAV_TAPPED,
  SUMMARY_GLOBALNAV_TAPPED,
} from './analytics';

export type BottomTabsRouteParams = {
  ['Summary Tab']: undefined;
  ['Offers Tab']: undefined;
  ['Profile Tab']: undefined;
  ['Help Tab']: undefined;
  ['More Tab']: undefined;
};
export type BottomTabsScreenNames = keyof BottomTabsRouteParams;

const Tabs = createBottomTabNavigator<BottomTabsRouteParams>();

const activeBlue = tokens.color.Secondary800.val;
const inactiveGray = tokens.color.Gray400.val;

type GetIconProps = { name: IconName; focused: boolean };
export const getIcon = ({ name, focused }: GetIconProps) => {
  return (
    <Icon
      name={name}
      width={20}
      height={20}
      color={focused ? activeBlue : inactiveGray}
    />
  );
};

export const BottomTabs = () => {
  const analytics = useAnalytics();
  const insets = useSafeAreaInsets();

  usePushNotificationDeeplinks();

  return (
    <>
      <Tabs.Navigator
        screenOptions={{
          headerShown: false,
          tabBarActiveTintColor: activeBlue,
          tabBarInactiveTintColor: inactiveGray,
          tabBarStyle: {
            height: Platform.select({
              ios: insets.bottom > 0 ? 83 : 70, //smaller for iPhone SE with physical home button
              android: 70,
            }),
          },
          tabBarItemStyle: {
            height: 50,
            flexDirection: 'column',
          },
          tabBarLabelStyle: {
            marginLeft: 0,
          },
        }}
      >
        <Tabs.Screen
          name="Summary Tab"
          options={{
            title: 'Summary',
            tabBarTestID: getTestId('summary'),
            tabBarAccessibilityLabel: 'Summary',
            tabBarIcon: ({ focused }) =>
              getIcon({ focused, name: 'smartphone' }),
          }}
          listeners={{
            tabPress: () => analytics.trackUserEvent(SUMMARY_GLOBALNAV_TAPPED),
          }}
          getComponent={() =>
            isManga()
              ? require('@src/features/dashboard').DashboardScreen
              : require('@direct-wealth/navigation').DirectWealthTabStack
          }
        />
        <Tabs.Group
          screenOptions={{
            header: (props: TopAppBarMangaProps) => topAppHeader({ ...props }),
            headerShown: true,
          }}
        >
          {isManga() && (
            <Tabs.Screen
              name="Offers Tab"
              options={{
                title: 'Offers',
                tabBarTestID: getTestId('offers'),
                tabBarAccessibilityLabel: 'Offers',
                tabBarIcon: ({ focused }) => getIcon({ focused, name: 'book' }),
              }}
              listeners={{
                tabPress: () =>
                  analytics.trackUserEvent(OFFERS_GLOBALNAV_TAPPED),
              }}
              getComponent={() => require('@src/features/offers').OffersScreen}
            />
          )}
          <Tabs.Screen
            name="Profile Tab"
            options={{
              title: 'Profile',
              tabBarTestID: getTestId('profile'),
              tabBarAccessibilityLabel: 'Profile',
              tabBarIcon: ({ focused }) => getIcon({ focused, name: 'user' }),
            }}
            listeners={{
              tabPress: () =>
                analytics.trackUserEvent(PROFILE_GLOBALNAV_TAPPED),
            }}
            getComponent={() => require('@src/features/profile').ProfileScreen}
          />
          <Tabs.Screen
            name="Help Tab"
            options={{
              title: 'Help',
              tabBarTestID: getTestId('help'),
              tabBarAccessibilityLabel: 'Help',
              tabBarIcon: ({ focused }) =>
                getIcon({ focused, name: 'help-circle' }),
            }}
            listeners={{
              tabPress: () =>
                analytics.trackUserEvent(ACTION_HELP_GLOBALNAV_TAPPED),
            }}
            getComponent={() =>
              require('@src/features/help/help-screen').HelpScreen
            }
          />
          <Tabs.Screen
            name="More Tab"
            options={{
              tabBarAccessibilityLabel: 'More',
              tabBarTestID: getTestId('more'),
              title: 'More',
              tabBarIcon: ({ focused }) => getIcon({ focused, name: 'menu' }),
            }}
            listeners={{
              tabPress: () =>
                analytics.trackUserEvent(SETTINGS_GLOBALNAV_TAPPED),
            }}
            getComponent={() =>
              require('@src/features/more/more-screen').MoreScreen
            }
          />
        </Tabs.Group>
      </Tabs.Navigator>

      <IdvResultDialog />
      <ShowMyDriveDisabledDialog />
    </>
  );
};

export const IdvResultDialog = () => {
  const { isSignedIn } = useAuth();
  const dpaCheckResultValue = useSelector(dpaCheckResult);
  const dpaUnlockResultShowLogoutValue = useSelector(dpaUnlockResultShowLogout);

  const showSuccessDialog = isSignedIn && dpaCheckResultValue === 'Success';
  const showFailureDialog = isSignedIn && dpaCheckResultValue === 'Failed';
  const showSuccessDialogWithLogout =
    showSuccessDialog && dpaUnlockResultShowLogoutValue;

  if (showSuccessDialogWithLogout) {
    return <DialogSuccessWithLogout />;
  }

  if (showSuccessDialog) {
    return <DialogSuccess />;
  }

  if (showFailureDialog) {
    return <DialogFailure />;
  }
  return null;
};

export const ShowMyDriveDisabledDialog = () => {
  const { isMyDriveEligible } = useMyDriveCustomer();
  const { isSignedIn } = useAuth();

  const myDriveDisabled = myDriveDisabledShown.get();
  const myDriveOnboarded = myDriveOnboardingCompleted.get();

  const shouldShowMyDriveDisabledDialog =
    isSignedIn && myDriveOnboarded && !isMyDriveEligible && !myDriveDisabled;

  if (shouldShowMyDriveDisabledDialog) {
    return <MyDriveDisabledDialog />;
  }

  return null;
};
