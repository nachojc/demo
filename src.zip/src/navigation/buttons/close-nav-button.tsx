import { CloseButton } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { useNavigation } from '@react-navigation/native';
import { useCallback } from 'react';
import { ColorValue } from 'react-native';

import { useAppStackRoute } from '../app/hooks';

type CloseNavButtonProps = {
  color: ColorValue;
  onPress?: () => void;
};

export const CloseNavButton = ({ color, onPress }: CloseNavButtonProps) => {
  const navigation = useNavigation();
  const route = useAppStackRoute();
  const { trackUserEvent } = useAnalytics();

  const onPresshandler = useCallback(() => {
    if (
      route.params &&
      'onCloseAnalyticsTag' in route.params &&
      route.params?.onCloseAnalyticsTag
    ) {
      trackUserEvent(route.params?.onCloseAnalyticsTag);
    }
    navigation.goBack();
  }, [route.params, trackUserEvent, navigation]);

  return (
    <CloseButton onPress={onPress ?? onPresshandler} iconProps={{ color }} />
  );
};

// Allows to be used with the navigation api
export const closeNavButtonWithProps = (props: CloseNavButtonProps) => {
  const Button = () => {
    return <CloseNavButton {...props} />;
  };
  Button.displayName = 'CloseNavButton with props';
  return Button;
};
