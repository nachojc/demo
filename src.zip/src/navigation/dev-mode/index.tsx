import { TopAppBarDW } from '@aviva/ion-mobile';
import { PortfolioSummaryHeader } from '@direct-wealth/components/portfolio-header';
import { SignaturePad } from '@direct-wealth/components/signature-pad/signature-pad';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { AvivaWebViewTopAppBar } from '@src/components/web-view/headers/aviva-web-view-top-app-bar';
import {
  DevOptionsScreen,
  FullScreenCarouselDevModeScreen,
} from '@src/features/dev-mode';
import { ComponentsScreen } from '@src/features/dev-mode/components';
import { ButtonComponentsScreen } from '@src/features/dev-mode/components/buttons';
import { CardComponentsScreen } from '@src/features/dev-mode/components/cards';
import { DropdownComponentsScreen } from '@src/features/dev-mode/components/drop-down';
import { FormComponentsScreen } from '@src/features/dev-mode/components/forms';
import {
  GlobalHeaderSelectionScreen,
  GlobalHeadersScreen,
} from '@src/features/dev-mode/components/global-header';
import { HtmlFormattingComponentsScreen } from '@src/features/dev-mode/components/html-formatting/html-formatting';
import { IconComponentsScreen } from '@src/features/dev-mode/components/icons';
import { ModalComponentsScreen } from '@src/features/dev-mode/components/modals';
import { OtherComponentsScreen } from '@src/features/dev-mode/components/others';
import { NavigatorComponentsScreen } from '@src/features/dev-mode/components/simple-wealth';
import { AccessibleCollapsibleTabsScreen } from '@src/features/dev-mode/components/tabs/accessible-collapsible-tabs';
import { CollapsibleTabsScreen } from '@src/features/dev-mode/components/tabs/manga-collapsible-tabs';
import { RNCollapsibleTabsScreen } from '@src/features/dev-mode/components/tabs/rn-collapsible-tab-view';
import { TabsScreen } from '@src/features/dev-mode/components/tabs/tabs';
import { TabsMenuScreen } from '@src/features/dev-mode/components/tabs/tabs-screen';
import { FunctionsScreen } from '@src/features/dev-mode/functions';
import { ModifyFlagsScreen } from '@src/features/dev-mode/modify-flags';
import { MyDriveSettingsScreen } from '@src/features/dev-mode/MyDrive';
import { PreconfigureScreen } from '@src/features/dev-mode/preconfigure';
import {
  RemoteFlagDetailsScreen,
  RemoteFlagsScreen,
} from '@src/features/dev-mode/remote-flags';
import { ScreenIndexScreen } from '@src/features/dev-mode/screen-index';
import { FeatureFlagsScreen } from '@src/features/dev-mode/screen-index/screens/feature-flags';
import { StandaloneResponseOptionsScreen } from '@src/features/dev-mode/standalone-response-options';
import { StandaloneResponsesScreen } from '@src/features/dev-mode/standalone-responses';

import { TopAppBarDevMode } from '../app/summary/headers';
import { DevModeStackParams } from './types';

const Stack = createNativeStackNavigator<DevModeStackParams>();

export const DevModeStack = () => {
  return (
    <Stack.Navigator screenOptions={{ header: TopAppBarDW }}>
      <Stack.Screen name="Options" component={DevOptionsScreen} />
      <Stack.Screen name="Preconfigure" component={PreconfigureScreen} />
      <Stack.Screen
        name="Standalone Responses"
        component={StandaloneResponsesScreen}
      />
      <Stack.Screen
        name="Standalone Response Options"
        component={StandaloneResponseOptionsScreen}
      />
      <Stack.Screen name="MyDrive Settings" component={MyDriveSettingsScreen} />
      <Stack.Screen name="Components" component={ComponentsScreen} />
      <Stack.Screen name="Buttons" component={ButtonComponentsScreen} />
      <Stack.Screen name="Cards" component={CardComponentsScreen} />
      <Stack.Screen name="Icons" component={IconComponentsScreen} />
      <Stack.Screen name="Dropdowns" component={DropdownComponentsScreen} />
      <Stack.Screen name="Forms" component={FormComponentsScreen} />
      <Stack.Screen name="Modals" component={ModalComponentsScreen} />
      <Stack.Screen name="Tabs" component={TabsMenuScreen} />
      <Stack.Screen name="Collapsible Tabs" component={CollapsibleTabsScreen} />
      <Stack.Screen
        name="RN Collapsible Tab View"
        component={RNCollapsibleTabsScreen}
      />
      <Stack.Screen
        name="Accessible Collapsible Tab View"
        component={AccessibleCollapsibleTabsScreen}
      />
      <Stack.Screen name="Tabs Component" component={TabsScreen} />
      <Stack.Screen
        name="HTML Formatting"
        component={HtmlFormattingComponentsScreen}
      />
      <Stack.Screen name="Others" component={OtherComponentsScreen} />
      <Stack.Screen name="Navigator" component={NavigatorComponentsScreen} />
      <Stack.Screen name="Signature Pad">
        {() => (
          <SignaturePad
            onClearPress={() => {
              console.log('Clear button pressed');
            }}
            onDonePress={() => {
              console.log('Done button pressed');
            }}
          />
        )}
      </Stack.Screen>
      <Stack.Screen
        name="Global Headers Selection"
        component={GlobalHeaderSelectionScreen}
      />
      <Stack.Screen
        name="Global Headers"
        component={GlobalHeadersScreen}
        options={{ header: PortfolioSummaryHeader }}
      />
      <Stack.Screen name="Feature Flags" component={FeatureFlagsScreen} />
      <Stack.Screen name="Functions" component={FunctionsScreen} />
      <Stack.Screen name="Screen Index" component={ScreenIndexScreen} />
      <Stack.Screen name="Modify Flags" component={ModifyFlagsScreen} />
      <Stack.Screen name="Remote Flags" component={RemoteFlagsScreen} />
      <Stack.Screen
        name="Remote Flag Details"
        component={RemoteFlagDetailsScreen}
      />

      <Stack.Screen
        name="FullScreenCarousel"
        component={FullScreenCarouselDevModeScreen}
        options={{
          presentation: 'fullScreenModal',
          headerShown: true,

          header: (props) => TopAppBarDevMode(props),
        }}
      />
      <Stack.Screen
        name="Web View"
        getComponent={() =>
          require('@direct-wealth/common/utils/external-webview')
            .ExternalWebview
        }
        initialParams={{ url: 'https://www.aviva.co.uk' }}
        options={{
          header: AvivaWebViewTopAppBar,
        }}
      />
      <Stack.Screen
        name="Migration"
        getComponent={() =>
          require('@src/features/dev-mode/migration/migration-screen')
            .MigrationScreen
        }
      />
      <Stack.Screen
        name="Wiremock Config"
        getComponent={() =>
          require('@src/features/dev-mode/wiremock-config/wiremock-config-screen')
            .WiremockConfigScreen
        }
      />
    </Stack.Navigator>
  );
};
