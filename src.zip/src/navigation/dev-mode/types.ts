import { ColorScheme } from '@direct-wealth/components/tabs/tabsTheme';
import { AllMocks } from '@src/api-mock/types';
import { RemoteFlagKey } from '@src/remote-flags';

export type GlobalHeader = {
  theme: ColorScheme;
};

export type DevModeStackParams = {
  ['Options']: undefined;
  ['Preconfigure']: undefined;
  ['Standalone Responses']: undefined;
  ['Standalone Response Options']: {
    mockResponseType: keyof AllMocks;
  };
  ['Components']: undefined;
  ['Buttons']: undefined;
  ['Cards']: undefined;
  ['Dropdowns']: undefined;
  ['Forms']: undefined;
  ['Others']: undefined;
  ['Navigator']: undefined;
  ['HTML Formatting']: undefined;
  ['Signature Pad']: undefined;
  ['Global Headers Selection']: undefined;
  ['Global Headers']: GlobalHeader;
  ['Icons']: undefined;
  ['Screen Index']: undefined;
  ['Modify Flags']: undefined;
  ['Remote Flags']: undefined;
  ['Remote Flag Details']: {
    flagKey: RemoteFlagKey;
  };
  ['Feature Flags']: undefined;
  ['Functions']: undefined;
  ['FullScreenCarousel']: undefined;
  ['MyDrive Settings']: undefined;
  ['Modals']: undefined;
  ['Tabs']: undefined;
  ['Web View']: { url: string; ssoEnabled?: boolean };
  ['Collapsible Tabs']: undefined;
  ['Collapsible Tabs (Legacy)']: undefined;
  ['RN Collapsible Tab View']: undefined;
  ['Accessible Collapsible Tab View']: undefined;
  ['Tabs Component']: undefined;
  ['Migration']: undefined;
  ['Wiremock Config']: undefined;
};
