import {
  NavigationProp,
  RouteProp,
  useNavigation,
  useRoute,
} from '@react-navigation/native';

import { DevModeStackParams } from './types';

type DevModeStackScreenNames = keyof DevModeStackParams;

export type DevModeStackNavigation<T extends keyof DevModeStackParams> =
  NavigationProp<DevModeStackParams, T>;
export type DevModeStackRoute<T extends DevModeStackScreenNames> = RouteProp<
  DevModeStackParams,
  T
>;

export function useDevModeStackRoute<T extends DevModeStackScreenNames>() {
  return useRoute<DevModeStackRoute<T>>();
}

export function useDevModeStackNavigation<T extends DevModeStackScreenNames>() {
  return useNavigation<DevModeStackNavigation<T>>();
}
