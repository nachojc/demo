import { NgModule } from '@angular/core';
import { SButtonComponentModule } from './components/button/button.module';
import { SCheckboxComponentModule } from './components/checkbox/checkbox.module';
import { SErrorDirectiveModule } from './directives/error/error.module';
import { SFirstNameDirectiveModule } from './directives/first-name/first-name.module';
import { SInputComponentModule } from './components/input/input.module';
import { SLabelDirectiveModule } from './directives/label/label.module';
import { SLastNameDirectiveModule } from './directives/last-name/last-name.module';
import { SSelectComponentModule } from './components/select/select.module';
import { SSortcodeComponentModule } from './components/sortcode/sortcode.module';
import { SNumericDirectiveModule } from './directives/numeric/numeric.module';

@NgModule({
  imports: [
    SButtonComponentModule,
    SCheckboxComponentModule,
    SErrorDirectiveModule,
    SFirstNameDirectiveModule,
    SInputComponentModule,
    SLabelDirectiveModule,
    SLastNameDirectiveModule,
    SSelectComponentModule,
    SSortcodeComponentModule,
    SNumericDirectiveModule
  ],
  exports: [
    SButtonComponentModule,
    SCheckboxComponentModule,
    SErrorDirectiveModule,
    SFirstNameDirectiveModule,
    SInputComponentModule,
    SLabelDirectiveModule,
    SLastNameDirectiveModule,
    SSelectComponentModule,
    SSortcodeComponentModule,
    SNumericDirectiveModule
  ]
})
export class SFormLibModule { }
