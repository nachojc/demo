import { NgModule } from "@angular/core";
import { SFormLibModule } from "./s-form-lib.module";
import { SLayoutAndNavigationLibModule } from "./s-layout-and-navigation-lib.module";


@NgModule({
  exports: [
    SFormLibModule,
    SLayoutAndNavigationLibModule
  ]
})

export class SElementsLibModule { }
