import { NgModule } from "@angular/core";
import { SHeaderComponentModule } from "./components/header/header.module";
import { SBreadcrumbsComponentModule } from './components/breadcrumbs/breadcrumbs.module';

@NgModule({
  imports: [
    SHeaderComponentModule,
    SBreadcrumbsComponentModule
  ],
  exports: [
    SHeaderComponentModule,
    SBreadcrumbsComponentModule
  ]
})

export class SLayoutAndNavigationLibModule { }
