import { Component, EventEmitter, Output, ElementRef, ViewChild } from '@angular/core';
import { BaseComponent } from '../base/base.component';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 's-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.scss', '../../styles/error.scss', '../../styles/input-boxes.scss' ],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: CheckboxComponent, multi: true }
  ]
})
export class CheckboxComponent extends BaseComponent implements ControlValueAccessor {
  @ViewChild('input') input: ElementRef;
  private _onTouched: Function;
  public _required: Boolean;

  @Output() valueChange = new EventEmitter<any>();

  private _propagateChange: Function;

  constructor(element: ElementRef) {
    super();
    this._required = element.nativeElement.getAttribute('required') !== null;
    this._errMessage = element.nativeElement.getAttribute('error-message') !== null ? '' : this._errMessage;
  }

  onTouched() {
    this._onTouched && this._onTouched();
  }

  checkHandler (event) {
    if (!event.target.checked) {
      event.stopPropagation();
    }
    this.value = event.target.checked ? true : '';

    if (this._propagateChange) {
      this._propagateChange(this.value);
    } else {
      this.valueChange.emit(this.value);
    }
    this.onTouched();
  }

  writeValue (val: any): void {
    this.value = val;
  }
  registerOnChange (fn: any): void {
    this._propagateChange = fn;
  }
  registerOnTouched (fn: any): void {
    this._onTouched = fn;
  }
}
