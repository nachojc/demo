import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectComponent } from './select.component';
import { EventEmitter, Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('SelectComponent', () => {
  let component: SelectComponent;
  let fixture: ComponentFixture<SelectComponent>;
  let selectEl;

  function selectOption(option: string) {
    component.writeValue(option);
    selectEl.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    return fixture.whenStable();
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SelectComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(SelectComponent);
    component = fixture.componentInstance;
    selectEl = fixture.debugElement.query(By.css('select')).nativeElement;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the following properties', async(() => {
    expect(component._options).not.toBeNull();
    expect(component.valueChange).toEqual(jasmine.any(EventEmitter));
  }));

  it('should return the right amount of options on #select', async(() => {
    component._options = ['jumanji', 'hat', 'saruman'];
    fixture.detectChanges();
    expect(selectEl.childElementCount).toEqual(3);
  }));

  it('user can select an option that is displayed on select', async(() => {
    component._options = ['jumanji', 'hat', 'saruman'];
    fixture.detectChanges();
    selectEl.value = 'hat';
    fixture.detectChanges();

    selectEl.dispatchEvent(new Event('change'));
    expect(component.value).toEqual('hat');
  }));

  it('emits the first value by default', () => {
    component._options = ['jumanji', 'hat', 'saruman'];
    fixture.detectChanges();

    component.valueChange.subscribe(selectedValue => {
      expect(selectedValue).toEqual('jumanji');
    });
    selectEl.dispatchEvent(new Event('change'));
  });

  it('emits the selected value at init', async(() => {
    component.valueChange.subscribe(selectedValue => {
      expect(selectedValue).toEqual('cake');
    });
    component.value = 'cake';
    component._options = ['cookie', 'cake', 'cupcakes'];
    component.ngAfterViewInit();
    fixture.detectChanges();
  }));

  it('emits the selected value at init (write value)', async(() => {
    component._options = ['cookie', 'cake', 'cupcakes'];
    fixture.detectChanges();
    component.writeValue('cake'); // Cannot find a way to call writeValue before actual populating options (detect changes) and being on time. That's way is before and timings cannot be tested
    component.valueChange.subscribe(selectedValue => {
      expect(selectedValue).toEqual('cake');
    });
  }));

  it('implements writeValue method', () => {
    expect(component.writeValue).toBeDefined();
  });

  it('implements writeValue and select the option accordingly', () => {
    component._options = ['cookie', 'cake', 'cupcakes'];
    fixture.detectChanges();
    component.writeValue('cake');

    const options = fixture.debugElement.queryAll(By.css('option'));

    expect(options[0].nativeElement.selected).toBe(false);
    expect(component.value).toEqual('cake');
    expect(options[1].nativeElement.selected).toBe(true);
    expect(options[2].nativeElement.selected).toBe(false);
  });

  it('implements writeValue, if given option does not exist then first is the selected one', done => {
    component._options = ['cookie', 'cake', 'cupcakes'];
    fixture.detectChanges();
    component.ngAfterViewInit();

    component.writeValue('biscuits');
    const options = fixture.debugElement.queryAll(By.css('option'));

    setTimeout(() => {
      expect(component.value).toEqual('cookie');
      expect(options[0].nativeElement.selected).toBe(true);
      expect(options[1].nativeElement.selected).toBe(false);
      expect(options[2].nativeElement.selected).toBe(false);
      done();
    }, 110); //greater then ngAfterViewInit delay
  });

  it('implements registerOnChange method', () => {
    expect(component.registerOnChange).toBeDefined();
  });

  it('emits an event when calling onChange (no form context)', done => {
    component.valueChange.subscribe(selectedValue => {
      expect(selectedValue).toEqual('option 1');
      done();
    });
    const pseudoEvent = { target: { value: 'option 1' } };
    component.onChange(pseudoEvent);
  });

  it('calls registerOnChange when calling onChange (form context)', done => {
    let emitted = false;
    component.valueChange.subscribe(selectedValue => {
      emitted = true;
    });

    component.registerOnChange(() => { });
    var spiedFunction = spyOn<any>(component, "_propagateChange");

    const pseudoEvent = { target: { value: 'option 1' } };
    component.onChange(pseudoEvent);

    setTimeout(() => {
      expect(spiedFunction).toHaveBeenCalled();
      expect(emitted).toBe(false);
      done();
    }, 200);
  });

  it('calls registerOnChange when change event is triggered (form context)', async(() => {
    component.registerOnChange(() => { });
    var spiedFunction = spyOn<any>(component, "_propagateChange");

    component._options = ['cookie', 'cake', 'cupcakes'];
    fixture.detectChanges();

    let valueChange = false;
    component.valueChange.subscribe(() => {
      valueChange = true;
    });
    selectOption('cupcakes').then(() => {
      expect(spiedFunction).toHaveBeenCalled();
    });

    setTimeout(() => {
      expect(valueChange).toBe(false);
    }, 200)
  }));

  it('emits and event when change event is triggered (no form context)', async(() => {
    component._options = ['cookie', 'cake', 'cupcakes'];
    fixture.detectChanges();

    component.valueChange.subscribe(value => {
      expect(value).toBe('cupcakes');
    });
    selectOption('cupcakes');
  }));

  it('implements registerOnTouched method', () => {
    expect(component.registerOnTouched).toBeDefined();
  });

  it('calls registerOnTouched when component lost focus', async(() => {
    component.registerOnTouched(() => { });
    var spiedFunction = spyOn<any>(component, "_onTouched");

    selectEl.dispatchEvent(new Event('blur'));
    fixture.whenStable().then(() => {
      expect(spiedFunction).toHaveBeenCalled();
      expect(component._opened).toBe(false);
    });
  }));

  it('_opened turns true when onSelectClicked', () => {
    expect(component._opened).toBe(false);
    component.onSelectClicked(null);
    expect(component._opened).toBe(true);
  });

  it('_opened turns true when select is clicked', () => {
    expect(component._opened).toBe(false);
    selectEl.click();
    expect(component._opened).toBe(true);
  });
});

/* In a reactive form */
@Component({
  template:
    `<form ngForm>
      <s-select id="fresh" [formControl]="selectControl" [options]="['cookie', 'cake', 'cupcakes']"></s-select>
      <s-select id="prepopulated" [formControl]="selectControlPrepopulated" [options]="['cookie', 'cake', 'cupcakes']"></s-select>
    </form>`
})
class TestTemplateFormComponent {
  selectControl = new FormControl();
  selectControlPrepopulated = new FormControl('cupcakes')
}

describe('Select in a dummy Reactive-Driven Form', () => {
  let fixture, form, selectDebugNormal, selectEl, selectDebugPrepopulated;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SelectComponent, TestTemplateFormComponent],
      imports: [FormsModule, ReactiveFormsModule]
    })
      .compileComponents();

    fixture = TestBed.createComponent(TestTemplateFormComponent);
    form = fixture.componentInstance;
    selectDebugNormal = fixture.debugElement.query(By.css('#fresh'));
    selectDebugPrepopulated = fixture.debugElement.query(By.css('#prepopulated'));
    selectEl = <HTMLSelectElement>selectDebugNormal.nativeElement.querySelector('select');
    fixture.detectChanges();
  }));

  it('should change to touched once you exit from the element', () => {
    expect(form.selectControl.untouched).toBe(true);
    selectEl.click();
    selectEl.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    expect(form.selectControl.untouched).toBe(false);
    expect(form.selectControl.touched).toBe(true);
    expect(selectDebugNormal.classes['ng-touched']).toBe(true);
  });

  it('should change dirty by default because we always send a value at the start', () => {
    expect(form.selectControl.pristine).toBe(false);
    expect(form.selectControl.dirty).toBe(true);
    expect(form.selectControl.value).toBe('cookie');
    fixture.detectChanges();
    expect(selectDebugNormal.classes['ng-dirty']).toBe(true);
    expect(selectDebugNormal.classes['ng-pristine']).toBe(false);
  });

  it('should get a value if we select an option', () => {
    selectEl.value = 'cake';
    selectEl.dispatchEvent(new Event('change'));
    fixture.detectChanges();
    expect(form.selectControl.value).toBe('cake');
  });

  it('should select a the first value in absence of prepopulated value', () => {
    expect(selectDebugNormal.componentInstance.value).toBe('cookie');
  });

  it('should select a prepopulated value', () => {
    expect(selectDebugPrepopulated.componentInstance.value).toBe('cupcakes');
  });
});
