import { Component, Input, Output, EventEmitter, ElementRef, AfterViewInit, ViewChildren, QueryList } from '@angular/core';
import { BaseComponent } from '../base/base.component';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 's-select',
  templateUrl: './select.component.html',
  host: { '[class.opened]': '_opened' },
  styleUrls: ['./select.component.scss', '../../styles/error.scss', '../../styles/input-boxes.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SelectComponent, multi: true }
  ]
})

export class SelectComponent extends BaseComponent implements ControlValueAccessor, AfterViewInit {
  @Input('options') _options: any[];
  private _propagateChange: Function;
  private _onTouched: Function;
  public _opened: boolean = false;
  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();
  @ViewChildren('optionList') private _optionList: QueryList<ElementRef>;
  //Compiler false positive @see https://github.com/ng-packagr/ng-packagr/issues/710


  ngAfterViewInit(): void {
    setTimeout(() => {
      if (this._options && this._options.length > 0) {
        this.value = this.value || this._options[0];
        
        if (this._propagateChange) {
          this._propagateChange(this.value);
        } else {
          this.valueChange.emit(this.value);
        }
      }
    }, 100); // ExpressionChangedAfterItHasBeenCheckedError fixme
  }

  onChange(event) {
    setTimeout(() => { this._opened = false }, 0);
    this.value = event.target.value;

    if (this._propagateChange) {
      this._propagateChange(this.value);
    } else {
      this.valueChange.emit(this.value);
    }
  }

  onTouched() {
    this._onTouched && this._onTouched();
    setTimeout(() => { this._opened = false }, 0);
  }

  writeValue(val: any): void {
    if (this._optionList) {
      this.selectOption(val);
    } else {
      setTimeout(() => {
        this.selectOption(val);
      }, 50); //fix me there must be another way. Needs to be lower than ngAfterViewInit
    }
  }

  selectOption(val) {
    this._optionList.forEach(option => {
      if (option.nativeElement.textContent === val) {
        this.value = val;
        option.nativeElement.selected = true;
      }
    });
  }

  registerOnChange(fn: any): void {
    this._propagateChange = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }

  onSelectClicked(evt) {
    this._opened = this._opened ? false : true;
  }
}
