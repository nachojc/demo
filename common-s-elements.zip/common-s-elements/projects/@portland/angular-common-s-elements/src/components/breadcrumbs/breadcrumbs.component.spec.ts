import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { BreadcrumbsComponent } from './breadcrumbs.component';

describe('BreadcrumbsComponent', () => {
  let component: BreadcrumbsComponent;
  let fixture: ComponentFixture<BreadcrumbsComponent>;
  let ul: HTMLUListElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [BreadcrumbsComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BreadcrumbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    ul = fixture.debugElement.query(By.css('ul')).nativeElement;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have _item as property', () => {
    expect(component._items).not.toBeNull();
  });

  it('should assign different classes to different status', () => {
    component._items = [
      { label: 'step 1', status: 'selected' },
      { label: 'step 2', status: 'ok' },
      { label: 'step 3', status: 'error' },
      { label: 'step 4', status: null },
      { label: 'step 5'},
    ];
    fixture.detectChanges();
    expect(ul.childElementCount).toBe(5);
    
    expect(ul.children[0].children[0].classList.contains('selected')).toBe(true);
    
    expect(ul.children[1].children[0].classList.contains('valid')).toBe(true);
    
    expect(ul.children[2].children[0].classList.contains('invalid')).toBe(true);
    
    expect(ul.children[3].children[0].classList.contains('selected')).toBe(false);
    expect(ul.children[3].children[0].classList.contains('valid')).toBe(false);
    expect(ul.children[3].children[0].classList.contains('invalid')).toBe(false);

    expect(ul.children[4].children[0].classList.contains('selected')).toBe(false);
    expect(ul.children[4].children[0].classList.contains('valid')).toBe(false);
    expect(ul.children[4].children[0].classList.contains('invalid')).toBe(false);
  });

  it('should place label in html', () => {
    component._items = [
      { label: 'step 1' },
      { label: 'step 2', status: 'error' },
      { label: 'step 3' },
    ];
    fixture.detectChanges();
    expect(ul.childElementCount).toBe(3);
    
    expect(ul.children[0].children[1].textContent).toEqual('step 1');
    expect(ul.children[1].children[1].textContent).toEqual('step 2');
    expect(ul.children[2].children[1].textContent).toEqual('step 3');
  });
});
