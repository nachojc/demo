import { Component, Input } from '@angular/core';

export interface BreadcrumbItem {
  label: string;
  status?: 'ok' | 'selected' | 'error' | null;
};

@Component({
  selector: 's-breadcrumbs',
  templateUrl: './breadcrumbs.component.html',
  styleUrls: ['./breadcrumbs.component.scss']
})
export class BreadcrumbsComponent {
  @Input('items') _items: BreadcrumbItem[];

  constructor() { }
}
