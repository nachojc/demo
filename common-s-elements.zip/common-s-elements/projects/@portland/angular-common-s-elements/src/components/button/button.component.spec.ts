import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ButtonComponent } from './button.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('ButtonComponent', () => {
  let component: ButtonComponent;
  let fixture: ComponentFixture<ButtonComponent>;
  let buttonDebugEl: DebugElement;
  let buttonEl: HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ButtonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButtonComponent);
    component = fixture.componentInstance;
    buttonDebugEl = fixture.debugElement.query(By.css('button'));
    buttonEl = buttonDebugEl.nativeElement;
    component._disabled = false;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#Button should call an event when clicked', async() => {
    component.clickEmit.subscribe(resEvent => {
      expect(resEvent).toBeTruthy();
      expect(resEvent.type).toEqual('click');
    });
    buttonEl.dispatchEvent(new Event('click'));
  });

  it('#disableButton should not call an event', async() => {
    component._disabled = true;
    fixture.detectChanges();

    component.clickEmit.subscribe(noEvent => {
      expect(noEvent).toBe(null);
    });
    buttonEl.dispatchEvent(new Event('click'));
  });

  it('#Button should call an event after pressing "Spacebar"', async() => {
    component.clickEmit.subscribe(resEvent => {
      expect(resEvent).toBeTruthy();
      expect(resEvent.key).toEqual(' ');
    });
    buttonDebugEl.triggerEventHandler('keyup', {'key': ' '});
  });

  it('#Button should call an event after pressing "Enter"', async() => {
    component.clickEmit.subscribe(resEvent => {
      expect(resEvent).toBeTruthy();
      expect(resEvent.key).toEqual('Enter');
    });
    buttonDebugEl.triggerEventHandler('keyup', {'key': 'Enter'});
  });

  it('#Button should not call an event after pressing "Alt', async() => {
    component.clickEmit.subscribe(noEvent => {
      expect(noEvent).toBe(null);
    });
    buttonDebugEl.triggerEventHandler('keyup', {'key': 'Alt'});
  });
});
