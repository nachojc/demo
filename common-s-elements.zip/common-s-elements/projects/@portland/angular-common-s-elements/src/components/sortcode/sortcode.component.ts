import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { fromEvent, Observable } from 'rxjs';
import { debounceTime, map } from 'rxjs/operators';

@Component({
  selector: 's-sortcode',
  templateUrl: './sortcode.component.html',
  // tslint:disable-next-line:use-host-property-decorator
  host: { '[class.ng-invalid]': '_invalid', '[class.ng-untouched]': '_untouched' },
  styleUrls: ['./sortcode.component.css', '../../styles/error.scss', '../../styles/input-boxes.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SortcodeComponent, multi: true }
  ],

})
export class SortcodeComponent implements ControlValueAccessor, AfterViewInit {
  @ViewChild('first') firstInput: ElementRef;
  @ViewChild('second') secondInput: ElementRef;
  @ViewChild('third') thirdInput: ElementRef;
  @Input() value: string;
  @Input() separator: Boolean = true;
  @Input() disabled: Boolean = false;
  @Input() required: Boolean = false;
  @Output() valueChange: EventEmitter<String> = new EventEmitter<String>();
  private _propagateChange: Function;
  private _onTouched: Function;
  private regex = /^([0-9]{2})$/;
  private blurFirstInput$: Observable<any>;
  private blurSecondInput$: Observable<any>;
  private blurThirdInput$: Observable<any>;
  private _debounceTime: number = 50;
  private secondWasEmpty: Boolean = true;
  private thirdWasEmpty: Boolean = true;
  _invalid: Boolean = false;
  _untouched: Boolean = true;

  constructor() { }

  ngAfterViewInit() {
    this.blurFirstInput$ = fromEvent<any>(this.firstInput.nativeElement, 'blur')
      .pipe(debounceTime(this._debounceTime))
      .pipe(map(event => event));

    this.blurSecondInput$ = fromEvent<any>(this.secondInput.nativeElement, 'blur')
      .pipe(debounceTime(this._debounceTime))
      .pipe(map(event => event));

    // Setting the debounce time on the input element
    this.blurThirdInput$ = fromEvent<any>(this.thirdInput.nativeElement, 'blur')
      .pipe(debounceTime(this._debounceTime))
      .pipe(map(event => event));

    this.blurFirstInput$.subscribe(elem => this.checkComponentFocus(elem));
    this.blurSecondInput$.subscribe(elem => this.checkComponentFocus(elem));
    this.blurThirdInput$.subscribe(elem => this.checkComponentFocus(elem));

    this.secondWasEmpty = !(this.secondInput.nativeElement.value.length > 0);
    this.thirdWasEmpty = !(this.secondInput.nativeElement.value.length > 0);


    if (this.firstInput.nativeElement.value.length > 0
        || this.secondInput.nativeElement.value.length > 0
        || this.thirdInput.nativeElement.value.length > 0) {
      setTimeout(() => {this._untouched = false; }, 500); // ExpressionChangedAfterItHasBeenCheckedError fixme
    }

    if ((this.firstInput.nativeElement.value.length > 0
        || this.secondInput.nativeElement.value.length > 0
        || this.thirdInput.nativeElement.value.length > 0) &&
        (!this.regex.test(this.firstInput.nativeElement.value)
        || !this.regex.test(this.secondInput.nativeElement.value)
        || !this.regex.test(this.thirdInput.nativeElement.value))) {
      setTimeout(() => {this._invalid = false; }, 500); // ExpressionChangedAfterItHasBeenCheckedError fixme
    }

  }

  checkComponentFocus(elem: any): void {

    if (this._onTouched !== undefined) {
      if (document.activeElement !== this.firstInput.nativeElement
        && document.activeElement !== this.secondInput.nativeElement
        && document.activeElement !== this.thirdInput.nativeElement) {
        this._onTouched();
      } else if (!this.regex.test(elem.target.value)) {
        this._onTouched();

      }
    } else {
      if (document.activeElement !== this.firstInput.nativeElement
        && document.activeElement !== this.secondInput.nativeElement
        && document.activeElement !== this.thirdInput.nativeElement) {
        this._untouched = false;
      } else if (!this.regex.test(elem.target.value)) {
        this._untouched = false;
        this._invalid = true;
      }
    }
  }

  writeValue(value: string): void {
    this.value = value;
    if (value !== undefined && value !== null) {
      if (value.length > 1) {
        this.firstInput.nativeElement.value = value.slice(0, 2);
        
      }
      if (value.length > 3) {
        this.secondInput.nativeElement.value = value.slice(2, 4);
        this.secondWasEmpty = false;
      }
      if (value.length > 5) {
        this.thirdInput.nativeElement.value = value.slice(4, 6);
        this.thirdWasEmpty = false;
      }
    }
  }
  registerOnChange(fn: any): void {
    this._propagateChange = fn;
  }
  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
    this.firstInput.nativeElement.disabled = isDisabled;
    this.secondInput.nativeElement.disabled = isDisabled;
    this.thirdInput.nativeElement.disabled = isDisabled;
  }

  handleEvent(pair, event) {
    // Controls whether the second or third input are empty.
    // In that case, if next key event received is a backspace we should
    // jump to the previous input.
    pair === 'second' && event.target.value.length === 0 ? this.secondWasEmpty = true : null;
    pair === 'second' && event.target.value.length > 0 ? this.secondWasEmpty = false : null;
    pair === 'third' && event.target.value.length === 0 ? this.thirdWasEmpty = true : null;
    pair === 'third' && event.target.value.length > 0 ? this.thirdWasEmpty = false : null;


    if (pair === 'first' && event.target.value.length === 2) {
      this.secondInput.nativeElement.focus();
    } else if (pair === 'second' && event.target.value.length === 2) {
      this.thirdInput.nativeElement.focus();
    }
    this.setSortcode(pair, event);
  }

  setSortcode(pair, event) {
    // This will propagate the value when is used from a Form
    if (this._propagateChange !== undefined) {
      if (this.firstInput.nativeElement.value.length === 2
        && this.secondInput.nativeElement.value.length === 2
        && this.thirdInput.nativeElement.value.length === 2) {
        if (this.regex.test(this.firstInput.nativeElement.value)
          && this.regex.test(this.secondInput.nativeElement.value)
          && this.regex.test(this.thirdInput.nativeElement.value)) {
          this._propagateChange(this.firstInput.nativeElement.value
            + this.secondInput.nativeElement.value
            + this.thirdInput.nativeElement.value);
        } else {
          this._propagateChange('');
          this._onTouched();
        }
      } else { this._propagateChange(''); }
    } else {
      // This will emit the value for Standalone use
      if (this.firstInput.nativeElement.value.length === 2
        && this.secondInput.nativeElement.value.length === 2
        && this.thirdInput.nativeElement.value.length === 2) {

          if (this.regex.test(this.firstInput.nativeElement.value)
          && this.regex.test(this.secondInput.nativeElement.value)
          && this.regex.test(this.thirdInput.nativeElement.value)) {
          this.valueChange.emit(
            this.firstInput.nativeElement.value
            + this.secondInput.nativeElement.value
            + this.thirdInput.nativeElement.value);

          this._invalid = false;
          this._untouched = false;
        } else {
          this.valueChange.emit('');
          this._invalid = true;
          this._untouched = false;
        }
      } else {
        this.valueChange.emit('');
        this._untouched = false;
      }
    }
  }

  getSortcode(pair): string {
    return {
      first: this.value != null ? this.value.slice(0, 2) : '',
      second: this.value != null ? this.value.slice(2, 4) : '',
      third: this.value != null ? this.value.slice(4, 6) : ''
    }[pair];
  }

  backspaceCheck(pair, event) {
    if (this.wasEmpty(pair) && event.key === 'Backspace') {
      if (pair === 'second') {
        this.firstInput.nativeElement.focus();
      } else if (pair === 'third') {
        this.secondInput.nativeElement.focus();
      }
    }
  }

  wasEmpty(pair) {
    return {
      second: this.secondWasEmpty,
      third: this.thirdWasEmpty
    }[pair];
  }

  isDisabled(disabled): boolean {
    if (disabled === '') {
      return true;
    } else if (disabled === true) {
      return true;
    } else {
      return false;
    }
  }

  isRequired(required): boolean {
    if (required === '') {
      return true;
    } else if (required === true) {
      return true;
    } else {
      return false;
    }
  }
}
