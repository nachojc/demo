import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputComponent } from './input.component';
import { By } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule, FormControl } from '@angular/forms';
import { Component } from '@angular/core';

function sendInput(text: string, inputEl, fixture) {
  inputEl.value = text;
  inputEl.dispatchEvent(new Event('input'));
  fixture.detectChanges();
  return fixture.whenStable();
}

describe('InputComponent', () => {
  let component: InputComponent;
  let fixture: ComponentFixture<InputComponent>;
  let inputEl;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InputComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(InputComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input')).nativeElement;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have all the properties on init', () => {
    expect(component.placeholder).toEqual(null);
    expect(component._debounceTime).toEqual(150);
  });

  // e2e
  it('should set the input tag placeholder', () => {
    component.placeholder = 'Jumanji';
    fixture.detectChanges();
    expect(inputEl.placeholder).toEqual('Jumanji');
  });

  it('should wait 150ms on user input by default', done => {
    let inputValue;
    component.valueChange.subscribe(value => {
      inputValue = value;
    });

    inputEl.value = 'cake';
    inputEl.dispatchEvent(new Event('input'));

    expect(inputValue).toBe(undefined);

    setTimeout(() => {
      expect(inputValue).toBe(undefined);
    }, 100); // smaller than debounce time

    setTimeout(() => {
      expect(inputValue).toBe('cake');
      done();
    }, 160); // greater than debounce time
  });

  it('should wait a given time on user input when debounce is changed', done => {
    component._debounceTime = 24;
    component.ngAfterViewInit(); //update debounce time

    let inputValue;
    component.valueChange.subscribe(value => {
      inputValue = value;
    });

    inputEl.value = 'cake';
    inputEl.dispatchEvent(new Event('input'));

    setTimeout(() => {
      expect(inputValue).toBe(undefined);
    }, 10); // smaller than debounce time

    setTimeout(() => {
      expect(inputValue).toBe('cake');
      done();
    }, 50); // greater than debounce time
  });

  it('changes component value on writeValue', () => {
    component.writeValue('Jumanji');
    fixture.detectChanges();
    expect(inputEl.value).toEqual('Jumanji');
  });

  it('implements registerOnChange method', () => {
    expect(component.registerOnChange).toBeDefined();
  });

  it('calls registerOnChange inside an form context when input event is triggered', async(() => {
    component.registerOnChange(() => { });
    var spiedFunction = spyOn<any>(component, "_propagateChange");
    let valueChange = false;
    component.valueChange.subscribe(value => {
      valueChange = true;
    });
    sendInput('user is typing', inputEl, fixture).then(() => {
      expect(spiedFunction).toHaveBeenCalled();
    });

    setTimeout(() => {
      expect(valueChange).toBe(false);
    }, 200)
  }));

  it('doesn\'t call registerOnChange neither EventEmitter when no input event is triggered (form context)', async(() => {
    component.registerOnChange(() => { });
    var spiedFunction = spyOn<any>(component, "_propagateChange");
    let valueChange = false;
    component.valueChange.subscribe(value => {
      valueChange = true;
    });
    expect(spiedFunction).not.toHaveBeenCalled();
    setTimeout(() => {
      expect(valueChange).toBe(false);
    }, 200)
  }));

  it('doesn\'t call registerOnChange neither EventEmitter when no input event is triggered (not form context)', async(() => {
    let cannotBeSpied = false;
    try {
      spyOn<any>(component, "_propagateChange");
    } catch {
      cannotBeSpied = true;
    }

    let valueChange = false;
    component.valueChange.subscribe(value => {
      valueChange = true;
    });
    expect(cannotBeSpied).toBe(true);
    setTimeout(() => {
      expect(valueChange).toBe(false);
    }, 200)
  }));

  it('doesn\'t call registerOnChange but EventEmitter when there is no form context and input event is triggered', async(() => {
    let cannotBeSpied = false;
    try {
      spyOn<any>(component, "_propagateChange");
    } catch {
      cannotBeSpied = true;
    }
    component.valueChange.subscribe(value => {
      expect(value).toEqual('user is typing');
    });
    sendInput('user is typing', inputEl, fixture).then(() => {
      expect(cannotBeSpied).toBe(true);
    });
  }));

  it('implements registerOnTouched method', () => {
    expect(component.registerOnTouched).toBeDefined();
  });

  it('calls registerOnTouched when component lost focus', async(() => {
    component.registerOnTouched(() => { });
    var spiedFunction = spyOn<any>(component, "_onTouched");
    inputEl.dispatchEvent(new Event('blur'));
    fixture.whenStable().then(() => {
      expect(spiedFunction).toHaveBeenCalled();
    });
  }));
});

/* In a reactive form */
@Component({
  template:
    `<form ngForm>
      <s-input id="fresh" [formControl]="inputControl"></s-input>
      <s-input id="prepopulated" [formControl]="inputControlPrepopulated"></s-input>
    </form>`
})
class TestTemplateFormComponent {
  inputControl = new FormControl();
  inputControlPrepopulated = new FormControl('Potatoes')
}

describe('Input in a dummy Reactive-Driven Form', () => {
  let fixture, form, inputDebugNormal, inputEl, inputDebugPrepopulated;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InputComponent, TestTemplateFormComponent],
      imports: [FormsModule, ReactiveFormsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(TestTemplateFormComponent);
    form = fixture.componentInstance;
    inputDebugNormal = fixture.debugElement.query(By.css('#fresh'));
    inputDebugPrepopulated = fixture.debugElement.query(By.css('#prepopulated'));
    inputEl = <HTMLInputElement>inputDebugNormal.nativeElement.querySelector('input');
    fixture.detectChanges();
  }));

  it('should change to touched once element is touched', () => {
    expect(form.inputControl.untouched).toBe(true);
    inputEl.click();
    inputEl.dispatchEvent(new Event('blur'));
    fixture.detectChanges();
    expect(form.inputControl.untouched).toBe(false);
    expect(form.inputControl.touched).toBe(true);
    expect(inputDebugNormal.classes['ng-touched']).toBe(true);
  });

  it('should get a value from selected option and gets dirty', done => {
    expect(inputDebugNormal.classes['ng-pristine']).toBe(true);
    expect(form.inputControl.dirty).toBe(false);
    expect(form.inputControl.pristine).toBe(true);
    inputEl.value = 'cake';
    inputEl.dispatchEvent(new Event('input'));

    setTimeout(() => {
      expect(inputDebugNormal.componentInstance.value).toBe('cake');
      expect(form.inputControl.dirty).toBe(true); // ng-dirty will be place in a while not here yet
      fixture.detectChanges();
      expect(inputDebugNormal.classes['ng-dirty']).toBe(true);
      done();
    }, 160); // debounce time
  });

  it('should select a prepopulated value', () => {
    expect(form.inputControl.touched).toBe(false);
    expect(inputDebugNormal.classes['ng-untouched']).toBe(true);
    expect(form.inputControl.pristine).toBe(true);
    expect(inputDebugNormal.classes['ng-pristine']).toBe(true);
    expect(inputDebugPrepopulated.componentInstance.input.nativeElement.value).toBe('Potatoes');
    expect(inputDebugPrepopulated.componentInstance.value).toBe('Potatoes');
  });
});
