import { ElementRef, Renderer2 } from '@angular/core';
export default function(renderer: Renderer2, el: ElementRef, errorText: string) {
  let errorContainer = el.nativeElement.querySelector('[error-container]');
  if (errorContainer !== null) { // there is a slot for error
    addError(renderer, errorContainer, errorText);
  } else { // put error at the bottom
    errorContainer = renderer.createElement('div');
    addError(renderer, errorContainer, errorText);
    renderer.appendChild(el.nativeElement, errorContainer);
  }
}

function addError (renderer, container, errorText) {
  const error = renderer.createText(errorText);
  renderer.addClass(container, 'errorDirective_error');
  renderer.appendChild(container, error);
}
