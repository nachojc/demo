import { ErrorDirective } from './error.directive';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

@Component({
  template: `<div error-message="This is the error"></div>`
})
class TestErrorDirectiveComponent { }

describe('Directive: ErrorDirective', () => {

  let component: TestErrorDirectiveComponent;
  let fixture: ComponentFixture<TestErrorDirectiveComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestErrorDirectiveComponent, ErrorDirective]
    });
    fixture = TestBed.createComponent(TestErrorDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('div'));
    fixture.detectChanges();
  });

  it('should display the right error message', () => {
    const errorContainer = inputEl.nativeElement.querySelector('.errorDirective_error');
    expect(errorContainer).toBeTruthy();
    expect(errorContainer.textContent).toEqual('This is the error');
  });
});
