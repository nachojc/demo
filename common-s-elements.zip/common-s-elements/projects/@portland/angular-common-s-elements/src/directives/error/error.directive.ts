import { Directive, Input, ElementRef, Renderer2, AfterViewInit } from '@angular/core';
import error from './error';

@Directive({
  selector: '[error-message]'
})
export class ErrorDirective implements AfterViewInit {

  @Input('error-message') errorText: string;

  constructor (private el: ElementRef, private renderer: Renderer2) {
   }

  ngAfterViewInit () {
    error(this.renderer, this.el, this.errorText);
  }
}
