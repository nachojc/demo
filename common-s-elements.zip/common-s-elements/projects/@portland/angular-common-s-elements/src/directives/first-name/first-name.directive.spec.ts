import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FirstNameDirective } from './first-name.directive';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  template: `
  <form myForm="ngForm">
    <input name="firstName" firstName #firstName1="ngModel" [(ngModel)]="firstName">
  </form>`
})
class TestFirstNameDirectiveComponent {
  firstName: string;
}

describe('Directive: FirstNameDirective', () => {

  let component: TestFirstNameDirectiveComponent;
  let fixture: ComponentFixture<TestFirstNameDirectiveComponent>;
  let inputEl: DebugElement;
  let firstName1;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestFirstNameDirectiveComponent, FirstNameDirective],
      imports: [CommonModule, FormsModule],
    });
    fixture = TestBed.createComponent(TestFirstNameDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    firstName1 = inputEl.references['firstName1'];
    fixture.detectChanges();
  });

  it('should display a label for the first name', () => {
    const labelContainer = inputEl.nativeElement.querySelector('.labelDirective_label');
    expect(labelContainer.textContent).toEqual('First name');
  });

  it('should display an error message as follows for the first name', async(() => {
    const errorContainer = inputEl.nativeElement.querySelector('.errorDirective_error');
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(errorContainer.textContent).toEqual('Your first name must not include numbers or symbols, only \'-\' is accepted, between 2 and 20 characteres.');
    })
  }));

  it('should not allow numbers or special chars other than "-"', async(() => {
    component.firstName = '33f3%%';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      // do we need to test error container is actually displaying?
      expect(firstName1.valid).toBe(false);
    });
  }));

  it('should only accept these characters: "-", spaces and letters', async(() => {
    component.firstName = 'Test Pass';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(true);
    });
  }));

  it('should contain at least 2 valid characters', async(() => {
    component.firstName = 'n';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(false);
    });
  }));

  it('should not contain more than 20 valid characters', async(() => {
    component.firstName = "it can't contain more than 20 characters";
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(false);
    });

    component.firstName = 'no longer than twenty';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(false);
    });
  }));

  it('should not validate when value is empty', async(() => {
    component.firstName = '';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(true);
    });
  }));

  it('should not allow special characters between uppercase and lowercase like "[", "^"', async(() => {
    component.firstName = 'a[A]zs';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(false);
    });

    component.firstName = '[aszs';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(false);
    });

    component.firstName = '^aszs^';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(false);
    });

    component.firstName = 'sszs]';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(firstName1.valid).toBe(false);
    });
  }));
});
