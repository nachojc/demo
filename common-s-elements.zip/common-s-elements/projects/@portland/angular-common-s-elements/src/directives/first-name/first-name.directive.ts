import { Directive, ElementRef, Renderer2, forwardRef, AfterViewInit } from '@angular/core';
import { NG_VALIDATORS, Validator, FormControl, ValidationErrors } from '@angular/forms';
import firstNameValidator from './first-name.validator';
import label from '../label/label';
import error from '../error/error';

@Directive({
  selector: '[firstName][ngModel]', // TODO: see if applicable to reactive.. [firstName][formControlName], [firstName][formControl]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => FirstNameDirective),
      multi: true
    }
  ]
})
export class FirstNameDirective implements AfterViewInit, Validator {
  // @see https://blog.thoughtram.io/angular/2016/03/14/custom-validators-in-angular-2.html
  constructor (private el: ElementRef, private renderer: Renderer2) { }

   ngAfterViewInit () {
    label(this.renderer, this.el, 'First name');
    error(this.renderer, this.el,
      'Your first name must not include numbers or symbols, only \'-\' is accepted, between 2 and 20 characteres.');
  }

  validate (c: FormControl): ValidationErrors | null {
    return firstNameValidator(c);
  }
}
