import { ValidationErrors, AbstractControl } from '@angular/forms';

const firstNamePattern = /^[a-zA-Z]([a-zA-Z\'\-\s]{0,18})[a-zA-Z]$/;

export default function firstNameValidate(c: AbstractControl): ValidationErrors | null {
  return (c.value && c.value.length > 0 && !firstNamePattern.test(c.value)) ?
    { firstNameValidator: { valid: false } } :
    null;
}
