import { Directive, ElementRef, Renderer2, Input, AfterViewInit } from '@angular/core';
import label from './label';

@Directive({
  selector: '[label]'
})
export class LabelDirective implements AfterViewInit {

  @Input('label') labelText: string;

  constructor (private el: ElementRef, private renderer: Renderer2) { }

  ngAfterViewInit () {
    label(this.renderer, this.el, this.labelText);
  }
}
