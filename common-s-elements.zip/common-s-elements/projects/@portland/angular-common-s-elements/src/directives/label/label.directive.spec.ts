import { LabelDirective } from './label.directive';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

@Component({
  template: `
    <div label="This is the label"></div>
    <div required label="This is the required label"></div>
  `
})
class TestLabelDirectiveComponent { }

describe('Directive: LabelDirective', () => {

  let component: TestLabelDirectiveComponent;
  let fixture: ComponentFixture<TestLabelDirectiveComponent>;
  let inputEl: DebugElement[];

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestLabelDirectiveComponent, LabelDirective]
    });
    fixture = TestBed.createComponent(TestLabelDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.queryAll(By.css('div'));
    fixture.detectChanges();
  });

  it('should display the right label value', () => {
    const labelContainer = inputEl[0].nativeElement.querySelector('.labelDirective_label');
    expect(labelContainer).toBeTruthy();
    expect(labelContainer.textContent).toEqual('This is the label');
  });

  it('should display the star next to label value when required', () => {
    const labelContainer = inputEl[1].nativeElement.querySelector('.labelDirective_label');
    expect(labelContainer).toBeTruthy();
    expect(labelContainer.textContent).toEqual('This is the required label*');
    expect(labelContainer.querySelector('.labelDirective_required')).toBeTruthy();
  });
});
