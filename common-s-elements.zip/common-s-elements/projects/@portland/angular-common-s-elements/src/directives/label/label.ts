import { ElementRef, Renderer2 } from '@angular/core';
export default function(renderer: Renderer2, el: ElementRef, labelText: string) {
  const labelContainer = el.nativeElement.querySelector('[label-container]');
  const label = createLabel(renderer, el, labelText);
  if (labelContainer !== null) { // there is a slot for label
    renderer.appendChild(labelContainer, label);
  } else { // put label at the beginning
    renderer.insertBefore(el.nativeElement, label, el.nativeElement.children[0]);
  }
}

function createLabel(renderer: Renderer2, el: ElementRef, text: string) {
  // <label class="labelDirective_label">
  //  {{text}}
  //  <span class="labelDirective_required" *ngIf="required">*</span>
  // </label>
  const label = renderer.createElement('label');
  renderer.addClass(label, 'labelDirective_label');
  const labelText = renderer.createText(text);
  renderer.appendChild(label, labelText);
  if (el.nativeElement.getAttribute('required') !== null) {
    const required = renderer.createElement('span');
    renderer.addClass(required, 'labelDirective_required');
    const requiredText = renderer.createText('*');
    renderer.appendChild(required, requiredText);
    renderer.appendChild(label, required);
  }
  return label;
}
