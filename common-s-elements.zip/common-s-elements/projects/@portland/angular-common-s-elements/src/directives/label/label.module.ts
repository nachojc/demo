import { NgModule } from "@angular/core";
import { LabelDirective } from "./label.directive";

@NgModule({
  declarations: [
    LabelDirective
  ],
  exports: [
    LabelDirective
  ]
})

export class SLabelDirectiveModule { }
