import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[numeric]'
})
export class NumericDirective {
  @HostListener('keypress', ['$event']) isNumber(event) {
    const charCode = (event.which) ? event.which : event.keyCode;

    return (charCode >= 48 && charCode <= 57) || this.isSpecialKey(charCode);
  }

  private isSpecialKey(charCode) {
    return charCode === 8 || charCode === 13 || charCode === 16
      || charCode === 37 || charCode === 38 || charCode === 39
      || charCode === 40 || charCode === 46 || charCode === 9;
  }
}
