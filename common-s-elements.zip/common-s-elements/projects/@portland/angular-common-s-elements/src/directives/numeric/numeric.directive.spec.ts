import { NumericDirective } from './numeric.directive';

describe('NumericDirective', () => {
  it('should create an instance', () => {
    const directive = new NumericDirective();
    expect(directive).toBeTruthy();
  });

  it('#isNumber should return the right boolean depending on event keyCode value', () => {
    const directive = new NumericDirective();

    expect(directive.isNumber({ keyCode: 6 })).toBe(false);
    expect(directive.isNumber({ keyCode: 49 })).toBe(true);
    expect(directive.isNumber({ keyCode: 9 })).toBe(true);
  });
});
