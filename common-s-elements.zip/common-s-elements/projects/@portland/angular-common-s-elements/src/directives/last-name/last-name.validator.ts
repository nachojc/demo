import { ValidationErrors, AbstractControl } from '@angular/forms';

const lastNamePattern = /^[a-zA-Z]([a-zA-Z\'\-\s]{0,28})[a-zA-Z]$/;


export default function LastNameValidate(c: AbstractControl): ValidationErrors | null {
  return (c.value && c.value.length > 0 && !lastNamePattern.test(c.value)) ?
    { lastNameValidator: { valid: false } } :
    null;
}
