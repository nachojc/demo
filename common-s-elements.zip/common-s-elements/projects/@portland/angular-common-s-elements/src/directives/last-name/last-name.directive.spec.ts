import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { LastNameDirective } from './last-name.directive';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  template: `
  <form myForm="ngForm">
    <input name="lastName" lastName #lastName1="ngModel" [(ngModel)]="lastName">
  </form>`
})
class TestLastNameDirectiveComponent {
  lastName: string;
 }

describe('Directive: LastNameDirective', () => {

  let component: TestLastNameDirectiveComponent;
  let fixture: ComponentFixture<TestLastNameDirectiveComponent>;
  let inputEl: DebugElement;
  let lastName1;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestLastNameDirectiveComponent, LastNameDirective],
      imports: [CommonModule, FormsModule],
    });
    fixture = TestBed.createComponent(TestLastNameDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    lastName1 = inputEl.references['lastName1'];
    fixture.detectChanges();
  });

  it('should display a label for the last name', () => {
    const labelContainer = inputEl.nativeElement.querySelector('.labelDirective_label');
    expect(labelContainer.textContent).toEqual('Last name');
  });

  it('should display an error message as follows for the last name', async(() => {
    const errorContainer = inputEl.nativeElement.querySelector('.errorDirective_error');
    fixture.whenStable().then( () => {
      fixture.detectChanges();
      expect(errorContainer.textContent).toEqual('Your last name must not include numbers or symbols, only \'-\' is accepted, between 2 and 30 characteres.');
    })
  }));

  it('should not allow numbers or special chars other than "-"', async(() => {
    component.lastName = '33f3%%';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      // do we need to test error container is actually displaying?
      expect(lastName1.valid).toBe(false);
    });
  }));

  it('should only accept these characters: "-", spaces and letters', async(() => {
    component.lastName = 'Test Pass';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(true);
    });
  }));

  it('should contain at least 2 valid characters', async(() => {
    component.lastName = 'n';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });
  }));

  it('should not contain more than 30 valid characters', async(() => {
    component.lastName = "it can't contain more than 30 characters";
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });

    component.lastName = "no longer than thirty character";
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });
  }));

  it('should not validate when value is empty', async(() => {
    component.lastName = '';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(true);
    });
  }));

  it('should not allow empty spaces neither at the begining nor at the end', async(() => {
    component.lastName = '  a  ';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });
  }));

  it('should not allow special characters between uppercase and lowercase like "[", "^"', async(() => {
    component.lastName = 'a[A]zs';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });

    component.lastName = '[aszs';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });

    component.lastName = '^aszs^';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });

    component.lastName = 'sszs]';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(lastName1.valid).toBe(false);
    });
  }));
});
