import { Directive, ElementRef, Renderer2, forwardRef, AfterViewInit } from '@angular/core';
import { NG_VALIDATORS, Validator, FormControl, ValidationErrors } from '@angular/forms';
import lastNameValidator from './last-name.validator';
import label from '../label/label';
import error from '../error/error';

@Directive({
  selector: '[lastName][ngModel]', // TODO: like first name [lastName][formControl]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => LastNameDirective),
      multi: true
    }
  ]
})
export class LastNameDirective implements AfterViewInit, Validator {
  constructor(private el: ElementRef, private renderer: Renderer2) { }

   ngAfterViewInit () {
    label(this.renderer, this.el, 'Last name');
    error(this.renderer, this.el,
      'Your last name must not include numbers or symbols, only \'-\' is accepted, between 2 and 30 characteres.');
  }

  validate (c: FormControl): ValidationErrors | null {
    return lastNameValidator(c);
  }
}
