import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { HighlightJsModule } from 'ngx-highlight-js';

import { SElementsLibModule } from '@portland/angular-common-s-elements'; // includes SFormLibModule and SLayoutAndNavigationLibModule
// import { SFormLibModule } from '@portland/angular-common-s-elements';
// import { SLayoutAndNavigationLibModule } from '@portland/angular-common-s-elements';
// import { HeaderComponentModule } from '@portland/angular-common-s-elements';
import { TemplateDrivenFormExampleComponent } from './template-driven-form-example/template-driven-form-example.component';
import { ModelDrivenFormExampleComponent } from './model-driven-form-example/model-driven-form-example.component';
import { SInputDemoComponent } from './catalogue-showroom/s-input-demo/s-input-demo.component';
import { SCheckboxDemoComponent } from './catalogue-showroom/s-checkbox-demo/s-checkbox-demo.component';
import { SSortcodeDemoComponent } from './catalogue-showroom/s-sortcode-demo/s-sortcode-demo.component';
import { SSelectDemoComponent } from './catalogue-showroom/s-select-demo/s-select-demo.component';
import { SHeaderDemoComponent } from './catalogue-showroom/s-header-demo/s-header-demo.component';
import { SBreadcrumbsDemoComponent } from './catalogue-showroom/s-breadcrumbs-demo/s-breadcrumbs-demo.component';
import { LabelDemoComponent } from './catalogue-showroom/label-demo/label-demo.component';
import { ErrorDemoComponent } from './catalogue-showroom/error-demo/error-demo.component';
import { FirstNameDemoComponent } from './catalogue-showroom/first-name-demo/first-name-demo.component';
import { LastNameDemoComponent } from './catalogue-showroom/last-name-demo/last-name-demo.component';
import { NumericDemoComponent } from './catalogue-showroom/numeric-demo/numeric-demo.component';

@NgModule({
  declarations: [
    AppComponent,
    TemplateDrivenFormExampleComponent,
    ModelDrivenFormExampleComponent,
    SInputDemoComponent,
    SCheckboxDemoComponent,
    SSortcodeDemoComponent,
    SSelectDemoComponent,
    SHeaderDemoComponent,
    SBreadcrumbsDemoComponent,
    LabelDemoComponent,
    ErrorDemoComponent,
    FirstNameDemoComponent,
    LastNameDemoComponent,
    NumericDemoComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    HighlightJsModule,
    SElementsLibModule // SFormLibModule and SLayoutAndNavigationLibModule
  ],
  providers: [
    {
     provide: APP_BASE_HREF,
     useValue: window.location.pathname.split('/')[1] + '/'
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
