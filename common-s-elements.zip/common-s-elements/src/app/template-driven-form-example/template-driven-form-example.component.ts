import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'template-driven-form-example',
  templateUrl: './template-driven-form-example.component.html',
  styleUrls: ['../../styles/forms-container.css']
})
export class TemplateDrivenFormExampleComponent implements OnInit {

  myFormTemplate: any;
  options = ['', 'this', 'is', 'my', 'only', 'option'];
  alphaValue: String = 'alpha initial value';

  constructor() { }

  ngOnInit() {
  }

  onSubmitTemp (myFormValue) {
    this.myFormTemplate = myFormValue;

    if (this.myFormTemplate.alpha.length > 6) {
      this.alphaValue = this.myFormTemplate.alpha;
    }
  }

}
