import { Component } from '@angular/core';

@Component({
  selector: 'error-demo',
  templateUrl: './error-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class ErrorDemoComponent { }
