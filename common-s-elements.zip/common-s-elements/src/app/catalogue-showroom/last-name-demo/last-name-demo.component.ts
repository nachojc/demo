import { Component } from '@angular/core';

@Component({
  selector: 'last-name-demo',
  templateUrl: './last-name-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class LastNameDemoComponent {
  myFormTemplate: any;

  onSubmitTemp (myFormValue) {
    this.myFormTemplate = myFormValue;
  }
}
