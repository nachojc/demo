import { Component } from '@angular/core';
import { BreadcrumbItem } from '@portland/angular-common-s-elements';

@Component({
  selector: 's-breadcrumbs-demo',
  templateUrl: './s-breadcrumbs-demo.component.html',
  styleUrls: ['./s-breadcrumbs-demo.component.scss', '../../../styles/page.css', './s-button.css']
})
export class SBreadcrumbsDemoComponent {
  olaNavigation: BreadcrumbItem[] = [{ label: 'About you', status: 'selected' }, { label: 'Financial details' }, { label: 'Summary' }, { label: 'Sign up' }];

  previousPageFunction(navigation) {
    let selected = false;
    let i = 0;
    let posic = 0;
    while (i < navigation.length && !selected) {
      if (navigation[i].status === 'selected') {
        posic = i;
        selected = true;
      }
      i++;
    }

    if (selected && posic - 1 >= 0) {
      navigation[posic] = { label: navigation[posic].label };
      navigation[posic - 1] = { label: navigation[posic - 1].label, status: 'selected' };
    } else {
      if (navigation[navigation.length - 1].status === 'ok' || navigation[navigation.length - 1].status === 'error') {
        navigation[navigation.length - 1] = { label: navigation[navigation.length - 1].label, status: 'selected' };
      }
    }
  }

  nextPageFunction(navigation, estado: string) {
    let selected = false;
    let i = 0;
    let posic = 0;
    while (i < navigation.length && !selected) {
      if (navigation[i].status === 'selected') {
        posic = i;
        selected = true;
      }
      i++;
    }

    if (selected) {
      navigation[posic] = { label: navigation[posic].label, status: estado };
      if (posic + 1 < navigation.length) {
        navigation[posic + 1] = { label: navigation[posic + 1].label, status: 'selected' };
      }
    }
  }
}
