import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SHeaderDemoComponent } from './s-header-demo.component';

describe('SHeaderDemoComponent', () => {
  let component: SHeaderDemoComponent;
  let fixture: ComponentFixture<SHeaderDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SHeaderDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SHeaderDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
