import { Component } from '@angular/core';

@Component({
  selector: 's-header-demo',
  templateUrl: './s-header-demo.component.html',
  styleUrls: ['./s-header-demo.component.scss', '../../../styles/page.css']
})
export class SHeaderDemoComponent { }
