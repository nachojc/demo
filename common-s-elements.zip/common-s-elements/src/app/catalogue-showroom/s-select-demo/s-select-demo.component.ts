import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 's-select-demo',
  templateUrl: './s-select-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class SSelectDemoComponent implements OnInit {
  public flatOptions: Array<number> = [11, 13, 15, 17, 19, 21];
  public flatNumber: Number;
  public selectedCurrency: String = 'EUR';

  myFormTemplate: any;
  myFormReactive: any;

  myForm: FormGroup;

  constructor(private form: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.form.group({
      flatNumber: new FormControl('')
    });
  }

  onSubmitTemp(myFormValue) {
    this.myFormTemplate = myFormValue;
  }

  onSubmitReact(myFormValue) {
    this.myFormReactive = myFormValue;
  }
}
