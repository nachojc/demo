import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SSortcodeDemoComponent } from './s-sortcode-demo.component';

describe('SSortcodeDemoComponent', () => {
  let component: SSortcodeDemoComponent;
  let fixture: ComponentFixture<SSortcodeDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SSortcodeDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SSortcodeDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
