import { Component } from '@angular/core';

@Component({
  selector: 's-sortcode-demo',
  templateUrl: './s-sortcode-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class SSortcodeDemoComponent {
  sc: String = '090128';
  sortCode: string;
  wrongValue: String = '0901XX';
  disabled: Boolean = true;
}
