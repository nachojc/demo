import { Component } from '@angular/core';

@Component({
  selector: 'label-demo',
  templateUrl: './label-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class LabelDemoComponent { }
