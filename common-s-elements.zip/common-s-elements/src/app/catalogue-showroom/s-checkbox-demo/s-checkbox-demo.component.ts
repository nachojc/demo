import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

@Component({
  selector: 's-checkbox-demo',
  templateUrl: './s-checkbox-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class SCheckboxDemoComponent implements OnInit {
  myFormTemplate: any;
  myFormReactive: any;

  standaloneValue: Boolean = true;

  checked: Boolean;

  myForm: FormGroup;

  constructor(private form: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.form.group({
      adios: new FormControl(this.checked)
    });
  }

  onSubmitReact (myFormValue) {
    this.myFormReactive = myFormValue;
  }

  onSubmitTemp (myFormValue) {
    this.myFormTemplate = myFormValue;
  }
}
