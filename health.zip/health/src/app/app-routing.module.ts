import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './component/main/main.component';
import { ErrorComponent } from './component/error/error.component';
import { AuthGuardService } from './services/guard.service';


const routes: Routes = [
  { path: '' , component: MainComponent, 
  canActivate: [AuthGuardService] },
  // canLoad: [AuthGuardService] },
  { path: 'error' , component: ErrorComponent },
  { path: '**', redirectTo: ''}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
