import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainComponent } from './component/main/main.component';
import { ErrorComponent } from './component/error/error.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HealthService } from './services/healt.service';
import { async } from '@angular/core/testing';

@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    ErrorComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

