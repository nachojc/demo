import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Subject, Observable, of } from 'rxjs';
import { first } from 'rxjs/operators';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class HealthService {
    private health$ = new Subject<boolean>();
    private _healthCheck: boolean;


    constructor(
        private router: Router,
        private http: HttpClient
        ) {}

    hasHealthCheck(): Observable<boolean> { 
        if (this._healthCheck === undefined){
            this.http.get('/api/healthz')
            .subscribe(res => {
                if (!!res && res['health'] === 'OK') {
                    this._healthCheck = true;
                    this.health$.next(this._healthCheck);
                } else {
                    this._healthCheck = false;
                    this.router.navigate(['/error']);
                }
            },
            err => {
                this._healthCheck = false;
                this.router.navigate(['/error']);
            })
            return this.health$.asObservable().pipe(first());
        } else {
            return of(this._healthCheck);
        }
    }

}
