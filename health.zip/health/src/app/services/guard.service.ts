import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { HealthService } from './healt.service';
import { Observable, Subject } from 'rxjs';
import { async } from '@angular/core/testing';

@Injectable({
  providedIn: 'root',
})
export class AuthGuardService implements CanActivate {
  constructor(
      private router: Router,
      private health: HealthService
      ) {}


  canActivate(): Observable<boolean> {

    return this.health.hasHealthCheck();
  }
}