// (function(){
    module.exports={
        root:__dirname,
        static:'srv/static',
        routes:'srv/routes'
    };
// }());