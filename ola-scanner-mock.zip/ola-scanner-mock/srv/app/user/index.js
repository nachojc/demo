const _ = require('lodash');

module.exports = function(){
    let userDB={};

    return {
        setNewUser:_setUser,
        getUserStatus: _getUserStatus,
        setFile: _setFile,
        setNewFile: _setNewFile,
        getUserByToken: _getUserByToken,
        reset:_resetUsers
    };


    function _setFile(req){
        let id= req.ID;

        if (!!userDB['_'+id]){
            let files = req.files;
            for (let i = 0; i < files.length; i++) {
                const element = files[i];
                
                let file = {
                    name:element.name,
                    path:'http://localhost:4400/images/'+element.file
                }
    
                userDB['_'+id].files.push(file);
            }
        }
        return !userDB['_'+id]?[]:userDB['_'+id].files;
    }

    function _setUser(req){
        let id= req.ID;

        if (!userDB['_'+id] || req.re){
            let token = ''+Math.random()*10000;

            token= token.substr(0,token.indexOf('.'));
            userDB['_'+id] = userDB['_'+id] || {};

            userDB['_'+id].phone = req.phone;
            userDB['_'+id].token = token;
            userDB['_'+id].name = req.name;
            userDB['_'+id].id = id;
            if(!userDB['_'+id].date) {
                userDB['_'+id].date= Date.now();
            }
            userDB['_'+id].files=!userDB['_'+id].files?[]:userDB['_'+id].files;
        }else{
            userDB['_'+id].waiting = true;
        }

        return userDB['_'+id];
    }

    
    function _getUserStatus(req){
        let id = req ? req.ID : 0;

        return {
            error:!userDB['_'+id],
            files:!!userDB['_'+id] ? userDB['_'+id].files : []};
    }

    function _getUserByToken(req){
        let token = req.query.token;

        let user = _.filter( userDB,
            (usr)=>usr.token===token
        );

        return user.length ? user[0]: {};
    }

    function _setNewFile(req){
        let id= req.ID;
        let result = [];
        
        if (!!userDB['_'+id]){
            let user = userDB['_'+id];
            req.files.forEach(file => {
                file.data = Date.now()

                user.files.push(file);
                result.push(file);
            });

        }
        return result;
    }

    function _resetUsers(req){
        userDB={};
    }
}();