module.exports = function(users){

    var express = require('express');
    var router = express.Router();
    
    const DELAY = 3000;
    // middleware that is specific to this router
    router
        .use(function timeLog (req, res, next) {
            console.log('Time: ', Date.now());
            next();
        })
        .get('/', function (req, res) {

                res.jsonp({
                    msg:'',
                    error:0,
                    data: users.getUserByToken(req) 
                });

        });

    return router;
};
