module.exports = function(users){

    var express = require('express');
    var router = express.Router();
    
    const DELAY = 3000;
    // middleware that is specific to this router
    router
        .use(function timeLog (req, res, next) {
            console.log('Time: ', Date.now());
            next();
        })
        .post('/', function (req, res) {
            console.log(req.body);
            setTimeout(function() {
                res.jsonp({
                    msg:'',
                    error:0,
                    data: users.setNewUser(req.body) 
                });
            }, DELAY);
        });

    return router;
};
