module.exports = function(users){

    var express = require('express');
    var router = express.Router();
    
    router
        .use(function timeLog (req, res, next) {
            console.log('Time: ', Date.now());
            next();
        })
        .post('/', function (req, res) {
            console.log(req.body);
            let data=users.setFile(req.body) ;
            res.jsonp({
                msg:'',
                error:!!data.length,
                data: data 
            });
        })
        .get('/about', function (req, res) {
            res.send('About birds');
        });

    return router;
};
