module.exports = function(users){
    
        var express = require('express');
        var router = express.Router();
        
        const DELAY = 3000;
        // middleware that is specific to this router
        router
            .use(function timeLog (req, res, next) {
                console.log('Time status: ', Date.now());
                next();
            })
            .get('/', function (req, res) {
                console.log(req.query);
                let data=users.getUserStatus(req.query) ;
                res.jsonp({
                    msg:'',
                    error:data.error,
                    data: data.files 
                });
            });
    
        return router;
    };
    