module.exports = function(users){
    
        var express = require('express');
        var router = express.Router();
        


        router
            .use(function timeLog (req, res, next) {
                console.log('Time status: ', Date.now());
                next();
            })
            .get('/', function (req, res) {
                console.log(req.query);
                let data=users.reset(req.query) ;
                res.jsonp({
                    msg:'Reset DB',
                    data: {} 
                });
            });
    
        return router;
    };
    