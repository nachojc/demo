module.exports = function(users){

    var express = require('express');
    var router = express.Router();
    
    router
        .use(function timeLog (req, res, next) {
            console.log('Time: ', Date.now());
            next();
        })
        .put('/', function (req, res) {
            console.log(req.body);

                res.jsonp({
                    msg:'',
                    error:0,
                    data: users.setNewFile(req.body) 
                });
        });

    return router;
};
