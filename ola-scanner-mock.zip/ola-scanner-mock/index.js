

    const PATH = require('./srv/config');
    const express = require('express');
    const bodyParser = require('body-parser');
    const cors = require('cors');

    const app = express();

    const users = require ('./srv/app/user');

    app.use(cors());
    // app.use(bodyParser.urlencoded({extended: false}));
    app.use(bodyParser.json({limit: '50MB' }));

    
    app.use(express.static(PATH.static));

    app.use('/send',  require('./'+ PATH.routes + '/send')(users));
    app.use('/status',  require('./'+ PATH.routes + '/status')(users));
    app.use('/add',  require('./'+ PATH.routes + '/files')(users));
    app.use('/checktoken',  require('./'+ PATH.routes + '/checktoken')(users));
    app.use('/upload',  require('./'+ PATH.routes + '/upload')(users));
    app.use('/reset',  require('./'+ PATH.routes + '/reset')(users));

    var srv = app.listen(4400,'localhost',function () {
        const config = srv.address();
        console.log('App runing at:',config.address,':',config.port);
    });
