const { logColor } = require("./utils/colors");

logColor.error("This is an error message");
logColor.success("This is a success message");
logColor.info("This is an info message");
logColor.warning("This is a warning message");


console.log('\x1b[36m%s\x1b[0m', 'I am cyan');  //cyan
console.log('\x1b[33m%s\x1b[0m', "stringToMakeYellow");  //yellow
console.log('\x1b[36m%s\x1b[0m', 'I am cyan');  //cyan
console.log('\x1b[33m%s\x1b[0m', "stringToMakeYellow");  //yellow