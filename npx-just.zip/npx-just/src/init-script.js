#!/usr/bin/env node
const fs = require("fs");

const yargs = require("yargs");
const { hideBin } = require("yargs/helpers");
const argv = yargs(hideBin(process.argv)).parse()["_"];
// console.log(argv);

const { getProjectName } = require("./utils/input-process");
const { setupRepository } = require("./utils/setup-process");
const { logColor } = require("./utils/colors");



const customizeProject = async (projectName) => {
  const projectPath = path.join(process.cwd(), projectName);
};

const main = async () => {
  const projectName = await getProjectName(argv);
if (!projectName) {
    logColor.error("Project name is required. Exiting.");
    process.exit(1);
  }
  await setupRepository(projectName, argv);

  // await customizeProject(projectName);
};

main().catch(console.error);
