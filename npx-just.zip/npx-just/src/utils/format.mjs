

export const formatProjectName = (name = "") => {
  // Basic validation: non-empty, no special characters except hyphens and underscores
  //  return /^[a-zA-Z0-9-_]+$/.test(name);
  const formatName = name
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-_@]/g, "");

  return formatName.length > 0 ? formatName : null;
};
