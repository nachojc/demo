export const setupRepository = async (projectName, argv) => {
  const { createFolder } = await import("./input-process.js");
  const { logColor } = await import("./colors.js");
  const { exec } = await import("child_process");
  const path = (await import("path")).default;
  const fs = (await import("fs")).default;

  const projectPath = await createFolder(projectName);

  // Initialize git repository
  await new Promise((resolve, reject) => {
    exec("git init", { cwd: projectPath }, (error, stdout, stderr) => {
      if (error) {
        logColor.error(`Error initializing git: ${error.message}`);
        return reject(error);
      }
      if (stderr) {
        logColor.warning(`Git stderr: ${stderr}`);
      }
      logColor.success(
        `Initialized empty Git repository in ${projectPath}/.git/`
      );
      resolve();
    });
  });

  // Create README.md
  const readmePath = path.join(projectPath, "README.md");
  fs.writeFileSync(
    readmePath,
    `# ${projectName}\n\nProject initialized with npx-just.\n`
  );
  logColor.success(`Created README.md`);

  // Create .gitignore
  const gitignorePath = path.join(projectPath, ".gitignore");
  fs.writeFileSync(gitignorePath, `node_modules/\ndist/\n.env\n`);
  logColor.success(`Created .gitignore`);

  // Optionally install dependencies if --install flag is present
  if (argv.includes("--install")) {
    logColor.info("Installing dependencies...");
    await new Promise((resolve, reject) => {
      exec("npm install", { cwd: projectPath }, (error, stdout, stderr) => {
        if (error) {
          logColor.error(`Error installing dependencies: ${error.message}`);
          return reject(error);
        }
        if (stderr) {
          logColor.warning(`npm stderr: ${stderr}`);
        } else {
          logColor.success(`Dependencies installed successfully.`);
        }
        resolve();
      });
    });
  } else {
    logColor.info(
      "Skipping dependency installation. Use --install to install dependencies."
    );
  }

  logColor.success(`Project ${projectName} setup complete!`);
};
