
// Reset = "\x1b[0m"
// Bright = "\x1b[1m"
// Dim = "\x1b[2m"
// Underscore = "\x1b[4m"
// Blink = "\x1b[5m"
// Reverse = "\x1b[7m"
// Hidden = "\x1b[8m"

// FgBlack = "\x1b[30m"
// FgRed = "\x1b[31m"
// FgGreen = "\x1b[32m"
// FgYellow = "\x1b[33m"
// FgBlue = "\x1b[34m"
// FgMagenta = "\x1b[35m"
// FgCyan = "\x1b[36m"
// FgWhite = "\x1b[37m"
// FgGray = "\x1b[90m"

// BgBlack = "\x1b[40m"
// BgRed = "\x1b[41m"
// BgGreen = "\x1b[42m"
// BgYellow = "\x1b[43m"
// BgBlue = "\x1b[44m"
// BgMagenta = "\x1b[45m"
// BgCyan = "\x1b[46m"
// BgWhite = "\x1b[47m"
// BgGray = "\x1b[100m"

export const logColors = {
  Red: `\x1b[31m`,
  Green: `\x1b[32m`,
  Yellow: `\x1b[33m`,
  Blue: `\x1b[34m`,
  Magenta: `\x1b[35m`,
  Cyan: `\x1b[36m`,
  White: `\x1b[37m`,
  Reset: `\x1b[0m`,
  Bold: `\x1b[1m`,
  Underline: `\x1b[4m`,
  Inverse: `\x1b[7m`,
};

const { Red, Green, Yellow, Blue,Reset } = logColors;
const logColorFormats = {
  red: `${Red}%s${Reset}`,
  green: `${Green}%s${Reset}`,
  yellow: `${Yellow}%s${Reset}`,
  blue: `${Blue}%s${Reset}`,
};

export const getTextColor = (color, text) => {
  return `${color}${text}${Reset}`;
}

export const logWithColor = (text, color) => {
  console.log(color || logColors.Reset, text);
};

 const logError = (text) => {
  logWithColor(text, logColorFormats.red);
};

 const logSuccess = (text) => {
  logWithColor(text, logColorFormats.green);
};

 const logInfo = (text) => {
  logWithColor(text, logColorFormats.cyan);
};

 const logWarning = (text) => {
  logWithColor(text, logColorFormats.yellow);
};

export const logColor = {
  error: logError,
  success: logSuccess,
  info: logInfo,
  warning: logWarning,
};
