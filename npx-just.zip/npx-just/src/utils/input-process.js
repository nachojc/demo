import fs from "fs";
import path from "path";
import readline from "readline";
import { formatProjectName } from "./format.mjs";

export const askQuestion = (rl, question) => {
  return new Promise((resolve) => {
    rl.question(question, (answer) => {
      resolve(answer);
    });
  });
};

export const readProjectName = async () => {
  const rl = createInterface();
  const projectName = await askQuestion(rl, "Enter project name: ");
  console.log(`Project name set to: ${projectName}`);
  rl.close();

  return projectName;
};

export const createInterface = () => {
  return readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
};

export const confirmationPrompt = async (message) => {
  const rl = createInterface();
  const answer = (await askQuestion(rl, message + " (y/n): ")) || "y";
  rl.close();
  return answer.toLowerCase() === "y" || answer.toLowerCase() === "yes";
};

export const getProjectName = async (argv) => {
  let projectName = argv.length > 0 ? formatProjectName(argv[0]) : null;
  console.log(`Project name set to: ${projectName}`);
  if (!projectName || !(await confirmationPrompt("Is this correct?"))) {
    projectName = formatProjectName(await readProjectName());
    if (!projectName) {
      console.error("Invalid project name. Exiting.");
      process.exit(1);
    }
    console.log(`Project name set to: ${projectName}`);
  }

  return projectName;
};

export const createFolder = async (name) => {
  const { getTextColor, logColors } = await import("./colors.js");
  const projectPath = path.join(process.cwd(), name);

  if (!fs.existsSync(projectPath)) {
    fs.mkdirSync(projectPath);
    console.log(
      `Created project directory: ${getTextColor(logColors.Green, projectPath)}`
    );
  } else {
    console.log(`Project directory already exists: ${projectPath}`);
  }

  return projectPath;
};
