import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { MainComponent } from './components/main/main.component';

import { UICommonModule } from './modules/ui/common/ui.common.module';
import { UIModalModule } from './modules/ui/modal/modal.module';
import { UIShapesModule } from './modules/ui/shapes/shapes.module';

import { ComunicationService } from './services/comunication/comunication.service';


@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MainComponent,
    
  ],
  imports: [
    BrowserModule,
    UICommonModule,
    UIModalModule,
    UIShapesModule,
    HttpClientModule
  ],
  providers: [ComunicationService],
  bootstrap: [AppComponent]
})
export class AppModule { }
