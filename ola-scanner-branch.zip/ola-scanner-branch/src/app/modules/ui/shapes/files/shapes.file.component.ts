
import { Component, Input } from '@angular/core';

@Component({
  selector: 'san-shapes-file',
  templateUrl: './shapes.file.component.html',
  styleUrls: ['./shapes.file.component.scss']
})
export class ShapesFileComponent {
  @Input() file;
}
