import { TestBed, async } from '@angular/core/testing';
import {} from 'jasmine';

import { ShapesFileComponent } from './shapes.file.component';


describe('AppComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [
            ShapesFileComponent
        ],
      }).compileComponents();
    }));

    it('should create the Header', async(() => {
        const fixture = TestBed.createComponent(ShapesFileComponent);
        const com = fixture.debugElement.componentInstance;
        expect(com).toBeTruthy();
      }));


});