import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ShapesFileComponent } from './files/shapes.file.component';


@NgModule({
  imports: [
    CommonModule     
  ],
  declarations: [
    ShapesFileComponent
  ],
  exports:[
    ShapesFileComponent
  ],
  providers: []
})
export class UIShapesModule {}