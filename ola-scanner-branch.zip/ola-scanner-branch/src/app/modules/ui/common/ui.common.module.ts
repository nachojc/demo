import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';

import { CommonModule } from '@angular/common';
import { CommonButtonComponent } from './button/button.component';
import { CommonImputComponent } from './input/input.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule      
  ],
  declarations: [
     CommonButtonComponent,
     CommonImputComponent
  ],
  exports:[
     CommonButtonComponent,
     CommonImputComponent
  ],
  providers: []
})
export class UICommonModule { }