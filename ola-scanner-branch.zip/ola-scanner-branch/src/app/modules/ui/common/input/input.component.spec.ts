import { TestBed, async } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';

import { CommonImputComponent } from './input.component';

describe('AppComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [
          CommonImputComponent
        ],
        imports: [FormsModule]
      }).compileComponents();
    }));

    it('should create ', async(() => {
        const fixture = TestBed.createComponent(CommonImputComponent);
        const com = fixture.debugElement.componentInstance;
        expect(com).toBeTruthy();
      }));








});