
import { Component,EventEmitter, Input, Output } from '@angular/core';
import {NgForm} from '@angular/forms';


@Component({
  selector: 'san-ui-common-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class CommonImputComponent  {
    // @Input() name: string;
    @Input() name: string;
    @Input() label: string;
    @Input() placeholder: string;
    @Input() type: string;
    @Input() required: boolean;
    @Input() value: string='';

    @Output() onBlur = new EventEmitter<object>();
    @Output('change') inputChange = new EventEmitter<object>();


    public error:string='';

    blurValue(){
      this.onBlur.emit({name:this.name,value:this.value});
    }
    onInputChange(e){
      this.inputChange.emit({name:this.name,value:this.value});
    }
}
