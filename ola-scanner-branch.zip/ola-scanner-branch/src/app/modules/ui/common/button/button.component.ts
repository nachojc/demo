
import { Component, Input } from '@angular/core';

@Component({
  selector: 'san-ui-common-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class CommonButtonComponent {
    @Input() label: string;
    @Input() desabled: string='false';
    @Input() name: string='';


    isDisabled(){
      return !this.desabled;
    }
}
