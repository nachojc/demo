import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpParams } from "@angular/common/http";
import { Observable } from 'rxjs/Observable';
import { IntervalObservable } from 'rxjs/observable/IntervalObservable';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import 'rxjs/add/operator/mergeMap';
import 'rxjs/add/operator/takeUntil';



@Injectable()
export class ComunicationService{
    private url:any={};
    private token:string;
    private ID:string;
    private status$:any;
    private DELAY = 3000;
    
    private destroyed$: ReplaySubject<boolean> ;
    


    constructor(private http:HttpClient){
        this.url = {
            send:'/api/send/',
            status:'/api/status'
        };
    }

    setToken(token:string){
        this.token=token;
    }
    getToken(): string {
        return this.token;
    }
    setID(ID:string){
        this.ID=ID;
    }
    sendMail(obj:object):Observable<any>{
        let params:any = obj;
        params.ID=this.ID;
        return this.http.post(this.url.send, params);
    }
    reSendMail(obj:object):Observable<any>{
        let params:any = obj;
        params.ID=this.ID;  
        return this.http.post(this.url.send, params);
    }

    startStatus():Observable<Object>{
        let params = {token:this.token,ID:this.ID}
        if (!this.destroyed$ || this.destroyed$.isStopped ) {
            this.destroyed$= new ReplaySubject(0);

            this.status$= IntervalObservable
                .create(this.DELAY)
                .takeUntil(this.destroyed$)
                .mergeMap(
                    (i)=>{
                        return this.http.get(this.url.status+'?ID='+this.ID+'&token='+this.token);
                    }
                );
        } 
        

        return this.status$;
    }
    stopStatus(){
        this.destroyed$.next(true);
        this.destroyed$.complete();
    }
}
