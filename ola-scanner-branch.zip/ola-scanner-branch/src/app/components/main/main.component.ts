
import { Component, OnDestroy } from '@angular/core';
import { ComunicationService } from '../../services/comunication/comunication.service';


@Component({
  selector: 'san-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnDestroy{
  ID:string="5555dd5";
  data:any={phone:'',name:''};
  status:number=0;
  modal:boolean;
  files:any=[];
  link:string;

  constructor(public http:ComunicationService){

  }
  
  isCompleted(){
    // console.log('test',this.data.phone)
    return this.data.phone.length>0;
  }
  openModal(){
    if (this.isCompleted()){
      this.modal=true;
      this._sendMail();
      
    }
  }
  
  
    onBlurField(e){
      this.updateField(e);
    }
  updateField(e){

    if(!!e.target){
      e=e.target.value;
    }
    
    this.data[e.name]=e.value;
    // console.log('event',e)
  }
  closeModal(){
    this.modal = false;
    this.stopComunications();
  }
  reSend(){
    this.status=1;
    if (this.isCompleted()){
      this.http.reSendMail(this.data).subscribe(
        res=>{
          this.status = 5;
          this.startComunications(res.data);
        }
      )
    }
  }

  ngOnDestroy(){
    this.stopComunications();
  }

  private _sendMail(){
    this.status=1;
    this.http.setID(this.ID);
    this.http.sendMail(this.data).subscribe(
      res=>{
        console.log(res.data);
        this.status = res.data.waiting?2:5;
        
        if(this.status===5){
          this.startComunications(res.data);
        }else{
          this.http.setToken(res.data.token);
        }
      }
    )
  }
  
  startComunications(data){
    if(data){
      this.http.setToken(data.token);
    }
    this.link = 'http://180.161.144.97:4300/' + this.http.getToken();
    this.http.startStatus().subscribe(
      (obj:any)=>{
        console.log(obj.data);
        this.files = obj.data;
      }
    )

  }
  private stopComunications(){
    this.http.stopStatus();
  }
}
