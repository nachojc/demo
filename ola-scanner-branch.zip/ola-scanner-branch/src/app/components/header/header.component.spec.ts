import { TestBed, async } from '@angular/core/testing';

import { HeaderComponent } from './header.component';

describe('AppComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [
            HeaderComponent
        ],
      }).compileComponents();
    }));

    it('should create the Header', async(() => {
        const fixture = TestBed.createComponent(HeaderComponent);
        const com = fixture.debugElement.componentInstance;
        expect(com).toBeTruthy();
      }));








});