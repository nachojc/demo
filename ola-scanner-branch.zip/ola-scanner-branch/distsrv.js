
const express = require('express');
const app = express();


app.use(express.static('dist'));

var srv = app.listen(4300,function () {
    // const config = srv.address();
    // console.log('App runing at:',config.address,':',config.port);
});