export const environment = {
  'production': true,
  'routes': {
    'catalogue': 'catalogue',
    'error-absolute': '/error',
    'error': 'error',
    'main': 'main',
    'student': 'student'
  }
};
