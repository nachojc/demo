
import { Component } from '@angular/core';

@Component({
  selector: 'san-404',
  templateUrl: './404.component.html',
  styleUrls: ['./404.component.scss']
})
export class PageNotFoundComponent {}
