import { NgModule }     from '@angular/core';
import {
  RouterModule, Routes,
} from '@angular/router';

import { MainComponent } from "./components/main/main.component";
import { PageNotFoundComponent } from './components/404/404.component';
import { environment } from '../environments/environment'; 

const appRoutes: Routes = [
  { path: environment.routes.main, component: MainComponent },
  { path: environment.routes.student, loadChildren: 'app/pages/student/student.module#StudentModule' },
  { path: '', redirectTo: environment.routes.student, pathMatch: 'full' },
  { path: environment.routes.error, component: PageNotFoundComponent },
  { path: environment.routes.catalogue, loadChildren: 'app/pages/catalogue/catalogue.module#UICatalogModule' },
  { path: '**', redirectTo: environment.routes.error, pathMatch: 'full'  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
    )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}