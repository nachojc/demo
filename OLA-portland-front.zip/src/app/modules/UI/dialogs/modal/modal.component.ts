
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'san-ui-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.scss']
})
export class ModalComponent {
    @Input() name: string;
    @Input() noTitle: boolean;
    @Input() title: string;
    @Input() open: boolean;

    @Output() onClose= new EventEmitter<boolean>();

    close(){
      this.onClose.emit(true);
    }
    isOpen(){
      return this.open;
    }
}
