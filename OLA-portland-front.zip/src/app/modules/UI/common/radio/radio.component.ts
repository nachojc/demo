import { Component, EventEmitter, Input,
  Output, ContentChildren, forwardRef,
  QueryList, AfterContentInit, OnInit } from '@angular/core';

import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';

let nextUniqueId = 0;

export const RADIO_GROUP_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => CommonRadioButtonComponent),
  multi: true
};

@Component({
    selector: 'san-radio',
    templateUrl: './radio.component.html',
    styleUrls: ['./radio.component.scss'],
})
export class CommonRadioButtonComponent {
  
  @Input() id: string;
  @Input() name: string;
  @Input() tabindex: number;
  @Input() disabled: boolean;
  @Input('checked') _checked: boolean;
  @Output() checkedChange: EventEmitter<boolean> = new EventEmitter();
  @Output('changed') $changed: EventEmitter<any> = new EventEmitter();
  private _id: string;

  constructor() {
    this._id = this.id ? '' + this.id : `radio-${nextUniqueId++}`;
  }

  changeHandler(evt) {
    debugger;
    this.checkedChange.emit(!!this._checked);
  }

};

@Component({
  selector: 'san-radio-group',
  templateUrl: './radio-group.component.html',
  styleUrls: ['./radio-group.component.scss'],
  providers: [RADIO_GROUP_CONTROL_VALUE_ACCESSOR],
  host: {
    'role': 'radiogroup',
    'class': 'san-radio-group',
  }
})
export class CommonRadioButtonGroupComponent implements ControlValueAccessor, AfterContentInit, OnInit {
  @Input() id: string;
  @Input() name: string;
  @Input() label: string;
  @Input() required: any;
  @Input() disabled: boolean;
  private _name: string;

  /** Child radio buttons. */
  @ContentChildren(forwardRef(() => CommonRadioButtonComponent), { descendants: true }) _radios: QueryList<CommonRadioButtonComponent>;

  ngOnInit() {
    this.required = this.required === '' || this.required === true;
    this._name = this.name ? '' + this.name : `radiogroup-${nextUniqueId++}`;
  }

  writeValue(selectedId: any) {
    if (selectedId !== undefined) {
      const radio = this._radios.find(radio => radio.id === selectedId);
      radio._checked = true;
    }
  }

  propagateChange = (_: any) => {};

  registerOnChange(fn) {
    this.propagateChange = fn;
  }

  registerOnTouched() { /* noop */}

  ChildrenHandler(evt: any) {
    console.log(evt);
  }


  ngAfterContentInit() {
    if (this._name) {
      this._radios
        .map(p => p)
        .forEach(e => {
          const a = e.name;
          e.name = this._name;
          e.disabled = this.disabled;

          //TODO: listen to radio children changed event
        });
    }
  }
};