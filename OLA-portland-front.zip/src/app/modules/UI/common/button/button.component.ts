import { Component, Input, Output, HostListener, OnInit, EventEmitter } from '@angular/core';

const map:Object = {
  'Enter': true,
  ' ': true
};

@Component({
  selector: 'san-button',
  template: '<ng-content></ng-content>',
  styleUrls: ['./button.component.scss'],
  host: {
    'role': 'button',
    'tabindex': '0'
  }
})
export class CommonButtonComponent implements OnInit {
    @Input() disabled:boolean|any;
    @Output('click') $click: EventEmitter<any> = new EventEmitter();
    
    @HostListener('keydown', ['$event'])
    handlerKey (event:KeyboardEvent) {
      if (!event.defaultPrevented) {
        if (map[event.key] === true) {
          event.preventDefault();
          this.clicked(event);
        }
      }
    }
    @HostListener('click', ['$event'])
    handlerClick (event:Event) {
      this.clicked(event);
    }

    ngOnInit() {
      this.disabled = this.disabled === '' || this.disabled === true;
    }

    clicked(event) {
      if (event !== undefined) { //it's me, not the host listener
        if (this.disabled === false) {
          this.$click.emit();
        } else {
          event.stopPropagation();
          event.preventDefault();
        }
      }
    }
}
