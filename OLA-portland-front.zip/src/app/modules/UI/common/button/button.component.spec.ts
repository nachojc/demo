import { TestBed, async } from '@angular/core/testing';

import { CommonButtonComponent } from './button.component';

describe('AppComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [
            CommonButtonComponent
        ],
      }).compileComponents();
    }));

    it('should create the Header', async(() => {
        const fixture = TestBed.createComponent(CommonButtonComponent);
        const com = fixture.debugElement.componentInstance;
        expect(com).toBeTruthy();
      }));








});