import { TestBed, async } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';

import { CommonInputComponent } from './input.component';

describe('AppComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [
          CommonInputComponent
        ],
        imports: [FormsModule]
      }).compileComponents();
    }));

    it('should create ', async(() => {
        const fixture = TestBed.createComponent(CommonInputComponent);
        const com = fixture.debugElement.componentInstance;
        expect(com).toBeTruthy();
      }));








});