import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UIFormComponent } from './form/form.component';


@NgModule({
    imports: [
      CommonModule
    ],
    declarations: [
        UIFormComponent
    ],
    exports:[
        UIFormComponent
    ],
    providers: []
  })
  export class UIFramesModule { }