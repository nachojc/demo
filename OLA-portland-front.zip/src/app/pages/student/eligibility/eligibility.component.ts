import { Component } from '@angular/core';


@Component({
  selector: 'san-eligibility-student',
  templateUrl: './eligibility.component.html',
  styleUrls: ['./eligibility.component.scss']
})
export class EligibilityStudentComponent { }
