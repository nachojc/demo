import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { CommonModule } from '@angular/common';
import { EligibilityStudentComponent } from './eligibility/eligibility.component';

import { Title } from '@angular/platform-browser';


import { StudentRoutingModule } from './student.router';
import { UIFormComponent } from '../../modules/UI/frames/form/form.component';
import { UICommonModule } from '../../modules/ui/common/ui.common.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    StudentRoutingModule,
    UICommonModule
  ],
  declarations: [
    EligibilityStudentComponent,
    UIFormComponent
  ],
  providers: [Title]
})
export class StudentModule { 
  constructor(private titleService: Title){
    titleService.setTitle('Student & Graduate Bank & Current Accounts - Santander UK') ;
  }
}