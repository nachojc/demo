import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EligibilityStudentComponent } from './eligibility/eligibility.component';
import { environment } from '../../../environments/environment';


const studenRoutes: Routes = [
    { path: 'eligibility', component: EligibilityStudentComponent},
    { path: 'personalDetails', component: EligibilityStudentComponent},
    { path: '', redirectTo: 'eligibility'},
    { path: '**', redirectTo: environment.routes['error-absolute'], pathMatch: 'full'}
  ];
  @NgModule({
    imports: [
      RouterModule.forChild(studenRoutes)
    ],
    exports: [
      RouterModule
    ],
    providers: [
      
    ]
  })
  export class StudentRoutingModule { }

