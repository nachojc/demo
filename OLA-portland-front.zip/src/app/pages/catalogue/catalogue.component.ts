import { Component } from '@angular/core';


@Component({
  selector: 'san-ui-catalogue',
  templateUrl: './catalogue.component.html'
})
export class UICatalogue { }
