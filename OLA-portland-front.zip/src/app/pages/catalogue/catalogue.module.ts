import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { UICatalogueRouter } from './catalogue.router';
import { UICatalogue } from './catalogue.component';

import { Title } from '@angular/platform-browser';


import { UIFramesModule } from '../../modules/UI/frames/frames.module';
import { UICommonModule } from '../../modules/ui/common/ui.common.module';

@NgModule({
  imports: [
    CommonModule,
    UICommonModule,
    UIFramesModule,
    UICatalogueRouter
  ],
  declarations: [
    UICatalogue
  ],
  providers: [Title]
})
export class UICatalogModule { 
  constructor (private titleService: Title) {
    titleService.setTitle('UI Catlogue - Santander UK') ;
  }
}