import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UICatalogue } from './catalogue.component';
import { environment } from '../../../environments/environment';


const catalogueRoutes: Routes = [
    { path: 'showroom', component: UICatalogue},
    { path: '', redirectTo: 'showroom'},
    { path: '**', redirectTo: environment.routes['error-absolute'], pathMatch: 'full'}
  ];
  @NgModule({
    imports: [
      RouterModule.forChild(catalogueRoutes)
    ],
    exports: [
      RouterModule
    ],
    providers: []
  })
  export class UICatalogueRouter { }

