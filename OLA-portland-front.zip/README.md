# New OLA Banking Front project

To install this project, you need before:
    1.- Install node version >= 6.9.x and npm 3.x.x
    2.- Run "npm install" in the root console of this project
    

And now you project ready to start
    run "npm start" in your command line to show the aplication



    