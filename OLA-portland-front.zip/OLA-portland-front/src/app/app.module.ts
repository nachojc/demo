import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {Location} from '@angular/common';
import { Router } from '@angular/router';

import { UICommonModule } from './modules/ui/common/ui.common.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { MainComponent } from './components/main/main.component';
import { AppRoutingModule } from './app.router';
import { ProductCatalog } from './services/product.service';
import { PageNotFoundComponent } from './components/404/404.component';



@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    MainComponent,
    PageNotFoundComponent

  ],
  imports: [
    BrowserModule,
    // UICommonModule,
    AppRoutingModule
    // RouterModule.forRoot(mainRoutes)
  ],
  providers: [ProductCatalog],
  bootstrap: [AppComponent]
})
export class AppModule {
    // Diagnostic only: inspect router configuration
    constructor(router: Router,private loc :Location, product: ProductCatalog) {
      product.setPath(loc.path());

      console.log(loc.path());
      // console.log('Routes: ', JSON.stringify(router.config, undefined, 2));
    }

}
