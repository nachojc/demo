import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EligibilityStudentComponent } from './eligibility/eligibility.component';

const studenRoutes: Routes = [
    {
      path: '',
      component: EligibilityStudentComponent,
      children: [
    //     {
    //       path: '',
    //       component: CrisisListComponent,
    //       children: [
    //         {
    //           path: ':id',
    //           component: CrisisDetailComponent,
    //           canDeactivate: [CanDeactivateGuard],
    //           resolve: {
    //             crisis: CrisisDetailResolver
    //           }
    //         },
    //         {
    //           path: '',
    //           component: CrisisCenterHomeComponent
    //         }
    //       ]
    //     }
      ]
    }
  ];
  @NgModule({
    imports: [
      RouterModule.forChild(studenRoutes)
    ],
    exports: [
      RouterModule
    ],
    providers: [
      
    ]
  })
  export class StudentRoutingModule { }

