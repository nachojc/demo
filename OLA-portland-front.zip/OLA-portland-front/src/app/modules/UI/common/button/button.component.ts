
import { Component, Input } from '@angular/core';

@Component({
  selector: 'san-ui-common-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss'],
  host:     {'[class]':'isPrimary()'}
})
export class CommonButtonComponent {
    @Input() label: string;
    @Input() desabled: string;
    @Input() name: string='';
    @Input() class: string='primary';


    isDisabled(){
      return this.desabled==='true';
    }
    isPrimary(){
      return this.class;
    }
}
