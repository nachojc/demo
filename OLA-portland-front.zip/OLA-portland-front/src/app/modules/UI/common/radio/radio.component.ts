import { Component, Directive,
  EventEmitter, Input, Output, 
  ViewEncapsulation, ViewChild, ContentChildren,
  ElementRef, Renderer, forwardRef, QueryList, 
  AfterViewInit, AfterContentInit } from '@angular/core';

import {ControlValueAccessor, NG_VALUE_ACCESSOR} from '@angular/forms';



export const RADIO_GROUP_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => CommonRadioButtonComponent),
  multi: true
};

@Component({
    selector: 'san-ui-common-radio-button',
    templateUrl: './radio.component.html',
    styleUrls: ['./radio.component.scss'],
    // encapsulation: ViewEncapsulation.None,
    // preserveWhitespaces: false
})
export class CommonRadioButtonComponent  {
  @Input('id') inputId:string;
  @Input() name:string;
  @Input() tabIndex:number;
  @Input() checked:boolean;
  @Input() disabled:boolean;
  @Input() required: boolean = false;
  @Input() value:any;

  @Input() ariaLabel:string;
  @Input() ariaLabelledby:string;
  @Input() ariaDescribedby:string;
    
  _onInputChange(event){}
  _onInputClick(event){}
};
let nextUniqueId = 0;

@Component({
  selector: 'san-ui-common-radio-button-group',
  templateUrl: './radio-group.component.html',
  styleUrls: ['./radio-group.component.scss'],
  // exportAs : 'CommonRadioButtonGroupComponent',
  providers: [RADIO_GROUP_CONTROL_VALUE_ACCESSOR],
  host: {
    'role': 'radiogroup',
    'class': 'san-radio-group',
  }
})
export class CommonRadioButtonGroupComponent implements AfterContentInit{
  @Input() id:string;
  @Input() values:any;
  @Input('value') _value:any;
  @Input('disabled') _disabled:boolean=false;
  @Input('required') _required: boolean = false;
  @Output('valueChange') _valueChange = new EventEmitter<any>();

  /** Child radio buttons. */
  @ContentChildren(forwardRef(() => CommonRadioButtonComponent), { descendants: true }) _radios: QueryList<CommonRadioButtonComponent>;

  private _selected: CommonRadioButtonComponent | null = null;
  private _name: string = `group-${nextUniqueId++}`;

  ngAfterContentInit(){
    if (this._name){
      this._radios
        .map(p => p)
        .forEach(e =>{
          e.name=this._name;
          e.disabled=this._disabled;
          e.required=this._required;

        });
    }
  }
};