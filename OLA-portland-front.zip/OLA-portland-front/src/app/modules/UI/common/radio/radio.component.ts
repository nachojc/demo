import { Component, EventEmitter, Input, Output } from '@angular/core';
import {NgForm} from '@angular/forms';


@Component({
  selector: 'san-ui-common-radio-button',
  templateUrl: './radio.component.html',
  styleUrls: ['./radio.component.scss']
})
export class CommonRadioButtonComponent  {
    
}
