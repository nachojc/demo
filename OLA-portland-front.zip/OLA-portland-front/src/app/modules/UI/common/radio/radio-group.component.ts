


import { Component,EventEmitter, Input, Output } from '@angular/core';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'san-ui-common-radio-button-group',
  templateUrl: './radio-group.component.html',
  styleUrls: ['./radio-group.component.scss']
})
export class CommonRadioButtonGroupComponent  {
  @Input() id:string;
  @Input() name:string;
  @Input() value:any;
  @Input() checked:boolean;
  @Input() disabled:boolean;


  @Output() valueChanged = new EventEmitter();

}
