import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';

import { CommonModule } from '@angular/common';
import { CommonButtonComponent } from './button/button.component';
import { CommonInputComponent } from './input/input.component';
import { CommonRadioButtonComponent, CommonRadioButtonGroupComponent} from './radio/radio.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule      
  ],
  declarations: [
     CommonButtonComponent,
     CommonInputComponent,
     CommonRadioButtonComponent,
     CommonRadioButtonGroupComponent
  ],
  exports:[
     CommonButtonComponent,
     CommonInputComponent,
     CommonRadioButtonComponent,
     CommonRadioButtonGroupComponent
  ],
  providers: []
})
export class UICommonModule { }