import { NgModule } from '@angular/core';
import { FormsModule }   from '@angular/forms';

import { CommonModule } from '@angular/common';
import { CommonButtonComponent } from './button/button.component';
import { CommonInputComponent } from './input/input.component';
import { CommonRadioButtonComponent} from './radio/radio.component';
import { CommonRadioButtonGroupComponent } from './radio/radio-group.component';



@NgModule({
  imports: [
    CommonModule,
    FormsModule      
  ],
  declarations: [
     CommonButtonComponent,
     CommonInputComponent,
     CommonRadioButtonComponent,
     CommonRadioGroupComponent
  ],
  exports:[
     CommonButtonComponent,
     CommonInputComponent,
     CommonRadioButtonComponent,
     CommonRadioButtonGroupComponent
  ],
  providers: []
})
export class UICommonModule { }