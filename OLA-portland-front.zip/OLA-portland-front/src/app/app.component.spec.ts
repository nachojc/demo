import { TestBed, async } from '@angular/core/testing';

import { AppComponent } from './app.component';
import { UICommonModule } from './modules/ui/common/ui.common.module';
import { UIModalModule } from './modules/ui/modal/modal.module';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { MainComponent } from './components/main/main.component';
import { HttpClientModule } from '@angular/common/http';
import { ComunicationService } from './services/comunication/comunication.service';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        HeaderComponent,
        FooterComponent,
        MainComponent,
        
      ],
      imports: [
        UICommonModule,
        UIModalModule,
        HttpClientModule
      ],
      providers: [ComunicationService]
    }).compileComponents();
  }));

  it('should create the app', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  }));

  it(`should have as title 'app'`, async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('My First Angular App');
  }));

  it('should render title in san-header', async(() => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('san-header').textContent).toContain('Your details are secure');
  }));
});
