export class ProductCatalog{
    private location:string;
    private parameters:object={};
    constructor(){
        
    }

    setPath(params:string){
        let param = params.split('?');
        this.location = param.length>1?param[1]:null;
        if (this.location){
            let values = this.location.split('&');
            values.forEach((val)=>{
                let value = val.split('=');
                this.parameters[value[0]]=value[1];
            });
        }
    }
    getParam(param:string){
        return this.parameters[param];
    }
}