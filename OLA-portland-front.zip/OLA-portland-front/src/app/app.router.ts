import { NgModule }     from '@angular/core';
import {
  RouterModule, Routes,
} from '@angular/router';

import { MainComponent } from "./components/main/main.component";
import { PageNotFoundComponent } from './components/404/404.component';

const appRoutes: Routes = [
  { path: 'main', component: MainComponent },
  { path: 'eligibility', loadChildren: 'app/pages/student/student.module#StudentModule' },
  { path: '', redirectTo: '/eligibility', pathMatch: 'full' },
  { path: 'error', component: PageNotFoundComponent },
  { path: '**', redirectTo: '/error', pathMatch: 'full'  }
];

@NgModule({
  imports: [
    RouterModule.forRoot(
      appRoutes,
    )
  ],
  exports: [
    RouterModule
  ]
})
export class AppRoutingModule {}