import { TestBed, async } from '@angular/core/testing';

import { FooterComponent } from './footer.component';

describe('AppComponent', () => {
    beforeEach(async(() => {
      TestBed.configureTestingModule({
        declarations: [
            FooterComponent
        ],
      }).compileComponents();
    }));

    it('should create the Header', async(() => {
        const fixture = TestBed.createComponent(FooterComponent);
        const com = fixture.debugElement.componentInstance;
        expect(com).toBeTruthy();
      }));








});