import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { CustomerDetailsService } from './services/customer-details/customer-details.service';
import { ConfigService } from './services/config/config.service';
import { Router } from '@angular/router';
import { StandardError } from './models/standard-error.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'regular-eSaver';

  constructor(
    private customerDetailsService: CustomerDetailsService,
    private configService: ConfigService,
    private router: Router
  ) { }

  ngOnInit() {
    this.configService.fetchConfig()
      .pipe(first())
      .subscribe(() => {
        this.checkCustomerDetails();
        },
        () => {
          StandardError.build('Bad Request', 400);
        }
      );
  }

  checkCustomerDetails() {
    this.customerDetailsService.isValidForNewJourney()
      .pipe(first())
      .subscribe(
        valid => {
          if (!valid) {
            this.router.navigateByUrl(this.configService.getConfigParam('old-journey'));
          }
        },
        () => {
          StandardError.build('Bad Request', 400);
        }
      );
  }
}
