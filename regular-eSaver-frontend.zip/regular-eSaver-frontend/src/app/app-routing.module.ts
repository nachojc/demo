import { NgModule } from '@angular/core';
import { Routes, RouterModule, Router } from '@angular/router';
import { Location } from '@angular/common';
import { UrlParamCollectorService } from './services/url-param-collector/url-param-collector.service';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
  constructor(
    private router: Router,
    private location: Location,
    private paramService: UrlParamCollectorService
  ) {
    this.populateUrlParams();
  }

  private populateUrlParams() {
    const url = this.router.parseUrl(this.location.path());
    this.paramService.setQueryParams(url.queryParams);
  }
}
