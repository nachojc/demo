import { Router } from '@angular/router';
import { TestBed } from '@angular/core/testing';
import { Location } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { UrlParamCollectorService } from './services/url-param-collector/url-param-collector.service';

describe('AppRoutingModule', () => {
  let appRoutingModule: AppRoutingModule;

  const routerMock = {
    parseUrl: jasmine.createSpy('parseUrl').and.returnValue({ queryParamMap: { get: () => '46094086' }}),
  };

  const locationMock = {
    path: Function
  };

  const paramServiceMock = {
    setQueryParams: jasmine.createSpy('setQueryParams')
  };

  const configureTestBed = () => {
    TestBed.configureTestingModule({
      providers: [
        AppRoutingModule,
        { provide: Router, useValue: routerMock},
        { provide: Location, useValue: locationMock },
        { provide: UrlParamCollectorService, useValue: paramServiceMock }
      ]
    });
    appRoutingModule = TestBed.get(AppRoutingModule);
  };

  it('should create an instance', () => {
    configureTestBed();
    expect(appRoutingModule).toBeTruthy();
  });

  it('should call setQueryParams of paramService', () => {
    configureTestBed();
    expect(paramServiceMock.setQueryParams).toHaveBeenCalled();
  });
});
