export class StandardError {
    message: string;
    statusCode: number;

    static build (message: string, statusCode: number) {
        return { message: message, statusCode: statusCode };
    }
}
