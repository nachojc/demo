import { Injectable } from '@angular/core';
import { Subject, Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ConfigService } from '../config/config.service';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {
  private token: string;
  private tokenSubject: Subject<String> = new Subject<String>();

  constructor(private http: HttpClient, private configService: ConfigService) { }

  getSecurityToken(): Observable<String> {
    if (this.token) {
      return of(this.token);
    }

    this.http.get(this.configService.getConfigParam('tokenAPIUrl'),
      { responseType: 'text', withCredentials: true })
      .subscribe(res => {
        this.token = res;
        this.tokenSubject.next(this.token);
      },
        () => {
          this.tokenSubject.error('error');
        }
      );

    return this.tokenSubject.asObservable();
  }
}
