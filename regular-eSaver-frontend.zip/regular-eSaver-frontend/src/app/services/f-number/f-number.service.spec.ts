import { TestBed } from '@angular/core/testing';
import { FNumberService } from './f-number.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { SecurityService } from '../security/security.service';
import { Subject } from 'rxjs';
import { ConfigService } from '../config/config.service';

describe('FNumberService', () => {
  let service: FNumberService;
  let httpTestingController: HttpTestingController;

  const configServiceMock = {
    getConfigParam: (obj) => {
      const mock = {
        'fNumberAPIUrl': 'http://localhost:4200/config/f-number'
      };
      return mock[obj];
    }
  };

  const mockFNumber = 'F1';
  let securityTokenSubjectMock = new Subject<String>();
  const securityServiceMock = {
    getSecurityToken: () => securityTokenSubjectMock.asObservable()
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FNumberService,
        { provide: SecurityService, useValue: securityServiceMock },
        { provide: ConfigService, useValue: configServiceMock }
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(FNumberService);
  });

  afterEach(() => {
    httpTestingController.verify();
    securityTokenSubjectMock = new Subject<any>();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call the NewUniversalCookie API endpoint and return a customer F-Number', () => {
    service.getFNumber().subscribe((fNumber) => {
      expect(fNumber).toEqual('F1');
    });

    securityTokenSubjectMock.next('mockSecurityToken');

    const req = httpTestingController.expectOne(`${configServiceMock.getConfigParam('fNumberAPIUrl')}?token=mockSecurityToken`);
    expect(req.request.method).toEqual('GET');
    req.flush(mockFNumber);
  });

  it('should not call the NewUniversalCookie API endpoint when there is an F-Number', () => {
    service.getFNumber().subscribe((fNumber) => {
      expect(fNumber).toEqual('F1');
    });

    securityTokenSubjectMock.next('mockSecurityToken');

    const req = httpTestingController.expectOne(`${configServiceMock.getConfigParam('fNumberAPIUrl')}?token=mockSecurityToken`);
    req.flush(mockFNumber);

    service.getFNumber().subscribe((fNumber) => {
      expect(fNumber).toEqual('F1');
    });

    httpTestingController.expectNone(`${configServiceMock.getConfigParam('fNumberAPIUrl')}?token=mockSecurityToken`);
  });

  it('should call the NewUniversalCookie API endpoint and return one error if err req', () => {
    service.getFNumber().subscribe(
      undefined,
      (error) => {
        expect(error).toEqual('Bad Request');
      });

    securityTokenSubjectMock.next('mockSecurityToken');

    const req = httpTestingController.expectOne(`${configServiceMock.getConfigParam('fNumberAPIUrl')}?token=mockSecurityToken`);
    expect(req.request.method).toEqual('GET');
    req.error(new ErrorEvent('Bad Request'), { status: 400 });
  });
});
