import { Injectable } from '@angular/core';
import { Subject, Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { SecurityService } from '../security/security.service';
import { first } from 'rxjs/operators';
import { ConfigService } from '../config/config.service';

@Injectable({
  providedIn: 'root'
})
export class FNumberService {
  private fNumber: String;
  private fNumberSubject: Subject<String> = new Subject<String>();

  constructor(
    private http: HttpClient,
    private security: SecurityService,
    private configService: ConfigService) { }

  getFNumber(): Observable<String> {
    if (this.fNumber) {
      return of(this.fNumber);
    }

    this.security.getSecurityToken()
      .pipe(first())
      .subscribe(
        token => {
          this.http.get(
            this.configService.getConfigParam('fNumberAPIUrl') + `?token=${token}`,
            { responseType: 'text' }
          )
          .pipe(first())
          .subscribe((fNumber: String) => {
            this.fNumber = fNumber;
            this.fNumberSubject.next(this.fNumber);
          },
          () => {
            this.fNumberSubject.error('Bad Request');
          });
        });

    return this.fNumberSubject.asObservable();
  }
}
