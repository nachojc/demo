import { TestBed } from '@angular/core/testing';
import { CustomerDetailsService } from './customer-details.service';
import { FNumberService } from '../f-number/f-number.service';
import { SecurityService } from '../security/security.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Subject } from 'rxjs';
import { ConfigService } from '../config/config.service';

describe('CustomerDetailsService', () => {
  let service: CustomerDetailsService;
  let httpTestingController: HttpTestingController;

  const configServiceMock = {
    getConfigParam: (obj) => {
      const mock = {
        'client-id': 'hihihi',
        'secret': 'nonono',
        'customerAPIUrl': 'http://localhost:4200/config/customer-details'
      };
      return mock[obj];
    }
  };

  const fakeCustomerDetails = {
    name: 'Karius',
    nickname: 'The Great Keeper',
    team: 'Besiktas'
  };

  let securityTokenSubjectMock = new Subject<String>();
  let securityFNumberSubjectMock = new Subject<String>();

  const securityServiceMock = {
    getSecurityToken: () => securityTokenSubjectMock.asObservable()
  };

  const fNumberServiceMock = {
    getFNumber: () => securityFNumberSubjectMock.asObservable()
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        CustomerDetailsService,
        { provide: SecurityService, useValue: securityServiceMock },
        { provide: FNumberService, useValue: fNumberServiceMock },
        { provide: ConfigService, useValue: configServiceMock }
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(CustomerDetailsService);
  });

  afterEach(() => {
    httpTestingController.verify();
    securityTokenSubjectMock = new Subject<any>();
    securityFNumberSubjectMock = new Subject<any>();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return true if the customer details retrieved are valid to proceed in Angular', () => {
    service.isValidForNewJourney().subscribe((result) => {
      expect(result).toEqual(true);
    });

    securityTokenSubjectMock.next('fakeToken');
    securityFNumberSubjectMock.next('F1');

    const req = httpTestingController.expectOne(`${configServiceMock.getConfigParam('customerAPIUrl')}/F1`);
    expect(req.request.headers.get('authorization')).toEqual('fakeToken');

    req.flush(fakeCustomerDetails);
  });

  it('should return an error if err in req to Customer Exp. API', () => {
    service.isValidForNewJourney().subscribe(
      undefined,
      (error) => {
      expect(error).toEqual('Bad Request');
    });

    securityTokenSubjectMock.next('fakeToken');
    securityFNumberSubjectMock.next('F1');

    const req = httpTestingController.expectOne(`${configServiceMock.getConfigParam('customerAPIUrl')}/F1`);

    req.error(new ErrorEvent('Bad Request'), { status: 400 });
  });
});
