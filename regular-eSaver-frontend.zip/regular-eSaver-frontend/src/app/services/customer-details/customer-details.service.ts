import { Injectable } from '@angular/core';
import { FNumberService } from '../f-number/f-number.service';
import { SecurityService } from '../security/security.service';
import { Observable, combineLatest, Subject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { first } from 'rxjs/operators';
import { ConfigService } from '../config/config.service';

@Injectable({
  providedIn: 'root'
})
export class CustomerDetailsService {
  private customerDetails: Object;
  private customerDetailsSubject = new Subject<any>();
  private customerValidSubject = new Subject<any>();

  constructor(
    private http: HttpClient,
    private securityService: SecurityService,
    private fNumberService: FNumberService,
    private configService: ConfigService
  ) { }

  isValidForNewJourney(): Observable<Boolean> {
    this.getCustomerDetails()
      .pipe(first())
      .subscribe(
        details => {
          this.customerDetails = details;
          this.customerValidSubject.next(
            this.isValidCustomer()
          );
        },
        () => {
          this.customerValidSubject.error('Bad Request');
        }
      );

    return this.customerValidSubject.asObservable();
  }

  // TODO: need to retrieve customer details for Angular Journey
  // getCustomerField(field: any): String {
  //   return this.customerDetails[field];
  // }

  private getCustomerDetails(): Observable<any> {
    combineLatest(
      this.securityService.getSecurityToken(),
      this.fNumberService.getFNumber()
    )
      .subscribe(
        (data: any) => {
          const options = {
            headers: new HttpHeaders( {
              'authorization': data[0],
              'client-id' : this.configService.getConfigParam('client-id'),
              'secret': this.configService.getConfigParam('secret')
            })
          };

          this.http.get(this.configService.getConfigParam('customerAPIUrl') + `/${data[1]}`, options)
          .pipe(first())
          .subscribe(
            (details) => {
              this.customerDetailsSubject.next(details);
            },
            () => {
              this.customerDetailsSubject.error('Bad Request');
            }
          );
        }
      );

    return this.customerDetailsSubject.asObservable();
  }

  private isValidCustomer(): Boolean {
    return !!this.customerDetails;
  }
}
