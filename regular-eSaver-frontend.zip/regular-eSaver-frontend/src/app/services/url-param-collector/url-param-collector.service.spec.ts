import { TestBed, inject } from '@angular/core/testing';
import { UrlParamCollectorService } from './url-param-collector.service';

describe('UrlParamCollectorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UrlParamCollectorService]
    });
  });

  it('should be created', inject([UrlParamCollectorService], (service: UrlParamCollectorService) => {
    expect(service).toBeTruthy();
  }));

  it('should set up params data and return requested param', inject([UrlParamCollectorService], (service: UrlParamCollectorService) => {
    const params = { '_flowId': 'baupgrade', 'prodId': '123lite', 'refId': '123Litetxf', 'psb': '3007390000001' };
    service.setQueryParams(params);

    expect(service.getQueryParam('_flowId')).toEqual(params._flowId);
    expect(service.getQueryParam('prodId')).toEqual(params.prodId);
    expect(service.getQueryParam('err')).toEqual('');
  }));
});
