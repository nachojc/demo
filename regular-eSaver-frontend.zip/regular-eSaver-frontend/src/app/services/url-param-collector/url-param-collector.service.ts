import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UrlParamCollectorService {
  private params: {};

  getQueryParam(param: string): string {
    return this.params[param] || '';
  }

  setQueryParams(params: Object) {
    this.params = params;
  }
}
