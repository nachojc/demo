import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of, Observable } from 'rxjs';
import { PlatformLocation } from '@angular/common';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private config: any;

  constructor(private http: HttpClient, private platformLocation: PlatformLocation) {}

  getConfigParam(parameter: string) {
    return this.config[parameter];
  }

  fetchConfig(): Observable<Boolean> {
    if (this.config) {
      return of(true);
    }

    return this.http.get<any>(this.platformLocation.getBaseHrefFromDOM() + 'config/application')
    .pipe(map((cfg) => {
      this.config = cfg;
        return true;
    }));
  }
}
