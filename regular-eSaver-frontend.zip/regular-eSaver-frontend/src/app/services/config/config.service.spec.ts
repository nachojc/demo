import { TestBed } from '@angular/core/testing';
import { ConfigService } from './config.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { PlatformLocation } from '@angular/common';

describe('ConfigService', () => {
  let service: ConfigService;
  let httpTestingController: HttpTestingController;

  const platFormLocationMock = {
    getBaseHrefFromDOM: () => 'localUrl/'
  };

  const mockConfigData = {
    sports: 'football',
    TV: 'BBC'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ConfigService,
        { provide: PlatformLocation, useValue: platFormLocationMock }
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(ConfigService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get the data of a config file and return true', () => {
    service.fetchConfig().subscribe((res) => {
      expect(res).toEqual(true);
    });

    const req = httpTestingController.expectOne('localUrl/config/application');
    expect(req.request.method).toEqual('GET');

    req.flush(mockConfigData);
  });

  it('should not make another HTTP call if we have a config data already', () => {
    service.fetchConfig().subscribe((res) => {
      expect(res).toEqual(true);
    });

    const req = httpTestingController.expectOne('localUrl/config/application');
    expect(req.request.method).toEqual('GET');

    req.flush(mockConfigData);

    service.fetchConfig().subscribe((res) => {
      expect(res).toEqual(true);
    });

    httpTestingController.expectNone('localUrl/config/application');
  });

  it('should return param of config object stored', () => {
    service.fetchConfig().subscribe(() => {
      expect(service.getConfigParam('sports')).toEqual(mockConfigData.sports);
    });

    const req = httpTestingController.expectOne('localUrl/config/application');

    req.flush(mockConfigData);
  });
});
