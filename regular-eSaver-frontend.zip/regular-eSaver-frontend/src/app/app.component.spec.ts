import { TestBed, ComponentFixture } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { ConfigService } from './services/config/config.service';
import { CustomerDetailsService } from './services/customer-details/customer-details.service';
import { of, Subject } from 'rxjs';
import { Router } from '@angular/router';
import { StandardError } from './models/standard-error.model';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let customerService: CustomerDetailsService;
  let router: Router;
  let isValidForNewJourneySubject = new Subject();
  let fetchConfigSubject = new Subject<any>();

  const customerDetailsServiceMock = {
    isValidForNewJourney: () => isValidForNewJourneySubject.asObservable()
  };

  const configServiceMock = {
    fetchConfig: () => fetchConfigSubject.asObservable(),
    getConfigParam: Function
  };

  const routerMock = {
    navigateByUrl: jasmine.createSpy('navigateByUrl')
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [
        { provide: CustomerDetailsService, useValue: customerDetailsServiceMock },
        { provide: ConfigService, useValue: configServiceMock },
        { provide: Router, useValue: routerMock }
      ]
    }).compileComponents();

    router = TestBed.get(Router);
    customerService = TestBed.get(CustomerDetailsService);
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
  });

  afterEach(() => {
    routerMock.navigateByUrl.calls.reset();
    isValidForNewJourneySubject = new Subject<any>();
    fetchConfigSubject = new Subject<any>();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('should call for customer details if we fetch the config', () => {
    const componentSpy = spyOn(component, 'checkCustomerDetails');

    component.ngOnInit();
    fetchConfigSubject.next(true);

    expect(componentSpy).toHaveBeenCalled();
  });

  it('should return if customer journey is valid after calling checkCustomerDetails', () => {
    const customerSpy = spyOn(customerService, 'isValidForNewJourney')
      .and
      .returnValue(of(true));

    component.checkCustomerDetails();

    expect(customerSpy).toHaveBeenCalled();
  });

  it('should call router with navigateByUrl if customer is not valid for new journey', () => {
    component.checkCustomerDetails();

    isValidForNewJourneySubject.next(false);

    expect(router.navigateByUrl).toHaveBeenCalled();
  });

  it('should build a StandardError after receive an error response from checkCustomerDetails', () => {
    const errorSpy = spyOn(StandardError, 'build');

    component.checkCustomerDetails();
    isValidForNewJourneySubject.error(StandardError.build('Bad Request', 400));

    expect(errorSpy).toHaveBeenCalled();
  });

  it('should build a StandardError after receive an error response from fetchConfig', () => {
    const errorSpy = spyOn(StandardError, 'build');

    component.ngOnInit();
    fetchConfigSubject.error(StandardError.build('Bad Request', 400));

    expect(errorSpy).toHaveBeenCalled();
  });
});
