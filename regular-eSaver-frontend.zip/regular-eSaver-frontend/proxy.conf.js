const fs = require('fs');

const proxyUrls = [
  '/config/application',
  '/config/terms',
  '/config/token',
  '/config/f-number',
  '/config/customer-details'
];

const PROXY_CONFIG = {
  "/config": {
    "secure": false,
    "bypass": function (req, res) {
      const file = findUrl(req.url);
      if ( file ) {
        console.log('Sending Mock file: ' + file);
  
        res.end(fs.readFileSync('./external-files' + file + '.json'));
        return true;
      }
    
      function findUrl(url) {
        values = proxyUrls.filter(proxyUrl => url.indexOf(proxyUrl) >= 0);
        return values.length ? values[0] : null;
      }
    }
  }
}

module.exports = PROXY_CONFIG;
