import { validateRegularPaymentsPage, completeRegularPaymentsPage } from '../pages/page-regular-payments';
import { Then, setDefaultTimeout } from 'cucumber';
import { browser } from 'protractor';

setDefaultTimeout(100 * 1000);

Then('I validate and complete regular payments page', {timeout: 30 * 5000}, async () => {
    await browser.executeScript('window.scrollTo(0,0);')
    await validateRegularPaymentsPage();
    await completeRegularPaymentsPage();
});

Then('I complete regular payments page', {timeout: 30 * 5000}, async () => {
    await browser.executeScript('window.scrollTo(0,0);')
    await completeRegularPaymentsPage();
});