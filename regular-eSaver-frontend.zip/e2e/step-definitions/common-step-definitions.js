import { getScreenshot } from '@portland/protractor-cucumber-utils'
import { Then, setDefaultTimeout } from 'cucumber';

browser.waitForAngularEnabled(false);

setDefaultTimeout(20 * 1000);

Then(/^I take screenshot with name <([^<>]*)>$/, async (nameOfScreenshot) => {
	await getScreenshot(nameOfScreenshot);
});