import { validateConfirmationPage, continueConfirmationPage, validateUserDataOnlyInConfirmationPage } from '../pages/page-confirmation';
import { Then, setDefaultTimeout } from 'cucumber';
import { browser } from 'protractor';

setDefaultTimeout(100 * 1000);

Then('I validate and complete confirmation page', {timeout: 24 * 5000}, async () => {
    await browser.executeScript('window.scrollTo(0,0);')
    await validateConfirmationPage();
    await continueConfirmationPage();
});

Then('I validate user data only and complete confirmation page', {timeout: 24 * 5000}, async () => {
    await browser.executeScript('window.scrollTo(0,0);')
    await validateUserDataOnlyInConfirmationPage();
    await continueConfirmationPage();
});