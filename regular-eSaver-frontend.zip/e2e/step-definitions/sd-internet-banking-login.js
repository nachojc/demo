import { internetLoginPage, loginToOnlineBanking, getTestDataForEsaver } from '../pages/page-internet-banking-login';
import { openUrl } from '@portland/protractor-cucumber-utils';
import { Given, Then, setDefaultTimeout } from 'cucumber';
import { browser } from 'protractor';

browser.waitForAngularEnabled(false);
setDefaultTimeout(100 * 1000);

Given(/^I have navigated to url <([^<>]*)>$/, {timeout: 60000}, async (webURL) => {
    await openUrl(webURL);
    await internetLoginPage.checkForRapportPopupAndCloseIt();
});

Then('I fill customer ID', {timeout: 20 * 5000},  async () => {
    await loginToOnlineBanking();
});

Then('I get test data for {string},{string},{string},{string},{string}', {timeout: 20 * 5000},  async (chromeCustomer, firefoxCustomer, safariCustomer, iEcustomer, edgeCustomer) => {
    await getTestDataForEsaver(chromeCustomer, firefoxCustomer, safariCustomer, iEcustomer, edgeCustomer);
});
