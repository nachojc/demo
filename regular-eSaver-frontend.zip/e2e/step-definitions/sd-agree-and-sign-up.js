import { validateAgreeAndSignUpPage, completeAgreeAndSignUpPage, validateLink,
    clickOnUpdateDetailsAndValidate, closeUpdateDetailsPopUp, 
    validateFooterLinks, verifyRedirectionIsDone, pressBrowserBackButtonAndValidate, 
    validateCustomerDataOnly,pressBrowserBackButtonAndValidateErrorPage
} from '../pages/page-agree-and-sign-up';
import { openUrl } from '@portland/protractor-cucumber-utils';
import { Then, setDefaultTimeout } from 'cucumber';
import { browser } from 'protractor';
import { protractor } from 'protractor';
import { expect } from 'chai';

setDefaultTimeout(100 * 1000);
browser.waitForAngularEnabled(true);

Then(/^I open regular eSaver application by navigating to <([^<>]*)>$/, {timeout: 20 * 5000}, async (webUrl) => {
    await openUrl(webUrl);
    const EC = protractor.ExpectedConditions;
    await browser.wait(EC.urlContains('about-you'), 60000).then(function(result) {
        expect(result).equals(true);
    });
    console.log('Navigated to: ', await browser.getCurrentUrl());
});

Then(/^I navigate to regular eSaver application URL <([^<>]*)>$/, {timeout: 20 * 5000}, async (webUrl) => {
    await openUrl(webUrl);
});

Then('I validate only customer data displayed and complete agree and sign up page', {timeout: 200 * 5000}, async () => {
    await validateCustomerDataOnly();
    await completeAgreeAndSignUpPage();
});

Then('I validate data displayed and complete agree and sign up page', {timeout: 200 * 5000}, async () => {
    await validateAgreeAndSignUpPage();
    await completeAgreeAndSignUpPage();
});

Then(/^I click and validate link <([^<>]*)>$/, {timeout: 200 * 5000}, async (nameOfLink) => {
    await validateLink(nameOfLink);
});

Then(/^I click and validate update details link$/, {timeout: 200 * 5000}, async () => {
    await clickOnUpdateDetailsAndValidate();
});

Then(/^I close update details popup$/, {timeout: 200 * 5000}, async () => {
    await closeUpdateDetailsPopUp();
});

Then(/^I click and validate all footer links$/, {timeout: 200 * 5000}, async () => {
    await validateFooterLinks();
});

Then(/^I verify user is redirected to old journey$/, {timeout: 200 * 5000}, async () => {
    await verifyRedirectionIsDone();
});

Then(/^I press browser back button and validate behaviour$/, async () => {
	await pressBrowserBackButtonAndValidate();
});

Then(/^I press browser back button and validate error page is diplayed$/, async () => {
	await pressBrowserBackButtonAndValidateErrorPage();
});