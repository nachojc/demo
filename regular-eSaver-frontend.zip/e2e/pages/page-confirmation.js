import { clickOn, confirmElementText } from '@portland/protractor-cucumber-utils';
import { firstname } from './page-internet-banking-login';
import { element, by, browser } from 'protractor';
import { expect } from 'chai';

// Confirmation Page Elements
const titleOfPage = element(by.css('.title') );
const breadcrumb1 = element(by.css('s-breadcrumbs > ul > li:nth-child(1) > span'));
const breadcrumb2 = element(by.css('s-breadcrumbs > ul > li:nth-child(2) > span'));
const summaryTextWithName = element(by.css('[data-qa=confirmation-block]>p.frame__subtitle'));
const summaryTextReceived = element(by.css('[data-qa=confirmation-block]>div.frame__content'));
const yourRefHeading = element(by.css('[data-qa=confirmation-block]+div.s-card>h1'))
const refNumber = element(by.css('[data-qa=reference-number-text]'));
const referenceText = element(by.css('[data-qa=reference-number-text]+p'));
const whatHappensNextCardTitle = element(by.css('[data-qa=card-title]'));
const bulletPoint1 = element(by.css('[data-qa=next-steps-t1]'));
const bulletPoint2 = element(by.css('[data-qa=next-steps-t2]'));
const bulletPoint3 = element(by.css('[data-qa=next-steps-t3]'));
const continueButton = element(by.css('[data-qa=confirmation-continue-btn]'));

export async function validateConfirmationPage () {
    console.log('>>>Validating Confirmation Page<<<');
    console.log(await browser.getCurrentUrl());
    expect(await browser.getCurrentUrl()).contains('confirmation');
    await confirmElementText(titleOfPage, 'Regular eSaver', 'titleOfPage');
    await confirmElementText(breadcrumb1, 'Agree and Sign up', 'breadcrumb1');
    await confirmElementText(breadcrumb2, 'Setup regular payments', 'breadcrumb2');
    await confirmElementText(yourRefHeading, 'Your reference', 'yourRefHeading');
    await confirmElementText(referenceText, 'We\'ll use this reference number if we contact you about your application.', 'referenceText');
    await confirmElementText(summaryTextWithName, `Congratulations ${firstname}`, 'summaryText');
    await confirmElementText(summaryTextReceived, 'Your Regular eSaver account request has been received', 'summaryTextReceived');
    await confirmElementText(whatHappensNextCardTitle, 'What happens next', 'whatHappensNextCardTitle');
    await confirmElementText(bulletPoint1, 'We\'ll complete some final checks before we open your account', 'bulletPoint1');
    await confirmElementText(bulletPoint2, 'These can take up to 3 working days, but are usually done within a couple of hours', 'bulletPoint2');
    await confirmElementText(bulletPoint3, 'We\'ll let you know when your account has opened by email', 'bulletPoint3');
    await confirmElementText(continueButton, 'Continue', 'continueButton');
}

export async function validateUserDataOnlyInConfirmationPage () {
    console.log('>>>Validating Confirmation Page<<<');
    console.log(await browser.getCurrentUrl());
    expect(await browser.getCurrentUrl()).contains('confirmation');
    await confirmElementText(summaryTextWithName, `Congratulations ${firstname}`, 'summaryText');
    await confirmElementText(summaryTextReceived, 'Your Regular eSaver account request has been received', 'summaryTextReceived');
}

export async function continueConfirmationPage () {
    console.log('>>>Completing Confirmation Page<<<');
    console.log('****************** OLA number: ', await refNumber.getText());
    await clickOn(continueButton);
}
