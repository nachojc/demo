'use strict';
import { clickOn, waitForElementToBeVisible, getElementText,
        enterData, getBrowserName, getScreenshot } from '@portland/protractor-cucumber-utils';
import { expect } from 'chai';
import { element, by, protractor, browser } from 'protractor';

var pidToEnter;
export var firstname, email, phoneNumber, postcode;
// Online Banking Page Elements
const rapportPopup = element(by.id('splash-97123-close-button') );
const titleOfPage = element( by.css('#content > h1:nth-child(1)') );
const customerIdInput = element( by.id('infoLDAP_E.customerID') );
const loginButton = element( by.id('btnFO') );
const securityAnswerInput = element(by.id('cbQuestionChallenge.responseUser'));
const continueButton = element(by.css('.defaultAction.primary[value=\'Continue\']'));
const fullPhaseCheckTitle = element(by.css('#formAuthenticationAbbey > h1'))
const passCodeInputField = element(by.xpath('//*[@id="authentication.PassCode"]'))
const registrationNumberInputField = element(by.xpath('//*[@id="authentication.ERN"]'))
const passwordPosition1 = element(by.css('input[name=\'signPosition1\']'));
const passwordPosition2 = element(by.css('input[name=\'signPosition2\']'));
const passwordPosition3 = element(by.css('input[name=\'signPosition3\']'));
const secNumPosition1 = element(by.css('input[name=\'passwordPosition1\']'));
const secNumPosition2 = element(by.css('input[name=\'passwordPosition2\']'));
const secNumPosition3 = element(by.css('input[name=\'passwordPosition3\']'));
const paperLessPageTitle = element(by.css('#content > h1'));
const paperLessNoThanksBtn = element(by.css('input#alertNoThanks.defaultAction'));
// const paperLessIAmSureBtn = element(by.css('#content > div.alertPopUp.popupNoThanks > form > div > fieldset > div > button.primary'));
const paperLessIAmSureBtn = element(by.css('input[name="datosInternos.indDecision"][value="N"]+button.primary'));
const securityPopUp = element(by.css('.PopUp-inner'));
const continueInsecurityPopUp = element(by.css('div.PopUp-inner > form > fieldset > div.buttonholder > span.button > a.primary'));
const myAccountsText = element(by.css('#content > h1:nth-child(2)'));
const myAccountsLink = element(by.xpath('//*[@id="submenu"]/ul/li[1]/a'));

const { After } = require('cucumber')
const fs = require('fs')
const mkdirp = require('mkdirp')
const jsonReports = process.cwd() + './target/reports/cucumber_report.html.json'

if (!fs.existsSync(jsonReports)) {
  mkdirp.sync(jsonReports)
}

After(function (scenario) {
  if (scenario.result.status === 'failed') {
    var attach = this.attach
    console.log('screenshot taken after fail')
    getScreenshot('failInThisScreen')
    return browser.takeScreenshot().then(function (png) {
      var decodedImage = Buffer.from(png, 'base64')
      return attach(decodedImage, 'image/png')
    })
  }
//   browser.driver.quit()
  console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
})



export let internetLoginPage = {
    checkForRapportPopupAndCloseIt: async () => {
        console.log('checking for Rapport popup');
        console.log(await rapportPopup.isPresent());

        if (await rapportPopup.isPresent()) {
            console.log('Closing Rapport popup');
            await clickOn(rapportPopup, 'page.internet.banking.login.internetLoginPage.checkForRapportPopupAndCloseIt');
        }
    },
    confirmTitleOfPage: async () => {
        // console.log('checking Title of page');
        await waitForElementToBeVisible(titleOfPage, 5000, 'page.internet.banking.login.internetLoginPage.getTitleOfPage');
        // tslint:disable-next-line:max-line-length
        expect ( await getElementText(titleOfPage, false, false, 'page.internet.banking.login.internetLoginPage.getTitleOfPage') ).equals('Log on to Online Banking');
    },

    inputCustomerId: async (pid) => {
        const nameOfBrowser = await getBrowserName();
        // console.log('Entering customer Id');
        console.log('inputting pid---', pid, 'in browser -- ', nameOfBrowser);
        await enterData(customerIdInput, pid, 'page.internet.banking.login.internetLoginPage.inputCustomerId');
    },

    clickLoginButton: async () => {
        // console.log('Clicking login button');
        await clickOn(loginButton, 'page.internet.banking.login.internetLoginPage.clickLoginButton');
        await protractor.browser.sleep(5000);
    },
    enterSecurityAnswer: async () => {
        // console.log('checking if security question is asked');
        if (await securityAnswerInput.isPresent())  {
            console.log('Entering security answer');
            await securityAnswerInput.sendKeys ('test');
            await getScreenshot('afterSecurityNumber');
            await clickContinue();
            await protractor.browser.sleep(5000);
            await getScreenshot('afterSecurityNumberContinue');
        }
    },
    enterMultiChannelPassword : async () => {
        // console.log('Checking if multi channel password is asked');
        if (await passwordPosition1.isPresent()) {
            // console.log('Entering multi channel password');
            await passwordPosition1.sendKeys('11335577a'.charAt(await getRequiredCharacterOfPassword(passwordPosition1)));
            await passwordPosition2.sendKeys('11335577a'.charAt(await getRequiredCharacterOfPassword(passwordPosition2)));
            await passwordPosition3.sendKeys('11335577a'.charAt(await getRequiredCharacterOfPassword(passwordPosition3)));
            // console.log('Done entering multi channel password');
        }
    },
    enterMultiChannelSecurityNumber : async () => {
        // console.log('Checking if multi channel security number is asked');
        if (await secNumPosition1.isPresent()) {
            // console.log('Entering multi channel security number');
            await secNumPosition1.sendKeys('13579'.charAt(await getRequiredCharacterOfPassword(secNumPosition1)));
            await secNumPosition2.sendKeys('13579'.charAt(await getRequiredCharacterOfPassword(secNumPosition2)));
            await secNumPosition3.sendKeys('13579'.charAt(await getRequiredCharacterOfPassword(secNumPosition3)));
        }
    },
    enterPasscodeAndRegistration: async () => {
        // console.log('Checking if input channel Passcode and Registration are asked');
        if (await fullPhaseCheckTitle.isPresent() && await fullPhaseCheckTitle.getText() === 'Enter Passcode and Registration number') {
            console.log('Entering input channel password');
            await passCodeInputField.sendKeys('11335577a');
            // console.log('Entering input channel registration number');
            await registrationNumberInputField.sendKeys('13579')
            // console.log('Done entering input channel password');
        }
    },
    clickOnAskLaterIfPaperFreePageShown : async () => {
        // console.log('Checking if current page is Paper Free option');
        // await paperLessPageTitle.isPresent()
        await browser.sleep(2000);
        if (await paperLessNoThanksBtn.isPresent()) {
            await getScreenshot('Paper Free Page');
            console.log('Clicking no thanks button on paper free page');
            await browser.sleep(1000);
            await clickOn(paperLessNoThanksBtn);
            await browser.sleep(1000);
            console.log('Clicking I Am Sure');
            await clickOn(paperLessIAmSureBtn);
        }
    },
    clickOnContinueIfSecurityPopupIsShown : async () => {
        // console.log('Checking for security popup');
        if (await securityPopUp.isPresent()) {
            await securityPopUp.click();
            await getScreenshot('security popup');
            console.log('Click continue on security popup');
            const EC = protractor.ExpectedConditions;
            await browser.wait(EC.elementToBeClickable(continueInsecurityPopUp), 20000).then(async()=> {
                await continueInsecurityPopUp.click();
            });
            await getScreenshot('close security popup');
        }
    },
    confirmMyAccountsScreen : async () => {
        // console.log('checking My accounts link is present');
        // tslint:disable-next-line:max-line-length
        await waitForElementToBeVisible(myAccountsLink, 100000, 'page.internet.banking.login.internetLoginPage.confirmMyAccountsScreen');
        // tslint:disable-next-line:max-line-length
        expect ( await getElementText(myAccountsLink, false, false, 'page.internet.banking.login.internetLoginPage.confirmMyAccountsScreen') ).equals('My accounts');
    }
};

export async function clickContinue() {
    // console.log('Clicking Continue');
    await clickOn(continueButton);
    await browser.sleep(2000);
}

export async function getRequiredCharacterOfPassword(elm) {
    const idValue = await elm.getAttribute('id');
    return idValue.substr(-1) - 1;
}

export async function loginToOnlineBanking  () {
    // console.log('login into online banking');
    await internetLoginPage.confirmTitleOfPage();
    await internetLoginPage.inputCustomerId(pidToEnter);
    await internetLoginPage.clickLoginButton();
    await getScreenshot('afterLogin');
    await internetLoginPage.enterSecurityAnswer();
    await internetLoginPage.enterPasscodeAndRegistration();
    await internetLoginPage.enterMultiChannelPassword();
    await internetLoginPage.enterMultiChannelSecurityNumber();
    await clickContinue();
    await browser.sleep(2000);
    await internetLoginPage.clickOnAskLaterIfPaperFreePageShown();
    await internetLoginPage.clickOnContinueIfSecurityPopupIsShown();
    await internetLoginPage.confirmMyAccountsScreen();
    await checkCookieIsPresent();
}

export async function checkCookieIsPresent(){
    let cookie = await browser.manage().getCookie('NewUniversalCookie');
    console.log('universal cookie shown:', cookie);
    var iterator = 1;
    while(cookie===null && iterator < 20){
        await browser.refresh();
        await browser.sleep(1000);
        cookie = await browser.manage().getCookie('NewUniversalCookie');
        iterator++;
    }
}

export async function getTestDataForEsaver  (chromeCustomer, firefoxCustomer, safariCustomer, iEcustomer, edgeCustomer) {
    // console.log('get customer data');
    var nameOfBrowser = await getBrowserName();

    var testData;
    nameOfBrowser = nameOfBrowser.toLowerCase();
    if (nameOfBrowser === 'chrome') { testData = chromeCustomer; }
    if (nameOfBrowser === 'firefox') { testData = firefoxCustomer; }
    if (nameOfBrowser === 'safari') { testData = safariCustomer; }
    if (nameOfBrowser === 'internet explorer') { testData = iEcustomer; }
    if (nameOfBrowser === 'microsoftedge') { testData = edgeCustomer; }

    var testDataSplit = testData.split(':');

    pidToEnter = testDataSplit[0];
    firstname = testDataSplit[1];
    email = testDataSplit[2];
    phoneNumber = maskMobileNumber(testDataSplit[3]);
    postcode = testDataSplit[4];
}

function maskMobileNumber(mobileNumber) {
  let maskedMobileNumber = null;
  if (mobileNumber) {
    if (mobileNumber.trim().startsWith('-')) {
      mobileNumber = mobileNumber.substr(1);
    }

    let mobileNumberArray = mobileNumber.split('-');
    if (mobileNumberArray.length == 2) {
      maskedMobileNumber = mobileNumberArray[1].replace(/.(?=.{4})/g, '*');
      maskedMobileNumber = mobileNumberArray[0] + '-' + maskedMobileNumber;
    } else if (mobileNumberArray.length == 1) {
      maskedMobileNumber = mobileNumberArray[0].replace(/.(?=.{4})/g, '*');
    }
  }
  return maskedMobileNumber === null ? '' : maskedMobileNumber;
}
