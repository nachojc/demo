import { clickOn, confirmElementText, clickLinkAndValidateNewTabUrlAndClose } from '@portland/protractor-cucumber-utils';
import { email, phoneNumber, postcode } from './page-internet-banking-login';
import { browser, protractor } from 'protractor';
import { expect } from 'chai';
const { element, by } = require('protractor');

// Agree And Sign Up Page Elements
const titleOfPage = element(by.css('.title') );
const breadcrumb1 = element(by.css('s-breadcrumbs > ul > li:nth-child(1) > span'));
const breadcrumb2 = element(by.css('s-breadcrumbs > ul > li:nth-child(2) > span'));

const detailsCardTitle = element(by.css('div.s-card:nth-child(1) > h1:nth-child(1)'));
const sAlert = element(by.css('.s-alert'));
const emailLabel = element(by.css('p.details-label:nth-child(1)'));
const emailElement = element(by.css('.details > div:nth-child(2)'));
const mobileLabelElement = element(by.css('p.details-label:nth-child(3)'));
const mobileElement = element(by.css('.details > div:nth-child(4)'));

const postcodeLabel = element(by.css('p[data-qa=postcode-label]'));
const postcodeElement = element(by.css('.details > div:nth-child(6)'));
const signUpCardTitle = element(by.css('.second'));
const signUpCardSubTitle = element(by.css('.second + h4'));
const bulletPoint1 = element(by.css('div.s-card:nth-child(2) > div > ul > li:nth-child(1)'));
const bulletPoint2 = element(by.css('div.s-card:nth-child(2) > div > ul > li:nth-child(2)'));
const bulletPoint3 = element(by.css('div.s-card:nth-child(2) > div > ul > li:nth-child(3)'));
const contactUsText = element(by.css('div.s-card:nth-child(2) > div:nth-child(2) > p'));
const termsAndConditionsLink = element(by.css('div.s-card:nth-child(2) > div:nth-child(3) > a'));
const agreeAndSignCheckBox = element(by.css('.ng-untouched > label:nth-child(1) > input:nth-child(1)'));
const agreeAndSignText = element(by.css('.label'));
const continueButton = element(by.css('.s-button'));

// Update details block elemets
const updateDetailsLink = element(by.css('[data-qa=update-details-link]'));
const changeContactDetailsHeading = element(by.css('[data-qa=update-details-instructions-block] > p.heading'));
const changeContactDetailTestx1 = element(by.css('[data-qa=update-details-instructions-block] > p.content:nth-child(2)'));
const changeContactDetailTestx2 = element(by.css('[data-qa=update-details-instructions-block] > p.content:nth-child(3)'));
const closeLink = element(by.css('[data-qa=update-details-close-link]'));

// links
const contactUsLink = element(by.css('a[href="https://www.santander.co.uk/uk/help-support/contact-us"]'));
const termsAndConditionsKFDLink = element(by.css('a[href="https://www.santander.co.uk/uk/savings/savings-terms-and-conditions"]'));
const onlineBankingGuaranteeLink = element(by.css('a[href="http://www.santander.co.uk/uk/online-mobile-banking-commitment/"]'));
const siteHelpAndAccessibilityLink = element(by.css('a[href="http://www.santander.co.uk/uk/accessibility/"]'));
const securityAndPrivacyLink = element(by.css('a[href="http://www.santander.co.uk/uk/help-support/security-centre/data-protection/"]'));
const legalLink = element(by.css('a[href="http://www.santander.co.uk/csgs/ContentServer?appID=abbey.internet.Abbeycom&c=Page&canal=CABBEYCOM&cid=1210606980678&empr=Abbeycom&leng=en_GB&pagename=Abbeycom%2FPage%2FWC_ACOM_TemplateA2"]'));

const links = {
    "contactUs": {
        element: contactUsLink,
        url: 'https://www.santander.co.uk/personal/support/talk-to-us'
    },
    "termsAndConditionsKFD": {
        element: termsAndConditionsKFDLink,
        url: 'https://www.santander.co.uk/uk/savings/savings-terms-and-conditions'
    },
    "onlineBankingGuarantee": {
        element: onlineBankingGuaranteeLink,
        url: 'http://www.santander.co.uk/uk/online-mobile-banking-commitment/'
    },
    "siteHelpAndAccessibility": {
        element: siteHelpAndAccessibilityLink,
        url: 'http://www.santander.co.uk/uk/accessibility/'
    },
    "securityAndPrivacy": {
        element: securityAndPrivacyLink,
        url: 'http://www.santander.co.uk/uk/help-support/security-centre/data-protection/'
    },
    "legal": {
        element: legalLink,
        url: 'http://www.santander.co.uk/csgs/ContentServer?appID=abbey.internet.Abbeycom&c=Page&canal=CABBEYCOM&cid=1210606980678&empr=Abbeycom&leng=en_GB&pagename=Abbeycom%2FPage%2FWC_ACOM_TemplateA2'
    }

}

export async function validateAgreeAndSignUpPage () {
    console.log('>>>Validating Agree And Sign Up Page<<<');
    await browser.sleep(3000);
    // await browser.manage().window().maximize();
    await confirmElementText(titleOfPage, 'Regular eSaver', 'titleOfPage');
    await confirmElementText(breadcrumb1, 'Agree and Sign up', 'breadcrumb1');
    await confirmElementText(breadcrumb2, 'Setup regular payments', 'breadcrumb2');
    await confirmElementText(detailsCardTitle, 'Your details', 'detailsCardTitle');
    await confirmElementText(sAlert, 'Please make sure your details are up-to-date, and match those shown below.', 'sAlert', true);
    await confirmElementText(emailLabel, 'Email address', 'emailLabel');
    await confirmElementText(emailElement, email, 'emailElement');
    await confirmElementText(mobileLabelElement, 'Mobile number', 'mobileLabelElement');
    await confirmElementText(mobileElement, phoneNumber, 'mobileElement', true);
    await confirmElementText(postcodeLabel, 'Post code', 'postcodeLabel');
    await confirmElementText(postcodeElement, postcode, 'postcodeElement');
    await confirmElementText(updateDetailsLink, 'How do I update these details?','updateDetailsLink');
    await confirmElementText(signUpCardTitle, 'Sign up', 'signUpCardTitle');
    await confirmElementText(signUpCardSubTitle, 'By continuing you are confirming:', 'signUpCardSubTitle');
    await confirmElementText(bulletPoint1, 'The details in this application are accurate', 'bulletPoint1');
    await confirmElementText(bulletPoint2, 'You agree to advise Santander within 30 days of any change in circumstances that affects your business or personal tax residency status or makes the information you\'ve provided us inaccurate', 'bulletPoint2');
    await confirmElementText(bulletPoint3, 'You understand that Santander will use your personal data to make checks on you as described in the Data Protection Statement (included in the General Terms and Conditions)', 'bulletPoint3');
    await confirmElementText(contactUsText, 'If there is anything about the Regular eSaver or the application process that you\'re unsure about please contact us before proceeding.', 'contactUsText', true);
    await confirmElementText(termsAndConditionsLink, 'General Terms and Conditions, Key Facts Document', 'termsAndConditionsLink');
    await confirmElementText(agreeAndSignText, 'I agree to sign up to Regular eSaver. I confirm I have read and accepted the items listed above', 'agreeAndSignText', true);
    await confirmElementText(continueButton, 'Continue', 'continueButton');
}

export async function validateCustomerDataOnly () {
    console.log('>>>Validating Agree And Sign Up Page Customer Data<<<');
    await browser.sleep(3000);
    await confirmElementText(emailElement, email, 'emailElement');
    await confirmElementText(mobileElement, phoneNumber, 'mobileElement', true);
    await confirmElementText(postcodeElement, postcode, 'postcodeElement');
}

export async function clickOnUpdateDetailsAndValidate( ) {
    console.log('>>>Validating Update Details Block<<<');
    await confirmElementText(updateDetailsLink, 'How do I update these details?');
    await clickOn(updateDetailsLink);
    await browser.sleep(2000);
    await confirmElementText(changeContactDetailsHeading, 'Change your contact details');
    await confirmElementText(changeContactDetailTestx1, `If any of the details are incorrect please go to: 'My details & settings' within your online banking to update.`);
    await confirmElementText(changeContactDetailTestx2, `You can't apply until you've changed your details and our records have been updated.`);
    await confirmElementText(closeLink, 'Close');
}

export async function closeUpdateDetailsPopUp() {
   await clickOn (closeLink);
   await browser.sleep(1000);
   expect (await changeContactDetailsHeading.isPresent()).false;
}

export async function completeAgreeAndSignUpPage () {
    console.log('>>>Completing Agree And Sign Up Page<<<');
    await clickOn(agreeAndSignCheckBox);
    await clickOn(continueButton);
    await browser.sleep(4000);
}

export async function validateLink (nameOfLink) {
    console.log('Validating link');
    await clickLinkAndValidateNewTabUrlAndClose(nameOfLink, links[nameOfLink].element, links[nameOfLink].url);
}

export async function validateFooterLinks () {
    console.log('Validating link');
    await clickLinkAndValidateNewTabUrlAndClose('onlineBankingGuarantee', links.onlineBankingGuarantee.element, links.onlineBankingGuarantee.url);
    await clickLinkAndValidateNewTabUrlAndClose('siteHelpAndAccessibility', links.siteHelpAndAccessibility.element, links.siteHelpAndAccessibility.url);
    await clickLinkAndValidateNewTabUrlAndClose('securityAndPrivacy', links.securityAndPrivacy.element, links.securityAndPrivacy.url);
    await clickLinkAndValidateNewTabUrlAndClose('legal', links.legal.element, links.legal.url);
}

export async function verifyRedirectionIsDone () {
    console.log('validating redirection');
    const EC = protractor.ExpectedConditions;
    await browser.wait(EC.urlContains('olaojsec.santanderuk.pre.corp'), 60000).then(function(result) {
        expect(result).equals(true);
    });
    console.log('Navigated to: ', await browser.getCurrentUrl());
    await browser.sleep(2000);
    // expect(await browser.getCurrentUrl()).equals('https://olaojsec.santanderuk.pre.corp/SecRetEsaverWeb/ola.htm?ps=3017680000014&refId=123RegeSavercompOLB&ex=060619&prod=regular&_flowId=esaver&ma=false');
}

export async function pressBrowserBackButtonAndValidate () {
    await browser.sleep(1000);
    const currrentUrl = await browser.getCurrentUrl();
    console.log('click browser back button')
    await browser.navigate().back();
    await browser.sleep(3000);
    expect(await browser.getCurrentUrl()).equals(currrentUrl);
}
export async function pressBrowserBackButtonAndValidateErrorPage () {
    console.log('click browser back button')
    await browser.navigate().back();
    await browser.sleep(3000);
    expect(await browser.getCurrentUrl()).contains('error');
}
