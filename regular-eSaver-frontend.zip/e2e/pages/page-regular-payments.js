import { clickOn, confirmElementText } from '@portland/protractor-cucumber-utils';
import { element, by, browser } from 'protractor';
import { expect } from 'chai';

// Regular Payments Page Elements
const titleOfPage = element(by.css('.title') );
const breadcrumb1 = element(by.css('s-breadcrumbs > ul > li:nth-child(1) > span'));
const breadcrumb2 = element(by.css('s-breadcrumbs > ul > li:nth-child(2) > span'));
const regularPaymentsCardTitle = element(by.css('.s-card--title'));
const infoParagraph1 = element(by.css('.s-card > p:nth-child(2)'));
const infoParagraph2 = element(by.css('.s-card > p:nth-child(3)'));
const infoParagraph3 = element(by.css('.s-card > p:nth-child(4)'));
const finishButton = element(by.xpath('/html/body/div/app-root/div/app-setup-regular-payments/div[2]/a'));


export async function validateRegularPaymentsPage () {
    console.log('>>>Validating Regular Payments Page<<<');
    console.log(await browser.getCurrentUrl());
    expect(await browser.getCurrentUrl()).contains('payments');
    await confirmElementText(titleOfPage, 'Regular eSaver', 'titleOfPage');
    await confirmElementText(breadcrumb1, 'Agree and Sign up', 'breadcrumb1');
    await confirmElementText(breadcrumb2, 'Setup regular payments', 'breadcrumb2');
    await confirmElementText(regularPaymentsCardTitle, 'Regular payments', 'regularPaymentsCardTitle');
    await confirmElementText(infoParagraph1, 'Please remember that in order to fund your account and make the most of the interest rate you should set up a standing order.', 'infoParagraph1');
    await confirmElementText(infoParagraph2, 'You can do this in your online banking after your account has been opened.', 'infoParagraph2');
    await confirmElementText(infoParagraph3, 'You can make any number of payments via standing order and you don\'t have to make a deposit every month. The amount can vary each month, providing you don\'t go over the £200 monthly funding limit.', 'infoParagraph3');
    await confirmElementText(finishButton, 'Finish', 'finishButton');
}

export async function completeRegularPaymentsPage () {
    console.log('>>>Completing Regular Payments Page<<<');
    await clickOn(finishButton);
    await browser.sleep(4000);
    expect(await browser.getCurrentUrl()).contains('santander.co.uk');
}