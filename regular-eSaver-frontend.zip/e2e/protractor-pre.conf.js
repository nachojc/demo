// Protractor configuration file, see link for more information
exports.config = {
	allScriptsTimeOut: 500000,
	ignoreUncaughtExceptions: true,
	untrackOutstandingTimeouts: true,
	framework: 'custom',
	frameworkPath: require.resolve('protractor-cucumber-framework'),
	seleniumAddress: 'http://sh-cap2-zone1-taassel-pro.appls.cap2.paas.gsnetcloud.corp/wd/hub',
	directConnect: false,
	multiCapabilities: [
		{
			browserName: 'chrome',
			acceptSslCerts: true,
			maxInstances: 1,
			chromeOptions: {
				useAutomationExtension: false
			}
		},
		// {
		// 	browserName: 'firefox',
		// 	acceptInsecureCerts: true,
		// 	ignoreProtectedModeSettings: true
		// },
		// {
		// 	browserName: 'safari',
		// 	ignoreProtectedModeSettings: true,
		// 	platform: "ANY",
		// 	shardTestFiles: false,
		// 	maxInstances: 1,
		// 	acceptInsecureCerts: true,
		// 	metadata: {
		// 		browser: {
		// 			name: 'safari',
		// 			version: '11'
		// 		},
		// 		device: 'TaaS Selenium Hub',
		// 		platform: {
		// 			name: 'osx',
		// 			version: '10.12'
		// 		}
		// 	}
		// },
		// {
		// 	browserName: "internet explorer",
		// 	ignoreProtectedModeSettings: true,
		// 	ignoreZoomSetting: true,
		// 	platform: "ANY",
		// 	version: "11",
		// 	shardTestFiles: false,
		// 	maxInstances: 1
		// },
		// {
		// 	browserName: "MicrosoftEdge",
		// 	seleniumAddress: 'http://sh-cap2-zone1-taassel-pro.appls.cap2.paas.gsnetcloud.corp/wd/hub'
		// }
	],
	plugins: [{
		package: 'protractor-multiple-cucumber-html-reporter-plugin',
		options: {
			automaticallyGenerateReport: true,
			removeExistingJsonReportFile: true,
			removeOriginalJsonReportFile: true,
			pageTitle: 'loginINTbanking',
			reportName: 'loginINTbanking',
			customData: {
				title: 'E2E Testing',
				data: [
					{ label: 'Project', value: 'regular esave' },
					{ label: 'Release', value: '1.0' },
					{ label: 'Cycle', value: '1' }
				]
			}
		}
	}],
	specs: [
		'features/01-pre/02-offline/*.feature',
	],
	cucumberOpts: {
		require: ["step-definitions/*.js"],
		format: ['json:./target/reports/cucumber_report.html.json', 'node_modules/cucumber-pretty']
  },
  onPrepare: async () => {
		const browser = require('protractor').browser;
		browser.ignoreSynchronization = true;
		require('babel-register');
		require('babel-polyfill');
	},
};
