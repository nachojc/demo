export interface RegularESaverAccountCase {
    type: string;
    attributes: {
        account: string
    };
    status: number;
}
