export enum ErrorCodes {
    GET_CUSTOMER_DETAILS = 1,
    CASE_SUBMISSION = 2,
    GET_ACCOUNT_STATUS = 3
}
