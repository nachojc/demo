export interface RegularESaverCase {
  id: string;
  type: string;
  attributes: RegularESaverCaseResource;
}

export interface RegularESaverCaseError {
  errors: RegularESaverCaseErrorResource[];
}

export interface RegularESaverCaseResource {
  email: string;
  firstName: string;
  mobilePhone: string;
  postCode: string;
  termsAndConditions: boolean;
}

export interface RegularESaverCaseResponse {
  data: RegularESaverCase;
}

export interface RegularESaverCaseErrorResource {
  status: number;
  code: number;
  detail: string;
  source: string;
}
