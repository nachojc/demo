import { Location } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { AppRoutingModule } from './app-routing.module';
import { UrlParamCollectorService } from './services/url-param-collector/url-param-collector.service';

describe('AppRoutingModule', () => {
  let appRoutingModule: AppRoutingModule;

  const routerMock = {
    parseUrl: jasmine.createSpy('parseUrl').and.returnValue({ queryParamMap: { get: () => '46094086' }}),
    navigate: jasmine.createSpy('navigate')
  };

  const locationMock = {
    path: Function
  };

  const paramServiceMock = {
    setQueryParams: jasmine.createSpy('setQueryParams'),
    hasMandatoryKeys: jasmine.createSpy('hasMandatoryKeys').and.returnValue(true)
  };

  const configureTestBed = () => {
    TestBed.configureTestingModule({
      providers: [
        AppRoutingModule,
        { provide: Router, useValue: routerMock},
        { provide: Location, useValue: locationMock },
        { provide: UrlParamCollectorService, useValue: paramServiceMock }
      ]
    });
    appRoutingModule = TestBed.get(AppRoutingModule);
  };

  afterEach(() => {
    routerMock.navigate.calls.reset();
  });

  it('should create an instance', () => {
    configureTestBed();
    expect(appRoutingModule).toBeTruthy();
  });

  it('should call setQueryParams of paramService', () => {
    configureTestBed();
    expect(paramServiceMock.setQueryParams).toHaveBeenCalled();
  });
});
