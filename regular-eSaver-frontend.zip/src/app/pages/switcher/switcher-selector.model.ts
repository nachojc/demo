export default 'app-switcher';
