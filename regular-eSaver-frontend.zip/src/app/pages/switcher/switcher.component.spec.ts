import { async, ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { of, Subject, from } from 'rxjs';
import { StandardError } from 'src/app/models/standard-error.model';
import { AdobeService } from 'src/app/services/adobe/adobe.service';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import { UrlParamCollectorService } from 'src/app/services/url-param-collector/url-param-collector.service';
// tslint:disable-next-line: max-line-length
import RegularESaverCaseHoldingsError from '../../../../external-files/regular-esaver-manager/regular-esaver/regular-esaver-holding-error.json';
import RegularESaverCaseDataError from '../../../../external-files/regular-esaver-manager/regular-esaver/regular-esaver-data-error.json';
import RegularESaverCaseOJError from '../../../../external-files/regular-esaver-manager/regular-esaver/regular-esaver-error-OJ.json';
import selector from './switcher-selector.model';
import { SwitcherComponent } from './switcher.component';
import { ErrorsService } from 'src/app/services/errors/errors.service';
import { FrontendLoggingService } from '@portland/angular-common-s-elements';

describe('Switcher', () => {
  let component: SwitcherComponent;
  let fixture: ComponentFixture<SwitcherComponent>;
  let navigator: NavigatorService;
  let paramService: UrlParamCollectorService;
  let config: ConfigService;
  let adobe: AdobeService;

  let customerSubject: Subject<any>;
  let fetchConfigSubject = new Subject<any>();

  const customerNextSubject = {
    firstName: 'Peter',
    email: 'peter@example.com',
    postCode: 'MK111B',
    mobilePhone: '+447911123456'
  };

  const errorsServiceMock = {
    setErrors: jasmine.createSpy('setErrors'),
    hasError: jasmine.createSpy('hasError')
  };

  const accountStatusWithDataErrorsMock = Object.assign({}, RegularESaverCaseDataError);
  const accountStatusWithHoldingsErrorsMock = Object.assign({}, RegularESaverCaseHoldingsError);

  const accountStatus500WithOJCodesMock = Object.assign({}, RegularESaverCaseOJError);

  const customerErrorSubject = StandardError.build('Invalid customer', 409);

  const navigatorMock = {
    navigate: jasmine.createSpy('navigate')
  };

  const customerDetailsServiceMock = {
    getCustomerDetails: () => customerSubject.asObservable()
  };

  const paramsServiceMock = {
    hasMandatoryKeys: () => true,
    isValidDate: () => true
  };

  const timeout = 7000;

  const configServiceMock = {
    fetchConfig: () => fetchConfigSubject.asObservable(),
    getConfigParam: jasmine.createSpy('getConfigParam').and.callFake(param => {
      return {
        'currentTime': of('fakeTime'),
        'timeout': of('' + timeout)
      }[param];
    })
  };

  const adobeServiceMock = {
    sendPageTrackingInformation: jasmine.createSpy('sendPageTrackingInformation')
  };

  const frontendLoggingServiceMock = {
    sendErrorLog: () => jasmine.createSpy('sendErrorLog'),
    createNetworkErrorObj: () => jasmine.createSpy('createNetworkErrorObj')
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SwitcherComponent],
      providers: [
        { provide: NavigatorService, useValue: navigatorMock },
        { provide: CustomerDetailsService, useValue: customerDetailsServiceMock },
        { provide: UrlParamCollectorService, useValue: paramsServiceMock },
        { provide: ConfigService, useValue: configServiceMock },
        { provide: AdobeService, useValue: adobeServiceMock },
        { provide: ErrorsService, useValue: errorsServiceMock },
        { provide: FrontendLoggingService, useValue: frontendLoggingServiceMock },
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(SwitcherComponent);
    component = fixture.componentInstance;
    navigator = TestBed.get(NavigatorService);
    paramService = TestBed.get(UrlParamCollectorService);
    config = TestBed.get(ConfigService);
    adobe = TestBed.get(AdobeService);
    customerSubject = new Subject<any>();
    fetchConfigSubject = new Subject<any>();
    // because ngOnInit is asynchronous (timeout operator)
    // we cannot call fixture.detectChanges() here, it needs to be called inside a fakeAsync block
  }));

  afterEach(() => {
    navigatorMock.navigate.calls.reset();
    configServiceMock.getConfigParam.calls.reset();
    adobeServiceMock.sendPageTrackingInformation.calls.reset();
    errorsServiceMock.setErrors.calls.reset();
  });

  afterAll(() => {
    fixture.nativeElement.style.display = 'none'; // removes spinner on tests screen
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should track adobe information with switcher pageIdentifier', () => {
    fixture.detectChanges();
    expect(adobe.sendPageTrackingInformation).toHaveBeenCalledWith('/switcher');
  });

  it('should have the selector from an external file', async(() => {
    const hackComponent = <any>component;
    const actualSelector = hackComponent.constructor.__annotations__ ?
      hackComponent.constructor.__annotations__[0].selector :
      undefined;
    if (actualSelector) { expect(actualSelector).toEqual(selector); }
  }));

  it('should navigate with ok when a customer is retrieved', () => {
    fixture.detectChanges();
    customerSubject.next(customerNextSubject);
    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'ok');
  });

  it('should navigate with nok when a customer is not retrieved', () => {
    fixture.detectChanges();
    customerSubject.error(customerErrorSubject);
    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'nok');
  });

  it('should navigate with nok after timeout value', fakeAsync(() => {
    fixture.detectChanges();
    tick(timeout + 100);
    expect(config.getConfigParam).toHaveBeenCalledWith('timeout');
    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'nok');
  }));

  it('should still navigate with ok if it receives a value within timeout value', fakeAsync(() => {
    fixture.detectChanges();
    tick(timeout - 100);
    expect(config.getConfigParam).toHaveBeenCalledWith('timeout');
    customerSubject.next(customerNextSubject);
    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'ok');
  }));

  it('should not navigate to switcher if mandatory URL params are not present, in init', () => {
    spyOn(paramService, 'isValidDate').and.returnValue(false);

    fixture.detectChanges();

    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'invalidDate');
  });

  it('should build a StandardError after receive an error response from fetchConfig', () => {
    const errorSpy = spyOn(StandardError, 'build');

    fetchConfigSubject.error(StandardError.build('Bad Request', 400));

    expect(errorSpy).toHaveBeenCalled();
  });

  it('should navigate to errors page if #getCustomerDetails call returns error codes 33 | 34', () => {
    errorsServiceMock.hasError.and.returnValue(true);
    fixture.detectChanges();
    customerSubject.error({ error: accountStatusWithDataErrorsMock });

    expect(errorsServiceMock.setErrors).toHaveBeenCalled();
    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'app-error-values');
  });

  it('should navigate to errors page if #getCustomerDetails call returns error codes 3 ', () => {
    errorsServiceMock.hasError.and.returnValue(true);
    fixture.detectChanges();
    customerSubject.error({ error: accountStatusWithHoldingsErrorsMock });

    expect(errorsServiceMock.setErrors).toHaveBeenCalled();
    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'app-error-values');
  });

  it('should navigate to the old journey if the there is a 500 status and the error code is not 3 | 33 | 34', () => {
    errorsServiceMock.hasError.and.returnValue(false);
    fixture.detectChanges();

    customerSubject.error({ error: accountStatus500WithOJCodesMock });

    expect(navigator.navigate).toHaveBeenCalledWith(selector, 'nok');
  });

  it('should not call #getCustomerDetails when it has already been called', () => {
    fixture.detectChanges();

    expect(navigatorMock.navigate).not.toHaveBeenCalled();
  });
});
