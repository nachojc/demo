import { Component, OnInit } from '@angular/core';
import { zip } from 'rxjs';
import { first, timeout, map } from 'rxjs/operators';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import { UrlParamCollectorService } from 'src/app/services/url-param-collector/url-param-collector.service';
import selector from './switcher-selector.model';
import { AdobeService } from 'src/app/services/adobe/adobe.service';
import { ErrorsService } from 'src/app/services/errors/errors.service';
import { FrontendLoggingService } from '@portland/angular-common-s-elements';
import { ErrorCodes } from 'src/app/models/errorCodes.model';

@Component({
  selector,
  templateUrl: './switcher.component.html',
  styleUrls: ['./switcher.component.css']
})
export class SwitcherComponent implements OnInit {
  private timeout = 15000;

  constructor(
    private navigator: NavigatorService,
    private customerDetails: CustomerDetailsService,
    private config: ConfigService,
    private paramService: UrlParamCollectorService,
    private adobe: AdobeService,
    private errorsService: ErrorsService,
    private loggingService: FrontendLoggingService
  ) { }

  ngOnInit() {
    if (!this.customerDetails.isAlreadyCalled) { // for browser-back action, not to repeat call
      this.adobe.sendPageTrackingInformation('/switcher');

      zip(
        this.config.getConfigParam('timeout'),
        this.config.getConfigParam('currentTime')
      ).pipe(
        first(),
        map(([cfgTimeout, currentTime]) => [
          parseInt(<string>cfgTimeout, 10), // TODO: timeout can be a number
          currentTime
        ])
      ).subscribe(
        ([cfgTimeout, currentTime]) => {
          this.timeout = <number>cfgTimeout;
          if (this.paramService.isValidDate(<Date>currentTime)) {
            this.askIfValidJourney();
          } else {
            this.navigator.navigate(selector, 'invalidDate');
          }
        }
      );
    }
  }

  private askIfValidJourney() {
    this.customerDetails.getCustomerDetails()
      .pipe(
        timeout(this.timeout),
        first()
      )
      .subscribe(
        () => this.navigator.navigate(selector, 'ok'),
        (httpError) => {
          if (httpError.status !== 409) {
            this.loggingService.sendErrorLog(
              this.loggingService.createNetworkErrorObj(httpError, ErrorCodes.GET_CUSTOMER_DETAILS)
            );
          }

          if (httpError.error) {
            this.errorsService.setErrors(httpError.error.errors);

            if (this.errorsService.hasError()) {
              this.navigator.navigate(selector, 'app-error-values');
            } else {
              this.navigator.navigate(selector, 'nok');
            }
          } else {
            this.navigator.navigate(selector, 'nok');
          }
        }
      );
  }
}
