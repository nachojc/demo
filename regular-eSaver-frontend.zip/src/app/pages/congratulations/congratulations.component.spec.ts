import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SProgressIndicatorComponentModule } from '@portland/angular-common-s-elements';
import regularESaverAccountCase from 'external-files/regular-esaver-manager/regular-esaver-account/regular-esaver-account-GET.json';
import regularESaverCase from 'external-files/regular-esaver-manager/regular-esaver/regular-esaver-POST.json';
import { of } from 'rxjs';
import { AccountStatusService } from 'src/app/services/account-status/account-status.service';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import congratulationsSelector from './congratulations-selector.model';
import { CongratulationsComponent } from './congratulations.component';

describe('CongratulationsComponent', () => {
  let component: CongratulationsComponent;
  let fixture: ComponentFixture<CongratulationsComponent>;

  const configMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.returnValue(of('Regular eSaver'))
  };

  const customerDetailsMock = Object.assign({}, regularESaverCase.data); // fix and refactor model
  const accountStatusMock = Object.assign({}, regularESaverAccountCase);

  const customerDetailsServiceMock = {
    getCustomerDetails: jasmine.createSpy('getCustomerDetails').and.returnValue(of(customerDetailsMock))
  };

  const accountStatusServiceMock = {
    getAccountStatus: jasmine.createSpy('getAccountStatus').and.returnValue(of(accountStatusMock))
  };

  const NavigatorServiceMock = {
    navigate: jasmine.createSpy('navigate')
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CongratulationsComponent ],
      imports: [ SProgressIndicatorComponentModule ],
      providers: [
        { provide: ConfigService, useValue: configMock },
        { provide: CustomerDetailsService, useValue: customerDetailsServiceMock },
        { provide: AccountStatusService, useValue: accountStatusServiceMock },
        { provide: NavigatorService, useValue: NavigatorServiceMock }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CongratulationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get productName, firstName and accountNumber onInit', () => {
    expect(component.productName).toEqual('Regular eSaver');
    expect(component.firstName).toEqual(customerDetailsMock.attributes.firstName);
    expect(component.accountNumber).toEqual(accountStatusMock.attributes.account);
  });

  it('should navigate with current component selector after clicking on Continue Button', () => {
    component.confirmCase();

    expect(NavigatorServiceMock.navigate).toHaveBeenCalledWith(congratulationsSelector);
  });
});
