import { Component, OnInit } from '@angular/core';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import { ProgressIndicatorItem } from '@portland/angular-common-s-elements';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { first } from 'rxjs/operators';
import { AccountStatusService } from 'src/app/services/account-status/account-status.service';
import selector from './congratulations-selector.model';

@Component({
  selector: 'app-congratulations',
  templateUrl: './congratulations.component.html',
  styleUrls: ['./congratulations.component.css']
})
export class CongratulationsComponent implements OnInit {
  pages: ProgressIndicatorItem[];

  productName: String;
  firstName: String;
  accountNumber: String;

  constructor(
    private navigator: NavigatorService,
    private configService: ConfigService,
    private customerDetailsService: CustomerDetailsService,
    private accountStatusService: AccountStatusService,
  ) { }

  ngOnInit() {
    this.pages = this.navigator.pages;

    this.configService.getConfigParam('productName')
      .pipe(first()).subscribe(
        (productName: string)  => this.productName = productName
      );

    this.customerDetailsService.getCustomerDetails()
      .pipe(first()).subscribe(
        details => this.firstName = details.attributes.firstName
      );

    this.accountStatusService.getAccountStatus()
      .pipe(first()).subscribe(
        details => this.accountNumber = details.attributes.account
      );
  }

  confirmCase() {
    this.navigator.navigate(selector);
  }
}
