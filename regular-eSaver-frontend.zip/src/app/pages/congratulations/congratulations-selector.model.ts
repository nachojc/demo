export default 'app-congratulations';
