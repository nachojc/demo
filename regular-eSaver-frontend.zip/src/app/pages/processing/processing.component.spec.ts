import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ProcessingComponent } from './processing.component';
import { AccountStatusService } from 'src/app/services/account-status/account-status.service';
import { of, Subject } from 'rxjs';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import processingSelector from './processing-selector.model';
import { ConfigService } from 'src/app/services/config/config.service';
import { StandardError } from 'src/app/models/standard-error.model';
import upTimeWindow from '../../../../external-files/config/application-GET.json';
import { FrontendLoggingService } from '@portland/angular-common-s-elements';

describe('ProcessingComponent', () => {
  let component: ProcessingComponent;
  let fixture: ComponentFixture<ProcessingComponent>;

  let accountStatusSubject: Subject<any>;
  let currentTimeSubject: Subject<any>;

  const RegularESaverAccountCase = {
    'type': 'regularESaverAccount',
    'attributes': {
        'account': 'SAVING R4600004546'
    },
    'status': 200
  };

  const accountStatus200Mock = Object.assign({}, RegularESaverAccountCase);

  const accountStatusServiceMock = {
    getAccountStatus: () => accountStatusSubject.asObservable()
  };

  const navigatorServiceMock = {
    navigate: jasmine.createSpy('navigate')
  };

  const frontendLoggingServiceMock = {
    sendErrorLog: () => jasmine.createSpy('sendErrorLog'),
    createNetworkErrorObj: () => jasmine.createSpy('createNetworkErrorObj')
  };

  const uptimeWindowMock = Object.assign({}, upTimeWindow.upTimeWindow);

  const configServiceMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.callFake(param => {
      return {
        'processing-waiting-time': of(1000),
        'processing-attempts': of(2),
        'processing-attempts-interval': of(2000),
        'currentTime': currentTimeSubject.asObservable(),
        'upTimeWindow': of(uptimeWindowMock)
      }[param];
    })
  };

  beforeEach(async(() => {
    accountStatusSubject = new Subject<any>();
    currentTimeSubject = new Subject<any>();

    TestBed.configureTestingModule({
      declarations: [ ProcessingComponent ],
      providers: [
        { provide: AccountStatusService, useValue: accountStatusServiceMock },
        { provide: NavigatorService, useValue: navigatorServiceMock },
        { provide: ConfigService, useValue: configServiceMock },
        { provide: FrontendLoggingService, useValue: frontendLoggingServiceMock }
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ProcessingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  afterEach(() => {
    navigatorServiceMock.navigate.calls.reset();
    configServiceMock.getConfigParam.calls.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get accountStatus data onInit and navigate with Congratulations if status is 200', fakeAsync(() => {
    currentTimeSubject.next(new Date('05/02/1983 09:15'));

    tick(1000); // We need to wait 1 sec before emitting the accountStatus
    accountStatusSubject.next(accountStatus200Mock); // 200

    expect(navigatorServiceMock.navigate).toHaveBeenCalledWith(processingSelector);
  }));

  it('should navigate with accountUndefined if response comes with error', fakeAsync(() => {
    currentTimeSubject.next(new Date('05/02/1983 09:15'));
    accountStatusSubject.error(StandardError.build('account is undefined', 500)); // 500

    tick(4900); // We need to wait 1 initial sec + 2 secs x 2 intervals = 5 secs

    expect(navigatorServiceMock.navigate).not.toHaveBeenCalledWith(processingSelector, 'accountUndefined');

    tick(200);

    expect(navigatorServiceMock.navigate).toHaveBeenCalledWith(processingSelector, 'accountUndefined');
  }));

  it('should navigate with bridgeOffline if currentTime is not within uptimeWindow', fakeAsync(() => {
    currentTimeSubject.next(new Date('05/02/1983 01:15'));

    expect(navigatorServiceMock.navigate).toHaveBeenCalledWith(processingSelector, 'bridgeOffline'); // we return after this

    navigatorServiceMock.navigate.calls.reset();

    tick(1000);
    accountStatusSubject.next(accountStatus200Mock);

    expect(navigatorServiceMock.navigate).not.toHaveBeenCalled(); // we do not go to timer to check accountStatus
  }));

  it('#getCurrentTimeInMinutes should return amount of minutes for hour and minutes from a date', () => {
    expect(component.getCurrentTimeInMinutes(new Date('05/02/1983 01:15'))).toEqual(75);
  });

  it('#setOnlineWindowTime takes an array with 2 strings and returns and array with two hours+minutes added', () => {
    expect(component.setOnlineWindowTime(['0631', '2059'])).toEqual([391, 1259]);
  });
});
