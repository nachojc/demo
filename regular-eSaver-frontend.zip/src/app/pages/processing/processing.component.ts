import { Component, OnDestroy, OnInit } from '@angular/core';
import { timer, zip, of } from 'rxjs';
import { delayWhen, flatMap, retryWhen, take, first, tap } from 'rxjs/operators';
import { AccountStatusService } from 'src/app/services/account-status/account-status.service';
import { ConfigService } from 'src/app/services/config/config.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import selector from './processing-selector.model';
import { StandardError } from 'src/app/models/standard-error.model';
import { FrontendLoggingService } from '@portland/angular-common-s-elements';
import { ErrorCodes } from 'src/app/models/errorCodes.model';

const weekHash = {
  '0' : 'Sunday',
  '1' : 'Monday',
  '2' : 'Tuesday',
  '3' : 'Wednesday',
  '4' : 'Thursday',
  '5' : 'Friday',
  '6' : 'Saturday'
};

@Component({
  selector: selector,
  templateUrl: './processing.component.html',
  styleUrls: ['./processing.component.css']
})
export class ProcessingComponent implements OnInit, OnDestroy {
  private retrySubscription;
  private attemptsToRetry: number;
  private currentTimeToCompare: number;
  private currentTimeDay: string;
  waitingTime: number;

  constructor(
    private accountStatusService: AccountStatusService,
    private navigator: NavigatorService,
    private configService: ConfigService,
    private loggingService: FrontendLoggingService
  ) { }

  ngOnInit() {
    zip(
      this.configService.getConfigParam('processing-waiting-time'),
      this.configService.getConfigParam('processing-attempts'),
      this.configService.getConfigParam('currentTime'),
      this.configService.getConfigParam('upTimeWindow'),
      this.configService.getConfigParam('processing-attempts-interval')
    ).pipe(
      first()
    ).subscribe(([waitingTime, attempts, currentTime, upTimeWindow, interval]) => {
      this.waitingTime = waitingTime / 1000;
      this.currentTimeDay = weekHash[new Date(currentTime).getDay().toString()];

      this.currentTimeToCompare = this.getCurrentTimeInMinutes(currentTime);
      const onlineWindowRange = this.setOnlineWindowTime(upTimeWindow[this.currentTimeDay]);

      if (!(this.currentTimeToCompare > onlineWindowRange[0]
          && this.currentTimeToCompare < onlineWindowRange[1])) {
        this.navigator.navigate(selector, 'bridgeOffline');
        return; // we need this not to continue with the timer and check accountStatus
      }

      this.attemptsToRetry = <number>attempts;
      let _gotAccount = false;

      timer(
        <number>waitingTime
      ).pipe( first())
      .subscribe(() => {
        this.retrySubscription = of('')
        .pipe(
          flatMap(() => this.accountStatusService.getAccountStatus()),
          retryWhen(error =>
            error.pipe(
                tap(val => {
                  if (val.message !== 'account is undefined') {
                    this.loggingService.sendErrorLog(
                      this.loggingService.createNetworkErrorObj(val, ErrorCodes.GET_ACCOUNT_STATUS)
                    );
                  }
                }),
                delayWhen( () => timer(interval)
              ), // interval
              take(this.attemptsToRetry) // attempts
            )
          ),
          take(1) // first() does not work => https://swalsh.org/blog/rxjs-first-vs-take1
        ).subscribe(
          data => {
            if (data.status === 200) {
              _gotAccount = true;
            }
          },
          (error: StandardError) => { this.navigator.navigate(selector, error); }, // does not execute
          () => {
            if (_gotAccount) {
              this.navigator.navigate(selector);
            } else {
              this.navigator.navigate(selector, 'accountUndefined');
            }
          }
        );
      });
    });
  }

  getCurrentTimeInMinutes(currentTime) {
    const timeInHours = new Date(currentTime).getHours();
    let timeInMinutes = timeInHours * 60;
    timeInMinutes += new Date(currentTime).getMinutes();

    return timeInMinutes;
  }

  setOnlineWindowTime(onlineWindowTime) {
    let onlineTimeInMinutes;
    const timeArray = [];

    onlineWindowTime.forEach(el => {
      const timeInHours = parseInt( el.substring(0, 2), 10 );
      let timeInMinutes = timeInHours * 60;
      onlineTimeInMinutes = timeInMinutes += parseInt(el.substring(2, 4), 10);

      timeArray.push(onlineTimeInMinutes);
    });

    return timeArray;
  }

  ngOnDestroy(): void {
    if (this.retrySubscription) {
      this.retrySubscription.unsubscribe();
    }
  }
}
