import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ErrorComponent } from './error.component';
import { By } from '@angular/platform-browser';

describe('ErrorComponent', () => {
  let component: ErrorComponent;
  let fixture: ComponentFixture<ErrorComponent>;
  let ulElem;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErrorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorComponent);
    component = fixture.componentInstance;
    ulElem = fixture.debugElement.query(By.css('ul'));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render the right text in an h1 html tag', () => {
    const h1Elem = fixture.debugElement.query(By.css('h1')).nativeElement;
    
    expect(h1Elem.textContent).toEqual('Sorry, there seems to be a problem');
  });

  it('should contain 5 <li> elements inside the <ul> element', () => {
    expect(ulElem.children.length).toEqual(5);
  });

  it('each element in the <ul> list should contain correct text', () => {
    expect(ulElem.children[0].nativeElement.textContent).toEqual('there is a problem with your internet or mobile connection');
    expect(ulElem.children[1].nativeElement.textContent).toEqual('you\'ve tried to access a secure page you\'ve previously saved');
    expect(ulElem.children[2].nativeElement.textContent).toEqual('you don\'t have JavaScript enabled on your browser');
    expect(ulElem.children[3].nativeElement.textContent).toEqual('you\'ve disabled cookies on your browser, or');
    expect(ulElem.children[4].nativeElement.textContent).toEqual('there\'s an issue with our systems');
  });

  it('should render the right text in an h2 tag', () => {
    const h2Elem = fixture.debugElement.query(By.css('h2')).nativeElement;

    expect(h2Elem.textContent).toEqual('Let us help you');
  });

  it('should show the right contact phone number in the contactParagraph', () => {
    const contactNumber = '0800 917 9170';
    const contactParagraph = fixture.debugElement.queryAll(By.css('p'))[2].nativeElement;
    
    expect(contactParagraph.textContent).toContain(contactNumber);
  });
});
