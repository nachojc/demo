import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ProgressIndicatorItem, FrontendLoggingService } from '@portland/angular-common-s-elements';
import { first } from 'rxjs/operators';
import { RegularESaverCase, RegularESaverCaseResource } from 'src/app/models/regularESaverCase.model';
import { AdobeService } from 'src/app/services/adobe/adobe.service';
import { CaseSubmissionService } from 'src/app/services/case-submission/case-submission.service';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { LegalDataCollectorService } from 'src/app/services/legal-data-collector/legal-data-collector.service';
import { LegalData } from 'src/app/services/legal-data-collector/legal-data.model';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import selector from './sign-up-selector.model';
import { ErrorCodes } from 'src/app/models/errorCodes.model';

@Component({
  selector: selector,
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css', '../../../styles/progressIndicatorInPage.css'],
  encapsulation: ViewEncapsulation.None
})
export class SignUpComponent implements OnInit {
  pages: ProgressIndicatorItem[];
  private regularESaverCase: RegularESaverCase;
  customerDetails: RegularESaverCaseResource;
  signUpData: LegalData;
  productName: String;
  private isSubmitted = false;

  private checkbox: NgModel;
  @ViewChild('checkbox') set _checkbox(checkboxAsNgModel: NgModel) {
    this.checkbox = checkboxAsNgModel;
  }

  termsAccepted: true | '';

  visibleInstructions: Boolean = false;

  constructor(
    private appNavigation: NavigatorService,
    private customerDetailsService: CustomerDetailsService,
    private configService: ConfigService,
    private legalDataCollector: LegalDataCollectorService,
    private caseSubService: CaseSubmissionService,
    private loggingService: FrontendLoggingService,
    private adobe: AdobeService
  ) { }

  ngOnInit(): void {
    this.pages = this.appNavigation.pages;

    this.configService.getConfigParam('productName')
      .subscribe(
        (productName: string) => this.productName = productName
      );

    this.legalDataCollector.getLegalData()
      .pipe(first()).subscribe(
        legalData => this.signUpData = legalData
      );

    this.customerDetailsService.getCustomerDetails()
      .pipe(first()).subscribe(
        (regularESaverCase: RegularESaverCase) => {
          this.regularESaverCase = regularESaverCase;
          this.customerDetails = regularESaverCase.attributes;
        }
      );
  }

  signUp() {
    if (!this.isSubmitted) {
      if (this.termsAccepted === true) {
        this.isSubmitted = true;
        this.customerDetails.termsAndConditions = true;
        this.caseSubService.handleCase(this.regularESaverCase) // TODO: this is not responsability of sign-up but the app
          .subscribe(
            () => {
              this.appNavigation.navigate(selector);
            },
            (error) => {
              this.loggingService.sendErrorLog(
                this.loggingService.createNetworkErrorObj(error, ErrorCodes.CASE_SUBMISSION)
              );
              this.adobe.setErrorInformation('Error in /about-you');
              this.appNavigation.navigate(selector, 'error');
            }
          );
      } else {
        this.checkbox.control.markAsTouched();
        this.adobe.setCheckboxError();
        this.adobe.sendPageTrackingInformation('/about-you');
      }
    }
  }

  toogleUpdateInstructions(event: Event) {
    event.preventDefault();
    this.visibleInstructions = !this.visibleInstructions;
  }
}
