export default 'app-sign-up';
