import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { SProgressIndicatorComponentModule, SCheckboxComponentModule } from '@portland/angular-common-s-elements';
import { of, Subject } from 'rxjs';
import { AdobeService } from 'src/app/services/adobe/adobe.service';
import { CaseSubmissionService } from 'src/app/services/case-submission/case-submission.service';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { LegalDataCollectorService } from 'src/app/services/legal-data-collector/legal-data-collector.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import regularESaverCaseResponse from '../../../../external-files/regular-esaver-manager/regular-esaver/regular-esaver-POST.json';
import signUpSelector from './sign-up-selector.model';
import { SignUpComponent } from './sign-up.component';
import { FrontendLoggingService} from '@portland/angular-common-s-elements';

describe('SignUpComponent', () => {
  let component: SignUpComponent;
  let fixture: ComponentFixture<SignUpComponent>;

  const customerDetailsMock = Object.assign({}, regularESaverCaseResponse.data);

  const NavigatorServiceMock = {
    navigate: jasmine.createSpy('navigate')
  };

  const CustomerServiceMock = {
    getCustomerDetails: jasmine.createSpy('getCustomerDetails').and.returnValue(of(customerDetailsMock))
  };

  const configMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.returnValue(of('Regular eSaver'))
  };

  const legalDataMock = {
    mainLegalBlock: '<h1>Main legal data block</h1>',
    contactUs: '<h2>Contact us text</h2>',
    legalDocsLinks: '<p>Legal docs links</p>',
    signature: 'Signature text'
  };

  const LegalDataCollectorServiceMock = {
    getLegalData: jasmine.createSpy('getLegalData').and.returnValue(of(legalDataMock))
  };

  let caseSubSubject: Subject<String>;

  const caseSubmissionMock = {
    handleCase: () => caseSubSubject.asObservable()
  };

  const adobeServiceMock = {
    setCheckboxError: jasmine.createSpy('setCheckboxError'),
    sendPageTrackingInformation: jasmine.createSpy('sendPageTrackingInformation'),
    setErrorInformation: jasmine.createSpy('setErrorInformation')
  };

  const frontendLoggingServiceMock = {
    sendErrorLog: () => jasmine.createSpy('sendErrorLog'),
    createNetworkErrorObj: () => jasmine.createSpy('createNetworkErrorObj')
  };

  beforeEach(() => {
    caseSubSubject = new Subject<String>();

    TestBed.configureTestingModule({
      declarations: [SignUpComponent],
      imports: [SProgressIndicatorComponentModule, SCheckboxComponentModule, FormsModule],
      providers: [
        { provide: ConfigService, useValue: configMock },
        { provide: CustomerDetailsService, useValue: CustomerServiceMock },
        { provide: NavigatorService, useValue: NavigatorServiceMock },
        { provide: LegalDataCollectorService, useValue: LegalDataCollectorServiceMock },
        { provide: CaseSubmissionService, useValue: caseSubmissionMock },
        { provide: AdobeService, useValue: adobeServiceMock },
        { provide: FrontendLoggingService, useValue: frontendLoggingServiceMock }

      ]
    })
      .compileComponents();

    fixture = TestBed.createComponent(SignUpComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    NavigatorServiceMock.navigate.calls.reset();
    adobeServiceMock.sendPageTrackingInformation.calls.reset();
    adobeServiceMock.setCheckboxError.calls.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate with current component selector after clicking on Continue Button', async(() => {
    component.termsAccepted = true;
    component.signUp();

    fixture.whenStable().then(() => {
      expect(NavigatorServiceMock.navigate).toHaveBeenCalledWith(signUpSelector);
    });
    caseSubSubject.next('fakeId');
  }));

  it('should not navigate with current component selector after clicking on Continue Button without accepting terms', () => {
    component.signUp();

    expect(NavigatorServiceMock.navigate).not.toHaveBeenCalled();
  });

  it('#toogleUpdateInstructions should swap from true to false and viceversa', () => {
    component.toogleUpdateInstructions(new Event(''));
    expect(component.visibleInstructions).toBe(true);

    component.toogleUpdateInstructions(new Event(''));
    expect(component.visibleInstructions).toBe(false);
  });

  it('should get productName onInit', () => {
    expect(component.productName).toEqual('Regular eSaver');
  });

  it('should set Sign up texts and links from LegalDataCollectorService onInit', () => {
    component.ngOnInit();

    expect(component.signUpData.mainLegalBlock).toEqual(legalDataMock.mainLegalBlock);
    expect(component.signUpData.contactUs).toEqual(legalDataMock.contactUs);
    expect(component.signUpData.legalDocsLinks).toEqual(legalDataMock.legalDocsLinks);
    expect(component.signUpData.signature).toEqual(legalDataMock.signature);
  });

  it('should call the navigation with error if CaseSubmission service fails to handleCase', async(() => {
    component.termsAccepted = true;
    const errorMessage = 'Error in /about-you';

    component.signUp();

    fixture.whenStable().then(() => {
      expect(NavigatorServiceMock.navigate).toHaveBeenCalledWith(signUpSelector, 'error');
      expect(adobeServiceMock.setErrorInformation).toHaveBeenCalledWith(errorMessage);
    });
    caseSubSubject.error('Bad Request');
  }));

  it(`should call the adobe setCheckboxError function, and we send the data to adobe
    , if user tries to continue without accepting terms`, () => {
    component.signUp();

    expect(adobeServiceMock.setCheckboxError).toHaveBeenCalled();
    expect(adobeServiceMock.sendPageTrackingInformation).toHaveBeenCalledWith('/about-you');
  });

  it('should prevent case submissions calls if it has already been made', async(() => {
    component.termsAccepted = true;
    component.signUp();

    fixture.whenStable().then(() => {
      expect(NavigatorServiceMock.navigate).toHaveBeenCalledWith(signUpSelector);

      NavigatorServiceMock.navigate.calls.reset();

      component.signUp();
      fixture.whenStable().then(() => {
        expect(NavigatorServiceMock.navigate).not.toHaveBeenCalledWith(signUpSelector);
      });
    });
    caseSubSubject.next('fakeId');
  }));
});
