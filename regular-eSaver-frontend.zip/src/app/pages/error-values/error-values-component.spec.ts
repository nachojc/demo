import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { ConfigService } from 'src/app/services/config/config.service';
import { ErrorsService } from 'src/app/services/errors/errors.service';
import { ErrorValuesComponent } from './error-values-component';
import { AdobeService } from '../../services/adobe/adobe.service';

describe('ErrorValues', () => {
  let component: ErrorValuesComponent;
  let fixture: ComponentFixture<ErrorValuesComponent>;

  const configMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.returnValue(of('Regular eSaver'))
  };

  const errorsServiceMock = {
    getErrorMsgIfCodePresent: jasmine.createSpy('getErrorMsgIfCodePresent'),
    errCodes: [3, 33, 34]
  };

  const adobeServiceMock = {
    setEligibilityErrors: jasmine.createSpy('setEligibilityErrors')
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ErrorValuesComponent],
      providers: [
          { provide: ConfigService, useValue: configMock },
          { provide: ErrorsService, useValue: errorsServiceMock },
          { provide: AdobeService, useValue: adobeServiceMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ErrorValuesComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get productName onInit', () => {
    fixture.detectChanges();
    expect(component.productName).toEqual('Regular eSaver');
  });

  it('should set #isAccountHolderError to true when holding error is present', () => {
    const holdingsMessage = "Customer already have contracts for this product specification";
    errorsServiceMock.getErrorMsgIfCodePresent.and.returnValues(holdingsMessage, null, null);
    fixture.detectChanges();

    expect(component.isAccountHolderError).toEqual(true);
    expect(component.isNotUKResidentError).toEqual(false);
    expect(component.isUnder16Error).toEqual(false);
  });

  it('should set #isUnder16Error to true on init if under16 error is present', () => {
    const under16Message = 'Customer is less than sixteen years old';

    errorsServiceMock.getErrorMsgIfCodePresent.and.returnValues(null, null, under16Message);

    fixture.detectChanges();
    expect(component.isUnder16Error).toEqual(true);
    expect(component.isAccountHolderError).toEqual(false);
    expect(component.isNotUKResidentError).toEqual(false);
  });

  it('should set #isNotUKResidentError to true on init if notUKResident error is present', () => {
    const notUKResidentMessage = 'Customer has a country of residence different than GB';

    errorsServiceMock.getErrorMsgIfCodePresent.and.returnValues(null, notUKResidentMessage, null);

    fixture.detectChanges();
    expect(component.isNotUKResidentError).toEqual(true);
    expect(component.isUnder16Error).toEqual(false);
    expect(component.isAccountHolderError).toEqual(false);
  });

  it('should set #isNotUKResidentError and #isUnder16Error to true on init event if but errors are present', () => {
    const notUKResidentMessage = 'Customer has a country of residence different than GB';
    const under16Message = 'Customer is less than sixteen years old';

    errorsServiceMock.getErrorMsgIfCodePresent.and.returnValues(null, notUKResidentMessage, under16Message);

    fixture.detectChanges();
    expect(component.isNotUKResidentError).toEqual(true);
    expect(component.isUnder16Error).toEqual(true);
    expect(component.isAccountHolderError).toEqual(false);
  });
});
