import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { zip } from 'rxjs';
import { ConfigService } from 'src/app/services/config/config.service';
import { ErrorsService } from 'src/app/services/errors/errors.service';
import selector from './error-values-selector.model';
import { AdobeService } from '../../services/adobe/adobe.service';

@Component({
  selector: selector,
  templateUrl: './error-values-component.html',
  styleUrls: ['./error-values-component.scss', '../../../../node_modules/@portland/angular-common-s-elements/assets/styles/s-link.css']
})
export class ErrorValuesComponent implements OnInit {
  productName: string;
  contactUsLink: string;

  // errors to show flags
  isAccountHolderError = false;
  isUnder16Error = false;
  isNotUKResidentError = false;

  constructor(
    private configService: ConfigService,
    private errorsService: ErrorsService,
    private adobeService: AdobeService
  ) { }

  ngOnInit() {
    zip(
      this.configService.getConfigParam('productName'),
      this.configService.getConfigParam('contact-us'),
      )
      .pipe(first())
      .subscribe(([productName, contactUsLink]) => {
        this.productName = productName;
        this.contactUsLink = contactUsLink;
      }
    );

    this.errorsService.errCodes.forEach(errCode => {
      const errMessage = this.errorsService.getErrorMsgIfCodePresent(errCode);

      if (errMessage) {
        switch (errCode) {
          case 3:
            this.isAccountHolderError = true;
            break;
          case 33:
            this.isNotUKResidentError = true;
            break;
          case 34:
            this.isUnder16Error = true;
            break;
        }
        this.adobeService.setEligibilityErrors(errMessage);
      }
    });
  }
}
