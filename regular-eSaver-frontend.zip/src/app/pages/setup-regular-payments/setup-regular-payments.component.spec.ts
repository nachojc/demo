import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SProgressIndicatorComponentModule } from '@portland/angular-common-s-elements';
import { of } from 'rxjs';
import { ConfigService } from 'src/app/services/config/config.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import { SetupRegularPaymentsComponent } from './setup-regular-payments.component';

describe('SetupRegularPaymentsComponent', () => {
  let component: SetupRegularPaymentsComponent;
  let fixture: ComponentFixture<SetupRegularPaymentsComponent>;

  const NavigatorServiceMock = {
    navigate: jasmine.createSpy('navigate')
  };

  const configMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.returnValue(of('Regular eSaver'))
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SetupRegularPaymentsComponent],
      imports: [SProgressIndicatorComponentModule],
      providers: [
        { provide: ConfigService, useValue: configMock },
        { provide: NavigatorService, useValue: NavigatorServiceMock }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SetupRegularPaymentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get productName onInit', () => {
    expect(component.productName).toEqual('Regular eSaver')
  })
});
