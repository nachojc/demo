import { Component, OnInit } from '@angular/core';
import { ProgressIndicatorItem } from '@portland/angular-common-s-elements';
import { ConfigService } from 'src/app/services/config/config.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';

@Component({
  selector: 'app-setup-regular-payments',
  templateUrl: './setup-regular-payments.component.html',
  styleUrls: ['./setup-regular-payments.component.css']
})
export class SetupRegularPaymentsComponent implements OnInit {
  productName: String;

  pages: ProgressIndicatorItem[];

  constructor(
    private appNavigation: NavigatorService,
    private configService: ConfigService
  ) { }

  ngOnInit(): void {
    this.pages =  this.appNavigation.pages;

    this.configService.getConfigParam('productName')
      .subscribe((productName: string) => this.productName = productName);
  }
}
