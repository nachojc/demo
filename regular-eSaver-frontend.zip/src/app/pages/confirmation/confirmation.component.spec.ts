import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SProgressIndicatorComponentModule } from '@portland/angular-common-s-elements';
import config from 'external-files/config/application-GET.json';
import regularESaverCase from 'external-files/regular-esaver-manager/regular-esaver/regular-esaver-POST.json';
import regularESaverSubmittedCase from 'external-files/regular-esaver-manager/regular-esaver/regular-esaver-PUT.json';
import { of, Subject } from 'rxjs';
import { StandardError } from 'src/app/models/standard-error.model';
import { CaseSubmissionService } from 'src/app/services/case-submission/case-submission.service';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import confirmationSelector from './confirmation-selector.model';
import { ConfirmationComponent } from './confirmation.component';
import { AdobeService } from 'src/app/services/adobe/adobe.service';

describe('ConfirmationComponent', () => {
  let component: ConfirmationComponent;
  let fixture: ComponentFixture<ConfirmationComponent>;
  let navigator: NavigatorService;

  const customerDetailsMock = Object.assign({}, regularESaverCase.data);
  const caseDetailsMock = Object.assign({}, regularESaverSubmittedCase);
  const referenceNumber = caseDetailsMock.data.caseDetails.referenceNumber

  let customerDetailsSubject: Subject<any>;
  let caseSubSubject: Subject<any>;

  const NavigatorServiceMock = {
    navigate: jasmine.createSpy('navigate')
  };

  const configMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.returnValue(of('Regular eSaver'))
  }

  const caseSubmissionMock = {
    handleCase: () => caseSubSubject.asObservable()
    //handleCase: () => jasmine.createSpy('handleCase').and.returnValue(caseSubSubject.asObservable())
  }

  const customerDetailsServiceMock = {
    getCustomerDetails: () => customerDetailsSubject.asObservable()
  }

  const adobeServiceMock = {
    setErrorInformation: jasmine.createSpy('setErrorInformation')
  };

  beforeEach(async(() => {
    customerDetailsSubject = new Subject<any>();
    caseSubSubject = new Subject<any>();

    TestBed.configureTestingModule({
      declarations: [ConfirmationComponent],
      imports: [SProgressIndicatorComponentModule],
      providers: [
        { provide: CaseSubmissionService, useValue: caseSubmissionMock },
        { provide: ConfigService, useValue: configMock },
        { provide: NavigatorService, useValue: NavigatorServiceMock },
        { provide: CustomerDetailsService, useValue: customerDetailsServiceMock },
        { provide: AdobeService, useValue: adobeServiceMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(ConfirmationComponent);
    component = fixture.componentInstance;
    navigator = TestBed.get(NavigatorService);
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate with current component selector after clicking on Continue Button', () => {
    component.confirmCase();

    expect(NavigatorServiceMock.navigate).toHaveBeenCalledWith(confirmationSelector);
  });

  it('should get productName and caseDetails onInit', () => {
    customerDetailsSubject.next(customerDetailsMock);
    caseSubSubject.next(referenceNumber);

    expect(component.productName).toEqual(config.productName);
    expect(component.referenceNumber).toEqual(referenceNumber);
  });

  it('should navigate with aditionalNavData if CaseSubmission service fails to handleCase', () => {
    customerDetailsSubject.next(customerDetailsMock);
    caseSubSubject.error(StandardError.build('Bad Request', 400));
    const errorMessage = 'Error in /confirmation';

    expect(navigator.navigate).toHaveBeenCalledWith(confirmationSelector, StandardError.build('Bad Request', 400));
    expect(adobeServiceMock.setErrorInformation).toHaveBeenCalledWith(errorMessage);
  });
});
