export default 'app-confirmation';
