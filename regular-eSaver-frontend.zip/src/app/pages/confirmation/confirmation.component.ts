import { Component, OnInit } from '@angular/core';
import { ProgressIndicatorItem } from '@portland/angular-common-s-elements';
import { first, flatMap } from 'rxjs/operators';
import { RegularESaverCase } from 'src/app/models/regularESaverCase.model';
import { StandardError } from 'src/app/models/standard-error.model';
import { CaseSubmissionService } from 'src/app/services/case-submission/case-submission.service';
import { ConfigService } from 'src/app/services/config/config.service';
import { CustomerDetailsService } from 'src/app/services/customer-details/customer-details.service';
import { NavigatorService } from 'src/app/services/navigator/navigator.service';
import selector from './confirmation-selector.model';
import { AdobeService } from 'src/app/services/adobe/adobe.service';

@Component({
  selector: selector,
  templateUrl: './confirmation.component.html',
  styleUrls: ['./confirmation.component.css']
})
export class ConfirmationComponent implements OnInit {
  pages: ProgressIndicatorItem[];

  productName: String;
  firstName: String;
  referenceNumber: String;

  constructor(
    private appNavigation: NavigatorService,
    private configService: ConfigService,
    private caseSubService: CaseSubmissionService,
    private customerDetailsService: CustomerDetailsService,
    private adobe: AdobeService
  ) { }

  ngOnInit(): void {
    this.pages = this.appNavigation.pages;

    this.configService.getConfigParam('productName')
      .subscribe((productName: string)  => this.productName = productName);

    this.customerDetailsService.getCustomerDetails()
      .pipe(
        first(),
        flatMap((regularESaverCase: RegularESaverCase) => {
          this.firstName = regularESaverCase.attributes.firstName;
          return this.caseSubService.handleCase(regularESaverCase);
        })
      )
      .subscribe(
        (referenceNumber: string) => this.referenceNumber = referenceNumber,
        (error: StandardError) => {
          this.adobe.setErrorInformation('Error in /confirmation');
          this.appNavigation.navigate(selector, error);
        }
      );
  }

  confirmCase() {
    this.appNavigation.navigate(selector);
  }
}
