import { Location } from '@angular/common';
import { NgModule } from '@angular/core';
import { Router, RouterModule, Routes } from '@angular/router';
// import routesNames from './app-routing-routes.model';
import { ConfirmationComponent } from './pages/confirmation/confirmation.component';
import { CongratulationsComponent } from './pages/congratulations/congratulations.component';
import { ErrorComponent } from './pages/error/error.component';
import { ProcessingComponent } from './pages/processing/processing.component';
import { SetupRegularPaymentsComponent } from './pages/setup-regular-payments/setup-regular-payments.component';
import { SignUpComponent } from './pages/sign-up/sign-up.component';
import { SwitcherComponent } from './pages/switcher/switcher.component';
import { UrlParamCollectorService } from './services/url-param-collector/url-param-collector.service';
import { ErrorValuesComponent } from './pages/error-values/error-values-component';

const routesNames = {
  switcher: '',
  signUp: 'about-you',
  errorValues: 'error-values',
  processing: 'processing',
  congratulations: 'congratulations',
  confirmation: 'confirmation',
  setupRegularPayments: 'setup-regular-payments',
  error: 'error'
};

const routes: Routes = [
  { path: routesNames.signUp, component: SignUpComponent },
  { path: routesNames.errorValues, component: ErrorValuesComponent },
  { path: routesNames.processing, component: ProcessingComponent },
  { path: routesNames.congratulations, component: CongratulationsComponent },
  { path: routesNames.confirmation, component: ConfirmationComponent },
  { path: routesNames.setupRegularPayments, component: SetupRegularPaymentsComponent },
  { path: routesNames.error, component: ErrorComponent },
  { path: routesNames.switcher, component: SwitcherComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)], // cannot get from a file
  exports: [RouterModule]
})
export class AppRoutingModule {
  constructor(
    private router: Router,
    private location: Location,
    private paramService: UrlParamCollectorService
  ) {
    this.populateUrlParams();
  }

  private populateUrlParams() {
    const url = this.router.parseUrl(this.location.path());
    this.paramService.setQueryParams(url.queryParams);
  }
}
