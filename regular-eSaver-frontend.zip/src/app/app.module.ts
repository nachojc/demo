import { HttpClientModule } from '@angular/common/http';
import { NgModule, ErrorHandler } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { SElementsLibModule, FRONTEND_LOGGING_API, FrontendLoggingService } from '@portland/angular-common-s-elements';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ConfirmationComponent } from './pages/confirmation/confirmation.component';
import { ErrorComponent } from './pages/error/error.component';
import { SetupRegularPaymentsComponent } from './pages/setup-regular-payments/setup-regular-payments.component';
import { SignUpComponent } from './pages/sign-up/sign-up.component';
import { SwitcherComponent } from './pages/switcher/switcher.component';
import { WINDOW_TOKEN } from './services/browser-manager/browser-manager.service';
import { LOCATION_TOKEN } from './services/navigator/navigator.service';
import { ProcessingComponent } from './pages/processing/processing.component';
import { CongratulationsComponent } from './pages/congratulations/congratulations.component';
import { ErrorValuesComponent } from './pages/error-values/error-values-component';

@NgModule({
  declarations: [
    AppComponent,
    SignUpComponent,
    ErrorValuesComponent,
    SetupRegularPaymentsComponent,
    ConfirmationComponent,
    SwitcherComponent,
    ErrorComponent,
    ProcessingComponent,
    CongratulationsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    SElementsLibModule,
    FormsModule
  ],
  providers: [
    { provide: LOCATION_TOKEN, useValue: window.location},
    { provide: WINDOW_TOKEN, useValue: window },
    { provide: FRONTEND_LOGGING_API, useValue: 'logging' },
    { provide: ErrorHandler, useClass: FrontendLoggingService }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
