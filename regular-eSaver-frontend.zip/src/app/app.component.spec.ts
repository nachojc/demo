import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NavigationEnd, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SHeaderComponentModule } from '@portland/angular-common-s-elements';
import { Subject } from 'rxjs';
import { AppComponent } from './app.component';
import { AdobeService } from './services/adobe/adobe.service';
import { BrowserManagerService, WINDOW_TOKEN } from './services/browser-manager/browser-manager.service';
import { CaseSubmissionService } from './services/case-submission/case-submission.service';
import { NavigatorService } from './services/navigator/navigator.service';
import { UrlParamCollectorService } from './services/url-param-collector/url-param-collector.service';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let adobe: AdobeService;
  let browserManager: BrowserManagerService;
  let navigator: NavigatorService;

  const windowMock = {
    assign: Function
  };

  const evn$ = new Subject<any>();

  const routerMock = {
    navigate: jasmine.createSpy('navigate'),
    events: evn$.asObservable()
  };

  const adobeMock = {
    sendPageTrackingInformation: jasmine.createSpy('sendPageTrackingInformation'),
    startAdobe: jasmine.createSpy('startAdobe'),
    setOlaId: jasmine.createSpy('setOlaId'),
    setErrorInformation: jasmine.createSpy('setErrorInformation')
  };

  const paramsServiceMock = {
    hasMandatoryKeys: () => true
  };

  const navigatorMock = {
    navigate: jasmine.createSpy('navigate')
  };

  const browserManagerServiceMock = {
    preventBackButton: jasmine.createSpy('preventBackButton')
  };

  const caseSubmissionServiceMock = {
    getCaseNumber: jasmine.createSpy('getCaseNumber')
  }

  const configureTests = () => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        HttpClientModule,
        SHeaderComponentModule
      ],
      declarations: [
        AppComponent
      ],
      providers: [
        { provide: Router, useValue: routerMock },
        { provide: WINDOW_TOKEN, useValue: windowMock },
        { provide: AdobeService, useValue: adobeMock },
        { provide: UrlParamCollectorService, useValue: paramsServiceMock },
        { provide: NavigatorService, useValue: navigatorMock },
        { provide: BrowserManagerService, useValue: browserManagerServiceMock },
        { provide: CaseSubmissionService, useValue: caseSubmissionServiceMock }
      ]
    }).compileComponents();

    fixture = TestBed.createComponent(AppComponent);
    adobe = TestBed.get(AdobeService);
    navigator = TestBed.get(NavigatorService);
    browserManager = TestBed.get(BrowserManagerService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  };

  afterEach(() => {
    routerMock.navigate.calls.reset();
    browserManagerServiceMock.preventBackButton.calls.reset();
    adobeMock.setOlaId.calls.reset();
    caseSubmissionServiceMock.getCaseNumber.calls.reset();
  });

  it('should create the app', () => {
    configureTests();
    expect(component).toBeTruthy();
  });

  it('should call to prevent back on init', () => {
    configureTests();
    expect(browserManager.preventBackButton).toHaveBeenCalled();
  });

  it('should call scrollTo on window and adobeTrack for page when NavigationEnd event is triggered on the router', async(() => {
    configureTests();
    fixture.whenStable().then(() => {
      const page = new NavigationEnd(1, 'my-home', 'your-home');
      evn$.next(page);

      fixture.whenStable().then(() => {
        expect(adobe.sendPageTrackingInformation).toHaveBeenCalledWith('my-home');
      });
    });
  }));

  it('should always scroll to the top after navigating to a new page', async(() => {
    const windowPosition = spyOn(<any>window, 'scrollTo');
    configureTests();

    fixture.whenStable().then(() => {
      const page = new NavigationEnd(1, 'df', 'dfd');
      evn$.next(page);

      fixture.whenStable().then(() => {
        expect(windowPosition).toHaveBeenCalledWith(0, 0);
      });
    });
  }));

  it('should call navigator service with error if not mandatory keys present', () => {
    const errorMessage = 'No mandatory keys present';
    spyOn(paramsServiceMock, 'hasMandatoryKeys').and.returnValue(false);

    configureTests();
    fixture.detectChanges();

    expect(navigator.navigate).toHaveBeenCalledWith('app-root');
    expect(adobeMock.setErrorInformation).toHaveBeenCalledWith(errorMessage);
  });
  
  it('should not call to olaId when there is no reference number', () => {
    configureTests();
    const referenceNumber = undefined;
    caseSubmissionServiceMock.getCaseNumber.and.returnValue(referenceNumber);
    const page = new NavigationEnd(1, 'from', 'url');
    evn$.next(page);

    expect(adobe.setOlaId).not.toHaveBeenCalled();
  });

  it('should call to olaId when there is reference number', () => {
    configureTests();
    const referenceNumber = 'ola2';
    caseSubmissionServiceMock.getCaseNumber.and.returnValue(referenceNumber);
    const page = new NavigationEnd(1, 'from', 'to');
    evn$.next(page);

    expect(adobe.setOlaId).toHaveBeenCalledWith(referenceNumber);
  });
});
