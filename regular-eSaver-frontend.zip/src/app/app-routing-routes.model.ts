export default {
  switcher: '',
  signUp: 'about-you',
  errorValues: 'error-values',
  processing: 'processing',
  congratulations: 'congratulations',
  confirmation: 'confirmation',
  setupRegularPayments: 'setup-regular-payments',
  error: 'error'
};
