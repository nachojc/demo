import { PlatformLocation } from '@angular/common';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable } from 'rxjs';
import { ConfigService } from './config.service';
import { HttpHeaders } from '@angular/common/http';

describe('ConfigService', () => {
  let service: ConfigService;
  let httpTestingController: HttpTestingController;

  const platFormLocationMock = {
    getBaseHrefFromDOM: () => 'localUrl/'
  };

  const mockConfigData = {
    sports: 'football',
    TV: 'BBC',
    attempts: 0
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        ConfigService,
        { provide: PlatformLocation, useValue: platFormLocationMock }
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(ConfigService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have a getConfigParam that returns an observable', () => {
    const obs = service.getConfigParam('something');
    expect(obs).toBeTruthy();
    expect(obs).toEqual(jasmine.any(Observable));
    httpTestingController.expectOne('localUrl/config/application'); // although it will not be excuted
  });

  it('should return a string when calling getConfigParam with a known value', () => {
    let football;
    service.getConfigParam('sports').subscribe(
      sports => football = sports
    );

    const req = httpTestingController.expectOne('localUrl/config/application');

    req.flush(mockConfigData);

    expect(football).toEqual('football');
  });

  it('should assign the right Date to current time per get response header value', () => {
    let date;
    service.getConfigParam('currentTime').subscribe(
      fetchdate => date = fetchdate
    );

    const req = httpTestingController.expectOne('localUrl/config/application');

    req.flush(mockConfigData, { headers: new HttpHeaders({'Date': '2019-12-17'})});

    expect(date).toEqual(new Date('2019-12-17'));
  });

  it('should return an error when calling getConfigParam with a unknown value', () => {
    let error;
    service.getConfigParam('potatoes').subscribe(
      () => {},
      err => error = err
    );

    const req = httpTestingController.expectOne('localUrl/config/application');
    req.flush(mockConfigData);

    expect(error.message).toEqual('unknown param');
  });

  it('should return a zero if that is the value of the param, even if it is a falsy value', () => {
    let numberOfAttempts;

    service.getConfigParam('attempts').subscribe(
      attempts => numberOfAttempts = attempts
    );

    const req = httpTestingController.expectOne('localUrl/config/application');

    req.flush(mockConfigData);

    expect(numberOfAttempts).toEqual(0);
  });

  it('should cache the config', () => {
    service.getConfigParam('sports').subscribe();

    const req = httpTestingController.expectOne('localUrl/config/application');
    expect(req.request.method).toEqual('GET');
    req.flush(mockConfigData);

    service.getConfigParam('sports').subscribe();

    httpTestingController.expectNone('localUrl/config/application');
  });
});
