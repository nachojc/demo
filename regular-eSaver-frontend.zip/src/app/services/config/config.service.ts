import { PlatformLocation } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { first, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {
  private config: any;
  private ongoingRequest = false;
  private configSubject: Subject<any> = new Subject();

  constructor(
    private http: HttpClient,
    private platformLocation: PlatformLocation
  ) { }

  getConfigParam(parameter: string): Observable<string|Date|number|any> {
    return this.fetchConfig()
      .pipe(
        first(),
        map(config => {
          const param = config[parameter];
          if (param !== undefined) {
            return param;
          } else {
            throw new Error('unknown param');
          }
        })
      );
  }

  private fetchConfig(): Observable<any> {
    if (!this.ongoingRequest) {
      if (this.config) {
        setTimeout(() => {
          this.configSubject.next(this.config);
        }, 0); // This allows return to be called first then sends value to the stream
      } else {
        this.ongoingRequest = true;
        this.http.get<any>(this.platformLocation.getBaseHrefFromDOM() + 'config/application', { observe: 'response' })
          .pipe(first())
          .subscribe(
            res => {
              this.ongoingRequest = false;
              this.config = res.body;
              this.config.currentTime = new Date(res.headers.get('Date'));
              this.configSubject.next(this.config);
            }
          );
      }
    }
    return this.configSubject.asObservable();
  }
}
