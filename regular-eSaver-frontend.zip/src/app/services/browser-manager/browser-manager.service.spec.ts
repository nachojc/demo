import { TestBed } from '@angular/core/testing';
import { BrowserManagerService, WINDOW_TOKEN } from './browser-manager.service';

describe('BrowserManagerService', () => {
  let service: BrowserManagerService;
  let myWindow;

  const windowMock = {
    onpopstate: () => { }
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        BrowserManagerService,
        { provide: WINDOW_TOKEN, useValue: windowMock }
      ]
    });
    service = TestBed.get(BrowserManagerService);
    myWindow = TestBed.get(WINDOW_TOKEN)
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('#preventBackButton should set the right history state', () => {
    service.preventBackButton();
    expect(history.state).toEqual(null);
  });

  it('#preventBackButton should call history.go() method when browser back is clicked', () => {
    const spy = spyOn(history, 'go');
  
    service.preventBackButton();
    expect(myWindow.onpopstate()).toEqual(undefined);
  
    expect(spy).toHaveBeenCalled();
  });
});
