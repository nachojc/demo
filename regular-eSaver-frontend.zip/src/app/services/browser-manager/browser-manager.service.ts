import { Injectable, Inject, InjectionToken } from '@angular/core';

export const WINDOW_TOKEN = new InjectionToken<Window>('Window object');

@Injectable({
  providedIn: 'root'
})
export class BrowserManagerService {

  constructor(
    @Inject(WINDOW_TOKEN) private window: Window,
  ) {}

  preventBackButton() {
    history.pushState(null, null, location.href);
    this.window.onpopstate = function() {
      history.go(1);
    };
  }
}
