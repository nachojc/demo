import { Injectable } from '@angular/core';
import { RegularESaverCaseErrorResource } from '../../models/regularESaverCase.model';

@Injectable({
  providedIn: 'root'
})
export class AdobeService {

  private applicationSteps = {
    '/switcher': 'processing',
    '/about-you': 'step1/about-you',
    '/confirmation': 'step2/confirmation',
    '/congratulations': 'step2/confirmation/account-number',
    '/setup-regular-payments': 'step3/setup-regular-payments',
    '/error-values': 'eligibility/validations-error',
    '/error': 'error'
  };

  constructor() {
    (<any>window).adobeContextData = {
      channel: 'ola/ptld-sss',
      olaId: '',
      errorCode: '',
      errorMsg: {},
      pageIdentifier: '',
      productIdentifier: '',
      productDetails: '',
      subSection1: 'personal',
      subSection2: 'isas',
      title: '',
      branchNumber: '3425'
    };
  }

  startAdobe(productIdentifier: string) {
    (<any>window).adobeContextData.productIdentifier = productIdentifier;
    (<any>window).adobeContextData.productDetails = 'OJBAN.' + productIdentifier;
  }

  sendPageTrackingInformation(pathIdentifier: string) {
    if ((<any>window)._satellite && !pathIdentifier.startsWith('/?')) {
      this.checkIfErrorPage(pathIdentifier);

      (<any>window).adobeContextData.pageIdentifier = this.applicationSteps[pathIdentifier];
      (<any>window)._satellite.track('Popup_PageView');

      this.resetErrorMsg();
    }
  }

  setOlaId(olaId: String) {
    (<any>window).adobeContextData.olaId = olaId;
  }

  checkIfErrorPage(pathIdentifier: string) {
    if (pathIdentifier === '/error') {
      (<any>window).adobeContextData.errorCode = '500';
    }
  }

  setCheckboxError() {
    (<any>window).adobeContextData.errorMsg['checkbox'] = 'required';
  }

  setEligibilityErrors(errorDetail: string) {
    if (!(<any>window).adobeContextData.errorMsg.detail) {
      (<any>window).adobeContextData.errorMsg.detail = [];
    }
    (<any>window).adobeContextData.errorCode = 500;
    (<any>window).adobeContextData.errorMsg.detail.push(errorDetail);
  }

  private resetErrorMsg() {
    (<any>window).adobeContextData.errorMsg = {};
  }

  setErrorInformation(errorMessage) {
    if (!(<any>window).adobeContextData.errorMsg.detail) {
      (<any>window).adobeContextData.errorMsg.detail = errorMessage;
    }
  }
}
