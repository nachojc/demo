import { TestBed } from '@angular/core/testing';
import { AdobeService } from './adobe.service';

describe('AdobeService', () => {
  let service;

  const _satelliteMock = {
    track() { }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AdobeService]
    });

    service = TestBed.get(AdobeService);
    (<any>window)._satellite = _satelliteMock;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should add the property adobeContextData to the window object with the following properties', () => {
    const adobeData = {
        channel: 'ola/ptld-sss',
        olaId: '',
        errorCode: '',
        errorMsg: { },
        pageIdentifier: '',
        productIdentifier: '',
        productDetails: '',
        subSection1: 'personal',
        subSection2: 'isas',
        title: '',
        branchNumber: '3425'
    };

    expect((<any>window).adobeContextData).toEqual(adobeData);
  });

  it('should change different adobeContextData properties based on the productIdentifier onInit', () => {
    service.startAdobe('secregularesaver');

    expect((<any>window).adobeContextData.pageIdentifier).toEqual('');
    expect((<any>window).adobeContextData.productIdentifier).toEqual('secregularesaver');
    expect((<any>window).adobeContextData.productDetails).toEqual('OJBAN.secregularesaver');
  });

  it('should call _satellite.track() when setPageIdentifier function is called', () => {
    const adobeLibSpy = spyOn((<any>window)._satellite, 'track');

    service.sendPageTrackingInformation('/confirmation');

    expect(adobeLibSpy).toHaveBeenCalledWith('Popup_PageView');
  });

  it('should not track page information if the library is not loaded as the _satellite property is undefined', () => {
    delete (<any>window)._satellite;

    service.sendPageTrackingInformation('/blablabla');

    expect((<any>window)._satellite).toBeUndefined();
  });

  it('should populate pageIdentifier with the corresponding value when we navigate to another page' , () => {
    service.sendPageTrackingInformation('/about-you');
    expect((<any>window).adobeContextData.pageIdentifier).toEqual('step1/about-you');

    service.sendPageTrackingInformation('/confirmation');
    expect((<any>window).adobeContextData.pageIdentifier).toEqual('step2/confirmation');

    service.sendPageTrackingInformation('/congratulations');
    expect((<any>window).adobeContextData.pageIdentifier).toEqual('step2/confirmation/account-number');

    service.sendPageTrackingInformation('/setup-regular-payments');
    expect((<any>window).adobeContextData.pageIdentifier).toEqual('step3/setup-regular-payments');

    service.sendPageTrackingInformation('/error-values');
    expect((<any>window).adobeContextData.pageIdentifier).toEqual('eligibility/validations-error')

    service.sendPageTrackingInformation('/error');
    expect((<any>window).adobeContextData.pageIdentifier).toEqual('error');
  });

  it('#setFormError should set errorMsg in adobe object', () => {
    service.setCheckboxError();

    expect((<any>window).adobeContextData.errorMsg).toEqual({'checkbox': 'required'});
  });

  it(`#checkIfErrorPage should populate errorCode property with 500 error of adobe 
      object if we navigate to error page and return true`, () => {
    service.checkIfErrorPage('/error');

    expect((<any>window).adobeContextData.errorCode).toEqual('500');
  });

  it('#checkIfErrorPage should not populate errorCode of adobe object if we do not navigate to error page', () => {
    service.checkIfErrorPage('/about-you');

    expect((<any>window).adobeContextData.errorCode).toEqual('');
  });

  it('should reset errorMsg property of object once we send the information', () => {
    service.setCheckboxError();
    service.sendPageTrackingInformation('/about-you');

    expect((<any>window).adobeContextData.errorMsg).toEqual({});
  });

  it('#setOlaId should have populated the Adobe olaId property', () => {
    service.setOlaId('testOlaId');

    expect((<any>window).adobeContextData.olaId).toEqual('testOlaId');
  });

  it('should not track adobe if pathIdentifier starts with /?', () => {
    service.sendPageTrackingInformation('/?whatever');
    expect((<any>window).adobeContextData.pageIdentifier).toEqual('');
  });

  it('#setEligibilityErrors should set the error status and detail to the adobeContextData', () => {
    const errorMessage = 'Customer already have contracts for this product specification';

    service.setEligibilityErrors(errorMessage);
    expect((<any>window).adobeContextData.errorCode).toEqual(500);
    expect((<any>window).adobeContextData.errorMsg).toEqual({
      detail: ['Customer already have contracts for this product specification']
    });
  });

  it('#setEligibilityErrors should set the error status and detail to the adobeContextData if more than one error comes', () => {
    const errorMessage = 'Customer already have contracts for this product specification';
    const errorMessage2 = 'Customer is less than sixteen years old';

    service.setEligibilityErrors(errorMessage);
    service.setEligibilityErrors(errorMessage2);

    expect((<any>window).adobeContextData.errorCode).toEqual(500);
    expect((<any>window).adobeContextData.errorMsg).toEqual({
      detail: ['Customer already have contracts for this product specification', 'Customer is less than sixteen years old']
    });
  });

  it('#setErrorInformation should populate the erroMsg property of adobeContextData with right info', () =>{
    const errorMessage = 'Error message';

    service.setErrorInformation(errorMessage);

    expect((<any>window).adobeContextData.errorMsg.detail).toEqual(errorMessage);
  });
});
