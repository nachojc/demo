import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, zip } from 'rxjs';
import { flatMap, map } from 'rxjs/operators';
import { RegularESaverCase } from '../../models/regularESaverCase.model';
import { ConfigService } from '../config/config.service';
import { SecurityService } from '../security/security.service';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';

@Injectable({
  providedIn: 'root'
})
export class CaseSubmissionService {
  private caseDetails: string;

  constructor(
    private http: HttpClient,
    private configService: ConfigService,
    private securityService: SecurityService,
    private urlParams: UrlParamCollectorService
  ) { }

  handleCase(regularESaverCase: RegularESaverCase): Observable<String> {
    if (this.caseDetails) {
      return of(this.caseDetails);
    }

    return zip(
      this.securityService.getSecurityToken(),
      this.configService.getConfigParam('client-id'),
      this.configService.getConfigParam('esaverAPIUrl')
    ).pipe(
      map(([token, clientId, url]) => ({
        options: {
          headers: new HttpHeaders(<any>{
            'Authorization': `Bearer ${token}`,
            'X-IBM-Client-Id': clientId
          })
        },
        url
      })),
      flatMap(requestData => this.http.put(
        // tslint:disable-next-line:max-line-length
        `${requestData.url}/${regularESaverCase.id}?psb=${this.urlParams.getQueryParam('psb')}${this.urlParams.checkAndAddParamIfExists('ma')}`,
        regularESaverCase,
        requestData.options
      )),
      map((response: any) => this.caseDetails = response.data.caseDetails.referenceNumber)
    );
  }

  getCaseNumber(): string | undefined {
    return this.caseDetails;
  }
}
