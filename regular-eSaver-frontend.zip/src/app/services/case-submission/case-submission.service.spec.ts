import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable, of } from 'rxjs';
import { StandardError } from 'src/app/models/standard-error.model';
import regularESaverCase from '../../../../external-files/regular-esaver-manager/regular-esaver/regular-esaver-POST.json';
import regularESaverCaseSubmitted from '../../../../external-files/regular-esaver-manager/regular-esaver/regular-esaver-PUT.json';
import { ConfigService } from '../config/config.service';
import { SecurityService } from '../security/security.service';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';
import { CaseSubmissionService } from './case-submission.service';
import { FrontendLoggingService } from '@portland/angular-common-s-elements';

describe('CaseSubmissionService', () => {
  let service: CaseSubmissionService;
  let httpTestingController: HttpTestingController;

  const regularESaverCaseToSent = Object.assign({}, regularESaverCase.data);
  regularESaverCaseToSent.attributes.termsAndConditions = true;

  const esaverAPIUrl = 'http://example.com/regular-esaver-manager/regular-esaver';

  const configServiceMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.callFake(param => {
      return {
        'client-id': of('ClientId'),
        'esaverAPIUrl': of(esaverAPIUrl)
      }[param];
    })
  };

  const securityServiceMock = {
    getSecurityToken: jasmine.createSpy('getSecurityToken').and.returnValue(of('AccessToken'))
  };

  let mockParams;
  const urlParamCollectorServiceMock = {
    getQueryParam: jasmine.createSpy('getQueryParam').and.callFake(param => {
      return mockParams[param];
    }),
    checkAndAddParamIfExists: jasmine.createSpy('checkAndAddParamIfExists').and.callFake((param) => {
      return `&${param}=true`;
    })
  };

  const referenceNumber = regularESaverCaseSubmitted.data.caseDetails.referenceNumber;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        CaseSubmissionService,
        { provide: ConfigService, useValue: configServiceMock },
        { provide: SecurityService, useValue: securityServiceMock },
        { provide: UrlParamCollectorService, useValue: urlParamCollectorServiceMock },
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    mockParams = { 'ma': 'true', 'psb': '123' };
    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(CaseSubmissionService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have a handleCase that returns an observable', () => {
    const obs = service.handleCase(regularESaverCaseToSent);
    expect(obs).toBeTruthy();
    expect(obs).toEqual(jasmine.any(Observable));
  });

  it('should handleCase should send case with regularESaverCaseId as body', () => {
    let olaNumber;

    service.handleCase(regularESaverCaseToSent).subscribe(
      caseId => olaNumber = caseId
    );

    const req = httpTestingController.expectOne(
      `${esaverAPIUrl}/${regularESaverCaseToSent.id}?psb=123&ma=true`
    );
    req.flush(regularESaverCaseSubmitted);

    expect(olaNumber).toEqual(referenceNumber);

    expect(req.request.headers.get('Authorization')).toEqual('Bearer AccessToken');
    expect(req.request.headers.get('X-IBM-Client-Id')).toEqual('ClientId');
  });

  it('#handleCase should return the data if a req has been made, so not second req', () => {
    let olaNumber;
    service.handleCase(regularESaverCaseToSent).subscribe(
      caseId => olaNumber = caseId
    );

    const req = httpTestingController.expectOne(
      `${esaverAPIUrl}/${regularESaverCaseToSent.id}?psb=123&ma=true`
    );
    req.flush(regularESaverCaseSubmitted);

    expect(olaNumber).toEqual(referenceNumber);

    service.handleCase(regularESaverCaseToSent);

    httpTestingController.expectNone(
      `${esaverAPIUrl}/${regularESaverCaseToSent.id}?psb=123&ma=true`
    );
  });

  it('has a getCaseNumber method that returns what caseDetails has', () => {
    expect(service.getCaseNumber).toBeDefined();
    expect(service.getCaseNumber()).toBeUndefined();

    service.handleCase(regularESaverCaseToSent)
      .subscribe(refNumber =>
        expect(service.getCaseNumber()).toBe(refNumber)
      );

    const req = httpTestingController.expectOne(
      `${esaverAPIUrl}/${regularESaverCaseToSent.id}?psb=123&ma=true`
    );
    req.flush(regularESaverCaseSubmitted);
  });
});
