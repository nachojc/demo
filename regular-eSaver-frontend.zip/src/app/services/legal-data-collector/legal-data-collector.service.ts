import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PlatformLocation } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class LegalDataCollectorService {

  constructor(private http: HttpClient, private platformLocation: PlatformLocation) { }

  getLegalData(): Observable<any> {
    return this.http.get(this.platformLocation.getBaseHrefFromDOM() + 'config/terms');
  }
}
