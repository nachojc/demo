import { TestBed } from '@angular/core/testing';
import { LegalDataCollectorService } from './legal-data-collector.service';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import { PlatformLocation } from '@angular/common';

describe('LegalDataCollectorService', () => {
  let httpTestingController: HttpTestingController;
  let service: LegalDataCollectorService;

  const platformLocationMock = {
    getBaseHrefFromDOM: () => 'http://localhost:4200/'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LegalDataCollectorService,
        { provide: PlatformLocation, useValue: platformLocationMock }
      ],
      imports: [HttpClientTestingModule]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(LegalDataCollectorService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('returned Observable should match the right data', () => {
    const mockLegalData = {
      legalBody: 'Dummy data',
      legalSignature: 'Dummy signature'
    };

    service.getLegalData()
      .subscribe(response => {
        expect(response.legalBody).toEqual('Dummy data');
        expect(response.legalSignature).toEqual('Dummy signature');
      });

    const req = httpTestingController.expectOne(
      'http://localhost:4200/config/terms'
    );

    expect(req.request.method).toEqual('GET');

    req.flush(mockLegalData);
  });
});
