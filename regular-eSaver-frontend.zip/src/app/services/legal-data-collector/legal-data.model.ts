export interface LegalData {
    mainLegalBlock: string;
    contactUs: string;
    legalDocsLinks: string;
    signature: string;
}
