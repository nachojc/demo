import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UrlParamCollectorService {
  private params: {};

  private mandatoryUrlParams = ['psb', 'refId', 'ex', 'prod', '_flowId'];

  constructor() { }

  getQueryParam(param: string): string {
    return this.params[param] || '';
  }

  setQueryParams(params: Object) {
    this.params = params;
  }

  hasMandatoryKeys() {
    return this.mandatoryUrlParams.every(mandatoryParam => this.params[mandatoryParam] !== undefined);
  }

  isValidDate(currentDate): boolean {
    return this.getExpirationDate() > currentDate;
  }

  getExpirationDate() {
    const exArr = this.params['ex'].match(/.{2}/g);
    exArr[2] = '20' + exArr[2];
    exArr[1] = parseInt(exArr[1], null) - 1;

    const myExDate = [];

    for (let i = 2; i >= 0; i--) {
      myExDate.push(exArr[i]);
    }

    return new Date(myExDate[0], myExDate[1], myExDate[2]);
  }

  getParamsForOldJourney() {
    let appParams = '?';

    for (const key in this.params) {
      if (key === 'psb') {
        appParams += `ps=${this.params[key]}&`;
      } else {
        appParams += `${key}=${this.params[key]}&`;
      }
    }

    return appParams.slice(0, - 1);
  }

  checkAndAddParamIfExists(paramName: string) {
    if (this.getQueryParam(paramName)) {
      return `&${paramName}=${this.getQueryParam(paramName)}`;
    } else {
      if (paramName === 'ma') {
        return `&${paramName}=false`;
      }
      return '';
    }
  }
}
