import { TestBed } from '@angular/core/testing';
import { UrlParamCollectorService } from './url-param-collector.service';

describe('UrlParamCollectorService', () => {
  let service: UrlParamCollectorService;
  let params;

  beforeEach(() => {
    params = {
      'psb': '3017680000014',
      'refId': '123RegeSavercompOLB',
      'ex': '141299',
      'prod': 'regular',
      '_flowId': 'esaver',
      'ma': 'true' };

    TestBed.configureTestingModule({
      providers: [UrlParamCollectorService]
    });

    service = TestBed.get(UrlParamCollectorService);
    service.setQueryParams(params);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set up params data and return requested param', () => {
    expect(service.getQueryParam('psb')).toEqual(params.psb);
    expect(service.getQueryParam('refId')).toEqual(params.refId);
    expect(service.getQueryParam('ex')).toEqual(params.ex);
    expect(service.getQueryParam('ma')).toEqual(params.ma);
    expect(service.getQueryParam('myHouse')).toEqual('');
  });

  it('#hasMandatoryKeys should return true if we have the right 5 params we need', () => {
    expect(service.hasMandatoryKeys()).toEqual(true);
  });

  it('#hasMandatoryKeys should return false if we do not have the right 5 params we need', () => {
    delete params['psb'];
    expect(service.hasMandatoryKeys()).toEqual(false);
  });

  it('#getExpirationDate should return the right format for getExpirationDate', () => {
    const dateObjectType = service.getExpirationDate();

    expect(dateObjectType).toEqual(jasmine.any(Date));
  });

  it('#isValidDate returns true if expiration date is higher than currentDate', () => {
    expect(service.isValidDate(new Date())).toEqual(true);
  });

  it('#isValidDate returns true if expiration date is higher than currentDate', () => {
    params.ex = '141217';
    expect(service.isValidDate(new Date())).toEqual(false);
  });

  it('#getParamsForOldJourney should set the right params for the old journey', () => {
    expect(service.getParamsForOldJourney()).toEqual(
      '?ps=3017680000014&refId=123RegeSavercompOLB&ex=141299&prod=regular&_flowId=esaver&ma=true'
    );
  });

  it('#getExpirationDate should return the right format for getExpirationDate', () => {
    const dateObjectType = Object.prototype.toString.call(service.getExpirationDate());
    expect(dateObjectType).toBe('[object Date]');
  });

  it('#isValidDate returns true if expiration date is higher than currentDate', () => {
    expect(service.isValidDate(new Date())).toEqual(true);
  });

  it('#isValidDate returns true if expiration date is higher than currentDate', () => {
    params.ex = '141217';
    expect(service.isValidDate(new Date())).toEqual(false);
  });

  it('#checkAndAddIfParamExists should return the correct value if param does exist', () => {
    expect(service.checkAndAddParamIfExists('psb')).toBe('&psb=3017680000014');
  });

  it('#checkAndAddIfParamExists should return the empty if param does not exist', () => {
    expect(service.checkAndAddParamIfExists('abc')).toBe('');
  });

  it('#checkAndAddIfParamExists should return ma=false if ma param does not exist', () => {
    delete params.ma;
    expect(service.checkAndAddParamIfExists('ma')).toBe('&ma=false');
  });

  it('#checkAndAddIfParamExists should return ma=true if ma param exists', () => {
    expect(service.checkAndAddParamIfExists('ma')).toBe('&ma=true');
  });
});
