import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { StandardError } from 'src/app/models/standard-error.model';
import { ConfigService } from '../config/config.service';
import { SecurityService } from './security.service';

describe('SecurityService', () => {
  let service: SecurityService;
  let httpTestingController: HttpTestingController;

  const mockToken = 'my-mock-token';

  const configServiceMock = {
    getConfigParam: (param) => {
      return {
        'tokenAPIUrl': of('http://localhost:4200/security/oauth2/token')
      }[param];
    }
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        SecurityService,
        { provide: ConfigService, useValue: configServiceMock }
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(SecurityService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call the security service API and return a valid token', () => {
    service.getSecurityToken().subscribe(token => {
      expect(token).toEqual(mockToken);
    });

    const req = httpTestingController.expectOne(configServiceMock.getConfigParam('tokenAPIUrl'));
    expect(req.request.method).toEqual('GET');

    req.flush(mockToken);
  });

  it('should not call the security service API when we have a token', () => {
    service.getSecurityToken().subscribe(token => {
      expect(token).toEqual(mockToken);
    });

    const req = httpTestingController.expectOne(configServiceMock.getConfigParam('tokenAPIUrl'));
    req.flush(mockToken);

    service.getSecurityToken().subscribe(token => {
      expect(token).toEqual(mockToken);
    });

    httpTestingController.expectNone(configServiceMock.getConfigParam('tokenAPIUrl'));
  });

  it('should call the security service API and return one error if err req', () => {
    let error;
    service.getSecurityToken().subscribe(
      undefined,
      (err) => error = err
    );

    const req = httpTestingController.expectOne(configServiceMock.getConfigParam('tokenAPIUrl'));
    req.error(new ErrorEvent(''), { status: 400 });

    const expectedError = StandardError.build(`Http failure response for http://localhost:4200/security/oauth2/token: 400 `, 400);
    expect(error.message).toEqual(expectedError.message);
    expect(error.statusCode).toEqual(expectedError.statusCode);
  });
});
