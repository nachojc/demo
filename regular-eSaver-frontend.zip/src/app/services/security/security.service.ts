import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, flatMap, map } from 'rxjs/operators';
import { StandardError } from 'src/app/models/standard-error.model';
import { ConfigService } from '../config/config.service';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {
  private token: string;

  constructor(private http: HttpClient, private configService: ConfigService) { }

  getSecurityToken(): Observable<String> {
    if (this.token) {
      return of(this.token);
    }

    return this.configService.getConfigParam('tokenAPIUrl')
      .pipe(
        flatMap((url: string) => this.http.get(url, { responseType: 'text', withCredentials: true })),
        map((response: string) => this.token = response),
        catchError(error => { throw StandardError.build(error.message || 'cannot get access token', error.status); })
      );
  }
}
