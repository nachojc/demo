import { Inject, Injectable, InjectionToken } from '@angular/core';
import { Router } from '@angular/router';
import { ProgressIndicatorItem } from '@portland/angular-common-s-elements';
import { first } from 'rxjs/operators';
import routes from '../../app-routing-routes.model';
import confirmationSelector from '../../pages/confirmation/confirmation-selector.model';
import congratulationsSelector from '../../pages/congratulations/congratulations-selector.model';
import signUpSelector from '../../pages/sign-up/sign-up-selector.model';
import switcherSelector from '../../pages/switcher/switcher-selector.model';
import processingSelector from '../../pages/processing/processing-selector.model';
import { ConfigService } from '../config/config.service';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';

export const LOCATION_TOKEN = new InjectionToken<Location>('Window location object');

@Injectable({
  providedIn: 'root'
})
export class NavigatorService {
  pages: ProgressIndicatorItem[] = [
    { label: 'Agree and Sign up', status: 'selected' },
    { label: 'Setup regular payments', status: null }
  ];

  constructor(
    private router: Router,
    @Inject(LOCATION_TOKEN) private location: Location,
    private config: ConfigService,
    private paramsService: UrlParamCollectorService
  ) { }

  navigate(target: String, additionalNavData?: any) {
    switch (target) {
      case switcherSelector:
        if (additionalNavData === 'app-error-values') {
          this.router.navigate([routes.errorValues]);
        } else if (additionalNavData === 'ok') {
          this.router.navigate([routes.signUp]);
        } else if (additionalNavData === 'invalidDate') {
          this.config.getConfigParam('santander-savings')
            .pipe(first())
            .subscribe((savingsUrl: string) => this.location.href = savingsUrl);
        } else {
          this.config.getConfigParam('old-journey')
            .pipe(first()).subscribe((OJUrl: string) => {
              this.location.href = OJUrl + this.paramsService.getParamsForOldJourney();
            });
        }
        break;
      case signUpSelector:
        if (additionalNavData === 'error') {
          this.router.navigate([routes.error]);
        } else {
          this.router.navigate([routes.processing]);
        }
        break;
      case processingSelector:
        if (additionalNavData === 'accountUndefined' || additionalNavData === 'bridgeOffline') {
          this.router.navigate([routes.confirmation]);
        } else {
          this.router.navigate([routes.congratulations]);
        }
        break;
      case confirmationSelector:
        if (additionalNavData === undefined) {
          this.pages[0].status = 'ok';
          this.pages[1].status = 'selected';
          this.router.navigate([routes.setupRegularPayments]);
        } else {
          this.router.navigate([routes.error]);
        }
        break;
      case congratulationsSelector:
        this.pages[0].status = 'ok';
        this.pages[1].status = 'selected';
        this.router.navigate([routes.setupRegularPayments]);
        break;
      case 'app-root':
        this.router.navigate([routes.error]);
        break;
    }
  }
}
