import { async, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { SProgressIndicatorComponentModule } from '@portland/angular-common-s-elements';
import { of } from 'rxjs';
import routes from '../../app-routing-routes.model';
import confirmationSelector from '../../pages/confirmation/confirmation-selector.model';
import processingSelector from '../../pages/processing/processing-selector.model';
import congratulationsSelector from '../../pages/congratulations/congratulations-selector.model';
import signUpSelector from '../../pages/sign-up/sign-up-selector.model';
import switcherSelector from '../../pages/switcher/switcher-selector.model';
import { ConfigService } from '../config/config.service';
import { LOCATION_TOKEN, NavigatorService } from './navigator.service';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';

describe('NavigatorService', () => {
  let service: NavigatorService;
  let config: ConfigService;
  let location;

  const routerMock = {
    navigate: jasmine.createSpy('navigate')
  };

  const locationMock = {
    href: undefined
  };

  const configServiceMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.callFake((field) => {
      return {
        'old-journey': of('http://old.com'),
        'santander-savings': of('http://savings.com')
      }[field];
    })
  };

  const paramsServiceMock = {
    getParamsForOldJourney: jasmine.createSpy('getParamsForOldJourney').and.returnValue('?fakeParams')
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        NavigatorService,
        { provide: Router, useValue: routerMock },
        { provide: LOCATION_TOKEN, useValue: locationMock },
        { provide: ConfigService, useValue: configServiceMock },
        { provide: UrlParamCollectorService, useValue: paramsServiceMock }
      ],
      imports: [ SProgressIndicatorComponentModule ]
    });
    service = TestBed.get(NavigatorService);
    config = TestBed.get(ConfigService);
    location = TestBed.get(LOCATION_TOKEN);
  });

  afterEach(() => {
    routerMock.navigate.calls.reset();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('navigates to "error" from AppComponent', async(() => {
    service.navigate('app-root');
    expect(routerMock.navigate).toHaveBeenCalledWith(['error']);
  }));

  it('navigates to "santander savings" if additional data comes with invalidDate', () => {
    expect(location.href).toEqual(undefined);
    service.navigate(switcherSelector, 'invalidDate');
    expect(config.getConfigParam).toHaveBeenCalledWith('santander-savings');
    expect(location.href).toEqual('http://savings.com');
  });

  it('navigates to "processing" from SignUpComponent', async(() => {
    service.navigate(signUpSelector);
    expect(routerMock.navigate).toHaveBeenCalledWith(['processing']);
  }));

  it('navigates to "error" from SignUpComponent if additional data comes with error', async(() => {
    service.navigate(signUpSelector, 'error');
    expect(routerMock.navigate).toHaveBeenCalledWith(['error']);
  }));

  it('navigates to "confirmation" from ProcessingComponent if additional data comes with accountUndefined', async(() => {
    service.navigate(processingSelector, 'accountUndefined');
    expect(routerMock.navigate).toHaveBeenCalledWith(['confirmation']);
  }));

  it('navigates to "confirmation" from ProcessingComponent if additional data comes with bridgeOffline', async(() => {
    service.navigate(processingSelector, 'bridgeOffline');
    expect(routerMock.navigate).toHaveBeenCalledWith(['confirmation']);
  }));

  it('navigates to "congratulations" from ProcessingComponent', async(() => {
    service.navigate(processingSelector);
    expect(routerMock.navigate).toHaveBeenCalledWith(['congratulations']);
  }));

  it('navigates to "setup-regular-payments" from CongratulationsComponent', async(() => {
    service.navigate(congratulationsSelector);
    expect(routerMock.navigate).toHaveBeenCalledWith([routes.setupRegularPayments]);
  }));

  it('navigates to "setup-regular-payments" from ConfirmationComponent', async(() => {
    service.navigate(confirmationSelector);
    expect(service.pages[0].status).toBe('ok');
    expect(service.pages[1].status).toBe('selected');
    expect(routerMock.navigate).toHaveBeenCalledWith([routes.setupRegularPayments]);
  }));

  it('navigates to "sign-up" from switcher with "ok"', () => {
    service.navigate(switcherSelector, 'ok');
    expect(routerMock.navigate).toHaveBeenCalledWith([routes.signUp]);
  });

  it('exits the application from switcher with false', () => {
    expect(location.href).toEqual(undefined);
    service.navigate(switcherSelector, false);
    expect(config.getConfigParam).toHaveBeenCalledWith('old-journey');
    expect(location.href).toEqual('http://old.com?fakeParams');
  });

  it('navigates to "error" from confirmation if additional data comes', () => {
    service.navigate(confirmationSelector, 'something');
    expect(routerMock.navigate).toHaveBeenCalledWith([routes.error]);
  });

  it('navigates to errorValues if switcher selector comes with additional nav data of error values', () => {
    service.navigate(switcherSelector, 'app-error-values');
    expect(routerMock.navigate).toHaveBeenCalledWith([routes.errorValues]);
  });
});
