import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ConfigService } from '../config/config.service';
import { SecurityService } from '../security/security.service';
import { zip, of, Observable } from 'rxjs';
import { map, flatMap } from 'rxjs/operators';
import { RegularESaverAccountCase } from 'src/app/models/regularESaverAccountCase.model';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';

@Injectable({
  providedIn: 'root'
})
export class AccountStatusService {
  private accountDetails;

  constructor (
    private http: HttpClient,
    private configService: ConfigService,
    private securityService: SecurityService,
    private urlParams: UrlParamCollectorService
  ) { }

  getAccountStatus (): Observable<RegularESaverAccountCase> {
    if (this.accountDetails) {
      return of(this.accountDetails);
    }

    return zip(
      this.securityService.getSecurityToken(),
      this.configService.getConfigParam('client-id'),
      this.configService.getConfigParam('esaverAccountAPIUrl')
    ).pipe(
      map(([token, clientId, url]) => ({
        options: {
          headers: new HttpHeaders(<any>{
            'Authorization': `Bearer ${token}`,
            'X-IBM-Client-Id': clientId,
          }),
        },
        url,
      })),
      flatMap(requestData =>
        this.http.get(
          <string>`${requestData.url}?psb=${this.urlParams.getQueryParam('psb')}${this.urlParams.checkAndAddParamIfExists('ma')}`,
          { headers: requestData.options.headers, observe: 'response' }
        )
      ),
      map((response: any) => {
        if (!response || response.status === 204) {
          throw new Error('account is undefined');
        } else {
          return this.accountDetails = <RegularESaverAccountCase> {
            type: response.body.type,
            attributes: response.body.attributes,
            status: response.status
          };
        }
      })
    );
  }
}
