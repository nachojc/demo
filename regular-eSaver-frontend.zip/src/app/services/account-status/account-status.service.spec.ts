import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import RegularESaverAccountCase from '../../../../external-files/regular-esaver-manager/regular-esaver-account/regular-esaver-account-GET.json';
import { ConfigService } from '../config/config.service';
import { SecurityService } from '../security/security.service';
import { AccountStatusService } from './account-status.service';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';

describe('AccountStatusService', () => {
  let service: AccountStatusService;
  let httpTestingController: HttpTestingController;

  const esaverAccountAPIUrl = 'http://example.com/regular-esaver-manager/regular-esaver';

  const configServiceMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.callFake(param => {
      return {
        'client-id': of('ClientId'),
        'esaverAccountAPIUrl': of(esaverAccountAPIUrl)
      }[param];
    })
  };

  const securityServiceMock = {
    getSecurityToken: jasmine.createSpy('getSecurityToken').and.returnValue(of('AccessToken'))
  };

  const urlParamCollectorServiceMock = {
    getQueryParam: jasmine.createSpy('getQueryParam').and.returnValue('123'),
    checkAndAddParamIfExists: jasmine.createSpy('checkAndAddParamIfExists').and.callFake(param => {
      return `&${param}=true`;
    })
  };

  const regularESaverAccountCase = Object.assign({}, RegularESaverAccountCase);

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        AccountStatusService,
        { provide: SecurityService, useValue: securityServiceMock },
        { provide: ConfigService, useValue: configServiceMock },
        { provide: UrlParamCollectorService, useValue: urlParamCollectorServiceMock }
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(AccountStatusService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should retrieve a regularESaverAccount resource', () => {
    let accountDetails;

    service.getAccountStatus().subscribe(
      details => accountDetails = details
    );

    const req = httpTestingController.expectOne(`${esaverAccountAPIUrl}?psb=123&ma=true`);
    expect(req.request.method).toEqual('GET');
    req.flush(RegularESaverAccountCase);

    expect(accountDetails).toEqual(regularESaverAccountCase);
  });

  it('should send the right headers in the request', () => {
    service.getAccountStatus().subscribe();

    const req = httpTestingController.expectOne(`${esaverAccountAPIUrl}?psb=123&ma=true`);
    expect(req.request.headers.get('Authorization')).toEqual('Bearer AccessToken');
    expect(req.request.headers.get('X-IBM-Client-Id')).toEqual('ClientId');
  });

  it('it should cache the response, so no second call is made if we have the details', () => {
    service.getAccountStatus().subscribe();

    const req = httpTestingController.expectOne(`${esaverAccountAPIUrl}?psb=123&ma=true`);
    req.flush(RegularESaverAccountCase);

    service.getAccountStatus().subscribe();
    httpTestingController.expectNone(`${esaverAccountAPIUrl}?psb=123&ma=true`);
  });

  it('should throw an error if response status is 204', () => {
    let accountDetailsError;

    service.getAccountStatus().subscribe(
      () => {},
      err => accountDetailsError = err
    );

    const req = httpTestingController.expectOne(`${esaverAccountAPIUrl}?psb=123&ma=true`);
    req.flush('', { status: 204, statusText: 'No Data' });

    expect(accountDetailsError.message).toEqual('account is undefined');
  });
});
