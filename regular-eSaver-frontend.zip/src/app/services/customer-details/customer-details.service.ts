import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, zip } from 'rxjs';
import { flatMap, map } from 'rxjs/operators';
import { RegularESaverCase, RegularESaverCaseResponse } from '../../models/regularESaverCase.model';
import { ConfigService } from '../config/config.service';
import { SecurityService } from '../security/security.service';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';

@Injectable({
  providedIn: 'root'
})
export class CustomerDetailsService {
  private customerDetails: RegularESaverCase;
  isAlreadyCalled = false;

  constructor(
    private http: HttpClient,
    private securityService: SecurityService,
    private configService: ConfigService,
    private urlParams: UrlParamCollectorService
    ) { }

  getCustomerDetails(): Observable<RegularESaverCase> {
    if (this.customerDetails || this.isAlreadyCalled) {
      return of(this.customerDetails);
    }

    this.isAlreadyCalled = true;

    return zip(
      this.securityService.getSecurityToken(),
      this.configService.getConfigParam('client-id'),
      this.configService.getConfigParam('esaverAPIUrl')
    ).pipe(
      map(([token, clientId, url]) => ({
        options: {
          headers: new HttpHeaders(<any>{
            'Authorization': `Bearer ${token}`,
            'X-IBM-Client-Id': clientId
          })
        },
        url
      })),
      flatMap(requestData => this.http.post(
        `${requestData.url}?psb=${this.urlParams.getQueryParam('psb')}${this.urlParams.checkAndAddParamIfExists('ma')}`,
        null, requestData.options)),
      map((response: RegularESaverCaseResponse) => this.customerDetails = <RegularESaverCase>{
        id: response.data.id,
        type: response.data.type,
        attributes: response.data.attributes
      })
    );
  }
}
