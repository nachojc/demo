import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Observable, of } from 'rxjs';
import regularESaverCaseResponse from '../../../../external-files/regular-esaver-manager/regular-esaver/regular-esaver-POST.json';
import { ConfigService } from '../config/config.service';
import { SecurityService } from '../security/security.service';
import { CustomerDetailsService } from './customer-details.service';
import { UrlParamCollectorService } from '../url-param-collector/url-param-collector.service';

describe('CustomerDetailsService', () => {
  let service: CustomerDetailsService;
  let httpTestingController: HttpTestingController;

  const esaverAPIUrl = 'http://example.com/regular-esaver-manager/regular-esaver';

  const configServiceMock = {
    getConfigParam: jasmine.createSpy('getConfigParam').and.callFake(param => {
      return {
        'client-id': of('ClientId'),
        'esaverAPIUrl': of(esaverAPIUrl)
      }[param];
    })
  };

  const urlParamCollectorServiceMock = {
    getQueryParam: jasmine.createSpy('getQueryParam').and.callFake(param => {
      return {
        'ma': 'true',
        'psb': '123'
      }[param];
    }),
    checkAndAddParamIfExists: jasmine.createSpy('checkAndAddParamIfExists').and.callFake(param => {
      return `&${param}=true`;
    })
  };

  const securityServiceMock = {
    getSecurityToken: jasmine.createSpy('getSecurityToken').and.returnValue(of('AccessToken'))
  };

  const regularESaverCase = Object.assign({}, regularESaverCaseResponse.data);

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        CustomerDetailsService,
        { provide: SecurityService, useValue: securityServiceMock },
        { provide: ConfigService, useValue: configServiceMock },
        { provide: UrlParamCollectorService, useValue: urlParamCollectorServiceMock }
      ],
      imports: [
        HttpClientTestingModule
      ]
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(CustomerDetailsService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have a getConfigParam that returns an observable', () => {
    const obs = service.getCustomerDetails();
    expect(obs).toBeTruthy();
    expect(obs).toEqual(jasmine.any(Observable));
  });

  it('should retrieve a regularESaver resource', () => {
    let customerDetails;
    service.getCustomerDetails().subscribe(
      details => customerDetails = details
    );
    const req = httpTestingController.expectOne(`${esaverAPIUrl}?psb=123&ma=true`);
    expect(req.request.method).toEqual('POST');
    req.flush(regularESaverCaseResponse);

    expect(customerDetails).toEqual(regularESaverCase);
  });

  it ('should send auth headers and no body', () => {
    service.getCustomerDetails().subscribe();

    const req = httpTestingController.expectOne(`${esaverAPIUrl}?psb=123&ma=true`);
    req.flush(regularESaverCaseResponse);

    expect(req.request.body).toBe(null);
    expect(req.request.headers.get('Authorization')).toEqual('Bearer AccessToken');
    expect(req.request.headers.get('X-IBM-Client-Id')).toEqual('ClientId');
  });

  it('should cache the request', () => {
    service.getCustomerDetails().subscribe();

    const req = httpTestingController.expectOne(`${esaverAPIUrl}?psb=123&ma=true`);
    req.flush(regularESaverCaseResponse);

    service.getCustomerDetails().subscribe();

    httpTestingController.expectNone(`${esaverAPIUrl}?psb=123&ma=true`);
  });

  it('should set #isAlreadyCalled to true after first call', () => {
    expect(service.isAlreadyCalled).toEqual(false);
    service.getCustomerDetails().subscribe();

    const req = httpTestingController.expectOne(`${esaverAPIUrl}?psb=123&ma=true`);
    req.flush(regularESaverCaseResponse);
    expect(service.isAlreadyCalled).toEqual(true);
  });
});
