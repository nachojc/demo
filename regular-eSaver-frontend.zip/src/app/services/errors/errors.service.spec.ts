import { TestBed } from '@angular/core/testing';
import { ErrorsService } from './errors.service';

describe('ErrorsService', () => {
  let service: ErrorsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});

    service = TestBed.get(ErrorsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should only store error with error code of 3', () => {
    const mockErrors = [
      {
        status: 500,
        code: 3,
        detail: 'Customer already have contracts for this product specification',
        source: 'portland.regular-esaver.post-application'
      },
      {
        status: 500,
        code: 999,
        detail: 'Fake',
        source: 'Fake.fake'
      }
    ];
    service.setErrors(mockErrors);

    service.getErrors().subscribe((errors) => {
      expect(errors.length).toEqual(1);
      expect(errors[0].code).toEqual(3);
    });
  });

  it('should only store errors with the follwoing error codes: 3 | 33 || 34 even if other errors are present', () => {
    const mockErrors = [
      {
        status: 500,
        code: 3,
        detail: 'Customer already have contracts for this product specification',
        source: 'portland.regular-esaver.post-application'
      },
      {
        status: 409,
        code: 33,
        detail: 'Customer has a country of residence different than GB',
        source: 'portland.regular-esaver.post-application'
      },
      {
        status: 409,
        code: 34,
        detail: 'Customer is less than sixteen years old',
        source: 'portland.regular-esaver.post-application'
      },
      {
        status: 409,
        code: 0,
        detail: 'fake',
        source: 'fake.fake.fake'
      }
    ];
    service.setErrors(mockErrors);

    service.getErrors().subscribe((errors) => {
      expect(errors.length).toEqual(3);
    });
  });

  it('#getErrorMsgIfCodePresent should return error message if error code exists in errors', () => {
    const mockErrors = [
      {
        status: 500,
        code: 3,
        detail: 'Customer already have contracts for this product specification',
        source: 'portland.regular-esaver.post-application'
      }
    ];
    service.setErrors(mockErrors);

    expect(service.getErrorMsgIfCodePresent(3)).toEqual('Customer already have contracts for this product specification');
    // expect(service.getErrorMsgIfCodePresent(5)).toEqual(undefined);
  });

  it('#hasError should return true if errors length is greater than 1', () => {
    const mockErrors = [
      {
        status: 500,
        code: 3,
        detail: 'Customer already have contracts for this product specification',
        source: 'portland.regular-esaver.post-application'
      }
    ];
    service.setErrors(mockErrors);
    expect(service.hasError()).toEqual(true);
  });

  it('#hasError should return false if errors length is 0', () => {
    expect(service.hasError()).toEqual(false);
  });
});
