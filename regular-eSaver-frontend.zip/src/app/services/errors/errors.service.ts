import { Injectable } from '@angular/core';
import { RegularESaverCaseErrorResource } from 'src/app/models/regularESaverCase.model';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ErrorsService {
  private errors: RegularESaverCaseErrorResource[] = [];
  errCodes = [3, 33, 34];

  constructor() { }

  getErrors(): Observable<RegularESaverCaseErrorResource[]> {
    return of(this.errors);
  }

  setErrors(errors: RegularESaverCaseErrorResource[]) {
    if (errors) {
      errors.forEach(error => {
        switch (error.code) {
          case 3:
            this.errors.push(error);
            break;
          case 33:
            this.errors.push(error);
            break;
          case 34:
            this.errors.push(error);
            break;
        }
      });
    }
  }

  getErrorMsgIfCodePresent(code: number): string {
    let errorDetail;
    this.errors.forEach(error => {
      if (error.code === code) {
        errorDetail = error.detail;
        return ;
      }
    });

    return errorDetail;
  }

  hasError(): boolean {
    return this.errors.length > 0;
  }
}
