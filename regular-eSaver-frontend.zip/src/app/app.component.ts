import { Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';
import { AdobeService } from './services/adobe/adobe.service';
import { BrowserManagerService } from './services/browser-manager/browser-manager.service';
import { CaseSubmissionService } from './services/case-submission/case-submission.service';
import { NavigatorService } from './services/navigator/navigator.service';
import { UrlParamCollectorService } from './services/url-param-collector/url-param-collector.service';
// import selector from './app-selector.model';

@Component({
  selector: 'app-root', // cannot get from a file
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  // If LOCATION_TOKEN service is injected here rather than in app module,
  // your test won't be able to inject a mock service, it always get this component injection (here)
})
export class AppComponent implements OnInit, OnDestroy {
  private routerSubscription: Subscription;

  constructor(
    private router: Router,
    private adobeService: AdobeService,
    private browserManager: BrowserManagerService,
    private paramService: UrlParamCollectorService,
    private navigator: NavigatorService,
    private caseSubmissionService: CaseSubmissionService
  ) { }

  ngOnInit() {
    this.browserManager.preventBackButton();

    if (this.paramService.hasMandatoryKeys()) {
      this.routerSubscription = this.router.events
        .pipe(filter(event => event instanceof NavigationEnd))
        .subscribe((navEvent: NavigationEnd) => {
          window.scrollTo(0, 0);
          const referenceNumber = this.caseSubmissionService.getCaseNumber();
          if (referenceNumber) {
            this.adobeService.setOlaId(referenceNumber);
          }
          this.adobeService.sendPageTrackingInformation(navEvent.url);
        }
      );
      this.adobeService.startAdobe('secregularesaver');

    } else {
      this.adobeService.setErrorInformation('No mandatory keys present');
      this.navigator.navigate('app-root'); // go to error
    }
  }

  ngOnDestroy() {
    this.routerSubscription && this.routerSubscription.unsubscribe();
  }
}
