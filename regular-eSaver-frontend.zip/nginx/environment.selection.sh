#!/bin/bash

rm /etc/nginx/conf.d/default.conf
ln -s /etc/nginx/environments/default."${SPRING_CONFIG_ENVIRONMENT}".conf /etc/nginx/conf.d/default.conf
sed -i "s/__PROFILE_CONFIG_LOCATION__/${SPRING_CONFIG_LOCATION//\//\\/}/g;s/__PROFILE_CONFIG_ENV__/$SPRING_CONFIG_ENVIRONMENT/g;s/__PROFILE_CONFIG_PROFILE__/$SPRING_CONFIG_PROFILE/g;s/__PROFILE_CONFIG_BRANCH__/$SPRING_CONFIG_LABEL/g" /etc/nginx/conf.d/default.conf
