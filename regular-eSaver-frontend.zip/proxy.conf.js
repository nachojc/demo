const fs = require('fs');

const proxyUrls = [
  '/config/application',
  '/config/terms',
  '/security-service/oauth2/token',
  '/adobe',
  '/logging',
  '/regular-esaver-manager/regular-esaver/regular-esaver',
  '/regular-esaver-manager/regular-esaver-account/regular-esaver-account',
];

const PROXY_CONFIG = {
  "/": {
    "secure": false,
    "bypass": function (req, res) {
      if (req.url === '/logging' ){
        res.status(200).end('UP');
        return true;
      }
      var file = findUrl(req.url);
      if (file) {
        file = file + '-' + req.method;
        console.log('Sending Mock file: ' + file);

        if (file === '/regular-esaver-manager/regular-esaver/regular-esaver-PUT') {
          return res.status(500);
        } else if (file === '/regular-esaver-manager/regular-esaver-account/regular-esaver-account-GET') {
          // file = '/regular-esaver-manager/regular-esaver/regular-esaver-holding-error';
          // file = '/regular-esaver-manager/regular-esaver/regular-esaver-data-error';
          // file = '/regular-esaver-manager/regular-esaver/regular-esaver-error-OJ';
          // return res.status(500);
          // res.status(204).end();
          res.status(200).end(fs.readFileSync('./external-files' + file + '.json'));
        } else {
          res.end(fs.readFileSync('./external-files' + file + '.json'));
        }

        // if (file === '/regular-esaver-manager/regular-esaver-account/regular-esaver-account-GET') {
        //   res.status(204); // either this or doing the journey in off hours, will get you to /confirmation and not /congratulations  
        // }


        return true;
      }

      function findUrl(url) {
        values = proxyUrls.filter(proxyUrl => url.indexOf(proxyUrl) >= 0);
        return values.length ? values[0] : null;
      }
    }
  }
}

module.exports = PROXY_CONFIG;
