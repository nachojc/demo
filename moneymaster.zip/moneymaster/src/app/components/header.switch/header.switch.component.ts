import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-header-switch',
  templateUrl: './header.switch.component.html',
  styleUrls: ['./header.switch.component.scss'],
})
export class HeaderSwitchComponent {
  @Input() money: number;
  @Input() edit = true;
  @Input() text: string;
 }
