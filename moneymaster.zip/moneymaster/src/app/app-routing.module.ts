import { NgModule } from '@angular/core';
import { RouterModule, Routes, Router } from '@angular/router';
import { LoginComponent } from './pages/login-component/login.component';
import { MainComponent } from './pages/main/main.component';
import { MoneyComponent } from './pages/money/money.component';
import { ParnerComponent } from './pages/parner/parner.component';
import { DetailsComponent } from './pages/details/details.component';
import { AgreementComponent } from './pages/agreement/agreement.component';
import { DetailsDataComponent } from './pages/details-data/details-data.component';
import { LabradorComponent } from './pages/labrador/labrador.component';
import { EnergyComponent } from './pages/energy/energy.component';


const routes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'main', component: MainComponent },
    { path: 'moneymaster', component: MoneyComponent },
    { path: 'parner/:id', component: ParnerComponent },
    { path: 'customer/details', component: DetailsComponent },
    { path: 'customar/data', component: DetailsDataComponent },
    { path: 'energy', component: EnergyComponent },
    { path: 'agreement', component: AgreementComponent },

    { path: 'labrador', component: LabradorComponent },
    
    { path: '**', redirectTo: '', pathMatch: 'full' },
  ];

  @NgModule({
    imports: [ RouterModule.forRoot(routes) ],
    exports: [RouterModule]
  })

  export class AppRoutingModule {}
