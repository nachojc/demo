import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { LoginComponent } from './pages/login-component/login.component';
import { AppRoutingModule } from './app-routing.module';
import { MainComponent } from './pages/main/main.component';
import { HeaderComponent } from './components/header/header.component';
import { HeaderSwitchComponent } from './components/header.switch/header.switch.component';
import { FooterComponent } from './components/footer/footer.component';
import { MoneyComponent } from './pages/money/money.component';
import { ParnerComponent } from './pages/parner/parner.component';
import { DetailsComponent } from './pages/details/details.component';
import { AgreementComponent } from './pages/agreement/agreement.component';
import { DetailsDataComponent } from './pages/details-data/details-data.component';
import { NextComponent } from './components/next/next.component';
import { LabradorComponent } from './pages/labrador/labrador.component';
import { EnergyComponent } from './pages/energy/energy.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { InputComponent } from './components/input/input.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MainComponent,
    HeaderComponent,
    HeaderSwitchComponent,
    FooterComponent,
    MoneyComponent,
    ParnerComponent,
    DetailsComponent,
    AgreementComponent,
    DetailsDataComponent,
    NextComponent,
    LabradorComponent,
    EnergyComponent,
    InputComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production }),

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
