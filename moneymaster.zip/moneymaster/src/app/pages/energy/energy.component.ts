import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-energy',
  templateUrl: './energy.component.html',
  styleUrls: ['./energy.component.css']
})
export class EnergyComponent  {

  constructor(private router: Router) { }

  nextPage() {
    this.router.navigate(['agreement']);
  }
}
