import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-details-data',
  templateUrl: './details-data.component.html',
  styleUrls: ['./details-data.component.css']
})
export class DetailsDataComponent {

  constructor(private router: Router) { }

  nextPage() {
    this.router.navigate(['energy']);
  }
}
