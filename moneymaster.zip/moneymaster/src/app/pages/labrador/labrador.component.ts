import { Component } from '@angular/core';

@Component({
  selector: 'app-labrador',
  templateUrl: './labrador.component.html',
  styleUrls: ['./labrador.component.css']
})
export class LabradorComponent {

}
