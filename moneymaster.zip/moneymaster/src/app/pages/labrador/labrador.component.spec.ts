import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LabradorComponent } from './labrador.component';

describe('LabradorComponent', () => {
  let component: LabradorComponent;
  let fixture: ComponentFixture<LabradorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LabradorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LabradorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
