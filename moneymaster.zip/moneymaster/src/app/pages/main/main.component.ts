import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent {
  public data = {
    user: {
      name : 'Paul',
      mouth : 36.01,
      opening: 30283.98
    },
    moneymaster: {
      spend : 744,
      imgs: [
        {name: 'british_gas'},
        {name: 'netflix'},
        {name: 'eon'},
      ]
    },
    accounts: [
      {name: '123 Current Account', money: 2005.00, available: 2005.00, account: '09-01-22 00083526'},
      {name: 'JOIN', money: 12005.02, available: 12005.00, account: '01-01-11 00083526'},
      {name: 'eSaver', money: 0.00  , available: 0.00, account: '07-01-22 00083526'},
      {name: '123 Current Account', money: 2005.00, available: 2005.00, account: '09-01-22 00083526'},

    ]
  };
  public modalHide = false;
  constructor(private router: Router) { }

  openMoneyMaster() {
    this.router.navigate(['moneymaster']);
  }
}
