import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-parner',
  templateUrl: './parner.component.html',
  styleUrls: ['./parner.component.css']
})
export class ParnerComponent {

  constructor(private router: Router) { }

  nextPage() {
    this.router.navigate(['customer/details']);
  }
}
