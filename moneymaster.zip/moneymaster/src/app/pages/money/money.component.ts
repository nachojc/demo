import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-money',
  templateUrl: './money.component.html',
  styleUrls: ['./money.component.css']
})
export class MoneyComponent  {
  public section = 0;
  public data = {
    bills: [
      {id:0,img:'british_gas',company:'British Gas',type:'Gas',price:200.33,cancel:false},
      {id:1,img:'eon',company:'Sky',type:'TV',price:200.33,cancel:false},
      {id:2,img:'british_telecom',company:'British Telecom',type:'Broadband',price:200.33,cancel:false},
      {id:3,img:'lynda',company:'Thames Water',type:'Water',price:39.00,cancel:false},
    ],
    subscriptions: [
      {id:0,img:'spotify',company:'Spotify',type:'Music',price:4.99,cancel:true},
      {id:1,img:'amazon_prime',company:'Amazon Prime',type:'Shopping',price:19.99,cancel:false},
      {id:2,img:'amazon_fresh',company:'Amazon Fresh',type:'Groceries',price:5.00,cancel:false},
      {id:3,img:'dropbox',company:'Dropbox',type:'Software',price:9.99,cancel:false},

    ]
  };

  constructor(private router: Router) { }
  gotoCancel(id){
    console.log(id);
  }

  gotoSwitch(id) {
    this.router.navigate(['parner', id]);
  }
}
