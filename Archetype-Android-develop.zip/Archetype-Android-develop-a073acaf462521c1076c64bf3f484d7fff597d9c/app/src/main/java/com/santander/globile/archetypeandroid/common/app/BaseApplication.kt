package com.santander.globile.archetypeandroid.common.app

import android.app.Application

class BaseApplication : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}