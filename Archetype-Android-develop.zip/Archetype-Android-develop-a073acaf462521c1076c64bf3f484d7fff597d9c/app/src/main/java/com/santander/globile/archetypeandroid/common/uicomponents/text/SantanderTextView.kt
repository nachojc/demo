package com.santander.globile.archetypeandroid.common.uicomponents.text

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.widget.TextView
import com.santander.globile.archetypeandroid.R

/**
 * This custom TextView uses the font provided by Santander
 */
@SuppressWarnings("CustomViewStyleable, PrivateResource")
class SantanderTextView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null, defStyleAttr: Int = 0
) : android.support.v7.widget.AppCompatTextView(context, attrs, defStyleAttr) {

    init {

        var style = Typeface.BOLD
        var font: String? = null

        if (attrs != null) {
            val typedArray = context.obtainStyledAttributes(attrs, R.styleable.TextAppearance)
            //Due to typeFace override, it is necessary to keep android:textStyle attribute too.
            style = typedArray.getInt(R.styleable.TextAppearance_android_textStyle, Typeface.NORMAL)
            typedArray.recycle()

            val typedArraySantander = context.obtainStyledAttributes(attrs, R.styleable.SantanderTextView)
            font = typedArraySantander.getString(R.styleable.SantanderTextView_textFont)
            typedArraySantander.recycle()

        }

        setTypeface(
            try {
                Typeface.createFromAsset(
                    context.assets,
                    "fonts/${font?.run { if (!endsWith(fontSuffix)) plus(fontSuffix) else this }
                        ?: defaultFont}"
                )
            } catch (e: Exception) {
                Typeface.createFromAsset(context.assets, "fonts/$defaultFont")
            },
            style)
    }

    companion object {
        private const val defaultFont = "SantanderText-Regular.ttf"
        private const val fontSuffix = ".ttf"
    }

}