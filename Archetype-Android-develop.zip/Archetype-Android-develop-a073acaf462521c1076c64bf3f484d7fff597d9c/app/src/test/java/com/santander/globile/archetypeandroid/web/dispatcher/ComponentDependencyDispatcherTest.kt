package com.santander.globile.archetypeandroid.web.dispatcher

import com.google.common.truth.Truth
import com.santander.globile.archetypeandroid.common.utils.getClassForName
import com.santander.globile.archetypeandroid.testutils.TestActivityComponentFacade
import kotlinx.coroutines.runBlocking
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.junit.MockitoJUnitRunner

@RunWith(MockitoJUnitRunner::class)
class ComponentDependencyDispatcherTest {

    private var componentDependencyDispatcher = ComponentDependencyDispatcher("java", "String")

    @Before
    fun setUp() {
        componentDependencyDispatcher.setView(null)
    }

    @Test
    fun `Check if String is a class and exists in this project`() {
        // Arrange
        val expected = String::class.java

        // Act
        val result = componentDependencyDispatcher.getComponentClassByName("lang")

        // Assert
        Truth.assertThat(result).isEqualTo(expected)
    }

    @Test
    fun `Non existing dependency`() {
        // Arrange
        val expected = null

        // Act
        val result = componentDependencyDispatcher.getComponentClassByName("fFdfasf")

        // Assert
        Truth.assertThat(result).isEqualTo(expected)
    }

    @Mock
    lateinit var listener: ComponentListener

    @Test
    fun `Delegate to a non existing component`() {
        // Arrange
        componentDependencyDispatcher.setView(listener)

        // Act
        componentDependencyDispatcher.delegateCallToComponent("w", null)

        // Assert
        Mockito.verify(listener, Mockito.times(1)).onComponentNotFound()
    }

    @Test
    fun `Delegate to a null component`() {
        // Arrange
        componentDependencyDispatcher.setView(listener)

        // Act
        componentDependencyDispatcher.delegateCallToComponent(null, null)

        // Assert
        Mockito.verify(listener, Mockito.times(1)).onComponentNotFound()
    }

    @Test
    fun `Component without expected delegated methods`() = runBlocking {
        //Arrange
        componentDependencyDispatcher.setView(listener)

        //Act
        componentDependencyDispatcher.callComponent(getClassForName("java.lang.String")!!, null)

        // Assert
        Mockito.verify(listener, Mockito.times(1)).onComponentMethodNotFound()
    }

    @Test
    fun `Component with must start activity method`() = runBlocking {
        //Arrange
        val componentFacade = getClassForName(
            "com.santander.globile.archetypeandroid.testutils.TestActivityComponentFacade"
        )
        val params = null
        componentDependencyDispatcher.setView(listener)

        //Act
        componentDependencyDispatcher.callComponent(componentFacade!!, params)

        // Assert
        Mockito.verify(listener, Mockito.times(1))
            .isComponentActivity(Mockito.any(TestActivityComponentFacade::class.java), Mockito.eq(params))
    }

    @Test
    fun `Component called with result returned`() = runBlocking {
        //Arrange
        componentDependencyDispatcher.setView(listener)

        //Act
        componentDependencyDispatcher.callComponent(
            getClassForName("com.santander.globile.archetypeandroid.testutils.TestComponentFacade")!!,
            null
        )

        // Assert
        Mockito.verify(listener, Mockito.times(1)).onComponentResponse(Mockito.anyString())
    }
}