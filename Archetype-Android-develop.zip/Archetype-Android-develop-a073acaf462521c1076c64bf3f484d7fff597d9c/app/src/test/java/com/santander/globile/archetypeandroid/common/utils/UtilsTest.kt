package com.santander.globile.archetypeandroid.common.utils

import com.google.common.truth.Truth
import org.junit.Test
import org.junit.runner.RunWith
import org.junit.runners.JUnit4

@RunWith(JUnit4::class)
class UtilsTest {

    @Test
    fun `Check String class exists`() {
        // Arrange
        val expected = String::class.java

        // Act
        val result = getClassForName("java.lang.String")

        // Assert
        Truth.assertThat(result).isEqualTo(expected)
    }

    @Test
    fun `Non existing class`() {
        // Arrange
        val expected = null

        // Act
        val result = getClassForName("w")

        // Assert
        Truth.assertThat(result).isEqualTo(expected)
    }
}