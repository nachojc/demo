# Introduction 
This is the base code for developing Android applications according to the Santander Mobile Reference Architecture.

# Getting Started
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically create a new Android application project based on this Archetype.

## Manually
1. Clone the repository
2. Modify package name in AndroidManifest.xml
3. Develop your app

# Build and Test
## Automatically
You can use the [Workspace](https://gitlab.alm.gsnetcloud.corp/Globile_Architecture/Workspace) to automatically build and run the app.

## Manually
1. Open the project in Android Studio
2. Build and run
