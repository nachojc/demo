import { Tree } from '@angular-devkit/schematics/src/tree/interface';
import { InsertChange } from '@schematics/angular/utility/change';
import { findNodes } from '@schematics/angular/utility/ast-utils';
import {
	chain,
	mergeWith,
	SchematicsException,
	apply,
	move,
	Rule,
	url,
	branchAndMerge,
	applyTemplates,
	filter,
	noop
} from '@angular-devkit/schematics';
import { SchemaOptions } from '../utility/schema';
import {
	capitalizeFirstLetter,
	addImport,
	addComponentIntoComponentsArray,
	readIntoSourceFile
} from '../utility/utils';
import {
	strings,
	Path,
	basename,
	dirname,
	join,
	normalize
} from '@angular-devkit/core';
import * as ts from 'typescript';

function addExportIntoIndex(file: any) {
	return (host: Tree) => {
		const source = readIntoSourceFile(host, file.path);
		const myNode = findNodes(source, ts.SyntaxKind.ExportDeclaration);
		const lastNode = myNode[myNode.length - 1];
		const declarationRecorder = host.beginUpdate(file.path);
		const element = `export * from './lib/${file.type}/${strings.dasherize(file.name)}/index';`;
		let toInsert = '';

		if (lastNode.kind === ts.SyntaxKind.ExportDeclaration) {
			toInsert = `\n${element}`;
		}
		const change = new InsertChange(file.path, lastNode.getEnd(), toInsert);

		if (change.toAdd) {
			declarationRecorder.insertLeft(change.pos, change.toAdd);
		}
		host.commitUpdate(declarationRecorder);
		return host;
	};
}

/**
 *
 *
 * @export
 * @param {SchemaOptions} options
 * @returns {Rule}
 */
export function createComponent(options: SchemaOptions): Rule {
	if (!options.name) {
		throw new SchematicsException(`Option name is required`);
	}
	const parsedPath = parseName(options);
	options.name = parsedPath.name;
	options.pathLibs = parsedPath.pathLibs;

	const flameLib = {
		path: `${options.pathLibs}/lib/${options.type}/${
			options.type
		}-components.ts`,
		className: `${capitalizeFirstLetter(options.name)}Module`,
		fileToEdit: `${options.type}-components.ts`,
		fileName: `./${options.name}/${options.name}.module`,
		type: options.type
	};

	const file = {
		path: `${options.pathLibs}/index.ts`,
		type: options.type,
		name: options.name
	};

	const templateSource = apply(url('./files/lib'), [
		options.skipTests
			? filter(path => !path.endsWith('.spec.ts.template'))
			: noop(),
		options.inlineStyle
			? filter(path => !path.endsWith('.__style__.template'))
			: noop(),
		options.inlineTemplate
			? filter(path => !path.endsWith('.html.template'))
			: noop(),
		applyTemplates({
			...strings,
			'if-flat': (s: string) => (options.flat ? '' : s),
			...options
		}),
		move(`${options.pathLibs}/lib/${options.type}`)
	]);

	return chain([
		addImport(flameLib),
		addComponentIntoComponentsArray(flameLib),
		addExportIntoIndex(file),
		branchAndMerge(chain([mergeWith(templateSource)]))
	]);
}

/**
 *
 *
 * @export
 * @param {SchemaOptions} options
 * @returns {Location}
 */
export function parseName(options: SchemaOptions) {
	const nameWithoutPath = basename(normalize(options.name));
	const namePath = dirname(join(
		normalize(`${options.pathLibs}`),
		options.name
	) as Path);
	return {
		name: nameWithoutPath,
		pathLibs: normalize(namePath)
	};
}
