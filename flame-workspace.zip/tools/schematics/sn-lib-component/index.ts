import {
  Rule,
  chain
} from "@angular-devkit/schematics";
import { createDocumentation } from "./flame-component";
import { createComponent } from "./flame-lib";

export default function componentSchematic(_options: any): Rule {
  return chain([
    createComponent({
      ... _options,
      pathLibs: `libs/flame-component-library/src`
    }),
    createDocumentation({
      ..._options,
      name: _options.name,
      path: `apps/flame-documentation/src/app`
    })
  ]);
}
