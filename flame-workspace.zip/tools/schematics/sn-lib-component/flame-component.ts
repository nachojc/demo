import {
  chain,
  mergeWith,
  SchematicsException,
  apply,
  filter,
  move,
  Rule,
  url,
  branchAndMerge,
  applyTemplates,
  noop
} from "@angular-devkit/schematics";
import {
  findNodes,
  addImportToModule
} from "@schematics/angular/utility/ast-utils";
import { SchemaOptions } from "../utility/schema";
import { Declaration } from "../utility/declaration";
import {
  addElementIntoArray,
  readIntoSourceFile,
  addImport,
  addComponentIntoComponentsArray
} from "../utility/utils";
import {
  strings,
  Path,
  basename,
  dirname,
  join,
  normalize
} from "@angular-devkit/core";
import * as ts from "typescript";
import { Tree } from "@angular-devkit/schematics/src/tree/interface";
import { InsertChange } from "@schematics/angular/utility/change";
import { dasherize, classify } from '@angular-devkit/core/src/utils/strings';

function addComponentIntoSideBar(configPage: any): Rule {
  return (host: Tree) => {
    const source = readIntoSourceFile(host, configPage.path);
    const menu: any = findNodes(
      source,
      ts.SyntaxKind.ArrayLiteralExpression
    ).filter((node: any) => {
      return (
        node.parent &&
        node.parent.name &&
        node.parent.name.escapedText === "menu"
      );
    })[0];

    const subMenuNode = menu.elements.find((node: any) => {
      return (
        node.properties.find((property: any) => {
          return (
            property.name.escapedText === "groupName" &&
            property.initializer.text === "atoms"
          );
        }) !== null
      );
    });
    const elementsNode = subMenuNode.properties.find((property: any) => {
      return property.name.escapedText === "menu";
    });

    const declarationRecorder = host.beginUpdate(configPage.path);
    const myPath = `{
        routerLink: '/ui-components/atoms/${dasherize(configPage.name)}',
        textContent: '${configPage.textContent}'
      }`;
    const change = addElementIntoArray(
      configPage.path,
      elementsNode.initializer as ts.ArrayLiteralExpression,
      myPath
    ) as InsertChange;
    if (change.toAdd) {
      declarationRecorder.insertLeft(change.pos, change.toAdd);
    }
    host.commitUpdate(declarationRecorder);
    return host;
  };
}

/**
 * Añade el componente creado al archivo de routing de flame-documentation
 *
 * @param {Declaration} fileDeclaration
 * @returns {Rule}
 */
function addComponentIntoRouting(fileDeclaration: any): Rule {
  return (host: Tree) => {
    const source = readIntoSourceFile(host, fileDeclaration.path);
    const routes = findNodes(
      source,
      ts.SyntaxKind.ArrayLiteralExpression
    ).filter((node: any) => {
      return (
        node.parent &&
        node.parent.name &&
        node.parent.name.escapedText === "routes"
      );
    })[0];
    const children = findNodes(
      routes,
      ts.SyntaxKind.ArrayLiteralExpression
    ).filter((node: any) => {
      return (
        node.parent &&
        node.parent.name &&
        node.parent.name.escapedText === "children"
      );
    })[0];

    const declarationRecorder = host.beginUpdate(fileDeclaration.path);
    const objElement = `
    {
      path: '${dasherize(fileDeclaration.name)}',
      component: ${fileDeclaration.className}
    }`;
    const change = addElementIntoArray(
      fileDeclaration.path,
      children as ts.ArrayLiteralExpression,
      objElement
    ) as InsertChange;
    if (change.toAdd) {
      declarationRecorder.insertLeft(change.pos, change.toAdd);
    }
    host.commitUpdate(declarationRecorder);
    return host;
  };
}

function addComponentIntoModule(params: any): Rule {
  return (host: Tree) => {
    const source = readIntoSourceFile(host, params.path);

    const libraryModules = findNodes(
      source,
      ts.SyntaxKind.ArrayLiteralExpression
    ).filter((node: any) => {
      return (
        node.parent &&
        node.parent.name &&
        node.parent.name.escapedText === "LIBRARY_MODULES"
      );
    })[0];
    const declarationChangeArray = addElementIntoArray(
      params.path,
      libraryModules as ts.ArrayLiteralExpression,
      params.className
    ) as InsertChange;
    const declarationRecorder = host.beginUpdate(params.path);

    if (declarationChangeArray.toAdd) {
      declarationRecorder.insertLeft(declarationChangeArray.pos, declarationChangeArray.toAdd);
    }
    host.commitUpdate(declarationRecorder);
    return host;
  };
}

/**
 *
 *
 * @export
 * @param {SchemaOptions} options
 * @returns {Rule}
 */
export function createDocumentation(options: SchemaOptions): Rule {
  if (!options.name) {
    throw new SchematicsException(`Option name is required`);
  }
  const parsedPath = parseName(options);
  options.name = parsedPath.name;
  options.path = parsedPath.path;

  const flameComponent = {
    path: `${options.path}/modules/ui-components/views/${options.type}/views/${
      options.type
    }.components.ts`,
    className: `${classify(options.name)}PageComponent`,
    fileToEdit: `${options.type}.components.ts`,
    fileName: `./${strings.dasherize(options.name)}/${strings.dasherize(
      options.name
    )}-page.component`,
    type: options.type
  };

  const flameRouting = {
    path: `${options.path}/modules/ui-components/views/${options.type}/${
      options.type
    }-view-routing.module.ts`,
    className: `${classify(options.name)}PageComponent`,
    fileToEdit: `ui-components-routing.module.ts`,
    fileName: `./views/${strings.dasherize(options.name)}/${strings.dasherize(
      options.name
    )}-page.component`,
    name: options.name,
    type: options.type
  };

  const flameModule = {
    path: `${options.path}/modules/ui-components/views/${options.type}/${
      options.type
    }-view.module.ts`,
    className: `${classify(options.name)}Module`,
    fileToEdit: `${options.type}-view.module.ts`,
    namePathComponent: "@santander/flame-component-library",
    fileName: "@santander/flame-component-library"
  };

  const sideBarConfig = {
    path: `${options.path}/modules/ui-components/views/${options.type}/${options.type}-view.component.ts`,
    textContent: classify(options.name),
    type: options.type,
    name: options.name
  };

  const templateSource = apply(url("./files/doc"), [
    options.skipTests
      ? filter(path => !path.endsWith(".spec.ts.template"))
      : noop(),
    options.inlineStyle
      ? filter(path => !path.endsWith(".__style__.template"))
      : noop(),
    options.inlineTemplate
      ? filter(path => !path.endsWith(".html.template"))
      : noop(),
    applyTemplates({
      ...strings,
      "if-flat": (s: string) => (options.flat ? "" : s),
      ...options
    }),
    move(`${parsedPath.path}/modules/ui-components/views/${options.type}/views`)
  ]);

  return chain([
    addImport(flameComponent),
    addImport(flameRouting),
    addImport(flameModule),
    addComponentIntoComponentsArray(flameComponent),
    addComponentIntoRouting(flameRouting),
    addComponentIntoModule(flameModule),
    addComponentIntoSideBar(sideBarConfig),
    branchAndMerge(chain([mergeWith(templateSource)]))
  ]);
}

/**
 *
 *
 * @export
 * @param {SchemaOptions} options
 * @returns {Location}
 */
export function parseName(options: SchemaOptions) {
  const nameWithoutPath = basename(normalize(options.name));
  const namePath = dirname(join(
    normalize(`${options.path}`),
    options.name
  ) as Path);
  return {
    name: nameWithoutPath,
    path: normalize(namePath)
  };
}
