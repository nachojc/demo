import {
  Rule,
  chain
} from "@angular-devkit/schematics";
import { createComponent } from "./createComponent";

export default function component(_options: any): Rule {
  return chain([
    createComponent({
      ..._options,
      path: 'libs'
    })
  ]);
}
