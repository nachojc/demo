import { Rule} from '@angular-devkit/schematics';
import { Tree, chain } from '@angular-devkit/schematics';
import {
	Path,
	normalize,
	dirname,
	basename,
	join
} from '@angular-devkit/core';

import { readIntoSourceFile, capitalizeFirstLetter } from '../utility/utils';
import { insertImport, addImportToModule } from '@schematics/angular/utility/ast-utils';

function insertRoutingIntoModule(file: any): Rule {
	return (host: Tree) => {
		const path = `${file.path}/src/lib/${file.name}-operation-library.module.ts`;
    const source = readIntoSourceFile(host,path);
		const declarationRecorder = host.beginUpdate(path);

    insertImport(source, path, `${capitalizeFirstLetter(file.name)}OperationLibraryRoutingModule`, `./${file.name}-operation-library.router.module`);
    addImportToModule(source, path, `${capitalizeFirstLetter(file.name)}OperationLibraryRoutingModule`, `./${file.name}-operation-library.router.module`);
		host.commitUpdate(declarationRecorder);
		return host;
	};
}

export function insertOperationRoutingIntoModule(options: any) {
	const parsedPath = parseName(options);

	options.name = parsedPath.name;
	options.path = parsedPath.path;

	return chain([
    insertRoutingIntoModule(options)
  ]);
}

/**
 *
 *
 * @export
 * @param {SchemaOptions} options
 * @returns {Location}
 */
export function parseName(options: any) {
	const nameWithoutPath = basename(normalize(options.name));
	const namePath = dirname(join(
		normalize(`${options.path}`),
		options.name
	) as Path);
	return {
		name: nameWithoutPath,
		path: normalize(namePath)
	};
}
