import { Rule, chain, externalSchematic } from '@angular-devkit/schematics';
import { insertLibIntoTsconfig } from './insertLibIntoTsconfig';
import { insertOperationRoutingIntoModule } from './insertOperationRoutingIntoModule';

export default function operationSchematic(_options: any): Rule {
	return chain([
		externalSchematic('@nrwl/schematics', 'lib', {
		  ..._options,
		  name: `${_options.name}-operation-library`,
		  prefix: 'sn',
      framework: 'angular',
      module: false
    }),
    insertLibIntoTsconfig({
      ..._options,
      path: 'apps/super-mobile',
      routing: true
    })
	]);
}
