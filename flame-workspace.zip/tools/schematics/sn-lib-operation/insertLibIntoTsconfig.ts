import { Rule, apply, url, branchAndMerge, mergeWith, applyTemplates, move } from '@angular-devkit/schematics';
import { InsertChange } from '@schematics/angular/utility/change';
import { Tree, SchematicsException, chain } from '@angular-devkit/schematics';
import {
	Path,
	normalize,
	dirname,
	basename,
	join,
	JsonParseMode,
	parseJsonAst,
	JsonAstArray,
  strings
} from '@angular-devkit/core';

import {
	appendValueInAstArray,
	findPropertyInAstObject
} from '@schematics/angular/utility/json-utils';
import { readIntoSourceFile, addElementIntoArray, capitalizeFirstLetter } from '../utility/utils';
import { findNodes } from '@schematics/angular/utility/ast-utils';
import * as ts from 'typescript';

function insertIntoTsconfig(file: any): Rule {
	return (host: Tree) => {
		const path = `${file.path}/tsconfig.json`;

		const declarationRecorder = host.beginUpdate(path);
		const buffer = host.read(path);
		const content = `../../libs/${file.name}-operation-library/src/lib/${
			file.name
    }-operation-library.module.ts`;

		if (!buffer) {
			return;
		}
		const tsconfig = parseJsonAst(buffer.toString(), JsonParseMode.Loose);
		if (tsconfig.kind !== 'object') {
			throw new SchematicsException(
				'Invalid tsconfig. Was expecting an object'
			);
		}

		const filesAstNode = findPropertyInAstObject(tsconfig, 'files');
		if (filesAstNode && filesAstNode.kind !== 'array') {
			throw new SchematicsException(
				'Invalid tsconfig "files" property; expected an array.'
			);
		}

		appendValueInAstArray(
			declarationRecorder,
			filesAstNode as JsonAstArray,
			content
		);

		host.commitUpdate(declarationRecorder);
		return host;
	};
}

function addComponentIntoAppRouting(configPage: any): Rule {
  return (host: Tree) => {
    const myPath = `${configPage.path}/src/app/app.routing.module.ts`;
    const source = readIntoSourceFile(host, myPath);
    const sideBarPath = findNodes(
      source,
      ts.SyntaxKind.ArrayLiteralExpression
    ).filter((node: any) => {
      return (node.parent && node.parent.name && node.parent.name.escapedText === 'routes')
    })[0];

    const declarationRecorder = host.beginUpdate(myPath);
    const myRoute = `{
      path: '${configPage.name}',
      loadChildren: '../../../../libs/${configPage.name}-operation-library/src/lib/${configPage.name}-operation-library.module#${capitalizeFirstLetter(configPage.name)}OperationLibraryModule'
    }`;
    const change = addElementIntoArray(
      myPath,
      sideBarPath as ts.ArrayLiteralExpression,
      myRoute
    ) as InsertChange;
    if (change.toAdd) {
      declarationRecorder.insertLeft(change.pos, change.toAdd);
    }
    host.commitUpdate(declarationRecorder);
    return host;
  }
}

export function insertLibIntoTsconfig(options: any) {
	if (!options.name) {
		throw new SchematicsException('Option name is required');
	}

	const parsedPath = parseName(options);

	options.name = parsedPath.name;
	options.path = parsedPath.path;

  const templateSource = apply(url('./files'),[
    applyTemplates({
      ...strings,
      'if-flat': (s: string) => (options.flat ? '' : s),
      ...options
    }),
    move(`libs/${options.name}-operation-library/src/lib/`)
  ]);

	return chain([
    insertIntoTsconfig(options),
    addComponentIntoAppRouting(options),
		branchAndMerge(chain([mergeWith(templateSource)]))
  ]);
}

/**
 *
 *
 * @export
 * @param {SchemaOptions} options
 * @returns {Location}
 */
export function parseName(options: any) {
	const nameWithoutPath = basename(normalize(options.name));
	const namePath = dirname(join(
		normalize(`${options.path}`),
		options.name
	) as Path);
	return {
		name: nameWithoutPath,
		path: normalize(namePath)
	};
}
