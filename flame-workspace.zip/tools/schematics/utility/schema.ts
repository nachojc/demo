import { Path } from "@angular-devkit/core";

export interface SchemaOptions {
  name: string;
  type: string;
  project: string;
  inlineStyle: boolean;
  inlineTemplate: boolean;
  viewEncapsulation: string;
  changeDetection: string;
  prefix: string;
  styleext: string;
  style: string;
  spec: string;
  skipTests: boolean;
  flat: boolean;
  skipImport: boolean;
  selector: string;
  module: string;
  export: boolean;
  entryComponent: boolean;
  lintFix: boolean;
  path: string;
  namePathComponent: string;
  pathLibs: string;
}

export interface Location {
  name: string;
  path: Path;
  pathLibs: Path;
}
