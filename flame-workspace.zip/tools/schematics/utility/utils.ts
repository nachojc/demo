import { Declaration } from './declaration';
import { insertImport, findNodes } from '@schematics/angular/utility/ast-utils';
import { Tree } from '@angular-devkit/schematics/src/tree/interface';
import * as ts from 'typescript';
import { InsertChange, Change, NoopChange } from '@schematics/angular/utility/change';
import { SchematicsException, Rule } from '@angular-devkit/schematics';

/**
 *
 *
 * @export
 * @param {string} path
 * @param {ts.ArrayLiteralExpression} arr
 * @param {string} element
 * @returns {Change}
 */
export function addElementIntoArray (path: string, arr: ts.ArrayLiteralExpression, element: string): Change {
  let node = null;
  // If it's not an array, nothing we can do really.
  if (arr.kind !== ts.SyntaxKind.ArrayLiteralExpression) {
    return new NoopChange();
  }

  if (arr.elements.length === 0) {
    // Forward the property.
    node = arr;
  } else {
    node = arr.elements;
  }

  if (Array.isArray(node)) {
    const elementArray = node as {} as Array<ts.Node>;
    const symbolsArray = elementArray.map(node => node.getText());
    if (symbolsArray.includes(element)) {
      return new NoopChange();
    }

    node = node[node.length - 1];
  }

  let toInsert: string;
  let position = node.getEnd();
  if (node.kind === ts.SyntaxKind.ArrayLiteralExpression) {
    // We found the field but it's empty. Insert it just before the `]`.
    position--;
    toInsert = `${element}`;
  } else {
    // Get the indentation of the last element, if any.
    const text = node.getFullText();
    if (text.match(/^\r?\n/)) {
      toInsert = `,${text.match(/^\r?\n(\r?)\s*/)[0]}${element}`;
    } else {
      toInsert = `, ${element}`;
    }
  }

  return new InsertChange(path, position, toInsert);

}

/**
 * Lee el fichero que se indique
 *
 * @param {Tree} host
 * @param {string} componentsFile
 * @returns {ts.SourceFile}
 */
export function readIntoSourceFile(host: Tree, componentsFile: string): ts.SourceFile {
  const text = host.read(componentsFile);
  if (text === null) {
    throw new SchematicsException(`File ${componentsFile} does not exist.`);
  }

  const sourceText = text.toString("utf-8");

  return ts.createSourceFile(
    componentsFile,
    sourceText,
    ts.ScriptTarget.Latest,
    true
  );
}

/**
 * Modifica la primera letra del componente para dar formato de class
 *
 * @param {string} component
 * @returns {string}
 */
export function capitalizeFirstLetter(component: string): string {
  return component.charAt(0).toUpperCase() + component.slice(1);
}

/**
 * Añade el import con los parametros seleccionados
 *
 * @param {Declaration} fileDeclaration
 * @returns {Rule}
 */
export function addImport(fileDeclaration: any): Rule {
  return (host: Tree) => {
    const source = readIntoSourceFile(host, fileDeclaration.path);
    const declarationRecorder = host.beginUpdate(fileDeclaration.path);
    const componentChange = insertImport(
      source,
      fileDeclaration.fileToEdit,
      fileDeclaration.className,
      fileDeclaration.fileName
    ) as InsertChange;
    if (componentChange.toAdd) {
      declarationRecorder.insertLeft(
        componentChange.pos,
        componentChange.toAdd
      );
    }
    host.commitUpdate(declarationRecorder);
    return host;
  };
}

/**
 * Añade el componente al array de componentes del archivo atoms/molecules-component.ts
 *
 * @param {Declaration} fileDeclaration
 * @returns {Rule}
 */
export function addComponentIntoComponentsArray(fileDeclaration: Declaration): Rule {
  return (host: Tree) => {
    const source = readIntoSourceFile(host, fileDeclaration.path);
    const myNode = findNodes(
      source,
      ts.SyntaxKind.ArrayLiteralExpression
    ).filter((node: any) => {
      return (
        node.parent &&
        node.parent.name &&
        node.parent.name.escapedText === 'ATOMS_COMPONENTS'
      );
    })[0];
    const declarationRecorder = host.beginUpdate(fileDeclaration.path);

    const change = addElementIntoArray(
      fileDeclaration.path,
      myNode as ts.ArrayLiteralExpression,
      fileDeclaration.className
    ) as InsertChange;
    if (change.toAdd) {
      declarationRecorder.insertLeft(change.pos, change.toAdd);
    }
    host.commitUpdate(declarationRecorder);
    return host;
  };
}
