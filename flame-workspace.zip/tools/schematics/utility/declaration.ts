export interface Declaration {
  path: string;
  fileName: string;
  fileToEdit: string;
  className: string;
  namePathComponent?: string;
  type: string;
}
