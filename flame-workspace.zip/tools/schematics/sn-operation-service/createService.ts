import {
	Tree,
	apply,
	url,
	branchAndMerge,
	mergeWith,
	applyTemplates,
	move,
	Rule,
  SchematicsException,
  chain
} from '@angular-devkit/schematics';
import {
	Path,
	normalize,
	dirname,
	basename,
	join,
	strings
} from '@angular-devkit/core';
import { addProviderToModule } from '@schematics/angular/utility/ast-utils';
import { readIntoSourceFile } from '../utility/utils';
import { dasherize, classify } from '@angular-devkit/core/src/utils/strings';
import { InsertChange } from '@schematics/angular/utility/change';

function addIntoModule(options: any): Rule {
  return (host: Tree) => {
    const modulePath = `libs/${options.directory}/src/lib/${options.directory}.module.ts`;

    const source = readIntoSourceFile(host, modulePath);

    const declarationChanges = addProviderToModule(
      source,
      modulePath,
      `${classify(options.name)}Service`,
      `./services/${dasherize(options.name)}.service`);

      const declarationRecorder = host.beginUpdate(modulePath);
    for (const change of declarationChanges) {
      if (change instanceof InsertChange) {
        declarationRecorder.insertLeft(change.pos, change.toAdd);
      }
    }
    host.commitUpdate(declarationRecorder);
    return host;
  }
}

export function createService(options: any): Rule {
  return () => {
    if (!options.directory) {
      throw new SchematicsException('No se ha especificado una libreria');
    }
    if (!options.name) {
      throw new SchematicsException('No se ha especificado un nombre para el servicio');
    }

    const parsedPath = parseName(options);
    options.name = parsedPath.name;
    options.path = parsedPath.path;

    const templateSource = apply(url('./files'),[
      applyTemplates({
        ...strings,
        'if-flat': (s: string) => (options.flat ? '' : s),
        ...options
      }),
      move(`${options.path}/${options.directory}/src/lib/services`)
    ]);
    return chain([
      addIntoModule(options),
      branchAndMerge(chain([mergeWith(templateSource)]))
    ]);

  }
}

/**
 *
 *
 * @export
 * @param {SchemaOptions} options
 * @returns {Location}
 */
export function parseName(options: any) {
	const nameWithoutPath = basename(normalize(options.name));
	const namePath = dirname(join(
		normalize(`${options.path}`),
		options.name
	) as Path);
	return {
		name: nameWithoutPath,
		path: normalize(namePath)
	};
}
