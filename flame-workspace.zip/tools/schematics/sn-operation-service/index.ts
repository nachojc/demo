import { Rule, chain } from '@angular-devkit/schematics';
import { createService } from './createService';

export default function operationSchematic(_options: any): Rule {
	return chain([
    createService({
      ..._options,
      path: 'libs',
      routing: true
    })
	]);
}
