import {
  Rule,
  chain
} from "@angular-devkit/schematics";
import { createView } from "./createView";

export default function component(_options: any): Rule {
  return chain([
    createView({
      ..._options,
      path: 'libs'
    })
  ]);
}
