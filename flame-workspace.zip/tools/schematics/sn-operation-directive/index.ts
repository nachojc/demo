import {
  Rule,
  chain
} from "@angular-devkit/schematics";
import { createDirective } from "./createDirective";

export default function component(_options: any): Rule {
  return chain([
    createDirective({
      ..._options,
      path: 'libs'
    })
  ]);
}
