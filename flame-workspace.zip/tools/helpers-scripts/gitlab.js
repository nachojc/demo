const request = require('request');
const inquirer = require('inquirer');
const execa = require('execa');
const Listr = require('listr');
const colors = require('colors');
const shelljs = require('shelljs');

inquirer
	.prompt([
		{
			type: 'list',
			name: 'assigned',
			message: '¿A quien quieres elegir para la merge request? ',
			choices: [
				{ name: 'Miguel Martínez Echevarria', value: '749186' },
				{ name: 'Mario Arranz Águeda', value: '2462660' }
			]
		},
		{ name: 'title', message: 'Titulo de la merge request: ' },
		{ name: 'description', message: 'Descripción de la merge request: ' },
		{
			name: 'assets',
			message: 'Lista los assets (enlace a zepplin y tarea/s de Jira): '
		},
		{ name: 'changes', message: 'Cambios que se han realizado: ' }
	])
	.then(answers => {
		const tasks = new Listr([
			{
				title: 'Lint all projects',
				task: () => execa('npm', ['run', 'lint:all'])
			},
			{
				title: 'Build all libs',
				task: () => execa('npm', ['run', 'build'])
			},
			{
				title: 'Unit test',
				task: () => execa('npm', ['run', 'test'])
			}
		]);

		tasks
			.run()
			.then(ctx => {
				createMergeRequest({
					sourceBranch: answers.sourceBranch,
					title: answers.title,
					assignee: answers.assigned,
					description: `
					## Descripción
${answers.description}

## Assets
${answers.assets}

## Cambios
${answers.changes}
					`
				});
			})
			.catch(err => {
				console.log(colors.red(err));
			});
	});

function createMergeRequest(params) {
	const options = {
		url: 'https://gitlab.com/api/v4/projects/10846364/merge_requests',
		headers: {
			'Private-Token': 'L3m84BzzXy8wXMwoYZwZ',
			'Content-Type': 'application/json'
		},
		json: {
			id: 1,
			source_branch: shelljs.exec('git symbolic-ref --short HEAD', {silent:true}).stdout.replace(/\n/g, ''),
			target_branch: 'develop',
			title: params.title,
			description: params.description,
			assignee_id: params.assignee
		}
	};

	request.post(options, (error) => {
		if(error) console.log(colors.red(error));
		else console.log(colors.green('Merge request creada correctamente'));
	});
}
