const colors = require('colors');
const execa = require('execa');
const Listr = require('listr');
const shelljs = require('shelljs');

const componentChangeRegex = /(libs)(\/)(flame-component-library|flame-core-library|globile-services-library)(.*ts)/g;
const filenameRegex = /(\/)(?!.*\1)(.*ts)/g
const genDocsTasks = [];

const componentChanges = shelljs.exec('git status', {
  silent: true
}).stdout.match(componentChangeRegex);

if (componentChanges !== null) {
  componentChanges.forEach((file) => {
    genDocsTasks.push({
      title: `[CLEANING]: `.cyan + `${file}`,
      task: () => execa('./node_modules/.bin/rimraf', [`./apps/flame-documentation/src/assets/docs/${file.replace(filenameRegex, '')}/doc.json`])
    }, {
      title: `[GENERATING]: `.green + `${file}\n`,
      task: () => execa('./node_modules/.bin/typedoc', ['--mode', 'modules', file, '--json', `./apps/flame-documentation/src/assets/docs/${file.replace(filenameRegex, '')}/doc.json`, '--tsconfig', './tools/helpers/tsconfig.json', '--logger', 'none'])
    })
  })

  new Listr(genDocsTasks).run().catch(err => {
    console.error('[ERROR]: '.red, err);
  });
} else {
  console.log(`No changes in libraries.\n`.green);
}
