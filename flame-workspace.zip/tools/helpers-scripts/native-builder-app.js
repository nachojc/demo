const path = require('path')
const execa = require('execa');
const Listr = require('listr');
const fsExtra = require('fs-extra');

const tasks = new Listr([{
  title: 'Building SuperMobile',
  task: () => execa('ng', ['build', 'super-mobile', '--prod', '--base-href', '.', `--configuration=${process.argv[2]}`])
}, {
  title: 'Copying to Android Archetype',
  task: () => {
    fsExtra.copySync(path.normalize('./dist/apps/super-mobile'), path.normalize('../archetype-android/app/src/main/assets/www'));
  }
}, {
  title: 'Copying to iOS Archetype',
  task: () => {
    fsExtra.copySync(path.normalize('./dist/apps/super-mobile'), path.normalize('../archetype-ios/www'));
  }
}]);

tasks.run().catch(err => {
  console.error(err);
});
