const inquirer = require('inquirer');
const shelljs = require('shelljs');
inquirer
	.prompt([
		{
			type: 'rawlist',
			name: 'commitType',
			message: '¿Cual es tu tipo de contribución al repositorio?',
			choices: [
				'build',
				'chore',
				'docs',
				'feat',
				'fix',
				'perf',
				'refactor',
				'revert',
				'style',
				'test'
			]
		},
		{ name: 'commitScope', message: '¿A que afecta este commit?' },
		{ name: 'commitMessage', message: 'Añade un mensaje' }
	])
	.then(answers => {
    const commitMessage = `"${answers.commitType}(${answers.commitScope}): ${answers.commitMessage.toLowerCase()}"`;
		shelljs.exec(`git commit -m${commitMessage}`);
	});
