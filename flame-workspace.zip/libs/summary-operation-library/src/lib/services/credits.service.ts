import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { DatePipe } from '@angular/common';

/**
 * Servicio con las llamadas a los endpoints de Credits
 *
 */
@Injectable()
export class CreditsService {
	public dates: any;
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient,
		private _datePipe: DatePipe
	) {}
	/**
	 * Obtiene la url con la versión correcta del servicio dependiendo del enviroment
	 *
	 * @private
	 * @returns string - url_base + '/' + version + '/'
	 * @memberof CreditsService
	 */
	private getUrlVersion(accounts = false) {
		if (accounts) {
			return this.environment.api.version.accounts === ''
				? `${this.environment.api.url}/`
				: `${this.environment.api.url}/${
						this.environment.api.version.accounts
				  }/`;
		}
		return this.environment.api.version.credits === ''
			? `${this.environment.api.url}/`
			: `${this.environment.api.url}/${this.environment.api.version.credits}/`;
	}

	/**
	 * Crea el periodo de fechas para consultar las transacciones de una tdc
	 * de acuerdo con la fecha de corte de la tarjeta
	 *
	 * @private
	 * @param {string} period
	 * @param {Date} today
	 * @param {string} dueDate
	 * @returns {*}
	 * @memberof CreditsService
	 */
	private transformPeriodCredit(
		period: string,
		today: Date,
		dueDate: string
	): any {
		const dateDue = new Date(dueDate);
		let dateDueCopy = new Date(dueDate);
		switch (period) {
			case 'chip-2': // Corte ---> Hoy
				return {
					fromDate: this._datePipe.transform(
						dueDate,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					),
					toDate: this._datePipe.transform(today, 'yyyy-MM-ddTHH:mm:ss.SSSSSS')
				};
			case 'chip-3': // Corte - 1 mes ---> Corte - 1 dia
				dateDueCopy.setDate(dateDueCopy.getDate() - 1);
				return {
					fromDate: this._datePipe.transform(
						new Date(
							dateDue.getFullYear(),
							dateDue.getMonth() - 1,
							dateDue.getDate()
						),
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					),
					toDate: this._datePipe.transform(
						dateDueCopy,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					)
				};
			case 'chip-4': // Corte - 2 meses ---> Corte - 1 mes - dia
				dateDueCopy = new Date(
					dateDue.getFullYear(),
					dateDue.getMonth() - 1,
					dateDue.getDate()
				);
				dateDueCopy.setDate(dateDueCopy.getDate() - 1);
				return {
					fromDate: this._datePipe.transform(
						new Date(
							dateDue.getFullYear(),
							dateDue.getMonth() - 2,
							dateDue.getDate()
						),
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					),
					toDate: this._datePipe.transform(
						dateDueCopy,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					)
				};
			default:
				return {
					fromDate: 2,
					toDate: 2
				};
		}
	}

	/**
	 * Crea el periodo de fechas para consultar las transacciones de una cuenta
	 *
	 * @private
	 * @param {string} period
	 * @param {Date} fromDate
	 * @param {Date} toDate
	 * @returns {*}
	 * @memberof CreditsService
	 */
	private transformPeriod(period: string, fromDate: Date, toDate: Date): any {
		switch (period) {
			case 'chip-2':
				return {
					fromDate: new Date(fromDate.getFullYear(), fromDate.getMonth(), 1),
					toDate: new Date(toDate.getFullYear(), toDate.getMonth() + 1, 0)
				};
			case 'chip-3':
				return {
					fromDate: new Date(
						fromDate.getFullYear(),
						fromDate.getMonth() - 1,
						1
					),
					toDate: new Date(toDate.getFullYear(), toDate.getMonth(), 0)
				};
			case 'chip-4':
				return {
					fromDate: new Date(
						fromDate.getFullYear(),
						fromDate.getMonth() - 2,
						1
					),
					toDate: new Date(toDate.getFullYear(), toDate.getMonth() - 1, 0)
				};
			default:
				return {
					fromDate: fromDate,
					toDate: toDate
				};
		}
	}

	/**
	 * Obtiene el summary de credits con los datos que necesita
	 * el resumen de TDC
	 * Interfaz que implementa para la respuesta - `ResponseListCredits`
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getCredits(limit: string = '10') {
		const params = new HttpParams().set('limit', limit);
		return this._httpClient.get(`${this.getUrlVersion()}credits`, { params });
	}

	/**
	 * Obtiene el detalle de una TDC
	 * Interfaz que implementa para la respuesta - `CreditDetailResponse`
	 * @param key - Key de la TDC
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getCardDetail(key: string) {
		let headers = new HttpHeaders();
		headers = headers
					.set('authentication_method', 'adasdasasd')
					.set('authentication_value','jasdasdhas');
		return this._httpClient.get(`${this.getUrlVersion()}credits/${key}`, {
			headers: headers
		});
	}

	/**
	 * Obtiene los movimientos de una cuenta o de una TDC
	 * Interfaz que implementa para la respuesta - `TransactionsResponse`
	 *
	 * @param {string} key - Key de la TDC
	 * @param {string} [limit='5'] - Parametro opcional, por default = 5
	 * @param {boolean} isAccount - Indica si es una cuenta o una tdc
	 * @param {string} [cursor] - Cursor de paginación para obtener más
	 * @param {string} [period] - Periodo (actual, pasado, anterior)
	 * @param {string} [dueDate] - Fecha de corte de la tarjeta
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getTransactions(
		key: string,
		limit: string = '5',
		isAccount: boolean,
		cursor?: string,
		period?: string,
		dueDate?: string
	) {
		let params = new HttpParams().set('limit', limit);
		if (cursor !== undefined) {
			params = params.set('limit', limit);
		}
		if (period !== undefined && cursor !== undefined) {
			this.dates = isAccount
				? this.transformPeriod(period, new Date(), new Date())
				: this.transformPeriodCredit(period, new Date(), dueDate);
			if (isAccount) {
				params = params
					.set('limit', limit)
					.set('from_date', this.dates.fromDate.toISOString().slice(0, 10))
					.set('to_date', this.dates.toDate.toISOString().slice(0, 10))
					.set('cursor', cursor);
			}
		}
		return this._httpClient.get(
			isAccount
				? `${this.getUrlVersion(true)}accounts/${key}/transactions`
				: `${this.getUrlVersion()}credits/${key}/transactions`,
			{
				params: isAccount
					? params
					: {
							limit: limit,
							from_date: this.dates.fromDate,
							to_date: this.dates.toDate,
							cursor: cursor
					  }
			}
		);
	}

	/**
	 * Obtiene el detalla de un movimiento de una cuenta de debito
	 * Interfaz que implementa para la respuesta - `TransactionDetailResponse`
	 * @param {string} key
	 * @param {string} transactionKey
	 * @returns
	 * @memberof CreditsService
	 */
	getDebitTransactionDetail(key: string, transactionKey: string) {
		return this._httpClient.get(
			`${this.getUrlVersion(
				true
			)}accounts/${key}/transactions/${transactionKey}`
		);
	}

	/**
	 * Obtiene el detalle de un movimiento de una TDC
	 * Interfaz que implementa para la respuesta - `TransactionDetailResponse`
	 * @param key - Key de una TDC
	 * @param keyTrans - Key del movimiento a obtener
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getTransactionDetail(key: string, keyTrans: string) {
		return this._httpClient.get(
			`${this.getUrlVersion()}credits/${key}/transactions/${keyTrans}`
		);
	}
}
