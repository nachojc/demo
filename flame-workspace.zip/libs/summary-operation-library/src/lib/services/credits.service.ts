import { Injectable, Inject, Injector } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { DatePipe } from '@angular/common';
import { Platform } from '@angular/cdk/platform';

/**
 * Servicio con las llamadas a los endpoints de Credits
 *
 */
@Injectable()
export class CreditsService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
    private _datePipe: DatePipe,
    private _injector: Injector
	) {
    const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
  }

  private _httpClient: any;
	private _urlCredits = this.environment.baas.urlCredits;
	private _urlCards = this.environment.baas.urlCards;
	private _urlDebits = this.environment.baas.urlAccountSummary;
	private _urlDebitTransactions = this.environment.baas.urlTransactions;

	/**
	 * Crea las cabeceras de las peticiones de los servicios
	 *
	 * @returns HttpHeaders con las cabeceras necesarias
	 * @memberof CreditsService
	 */
	createAuthorizationHeader(): HttpHeaders {
		return new HttpHeaders({
			Authorization: 'Bearer',
			Accept: 'application/json'
		});
	}

	/**
	 * Obtiene el summary de credits con los datos que necesita
	 * el resumen de TDC
	 * Interfaz que implementa para la respuesta - `ResponseListCredits`
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getCredits() {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.get(this._urlCredits, {
			headers: headers
		});
	}

	/**
	 * Obtiene el summary de tarjetas de débito con los datos que necesita
	 * el resumen de TDD
	 * Interfaz que implementa para la respuesta - `ResponseListCredits`
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getDebits() {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.get(this._urlDebits, {
			headers: headers
		});
	}

	/**
	 * Obtiene el detalle de una TDC
	 * Interfaz que implementa para la respuesta - `CreditDetailResponse`
	 * @param key - Key de la TDC
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getCardDetail(key: string) {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.get(`${this._urlCredits}/${key}`, {
			headers: headers
		});
	}

	/**
	 * Obtiene los movimientos de una TDC
	 * Interfaz que implementa para la respuesta - `TransactionsResponse`
	 * @param key - Key de la TDC
	 * @param [limit] - Parametro opcional, por default = 5
	 * @param [cursor] - Cursor de paginación para obtener más
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getTransactions(
		key: string,
		limit: string = '5',
		cursor?: string,
		period?: string,
		dueDate?: string
	) {
		let headers = new HttpHeaders();
		let params = new HttpParams();
		params = new HttpParams().set('limit', limit);
		if (cursor !== undefined) {
			params = new HttpParams().set('limit', limit).set('cursor', cursor);
		}
		if (period !== undefined && cursor !== undefined) {
			const dates = this.transformPeriodCredit(period, new Date(), dueDate);
			params = new HttpParams()
				.set('limit', limit)
				.set('start_date', dates.fromDate)
				.set('​end_date', dates.toDate)
				.set('cursor', cursor);
		}
    headers = this.createAuthorizationHeader();
		return this._httpClient.get(`${this._urlCredits}/${key}/transactions`, {
			headers: headers,
			params: params
		});
	}

	getDebitTransactions(
		key: string,
		limit: string,
		cursor: string,
		period: string,
		dueDate?: string
	) {
		let headers = new HttpHeaders();
		let params = new HttpParams();

		const dates = this.transformPeriod(period, new Date(), new Date());

		if (cursor !== undefined) {
			params = new HttpParams()
				.set('limit', limit)
				.set('from_date', dates.fromDate.toISOString().slice(0, 10))
				.set('to_date', dates.toDate.toISOString().slice(0, 10))
				.set('cursor', cursor);
		}

		headers = this.createAuthorizationHeader();

		return this._httpClient.get(
			this._urlDebitTransactions + key + '/transactions',
			{ headers: headers, params: params }
		);
	}

	getDebitTransactionDetail(key: string, transactionKey: string) {
		let headers = new HttpHeaders();

		headers = this.createAuthorizationHeader();

		return this._httpClient.get(
			this._urlDebitTransactions + key + '/transactions/' + transactionKey,
			{ headers: headers }
		);
	}

	transformPeriodCredit(period: string, today: Date, dueDate: string): any {
		const dateDue = new Date(dueDate);
		let dateDueCopy = new Date(dueDate);

		switch (period) {
			case 'chip-2': // Corte ---> Hoy
				return {
					fromDate: this._datePipe.transform(
						dueDate,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					),
					toDate: this._datePipe.transform(today, 'yyyy-MM-ddTHH:mm:ss.SSSSSS')
				};
			case 'chip-3': // Corte - 1 mes ---> Corte - 1 dia
				dateDueCopy.setDate(dateDueCopy.getDate() - 1);
				return {
					fromDate: this._datePipe.transform(
						new Date(
							dateDue.getFullYear(),
							dateDue.getMonth() - 1,
							dateDue.getDate()
						),
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					),
					toDate: this._datePipe.transform(
						dateDueCopy,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					)
				};
			case 'chip-4': // Corte - 2 meses ---> Corte - 1 mes - dia
				dateDueCopy = new Date(
					dateDue.getFullYear(),
					dateDue.getMonth() - 1,
					dateDue.getDate()
				);
				dateDueCopy.setDate(dateDueCopy.getDate() - 1);
				return {
					fromDate: this._datePipe.transform(
						new Date(
							dateDue.getFullYear(),
							dateDue.getMonth() - 2,
							dateDue.getDate()
						),
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					),
					toDate: this._datePipe.transform(
						dateDueCopy,
						'yyyy-MM-ddTHH:mm:ss.SSSSSS'
					)
				};
			default:
				return {
					fromDate: 2,
					toDate: 2
				};
		}
	}

	transformPeriod(period: string, fromDate: Date, toDate: Date): any {
		switch (period) {
			case 'chip-2':
				return {
					fromDate: new Date(fromDate.getFullYear(), fromDate.getMonth(), 1),
					toDate: new Date(toDate.getFullYear(), toDate.getMonth() + 1, 0)
				};
			case 'chip-3':
				return {
					fromDate: new Date(
						fromDate.getFullYear(),
						fromDate.getMonth() - 1,
						1
					),
					toDate: new Date(toDate.getFullYear(), toDate.getMonth(), 0)
				};
			case 'chip-4':
				return {
					fromDate: new Date(
						fromDate.getFullYear(),
						fromDate.getMonth() - 2,
						1
					),
					toDate: new Date(toDate.getFullYear(), toDate.getMonth() - 1, 0)
				};
			default:
				return {
					fromDate: fromDate,
					toDate: toDate
				};
		}
	}

	/**
	 * Obtiene el detalle de un movimiento de una TDC
	 * Interfaz que implementa para la respuesta - `TransactionDetailResponse`
	 * @param key - Key de una TDC
	 * @param keyTrans - Key del movimiento a obtener
	 * @returns un `Observable` con la respuesta del servidor
	 * @memberof CreditsService
	 */
	getTransactionDetail(key: string, keyTrans: string) {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.get(
			`${this._urlCredits}/${key}/transactions/${keyTrans}`,
			{ headers: headers }
		);
	}

	getMovement(key: string, keyTrans: string) {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.get(
			`${this._urlCards}${key}/transactions/${keyTrans}`, // Agregar diagonal con _urlCredits
			{ headers: headers }
		);
	}
}
