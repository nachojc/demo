import {
  Injectable,
  Inject,
  Injector
} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { Platform } from '@angular/cdk/platform';

@Injectable()
export class AccountsService {
	constructor(
    @Inject(ENV_CONFIG) private environment: any,
    private _injector: Injector
  ) {
    const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
  }

  private _httpClient: any;
	private _urlTransactions = this.environment.baas.urlTransactions;

	createAuthorizationHeader() {
		return new HttpHeaders({
			Authorization: '79274258',
			'Content-Type': 'application/json',
			Accept: 'application/json'
		});
	}


	getTransactions(key: string, limit?: string) {
		let headers = new HttpHeaders();
		let params = new HttpParams();
		if (limit !== undefined) {
			params = new HttpParams().set('limit', limit);
		}

		headers = this.createAuthorizationHeader();

		return this._httpClient.get(
			this._urlTransactions + key + '/transactions',
			{ headers: headers, params: params }
		);
	}

	getDetail(key: string) {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();

		return this._httpClient.get(this._urlTransactions + key, {
			headers: headers
		});
  }

  getTransactionDetailAccount(keyCard: string, keyTrans: string, limit?: string) {
		let headers = new HttpHeaders();

		headers = this.createAuthorizationHeader();

		return this._httpClient.get(
			this._urlTransactions + keyCard + '/transactions/' + keyTrans,
			{ headers: headers }
		);
	}

	associatedPhone(key:string, param:object) {
		let headers = new HttpHeaders();
		let params = new HttpParams();
    params = new HttpParams()
      .set('operation-type', param['operation-type'])
      .set('phone_number', param['phone_number'])
			.set('company', param['company']);

		headers = this.createAuthorizationHeader();

		return this._httpClient.put(
			this._urlTransactions + key + '/associated-phone',
			{ headers: headers, params: params }
		);
	}
}
