import { Injectable, Inject, EventEmitter } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { ENV_CONFIG } from '@santander/flame-core-library';
import {
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { InvalidOperationComponent } from '../components/invalid-operation/invalid-operation.component';

@Injectable()
export class AccountsService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient,
		private dialog: DialogService
	) {}

	private dialogRef: DialogReference;
	public closeEventSlide = new EventEmitter<boolean>();

	/**
	 * Obtiene la url con la versión correcta del servicio dependiendo del enviroment
	 *
	 * @private
	 * @returns string - url_base + '/' + version + '/'
	 * @memberof AccountsService
	 */
	private getUrlVersion() {
		return this.environment.api.version.accounts === ''
			? `${this.environment.api.url}/`
			: `${this.environment.api.url}/${this.environment.api.version.accounts}/`;
	}

	/**
	 * Obtiene el detalle de una cuenta de débito mediante su key
	 *
	 * @param {string} key
	 * @returns
	 * @memberof AccountsService
	 */
	getDetail(key: string) {
		let headers = new HttpHeaders();
		headers = headers
					.set('authentication_method', 'adasdasasd')
					.set('authentication_value','jasdasdhas');
		return this._httpClient.get(`${this.getUrlVersion()}accounts/${key}`, {
			headers: headers
		});
	}

	/**
	 * Asocia un telefono a una cuenta de débito
	 *
	 * @param {string} key
	 * @param {*} requestBody
	 * @returns
	 * @memberof AccountsService
	 */
	associatedPhone(key: string, requestBody: any) {
		return this._httpClient.put(
			`${this.getUrlVersion()}accounts/${key}/associated-phone`,
			requestBody
		);
	}

	/**
	 * Muestra un mensaje de error en un dialogo cuando el servicio lo tenga.
	 *
	 * @param {*} titleDialog
	 * @param {string} title
	 * @param {string} message
	 * @param {string} url
	 * @memberof AccountsService
	 */
	showErrorDialog(titleDialog, title: string, message: string, url: string) {
		this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: titleDialog,
				enableHr: true,
				disabledButton: true,
				closeBackdropClick: true,
				buttons: [
					{
						class: 'strech',
						label: 'Aceptar',
						action: scope => {
							this.dialogRef.close();
						}
					}
				]
			},
			new CustomDialog(InvalidOperationComponent, {
				titleInvalid: title,
				message: message,
				url: url
			})
		);
	}
}
