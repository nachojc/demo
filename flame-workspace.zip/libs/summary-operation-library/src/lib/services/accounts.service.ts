import {
  Injectable,
  Inject
} from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ENV_CONFIG } from '@santander/flame-core-library';

@Injectable()
export class AccountsService {
	constructor(
    @Inject(ENV_CONFIG) private environment: any,
    private _httpClient: HttpClient
  ) { }

	getTransactions(key: string, limit?: string) {
    const params = new HttpParams()
      .set('limit', limit ? limit : '20');

		return this._httpClient.get(`${this.environment.api.url}/accounts/${key}/transactions`, {
      params: params
    });
	}

	getDetail(key: string) {
		return this._httpClient.get(`${this.environment.api.url}/accounts/${key}`);
  }

  getTransactionDetailAccount(keyCard: string, keyTrans: string, limit?: string) {
    const params = new HttpParams()
      .set('limit', limit ? limit : '10');

		return this._httpClient.get(`${this.environment.api.url}/accounts/${keyCard}/transactions/${keyTrans}`, {
      params: params
    });
	}

	associatedPhone(key:string, param:object) {
		const params = new HttpParams()
      .set('operation-type', param['operation-type'])
      .set('phone_number', param['phone_number'])
			.set('company', param['company']);

		return this._httpClient.put(`${this.environment.api.url}/accounts/${key}/associated-phone`, {
      params: params
    });
	}
}
