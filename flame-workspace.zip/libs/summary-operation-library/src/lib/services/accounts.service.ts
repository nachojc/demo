import { Injectable, Inject, EventEmitter } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ENV_CONFIG } from '@santander/flame-core-library';
import {
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { InvalidOperationComponent } from '../components/invalid-operation/invalid-operation.component';

@Injectable()
export class AccountsService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient,
    private dialog: DialogService
	) {}

  private dialogRef: DialogReference;
  public closeEventSlide = new EventEmitter<boolean>();

	getTransactions(key: string, limit?: string) {
		const params = new HttpParams().set('limit', limit ? limit : '20');

		return this._httpClient.get(
			`${this.environment.api.url}/accounts/${key}/transactions`,
			{
				params: params
			}
		);
	}

	getDetail(key: string) {
		return this._httpClient.get(`${this.environment.api.url}/accounts/${key}`);
	}

	getTransactionDetailAccount(
		keyCard: string,
		keyTrans: string,
		limit?: string
	) {
		const params = new HttpParams().set('limit', limit ? limit : '10');

		return this._httpClient.get(
			`${
				this.environment.api.url
			}/accounts/${keyCard}/transactions/${keyTrans}`,
			{
				params: params
			}
		);
	}

	associatedPhone(key: string, requestBody: any) {
		return this._httpClient.put(
			`${this.environment.api.url}/accounts/${key}/associated-phone`,
			requestBody
		);
	}

	showErrorDialog(titleDialog, title: string, message: string, url: string) {
		this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: titleDialog,
				enableHr: true,
				disabledButton: true,
				closeBackdropClick: true,
				buttons: [
					{
						class: 'strech',
						label: 'Aceptar',
						action: scope => {
							this.dialogRef.close();
						}
					}
				]
			},
			new CustomDialog(InvalidOperationComponent, {
				titleInvalid: title,
				message: message,
				url: url
			})
		);
	}
}
