import {
  Injectable,
  Inject,
  Injector
} from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { Platform } from '@angular/cdk/platform';

@Injectable()
export class AccountsService {
	constructor(
    @Inject(ENV_CONFIG) private environment: any,
    private _injector: Injector
  ) {
    const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
  }

  private _httpClient: any;
	private _urlTransactions = this.environment.baas.urlTransactions;

	getTransactions(key: string, limit?: string) {
    const params = new HttpParams()
    .set('limit', limit ? limit : '20');

		return this._httpClient.get(
			this._urlTransactions + key + '/transactions',
			{ params: params }
		);
	}

	getDetail(key: string) {
		return this._httpClient.get(this._urlTransactions + key);
  }

  getTransactionDetailAccount(keyCard: string, keyTrans: string, limit?: string) {
		return this._httpClient.get(
			this._urlTransactions + keyCard + '/transactions/' + keyTrans
		);
	}

	associatedPhone(key:string, param:object) {
		let params = new HttpParams();
    params = new HttpParams()
      .set('operation-type', param['operation-type'])
      .set('phone_number', param['phone_number'])
			.set('company', param['company']);

		return this._httpClient.put(
			this._urlTransactions + key + '/associated-phone',
			{params: params }
		);
	}
}
