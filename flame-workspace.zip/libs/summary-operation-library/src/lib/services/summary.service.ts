import {
  Injectable,
  Inject,
  Injector
} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { Platform } from '@angular/cdk/platform';

/**
 * Servicio con las llamadas a los endpoints de Summary
 *
 */
@Injectable()
export class SummaryService {
	constructor(
    @Inject(ENV_CONFIG) private environment: any,
    private _injector: Injector
  ) {
    const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
  }

  private _httpClient: any;
	private _urlSummary = this.environment.baas.urlSummary;

	/**
   * Crea las cabeceras de las peticiones de los servicios
   *
   * @returns HttpHeaders con las cabeceras necesarias
   * @memberof SummaryService
   */
  createAuthorizationHeader() {
		return new HttpHeaders({
			Authorization: '79274258',
			'Content-Type': 'application/json',
			Accept: 'application/json'
		});
	}

	/**
   * Obtiene el summary de productos, con cuentas, tarjetas, etc
   * Interfaz que implemente para la respuesta `SummaryResponse`
   * @returns
   * @memberof SummaryService
   */
  getSummary() {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();

		return this._httpClient.get(this._urlSummary, { headers: headers });
  }

  	/**
   * Obtiene el tipo de usuario para el modal de contacto.
   * Type: 1 (Superlínea)
   * Type: 2 (Superlínea Select)
   * Type: 3 (Superlínea Private Banking)
   * @returns
   * @memberof SummaryService
   */
  getUserType() {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();

		return this._httpClient.get(this._urlSummary + '/user', { headers: headers });
	}

}
