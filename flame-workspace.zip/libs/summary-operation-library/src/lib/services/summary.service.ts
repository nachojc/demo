import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ENV_CONFIG } from '@santander/flame-core-library';

/**
 * Servicio con las llamadas a los endpoints de Summary
 *
 */
@Injectable()
export class SummaryService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient
	) {}
	/**
	 * Obtiene el summary de productos, con cuentas, tarjetas, etc
	 * Interfaz que implemente para la respuesta `SummaryResponse`
	 * @returns
	 * @memberof SummaryService
	 */
	getSummary(page?: number, limit?: number) {
		const params = new HttpParams()
			.set('page', page ? page.toString() : '1')
			.set('limit', limit ? limit.toString() : '10');
		return this._httpClient.get(this.environment.api.url + '/summary', {
			params: params
		});
	}

	/**
	 * Obtiene el tipo de usuario para el modal de contacto.
	 * Type: 1 (Superlínea)
	 * Type: 2 (Superlínea Select)
	 * Type: 3 (Superlínea Private Banking)
	 * @returns
	 * @memberof SummaryService
	 */
	getUserType() {
		return this._httpClient.get(
			this.environment.api.url + '/summary' + '/user'
		);
	}
}
