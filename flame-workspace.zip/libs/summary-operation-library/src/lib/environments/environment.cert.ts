export const environment = {
	production: false,
	certification: true,
	idp: {
		url: 'http://localhost:3000/IDPWeb/idp/',
		urlRSA: 'http://localhost:3000/IDPWeb/idp/',
		urlSign: 'http://localhost:3000/IDPWeb/idp/',
		urlRSASign: 'http://localhost:3000/IDPWeb/idp/'
	},
	baas: {
		urlSummary: 'http://localhost:3000/summaryBaas',
		urlTransactions: 'http://localhost:3000/accounts/',
		urlCredits:	'http://localhost:3000/credits',
    urlCards: 'http://localhost:3000/cards/',
    urlTransfersSameBank: 'http://localhost:3000/transfers/'
	}
};
