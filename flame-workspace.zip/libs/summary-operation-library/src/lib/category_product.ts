// TODO: Modificar CHECKING_ACCOUNTS_USD y agregar las que falten
export const category_names = {
	"CHECKING_ACCOUNTS": "Cuentas de débito",
	"CHECKING_ACCOUNTS_USD": "Cuentas en dólares",
	"CREDIT_CARDS": "Tarjetas de crédito"
};
