// TODO: Modificar CHECKING_ACCOUNTS_USD y agregar las que falten
export const categoryNames = {
	CHECKING_ACCOUNTS: 'Cuentas de débito',
	CHECKING_ACCOUNTS_USD: 'Cuentas en dólares',
	CREDIT_CARDS: 'Tarjetas de crédito',
	GROWING_MONEY: 'Dinero creciente'
};

export const PHONECOMPANIES = [
	{
		id: 1,
		value: 'Telcel'
	},
	{ id: 2, value: 'Movistar' },
	{ id: 3, value: 'AT&T' },
	{ id: 4, value: 'Unefon' },
	{ id: 5, value: 'Iusacel' },
	{ id: 6, value: 'Flash Mobile' },
	{ id: 7, value: 'Virgin Mobile' },
	{ id: 8, value: 'Nextel' },
	{ id: 9, value: 'Weex' },
	{ id: 10, value: 'No cuento con la compañía' }
];
