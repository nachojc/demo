/* tslint:disable */
import { Money } from './money';
export interface AccountTransactionsList {

  /**
   * Date when the transfer was made by the customer. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html).
   */
  creation_date?: string;

  /**
   * The amount of the transaction made by the customer.
   */
  amount?: Money;

  /**
   * Description of the transaction. Could indicates the reason of the transaction.
   */
  description?: string;
}
