/* tslint:disable */
import { Money } from './money';
import { ProductsFront } from './products.front';

export interface ProductsCardFront extends ProductsFront {
	/**
	 * Function of the card when touched
	 */
	action?: (i: number, slider: any) => void;

	/**
	 * Position of the card in the card slider
	 */
	position?: string;

	/**
	 * State of the card, indicates if the card was touched
	 */
	flipped?: boolean;

	/**
	 * Shows the determined amount that corresponds to the fixed payment.
	 */
	minimum_payment?: Money;

	/**
	 * This date specifies the last day for the monthly required payment
	 */
	due_date?: string;

	/**
	 * Shows the amount of the payment to not generate interest.
	 */
	statement_balance?: Money;
}
