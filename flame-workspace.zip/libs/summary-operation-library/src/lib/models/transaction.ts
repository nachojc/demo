/* tslint:disable */
import { Money } from './money';

/**
 * Transaction object for the transactions list. Contains the information of a transaction made the customer
 */
export interface Transaction {
	/**
	 * This Key uniquely identifies the transaction.
	 */
	key?: string;

	/**
	 * Anonymized origin account number
	 */
	display_number?: string;

	/**
	 * Date when the transfer was made by the customer. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html).
	 */
	creation_date?: string;

	/**
	 * Transaction detail, could indicate the reason of the transaction.
	 */
	description?: string;

	/**
	 * Transaction amount.
	 */
	amount?: Money;

	/**
	 * Date when the transfer was posted. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html).
	 */
	posted_date?: string;
}
