/* tslint:disable */
import { Money } from './money';

/**
 * Transaction object for the transactions list. Contains the information of a transaction made the customer
 */
export interface Transaction {

  /**
   * This transaction unique identifier
   */
  key?: string;

  /**
   * Origin  of the transaction, could be the business name where the transaction was made.
   */
  transaction_origin?: string;

  /**
   * Date when the transfer was made by the customer.  [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html).
   */
  creation_date?: string;

  /**
   * Date when the transfer was posted. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html).
   */
  posted_date?: string;

  /**
   * Url for the transaction detail
   */
  url?: string;

  /**
   * Retrieved the amount of the transaction. Expense or income symbol (+ in green / - in red)
   */
  amount?: Money;
}
