/* tslint:disable */
import { RelatedPhoneInfoResponse } from './related-phone-info-response';
export interface RelatedPhoneResponse {
  data?: RelatedPhoneInfoResponse;
}
