/* tslint:disable */
import { CreditDetail } from './credit-detail';
import { NotificationWrapper } from './notification-wrapper';
export interface CreditDetailResponse {
  data?: CreditDetail;
  notifications?: Array<NotificationWrapper>;
}
