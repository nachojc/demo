/* tslint:disable */
import { Product } from './product';
export interface RelatedCard {

  /**
   * Number of the related card to the account
   */
  number?: string;
  product?: Product;

  /**
   * The expiration date off the related card
   */
  expiration_date?: string;
}
