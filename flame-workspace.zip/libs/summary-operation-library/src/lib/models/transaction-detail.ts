/* tslint:disable */
import { Transaction } from './transaction';
export interface TransactionDetail extends Transaction {

  /**
   * This card number belongs to the card which was used in the banking operation
   */
  card_number?: string;

  /**
   * Description of the transaction. Could indicates the reason of the transaction.
   */
  description?: string;

  /**
   * Number identifier of the movement provided by the customer
   */
  reference?: string;
}
