/* tslint:disable */
import { Transaction } from './transaction';
import { Money } from './money';
export interface TransactionDetail extends Transaction {

  /**
   * Number that identifies this transaction.
   */
  number?: string;
  account?: {related_card?: string, running_balance?: Money};

  /**
   * Origin of the transaction, could indicate the branch or business where the transaction was made.
   */
  transaction_origin?: string;

  /**
   * Identifier of the movement provided by the customer.
   */
  reference?: string;

  /**
   * Identifier of the movement provided by the bank.
   */
  tracking_number?: number;
}
