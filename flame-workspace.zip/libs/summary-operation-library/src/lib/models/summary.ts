/* tslint:disable */
import { Money } from './money';
import { Products } from './products';

/**
 * Basic information about the contracted products of a customer
 */
export interface Summary {

  /**
   * Name of the category which classify the products according to the type of financial product.
   */
  category_name?: string;

  /**
   * The sum of all product balances in this category
   */
  total_balance?: Money;
  products?: Array<Products>;
}
