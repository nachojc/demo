/* tslint:disable */
import { Product } from './product';
import { RelatedCard } from './related-card';
import { Money } from './money';
import { AccountTransactionsList } from './account-transactions-list';
export interface AccountDetail {

  /**
   * This Key uniquely identifies account.
   */
  key?: string;

  /**
   * Account number
   */
  number?: string;

  /**
   * Alias account given by the customer. The Alias is usually use by the customers to identify easily their accounts
   */
  alias?: string;

  /**
   * Account product
   */
  product?: Product;

  /**
   * Number use by the customer to receive a SPEI transfer.
   */
  clabe?: string;

  /**
   * Related debit card to the account.
   */
  related_card?: RelatedCard;

  /**
   * The mobile phone related to the account
   */
  related_phone?: {phone_number?: string, company?: string};

  /**
   * Current balance of the account, shows the available money into the account
   */
  balance?: Money;

  /**
   * Shows a list of the latest transactions made by the customer into the account.
   */
  latest_transactions?: Array<AccountTransactionsList>;
}
