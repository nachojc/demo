/* tslint:disable */
import { AccountDetail } from './account-detail';
import { NotificationWrapper } from './notification-wrapper';
export interface AccountDetailResponse {
  data?: AccountDetail;
  notifications?: Array<NotificationWrapper>;
}
