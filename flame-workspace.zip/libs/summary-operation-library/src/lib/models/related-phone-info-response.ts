/* tslint:disable */
export interface RelatedPhoneInfoResponse {

  /**
   * The account unique identifier
   */
  account_key?: string;

  /**
   * The phone number associated to the account
   */
  phone_number?: string;

  /**
   * Date when the association was made by the customer. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html).
   */
  operation_date?: string;

  /**
   * The phone company of the associated number
   */
  company?: string;

  /**
   * Reference number associated to the account
   */
  reference?: number;
}
