/* tslint:disable */
export interface Card {

  /**
   * The anonymized number of the related card to the credit line
   */
  display_number?: string;

  /**
   * The relation type between the credit line and the related card
   */
  relation_type?: string;

  /**
   * The expiration date of the related card with the following format MM/YY
   */
  expiration_date?: string;

  /**
   * The URL for the next step in the user experience
   */
  url?: string;
}
