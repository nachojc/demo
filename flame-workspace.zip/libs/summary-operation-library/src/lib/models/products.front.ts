/* tslint:disable */
import { Products } from './products';

export interface ProductsFront extends Products {
	/**
	 * Name of the category of the product
	 */
	category_name?: string;

	/**
	 * Type of card svg
	 */
	type?: string;

	/**
	 * Url of the asset image of the card
	 */
	image?: string;

}
