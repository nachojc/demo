/* tslint:disable */
import { TransactionDetail } from './transaction-detail';
import { NotificationWrapper } from './notification-wrapper';
export interface ResponseDetailTransactions {
  data?: TransactionDetail;
  notifications?: Array<NotificationWrapper>;
}
