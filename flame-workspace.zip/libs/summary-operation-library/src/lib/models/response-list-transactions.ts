/* tslint:disable */
import { Transaction } from './transaction';
import { NotificationWrapper } from './notification-wrapper';
import { Cursor } from './cursor';
export interface ResponseListTransactions {
  data?: Array<Transaction>;
  notifications?: Array<NotificationWrapper>;
  paging?: Cursor;
}
