/* tslint:disable */
import { Account } from './account';
import { NotificationWrapper } from './notification-wrapper';
import { Cursor } from './cursor';
export interface AccountListResponse {
  data?: Array<Account>;
  notifications?: Array<NotificationWrapper>;
  paging?: Cursor;
}
