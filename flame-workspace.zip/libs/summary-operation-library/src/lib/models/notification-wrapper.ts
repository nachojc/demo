/* tslint:disable */
export interface NotificationWrapper {

  /**
   * Code to identify the notification and classify according the first character (E) Error ,(W) Warning,(I) Info.
   */
  code?: string;

  /**
   * Notification message  for display to the customer.
   */
  message?: string;

  /**
   * [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html)Date and time when the notification is done
   */
  timestamp?: string;
}
