/* tslint:disable */
import { TransactionDetail } from './transaction-detail';
import { NotificationWrapper } from './notification-wrapper';
export interface TransactionDetailResponse {
  data?: TransactionDetail;
  notifications?: Array<NotificationWrapper>;
}
