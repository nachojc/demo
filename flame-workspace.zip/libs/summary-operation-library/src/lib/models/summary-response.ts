/* tslint:disable */
import { Summary } from './summary';
import { NotificationWrapper } from './notification-wrapper';
import { Cursor } from './cursor';
export interface SummaryResponse {
  data?: Array<Summary>;
  notifications?: Array<NotificationWrapper>;
  paging?: Cursor;
}
