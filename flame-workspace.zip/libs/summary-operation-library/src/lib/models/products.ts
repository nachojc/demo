/* tslint:disable */
import { Money } from './money';
export interface Products {

  /**
   * This key uniquely identifies this product.
   */
  key?: string;

  /**
   * Alias given by the customer. The alias is used by the customer to easily identify its products.
   */
  alias?: string;

  /**
   * Description of the customer product.
   */
  description?: string;

  /**
   * The URL of the referred product.
   */
  url?: string;

  /**
   * The URL for the product image.
   */
  image_url?: string;

  /**
   * Anonymized number of the product contracted by the customer
   */
  display_number?: string;

  /**
   * Related phone to the product. This is usually used when a customer wants to receive a transfer using his phone number as a transfer target.
   */
  related_phone?: string;

  /**
   * Current product status. Refers to the actual state of the customer contracted product. AVAILABLE: Means that the product its currently available or active. BLOCKED: Means that the product is currently blocked or suspended. CLOSED: Means that the product is currently closed or not available.
   */
  status?: 'AVAILABLE' | 'BLOCKED' | 'CLOSED';

  /**
   * This is the main balance used for the type of product. This type of balance varies across products but within each product class this field should represent the same information. For example, the primary balance for a loan product is the outstanding loan value, but it is the total balance for a deposit account.
   */
  balance?: Money;
}
