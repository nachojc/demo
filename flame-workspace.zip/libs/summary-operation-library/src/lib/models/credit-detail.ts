/* tslint:disable */
import { Credit } from './credit';
import { Money } from './money';
import { Transaction } from './transaction';
export interface CreditDetail extends Credit {

  /**
   * This date specifies the last day of your billing cycle for your credit line
   */
  statement_date?: string;

  /**
   * Shows the available money into the credit card.
   */
  available_credit?: Money;

  /**
   * Credit limit granted by the financial institution.
   */
  credit_limit?: Money;

  /**
   * Indicates the monthly payment which the customer has to make once an agreement with the financial institution its accomplish.
   */
  fixed_payment?: Money;

  /**
   * Retrieved a list of the latest transactions made by the customer into the card.
   */
  latest_transactions?: Array<Transaction>;
}
