/* tslint:disable */
export interface Product {

  /**
   * Refers to the type of product contracted by the customer
   */
  type?: string;

  /**
   * Shows a detailed  description for this product.
   */
  description?: string;
}
