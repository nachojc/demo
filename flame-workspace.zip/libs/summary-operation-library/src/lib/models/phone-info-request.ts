/* tslint:disable */
export interface PhoneInfoRequest {

  /**
   * The operation to be performed by the customer
   */
  "operation-type"?: 'ASSOCIATE' | 'MODIFY' | 'DISSOCIATE';

  /**
   * The phone number associated to the account
   */
  phone_number?: string;

  /**
   * The phone company of the associated number
   */
  company?: string;
}
