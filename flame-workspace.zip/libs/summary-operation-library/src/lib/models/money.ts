/* tslint:disable */

/**
 * Money
 * Fields that represent money, must to follow this structure:
 */
export interface Money {

  /**
   * Amount - number
   */
  amount?: number;

  /**
   * Currency codes - ISO 4217
   */
  currency_code?: string;
}
