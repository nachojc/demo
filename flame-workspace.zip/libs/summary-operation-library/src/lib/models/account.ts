/* tslint:disable */
import { Money } from './money';

/**
 * Account object for the accounts list. Contains the basic information of an account
 */
export interface Account {

  /**
   * This Key uniquely identifies this account.
   */
  key?: string;

  /**
   * Anonymized account number
   */
  display_number?: string;

  /**
   * Alias account given by the customer. The Alias is usually use by the customers to identify easily their accounts
   */
  alias?: string;

  /**
   * Url to the next call in order to obtain the detailed information of the account
   */
  url?: string;

  /**
   * Current balance of the account, shows the available money into the account
   */
  balance?: Money;
}
