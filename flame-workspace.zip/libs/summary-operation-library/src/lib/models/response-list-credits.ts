/* tslint:disable */
import { Credit } from './credit';
import { NotificationWrapper } from './notification-wrapper';
import { Cursor } from './cursor';
export interface ResponseListCredits {
  data?: Array<Credit>;
  notifications?: Array<NotificationWrapper>;
  paging?: Cursor;
}
