/* tslint:disable */
import { NotificationWrapper } from './notification-wrapper';
export interface EmptyDataResponse {
  data?: string;
  notifications?: Array<NotificationWrapper>;
}
