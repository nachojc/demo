/* tslint:disable */
import { Transaction } from './transaction';
import { NotificationWrapper } from './notification-wrapper';
import { Cursor } from './cursor';
export interface TransactionsResponse {
  data?: Array<Transaction>;
  notifications?: Array<NotificationWrapper>;
  paging?: Cursor;
}
