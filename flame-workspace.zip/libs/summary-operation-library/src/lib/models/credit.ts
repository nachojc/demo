/* tslint:disable */
import { Money } from './money';
import { Card } from './card';

/**
 * Credit object for the credit lines list. Contains the basic information of an credit line
 */
export interface Credit {

  /**
   * This is a unique identifier for the credit line.
   */
  key?: string;

  /**
   * The name of the credit line product
   */
  name?: string;

  /**
   * Alias given by the customer. The Alias is usually use by the customers to identify easily their cards
   */
  alias?: string;

  /**
   * Shows the credit line status could be ACTIVE, BLOCKED, SUSPENDED, etc
   */
  status?: 'ACTIVE' | 'INACTIVE' | 'SUSPENDED' | 'BLOCKED';

  /**
   * Indicates the current balance of the credit line
   */
  balance?: Money;
  related_cards?: Array<Card>;

  /**
   * Shows the determined amount that corresponds to the fixed payment.
   */
  minimum_payment?: Money;

  /**
   * This date specifies the last day for the monthly required payment
   */
  due_date?: string;

  /**
   * The URL for the next step in the user experience
   */
  url?: string;

  /**
   * Shows the amount of the payment to not generate interest.
   */
  statement_balance?: Money;
}
