export interface ImageRSA {
	altText: string;
	data: string;
	path: string;
}
