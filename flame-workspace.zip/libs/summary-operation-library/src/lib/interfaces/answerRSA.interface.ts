export interface AnswerRSA {
	text: {
		name: string;
		value: string;
	};
}
