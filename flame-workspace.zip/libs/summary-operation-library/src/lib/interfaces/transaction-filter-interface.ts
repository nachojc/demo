
export interface TransactionFilter {
	income: boolean;
	expense: boolean;
	pending: boolean;
}
