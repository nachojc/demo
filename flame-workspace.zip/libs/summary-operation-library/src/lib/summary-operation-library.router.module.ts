import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SummaryViewComponent } from './views/summary-view/summary-view.component';
import { AccountSummaryViewComponent } from './views/account-summary-view/account-summary-view.component';
import { AccountDetailViewComponent } from './views/account-detail-view/account-detail-view.component';
import { CreditCardSummaryViewComponent } from './views/credit-card-summary-view/credit-card-summary-view.component';
import { CreditCardDetailViewComponent } from './views/credit-card-detail-view/credit-card-detail-view.component';
import { RelatePhoneViewComponent } from './views/relate-phone-view/relate-phone-view.component';
import { RelatePhoneSuccessViewComponent } from './views/relate-phone-success-view/relate-phone-success-view.component';
import { CreditCardMoneyViewComponent } from './views/credit-card-money-view/credit-card-money-view.component';
import { CreditCardVoucherViewComponent } from './views/credit-card-voucher-view/credit-card-voucher-view.component';


const routes: Routes = [
	{
		path: 'global-position',
		component: SummaryViewComponent
	},
	{
		path: 'account-summary',
		component: AccountSummaryViewComponent
	},
	{
		path: 'account-detail',
		component: AccountDetailViewComponent
  	},
	{
		path: 'credit-card-summary',
		component: CreditCardSummaryViewComponent
	},
	{
		path: 'credit-card-detail',
		component: CreditCardDetailViewComponent
	},
	{
		path: 'credit-card-money',
		component: CreditCardMoneyViewComponent
	},
	{
		path: 'credit-card-voucher',
		component: CreditCardVoucherViewComponent
	},
	{
		path: 'relate-phone',
		component: RelatePhoneViewComponent
	},
	{
		path: 'relate-success',
		component: RelatePhoneSuccessViewComponent
	}
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class SummaryOperationLibraryRoutingModule {}
