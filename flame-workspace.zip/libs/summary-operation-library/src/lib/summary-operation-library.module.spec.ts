import { async, TestBed } from '@angular/core/testing';
import { SummaryOperationLibraryModule } from './summary-operation-library.module';

describe('SummaryOperationLibraryModule', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [SummaryOperationLibraryModule]
		}).compileComponents();
	}));

	it('should create', () => {
		expect(SummaryOperationLibraryModule).toBeDefined();
	});
});
