import { Component, OnInit } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';

@Component({
  selector: 'sm-dialog-disposition',
  templateUrl: './dialog-disposition.component.html',
  styleUrls: ['./dialog-disposition.component.scss']
})
export class DialogDispositionComponent implements OnInit, CustomDialogComponent {

  public data: any;
  public quantity: string;
  public credit: any = {};
  public account: any = {};


  ngOnInit() {
    this.quantity = this.data.quantity;
    this.account = this.data.account;
    this.credit = this.data.credit;
  }
}
