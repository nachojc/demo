import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DialogModule, CapitalizeModule } from '@santander/flame-component-library';
import { DialogDispositionComponent } from './dialog-disposition.component';

describe('DialogDispositionComponent', () => {
	let component: DialogDispositionComponent;
	let fixture: ComponentFixture<DialogDispositionComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [DialogDispositionComponent],
			imports: [DialogModule, CapitalizeModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogDispositionComponent);
		component = fixture.componentInstance;
		component.data = { quantity: '1220', account: {key: '2131', description: 'ed'}, credit: {key: '234', product: { description: '33'}}};
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});