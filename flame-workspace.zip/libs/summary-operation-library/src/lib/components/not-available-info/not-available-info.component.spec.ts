/*
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NotAvailableInfoComponent } from './not-available-info.component';


describe('NotAvailableInfoComponent', () => {
  let component: NotAvailableInfoComponent;
  let fixture: ComponentFixture<NotAvailableInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotAvailableInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotAvailableInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
*/
