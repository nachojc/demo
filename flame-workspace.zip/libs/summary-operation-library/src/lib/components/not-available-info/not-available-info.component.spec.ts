import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EmojiModule } from '@santander/flame-component-library';
import { NotAvailableInfoComponent } from './not-available-info.component';


describe('NotAvailableInfoComponent', () => {
  let component: NotAvailableInfoComponent;
  let fixture: ComponentFixture < NotAvailableInfoComponent > ;

  beforeEach(async (() => {
    TestBed.configureTestingModule({
        imports: [EmojiModule],
        declarations: [NotAvailableInfoComponent]
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotAvailableInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should noPadding in componente', () => {
    expect(component.noPadding).toBeFalsy();
  });

  it('should size in componente', () => {
    expect(component.size).toBe('small');
  });

  it('should noPadding in componente, changing value', () => {
    component.noPadding = false
    expect(component.noPadding).toBeFalsy();
  });

  it('should size in componente, changing value', () => {
    component.size = 'small'
    expect(component.size).toBe('small');
  });
});
