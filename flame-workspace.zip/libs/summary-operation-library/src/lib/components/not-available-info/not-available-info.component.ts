import { Component, Input } from '@angular/core';

@Component({
	selector: 'sm-not-available-info',
	templateUrl: './not-available-info.component.html',
	styleUrls: ['./not-available-info.component.scss']
})
export class NotAvailableInfoComponent {
  @Input()
  public noPadding = false;
  @Input()
  public size = 'small';

	constructor() {}
}
