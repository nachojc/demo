import { Component, Input } from '@angular/core';

@Component({
	selector: 'sm-not-available-info',
	templateUrl: './not-available-info.component.html',
	styleUrls: ['./not-available-info.component.scss']
})
export class NotAvailableInfoComponent {
	/**
	 * Crea una instancia de NotAvailableInfoComponent.
	 * @memberof NotAvailableInfoComponent
	 */
	constructor() {}

	/**
	 * Activa si se muestra el componente el la pantalla requerida
	 * @memberof NotAvailableInfoComponent
	 */
	@Input()
	public noPadding = false;

	/**
	 * @memberof NotAvailableInfoComponent
	 */
	@Input()
	public urlImg: string;

	/**
	 * variable para el titulo
	 *
	 * @type {string}
	 * @memberof NotAvailableInfoComponent
	 */
	@Input() title: string;

	/**
	 * variable para el mensaje de error
	 *
	 * @type {string}
	 * @memberof NotAvailableInfoComponent
	 */
	@Input() message: string;
}
