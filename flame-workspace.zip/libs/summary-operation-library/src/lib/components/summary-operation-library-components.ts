import { AccountAliasComponent } from './account-alias/account-alias.component';
import { AccountMovementComponent } from './account-movement/account-movement.component';
import { AliasDirective } from './account-alias/account-alias.directive';
import { InvalidOperationComponent } from './invalid-operation/invalid-operation.component';
import { NotAvailableInfoComponent } from './not-available-info/not-available-info.component';
import { ScrollSpinnerComponent } from './scroll-spinner/scroll-spinner.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RelateConfirmViewComponent } from './relate-confirm-view/relate-confirm-view.component';

export const SummaryOperationLibraryComponents = [
	AliasDirective,
	AccountMovementComponent,
	AccountAliasComponent,
	NotAvailableInfoComponent,
	InvalidOperationComponent,
	RelateConfirmViewComponent,
	ScrollSpinnerComponent,
	TransactionComponent
];

export const SummaryOperationLibraryEntryComponents = [
	AccountAliasComponent,
	AccountMovementComponent,
	InvalidOperationComponent,
	RelateConfirmViewComponent,
	TransactionComponent
];
