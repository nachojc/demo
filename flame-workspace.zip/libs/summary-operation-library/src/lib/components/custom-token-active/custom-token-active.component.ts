import { Component } from '@angular/core';

/**
 * Entry component para mostrar un mensaje dentro del token de que esta activo.
 *
 * @export
 * @class CustomTokenActiveComponent
 */
@Component({
	selector: 'sm-custom-token-active',
	templateUrl: './custom-token-active.component.html',
	styleUrls: []
})
export class CustomTokenActiveComponent {}
