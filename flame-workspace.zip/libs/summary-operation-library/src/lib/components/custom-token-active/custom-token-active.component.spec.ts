import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomTokenActiveComponent } from './custom-token-active.component';

describe('CustomTokenActiveComponent', () => {
	let component: CustomTokenActiveComponent;
	let fixture: ComponentFixture<CustomTokenActiveComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CustomTokenActiveComponent],
			imports: []
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CustomTokenActiveComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create component', () => {
		expect(component).toBeTruthy();
	});
});
