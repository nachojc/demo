import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../../services';

@Component({
	selector: 'sm-relate-confirm-view',
	templateUrl: './relate-confirm-view.component.html',
	styleUrls: ['./relate-confirm-view.component.scss']
})
export class RelateConfirmViewComponent implements OnInit {
	/**
	 * variables
	 *
	 * @type {*}
	 * @memberof RelateConfirmViewComponent
	 */
	public data: any;
	public statusSlide: string;
	public isAccept = false;

	constructor(private _accountService: AccountsService) {}

	/**
	 * metodo que emite un booleano de confirmacion del slide
	 *
	 * @param {*} e
	 * @memberof RelateConfirmViewComponent
	 */
	confirmationEvent(e: any) {
		if (e) {
			this.statusSlide = 'success';
			this._accountService.closeEventSlide.emit(e);
		}
	}

	/**
	 * metodo para aceptar terminos
	 *
	 * @memberof RelateConfirmViewComponent
	 */
	acceptTerms() {
		this.isAccept = !this.isAccept;
	}

	ngOnInit() {
		if (
			this.data.dataConfirm.operation_type === 'MODIFY' ||
			this.data.dataConfirm.operation_type === 'ASSOCIATE'
		) {
			this.isAccept = true;
		}
	}
}
