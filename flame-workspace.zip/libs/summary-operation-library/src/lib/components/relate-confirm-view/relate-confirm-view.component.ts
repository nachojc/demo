import { Component, OnInit } from '@angular/core';
import {
	CustomDialogComponent,
	DialogService,
	DialogReference
} from '@santander/flame-component-library';

@Component({
	selector: 'sm-relate-confirm-view',
	templateUrl: './relate-confirm-view.component.html',
	styleUrls: ['./relate-confirm-view.component.scss']
})
export class RelateConfirmViewComponent
	implements OnInit, CustomDialogComponent {
	data: any;
	constructor(private dialog: DialogService) {}
	private dialogRef: DialogReference;
	private terms =
		`<p>Las presentes CONDICIONES GENERALES y el AVISO DE PRIVACIDAD les son aplicables a todas aquellas 
		personas que ingresen o hagan uso de la página www.santander.com.mx (el “Sitio”) 
		titularidad de las entidades integrantes del Grupo Financiero Santander México1 (“Santander”) mediante 
		equipos de cómputo, teléfonos móviles, tabletas o cualquier otro equipo de comunicación (los "Usuarios").
		En consecuencia, le recomendamos leer detenidamente, antes de ingresar o utilizar de cualquier servicio o 
		contenido del Sitio, ya que es bajo su más estricta responsabilidad.</p>  <p>Ser Usuario del Sitio implica que ha leído 
		y aceptado las presentes CONDICIONES GENERALES y AVISO DE PRIVACIDAD. Si por el motivo que fuere no está de acuerdo 
		con estas CONDICIONES GENERALES o el AVISO DE PRIVACIDAD deberá abstenerse de acceder o utilizar el Sitio.</p><p>Santander se 
		reserva el derecho a actualizar, modificar o eliminar la información contenida en el Sitio, así como la configuración o 
		presentación del mismo, en cualquier momento sin asumir alguna responsabilidad frente a los Usuarios por ello.</p> 
		<p>CONDICIONES GENERALES</p><p>1. Responsabilidad</p><p>
		El acceso y uso del Sitio implica la adhesión plena y sin reservas a las presentes CONDICIONES GENERALES.</p>`;
		
		
	ngOnInit() {}

	openTerms() {
		this.dialogRef = this.dialog.open({
			closeLabel: 'Listo',
			title: 'Términos y condiciones',
			enableHr: false,
			disabledButton: true,
			buttons: [
				{
					label: ''
				}
			],
			body: `<div class="text-left mt-4"> ${ this.terms } </div>`
		});
	}

	acceptTerms() {
		this.data.button.disabled = !this.data.button.disabled;
	}
}
