import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';

import { RelateConfirmViewComponent } from './relate-confirm-view.component';
import { AccountsService } from '../../services';
import { ProductModule, CheckboxModule, SlideButtonModule } from '@santander/flame-component-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { OverlayModule } from '@angular/cdk/overlay';
import { RouterModule } from '@angular/router';
import { Injector } from '@angular/core';
import { ENV_CONFIG } from '@santander/flame-core-library';
import {
  HttpTestingController,
  HttpClientTestingModule
} from '@angular/common/http/testing';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { APP_BASE_HREF } from '@angular/common';


describe('RelateConfirmViewComponent', () => {
  const url = 'http://localhost:3000/api/accounts/';
  let injector: TestBed;
  let service: AccountsService;
  let httpMock: HttpTestingController;
  let component: RelateConfirmViewComponent;
  let fixture: ComponentFixture<RelateConfirmViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ProductModule,
        CheckboxModule,
        SlideButtonModule,
        OverlayModule,
        HttpClientTestingModule,
        NgxMaskModule.forRoot(),
        RouterModule.forRoot([]),
      ],
      declarations: [RelateConfirmViewComponent],
      providers: [AccountsService, MaskPipe,
        {
          provide: ENV_CONFIG,
          useValue: {
            api: {
              url: 'http://localhost:3000/api'
            }
          }
        }, {
          provide: Injector,
          useValue: {}
        },
        {
          provide: APP_BASE_HREF,
          useValue: '/'
        }
      ]
    }).compileComponents();

    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [RelateConfirmViewComponent]
      }
    });

    injector = getTestBed();
    service = injector.get(AccountsService);
    httpMock = injector.get(HttpTestingController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelateConfirmViewComponent);
    component = fixture.componentInstance;
    component.data = { dataConfirm: { operation_type: 'MODIFY', account: '56*5124', phone_number: '2929292929', company: 'Telcel', cardType: 'aero' } };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create acceptTerms', () => {
    component.acceptTerms();
  });

  it('should create confirmationEvent', () => {
    component.confirmationEvent('e');
  });
});