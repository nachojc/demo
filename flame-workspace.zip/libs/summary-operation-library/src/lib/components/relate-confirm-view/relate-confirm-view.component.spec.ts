/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelateConfirmViewComponent } from './relate-confirm-view.component';

describe('RelateConfirmViewComponent', () => {
  let component: RelateConfirmViewComponent;
  let fixture: ComponentFixture<RelateConfirmViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelateConfirmViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelateConfirmViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
*/
