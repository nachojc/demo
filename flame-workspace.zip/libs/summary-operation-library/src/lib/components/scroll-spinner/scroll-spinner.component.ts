import { Component } from '@angular/core';

@Component({
	selector: 'sm-scroll-spinner',
	template: `<ng-container></ng-container>`,
	styleUrls: ['./scroll-spinner.component.scss']
})
export class ScrollSpinnerComponent {

	constructor() {}

}
