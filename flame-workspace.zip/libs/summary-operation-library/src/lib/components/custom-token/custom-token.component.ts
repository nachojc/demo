import { Component } from '@angular/core';

/**
 * Entry component para mostrar un mensaje dentro del token
 *
 * @export
 * @class CustomTokenComponent
 */
@Component({
	selector: 'sm-custom-token',
	templateUrl: './custom-token.component.html',
	styleUrls: ['./custom-token.component.scss']
})
export class CustomTokenComponent {}
