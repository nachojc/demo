import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CustomTokenComponent } from './custom-token.component';

describe('CustomTokenComponent', () => {
	let component: CustomTokenComponent;
	let fixture: ComponentFixture<CustomTokenComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CustomTokenComponent],
			imports: []
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CustomTokenComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create component', () => {
		expect(component).toBeTruthy();
	});
});
