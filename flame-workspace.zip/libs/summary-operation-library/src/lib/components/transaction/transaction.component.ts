import { CreditsService } from './../../services/credits.service';
import { Component, OnInit } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';
import { TransactionDetail, TransactionDetailResponse } from '../../models';

@Component({
	selector: 'sm-transaction',
	templateUrl: './transaction.component.html',
	styleUrls: [ './transaction.component.scss' ]
})
export class TransactionComponent implements OnInit, CustomDialogComponent {
	data: any;

	// variables
	public detail: TransactionDetail = {};

	constructor(private _creditsService: CreditsService) {
	}

	ngOnInit() {
		if (this.data.product && this.data.transaction.key) {
			this._creditsService
				.getTransactionDetail(this.data.product.card_key, this.data.transaction.key)
				.subscribe((response: TransactionDetailResponse) => {
					this.detail = response.data;
				});
		}
	}
}
