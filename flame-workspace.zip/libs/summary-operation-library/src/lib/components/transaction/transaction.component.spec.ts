import { TransactionComponent } from './transaction.component';
import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed
} from '@angular/core/testing';
import { ENV_CONFIG } from '@santander/flame-core-library';
import {
	DialogModule,
	IconModule,
	ProductModule,
	IconButtonModule
} from '@santander/flame-component-library';
import { Injector } from '@angular/core';
import { CreditsService } from '../../services/credits.service';
import {
	HttpClientTestingModule,
	HttpTestingController
} from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';

const data = {
	data: {
		key: '032353',
		transaction_origin: 'CFE',
		creation_date: null,
		posted_date: '2019-03-13T00:00:00',
		url: '/credits/5474840000073614/transactions/5',
		amount: {
			amount: -244,
			currency_code: 'MXN'
		},
		card_number: '5474840000073614',
		description: 'PAGO DE SERVICIOS',
		reference: '07921895'
	},
	notifications: [
		{
			code: 'E422CDNPAYRCPTG001',
			message: 'Something is invalid',
			timestamp: '2019-03-15T00:41:59.566Z'
		}
	]
};
describe('TransactionComponent', () => {
	const url = 'http://localhost:3000/api';
	let component: TransactionComponent;
	let fixture: ComponentFixture<TransactionComponent>;
	let injector: TestBed;
	let service: CreditsService;
	let httpMock: HttpTestingController;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TransactionComponent],
			imports: [
				DialogModule,
				IconModule,
				ProductModule,
				IconButtonModule,
				HttpClientTestingModule
			],
			providers: [
				CreditsService,
				DatePipe,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api',
							version: {
								summary: '',
								accounts: '',
								credits: '',
								cards: '',
								transfers: ''
							}
						}
					}
				},
				{ provide: Injector, useValue: {} }
			]
		}).compileComponents();
		injector = getTestBed();
		service = injector.get(CreditsService);
		httpMock = injector.get(HttpTestingController);
	}));

	afterEach(() => {
		httpMock.verify();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(TransactionComponent);
		component = fixture.componentInstance;
		component.data = {
			transaction: { amount: { amount: '123' }, key: '032353' },
			product: { card_key: '4e20fbb243684d9eb19ff33a50ee422e' }
		};
		fixture.detectChanges();
		const request = httpMock.expectOne(
			url + '/credits/4e20fbb243684d9eb19ff33a50ee422e/transactions/032353'
		);
		expect(request.request.method).toEqual('GET');
		expect(request.request.responseType).toEqual('json');
		request.flush(data);
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
