import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed
} from '@angular/core/testing';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { AccountMovementComponent } from './account-movement.component';
import {
	DialogModule,
	IconModule,
	ProductModule,
	IconButtonModule
} from '@santander/flame-component-library';
import { Injector } from '@angular/core';
import { CreditsService } from '../../services/credits.service';
import {
	HttpClientTestingModule,
	HttpTestingController
} from '@angular/common/http/testing';
import { DatePipe } from '@angular/common';
const data = {
	data: {
		key: '101',
		display_number: '56*3565',
		creation_date: '2017-11-10T11:02:44.00001',
		description: 'Otros abonos',
		amount: {
			amount: 10000,
			currency_code: 'MXN'
		},
		number: '101',
		account: {
			related_card: '56722733565',
			running_balance: {
				amount: 35399.66,
				currency_code: 'MXN'
			}
		},
		transaction_origin: '1124',
		reference: '1231',
		tracking_number: null
	},
	notifications: null
};
describe('AccountMovementComponent', () => {
	const url = 'http://localhost:3000/api';
	let component: AccountMovementComponent;
	let fixture: ComponentFixture<AccountMovementComponent>;
	let injector: TestBed;
	let service: CreditsService;
	let httpMock: HttpTestingController;
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [AccountMovementComponent],
			imports: [
				DialogModule,
				IconModule,
				ProductModule,
				IconButtonModule,
				HttpClientTestingModule
			],
			providers: [
				CreditsService,
				DatePipe,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api',
							version: {
								summary: '',
								accounts: '',
								credits: '',
								cards: '',
								transfers: ''
							}
						}
					}
				},
				{ provide: Injector, useValue: {} }
			]
		}).compileComponents();
		injector = getTestBed();
		service = injector.get(CreditsService);
		httpMock = injector.get(HttpTestingController);
	}));

	afterEach(() => {
		httpMock.verify();
	});

	beforeEach(() => {
		fixture = TestBed.createComponent(AccountMovementComponent);
		component = fixture.componentInstance;
		component.data = {
			transaction: { amount: { amount: '123' }, key: '101' },
			product: { card_key: '056722751246' }
		};
		fixture.detectChanges();

		const request = httpMock.expectOne(
			url + '/accounts/056722751246/transactions/101'
		);
		expect(request.request.method).toEqual('GET');
		expect(request.request.responseType).toEqual('json');
		request.flush(data);
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
