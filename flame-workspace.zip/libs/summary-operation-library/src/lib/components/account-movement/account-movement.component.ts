import { TransactionDetail, TransactionDetailResponse } from './../../models';
import { Component, OnInit } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';
import { CreditsService } from '../../services/credits.service';
// import { AccountsService } from '../../../services/accounts.service';

/**
 * Entry component para colocar el detalle de un movimiento de una cuenta en un dialog
 *
 * @export
 * @class AccountMovementComponent
 * @implements {OnInit}
 * @implements {CustomDialogComponent}
 */
@Component({
	selector: 'sm-account-movement',
	templateUrl: './account-movement.component.html',
	styleUrls: ['./account-movement.component.scss']
})
export class AccountMovementComponent implements OnInit, CustomDialogComponent {
	/**
	 * Crea una instancia de  AccountMovementComponent.
	 * @param {CreditsService} _creditsService
	 * @memberof AccountMovementComponent
	 */
	constructor(private _creditsService: CreditsService) {}

	// variables publicas
	public data: any;
	public transaction: any;
	public showInfo = false;
	public detail: TransactionDetail = {
		account: {
			running_balance: {}
		}
	};

	/**
	 * Muestra el detalle de un movimiento SPEI
	 *
	 * @memberof AccountMovementComponent
	 */
	public navigateTransferDetail() {}

	/**
	 * Obtiene el detalle de un movimiento mediante el key de cuenta y de movimiento
	 *
	 * @memberof AccountMovementComponent
	 */
	ngOnInit() {
		this.transaction = this.data.transaction;
		this._creditsService
			.getDebitTransactionDetail(
				this.data.product.card_key,
				this.transaction.key
			)
			.subscribe((response: TransactionDetailResponse) => {
				this.detail = response.data;
			});
	}
}
