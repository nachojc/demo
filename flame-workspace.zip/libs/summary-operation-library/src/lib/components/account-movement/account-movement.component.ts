import { Component, OnInit } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';
import { CreditsService } from '../../services/credits.service';
// import { AccountsService } from '../../../services/accounts.service';

@Component({
	selector: 'sm-account-movement',
	templateUrl: './account-movement.component.html',
	styleUrls: ['./account-movement.component.scss']
})
export class AccountMovementComponent implements OnInit, CustomDialogComponent {
  data: any;

  // variables
  public transaction: any;
  public showInfo = false;
  public detail: any;

	constructor( private _creditsService: CreditsService ) { }

	ngOnInit() {
    this.transaction = this.data.detail;
    this._creditsService.getDebitTransactionDetail(this.transaction.display_number, this.transaction.key)
    .subscribe((response: any) => {
      this.detail = response.data;
    });
  }

  public conteInfo() {
    this.showInfo = !this.showInfo;
  }
}
