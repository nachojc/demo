/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccountAliasComponent } from './account-alias.component';

describe('AccountAliasComponent', () => {
  let component: AccountAliasComponent;
  let fixture: ComponentFixture<AccountAliasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountAliasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountAliasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
 */
