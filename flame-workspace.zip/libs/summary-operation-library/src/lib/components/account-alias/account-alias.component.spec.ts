import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormFieldModule } from '@santander/flame-component-library';
import { ReactiveFormsModule } from '@angular/forms';
import { AccountAliasComponent } from './account-alias.component';
import { AliasService } from './account-alias.service';

describe('AccountAliasComponent', () => {
	let component: AccountAliasComponent;
	let fixture: ComponentFixture<AccountAliasComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [AccountAliasComponent],
			imports: [ReactiveFormsModule, FormFieldModule],
			providers: [AliasService]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AccountAliasComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
