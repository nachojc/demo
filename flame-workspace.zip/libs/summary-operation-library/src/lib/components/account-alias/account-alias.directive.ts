import {
	Directive,
	OnInit,
	Output,
	EventEmitter,
	OnDestroy
} from '@angular/core';
import { AccountAliasComponent } from './account-alias.component';
import { AliasService } from './account-alias.service';

import {
	DialogService,
	DialogReference,
	CustomDialog
} from '@santander/flame-component-library';
import { Subscription } from 'rxjs';

@Directive({
	selector: '[smAlias]',
	host: {
		'(click)': 'openAlias($event)'
	}
})
export class AliasDirective implements OnInit, OnDestroy {
	private dialogRef: DialogReference;
	public isDialogOpen = false;
	private subscription: Subscription;
	public newAlias = '';

	constructor(
		private dialog: DialogService,
		private aliasService: AliasService
	) {}

	@Output() updateAlias = new EventEmitter<string>();

	openAlias() {
		this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cancelar',
				title: 'Modifica el alias de la cuenta',
				enableHr: false,
				disabledButton: true
			},
			new CustomDialog(AccountAliasComponent)
		);
		this.isDialogOpen = true;
		this.dialogRef.beforeClose().subscribe((cancel?: boolean) => {
			this.isDialogOpen = false;
			if (!cancel && this.newAlias !== '') {
				this.updateAlias.emit(this.newAlias);
			}
		});
	}

	ngOnInit() {
		this.subscription = this.aliasService.newAlias().subscribe(element => {
			if (element === '') {
				this.dialogRef.changeStatusButton(true);
			} else {
				this.dialogRef.changeStatusButton(false);
			}
			this.newAlias = element;
		});
	}

	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
}
