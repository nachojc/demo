import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AliasService } from './account-alias.service';

@Component({
	selector: 'sm-account-alias',
	templateUrl: './account-alias.component.html',
	styleUrls: []
})
export class AccountAliasComponent {
	constructor(
		private formBuilder: FormBuilder,
		private aliasService: AliasService
	) {
		this.aliasFormBuilder();
		this.aliasForm.valueChanges.subscribe(() => {
			this.aliasService.changeAlias(this.aliasForm.get('alias').value);
		});
	}
	public aliasForm: FormGroup;

	private aliasFormBuilder() {
		this.aliasForm = this.formBuilder.group({
			alias: this.formBuilder.control('', [
				Validators.required,
				Validators.maxLength(30)
			])
		});
	}
}
