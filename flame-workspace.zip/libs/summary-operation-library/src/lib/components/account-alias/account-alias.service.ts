import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AliasService {
	private element = new Subject<any>();

	changeAlias(element: string) {
		this.element.next(element);
	}

	newAlias(): Observable<any> {
		return this.element.asObservable();
	}
}
