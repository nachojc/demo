import { Component, DebugElement, ViewChild } from '@angular/core';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { AliasDirective } from './account-alias.directive';
import { OverlayModule } from '@angular/cdk/overlay';
import { DialogService, DialogReference, DialogModule } from '@santander/flame-component-library';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { AccountAliasComponent } from './account-alias.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AliasService } from './account-alias.service';

@Component({
    selector: 'sn-test-app',
	template: `
    <span smAlias #smAlias (updateAlias)="updateAlias($event)">Modificar</span>
	`
})

class TestAppComponent {
    @ViewChild('smAlias', { read: AliasDirective })
    smAlias: AliasDirective;
}

describe('AliasDirective', () => {
  let component: TestAppComponent;
  let fixture: ComponentFixture<TestAppComponent>;
  let aliasElement: DebugElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
        imports: [ OverlayModule, DialogModule, BrowserAnimationsModule ],
        declarations: [ AliasDirective, TestAppComponent ],
        providers: [DialogService, { provide: DialogReference, useValue: {} }]
    })
    .compileComponents();

    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
          entryComponents: [TestAppComponent, AccountAliasComponent]
      }
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestAppComponent);
    component = fixture.componentInstance;
    aliasElement = fixture.debugElement.query(By.directive(AliasDirective));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('validate openAlias', inject([AliasService], (service: AliasService)  => {
    component.smAlias.openAlias();
    service.newAlias();
    service.changeAlias('ew');
  }));

});