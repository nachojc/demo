import { Component, Input } from '@angular/core';

/**
 * Empty state para filtro en resumen de cuenta / resumen tdc
 *
 * @export
 * @class NotFilterDepositComponent
 */
@Component({
	selector: 'sm-not-filter-deposit',
	templateUrl: './not-filter-deposit.component.html',
	styleUrls: ['./not-filter-deposit.component.scss']
})
export class NotFilterDepositComponent {
	/**
	 * Crea una instancia de NotAvailableInfoComponent.
	 * @memberof NotAvailableInfoComponent
	 */
	constructor() {}
	/**
	 * Mensaje o titulo del empty state
	 *
	 * @type {string}
	 * @memberof NotFilterDepositComponent
	 */
	@Input() message: string;
	/**
	 * Descripción adicional que incluye el mensaje
	 *
	 * @type {string}
	 * @memberof NotFilterDepositComponent
	 */
	@Input() description: string;
	/**
	 * Tercer texto adicional para mensaje
	 *
	 * @type {string}
	 * @memberof NotFilterDepositComponent
	 */
	@Input() paragraph: string;
	/**
	 * Path para el svg/imagen que se debe mostrar
	 *
	 * @type {string}
	 * @memberof NotFilterDepositComponent
	 */
	@Input() imagen: string;
}
