import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { EmojiModule } from '@santander/flame-component-library';
import { NotFilterDepositComponent } from './not-filter-deposit.component';

describe('NotFilterDepositComponent', () => {
	let component: NotFilterDepositComponent;
	let fixture: ComponentFixture<NotFilterDepositComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [EmojiModule],
			declarations: [NotFilterDepositComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(NotFilterDepositComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
