/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvalidOperationComponent } from './invalid-operation.component';
import { DialogModule } from '@santander/flame-component-library';

describe('InvalidOperationComponent', () => {
	let component: InvalidOperationComponent;
	let fixture: ComponentFixture<InvalidOperationComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [InvalidOperationComponent],
			imports: [DialogModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(InvalidOperationComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
*/
