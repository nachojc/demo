import { Component } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';

@Component({
	selector: 'sm-invalid-operation',
	templateUrl: './invalid-operation.component.html',
	styleUrls: []
})
export class InvalidOperationComponent implements CustomDialogComponent {
	data: any;

	constructor() {}

}
