import { Component } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';

/**
 * Entry component para mostrar en un dialog una notificación
 * de que la operación que se intenta realizar es invalida.
 *
 * @export
 * @class InvalidOperationComponent
 * @implements {CustomDialogComponent}
 */
@Component({
	selector: 'sm-invalid-operation',
	templateUrl: './invalid-operation.component.html',
	styleUrls: []
})
export class InvalidOperationComponent implements CustomDialogComponent {

	/**
   * Objeto que se usa para el custom dialog
   *
   * @type {*}
   * @memberof InvalidOperationComponent
   */
  data: any;

	constructor() {}

}
