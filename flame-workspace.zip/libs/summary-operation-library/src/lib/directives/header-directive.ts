import { Directive, HostListener, ElementRef, Input } from '@angular/core';

@Directive({
	selector: '[smHeaderName]'
})
export class HeaderDirective {
	private isScaled = false;
	private isWhite = false;
	private colorStates = [
		'#e5e5e5',
		'#e7e7e7',
		'#eaeaea',
		'#ececec',
		'#efefef',
		'#f2f2f2',
		'#f4f4f4',
		'#f7f7f7',
		'#f9f9f9',
		'#fcfcfc',
		'#ffffff'
	];
	private scaleStates = [
		1,
		0.975,
		0.95,
		0.925,
		0.9,
		0.875,
		0.85,
		0.825,
		0.8,
		0.775,
		0.75
	];
	constructor(private el: ElementRef) {}
  @Input() active = true;

	@HostListener('window:scroll', ['$event'])
	onscroll(event) {
    const top = event.srcElement.children[0].scrollTop;
		if (top >= 10 && top < 120 && this.active) {
			const text = this.el.nativeElement.querySelector('.sn-top-bar-center');
			text.style.transform = `scale(${
				this.scaleStates[Math.floor(top / 10) - 1]
			})`;
		} else if (top < 10  && this.active) {
			if (this.isScaled) {
				const text = this.el.nativeElement.querySelector('.sn-top-bar-center');
				this.isScaled = false;
				text.style.transform = `scale(${this.scaleStates[0]})`;
			}
		} else if (top > 120  && this.active) {
			if (!this.isScaled) {
				const text = this.el.nativeElement.querySelector('.sn-top-bar-center');
				this.isScaled = true;
				text.style.transform = `scale(${this.scaleStates[10]})`;
			}
		}

		if (top >= 120 && top < 230  && this.active) {
			this.el.nativeElement.style.backgroundColor = this.colorStates[
				Math.floor(top / 10) - 12
			];
		} else if (top < 120  && this.active) {
			if (this.isWhite) {
				this.isWhite = false;
				this.el.nativeElement.style.backgroundColor = this.colorStates[0];
			}
		} else if (top > 230 && this.active) {
			if (!this.isWhite) {
				this.isWhite = true;
				this.el.nativeElement.style.backgroundColor = this.colorStates[10];
			}
		}
	}
}
