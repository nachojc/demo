import { Directive, HostListener, EventEmitter, Output, ElementRef, Input } from '@angular/core';

@Directive({
	selector: '[smScrollable]'
})
export class ScrollDirective {
	private header = false;
	private styleHeader = {
		position: 'fixed',
		top: '60px',
		padding: '24px 0 10px 24px',
		'background-color': 'white',
		'z-index': '1',
		width: '100%',
		'margin-left': '-24px',
		'box-shadow': '0 14px 14px -12px rgba(var(--sn-color-primary_rgb), 0.5)'
	};

  @Output() scrolled = new EventEmitter();
  @Input() active = true;

	constructor(public el: ElementRef) {}

	@HostListener('window:scroll', [ '$event' ])
	onScroll(event) {
		try {
			const top = event.srcElement.children[0].scrollTop;
			const offset = event.srcElement.children[0].offsetHeight;
			const scrollHeight = event.srcElement.children[0].scrollHeight;
			const height = this.el.nativeElement.scrollHeight;
			const offset2 = this.el.nativeElement.offsetHeight;
			if ((top + (offset - offset2) > scrollHeight - height - 1) && this.active) {
				this.scrolled.emit(true);
			}
			if (top - 20 + 60 > scrollHeight - height && !this.header) { // +60px del header
				this.setHeader(true);
			} else if (top - 20 + 60 < scrollHeight - height && this.header) { // +60px del header
				this.setHeader(false);
			}
		} catch (err) {
			// console.log(err);
		}
	}

	setHeader(enable) {
		this.header = enable && this.active;
		const header = this.el.nativeElement.querySelector('.sn-last-movements');
		this.styleSetter(header);
	}

	styleSetter(element: any) {
		for (const key in this.styleHeader) {
			if (this.styleHeader.hasOwnProperty(key)) {
				element.style[key] = this.header ? this.styleHeader[key] : '';
			}
		}
	}
}
