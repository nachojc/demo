import {
	Directive,
	HostListener,
	EventEmitter,
	Output,
	ElementRef,
	Input,
	Inject,
	ContentChild,
	AfterContentInit,
	Renderer2,
	OnDestroy
} from '@angular/core';
import { WINDOW } from '../services';

@Directive({
	selector: '[smScrollable]'
})
export class ScrollDirective implements AfterContentInit {
	private header = false;
	private styleHeader = {
		position: 'fixed',
		top: '59px',
		padding: '24px 0 24px 24px',
		'background-color': 'white',
		'z-index': '1',
		width: '100%',
		display: 'flex',
		'box-shadow': '0 14px 14px -12px rgba(var(--sn-color-primary_rgb), 0.5)'
	};
	private copyTop: any;

	@Output() scrolled = new EventEmitter();
	@Input() active = true;
	@Input() host: any;
	@ContentChild('topFixed') top: any;
	private initTop = 0;

	constructor(
		public el: ElementRef,
		@Inject(WINDOW) private window: Window,
		private _renderer: Renderer2
	) {}

	@HostListener('window:scroll', ['$event'])
	onScroll(event) {
		if (this.active) {
			try {
				const top = event.srcElement.children[0].scrollTop;
				const offset = event.srcElement.children[0].offsetHeight;
				const scrollHeight = event.srcElement.children[0].scrollHeight;
				const height = this.el.nativeElement.scrollHeight;
				const offset2 = this.el.nativeElement.offsetHeight;
				const div = this.top.nativeElement;
				const divBoun = div.getBoundingClientRect();

				if (top + (offset - offset2) + 8 > scrollHeight - height - 1) {
					this.scrolled.emit(true);
				}
				if (divBoun.top - 68 < 0 && !this.header) {
					this.setHeader(true);
				} else if (top + 68 < this.initTop && this.header) {
					this.setHeader(false);
				}
			} catch (err) {
				// console.log(err);
			}
		}
	}

	setHeader(enable) {
		this.header = enable && this.active;
		if (this.header) {
			this._renderer.appendChild(
				this.host.el.nativeElement,
				this.top.nativeElement
			);
		} else {
			const element = this.el.nativeElement.firstElementChild;
			this._renderer.insertBefore(
				element,
				this.top.nativeElement,
				element.firstChild
			);
		}
		this.styleSetter(this.top.nativeElement);
	}

	styleSetter(element: any) {
		for (const key in this.styleHeader) {
			if (this.styleHeader.hasOwnProperty(key)) {
				this._renderer.setStyle(
					element,
					key,
					this.header ? this.styleHeader[key] : ''
				);
			}
		}
	}

	ngAfterContentInit(): void {
		const div = this.top.nativeElement;
		const divBoun = div.getBoundingClientRect();
		this.initTop = divBoun.top;
	}
}
