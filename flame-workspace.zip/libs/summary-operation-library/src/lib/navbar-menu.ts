// TODO: Modificar las rutas cuando esten listas
export const navbarElements = [
	{
		name: 'Mi vida',
		icon: 'sn-CHAN07',
    route: '/summary/global-position',
    disabled: true
	},
	{
		name: 'Transferencias',
		icon: 'sn-BAN55',
    route: '/summary/global-position',
    disabled: true
	},
	{
		name: 'Productos',
		icon: {
      path: 'assets/animations/productos.json',
      renderer: 'svg',
      autoplay: false,
      loop: false
    },
    route: '/summary/global-position',
    animated: true
	},
	{
		name: 'Tienda',
		icon: 'sn-SERV08',
    route: '/summary/global-position',
    disabled: true
	},
	{
		name: 'Más',
		icon: {
      path: 'assets/animations/mas.json',
      renderer: 'svg',
      autoplay: false,
      loop: false
    },
    route: '/more-menu',
    animated: true
	}
];
