// TODO: Modificar las rutas cuando esten listas
export const navbarElements = [
	{
		name: 'Mi vida',
		icon: 'sn-CHAN07',
		route: '/summary/global-position'
	},
	{
		name: 'Transferencias',
		icon: 'sn-BAN55',
		route: '/summary/global-position'
	},
	{
		name: 'Mis productos',
		icon: 'sn-SMOV09',
		route: '/summary/global-position'
	},
	{
		name: 'Tienda',
		icon: 'sn-SERV08',
		route: '/summary/global-position'
	},
	{
		name: 'Más',
    icon: 'sn-FUNC56',
		route: '/more-menu'
	}
];
