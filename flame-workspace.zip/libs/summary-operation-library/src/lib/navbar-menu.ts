// TODO: Modificar las rutas cuando esten listas
export const navbarElements = [
	{
		name: 'Mi vida',
		icon: 'BAN05',
		route: '/summary/global-position'
	},
	{
		name: 'Transferencias',
		icon: 'BAN55',
		route: '/summary/global-position'
	},
	{
		name: 'Mis productos',
		icon: 'mis-productos',
		route: '/summary/global-position'
	},
	{
		name: 'Tienda',
		icon: 'tienda',
		route: '/summary/global-position'
	},
	{
		name: 'Más',
    icon: 'mas',
		route: '/more-menu'
	}
];
