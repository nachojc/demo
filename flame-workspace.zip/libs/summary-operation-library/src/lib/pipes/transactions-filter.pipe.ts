import { TransactionFilter } from './../interfaces/transaction-filter-interface';
import { Transaction } from './../models/transaction';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'transactionFilter',
	pure: false
})
export class TransactionFilterPipe implements PipeTransform {
	transform(transactions: Transaction[], filter: TransactionFilter): Transaction[] {
		if (!transactions) return [];
		if (filter.expense && filter.income && filter.pending) return transactions;

		return transactions.filter((transaction: Transaction) => {
			return (
				(!filter.pending && !filter.income && filter.expense && transaction.amount.amount < 0) ||
				(!filter.pending && !filter.expense && filter.income && transaction.amount.amount >= 0) ||
        (filter.pending && !filter.expense && !filter.income && !transaction.posted_date) ||
        (!filter.pending &&
					filter.expense &&
					filter.income &&
					!transaction.posted_date) ||
				(filter.pending &&
					filter.expense &&
					!filter.income &&
					!transaction.posted_date &&
					transaction.amount.amount < 0) ||
				(filter.pending &&
					!filter.expense &&
					filter.income &&
					!transaction.posted_date &&
					transaction.amount.amount >= 0)
			);
		});
	}
}
