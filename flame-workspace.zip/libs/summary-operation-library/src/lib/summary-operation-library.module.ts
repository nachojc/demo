// NPM Deps
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';

import {
	CommonModule,
	DatePipe,
	CurrencyPipe,
	TitleCasePipe
} from '@angular/common';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	CallButtonModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
  AvatarModule,
  SlideButtonModule,
	TokenDialogModule,
  SnackBarModule,
  SearchBarModule,
  AmountFieldModule,
  TokenDialogService,
  ContactDialogModule,
  ContactDialogService
} from '@santander/flame-component-library';

// Router
import { SummaryOperationLibraryRoutingModule } from './summary-operation-library.router.module';

// Components
import { SummaryOperationLibraryViews } from './views/summary-operation-library-views';
import { SummaryOperationLibraryComponents,
  SummaryOperationLibraryEntryComponents
} from './components/summary-operation-library-components';
// Services
import { SummaryService } from './services/summary.service';
import { AccountsService } from './services/accounts.service';
import { CreditsService } from './services/credits.service';
// Pipes
import { TransactionFilterPipe } from './pipes/transactions-filter.pipe';
// Directives
import { ScrollDirective } from './directives/scroll-directive';
import { HeaderDirective } from './directives/header-directive';

@NgModule({
	imports: [
    AvatarModule,
		ButtonModule,
		CardModule,
		CarouselModule,
    CommonModule,
    ContactDialogModule,
		HttpClientModule,
		DialogModule,
		SlideToggleModule,
		SpinnerModule,
		IconModule,
		IconButtonModule,
		ReactiveFormsModule,
		FormFieldModule,
		InputModule,
		NotificationModule,
		NgxMaskModule.forRoot(),
		NavbarModule,
		IconButtonModule,
		ChipModule,
		ProductModule,
		DialogSelectModule,
		CheckboxModule,
		TopBarModule,
		CallButtonModule,
		AccountSelectModule,
		CardSliderModule,
		EmojiModule,
		MotiveFieldModule,
		SlideButtonModule,
		SnackBarModule,
		SummaryOperationLibraryRoutingModule,
    TokenDialogModule,
    SearchBarModule,
    AmountFieldModule
	],
	declarations: [
    ...SummaryOperationLibraryComponents,
    ...SummaryOperationLibraryViews,
    TransactionFilterPipe,
    ScrollDirective,
    HeaderDirective
  ],
	entryComponents: [
		...SummaryOperationLibraryEntryComponents
	],
	providers: [
		DatePipe,
    TitleCasePipe,
    ContactDialogService,
    CurrencyPipe,
    SummaryService,
		AccountsService,
		CreditsService,
		MaskPipe,
    TokenDialogService,
    TransactionFilterPipe
	]
})
export class SummaryOperationLibraryModule {}
