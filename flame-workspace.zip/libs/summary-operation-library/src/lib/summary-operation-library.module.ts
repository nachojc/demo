// NPM Deps
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';

import {
	CommonModule,
	DatePipe,
	CurrencyPipe,
	TitleCasePipe
} from '@angular/common';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
  AvatarModule,
  SlideButtonModule,
	TokenDialogModule,
  SnackBarModule,
  SearchBarModule,
  AmountFieldModule,
  TokenDialogService,
  ContactDialogModule,
  ContactDialogService,
  ErrorsModule,
  SnCurrencyModule
} from '@santander/flame-component-library';

// Router
import { SummaryOperationLibraryRoutingModule } from './summary-operation-library.router.module';

// Components
import { SummaryOperationLibraryViews } from './views/summary-operation-library-views';
import { SummaryOperationLibraryComponents,
  SummaryOperationLibraryEntryComponents
} from './components/summary-operation-library-components';
// Services
import { SummaryService, CreditsService, AccountsService, WINDOW_PROVIDERS } from './services';
// Pipes
import { TransactionFilterPipe } from './pipes/transactions-filter.pipe';
// Directives
import { ScrollDirective } from './directives/scroll-directive';
import { HeaderDirective } from './directives/header-directive';
import { AutoWidthInputModule } from 'libs/flame-component-library/src/lib/atoms/auto-width-input/auto-width-input.module';
import { ApiInterceptor } from '@santander/flame-core-library';

@NgModule({
	imports: [
    AvatarModule,
		ButtonModule,
		CardModule,
		CarouselModule,
    CommonModule,
    ContactDialogModule,
		HttpClientModule,
		DialogModule,
		SlideToggleModule,
		SpinnerModule,
		IconModule,
		IconButtonModule,
		ReactiveFormsModule,
		FormFieldModule,
		InputModule,
		NotificationModule,
		NgxMaskModule.forRoot(),
		NavbarModule,
		IconButtonModule,
		ChipModule,
		ProductModule,
		DialogSelectModule,
		CheckboxModule,
		TopBarModule,
		AccountSelectModule,
		CardSliderModule,
		EmojiModule,
		MotiveFieldModule,
		SlideButtonModule,
		SnackBarModule,
		SummaryOperationLibraryRoutingModule,
    TokenDialogModule,
    SearchBarModule,
    AmountFieldModule,
    FormsModule,
    ErrorsModule,
		SnCurrencyModule.forRoot({
			align: 'right',
			allowNegative: false,
			allowZero: true,
			decimal: '.',
			precision: 2,
			prefix: '',
			suffix: '',
			thousands: ',',
      nullable: true
    }),
    AutoWidthInputModule
	],
	declarations: [
    ...SummaryOperationLibraryComponents,
    ...SummaryOperationLibraryViews,
    TransactionFilterPipe,
    ScrollDirective,
    HeaderDirective,

  ],
	entryComponents: [
		...SummaryOperationLibraryEntryComponents
	],
	providers: [
		DatePipe,
    TitleCasePipe,
    ContactDialogService,
    CurrencyPipe,
    SummaryService,
		AccountsService,
		CreditsService,
		MaskPipe,
    TokenDialogService,
    TransactionFilterPipe,
    WINDOW_PROVIDERS
    ,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ApiInterceptor,
      multi: true
    }
	]
})
export class SummaryOperationLibraryModule {}
