import { SliderViewModule } from './../../../../apps/super-mobile/src/app/components/slider-view/slider-view.module';
import { CapitalizeModule } from './../../../flame-component-library/src/lib/pipes/capitalize/capitalize.module';
// NPM Deps
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
	CommonModule,
	DatePipe,
	CurrencyPipe,
	TitleCasePipe
} from '@angular/common';
import {
	AccountSelectModule,
	AutoWidthInputModule,
	ButtonModule,
	CardModule,
	CardSliderModule,
	CarouselModule,
	ChipModule,
	DialogModule,
	DialogSelectModule,
	EmojiModule,
	RadioButtonModule,
	FormFieldModule,
	IconButtonModule,
	IconModule,
	InputModule,
	MotiveFieldModule,
	NavbarModule,
	NotificationModule,
	ProductModule,
	SlideToggleModule,
	SpinnerModule,
	TokenDialogModule,
	TopBarModule,
	AmountFieldModule,
	AvatarModule,
	ContactDialogModule,
	ContactDialogService,
	ErrorsModule,
	SearchBarModule,
	SlideButtonModule,
	SnackBarModule,
	SnCurrencyModule,
	TokenDialogService,
	ThemeModule,
	FlameFoundationTheme,
	CheckboxModule,
	SkeletonModule
} from '@santander/flame-component-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
// Router
import { SummaryOperationLibraryRoutingModule } from './summary-operation-library.router.module';
// Components
import { SummaryOperationLibraryViews } from './views/summary-operation-library-views';
import {
	SummaryOperationLibraryComponents,
	SummaryOperationLibraryEntryComponents
} from './components/summary-operation-library-components';
// Services
import {
	SummaryService,
	CreditsService,
	AccountsService,
	WINDOW_PROVIDERS,
	CopyTextService
} from './services';
// Pipes
import { TransactionFilterPipe } from './pipes/transactions-filter.pipe';
// Directives
import { ScrollDirective } from './directives/scroll-directive';
import { HeaderAnimationModule } from '@santander/flame-component-library';
import { ApiInterceptor } from '@santander/flame-core-library';
import { DialogDispositionComponent } from './components/dialog-disposition/dialog-disposition.component';

@NgModule({
	imports: [
		AvatarModule,
		AutoWidthInputModule,
		ButtonModule,
		CardModule,
		CarouselModule,
		CommonModule,
		ContactDialogModule,
		HttpClientModule,
		DialogModule,
		SlideToggleModule,
		SpinnerModule,
		IconModule,
		IconButtonModule,
		ReactiveFormsModule,
		FormFieldModule,
		InputModule,
		NotificationModule,
		NgxMaskModule.forRoot(),
		NavbarModule,
		IconButtonModule,
		ChipModule,
		ProductModule,
		DialogSelectModule,
		TopBarModule,
		AccountSelectModule,
		CardSliderModule,
		EmojiModule,
		MotiveFieldModule,
		SlideButtonModule,
		SnackBarModule,
		SummaryOperationLibraryRoutingModule,
		TokenDialogModule,
		SearchBarModule,
		AmountFieldModule,
		FormsModule,
		ErrorsModule,
		HeaderAnimationModule,
		CapitalizeModule,
		SnCurrencyModule.forRoot({
			align: 'right',
			allowNegative: false,
			allowZero: true,
			decimal: '.',
			precision: 2,
			prefix: '',
			suffix: '',
			thousands: ',',
			nullable: true,
			integers: 1
		}),
		ThemeModule.forRoot({
			themes: [FlameFoundationTheme],
			active: 'flame-foundation'
		}),
		SlideButtonModule,
		RadioButtonModule,
		CheckboxModule,
		SliderViewModule,
		SkeletonModule
	],
	declarations: [
		...SummaryOperationLibraryComponents,
		...SummaryOperationLibraryViews,
		TransactionFilterPipe,
		ScrollDirective,
		DialogDispositionComponent
	],
	entryComponents: [...SummaryOperationLibraryEntryComponents],
	providers: [
		AccountsService,
		CreditsService,
		CopyTextService,
		DatePipe,
		MaskPipe,
		ContactDialogService,
		CurrencyPipe,
		SummaryService,
		TitleCasePipe,
		TokenDialogService,
		TransactionFilterPipe,
		WINDOW_PROVIDERS,
		{
			provide: HTTP_INTERCEPTORS,
			useClass: ApiInterceptor,
			multi: true
		}
	]
})
export class SummaryOperationLibraryModule {}
