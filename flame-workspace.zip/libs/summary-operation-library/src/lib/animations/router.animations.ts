import { TransitionsSummaryAnimations, VoucherSummaryInAnimation, VoucherTransfersOutAnimation, TransitionsSummaryReverseAnimations } from './transitions/transitions.animations';

export const RouterSummaryAnimations = [
  TransitionsSummaryAnimations,
  TransitionsSummaryReverseAnimations,
  VoucherTransfersOutAnimation,
  VoucherSummaryInAnimation
]
