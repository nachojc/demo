import { TransitionsSummaryAnimations, VoucherSummaryInAnimation } from './transitions/transitions.animations';

export const RouterSummaryAnimations = [
  TransitionsSummaryAnimations,
  VoucherSummaryInAnimation,
]
