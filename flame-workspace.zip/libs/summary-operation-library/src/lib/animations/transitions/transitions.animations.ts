import {
  trigger,
  animate,
  animation,
  transition,
  keyframes,
  style,
  state,
  query,
  group
} from '@angular/animations';
import { VoucherInAnimation, LeftToRightSlideInAnimation } from '@santander/flame-component-library';

export const LeftToRightSlideInAnimations = trigger('slideIn', [
  transition(
    'void <=> *',
    [LeftToRightSlideInAnimation]
  ),
])

export const TransitionsSummaryAnimations = transition('* => 71, * => 72', [
  // La transicion entre ambas pantallas (entrante y saliente)
  // deben ejecutarse al mismo tiempo para obtener el efecto deseado
  group([
    // La pagina actual debe desaparecer deslizandose hacia la izquierda
    query(
      ':leave',
      [
        style({
          position: 'fixed',
          width: '100%',
          transform: 'translateX(0%)',
        }),
        animation(
          animate(
            '{{time}} cubic-bezier(0.550, 0.085, 0.680, 0.530)',
            keyframes([
              style({ transform: 'translateX(0)', offset: 0 }),
              style({ opacity: '1', offset: 0 }),
              style({ transform: 'translateX({{translationOne}})', offset: 1 }),
              style({ opacity: '0', offset: 1 })
            ])
          ),
          { params: { time: '0.35s', translationOne: '-1000px' } }
        )
      ], { optional: true }
    ),
    // La pagina actual debe aparecer deslizandose hacia la izquierda
    query(
      ':enter',
      [
        style({
          position: 'fixed',
          width: '100%',
          transform: 'translateX(-100%)',
        }),
        animation(
          animate(
            '{{time}} cubic-bezier(0.250, 0.460, 0.450, 0.940)',
            keyframes([
              style({ transform: 'translateX({{translationOne}})', offset: 0 }),
              style({ opacity: '0', offset: 0 }),
              style({ transform: 'translateX(0)', offset: 1 }),
              style({ opacity: '1', offset: 1 })
            ])
          ),
          { params: { time: '0.35s', translationOne: '1000px' } }
        )], { optional: true }
    )
  ]),
]
);

export const VoucherSummaryInAnimation = transition('* => 73', [
  // La transicion entre ambas pantallas (entrante y saliente)
  // deben ejecutarse al mismo tiempo para obtener el efecto deseado

  // La pagina debe aparecer hacia el centro con un efecto ZOOM
  query(
    ':enter',
    [
      style({
        position: 'fixed',
        width: '100%',
        transform: 'scale3d(0.3, 0.3, 0.3)',
      }),
      VoucherInAnimation], { optional: true }
  ),
]);