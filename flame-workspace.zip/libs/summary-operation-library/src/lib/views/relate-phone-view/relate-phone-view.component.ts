import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
	ContactDialogService,
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AnswerRSA } from './../../interfaces/answerRSA.interface';
import {
	DataTransferService,
	inputEqualsValidator
} from '@santander/flame-core-library';
import { Location } from '@angular/common';
import { AccountsService } from '../../services/accounts.service';
import { PHONECOMPANIES } from '../../category_product';
import { RelateConfirmViewComponent } from '../../components/relate-confirm-view/relate-confirm-view.component';
import { timer } from 'rxjs';

@Component({
	selector: 'sm-relate-phone-view.',
	templateUrl: './relate-phone-view.component.html',
	styleUrls: ['./relate-phone-view.component.scss']
})
export class RelatePhoneViewComponent implements OnInit {
	/**
	 * Crea una instancia de  RelatePhoneViewComponent.
	 * @param {FormBuilder} _formBuilder
	 * @param {Router} _router
	 * @param {DialogService} _dialog
	 * @param {DataTransferService} _dataTransferService
	 * @param {SummaryService} _summaryService
	 * @param {MaskPipe} _mask
	 * @param {Location} _location
	 * @param {AccountsService} _accountsService
	 * @memberof RelatePhoneViewComponent
	 */
	constructor(
		private _formBuilder: FormBuilder,
		private _router: Router,
		private _dataTransferService: DataTransferService,
		private _location: Location,
		private _accountsService: AccountsService,
		public contactDialogService: ContactDialogService,
		private dialog: DialogService
	) {}

	/**
	 * variables
	 *
	 * @type {string}
	 * @memberof RelatePhoneViewComponent
	 */
	private dialogRef: DialogReference;
	public operationType: string;
	public company: string;
	public acceptedTerms = false;
	public account: any = {};
	public summaryAccount: any;
	public accountDetailParams: any;
	public modify = false;
	public related = false;
	public relateForm: FormGroup;
	public optionsSended = PHONECOMPANIES.map(option => {
		return {
			name: option.value,
			value: option.id
		};
	});

	/**
	 * se crea el formulario
	 *
	 * @memberof RelatePhoneViewComponent
	 */
	relatePhoneFormBuilder() {
		this.relateForm = this._formBuilder.group(
			{
				number: this._formBuilder.control('', [
					Validators.required,
					Validators.maxLength(10)
				]),
				confirmNumber: this._formBuilder.control('', [
					Validators.required,
					Validators.maxLength(10)
				]),
				company: this._formBuilder.control('', [Validators.required])
			},
			{
				validator: inputEqualsValidator([
					{
						from: 'number',
						to: 'confirmNumber'
					}
				])
			}
		);
	}

	/**
	 * se obtiene el detalle de la cuenta del servicicio de acuerdo al key
	 *
	 * @memberof RelatePhoneViewComponent
	 */
	getAccountDetail() {
		this._dataTransferService.getData().then(response => {
      this.summaryAccount = Object.assign({}, response.data);
			if (this.summaryAccount.related_phone) {
				this.modify = true;
			}
			this.summaryAccount.cardType = response.cardType;
		});
	}

	/**
	 * se recupera la respuesta del la compañia telefonica
	 *
	 * @param {AnswerRSA} answer
	 * @memberof RelatePhoneViewComponent
	 */
	onSelectedOption(answer: AnswerRSA) {
		this.company = answer.text.name;
		this.relateForm.get('company').setValue(answer.text.name);
	}

	/**
	 * metodo para crear el request para el servicio del put
	 *
	 * ASSOCIATE = dar de alta
	 * MODIFY = modificar
	 * DISSOCIATE = dar de baja
	 *
	 * @param {string} operationType
	 * @returns
	 * @memberof RelatePhoneViewComponent
	 */
	createRequest() {
		return {
			operation_type: this.operationType,
			phone_number:
				this.operationType === 'DISSOCIATE'
					? this.summaryAccount.related_phone.phone_number
					: this.relateForm.get('confirmNumber').value,
			company:
				this.operationType === 'DISSOCIATE'
					? this.summaryAccount.related_phone.company
					: this.company
		};
	}

	/**
	 * metodo que crea los datos del modal de confirmación
	 *
	 * @returns
	 * @memberof RelatePhoneViewComponent
	 */
	dataConfirm() {
		return {
			cardType: this.summaryAccount.cardType,
			display_name: this.summaryAccount.product.description,
			operation_type: this.operationType,
			account: this.summaryAccount.number,
			phone_number:
				this.operationType === 'DISSOCIATE'
					? this.summaryAccount.related_phone.phone_number
					: this.relateForm.get('confirmNumber').value,
			company:
				this.operationType === 'DISSOCIATE'
					? this.summaryAccount.related_phone.company
					: this.company
		};
	}

	/**
	 * metodo para dar de alta, modificar o dar de baja
	 *
	 * @param {string} keyAccount
	 * @param {string} action
	 * @memberof RelatePhoneViewComponent
	 */
	putRelatePhone(operationType: string) {
		this.operationType = operationType;
		if (
			operationType === 'MODIFY' &&
			this.summaryAccount.related_phone.phone_number ===
				this.relateForm.get('confirmNumber').value
		) {
			this._accountsService.showErrorDialog(
				'Número ya asociado',
				'',
				`Lo sentimos el número celular ${
					this.summaryAccount.related_phone.phone_number
				} ya se encuentra asociado a una cuenta Santander.`,
				'./assets/icons/icon-nodisponible.jpg'
			);
		} else {
			this.dialogRef = this.dialog.open(
				{
					closeLabel: 'Cerrar',
					title:
						this.operationType === 'DISSOCIATE'
							? 'Baja de número'
							: 'Confirma tus datos',
					enableHr: true,
					showButton: false,
					closeBackdropClick: true
				},
				new CustomDialog(RelateConfirmViewComponent, {
					dataConfirm: this.dataConfirm()
				})
			);
			this._accountsService.closeEventSlide.subscribe(response => {
				timer(500).subscribe(() => {
					this.dialogRef.close();
					this.navigateAndExecutePut();
				});
			});
		}
	}

	/**
	 *
	 *
	 * @memberof RelatePhoneViewComponent
	 */
	acceptTermsChange() {
		this.acceptedTerms = !this.acceptedTerms;
	}

	/**
	 * metodo para regresar ala pantalla anterior
	 *
	 * @memberof RelatePhoneViewComponent
	 */
	navigateBack() {
		this._location.back();
	}

	/**
	 *
	 * metodo para ir al comprobante
	 * @param {*} result
	 * @memberof RelatePhoneViewComponent
	 */
	navigateAndExecutePut() {
		this._accountsService
			.associatedPhone(this.summaryAccount.key, this.createRequest())
			.subscribe((response: any) => {
				const copyResult = Object.assign({}, response.data);
				copyResult.operationType = this.operationType;
				this._dataTransferService.sendData(copyResult);
				this._router.navigate(['/summary/relate-success']);
			});
	}

	/**
	 * Inicializa los datos de la vista
	 *
	 * @memberof RelatePhoneViewComponent
	 */
	ngOnInit() {
		this.getAccountDetail();
		this.relatePhoneFormBuilder();
	}
}
