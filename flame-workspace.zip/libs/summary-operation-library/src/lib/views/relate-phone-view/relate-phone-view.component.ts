import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {
	DialogService,
	CustomDialog,
	DialogReference
} from '@santander/flame-component-library';
import {
	FormBuilder,
	FormGroup,
	Validators
} from '@angular/forms';
import { AnswerRSA } from './../../interfaces/answerRSA.interface';
import { RelateConfirmViewComponent } from './../../components/relate-confirm-view/relate-confirm-view.component';
import {
	numberLengthValidator,
	DataTransferService,
	inputEqualsValidator
} from '@santander/flame-core-library';
import { ShowOnDirtyErrorStateMatcher } from '@santander/flame-component-library';
import { SummaryService } from '../../services/summary.service';
import { MaskPipe } from 'ngx-mask';
import { Location } from '@angular/common';
import { AccountsService } from '../../services/accounts.service';

@Component({
	selector: 'sm-relate-phone-view.',
	templateUrl: './relate-phone-view.component.html',
	styleUrls: ['./relate-phone-view.component.scss']
})
export class RelatePhoneViewComponent implements OnInit {

	public acceptedTerms = false;
	public params: any = {};
	public account: any = {};
	public related = false;
	public modify = false;
	public showHintNumber = false;
	public relateForm: FormGroup;
	public matcher = new ShowOnDirtyErrorStateMatcher();
	public options = [
		{
			value: 'Telcel'
		},
		{
			value: 'Movistar'
		},
		{
			value: 'AT&T'
		},
		{
			value: 'Unefon'
		},
		{
			value: 'Iusacel'
		},
		{
			value: 'Flash Mobile'
		},
		{
			value: 'Virgin Mobile'
		},
		{
			value: 'Nextel'
		},
		{
			value: 'Weex'
		},
		{
			value: 'No cuento con la compañía'
		}
	];
	public optionsSended = this.options.map(option => {
		return {
			name: option.value,
			value: option.value
		};
	});
	public _company = '';
	public cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];
	public categories = [];
  public card = [];
  public dialogRef: DialogReference;
	private dialogConfig = {
		closeLabel: 'Cancelar',
		title: 'Baja de número asociado',
		enableHr: false,
		disabledButton: true,
		buttons: []
	};
	public customConfig = {
		account: '',
		number: 0,
		company: '',
		text: '',
		icon: true,
		newRelate: false,
		button: null
	};

	public compares = [
		{
			from: 'number',
			to: 'confirmNumber'
		}
	];

	constructor(
		private formBuilder: FormBuilder,
		private _router: Router,
		private dialog: DialogService,
		private _dataTransferService: DataTransferService,
		private _summaryService: SummaryService,
		private _mask: MaskPipe,
		private _location: Location,
		private _accountsService: AccountsService
	) {
    this.initAccountRel();
  }

  private initAccountRel() {
		this.account = <any> {
			product: {},
			related_phone: {
				phone_number: ''
			}
		};
  }

	public getRandomImage(arr) {
		return arr[Math.floor(Math.random() * arr.length)];
	}

	private relateFormBuilder() {
		this.relateForm = this.formBuilder.group({
			number: this.formBuilder.control({ value: '', disabled: this.related }, [
				Validators.required,
				numberLengthValidator([10]),
				Validators.minLength(10),
				Validators.maxLength(10)
      ]),
      confirmNumber: this.formBuilder.control({ value: '', disabled: this.related }, [
				Validators.required,
				numberLengthValidator([10]),
				Validators.minLength(10),
				Validators.maxLength(10)
			]),
			company: this.formBuilder.control({ value: '', disabled: this.related }, [
				Validators.required
			])
		}, {validator: inputEqualsValidator(this.compares)});
	}

	ngOnInit() {
		this.getDataAccount();
		this.relateFormBuilder();
	}

	private getDataAccount() {
		this._dataTransferService.getData().then((data: any) => {
      if (data !== undefined) {
        if (data.number !== undefined) {
          this.account = data;
          if (data.related_phone.phone_number !== undefined) {
            this.disableForm();
          }
        }
        this.customConfig.account = this.account.number;
      } else {
        this.getAccounts();
      }
		});
	}

	/**
	 * @TODO MODIFY CALL TO CORRECT SERVICE
	 */
	private getAccounts() {
		this._summaryService.getSummary().subscribe(response => {
      this.categories = response.data[0].products;
			this.categories.map((item: any) => {
				item.card_type = this.getRandomImage(this.cardImages);
				item.product = {
					description: item.description
				};
				item.number = item.display_number;
			});
      if (this.account.balance === undefined) {
        this.account = response.data[0].products[0];
        this.customConfig.account = this.account.number;
				this.account.related_phone = this.account.related_phone === null
					? {}
					: this.account.related_phone;
      }
		});
	}

	public showConfirm() {
		if (this.relateForm.get('number').value === '1234567890') {
			this.phoneRelated(this.relateForm.get('number').value);
			return;
		}
		this.getFormData();
		this.dialogConfig.title = 'Confirmar datos';
		if(this.modify){
			this.sendDataRelated(
				`Modificación de número celular exitoso`,
				`Ahora puedes proporcionar tu número de celular para recibir depósitos o
				transferencias, indicando que tu banco es Santander`,
				'MODIFY'
			);
		}else{
			this.sendDataRelated(
				`Asociación de cuenta exitosa`,
				`Ahora puedes proporcionar tu número de celular para recibir depósitos o
				transferencias, indicando que tu banco es Santander`
			);
		}
	}

	public deleteRelated() {
		this.dialogConfig.title = 'Baja de número de celular';
		this.dialogConfig.buttons = [
			{
				label: 'Continuar',
				class: 'strech',
				action: scope => {
					scope.cancel();
					this.sendDataRelated('Baja de número asociado exitoso', '', 'DISSOCIATE');
				}
			}
		];
		this.customConfig.text =
			`Confirma el número de celular que deseas dar de baja
			y la cuenta a la que se encuentra asociado.`;
		this.customConfig.icon = false;
		this.customConfig.newRelate = false;
		this.openDialog();
	}

	public phoneRelated(number: string) {
		this.dialogConfig.title = 'Número ya asociado';
		this.dialogConfig.buttons = [
			{
				label: 'Aceptar',
				class: 'strech',
				action: scope => {
					scope.cancel();
					this.enableForm();
				}
			}
		];
		this.customConfig.text =
			`Lo sentimos el número celular
			${ this._mask.transform(number, '00-0000-0000') }
			ya se encuentra asociado a una cuenta Santander.`;
		this.customConfig.icon = false;
		this.customConfig.newRelate = true;
		this.openDialog();
	}

	public openDialog() {
		this.dialogRef = this.dialog.open(
			this.dialogConfig,
			new CustomDialog(RelateConfirmViewComponent, this.customConfig)
		);
	}

	public sendDataRelated(title: string, text: string = '', operation: string = 'ASSOCIATE') {
		if(operation !== 'DISSOCIATE'){
			this.params = {
				"operation-type": operation,
				phone_number: this.account.related_phone.phone_number,
				company: this.account.related_phone.company
			};
		}else{
			this.params = {
				"operation-type": operation,
				phone_number: '',
				company: ''
			};
		}

		this._accountsService.associatedPhone('056722733565', this.params).subscribe((response) => {
			this._dataTransferService.sendData({
				title: title,
				text: text,
				account: {
					related_phone:{
						number: response.data.phone_number,
						company: response.data.company
					},
					operation_date: response.data.operation_date,
					reference: response.data.reference
				}
			});
			this.navigateMenu('/summary/relate-success');
		});
	}

	navigateMenu(route: string) {
		this._router.navigate([route]);
	}

	public onSelectedOption(answer: AnswerRSA) {
		this._company = answer.text.value;
		this.customConfig.company = answer.text.value;
	}

	public enableForm() {
		this.related = false;
		this.modify = true;
		this.relateForm.reset({
      number: { value: '', disabled: false },
      company: { value: '', disabled: false }
    });
		this._company = '';
		this._dataTransferService.sendData({});
	}

	public clearInput(inputName:string){
		this.relateForm.controls[inputName].setValue('');
	}

  public disableForm() {
    this.related = true;
    this.relateForm.get('number').setValue(this.account.related_phone.phone_number);
    this.relateForm.get('company').setValue(this.account.related_phone.company);
    this.relateForm.get('company').disable();
    this.relateForm.get('number').disable();
    this._company = this.account.related_phone.company;
    this.customConfig.company = this._company;
    this.customConfig.number = this.account.related_phone.phone_number;
  }

  private getFormData() {
    this.account.related_phone.phone_number = this.relateForm.get('number').value;
    this.account.related_phone.company = this._company;
    this.customConfig.account = this.account.number;
  }

  acceptTerms() {
    this.acceptedTerms = !this.acceptedTerms;
  }

	public navigateBack() {
		this._location.back();
  }

}
