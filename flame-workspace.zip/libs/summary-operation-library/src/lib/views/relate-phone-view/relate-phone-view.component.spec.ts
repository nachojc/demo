import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed,
	inject
} from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { HttpRequest } from '@angular/common/http';
import { RelatePhoneViewComponent } from './relate-phone-view.component';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import {
	DataTransferService,
	ENV_CONFIG,
	AuthenticationService
} from '@santander/flame-core-library';
import { RouterTestingModule } from '@angular/router/testing';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
	AvatarModule,
	SlideButtonModule,
	TokenDialogModule,
	SnackBarModule,
	SearchBarModule,
	AmountFieldModule,
	TokenDialogService,
	ContactDialogModule,
	ContactDialogService,
	ErrorsModule,
	SnCurrencyModule,
	TopBarModule,
	HeaderAnimationModule
} from '@santander/flame-component-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import {
	Injector,
	CUSTOM_ELEMENTS_SCHEMA,
	NO_ERRORS_SCHEMA
} from '@angular/core';
import { RouterModule, Router } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import { APP_BASE_HREF, Location } from '@angular/common';
import { SummaryService, AccountsService } from '../../services';
import {
	HttpTestingController,
	HttpClientTestingModule
} from '@angular/common/http/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AnswerRSA } from '../../interfaces/answerRSA.interface';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import {
	SummaryOperationLibraryComponents,
	SummaryOperationLibraryEntryComponents
} from './../../components/summary-operation-library-components';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import { ScrollDirective } from './../../directives';

const summaryBass = {
	data: [
		{
			category_name: 'CHECKING_ACCOUNTS',
			total_balance: {
				currency_code: 'MXN',
				amount: 69827.78
			},
			products: [
				{
					key: '056722751246',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '56*5124',
					related_phone: {
						phone_number: '5510555143',
						company: 'TELCEL'
					},
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: 69827.78
					}
				},
				{
					key: '056722733565',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '56*3356',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'USD',
						amount: 0
					}
				}
			]
		},
		{
			category_name: 'CREDIT_CARDS',
			total_balance: {
				currency_code: 'MXN',
				amount: 85399.66
			},
			products: [
				{
					key: '4e20fbb243684d9eb19ff33a50ee422e',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '*3699',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: 1812.1
					}
				},
				{
					key: '1b10lop243683d9eb19ff33a50ee345a',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '*9981',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: -22038.1
					}
				}
			]
		},
		{
			category_name: 'GROWING_MONEY',
			total_balance: 3401954.06,
			products: [
				{
					key: '056515888469',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '056515888469',
					related_phone: null,
					status: null,
					balance: {
						currency_code: 'MXN',
						amount: 1183062.17
					}
				},
				{
					key: '056515888546',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '056515888546',
					related_phone: null,
					status: null,
					balance: {
						currency_code: 'MXN',
						amount: 2218891.89
					}
				}
			]
		}
	],
	notifications: null,
	paging: null
};

describe('RelatePhoneViewComponent', () => {
	const url = 'http://localhost:3000/api';
	let injector: TestBed;
	let component: RelatePhoneViewComponent;
	let fixture: ComponentFixture<RelatePhoneViewComponent>;
	let dataTransferService: DataTransferService;
	let httpMock: HttpTestingController;

	const dataRelated = {
		key: '056722751246',
		number: '00922398411',
		alias: 'MY CHEQUING ACCOUNT',
		product: {
			type: 'Debit card',
			description: 'SUPER NOMINA'
		},
		clabe: '990182 163201 535556',
		related_card: {
			number: '5200 0000 0000 0000',
			product: {
				type: 'Debit card',
				description: 'Tarjeta de debito'
			},
			expiration_date: '11/19'
		},
		related_phone: {
			phone_number: '5510555143',
			company: 'TELCEL'
		},
		balance: {
			amount: 69827.78,
			currency_code: 'MXN'
		},
		latest_transactions: [
			{
				creation_date: '2017-07-21T17:32:28Z',
				amount: {
					amount: 50000.5,
					currency_code: 'MXN'
				},
				description: 'string'
			}
		],
		card_type: './assets/icons/card-pref.svg'
	};

	const responseData = {
		data: {
			account_key: '4e20fbb243684d9eb19ff33a50ee422e',
			phone_number: '5589765423',
			operation_date: '2017-07-21T17:32:28Z',
			company: 'TELCEL',
			reference: '6126533'
		}
	};

	const answer: AnswerRSA = {
		text: {
			name: 'UNEFON',
			value: 'UNEFON'
		}
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			declarations: [
				RelatePhoneViewComponent,
				...SummaryOperationLibraryComponents,
				...SummaryOperationLibraryViews,
				MoreMainMenuViewComponent,
				ScrollDirective,
				TransactionFilterPipe
			],
			imports: [
				SpinnerModule,
				SlideToggleModule,
				ButtonModule,
				DialogModule,
				CarouselModule,
				CardModule,
				IconModule,
				ReactiveFormsModule,
				FormFieldModule,
				TopBarModule,
				InputModule,
				NotificationModule,
				NavbarModule,
				IconButtonModule,
				ProductModule,
				HttpClientTestingModule,
				DialogSelectModule,
				CheckboxModule,
				AccountSelectModule,
				BrowserAnimationsModule,
				CardSliderModule,
				EmojiModule,
				MotiveFieldModule,
				AvatarModule,
				SlideButtonModule,
				TokenDialogModule,
				SnackBarModule,
				SearchBarModule,
				AmountFieldModule,
				ContactDialogModule,
				ErrorsModule,
				SnCurrencyModule,
				NgxMaskModule.forRoot(),
				RouterTestingModule,
				HeaderAnimationModule,
				SummaryOperationLibraryRoutingModule,
				RouterModule.forRoot([])
			],
			providers: [
				SummaryService,
				AccountsService,
				DataTransferService,
				ContactDialogService,
				TokenDialogService,
				MaskPipe,
				Injector,
				TransactionFilterPipe,
				AuthenticationService,
				{ provide: Injector, useValue: {} },
				{ provide: APP_BASE_HREF, useValue: '/' },
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api'
						}
					}
				}
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [...SummaryOperationLibraryEntryComponents]
			}
		});

		injector = getTestBed();
		httpMock = injector.get(HttpTestingController);
		dataTransferService = injector.get(DataTransferService);
		dataTransferService.sendData(dataRelated);
	}));

	beforeEach(done => {
		fixture = TestBed.createComponent(RelatePhoneViewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		dataTransferService.getData().then(data => {
			expect(data).toBe(dataRelated);
			const request = httpMock.expectOne(
				(req: HttpRequest<any>) =>
					req.urlWithParams === `${url}/summary?page=1&limit=10`
			);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(summaryBass);

			fixture.detectChanges();
			done();
		});
	});

	afterEach(() => {
		httpMock.verify();
	});

	it('should create component', async(() => {
		expect(component).toBeTruthy();
	}));

	it('should allow modify phone related', async(
		inject([Router], (router: Router) => {
			const button = fixture.debugElement.query(By.css('button'));
			button.nativeElement.click();
			expect(component.related).toBeFalsy();
			expect(component.modify).toBeTruthy();
			fixture.detectChanges();
			const number = '1234567891';
			component.relateForm.get('number').setValue(number);
			component.relateForm.get('confirmNumber').setValue(number);
			component.onSelectedOption(answer);
			const company = answer.text.value;
			component.relateForm.get('company').setValue(company);

			const snIconButton = fixture.debugElement.query(By.css('sn-icon-button'));
			snIconButton.nativeElement.click();

			expect(component.acceptTerms).toBeTruthy();

			fixture.detectChanges();
			const buttonAssociate = fixture.debugElement.query(
				By.css('.associate-button')
			);
			spyOn(router, 'navigate').and.returnValue(true);
			buttonAssociate.nativeElement.click();
			const key = component.account.key;
			const request = httpMock.expectOne(
				`${url}/accounts/${key}/associated-phone`
			);
			expect(request.request.method).toEqual('PUT');
			expect(request.request.responseType).toEqual('json');
			request.flush(responseData);
			fixture.whenStable().then(() => {
				expect(router.navigate).toHaveBeenCalledWith([
					'/summary/relate-success'
				]);
			});
		})
	));

	it('should show phone already related alert', async(() => {
		const button = fixture.debugElement.query(By.css('button'));
		button.nativeElement.click();
		expect(component.related).toBeFalsy();
		expect(component.modify).toBeTruthy();
		fixture.detectChanges();
		const number = '1234567890';
		component.relateForm.get('number').setValue(number);
		component.relateForm.get('confirmNumber').setValue(number);
		component.onSelectedOption(answer);
		const company = answer.text.value;
		component.relateForm.get('company').setValue(company);

		const snIconButton = fixture.debugElement.query(By.css('sn-icon-button'));
		snIconButton.nativeElement.click();

		expect(component.acceptTerms).toBeTruthy();

		fixture.detectChanges();
		const buttonAssociate = fixture.debugElement.query(
			By.css('.associate-button')
		);
		buttonAssociate.nativeElement.click();
		component.dialogRef.componentInstance.buttons[0].action(
			component.dialogRef.componentInstance
		);
	}));

	it('should delete related phone', async(
		inject([Router], (router: Router) => {
			const deleteText = fixture.debugElement.query(By.css('div.edit p'));
			deleteText.nativeElement.click();
			spyOn(router, 'navigate').and.returnValue(true);
			component.dialogRef.componentInstance.buttons[0].action(
				component.dialogRef.componentInstance
			);
			const key = component.account.key;
			const request = httpMock.expectOne(
				`${url}/accounts/${key}/associated-phone`
			);
			expect(request.request.method).toEqual('PUT');
			expect(request.request.responseType).toEqual('json');
			request.flush(responseData);
			fixture.whenStable().then(() => {
				expect(router.navigate).toHaveBeenCalledWith([
					'/summary/relate-success'
				]);
			});
		})
	));

	it('Should navigate back', inject([Location], (location: Location) => {
		fixture.detectChanges();
		const snCard = fixture.debugElement.query(By.css('sn-top-bar div div'));
		spyOn(location, 'back').and.returnValue(true);
		snCard.nativeElement.click();
		fixture.whenStable().then(() => {
			expect(location.back).toHaveBeenCalled();
		});
	}));
});
