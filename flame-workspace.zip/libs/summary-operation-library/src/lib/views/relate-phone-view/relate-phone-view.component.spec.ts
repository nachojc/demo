// import { async,
//           ComponentFixture,
//           TestBed,
//           getTestBed,
//           inject } from '@angular/core/testing';
// import {
// 	FormFieldModule,
// 	ButtonModule,
// 	CheckboxModule,
// 	DialogSelectModule,
// 	InputModule,
// 	IconModule,
// 	TopBarModule,
//   ProductModule,
//   NavbarModule,
//   ChipModule,
//   SlideToggleModule,
//   CardModule,
//   IconButtonModule,
//   CustomDialog
// } from '@santander/flame-component-library';
// import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
// import { ReactiveFormsModule } from '@angular/forms';
// import { CommonModule } from '@angular/common';
// import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
// import { RouterModule } from '@angular/router';
// import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
// import { By } from '@angular/platform-browser';
// import { DebugElement } from '@angular/core';
// import { numberLengthValidator, DataTransferService } from '@santander/flame-core-library';
// import { AccountRelatePhone } from './relate-phone.interface';
// import { AnswerRSA } from './../../../sign-op/interfaces/answerRSA.interface';
// import { AccountsService } from '../../services/account-summary.service';
// import { NgxMaskModule, MaskPipe } from 'ngx-mask';
// import { AccountSummaryOpRoutingModule } from '../../account-summary.router.module';
// import { AccountSummaryOpComponents } from '../acount-summary-op-components';
// import { RelateConfirmViewComponent } from './relate-confirm-view/relate-confirm-view.component';
// import { RelatePhoneViewComponent } from './relate-phone-view.component';
// import { environment } from '../../../../../environments/environment';
// // import * as dataService from '../../../../../../api/db.json';

// const dataService = {
//   "data": [
//     {
//       "category_name": "Cuentas de débito",
//       "total_balance": {
//         "currency_code": "MXP",
//         "amount": 85399.66
//       },
//       "products": [
//         {
//           "key": "056722734006",
//           "alias": null,
//           "description": "SUPER NOMINA",
//           "url": null,
//           "display_number": "56*3400",
//           "related_phone": null,
//           "status": "AVAILABLE",
//           "balance": {
//             "currency_code": "MXP",
//             "amount": 142900
//           }
//         },
//         {
//           "key": "056722733565",
//           "alias": null,
//           "description": "SUPER NOMINA",
//           "url": null,
//           "display_number": "56*3356",
//           "related_phone": null,
//           "status": "AVAILABLE",
//           "balance": {
//             "currency_code": "MXP",
//             "amount": 50.5
//           }
//         }
//       ]
//     },
//     {
//       "category_name": "Tarjeta de Crédito",
//       "total_balance": {
//         "currency_code": "MXP",
//         "amount": 85399.66
//       },
//       "products": [
//         {
//           "key": "056722734026",
//           "alias": null,
//           "description": "SUPER NOMINA",
//           "url": null,
//           "display_number": "56*5678",
//           "related_phone": null,
//           "status": "AVAILABLE",
//           "balance": {
//             "currency_code": "MXP",
//             "amount": 80000
//           }
//         },
//         {
//           "key": "056722733525",
//           "alias": null,
//           "description": "SUPER NOMINA",
//           "url": null,
//           "display_number": "56*3871",
//           "related_phone": null,
//           "status": "AVAILABLE",
//           "balance": {
//             "currency_code": "MXP",
//             "amount": 27049.5
//           }
//         }
//       ]
//     }
//   ],
//   "notifications": null,
//   "paging": null
// };

// describe('RelatePhoneViewComponent', () => {

//   const url = environment.baas.urlSummary;
//   const relatedAccount = {
//     card_type: './assets/icons/card-amex.svg',
//     number: '56*3400',
//     product: {
//       type: "Debit card",
//       description: "Tarjeta de debito"
//     },
//     balance: {
//       amount: 1234.5,
//       currency_code: "MXN"
//     },
//     related_phone: {
//       number: 5589765423,
//       company: "TELCEL"
//     }
//   };
//   const testFormCorrect = {
//     case1: {
//       number: '1234567899',
//       company: 'UNEFON'
//     },
//     case2: {
//       number: '1234567890',
//       company: 'UNEFON'
//     }
//   };

//   const testFormIncorrect = {
//     case1: {
//       number: '123456789',
//       company: 'UNEFON'
//     },
//     case2: {
//       number: '12345678901',
//       company: 'UNEFON'
//     },
//     case3: {
//       number: '123456789a',
//       company: 'UNEFON'
//     }
//   };

//   const answer: AnswerRSA = {
// 		text: {
// 			name: 'UNEFON',
// 			value: 'UNEFON'
// 		}
//   };

//   let injector: TestBed;
//   let service: AccountsService;
//   let dataTransfer: DataTransferService;
//   let httpMock: HttpTestingController;

// 	beforeEach(
// 		async(() => {
// 			TestBed.configureTestingModule({
//         imports: [
//           ButtonModule,
//           TopBarModule,
//           CheckboxModule,
//           IconModule,
//           DialogSelectModule,
//           FormFieldModule,
//           InputModule,
//           ProductModule, // Del
//           NavbarModule,
//           ChipModule,
//           SlideToggleModule,
//           CardModule,
//           IconButtonModule, // Del
//           AccountSummaryOpRoutingModule,
//           CommonModule,
//           ReactiveFormsModule,
//           HttpClientTestingModule,
//           BrowserAnimationsModule,
//           NgxMaskModule.forRoot(),
//           RouterModule.forRoot([])
//         ],
// 				declarations: [
//           AccountSummaryOpComponents
//         ],
//         providers: [
//           DataTransferService,
//           AccountsService,
//           MaskPipe
//         ]
//       }).compileComponents();

//       TestBed.overrideModule(BrowserDynamicTestingModule, {
//         set: {
//           entryComponents: [
//             RelateConfirmViewComponent
//           ]
//         }
//       });
//       injector = getTestBed();
//       dataTransfer = injector.get(DataTransferService);
//       service = injector.get(AccountsService);
//       httpMock = injector.get(HttpTestingController);
// 		})
//   );

//   afterEach(() => {
//     httpMock.verify();
//   });

//   describe('should relate new phone to account', () => {
//     let component: RelatePhoneViewComponent;
//     let fixture: ComponentFixture<RelatePhoneViewComponent>;
//     let button: DebugElement;

// 		beforeEach(() => {
//       fixture = TestBed.createComponent(RelatePhoneViewComponent);
//       component = fixture.componentInstance;
//       fixture.detectChanges();

//       button = fixture.debugElement.query(By.css('button'));
//       service.getSummaryBass().subscribe(response => {
//         expect(response.data.length).toBe(2);
// 				component.categories = response.data;
// 				component.categories.map((category: any) => {
// 					category.products.map((item: any) => {
// 						item.card_type = component.getRandomImage(component.cardImages);
// 						item.product = {
// 							description: item.description
// 						};
// 						item.number = item.display_number;
// 					});
//         });
//         component.accountRel = response.data[0].products[0];
//         component.customConfig.account = component.accountRel.number;
//         component.accountRel.related_phone = component.accountRel.related_phone === null
// 					? {}
//           : component.accountRel.related_phone;
//       });

//       const req = httpMock.expectOne(url);
//       expect(req.request.method).toEqual('GET');
//       expect(req.request.responseType).toEqual('json');

//       req.flush(dataService);

//     });

//     it('The relate phone button should be disabled at the start', () => {
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('The relate phone button should be disabled when phone number is incorrect. Case 1', () => {
//       component.relateForm.controls['number'].setValue(
//         testFormIncorrect.case1.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormIncorrect.case1.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('The relate phone button should be disabled when phone number is incorrect. Case 2', () => {
//       component.relateForm.controls['number'].setValue(
//         testFormIncorrect.case2.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormIncorrect.case2.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('The relate phone button should be disabled when phone number is incorrect. Case 3', () => {
//       component.relateForm.controls['number'].setValue(
//         testFormIncorrect.case3.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormIncorrect.case3.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('should notify when phone number is related', () => {
//       component.relateForm.controls['number'].setValue(
//         testFormCorrect.case2.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormCorrect.case2.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       expect(component.dialogRef.componentInstance.heading).toBe('Número ya asociado');
//       component.dialogRef.componentInstance.buttons[0].action(
//         component.dialogRef.componentInstance
//       );

//       expect(component.relateForm.controls['number'].value).toBe('');
//       expect(component.relateForm.controls['company'].value).toBe('');
//       expect(component._company).toBe('');
//       expect(component.related).toBeFalsy();

//     });

//     it('should show confirm message before relate phone', () => {
//       component.relateForm.controls['number'].setValue(
//         testFormCorrect.case1.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormCorrect.case1.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       expect(component.dialogRef.componentInstance.heading).toBe('Confirmar datos');
//       expect(component.dialogRef.componentInstance.buttons[0].disabled).toBeTruthy();
//       component.dialogRef.componentInstance.cancel();
//     });

//     it('The confirm button has been clicked and navigateMenu called', () => {
//       component.relateForm.controls['number'].setValue(
//         testFormCorrect.case1.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormCorrect.case1.company
//       );
//       component.onSelectedOption(answer);
//       fixture.detectChanges();

//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       expect(component.dialogRef.componentInstance.heading).toBe('Confirmar datos');
//       expect(component.dialogRef.componentInstance.buttons[0].disabled).toBeTruthy();
//       if (component.dialogRef.componentInstance.bodyContent instanceof CustomDialog) {
//         component.dialogRef.componentInstance.bodyContent.data.button.disabled = false;
//         expect(component.dialogRef.componentInstance.buttons[0].disabled).toBeFalsy();
//         spyOn(component, 'navigateMenu');
//         component.dialogRef.componentInstance.buttons[0].action(
//           component.dialogRef.componentInstance
//         );

//         fixture.whenStable().then(() => {
//           expect(component.navigateMenu).toHaveBeenCalled();
//         });
//       }
//     });

//   });

//   describe('should unsubscribe related phone to account', () => {
//     let component: RelatePhoneViewComponent;
//     let fixture: ComponentFixture<RelatePhoneViewComponent>;
//     let button: DebugElement;

// 		beforeEach((done) => {
//       dataTransfer.sendData(relatedAccount);
//       fixture = TestBed.createComponent(RelatePhoneViewComponent);
//       component = fixture.componentInstance;

//       dataTransfer.getData().then((response) => {
//         component.accountRel = response;
//         fixture.detectChanges();
//         if (response.related_phone.number !== undefined) {
//           component.disableForm();
//           fixture.detectChanges();
//           button = fixture.debugElement.query(By.css('.outlined'));
// 				}
//         done();
//       });
// 		});

// 		it('The unsubscribe button should be enabled at the start', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//     });

//     it('should show confirm message before unsubscribe related phone', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();

//       expect(component.dialogRef.componentInstance.heading).toBe('Baja de número asociado');
//       expect(
//         component.dialogRef.componentInstance.buttons[0].disabled
//       ).toBeFalsy();
//       component.dialogRef.componentInstance.cancel();
//       fixture.detectChanges();

//     });

//     it('The continue button has been clicked and navigateMenu called', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();

//       expect(component.dialogRef.componentInstance.heading).toBe('Baja de número asociado');
//       expect(
//         component.dialogRef.componentInstance.buttons[0].disabled
//       ).toBeFalsy();

//       spyOn(component, 'navigateMenu');

//       component.dialogRef.componentInstance.buttons[0].action(
//         component.dialogRef.componentInstance
//       );

//       fixture.whenStable().then(() => {
//         expect(component.navigateMenu).toHaveBeenCalled();
//       });
//     });


//   });

//   describe('should modify related phone to account', () => {
//     let component: RelatePhoneViewComponent;
//     let fixture: ComponentFixture<RelatePhoneViewComponent>;
//     let button: DebugElement;

// 		beforeEach((done) => {
//       dataTransfer.sendData(relatedAccount);
//       fixture = TestBed.createComponent(RelatePhoneViewComponent);
//       component = fixture.componentInstance;

//       dataTransfer.getData().then((response) => {
//         component.accountRel = response;
//         fixture.detectChanges();
//         if (response.related_phone.number !== undefined) {
//           component.disableForm();
//           fixture.detectChanges();
//           button = fixture.debugElement.query(By.css('button'));
// 				}
//         done();
//       });
// 		});

// 		it('The modify button should be enabled at the start', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//     });

//     it('The form should be disabled at the start', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       expect(component.relateForm.get('number').enabled).toBeFalsy();
//       expect(component.relateForm.get('company').enabled).toBeFalsy();

//     });

//     it('should enable and clear form when modify button has been clicked', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       expect(component.relateForm.get('number').enabled).toBeFalsy();
//       expect(component.relateForm.get('company').enabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();

//       expect(component.related).toBeFalsy();
//       expect(component.relateForm.get('number').value).toBe('');
//       expect(component.relateForm.get('company').value).toBe('');
//       expect(component._company).toBe('');

//       expect(component.relateForm.get('number').enabled).toBeTruthy();
//       expect(component.relateForm.get('company').enabled).toBeTruthy();

//       fixture.detectChanges();
//     });

//     it('The relate phone button should be disabled when modify button has been clicked', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       button = fixture.debugElement.query(By.css('button'));
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('The relate phone button should be disabled when phone number is incorrect. Case 1', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       button = fixture.debugElement.query(By.css('button'));
//       expect(button.properties.disabled).toBeTruthy();

//       component.relateForm.controls['number'].setValue(
//         testFormIncorrect.case1.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormIncorrect.case1.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('The relate phone button should be disabled when phone number is incorrect. Case 2', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       button = fixture.debugElement.query(By.css('button'));
//       expect(button.properties.disabled).toBeTruthy();

//       component.relateForm.controls['number'].setValue(
//         testFormIncorrect.case2.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormIncorrect.case2.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('The relate phone button should be disabled when phone number is incorrect. Case 3', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       button = fixture.debugElement.query(By.css('button'));
//       expect(button.properties.disabled).toBeTruthy();

//       component.relateForm.controls['number'].setValue(
//         testFormIncorrect.case3.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormIncorrect.case3.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeTruthy();
//     });

//     it('should show confirm message before relate new phone', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       button = fixture.debugElement.query(By.css('button'));
//       expect(button.properties.disabled).toBeTruthy();

//       component.relateForm.controls['number'].setValue(
//         testFormCorrect.case1.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormCorrect.case1.company
//       );
//       component.onSelectedOption(answer);

//       fixture.detectChanges();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       expect(component.dialogRef.componentInstance.heading).toBe('Confirmar datos');
//       expect(component.dialogRef.componentInstance.buttons[0].disabled).toBeTruthy();
//       component.dialogRef.componentInstance.cancel();
//     });

//     it('The confirm button has been clicked and navigateMenu called', () => {
//       expect(component.related).toBeTruthy();
//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       button = fixture.debugElement.query(By.css('button'));
//       expect(button.properties.disabled).toBeTruthy();

//       component.relateForm.controls['number'].setValue(
//         testFormCorrect.case1.number
//       );
//       component.relateForm.controls['company'].setValue(
//         testFormCorrect.case1.company
//       );
//       component.onSelectedOption(answer);
//       fixture.detectChanges();

//       expect(button.properties.disabled).toBeFalsy();
//       button.nativeElement.click();
//       fixture.detectChanges();
//       expect(component.dialogRef.componentInstance.heading).toBe('Confirmar datos');
//       expect(component.dialogRef.componentInstance.buttons[0].disabled).toBeTruthy();
//       if (component.dialogRef.componentInstance.bodyContent instanceof CustomDialog) {
//         component.dialogRef.componentInstance.bodyContent.data.button.disabled = false;
//         expect(component.dialogRef.componentInstance.buttons[0].disabled).toBeFalsy();
//         spyOn(component, 'navigateMenu');
//         component.dialogRef.componentInstance.buttons[0].action(
//           component.dialogRef.componentInstance
//         );

//         fixture.whenStable().then(() => {
//           expect(component.navigateMenu).toHaveBeenCalled();
//         });
//       }
//     });
//   });
// });
