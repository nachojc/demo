import {
  async,
  ComponentFixture,
  TestBed
} from '@angular/core/testing';
import { RelatePhoneSuccessViewComponent } from './relate-phone-success-view.component';
import { SummaryViewComponent } from '../summary-view/summary-view.component';
import { AccountDetailViewComponent } from '../account-detail-view/account-detail-view.component'
import { ProductsSummaryViewComponent } from '../products-summary-view/products-summary-view.component';
import { CreditCardDetailViewComponent } from '../credit-card-detail-view/credit-card-detail-view.component';
import { CreditCardMoneyViewComponent } from '../credit-card-money-view/credit-card-money-view.component';
import { CreditCardVoucherViewComponent } from '../credit-card-voucher-view/credit-card-voucher-view.component';
import { RelatePhoneViewComponent } from '../relate-phone-view/relate-phone-view.component';
import { NotAvailableInfoComponent } from '../../components/not-available-info/not-available-info.component';
import { ScrollSpinnerComponent } from '../../components/scroll-spinner/scroll-spinner.component';
import { ChipComponent } from 'libs/flame-component-library/src/lib/atoms/chip/chip.component';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import { DataTransferService } from '@santander/flame-core-library';
import { RouterTestingModule } from '@angular/router/testing';
import {
  SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
  AvatarModule,
  SlideButtonModule,
	TokenDialogModule,
  SnackBarModule,
  SearchBarModule,
  AmountFieldModule,
  TokenDialogService,
  ContactDialogModule,
  ContactDialogService,
  ErrorsModule,
  SnCurrencyModule,
  TopBarModule
} from '@santander/flame-component-library';
import {
  NgxMaskModule,
  MaskPipe
} from 'ngx-mask';
import { Injector } from '@angular/core';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';
import {APP_BASE_HREF} from '@angular/common';

fdescribe('RelatePhoneSuccessViewComponent', () => {
  let component: RelatePhoneSuccessViewComponent;
  let fixture: ComponentFixture<RelatePhoneSuccessViewComponent>;
  let dataTransferService: DataTransferService;

  const data = {
    title: '',
    text: '',
    account: {
      related_phone: {
        number: '5530789000',
        company: 'TELCEL'
      }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        RelatePhoneSuccessViewComponent,
        SummaryViewComponent,
        AccountDetailViewComponent,
        ProductsSummaryViewComponent,
        CreditCardDetailViewComponent,
        CreditCardMoneyViewComponent,
        CreditCardVoucherViewComponent,
        ScrollSpinnerComponent,
        ChipComponent,
        NotAvailableInfoComponent,
        RelatePhoneViewComponent ],
      imports: [
        SpinnerModule,
        SlideToggleModule,
        ButtonModule,
        DialogModule,
        CarouselModule,
        CardModule,
        IconModule,
        ReactiveFormsModule,
        FormFieldModule,
        TopBarModule,
        InputModule,
        NotificationModule,
        NavbarModule,
        IconButtonModule,
        ProductModule,
        DialogSelectModule,
        CheckboxModule,
        AccountSelectModule,
        CardSliderModule,
        EmojiModule,
        MotiveFieldModule,
        AvatarModule,
        SlideButtonModule,
        TokenDialogModule,
        SnackBarModule,
        SearchBarModule,
        AmountFieldModule,
        ContactDialogModule,
        ErrorsModule,
        SnCurrencyModule,
        NgxMaskModule.forRoot(),
        RouterTestingModule,
        SummaryOperationLibraryRoutingModule,
        RouterModule.forRoot([
          {
            path: 'summary/global-position',
            component: SummaryViewComponent
          }
        ])
      ],
      providers: [
        DataTransferService,
        ContactDialogService,
        TokenDialogService,
        MaskPipe,
        Injector,
        {provide: APP_BASE_HREF, useValue : '/' } ]
    })
      .compileComponents();
  }));

  beforeEach((done) => {
    dataTransferService = TestBed.get(DataTransferService);
    fixture = TestBed.createComponent(RelatePhoneSuccessViewComponent);
    component = fixture.componentInstance;

    dataTransferService.sendData({
      title: '',
      text: '',
      account: {
        related_phone:{
          number: '5530789000',
          company: 'TELCEL'
        }
      }
    });

    spyOn(dataTransferService, 'getData').and.returnValue(Promise.resolve(data));
    
    fixture.detectChanges();
    done();
  });

  it('should create', async(() => {
    expect(component).toBeTruthy();
  }));

  it('should init', ()=> {
    spyOn((component as any), 'getDataAccount');
    component.ngOnInit();
    expect((component as any).getDataAccount).toHaveBeenCalled();
  });

  it('should this.data is equal to data', () => {
    expect(component.data).toEqual(data);
  } )  

  it('should click navigateToSummary', () => {
    fixture.componentInstance.navigateToSummary();
    fixture.detectChanges();
    expect(fixture.debugElement.nativeElement.click());
  });  

  it('should Promise getDataAccount', () => {
    expect(dataTransferService.getData).toHaveBeenCalled();
  });  

  it('should call navigate', ()=> {
    spyOn((component as any)._router, 'navigate');
    (component as any).navigateToSummary();
    expect((component as any)._router.navigate).toHaveBeenCalled();
  });
});
