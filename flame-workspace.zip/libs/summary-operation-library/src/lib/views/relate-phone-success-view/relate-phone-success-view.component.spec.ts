import {
  async,
  ComponentFixture,
  TestBed
} from '@angular/core/testing';
import { RelatePhoneSuccessViewComponent } from './relate-phone-success-view.component';
import { DataTransferService } from '@santander/flame-core-library';
import { RouterModule } from '@angular/router';
import {
  IconModule,
  ButtonModule,
  TopBarModule
} from '@santander/flame-component-library';
import {
  NgxMaskModule,
  MaskPipe
} from 'ngx-mask';
import { Injector } from '@angular/core';

describe('RelatePhoneSuccessViewComponent', () => {
  let component: RelatePhoneSuccessViewComponent;
  let fixture: ComponentFixture<RelatePhoneSuccessViewComponent>;
  const service = DataTransferService;

  const data = {
    title: '',
    text: '',
    account: {
      related_phone: {
        number: 0,
        company: ''
      }
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RelatePhoneSuccessViewComponent],
      imports: [
        IconModule,
        ButtonModule,
        TopBarModule,
        NgxMaskModule.forRoot(),
        RouterModule.forRoot([])],
      providers: [
        DataTransferService,
        MaskPipe,
        Injector]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelatePhoneSuccessViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should click navigateToSummary', () => {
    fixture.componentInstance.navigateToSummary();
    fixture.detectChanges();
    expect(fixture.debugElement.nativeElement.click());
  });

  it('should Promise getDataAccount', () => {
    spyOn(service.prototype, 'getData').and.callThrough();
    service.prototype.getData();
    expect(service.prototype.getData).toHaveBeenCalled();
  });

  it('should get data', () => {
    expect(component.data);
    expect(component.data.title);
    expect(component.data.text);
    expect(component.data.account);
    expect(component.data.account.related_phone);
    expect(component.data.account.related_phone.number);
    expect(component.data.account.related_phone.company);
  });

});
