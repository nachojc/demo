import {
	async,
	ComponentFixture,
	TestBed,
	inject
} from '@angular/core/testing';
import { RelatePhoneSuccessViewComponent } from './relate-phone-success-view.component';
import { SummaryViewComponent } from '../summary-view/summary-view.component';
import { AccountDetailViewComponent } from '../account-detail-view/account-detail-view.component';
import { ProductsSummaryViewComponent } from '../products-summary-view/products-summary-view.component';
import { CreditCardDetailViewComponent } from '../credit-card-detail-view/credit-card-detail-view.component';
import { CreditCardMoneyViewComponent } from '../credit-card-money-view/credit-card-money-view.component';
import { CreditCardVoucherViewComponent } from '../credit-card-voucher-view/credit-card-voucher-view.component';
import { RelatePhoneViewComponent } from '../relate-phone-view/relate-phone-view.component';
import { NotAvailableInfoComponent } from '../../components/not-available-info/not-available-info.component';
import { ScrollSpinnerComponent } from '../../components/scroll-spinner/scroll-spinner.component';
import { ChipComponent } from 'libs/flame-component-library/src/lib/atoms/chip/chip.component';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import {
	DataTransferService,
	AuthenticationService,
	ENV_CONFIG
} from '@santander/flame-core-library';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	CapitalizeModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
	AvatarModule,
	SlideButtonModule,
	TokenDialogModule,
	SnackBarModule,
	SearchBarModule,
	AmountFieldModule,
	TokenDialogService,
	ContactDialogModule,
	ContactDialogService,
	ErrorsModule,
	SnCurrencyModule,
	TopBarModule,
	HeaderAnimationModule
} from '@santander/flame-component-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { RouterModule, Router } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { APP_BASE_HREF } from '@angular/common';
import {
	Injector,
	CUSTOM_ELEMENTS_SCHEMA,
	NO_ERRORS_SCHEMA
} from '@angular/core';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { SliderViewModule } from 'apps/super-mobile/src/app/components/slider-view/slider-view.module';

describe('RelatePhoneSuccessViewComponent', () => {
	let component: RelatePhoneSuccessViewComponent;
	let fixture: ComponentFixture<RelatePhoneSuccessViewComponent>;
	let dataTransferService: DataTransferService;

	const data = {
		account_key: '3242432432',
		phone_number: '222222',
		operation_date: '12121312',
		company: '1111',
		reference: '111112',
		operationType: '22222'
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			declarations: [
				RelatePhoneSuccessViewComponent,
				SummaryViewComponent,
				AccountDetailViewComponent,
				ProductsSummaryViewComponent,
				CreditCardDetailViewComponent,
				CreditCardMoneyViewComponent,
				CreditCardVoucherViewComponent,
				ScrollSpinnerComponent,
				ChipComponent,
				NotAvailableInfoComponent,
				RelatePhoneViewComponent,
				TransactionFilterPipe
			],
			imports: [
				SpinnerModule,
				SlideToggleModule,
				ButtonModule,
				DialogModule,
				CarouselModule,
				CardModule,
				CapitalizeModule,
				IconModule,
				ReactiveFormsModule,
				FormFieldModule,
				TopBarModule,
				InputModule,
				NotificationModule,
				NavbarModule,
				IconButtonModule,
				ProductModule,
				DialogSelectModule,
				CheckboxModule,
				AccountSelectModule,
				CardSliderModule,
				EmojiModule,
				MotiveFieldModule,
				AvatarModule,
				SlideButtonModule,
				TokenDialogModule,
				SnackBarModule,
				SearchBarModule,
				AmountFieldModule,
				ContactDialogModule,
				ErrorsModule,
				HeaderAnimationModule,
				SnCurrencyModule,
				NgxMaskModule.forRoot(),
				SliderViewModule,
				RouterTestingModule,
				FormsModule,
				SummaryOperationLibraryRoutingModule,
				RouterModule.forRoot([
					{
						path: 'summary/global-position',
						component: SummaryViewComponent
					}
				])
			],
			providers: [
				DataTransferService,
				ContactDialogService,
				TokenDialogService,
				MaskPipe,
				Injector,
				TransactionFilterPipe,
				AuthenticationService,
				{ provide: Injector, useValue: {} },
				{ provide: APP_BASE_HREF, useValue: '/' },
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api'
						}
					}
				}
			]
		}).compileComponents();
	}));

	beforeEach(done => {
		dataTransferService = TestBed.get(DataTransferService);
		dataTransferService.sendData(data);

		fixture = TestBed.createComponent(RelatePhoneSuccessViewComponent);
		component = fixture.componentInstance;

		fixture.detectChanges();
		done();
	});

	it('should create', async(() => {
		expect(component).toBeTruthy();
	}));

	it('should data component is equal to data from dataTransfer', () => {
		expect(component.dataRelated).toEqual(data);
	});

	it('should navigate to summary',() => {
		component.navigateToSummary();	
	});
});