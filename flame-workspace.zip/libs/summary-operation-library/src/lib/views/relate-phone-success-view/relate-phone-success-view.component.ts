import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';

/**
 * Vista para mostrar la respues a una asociasión de teléfono a cuenta
 *
 * @export
 * @class RelatePhoneSuccessViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-relate-phone-success-view',
	templateUrl: './relate-phone-success-view.component.html',
	styleUrls: ['./relate-phone-success-view.component.scss']
})
export class RelatePhoneSuccessViewComponent implements OnInit {
	/**
	 * Crea una instancia de RelatePhoneSuccessViewComponent.
	 * @param {DataTransferService} _dataTransferService
	 * @param {Router} _router
	 * @memberof RelatePhoneSuccessViewComponent
	 */
	constructor(
		private _dataTransferService: DataTransferService,
		private _router: Router
	) {}
	/**
	 * Variables publicas
	 */
	public dataRelated = {
		account_key: '',
		phone_number: '',
		operation_date: '',
		company: '',
    reference: '',
    operationType: ''
	};

	/**
	 *
	 *
	 * @memberof RelatePhoneSuccessViewComponent
	 */
	public navigateToSummary() {
		this._router.navigate(['/summary/global-position']);
	}

	/**
	 * Obtiene los datos para la vista mediante data transfer
	 *
	 * @memberof RelatePhoneSuccessViewComponent
	 */
	ngOnInit() {
		this._dataTransferService.getData().then((data: any) => {
			this.dataRelated = data;
		});
	}
}
