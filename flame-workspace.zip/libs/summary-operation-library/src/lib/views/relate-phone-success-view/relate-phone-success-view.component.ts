import { Component,
          OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';

@Component({
	selector: 'sm-relate-phone-success-view',
	templateUrl: './relate-phone-success-view.component.html',
	styleUrls: ['./relate-phone-success-view.component.scss']
})
export class RelatePhoneSuccessViewComponent implements OnInit {

  constructor(
		private _dataTransferService: DataTransferService,
		private _router: Router
	) {
		this.data = {
			title: '',
			text: '',
			account: {
				related_phone: {
					number: 0,
					company: ''
				}
			}
		};
	}
	public data: any;

	ngOnInit() {
		this.getDataAccount();
	}

	public navigateToSummary() {
		this._router.navigate(['/summary/global-position']);
	}

	private getDataAccount() {
		this._dataTransferService.getData().then((data: any) => {
			this.data = data;
		});
	}
}
