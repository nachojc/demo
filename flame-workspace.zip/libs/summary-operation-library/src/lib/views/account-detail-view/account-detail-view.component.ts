import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountsService } from '../../services/accounts.service';
import { navbarElements } from '../../navbar-menu';
import { DataTransferService } from '@santander/flame-core-library';

import { NotificationService } from '@santander/flame-component-library';
import { AccountDetail } from '../../models/account-detail';
// TODO: Comprobar la forma en la que se usará el plugin para copiar texto.
declare const clipboard: any;

@Component({
	selector: 'sm-account-detail-view.',
	templateUrl: './account-detail-view.component.html',
	styleUrls: ['./account-detail-view.component.scss']
})
export class AccountDetailViewComponent implements OnInit {
	constructor(
		private _accountsService: AccountsService,
		private _route: ActivatedRoute,
		private _router: Router,
		private notificationService: NotificationService,
		private _dataTransferService: DataTransferService
	) {
		this.account = <AccountDetail>{
			product: {},
			related_card: {},
			related_phone: {},
			balance: {},
			latest_transactions: []
		};
	}
	public navbarElements = navbarElements;
	public params: any;
  public account: AccountDetail;
  public card_type: string;

	ngOnInit() {
		this._route.queryParams.subscribe(params => {
      this.params = params;
			this._accountsService.getDetail(params.key).subscribe(response => {
        this.account = response.data;
        this.card_type = params.cardType ? params.cardType : '';
			});
		});
	}

	updateAlias(value: string) {
		if (value !== '') {
			this.account.alias = value;
			this.notificationService.open({
				legend: '¡Modificaste el alias de tu cuenta!',
        type: 'thumbs_up',
        size: 'small'
			});
		}
	}

	copyText(text: string) {
		this.notificationService.open({
			legend: text + ' copiada al portapapeles',
      type: 'thumbs_up',
      size: 'small'
		});
		clipboard.copy(text);
	}

	public navigate() {
		this._router.navigate(['/summary/account-detail'], {
			queryParams: this.params,
			queryParamsHandling: 'merge'
		});
	}

	public navigateRelatePhone() {
    let card_aux: any;
    card_aux = this.account;
    card_aux.card_type = this.card_type;

		this._dataTransferService.sendData(card_aux);
		this._router.navigate(['/summary/relate-phone']);
	}

	navigateMenu(route: string) {
		this._router.navigate([route]);
	}
}
