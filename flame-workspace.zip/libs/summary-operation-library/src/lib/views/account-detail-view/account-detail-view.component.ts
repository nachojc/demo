import { AccountDetail, AccountDetailResponse } from './../../models';
import { Component, OnInit, Inject, Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountsService } from '../../services/accounts.service';
import { CopyTextService } from '../../services/copy-text.service';
import { navbarElements } from '../../navbar-menu';
import { DataTransferService } from '@santander/flame-core-library';
import { Location } from '@angular/common';
import {
	NotificationService,
	ContactDialogService
} from '@santander/flame-component-library';
// TODO: Comprobar la forma en la que se usará el plugin para copiar texto.

/**
 * Vista para visualizar el detalle de una cuenta.
 *
 * @export
 * @class AccountDetailViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-account-detail-view.',
	templateUrl: './account-detail-view.component.html',
	styleUrls: ['./account-detail-view.component.scss']
})
@Injectable()
export class AccountDetailViewComponent implements OnInit {
	/**
	 * Crea una instancia de AccountDetailViewComponent.
	 *
	 * @param {AccountsService} _accountsService
	 * @param {ActivatedRoute} _route
	 * @param {Router} _router
	 * @param {NotificationService} _notificationService
	 * @param {ContactDialogService} _contactDialogService
	 * @param {DataTransferService} _dataTransferService
	 * @memberof AccountDetailViewComponent
	 */
	constructor(
		private _accountsService: AccountsService,
		private _route: ActivatedRoute,
		private _router: Router,
		private _location: Location,
		private _notificationService: NotificationService,
		private _contactDialogService: ContactDialogService,
		private _dataTransferService: DataTransferService,
		private _copyTextService: CopyTextService
	) {
		this.account = <AccountDetail>{
			product: {},
			related_card: {},
			image_url: '',
			related_phone: {},
			balance: {},
			latest_transactions: []
		};
	}

	private type = 1;
	public messageError: string;
	public params: any;
	public navbarElements = navbarElements;
	public account: AccountDetail;
	public card_type: string;
	public serviceError = false;

	/**
	 * Permite copiar datos al portapapeles
	 *
	 * @param {string} text
	 * @memberof AccountDetailViewComponent
	 */
	public copyText(text: string, textToCopy: string): void {
		this._notificationService.open({
			legend: text + ' en el portapapeles',
			type: 'thumbs_up',
			size: 'small'
		});

		this._copyTextService.copyText(textToCopy);
	}

	/**
	 * Permite abrir el modal de contacto "Santander Connect"
	 *
	 * @memberof AccountDetailViewComponent
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**
	 * Permite la navegar a la vista anterior
	 *
	 * @memberof AccountDetailViewComponent
	 */
	public navigateBack(): void {
		this._location.back();
	}

	/**
	 * Permite ir al flujo para relacionar un telefono con la cuenta
	 *
	 * @memberof AccountDetailViewComponent
	 */
	public navigateRelatePhone(): void {
		this._dataTransferService.sendData({
			cardType: this.card_type,
			data: this.account
		});
		this._router.navigate(['/summary/relate-phone']);
	}

	/**
	 * Obtiene el detalle de la cuenta por medio del key
	 *
	 * @memberof AccountDetailViewComponent
	 */
	ngOnInit(): void {
		this._route.queryParams.subscribe(params => {
			this.params = params;
			this._accountsService.getDetail(params.key).subscribe(
				(response: AccountDetailResponse) => {
					this.account = response.data;
					this.card_type = params.cardType ? params.cardType : '';
				},
				error => {
					console.log('error', error);
					this.account.related_card = {
						expiration_date: '--/--',
						number: '---- ---- ---- ----'
					};
					this.messageError =
						error.notifications !== undefined
							? error.notifications[0].message
							: 'No podemos atender tu solicitud, intenta más tarde';
					this.serviceError = true;
				}
			);
		});
	}
}
