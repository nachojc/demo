import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AccountsService } from '../../services/accounts.service';
import { navbarElements } from '../../navbar-menu';
import { DataTransferService } from '@santander/flame-core-library';
import {
	NotificationService,
	ContactDialogService
} from '@santander/flame-component-library';
import { AccountDetail } from '../../models/account-detail';
// TODO: Comprobar la forma en la que se usará el plugin para copiar texto.
declare const clipboard: any;

/**
 * Vista para visualizar el detalle de una cuenta.
 *
 * @export
 * @class AccountDetailViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-account-detail-view.',
	templateUrl: './account-detail-view.component.html',
	styleUrls: ['./account-detail-view.component.scss']
})
export class AccountDetailViewComponent implements OnInit {
	/**
	 * Crea una instancia de AccountDetailViewComponent.
	 *
	 * @param {AccountsService} _accountsService
	 * @param {ActivatedRoute} _route
	 * @param {Router} _router
	 * @param {NotificationService} _notificationService
	 * @param {ContactDialogService} _contactDialogService
	 * @param {DataTransferService} _dataTransferService
	 * @memberof AccountDetailViewComponent
	 */
	constructor(
		private _accountsService: AccountsService,
		private _route: ActivatedRoute,
		private _router: Router,
		private _notificationService: NotificationService,
		private _contactDialogService: ContactDialogService,
		private _dataTransferService: DataTransferService
	) {
		this.account = <AccountDetail>{
			product: {},
			related_card: {},
			related_phone: {},
			balance: {},
			latest_transactions: []
		};
	}

	private type = 1;
	public params: any;
	public navbarElements = navbarElements;
	public account: AccountDetail;
	public card_type: string;

	/**
	 * Permite copiar datos al portapapeles
	 *
	 * @param {string} text
	 * @memberof AccountDetailViewComponent
	 */
	public copyText(text: string): void {
		this._notificationService.open({
			legend: text + ' copiada al portapapeles',
			type: 'thumbs_up',
			size: 'small'
		});
		clipboard.copy(text);
	}

	/**
	 * Permite abrir el modal de "Santander Connect"
	 *
	 * @memberof AccountDetailViewComponent
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**
	 * Permite la navegación de vuelta a products summary
	 *
	 * @memberof AccountDetailViewComponent
	 */
	public navigateToProducts(): void {
		this._router.navigate(['/summary/products-summary'], {
			queryParams: this.params,
			queryParamsHandling: 'merge'
		});
	}

	/**
	 * Permite ir al flujo para relacionar un telefono con cuenta
	 *
	 * @memberof AccountDetailViewComponent
	 */
	public navigateRelatePhone(): void {
    let card_aux: any;
		card_aux = this.account;
		card_aux.card_type = this.card_type;

		this._dataTransferService.sendData(card_aux);
		this._router.navigate(['/summary/relate-phone']);
	}

	/**
	 * Permite la navegación entre opciones del menu
	 *
	 * @param {string} route
	 * @memberof AccountDetailViewComponent
	 */
	public navigateMenu(route: string): void {
		this._router.navigate([route]);
	}

	/**
	 * Obtiene el detalle de la cuenta por medio del key
	 *
	 * @memberof AccountDetailViewComponent
	 */
	ngOnInit(): void {
		this._route.queryParams.subscribe(params => {
			this.params = params;
			this._accountsService.getDetail(params.key).subscribe((response: any) => {
				this.account = response.data;
				this.card_type = params.cardType ? params.cardType : '';
			});
		});
	}
}
