import { Injector } from '@angular/core';
import {
	APP_BASE_HREF,
	CommonModule,
	CurrencyPipe,
	DatePipe,
	Location,
	TitleCasePipe
} from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed,
	inject
} from '@angular/core/testing';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import {
	HttpTestingController,
	HttpClientTestingModule
} from '@angular/common/http/testing';
import { of } from 'rxjs';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
	AvatarModule,
	SlideButtonModule,
	TokenDialogModule,
	SnackBarModule,
	SearchBarModule,
	AmountFieldModule,
	TokenDialogService,
	ContactDialogModule,
	ContactDialogService,
	ErrorsModule,
	SnCurrencyModule,
	AutoWidthInputModule,
	NotificationService,
	HeaderAnimationModule,
	CapitalizeModule
} from '@santander/flame-component-library';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import {
	SummaryService,
	CreditsService,
	AccountsService,
	CopyTextService
} from './../../services';
import { ScrollDirective } from './../../directives';
import {
	SummaryOperationLibraryComponents,
	SummaryOperationLibraryEntryComponents
} from './../../components/summary-operation-library-components';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { AccountDetailViewComponent } from './account-detail-view.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { SliderViewModule } from 'apps/super-mobile/src/app/components/slider-view/slider-view.module';

const accountDetail = {
	data: {
		key: '056722751246',
		number: '00922398411',
		alias: 'MY CHEQUING ACCOUNT',
		product: {
			type: 'Debit card',
			description: 'SUPER NOMINA'
		},
		clabe: '990182 163201 535556',
		related_card: {
			number: '5200 0000 0000 0000',
			product: {
				type: 'Debit card',
				description: 'Tarjeta de debito'
			},
			expiration_date: '11/19'
		},
		related_phone: {
			phone_number: '5589765423',
			company: 'TELCEL'
		},
		balance: {
			amount: 69827.78,
			currency_code: 'MXN'
		},
		latest_transactions: [
			{
				creation_date: '2017-07-21T17:32:28Z',
				amount: {
					amount: 50000.5,
					currency_code: 'MXN'
				},
				description: 'string'
			}
		]
	},
	notifications: [
		{
			code: 'SUCCESS',
			message: 'Success',
			timestamp: '2019-02-12T16:39:09.842Z'
		}
	]
};

describe('AccountDetailViewComponent ', () => {
	const url = 'http://localhost:3000/api/accounts/';
	let injector: TestBed;
	let service: AccountsService;
	let httpMock: HttpTestingController;
	let route: ActivatedRoute;
	let component: AccountDetailViewComponent;
	let fixture: ComponentFixture<AccountDetailViewComponent>;

	const card = {
		key: '056722751246',
		image: 'pref',
		cardType: 'pref',
		status: 'AVAILABLE'
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				CommonModule,
				ContactDialogModule,
				DialogModule,
				SlideToggleModule,
				SpinnerModule,
				IconModule,
				IconButtonModule,
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				NotificationModule,
				NavbarModule,
				IconButtonModule,
				ChipModule,
				ProductModule,
				DialogSelectModule,
				CheckboxModule,
				TopBarModule,
				AccountSelectModule,
				CardSliderModule,
				EmojiModule,
				MotiveFieldModule,
				SlideButtonModule,
				SnackBarModule,
				SummaryOperationLibraryRoutingModule,
				TokenDialogModule,
				SearchBarModule,
				AmountFieldModule,
				HttpClientTestingModule,
				BrowserAnimationsModule,
				NgxMaskModule.forRoot(),
				RouterModule.forRoot([]),
				FormsModule,
				ErrorsModule,
				HeaderAnimationModule,
				SnCurrencyModule.forRoot({
					align: 'right',
					allowNegative: false,
					allowZero: true,
					decimal: '.',
					precision: 2,
					prefix: '',
					suffix: '',
					thousands: ',',
					nullable: true,
					integers: 1
				}),
				AutoWidthInputModule,
				CapitalizeModule,
				SliderViewModule
			],
			declarations: [
				AccountDetailViewComponent,
				...SummaryOperationLibraryComponents,
				...SummaryOperationLibraryViews,
				MoreMainMenuViewComponent,
				ScrollDirective,
				TransactionFilterPipe
			],
			providers: [
				DatePipe,
				TitleCasePipe,
				ContactDialogService,
				CurrencyPipe,
				SummaryService,
				AccountsService,
				CreditsService,
				MaskPipe,
				TokenDialogService,
				TransactionFilterPipe,
				CopyTextService,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api',
							version: {
								summary: '',
								accounts: '',
								credits: '',
								cards: '',
								transfers: ''
							}
						}
					}
				},
				{
					provide: Injector,
					useValue: {}
				},
				{
					provide: APP_BASE_HREF,
					useValue: '/'
				}
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [...SummaryOperationLibraryEntryComponents]
			}
		});

		injector = getTestBed();
		route = injector.get(ActivatedRoute);
		service = injector.get(AccountsService);
		httpMock = injector.get(HttpTestingController);

		route.queryParams = of(card);
	}));

	afterEach(() => {
		httpMock.verify();
	});

	describe('Account detail response complete', () => {
		beforeEach(() => {
			fixture = TestBed.createComponent(AccountDetailViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			const request = httpMock.expectOne(`${url}${card.key}`);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(accountDetail);
			fixture.detectChanges();
		});

		it('Should create AccountDetailViewComponent', () => {
			expect(component).toBeTruthy();
		});

		it('Should open contact phone dialog', inject(
			[ContactDialogService],
			(contactDialog: ContactDialogService) => {
				fixture.detectChanges();
				const snRight = fixture.debugElement.query(
					By.css('sn-top-bar div div.mr-2')
				);
				spyOn(contactDialog, 'openDialogContact');
				snRight.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(contactDialog.openDialogContact).toHaveBeenCalledWith(1);
				});
			}
		));

		it('Should navigate to relate phone', inject([Router], (router: Router) => {
			fixture.detectChanges();
			const relate = fixture.debugElement.query(
				By.css(
					'.account-detail-container .sn-top-container .mt-3 .account-element.mb-4:last-child .row .col-3 p'
				)
			);
			spyOn(router, 'navigate').and.returnValue(true);
			relate.nativeElement.click();
			fixture.whenStable().then(() => {
				expect(router.navigate).toHaveBeenCalledWith(['/summary/relate-phone']);
			});
		}));

		it('Should navigate back', inject([Location], (location: Location) => {
			fixture.detectChanges();
			const snCard = fixture.debugElement.query(By.css('sn-card'));
			spyOn(location, 'back').and.returnValue(true);
			snCard.nativeElement.click();
			fixture.whenStable().then(() => {
				expect(location.back).toHaveBeenCalled();
			});
		}));

		it('Should copy account number to clipboard', inject(
			[NotificationService],
			(notification: NotificationService) => {
				const pCopy = fixture.debugElement.query(
					By.css(
						'.account-detail-container .sn-top-container .mt-3 .account-element.mb-4:nth-child(2) .row .col-3 p'
					)
				);
				spyOn(notification, 'open');
				pCopy.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(notification.open).toHaveBeenCalled();
				});
			}
		));
	});

	describe('Accounts service error', () => {
		beforeEach(() => {
			const mockErrorResponse = { status: 400, statusText: 'Bad Request' };
			fixture = TestBed.createComponent(AccountDetailViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			const request = httpMock.expectOne(`${url}${card.key}`);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(accountDetail, mockErrorResponse);
			fixture.detectChanges();
		});

		it('Should show the error message ', () => {
			expect(component.serviceError).toBeTruthy();
			expect(component.messageError).toEqual(
				'No podemos atender tu solicitud, intenta más tarde'
			);
		});
	});
});
