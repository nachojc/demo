 import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { CreditCardMoneyViewComponent } from './credit-card-money-view.component';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
  AvatarModule,
  SlideButtonModule,
	TokenDialogModule,
  SnackBarModule,
  SearchBarModule,
  AmountFieldModule,
  TokenDialogService,
  ContactDialogModule,
  ContactDialogService,
  ErrorsModule,
  SnCurrencyModule,
  AutoWidthInputModule
} from '@santander/flame-component-library';
import { ENV_CONFIG, DataTransferService } from '@santander/flame-core-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import { CommonModule, DatePipe, TitleCasePipe, CurrencyPipe } from '@angular/common';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import { SummaryService, CreditsService, AccountsService } from './../../services';
import { ScrollDirective, HeaderDirective } from './../../directives';
import { RouterModule } from '@angular/router';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Injector } from '@angular/core';
import { SummaryOperationLibraryComponents, SummaryOperationLibraryEntryComponents } from './../../components/summary-operation-library-components';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { environment } from '../../environments/environment.cert';
const dataService = {
  data: [{
      category_name: 'CHECKING_ACCOUNTS',
      total_balance: {
        currency_code: 'MXN',
        amount: 69827.78
      },
      products: [{
          key: '056722751246',
          alias: null,
          description: 'SUPER NOMINA',
          url: null,
          display_number: '56*5124',
          related_phone: {
            phone_number: '5510555143',
            company: 'TELCEL'
          },
          status: 'AVAILABLE',
          balance: {
            currency_code: 'MXN',
            amount: 69827.78
          }
        },
        {
          key: '056722733565',
          alias: null,
          description: 'SUPER NOMINA',
          url: null,
          display_number: '56*3356',
          related_phone: null,
          status: 'AVAILABLE',
          balance: {
            currency_code: 'USD',
            amount: 0
          }
        }
      ]
    },
    {
      category_name: 'CREDIT_CARDS',
      total_balance: {
        currency_code: 'MXN',
        amount: 85399.66
      },
      products: [{
          key: '4e20fbb243684d9eb19ff33a50ee422e',
          alias: null,
          description: 'SUPER NOMINA',
          url: null,
          display_number: '*3699',
          related_phone: null,
          status: 'AVAILABLE',
          balance: {
            currency_code: 'MXN',
            amount: 1812.1
          }
        },
        {
          key: '1b10lop243683d9eb19ff33a50ee345a',
          alias: null,
          description: 'SUPER NOMINA',
          url: null,
          display_number: '*9981',
          related_phone: null,
          status: 'AVAILABLE',
          balance: {
            currency_code: 'MXN',
            amount: -22038.1
          }
        }
      ]
    }
  ],
  notifications: null,
  paging: null
};

describe('CreditCardMoneyViewComponent', () => {

  const url = environment.baas.urlSummary;
  let injector: TestBed;
  let service: SummaryService;
  let dataTransfer: DataTransferService;
  let httpMock: HttpTestingController;


  beforeEach(async (() => {
    TestBed.configureTestingModule({
        imports: [
          AvatarModule,
          ButtonModule,
          CardModule,
          CarouselModule,
          CommonModule,
          ContactDialogModule,
          DialogModule,
          SlideToggleModule,
          SpinnerModule,
          IconModule,
          IconButtonModule,
          ReactiveFormsModule,
          FormFieldModule,
          InputModule,
          NotificationModule,
          NavbarModule,
          IconButtonModule,
          ChipModule,
          ProductModule,
          DialogSelectModule,
          CheckboxModule,
          TopBarModule,
          AccountSelectModule,
          CardSliderModule,
          EmojiModule,
          MotiveFieldModule,
          SlideButtonModule,
          SnackBarModule,
          SummaryOperationLibraryRoutingModule,
          TokenDialogModule,
          SearchBarModule,
          AmountFieldModule,
          HttpClientTestingModule,
          BrowserAnimationsModule,
          NgxMaskModule.forRoot(),
          RouterModule.forRoot([]),
          FormsModule,
          ErrorsModule,
          SnCurrencyModule.forRoot({
            align: 'right',
            allowNegative: false,
            allowZero: true,
            decimal: '.',
            precision: 2,
            prefix: '',
            suffix: '',
            thousands: ',',
            nullable: true
          }),
          AutoWidthInputModule,
        ],
        declarations: [
          CreditCardMoneyViewComponent,
          ...SummaryOperationLibraryComponents,
          ...SummaryOperationLibraryViews,
          MoreMainMenuViewComponent,
          ScrollDirective,
          HeaderDirective,
          TransactionFilterPipe
        ],
        providers: [
          DatePipe,
          TitleCasePipe,
          ContactDialogService,
          CurrencyPipe,
          SummaryService,
          AccountsService,
          CreditsService,
          MaskPipe,
          TokenDialogService,
          TransactionFilterPipe,
          {
            provide: ENV_CONFIG,
            useValue: {
              baas: {
                urlSummary: 'http://localhost:3000/summaryBaas',
                urlTransactions: 'http://localhost:3000/accounts/',
                urlCredits: 'https://localhost:3000/credits/',
                urlCards: 'http://localhost:3000/cards/',
                urlTransfersSameBank: 'http://localhost:3000/transfers/',
                urlPayments: 'http://localhost:3000/payments/'
              }
            }
          },
          {
            provide: Injector,
            useValue: {}
          }
        ]
      })
      .compileComponents();
    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
        entryComponents: [...SummaryOperationLibraryEntryComponents]
      }
    });

    injector = getTestBed();
    dataTransfer = injector.get(DataTransferService);
    service = injector.get(SummaryService);
    httpMock = injector.get(HttpTestingController);
  }));


  afterEach(() => {
    httpMock.verify();
  });


  describe('Client with all the types of products', () => {
    let component: CreditCardMoneyViewComponent;
    let fixture: ComponentFixture < CreditCardMoneyViewComponent > ;

    beforeEach(() => {
      fixture = TestBed.createComponent(CreditCardMoneyViewComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();

      const request = httpMock.expectOne(url);
      expect(request.request.method).toEqual('GET');
      expect(request.request.responseType).toEqual('json');
      request.flush(dataService);
      fixture.detectChanges();
    });

    it('Should create alternative flow of SummaryViewComponent', () => {
			expect(component).toBeTruthy();
		});

    it('should click navigateVoucher', () => {
      fixture.componentInstance.navigateVoucher();
      fixture.detectChanges();
    });

    it('Should open dialog Phone', () => {
      fixture.componentInstance.openPhoneDialog();
      fixture.detectChanges();
    });
  });
});
