import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed,
	inject
} from '@angular/core/testing';
import { CreditCardMoneyViewComponent } from './credit-card-money-view.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpRequest } from '@angular/common/http';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
	AvatarModule,
	SlideButtonModule,
	TokenDialogModule,
	SnackBarModule,
	SearchBarModule,
	AmountFieldModule,
	TokenDialogService,
	ContactDialogModule,
	ContactDialogService,
	ErrorsModule,
	SnCurrencyModule,
	AutoWidthInputModule,
	HeaderAnimationModule
} from '@santander/flame-component-library';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import {
	CommonModule,
	DatePipe,
	TitleCasePipe,
	CurrencyPipe,
	APP_BASE_HREF
} from '@angular/common';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import {
	SummaryService,
	CreditsService,
	AccountsService
} from './../../services';
import { ScrollDirective } from './../../directives';
import { RouterModule, Router } from '@angular/router';
import {
	HttpClientTestingModule,
	HttpTestingController
} from '@angular/common/http/testing';
import { Injector, DebugElement } from '@angular/core';
import {
	SummaryOperationLibraryComponents,
	SummaryOperationLibraryEntryComponents
} from './../../components/summary-operation-library-components';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { By } from '@angular/platform-browser';

const dataService = {
	data: [
		{
			category_name: 'CHECKING_ACCOUNTS',
			total_balance: {
				currency_code: 'MXN',
				amount: 69827.78
			},
			products: [
				{
					key: '056722751246',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '56*5124',
					related_phone: {
						phone_number: '5510555143',
						company: 'TELCEL'
					},
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: 69827.78
					}
				},
				{
					key: '056722733565',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '56*3356',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'USD',
						amount: 0
					}
				}
			]
		},
		{
			category_name: 'CREDIT_CARDS',
			total_balance: {
				currency_code: 'MXN',
				amount: 85399.66
			},
			products: [
				{
					key: '4e20fbb243684d9eb19ff33a50ee422e',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '*3699',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: 1812.1
					}
				},
				{
					key: '1b10lop243683d9eb19ff33a50ee345a',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '*9981',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: -22038.1
					}
				}
			]
		}
	],
	notifications: null,
	paging: null
};
const dataForm = {
	amount: 3000,
	motive: 'Transferencia'
};
const dataFormCorrect = {
	amount: 1000,
	motive: 'Transferencia'
};

describe('CreditCardMoneyViewComponent', () => {
	const url = 'http://localhost:3000/api/summary';
	let injector: TestBed;
	let service: SummaryService;
	let httpMock: HttpTestingController;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				CommonModule,
				ContactDialogModule,
				DialogModule,
				SlideToggleModule,
				SpinnerModule,
				IconModule,
				IconButtonModule,
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				NotificationModule,
				NavbarModule,
				IconButtonModule,
				ChipModule,
				ProductModule,
				DialogSelectModule,
				CheckboxModule,
				TopBarModule,
				AccountSelectModule,
				CardSliderModule,
				EmojiModule,
				MotiveFieldModule,
				SlideButtonModule,
				SnackBarModule,
				SummaryOperationLibraryRoutingModule,
				TokenDialogModule,
				SearchBarModule,
				AmountFieldModule,
				HttpClientTestingModule,
				BrowserAnimationsModule,
				RouterTestingModule,
				NgxMaskModule.forRoot(),
				RouterModule.forRoot([]),
				FormsModule,
				ErrorsModule,
				HeaderAnimationModule,
				SnCurrencyModule.forRoot({
          align: 'right',
          allowNegative: false,
          allowZero: true,
          decimal: '.',
          precision: 2,
          prefix: '',
          suffix: '',
          thousands: ',',
          nullable: true,
          integers: 2
        }),
				AutoWidthInputModule
			],
			declarations: [
				CreditCardMoneyViewComponent,
				...SummaryOperationLibraryComponents,
				...SummaryOperationLibraryViews,
				MoreMainMenuViewComponent,
				ScrollDirective,
				TransactionFilterPipe
			],
			providers: [
				DatePipe,
				TitleCasePipe,
				ContactDialogService,
				CurrencyPipe,
				SummaryService,
				AccountsService,
				CreditsService,
				MaskPipe,
				TokenDialogService,
				TransactionFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api'
						}
					}
				},
				{
					provide: Injector,
					useValue: {}
				},
				{ provide: APP_BASE_HREF, useValue: '/' }
			]
		}).compileComponents();
		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [...SummaryOperationLibraryEntryComponents]
			}
		});

		injector = getTestBed();
		service = injector.get(SummaryService);
		httpMock = injector.get(HttpTestingController);
	}));

	afterEach(() => {
		httpMock.verify();
	});

	describe('Load products from summary service', () => {
		let component: CreditCardMoneyViewComponent;
		let fixture: ComponentFixture<CreditCardMoneyViewComponent>;
		let button: DebugElement;

		beforeEach(() => {
			fixture = TestBed.createComponent(CreditCardMoneyViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			const request = httpMock.expectOne(
				(req: HttpRequest<any>) =>
					req.urlWithParams === `${url}?page=1&limit=10`
			);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(dataService);
			fixture.detectChanges();
			button = fixture.debugElement.query(By.css('button'));
		});

		it('Should create SummaryViewComponent', () => {
			expect(component).toBeTruthy();
		});

		it('should button be disabled at the start', () => {
			expect(button.nativeElement.disabled).toBeTruthy();
		});

		it('should show error message when amount is bigger than tdc available', async(() => {
			component.formCreditCard.get('amount').setValue(dataForm.amount);
			fixture.whenStable().then(() => {
				expect(button.nativeElement.disabled).toBeTruthy();
			});
		}));

		it('should navigate to voucher view', inject([Router], (router: Router) => {
			spyOn(router, 'navigate').and.returnValue(true);
			component.formCreditCard.get('amount').setValue(dataFormCorrect.amount);
			fixture.detectChanges();
			expect(button.nativeElement.disabled).toBeFalsy();
			button.nativeElement.click();
			fixture.whenStable().then(() => {
				expect(router.navigate).toHaveBeenCalled();
			});
		}));

		it('Should open contact phone dialog', inject(
			[ContactDialogService],
			(contactDialog: ContactDialogService) => {
				fixture.detectChanges();
				const snRight = fixture.debugElement.query(
					By.css('sn-top-bar div div.mr-2')
				);
				spyOn(contactDialog, 'openDialogContact');
				snRight.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(contactDialog.openDialogContact).toHaveBeenCalledWith(1);
				});
			}
		));
	});
});
