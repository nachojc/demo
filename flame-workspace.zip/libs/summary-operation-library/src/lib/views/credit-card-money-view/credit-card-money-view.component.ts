import { AccountSelectComponent } from './../../../../../flame-component-library/src/lib/molecules/accounts-select/account-select.component';
import { SummaryResponse, Summary, Products } from './../../models';
import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SummaryService } from '../../services/summary.service';
import { InvalidOperationComponent } from './../../components/invalid-operation/invalid-operation.component';
import {
	DialogService,
	DialogReference,
	CustomDialog,
	TokenDialogService,
  ContactDialogService
} from '@santander/flame-component-library';

import {
	fadeOutManual,
	fadeInManual,
	contactListIn
} from '@santander/flame-component-library';
import { Validators, FormBuilder } from '@angular/forms';
@Component({
  selector: 'sm-credit-card-money',
  templateUrl: './credit-card-money-view.component.html',
  styleUrls: ['./credit-card-money-view.component.scss'],
  animations: [fadeOutManual, fadeInManual, contactListIn]
})
export class CreditCardMoneyViewComponent implements OnInit {

  /**
   * Crea una instancia de CreditCardMoneyViewComponent.
   */
  constructor(
    private router: Router,
    private _route: ActivatedRoute,
    private _summaryService: SummaryService,
    private dialog: DialogService,
    private _contactDialogService: ContactDialogService,
    private formBuilder: FormBuilder
  ) {
    this.initAccount();
  }

  /**
   * Variables Privadas
   */
  private dialogRef: DialogReference;


  /**
   * Variables Publicas
   */
  public motive = 'Transferencia';
  public quantity = 0;
  public accounts: Array < Products > = [];
  public credits: Array < Products > = [];
  public type = 1;
  public formCreditCard: any;
  public tdc: any = {
    balance: {}
  };
  public account: any = {};
  public cardImages = [
    './assets/icons/card-amex.svg',
    './assets/icons/card-aero.svg',
    './assets/icons/card-basic.svg',
    './assets/icons/card-pref.svg'
  ];

  /**
   * @private
   * @memberof CreditCardMoneyViewComponent
   */
  private initAccount() {
    this.account = {
      product: {},
      related_phone: {},
      balance: {}
    };
  }

  /**
   * @TODO: MODIFICAR LLAMADA PARA CORREGIR EL SERVICIO
   */
  private getSummary() {
    this._summaryService.getSummary().subscribe((response: SummaryResponse) => {
      response.data.map((summary: Summary) => {
        if (summary.category_name === 'CREDIT_CARDS') {
          this.credits = summary.products;
          this.setImages(this.credits);
        }
        if (summary.category_name === 'CHECKING_ACCOUNTS') {
          this.accounts = summary.products;
          this.setImages(this.accounts);
        }
      });
      if (this.tdc.key === undefined) {
        this.tdc = this.credits[0];
      }
      if (this.account.key === undefined) {
        this.account = this.accounts[0];
      }
    });
  }


  /**
   * Llama al componente "invalid-operation.component"
   */
  private showInvalidOperation(titleInvalid: string, message: string, url: string) {
    this.dialogRef = this.dialog.open({
        closeLabel: 'Cerrar',
        title: 'Operación inválida',
        enableHr: true,
        disabledButton: true,
        buttons: [{
          label: ''
        }]
      },
      new CustomDialog(InvalidOperationComponent, {
        title: titleInvalid,
        message: message,
        url: url
      })
    );
    this.dialogRef.beforeClose().subscribe(_ => {});
  }

  /**
   * Método encargado del abrir el modal de "Santander Connect"
   */
  openPhoneDialog() {
    this._contactDialogService.openDialogContact(this.type);
  }


  /**
   * Método encargado de validar que se cumpla el proceso para generar comprobante
   * Si no se cumple las condiciones, muestra modal del componente "invalid-operation.component"
   */
  navigateVoucher() {
    if (
      this.quantity > 0 &&
      this.motive !== '' &&
      this.quantity < this.tdc.balance.amount
    ) {
      const cardImage = this.tdc.card_type.substring(20);
      this.router.navigate(['/summary/credit-card-voucher'], {
        queryParams: {
          key: this.tdc.key,
          account: this.tdc.display_number,
          image: cardImage.substr(0, cardImage.length - 4),
          selAccount: this.account.display_number,
          type: this.account.card_type,
          displayName: this.account.description,
          voucherType: 'SPEI',
          quantity: this.quantity,
          motive: this.motive
        },
        queryParamsHandling: 'merge'
      });
    } else if (
      this.quantity > this.tdc.balance.amount ||
      this.tdc.balance.amount < 0
    ) {
      this.showInvalidOperation(
        'Necesitas más saldo',
        'Por ahora no cuentas con fondos suficientes para realizar esta operación',
        './assets/no-money.svg'
      );
    }
  }

  public getRandomImage(arrayImage) {
    return arrayImage[Math.floor(Math.random() * arrayImage.length)];
  }


  /**
   * Método que crea un array con los resultados de la llamada a la función
   */
  setImages(products: any) {
    products.map((item: any) => {
      item.card_type = this.getRandomImage(this.cardImages);
      item.product = {
        description: item.description
      };
      item.number = item.display_number;
    });
  }

  /**
   * Método que valida el valor de entrada del componente "motive-field"
   */
  getMotive(motive: string) {
    this.motive = motive === '' ? 'Transferencia' : motive;
  }

   /**
   * Método que almacena el valor introducido en el componente "amount-field"
   */
  getQuantity(quantity: number) {
    this.quantity = quantity;
    this.verifyAmounts();
  }
  /**
  * Verifica la cantidad ingresada con la disponible en la tdc
  */
 public verifyAmounts() {
  if (this.tdc.key) {
      const money = this.formCreditCard.get('myAmount').value;
      if (money > this.tdc.balance.amount || this.tdc.balance.amount < 0) {
          this.formCreditCard.get('myAmount').setErrors({
              max: true
          });
      } else {
          this.formCreditCard.get('myAmount').setErrors({
              max: null
          });
          this.formCreditCard.get('myAmount').updateValueAndValidity();
      }
  }
}

  /**
   * Inicializar el componente una vez recibido las propiedades de entrada
   * Se implementa los Validators del componente "amount-field"
   */
  ngOnInit() {
    this.getSummary();
    this._route.queryParams.subscribe(params => {
      this.tdc = {
        key: params.key,
        balance: {
          amount: params. amount,
          currency_code: params.currency
        },
        display_number: params.account,
        number: params.account,
        product: {
          description: params.displayName
        },
        card_type: params.type
      };
    });

    this.formCreditCard = this.formBuilder.group({
      myAmount: [0, [Validators.max(this.tdc.balance.amount), Validators.min(0), Validators.required]]
    });
  }
}
