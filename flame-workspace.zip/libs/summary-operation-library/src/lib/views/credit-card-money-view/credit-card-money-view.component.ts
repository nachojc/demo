import {
	SummaryResponse,
	Summary,
	Products,
	ProductsFront
} from './../../models';
import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute } from '@angular/router';
import { SummaryService } from '../../services/summary.service';
import { ContactDialogService } from '@santander/flame-component-library';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';

/**
 * Vista para disponer de efectivo de una tdc a una cuenta.
 *
 * @export
 * @class CreditCardMoneyViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-credit-card-money',
	templateUrl: './credit-card-money-view.component.html',
	styleUrls: ['./credit-card-money-view.component.scss']
})
export class CreditCardMoneyViewComponent implements OnInit {
	/**
	 * Crea una instancia de CreditCardMoneyViewComponent.
	 * @param {Router} _router
	 * @param {ActivatedRoute} _route
	 * @param {SummaryService} _summaryService
	 * @param {ContactDialogService} _contactDialogService
	 * @param {FormBuilder} _formBuilder
	 * @param {Location} _location
	 * @memberof CreditCardMoneyViewComponent
	 */
	constructor(
		private _router: Router,
		private _route: ActivatedRoute,
		private _summaryService: SummaryService,
		private _contactDialogService: ContactDialogService,
		private _formBuilder: FormBuilder,
		private _location: Location
	) {}

	private type = 1;
	private cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];
	public motive = 'Transferencia';
	public quantity = 0;
	public accounts: Array<Products> = [];
	public credits: Array<Products> = [];
	public formCreditCard: FormGroup;
	public tdc: any = {
		balance: {}
	};
	public account: any = {};

	/**
	 * Obtiene una imagen aleatoria para un producto.
	 *
	 * @private
	 * @returns {string}
	 * @memberof CreditCardMoneyViewComponent
	 */
	private getRandomImage(): string {
		return this.cardImages[Math.floor(Math.random() * this.cardImages.length)];
	}

	/**
	 * Método que crea un array con los resultados de la llamada a la función
	 */
	private setImages(products: Array<ProductsFront>): void {
		products.map((item: any) => {
			item.card_type = this.getRandomImage();
			item.product = {
				description: item.description
			};
			item.number = item.display_number;
		});
	}

	/**
	 * Obtiene las cuentas y tarjetas disponibles del cliente.
	 *
	 * @TODO MODIFICAR LLAMADA PARA CORREGIR EL SERVICIO
	 * @private
	 * @memberof CreditCardMoneyViewComponent
	 */
	private getSummary(): void {
		this._summaryService.getSummary().subscribe((response: SummaryResponse) => {
			response.data.map((summary: Summary) => {
				if (summary.category_name === 'CREDIT_CARDS') {
					this.credits = summary.products;
					this.setImages(this.credits);
				}
				if (summary.category_name === 'CHECKING_ACCOUNTS') {
					this.accounts = summary.products;
					this.setImages(this.accounts);
				}
			});
			if (this.tdc.key === undefined) {
				this.tdc = this.credits[0];
			}
			if (this.account.key === undefined) {
				this.account = this.accounts[0];
			}
		});
	}

	/**
	 * Método encargado del abrir el modal de "Santander Connect"
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**
	 * Método encargado de validar que se cumpla el proceso para generar comprobante
	 * Si no se cumple las condiciones, muestra modal del componente "invalid-operation.component"
	 */
	public navigateVoucher(): void {
		const cardImage = this.tdc.card_type.substring(20);
		this._router.navigate(['/summary/credit-card-voucher'], {
			queryParams: {
				key: this.tdc.key,
				account: this.tdc.display_number,
				image: cardImage.substr(0, cardImage.length - 4),
				selAccount: this.account.display_number,
				type: this.account.card_type,
				displayName: this.account.description,
				voucherType: 'SPEI',
				quantity: this.quantity,
				motive: this.motive
			},
			queryParamsHandling: 'merge'
		});
	}

	/**
	 * Método que valida el valor de entrada del componente "motive-field"
	 */
	public getMotive(motive: string): void {
		this.motive = motive === '' ? 'Transferencia' : motive;
	}

	/**
	 * Método que almacena el valor introducido en el componente "amount-field"
	 */
	public getQuantity(quantity: number): void {
		this.quantity = quantity;
		this.verifyAmounts();
	}

	/**
	 * Verifica la cantidad ingresada con la disponible en la tdc
	 */
	public verifyAmounts(): void {
		if (this.tdc.key) {
			const money = this.formCreditCard.get('amount').value;

			if (money > this.tdc.balance.amount || this.tdc.balance.amount < 0) {
				this.formCreditCard.get('amount').setErrors({
					max: true
				});
			} else {
				this.formCreditCard.get('amount').setErrors({
					max: null
				});
				this.formCreditCard.get('amount').updateValueAndValidity();
			}
		}
	}

	/**
	 * Permite regresar a la vista anterior.
	 *
	 * @memberof CreditCardMoneyViewComponent
	 */
	public navigateBack(): void {
		this._location.back();
	}

	/**
	 * Inicializar el componente una vez recibido las propiedades de entrada
	 * Se implementa los Validators del componente "amount-field"
	 */
	ngOnInit(): void {
		this.getSummary();
		this._route.queryParams.subscribe(params => {
			this.tdc = {
				key: params.key,
				balance: {
					amount: params.amount,
					currency_code: params.currency
				},
				display_number: params.account,
				number: params.account,
				product: {
					description: params.displayName
				},
				card_type: params.type
			};
		});

		this.formCreditCard = this._formBuilder.group({
			amount: [
				0,
				[
					Validators.max(this.tdc.balance.amount),
					Validators.min(0),
					Validators.required
				]
			]
		});
	}
}
