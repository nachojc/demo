import { Injector } from '@angular/core';
import {
	APP_BASE_HREF,
	CommonModule,
	CurrencyPipe,
	DatePipe,
	Location,
	TitleCasePipe
} from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed,
	inject
} from '@angular/core/testing';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import {
	HttpTestingController,
	HttpClientTestingModule
} from '@angular/common/http/testing';
import { of } from 'rxjs';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	CapitalizeModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
	AvatarModule,
	SlideButtonModule,
	TokenDialogModule,
	SnackBarModule,
	SearchBarModule,
	AmountFieldModule,
	TokenDialogService,
	ContactDialogModule,
	ContactDialogService,
	ErrorsModule,
	SnCurrencyModule,
	AutoWidthInputModule,
	NotificationService,
	HeaderAnimationModule
} from '@santander/flame-component-library';
import { ENV_CONFIG, DataTransferService } from '@santander/flame-core-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import {
	SummaryService,
	CreditsService,
	AccountsService,
	CopyTextService
} from './../../services';
import { ScrollDirective } from './../../directives';
import {
	SummaryOperationLibraryComponents,
	SummaryOperationLibraryEntryComponents
} from './../../components/summary-operation-library-components';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { CreditCardDetailViewComponent } from './credit-card-detail-view.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { SliderViewModule } from 'apps/super-mobile/src/app/components/slider-view/slider-view.module';

const cardDetail = {
	data: {
		key: '4e20fbb243684d9eb19ff33a50ee422e',
		name: 'Aeromexico Blanca',
		alias: 'Tarjeta de Crédito Aeromexico',
		status: 'ACTIVE',
		balance: {
			amount: 0,
			currency_code: 'MXN'
		},
		related_cards: [
			{
				display_number: '5474840000073614',
				relation_type: 'Primary',
				expiration_date: '05/22',
				url: '/cards/{card-key}'
			}
		],
		minimum_payment: {
			amount: 0,
			currency_code: 'MXN'
		},
		due_date: '2019-04-16T00:00:00',
		statement_balance: {
			amount: 25090.96,
			currency_code: 'MXN'
		},
		statement_date: '2019-04-26T00:00:00',
		available_credit: {
			amount: 25090.96,
			currency_code: 'MXN'
		},
		credit_limit: {
			amount: 25111,
			currency_code: 'MXN'
		},
		fixed_payment: {
			amount: 0,
			currency_code: 'MXN'
		}
	},
	notifications: null
};

describe('CreditCardDetailViewComponent ', () => {
	// const url = environment.baas.urlCredits;
	const url = 'http://localhost:3000/api/credits/';
	let injector: TestBed;
	let service: CreditsService;
	let httpMock: HttpTestingController;
	let route: ActivatedRoute;
	let component: CreditCardDetailViewComponent;
	let fixture: ComponentFixture<CreditCardDetailViewComponent>;

	const card = {
		key: '4e20fbb243684d9eb19ff33a50ee422e',
		image: 'aero',
		cardType: 'aero'
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				ButtonModule,
				CapitalizeModule,
				CardModule,
				CarouselModule,
				CommonModule,
				ContactDialogModule,
				DialogModule,
				SlideToggleModule,
				SpinnerModule,
				IconModule,
				IconButtonModule,
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				NotificationModule,
				NavbarModule,
				IconButtonModule,
				ChipModule,
				ProductModule,
				DialogSelectModule,
				CheckboxModule,
				TopBarModule,
				AccountSelectModule,
				CardSliderModule,
				EmojiModule,
				MotiveFieldModule,
				SlideButtonModule,
				SnackBarModule,
				SummaryOperationLibraryRoutingModule,
				TokenDialogModule,
				SearchBarModule,
				AmountFieldModule,
				HttpClientTestingModule,
				BrowserAnimationsModule,
				HeaderAnimationModule,
				NgxMaskModule.forRoot(),
				RouterModule.forRoot([]),
				FormsModule,
				ErrorsModule,
				SliderViewModule,
				SnCurrencyModule.forRoot({
					align: 'right',
					allowNegative: false,
					allowZero: true,
					decimal: '.',
					precision: 2,
					prefix: '',
					suffix: '',
					thousands: ',',
					nullable: true,
					integers: 1
				}),
				AutoWidthInputModule
			],
			declarations: [
				CreditCardDetailViewComponent,
				...SummaryOperationLibraryComponents,
				...SummaryOperationLibraryViews,
				MoreMainMenuViewComponent,
				ScrollDirective,
				TransactionFilterPipe
			],
			providers: [
				DatePipe,
				TitleCasePipe,
				ContactDialogService,
				CurrencyPipe,
				SummaryService,
				AccountsService,
				CreditsService,
				MaskPipe,
				TokenDialogService,
				DataTransferService,
				TransactionFilterPipe,
				CopyTextService,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api',
							version: {
								summary: '',
								accounts: '',
								credits: '',
								cards: '',
								transfers: ''
							}
						}
					}
				},
				{
					provide: Injector,
					useValue: {}
				},
				{
					provide: APP_BASE_HREF,
					useValue: '/'
				}
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [...SummaryOperationLibraryEntryComponents]
			}
		});

		injector = getTestBed();
		route = injector.get(ActivatedRoute);
		service = injector.get(CreditsService);
		httpMock = injector.get(HttpTestingController);

		route.queryParams = of(card);
	}));

	afterEach(() => {
		httpMock.verify();
	});

	describe('Card detail response complete', () => {
		beforeEach(() => {
			fixture = TestBed.createComponent(CreditCardDetailViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			const request = httpMock.expectOne(`${url}${card.key}`);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(cardDetail);
			fixture.detectChanges();
		});

		it('Should create CreditCardDetailViewComponent', () => {
			expect(component).toBeTruthy();
		});

		it('Should open contact phone dialog', inject(
			[ContactDialogService],
			(contactDialog: ContactDialogService) => {
				fixture.detectChanges();
				const snRight = fixture.debugElement.query(
					By.css('sn-top-bar div div.mr-2')
				);
				spyOn(contactDialog, 'openDialogContact');
				snRight.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(contactDialog.openDialogContact).toHaveBeenCalledWith(1);
				});
			}
		));

		it('Should navigate to payments', inject([Router], (router: Router) => {
			fixture.detectChanges();
			const buttonPayment = fixture.debugElement.query(By.css('button'));
			spyOn(router, 'navigate').and.returnValue(true);
			buttonPayment.nativeElement.click();
			fixture.whenStable().then(() => {
				expect(router.navigate).toHaveBeenCalledWith([
					'/payments/card-payments'
				]);
			});
		}));

		it('Should navigate back', inject([Location], (location: Location) => {
			fixture.detectChanges();
			const snCard = fixture.debugElement.query(By.css('sn-card'));
			spyOn(location, 'back').and.returnValue(true);
			snCard.nativeElement.click();
			fixture.whenStable().then(() => {
				expect(location.back).toHaveBeenCalled();
			});
		}));

		it('Should copy card number to clipboard', inject(
			[NotificationService],
			(notification: NotificationService) => {
				const spanCopy = fixture.debugElement.query(
					By.css('.element-detail.spacing span')
				);
				spyOn(notification, 'open');
				spanCopy.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(notification.open).toHaveBeenCalled();
				});
			}
		));
	});

	describe('Credits service error', () => {
		beforeEach(() => {
			const mockErrorResponse = { status: 400, statusText: 'Bad Request' };
			fixture = TestBed.createComponent(CreditCardDetailViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			const request = httpMock.expectOne(`${url}${card.key}`);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(cardDetail, mockErrorResponse);
			fixture.detectChanges();
		});

		it('Should show the error message ', () => {
			const errorContainer = fixture.debugElement.nativeElement.querySelector(
				'sm-not-available-info'
			);
			expect(component.messageError).toEqual(
				'No podemos atender tu solicitud, intenta más tarde'
			);
			expect(component.serviceError).toBeTruthy();
			expect(errorContainer).toBeTruthy();
		});
	});
});
