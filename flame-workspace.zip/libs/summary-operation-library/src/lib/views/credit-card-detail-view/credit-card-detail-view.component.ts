// Angular
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// Components
import { NotificationService, ContactDialogService } from '@santander/flame-component-library';
// Services
import { CreditsService } from '../../services/credits.service';
// Interfaces
import { CreditDetailResponse, CreditDetail, Card } from '../../models';
// Navbar
import { navbarElements } from '../../navbar-menu';
// TODO: Comprobar la forma en la que se usará el plugin para copiar texto.
declare const clipboard: any;

@Component({
	selector: 'sm-credit-card-detail-view.',
	templateUrl: './credit-card-detail-view.component.html',
	styleUrls: ['./credit-card-detail-view.component.scss']
})
export class CreditCardDetailViewComponent implements OnInit {
	constructor(
		private _creditsService: CreditsService,
		private _route: ActivatedRoute,
		private _router: Router,
    private notificationService: NotificationService,
    private _contactDialogService: ContactDialogService
	) {
		this.tdc = <CreditDetail>{
			related_cards: [],
			available_credit: {},
			credit_limit: {},
			balance: {},
			statement_balance: {},
			fixed_payment: {},
			minimum_payment: {}
		};
	}
	public params: any;
	public tdc: CreditDetail;
	public main_card: Card = {};
	public card_type: string;
	public navbarElements = navbarElements;
  public serviceError = false;
  public type = 1;


	ngOnInit() {
		this._route.queryParams.subscribe(params => {
			this.params = params;
			this._creditsService.getCardDetail(params.key).subscribe(
				(response: CreditDetailResponse) => {
					if (response.data !== null) {
						this.tdc = response.data;
						this.main_card = this.tdc.related_cards[0];
						this.tdc.related_cards.map((card: Card) => {
							if (card.relation_type === 'MAIN') {

								this.main_card = card;
							}
						});
						this.card_type = params.image
							? params.image
							: params.cardType
							? params.cardType
							: '';
					}
				},
				error => {
					this.serviceError = true;
					// console.log(error)
				}
			);
		});
	}

	updateAlias(value: string) {
		if (value !== '') {
			this.tdc.alias = value;
			this.notificationService.open({
				legend: '¡Cambiaste tu alias exitosamente!',
				icon: 'sn-mensaje'
			});
		}
	}

	copyText(text: string) {
		this.notificationService.open({
			legend: 'Copiado al portapapeles',
			icon: 'sn-mensaje'
		});
		clipboard.copy(text);
	}

	public navigate() {
		this._router.navigate(['/summary/credit-card-summary'], {
			queryParams: this.params,
			queryParamsHandling: 'merge'
		});
	}

	navigateMenu(route: string) {
		this._router.navigate([route]);
	}

	public navigatePayment() {
		this._router.navigate(['/payments/card-payments']);
  }
  openPhoneDialog() {
    this._contactDialogService.openDialogContact(this.type);
  }
}
