// Angular
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// Components
import { NotificationService, ContactDialogService } from '@santander/flame-component-library';
// Services
import { CreditsService } from '../../services/credits.service';
// Interfaces
import { CreditDetailResponse, CreditDetail, Card } from '../../models';
// Navbar
import { navbarElements } from '../../navbar-menu';
// TODO: Comprobar la forma en la que se usará el plugin para copiar texto.
declare const clipboard: any;

@Component({
  selector: 'sm-credit-card-detail-view.',
  templateUrl: './credit-card-detail-view.component.html',
  styleUrls: ['./credit-card-detail-view.component.scss']
})
export class CreditCardDetailViewComponent implements OnInit {

  /**
   * Crea una instancia de CreditCardDetailViewComponent.
   */
  constructor(
    private _creditsService: CreditsService,
    private _route: ActivatedRoute,
    private _router: Router,
    private notificationService: NotificationService,
    private _contactDialogService: ContactDialogService
  ) {
    this.tdc = < CreditDetail > {
      related_cards: [],
      available_credit: {},
      credit_limit: {},
      balance: {},
      statement_balance: {},
      fixed_payment: {},
      minimum_payment: {}
    };
  }


  /**
   * Variables Publicas
   */
  public params: any;
  public tdc: CreditDetail;
  public main_card: Card = {};
  public card_type: string;
  public navbarElements = navbarElements;
  public serviceError = false;
  public type = 1;

  /**
   * Permite la navegación a la vista
   */

  public navigate() {
    this._router.navigate(['/summary/products-summary'], {
      queryParams: this.params,
      queryParamsHandling: 'merge'
    });
  }

  /**
   * Permite la navegación a la vista de pago de tarjeta
   */
  public navigatePayment() {
    this._router.navigate(['/payments/card-payments']);
  }

  /**
   * Permite copiar en numero de tarjeta
   */
  copyText(text: string) {
    this.notificationService.open({
      legend: 'Copiado al portapapeles',
      icon: 'sn-mensaje'
    });
    clipboard.copy(text);
  }

  /**
   * Permite la navegación de una vista a la siguiente a medida que los usuarios realizan tareas
   */
  navigateMenu(route: string) {
    this._router.navigate([route]);
  }

  /**
   * Método encargado del abrir el modal de "Santander Connect"
   */
  openPhoneDialog() {
    this._contactDialogService.openDialogContact(this.type);
  }


  /**@TODO: VALIDAR FLUJO DE CAMBIO DE ALIAS EN HU FUTURAS */
  /** updateAlias(value: string) {
  	if (value !== '') {
  		this.tdc.alias = value;
  		this.notificationService.open({
  			legend: '¡Cambiaste tu alias exitosamente!',
  			icon: 'sn-mensaje'
  		});
  	}
  } */


  /**
   * Inicializar el componente una vez recibido las propiedades de entrada
   * @memberof CreditCardDetailViewComponent
   */
  ngOnInit() {
    this._route.queryParams.subscribe(params => {
      this.params = params;
      this._creditsService.getCardDetail(params.key).subscribe(
        (response: CreditDetailResponse) => {
          if (response.data !== null) {
            this.tdc = response.data;
            this.main_card = this.tdc.related_cards[0];
            this.tdc.related_cards.map((card: Card) => {
              if (card.relation_type === 'MAIN') {

                this.main_card = card;
              }
            });
            this.card_type = params.image ?
              params.image :
              params.cardType ?
              params.cardType :
              '';
          }
        },
        error => {
          this.serviceError = true;
          // console.log(error)
        }
      );
    });
  }
}
