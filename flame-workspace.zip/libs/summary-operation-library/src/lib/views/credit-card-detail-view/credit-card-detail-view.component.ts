import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import {
	NotificationService,
	ContactDialogService
} from '@santander/flame-component-library';
import { DataTransferService } from '@santander/flame-core-library';
import { CreditsService } from '../../services/credits.service';
import { CreditDetailResponse, CreditDetail, Card } from '../../models';
import { navbarElements } from '../../navbar-menu';
// @TODO Comprobar la forma en la que se usará el plugin para copiar texto.

@Component({
	selector: 'sm-credit-card-detail-view.',
	templateUrl: './credit-card-detail-view.component.html',
	styleUrls: ['./credit-card-detail-view.component.scss']
})
export class CreditCardDetailViewComponent implements OnInit {
	/**
	 * Crea una instancia de CreditCardDetailViewComponent.
	 *
	 * @param {CreditsService} _creditsService
	 * @param {ActivatedRoute} _route
	 * @param {Router} _router
	 * @param {NotificationService} _notificationService
	 * @param {ContactDialogService} _contactDialogService
	 * @memberof CreditCardDetailViewComponent
	 */
	constructor(
		private _creditsService: CreditsService,
		private _route: ActivatedRoute,
		private _router: Router,
		private _notificationService: NotificationService,
		private _contactDialogService: ContactDialogService,
		private _dataTransferService: DataTransferService,
		private _location: Location
	) {
		this.tdc = <CreditDetail>{
			related_cards: [],
			available_credit: {},
			credit_limit: {},
			balance: {},
			statement_balance: {},
			fixed_payment: {},
			minimum_payment: {}
		};
	}
	private params: any;
	private type = 1;
	public tdc: CreditDetail;
	public main_card: Card = {};
	public card_type: string;
	public navbarElements = navbarElements;
	public serviceError = false;

	/**
	 * Permite copiar un numero de tarjeta al portapapeles
	 *
	 * @param {string} text
	 * @memberof CreditCardDetailViewComponent
	 */
	public copyText(text: string): void {
		this._notificationService.open({
			legend: 'Copiado al portapapeles',
			type: 'thumbs_up'
		});
	}

	/**
	 * Permite la navegación entre opciones del menu
	 *
	 * @param {string} route
	 * @memberof CreditCardDetailViewComponent
	 */
	public navigateMenu(route: string): void {
		this._router.navigate([route]);
	}

	/**
	 * Permite la navegación de vuelta a products summary
	 *
	 * @memberof CreditCardDetailViewComponent
	 */
	public navigateBack(): void {
		this._location.back();
	}

	/**
	 * Permite la navegación al pago de la tarjeta
	 *
	 * @memberof CreditCardDetailViewComponent
	 */
	public navigateToPayment(): void {
		const card = {
			key: this.tdc.key,
			balance: this.tdc.balance,
			cardType: this.card_type,
			display_number: this.params.display_number,
			name: this.tdc.name,
			alias: this.tdc.alias
		};
		this._dataTransferService.sendData(card);
		this._router.navigate(['/payments/card-payments']);
	}

	/**
	 * Permite abrir el modal de "Santander Connect"
	 *
	 * @memberof CreditCardDetailViewComponent
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**@TODO: VALIDAR FLUJO DE CAMBIO DE ALIAS EN HU FUTURAS */
	/** updateAlias(value: string) {
  	if (value !== '') {
  		this.tdc.alias = value;
  		this._notificationService.open({
  			legend: '¡Cambiaste tu alias exitosamente!',
  			icon: 'sn-mensaje'
  		});
  	}
  } */

	/**
	 * Inicializa el componente una vez recibido los parametros de entrada
	 *
	 * @memberof CreditCardDetailViewComponent
	 */
	ngOnInit(): void {
		this._route.queryParams.subscribe(params => {
			this.params = params;
			this._creditsService.getCardDetail(params.key).subscribe(
				(response: CreditDetailResponse) => {
					if (response.data !== null) {
						this.tdc = response.data;
						this.main_card = this.tdc.related_cards[0];
						this.tdc.related_cards.map((card: Card) => {
							if (card.relation_type === 'Primary') {
								this.main_card = card;
							}
						});
						this.card_type = params.image
							? params.image
							: params.cardType
							? params.cardType
							: '';
					}
				},
				error => {
					this.serviceError = true;
				}
			);
		});
	}
}
