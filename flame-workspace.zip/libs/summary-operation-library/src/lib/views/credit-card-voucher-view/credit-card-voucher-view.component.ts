import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { VoucherOutAnimation } from '@santander/flame-component-library';

@Component({
	selector: 'sm-credit-card-voucher',
	templateUrl: './credit-card-voucher-view.component.html',
	styleUrls: ['./credit-card-voucher-view.component.scss'],
	animations: [VoucherOutAnimation]
})
export class CreditCardVoucherViewComponent implements OnInit {

	constructor(private _router: Router, private _route: ActivatedRoute) {}

	public voucherExitMove = "";
  	public dataTrans: any = {};
	public pathRepeat: Array<number>;
	public fakeInfo = {
		id: 5,
		comision: {
			amount: 10,
			currency_code: 'MXN'
		},
		operation: '02/Nov/2018 - 09:42:57 h',
		referenceSantanderMovil: '234561212',
		status: 'Aplicado'
	};

	/**
	 * Obtiene los valores mostrados en pantalla
	 * @memberof CreditCardVoucherViewComponent
	 */
	private getParams() {
		this._route.queryParams.subscribe(params => {
			this.dataTrans = params;
		});
	}

	/**
	 * Se inicial la animación de salida para el voucher
	 *
	 * @memberof CreditCardVoucherViewComponent
	 */
	public animationExit(){
		this.voucherExitMove = "out";
	}
	/**
	 * Permite la navegación a la vista de Mis Productos
	 * @memberof CreditCardVoucherViewComponent
	 */
	public close(event: any) {
		if(event.totalTime) {
			this._router.navigate(['/summary/products-summary'], {
				queryParams: {
					key: this.dataTrans.key,
					image: this.dataTrans.image
				}
			}); 
		}
	}

	/**
	 * Inicializar el componente una vez recibido las propiedades de entrada
	 * @memberof CreditCardVoucherViewComponent
	 */
	ngOnInit() {
		this.getParams();
		const temporal = parseInt((window.innerWidth / 30).toString(), 10) + 1;
		this.pathRepeat = Array(temporal)
			.fill(0)
			.map((x, i) => i);
	}
}
