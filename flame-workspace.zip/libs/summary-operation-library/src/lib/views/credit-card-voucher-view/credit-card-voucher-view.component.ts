import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
	selector: 'sm-credit-card-voucher',
	templateUrl: './credit-card-voucher-view.component.html',
	styleUrls: [ './credit-card-voucher-view.component.scss' ]
})
export class CreditCardVoucherViewComponent implements OnInit {
	public fakeInfo = {
		id: 5,
		comision: {
			amount: 10,
			currency_code: 'MXN'
		},
		operation: '02/Nov/2018 - 09:42:57 h',
		referenceSantanderMovil: '234561212',
		status: 'Aplicado'
	};

	public dataTrans: any = {};
	public pathRepeat: Array<number>;

	public showMoreInfo = false;

	constructor(
    private _router: Router,
    private _route: ActivatedRoute
  ) {}

	ngOnInit() {
		this.getParams();
		const temporal = parseInt((window.innerWidth / 30).toString(), 10) + 1;
		this.pathRepeat = Array(temporal).fill(0).map((x, i) => i);
	}

	getParams() {
		this._route.queryParams.subscribe((params) => {
			this.dataTrans = params;
		});
	}

	close() {
    this._router.navigate(['/summary/credit-card-summary'], {
			queryParams: {
				key: this.dataTrans.key,
				image: this.dataTrans.image
			}
		});
  }
}
