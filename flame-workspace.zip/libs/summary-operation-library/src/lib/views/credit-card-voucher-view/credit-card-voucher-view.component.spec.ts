import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CreditCardVoucherViewComponent } from './credit-card-voucher-view.component';
import {
  EmojiModule, 
  IconModule, 
  IconButtonModule,
  ProductModule,
  TopBarModule
} from '@santander/flame-component-library';
import { RouterModule } from '@angular/router';
import { APP_BASE_HREF } from '@angular/common';

describe('CreditCardVoucherViewComponent', () => {
  let component: CreditCardVoucherViewComponent;
  let fixture: ComponentFixture<CreditCardVoucherViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        IconModule,
        TopBarModule,
        EmojiModule,
        ProductModule,
        IconButtonModule,
        RouterModule.forRoot([]),
      ],
      declarations: [CreditCardVoucherViewComponent],
      providers: [{ provide: APP_BASE_HREF, useValue: '/' }]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreditCardVoucherViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should funtion close', () => {
    fixture.componentInstance.close();
    fixture.detectChanges();
  });

});

