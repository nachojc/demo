import { TransactionFilter } from './../../interfaces/transaction-filter-interface';
// Angular
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DatePipe } from '@angular/common';
// Components
import {
	DialogService,
	DialogReference,
	CustomDialog,
	TokenDialogService,
	ContactDialogService
} from '@santander/flame-component-library';
import { InvalidOperationComponent } from './../../components/invalid-operation/invalid-operation.component';
import { TransactionComponent } from './../../components/transaction/transaction.component';
// Services
import { CreditsService } from '../../services/credits.service';
// Interfaces
import {
	ResponseListCredits,
	Credit,
	TransactionsResponse,
	Transaction,
	ProductsCardFront
} from './../../models';
// Navbar
import { navbarElements } from '../../navbar-menu';
import { DataTransferService } from '@santander/flame-core-library';
import { AccountMovementComponent } from '../../components/account-movement/account-movement.component';

@Component({
	selector: 'sm-credit-card-summary-view.',
	templateUrl: './credit-card-summary-view.component.html',
	styleUrls: ['./credit-card-summary-view.component.scss']
})
export class CreditCardSummaryViewComponent implements OnInit {
	constructor(
		private _creditsService: CreditsService,
		private _tokenDialogService: TokenDialogService,
		private _router: Router,
		private _route: ActivatedRoute,
		private dialog: DialogService,
		private _datePipe: DatePipe,
		private _dataTransferService: DataTransferService,
		private _contactDialogService: ContactDialogService
	) {}

	private dialogRef: DialogReference;
	public navbarElements = navbarElements;
	public transactionsCard: Array<Transaction> = [];
	public cards: Array<Credit> = [];
	public allCards: Array<ProductsCardFront> = [];
	public card: ProductsCardFront = {};
	public scrollActive = true;
	public showContainerFilter = false;
	public showMovements = false;
	public errorMovements = false;
	public errorCards = false;
	public hideDialogToken = false;
	public confirmedToken = false;
	public selectedFilterPeriod = 'chip-2';
	public selectedFilterType = '4';
	private _cursor = '0';
	public loading = false;
	public loadingCards = false;
	public transactions = 5;
	public transactionsStep = 5;
	public filter: TransactionFilter = {
		income: true,
		expense: true,
		pending: true
	};
	public title = '';
	public accountsAvailable = 0;
	public type = 1;

	ngOnInit() {
		this.cardsInfo();
		this._route.queryParams.subscribe(params => {
			this.card = params;
		});
		this._tokenDialogService.getConfirmEvent().subscribe(res => {
			this.confirmedToken = true;
			setTimeout(() => {
				if (res.ok === 200) {
					this._tokenDialogService.closeDialogToken();
				}
			}, 1000);
		});
		this._tokenDialogService.getStateDialog().subscribe(res => {
			this.scrollActive = true;
			if (res === 'closed' && this.confirmedToken) {
				this.confirmedToken = false;
				this.showInfo();
			} else if (res === 'closed') {
				this.card.flipped = false;
			}
		});
	}

	public updateTransactions(more?: boolean, changePeriod?: boolean) {
		if (!more && !changePeriod) {
			this.resetFilters();
		}
		this.errorMovements = false;
		// this.scrollActive = true;
		if (this._cursor !== null) {
			this._creditsService[
				this.isCheckingAccount() ? 'getDebitTransactions' : 'getTransactions'
			](
				this.card.key,
				'5',
				this._cursor,
				this.selectedFilterPeriod,
				this.card.due_date
			).subscribe(
				(response: TransactionsResponse) => {
					this._cursor = response.paging
						? response.paging.next_cursor_key
						: null;
					if (more && !changePeriod) {
						if (response.data !== null) {
							this.transactionsCard.push(...response.data);
						} else {
							// this.scrollActive = false;
						}
					} else {
						this.transactionsCard = response.data;
					}
					if (this.transactionsCard.length > 0) {
						this.showMovements = true;
					} else {
						this.showMovements = false;
					}
					if (more) {
						this.transactions += this.transactionsStep;
					}
					this.loading = false;
				},
				error => {
					this.errorMovements = true;
					this.loading = false;
				}
			);
		} else {
			this.loading = false;
		}
	}

	private resetFilters() {
		this.showContainerFilter = false;
		this._cursor = '0'; // Pendiente
		this.activeAllFilter();
		this.selectedFilterPeriod = 'chip-2';
		this.transactions = 5;
	}

	public cardsInfo() {
		this._dataTransferService
			.getData()
			.then((products: Array<ProductsCardFront>) => {
				this.allCards = products;
				this.allCards.map((item: ProductsCardFront) => {
					this.accountsAvailable =
						item.category_name === 'CHECKING_ACCOUNTS'
							? this.accountsAvailable + 1
							: this.accountsAvailable;
					item.action = (i: number, slider: any) => {
						if (this.allCards[i].key === this.card.key) {
							this.scrollActive = false;
							this.card.flipped = true;
							this._tokenDialogService.openDialogToken();
						} else {
							slider.selectCard(i);
						}
					};
					if (item.key === this.card.key) {
						item.position = 'active';
						this.card = item;
					}
				});
				this.loadingCards = true;
				this._creditsService.getCredits().subscribe(
					(response: ResponseListCredits) => {
						const credits = response.data;
						for (let i = 0; i < this.allCards.length; i++) {
							if (this.allCards[i].category_name === 'CREDIT_CARDS') {
								for (let k = 0; k < credits.length; k++) {
									if (this.allCards[i].key === credits[k].key) {
										credits[k].related_cards.map((card: any) => {
											// TODO: Pendiente si dejarlo
											if (card.relation_type === 'Primary') {
												this.allCards[i].display_number = card.display_number;
											}
										});
										// this.allCards[i].state = credits[k].state; // Evaluar posibilidad de que el status sea el del credito
										this.allCards[i].due_date = credits[k].due_date;
										this.allCards[i].minimum_payment =
											credits[k].minimum_payment;
										this.allCards[i].statement_balance =
											credits[k].statement_balance;
										if (this.allCards[i].key === this.card.key) {
											this.allCards[i].position = 'active';
											this.card = this.allCards[i];
											this.updateTransactions();
										}
										break;
									}
								}
							}
						}
						this.loadingCards = false;
					},
					error => {
						this.errorCards = true;
					}
				);
			});
	}

	public navigateToSummary() {
		this._router.navigate(['/summary/global-position']);
	}

	public showInfo() {
		this._router.navigate(
			[
				this.isCheckingAccount()
					? '/summary/account-detail'
					: '/summary/credit-card-detail'
			],
			{
				queryParams: {
					key: this.card.key,
					amount: this.card.balance.amount,
					currency_code: this.card.balance.currency_code,
					display_number: this.card.display_number,
					cardType: this.card.type,
					description: this.card.description,
					alias: this.card.alias,
					status: this.card.status
				},
				queryParamsHandling: 'merge'
			}
		);
		this.card.flipped = false;
	}

	public showTransaction(transaction: any) {
		this.scrollActive = false;
		this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Detalle de movimiento',
				enableHr: false,
				disabledButton: false,
				buttons: [
					{
						label: ''
					}
				]
			},
			new CustomDialog(
				this.isCheckingAccount()
					? AccountMovementComponent
					: TransactionComponent,
				{
					transaction: transaction,
					bloking: {
						temporary_blocking: this.card.status === 'BLOCKED'
					},
					product: {
						card_key: this.card.key,
						card_name: this.card.alias
							? this.card.alias
							: this.card.description,
						card_number: this.card.display_number,
						card_imag: `./assets/icons/card-${this.card.type}.svg`
					},
					detail: transaction
				}
			)
		);
		this.dialogRef.beforeClose().subscribe(_ => {
			this.scrollActive = true;
		});
	}

	navigateMenu(route: string) {
		this._router.navigate([route]);
	}

	public changeTransactions(card: any) {
		this.card = card;
		if (this.loadingCards && !this.isCheckingAccount()) {
			return;
		}
		this.updateTransactions();
	}

	public filtrar() {
		this.showContainerFilter = !this.showContainerFilter;
	}

	public navigatePayment() {
		const route = './payments/card-payments';
		this._router.navigate([route], {
			queryParams: {
				key: this.card.key,
				amount: this.card.balance.amount,
				currency_code: this.card.balance.currency_code,
				display_number: this.card.display_number,
				cardType: this.card.type,
			},
			queryParamsHandling: 'merge'
    });
	}

	dialogTokenEvent(data: string) {
		if (data === 'closed' && this.confirmedToken) {
			this.showInfo();
		}
	}

	blocking(event) {
		this.card.status = event ? 'BLOCKED' : 'AVAILABLE';
	}

	public transferMoney() {
		/*
    this.showInvalidOperation(
      'Inténtalo más tarde',
      'Ahora no es posible completar esta operación',
      'alert'
    );
    */
    /*
		this.showInvalidOperation(
			'¡Aún no tienes una cuenta de cheques!',
			'Abre una cuenta para realizar esta operación',
			null,
			'./assets/no-contacts.svg',
      'Sin cuenta de cheques'
		);
		 return ;
		// */
		if (this.accountsAvailable === 0) {
			this.showInvalidOperation(
				'¡Aún no tienes una cuenta de cheques!',
				'Abre una cuenta para realizar esta operación',
				null,
        './assets/no-contacts.svg',
        'Sin cuenta de cheques'
			);
		} else if (this.card.balance.amount <= 0) {
			this.showInvalidOperation(
				'No tienes crédito disponible',
				'Espera a contar con saldo suficiente para disponer de efectivo',
				null,
				'./assets/no-money.svg'
			);
		} else if (this.card.status !== 'AVAILABLE') {
			// @TODO: corroborar si es correcto el flujo
			this.showInvalidOperation(
				'Inténtalo más tarde',
				'Ahora no es posible completar esta operación',
				'alert'
			);
		} else {
			this._router.navigate(['/summary/credit-card-money'], {
				queryParams: {
					key: this.card.key,
					account: this.card.display_number,
					amount: this.card.balance.amount,
					currency: this.card.balance.currency_code,
					displayName: this.card.alias
						? this.card.alias
						: this.card.description,
					type: `./assets/icons/card-${this.card.type}.svg`
				},
				queryParamsHandling: 'merge'
			});
		}
	}

	private showInvalidOperation(
		titulo: string,
		mensaje: string,
		emoji?: string,
    url?: string,
    dialogTitle?: string
	) {
		this.scrollActive = false;
		this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: dialogTitle ? dialogTitle :'Operación inválida',
				enableHr: true,
				disabledButton: true,
				buttons: [{ label: '' }]
			},
			new CustomDialog(InvalidOperationComponent, {
				emoji: emoji,
				titulo: titulo,
				mensaje: mensaje,
				url: url
			})
		);
		this.dialogRef.beforeClose().subscribe(_ => {
			this.scrollActive = true;
		});
	}

	public filterChipPeriod(event: any) {
		this.selectedFilterPeriod = event.num;
		this._cursor = '';
		this.updateTransactions(false, true);
	}

	public filterChipType(type: string) {
		if (type === 'all') {
			this.activeAllFilter();
		} else {
			if (this.isAllFilter()) {
				this.clearFilter();
			}
			this.filter[type] = !this.filter[type];
			if (this.isClearedFilter()) {
				this.activeAllFilter();
			}
		}
	}

	scrollHandler(event: any) {
		if (event && !this.loading) {
			this.loading = true;
			if (this.transactions < this.transactionsCard.length) {
				this.transactions += this.transactionsStep;
				this.loading = false;
			} else {
				this.updateTransactions(true);
			}
		}
	}

	public isCheckingAccount() {
		return (
			this.card.category_name === 'CHECKING_ACCOUNTS' ||
			this.card.category_name === 'CHECKING_ACCOUNTS_USD'
		);
	}

	private isAllFilter(): boolean {
		return this.filter.expense && this.filter.income && this.filter.pending;
	}

	private isClearedFilter(): boolean {
		return !this.filter.expense && !this.filter.income && !this.filter.pending;
	}

	private clearFilter(): void {
		this.filter = { income: false, expense: false, pending: false };
	}

	private activeAllFilter(): void {
		this.filter = { income: true, expense: true, pending: true };
	}
	openPhoneDialog() {
		this._contactDialogService.openDialogContact(this.type);
	}
}
