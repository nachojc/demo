import { SummaryResponse, Summary, Money, ProductsFront } from './../../models';

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { SummaryService } from '../../services/summary.service';
import { navbarElements } from '../../navbar-menu';
import { Message } from 'libs/flame-component-library/src/lib/atoms/snack-bar/snack-bar.interface';
import { category_names } from './../../category_product';
import { ContactDialogService } from '@santander/flame-component-library';

@Component({
	selector: 'sm-summary-view',
	templateUrl: './summary-view.component.html',
	styleUrls: ['./summary-view.component.scss']
})
export class SummaryViewComponent implements OnInit {
	constructor(
		private _summaryService: SummaryService,
		private _router: Router,
		private _dataTransferService: DataTransferService,
		private _contactDialogService: ContactDialogService
	) {}

	public navbarElements = navbarElements;
	public showView = false;
	public cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];
	public type = 1;
	public summaryData: Array<Summary> = [];
	public category_names = category_names;
  public errorSummary = false;
  public showTooltip = false;
	public totalBalance: Money = {
		amount: 0,
		currency_code: 'MXN'
	};

	public snackInterface: Message = {
		title: 'Dinero disponible en tus cuentas',
		text:
			'Es el total de dinero disponible en las cuentas de cheques, ahorros y nómina en moneda nacional de las que tú eres titular.',
		button: true
	};

	public getRandomImage(arr) {
		return arr[Math.floor(Math.random() * arr.length)];
	}

	public onClick(card: any) {
		this._dataTransferService.sendData(card);
		this._router.navigate(['/summary/account-summary']);
	}

	ngOnInit() {
		this._summaryService.getUserType().subscribe(response => {
			this.type = response.data.type;
		});
		this._summaryService.getSummary().subscribe(
			(response: SummaryResponse) => {
				this.summaryData = response.data;
				this.lookForDolars();
				this.addImagesToAccounts();
			},
			error => {
				this.errorSummary = true;
			}
		);
	}

	/**
	 * Agrega imagenes de tarjetas a las cuentas
	 * @TODO Temporal hasta que se resuelva lo de las imagenes
	 */
	private addImagesToAccounts() {
		let indToRemove = -1;
		this.summaryData.map((summary: Summary, index: number) => {
			if (summary.products.length === 0) {
				indToRemove = index;
			}
			summary.products.map((item: ProductsFront, indP: number) => {
				if (
					item.balance.currency_code === 'MXN' &&
					summary.category_name === 'CHECKING_ACCOUNTS'
				) {
          this.showTooltip = true;
				}
				item.image = this.getRandomImage(this.cardImages);
			});
		});
		if (indToRemove >= 0) {
			this.summaryData.splice(indToRemove, 1);
    }
    if (this.totalBalance.amount === 0 && this.summaryData.length === 1){
      if(this.summaryData[0].category_name === 'CREDIT_CARDS'){
        this.totalBalance = this.summaryData[0].total_balance;
      }
    }

	}

	/**
	 * Busca una cuenta en dolares para separarla de CHECKING_ACCOUNTS
	 * @TODO Temporal hasta que BAAS regrese las categorías divididas
	 *
	 */
	private lookForDolars() {
		for (let i = 0; i < this.summaryData.length; i++) {
			const summary = this.summaryData[i];
			if (summary.category_name === 'CHECKING_ACCOUNTS') {
				this.totalBalance = summary.total_balance;
				for (let k = 0; k < summary.products.length; k++) {
					const product = summary.products[k];
					if (product.balance.currency_code === 'USD') {
						this.addAccountDolar(product, i, k);
					}
				}
			}
		}
	}

	/**
	 * Separa/Agrega una cuenta en dolares
	 *
	 * @param account Cuenta en dolares a separar
	 * @param index Indice del arreglo de summary
	 * @param indP Indice del arreglo de productos
	 * @memberof SummaryViewComponent
	 */
	addAccountDolar(account: ProductsFront, index: number, indP: number) {
		let isAdded = false;
		for (let i = 0; i < this.summaryData.length; i++) {
			const item = this.summaryData[i];
			if (item.category_name === 'CHECKING_ACCOUNTS_USD') {
				item.products.push(account);
				item.total_balance.amount += account.balance.amount;
				isAdded = true;
			}
		}
		if (!isAdded) {
			this.summaryData.splice(index + 1, 0, {
				category_name: 'CHECKING_ACCOUNTS_USD',
				total_balance: account.balance,
				products: [account]
			});
		}
		this.summaryData[index].products.splice(indP, 1);
	}

	navigateMenu(route: string): void {
		this._router.navigate([route]);
	}

	public navigateProduct(product: any, category: string): void {
		const route = '/summary/credit-card-summary';
		const products: Array<ProductsFront> = [];
		this.summaryData.map((summary: Summary) => {
			summary.products.map((item: ProductsFront) => {
				const cardImage = item.image.substring(20);
				item.category_name = summary.category_name;
				item.type = cardImage.substr(0, cardImage.length - 4);
				products.push(item);
			});
		});

		this._dataTransferService.sendData(products);
		this._router.navigate([route], {
			queryParams: {
				key: product.key
			},
			queryParamsHandling: 'merge'
		});
	}

	openPhoneDialog() {
		this._contactDialogService.openDialogContact(this.type);
	}
}
