import { SummaryResponse, Summary, Money, ProductsFront } from './../../models';
import { Component, OnInit, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import {
	DataTransferService,
	AuthenticationService
} from '@santander/flame-core-library';
import { SummaryService } from '../../services/summary.service';
import { navbarElements } from '../../navbar-menu';
import { categoryNames } from './../../category_product';
import {
	ContactDialogService,
	Message,
	MaximizeProductOutAnimation
} from '@santander/flame-component-library';

/**
 * @export
 * @class SummaryViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-summary-view',
	templateUrl: './summary-view.component.html',
	styleUrls: ['./summary-view.component.scss'],
	animations: [MaximizeProductOutAnimation]
})
export class SummaryViewComponent implements OnInit {
	/**
	 * Crea una instancia de SummaryViewComponent.
	 *
	 * @param {SummaryService} _summaryService
	 * @param {Router} _router
	 * @param {DataTransferService} _dataTransferService
	 * @param {ContactDialogService} _contactDialogService
	 * @memberof SummaryViewComponent
	 */
	constructor(
		private _summaryService: SummaryService,
		private _router: Router,
		private _dataTransferService: DataTransferService,
		private _contactDialogService: ContactDialogService,
		private _authenticationService: AuthenticationService,
		private _elemRef: ElementRef
	) {}

	private cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];
	private type = 1;
	private positionImages = [];
	public animation = false;
	public animationStatus = '';
	public imagenCard = '';
	public topPositionCard = '';
	public marginLeftCard = '';
	public navbarElements = navbarElements;
	public categoryNames = categoryNames;
	public summaryData: Array<Summary> = [];
	public errorSummary = false;
	public showTooltip = false;
	public totalBalance: Money = {
		amount: 0,
		currency_code: 'MXN'
	};
	public snackInterface: Message = {
		title: 'Dinero disponible en tus cuentas',
		text:
			'Es el total de dinero disponible en las cuentas de cheques, ahorros y nómina en moneda nacional de las que tú eres titular.',
		button: true
	};
	public messageError = 'No podemos atender tu solicitud, intenta más tarde'

	/**
	 * Obtiene una imagen aleatoria para un producto.
	 *
	 * @private
	 * @returns {string}
	 * @memberof SummaryViewComponent
	 */
	private getRandomImage(): string {
		return this.cardImages[Math.floor(Math.random() * this.cardImages.length)];
	}

	/**
	 * Agrega imagenes de tarjetas a las cuentas.
	 *
	 * @TODO Temporal hasta que se resuelva lo de las imagenes.
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private addImagesToAccounts(): void {
		let indToRemove = -1;
		this.summaryData.map((summary: Summary, index: number) => {
			if (summary.products.length === 0) {
				indToRemove = index;
			}
			summary.products.map((item: ProductsFront, indP: number) => {
				this.showTooltip = true;
        if(summary.category_name === 'GROWING_MONEY') {
          item.image_url = 'growing';
        }
        item.image = this.getRandomImage();
			});
		});
		if (indToRemove >= 0) {
			this.summaryData.splice(indToRemove, 1);
		}
		if (this.totalBalance.amount === 0 && this.summaryData.length === 1) {
			if (
				this.summaryData[0].category_name === 'CREDIT_CARDS' ||
				this.summaryData[0].category_name === 'CHECKING_ACCOUNTS_USD'
			) {
				this.totalBalance = this.summaryData[0].total_balance;
			}
		}
	}

	/**
	 * Busca una cuenta en dolares para separarla de la categoría
	 * CHECKING_ACCOUNTS y pase a ser parte de la categoría CHECKING_ACCOUNTS_USD.
	 *
	 * @TODO Temporal hasta que BAAS regrese las categorías divididas.
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private lookForDollars(): void {
		let dollars = -1;
		// Se recorre al revés para no saltar ninguno con el splice
		for (let i = this.summaryData.length - 1; i >= 0; i--) {
			const summary = this.summaryData[i];
			if (summary.category_name === 'CHECKING_ACCOUNTS') {
				this.totalBalance = summary.total_balance;
				for (let k = summary.products.length - 1; k >= 0; k--) {
					const product = summary.products[k];
					if (product.balance.currency_code === 'USD') {
						this.addDollarAccount(product, i, k);
						dollars = i + 1;
					}
				}
			}
		}
		if (dollars >= 0) {
			// invertir el arreglo de dolares ya que se agregaron al reves
			this.summaryData[dollars].products.reverse();
		}
	}

	/**
	 * Separa/Agrega una cuenta en dolares a la categoría CHECKING_ACCOUNTS_USD.
	 *
	 * @param account Cuenta en dolares a separar
	 * @param index Indice del arreglo de summary
	 * @param indP Indice del arreglo de productos
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private addDollarAccount(
		account: ProductsFront,
		index: number,
		indP: number
	): void {
		let isAdded = false;
		for (let i = 0; i < this.summaryData.length; i++) {
			const item = this.summaryData[i];
			if (item.category_name === 'CHECKING_ACCOUNTS_USD') {
				item.products.push(account);
				isAdded = true;
			}
		}
		if (!isAdded) {
			this.summaryData.splice(index + 1, 0, {
				category_name: 'CHECKING_ACCOUNTS_USD',
				total_balance: account.balance,
				products: [account]
			});
		}
		this.summaryData[index].products.splice(indP, 1);
	}

	/**
	 * Función que obtiene las posiciones de las tarjetas una vez cargada la página
	 *
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private positionCards() {
		const cards = this._elemRef.nativeElement.querySelectorAll(
			'.sn-product-card'
		);
		cards.forEach(element => {
			const positions = element.getClientRects();
			const accountNumber = element.parentElement
				.getElementsByClassName('account-number')
				.item(0)
				.innerText.split(' ')
				.join('');
			const number = accountNumber.substring(
				accountNumber.length - 4,
				accountNumber.length
			);
			const position = {
				left: positions[0].left,
				top: positions[0].top,
				image: element.firstElementChild.getAttribute('src'),
				accountNumber: number
			};
			this.positionImages.push(position);
		});
	}

	/**
	 * Animación para la tarjeta al regreso de products summary view
	 *
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private animationBack() {
		this.animationStatus = 'final';
		const infoCards = localStorage.getItem('positionImages');
		if (infoCards) {
			const accountNumber = localStorage.getItem('itemCard');
			if (accountNumber) {
				const positionCards = JSON.parse(infoCards);
				const cardPosition = positionCards.find(
					cards => cards.accountNumber === accountNumber
				);
				if (cardPosition) {
					this.imagenCard = cardPosition.image;
					this.topPositionCard = cardPosition.top;
					this.marginLeftCard = cardPosition.left;
					this.animation = true;
					localStorage.removeItem('itemCard');
				}
			}
			localStorage.removeItem('positionImages');
		}
	}

	/**
	 * Navega al summary de un producto (carrousel horizontal).
	 *
	 * @param {ProductsFront} product
	 * @memberof SummaryViewComponent
	 */
	public navigateProduct(product: ProductsFront): void {
		this.animationStatus = 'initial';
		const cardPosition = this.positionImages.find(
			card =>
				product.display_number.substring(
					product.display_number.length - 4,
					product.display_number.length
				) === card.accountNumber
		);
		if (cardPosition) {
			this.imagenCard = cardPosition.image;
			this.topPositionCard = cardPosition.top;
			this.marginLeftCard = cardPosition.left;
		}
		this.animation = true;
		const route = '/summary/products-summary';
		const products: Array<ProductsFront> = [];
		for (let i = 0; i < this.summaryData.length; i++) {
			const summary = this.summaryData[i];
			for (let k = 0; k < summary.products.length; k++) {
				const item: ProductsFront = summary.products[k];
				if (summary.category_name === 'GROWING_MONEY') {
					if (item.key === product.key) {
						this._router.navigate(['/growing/accounts']);
						return;
					}
					continue;
				}
				const cardImage = item.image.substring(20);
				item.category_name = summary.category_name;
				item.type = cardImage.substr(0, cardImage.length - 4);
				products.push(item);
			}
		}
		this._dataTransferService.sendData(products);
		localStorage.setItem('positionImages', JSON.stringify(this.positionImages));
		// setTimeout(() => {
		//   this.animationStatus = 'final';
		//   setTimeout(() => {
		//     this._router.navigate([route], {
		//       queryParams: {
		//         key: product.key
		//       },
		//       queryParamsHandling: 'merge'
		//     });
		//   }, 300);
		// }, 50);
		this._router.navigate([route], {
			queryParams: {
				key: product.key
			},
			queryParamsHandling: 'merge'
		});
	}

	/**
	 * Abre el dialogo de contacto.
	 *
	 * @memberof SummaryViewComponent
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**
	 * Obtiene el tipo de usuario y los productos del mismo.
	 *
	 * @memberof SummaryViewComponent
	 */
	ngOnInit(): void {
		this._summaryService.getSummary().subscribe(
			(response: SummaryResponse) => {
				this.summaryData = response.data;
				this.lookForDollars();
				this.addImagesToAccounts();
				// this.animationBack();
				setTimeout(() => {
					this.animationStatus = 'initial';
					this.positionCards();
				}, 50);
			},
			error => {
				this.messageError = error.notifications ? error.notifications[0].message : this.messageError;
				this.errorSummary = true;
			}
		);
	}
}
