import { SummaryResponse, Summary, Money, ProductsFront } from './../../models';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataTransferService, AuthenticationService } from '@santander/flame-core-library';
import { SummaryService } from '../../services/summary.service';
import { navbarElements } from '../../navbar-menu';
import { categoryNames } from './../../category_product';
import {
	ContactDialogService,
	Message
} from '@santander/flame-component-library';

/**
 *
 *
 * @export
 * @class SummaryViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-summary-view',
	templateUrl: './summary-view.component.html',
	styleUrls: ['./summary-view.component.scss']
})
export class SummaryViewComponent implements OnInit {
	/**
	 * Crea una instancia de SummaryViewComponent.
	 *
	 * @param {SummaryService} _summaryService
	 * @param {Router} _router
	 * @param {DataTransferService} _dataTransferService
	 * @param {ContactDialogService} _contactDialogService
	 * @memberof SummaryViewComponent
	 */
	constructor(
		private _summaryService: SummaryService,
		private _router: Router,
		private _dataTransferService: DataTransferService,
    private _contactDialogService: ContactDialogService,
    private _authenticationService: AuthenticationService
	) {}

	private cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];
	private type = 1;

	public navbarElements = navbarElements;
	public categoryNames = categoryNames;
	public summaryData: Array<Summary> = [];
	public errorSummary = false;
	public showTooltip = false;
	public totalBalance: Money = {
		amount: 0,
		currency_code: 'MXN'
	};
	public snackInterface: Message = {
		title: 'Dinero disponible en tus cuentas',
		text:
			'Es el total de dinero disponible en las cuentas de cheques, ahorros y nómina en moneda nacional de las que tú eres titular.',
		button: true
	};

	/**
	 * Obtiene una imagen aleatoria para un producto.
	 *
	 * @private
	 * @returns {string}
	 * @memberof SummaryViewComponent
	 */
	private getRandomImage(): string {
		return this.cardImages[Math.floor(Math.random() * this.cardImages.length)];
	}

	/**
	 * Agrega imagenes de tarjetas a las cuentas.
	 *
	 * @TODO Temporal hasta que se resuelva lo de las imagenes.
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private addImagesToAccounts(): void {
		let indToRemove = -1;
		this.summaryData.map((summary: Summary, index: number) => {
			if (summary.products.length === 0) {
				indToRemove = index;
			}
			summary.products.map((item: ProductsFront, indP: number) => {
				if (
					item.balance.currency_code === 'MXN' &&
					summary.category_name === 'CHECKING_ACCOUNTS'
				) {
					this.showTooltip = true;
				}
				item.image = this.getRandomImage();
			});
		});
		if (indToRemove >= 0) {
			this.summaryData.splice(indToRemove, 1);
		}
		if (this.totalBalance.amount === 0 && this.summaryData.length === 1) {
			if (
				this.summaryData[0].category_name === 'CREDIT_CARDS' ||
				this.summaryData[0].category_name === 'CHECKING_ACCOUNTS_USD'
			) {
				this.totalBalance = this.summaryData[0].total_balance;
			}
		}
	}

	/**
	 * Busca una cuenta en dolares para separarla de la categoría
	 * CHECKING_ACCOUNTS y pase a ser parte de la categoría CHECKING_ACCOUNTS_USD.
	 *
	 * @TODO Temporal hasta que BAAS regrese las categorías divididas.
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private lookForDollars(): void {
    let dollars = -1;
    // Se recorre al revés para no saltar ninguno con el splice
		for (let i = this.summaryData.length - 1; i >= 0; i--) {
			const summary = this.summaryData[i];
			if (summary.category_name === 'CHECKING_ACCOUNTS') {
				this.totalBalance = summary.total_balance;
				for (let k = summary.products.length - 1; k >= 0; k--) {
					const product = summary.products[k];
					if (product.balance.currency_code === 'USD') {
            this.addDollarAccount(product, i, k);
            dollars = i + 1;
					}
				}
			}
    }
    if(dollars >= 0){ // invertir el arreglo de dolares ya que se agregaron al reves
      this.summaryData[dollars].products.reverse();
    }
	}

	/**
	 * Separa/Agrega una cuenta en dolares a la categoría CHECKING_ACCOUNTS_USD.
	 *
	 * @param account Cuenta en dolares a separar
	 * @param index Indice del arreglo de summary
	 * @param indP Indice del arreglo de productos
	 * @private
	 * @memberof SummaryViewComponent
	 */
	private addDollarAccount(
		account: ProductsFront,
		index: number,
		indP: number
	): void {
		let isAdded = false;
		for (let i = 0; i < this.summaryData.length; i++) {
			const item = this.summaryData[i];
			if (item.category_name === 'CHECKING_ACCOUNTS_USD') {
				item.products.push(account);
				isAdded = true;
			}
		}
		if (!isAdded) {
			this.summaryData.splice(index + 1, 0, {
				category_name: 'CHECKING_ACCOUNTS_USD',
				total_balance: account.balance,
				products: [account]
			});
		}
		this.summaryData[index].products.splice(indP, 1);
	}

	/**
	 * Permite navegar a una ruta especifica del navbar.
	 *
	 * @param {string} route
	 * @memberof SummaryViewComponent
	 */
	public navigateMenu(route: string): void {
		this._router.navigate([route]);
	}

	/**
	 * Navega al summary de un producto (carrousel horizontal).
	 *
	 * @param {ProductsFront} product
	 * @memberof SummaryViewComponent
	 */
	public navigateProduct(product: ProductsFront): void {
		const route = '/summary/products-summary';
		const products: Array<ProductsFront> = [];
		for (let i = 0; i < this.summaryData.length; i++) {
			const summary = this.summaryData[i];
			for (let k = 0; k < summary.products.length; k++) {
				const item: ProductsFront = summary.products[k];
				if (summary.category_name === 'GROWING_MONEY') {
					if (item.key === product.key) {
						this._router.navigate(['/growing/accounts']);
						return;
					}
					continue;
				}
				const cardImage = item.image.substring(20);
				item.category_name = summary.category_name;
				item.type = cardImage.substr(0, cardImage.length - 4);
				products.push(item);
			}
		}

		this._dataTransferService.sendData(products);
		this._router.navigate([route], {
			queryParams: {
				key: product.key
			},
			queryParamsHandling: 'merge'
		});
	}

	/**
	 * Abre el dialogo de contacto.
	 *
	 * @memberof SummaryViewComponent
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**
	 * Obtiene el tipo de usuario y los productos del mismo.
	 *
	 * @memberof SummaryViewComponent
	 */
	ngOnInit(): void {
		this._summaryService.getUserType().subscribe((response: any) => {
			this.type = response.data.type;
    });
    // this._authenticationService.refreshToken()
    // .subscribe((response: any)=>{

    //   localStorage.removeItem('oauthToken');
    //   localStorage.setItem('oauthToken', response);
      this._summaryService.getSummary().subscribe(
        // tslint:disable-next-line:no-shadowed-variable
        (response: SummaryResponse) => {
          this.summaryData = response.data;
          this.lookForDollars();
          this.addImagesToAccounts();
        },
        error => {
          this.errorSummary = true;
        }
      );
    // });
	}
}
