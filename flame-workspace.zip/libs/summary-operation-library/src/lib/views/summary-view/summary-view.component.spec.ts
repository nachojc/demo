import {
  async,
  ComponentFixture,
  TestBed
} from '@angular/core/testing';
import {
	ButtonModule,
	DialogModule,
	CardModule,
	IconModule,
	NavbarModule,
	IconButtonModule,
	ProductModule,
  SlideToggleModule,
  ChipModule,
  FormFieldModule,
  CarouselModule,
  SpinnerModule,
  InputModule,
  NotificationModule,
  DialogSelectModule,
  CheckboxModule,
  TopBarModule,
  CallButtonModule,
  AccountSelectModule,

} from '@santander/flame-component-library';

import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import { CommonModule, DatePipe, TitleCasePipe, CurrencyPipe } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
// tslint:disable-next-line:nx-enforce-module-boundaries
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import { AccountsService } from '../../services/accounts.service';
import { CreditsService } from '../../services/credits.service';
import { MaskPipe, NgxMaskModule } from 'ngx-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { SummaryViewComponent } from './summary-view.component';


describe('SummaryViewComponent', () => {
  let component: SummaryViewComponent;
  let fixture: ComponentFixture < SummaryViewComponent > ;

  beforeEach(async (() => {
    TestBed.configureTestingModule({
      imports: [
        SummaryOperationLibraryRoutingModule,
        ButtonModule,
        CardModule,
        CarouselModule,
        CommonModule,
        HttpClientModule,
        DialogModule,
        SlideToggleModule,
        SpinnerModule,
        IconModule,
        IconButtonModule,
        ReactiveFormsModule,
        FormFieldModule,
        InputModule,
        NotificationModule,
        NgxMaskModule.forRoot(),
        NavbarModule,
        IconButtonModule,
        ChipModule,
        ProductModule,
        DialogSelectModule,
        CheckboxModule,
        TopBarModule,
        CallButtonModule,
        AccountSelectModule,
        RouterModule.forRoot([])
      ],
        declarations: [
          SummaryViewComponent,
          SummaryOperationLibraryViews,
          MoreMainMenuViewComponent,
        ],
        providers: [
          DatePipe,
          TitleCasePipe,
          CurrencyPipe,
          AccountsService,
          CreditsService,
          MaskPipe
        ]
      })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SummaryViewComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should showView', () => {
    component.showView = false;
    expect(component.showView).toBeFalsy();
  });
});
