import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed,
	inject
} from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
	AvatarModule,
	SlideButtonModule,
	TokenDialogModule,
	SnackBarModule,
	SearchBarModule,
	AmountFieldModule,
	TokenDialogService,
	ContactDialogModule,
	ContactDialogService
} from '@santander/flame-component-library';
import { DataTransferService, ENV_CONFIG } from '@santander/flame-core-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import {
	CommonModule,
	DatePipe,
	TitleCasePipe,
	CurrencyPipe,
	APP_BASE_HREF
} from '@angular/common';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import {
	SummaryService,
	CreditsService,
	AccountsService
} from './../../services';
import { ScrollDirective, HeaderDirective } from './../../directives';

import { RouterModule, Router } from '@angular/router';
import { SummaryViewComponent } from './summary-view.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import {
	HttpTestingController,
	HttpClientTestingModule
} from '@angular/common/http/testing';
import { Injector } from '@angular/core';
import { Summary, ProductsFront } from './../../models';
import { environment } from './../../environments/environment';
import {
	SummaryOperationLibraryComponents,
	SummaryOperationLibraryEntryComponents
} from './../../components/summary-operation-library-components';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';

const dataService = {
	data: [
		{
			category_name: 'CHECKING_ACCOUNTS',
			total_balance: {
				currency_code: 'MXN',
				amount: 69827.78
			},
			products: [
				{
					key: '056722751246',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '56*5124',
					related_phone: {
						phone_number: '5510555143',
						company: 'TELCEL'
					},
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: 69827.78
					}
				},
				{
					key: '056722733565',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '56*3356',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'USD',
						amount: 0
					}
				},
				{
					key: '056722739876',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '56*9876',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'USD',
						amount: 100
					}
				}
			]
		},
		{
			category_name: 'CREDIT_CARDS',
			total_balance: {
				currency_code: 'MXN',
				amount: 85399.66
			},
			products: [
				{
					key: '4e20fbb243684d9eb19ff33a50ee422e',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '*3699',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: 1812.1
					}
				},
				{
					key: '1b10lop243683d9eb19ff33a50ee345a',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '*9981',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: -22038.1
					}
				}
			]
		},
		{
			category_name: 'GROWING_MONEY',
			total_balance: 3401954.06,
			products: [
				{
					key: '056515888469',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '056515888469',
					related_phone: null,
					status: null,
					balance: {
						currency_code: 'MXN',
						amount: 1183062.17
					}
				},
				{
					key: '056515888546',
					alias: null,
					description: 'SUPER NOMINA',
					url: null,
					display_number: '056515888546',
					related_phone: null,
					status: null,
					balance: {
						currency_code: 'MXN',
						amount: 2218891.89
					}
				}
			]
		}
	],
	notifications: null,
	paging: null
};
const dataUser = {
	data: {
		type: 2
	}
};
const dataMonoDollar = {
	data: [
		{
			category_name: 'CHECKING_ACCOUNTS',
			total_balance: {
				currency_code: 'USD',
				amount: 2000
			},
			products: [
				{
					key: '056722733565',
					alias: null,
					description: 'Ahorro',
					url: null,
					display_number: '32*9876',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'USD',
						amount: 2000
					}
				}
			]
		}
	],
	notifications: null,
	paging: null
};
const dataMonoTdc = {
	data: [
		{
			category_name: 'CREDIT_CARDS',
			total_balance: {
				currency_code: 'MXN',
				amount: 30000
			},
			products: [
				{
					key: '4e20fbb243684d9eb19ff33a50ee422e',
					alias: null,
					description: 'Aeroméxico Infinite',
					url: null,
					display_number: '*5678',
					related_phone: null,
					status: 'AVAILABLE',
					balance: {
						currency_code: 'MXN',
						amount: 30000
					}
				}
			]
		}
	],
	notifications: null,
	paging: null
};

describe('SummaryViewComponent', () => {
	const url = environment.baas.urlSummary;
	const totalCategories = 4;
	let injector: TestBed;
	let service: SummaryService;
	let dataTransfer: DataTransferService;
	let httpMock: HttpTestingController;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				CommonModule,
				ContactDialogModule,
				DialogModule,
				SlideToggleModule,
				SpinnerModule,
				IconModule,
				IconButtonModule,
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				NotificationModule,
				NavbarModule,
				IconButtonModule,
				ChipModule,
				ProductModule,
				DialogSelectModule,
				CheckboxModule,
				TopBarModule,
				AccountSelectModule,
				CardSliderModule,
				EmojiModule,
				MotiveFieldModule,
				SlideButtonModule,
				SnackBarModule,
				SummaryOperationLibraryRoutingModule,
				TokenDialogModule,
				SearchBarModule,
				AmountFieldModule,
				HttpClientTestingModule,
				BrowserAnimationsModule,
				NgxMaskModule.forRoot(),
				RouterModule.forRoot([])
			],
			declarations: [
				...SummaryOperationLibraryComponents,
				...SummaryOperationLibraryViews,
				SummaryViewComponent,
				MoreMainMenuViewComponent,
				ScrollDirective,
				HeaderDirective,
				TransactionFilterPipe
			],
			providers: [
				DatePipe,
				TitleCasePipe,
				ContactDialogService,
				CurrencyPipe,
				SummaryService,
				AccountsService,
				CreditsService,
				MaskPipe,
				TokenDialogService,
				TransactionFilterPipe,
				{
					provide: ENV_CONFIG,
					useValue: {
						baas: {
							urlSummary: 'http://localhost:3000/summaryBaas',
							urlTransactions: 'http://localhost:3000/accounts/',
							urlCredits: 'http://localhost:3000/credits',
							urlCards: 'http://localhost:3000/cards/',
							urlTransfersSameBank: 'http://localhost:3000/transfers/',
							urlPayments: 'http://localhost:3000/payments/'
						}
					}
				},
				{ provide: Injector, useValue: {} },
				{ provide: APP_BASE_HREF, useValue: '/' }
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [...SummaryOperationLibraryEntryComponents]
			}
		});

		injector = getTestBed();
		dataTransfer = injector.get(DataTransferService);
		service = injector.get(SummaryService);
		httpMock = injector.get(HttpTestingController);
	}));

	afterEach(() => {
		httpMock.verify();
	});

	describe('Client with all the types of products', () => {
		let component: SummaryViewComponent;
		let fixture: ComponentFixture<SummaryViewComponent>;

		beforeEach(() => {
			fixture = TestBed.createComponent(SummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			// Obtiene el tipo de usuario
			const requestUser = httpMock.expectOne(url + '/user');
			expect(requestUser.request.method).toEqual('GET');
			expect(requestUser.request.responseType).toEqual('json');
			requestUser.flush(dataUser);

			// Obtiene los productos del usuario
			const request = httpMock.expectOne(url);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(dataService);

			fixture.detectChanges();
		});

		it('Should create SummaryViewComponent', () => {
			expect(component).toBeTruthy();
		});

		it('All products should have an image', () => {
			component.summaryData.map((summary: Summary) => {
				summary.products.map((item: ProductsFront) => {
					expect(item.image).toBeDefined();
				});
			});
		});

		it('The dollar accounts category should be created', () => {
			expect(component.summaryData.length).toBe(totalCategories);
			const category = component.summaryData.find((summary: Summary) => {
				return summary.category_name === 'CHECKING_ACCOUNTS_USD';
			});
			expect(category).toBeDefined();
      fixture.detectChanges();
		});

		it('The snack-bar directive should open', () => {
			const messageBox = fixture.debugElement.nativeElement.querySelector(
				'.message-box'
			);
			const snackBar = fixture.debugElement.nativeElement.querySelector(
				'.sn-number div'
			);
			expect(messageBox.style.height).toBe('0px');
			expect(messageBox.style.opacity).toBe('0');

			snackBar.click();

			expect(messageBox.style.height).toBe('unset');
			expect(messageBox.style.opacity).toBe('1');
		});

		it('Should open contact phone dialog', inject(
			[ContactDialogService],
			(contactDialog: ContactDialogService) => {
				fixture.detectChanges();
				const snRight = fixture.debugElement.query(
					By.css('sn-top-bar div div.mr-2')
				);
				spyOn(contactDialog, 'openDialogContact');
				snRight.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(contactDialog.openDialogContact).toHaveBeenCalledWith(2);
				});
			}
		));

		it('Should navigate to product summary (carrousel) when product clicked', inject(
			[Router],
			(router: Router) => {
				const product = fixture.debugElement.query(By.css('.sn-product'));
				spyOn(router, 'navigate').and.returnValue(true);
				product.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(router.navigate).toHaveBeenCalledWith(
						['/summary/products-summary'],
						{
							queryParams: {
								key: '056722751246'
							},
							queryParamsHandling: 'merge'
						}
					);
				});
			}
		));

		it('Should navigate to growing accounts', inject(
			[Router],
			(router: Router) => {
				const container = fixture.debugElement.query(
					By.css('.sn-bg-white:last-child')
				);
				const product = container.query(By.css('.sn-product'));
				spyOn(router, 'navigate').and.returnValue(true);
				product.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(router.navigate).toHaveBeenCalledWith(['/growing/accounts']);
				});
			}
		));

		it('Should navigate to menu option', inject([Router], (router: Router) => {
			fixture.detectChanges();
			const navbar = fixture.debugElement.query(By.css('sn-navbar'));
      const firstOption = navbar.query(By.css('.sn-flat-button.inactive'));
			spyOn(router, 'navigate').and.returnValue(true);
			firstOption.nativeElement.click();
			fixture.whenStable().then(() => {
				expect(router.navigate).toHaveBeenCalledWith([
					'/summary/global-position'
				]);
			});
		}));
	});

	describe('Client with only one account in dollars', () => {
		let component: SummaryViewComponent;
		let fixture: ComponentFixture<SummaryViewComponent>;

		beforeEach(() => {
			fixture = TestBed.createComponent(SummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			// Obtiene el tipo de usuario
			const requestUser = httpMock.expectOne(url + '/user');
			expect(requestUser.request.method).toEqual('GET');
			expect(requestUser.request.responseType).toEqual('json');
			requestUser.flush(dataUser);

			// Obtiene el mono producto del usuario
			const request = httpMock.expectOne(url);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(dataMonoDollar);
			fixture.detectChanges();
		});

		it('Should create alternative flow of SummaryViewComponent', () => {
			expect(component).toBeTruthy();
		});

		it('The only product should be a dollar account', () => {
			expect(component.summaryData.length).toBe(1);
			expect(component.summaryData[0].products.length).toBe(1);
			const category = component.summaryData.find((summary: Summary) => {
				return summary.category_name === 'CHECKING_ACCOUNTS_USD';
			});
			expect(category).toBeDefined();
		});

		it('Total amount of the view should be the total amount of the product', () => {
			expect(component.totalBalance.amount).toBe(
				component.summaryData[0].products[0].balance.amount
			);
		});

		it('The snack-bar directive should not be in the view', () => {
			const snackBar = fixture.debugElement.nativeElement.querySelector(
				'.sn-number div'
			);
			expect(snackBar).toBeNull();
		});
	});

	describe('Client with only one credit card', () => {
		let component: SummaryViewComponent;
		let fixture: ComponentFixture<SummaryViewComponent>;

		beforeEach(() => {
			fixture = TestBed.createComponent(SummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			// Obtiene el tipo de usuario
			const requestUser = httpMock.expectOne(url + '/user');
			expect(requestUser.request.method).toEqual('GET');
			expect(requestUser.request.responseType).toEqual('json');
			requestUser.flush(dataUser);

			// Obtiene el mono producto del usuario
			const request = httpMock.expectOne(url);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(dataMonoTdc);
			fixture.detectChanges();
		});

		it('Should create alternative flow of SummaryViewComponent', () => {
			expect(component).toBeTruthy();
		});

		it('The only product should be a credit card', () => {
			expect(component.summaryData.length).toBe(1);
			expect(component.summaryData[0].products.length).toBe(1);
			const category = component.summaryData.find((summary: Summary) => {
				return summary.category_name === 'CREDIT_CARDS';
			});
			expect(category).toBeDefined();
		});

		it('Total amount of the view should be the total amount of the product', () => {
			expect(component.totalBalance.amount).toBe(
				component.summaryData[0].products[0].balance.amount
			);
		});

		it('The snack-bar directive should not be in the view', () => {
			const snackBar = fixture.debugElement.nativeElement.querySelector(
				'.sn-number div'
			);
			expect(snackBar).toBeNull();
		});
	});

	describe('Server error', () => {
		let component: SummaryViewComponent;
		let fixture: ComponentFixture<SummaryViewComponent>;

		beforeEach(() => {
			fixture = TestBed.createComponent(SummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			// Obtiene el tipo de usuario
			const requestUser = httpMock.expectOne(url + '/user');
			expect(requestUser.request.method).toEqual('GET');
			expect(requestUser.request.responseType).toEqual('json');
			requestUser.flush(dataUser);

			const mockErrorResponse = { status: 400, statusText: 'Bad Request' };
			const request = httpMock.expectOne(url);
			expect(request.request.method).toEqual('GET');
			expect(request.request.responseType).toEqual('json');
			request.flush(dataMonoTdc, mockErrorResponse);
			fixture.detectChanges();
		});

		it('Should show the error message', () => {
			const errorContainer = fixture.debugElement.nativeElement.querySelector(
				'.sn-notavailable-container'
			);
			expect(component.errorSummary).toBeTruthy();
			expect(errorContainer).toBeTruthy();
			expect(component.summaryData.length).toBe(0);
		});
	});
});
