import { Component, OnInit } from '@angular/core';
import { AccountsService } from '../../services/accounts.service';
import { ActivatedRoute, Router } from '@angular/router';
import {
	DialogService,
	DialogReference,
	CustomDialog
} from '@santander/flame-component-library';
import { AccountMovementComponent } from './../../components/account-movement/account-movement.component';

import { navbarElements } from '../../navbar-menu';
const limit = '5';
@Component({
	selector: 'sm-account-summary-view.',
	templateUrl: './account-summary-view.component.html',
	styleUrls: ['./account-summary-view.component.scss']
})
export class AccountSummaryViewComponent implements OnInit {
	constructor(
		private _accountsService: AccountsService,
		private _router: Router,
		private _route: ActivatedRoute,
		private dialog: DialogService
	) {}

	public transactionsCard = [];
	private dialogRef: DialogReference;
	public amount: string;
	public displayNumber: string;
	public currencyCode: string;
	public cardType: string;
	public cardName: string;
	private card: any;
  public navbarElements = navbarElements;
  public showContainerFilter= false;
  public blocked: boolean;
  public selectedFilterPeriod = '1';
  public selectedFilterType = '4';

	ngOnInit() {
		this._route.queryParams.subscribe(params => {
			this.card = params;
			this.amount = params.amount ? params.amount : '';
			this.displayNumber = params.display_number ? params.display_number : '';
			this.currencyCode = params.currency_code ? params.currency_code : '';
			this.cardType = params.image ? params.image : '';

			this.cardName = params.alias
				? params.alias
				: params.description
				? params.description
				: '';
			const key = params.key ? params.key : '056722734026';
			this._accountsService
				.getTransactions(key, limit)
				.subscribe(response => {
					this.transactionsCard = response.data;
				});
		});
	}

	public showMoreDetails() {
		this._router.navigate(['/summary/account-detail'], {
			queryParams: {
				key: this.card.key,
				amount: this.card.amount,
				currency_code: this.card.currency_code,
				display_number: this.card.display_number,
				cardType: this.cardType,
				description: this.card.description,
				alias: this.card.alias
			},
			queryParamsHandling: 'merge'
		});
	}

	public showTransaction(transaction: any) {
        this._accountsService.getTransactionDetailAccount(this.card.key, transaction.key)
        .subscribe((response) => {
          this.dialogRef = this.dialog.open(
            {
              closeLabel: 'Cancelar',
              title: 'Detalle de movimiento',
              enableHr: false,
              disabledButton: true,
              buttons: [
                {
                  label: ''
                }
              ]
            },
            new CustomDialog(AccountMovementComponent, {
              transaction: transaction,
              bloking:{
                temporary_blocking: this.blocked,
              },
              product:{
                card_key: this.card.key
              },
              detail: response.data
            })
          );
          this.dialogRef.beforeClose().subscribe(_ => {});
        })
  }

	navigateMenu(route: string) {
		this._router.navigate([route]);
  }

  public filtrar(value) {
    this.showContainerFilter = value;
  }
  blocking (event){
    this.blocked = event;
  }

  public filterChipPeriod(event: any) {
    this.selectedFilterPeriod = event.num;
  }

  public filterChipType(event: any) {
    this.selectedFilterType = event.num;
  }
}
