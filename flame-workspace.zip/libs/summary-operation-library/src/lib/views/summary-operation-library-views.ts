import { AccountDetailViewComponent } from './account-detail-view/account-detail-view.component';
import { SummaryViewComponent } from './summary-view/summary-view.component';
import { ProductsSummaryViewComponent } from './products-summary-view/products-summary-view.component';
import { CreditCardDetailViewComponent } from './credit-card-detail-view/credit-card-detail-view.component';
import { RelatePhoneViewComponent } from './relate-phone-view/relate-phone-view.component';
import { RelatePhoneSuccessViewComponent } from './relate-phone-success-view/relate-phone-success-view.component';
import { CreditCardMoneyViewComponent } from './credit-card-money-view/credit-card-money-view.component';
import { CreditCardVoucherViewComponent } from './credit-card-voucher-view/credit-card-voucher-view.component';

export const SummaryOperationLibraryViews = [
	AccountDetailViewComponent,
	CreditCardDetailViewComponent,
	CreditCardMoneyViewComponent,
	ProductsSummaryViewComponent,
	CreditCardVoucherViewComponent,
	RelatePhoneSuccessViewComponent,
	RelatePhoneViewComponent,
	SummaryViewComponent
];
