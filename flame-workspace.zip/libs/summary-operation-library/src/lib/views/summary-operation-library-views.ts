import { AccountDetailViewComponent } from './account-detail-view/account-detail-view.component';
import { SummaryViewComponent } from './summary-view/summary-view.component';
import { CreditCardSummaryViewComponent } from './credit-card-summary-view/credit-card-summary-view.component';
import { AccountSummaryViewComponent } from './account-summary-view/account-summary-view.component';
import { CreditCardDetailViewComponent } from './credit-card-detail-view/credit-card-detail-view.component';
import { RelatePhoneViewComponent } from './relate-phone-view/relate-phone-view.component';
import { RelatePhoneSuccessViewComponent } from './relate-phone-success-view/relate-phone-success-view.component';
import { CreditCardMoneyViewComponent } from './credit-card-money-view/credit-card-money-view.component';
import { CreditCardVoucherViewComponent } from './credit-card-voucher-view/credit-card-voucher-view.component';

export const SummaryOperationLibraryViews = [
	AccountDetailViewComponent,
	AccountSummaryViewComponent,
	CreditCardDetailViewComponent,
	CreditCardMoneyViewComponent,
	CreditCardSummaryViewComponent,
	CreditCardVoucherViewComponent,
	RelatePhoneSuccessViewComponent,
	RelatePhoneViewComponent,
	SummaryViewComponent
];
