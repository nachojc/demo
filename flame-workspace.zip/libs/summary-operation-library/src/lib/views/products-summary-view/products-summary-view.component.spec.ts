import {
	async,
	ComponentFixture,
	TestBed,
	getTestBed,
	fakeAsync,
	tick,
	flush,
	inject
} from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';

import { ReactiveFormsModule } from '@angular/forms';
import {
	SpinnerModule,
	SlideToggleModule,
	ButtonModule,
	DialogModule,
	CarouselModule,
	CardModule,
	IconModule,
	FormFieldModule,
	InputModule,
	NotificationModule,
	NavbarModule,
	IconButtonModule,
	ChipModule,
	ProductModule,
	DialogSelectModule,
	CheckboxModule,
	TopBarModule,
	AccountSelectModule,
	CardSliderModule,
	EmojiModule,
	MotiveFieldModule,
	AvatarModule,
	SlideButtonModule,
	TokenDialogModule,
	SnackBarModule,
	SearchBarModule,
	AmountFieldModule,
	TokenDialogService,
	ContactDialogModule,
	ContactDialogService,
	OverlayService,
	DialogService,
	DialogReference,
	CustomDialog
} from '@santander/flame-component-library';
import { DataTransferService, ENV_CONFIG } from '@santander/flame-core-library';
import { NgxMaskModule, MaskPipe } from 'ngx-mask';
import { SummaryOperationLibraryRoutingModule } from '../../summary-operation-library.router.module';
import {
	CommonModule,
	DatePipe,
	TitleCasePipe,
	CurrencyPipe
} from '@angular/common';
import { SummaryOperationLibraryViews } from '../summary-operation-library-views';
import { MoreMainMenuViewComponent } from 'apps/super-mobile/src/app/components/more-main-menu-view/more-main-menu-view.component';
import {
	SummaryService,
	CreditsService,
	AccountsService
} from '../../services';
import { ScrollDirective, HeaderDirective } from '../../directives';
import { RouterModule, ActivatedRoute, Params, Router } from '@angular/router';
import { ProductsSummaryViewComponent } from './products-summary-view.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import {
	HttpTestingController,
	HttpClientTestingModule
} from '@angular/common/http/testing';
import { Injector, ElementRef } from '@angular/core';
import { environment } from '../../environments/environment';
import {
	SummaryOperationLibraryComponents,
	SummaryOperationLibraryEntryComponents
} from '../../components/summary-operation-library-components';
import { TransactionFilterPipe } from '../../pipes/transactions-filter.pipe';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';
import { HttpRequest } from '@angular/common/http';
import { ChipComponent } from './../../../../../flame-component-library/src/lib/atoms/chip/chip.component';
import { SlideToggleComponent } from './../../../../../flame-component-library/src/lib/atoms/slide-toggle/slide-toggle.component';
import { AccountMovementComponent } from './../../components/account-movement/account-movement.component';
import { WINDOW_PROVIDERS, WINDOW } from '../../services';
import { Observable, of } from 'rxjs';

const dataService = {
	data: [
		{
			key: '4e20fbb243684d9eb19ff33a50ee422e',
			name: 'Aeromexico Blanca',
			alias: 'Rosa Marias Olvera/BPYTE',
			status: 'ACTIVE',
			balance: {
				amount: 1812.1,
				currency_code: 'MXN'
			},
			related_cards: [
				{
					display_number: '**** **** **** 3699',
					relation_type: 'Primary',
					expiration_date: '05/22',
					url: '/cards/{card-key}'
				}
			],
			statement_balance: {
				amount: 50000,
				currency_code: 'MXN'
			},
			minimum_payment: {
				amount: 0,
				currency_code: 'MXN'
			},
			due_date: '2019-04-08T00:00:00'
		},
		{
			key: '1b10lop243683d9eb19ff33a50ee345a',
			name: 'Mastercard Empresarial',
			alias: 'Rosa Marias Olvera/BPYTE',
			status: 'BLOCKED',
			balance: {
				amount: -22038.1,
				currency_code: 'MXN'
			},
			related_cards: [
				{
					display_number: '**** **** **** 9981',
					relation_type: 'Primary',
					expiration_date: '08/22',
					url: '/card/{card-key}'
				}
			],
			statement_balance: {
				amount: 8000,
				currency_code: 'MXN'
			},
			minimum_payment: {
				amount: 310,
				currency_code: 'MXN'
			},
			due_date: '2019-04-08T00:00:00'
		}
	],
	notifications: null,
	paging: null
};
const dataSummary = [
	{
		key: '056722751246',
		alias: null,
		description: 'SUPER NOMINA',
		url: null,
		display_number: '56*5124',
		related_phone: {
			phone_number: '5510555143',
			company: 'TELCEL'
		},
		status: 'AVAILABLE',
		balance: {
			currency_code: 'MXN',
			amount: 69827.78
		},
		image: './assets/icons/card-pref.svg',
		category_name: 'CHECKING_ACCOUNTS',
		type: 'pref',
		position: 'active'
	},
	{
		key: '056722733565',
		alias: null,
		description: 'SUPER NOMINA',
		url: null,
		display_number: '56*3356',
		related_phone: null,
		status: 'AVAILABLE',
		balance: {
			currency_code: 'USD',
			amount: 0
		},
		image: './assets/icons/card-aero.svg',
		category_name: 'CHECKING_ACCOUNTS_USD',
		type: 'aero',
		position: 'next'
	},
	{
		key: '4e20fbb243684d9eb19ff33a50ee422e',
		alias: null,
		description: 'SUPER NOMINA',
		url: null,
		display_number: '**** **** **** 3699',
		related_phone: null,
		status: 'AVAILABLE',
		balance: {
			currency_code: 'MXN',
			amount: 1812.1
		},
		image: './assets/icons/card-pref.svg',
		category_name: 'CREDIT_CARDS',
		type: 'pref',
		position: 'last',
		due_date: '2019-04-08T00:00:00',
		minimum_payment: {
			amount: 0,
			currency_code: 'MXN'
		},
		statement_balance: {
			amount: 50000,
			currency_code: 'MXN'
		}
	},
	{
		key: '1b10lop243683d9eb19ff33a50ee345a',
		alias: null,
		description: 'SUPER NOMINA',
		url: null,
		display_number: '**** **** **** 9981',
		related_phone: null,
		status: 'AVAILABLE',
		balance: {
			currency_code: 'MXN',
			amount: -22038.1
		},
		image: './assets/icons/card-basic.svg',
		category_name: 'CREDIT_CARDS',
		type: 'basic',
		position: 'last',
		due_date: '2019-04-08T00:00:00',
		minimum_payment: {
			amount: 310,
			currency_code: 'MXN'
		},
		statement_balance: {
			amount: 8000,
			currency_code: 'MXN'
		}
	}
];
const dataTransactions = {
	data: [
		{
			key: '101',
			display_number: '56722733565',
			creation_date: '2017-11-10T11:02:44.00001',
			description: 'OTROS ABONOS',
			amount: {
				amount: 10000,
				currency_code: 'MXN'
			}
		},
		{
			key: '94',
			display_number: '56722733565',
			creation_date: '2017-10-02T12:34:13.000047',
			description: 'I V A  POR COMISION',
			amount: {
				amount: 675.2,
				currency_code: 'MXN'
			}
		},
		{
			key: '93',
			display_number: '56722733565',
			creation_date: '2017-10-02T12:34:13.000047',
			description: 'COM TRANSF INTAL ENVIADA',
			amount: {
				amount: -4220,
				currency_code: 'MXN'
			}
		},
		{
			key: '92',
			display_number: '56722733565',
			creation_date: null,
			posted_date: '2017-10-02T12:34:07.000029',
			description: 'TRANSF INTERNACIONAL ENVIADA',
			amount: {
				amount: -376.2,
				currency_code: 'MXN'
			}
		},
		{
			key: '85',
			display_number: '56722733565',
			creation_date: '2017-09-22T13:00:30.000069',
			description: 'I V A  POR COMISION',
			amount: {
				amount: 675.2,
				currency_code: 'MXN'
			}
		}
	],
	notifications: null,
	paging: {
		next_cursor_key: '1'
	}
};
const dataCardTransactions = {
	data: [
		{
			key: '05',
			transaction_origin: 'COM TRANSF INTAL ENVIADA',
			creation_date: '2019-03-13T23:35:29',
			posted_date: null,
			url: '/credits/5474840000073614/transactions/5',
			amount: {
				amount: -120.5,
				currency_code: 'MXN'
			}
		},
		{
			key: '04',
			transaction_origin: 'IVA  POR COMISION',
			creation_date: '2019-03-13T23:25:59',
			posted_date: null,
			url: '/credits/5474840000073614/transactions/4',
			amount: {
				amount: -4220.99,
				currency_code: 'MXN'
			}
		},
		{
			key: '03',
			transaction_origin: 'CFE',
			creation_date: null,
			posted_date: '2019-03-13T00:00:00',
			url: '/credits/5474840000073614/transactions/3',
			amount: {
				amount: -244,
				currency_code: 'MXN'
			}
		},
		{
			key: '02',
			transaction_origin: 'CFE',
			creation_date: null,
			posted_date: '2019-03-13T00:00:00',
			url: '/credits/5474840000073614/transactions/2',
			amount: {
				amount: -244,
				currency_code: 'MXN'
			}
		},
		{
			key: '01',
			transaction_origin: 'TICKETMASTER MX',
			creation_date: '2019-03-13T00:00:00',
			posted_date: null,
			url: '/credits/5474840000073614/transactions/1',
			amount: {
				amount: 856.39,
				currency_code: 'MXN'
			}
		}
	],
	notifications: [
		{
			code: 'E422CDNPAYRCPTG001',
			message: 'OK',
			timestamp: '2019-02-15T18:02:33.438Z'
		}
	],
	paging: {
		next_cursor_key: '10'
	}
};
const dialogConfig = {
	hasBackdrop: true,
	backdropClass: 'dark-backdrop',
	panelClass: 'tm-file-preview-dialog-panel',
	disabledButton: false,
	showButton: true,
	closeBackdropClick: true,
	closeLabel: 'Cerrar',
	title: 'Detalle de movimiento',
	enableHr: false,
	buttons: [
		{
			label: ''
		}
	]
};
const dataDetailTransaction = {
	data: {
		key: '101',
		display_number: '56*3565',
		creation_date: '2017-11-10T11:02:44.00001',
		description: 'OTROS ABONOS',
		amount: {
			amount: 10000,
			currency_code: 'MXN'
		},
		reference: null,
		tracking_number: 'B601',
		transaction_origin: 'H$FQ',
		number: '101',
		account: {
			related_card: '56722733565',
			running_balance: {
				amount: 35399.66,
				currency_code: 'MXN'
			}
		}
	},
	notifications: null
};

describe('ProductsSummaryViewComponent', () => {
	const url = environment.baas.urlCredits;
	const urlAccounts = environment.baas.urlTransactions;

	let injector: TestBed;
	let service: CreditsService;
	let dialog: DialogService;
	let overlay: OverlayService;
	let transactionFilter: TransactionFilterPipe;
	let dataTransfer: DataTransferService;
	let httpMock: HttpTestingController;
	let fixture: ComponentFixture<ProductsSummaryViewComponent>;
	let component: ProductsSummaryViewComponent;
	let route: ActivatedRoute;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				ButtonModule,
				CardModule,
				CarouselModule,
				CommonModule,
				ContactDialogModule,
				DialogModule,
				SlideToggleModule,
				SpinnerModule,
				IconModule,
				IconButtonModule,
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				NotificationModule,
				NavbarModule,
				IconButtonModule,
				ChipModule,
				ProductModule,
				DialogSelectModule,
				CheckboxModule,
				TopBarModule,
				AccountSelectModule,
				CardSliderModule,
				EmojiModule,
				MotiveFieldModule,
				SlideButtonModule,
				SnackBarModule,
				SummaryOperationLibraryRoutingModule,
				TokenDialogModule,
				SearchBarModule,
				AmountFieldModule,
				HttpClientTestingModule,
				BrowserAnimationsModule,
				RouterTestingModule,
				NgxMaskModule.forRoot(),
				RouterModule.forRoot([])
			],
			declarations: [
				...SummaryOperationLibraryComponents,
				...SummaryOperationLibraryViews,
				ProductsSummaryViewComponent,
				MoreMainMenuViewComponent,
				ScrollDirective,
				HeaderDirective,
				TransactionFilterPipe
			],
			providers: [
				DatePipe,
				TitleCasePipe,
				ContactDialogService,
				CurrencyPipe,
				SummaryService,
				AccountsService,
				CreditsService,
				MaskPipe,
				TokenDialogService,
				TransactionFilterPipe,
				WINDOW_PROVIDERS,
				{
					provide: ENV_CONFIG,
					useValue: {
						baas: {
							urlSummary: 'http://localhost:3000/summaryBaas',
							urlTransactions: 'http://localhost:3000/accounts/',
							urlCredits: 'http://localhost:3000/credits',
							urlCards: 'http://localhost:3000/cards/',
							urlTransfersSameBank: 'http://localhost:3000/transfers/',
							urlPayments: 'http://localhost:3000/payments/'
						}
					}
				},
				{ provide: Injector, useValue: {} }
			]
		}).compileComponents();

		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [...SummaryOperationLibraryEntryComponents]
			}
		});

		injector = getTestBed();
		dataTransfer = injector.get(DataTransferService);
		service = injector.get(CreditsService);
		dialog = injector.get(DialogService);
		overlay = injector.get(OverlayService);
		route = injector.get(ActivatedRoute);
		transactionFilter = new TransactionFilterPipe();
		httpMock = injector.get(HttpTestingController);
	}));

	beforeEach(done => {
		dataTransfer.sendData(dataSummary);
		done();
	});

	afterEach(() => {
		httpMock.verify();
	});

	describe('Account with transactions', () => {
		beforeEach(done => {
			fixture = TestBed.createComponent(ProductsSummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();

			dataTransfer.getData().then(data => {
				expect(data).toBe(dataSummary);
				const request = httpMock.expectOne(url);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataService);
				fixture.detectChanges();

				const requestTrans = httpMock.expectOne(
					(req: HttpRequest<any>) =>
						req.urlWithParams ===
						`${urlAccounts}056722751246/transactions?limit=5&from_date=2019-05-01&to_date=2019-05-31&cursor=0`
				);
				expect(requestTrans.request.method).toEqual('GET');
				expect(requestTrans.request.responseType).toEqual('json');
				requestTrans.flush(dataTransactions);
				done();
			});
		});

		it('Should create ProductsSummaryViewComponent', () => {
			fixture.detectChanges();
			expect(component).toBeTruthy();
			expect(component.allCards).toBeDefined();
			expect(component.allCards.length).toBe(4);
			expect(component.transactionsCard).toBeDefined();
			expect(component.transactionsCard.length).toBe(component.transactions);
		});

		it('Should show transaction detail', async(() => {
			const dialogRef: DialogReference = dialog.open(
				dialogConfig,
				new CustomDialog(AccountMovementComponent, {
					bloking: {
						temporary_blocking: component.card.status === 'BLOCKED'
					},
					product: {
						card_key: component.card.key,
						card_name: component.card.alias
							? component.card.alias
							: component.card.description,
						card_number: component.card.display_number,
						card_imag: `./assets/icons/card-${component.card.type}.svg`
					},
					detail: component.transactionsCard[0]
				})
			);
			spyOn(dialog, 'open').and.returnValue(dialogRef);
			fixture.detectChanges();
			const transaction = fixture.debugElement.nativeElement.querySelector(
				'.sn-transaction'
			);
			transaction.click();
			fixture.whenStable().then(() => {
				expect(dialog.open).toHaveBeenCalled();
				expect(component.scrollActive).toBe(false);
				const request = httpMock.expectOne(
					`${urlAccounts}56722733565/transactions/101`
				);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataDetailTransaction);
				dialogRef.close();
			});
		}));

		it('Should open dialog with transaction detail', async(() => {
			fixture.detectChanges();
			const transaction = fixture.debugElement.nativeElement.querySelector(
				'.sn-transaction'
			);
			transaction.click();
			fixture.detectChanges();
			fixture.whenStable().then(() => {
				expect(component.scrollActive).toBe(false);
				expect(component.dialogRef).toBeTruthy();
				const request = httpMock.expectOne(
					`${urlAccounts}56722733565/transactions/101`
				);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataDetailTransaction);
				component.dialogRef.close();
				fixture.detectChanges();
				expect(component.scrollActive).toBeFalsy();
				fixture.whenStable().then(() => {
					expect(component.scrollActive).toBeTruthy();
				});
			});
		}));

		it('Should call the blockCard function', async(() => {
			fixture.detectChanges();
			spyOn(component, 'blockCard');
			const slide = fixture.debugElement.query(
				By.directive(SlideToggleComponent)
			);
			const button = slide.query(By.css('button'));
			button.nativeElement.click();
			fixture.detectChanges();
			expect(component.blockCard).toHaveBeenCalled();
		}));

		it('Should show the card status blocked', () => {
			fixture.detectChanges();
			const slide = fixture.debugElement.query(
				By.directive(SlideToggleComponent)
			);
			const button = slide.query(By.css('button'));
			button.nativeElement.click();
			fixture.detectChanges();
			const cardButton = fixture.debugElement.query(By.css('div.card-button'));
			expect(component.card.status).toBe('BLOCKED');
			expect(cardButton.classes.blocked).toBe(true);
			button.nativeElement.click();
			fixture.detectChanges();
			expect(component.card.status).toBe('AVAILABLE');
			expect(cardButton.classes.blocked).toBe(false);
		});

		it('Should call the showFilter function', () => {
			fixture.detectChanges();
			spyOn(component, 'showFilter');
			const chip = fixture.debugElement.query(By.directive(ChipComponent));
			const div = chip.query(By.css('div'));
			div.nativeElement.click();
			expect(component.showFilter).toHaveBeenCalled();
			fixture.detectChanges();
		});

		it('Should show the filter in the view', () => {
			fixture.detectChanges();
			const chip = fixture.debugElement.query(By.directive(ChipComponent));
			const div = chip.query(By.css('div'));
			div.nativeElement.click();
			fixture.detectChanges();
			const filterContainer = fixture.debugElement.query(
				By.css('.sn-filter-container')
			);
			expect(component.showContainerFilter).toBe(true);
			expect(filterContainer.classes['show-filter']).toBe(true);
		});

		it('Should filter transactions by period ', () => {
			fixture.detectChanges();
			const chip = fixture.debugElement.query(By.directive(ChipComponent));
			const div = chip.query(By.css('div'));
			div.nativeElement.click();

			const filterContainer = fixture.debugElement.query(
				By.css('.sn-filter-container')
			);
			let option = filterContainer.query(By.css('#chip-3'));
			let divOption = option.query(By.css('div'));
			divOption.nativeElement.click();
			fixture.detectChanges();
			expect(component.selectedFilterPeriod).toBe('chip-3');
			expect(divOption.classes.active).toBe(true);
			let requestTrans = httpMock.expectOne(
				(req: HttpRequest<any>) =>
					req.urlWithParams ===
					`${urlAccounts}056722751246/transactions?limit=5&from_date=2019-04-01&to_date=2019-04-30&cursor=`
			);
			expect(requestTrans.request.method).toEqual('GET');
			expect(requestTrans.request.responseType).toEqual('json');
			requestTrans.flush(dataTransactions);

			option = filterContainer.query(By.css('#chip-4'));
			divOption = option.query(By.css('div'));
			divOption.nativeElement.click();
			fixture.detectChanges();
			expect(component.selectedFilterPeriod).toBe('chip-4');
			expect(divOption.classes.active).toBe(true);
			requestTrans = httpMock.expectOne(
				(req: HttpRequest<any>) =>
					req.urlWithParams ===
					`${urlAccounts}056722751246/transactions?limit=5&from_date=2019-03-01&to_date=2019-03-31&cursor=`
			);
			expect(requestTrans.request.method).toEqual('GET');
			expect(requestTrans.request.responseType).toEqual('json');
			requestTrans.flush(dataTransactions);
		});

		it('Should filter transactions by type (6 possibilities)', () => {
			fixture.detectChanges();
			const chip = fixture.debugElement.query(By.directive(ChipComponent));
			const div = chip.query(By.css('div'));
			div.nativeElement.click();

			const filterContainer = fixture.debugElement.query(
				By.css('.sn-filter-container')
			);
			const all = filterContainer.query(By.css('#chip-5'));
			const divAll = all.query(By.css('div'));
			const income = filterContainer.query(By.css('#chip-6'));
			const divIncome = income.query(By.css('div'));
			const expense = filterContainer.query(By.css('#chip-7'));
			const divExpense = expense.query(By.css('div'));
			const pending = filterContainer.query(By.css('#chip-8'));
			const divPending = pending.query(By.css('div'));
			// Solo depositos
			divIncome.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(true);
			expect(component.filter.expense).toBe(false);
			expect(component.filter.pending).toBe(false);
			expect(divIncome.classes.active).toBe(true);

			let result = transactionFilter.transform(
				component.transactionsCard,
				component.filter
			);
			expect(result.length).toBe(3);
			for (let i = 0; i < result.length; i++) {
				expect(result[i].amount.amount).toBeGreaterThan(0);
			}

			// Solo depositos y retiros
			divExpense.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(true);
			expect(component.filter.expense).toBe(true);
			expect(component.filter.pending).toBe(false);

			expect(divIncome.classes.active).toBe(true);
			expect(divExpense.classes.active).toBe(true);

			result = transactionFilter.transform(
				component.transactionsCard,
				component.filter
			);
			expect(result.length).toBe(4);
			for (let i = 0; i < result.length; i++) {
				expect(result[i].posted_date).toBeUndefined();
			}
			// Solo retiros
			divAll.nativeElement.click();
			fixture.detectChanges();
			divExpense.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(false);
			expect(component.filter.expense).toBe(true);
			expect(component.filter.pending).toBe(false);
			expect(divExpense.classes.active).toBe(true);

			result = transactionFilter.transform(
				component.transactionsCard,
				component.filter
			);
			expect(result.length).toBe(2);
			for (let i = 0; i < result.length; i++) {
				expect(result[i].amount.amount).toBeLessThan(0);
			}

			// Solo retiros y por aprobar
			divPending.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(false);
			expect(component.filter.expense).toBe(true);
			expect(component.filter.pending).toBe(true);
			expect(divExpense.classes.active).toBe(true);
			expect(divPending.classes.active).toBe(true);

			result = transactionFilter.transform(
				component.transactionsCard,
				component.filter
			);
			expect(result.length).toBe(1);
			for (let i = 0; i < result.length; i++) {
				expect(result[i].amount.amount).toBeLessThan(0);
				expect(result[i].posted_date).toBeUndefined();
			}
			// Solo por aprobar
			divAll.nativeElement.click();
			fixture.detectChanges();
			divPending.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(false);
			expect(component.filter.expense).toBe(false);
			expect(component.filter.pending).toBe(true);
			expect(divPending.classes.active).toBe(true);

			result = transactionFilter.transform(
				component.transactionsCard,
				component.filter
			);
			expect(result.length).toBe(4);
			for (let i = 0; i < result.length; i++) {
				expect(result[i].posted_date).toBeUndefined();
			}
			// Solo por aprobar y depositos
			divIncome.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(true);
			expect(component.filter.expense).toBe(false);
			expect(component.filter.pending).toBe(true);
			expect(divIncome.classes.active).toBe(true);
			expect(divPending.classes.active).toBe(true);

			result = transactionFilter.transform(
				component.transactionsCard,
				component.filter
			);
			expect(result.length).toBe(3);
			for (let i = 0; i < result.length; i++) {
				expect(result[i].amount.amount).toBeGreaterThan(0);
				expect(result[i].posted_date).toBeUndefined();
			}
		});

		it('Should active all types of filter when clicked last option active', () => {
			fixture.detectChanges();
			const chip = fixture.debugElement.query(By.directive(ChipComponent));
			const div = chip.query(By.css('div'));
			div.nativeElement.click();

			const filterContainer = fixture.debugElement.query(
				By.css('.sn-filter-container')
			);
			const all = filterContainer.query(By.css('#chip-5'));
			const divAll = all.query(By.css('div'));
			const income = filterContainer.query(By.css('#chip-6'));
			const divIncome = income.query(By.css('div'));
			// Solo depositos
			divIncome.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(true);
			expect(component.filter.expense).toBe(false);
			expect(component.filter.pending).toBe(false);
			expect(divIncome.classes.active).toBe(true);

			divIncome.nativeElement.click();
			fixture.detectChanges();
			expect(component.filter.income).toBe(true);
			expect(component.filter.expense).toBe(true);
			expect(component.filter.pending).toBe(true);
			expect(divIncome.classes.active).toBe(false);
			expect(divAll.classes.active).toBe(true);
			let result = transactionFilter.transform(
				component.transactionsCard,
				component.filter
			);
			expect(result).toBe(component.transactionsCard);
		});

		it('Should navigate back to summary view', inject(
			[Router],
			(router: Router) => {
				fixture.detectChanges();
				const snLeft = fixture.debugElement.query(By.css('sn-top-bar div div'));
				spyOn(router, 'navigate').and.returnValue(true);
				snLeft.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(router.navigate).toHaveBeenCalledWith([
						'/summary/global-position'
					]);
				});
			}
		));

		it('Should navigate to show the detail of account ', async(
			fakeAsync(
				inject(
					[Router, TokenDialogService],
					(router: Router, token: TokenDialogService) => {
						fixture.detectChanges();
						spyOn(router, 'navigate').and.returnValue(true);
						const products = fixture.debugElement.queryAll(
							By.css('.sn-card-slide')
						);
						const card = products[0].nativeElement.querySelector('div sn-card');
						card.click();
						expect(component.scrollActive).toBe(false);
						expect(component.card.flipped).toBe(true);
						fixture.detectChanges();
						token.confirmEvent();
						tick(1500); // para cambiar de estado
						fixture.detectChanges();
						tick(1000); // para mostrar la carga
						fixture.detectChanges();
						flush(); // para entrar en la respuesta de get StateDialog
						fixture.detectChanges();
						expect(component.scrollActive).toBe(true);
						expect(router.navigate).toHaveBeenCalledWith(
							['/summary/account-detail'],
							{
								queryParams: {
									key: component.card.key,
									amount: component.card.balance.amount,
									currency_code: component.card.balance.currency_code,
									display_number: component.card.display_number,
									cardType: component.card.type,
									description: component.card.description,
									alias: component.card.alias,
									status: component.card.status
								},
								queryParamsHandling: 'merge'
							}
						);
					}
				)
			)
		));

		it('Should navigate to transfer money view', inject(
			[Router],
			(router: Router) => {
				const iconButtons = fixture.debugElement.queryAll(
					By.css('.sn-icon-button')
				);
				const divTransfer = iconButtons[2].query(By.css('div'));
				spyOn(router, 'navigate').and.returnValue(true);
				divTransfer.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(router.navigate).toHaveBeenCalledWith(['/transfers/initial']);
				});
			}
		));

		it('Should navigate to pay services view', inject(
			[Router],
			(router: Router) => {
				fixture.detectChanges();
				const iconButtons = fixture.debugElement.queryAll(
					By.css('.sn-icon-button')
				);
				const divPayServices = iconButtons[4].query(By.css('div'));
				spyOn(router, 'navigate').and.returnValue(true);
				divPayServices.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(router.navigate).toHaveBeenCalledWith([
						'/payments/services/pay'
					]);
				});
			}
		));

		it('Should navigate to menu option', inject([Router], (router: Router) => {
			fixture.detectChanges();
			const navbar = fixture.debugElement.query(By.css('sn-navbar'));
			const firstOption = navbar.query(By.css('.sn-flat-button.inactive'));
			spyOn(router, 'navigate').and.returnValue(true);
			firstOption.nativeElement.click();
			fixture.whenStable().then(() => {
				expect(router.navigate).toHaveBeenCalledWith([
					'/summary/global-position'
				]);
			});
		}));

		it('Should open contact phone dialog', inject(
			[ContactDialogService],
			(contactDialog: ContactDialogService) => {
				fixture.detectChanges();
				const snRight = fixture.debugElement.query(
					By.css('sn-top-bar div div.mr-2')
				);
				spyOn(contactDialog, 'openDialogContact');
				snRight.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(contactDialog.openDialogContact).toHaveBeenCalledWith(1);
				});
			}
		));

		it('Should get more transactions when scroll is in the bottom', async(() => {
			fixture.detectChanges();
			fixture.whenStable().then(() => {
				fixture.detectChanges();
				window.scroll(0, 1800);
				expect(component.loading).toBe(false);
				setTimeout(() => {
					expect(component.loading).toBe(true);
					expect(component.transactions).toBeLessThanOrEqual(
						component.transactionsCard.length
					);

					const requestTrans = httpMock.expectOne(
						(req: HttpRequest<any>) =>
							req.urlWithParams ===
							`${urlAccounts}056722751246/transactions?limit=5&from_date=2019-05-01&to_date=2019-05-31&cursor=1`
					);

					expect(requestTrans.request.url).toEqual(
						`${urlAccounts}056722751246/transactions`
					);
					expect(requestTrans.request.method).toEqual('GET');
					expect(requestTrans.request.responseType).toEqual('json');
					requestTrans.flush(dataTransactions);
					fixture.detectChanges();
					expect(component.loading).toBe(false);
					expect(component.transactionsCard.length).toBe(10);
				}, 1000);
			});
		}));

		it('Should show more transactions when scroll is in the bottom and view has more available', async(() => {
			component.transactionsCard.push(...dataTransactions.data);
			fixture.detectChanges();
			window.scroll(0, 1800);
			fixture.whenStable().then(() => {
				expect(component.loading).toBe(false);
				expect(component.transactions).toBeLessThan(
					component.transactionsCard.length
				);
				fixture.detectChanges();
			});
		}));

		it('Should change the product in the carrousel (from component) ', async(() => {
			fixture.detectChanges();
			component.changeTransactions(component.allCards[1]);
			fixture.detectChanges();
			const key = component.card.key;
			const urlTrans = component.isCheckingAccount()
				? `${urlAccounts}${key}/transactions?limit=5&from_date=2019-05-01&to_date=2019-05-31&cursor=0`
				: `${url}/${key}/transactions?limit=5&from_date=2019-05-01&to_date=2019-05-31&cursor=0`;
			const requestTrans = httpMock.expectOne(
				(req: HttpRequest<any>) => req.urlWithParams === urlTrans
			);
			expect(requestTrans.request.method).toEqual('GET');
			expect(requestTrans.request.responseType).toEqual('json');
			requestTrans.flush(dataTransactions);
			fixture.detectChanges();
		}));

		it('Should change the product in the carrousel (from view) ', async(() => {
			fixture.detectChanges();
			const products = fixture.debugElement.queryAll(By.css('.sn-card-slide'));
			const card = products[1].nativeElement.querySelector('div sn-card');
			card.click();
			fixture.detectChanges();
			const key = component.card.key;
			const urlTrans = component.isCheckingAccount()
				? `${urlAccounts}${key}/transactions?limit=5&from_date=2019-05-01&to_date=2019-05-31&cursor=0`
				: `${url}/${key}/transactions?limit=5&from_date=2019-05-01&to_date=2019-05-31&cursor=0`;
			const requestTrans = httpMock.expectOne(
				(req: HttpRequest<any>) => req.urlWithParams === urlTrans
			);
			expect(requestTrans.request.method).toEqual('GET');
			expect(requestTrans.request.responseType).toEqual('json');
			requestTrans.flush(dataTransactions);
		}));
	});

	describe('Select credit card with query params', () => {
		beforeEach(done => {
			const card = { key: '4e20fbb243684d9eb19ff33a50ee422e' };
			route.queryParams = of(card);
			fixture = TestBed.createComponent(ProductsSummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();
			expect(component.card).toBe(card);
			dataTransfer.getData().then(data => {
				fixture.detectChanges();
				expect(data).toBe(dataSummary);
				const request = httpMock.expectOne(url);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataService);
				fixture.detectChanges();
				const key = component.card.key;
				// Se comprueba sin parametros ya que las fechas aqui llevan hasta milisegundos.
				const requestTrans = httpMock.expectOne(
					(req: HttpRequest<any>) => req.url === `${url}/${key}/transactions`
				);
				expect(requestTrans.request.method).toEqual('GET');
				expect(requestTrans.request.responseType).toEqual('json');
				requestTrans.flush(dataCardTransactions);
				fixture.detectChanges();
				done();
			});
		});

		it('Should select credit card product by query params ', () => {
			expect(component.card.category_name).toBe('CREDIT_CARDS');
		});

		it('Should open dialog with transaction detail', async(() => {
			fixture.detectChanges();
			const transaction = fixture.debugElement.nativeElement.querySelector(
				'.sn-transaction'
			);
			transaction.click();
			fixture.detectChanges();
			fixture.whenStable().then(() => {
				expect(component.scrollActive).toBe(false);
				expect(component.dialogRef).toBeTruthy();
				const request = httpMock.expectOne(
					`${url}/4e20fbb243684d9eb19ff33a50ee422e/transactions/05`
				);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataDetailTransaction);
				component.dialogRef.close();
				fixture.detectChanges();
				expect(component.scrollActive).toBeFalsy();
				fixture.whenStable().then(() => {
					expect(component.scrollActive).toBeTruthy();
				});
			});
		}));

		it('Should navigate to payment credit card ', inject(
			[Router],
			(router: Router) => {
				const iconButtons = fixture.debugElement.queryAll(
					By.css('.sn-icon-button')
				);
				const divPayment = iconButtons[2].query(By.css('div'));
				spyOn(router, 'navigate').and.returnValue(true);
				divPayment.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(router.navigate).toHaveBeenCalledWith(
						['./payments/card-payments'],
						{
							queryParams: {
								key: component.card.key,
								amount: component.card.balance.amount,
								currency_code: component.card.balance.currency_code,
								display_number: component.card.display_number,
								cardType: component.card.type
							},
							queryParamsHandling: 'merge'
						}
					);
				});
			}
		));

		it('Should navigate to take out money from a credit card ', inject(
			[Router],
			(router: Router) => {
				const iconButtons = fixture.debugElement.queryAll(
					By.css('.sn-icon-button')
				);
				const divMoney = iconButtons[1].query(By.css('div'));
				spyOn(router, 'navigate').and.returnValue(true);
				divMoney.nativeElement.click();
				fixture.whenStable().then(() => {
					expect(router.navigate).toHaveBeenCalledWith(
						['/summary/credit-card-money'],
						{
							queryParams: {
								key: component.card.key,
								account: component.card.display_number
									.substr(-6)
									.replace(' ', ''),
								amount: component.card.balance.amount,
								currency: component.card.balance.currency_code,
								displayName: component.card.alias
									? component.card.alias
									: component.card.description,
								type: `./assets/icons/card-${component.card.type}.svg`
							},
							queryParamsHandling: 'merge'
						}
					);
				});
			}
		));

		it('Should navigate to show the detail of a credit card ', async(
			fakeAsync(
				inject(
					[Router, TokenDialogService],
					(router: Router, token: TokenDialogService) => {
						fixture.detectChanges();
						spyOn(router, 'navigate').and.returnValue(true);
						const products = fixture.debugElement.queryAll(
							By.css('.sn-card-slide')
						);
						const card = products[2].nativeElement.querySelector('div sn-card');
						card.click();
						expect(component.scrollActive).toBe(false);
						expect(component.card.flipped).toBe(true);
						fixture.detectChanges();
						token.confirmEvent();
						tick(1500); // para cambiar de estado
						fixture.detectChanges();
						tick(1000); // para mostrar la carga
						fixture.detectChanges();
						flush(); // para entrar en la respuesta de get StateDialog
						fixture.detectChanges();
						expect(component.scrollActive).toBe(true);
						expect(router.navigate).toHaveBeenCalledWith(
							['/summary/credit-card-detail'],
							{
								queryParams: {
									key: component.card.key,
									amount: component.card.balance.amount,
									currency_code: component.card.balance.currency_code,
									display_number: component.card.display_number,
									cardType: component.card.type,
									description: component.card.description,
									alias: component.card.alias,
									status: component.card.status
								},
								queryParamsHandling: 'merge'
							}
						);
					}
				)
			)
		));

		it('Should not navigate to take out money when no credit line available', async(() => {
      const amount = component.card.balance.amount;
			component.card.balance.amount = 0;
			const iconButtons = fixture.debugElement.queryAll(
				By.css('.sn-icon-button')
			);
			const divMoney = iconButtons[1].query(By.css('div'));
			divMoney.nativeElement.click();
			fixture.detectChanges();
			fixture.whenStable().then(() => {
				expect(component.scrollActive).toBe(false);
				expect(component.dialogRef).toBeTruthy();
				component.dialogRef.close();
				fixture.detectChanges();
				expect(component.scrollActive).toBeFalsy();
				fixture.whenStable().then(() => {
          expect(component.scrollActive).toBeTruthy();
          component.card.balance.amount = amount;
				});
			});
		}));

		it('Should not navigate to take out money when card is blocked', async(() => {
      const status = component.card.status;
			component.card.status = 'BLOCKED';
			const iconButtons = fixture.debugElement.queryAll(
				By.css('.sn-icon-button')
			);
			const divMoney = iconButtons[1].query(By.css('div'));
			divMoney.nativeElement.click();
			fixture.detectChanges();
			fixture.whenStable().then(() => {
				expect(component.scrollActive).toBe(false);
				expect(component.dialogRef).toBeTruthy();
				component.dialogRef.close();
				fixture.detectChanges();
				expect(component.scrollActive).toBeFalsy();
				fixture.whenStable().then(() => {
          expect(component.scrollActive).toBeTruthy();
          component.card.status = status;
				});
			});
		}));
	});

	describe('Credits service error', () => {
		beforeEach(done => {
			const card = { key: '4e20fbb243684d9eb19ff33a50ee422e' };
			route.queryParams = of(card);
			fixture = TestBed.createComponent(ProductsSummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();
			expect(component.card).toBe(card);
			dataTransfer.getData().then(data => {
				fixture.detectChanges();
				expect(data).toBe(dataSummary);
				const mockErrorResponse = { status: 400, statusText: 'Bad Request' };
				const request = httpMock.expectOne(url);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataService, mockErrorResponse);
				fixture.detectChanges();
				done();
			});
		});

		it('Should show the error message ', () => {
			const errorContainer = fixture.debugElement.nativeElement.querySelector(
				'sm-not-available-info'
			);
			expect(component.errorCards).toBeTruthy();
			expect(errorContainer).toBeTruthy();
		});
	});

	describe('Transactions service error', () => {
		beforeEach(done => {
			const card = { key: '4e20fbb243684d9eb19ff33a50ee422e' };
			route.queryParams = of(card);
			fixture = TestBed.createComponent(ProductsSummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();
			expect(component.card).toBe(card);
			dataTransfer.getData().then(data => {
				fixture.detectChanges();
				expect(data).toBe(dataSummary);
				const mockErrorResponse = { status: 400, statusText: 'Bad Request' };
				const request = httpMock.expectOne(url);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataService);
				fixture.detectChanges();
				const key = component.card.key;
				// Se comprueba sin parametros ya que las fechas aqui llevan hasta milisegundos.
				const requestTrans = httpMock.expectOne(
					(req: HttpRequest<any>) => req.url === `${url}/${key}/transactions`
				);
				expect(requestTrans.request.method).toEqual('GET');
				expect(requestTrans.request.responseType).toEqual('json');
				requestTrans.flush(dataCardTransactions, mockErrorResponse);
				fixture.detectChanges();
				done();
			});
		});

		it('Should show the error message ', () => {
			const errorContainer = fixture.debugElement.nativeElement.querySelector(
				'sm-not-available-info'
			);
			expect(component.errorMovements).toBeTruthy();
			expect(component.loading).toBeFalsy();
			expect(errorContainer).toBeTruthy();
		});
	});

	describe('Service response with transactions empty', () => {
		beforeEach(done => {
			const card = { key: '4e20fbb243684d9eb19ff33a50ee422e' };
			route.queryParams = of(card);
			fixture = TestBed.createComponent(ProductsSummaryViewComponent);
			component = fixture.componentInstance;
			fixture.detectChanges();
			expect(component.card).toBe(card);
			dataTransfer.getData().then(data => {
				fixture.detectChanges();
				expect(data).toBe(dataSummary);
				const request = httpMock.expectOne(url);
				expect(request.request.method).toEqual('GET');
				expect(request.request.responseType).toEqual('json');
				request.flush(dataService);
				fixture.detectChanges();
				const key = component.card.key;
				// Se comprueba sin parametros ya que las fechas aqui llevan hasta milisegundos.
				const requestTrans = httpMock.expectOne(
					(req: HttpRequest<any>) => req.url === `${url}/${key}/transactions`
				);
				expect(requestTrans.request.method).toEqual('GET');
				expect(requestTrans.request.responseType).toEqual('json');
				requestTrans.flush({ data: [] });
				fixture.detectChanges();
				done();
			});
		});

		it('Should show the empty transactions message ', () => {
			const emptyContainer = fixture.debugElement.nativeElement.querySelector(
				'.sn-movements-container'
			);
			expect(component.showMovements).toBeFalsy();
			expect(component.transactionsCard.length).toBe(0);
			expect(component.loading).toBeFalsy();
			expect(emptyContainer).toBeTruthy();
		});
	});
});
