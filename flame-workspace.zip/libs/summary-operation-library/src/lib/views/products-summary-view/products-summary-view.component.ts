import { AfterContentChecked } from '@angular/core';
// Angular
import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// Servicios de librerias
import {
	DialogService,
	DialogReference,
	CustomDialog,
	TokenDialogService,
	ContactDialogService
} from '@santander/flame-component-library';
import { DataTransferService } from '@santander/flame-core-library';
// Componentes
import { InvalidOperationComponent } from './../../components/invalid-operation/invalid-operation.component';
import { TransactionComponent } from './../../components/transaction/transaction.component';
import { AccountMovementComponent } from '../../components/account-movement/account-movement.component';
// Services
import { CreditsService } from '../../services/credits.service';
// Interfaces
import {
	ResponseListCredits,
	TransactionsResponse,
	Transaction,
	ProductsCardFront
} from './../../models';
import { TransactionFilter } from './../../interfaces/transaction-filter-interface';
// Navbar
import { navbarElements } from '../../navbar-menu';

/**
 * Vista del resumen de cada producto (carrousel con tarjetas).
 *
 * @export
 * @class ProductsSummaryViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-products-summary-view.',
	templateUrl: './products-summary-view.component.html',
	styleUrls: ['./products-summary-view.component.scss']
})
export class ProductsSummaryViewComponent
	implements OnInit, AfterContentChecked {
	/**
	 * Crea una instancia de ProductsSummaryViewComponent.
	 *
	 * @param {CreditsService} _creditsService
	 * @param {TokenDialogService} _tokenDialogService
	 * @param {Router} _router
	 * @param {ActivatedRoute} _route
	 * @param {DialogService} _dialog
	 * @param {DataTransferService} _dataTransferService
	 * @param {ContactDialogService} _contactDialogService
	 * @memberof ProductsSummaryViewComponent
	 */
	constructor(
		private _creditsService: CreditsService,
		private _tokenDialogService: TokenDialogService,
		private _router: Router,
		private _route: ActivatedRoute,
		private _dialog: DialogService,
		private _dataTransferService: DataTransferService,
		private _contactDialogService: ContactDialogService,
    private _cdref: ChangeDetectorRef,
	) {}



	/**
	 * Variables privadas
	 */
	private cursor = '0';
	private accountsAvailable = 0;
	private type = 1;
	private transactionsStep = 5;
	private loadingCards = false;
	private confirmedToken = false;

	/**
	 * Variables publicas
	 */
	public dialogRef: DialogReference;
	public navbarElements = navbarElements;
	public filter: TransactionFilter = {
		income: true,
		expense: true,
		pending: true
	};
	public transactionsCard: Array<Transaction> = [];
	public allCards: Array<ProductsCardFront> = [];
	public card: ProductsCardFront = {};
	public selectedFilterPeriod = 'chip-2';
	public transactions = 5;
	public scrollActive = true;
	public loading = false;
	public showContainerFilter = false;
	public showMovements = false;
	public errorMovements = false;
	public errorCards = false;

	/**
	 * Obtiene del servicio dataTransferService un arreglo que contiene
	 * los productos del cliente para mostrarlos en el carrousel.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private getCardsData(): void {
		this._dataTransferService
			.getData()
			.then((products: Array<ProductsCardFront>) => {
				this.allCards = products;
				this.allCards.map((item: ProductsCardFront) => {
					this.accountsAvailable =
						item.category_name === 'CHECKING_ACCOUNTS'
							? this.accountsAvailable + 1
							: this.accountsAvailable;
					item.action = (i: number, slider: any) => {
						if (this.allCards[i].key === this.card.key) {
							this.scrollActive = false;
							this.card.flipped = true;
							this._tokenDialogService.openDialogToken();
						} else {
							slider.selectCard(i);
						}
					};
					if (item.key === this.card.key) {
						item.position = 'active';
						this.card = item;
					}
				});
				this.loadingCards = true;
				this.getCreditsData();
			});
	}

	/**
	 * Obtiene los datos adicionales de credits
	 * (due_date, minimum_payment y statement_balance) para mostrarlos.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private getCreditsData(): void {
		this._creditsService.getCredits().subscribe(
			(response: ResponseListCredits) => {
				const credits = response.data;
				for (let i = 0; i < this.allCards.length; i++) {
					if (this.allCards[i].category_name === 'CREDIT_CARDS') {
						for (let k = 0; k < credits.length; k++) {
							if (this.allCards[i].key === credits[k].key) {
								credits[k].related_cards.map((card: any) => {
									// TODO: Temporal hasta que se defina cual será la tarjeta que se mostrará en caso de tener más de una
									if (card.relation_type === 'Primary') {
										this.allCards[i].display_number = card.display_number;
									}
								});
								// this.allCards[i].state = credits[k].state; // Evaluar posibilidad de que el status sea el del credito
								this.allCards[i].alias = credits[k].alias;
								this.allCards[i].due_date = credits[k].due_date;
								this.allCards[i].minimum_payment = credits[k].minimum_payment;
								this.allCards[i].statement_balance =
									credits[k].statement_balance;
								/** Si la tarjeta seleccionada desde summary es una tdc
								 * necesita primero obtener la fecha de corte para obtener las
								 * transacciones de la tarjeta, por eso forza el llamado a updateTransactions
								 */
								if (this.allCards[i].key === this.card.key) {
									this.allCards[i].position = 'active';
									this.card = this.allCards[i];
									this.updateTransactions();
								}
								break;
							}
						}
					}
				}
				this.loadingCards = false;
			},
			error => {
				this.errorCards = true;
			}
		);
	}

	/**
	 * Obtiene las transacciones de la tarjeta actual del carrousel.
	 * Obtiene más de 5 en 5 si se hace scroll y el parametro more es true.
	 *
	 * @private
	 * @param {boolean} [more]
	 * @param {boolean} [changePeriod]
	 * @memberof ProductsSummaryViewComponent
	 */
	private updateTransactions(more?: boolean, changePeriod?: boolean): void {
		if (!more && !changePeriod) {
			this.resetFilters();
		}
		this.errorMovements = false;
		// this.scrollActive = true;
		if (this.cursor !== null) {
			this._creditsService[
				this.isCheckingAccount() ? 'getDebitTransactions' : 'getTransactions'
			](
				this.card.key,
				'5',
				this.cursor,
				this.selectedFilterPeriod,
				this.card.due_date
			).subscribe(
				(response: TransactionsResponse) => {
					this.cursor = response.paging
						? response.paging.next_cursor_key
						: null;
					if (more && !changePeriod) {
						if (response.data !== null) {
							this.transactionsCard.push(...response.data);
						} else {
							this.scrollActive = false;
						}
					} else {
						this.transactionsCard = response.data;
					}
					if (this.transactionsCard.length > 0) {
						this.showMovements = true;
					} else {
						this.showMovements = false;
					}
					if (more) {
						this.transactions += this.transactionsStep;
					}
					this.loading = false;
				},
				error => {
					this.errorMovements = true;
					this.loading = false;
				}
			);
		} else {
			this.loading = false;
		}
	}

	/**
	 * Obtiene el detalle de un producto (account o tdc), es decir,
	 * navega a la vista del detalle del mismo.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private navigateToDetail(): void {
		this._router.navigate(
			[
				this.isCheckingAccount()
					? '/summary/account-detail'
					: '/summary/credit-card-detail'
			],
			{
				queryParams: {
					key: this.card.key,
					amount: this.card.balance.amount,
					currency_code: this.card.balance.currency_code,
					display_number: this.card.display_number,
					cardType: this.card.type,
					description: this.card.description,
					alias: this.card.alias,
					status: this.card.status
				},
				queryParamsHandling: 'merge'
			}
		);
		this.card.flipped = false;
	}

	/**
	 * Muestra una operación invalida al intentar disponer de efectivo de una TDC.
	 *
	 * @private
	 * @param {string} title
	 * @param {string} message
	 * @param {string} [emoji]
	 * @param {string} [url]
	 * @param {string} [dialogTitle]
	 * @memberof ProductsSummaryViewComponent
	 */
	private showInvalidOperation(
		title: string,
		message: string,
		emoji?: string,
		url?: string,
		dialogTitle?: string
	): void {
		this.scrollActive = false;
		this.dialogRef = this._dialog.open(
			{
				closeLabel: 'Cerrar',
				title: dialogTitle ? dialogTitle : 'Operación inválida',
				enableHr: true,
				disabledButton: true,
				buttons: [{ label: '' }]
			},
			new CustomDialog(InvalidOperationComponent, {
				emoji: emoji,
				title: title,
				message: message,
				url: url
			})
		);
		this.dialogRef.beforeClose().subscribe(_ => {
			this.scrollActive = true;
		});
	}

	/**
	 * Activa todas las opciones del filtro por tipo.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private activeAllFilter(): void {
		this.filter = { income: true, expense: true, pending: true };
	}

	/**
	 * Limpia todas las opciones del filtro por tipo.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private clearFilter(): void {
		this.filter = { income: false, expense: false, pending: false };
	}

	/**
	 * Comprueba si el filtro por tipo tiene todas sus opciones limpias.
	 *
	 * @private
	 * @returns {boolean}
	 * @memberof ProductsSummaryViewComponent
	 */
	private isFilterClear(): boolean {
		return !this.filter.expense && !this.filter.income && !this.filter.pending;
	}

	/**
	 * Reinicia el filtro a sus valores predeterminados.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private resetFilters() {
		this.showContainerFilter = false;
		this.cursor = '0'; // Pendiente
		this.activeAllFilter();
		this.selectedFilterPeriod = 'chip-2';
		this.transactions = 5;
	}

	/**
	 * Muestra el bloque del filtro en la pantalla.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public showFilter() {
		this.showContainerFilter = !this.showContainerFilter;
	}

	/**
	 * Comprueba si el filtro por tipo tiene todas sus opciones activas.
	 *
	 * @returns {boolean}
	 * @memberof ProductsSummaryViewComponent
	 */
	public isAllFilter(): boolean {
		return this.filter.expense && this.filter.income && this.filter.pending;
	}

	/**
	 * Activa el filtro por periodo.
	 *
	 * @param {*} event Tipo de periodo seleccionado.
	 * @memberof ProductsSummaryViewComponent
	 */
	public filterByPeriod(event: any) {
		this.selectedFilterPeriod = event.num;
		this.cursor = '';
		this.updateTransactions(false, true);
	}

	/**
	 * Activa el filtro por tipo.
	 *
	 * @param {string} type Tipo de filtro seleccionado.
	 * @memberof ProductsSummaryViewComponent
	 */
	public filterByType(type: string) {
		if (type === 'all') {
			this.activeAllFilter();
		} else {
			if (this.isAllFilter()) {
				this.clearFilter();
			}
			this.filter[type] = !this.filter[type];
			if (this.isFilterClear()) {
				this.activeAllFilter();
			}
		}
	}

	/**
	 * Comprueba si el producto actual del carrousel es una cuenta.
	 *
	 * @returns
	 * @memberof ProductsSummaryViewComponent
	 */
	public isCheckingAccount() {
		return (
			this.card.category_name === 'CHECKING_ACCOUNTS' ||
			this.card.category_name === 'CHECKING_ACCOUNTS_USD'
		);
	}

	/**
	 * Actualiza el producto del carrousel y obtiene sus ultimas transacciones.
	 *
	 * @param {*} card
	 * @returns
	 * @memberof ProductsSummaryViewComponent
	 */
	public changeTransactions(card: any) {
		if (this.loadingCards && !this.isCheckingAccount()) {
			return;
		}
		this.card = card;
		this.updateTransactions();
	}

	/**
	 * Muestra en un dialog el detalle de una transacción.
	 *
	 * @param {*} transaction transaccion seleccionada
	 * @memberof ProductsSummaryViewComponent
	 */
	public showTransaction(transaction: any) {
		this.scrollActive = false;
		this.dialogRef = this._dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Detalle de movimiento',
				enableHr: false,
				disabledButton: false,
				buttons: [
					{
						label: ''
					}
				]
			},
			new CustomDialog(
				this.isCheckingAccount()
					? AccountMovementComponent
					: TransactionComponent,
				{
					transaction: transaction,
					bloking: {
						temporary_blocking: this.card.status === 'BLOCKED'
					},
					product: {
						card_key: this.card.key,
						card_name: this.card.alias
							? this.card.alias
							: this.card.description,
						card_number: this.card.display_number,
						card_imag: `./assets/icons/card-${this.card.type}.svg`
					},
					detail: transaction
				}
			)
		);
		this.dialogRef.beforeClose().subscribe(_ => {
			this.scrollActive = true;
		});
	}

	/**
	 * Inicia el flujo de diposición de efectivo y comprueba si se puede realizar
	 * en caso de que no se pueda muestra una operación invalida.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public takeOutMoney() {
		if (this.accountsAvailable === 0) {
			this.showInvalidOperation(
				'¡Aún no tienes una cuenta de cheques!',
				'Abre una cuenta para realizar esta operación',
				null,
				'./assets/no-contacts.svg',
				'Sin cuenta de cheques'
			);
		} else if (this.card.balance.amount <= 0) {
			this.showInvalidOperation(
				'No tienes crédito disponible',
				'Espera a contar con saldo suficiente para disponer de efectivo',
				null,
				'./assets/no-money.svg'
			);
		} else if (this.card.status !== 'AVAILABLE') {
			// @TODO: corroborar si es correcto el flujo
			this.showInvalidOperation(
				'Inténtalo más tarde',
				'Ahora no es posible completar esta operación',
				'alert'
			);
		} else {
			this._router.navigate(['/summary/credit-card-money'], {
				queryParams: {
					key: this.card.key,
					account: this.card.display_number.substr(-6).replace(' ', ''),
					amount: this.card.balance.amount,
					currency: this.card.balance.currency_code,
					displayName: this.card.alias
						? this.card.alias
						: this.card.description,
					type: `./assets/icons/card-${this.card.type}.svg`
				},
				queryParamsHandling: 'merge'
			});
		}
	}

	/**
	 * Función que se ejecuta al hacer scroll sobre la vista y llegar al final
	 * de las transacciones, actualiza las mismas en busca de más.
	 *
	 * @param {*} event
	 * @memberof ProductsSummaryViewComponent
	 */
	public scrollHandler(event: any) {
		if (event && !this.loading) {
			this.loading = true;
			if (this.transactions < this.transactionsCard.length) {
				this.transactions += this.transactionsStep;
				this.loading = false;
			} else {
				this.updateTransactions(true);
			}
		}
	}

	/**
	 * Permite bloquear el producto actual del carrousel mediante el quick action
	 * de la vista.
	 *
	 * @param {*} event
	 * @memberof ProductsSummaryViewComponent
	 */
	public blockCard(event) {
		this.card.status = event ? 'BLOCKED' : 'AVAILABLE';
	}

	/**
	 * Abre el dialogo de contacto.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public openPhoneDialog() {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**
	 * Navega a la vista summary (mis productos).
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public navigateToSummary() {
		this._router.navigate(['/summary/global-position']);
	}

	/**
	 * Permite navegar a una ruta especifica del navbar.
	 *
	 * @param {string} route
	 * @memberof ProductsSummaryViewComponent
	 */
	public navigateMenu(route: string) {
		this._router.navigate([route]);
	}

	/**
	 * Permite navegar a la vista de pago de tarjeta de una TDC.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public navigatePayment() {
		const route = './payments/card-payments';
		this._router.navigate([route], {
			queryParams: {
				key: this.card.key,
				amount: this.card.balance.amount,
				currency_code: this.card.balance.currency_code,
				display_number: this.card.display_number,
				cardType: this.card.type
			},
			queryParamsHandling: 'merge'
		});
	}

	/**
	 * Permite navegar al flujo de transferencia de efectivo
	 * @TODO Validar que los flujos alternos sean los mismos que disposición de efectivo
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public transferMoney() {
		if (this.accountsAvailable === 0) {
			this.showInvalidOperation(
				'¡Aún no tienes una cuenta de cheques!',
				'Abre una cuenta para realizar esta operación',
				null,
				'./assets/no-contacts.svg',
				'Sin cuenta de cheques'
			);
		} else if (this.card.balance.amount <= 0) {
			this.showInvalidOperation(
				'No tienes crédito disponible',
				'Espera a contar con saldo suficiente para disponer de efectivo',
				null,
				'./assets/no-money.svg'
			);
		} else if (this.card.status !== 'AVAILABLE') {
			// @TODO: corroborar si es correcto el flujo
			this.showInvalidOperation(
				'Inténtalo más tarde',
				'Ahora no es posible completar esta operación',
				'alert'
			);
		} else {
			this._router.navigate(['/transfers/initial']);
		}
	}

	/**
	 * Permite navegar al pago de servicios
	 * @TODO Validar que los flujos alternos sean los mismos que disponer de efectivo
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public payServices() {
		if (this.accountsAvailable === 0) {
			this.showInvalidOperation(
				'¡Aún no tienes una cuenta de cheques!',
				'Abre una cuenta para realizar esta operación',
				null,
				'./assets/no-contacts.svg',
				'Sin cuenta de cheques'
			);
		} else if (this.card.balance.amount <= 0) {
			this.showInvalidOperation(
				'No tienes crédito disponible',
				'Espera a contar con saldo suficiente para disponer de efectivo',
				null,
				'./assets/no-money.svg'
			);
		} else if (this.card.status !== 'AVAILABLE') {
			// @TODO: corroborar si es correcto el flujo
			this.showInvalidOperation(
				'Inténtalo más tarde',
				'Ahora no es posible completar esta operación',
				'alert'
			);
		} else {
			this._router.navigate(['/payments/services']);
		}
	}

	/**
	 * Obtiene los productos y crea la subscripción a los eventos del token dialog.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	ngOnInit() {
		this.getCardsData();
		this._route.queryParams.subscribe(params => {
			if (params.hasOwnProperty('key')) {
				this.card = params;
			}
		});
		this._tokenDialogService.getConfirmEvent().subscribe(res => {
			this.confirmedToken = true;

			if (res.ok === 200) {
        this._tokenDialogService.setStatusSlide('success');
					// Para que se pueda ver el último estado por lo menos 1seg
					setTimeout(() => {
						this._tokenDialogService.closeDialogToken();
					}, 1000);
			}
		});

		this._tokenDialogService.getStateDialog().subscribe(res => {
			this.scrollActive = true;
			if (res === 'startclose' && this.confirmedToken) {
				this.confirmedToken = false;
				this.navigateToDetail();
			} else if (res === 'closed') {
				this.card.flipped = false;
			}
		});
  }



	/**
	 * Para evitar el error al cambio del titulo del componente sn-topbar
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	ngAfterContentChecked() {
		this._cdref.detectChanges();
	}
}
