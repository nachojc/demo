import { TransactionFilterPipe } from './../../pipes/transactions-filter.pipe';
// Angular
import {
	AfterContentChecked,
	ChangeDetectorRef,
	Component,
	OnInit,
	ViewEncapsulation,
	ViewChild
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { DataTransferService } from '@santander/flame-core-library';
import {
	DialogService,
	DialogReference,
	CustomDialog,
	TokenDialogService,
	ContactDialogService,
	CustomToken
} from '@santander/flame-component-library';
// Componentes
import { InvalidOperationComponent } from '../../components/invalid-operation/invalid-operation.component';
import { TransactionComponent } from '../../components/transaction/transaction.component';
import { AccountMovementComponent } from '../../components/account-movement/account-movement.component';
import { CustomTokenComponent } from '../../components/custom-token/custom-token.component';
import { CustomTokenActiveComponent } from '../../components/custom-token-active/custom-token-active.component';
import { CreditsService } from '../../services/credits.service';
import {
	ResponseListCredits,
	TransactionsResponse,
	Transaction,
	ProductsCardFront
} from '../../models';
import { TransactionFilter } from '../../interfaces/transaction-filter-interface';
import { navbarElements } from '../../navbar-menu';
import { timer } from 'rxjs';
import { SnSliderViewDirective } from 'apps/super-mobile/src/app/components/slider-view/slider-view.directive';
/**
 * Vista del resumen de cada producto (carrousel con tarjetas).
 *
 * @export
 * @class ProductsSummaryViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-products-summary-view.',
	templateUrl: './products-summary-view.component.html',
	styleUrls: ['./products-summary-view.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class ProductsSummaryViewComponent
	implements OnInit, AfterContentChecked {
	/**
	 * Crea una instancia de ProductsSummaryViewComponent.
	 *
	 * @param {CreditsService} _creditsService
	 * @param {TokenDialogService} _tokenDialogService
	 * @param {Router} _router
	 * @param {ActivatedRoute} _route
	 * @param {Location} _location
	 * @param {DialogService} _dialog
	 * @param {DataTransferService} _dataTransferService
	 * @param {ContactDialogService} _contactDialogService
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	constructor(
		private _creditsService: CreditsService,
		private _tokenDialogService: TokenDialogService,
		private _router: Router,
		private _route: ActivatedRoute,
		private _location: Location,
		private _dialog: DialogService,
		private _dataTransferService: DataTransferService,
		private _contactDialogService: ContactDialogService,
		private _cdref: ChangeDetectorRef
	) {}

	/**
	 * Variables privadas
	 */
	private cursor = '0';
	private accountsAvailable = 0;
	private type = 1;
	private transactionsStep = 5;
	private loadingCards = false;
	private confirmedToken = false;
	private periodCount = 0;
	private typeCount = 0;
	private filterPipe = new TransactionFilterPipe();
	private allTransactions: Array<Transaction> = [];

	/**
	 * Variables publicas
	 */
	public dialogRef: DialogReference;
	public navbarElements = navbarElements;
	public filter: TransactionFilter = {
		income: true,
		expense: true,
		pending: true
	};
	public transactionsCard: Array<Transaction> = [];
	public allCards: Array<ProductsCardFront> = [];
	public card: ProductsCardFront = {};
	public selectedFilterPeriod = 'chip-2';
	public transactions = 5;
	public scrollActive = true;
	public loading = false;
	public showContainerFilter = false;
	public showMovements = false;
	public errorMovements = false;
	public errorCards = false;
	public count = 0;
	public alert: string;
	public description: string;
	public paragraph: string;
	public typeFilter: string;
	public messageError = 'No podemos atender tu solicitud, intenta más tarde'

	@ViewChild(SnSliderViewDirective) slider: SnSliderViewDirective;

	/**
	 * Obtiene del servicio dataTransferService un arreglo que contiene
	 * los productos del cliente para mostrarlos en el carrousel.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private getCardsData(): void {
		this._dataTransferService
			.getData()
			.then((products: Array<ProductsCardFront>) => {
				this.allCards = products;
				let getCredits = false;
				this.allCards.map((item: ProductsCardFront, index: number) => {
					if (item.category_name === 'CREDIT_CARDS') {
						getCredits = true;
					}
					item.flipped = false;
					this.accountsAvailable =
						item.category_name === 'CHECKING_ACCOUNTS'
							? this.accountsAvailable + 1
							: this.accountsAvailable;
					item.action = (i: number, slider: any) => {
					if (this.allCards[i].key === this.card.key) {
						this.scrollActive = false;
						const params: CustomToken = {
							subtitle: 'Ingresa tu clave de 4 dígitos para confirmar',
							title: 'Confirma con tu SuperToken',
							closeLabel: 'Cancelar',
							showTokenInput: true,
							typeButton: 'basic'
							// customBody: CustomTokenComponent,
							// customBody: CustomTokenActiveComponent,
							// showTokenInput: false,
							// typeButton: 'slide'
						};
						this._tokenDialogService.openDialogToken(params);
					} else {
						slider.selectSlideByIndex(i);
					}
				};
				if (item.key === this.card.key) {
					this.setActive(index);
					this.card = item;
				}
			});
			this.loadingCards = true;
			if (getCredits) {
				this.getCreditsData();
			}
		});
	}

	/**
	 *
	 *
	 */
	private setActive(i: number): void {
		this.allCards[i].position = 'active';
		for (let k = 0; k < this.allCards.length; k++) {
			if (k !== i) {
				this.allCards[k].position = '';
			}
		}
	}

	/**
	 * Obtiene los datos adicionales de credits
	 * (due_date, minimum_payment y statement_balance) para mostrarlos.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private getCreditsData(): void {
		this._creditsService.getCredits().subscribe(
			(response: ResponseListCredits) => {
				const credits = response.data;
				for (let i = 0; i < this.allCards.length; i++) {
					if (this.allCards[i].category_name === 'CREDIT_CARDS') {
						for (let k = 0; k < credits.length; k++) {
							if (this.allCards[i].key === credits[k].key) {
								credits[k].related_cards.map((card: any) => {
									// TODO: Temporal hasta que se defina cual será la tarjeta que se mostrará en caso de tener más de una
									if (card.relation_type === 'Primary') {
										this.allCards[i].display_number = card.display_number;
									}
								});
								// this.allCards[i].state = credits[k].state; // Evaluar posibilidad de que el status sea el del credito
								this.allCards[i].alias = credits[k].alias;
								this.allCards[i].due_date = credits[k].due_date;
								this.allCards[i].minimum_payment = credits[k].minimum_payment;
								this.allCards[i].statement_balance =
									credits[k].statement_balance;
								/** Si la tarjeta seleccionada desde summary es una tdc
								 * necesita primero obtener la fecha de corte para obtener las
								 * transacciones de la tarjeta, por eso forza el llamado a updateTransactions
								 */
								if (this.allCards[i].key === this.card.key) {
									this.setActive(i);
									this.card = this.allCards[i];
								}
								break;
							}
						}
					}
				}
				this.updateTransactions();
				this.loadingCards = false;
			},
			error => {
				this.messageError = error.notifications ? error.notifications[0].message : this.messageError;
				this.errorCards = true;
			}
		);
	}

	private implementFilter() {
		this.transactionsCard = this.filterPipe.transform(
			this.allTransactions,
			this.filter
		);
		if (this.transactionsCard.length > 0) {
			this.showMovements = true;
		} else {
			this.showMovements = false;
		}
		this.updateHeight();
	}

	/**
	 * Necesaria temporalmente para actualizar el height actual y no tomar el más alto de las slides
	 * @TODO fix para considerar el height unico del slide actual
	 *
	 * @private
	 * @param {number} [time=10]
	 * @memberof ProductsSummaryViewComponent
	 */
	private updateHeight(time = 10) {
		const source = timer(time);
		source.subscribe(() => this.slider.setMaxHeight());
	}

	/**
	 * Obtiene las transacciones de la tarjeta actual del carrousel.
	 * Obtiene más de 5 en 5 si se hace scroll y el parametro more es true.
	 *
	 * @private
	 * @param {boolean} [more]
	 * @param {boolean} [changePeriod]
	 * @memberof ProductsSummaryViewComponent
	 */
	private updateTransactions(more?: boolean, changePeriod?: boolean): void {
		if (!more && !changePeriod) {
			this.resetFilters();
		}
		this.errorMovements = false;
		this.scrollActive = true;
		this.validationFilter();

		if (this.cursor !== null) {
			this._creditsService
				.getTransactions(
					this.card.key,
					'5',
					this.isCheckingAccount(),
					this.cursor,
					this.selectedFilterPeriod,
					this.card.due_date
				)
				.subscribe(
					(response: TransactionsResponse) => {
						this.cursor = response.paging
							? response.paging.next_cursor_key
							: null;
						if (more && !changePeriod) {
							if (response.data !== null) {
								this.allTransactions.push(...response.data);
								this.implementFilter();
							} else {
								this.scrollActive = false;
							}
						} else {
							this.allTransactions = response.data;
							this.implementFilter();
						}
						if (more) {
							this.transactions += this.transactionsStep;
						}
						this.loading = false;
					},
					error => {
						this.messageError = error.notifications ? error.notifications[0].message : this.messageError;
						this.errorMovements = true;
						this.loading = false;
					}
				);
		} else {
			this.loading = false;
		}
	}

	/**
	 * Obtiene el detalle de un producto (account o tdc), es decir,
	 * navega a la vista del detalle del mismo.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private navigateToDetail(): void {
		this._router.navigate(
			[
				this.isCheckingAccount()
					? '/summary/account-detail'
					: '/summary/credit-card-detail'
			],
			{
				queryParams: {
					key: this.card.key,
					amount: this.card.balance.amount,
					currency_code: this.card.balance.currency_code,
					display_number: this.card.display_number,
					cardType: this.card.type,
					description: this.card.description,
					alias: this.card.alias,
					status: this.card.status
				},
				queryParamsHandling: 'merge'
			}
		);
	}

	/**
	 * Muestra una operación invalida al intentar disponer de efectivo de una TDC.
	 *
	 * @private
	 * @param {string} title
	 * @param {string} message
	 * @param {string} [emoji]
	 * @param {string} [url]
	 * @param {string} [dialogTitle]
	 * @memberof ProductsSummaryViewComponent
	 */
	private showInvalidOperation(
		title: string,
		message: string,
		emoji?: string,
		url?: string,
		dialogTitle?: string
	): void {
		this.scrollActive = false;
		this.dialogRef = this._dialog.open(
			{
				closeLabel: 'Cerrar',
				title: dialogTitle ? dialogTitle : 'Operación inválida',
				enableHr: true,
				disabledButton: true,
				buttons: [{ label: '' }]
			},
			new CustomDialog(InvalidOperationComponent, {
				emoji: emoji,
				title: title,
				message: message,
				url: url
			})
		);
		this.dialogRef.beforeClose().subscribe(_ => {
			this.scrollActive = true;
		});
	}

	/**
	 * Activa todas las opciones del filtro por tipo.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private activeAllFilter(): void {
		this.filter = { income: true, expense: true, pending: true };
	}

	/**
	 * Limpia todas las opciones del filtro por tipo.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private clearFilter(): void {
		this.filter = { income: false, expense: false, pending: false };
	}

	/**
	 * Comprueba si el filtro por tipo tiene todas sus opciones limpias.
	 *
	 * @private
	 * @returns {boolean}
	 * @memberof ProductsSummaryViewComponent
	 */
	private isFilterClear(): boolean {
		return !this.filter.expense && !this.filter.income && !this.filter.pending;
	}

	/**
	 * Reinicia el filtro a sus valores predeterminados.
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private resetFilters(): void {
		this.showContainerFilter = false;
		this.cursor = '0'; // Pendiente
		this.count = 0;
		this.periodCount = 0;
		this.typeCount = 0;
		this.activeAllFilter();
		this.selectedFilterPeriod = 'chip-2';
		this.transactions = 5;
	}

	/**
	 * Muestra los mensajes de acuerdo a los filtros seleccionados
	 *
	 * @private
	 * @memberof ProductsSummaryViewComponent
	 */
	private validationFilter() {
		let typePeriod = 1,
			typeFilter = 1;

		if (this.selectedFilterPeriod === 'chip-2') {
			typePeriod = 1; //Actual
		}
		if (this.selectedFilterPeriod === 'chip-3') {
			typePeriod = 2; // Pasado
		}
		if (this.selectedFilterPeriod === 'chip-4') {
			typePeriod = 3; //Anterior
		}
		// Corresponden a las combinaciones de filtro de Cuentas
		if (this.typeFilter === 'all' && this.isCheckingAccount()) {
			typeFilter = 1;
		}
		if (this.typeFilter === 'income' && this.isCheckingAccount()) {
			typeFilter = 2;
		}
		if (this.typeFilter === 'expense' && this.isCheckingAccount()) {
			typeFilter = 3;
		}
		// Corresponden a las combinaciones de filtro de TDC
		if (this.typeFilter === 'all' && !this.isCheckingAccount()) {
			typeFilter = 4;
		}
		if (this.typeFilter === 'income' && !this.isCheckingAccount()) {
			typeFilter = 5;
		}
		if (this.typeFilter === 'expense' && !this.isCheckingAccount()) {
			typeFilter = 6;
		}
		if (this.typeFilter === 'pending' && !this.isCheckingAccount()) {
			typeFilter = 7;
		}


		this.alert = '';
		this.description = '';
		this.paragraph = '';
		switch (typePeriod * 100 + typeFilter) {
			// Casos que corresponden a las combinaciones de filtro de Cuentas
			case 101:
				this.alert = 'Sin movimientos';
				this.description = 'Aún no tienes movimientos en este período';
				break;
			case 102:
				this.alert = 'Este mes no tuviste depósitos.';
				this.description = 'Te los mostraremos aquí en cuanto existan';
				break;
			case 103:
				this.alert = '¡Aún no hay retiros este mes!';
				this.description = 'Usa tu app y dale movimiento a tu cuenta';
				break;
			case 201:
				this.alert = 'Sin movimientos';
				this.description = '¡Vaya! No hiciste movimientos durante ese mes.';
				this.paragraph = 'Intenta usar más tu app';
				break;
			case 202:
				this.alert = '¡Ops! No tuviste depósitos ese mes';
				this.description = '¡Usa tu app y dale actividad a tus cuentas!';
				break;
			case 203:
				this.alert = '¡Sin retiros!';
				this.description = 'Parece que cuidaste muy bien';
				this.paragraph = 'tus finanzas el mes pasado';
				break;
			case 301:
				this.alert = 'Sin movimientos';
				this.description = '¡Vaya! No hiciste movimientos durante ese mes.';
				this.paragraph = 'Intenta usar más tu app';
				break;
			case 302:
				this.alert = 'No hubo depósitos en este tiempo';
				this.description = '¡Ánimo! Este mes puede ser mejor';
				break;
			case 303:
				this.alert = '¡Increíble! No hiciste retiros en ese mes';
				this.description = 'Usa más tu app para más movimientos';
				break;
				// Casos que corresponden a las combinaciones de filtro de TDC
			case 104:
			case 204:
			case 304:
				this.alert = '¡Vaya!';
				this.description = 'No tuviste movimientos en este periodo.'
				this.paragraph = '¡Usa más tu tarjeta!';
				break;
			case 105:
			case 205:
			case 305:
				this.alert = '¡Uy!';
				this.description = 'Parece que no hay ingresos en este'
				this.paragraph = 'periodo. ¿Todo bien con tus ingresos?';
				break;
			case 106:
			case 206:
		  case 306:
				this.alert = '¡Wow!';
				this.description = 'No usaste tu tarjeta en este periodo. Tus'
				this.paragraph = 'finanzas parecen estables';
				break;
			case 107:
			case 207:
			case 307:
				this.alert = '¡Ups!';
				this.description = 'No tenemos ningún pago por aprobar en'
				this.paragraph = 'este tiempo. ¡Usa más tu tarjeta!';
				break;
			default:
					this.alert = '¡Ups!';
					this.description = 'No tenemos ningún pago por aprobar en'
					this.paragraph = 'este tiempo. ¡Usa más tu tarjeta!';
				break;
			}
		}

	/**
	 * Muestra el bloque del filtro en la pantalla.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public showFilter(event): void {
		this.showContainerFilter = !this.showContainerFilter;
		this.updateHeight(351); // Por la animación de despliegue del filtro
	}

	/**
	 * Comprueba si el filtro por tipo tiene todas sus opciones activas.
	 *
	 * @returns {boolean}
	 * @memberof ProductsSummaryViewComponent
	 */
	public isAllFilter(): boolean {
		return (
			this.filter.expense &&
			this.filter.income &&
			(this.filter.pending || this.isCheckingAccount())
		);
	}

	/**
	 * Activa el filtro por periodo.
	 *
	 * @param {*} event Tipo de periodo seleccionado.
	 * @memberof ProductsSummaryViewComponent
	 */
	public filterByPeriod(event: any): void {
		const lastValue = this.selectedFilterPeriod;
		this.selectedFilterPeriod = event.num;
		this.cursor = '';
		if (event.num === 'chip-2') {
			this.periodCount = 0;
		} else {
			if (event.source.class !== 'active') {
				this.periodCount = 1;
			}
		}
		this.count = this.periodCount + this.typeCount;
		if (lastValue !== this.selectedFilterPeriod) {
			this.updateTransactions(false, true);
		}
		this.validationFilter();
	}

	/**
	 * Activa el filtro por tipo.
	 *
	 * @param {string} type Tipo de filtro seleccionado.
	 * @memberof ProductsSummaryViewComponent
	 */
	public filterByType(type: string, event: any): void {
		if (type === 'all') {
			this.activeAllFilter();
			this.typeCount = 0;
		} else {
			if (this.isCheckingAccount()) {
				this.clearFilter();
				this.filter[type] = true;
				if (event.source.class !== 'active') {
					this.typeCount = 1;
				}
			} else {
				if (this.isAllFilter()) {
					this.clearFilter();
					this.typeCount = 0;
				}
				this.filter[type] = !this.filter[type];
				if (event.source.class !== 'active') {
					this.typeCount++;
				} else {
					this.typeCount--;
				}
				if (this.typeCount === 3) {
					this.typeCount = 0;
				}
				if (this.isFilterClear()) {
					this.activeAllFilter();
					this.typeCount = 0;
				}
			}
		}
		this.typeFilter = type;
		this.validationFilter();
		this.count = this.periodCount + this.typeCount;
		this.implementFilter();
	}

	/**
	 * Comprueba si el producto actual del carrousel es una cuenta.
	 *
	 * @returns {boolean}
	 * @memberof ProductsSummaryViewComponent
	 */
	public isCheckingAccount(index?: number): boolean {
		return index
			? this.allCards[index].category_name === 'CHECKING_ACCOUNTS' ||
					this.allCards[index].category_name === 'CHECKING_ACCOUNTS_USD'
			: this.card.category_name === 'CHECKING_ACCOUNTS' ||
					this.card.category_name === 'CHECKING_ACCOUNTS_USD';
	}

	/**
	 * Actualiza el producto del carrousel y obtiene sus ultimas transacciones.
	 *
	 * @param {*} slide
	 * @returns
	 * @memberof ProductsSummaryViewComponent
	 */
	public changeTransactions(slide: any): void {
		if (this.loadingCards && !this.isCheckingAccount()) {
			return;
		}
		this.card = this.allCards[slide.index];
		this.setActive(slide.index);
		this.updateTransactions();
		const urlTree = this._router.createUrlTree([], {
			queryParams: { key: this.card.key },
			queryParamsHandling: 'merge',
			preserveFragment: true
		});
		this._location.go(urlTree.toString());
	}

	/**
	 * Muestra en un dialog el detalle de una transacción.
	 *
	 * @param {*} transaction transaccion seleccionada
	 * @memberof ProductsSummaryViewComponent
	 */
	public showTransaction(transaction: any): void {
		this.scrollActive = false;
		this.dialogRef = this._dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Detalle de movimiento',
				enableHr: false,
				disabledButton: false,
				buttons: [
					{
						label: ''
					}
				]
			},
			new CustomDialog(
				this.isCheckingAccount()
					? AccountMovementComponent
					: TransactionComponent,
				{
					transaction: transaction,
					blocked: this.card.status === 'BLOCKED',
					product: {
						card_key: this.card.key,
						card_name: this.card.alias
							? this.card.alias
							: this.card.description,
						card_number: this.card.display_number,
						card_image: this.card.image_url
					}
				}
			)
		);
		this.dialogRef.beforeClose().subscribe(_ => {
			this.scrollActive = true;
		});
	}

	/**
	 * Inicia el flujo de diposición de efectivo y comprueba si se puede realizar
	 * en caso de que no se pueda muestra una operación invalida.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public takeOutMoney(): void {
		if (this.accountsAvailable === 0) {
			this.showInvalidOperation(
				'¡Aún no tienes una cuenta de cheques!',
				'Abre una cuenta para realizar esta operación',
				null,
				'./assets/no-contacts.svg',
				'Sin cuenta de cheques'
			);
		} else if (this.card.balance.amount <= 0) {
			this.showInvalidOperation(
				'No tienes crédito disponible',
				'Espera a contar con saldo suficiente para disponer de efectivo',
				null,
				'./assets/no-money.svg'
			);
		} else if (this.card.status !== 'AVAILABLE') {
			// @TODO: corroborar si es correcto el flujo
			this.showInvalidOperation(
				'Inténtalo más tarde',
				'Ahora no es posible completar esta operación',
				'alert'
			);
		} else {
			this._router.navigate(['/summary/credit-card-money'], {
				queryParams: {
					key: this.card.key,
					account: this.card.display_number.substr(-6).replace(' ', ''),
					amount: this.card.balance.amount,
					currency: this.card.balance.currency_code,
					displayName: this.card.alias
						? this.card.alias
						: this.card.description,
					type: `./assets/icons/card-${this.card.type}.svg`
				},
				queryParamsHandling: 'merge'
			});
		}
	}

	/**
	 * Función que se ejecuta al hacer scroll sobre la vista y llegar al final
	 * de las transacciones, actualiza las mismas en busca de más.
	 *
	 * @param {*} event
	 * @memberof ProductsSummaryViewComponent
	 */
	public scrollHandler(event: any): void {
		if (event && !this.loading) {
			this.loading = true;
			if (this.transactions < this.transactionsCard.length) {
				this.transactions += this.transactionsStep;
				this.loading = false;
				this.updateHeight();
			} else {
				this.updateTransactions(true);
			}
		}
	}

	/**
	 * Permite bloquear el producto actual del carrousel mediante el quick action
	 * de la vista.
	 *
	 * @param {boolean} event
	 * @memberof ProductsSummaryViewComponent
	 */
	public blockCard(event: boolean): void {
		this.card.status = event ? 'BLOCKED' : 'AVAILABLE';
	}

	/**
	 * Abre el dialogo de contacto.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public openPhoneDialog(): void {
		this._contactDialogService.openDialogContact(this.type);
	}

	/**
	 * Navega a la vista summary (mis productos).
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public navigateToSummary() {
		if(this.card.display_number) {
			localStorage.setItem(
				'itemCard',
				this.card.display_number.substring(
					this.card.display_number.length - 4,
					this.card.display_number.length
				)
			);
		}
		this._router.navigate(['/summary/global-position']);
	}

	/**
	 * Permite navegar a la vista de pago de tarjeta de una TDC.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public navigatePayment(): void {
		const card = {
			key: this.card.key,
			balance: this.card.balance,
			cardType: this.card.type,
			display_number: this.card.display_number,
			name: this.card.description,
			alias: this.card.alias
		};
		this._dataTransferService.sendData(card);
		this._router.navigate(['/payments/card-payments']);
	}

	/**
	 * Permite navegar al flujo de transferencia de efectivo
	 * @TODO Validar que los flujos alternos sean los mismos que disposición de efectivo
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public transferMoney(): void {
		if (this.accountsAvailable === 0) {
			this.showInvalidOperation(
				'¡Aún no tienes una cuenta de cheques!',
				'Abre una cuenta para realizar esta operación',
				null,
				'./assets/no-contacts.svg',
				'Sin cuenta de cheques'
			);
		} else if (this.card.balance.amount <= 0) {
			this.showInvalidOperation(
				'No tienes crédito disponible',
				'Espera a contar con saldo suficiente para disponer de efectivo',
				null,
				'./assets/no-money.svg'
			);
		} else if (this.card.status !== 'AVAILABLE') {
			// @TODO: corroborar si es correcto el flujo
			this.showInvalidOperation(
				'Inténtalo más tarde',
				'Ahora no es posible completar esta operación',
				'alert'
			);
		} else {
			this._router.navigate(['/transfers/initial']);
		}
	}

	/**
	 * Permite navegar al pago de servicios
	 * @TODO Validar que los flujos alternos sean los mismos que disponer de efectivo
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	public payServices(): void {
		if (this.accountsAvailable === 0) {
			this.showInvalidOperation(
				'¡Aún no tienes una cuenta de cheques!',
				'Abre una cuenta para realizar esta operación',
				null,
				'./assets/no-contacts.svg',
				'Sin cuenta de cheques'
			);
		} else if (this.card.balance.amount <= 0) {
			this.showInvalidOperation(
				'No tienes crédito disponible',
				'Espera a contar con saldo suficiente para disponer de efectivo',
				null,
				'./assets/no-money.svg'
			);
		} else if (this.card.status !== 'AVAILABLE') {
			// @TODO: corroborar si es correcto el flujo
			this.showInvalidOperation(
				'Inténtalo más tarde',
				'Ahora no es posible completar esta operación',
				'alert'
			);
		} else {
			this._router.navigate(['/payments/services']);
		}
	}

	/**
	 * Obtiene los productos y crea la subscripción a los eventos del token dialog.
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	ngOnInit(): void {
		this.getCardsData();
		this._route.queryParams.subscribe(params => {
			if (params.hasOwnProperty('key')) {
				this.card = params;
			}
		});
		this._tokenDialogService.getConfirmEvent().subscribe(res => {
			this.confirmedToken = true;

			if (res.ok === 200) {
				this._tokenDialogService.setStatusSlide('success');
				this.card.flipped = true;
				// Para que se pueda ver el último estado por lo menos 1seg
				setTimeout(() => {
					this._tokenDialogService.closeDialogToken();
				}, 1000);
			}
		});

		this._tokenDialogService.getStateDialog().subscribe(res => {
			this.scrollActive = true;
			if (res === 'startclose' && this.confirmedToken) {
				this.confirmedToken = false;
				this.navigateToDetail();
			}
		});
	}

	/**
	 * Para evitar el error al cambio del titulo del componente sn-topbar
	 *
	 * @memberof ProductsSummaryViewComponent
	 */
	ngAfterContentChecked(): void {
		this._cdref.detectChanges();
	}
}
