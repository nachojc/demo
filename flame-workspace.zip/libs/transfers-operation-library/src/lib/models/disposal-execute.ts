/* tslint:disable */
import { Money } from './money';
export interface DisposalExecute {

  /**
   * The unique identifier of the origin account that can be used to the transfer operation
   */
  from_credit_card_key?: string;

  /**
   * The unique identifier of the destination account that can be used to the transfer operation
   */
  to_account_key?: string;
  amount?: Money;

  /**
   * Brief description of the concept
   */
  concept?: string;
  fee?: Money;
  tax?: {percentage?: string, rate?: number, amount?: Money};

  /**
   * Date and time when the cash advance was made. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  operation_date?: string;

  /**
   * Amount relating to tax.
   */
  reference?: string;
}
