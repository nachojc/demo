/* tslint:disable */
import { Bank } from './bank';
import { Notification } from './notification';
export interface BanksResponse {
  data?: Array<Bank>;
  notifications?: Array<Notification>;
}
