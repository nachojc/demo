/* tslint:disable */
import { Money } from './money';
export interface DisposalRequest {

  /**
   * The unique identifier of the origin account that can be used to the transfer operation
   */
  from_credit_card_key?: string;

  /**
   * The unique identifier of the destination account that can be used to the transfer operation
   */
  to_account_key?: string;
  amount?: Money;

  /**
   * Brief description of the concept
   */
  concept?: string;
}
