/* tslint:disable */
import { TransferExecute } from './transfer-execute';
export interface TransferThirdPartiesExecuted extends TransferExecute {
}
