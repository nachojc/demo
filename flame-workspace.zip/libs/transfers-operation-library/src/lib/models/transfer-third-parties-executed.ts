/* tslint:disable */
import { TransferExecute } from './transfer-execute';
export interface TransferThirdPartiesExecuted extends TransferExecute {

  /**
   * Date when the transfer was effective. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  creation_date?: string;

  /**
   * URL provided to download the Electronic Payment Proof (CEP for mexico)
   */
  receipt_url?: string;
}
