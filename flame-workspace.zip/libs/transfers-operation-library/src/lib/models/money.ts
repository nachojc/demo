/* tslint:disable */
export interface Money {

  /**
   * [ISO 4217](https://www.iso.org/iso-4217-currency-codes.html) currency code
   */
  currency_code?: string;

  /**
   * Any monetary amount should take the big-decimal format
   */
  amount?: number;
}
