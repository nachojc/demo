/* tslint:disable */
import { CashDisposalResponse } from './cash-disposal-response';
import { Notification } from './notification';
export interface DisposalResponse {
  data?: CashDisposalResponse;
  notifications?: Array<Notification>;
}
