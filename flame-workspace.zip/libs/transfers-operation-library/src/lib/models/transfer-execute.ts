/* tslint:disable */
import { Account } from './account';
import { Money } from './money';
export interface TransferExecute {
  from_account?: Account;

  /**
   * The unique transfer identifier of the transaction.
   */
  key?: string;

  /**
   * Date when the transfer was effective. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  effective_date?: string;

  /**
   * The status of the transfer to update
   */
  status?: 'PROCESSED' | 'BLOCKED' | 'DECLINED' | 'SCHEDULED';

  /**
   * The type identifier of the transfer
   */
  type?: 'UNIQUE' | 'RECURRING';

  /**
   * Transfer confirmation number.
   */
  confirmation_number?: string;
  to_account?: Account;
  amount?: Money;

  /**
   * Description of the transfer
   */
  concept?: string;

  /**
   * The transfer reference
   */
  reference?: string;

  /**
   * Indicates the type of movement that happens to the investment account  * `TRANSFER` -  Money transfer from the main account to the target account.
   *   * `WITHDRAWAL` - Money withdrawal from the target account to the main account.
   *   * `DEPOSIT` -  Money deposit from the main account to the target account.
   */
  operation_type?: 'TRANSFER' | 'WITHDRAWAL' | 'DEPOSIT';
}
