/* tslint:disable */
import { Money } from './money';
export interface Account {

  /**
   * The unique identifier of the account
   */
  key?: string;

  /**
   * The URL for the next step in the user experience for information account
   */
  url?: string;

  /**
   * The type identifier of the transfer
   */
  type?: 'CHECKING' | 'DEBIT';

  /**
   * Nickname of the account
   */
  alias?: string;

  /**
   * Obfuscated account number.
   */
  display_number?: string;

  /**
   * The name of the bank of the destination account
   */
  bank?: string;

  /**
   * Given name of the account.
   */
  name?: string;

  /**
   * Main account balance.
   */
  main_balance?: Money;
}
