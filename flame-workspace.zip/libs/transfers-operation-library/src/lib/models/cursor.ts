/* tslint:disable */

/**
 * Cursors object for identifying pagination before and after
 */
export interface Cursor {

  /**
   * The next cursor key for the set of entries retrieved. This value is left absent when there are no more values to return.
   */
  next_cursor_key?: string;
}
