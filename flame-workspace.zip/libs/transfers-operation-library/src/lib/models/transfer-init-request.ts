/* tslint:disable */
export interface TransferInitRequest {

  /**
   * The unique identifier of the default account that will be used for the transfer.
   */
  default_account_key?: string;
}
