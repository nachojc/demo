/* tslint:disable */
export interface CashAdvanceInitRequest {

  /**
   * The unique identifier of the default account that will be used for the transfer.
   */
  default_credit_card_key?: string;
}
