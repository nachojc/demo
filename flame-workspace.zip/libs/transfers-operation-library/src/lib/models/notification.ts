/* tslint:disable */
export interface Notification {

  /**
   * Code to identify the notification and classify acording to the firt character (E) Error, (W) Warning and (I) Info.
   */
  code?: string;

  /**
   * Notification description  for display to the customer.
   */
  description?: string;

  /**
   * Date and time when the notification is done. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html)
   */
  timestamp?: string;
}
