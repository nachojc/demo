/* tslint:disable */
import { PayeeDetail } from './payee-detail';
import { Notification } from './notification';
export interface PayeesResponse {
  data?: PayeeDetail;
  notifications?: Array<Notification>;
}
