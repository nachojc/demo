/* tslint:disable */
import { DetailModify } from './detail-modify';
import { Notification } from './notification';
export interface PayeeDetailModify {
  data?: DetailModify;
  notifications?: Array<Notification>;
}
