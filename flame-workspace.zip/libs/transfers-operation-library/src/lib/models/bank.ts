/* tslint:disable */
export interface Bank {

  /**
   * Bank code.
   */
  key?: string;

  /**
   * Full description of the bank institution.
   */
  name?: string;
}
