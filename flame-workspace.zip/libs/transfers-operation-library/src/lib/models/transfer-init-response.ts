/* tslint:disable */
import { TransferAttemptInit } from './transfer-attempt-init';
import { Notification } from './notification';
export interface TransferInitResponse {
  data?: TransferAttemptInit;
  notifications?: Array<Notification>;
}
