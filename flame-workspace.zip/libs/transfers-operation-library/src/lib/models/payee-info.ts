/* tslint:disable */
import { Payee } from './payee';
export interface PayeeInfo extends Payee {

  /**
   * Payee unique identifier.
   */
  key?: string;

  /**
   * Alias of the payee.
   */
  alias?: string;

  /**
   * CURP or RFC of the payee are a personal unique identifier, this information is optional. The CURP is composed of 18 characters and the RFC is composed of 13 characters
   */
  personal_identifier?: string;

  /**
   * The maximum amount to be transferred per account
   */
  transfer_limit?: number;
}
