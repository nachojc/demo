/* tslint:disable */
import { TransferAccountsDetail } from './transfer-accounts-detail';
import { Notification } from './notification';
import { Cursor } from './cursor';
export interface TransfersInfoResponse {

  /**
   * Lists the transfers information
   */
  data?: Array<TransferAccountsDetail>;
  notifications?: Array<Notification>;
  paging?: Cursor;
}

/**
 * Interfaz Body query para consultar y filtrar las transferencias hechas por el usuario
 */
export interface TransfersGetParams {

  /**
   * [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html) Date and time when the notification is done
   */
  startDate?: Date;

  /**
   * [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html) Date and time when the notification is done
   */
  endDate?: Date;

  /**
   * Unique identifier of the origin account.
   */
  originAccount?: string;

  /**
   * Unique identifier of the destination account.
   */
  destinationAccount?: string;

  /**
   * The minimum amount for the transfer
   */
  minAmount?: number;

  /**
   * The maximum amount for the transfer.
   */
  maxAmount?: number;

  /**
   * The transfer type for retrieve all the customer transfers. For example: EXECUTE, SCHEDULED
   */
  transferType?: TransfersGetParams.TransferType;

  /**
   * The transfer status for retrieve for retrieve all the customer transfers. For example: POSTED, PENDING
   */
  transferStatus?: TransfersGetParams.TransferStatus;

  /**
   * Cursor for the next call. If the query is not informed indicates the first call.
   */
  cursor?: string;

  /**
   * Number of elements to be retrieved
   */
  limit?: number;
}

export namespace TransfersGetParams {
  export type TransferType = 'EXECUTE' | 'SCHEDULED';
  export const TransferType = {
    EXECUTE: 'EXECUTE' as TransferType,
    SCHEDULED: 'SCHEDULED' as TransferType,
  };
  export type TransferStatus = 'POSTED' | 'PENDING';
  export const TransferStatus = {
    POSTED: 'POSTED' as TransferStatus,
    PENDING: 'PENDING' as TransferStatus
  }
}
