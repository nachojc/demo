/* tslint:disable */
import { PayeeDetailDelete } from './payee-detail-delete';
import { Notification } from './notification';
export interface DeletePayeeResponse {
  data?: PayeeDetailDelete;
  notifications?: Array<Notification>;
}
