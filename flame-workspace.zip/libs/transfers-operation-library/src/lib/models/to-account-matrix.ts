/* tslint:disable */
export interface ToAccountMatrix {

  /**
   * The unique identifier of the destination account that can be used to the transfer operation
   */
  account_key?: string;

  /**
   * The maximum amount for a transfer
   */
  max_limit?: number;

  /**
   * The minimum amount for a transfer.
   */
  min_limit?: number;
}
