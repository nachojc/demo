/* tslint:disable */
import { CashWithDrawalsAttemptInit } from './cash-with-drawals-attempt-init';
export interface CashWithDrawalsInitResponse {
  data?: CashWithDrawalsAttemptInit;
}
