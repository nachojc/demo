/* tslint:disable */
import { CashWithDrawalsAttemptInit } from './cash-with-drawals-attempt-init';
import { Notification } from './notification';
export interface CashWithDrawalsInitResponse {
  data?: CashWithDrawalsAttemptInit;
  notifications?: Array<Notification>;
}
