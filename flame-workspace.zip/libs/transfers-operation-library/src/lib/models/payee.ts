/* tslint:disable */
import { PayeeAccount } from './payee-account';

/**
 * Person that receives a payment.
 */
export interface Payee {

  /**
   * Full payee name.
   */
  name?: string;

  /**
   * Alias of the payee.
   */
  alias?: string;
  account?: PayeeAccount;
}
