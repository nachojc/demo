/* tslint:disable */
import { ToAccountMatrix } from './to-account-matrix';
export interface TransferMatrix {

  /**
   * The unique identifier of the origin account that can be used to the transfer operation
   */
  from_account_key?: string;
  to_accounts?: Array<ToAccountMatrix>;
}
