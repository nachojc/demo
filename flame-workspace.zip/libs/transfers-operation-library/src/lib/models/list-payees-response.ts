/* tslint:disable */
import { PayeeSummary } from './payee-summary';
import { Notification } from './notification';
import { Cursor } from './cursor';
export interface ListPayeesResponse {
  data?: Array<PayeeSummary>;
  notifications?: Array<Notification>;
  paging?: Cursor;
}
