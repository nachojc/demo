/* tslint:disable */
import { TransferExecute } from './transfer-execute';
import { Notification } from './notification';
export interface TransferResponse {
  data?: TransferExecute;
  notifications?: Array<Notification>;
}
