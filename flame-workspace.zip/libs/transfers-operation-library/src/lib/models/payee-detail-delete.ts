/* tslint:disable */
import { PayeeInfo } from './payee-info';
export interface PayeeDetailDelete extends PayeeInfo {

  /**
   * The unique identifier of the payee.
   */
  key?: string;

  /**
   * Date the payee was registered. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  creation_date?: string;

  /**
   * The status of the payee  * `DELETED` -  Indicates whether the payee was deleted.
   */
  status?: 'DELETED';
}
