/* tslint:disable */
import { Notification } from './notification';
export interface EmptyDataResponse {
  data?: string;
  notifications?: Array<Notification>;
}
