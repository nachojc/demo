/* tslint:disable */
import { TransferExecute } from './transfer-execute';
import { Notification } from './notification';
export interface TransferReceiptResponse {
  data?: TransferExecute;
  notifications?: Array<Notification>;
}
