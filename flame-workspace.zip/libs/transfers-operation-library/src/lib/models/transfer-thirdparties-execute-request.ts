/* tslint:disable */
import { TransferExecuteRequest } from './transfer-execute-request';
export interface TransferThirdpartiesExecuteRequest extends TransferExecuteRequest {

  /**
   * The name of the bank of the destination account
   */
  bank?: string;
}
