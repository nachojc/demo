/* tslint:disable */
import { TransferThirdPartiesExecuted } from './transfer-third-parties-executed';
import { Notification } from './notification';
export interface TransferThirdPartiesExecuteResponse {
  data?: TransferThirdPartiesExecuted;
  notifications?: Array<Notification>;
}
