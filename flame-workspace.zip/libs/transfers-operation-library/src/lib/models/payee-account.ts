/* tslint:disable */
export interface PayeeAccount {

  /**
   * The account number related to the payee
   */
  number?: string;

  /**
   * Refers to the bank name of the account number related to the payee
   */
  bank?: string;

  /**
   * Shows the type of payee account. * `SANTANDER_ACCOUNT` - Santander account number to 11 digits
   *  * `CLABE` - Interbank key to 18 digits
   *  * `MOBILE_ACCOUNT` - The mobile number that is associated with a bank account
   *  * `THIRDPARTY_DEBIT_CARD` - The debit card number to 18 digits
   *  * `CREDIT_CARD` - The credit card number to 18 digits
   */
  account_type?: 'SANTANDER_ACCOUNT' | 'CLABE' | 'MOBILE_ACCOUNT' | 'THIRDPARTY_DEBIT_CARD' | 'CREDIT_CARD';
}
