/* tslint:disable */
export interface Card {

  /**
   * The unique identifier of the account
   */
  key?: string;

  /**
   * Nickname of the card
   */
  alias?: string;

  /**
   * Obfuscated card number
   */
  display?: string;

  /**
   * The name of the bank of the destination account
   */
  bank?: string;
}
