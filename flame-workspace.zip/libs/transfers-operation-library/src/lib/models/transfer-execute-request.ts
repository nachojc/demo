/* tslint:disable */
import { Money } from './money';
export interface TransferExecuteRequest {

  /**
   * The unique identifier of the origin account that can be used to the transfer operation
   */
  from_account_key?: string;

  /**
   * The unique identifier of the destination account that can be used to the transfer operation
   */
  to_account_key?: string;
  amount?: Money;

  /**
   * Description of the transfer
   */
  concept?: string;

  /**
   * The transfer reference
   */
  reference?: string;

  /**
   * Date and time when the transfer was executed. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  effective_date?: string;

  /**
   * Indicates the type of movement that happens to the investment account  * `TRANSFER` -  Money transfer from the main account to the target account.
   *   * `WITHDRAWAL` - Money withdrawal from the target account to the main account.
   *   * `DEPOSIT` -  Money deposit from the main account to the target account.
   */
  operation_type?: 'TRANSFER' | 'WITHDRAWAL' | 'DEPOSIT';
}
