/* tslint:disable */
import { Card } from './card';
import { Account } from './account';
export interface CashWithDrawalsAttemptInit {

  /**
   * The unique transfer identifier of the transaction. Used for subsequent steps to complete the transfer.
   */
  key?: string;
  credits_cards?: Array<Card>;
  accounts?: Array<Account>;
}
