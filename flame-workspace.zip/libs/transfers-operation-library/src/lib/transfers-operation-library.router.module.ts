import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TransferSameBankViewComponent } from './views/transfer-money-view/transfers-same-bank/same-bank-view.component';
import { TransferEmptyStateViewComponent } from './views/transfer-money-view/transfers-empty-state/empty-state-view.component';
import { TransfersVoucherViewComponent } from './views/transfer-money-view/transfers-voucher/transfers-voucher-view.component';
import { TransfersSameAccountsComponent } from './views/transfer-money-view/transfers-same-accounts/transfers-same-accounts.component';
import { TranfersOthersBanksComponent } from './views/transfer-money-view/transfers-others-banks/tranfers-others-banks.component';
import { TranfersVoucherOthersBanksComponent } from './views/transfer-money-view/transfers-voucher-others-banks/voucher-others-banks.component';
import { TransferInitialViewComponent } from './views/transfer-money-view/transfer-initial-view/transfer-initial-view.component';

const routes: Routes = [
	{
		path: 'same-bank',
		component: TransferSameBankViewComponent
	},
	{
		path: 'empty-state',
		component: TransferEmptyStateViewComponent
	},
	{
		path: 'voucher',
		component: TransfersVoucherViewComponent
	},
	{
		path: 'between-same-accounts',
		component: TransfersSameAccountsComponent
	},
	{
		path: 'others-banks',
		component: TranfersOthersBanksComponent
	},
	{
		path: 'voucher-others-banks',
		component: TranfersVoucherOthersBanksComponent
  },
  {
    path: 'initial',
    component: TransferInitialViewComponent
  }
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class TransfersOperationLibraryRoutingModule {}
