import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TransferEmptyStateViewComponent } from './views/transfer-money-view/transfers-empty-state/empty-state-view.component';
import { TransfersVoucherViewComponent } from './views/transfer-money-view/transfers-voucher/transfers-voucher-view.component';
import { TransfersSameAccountsComponent } from './views/transfer-money-view/transfers-same-accounts/transfers-same-accounts.component';
import { TranfersOthersBanksComponent } from './views/transfer-money-view/transfers-others-banks/tranfers-others-banks.component';
import { TranfersVoucherOthersBanksComponent } from './views/transfer-money-view/transfers-voucher-others-banks/voucher-others-banks.component';
import { TransferInitialViewComponent } from './views/transfer-money-view/transfer-initial-view/transfer-initial-view.component';
import { TransferSameBankViewComponent } from './views/transfer-money-view/transfers-same-bank/same-bank-view.component';


const routes: Routes = [
  {
    path: 'initial',
    component: TransferInitialViewComponent,
    data: { num: 81 }
  },
  {
    path: 'empty-state',
    component: TransferEmptyStateViewComponent,
    data: { num: 81 }
  },
  {
    path: 'voucher-others-banks',
    component: TranfersVoucherOthersBanksComponent,
    data: { num: 82 }
  },
	{
		path: 'voucher',
    component: TransfersVoucherViewComponent,
    data: { num: 82 }
	},
	{
    path: 'between-same-accounts',
		component: TransfersSameAccountsComponent
	},
	{
    path: 'others-banks',
		component: TranfersOthersBanksComponent
	},
  {
    path: 'same-bank',
    component: TransferSameBankViewComponent
  },
];


@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class TransfersOperationLibraryRoutingModule {}
