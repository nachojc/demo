import {
	trigger,
	animate,
	transition,
  style,
  state
} from '@angular/animations';

export const voucherIn = trigger('voucherIn', [
  state(
    'void',
    style({
      transform: 'scale(0.75)',
      opacity: '0'
    })
  ),
  state(
    'normal',
    style({
      transform: 'scale(1)',
      opacity: '1'
    })
  ),
  transition('void => normal', [animate('0.40s ease-in')])
])

export const voucherOut = trigger('voucherOut', [
  state(
    'normal',
    style({
      transform: 'scale(1)',
      opacity: '1'
    })
  ),
  state(
    'void',
    style({
      transform: 'scale(0.75)',
      opacity: '0'
    })
  ),
  transition('normal => void', [animate('0.40s ease-in')])
])
