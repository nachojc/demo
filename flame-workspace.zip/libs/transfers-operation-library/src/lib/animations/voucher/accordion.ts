import {
	trigger,
	animate,
	transition,
	style,
	state
} from '@angular/animations';

export const accordionAnimation = trigger('accordionAnimation', [
	state(
		'initial',
		style({
			height: '0',
			overflow: 'hidden',
			opacity: '1'
		})
	),
	state(
		'final',
		style({
			overflow: 'hidden',
			opacity: '1'
		})
	),
	transition('initial=>final', animate('0.30s ease-in')),
	transition('final=>initial', animate('0.30s ease-in'))
]);
