import {
	trigger,
  animate,
  animation,
  transition,
  keyframes,
  style,
  state,
  query,
  group
} from '@angular/animations';

export const headerAnimation = trigger('headerAnimation', [
  transition(
    ':enter',
    [animation(
      animate(
        '{{time}} cubic-bezier(0.250, 0.460, 0.450, 0.940)',
        keyframes([
          style({ transform: 'rotateX(100deg)', offset: 0 }),
          style({ transformOrigin: 'bottom', offset: 0 }),
          style({ opacity: '0', offset: 0 }),
          style({ transform: 'rotateX(0)', offset: 1 }),
          style({ opacity: '1', offset: 1 })
        ])
      ),
      { params: { time: '0.3s'} }
    )]
  ),
  transition(
    ':leave',[
      animation(
        animate(
          '{{time}} linear',
          keyframes([
            style({ transformOrigin: 'bottom', offset: 0 }),
            style({ transform: 'scaleY(0)', offset: 1 }),
            style({ transformOrigin: 'bottom', offset: 1 }),
          ])
        ),
      { params: { time: '0.3s'} }
    )]
  ),
]);

export const listAnimation = trigger('listAnimation', [
  transition(
    ':enter',[
      style({opacity: 0}),
      animation(
        animate(
          '{{time}} cubic-bezier(0.4, 0.21, 0.3, 1.000)',
          keyframes([
            style({ transform: 'translateY(100px)', offset: 0 }),
            style({ transform: 'translateY(0)', offset: 1 }),
            style({ opacity: '1', offset: 1.0 })
          ])
        ),
      { params: { time: '0.5s'} }
    )]
  ),
  transition(
    ':leave',[
      style({opacity: 1}),
      animation(
        animate(
          '{{time}} cubic-bezier(0.4, 0.21, 0.3, 1.000)',
          keyframes([
            style({ transform: 'translateY(0)', offset: 0 }),
            style({ opacity: '0', offset: 1.0 }),
            style({ transform: 'translateY(100px)', offset: 1 })
          ])
        ),
      { params: { time: '0.3s'} }
    )]
  ),
]);

export const buttonFadeAnimation = trigger('buttonAnimation', [
  transition(
    ':leave',[
    animation(
      animate('{{time}} cubic-bezier(0.550, 0.085, 0.680, 0.530)',
      keyframes([
        style({transform: 'scaleX(1)', offset: 0}),
        style({transformOrigin: '0 0', offset: 0}),
        style({transform: 'scaleX(0)', offset: 1}),
      ])
      ),
      { params: { time: '0.2s'} }
    )
  ]),
]);
