import { TransitionsTransfersAnimations, VoucherTransfersOutAnimation, VoucherTransfersInAnimation, TransitionsTransfersReverseAnimations } from './transitions/transitions.animations';

export const RouterTransfersAnimations = [
  TransitionsTransfersAnimations,
  TransitionsTransfersReverseAnimations,
  VoucherTransfersOutAnimation,
  VoucherTransfersInAnimation
]
