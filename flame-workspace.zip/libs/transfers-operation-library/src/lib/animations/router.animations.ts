import { TransitionsTransfersAnimations, VoucherTransfersInAnimation } from './transitions/transitions.animations';

export const RouterTransfersAnimations = [
  TransitionsTransfersAnimations,
  VoucherTransfersInAnimation,
]
