import {
	trigger,
  animate,
  animation,
  transition,
  keyframes,
  style,
  state,
  query,
  group
} from '@angular/animations';

export const headerInitialViewAnimation = trigger('headerAnimation', [
  transition(
    ':enter',[
    style({opacity: 0}),
    style({transform: 'translateZ(-80px)'}),
    animation(
      animate(
        '{{time}} cubic-bezier(0.250, 0.460, 0.450, 0.940)',
        keyframes([
          style({ transform: 'translateZ(-80px)', offset: 0 }),
          style({ opacity: '0', offset: 0 }),
          style({ transform: 'translateZ(0)', offset: 1 }),
          style({ opacity: '1', offset: 1 })
        ])
      ),
      { params: { time: '0.25s'} }
    )]
  ),
  transition(
    ':leave',
    [animation(
      animate(
        '{{time}} cubic-bezier(0.250, 0.460, 0.450, 0.940)',
        keyframes([
          style({ transform: 'translateZ(0)', offset: 0 }),
          style({ opacity: '1', offset: 0 }),
          style({ transform: 'translateZ(-80px)', offset: 1 }),
          style({ opacity: '0', offset: 1 })
        ])
      ),
      { params: { time: '0.25s'} }
    )]
  ),
])
