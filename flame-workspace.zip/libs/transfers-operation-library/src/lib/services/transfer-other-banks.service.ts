import { Injectable, Inject, Injector } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { Platform } from '@angular/cdk/platform';
import { TransferInitRequest } from '../models/transfer-init-request';
import { TransferThirdpartiesExecuteRequest } from '../models/transfer-thirdparties-execute-request';
import { catchError, mergeMap } from 'rxjs/operators';
import { of } from 'rxjs';
import {
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { DialogErrorComponent } from '../components/dialog-dummy/dialog-dummy.component';

@Injectable()
export class TransfersOtherBanksService {
	private _urlTransfers = this.environment.baas.urlTransfers;
	private dialogRef: DialogReference;

	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _injector: Injector,
		private dialog: DialogService
	) {
		const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
	}

	private _httpClient: any;

	initializeNewTransfer(key: TransferInitRequest) {
		return this._httpClient
			.post(`${this._urlTransfers}third-parties`, key)
			.pipe(
				mergeMap((data: Response) => {
          // manejo successful
          localStorage.setItem('showComponent', 'true');
					return of(data);
				}),
				catchError((errHttp: HttpErrorResponse) => {
					localStorage.setItem('showComponent', 'false');
					this.showErrorDialog(errHttp, 'Error', 'Ocurrio un error', './');
					return of();
				})
			);
	}

	executeTransfer(
		keyTransfer: string,
		transferThirdpartiesExecuteRequest: TransferThirdpartiesExecuteRequest
	) {
		return this._httpClient
			.put(
				`${this._urlTransfers}third-parties/${keyTransfer}/execute`,
				transferThirdpartiesExecuteRequest
			)
			.pipe(
				mergeMap((data: Response) => {
					// manejo successful
					return of(data);
				}),
				catchError((errHttp: HttpErrorResponse) => {
					this.showErrorDialog(errHttp, 'Error', 'Ocurrio un error', './');
					return of({});
				})
			);
	}

	showErrorDialog(
		errHttp: HttpErrorResponse,
		title: string,
		message: string,
		url: string
	) {
		this.dialogRef = this.dialog.open(
			{
				title: 'Operación inválida',
				enableHr: true,
				disabledButton: true,
				closeBackdropClick: false,
				buttons: [
					{
						class: 'strech',
						label: 'Aceptar',
						action: scope => {
							this.dialogRef.close();
						}
					}
				]
			},
			new CustomDialog(DialogErrorComponent, {
				titleInvalid: title,
				message: message,
				url: url
			})
		);
	}
}
