import { Injectable, Inject, Injector } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { Platform } from '@angular/cdk/platform';
import { TransferInitRequest } from '../models/transfer-init-request';
import { TransferThirdpartiesExecuteRequest } from '../models/transfer-thirdparties-execute-request';

@Injectable()
export class TransfersOtherBanksService {
	private _urlTransfers = this.environment.baas.urlTransfers;

	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _injector: Injector
	) {
		const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
	}

	private _httpClient: any;

	createAuthorizationHeader() {
		return new HttpHeaders({
			Authorization: '79274258',
			'Content-Type': 'application/json',
			Accept: 'application/json'
		});
	}

	initializeNewTransfer(key: TransferInitRequest) {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.post(`${this._urlTransfers}third-parties`, key, {
			headers: headers
		});
	}

	executeTransfer(
		keyTransfer: string,
		transferThirdpartiesExecuteRequest: TransferThirdpartiesExecuteRequest
	) {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.put(
			`${this._urlTransfers}third-parties/${keyTransfer}/execute`,
			transferThirdpartiesExecuteRequest,
			{ headers: headers }
		);
	}
}
