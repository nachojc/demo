import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { TransferInitRequest } from '../models/transfer-init-request';
import { TransferThirdpartiesExecuteRequest } from '../models/transfer-thirdparties-execute-request';
import { catchError, mergeMap } from 'rxjs/operators';
import { of } from 'rxjs';
import {
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { DialogErrorComponent } from '../components/dialog-dummy/dialog-dummy.component';
import { PayeesResponse } from '../models';

@Injectable()
export class TransfersOtherBanksService {
	private _urlTransfers = this.environment.api.url + '/transfers';
	private _urlBeneficiary =
		this.environment.api.url + `${this._urlTransfers}/payees/`;
	private dialogRef: DialogReference;

	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient,
		private dialog: DialogService
	) {}

	initializeNewTransfer(paramsBody: any) {
		return this._httpClient
			.post(`${this._urlTransfers}/third-parties`, paramsBody)
			.pipe(
				mergeMap((data: Response) => {
					return of(data);
				}),
				catchError((errHttp: HttpErrorResponse) => {
					this.showErrorDialog(
						errHttp,
						'Algo anda mal aquí',
						'Nuestro servicio de tranferencias no está disponible por ahora. Prueba más tarde',
						undefined
					);
					return of();
				})
			);
	}

	getInfoByKey(keyBeneficiary: string) {
		return this._httpClient.get<PayeesResponse>(
			this._urlBeneficiary + keyBeneficiary
		);
	}

	executeTransfer(
		keyTransfer: string,
		transferThirdpartiesExecuteRequest: TransferThirdpartiesExecuteRequest
	) {
		return this._httpClient
			.put(
				`${this._urlTransfers}/third-parties/${keyTransfer}/execute`,
				transferThirdpartiesExecuteRequest
			)
			.pipe(
				mergeMap((data: Response) => {
					// manejo successful
					return of(data);
				}),
				catchError((errHttp: HttpErrorResponse) => {
					this.showErrorDialog(
						errHttp,
						'Algo anda mal aquí',
						'Nuestro servicio de tranferencias no está disponible por ahora. Prueba más tarde',
						undefined
					);
					return of();
				})
			);
	}

	showErrorDialog(
		errHttp: HttpErrorResponse,
		title: string,
		message: string,
		url: string
	) {
		this.dialogRef = this.dialog.open(
			{
				title: '',
				closeLabel: 'cerrar',
				enableHr: true,
				disabledButton: true,
				closeBackdropClick: false,
				buttons: [
					{
						class: 'strech',
						label: 'Aceptar',
						action: scope => {
							this.dialogRef.close();
						}
					}
				]
			},
			new CustomDialog(DialogErrorComponent, {
				titleInvalid: title,
				message: message,
				url: url
			})
		);
	}
}
