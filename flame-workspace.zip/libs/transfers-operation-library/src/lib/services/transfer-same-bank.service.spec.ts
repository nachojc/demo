import { TestBed, inject, async } from "@angular/core/testing";
import { TransferSameBankService } from './transfer-same-bank.service';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { OverlayModule } from '@angular/cdk/overlay';
import { HttpClientTestingModule } from '@angular/common/http/testing';

const environment = {
  production: false,
  sm: {
    clientId: '0KxtKPNZzUIMueEfxeP6x_NKWPJLRREWHEHsyOw1a4w',
    clientSecret: 	'KLkcUzobEGpTo8idYowgscCZPs1aRvnhSF0tEYQSZ5k='
  },
	idp: {
		url: 'http://localhost:3000/IDPWeb/idp',
		redirectUri: 'http://www.santander.com.mx/mx/home'
	},
	oauth: {
		url: 'http://localhost:3000/oauth2/v1/token',
    scope: 'summary_1.0.0 accounts_1.0.0'
  },
  api: {
    url: 'http://localhost:3000/api',
    version: {
      summary: '',
      accounts: '',
      credits: '',
      cards: '',
      transfers: ''
    }
  }
};

describe('Service: LanguagesService', () => {
  let service;

  beforeEach(() => TestBed.configureTestingModule({
    imports: [
      HttpClientTestingModule,
      OverlayModule
    ],
    providers: [ TransferSameBankService,
      {
        provide: ENV_CONFIG,
        useValue: environment
      } ]
  }));

  beforeEach(inject([TransferSameBankService], s => {
    service = s;
  }));

  it('getPayeesLookup', async(() => {
    service.getPayeeLookup().subscribe( resultado => {
      expect(resultado.data.key).toBe('4e20fbb243684d9eb19ff33a50ee422f');
    })
  }));

  it('getAllPayees', async(()=>{
    service.getAllPayees().subscribe( resultado => {
      expect(resultado.data.length).toBe(4);
    })
  }));

  it('getPayeeDetailed', async(()=>{
    service.getPayeeDetailed().subscribe( resultado => {
      expect(resultado.data.account).toBeDefined();
    })
  }))
});
