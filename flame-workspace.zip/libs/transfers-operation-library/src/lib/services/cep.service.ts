import { Injectable } from '@angular/core';
import * as CryptoJS from 'crypto-js';

@Injectable()
export class CepTranferService {
	/**
	 * url de banxico.org
	 *
	 * @private
	 * @memberof CepTranferService
	 */
	private _url = 'https://www.banxico.org.mx/cep/go';

	constructor() {}

	/**
	 * se genera la url donde iran los datos i, s, d
	 * i= clave spei de la intitución que genera la url, s= numero de serie de la clave utilizada para el cifrado, d= información de la consulta cifrada
	 * @param {*} info
	 * @returns
	 * @memberof CepTranferService
	 */
	generateUrlGet(info: any) {
		return `${this._url}?i=${info.referenceNumber}&s=${
			info.serieClaveBankSendEmit
		}&d=${this.generateKeyEncrypt(info)}`;
	}

	/**
	 * se checa que caracter de busqueda, R= Referenci, T= clave de rastreo
	 *
	 * @param {*} checkCharacter
	 * @returns
	 * @memberof CepTranferService
	 */
	checkConsultCharacter(checkCharacter: any) {
		if (checkCharacter.referenceNumber) {
			return `R|${checkCharacter.referenceNumber}`;
		} else {
			// return `T|${check.clave_de_rastreo}` se tiene que checar aun con apis
		}
	}

	/**
	 * se genera la cadena a cifrar : fecha|criterio de consulta|valor de consulta|clave spei banco emisor|clave spei banco receptor|numero de cuenta del beneficiario|monto de la operacio
	 *
	 * @param {*} dataToEncrypt
	 * @returns
	 * @memberof CepTranferService
	 */
	generateKeyEncrypt(dataToEncrypt: any) {
		const stringToEncrypt = `${dataToEncrypt.date.replace(
			/\//g,
			''
		)}|${this.checkConsultCharacter(dataToEncrypt)}|${
			dataToEncrypt.speiOrigin
		}|${dataToEncrypt.speiSend}|${dataToEncrypt.accountNumber.replace(
			/\ /g,
			''
		)}|${dataToEncrypt.totalSend}`;
		return this.sanitization(this.encryptAES128(stringToEncrypt));
	}

	/**
	 * se cifra en AES-128
	 *
	 * @param {string} stringToEncryptAES
	 * @returns
	 * @memberof CepTranferService
	 */
	encryptAES128(stringToEncryptAES: string) {
		const key = CryptoJS.enc.Utf8.parse(stringToEncryptAES);
		const iv = CryptoJS.enc.Utf8.parse(stringToEncryptAES);
		const encrypted = CryptoJS.AES.encrypt('String to encrypt', key, {
			keySize: 16,
			iv: iv,
			mode: CryptoJS.mode.ECB,
			padding: CryptoJS.pad.Pkcs7
		});
		return encrypted;
	}

	/**
	 * se cifra en B64 y se remplasan los caracteres (+,= o /) para considerarse en una url como insegura
	 *
	 * @param {string} stringToSatination
	 * @returns
	 * @memberof CepTranferService
	 */
	sanitization(stringToSatination: string) {
		const resulEncrypt = btoa(stringToSatination);
		const resultStringSanitization = resulEncrypt.replace(/\+|\=|\//g, '');
		return resultStringSanitization;
	}
}
