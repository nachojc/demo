import { Injectable, Inject, Injector } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { map } from 'rxjs/operators';
import { PayeeExternalResponse } from 'libs/beneficiary-operation-library/src/lib/models/payee-external-response';
import { ListPayeesResponse } from 'libs/beneficiary-operation-library/src/lib/models/list-payees-response';
import { PayeesResponse } from 'libs/beneficiary-operation-library/src/lib/models/payees-response';
import { ModifyRequest } from 'libs/beneficiary-operation-library/src/lib/models/modify-request';
import { PayeeDetailModify } from 'libs/beneficiary-operation-library/src/lib/models/payee-detail-modify';
import { TransferInitRequest, TransferInitResponse, TransfersInfoResponse, TransfersGetParams, TransferExecuteRequest, TransferResponse, TransferReceiptResponse } from '../models';
import { Platform } from '@angular/cdk/platform';

@Injectable()
export class TransferSameBankService {
  private _urlTransfers = this.environment.baas.urlTransfers;
  private _urlPayees = `${this._urlTransfers}payees`;
  private _urlSummary = this.environment.baas.urlSummary;

	constructor(
    @Inject(ENV_CONFIG) private environment: any,
    private _injector: Injector,
    private _httpClient: HttpClient
  ) {
  }

  getPayeeLookup(key:string){
    const params = new HttpParams()
    .set('indentifier', key);
    return this._httpClient.get<PayeeExternalResponse>(this._urlPayees, {params});
  }

  getAllPayees(cursor?: string, limit?: string){
    const params = new HttpParams()
    if (cursor){
      params.append('cursor', cursor);
    }else if(limit){
      params.append('limit', limit);
    }
    return this._httpClient.get<ListPayeesResponse>(this._urlPayees, {params});
  }

  getPayeeDetailed(key: string){
    return this._httpClient.get<PayeesResponse>(`${this._urlPayees}/${key}`);
  }

  modifyPayee(key: string, body: ModifyRequest){
    return this._httpClient.put<PayeeDetailModify>(`${this._urlPayees}/${key}`, body);
  }

  deletePayee(){
    // No se requiere en esta operativa esta accion
  }

  initializeTransfer(body: TransferInitRequest){
    return this._httpClient.post<TransferInitResponse>(this._urlTransfers, body);
  }

  getTransfersByCustomer(query: TransfersGetParams){
    const params = new HttpParams()
    if (query){
      Object.keys(query).forEach((value) => {
        if (query[value]){
          params.append(value, query[value]);
        }
      });
    }
    return this._httpClient.get<TransfersInfoResponse>(this._urlTransfers, {params});
  }

  executeTransfer(key: string, body: TransferExecuteRequest){
    return this._httpClient.put<TransferResponse>(`${this._urlTransfers}/${key}/execute`, body);
  }

  getDetailedTransfer(key: string){
    return this._httpClient.get<TransferReceiptResponse>(`${this._urlTransfers}/${key}`);
  }

  getAccounts(){
    return this._httpClient.get(this._urlSummary);
  }
}
