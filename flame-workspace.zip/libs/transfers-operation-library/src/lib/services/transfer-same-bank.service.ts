import { Injectable, Inject, Injector } from '@angular/core';
import {
	HttpClient,
	HttpParams,
	HttpErrorResponse
} from '@angular/common/http';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { catchError, mergeMap } from 'rxjs/operators';
import { ModifyRequest } from 'libs/beneficiary-operation-library/src/lib/models/modify-request';
import {
	TransferInitRequest,
	TransfersGetParams,
	TransferExecuteRequest
} from '../models';
import { Platform } from '@angular/cdk/platform';
import {
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { DialogErrorComponent } from '../components/dialog-dummy/dialog-dummy.component';
import { of } from 'rxjs';

@Injectable()
export class TransferSameBankService {
	private _urlTransfers = this.environment.baas.urlTransfers;
	private _urlPayees = `${this._urlTransfers}payees`;
	private _urlSummary = this.environment.baas.urlSummary;
	private dialogRef: DialogReference;

	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _injector: Injector,
		private dialog: DialogService
	) {
		const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
	}

	private _httpClient: any;

	getPayeeLookup(key: string) {
		const params = new HttpParams().set('indentifier', key);
		return this._httpClient.get(this._urlPayees, {
			params
		});
	}

	getAllPayees(cursor?: string, limit?: string) {
		const params = new HttpParams();
		if (cursor) {
			params.append('cursor', cursor);
		} else if (limit) {
			params.append('limit', limit);
		}
		return this._httpClient
			.get(this._urlPayees, {
				params
			})
			.pipe(
				mergeMap((data: Response) => {
					// manejo successful
					return of(data);
				}),
				catchError((errHttp: HttpErrorResponse) => {
					this.showErrorDialog(errHttp, 'Error', 'Ocurrio un error', './');
					return of({});
				})
			);
	}

	getPayeeDetailed(key: string) {
		return this._httpClient.get(`${this._urlPayees}/${key}`);
	}

	modifyPayee(key: string, body: ModifyRequest) {
		return this._httpClient.put(`${this._urlPayees}/${key}`, body);
	}

	initializeTransfer(body: TransferInitRequest) {
		return this._httpClient.post(this._urlTransfers, body).pipe(
			mergeMap((data: Response) => {
				return of(data);
			}),
			catchError((errHttp: HttpErrorResponse) => {
				this.showErrorDialog(errHttp, 'Error', 'Ocurrio un error', './');
				return of({});
			})
		);
	}

	getTransfersByCustomer(query: TransfersGetParams) {
		const params = new HttpParams();
		if (query) {
			Object.keys(query).forEach(value => {
				if (query[value]) {
					params.append(value, query[value]);
				}
			});
		}
		return this._httpClient.get(this._urlTransfers, {
			params
		});
	}

	executeTransfer(key: string, body: TransferExecuteRequest) {
		return this._httpClient
			.put(`${this._urlTransfers}/${key}/execute`, body)
			.pipe(
				mergeMap((data: Response) => {
					// manejo successful
					return of(data);
				}),
				catchError((errHttp: HttpErrorResponse) => {
					this.showErrorDialog(errHttp, 'Error', 'Ocurrio un error', './');
					return of({});
				})
			);
	}

	getDetailedTransfer(key: string) {
		return this._httpClient.get(`${this._urlTransfers}/${key}`);
	}

	getAccounts() {
		return this._httpClient.get(this._urlSummary).pipe(
			mergeMap((data: Response) => {
				// manejo successful
				return of(data);
			}),
			catchError((errHttp: HttpErrorResponse) => {
				this.showErrorDialog(errHttp, 'Error', 'Ocurrio un error', './');
				return of({});
			})
		);
	}

	showErrorDialog(
		errHttp: HttpErrorResponse,
		title: string,
		message: string,
		url: string
	) {
		this.dialogRef = this.dialog.open(
			{
				title: 'Operación inválida',
				enableHr: true,
				disabledButton: true,
				closeBackdropClick: false,
				buttons: [
					{
						class: 'strech',
						label: 'Aceptar',
						action: scope => {
							this.dialogRef.close();
						}
					}
				]
			},
			new CustomDialog(DialogErrorComponent, {
				titleInvalid: title,
				message: message,
				url: url
			})
		);
	}
}
