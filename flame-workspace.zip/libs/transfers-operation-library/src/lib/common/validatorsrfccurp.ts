import { ValidatorFn, AbstractControl } from '@angular/forms';

export function CURPRFCValidator(): ValidatorFn {
  return (control: AbstractControl): {[key: string]: any} | null => {
    const rfc = /^(([ÑA-Z|ña-z|&]{3}|[A-Z|a-z]{4})\d{2}((0[1-9]|1[012])(0[1-9]|1\d|2[0-8])|(0[13456789]|1[012])(29|30)|(0[13578]|1[02])31)(\w{2})([A|a|0-9]{1}))$|^(([ÑA-Z|ña-z|&]{3}|[A-Z|a-z]{4})([02468][048]|[13579][26])0229)(\w{2})([A|a|0-9]{1})$/;
    const curp = /^[A-Z][A,E,I,O,U,X][A-Z]{2}[0-9]{2}[0-1][0-9][0-3][0-9][M,H][A-Z]{2}[B,C,D,F,G,H,J,K,L,M,N,Ñ,P,Q,R,S,T,V,W,X,Y,Z]{3}[0-9,A-Z][0-9]$/;
    const optional = rfc.test(control.value) || curp.test(control.value) || control.value.length === 0;
    return optional ? null : {optionalInvalid : {valid: false, value: control.value}};
  };
}
