// NPM Deps
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { NgxMaskModule } from 'ngx-mask';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import {
	CommonModule,
	DatePipe,
	CurrencyPipe,
	TitleCasePipe
} from '@angular/common';
import {
	AvatarModule,
	AmountFieldModule,
	MotiveFieldModule,
	ButtonModule,
	IconModule,
	IconButtonModule,
	ThemeModule,
	FlameFoundationTheme,
	RadioButtonModule,
	ProductModule,
	DialogModule,
	TokenInputModule,
	SlideButtonModule,
	TokenDialogModule,
	FormFieldModule,
	InputModule,
	SearchBarModule,
	ContactListModule,
	TopBarModule,
	AccountSelectModule,
	ChipModule,
	EmojiModule,
  ContactDialogService,
  ContactDialogModule,
  SnCurrencyModule,
  ErrorsModule
} from '@santander/flame-component-library';

// Router
import { TransfersOperationLibraryRoutingModule } from './transfers-operation-library.router.module';

// Views
import { TransfersOperationLibraryViews } from './views/transfers-operation-library-views';

// Components
import { TransfersOperationLibraryComponents } from './components/transfers-operation-library-components';

// Services
import { TransferSameBankService } from './services/transfer-same-bank.service';
import { CepTranferService } from './services/cep.service';
import { TransfersOtherBanksService } from './services/transfer-other-banks.service';
import { SearchFilterPipe } from './pipes/search-filter.pipe';
import { AccountsFilterPipe } from './pipes/search-accounts.pipe';
import { AutoWidthInputModule } from 'libs/flame-component-library/src/lib/atoms/auto-width-input/auto-width-input.module';
import { DialogErrorComponent } from './components/dialog-dummy/dialog-dummy.component';

@NgModule({
	imports: [
		TransfersOperationLibraryRoutingModule,
		AvatarModule,
		AmountFieldModule,
		RadioButtonModule,
		ProductModule,
		ButtonModule,
		FormsModule,
    ReactiveFormsModule,
    SnCurrencyModule.forRoot({
			align: 'right',
			allowNegative: false,
			allowZero: true,
			decimal: '.',
			precision: 2,
			prefix: '',
			suffix: '',
			thousands: ',',
			nullable: true
    }),
    FormFieldModule,
    ErrorsModule,
		MotiveFieldModule,
		IconButtonModule,
		CommonModule,
		HttpClientModule,
		IconModule,
		DialogModule,
		TokenInputModule,
		SlideButtonModule,
		TokenDialogModule,
		SearchBarModule,
		TopBarModule,
		ThemeModule.forRoot({
			themes: [FlameFoundationTheme],
			active: 'flame-foundation'
		}),
		NgxMaskModule.forRoot(),
		InputModule,
		ContactListModule,
		AccountSelectModule,
		ChipModule,
    EmojiModule,
    ContactDialogModule,
    ErrorsModule,
    AutoWidthInputModule
	],
	declarations: [
		...TransfersOperationLibraryComponents,
		...TransfersOperationLibraryViews,
		SearchFilterPipe,
		AccountsFilterPipe
	],
  exports: [],
  entryComponents: [
    DialogErrorComponent
	],
	providers: [
		DatePipe,
		TitleCasePipe,
		CurrencyPipe,
		TransferSameBankService,
		TransfersOtherBanksService,
    CepTranferService,
    ContactDialogService
	]
})
export class TransfersOperationLibraryModule {}
