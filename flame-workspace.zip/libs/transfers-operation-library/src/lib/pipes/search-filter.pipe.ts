import { Pipe, PipeTransform } from '@angular/core';
import { PayeeSummary } from 'libs/beneficiary-operation-library/src/lib/models/payee-summary';

@Pipe({name: 'searchfilter'})
export class SearchFilterPipe implements PipeTransform {
  transform(value: Array<PayeeSummary>, filter: string): any {
    const nuevo = {
      name: [],
      alias: [],
      account: [],
      bank: [],
      clabe: [],
      phone: [],
      results : 0
    };
    if (filter.length > 0){
      const search_name: Array<PayeeSummary> = value.filter((item)=> item.name.toLowerCase().includes(filter.toLowerCase()));
      const search_alias: Array<PayeeSummary> = value.filter((item)=> item.alias.toLowerCase().includes(filter.toLowerCase()));
      const search_account: Array<PayeeSummary> = value.filter((item)=> item.account.number.toLowerCase().includes(filter.toLowerCase()));
      const search_bank: Array<PayeeSummary> = value.filter((item)=> item.account.bank.toLowerCase().includes(filter.toLowerCase()));
      const search_clabe: Array<PayeeSummary> = value.filter((item)=> {
        if (item.account.type === 'CLABE'){
          if(item.account.number.toLowerCase().includes(filter.toLowerCase())){
            return true;
          }
        }else{
          return false;
        }
      });
      const search_phone: Array<PayeeSummary> = value.filter((item)=> {
        if (item.account.type === 'SANTANDER_MOBILE_ACCOUNT' || item.account.type === 'THIRDPARTY_MOBILE_ACCOUNT'){
          if(item.account.number.toLowerCase().includes(filter.toLowerCase())){
            return true;
          }
        }else{
          return false;
        }
      });
      nuevo.results = search_account.length + search_alias.length +
                      search_bank.length + search_clabe.length +
                      search_name.length + search_phone.length;
      nuevo.account = search_account;
      nuevo.alias = search_alias;
      nuevo.bank = search_bank;
      nuevo.clabe = search_clabe;
      nuevo.name = search_name;
      nuevo.phone = search_phone;
      return nuevo;
    }else{
      return nuevo;
    }
  }
}
