import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'accountsfilter'})
export class AccountsFilterPipe implements PipeTransform {
  transform(value: any, filter: string): any {
    const nuevo = {
      results: 0,
      values: []
    }
    if (filter.length > 0){
      const search_cards = value.filter(item => item.description.toLowerCase().includes(filter.toLowerCase()));
      nuevo.results = search_cards.length;
      nuevo.values = search_cards;
      return nuevo;
    }else{
      return nuevo;
    }
  }
}
