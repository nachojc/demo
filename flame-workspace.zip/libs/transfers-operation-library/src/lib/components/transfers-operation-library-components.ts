import { InputMotiveComponent } from './input-motive/input-motive.component';
import { ChipTransferComponent } from './option-chip-transfer/chip-transfer.component';
import { ContactsWidgetComponent } from './contacts-widget/contacts-widget.component';

export const TransfersOperationLibraryComponents = [
  InputMotiveComponent,
  ChipTransferComponent,
  ContactsWidgetComponent
];
