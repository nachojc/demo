import { ContactsWidgetComponent } from './contacts-widget/contacts-widget.component';
import { DialogErrorComponent } from './dialog-dummy/dialog-dummy.component';
import { TokenConfirmComponent } from './token-confirm/token-confirm.component';

export const TransfersOperationLibraryComponents = [
	ContactsWidgetComponent,
	DialogErrorComponent,
	TokenConfirmComponent
];

export const TransfersOperationLibraryEntryComponents = [
	DialogErrorComponent,
	TokenConfirmComponent
];
