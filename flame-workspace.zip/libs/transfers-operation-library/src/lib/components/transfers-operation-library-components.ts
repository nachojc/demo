import { ContactsWidgetComponent } from './contacts-widget/contacts-widget.component';
import { DialogErrorComponent } from './dialog-dummy/dialog-dummy.component';

export const TransfersOperationLibraryComponents = [
  ContactsWidgetComponent,
  DialogErrorComponent
];
