import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TokenConfirmComponent } from './token-confirm.component';
import { NgxMaskModule } from 'ngx-mask';

describe('TokenConfirmComponent', () => {
	let component: TokenConfirmComponent;
	let fixture: ComponentFixture<TokenConfirmComponent>;

	const fakeData = {
		type: 2,
		amount: 123,
		toAccount: {
			name: 'Cuenta fake',
			bank: 'Santander',
			account: '1234567890123456'
		},
		fromAccount: {
			name: 'Jacinto Bothi',
			account: '1234567891234567'
		}
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				NgxMaskModule.forRoot(),
			],
			declarations: [TokenConfirmComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TokenConfirmComponent);
		component = fixture.componentInstance;
		component.data = { ...fakeData };
		fixture.detectChanges();
	});

	it('should create a component err', () => {
		expect(component).toBeTruthy();
	});

	it('should format account', ()=>{
		component.formatAccount();//16 length
		expect(component.formatCase).toEqual('0000 0000 0000 0000');
		component.dataOtherBanks.toAccount.account = '123456789012345678'; //18 length
		component.formatAccount();
		expect(component.formatCase).toEqual('0000 0000 0000 0000 0000');
		component.dataOtherBanks.toAccount.account = '1234567890'; //10 length
		component.formatAccount();
		expect(component.formatCase).toEqual('00 0000 0000');



	});
});
