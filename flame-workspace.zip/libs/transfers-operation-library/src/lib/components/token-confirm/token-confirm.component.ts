import { Component, OnInit } from '@angular/core';
import { DataTransferService } from '@santander/flame-core-library';

@Component({
	selector: 'sm-token-confirm',
	templateUrl: './token-confirm.component.html',
	styleUrls: ['./token-confirm.component.scss']
})
export class TokenConfirmComponent implements OnInit {
	constructor(private _dataBehaviorTransferService: DataTransferService) {}

	/**
	 * variable
	 *
	 * @memberof TokenConfirmComponent
	 */
	public dataOtherBanks = {
		amount: 0,
		toAccount: {
			name: '',
			bank: '',
			account: ''
		},
		fromAccount: {
			name: '',
			account: ''
		}
	};

	/**
	 * se recuprerar los datos del servicio behavior
	 *
	 * @memberof TokenConfirmComponent
	 */
	ngOnInit() {
		this._dataBehaviorTransferService
			.getData()
			.then(response => (this.dataOtherBanks = response));
	}
}
