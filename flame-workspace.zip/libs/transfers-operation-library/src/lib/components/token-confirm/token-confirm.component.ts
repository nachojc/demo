import { Component, OnInit } from '@angular/core';
import { DataTransferService } from '@santander/flame-core-library';
import { CustomDialogComponent } from '@santander/flame-component-library';

@Component({
	selector: 'sm-token-confirm',
	templateUrl: './token-confirm.component.html',
	styleUrls: ['./token-confirm.component.scss']
})
export class TokenConfirmComponent implements OnInit, CustomDialogComponent {
	constructor() {}

	public data: any;
	public formatCase: string;

	/**
	 * variable
	 *
	 * @memberof TokenConfirmComponent
	 */
	public dataOtherBanks = {
		type: 2,
		amount: 0,
		toAccount: {
			name: '',
			bank: '',
			account: ''
		},
		fromAccount: {
			name: '',
			account: ''
		}
	};

	formatAccount() {
		switch (true) {
			case this.dataOtherBanks.toAccount.account.length === 16:
				this.formatCase = '0000 0000 0000 0000';
				break;
			case this.dataOtherBanks.toAccount.account.length === 18:
				this.formatCase = '0000 0000 0000 0000 0000';
				break;
			case this.dataOtherBanks.toAccount.account.length === 10:
				this.formatCase = '00 0000 0000';
				break;
		}
	}
	/**
	 * se recuprerar los datos del servicio behavior
	 *
	 * @memberof TokenConfirmComponent
	 */
	ngOnInit() {
		this.dataOtherBanks = { ...this.data };
		this.formatAccount();
	}
}
