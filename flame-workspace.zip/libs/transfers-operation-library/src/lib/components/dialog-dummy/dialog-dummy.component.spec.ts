import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DialogErrorComponent } from './dialog-dummy.component';
import {
	ButtonModule,
	ThemeModule,
	FlameFoundationTheme
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import {
	CUSTOM_ELEMENTS_SCHEMA,
	NO_ERRORS_SCHEMA,
	EventEmitter
} from '@angular/core';

describe('DialogErrorComponent', () => {
	let component: DialogErrorComponent;
	let fixture: ComponentFixture<DialogErrorComponent>;

	const dataFake = {
		url: '',
		title: 'Error',
		message: 'Ocurrio un error',
		textButton: 'Aceptar'
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				ButtonModule,
				CommonModule,
				RouterTestingModule.withRoutes([]),
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				})
			],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			declarations: [DialogErrorComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogErrorComponent);
		component = fixture.componentInstance;
		component.data = dataFake;
		fixture.detectChanges();
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('should emit the event close the modal', () => {
		spyOn(component, 'close');
		component.data.closeEvtButton = new EventEmitter();
		component.data.closeEvtButton.emit(true);
		fixture.detectChanges();
	});
});
