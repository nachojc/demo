import { Component } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';

@Component({
	selector: 'sm-dialog-dummy',
	templateUrl: './dialog-dummy.component.html',
	styleUrls: []
})
export class DialogErrorComponent implements CustomDialogComponent {
	data: any;

	close() {
		this.data.closeEvtButton.emit(true);
	}
}
