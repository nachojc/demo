import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
	selector: 'sm-chips-transfer',
	templateUrl: './chip-transfer.component.html',
	styleUrls: ['./chip-transfer.component.scss']
})
export class ChipTransferComponent implements OnInit {
	/**
	 *emite la opción de el dia que se elige 1 0 2
	 *
	 * @memberof ChipTransferComponent
	 */
	@Output() emitDay = new EventEmitter<number>();

	/**
	 * solo las variables para pintar el estilo seleccionado (active)
	 *
	 * @memberof ChipTransferComponent
	 */
	isToday = false;
	isTomorrow: boolean;

	constructor() {}

	ngOnInit() {}

	checkDay(day: number) {
		switch (day) {
			case 1:
				this.isToday = true;
				this.isTomorrow = false;
				this.emitDay.emit(day);
				break;
			case 2:
				this.isToday = false;
				this.isTomorrow = true;
				this.emitDay.emit(day);
				break;
		}
	}
}
