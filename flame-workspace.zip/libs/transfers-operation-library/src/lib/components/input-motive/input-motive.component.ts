import { Component, OnInit, Input } from '@angular/core';

@Component({
	selector: 'sm-input-motive',
	templateUrl: './input-motive.component.html',
	styleUrls: ['./input-motive.component.scss']
})
export class InputMotiveComponent implements OnInit {
	// Inputs
	@Input() disable = false;
	@Input() placeHolder: string;
	@Input() fieldText: string;
	@Input() typeField: string; // is for the type number/alphanumeric
	@Input() maxLength: number;

	// Control
	public cleanButtonActive = false;
	public valueInput: string;

	constructor() {}

	ngOnInit() {}

	evaluate(evt: any) {
		if (evt.target.value.length <= this.maxLength) {
			return this.checkTypeField().test(evt.key);
		} else {
			return false;
		}
	}

	checkTypeField() {
		const regexNumber = new RegExp(/^[0-9]+$/);
		const regexAlphanumeric = new RegExp(/^[a-zA-Z0-9\s]*$/);
		return this.typeField === 'number' ? regexNumber : regexAlphanumeric;
  }

  ckeckButtonCancel() {
    if (this.valueInput.length !== 0) {
      this.cleanButtonActive = true;
    } else {
      this.cleanButtonActive = false;
    }
  }

	clear() {
		this.valueInput = null;
		this.cleanButtonActive = false;
	}
}
