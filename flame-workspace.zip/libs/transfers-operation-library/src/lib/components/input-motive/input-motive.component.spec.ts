// import { FormsModule } from '@angular/forms';
// import { IconModule } from './../../atoms/icon/icon.module';
// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { InputMotiveComponent } from './input-motive.component';

// describe('InputMotiveComponent', () => {
// 	let component: InputMotiveComponent;
// 	let fixture: ComponentFixture<InputMotiveComponent>;

// 	beforeEach(async(() => {
// 		TestBed.configureTestingModule({
//       declarations: [InputMotiveComponent],
//       imports: [IconModule, FormsModule]
// 		}).compileComponents();
// 	}));

// 	beforeEach(() => {
// 		fixture = TestBed.createComponent(InputMotiveComponent);
// 		component = fixture.componentInstance;
// 		fixture.detectChanges();
// 	});

// 	it('should create', () => {
// 		expect(component).toBeTruthy();
// 	});
// });
