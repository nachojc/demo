import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TransferSameBankService } from '../../services/transfer-same-bank.service';

@Component({
  selector: 'sm-contacts-widget',
  templateUrl: './contacts-widget.component.html',
  styleUrls: ['./contacts-widget.component.scss']
})
export class ContactsWidgetComponent implements OnInit {

  // Output
  @Output() selectedOption = new EventEmitter<any>();

  // Control
  public showSearchbar = false;
  public showSearchOverlayContainer = false;

  // Variables
  public payeesList = [];
  public filterValue = '';
  public accounts = [];

  public cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
  ];

  constructor(private payeeService: TransferSameBankService) {
    this.payeeService.getAllPayees()
    .subscribe(res =>{
      this.payeesList = res.data;
    });
    this.payeeService.getAccounts()
    .subscribe((res:any) =>{
      this.accounts = this.accounts.concat(res.data[0].products);
      this.accounts = this.accounts.concat(res.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
    })
  }

  ngOnInit() {
  }

  onFocusSearchBar(){
    if (!this.showSearchOverlayContainer){
      this.showSearchOverlayContainer = !this.showSearchOverlayContainer;
    }
  }

  onBlurSearchBar(){
    this.showSearchOverlayContainer = !this.showSearchOverlayContainer;
  }

  filterSearching(data: any){
    this.filterValue = data;
  }

  selectedEvent(data:any, type: string){
    if (type === 'Payee'){
      this.selectedOption.emit({type, value: data});
    }else if(type === 'Account'){
      this.selectedOption.emit({type, value: data});
    }
  }

}
