import { Component, Output, EventEmitter, Input } from '@angular/core';
import { TransferSameBankService } from '../../services/transfer-same-bank.service';
import { headerAnimation, listAnimation, buttonFadeAnimation } from '../../animations/contacts-widget/contacts.animations';

@Component({
	selector: 'sm-contacts-widget',
	templateUrl: './contacts-widget.component.html',
  styleUrls: ['./contacts-widget.component.scss'],
  animations: [headerAnimation, listAnimation, buttonFadeAnimation]
})
export class ContactsWidgetComponent {

  constructor(public payeeService: TransferSameBankService) {
    this.initializeData();
  }
  private _openedview = false;

	public showSearchbar = false;
	public showSearchOverlayContainer = false;
	public payeesList = [];
	public filterValue = '';
	public accounts = [];
	public cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];
  @Output() selectedOption = new EventEmitter<any>();
  @Output() showSearchView = new EventEmitter<boolean>();
  @Input()
  set opened(value: boolean){
    if (value){
      // this.showSearchOverlayContainer = value;
      this.showSearchbar = value;
    }
    this._openedview = value;
  }
  get opened(){
    return this._openedview;
  }

  public input_values = {
    amount: 0,
    motive: ''
  }

  initializeData(){
    this.payeeService.getAllPayees()
    .subscribe((response:any) =>{
      this.payeesList = response.data;
    });
    this.payeeService.getAccounts()
    .subscribe((res:any) =>{
      this.accounts = this.accounts.concat(res.data[0].products);
      this.accounts = this.accounts.concat(res.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
    })
  }

	onBlurSearchBar() {
    this.showSearchOverlayContainer = false;
    this.showSearchView.emit(false);
    this.showSearchbar = false;
	}

	filterSearching(data: any) {
    this.filterValue = data;
    this.showSearchOverlayContainer = true;
  }

  stateSearchBar(value: boolean){
    this.showSearchView.emit(value);
    this.showSearchbar = value;
  }

	selectedEvent(data: any, type: string) {
		if (type === 'Payee') {
			this.selectedOption.emit({ type, value: data });
		} else if (type === 'Account') {
			this.selectedOption.emit({ type, value: data });
		}
	}
}
