import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { ContactsWidgetComponent } from './contacts-widget.component';
import { SearchBarModule, AmountFieldModule, MotiveFieldModule, AvatarModule, ProductModule, IconButtonModule, IconModule } from '@santander/flame-component-library';
import { AccountsFilterPipe } from '../../pipes/search-accounts.pipe';
import { SearchFilterPipe } from '../../pipes/search-filter.pipe';
import { FormsModule } from '@angular/forms'; import { ReactiveFormsModule } from '@angular/forms';
import { TransferSameBankService } from '../../services/transfer-same-bank.service';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { HttpClientModule } from '@angular/common/http';
import { ListPayeesResponse } from '../../models';
import { By } from '@angular/platform-browser';
import { of } from 'rxjs';

export const environment = {
	production: false,
	development: true,
	idp: {
		url: 'http://localhost:3000/IDPWeb/idp/',
		urlRSA: 'http://localhost:3000/IDPWeb/idp/',
		urlSign: 'http://localhost:3000/IDPWeb/idp/',
		urlRSASign: 'http://localhost:3000/IDPWeb/idp/'
	},
	oauth: {
		url:
			'https://front-grants-bussupport-comsrvc-security-pf-dev.appls.cto1.paas.gsnetcloud.corp/oauth2/v1/token'
	},
	baas: {
		urlAccountSummary: 'http://localhost:3000/accountSummary',
		urlSummary: 'http://localhost:3000/summaryBaas',
		urlTransactions: 'http://localhost:3000/accounts/',
		urlCredits: 'http://localhost:3000/credits',
		urlCards: 'http://localhost:3000/cards/',
		urlTransfers: 'http://localhost:3000/transfers/',
		urlPayments: 'http://localhost:3000/payments/',
		urlBeneficiary: 'http://localhost:3000/transfers/payees/'
	}
};

declare var ListPayeesResponsePrototype: {
  prototype: ListPayeesResponse;
  new(): ListPayeesResponse;
};

describe('ContactsWidgetComponent', () => {
  let component: ContactsWidgetComponent;
  let fixture: ComponentFixture<ContactsWidgetComponent>;
  // tslint:disable-next-line:prefer-const
  let servicio: any;
  let rootElement: any;
  let accountsPipeFilter: any;
  let payeesPipeFilter: any;

  const mockPayeesList = {
    "data": [
      {
        "key": "0m29qh0l7xy6oattzh65kq2jgn19fbx6",
        "account": {
          "number": "5179921863843075",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "SCOTIABANK"
        },
        "name": "Jack Jacobs",
        "alias": "The Fourth",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "otmn77lqcc111oblddj1rekjfk52vqe3",
        "account": {
          "number": "363042688497206369",
          "type": "CLABE",
          "bank": "SCOTIABANK"
        },
        "name": "Rosie Franklin",
        "alias": "Juris Doctor",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq",
        "account": {
          "number": "926321303849798078",
          "type": "CLABE",
          "bank": "SCOTIABANK"
        },
        "name": "Owen Saunders",
        "alias": "The Third",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "5sdkcqgbiy0o8gilvd0ww17y4kpvq9mt",
        "account": {
          "number": "99771443157",
          "type": "SANTANDER_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Joseph Webb",
        "alias": "Doctor of Osteopathic Medicine",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "jniooip0w06ufj2n3h43afrlnstfizv3",
        "account": {
          "number": "5101796332543032",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "SCOTIABANK"
        },
        "name": "Ada Romero",
        "alias": "Bachelor of Engineering",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "dwtoh70ok0s393c3sip8qvc0l7nyticy",
        "account": {
          "number": "5138821295814142",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "BANAMEX"
        },
        "name": "Minerva Ryan",
        "alias": "Bachelor of Technology",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "dams9kplafqwxrgel4c7sq5bdwrzac39",
        "account": {
          "number": "(712) 283-6426",
          "type": "SANTANDER_MOBILE_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Emma Hampton",
        "alias": "Doctor of Osteopathic Medicine",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "ia1rpal73nack998zvn7bnfxyzjwzf66",
        "account": {
          "number": "5169121412084758",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "CIBANCO"
        },
        "name": "Lora Curtis",
        "alias": "Bachelor of Technology",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "iwgohq5r0ubl3qgwfr7p9hwfdnggtfg0",
        "account": {
          "number": "60220276131",
          "type": "SANTANDER_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Manuel Mason",
        "alias": "Bachelor of Engineering",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "5ya77rlszyprcpc9jx64xoj5i0hruwrj",
        "account": {
          "number": "(557) 666-4869",
          "type": "SANTANDER_MOBILE_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Loretta Quinn",
        "alias": "The Fourth",
        "url": "/beneficiaries/{beneficiary-key}"
      }
    ],
    "notifications": [
      {
        "code": "E422CDNPAYRCPTG001",
        "description": "Something is happening",
        "timestamp": "2019-02-16T23:38:45.408Z"
      }
    ],
    "paging": {
      "next_cursor_key": "10"
    }
  }

  const mockAccountList = {
    "data": [
      {
        "category_name": "CHECKING_ACCOUNTS",
        "total_balance": {
          "currency_code": "MXN",
          "amount": 69827.78
        },
        "products": [
          {
            "key": "056722751246",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "56*5124",
            "related_phone": {
              "phone_number": "5510555143",
              "company": "TELCEL"
            },
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "MXN",
              "amount": 69827.78
            }
          },
          {
            "key": "056722733565",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "56*3356",
            "related_phone": null,
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "USD",
              "amount": 0
            }
          }
        ]
      },
      {
        "category_name": "CREDIT_CARDS",
        "total_balance": {
          "currency_code": "MXN",
          "amount": 85399.66
        },
        "products": [
          {
            "key": "4e20fbb243684d9eb19ff33a50ee422e",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "*3699",
            "related_phone": null,
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "MXN",
              "amount": 1812.1
            }
          },
          {
            "key": "1b10lop243683d9eb19ff33a50ee345a",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "*9981",
            "related_phone": null,
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "MXN",
              "amount": -22038.1
            }
          }
        ]
      }
    ],
    "notifications": null,
    "paging": null
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactsWidgetComponent, SearchFilterPipe, AccountsFilterPipe ],
      imports: [SearchBarModule, AmountFieldModule,
        MotiveFieldModule, AvatarModule,
        ProductModule, IconButtonModule,
        HttpClientModule,
        IconModule, FormsModule],
      providers: [TransferSameBankService,
        {
          provide: ENV_CONFIG,
          useValue: environment
        }]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactsWidgetComponent);
    component = fixture.componentInstance;
    servicio = component.payeeService;
    rootElement = fixture.debugElement;
    accountsPipeFilter = new AccountsFilterPipe();
    payeesPipeFilter = new SearchFilterPipe();
    fixture.detectChanges();
  });

  it('Debe crearse el componente', () => {
    expect(component).toBeTruthy();
  });

  it('componente con contactos', () =>{
    component.payeesList = mockPayeesList.data;
    expect(component.payeesList.length).toBeGreaterThan(1);
    fixture.detectChanges();
    const container = fixture.debugElement.query(By.css('.main-container')).nativeElement;
    expect(container.classList).toContain('main-container');
  });

  it('componente sin contactos', () =>{
    component.payeesList = [];
    expect(component.payeesList.length).toEqual(0);
    fixture.detectChanges();
    const container = fixture.debugElement.query(By.css('.no-payees')).nativeElement;
    expect(container.classList).toContain('no-payees');
  });

  it('Inyectar servicio TransferSameBankService', ()=>{
    expect(servicio).toBeTruthy();
  })

  it('Asignar payeesList en base a la llamada getAllPayees del servicio TransferSameBankService', ()=>{
    spyOn(servicio, 'getAllPayees').and.returnValue(of(mockPayeesList));
    component.initializeData();
    expect(component.payeesList).toEqual(mockPayeesList.data);
  })

  it('Asignar accounts en base a la llamada getAccounts del servicio TransferSameBankService', ()=>{
    spyOn(servicio, 'getAccounts').and.returnValue(of(mockAccountList));
    component.initializeData();
    expect(component.accounts.length).toBeGreaterThan(1);
  })

  it('Habilitar buscador',() =>{
    spyOn(servicio, 'getAllPayees').and.returnValue(of(mockPayeesList));
    spyOn(servicio, 'getAccounts').and.returnValue(of(mockAccountList));
    component.initializeData();
    spyOn(component, 'stateSearchBar');
    const button_search = rootElement.query(By.css('sn-icon-button[icon="sn-FUNC71"]')).nativeElement;
    expect(button_search).toBeTruthy();
    button_search.click();
    expect(component.stateSearchBar).toHaveBeenCalled();
  })

  it('Mostrar buscador', () =>{
    component.stateSearchBar(!component.showSearchbar);
    fixture.detectChanges();
    const container_searching = rootElement.query(By.css('.search-bar')).nativeElement;
    expect(container_searching).toBeTruthy();
    expect(container_searching.classList).toContain('search-bar');
  })

  it('Realizar busqueda de contacto', ()=>{
    component.stateSearchBar(!component.showSearchbar);
    fixture.detectChanges();
    const container_searching = rootElement.query(By.css('.search-bar')).nativeElement;
    expect(container_searching).toBeTruthy();
    component.filterSearching('santander');
    fixture.detectChanges();
    expect(component.filterValue).toBe('santander');
    expect(component.showSearchOverlayContainer).toBe(true);
  })

  it('Testeando resultados con filtro cuenta', () =>{
    spyOn(servicio, 'getAllPayees').and.returnValue(of(mockPayeesList));
    spyOn(servicio, 'getAccounts').and.returnValue(of(mockAccountList));
    component.initializeData();
    fixture.detectChanges();
    const query = 'NOM';
    const resultados = accountsPipeFilter.transform(component.accounts, query);
    expect(resultados.results).toBeGreaterThanOrEqual(1);
    resultados.values.forEach(elemento => {
      expect(elemento.description.toLowerCase()).toContain(query.toLowerCase());
    });
  });

  it('Testeando resultados con filtro beneficiarios', () =>{
    spyOn(servicio, 'getAllPayees').and.returnValue(of(mockPayeesList));
    spyOn(servicio, 'getAccounts').and.returnValue(of(mockAccountList));
    component.initializeData();
    fixture.detectChanges();
    const query = '(712)';
    const resultados = payeesPipeFilter.transform(component.payeesList, query);
    expect(resultados.results).toBeGreaterThanOrEqual(0);
    resultados.account.forEach(elemento => {
      expect(elemento.account.number.toLowerCase()).toContain(query.toLowerCase());
    });
    resultados.alias.forEach(elemento => {
      expect(elemento.alias.toLowerCase()).toContain(query.toLowerCase());
    });
    resultados.bank.forEach(elemento => {
      expect(elemento.account.bank.toLowerCase()).toContain(query.toLowerCase());
    });
    resultados.clabe.forEach(elemento => {
      expect(elemento.account.number.toLowerCase()).toContain(query.toLowerCase());
    });
    resultados.name.forEach(elemento => {
      expect(elemento.name.toLowerCase()).toContain(query.toLowerCase());
    });
    resultados.phone.forEach(elemento => {
      expect(elemento.account.number.toLowerCase()).toContain(query.toLowerCase());
    });
  });

  it('Output Seleccion de contacto', ()=>{
    spyOn(servicio, 'getAllPayees').and.returnValue(of(mockPayeesList));
    component.initializeData();
    fixture.detectChanges();
    let resultado: any;
    component.selectedOption.subscribe((value)=> resultado = value);
    component.selectedEvent(component.payeesList[0], 'Payee');
    expect(resultado.type).toBe('Payee');
    expect(resultado.value).toBe(component.payeesList[0]);
  })

  it('Output Seleccion de cuenta propia', ()=>{
    let resultado: any;
    spyOn(servicio, 'getAccounts').and.returnValue(of(mockAccountList));
    component.initializeData();
    fixture.detectChanges();
    component.selectedOption.subscribe((value)=> resultado = value);
    component.selectedEvent(component.accounts[0], 'Account');
    expect(resultado.type).toBe('Account');
    expect(resultado.value).toBe(component.accounts[0]);
  })

  it('Boton cancelar busqueda', ()=>{
    let resultado: any;
    spyOn(servicio, 'getAccounts').and.returnValue(of(mockAccountList));
    spyOn(servicio, 'getAllPayees').and.returnValue(of(mockPayeesList));
    component.initializeData();
    fixture.detectChanges();
    component.stateSearchBar(!component.showSearchbar);
    fixture.detectChanges();
    component.showSearchView.subscribe((value)=> resultado = value);
    component.onBlurSearchBar();
    fixture.detectChanges();
    expect(component.showSearchOverlayContainer).toBe(false);
    expect(resultado).toBe(false);
    expect(component.showSearchbar).toBe(false);
  })
});
