import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactsWidgetComponent } from './contacts-widget.component';

describe('ContactsWidgetComponent', () => {
  let component: ContactsWidgetComponent;
  let fixture: ComponentFixture<ContactsWidgetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContactsWidgetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactsWidgetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
