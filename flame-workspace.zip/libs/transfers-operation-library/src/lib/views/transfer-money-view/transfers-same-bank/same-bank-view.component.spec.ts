/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferMoneyViewComponent } from './transfer-money-view.component';

describe('TransferMoneyViewComponent', () => {
  let component: TransferMoneyViewComponent;
  let fixture: ComponentFixture<TransferMoneyViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferMoneyViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferMoneyViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
 */
