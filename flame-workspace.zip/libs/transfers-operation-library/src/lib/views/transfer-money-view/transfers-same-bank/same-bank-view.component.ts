import { Component, OnInit, ElementRef, ViewChild, Input } from '@angular/core';
import { Router } from '@angular/router';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';

@Component({
	selector: 'sm-transfer-same-bank',
	templateUrl: './same-bank-view.component.html',
	styleUrls: ['./same-bank-view.component.scss']
})
export class TransferSameBankViewComponent implements OnInit {
  // Elementos DOM

  // Input
  @Input() dataPayee: any;

  // Control
  public disableInputs = false;
  public hideDialogToken = false;
  public confirmedToken = false;

	// Variables


	// Transfer Information
	// Objeto de transferencia inicial

	// Lista de transferencias


	// Fake Info

  public cardImages = [
    './assets/icons/card-amex.svg',
    './assets/icons/card-aero.svg',
    './assets/icons/card-basic.svg',
    './assets/icons/card-pref.svg'
  ];

  public accounts: Array<any> = [];

  public account = <any>{
    product: {},
    related_phone: {},
    balance: {}
  };

	constructor(
		private router: Router,
		private transferService: TransferSameBankService
	) {
    this.transferService.getAccounts()
    .subscribe((res:any) =>{
      this.accounts = this.accounts.concat(res.data[0].products);
      this.accounts = this.accounts.concat(res.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
      this.account = this.accounts[0];
    })
	}

	confirmTokenEvent(data: any) {
		this.hideDialogToken = true;
		this.confirmedToken = true;
  }

  dialogTokenEvent(data: string) {
		if (data === 'closed' && this.confirmedToken) {
			this.router.navigate(['/transfers/voucher'], {
				queryParams: {
					voucherType: Math.floor(Math.random() * 2) + 1
				}
			});
		}
  }

	ngOnInit() {
	}
}
