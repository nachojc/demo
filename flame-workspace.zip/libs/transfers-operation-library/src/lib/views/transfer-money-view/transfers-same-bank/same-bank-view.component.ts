import { Component, OnInit, ElementRef, ViewChild, Input, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TransferInitResponse } from '../../../models';

@Component({
	selector: 'sm-transfer-same-bank',
	templateUrl: './same-bank-view.component.html',
	styleUrls: ['./same-bank-view.component.scss']
})
export class TransferSameBankViewComponent implements OnInit {

  constructor(
    private router: Router,
    private transferService: TransferSameBankService,
    private formBuilder: FormBuilder
  ) {
    this.initializer();
  }

  public disableInputs = false;
  public hideDialogToken = false;
  public confirmedToken = false;
  public typeIndentifier = 'CURP';
  public transactionForm: FormGroup;

  public cardImages = [
    './assets/icons/card-amex.svg',
    './assets/icons/card-aero.svg',
    './assets/icons/card-basic.svg',
    './assets/icons/card-pref.svg'
  ];

  public accounts: Array<any> = [];

  public account = <any>{
    product: {},
    related_phone: {},
    balance: {}
  };

  public transferConfigInit: any;

  @Input() dataPayee: any;
  @Input()
  set fromAccount(value: any){
    this.account = value;
  }
  get fromAccount(){
    return this.account;
  }
  @Output() showContactView = new EventEmitter<boolean>();

  initializer(){
    this.transferService.getAccounts()
    .subscribe((response:any) =>{
      this.accounts = this.accounts.concat(response.data[0].products);
      this.accounts = this.accounts.concat(response.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
    });
    this.transactionForm = this.formBuilder.group({
      amount: [0.0, Validators.required,],
      motive: ['', Validators.required],
      reference: ['', [Validators.required, ]],
      optional: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

	confirmTokenEvent(data: any) {
		this.hideDialogToken = true;
		this.confirmedToken = true;
  }

  dialogTokenEvent(data: string) {
		if (data === 'closed' && this.confirmedToken) {
			this.router.navigate(['/transfers/voucher'], {
				queryParams: {
					voucherType: Math.floor(Math.random() * 2) + 1
				}
			});
		}
  }

  stateContactView(){
    this.showContactView.emit(true);
  }

  onSubmit() {
    console.log("enviar")
  }

	ngOnInit() {
    this.transferService.initializeTransfer({default_account_key: this.dataPayee.key})
    .subscribe((response: TransferInitResponse) =>{
      this.transferConfigInit = response.data;
    })
  }
}
