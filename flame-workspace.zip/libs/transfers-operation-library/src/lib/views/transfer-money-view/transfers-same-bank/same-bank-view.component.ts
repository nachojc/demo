import { Component, OnInit, ElementRef, ViewChild, Input, EventEmitter, Output, DoCheck } from '@angular/core';
import { Router } from '@angular/router';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { TransferInitResponse } from '../../../models';
import { CURPRFCValidator } from '../../../common/validatorsrfccurp';
import { CustomDialog } from '@santander/flame-component-library';
import { TokenConfirmComponent } from '../../../components/token-confirm/token-confirm.component';

@Component({
	selector: 'sm-transfer-same-bank',
	templateUrl: './same-bank-view.component.html',
	styleUrls: ['./same-bank-view.component.scss']
})
export class TransferSameBankViewComponent implements OnInit, DoCheck {

  constructor(
    private router: Router,
    public transferService: TransferSameBankService,
    private formBuilder: FormBuilder
  ) {
    this.initializer();
  }

  public disableInputs = false;
  public hideDialogToken = false;
  public confirmedToken = false;
  public typeIndentifier = 'CURP';
  public statusSlide = '';
  public transactionForm: FormGroup;
  public cardImages = [
    './assets/icons/card-amex.svg',
    './assets/icons/card-aero.svg',
    './assets/icons/card-basic.svg',
    './assets/icons/card-pref.svg'
  ];
  public dialogBody = {
    amount: 0,
    type: 3,
		toAccount: {
      name: '',
      bank: 'Santander',
			account: ''
		},
		fromAccount: {
      name: '',
			account: ''
		}
  };
  public customBody = new CustomDialog(TokenConfirmComponent, this.dialogBody);

  public accounts: Array<any> = [];

  public account = <any>{
    product: {},
    related_phone: {},
    balance: {}
  };
  public oldAccount: any;

  public transferConfigInit: any;

  @Input() dataPayee: any;
  @Input()
  get fromAccount(){
    return this.account;
  }
  set fromAccount(value: any){
    this.account = value;
  }
  @Output() showContactView = new EventEmitter<boolean>();

  initializer(){
    this.transferService.getAccounts()
    .subscribe((response:any) =>{
      this.accounts = this.accounts.concat(response.data[0].products);
      this.accounts = this.accounts.concat(response.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
    });
    this.transactionForm = this.formBuilder.group({
      amount: [0.0, [Validators.required,Validators.min(10)]],
      motive: ['Transferencias', [Validators.required, Validators.minLength(3), Validators.pattern(/^[a-zA-Z0-9\s]*$/)]],
      reference: ['', [Validators.nullValidator, Validators.pattern(/^[0-9]{1,7}$/)]],
      optional: ['', [Validators.nullValidator, CURPRFCValidator()]],
    });
    this.transactionForm.valueChanges.subscribe((values: any)=>{
      this.dialogBody.amount = values.amount;
    });
  }

	confirmTokenEvent(data: any) {
		this.hideDialogToken = true;
		this.confirmedToken = true;
  }

  dialogTokenEvent(data: string) {
		if (data === 'closed' && this.confirmedToken) {
			this.router.navigate(['/transfers/voucher'], {
				queryParams: {
					voucherType: 3
				}
			});
		}
  }

  stateContactView(){
    this.showContactView.emit(true);
  }

	ngOnInit() {
    this.transferService.initializeTransfer({default_account_key: this.dataPayee.key})
    .subscribe((response: TransferInitResponse) =>{
      this.transferConfigInit = response.data;
    })
    this.dialogBody.toAccount = {
      name: this.dataPayee.name,
      account: this.dataPayee.account.number,
      bank: 'Santander'
    }
    const maxamount = this.account.balance.amount;
    this.dialogBody.fromAccount = {
      name: this.account.description,
      account: this.account.number,
    }
    this.transactionForm.get('amount').setValidators([Validators.required, Validators.min(1), Validators.max(maxamount)]);
    this.transactionForm.updateValueAndValidity();
  }

  ngDoCheck(){
    if (this.oldAccount !== this.account){
      this.dialogBody.toAccount = {
        name: this.account.description,
        account: this.account.number,
        bank: 'Santander'
      }
      this.oldAccount = this.account;
      this.transactionForm.get('amount').setValue(0);
      this.transactionForm.get('amount').setValidators([Validators.required, Validators.min(10), Validators.max(this.account.balance.amount)]);
      this.transactionForm.updateValueAndValidity();
    }
  }
}
