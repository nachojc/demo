import { Component } from '@angular/core';

@Component({
	selector: 'sm-transfer-empty-state',
	templateUrl: './empty-state-view.component.html',
	styleUrls: ['./empty-state-view.component.scss']
})
export class TransferEmptyStateViewComponent {
	constructor(){}
}
