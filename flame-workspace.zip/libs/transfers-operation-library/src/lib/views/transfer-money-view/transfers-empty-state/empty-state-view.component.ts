import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { PERSONAS } from '../fake-info';

@Component({
	selector: 'sm-transfer-empty-state',
	templateUrl: './empty-state-view.component.html',
	styleUrls: ['./empty-state-view.component.scss']
})
export class TransferEmptyStateViewComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
