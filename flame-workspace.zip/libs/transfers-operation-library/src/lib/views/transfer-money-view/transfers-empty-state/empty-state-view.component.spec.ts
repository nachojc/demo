import {
	async,
	ComponentFixture,
	TestBed,
	fakeAsync
} from '@angular/core/testing';
import { TransferEmptyStateViewComponent } from './empty-state-view.component';
import {
	ButtonModule,
	IconModule,
	AvatarModule,
	DialogSelectModule,
	EmojiModule,
	FormFieldModule,
	IconButtonModule,
	InputModule,
	ChipModule,
	ProductModule,
	ThemeModule,
	FlameFoundationTheme,
	TokenDialogModule,
	TopBarModule,
	HiddenButtonsModule,
	SearchBarModule
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule, Location } from '@angular/common';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { BeneficiaryViewComponent } from 'libs/beneficiary-operation-library/src/lib/views/beneficiary-view/beneficiary-view.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

describe('TransferInitialViewComponent', () => {
	let component: TransferEmptyStateViewComponent;
	let fixture: ComponentFixture<TransferEmptyStateViewComponent>;
	let button: DebugElement;
	let location: Location;
	let router: Router;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				ButtonModule,
				CommonModule,
				IconModule,
				RouterTestingModule.withRoutes([
					{
						path: 'beneficiary/user-account',
						component: BeneficiaryViewComponent
					}
				]),
				AvatarModule,
				ButtonModule,
				CommonModule,
				DialogSelectModule,
				EmojiModule,
				FormFieldModule,
				FormsModule,
				IconModule,
				IconButtonModule,
				InputModule,
				ReactiveFormsModule,
				ChipModule,
				ProductModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TokenDialogModule,
				TopBarModule,
				HiddenButtonsModule,
				SearchBarModule
			],
			declarations: [TransferEmptyStateViewComponent, BeneficiaryViewComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		router = TestBed.get(Router);
		location = TestBed.get(Location);
		fixture = TestBed.createComponent(TransferEmptyStateViewComponent);
		component = fixture.componentInstance;
		button = fixture.debugElement.query(By.css('button'));
		fixture.detectChanges();
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('navigate to create a  new contact', fakeAsync(() => {
		button.nativeElement.click();
		fixture.detectChanges();
		router.navigate(['/beneficiary/user-account']).then(() => {
			expect(location.path()).toBe('/beneficiary/user-account');
		});
	}));
});
