import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TransferEmptyStateViewComponent } from './empty-state-view.component';
import {
	ButtonModule, TokenDialogModule
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { TokenConfirmComponent } from '../../../components/token-confirm/token-confirm.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NgxMaskModule } from 'ngx-mask';

describe('TransferEmptyStateViewComponent', () => {

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TransferEmptyStateViewComponent, TokenConfirmComponent],
			imports: [
				RouterTestingModule.withRoutes([
					{ path: 'beneficiary/user-account', component: TransferEmptyStateViewComponent }
				]),
				ButtonModule,
        NgxMaskModule.forRoot()
			]
		}).overrideModule(
      BrowserDynamicTestingModule, {
        set: {
          entryComponents: [TokenConfirmComponent],
        }
      }
    )
		.compileComponents();
	}));

	describe('Empty State Transfers', () => {
		let component: TransferEmptyStateViewComponent;
		let fixture: ComponentFixture<TransferEmptyStateViewComponent>;
    // Most test suites in this guide call beforeEach() to set the preconditions for each it()
    // test and rely on the TestBed to create classes and inject services.
    beforeEach(() => {
      fixture = TestBed.createComponent(TransferEmptyStateViewComponent);
      component = fixture.debugElement.componentInstance;
    });
    it('should create the app', async(() => {
      expect(component).toBeTruthy();
    }));
  });
	// beforeEach(() => {
	// 	fixture = TestBed.createComponent(TransferEmptyStateViewComponent);
	// 	component = fixture.componentInstance;
	// 	fixture.detectChanges();
	// });

	// it('should create a component', () => {
	// 	fixture.detectChanges();
	// 	fixture.whenStable().then(()=>{
	// 		expect(component).toBeTruthy();
	// 	})
	// });
});
