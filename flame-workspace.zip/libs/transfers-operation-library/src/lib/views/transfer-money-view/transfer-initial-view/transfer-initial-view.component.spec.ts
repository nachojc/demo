import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TransferInitialViewComponent } from './transfer-initial-view.component';
import { RouterTestingModule } from '@angular/router/testing';
import {
	AvatarModule,
	AmountFieldModule,
	RadioButtonModule,
	ProductModule,
	ButtonModule,
	MotiveFieldModule,
	IconButtonModule,
	IconModule,
	DialogModule,
	TokenInputModule,
	SlideButtonModule,
	TokenDialogModule,
	SearchBarModule,
	TopBarModule,
	ThemeModule,
	FlameFoundationTheme,
	FormFieldModule,
	InputModule,
	ContactListModule,
	AccountSelectModule,
	EmojiModule,
	ChipModule,
	ContactDialogModule,
	ContactDialogService,
	TokenDialogService
} from '@santander/flame-component-library';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
	CommonModule,
	DatePipe,
	TitleCasePipe,
	CurrencyPipe
} from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { TransfersOperationLibraryRoutingModule } from '../../../transfers-operation-library.router.module';
import { NgxMaskModule } from 'ngx-mask';
import { TransfersOperationLibraryComponents } from '../../../components/transfers-operation-library-components';
import { TransfersOperationLibraryViews } from '../../transfers-operation-library-views';
import { SearchFilterPipe } from '../../../pipes/search-filter.pipe';
import { AccountsFilterPipe } from '../../../pipes/search-accounts.pipe';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';
import { TransfersOtherBanksService } from '../../../services/transfer-other-banks.service';
import { CepTranferService } from '../../../services/cep.service';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { Injector } from '@angular/core';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';

const payee = {
	caseOtherBank: {
		type: 'Payee',
		value: {
			account: {
				bank: 'SCOTIABANK',
				number: '5179921863843075',
				type: 'THIRDPARTY_DEBIT_CARD'
			},
			alias: 'The Fourth',
			key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
			name: 'Jack Jacobs',
			url: '/beneficiaries/{beneficiary-key}'
		}
	},
	caseSameBankThird: {
		type: 'Payee',
		value: {
			account: {
				bank: 'SANTANDER',
				number: '12345678902',
				type: 'SANTANDER_ACCOUNT'
			},
			alias: 'The Fourth Thanos',
			key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
			name: 'Jack Jacobs Stark',
			url: '/beneficiaries/{beneficiary-key}'
		}
	}
};
const caseAccount = {
	type: 'Account',
	value: {
		alias: 'Aaron',
		balance: {
			currency_code: 'MXN',
			amount: 69827.78
		},
		card_type: './assets/icons/card-basic.svg',
		description: 'SUPER NOMINA',
		display_number: '56*5124',
		key: '056722751246',
		number: '56*5124',
		product: {
			description: 'SUPER NOMINA'
		},
		related_phone: {
			phone_number: '5510555143',
			company: 'TELCEL'
		},
		status: 'AVAILABLE',
		url: 'test.com'
	}
};

describe('TransferInitialViewComponent', () => {
	let component: TransferInitialViewComponent;
	let fixture: ComponentFixture<TransferInitialViewComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				TransfersOperationLibraryRoutingModule,
				AvatarModule,
				AmountFieldModule,
				RadioButtonModule,
				ProductModule,
				ButtonModule,
				FormsModule,
				MotiveFieldModule,
				IconButtonModule,
				CommonModule,
				HttpClientModule,
				IconModule,
				DialogModule,
				TokenInputModule,
				SlideButtonModule,
				TokenDialogModule,
				SearchBarModule,
				TopBarModule,
				RouterTestingModule.withRoutes([]),
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				NgxMaskModule.forRoot(),
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				ContactListModule,
				AccountSelectModule,
				ChipModule,
				EmojiModule,
				ContactDialogModule
			],
			declarations: [
				...TransfersOperationLibraryComponents,
				...TransfersOperationLibraryViews,
				SearchFilterPipe,
				AccountsFilterPipe,
				TransferInitialViewComponent
			],
			providers: [
				DatePipe,
				TitleCasePipe,
				CurrencyPipe,
				TransferSameBankService,
				TransfersOtherBanksService,
				CepTranferService,
				ContactDialogService,
				TokenDialogService,
				BeneficiaryService,
				SummaryService,
				{
					provide: ENV_CONFIG,
					useValue: {
						baas: {}
					}
				},
				{ provide: Injector, useValue: {} }
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TransferInitialViewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('should show same account', () => {
		component.selectedContactEvent(caseAccount);
		component.showComponent = 'SameBankAccounts';
		expect(component.showComponent).toBeTruthy();
		fixture.detectChanges();
	});

	it('should show others banks', () => {
		component.selectedContactEvent(payee.caseOtherBank);
		component.showComponent = 'OtherBanks';
		expect(component.showComponent).toBeTruthy();
		fixture.detectChanges();
	});

	it('should show same bank third', () => {
		component.selectedContactEvent(payee.caseSameBankThird);
		component.showComponent = 'SameBankThird';
		expect(component.showComponent).toBeTruthy();
		fixture.detectChanges();
	});

	it('should show contacts search', () => {
		component.showComponent = 'Contacts';
		expect(component.showComponent).toBeTruthy();
		fixture.detectChanges();
	});
});
