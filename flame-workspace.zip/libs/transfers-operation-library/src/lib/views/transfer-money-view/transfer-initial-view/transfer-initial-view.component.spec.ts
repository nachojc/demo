import {
	async,
	ComponentFixture,
	TestBed,
	inject
} from '@angular/core/testing';
import { Router } from '@angular/router';
import { TransferInitialViewComponent } from './transfer-initial-view.component';
import { RouterTestingModule } from '@angular/router/testing';
import {
	AvatarModule,
	AmountFieldModule,
	RadioButtonModule,
	ProductModule,
	ButtonModule,
	MotiveFieldModule,
	IconButtonModule,
	IconModule,
	DialogModule,
	TokenInputModule,
	SlideButtonModule,
	TokenDialogModule,
	SearchBarModule,
	TopBarModule,
	ThemeModule,
	FlameFoundationTheme,
	FormFieldModule,
	InputModule,
	ContactListModule,
	AccountSelectModule,
	EmojiModule,
	ChipModule,
	ContactDialogModule,
	ContactDialogService,
	TokenDialogService,
	ErrorsModule,
	CheckboxModule,
	AutoWidthInputModule,
	HeaderAnimationModule,
	DialogService
} from '@santander/flame-component-library';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
	CommonModule,
	DatePipe,
	TitleCasePipe,
	CurrencyPipe,
	Location
} from '@angular/common';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { TransfersOperationLibraryRoutingModule } from '../../../transfers-operation-library.router.module';
import { NgxMaskModule } from 'ngx-mask';
import {
	TransfersOperationLibraryComponents,
	TransfersOperationLibraryEntryComponents
} from '../../../components/transfers-operation-library-components';
import { TransfersOperationLibraryViews } from '../../transfers-operation-library-views';
import { SearchFilterPipe } from '../../../pipes/search-filter.pipe';
import { AccountsFilterPipe } from '../../../pipes/search-accounts.pipe';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';
import { TransfersOtherBanksService } from '../../../services/transfer-other-banks.service';
import { CepTranferService } from '../../../services/cep.service';
import { ENV_CONFIG } from '@santander/flame-core-library';
import {
	Injector,
	NgModule,
	CUSTOM_ELEMENTS_SCHEMA,
	NO_ERRORS_SCHEMA
} from '@angular/core';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { DialogErrorComponent } from '../../../components/dialog-dummy/dialog-dummy.component';
import { By } from '@angular/platform-browser';
import { HttpClientTestingModule } from '@angular/common/http/testing';

const payee = {
	caseOtherBank: {
		type: 'Payee',
		value: {
			personal_identifier : undefined,
			account: {
				bank: 'SCOTIABANK',
				number: '5179921863843075',
				account_type: 'THIRDPARTY_DEBIT_CARD'
			},
			alias: 'The Fourth',
			key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
			name: 'Jack Jacobs',
			url: '/beneficiaries/{beneficiary-key}'
		}
	},
	caseSameBankThird: {
		type: 'Payee',
		value: {

			account: {
				bank: 'SANTANDER',
				number: '12345678902',
				account_type: 'SANTANDER_ACCOUNT'
			},
			alias: 'The Fourth Thanos',
			key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
			name: 'Jack Jacobs Stark',
			url: '/beneficiaries/{beneficiary-key}'
		}
	}
};
const caseAccount = {
	type: 'Account',
	value: {
		alias: 'Aaron',
		balance: {
			currency_code: 'MXN',
			amount: 69827.78
		},
		card_type: './assets/icons/card-basic.svg',
		description: 'SUPER NOMINA',
		display_number: '56*5124',
		key: '056722751246',
		number: '56*5124',
		product: {
			description: 'SUPER NOMINA'
		},
		related_phone: {
			phone_number: '5510555143',
			company: 'TELCEL'
		},
		status: 'AVAILABLE',
		url: 'test.com'
	}
};

const caseSameBank = {
  "type": "Payee",
  "value": {
    "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq",
    "account": {
      "number": "23456789045",
      "account_type": "SANTANDER_ACCOUNT",
      "bank": "SANTANDER"
    },
    "name": "Owen Saunders Maggy",
    "alias": "The Third Maggy",
    "url": "/beneficiaries/{beneficiary-key}",
    "personal_identifier": "MARE921122HJKDLN01"
  }
};

describe('TransferInitialViewComponent', () => {
	let component: TransferInitialViewComponent;
	let fixture: ComponentFixture<TransferInitialViewComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				AmountFieldModule,
				ProductModule,
				ButtonModule,
				FormsModule,
				HeaderAnimationModule,
				MotiveFieldModule,
				IconButtonModule,
				CommonModule,
				HttpClientTestingModule,
				IconModule,
				DialogModule,
				TokenInputModule,
				SlideButtonModule,
				TokenDialogModule,
				SearchBarModule,
				TopBarModule,
				ErrorsModule,
				RouterTestingModule.withRoutes([
					{ path: 'summary/global-position', component: TransferInitialViewComponent }
				]),
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				NgxMaskModule.forRoot(),
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				ContactListModule,
				AccountSelectModule,
				ChipModule,
				EmojiModule,
				ContactDialogModule,
				ErrorsModule,
				AutoWidthInputModule,
				CheckboxModule,
				HeaderAnimationModule,
				NoopAnimationsModule
			],
			declarations: [
				...TransfersOperationLibraryComponents,
				...TransfersOperationLibraryViews,
				SearchFilterPipe,
				AccountsFilterPipe,
				TransferInitialViewComponent
			],
			schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
			providers: [
				DatePipe,
				TitleCasePipe,
				CurrencyPipe,
				TransferSameBankService,
				TransfersOtherBanksService,
				CepTranferService,
				ContactDialogService,
				TokenDialogService,
				BeneficiaryService,
				SummaryService,
				DialogService,
				DialogErrorComponent,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: '',
							version: {
								transfers: ''
							}
						}
					}
				},
				{ provide: Injector, useValue: {} }
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TransferInitialViewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should show same account', () => {
		component.selectedContactEvent(caseAccount);
		component.showComponent = 'SameBankAccounts';
		fixture.detectChanges();
		expect(component.showComponent).toBeTruthy();
	});

	it('mostrar cuentas terceros mismo banco', () => {
		component.selectedContactEvent(caseSameBank);
		expect(component.showComponent).toBe('SameBankThird');
	})

	it('should show contacts search', () => {
		component.showComponent = 'Contacts';
		fixture.detectChanges();
		expect(component.showComponent).toBeTruthy();
	});

	it('Open Dialog Error', ()=>{
		component.openError();
		fixture.detectChanges();
	})

	it('Navigate Back', () =>{
		component.navigateBack();
		fixture.detectChanges();
		//Diferent view
		component.showComponent = 'OtherBanks';
		component.navigateBack();
		expect(component.showComponent).toBe('Contacts');
	})

	it('State View true testing', () => {
		component.searchViewState(true);
		fixture.detectChanges();
		expect(component.showComponent).toBe('Contacts');
		expect(component.showSearchView).toBe(true);
	})

	it('State View false testing', () => {
		component.beforeStateView = 'OtherBanks';
		component.searchViewState(false);
		expect(component.showComponent).toBe(component.beforeStateView);
		expect(component.showSearchView).toBeFalsy(false);
		// Comprobar que la busqueda no se muestre
		component.beforeStateView = 'Contacts';
		component.searchViewState(false);
		expect(component.showSearchView).toBeFalsy();
	})
});

