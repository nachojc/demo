import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransferInitialViewComponent } from './transfer-initial-view.component';

describe('TransferInitialViewComponent', () => {
  let component: TransferInitialViewComponent;
  let fixture: ComponentFixture<TransferInitialViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TransferInitialViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TransferInitialViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
