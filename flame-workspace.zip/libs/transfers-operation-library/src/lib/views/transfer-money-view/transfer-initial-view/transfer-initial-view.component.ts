import { Component } from '@angular/core';
import { Location } from '@angular/common';
import {
  ContactDialogService,
  DialogReference,
  DialogService,
  CustomDialog
} from '@santander/flame-component-library';
import { headerInitialViewAnimation } from '../../../animations/general/generic.animations';
import { DialogErrorComponent } from '../../../components/dialog-dummy/dialog-dummy.component';
/**
 * Vista para iniciar una transferencia.
 *
 * @export
 * @class TransferInitialViewComponent
 */
@Component({
  selector: 'sm-transfer-initial-view',
  templateUrl: './transfer-initial-view.component.html',
  styleUrls: ['./transfer-initial-view.component.scss'],
  animations: [headerInitialViewAnimation]
})
export class TransferInitialViewComponent {
	/**
	 * Crea una instancia de TransferInitialViewComponent.
	 * @param {ContactDialogService} _contactDialogService
	 * @param {Location} _location
	 * @memberof TransferInitialViewComponent
	 */
  constructor(
    public _contactDialogService: ContactDialogService,
    private _location: Location,
    private dialog: DialogService
  ) { }

	/*
	 * Variables públicas
	 */
  private dialogRef: DialogReference;
  public showComponent = 'Contacts';
  public showSearchView = false;
  public selectedContact: any;
  public beforeStateView = this.showComponent;
  public fakeAccount = {
    alias: null,
    balance: { currency_code: 'MXN', amount: 69827.78 },
    card_type: './assets/icons/card-pref.svg',
    description: 'SUPER NOMINA',
    display_number: '56*5124',
    key: '056722751246',
    number: '56*5124',
    product: { description: 'SUPER NOMINA' },
    related_phone: { phone_number: '5510555143', company: 'TELCEL' },
    status: 'AVAILABLE',
    url: null
  };

	/**
	 * Función para seleccionar un contacto y mostrar el flujo de transferencia
	 *
	 * @param {*} data
	 * @memberof TransferInitialViewComponent
	 */
  public selectedContactEvent(data: any): void {
    console.log(data);
    this.showSearchView = this.showSearchView ? !this.showSearchView : false;
    switch (true) {
      case data.type === 'Account':
        this.selectedContact = data.value;
        this.showComponent = 'SameBankAccounts';
        break;
      case data.type === 'Payee' &&
        (data.value.account.account_type === 'SANTANDER_ACCOUNT' ||
          data.value.account.account_type === 'SANTANDER_MOBILE_ACCOUNT'):
        this.selectedContact = data.value;
        this.showComponent = 'SameBankThird';
        break;
      default:
        if (
          data.value.personal_identifier === '' ||
          data.value.personal_identifier === undefined
        ) {
          this.openError();
        } else {
          this.selectedContact = data.value;
          this.showComponent = 'OtherBanks';
        }
        break;
    }
    this.beforeStateView = this.showComponent;
  }

	/**
	 * Permite manejar los estados entre la  vista actual y la de busqueda.
	 *
	 * @param {boolean} flag
	 * @memberof TransferInitialViewComponent
	 */
  public searchViewState(flag: boolean): void {
    if (flag) {
      this.showSearchView = flag;
      this.showComponent = 'Contacts';
    } else {
      if (this.beforeStateView !== 'Contacts') {
        this.showSearchView = false;
        this.showComponent = this.beforeStateView;
      } else {
        this.showSearchView = false;
      }
    }
  }

	/**
	 * Permite navegar a la vista anterior
	 *
	 * @memberof TransferInitialViewComponent
	 */
  public navigateBack(): void {
    if (this.showComponent === 'Contacts') {
      this._location.back();
    } else {
      this.showComponent = 'Contacts';
    }
  }

  openError() {
    this.dialogRef = this.dialog.open(
      {
        title: 'Operación inválida',
        enableHr: true,
        disabledButton: true,
        closeBackdropClick: false,
        buttons: [
          {
            class: 'strech',
            label: 'Aceptar',
            action: scope => {
              this.dialogRef.close();
            }
          }
        ]
      },
      new CustomDialog(DialogErrorComponent, {
        titleInvalid: 'Error',
        message:
          'No tienes registrado RFC o CURP, acude a tu sucursal mas cercana y solicita mas información',
        url: undefined
      })
    );
  }
}
