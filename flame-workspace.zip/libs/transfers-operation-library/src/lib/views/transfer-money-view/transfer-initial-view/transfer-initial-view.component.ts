import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sm-transfer-initial-view',
  templateUrl: './transfer-initial-view.component.html',
  styleUrls: ['./transfer-initial-view.component.scss']
})
export class TransferInitialViewComponent implements OnInit {

  public showComponent = 'Contacts';
  public selectedContact: any;

  constructor() { }

  ngOnInit() {
  }

  selectedContactEvent(data:any){
    if(data.type === 'Account'){
      this.selectedContact = data.value;
      this.showComponent = 'SameBankAccounts';
    }else{
      if (data.value.account.type === 'SANTANDER_ACCOUNT' || data.value.account.type === 'SANTANDER_MOBILE_ACCOUNT'){
        this.selectedContact = data.value;
        this.showComponent = 'SameBankThird';
      }else{
        this.selectedContact = data.value;
        this.showComponent = 'OtherBanks';
      }
    }
  }

}
