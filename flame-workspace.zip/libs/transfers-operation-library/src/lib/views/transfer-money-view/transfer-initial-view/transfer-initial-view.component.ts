import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { ContactDialogService } from '@santander/flame-component-library';
import { headerInitialViewAnimation } from '../../../animations/general/generic.animations';
/**
 * Vista para iniciar una transferencia.
 *
 * @export
 * @class TransferInitialViewComponent
 * @implements {OnInit}
 */
@Component({
	selector: 'sm-transfer-initial-view',
	templateUrl: './transfer-initial-view.component.html',
	styleUrls: ['./transfer-initial-view.component.scss'],
	animations: [headerInitialViewAnimation]
})
export class TransferInitialViewComponent implements OnInit {
	/**
	 * Crea una instancia de TransferInitialViewComponent.
	 * @param {ContactDialogService} _contactDialogService
	 * @param {Location} _location
	 * @memberof TransferInitialViewComponent
	 */
	constructor(
		public _contactDialogService: ContactDialogService,
		private _location: Location
	) {}

	/*
	 * Variables públicas
	 */
	public showComponent = 'Contacts';
	public showSearchView = false;
	public selectedContact: any;
	public beforeStateView = this.showComponent;
	public fakeAccount = {
		alias: null,
		balance: { currency_code: 'MXN', amount: 69827.78 },
		card_type: './assets/icons/card-pref.svg',
		description: 'SUPER NOMINA',
		display_number: '56*5124',
		key: '056722751246',
		number: '56*5124',
		product: { description: 'SUPER NOMINA' },
		related_phone: { phone_number: '5510555143', company: 'TELCEL' },
		status: 'AVAILABLE',
		url: null
	};

	/**
	 * Función para seleccionar un contacto y mostrar el flujo de transferencia
	 *
	 * @param {*} data
	 * @memberof TransferInitialViewComponent
	 */
	public selectedContactEvent(data: any): void {
		this.showSearchView = this.showSearchView ? !this.showSearchView : false;
		if (data.type === 'Account') {
			this.selectedContact = data.value;
			this.showComponent = 'SameBankAccounts';
		} else {
			if (
				data.value.account.type === 'SANTANDER_ACCOUNT' ||
				data.value.account.type === 'SANTANDER_MOBILE_ACCOUNT'
			) {
				this.selectedContact = data.value;
				this.showComponent = 'SameBankThird';
			} else {
				this.selectedContact = data.value;
				this.showComponent = 'OtherBanks';
			}
		}
		this.beforeStateView = this.showComponent;
	}

	/**
	 * Permite manejar los estados entre la  vista actual y la de busqueda.
	 *
	 * @param {boolean} flag
	 * @memberof TransferInitialViewComponent
	 */
	public searchViewState(flag: boolean): void {
		if (flag) {
			this.showSearchView = flag;
			this.showComponent = 'Contacts';
		} else {
			if (this.beforeStateView !== 'Contacts') {
				this.showSearchView = false;
				this.showComponent = this.beforeStateView;
			} else {
				this.showSearchView = false;
			}
		}
	}

	/**
	 * Permite navegar a la vista anterior
	 *
	 * @memberof TransferInitialViewComponent
	 */
	public navigateBack(): void {
		if (this.showComponent === 'Contacts') {
			this._location.back();
		} else {
			this.showComponent = 'Contacts';
		}
	}

	ngOnInit(): void {}
}
