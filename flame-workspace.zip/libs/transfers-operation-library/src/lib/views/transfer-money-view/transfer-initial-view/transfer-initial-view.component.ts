import { Component, OnInit } from '@angular/core';
import { ContactDialogService } from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { headerInitialViewAnimation } from '../../../animations/general/generic.animations';
@Component({
  selector: 'sm-transfer-initial-view',
  templateUrl: './transfer-initial-view.component.html',
  styleUrls: ['./transfer-initial-view.component.scss'],
  animations: [headerInitialViewAnimation]
})
export class TransferInitialViewComponent implements OnInit {

  public showComponent = 'Contacts';
  public showSearchView = false;
  public selectedContact: any;
  public beforeStateView = this.showComponent;
  public fakeAccount = {
    alias: null,
    balance: {currency_code: "MXN", amount: 69827.78},
    card_type: "./assets/icons/card-pref.svg",
    description: "SUPER NOMINA",
    display_number: "56*5124",
    key: "056722751246",
    number: "56*5124",
    product: {description: "SUPER NOMINA"},
    related_phone: {phone_number: "5510555143", company: "TELCEL"},
    status: "AVAILABLE",
    url: null
  }

  constructor(public contactDialogService: ContactDialogService,
    private router: Router) { }

  ngOnInit() {
  }

  selectedContactEvent(data:any){
    this.showSearchView = this.showSearchView ? !this.showSearchView: false;
    if(data.type === 'Account'){
      this.selectedContact = data.value;
      this.showComponent = 'SameBankAccounts';
    }else{
      if (data.value.account.type === 'SANTANDER_ACCOUNT' || data.value.account.type === 'SANTANDER_MOBILE_ACCOUNT'){
        this.selectedContact = data.value;
        this.showComponent = 'SameBankThird';
      }else{
        this.selectedContact = data.value;
        this.showComponent = 'OtherBanks';
      }
    }
    this.beforeStateView = this.showComponent;
  }

  searchViewState(flag: boolean){
    if(flag){
      this.showSearchView = flag;
      this.showComponent = 'Contacts';
    }else{
      if (this.beforeStateView !== 'Contacts'){
        this.showSearchView = false;
        this.showComponent = this.beforeStateView;
      }else{
        this.showSearchView = false;
      }
    }

  }

  navigate(){
    if (this.showComponent === 'Contacts'){
      this.router.navigate(['/summary/global-position']);
    }else{
      this.showComponent = 'Contacts';
    }
  }

}
