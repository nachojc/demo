import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
	selector: 'sm-transfers-voucher',
	templateUrl: './transfers-voucher-view.component.html',
	styleUrls: ['./transfers-voucher-view.component.scss']
})
export class TransfersVoucherViewComponent implements OnInit {
	// Elementos DOM
	@ViewChild('containerinfo') containerInfo;

	// Variables
	public pathRepeat: Array<number>;
	public showVoucherOneOrTwo: boolean;

	// Fake info
	public fakeInfo = {
		id: 5,
		totalSend: '350',
		reason: 'Comida wework',
		fullname: 'Douglas Costa de Souza',
		shortname: 'Douglas Costa',
		bank: 'BANREGIO',
		accountnumber: '1111 2222 3333 4444',
		imgsrc:
			'https://as01.epimg.net/img/comunes/fotos/fichas/deportistas/d/dou/large/19467.png',
		operation: '14/11/2018 - 11:52:23 h',
		accountOrigin: '32**2345',
		referenceSantanderMovil: '123456',
		referenceNumber: '001',
		status: 'En proceso de validación'
	};

	// Control
	public showMoreInfo = false;

	constructor(private _route: ActivatedRoute) {}

	ngOnInit() {
    this.evaluateTypeVoucher();
    console.log(this.containerInfo.nativeElement.offsetWidth);
		const temporal =
			parseInt(
				(this.containerInfo.nativeElement.offsetWidth / 30).toString(),
				10
			) + 1;
		this.pathRepeat = Array(temporal)
			.fill(0)
			.map((x, i) => i);
	}

	evaluateTypeVoucher() {
		this._route.queryParams.subscribe(params => {
			return (this.showVoucherOneOrTwo = params.voucherType === '3');
		});
	}
}
