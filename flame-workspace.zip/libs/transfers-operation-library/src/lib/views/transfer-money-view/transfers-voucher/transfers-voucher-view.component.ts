import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { VoucherOutAnimation } from '@santander/flame-component-library';

@Component({
	selector: 'sm-transfers-voucher',
	templateUrl: './transfers-voucher-view.component.html',
	styleUrls: ['./transfers-voucher-view.component.scss']
})
export class TransfersVoucherViewComponent implements OnInit {
	constructor(private _router: Router, private _route: ActivatedRoute) {}

	// Elementos DOM
	@ViewChild('containerinfo') containerInfo;

	// Variables
	public pathRepeat: Array<number>;
	public showVoucherOneOrTwo = false;

	// Fake info
	public fakeInfo = {
		id: 5,
		totalSend: '350',
		reason: 'Comida wework',
		fullname: 'Douglas Costa de Souza',
		shortname: 'Douglas Costa',
		bank: 'Santander',
		accountnumber: '1111 2222 3333 4444',
		imgsrc:
			'https://as01.epimg.net/img/comunes/fotos/fichas/deportistas/d/dou/large/19467.png',
		operation: '02/Nov/18 - 21:40:57 h',
		accountOrigin: '32**2345',
		referenceSantanderMovil: '123456',
		referenceNumber: '001',
		status: 'Liquidado'
	};

	// Control
	public showMoreInfo = false;
	public voucherExitMove = "";

	private evaluateTypeVoucher() {
		this._route.queryParams.subscribe(params => {
			this.showVoucherOneOrTwo = params.voucherType === '3';
		});
	}

	/**
	 * Función que regresa al summary
	 *
	 * @param {*} event
	 * @memberof TransfersVoucherViewComponent
	 */
	public close() {
    this._router.navigate(['/summary/global-position']);
	}

	ngOnInit() {
		this.evaluateTypeVoucher();
			const temporal =
				parseInt(
					(this.containerInfo.nativeElement.offsetWidth / 30).toString(),
					10
				) + 1;
			this.pathRepeat = Array(temporal)
				.fill(0)
				.map((x, i) => i);
		}
}
