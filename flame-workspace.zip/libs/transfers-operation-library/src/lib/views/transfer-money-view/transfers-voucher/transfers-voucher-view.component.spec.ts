import { async, ComponentFixture, TestBed, tick } from '@angular/core/testing';

import { TransfersVoucherViewComponent } from './transfers-voucher-view.component';
import { Router } from '@angular/router';
import { AvatarModule, IconButtonModule, IconModule, ProductModule } from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';

describe('TransfersVoucherComponent', () => {
	let component: TransfersVoucherViewComponent;
	let fixture: ComponentFixture<TransfersVoucherViewComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TransfersVoucherViewComponent],
			imports: [
        AvatarModule,
        IconButtonModule,
        IconModule,
				ProductModule,
				RouterTestingModule.withRoutes([
					{ path: 'voucher', component: TransfersVoucherViewComponent }
				]
				)
			],
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TransfersVoucherViewComponent);
		component = fixture.componentInstance;
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('Evaluar tipo de voucher', () => {
		TestBed.get(Router).navigate(['/voucher'], {
			queryParams: {
				voucherType: 3
			}
		}).then(() => {
			spyOn<any>(component, 'evaluateTypeVoucher').and.callThrough();
		}).catch(e => console.log(e));
	});

	it('Cerrar Voucher', ()=>{
		component.ngOnInit();
		component.close();
	})
});
