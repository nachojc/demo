import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransfersVoucherViewComponent } from './transfers-voucher-view.component';

describe('TransfersVoucherComponent', () => {
	let component: TransfersVoucherViewComponent;
	let fixture: ComponentFixture<TransfersVoucherViewComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TransfersVoucherViewComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TransfersVoucherViewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
