import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TransfersSameAccountsComponent } from './transfers-same-accounts.component';

describe('TransfersSameAccountsComponent', () => {
	let component: TransfersSameAccountsComponent;
	let fixture: ComponentFixture<TransfersSameAccountsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TransfersSameAccountsComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TransfersSameAccountsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
