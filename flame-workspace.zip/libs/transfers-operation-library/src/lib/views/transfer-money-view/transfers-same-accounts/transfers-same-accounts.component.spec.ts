import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';

import { TransfersSameAccountsComponent } from './transfers-same-accounts.component';
import { ContactsWidgetComponent } from '../../../components/contacts-widget/contacts-widget.component';
import { SearchFilterPipe } from '../../../pipes/search-filter.pipe';
import { AccountsFilterPipe } from '../../../pipes/search-accounts.pipe';
import { SearchBarModule, AmountFieldModule, MotiveFieldModule, AvatarModule, ProductModule, IconButtonModule, IconModule, ContactDialogModule, ErrorsModule, AccountSelectModule, TokenDialogModule } from '@santander/flame-component-library';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { OverlayModule } from '@angular/cdk/overlay';
import { RouterTestingModule } from '@angular/router/testing';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { of } from 'rxjs';
import { By } from '@angular/platform-browser';
import { TokenConfirmComponent } from '../../../components/token-confirm/token-confirm.component';
import { NgxMaskModule } from 'ngx-mask';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

export const environment = {
  production: false,
  sm: {
    clientId: '0KxtKPNZzUIMueEfxeP6x_NKWPJLRREWHEHsyOw1a4w',
    clientSecret: 	'KLkcUzobEGpTo8idYowgscCZPs1aRvnhSF0tEYQSZ5k='
  },
	idp: {
		url: 'http://localhost:3000/IDPWeb/idp',
		redirectUri: 'http://www.santander.com.mx/mx/home'
	},
	oauth: {
		url: 'http://localhost:3000/oauth2/v1/token',
    scope: 'summary_1.0.0 accounts_1.0.0'
  },
  api: {
    url: 'http://localhost:3000/api',
    version: {
      summary: '',
      accounts: '',
      credits: '',
      cards: '',
      transfers: ''
    }
  }
};

describe('TransfersSameAccountsComponent', () => {
	let component: TransfersSameAccountsComponent;
  let fixture: ComponentFixture<TransfersSameAccountsComponent>;
  let rootElement: any;
  let servicio: any;
  let httpMock: HttpTestingController;

  const mockPayeesList = {
    "data": [
      {
        "key": "0m29qh0l7xy6oattzh65kq2jgn19fbx6",
        "account": {
          "number": "5179921863843075",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "SCOTIABANK"
        },
        "name": "Jack Jacobs",
        "alias": "The Fourth",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "otmn77lqcc111oblddj1rekjfk52vqe3",
        "account": {
          "number": "363042688497206369",
          "type": "CLABE",
          "bank": "SCOTIABANK"
        },
        "name": "Rosie Franklin",
        "alias": "Juris Doctor",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "62k8i7sjq69rvxuueaduwagwnkvr3jjq",
        "account": {
          "number": "926321303849798078",
          "type": "CLABE",
          "bank": "SCOTIABANK"
        },
        "name": "Owen Saunders",
        "alias": "The Third",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "5sdkcqgbiy0o8gilvd0ww17y4kpvq9mt",
        "account": {
          "number": "99771443157",
          "type": "SANTANDER_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Joseph Webb",
        "alias": "Doctor of Osteopathic Medicine",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "jniooip0w06ufj2n3h43afrlnstfizv3",
        "account": {
          "number": "5101796332543032",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "SCOTIABANK"
        },
        "name": "Ada Romero",
        "alias": "Bachelor of Engineering",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "dwtoh70ok0s393c3sip8qvc0l7nyticy",
        "account": {
          "number": "5138821295814142",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "BANAMEX"
        },
        "name": "Minerva Ryan",
        "alias": "Bachelor of Technology",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "dams9kplafqwxrgel4c7sq5bdwrzac39",
        "account": {
          "number": "(712) 283-6426",
          "type": "SANTANDER_MOBILE_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Emma Hampton",
        "alias": "Doctor of Osteopathic Medicine",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "ia1rpal73nack998zvn7bnfxyzjwzf66",
        "account": {
          "number": "5169121412084758",
          "type": "THIRDPARTY_DEBIT_CARD",
          "bank": "CIBANCO"
        },
        "name": "Lora Curtis",
        "alias": "Bachelor of Technology",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "iwgohq5r0ubl3qgwfr7p9hwfdnggtfg0",
        "account": {
          "number": "60220276131",
          "type": "SANTANDER_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Manuel Mason",
        "alias": "Bachelor of Engineering",
        "url": "/beneficiaries/{beneficiary-key}"
      },
      {
        "key": "5ya77rlszyprcpc9jx64xoj5i0hruwrj",
        "account": {
          "number": "(557) 666-4869",
          "type": "SANTANDER_MOBILE_ACCOUNT",
          "bank": "SANTANDER"
        },
        "name": "Loretta Quinn",
        "alias": "The Fourth",
        "url": "/beneficiaries/{beneficiary-key}"
      }
    ],
    "notifications": [
      {
        "code": "E422CDNPAYRCPTG001",
        "description": "Something is happening",
        "timestamp": "2019-02-16T23:38:45.408Z"
      }
    ],
    "paging": {
      "next_cursor_key": "10"
    }
  }

  const mockAccountList = {
    "data": [
      {
        "category_name": "CHECKING_ACCOUNTS",
        "total_balance": {
          "currency_code": "MXN",
          "amount": 69827.78
        },
        "products": [
          {
            "key": "056722751246",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "56*5124",
            "related_phone": {
              "phone_number": "5510555143",
              "company": "TELCEL"
            },
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "MXN",
              "amount": 69827.78
            }
          },
          {
            "key": "056722733565",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "56*3356",
            "related_phone": null,
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "USD",
              "amount": 0
            }
          }
        ]
      },
      {
        "category_name": "CREDIT_CARDS",
        "total_balance": {
          "currency_code": "MXN",
          "amount": 85399.66
        },
        "products": [
          {
            "key": "4e20fbb243684d9eb19ff33a50ee422e",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "*3699",
            "related_phone": null,
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "MXN",
              "amount": 1812.1
            }
          },
          {
            "key": "1b10lop243683d9eb19ff33a50ee345a",
            "alias": null,
            "description": "SUPER NOMINA",
            "url": null,
            "display_number": "*9981",
            "related_phone": null,
            "status": "AVAILABLE",
            "balance": {
              "currency_code": "MXN",
              "amount": -22038.1
            }
          }
        ]
      }
    ],
    "notifications": null,
    "paging": null
  }

	beforeEach(async(() => {
		TestBed.configureTestingModule({
      declarations: [ TransfersSameAccountsComponent, ContactsWidgetComponent, SearchFilterPipe, AccountsFilterPipe, TokenConfirmComponent],
      imports: [SearchBarModule,
        AmountFieldModule,
        MotiveFieldModule,
        AvatarModule,
        ProductModule,
        IconButtonModule,
        HttpClientTestingModule,
        IconModule,
        FormsModule,
        NoopAnimationsModule,
        OverlayModule,
        RouterTestingModule,
        ContactDialogModule,
        ErrorsModule,
        ReactiveFormsModule,
        AccountSelectModule,
        ProductModule,
        TokenDialogModule,
        NgxMaskModule.forRoot()
      ],
      providers: [TransferSameBankService,
        {
          provide: ENV_CONFIG,
          useValue: environment
        }],
    }).overrideModule(
      BrowserDynamicTestingModule, {
        set: {
          entryComponents: [TokenConfirmComponent],
        }
      }
    ).compileComponents();
    httpMock = TestBed.get(HttpTestingController);
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TransfersSameAccountsComponent);
    component = fixture.componentInstance;
    component.fromAccount = {
      "key": "056722751246",
      "alias": null,
      "url": null,
      "balance": {
        "currency_code": "MXN",
        "amount": 69827.78
      },
      "card_type": "./assets/icons/card-pref.svg",
      "description": "SUPER NOMINA",
      "display_number": "56*5124",
      "number": "56*5124",
      "product": {
        "description": "SUPER NOMINA"
      },
      "related_phone": {
        "phone_number": "5510555143",
        "company": "TELCEL"
      },
      "status": "AVAILABLE"
    };
    component.dataAccount = {
      "key": "4e20fbb243684d9eb19ff33a50ee422e",
      "alias": null,
      "url": null,
      "balance": {
        "currency_code": "MXN",
        "amount": 1812.1
      },
      "card_type": "./assets/icons/card-amex.svg",
      "description": "SUPER NOMINA",
      "display_number": "*3699",
      "number": "*3699",
      "product": {
        "description": "SUPER NOMINA"
      },
      "related_phone": null,
      "status": "AVAILABLE",
      "image_url": null
    }
    servicio = component.transferService;
    rootElement = fixture.debugElement;
    // Simular peticiones HTTP
    const req2 = httpMock.expectOne('http://localhost:3000/api/summary?page=1&limit=10')
    req2.flush(mockAccountList);
    component.initializer();
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
  });

  it('Asignar accounts en base a la llamada getAccounts del servicio TransferSameAccountsService', ()=>{
    expect(component.accounts.length).toBeGreaterThan(1);
  })

  it('fromAccount Assignment', ()=>{
    expect(component.fromAccount).toBeDefined();
  })

  it('Modificar motive field directamente', () =>{
    component.transactionForm.get('motive').setValue('Hola mundo');
    fixture.detectChanges();
    const valor = component.transactionForm.get('motive').value;
    expect(valor).toBe('Hola mundo');
  });

  it('Abrir dialogo de cuentas (Flujo alterno)', () => {
    const selectAccountContainer = fixture.debugElement.query(By.css('sn-account-select'));
    expect(selectAccountContainer.nativeElement).toBeTruthy();
    spyOn(selectAccountContainer.nativeElement, 'click');
    selectAccountContainer.nativeElement.click();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      const selectAccountDialog = rootElement.parentElement.query(By.css("sn-dialog"));
      expect(selectAccountDialog).toBeTruthy();
    });
  })

  it('Abrir lista de contactos (evento Funcion)', () => {
    spyOn(component, 'stateContactView').and.callThrough();
    component.stateContactView();
    fixture.detectChanges();
    const searchBarComponent = fixture.debugElement.query(By.css('sn-search-bar'));
    expect(searchBarComponent).toBeDefined();
  })

  it('Abrir lista de contactos (Flujo alterno)', () => {
    spyOn(component, 'stateContactView');
    const contactListContainer = fixture.debugElement.query(By.css('sn-product'));
    expect(contactListContainer.nativeElement).toBeTruthy();
    contactListContainer.nativeElement.click();
    expect(component.stateContactView).toHaveBeenCalled();
    fixture.detectChanges();
    const searchBarComponent = fixture.debugElement.query(By.css('sn-search-bar'));
    expect(searchBarComponent).toBeDefined();
  })

  it('Asignar Valor a la operacion', () => {
    const button = fixture.debugElement.query(By.css('button'));
    expect(component.transactionForm.valid).toBeFalsy();
    expect(button.nativeElement.disabled).toBeTruthy();
    component.transactionForm.get('motive').setValue('Hola mundo');
    component.transactionForm.get('amount').setValue(20.22);
    fixture.detectChanges();
    expect(component.transactionForm.valid).toBeTruthy();
    expect(button.nativeElement.disabled).toBeFalsy();
    button.nativeElement.click();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      const tokenDialog = rootElement.parentElement.query(By.css("sn-modal-title"));
      expect(tokenDialog).toBeTruthy();
      expect(tokenDialog.nativeElement.innerHTML).toBe('Confirma esta operación');
    });
    component.confirmTokenEvent({ok: true});
  })

});
