import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';

@Component({
	selector: 'sm-transfers-same-accounts',
	templateUrl: './transfers-same-accounts.component.html',
	styleUrls: ['./transfers-same-accounts.component.scss']
})
export class TransfersSameAccountsComponent implements OnInit {

  // Input
  @Input() dataAccount: any;

	// Control
  public disableInputs = false;
  public hideDialogToken = false;
  public confirmedToken = false;

  public cardImages = [
    './assets/icons/card-amex.svg',
    './assets/icons/card-aero.svg',
    './assets/icons/card-basic.svg',
    './assets/icons/card-pref.svg'
  ];

  // Models
  public accounts: Array<any> = [];

  public account = <any>{
    product: {},
    related_phone: {},
    balance: {}
  };

  constructor(private router: Router,
    private transferService: TransferSameBankService) {
    this.transferService.getAccounts()
    .subscribe((res:any) =>{
      this.accounts = this.accounts.concat(res.data[0].products);
      this.accounts = this.accounts.concat(res.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
      this.account = this.accounts[0];
    })
  }

  ngOnInit() {}

	dialogTokenEvent(data: string) {
		if (data === 'closed' && this.confirmedToken) {
			this.router.navigate(['/transfers/voucher'], {
				queryParams: {
					voucherType: Math.floor(Math.random() * 2) + 1
				}
			});
		}
	}

	confirmTokenEvent(data: any) {
		this.hideDialogToken = true;
		this.confirmedToken = true;
	}
}
