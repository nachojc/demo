import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { Router } from '@angular/router';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
	selector: 'sm-transfers-same-accounts',
	templateUrl: './transfers-same-accounts.component.html',
	styleUrls: ['./transfers-same-accounts.component.scss']
})
export class TransfersSameAccountsComponent implements OnInit {

  constructor(private router: Router,
    private transferService: TransferSameBankService,
    private formBuilder: FormBuilder) {
    this.initializer();
  }

  public disableInputs = false;
  public hideDialogToken = false;
  public confirmedToken = false;
  public cardImages = [
    './assets/icons/card-amex.svg',
    './assets/icons/card-aero.svg',
    './assets/icons/card-basic.svg',
    './assets/icons/card-pref.svg'
  ];
  public accounts: Array<any> = [];
  public transactionForm: FormGroup;
  public account = <any>{
    product: {},
    related_phone: {},
    balance: {}
  };
  public inputValues = {
    amount: 0.0
  }

  @Input() dataAccount: any;
  @Input()
  set fromAccount(value: any){
    this.account = value;
  }
  get fromAccount(){
    return this.account;
  }
  @Output() showContactView = new EventEmitter<boolean>();

  initializer(){
    this.transferService.getAccounts()
    .subscribe((res:any) =>{
      this.accounts = this.accounts.concat(res.data[0].products);
      this.accounts = this.accounts.concat(res.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
    })
    this.transactionForm = this.formBuilder.group({
      amount: [0.0, Validators.required,],
      motive: ['', Validators.required],
      reference: ['', [Validators.required, ]],
      optional: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

	dialogTokenEvent(data: string) {
    if (data === 'closed' && this.confirmedToken) {
			this.router.navigate(['/transfers/voucher'], {
				queryParams: {
          voucherType: Math.floor(Math.random() * 2) + 1
				}
			});
		}
	}

	confirmTokenEvent(data: any) {
    this.hideDialogToken = true;
		this.confirmedToken = true;
  }

  stateContactView(){
    this.showContactView.emit(true);
  }

  ngOnInit() {}
}
