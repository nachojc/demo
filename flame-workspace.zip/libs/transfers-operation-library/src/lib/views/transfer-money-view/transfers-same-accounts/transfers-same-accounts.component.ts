import { Component, OnInit, Input, EventEmitter, Output, OnChanges, SimpleChanges, DoCheck, ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';
import { TransferSameBankService } from '../../../services/transfer-same-bank.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TokenConfirmComponent } from '../../../components/token-confirm/token-confirm.component';
import { CustomDialog } from '@santander/flame-component-library';
import { delay } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
	selector: 'sm-transfers-same-accounts',
	templateUrl: './transfers-same-accounts.component.html',
  styleUrls: ['./transfers-same-accounts.component.scss']
})
export class TransfersSameAccountsComponent implements OnInit, DoCheck {

  constructor(private router: Router,
    public transferService: TransferSameBankService,
    private formBuilder: FormBuilder) {
    this.initializer();
  }

  public disableInputs = false;
  public hideDialogToken = false;
  public confirmedToken = false;
  public statusSlide = '';
  public dialogBody = {
    amount: 0,
    type: 1,
		toAccount: {
			name: '',
			account: ''
		},
		fromAccount: {
			name: '',
			account: ''
		}
  };
  public customBody = new CustomDialog(TokenConfirmComponent, this.dialogBody);
  public cardImages = [
    './assets/icons/card-amex.svg',
    './assets/icons/card-aero.svg',
    './assets/icons/card-basic.svg',
    './assets/icons/card-pref.svg'
  ];
  public accounts: Array<any> = [];
  public transactionForm: FormGroup;
  public account = <any>{
    product: {},
    related_phone: {},
    balance: {}
  };
  public oldAccount: any;
  public balanceAccount = 0;

  // Este funciona como Cuenta Destino
  @Input() dataAccount: any;
  // Este funciona como Cuenta Origen
  @Input()
  get fromAccount(){
    return this.account;
  }
  set fromAccount(value: any){
    this.account = value;
    this.oldAccount = value;
  }

  @Output() showContactView = new EventEmitter<boolean>();

  initializer(){
    this.transferService.getAccounts()
    .subscribe((res:any) =>{
      this.accounts = this.accounts.concat(res.data[0].products);
      this.accounts = this.accounts.concat(res.data[1].products);
      this.accounts.map((item: any) => {
        item.card_type = this.cardImages[
          Math.floor(Math.random() * this.cardImages.length)
        ];
        item.product = {
          description: item.description
        };
        item.number = item.display_number;
      });
    })
    this.transactionForm = this.formBuilder.group({
      amount: [0.0, [Validators.required, Validators.min(10)]],
      motive: ['Transferencia', [Validators.minLength(3), Validators.pattern(/^[a-zA-Z0-9\s]*$/)]]
    });
    this.transactionForm.valueChanges.subscribe((values: any)=>{
      this.dialogBody.amount = values.amount;
    });
  }

	dialogTokenEvent(data: string) {
    if (data === 'closed' && this.confirmedToken) {
			this.router.navigate(['/transfers/voucher'], {
				queryParams: {
          voucherType: Math.floor(Math.random() * 2) + 1
				}
			});
		}
	}

	confirmTokenEvent(data: any) {
    // Aqui mandar la solicitud
    this.statusSlide = 'success';
    // Simulacion de tiempo que tardo en resolver la solicitud
    of(null)
    .pipe(
      delay(1500)
    )
    .subscribe(timeout =>{
      this.hideDialogToken = true;
      this.confirmedToken = true;
    })
  }

  stateContactView(){
    this.showContactView.emit(true);
  }

  ngOnInit() {
    this.dialogBody.fromAccount = {
      name: this.dataAccount.description,
      account: this.dataAccount.number
    }
    this.balanceAccount = this.account.balance.amount;
    this.dialogBody.toAccount = {
      name: this.account.description,
      account: this.account.number
    }
    this.transactionForm.get('amount').setValidators([Validators.required, Validators.min(10), Validators.max(this.balanceAccount)]);
    this.transactionForm.updateValueAndValidity();
  }

  ngDoCheck(){
    if (this.oldAccount !== this.account){
      this.dialogBody.toAccount = {
        name: this.account.description,
        account: this.account.number
      }
      this.oldAccount = this.account;
      this.transactionForm.get('amount').setValue(0);
      this.transactionForm.get('amount').setValidators([Validators.required, Validators.min(10), Validators.max(this.account.balance.amount)]);
      this.transactionForm.updateValueAndValidity();
    }
  }
}
