import { Component, OnInit, ViewChild, EventEmitter } from '@angular/core';
import { DataTransferService } from '@santander/flame-core-library';
import {
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { DataFakeVoucher } from '../fake-info';
import { accordionAnimation } from '@santander/flame-component-library';
import { VoucherOutAnimation } from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { DialogErrorComponent } from '../../../components/dialog-dummy/dialog-dummy.component';

@Component({
	selector: 'sm-voucher-others-banks',
	templateUrl: './voucher-others-banks.component.html',
	styleUrls: ['./voucher-others-banks.component.scss'],
	animations: [accordionAnimation, VoucherOutAnimation]
})
export class TranfersVoucherOthersBanksComponent implements OnInit {
	constructor(
		private _dataBehaviorTransferService: DataTransferService,
		private dialog: DialogService,
		private _router: Router
	) {}

	public closeEvent = new EventEmitter<boolean>();
	public pathRepeat: Array<number>;
	public dialogRef: DialogReference;
	public showMore = false;
	public voucherExitMove = '';
	public dataVoucher = {
		key: '',
		confirmation_number: '',
		effective_date: '',
		status: '',
		from_account: {
			key: '',
			url: '',
			type: '',
			alias: '',
			display_number: '',
			bank: '',
			name: '',
			main_balance: {
				currency_code: '',
				amount: 0
			}
		},
		to_payee: {
			key: '',
			url: '',
			type: '',
			alias: '',
			display_number: '',
			bank: '',
			name: '',
			main_balance: {
				currency_code: '',
				amount: 0
			}
		},
		amount: {
			currency_code: '',
			amount: 0
		},
		concept: '',
		reference: '',
		creation_date: '',
		url_receipt: '',
		operation_type: '',
		customer_personal_identifier: '',
		tracking_number: '',
		personal_identifier_beneficiary: ''
	};
	@ViewChild('containerinfo') containerInfo;

	/**
	 * crea diviciones tipo paper-cut
	 *
	 * @memberof TranfersVoucherOthersBanksComponent
	 */
	createDivisions() {
		const temporal =
			parseInt(
				(this.containerInfo.nativeElement.offsetWidth / 30).toString(),
				10
			) + 1;
		this.pathRepeat = Array(temporal)
			.fill(0)
			.map((result, index) => index);
	}

	/**
	 * muestra advertencia de redireccionamieto a una nueva ventana para el comprobante cep
	 *
	 * @memberof TranfersVoucherOthersBanksComponent
	 */
	openWindowCep() {
		const evtClose = this.closeEvent;
		this.dialogRef = this.dialog.open(
			{
				title: 'Operación inválida',
				closeLabel: 'cerrar',
				enableHr: true,
				disabledButton: true,
				closeBackdropClick: true,
				showButton: false,
				buttons: []
			},
			new CustomDialog(DialogErrorComponent, {
				titleInvalid: 'Redirección a otro sitio',
				message:
					'Estás por salir de la aplicación para consultar la información en tu navegador ¿Deseas ir?',
				url: undefined,
				showButtonAccept: true,
				closeEvtButton: evtClose,
				textButton: 'Si, llévame al otro sitio'
			})
		);
		this.closeEvent.subscribe((response: boolean) => {
			if (response) {
				window.open(this.dataVoucher.url_receipt, '_blank');
				this.dialogRef.close();
			}
		});
	}

	/**
	 * Función que inicia la animación de salida del voucher
	 *
	 * @memberof TransfersVoucherViewComponent
	 */
	public animationExit() {
		this.voucherExitMove = 'out';
	}

	/**
	 * Función que regresa al summary
	 *
	 * @param {*} event
	 * @memberof TransfersVoucherViewComponent
	 */
	public close(event: any) {
		if (event.totalTime) {
			this._router.navigate(['/summary/global-position']);
		}
	}

	/**
	 * Se recupera la información del voucher que esta en el servicio behavior y en fakeinfo.ts
	 *
	 * @memberof TranfersVoucherOthersBanksComponent
	 */
	ngOnInit() {
		this.createDivisions();
		this._dataBehaviorTransferService.getData().then(res => {
			this.dataVoucher = res;
			if (res === undefined) {
				this.dataVoucher = DataFakeVoucher;
			}
		});
	}
}
