import { Component, OnInit, ViewChild } from '@angular/core';
import { CepTranferService } from '../../../services/cep.service';
import { DataTransferService } from '@santander/flame-core-library';
import { TransferThirdPartiesExecuteResponse } from '../../../models';
import {
	DialogReference,
	DialogService
} from '@santander/flame-component-library';

@Component({
	selector: 'sm-voucher-others-banks',
	templateUrl: './voucher-others-banks.component.html',
	styleUrls: ['./voucher-others-banks.component.scss']
})
export class TranfersVoucherOthersBanksComponent implements OnInit {
	// Elementos DOM
	@ViewChild('containerinfo') containerInfo;

	// Variables
	public pathRepeat: Array<number>;
	public dialogRef: DialogReference;

	// Control
	public showMore = false;
	public dataVoucher = {
		key: '',
		confirmation_number: '',
		effective_date: '',
		status: '',
		type: '',
		from_account: {
			key: '',
			url: '',
			type: '',
			alias: '',
			display_card: '',
			bank: ''
		},
		to_account: {
			key: '',
			url: '',
			type: '',
			alias: '',
			display_card: '',
			bank: ''
		},
		amount: {
			currency_code: '',
			amount: 0
		},
		concept: '',
		reference: '',
		creation_date: '',
		epp_url: '',
		personal_identifier_beneficiary: ''
	};

	constructor(
		private _cepTranferService: CepTranferService,
		private _dataBehaviorTransferService: DataTransferService,
		private dialog: DialogService
	) {}

	ngOnInit() {
		this.creaDiviciones();
		this._dataBehaviorTransferService.getData().then(res => {
			this.dataVoucher = res;
		});
	}

	creaDiviciones() {
		const temporal =
			parseInt(
				(this.containerInfo.nativeElement.offsetWidth / 30).toString(),
				10
			) + 1;
		this.pathRepeat = Array(temporal)
			.fill(0)
			.map((x, i) => i);
	}

	/**
	 * se abre la nueva pantalla a banxico.org.mx/cep
	 *
	 * @memberof TranfersVoucherOthersBanksComponent
	 */
	openWindowCep() {
		this.dialogRef = this.dialog.open({
			closeLabel: 'Cancelar',
			title: 'Redirección a otro sitio',
			body: `<div>
              <img src="assets/icons/icon-nodisponible.jpg" alt="" />
              <p class="mb-4 mt-4">
                Estás por salir de la aplicación para consultar
                la información en tu navegador ¿Deseas ir?
              </p>
             </div>`,
			enableHr: false,
			disabledButton: true,
			buttons: [
				{
					label: 'Si, llévame al otro sitio',
					class: 'strech',
					action: scope => {
						// aqui se redirecciona al sitio fuera de la aplicación
						// se realizara un logout
						window.open(this.dataVoucher.epp_url, '_blank');
					}
				}
			]
		});
	}
}
