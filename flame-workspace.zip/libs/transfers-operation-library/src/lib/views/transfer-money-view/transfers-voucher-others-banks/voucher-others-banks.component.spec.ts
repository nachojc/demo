import {
	async,
	ComponentFixture,
	TestBed,
	inject
} from '@angular/core/testing';
import { TranfersVoucherOthersBanksComponent } from './voucher-others-banks.component';
import {
	IconModule,
	AvatarModule,
	EmojiModule,
	IconButtonModule,
	ThemeModule,
	FlameFoundationTheme,
	DialogService,
	DialogModule,
	CheckboxModule
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { DataTransferService } from '@santander/flame-core-library';
import * as data from '../../../../../../../apps/super-mobile/api/middlewares/data';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { DialogErrorComponent } from '../../../components/dialog-dummy/dialog-dummy.component';

describe('TranfersVoucherOthersBanksComponent', () => {
	let component: TranfersVoucherOthersBanksComponent;
	let fixture: ComponentFixture<TranfersVoucherOthersBanksComponent>;
	let serviceBehavior: DataTransferService;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				IconModule,
				RouterTestingModule.withRoutes([]),
				AvatarModule,
				EmojiModule,
				IconModule,
				IconButtonModule,
				DialogModule,
				NoopAnimationsModule,
				CheckboxModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				})
			],
			declarations: [TranfersVoucherOthersBanksComponent, DialogErrorComponent],
			providers: [DataTransferService, DialogService, DialogErrorComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TranfersVoucherOthersBanksComponent);
		serviceBehavior = TestBed.get(DataTransferService);
		const copyDataVoucher = Object.assign(
			{},
			data.transfersThirdPartiesExecute
		);
		copyDataVoucher.personal_identifier_beneficiary = 'BOCJ941031';
		serviceBehavior.sendData(copyDataVoucher);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('should create the service', () => {
		serviceBehavior.getData().then(response => {
			component.dataVoucher = response;
			expect(serviceBehavior).toBeTruthy();
		});
		fixture.detectChanges();
	});

	it('should show the data in the voucher', () => {
		expect(component.dataVoucher).toBeTruthy();
		fixture.detectChanges();
	});

	it('should redirect cep', () => {
		TestBed.get(DialogErrorComponent);
		const dialog = TestBed.get(DialogService);
		spyOn(dialog, 'open').and.callFake(() => {});
		spyOn(component.closeEvent, 'subscribe').and.returnValue(false);
		spyOn(component, 'openWindowCep').and.callThrough();
		component.openWindowCep();
		fixture.detectChanges();
	});

	it('should close', inject([Router], (router: Router) => {
		const event = 350;
		component.close(event);
		fixture.detectChanges();
		router.navigate(['/summary/global-position']);
	}));
});
