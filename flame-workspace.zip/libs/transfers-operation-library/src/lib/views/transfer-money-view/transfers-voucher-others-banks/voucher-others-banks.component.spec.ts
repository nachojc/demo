import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TranfersVoucherOthersBanksComponent } from './voucher-others-banks.component';
import {
	IconModule,
	AvatarModule,
	EmojiModule,
	IconButtonModule,
	ThemeModule,
	FlameFoundationTheme,
	DialogService,
	DialogModule
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { DataTransferService } from '@santander/flame-core-library';
import * as data from '../../../../../../../apps/super-mobile/api/middlewares/data';

describe('TranfersVoucherOthersBanksComponent', () => {
	let component: TranfersVoucherOthersBanksComponent;
	let fixture: ComponentFixture<TranfersVoucherOthersBanksComponent>;
	let serviceBehavior: DataTransferService;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				IconModule,
				RouterTestingModule.withRoutes([]),
				AvatarModule,
				EmojiModule,
				IconModule,
				IconButtonModule,
				DialogModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				})
			],
			declarations: [TranfersVoucherOthersBanksComponent],
			providers: [DataTransferService, DialogService]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TranfersVoucherOthersBanksComponent);
    serviceBehavior = TestBed.get(DataTransferService);
    const copyDataVoucher = Object.assign({}, data.transfersThirdPartiesExecute);
    copyDataVoucher.personal_identifier_beneficiary = 'BOCJ941031';
		serviceBehavior.sendData(copyDataVoucher);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('should create the service', () => {
		serviceBehavior.getData().then(response => {
			component.dataVoucher = response;
			expect(serviceBehavior).toBeTruthy();
		});
		fixture.detectChanges();
	});

	it('should show the data in the voucher', () => {
		expect(component.dataVoucher).toBeTruthy();
		fixture.detectChanges();
	});
});
