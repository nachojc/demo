import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TranfersVoucherOthersBanksComponent } from './voucher-others-banks.component';

describe('TransfersVoucherComponent', () => {
	let component: TranfersVoucherOthersBanksComponent;
	let fixture: ComponentFixture<TranfersVoucherOthersBanksComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TranfersVoucherOthersBanksComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TranfersVoucherOthersBanksComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
