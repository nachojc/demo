import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TranfersOthersBanksComponent } from './tranfers-others-banks.component';

describe('TranfersOthersBanksComponent', () => {
	let component: TranfersOthersBanksComponent;
	let fixture: ComponentFixture<TranfersOthersBanksComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TranfersOthersBanksComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TranfersOthersBanksComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
