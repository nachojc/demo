import {
	async,
	ComponentFixture,
	TestBed,
	inject,
	fakeAsync
} from '@angular/core/testing';
import { TranfersOthersBanksComponent } from './tranfers-others-banks.component';
import { TransfersOperationLibraryRoutingModule } from '../../../transfers-operation-library.router.module';
import {
	AvatarModule,
	AmountFieldModule,
	RadioButtonModule,
	ProductModule,
	ButtonModule,
	MotiveFieldModule,
	IconButtonModule,
	IconModule,
	DialogModule,
	TokenInputModule,
	SlideButtonModule,
	SearchBarModule,
	TokenDialogModule,
	TopBarModule,
	ThemeModule,
	FlameFoundationTheme,
	FormFieldModule,
	InputModule,
	ContactListModule,
	AccountSelectModule,
	ChipModule,
	EmojiModule,
	ContactDialogModule,
	ContactDialogService,
	TokenDialogService,
	AutoWidthInputModule,
	ErrorsModule,
	CheckboxModule,
	HeaderAnimationModule
} from '@santander/flame-component-library';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgxMaskModule } from 'ngx-mask';
import { TransfersOperationLibraryComponents } from '../../../components/transfers-operation-library-components';
import { TransfersOperationLibraryViews } from '../../transfers-operation-library-views';
import { SearchFilterPipe } from '../../../pipes/search-filter.pipe';
import { AccountsFilterPipe } from '../../../pipes/search-accounts.pipe';
import { TransfersOtherBanksService } from '../../../services/transfer-other-banks.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { Injector, DebugElement } from '@angular/core';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { CepTranferService } from '../../../services/cep.service';
import * as data from '../../../../../../../apps/super-mobile/api/middlewares/data';
import { PayeeInfo, accounts, DataFakeVoucher } from '../fake-info';
import { By } from '@angular/platform-browser';
import {
	HttpClientTestingModule,
	HttpTestingController
} from '@angular/common/http/testing';
import { of } from 'rxjs';
import { Router } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('TranfersOthersBanksComponent', () => {
	let component: TranfersOthersBanksComponent;
	let fixture: ComponentFixture<TranfersOthersBanksComponent>;
	let payeeInfo: any;
	let formBuilder: FormBuilder;
	let transfersOtherBanksService: TransfersOtherBanksService
	let tokenDialogService: TokenDialogService;
	const contactPayee = {
		type: 'Payee',
		value: {
			personal_identifier : undefined,
			account: {
				bank: 'SCOTIABANK',
				number: '5179921863843075',
				account_type: 'THIRDPARTY_DEBIT_CARD'
			},
			alias: 'The Fourth',
			key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
			name: 'Jack Jacobs',
			url: '/beneficiaries/{beneficiary-key}'
		}
	};
	const transferProducts:any = {
		"data": {
		  "key": "4e20fbb243684d9eb19ff33a50ee422f",
		  "accounts": [{
			  "key": "4e20fbb243684d9eb19ff33a50ee422e",
			  "url": "/accounts/{account-key}",
			  "type": "DEBIT",
			  "alias": "My account",
			  "display_number": "9**1234",
			  "bank": "Banamex",
			  "name": "Ahorro",
			  "main_balance": {
				"currency_code": "MXN",
				"amount": 123456
			  },
			  "balance": {
				"currency_code": "MXN",
				"amount": 50000
			  },
			  "category_name": "DEBIT_ACCOUNTS"
			}
			]
		},
		"notifications": [
			{
			  "code": "E422CDNPAYRCPTG001",
			  "description": "Something happened.",
			  "timestamp": "2019-02-16T23:38:45.408Z"
			}
		  ]
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				TransfersOperationLibraryRoutingModule,
				AvatarModule,
				AmountFieldModule,
				RadioButtonModule,
				ProductModule,
				ButtonModule,
				FormsModule,
				MotiveFieldModule,
				IconButtonModule,
				CommonModule,
				HttpClientModule,
				IconModule,
				DialogModule,
				TokenInputModule,
				SlideButtonModule,
				TokenDialogModule,
				SearchBarModule,
				RouterTestingModule.withRoutes([
				]),
				TopBarModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				NgxMaskModule.forRoot(),
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				ContactListModule,
				AccountSelectModule,
				ChipModule,
				EmojiModule,
				ContactDialogModule,
				AutoWidthInputModule,
				ErrorsModule,
				HttpClientTestingModule,
				CheckboxModule,
				HeaderAnimationModule,
				BrowserAnimationsModule
			],
			declarations: [
				...TransfersOperationLibraryComponents,
				...TransfersOperationLibraryViews,
				SearchFilterPipe,
				AccountsFilterPipe
			],
			providers: [
				TransfersOtherBanksService,
				CepTranferService,
				ContactDialogService,
				TokenDialogService,
				BeneficiaryService,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: '',
							version: {}
						}
					}
				},
				{ provide: Injector, useValue: {} }
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TranfersOthersBanksComponent);
		component = fixture.componentInstance;
		payeeInfo = PayeeInfo;
		formBuilder = new FormBuilder();
		transfersOtherBanksService = TestBed.get(TransfersOtherBanksService);
		tokenDialogService = TestBed.get(TokenDialogService);
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should be ngOnInit', () => {
		spyOn(component, 'initialTransfer').and.callThrough();
		component.ngOnInit();
		expect(component.initialTransfer).toHaveBeenCalledWith(payeeInfo.key);
		spyOn(component, 'tranfersFormBuilder');
		component.ngOnInit();
		spyOn(component, 'tokenHandling');
		component.ngOnInit();
		expect(component.tokenHandling).toHaveBeenCalled();
	});

	it('shoul be initial the transfer', () => {
		const personalContact = {data : {...contactPayee, personal_identifier:'1234567'}};
		const serviceInitializeSpy = spyOn(transfersOtherBanksService,'initializeNewTransfer').and.returnValues(of(transferProducts));
		const seviceGetKeySpy = spyOn(transfersOtherBanksService,'getInfoByKey').and.returnValues(of(personalContact));
		component.initialTransfer(payeeInfo.key);
		expect(serviceInitializeSpy).toHaveBeenCalled();
		expect(seviceGetKeySpy).toHaveBeenCalled();
	});




	it('shoul be get the info for the beneficiary by the key', () => {
		inject(
			[HttpTestingController, BeneficiaryService],
			(
				httpMock: HttpTestingController,
				serviceBeneficiary: BeneficiaryService
			) => {
				const urlBeneficiary = '/transfers/payees';
				serviceBeneficiary.getInfoByKey(payeeInfo.key).subscribe(res => {
					expect(res).toEqual(data.beneficiaryByKey);
				});
				const req = httpMock.expectOne(urlBeneficiary);
				expect(req.request.method).toBe('GET');
				expect(req.request.responseType).toEqual('json');
				req.flush(data.beneficiaryByKey);
			}
		);
		expect(component.initialTransfer).toBeTruthy();
	});

	it('should be tranfersFormBuilder', () => {
		spyOn(component, 'tranfersFormBuilder');
		component.tranfersFormBuilder();
		component.tranfersForm = formBuilder.group({
			numReference: formBuilder.control(null),
			rfc: formBuilder.control(null),
			curp: formBuilder.control(null),
			rfccurpbeneficiary: formBuilder.control(null),
			amount: formBuilder.control(null)
		});
		expect(component.tranfersFormBuilder).toHaveBeenCalled();
	});


	it('should evaluate enabled button', () =>{

		let result = component.evaluateAndSetValue('amount','');
		result = component.evaluateAndSetValue('amount','');
		result = component.evaluateAndSetValue('reference','123456');
		result = component.evaluateAndSetValue('reference','test');
	});


	it('shoul create request for the put service', () => {
		spyOn(component, 'createRequestForPut');
		component.createRequestForPut();
		expect(component.createRequestForPut).toHaveBeenCalled();
	});

	it('should call put transfer', ()=>{
		const executeTransferSpy = spyOn(transfersOtherBanksService,'executeTransfer').and.returnValues(of(DataFakeVoucher));
		const router = TestBed.get(Router);
		const routerSpy = spyOn(router, 'navigate');

		component.isBeneficiary = false;
		component.beneficiaryByKey = {data : { account : contactPayee.value.account, personal_identifier: '123456' }};
		component.transferInitResponse = transferProducts;
		component.amount = 100;
		component.accounts = transferProducts.data.accounts;
		component.selectAccount(transferProducts.data.accounts[0]);
		component.putDataTransfer();
	});

	it('Mostrar lista de contactos', () => {
		spyOn(component, 'stateContactView').and.callThrough();
		component.stateContactView();
		fixture.detectChanges();
		expect(component.stateContactView).toHaveBeenCalled();
	})

	it('Open Dialog Event', () =>{
		spyOn(component, 'openTokenDialog').and.callThrough();
		component.openTokenDialog()
		fixture.detectChanges();
		expect(component.openTokenDialog).toHaveBeenCalled();
	})

});
