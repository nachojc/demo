
import {
	async,
	ComponentFixture,
	TestBed,
	inject
} from '@angular/core/testing';
import { TranfersOthersBanksComponent } from './tranfers-others-banks.component';
import { TransfersOperationLibraryRoutingModule } from '../../../transfers-operation-library.router.module';
import {
	AvatarModule,
	AmountFieldModule,
	RadioButtonModule,
	ProductModule,
	ButtonModule,
	MotiveFieldModule,
	IconButtonModule,
	IconModule,
	DialogModule,
	TokenInputModule,
	SlideButtonModule,
	SearchBarModule,
	TokenDialogModule,
	TopBarModule,
	ThemeModule,
	FlameFoundationTheme,
	FormFieldModule,
	InputModule,
	ContactListModule,
	AccountSelectModule,
	ChipModule,
	EmojiModule,
	ContactDialogModule,
	ContactDialogService,
	TokenDialogService
} from '@santander/flame-component-library';
import { FormsModule, ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgxMaskModule } from 'ngx-mask';
import { AutoWidthInputModule } from 'libs/flame-component-library/src/lib/atoms/auto-width-input/auto-width-input.module';
import { ErrorsModule } from 'libs/flame-component-library/src/lib/atoms/errors/errors.module';
import { TransfersOperationLibraryComponents } from '../../../components/transfers-operation-library-components';
import { TransfersOperationLibraryViews } from '../../transfers-operation-library-views';
import { SearchFilterPipe } from '../../../pipes/search-filter.pipe';
import { AccountsFilterPipe } from '../../../pipes/search-accounts.pipe';
import { TransfersOtherBanksService } from '../../../services/transfer-other-banks.service';
import { RouterTestingModule } from '@angular/router/testing';
import { ENV_CONFIG } from '@santander/flame-core-library';
import { Injector, DebugElement } from '@angular/core';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { CepTranferService } from '../../../services/cep.service';
import * as data from '../../../../../../../apps/super-mobile/api/middlewares/data';
import { PayeeInfo } from '../fake-info';
import { By } from '@angular/platform-browser';
import {
	HttpClientTestingModule,
	HttpTestingController
} from '@angular/common/http/testing';

describe('TranfersOthersBanksComponent', () => {
	let component: TranfersOthersBanksComponent;
	let fixture: ComponentFixture<TranfersOthersBanksComponent>;
	let payeeInfo: any;
	let formBuilder: FormBuilder;
	let debugElement: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				TransfersOperationLibraryRoutingModule,
				AvatarModule,
				AmountFieldModule,
				RadioButtonModule,
				ProductModule,
				ButtonModule,
				FormsModule,
				MotiveFieldModule,
				IconButtonModule,
				CommonModule,
				HttpClientModule,
				IconModule,
				DialogModule,
				TokenInputModule,
				SlideButtonModule,
				TokenDialogModule,
				SearchBarModule,
				RouterTestingModule.withRoutes([]),
				TopBarModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				NgxMaskModule.forRoot(),
				ReactiveFormsModule,
				FormFieldModule,
				InputModule,
				ContactListModule,
				AccountSelectModule,
				ChipModule,
				EmojiModule,
				ContactDialogModule,
				AutoWidthInputModule,
				ErrorsModule,
				HttpClientTestingModule
			],
			declarations: [
				...TransfersOperationLibraryComponents,
				...TransfersOperationLibraryViews,
				SearchFilterPipe,
				AccountsFilterPipe
			],
			providers: [
				TransfersOtherBanksService,
				CepTranferService,
				ContactDialogService,
				TokenDialogService,
				BeneficiaryService,
				{
					provide: ENV_CONFIG,
					useValue: {
						baas: {}
					}
				},
				{ provide: Injector, useValue: {} }
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TranfersOthersBanksComponent);
		component = fixture.componentInstance;
		payeeInfo = PayeeInfo;
		formBuilder = new FormBuilder();
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should be ngOnInit', () => {
		spyOn(component, 'initialTransfer');
		component.ngOnInit();
		expect(component.initialTransfer).toHaveBeenCalledWith(payeeInfo.key);
		spyOn(component, 'tranfersFormBuilder');
		component.ngOnInit();
		expect(component.tranfersFormBuilder).toHaveBeenCalled();
		spyOn(component, 'selectChipOption');
		component.ngOnInit();
		expect(component.selectChipOption).toHaveBeenCalledWith('2');
		spyOn(component, 'tokenHandling');
		component.ngOnInit();
		expect(component.tokenHandling).toHaveBeenCalled();
	});

	it('shoul be initial the transfer', () => {
		spyOn(component, 'initialTransfer');
		component.initialTransfer(payeeInfo.key);
		inject(
			[HttpTestingController, TransfersOtherBanksService],
			(
				httpMock: HttpTestingController,
				serviceTransfer: TransfersOtherBanksService
			) => {
				const urlTransfers = '/transfers/third-parties';
				serviceTransfer
					.initializeNewTransfer({ default_account_key: payeeInfo.key })
					.subscribe(res => {
						expect(res).toEqual(data.transfersThirdPartiesInitial);
						component.transferInitResponse = data.transfersThirdPartiesInitial;
					});
				const req = httpMock.expectOne(urlTransfers);
				expect(req.request.method).toBe('POST');
				expect(req.request.responseType).toEqual('json');
				req.flush(data.transfersThirdPartiesInitial);
			}
		);
		expect(component.initialTransfer).toHaveBeenCalledWith(payeeInfo.key);
	});

	it('shoul be get the info for the beneficiary by the key', () => {
		inject(
			[HttpTestingController, BeneficiaryService],
			(
				httpMock: HttpTestingController,
				serviceBeneficiary: BeneficiaryService
			) => {
				const urlBeneficiary = '/transfers/payees';
				serviceBeneficiary.getInfoByKey(payeeInfo.key).subscribe(res => {
					expect(res).toEqual(data.beneficiaryByKey);
				});
				const req = httpMock.expectOne(urlBeneficiary);
				expect(req.request.method).toBe('GET');
				expect(req.request.responseType).toEqual('json');
				req.flush(data.beneficiaryByKey);
			}
		);
		expect(component.initialTransfer).toBeTruthy();
	});

	it('should be tranfersFormBuilder', () => {
		spyOn(component, 'tranfersFormBuilder');
		component.tranfersFormBuilder();
		component.tranfersForm = formBuilder.group({
			numReference: formBuilder.control(null),
			rfc: formBuilder.control(null),
			curp: formBuilder.control(null),
			rfccurpbeneficiary: formBuilder.control(null),
			amount: formBuilder.control(null)
		});
		expect(component.tranfersFormBuilder).toHaveBeenCalled();
	});

	it('should be selectChipOption', () => {
		spyOn(component, 'selectChipOption');
		component.selectedChip = String(Math.floor(Math.random() * 2 + 1));
		component.selectChipOption(component.selectedChip);
		debugElement = fixture.debugElement.query(By.css('#chip'));
		switch (component.selectedChip) {
			case '1':
				expect(debugElement.nativeElement.classList.contains('default')).toBe(
					true
				);
				break;
			case '2':
				expect(debugElement.nativeElement.classList.contains('active')).toBe(
					false
				);
				break;
		}
		component.tranfersForm.controls['rfc'].setValue('BOCJ941031');
		component.tranfersForm.controls['curp'].setValue('BOCJ941031HHGTRC02');
		expect(component.selectChipOption).toHaveBeenCalled();
	});

	it('shoul create request for the put service', () => {
		spyOn(component, 'createRequestForPut');
		component.createRequestForPut();
		expect(component.createRequestForPut).toHaveBeenCalled();
	});
});
