// NPM dep
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TokenDialogService } from '@santander/flame-component-library';
import { PayeeInfo } from '../fake-info';
import { TransfersOtherBanksService } from '../../../services/transfer-other-banks.service';
import {
	TransferInitResponse,
	TransferThirdPartiesExecuteResponse
} from '../../../models';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { TransferThirdpartiesExecuteRequest } from '../../../models/transfer-thirdparties-execute-request';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';
import {
	Products,
	SummaryResponse,
	Summary
} from 'libs/summary-operation-library/src/lib/models';

@Component({
	selector: 'sm-transfers-others-banks',
	templateUrl: './tranfers-others-banks.component.html',
	styleUrls: ['./tranfers-others-banks.component.scss']
})
export class TranfersOthersBanksComponent implements OnInit {
	// variables
	tranfersForm: FormGroup;
	selectedChip: string;
	isBeneficiary = false;
	isDisabledSelectAccount = false;
	isDisabledButton = true;
	iconActive: string;
	amount: number;
	motive = 'Transferencia';
	beneficiaryByKey: any;
	transferInitResponse: TransferInitResponse;
	accounts: Array<Products> = [];
	account: any = {};
	productChange: Products;
	fromAccountKey: string;
	errorCustomMessage = '';

	// images card
	cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];

	// @Input/ @Output
	@Input() keyPayee: string;
	@Input() infoPayee: any;
	@Output() emitInfoTransfer = new EventEmitter<any>();

	constructor(
		private router: Router,
		private formBuilder: FormBuilder,
		public tokenDialogService: TokenDialogService,
		private _transfersOtherBanksService: TransfersOtherBanksService,
		private _dataBehaviorTransferService: DataTransferService,
		private _beneficiaryService: BeneficiaryService,
		private _summaryService: SummaryService
	) {}

	ngOnInit() {
		if (this.infoPayee === undefined) {
			this.infoPayee = PayeeInfo;
		}
		this.initialTransfer(this.infoPayee.key);
		this.tranfersFormBuilder();
		this.selectChipOption('2');
		this.tokenHandling();
		this.getSumaryAccounts();
	}

	tranfersFormBuilder() {
		this.tranfersForm = this.formBuilder.group({
			numReference: this.formBuilder.control(null),
			rfc: this.formBuilder.control(null),
			curp: this.formBuilder.control(null),
			rfccurpbeneficiary: this.formBuilder.control(null)
		});
	}

	selectChipOption(num: string) {
		this.selectedChip = num;
		// solución temporal para el RFC ó CURP del titula de la cuenta
		this.tranfersForm.get('rfc').setValue('BOCJ941031');
		this.tranfersForm.get('curp').setValue('BOCJ941031HHGTRC02');
	}

	private tokenHandling() {
		this.tokenDialogService.getConfirmEvent().subscribe(res => {
			setTimeout(() => {
				if (res.ok === 200) {
					this.tokenDialogService.closeDialogToken();
					this.postDataTransfer();
				}
			}, 1000);
		});
	}

	initialTransfer(key: string) {
		//se inicializa la tranferencia y se recuperan los datos necesario para la transferencia
		this._transfersOtherBanksService
			.initializeNewTransfer({ default_account_key: key })
			.subscribe(
				(res: TransferInitResponse) => {
					this.transferInitResponse = res;
				},
				error => {
					// manejo de error
					console.log('error', error);
				}
			);
		//  aqui se obtiene informacion de beneficiario como la curp, el bank
		this._beneficiaryService.getInfoByKey(this.infoPayee.key).subscribe(res => {
			this.beneficiaryByKey = res;
			this.tranfersForm
				.get('rfccurpbeneficiary')
				.setValue(this.beneficiaryByKey.data.personal_identifier);
		});
	}

	getSumaryAccounts() {
		this._summaryService.getSummary().subscribe((response: SummaryResponse) => {
			response.data.map((summary: Summary) => {
				if (summary.category_name === 'CHECKING_ACCOUNTS') {
					this.accounts = summary.products;
					this.setImages(this.accounts);
				}
			});
		});
	}

	setImages(products: any) {
		products.map((item: any) => {
			item.card_type = this.cardImages[
				Math.floor(Math.random() * this.cardImages.length)
			];
			item.product = {
				description: item.description
			};
			item.number = item.display_number;
		});
	}

	selectAccount(evtProduct: Products) {
		this.productChange = evtProduct;
		this.fromAccountKey = evtProduct.key;
		this.evaluateAndSetValue('otherProduct', null);
	}

	withBeneficiary() {
		this.isBeneficiary = !this.isBeneficiary;
		return this.isBeneficiary
			? (this.iconActive = 'sn-check')
			: (this.iconActive = '');
	}

	evaluateAndSetValue(inputValidate: string, evtInputValue: string) {
		switch (inputValidate) {
			case 'amount':
				this.amount = Number(evtInputValue);
				if (
					this.amount > 0 &&
					this.motive !== '' &&
					this.motive !== undefined &&
					this.productChange.balance.amount !== 0
				) {
					this.isDisabledButton = false;
				} else {
					this.isDisabledButton = true;
				}
				break;
			case 'motive':
				this.motive = evtInputValue;
				if (
					this.motive !== undefined &&
					this.motive !== '' &&
					this.amount > 0 &&
					this.productChange.balance.amount !== 0
				) {
					this.isDisabledButton = false;
				} else {
					this.isDisabledButton = true;
				}
				break;
			case 'otherProduct':
				if (this.productChange.balance !== undefined) {
					if (this.productChange.balance.amount === 0) {
						this.isDisabledSelectAccount = true;
						this.isDisabledButton = true;
						this.errorCustomMessage =
							' No cuentas con la cantidad ingresada en esta cuenta. Selecciona otra.';
					} else {
						if (
							this.motive !== undefined &&
							this.motive !== '' &&
							this.amount > 0
						) {
							this.isDisabledButton = false;
						}
						this.isDisabledSelectAccount = false;
						this.errorCustomMessage = '';
					}
				}
				break;
		}
	}

	evaluateForEmit() {
		this.emitInfoTransfer.emit(this.setDataSend());
	}

	setDataSend() {
		return {
			from_account_key: this.fromAccountKey,
			to_account_key: this.infoPayee.key,
			amount: {
				currency_code: this.productChange.balance.currency_code,
				amount: Number(this.amount)
			},
			concept: this.motive,
			reference: this.tranfersForm.get('numReference').value,
			effective_date: String(new Date()),
			bank: this.beneficiaryByKey.data.account.bank,
			personal_identifier_beneficiary: this.isBeneficiary
				? this.tranfersForm.get('rfccurpbeneficiary').value
				: null
		};
	}

	postDataTransfer() {
		this._transfersOtherBanksService
			.executeTransfer(
				this.transferInitResponse.data.key, // key de la tranferencia
				this.setDataSend()
			)
			.subscribe(
				(response: TransferThirdPartiesExecuteResponse) => {
					this.copyResponseForVoucher(response);
				},
				error => {
					// manejo del error
					console.log('error', error);
				}
			);
	}

	copyResponseForVoucher(response: any) {
		const copy = Object.assign({}, response.data);
		copy.personal_identifier_beneficiary = this.beneficiaryByKey.data.personal_identifier;
		this._dataBehaviorTransferService.sendData(copy);
		this.router.navigate(['/transfers/voucher-others-banks']);
	}
}
