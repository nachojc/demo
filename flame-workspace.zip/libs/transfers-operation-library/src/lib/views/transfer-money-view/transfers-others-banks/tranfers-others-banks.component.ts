import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	ChangeDetectorRef,
	AfterViewChecked
} from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TokenDialogService } from '@santander/flame-component-library';
import { PayeeInfo } from '../fake-info';
import { TransfersOtherBanksService } from '../../../services/transfer-other-banks.service';
import {
	TransferInitResponse,
	TransferThirdPartiesExecuteResponse
} from '../../../models';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { Products } from 'libs/summary-operation-library/src/lib/models';

@Component({
	selector: 'sm-transfers-others-banks',
	templateUrl: './tranfers-others-banks.component.html',
	styleUrls: ['./tranfers-others-banks.component.scss']
})
export class TranfersOthersBanksComponent implements OnInit, AfterViewChecked {
	constructor(
		private router: Router,
		private formBuilder: FormBuilder,
		public tokenDialogService: TokenDialogService,
		private _transfersOtherBanksService: TransfersOtherBanksService,
		private _dataBehaviorTransferService: DataTransferService,
		private _beneficiaryService: BeneficiaryService,
		private cdRef: ChangeDetectorRef
	) {}

	private beneficiaryByKey: any;
	/**
	 * variable que contine la informacio de la consulta del beneficiario
	 *
	 * @type {FormGroup}
	 * @memberof TranfersOthersBanksComponent
	 */

	/**
	 *
	 * form group para los input del screen
	 * @type {FormGroup}
	 * @memberof TranfersOthersBanksComponent
	 */
	public tranfersForm: FormGroup;

	/**
	 *
	 * booleano que indica si el usiario incluye beneficiario
	 * @memberof TranfersOthersBanksComponent
	 */
	public isBeneficiary = false;

	/**
	 * booleano que indica que el selecAccount este desabilitado cuando no tenga fondos.
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	public isDisabledSelectAccount = false;

	/**
	 *
	 * booleano para habilitar o desabilitar el boton de continuar
	 * @memberof TranfersOthersBanksComponent
	 */
	public isDisabledButton = true;

	/**
	 * selector del icono
	 * ejemplo = 'sn-BAN92'
	 *
	 * @type {string}
	 * @memberof TranfersOthersBanksComponent
	 */
	public iconActive: string;

	/**
	 * valor del sn-amount-field
	 *
	 * @type {number}
	 * @memberof TranfersOthersBanksComponent
	 */
	public amount: number;

	/**
	 * variable para el limite maximo del la transferencia
	 * por ejemplo el total de la cuenta origen
	 * @type {number}
	 * @memberof TranfersOthersBanksComponent
	 */
	public maxLimit: number;

	/**
	 * valor del sn-motive-field
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	public motive = 'Transferencia';

	/**
	 * variable que almacena el resultado de la inicializacion de la transferecia.
	 *
	 * @type {TransferInitResponse}
	 * @memberof TranfersOthersBanksComponent
	 */
	public transferInitResponse: TransferInitResponse;

	/**
	 * variables para las cuentas que tiene el usuario
	 *
	 * @type {Array<Products>}
	 * @memberof TranfersOthersBanksComponent
	 */
	public accounts: Array<Products> = [];
	public account: any = {};

	/**
	 * variable que almacena el emit de la seleccion de otra cuenta origin de efectivo
	 *
	 * @type {Products}
	 * @memberof TranfersOthersBanksComponent
	 */
	public productChange: Products;

	/**
	 * key de la cuenta origen
	 *
	 * @type {string}
	 * @memberof TranfersOthersBanksComponent
	 */
	public fromAccountKey: string;

	/**
	 * array de imagen de la tarjeta
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	public cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];

	/**
	 * Input para le key del beneficiario
	 * este se obtiene del componente de initial y contact-widget
	 * @type {string}
	 * @memberof TranfersOthersBanksComponent
	 */
	@Input() keyPayee: string;

	/**
	 * Input para todos los datos del beneficiario provenientes de contact-widget
	 *
	 * @type {*}
	 * @memberof TranfersOthersBanksComponent
	 */
	@Input() infoPayee: any;

	/**
	 * Output que emite la informacion al momento de realizar un cambio de contacto al que se le va a transferir
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	@Output() showContactView = new EventEmitter<Boolean>();

	/**
	 * recibe la respuesta del token y ejecuta el post en caso de se run 200
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	tokenHandling() {
		this.tokenDialogService.getConfirmEvent().subscribe(response => {
			if (response.ok === 200) {
				this.tokenDialogService.closeDialogToken();
				this.putDataTransfer();
			}
		});
	}

	/**
	 * crear las propiedades de transferForm
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	tranfersFormBuilder() {
		this.tranfersForm = this.formBuilder.group({
			numReference: this.formBuilder.control(null),
			rfccurpbeneficiary: this.formBuilder.control(null),
			amount: this.formBuilder.control(null)
		});
	}

	/**
	 * se inicializa la transferencia y se obtine la informacion del beneficiario de acuerdo al key
	 *
	 * @param {string} key
	 * @memberof TranfersOthersBanksComponent
	 */
	initialTransfer(key: string) {
		this._transfersOtherBanksService
			.initializeNewTransfer({ default_account_key: key })
			.subscribe(
				(response: any) => {
					this.transferInitResponse = response;
          this.setDataSelectAccount(response);
					this._transfersOtherBanksService
						.getInfoByKey(this.infoPayee.key)
						.subscribe(res => {
							this.beneficiaryByKey = res;
							this.tranfersForm
								.get('rfccurpbeneficiary')
								.setValue(this.beneficiaryByKey.data.personal_identifier);
						});
				}
			);
	}

	/**
	 *
	 * Se setean los productos que tiene el usuario
	 * @param {TransferInitResponse} initResponse
	 * @memberof TranfersOthersBanksComponent
	 */
	setDataSelectAccount(initResponse: TransferInitResponse) {
		this.accounts = initResponse.data.accounts.map((item: any) => {
			return {
				key: item.key,
				description: item.name,
				display_number: item.display_number,
				balance: item.main_balance
			};
		});
		this.accounts.map((item: any) => {
			item.card_type = this.cardImages[
				Math.floor(Math.random() * this.cardImages.length)
			];
			item.product = {
				description: item.description
			};
			item.number = item.display_number;
		});
	}

	/**
	 * se recuperan los valore del cambio de cuenta origen
	 * se setea el limite al la propiedad amount del tranfersForm
	 *
	 * @param {Products} evtProduct
	 * @memberof TranfersOthersBanksComponent
	 */
	selectAccount(evtProduct: Products) {
		this.productChange = evtProduct;
		this.fromAccountKey = evtProduct.key;
		if (this.productChange.balance !== undefined) {
			this.maxLimit = this.productChange.balance.amount;
			this.tranfersForm
				.get('amount')
				.setValidators([Validators.max(this.maxLimit), Validators.min(0)]);
		}
		this.evaluateAndSetValue('otherProduct', null);
	}

	/**
	 *
	 * Cambio de icono cuando incluye beneficioario
	 * @returns
	 * @memberof TranfersOthersBanksComponent
	 */
	withBeneficiary() {
		this.isBeneficiary = !this.isBeneficiary;
		return this.isBeneficiary
			? (this.iconActive = 'sn-SMOV18')
			: (this.iconActive = '');
	}

	/**
	 * Se evalua las direnentes formas de habilitar el button de contuniar
	 *
	 * @param {string} inputValidate
	 * @param {*} evtInputValue
	 * @memberof TranfersOthersBanksComponent
	 */
	evaluateAndSetValue(inputValidate: string, evtInputValue: any) {
		switch (inputValidate) {
			case 'amount':
				this.amount = this.tranfersForm.get('amount').value;
				this.isDisabledButton =
					this.amount > 0 &&
					this.motive !== '' &&
					this.motive !== undefined &&
					this.productChange.balance.amount !== 0 &&
					this.amount <= this.maxLimit
						? false
						: true;
				break;
			case 'motive':
				this.motive =
					evtInputValue !== undefined &&
					evtInputValue.target.className === 'sn-FUNC31'
						? (this.motive = undefined)
						: this.motive;
				this.isDisabledButton =
					this.motive !== undefined &&
					this.motive !== '' &&
					this.amount > 0 &&
					this.productChange.balance.amount !== 0 &&
					this.amount <= this.maxLimit
						? false
						: true;
				break;
			case 'otherProduct':
				if (this.productChange.balance !== undefined) {
					if (this.productChange.balance.amount <= 0) {
						this.isDisabledSelectAccount = true;
						this.isDisabledButton = true;
					} else {
						if (
							this.motive !== undefined &&
							this.amount > 0 &&
							this.amount <= this.maxLimit
						) {
							this.isDisabledButton = false;
						}
						this.isDisabledSelectAccount = false;
					}
				}
				break;
			case 'reference':
				if (new RegExp(/^[0-9]+$/).test(evtInputValue)) {
					return true;
				} else {
					return false;
				}
		}
	}

	/**
	 * funcion para emitir la informacion en caso de cambio de cuenta del beneficiario
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	stateContactView() {
		this.showContactView.emit(true);
	}

	/**
	 * se crear el request para el servio de put o del emit
	 *
	 * @returns {*}
	 * @memberof TranfersOthersBanksComponent
	 */
	createRequestForPut(): any {
		return {
			from_account_key: this.fromAccountKey,
			to_account_key: this.infoPayee.key,
			amount: {
				currency_code: this.productChange.balance.currency_code,
				amount: Number(this.amount)
			},
			concept: this.motive,
			reference: this.tranfersForm.get('numReference').value,
			effective_date: String(new Date()),
			operation_type: 'TRANSFER',
			bank: this.beneficiaryByKey.data.account.bank
		};
	}

	/**
	 * se ejecuta el servicio del put
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	putDataTransfer() {
		this._transfersOtherBanksService
			.executeTransfer(
				this.transferInitResponse.data.key,
				this.createRequestForPut()
			)
			.subscribe(
				(response: TransferThirdPartiesExecuteResponse) => {
					this.copyResponseForVoucher(response);
				},
				error => {}
			);
	}

	/**
	 *
	 * se agregar el rfc del beneficiario para el voucher
	 * @param {*} response
	 * @memberof TranfersOthersBanksComponent
	 */
	copyResponseForVoucher(response: any) {
		const copy = Object.assign({}, response.data);
		copy.personal_identifier_beneficiary = this.beneficiaryByKey.data.personal_identifier;
		this._dataBehaviorTransferService.sendData(copy);
		this.router.navigate(['/transfers/voucher-others-banks']);
	}

	ngOnInit() {
		if (this.infoPayee === undefined) {
			this.infoPayee = PayeeInfo;
		}
		this.initialTransfer(this.infoPayee.key);
		this.tranfersFormBuilder();
		this.tokenHandling();
	}

	/**
	 * se detectan cambios
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	ngAfterViewChecked() {
		this.cdRef.detectChanges();
	}
}
