import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	ChangeDetectorRef,
	AfterViewChecked
} from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
	TokenDialogService,
	CustomToken,
	CustomDialog
} from '@santander/flame-component-library';
import { PayeeInfo } from '../fake-info';
import { TransfersOtherBanksService } from '../../../services/transfer-other-banks.service';
import {
	TransferInitResponse,
	TransferThirdPartiesExecuteResponse
} from '../../../models';
import { DataTransferService } from '@santander/flame-core-library';
import { Products } from 'libs/summary-operation-library/src/lib/models';
import { TokenConfirmComponent } from '../../../components/token-confirm/token-confirm.component';
import { timer } from 'rxjs';

@Component({
	selector: 'sm-transfers-others-banks',
	templateUrl: './tranfers-others-banks.component.html',
	styleUrls: ['./tranfers-others-banks.component.scss']
})
export class TranfersOthersBanksComponent implements OnInit, AfterViewChecked {
	constructor(
		private router: Router,
		private formBuilder: FormBuilder,
		public _tokenDialogService: TokenDialogService,
		private _transfersOtherBanksService: TransfersOtherBanksService,
		private _dataBehaviorTransferService: DataTransferService,
		private cdRef: ChangeDetectorRef
	) {}

	private tokenLocalStorage: boolean;
	public beneficiaryByKey: any;
	/**
	 * variable que contine la informacio de la consulta del beneficiario
	 *
	 * @type {FormGroup}
	 * @memberof TranfersOthersBanksComponent
	 */

	/**
	 *
	 * form group para los input del screen
	 * @type {FormGroup}
	 * @memberof TranfersOthersBanksComponent
	 */
	public tranfersForm: FormGroup;

	/**
	 * Dialog body para Token Dialog
	 */
	public dialogBody = {
		amount: 0,
		type: 2,
		toAccount: {
			name: '',
      account: '',
      bank: ''
		},
		fromAccount: {
			name: '',
			account: ''
		}
	};

	/**
	 *
	 * booleano que indica si el usiario incluye beneficiario
	 * @memberof TranfersOthersBanksComponent
	 */
	public isBeneficiary = false;

	/**
	 * booleano que indica que el selecAccount este desabilitado cuando no tenga fondos.
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	public isDisabledSelectAccount = false;

	/**
	 *
	 * booleano para habilitar o desabilitar el boton de continuar
	 * @memberof TranfersOthersBanksComponent
	 */
	public isDisabledButton = true;

	/**
	 * valor del sn-amount-field
	 *
	 * @type {number}
	 * @memberof TranfersOthersBanksComponent
	 */
	public amount: number;

	/**
	 * variable para el limite maximo del la transferencia
	 * por ejemplo el total de la cuenta origen
	 * @type {number}
	 * @memberof TranfersOthersBanksComponent
	 */
	public maxLimit: number;

	/**
	 * valor del sn-motive-field
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	public motive = 'Transferencia';

	/**
	 * variable que almacena el resultado de la inicializacion de la transferecia.
	 *
	 * @type {TransferInitResponse}
	 * @memberof TranfersOthersBanksComponent
	 */
	public transferInitResponse: TransferInitResponse;

	/**
	 * variables para las cuentas que tiene el usuario
	 *
	 * @type {Array<Products>}
	 * @memberof TranfersOthersBanksComponent
	 */
	public accounts: Array<Products> = [];
	public account: any = {};

	/**
	 * variable que almacena el emit de la seleccion de otra cuenta origin de efectivo
	 *
	 * @type {Products}
	 * @memberof TranfersOthersBanksComponent
	 */
	public productChange: Products;

	/**
	 * key de la cuenta origen
	 *
	 * @type {string}
	 * @memberof TranfersOthersBanksComponent
	 */
	public fromAccountKey: string;

	/**
	 * array de imagen de la tarjeta
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	public cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
	];

	/**
	 * Input para le key del beneficiario
	 * este se obtiene del componente de initial y contact-widget
	 * @type {string}
	 * @memberof TranfersOthersBanksComponent
	 */
	@Input() keyPayee: string;

	/**
	 * Input para todos los datos del beneficiario provenientes de contact-widget
	 *
	 * @type {*}
	 * @memberof TranfersOthersBanksComponent
	 */
	@Input() infoPayee: any;

	/**
	 * Output que emite la informacion al momento de realizar un cambio de contacto al que se le va a transferir
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	@Output() showContactView = new EventEmitter<Boolean>();

	private checkIfExistToken() {
		return localStorage.getItem('token')
			? (this.tokenLocalStorage = true)
			: (this.tokenLocalStorage = false);
	}

	/**
	 * recibe la respuesta del token y ejecuta el post en caso de se run 200
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	tokenHandling() {
		this._tokenDialogService.getConfirmEvent().subscribe(response => {
			if (response.ok === 200) {
				if (this.tokenLocalStorage) {
					this._tokenDialogService.setStatusSlide('success');
				}
				timer(600).subscribe(() => {
					this._tokenDialogService.closeDialogToken();
					this.putDataTransfer();
				});
			}
		});
	}

	/**
	 * crear las propiedades de transferForm
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	tranfersFormBuilder() {
		this.tranfersForm = this.formBuilder.group({
			numReference: this.formBuilder.control(null),
			rfccurpbeneficiary: this.formBuilder.control(null),
			amount: this.formBuilder.control(0)
		});
	}

	/**
	 * se inicializa la transferencia y se obtine la informacion del beneficiario de acuerdo al key
	 *
	 * @param {string} key
	 * @memberof TranfersOthersBanksComponent
	 */
	initialTransfer(key: string) {
		this._transfersOtherBanksService
			.initializeNewTransfer({
				default_account_key: key,
				operation_type: 'SANTANDER_THIRD_PARTIES'
			})
			.subscribe((response: any) => {
				this.transferInitResponse = response;
				this.setDataSelectAccount(response);
				this._transfersOtherBanksService
					.getInfoByKey(this.infoPayee.key)
					.subscribe(res => {
						this.beneficiaryByKey = res;
						if (this.beneficiaryByKey.data.personal_identifier) {
							this.tranfersForm
								.get('rfccurpbeneficiary')
								.setValue(this.beneficiaryByKey.data.personal_identifier);
							this.isBeneficiary = true;
						}
					});
			});
	}

	/**
	 *
	 * Se setean los productos que tiene el usuario
	 * @param {TransferInitResponse} initResponse
	 * @memberof TranfersOthersBanksComponent
	 */
	setDataSelectAccount(initResponse: TransferInitResponse) {
		this.accounts = initResponse.data.accounts.map((item: any) => {
			return {
				key: item.key,
				description: item.name,
				display_number: item.display_number,
				balance: item.main_balance
			};
		});
		this.accounts.map((item: any) => {
			item.card_type = this.cardImages[
				Math.floor(Math.random() * this.cardImages.length)
			];
			item.product = {
				description: item.description
			};
			item.number = item.display_number;
		});
	}

	/**
	 * se recuperan los valore del cambio de cuenta origen
	 * se setea el limite al la propiedad amount del tranfersForm
	 *
	 * @param {Products} evtProduct
	 * @memberof TranfersOthersBanksComponent
	 */
	selectAccount(evtProduct: Products) {
		this.productChange = evtProduct;
		this.fromAccountKey = evtProduct.key;
		if (this.productChange.balance !== undefined) {
			this.maxLimit = this.productChange.balance.amount;
			this.tranfersForm
				.get('amount')
				.setValidators([Validators.max(this.maxLimit), Validators.min(0)]);
		}
		this.evaluateAndSetValue('otherProduct', null);
	}

	/**
	 * Se evalua las direnentes formas de habilitar el button de contuniar
	 *
	 * @param {string} inputValidate
	 * @param {*} evtInputValue
	 * @memberof TranfersOthersBanksComponent
	 */
	evaluateAndSetValue(inputValidate: string, evtInputValue: any) {
		switch (inputValidate) {
			case 'amount':
				this.amount = this.tranfersForm.get('amount').value;
				this.isDisabledButton =
					this.amount > 0.0 &&
					this.motive !== '' &&
					this.motive !== undefined &&
					this.productChange.balance.amount !== 0 &&
					this.amount <= this.maxLimit
						? false
						: true;
				break;
			case 'motive':
				this.motive =
					evtInputValue !== undefined &&
					evtInputValue.target.className === 'sn-FUNC31'
						? (this.motive = undefined)
						: this.motive;
				break;
			case 'otherProduct':
				if (this.productChange.balance !== undefined) {
					if (this.productChange.balance.amount <= 0) {
						this.isDisabledSelectAccount = true;
						this.isDisabledButton = true;
					} else {
						if (
							this.motive !== undefined &&
							this.amount > 0 &&
							this.amount <= this.maxLimit
						) {
							this.isDisabledButton = false;
						}
						this.isDisabledSelectAccount = false;
					}
				}
				break;
			case 'reference':
				if (new RegExp(/^[0-9]+$/).test(evtInputValue)) {
					return true;
				} else {
					return false;
				}
		}
	}

	/**
	 * funcion para emitir la informacion en caso de cambio de cuenta del beneficiario
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	stateContactView() {
		this.showContactView.emit(true);
	}

	/**
	 * se crear el request para el servio de put o del emit
	 *
	 * @returns {*}
	 * @memberof TranfersOthersBanksComponent
	 */
	createRequestForPut(): any {
		return {
			from_account_key: this.fromAccountKey,
			to_account_key: this.infoPayee.key,
			amount: {
				currency_code: this.productChange.balance.currency_code,
				amount: Number(this.amount)
			},
			concept: this.motive,
			reference: this.tranfersForm.get('numReference').value,
			bank: this.beneficiaryByKey.data.account.bank
		};
	}

	/**
	 * se ejecuta el servicio del put
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	putDataTransfer() {

		this._transfersOtherBanksService
			.executeTransfer(
				this.transferInitResponse.data.key,
				this.createRequestForPut()
			)
			.subscribe(
				(response: TransferThirdPartiesExecuteResponse) => {
					this.copyResponseForVoucher(response);
				}
			);
	}

	/**
	 *
	 * se agregar el rfc del beneficiario para el voucher
	 * @param {*} response
	 * @memberof TranfersOthersBanksComponent
	 */
	copyResponseForVoucher(response: any) {
		const copy = Object.assign({}, response.data);
		copy.personal_identifier_beneficiary = this.isBeneficiary
			? this.beneficiaryByKey.data.personal_identifier
			: this.tranfersForm.get('rfccurpbeneficiary').value;
		this._dataBehaviorTransferService.sendData(copy);
		this.router.navigate(['/transfers/voucher-others-banks']);
	}

	openTokenDialog() {
		const params: CustomToken = {
			subtitle: 'Transferencia sin costo',
			title: 'Confirma con tu SuperToken',
			closeLabel: 'Ocultar',
			showTokenInput: this.tokenLocalStorage ? false : true,
			typeButton: this.tokenLocalStorage ? 'slide' : 'basic',
			customBody: new CustomDialog(
				TokenConfirmComponent,
				(this.dialogBody = {
					amount: this.amount,
					type: 2,
					toAccount: {
						name: this.infoPayee.name,
						bank: this.infoPayee.account.bank,
						account: this.infoPayee.account.number
					},
					fromAccount: {
						name: this.productChange.description,
						account: this.productChange.display_number
					}
				})
			)
		};
		this._tokenDialogService.openDialogToken(params);
	}

	ngOnInit() {
		if (this.infoPayee === undefined) {
			this.infoPayee = PayeeInfo;
		}
		this.checkIfExistToken();
		this.initialTransfer(this.infoPayee.key);
		this.tranfersFormBuilder();
		this.tokenHandling();
	}

	/**
	 * se detectan cambios
	 *
	 * @memberof TranfersOthersBanksComponent
	 */
	ngAfterViewChecked() {
		this.cdRef.detectChanges();
	}
}
