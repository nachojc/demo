export const PERSONAS: any[] = [
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	}
];

export const accounts = [
	{
		key: '056722751246',
		alias: null,
		description: 'Súper cuenta nómina',
		url: null,
		display_number: '*3400',
		related_phone: null,
		status: 'AVAILABLE',
		balance: {
			currency_code: 'MXP',
			amount: 142900
		}
	},
	{
		key: '056722733565',
		alias: null,
		description: 'Súper cuenta nómina',
		url: null,
		display_number: '*3356',
		related_phone: null,
		status: 'AVAILABLE',
		balance: {
			currency_code: 'MXP',
			amount: 50.5
		}
	}
];

export const PayeeInfo = {
	key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
	account: {
		number: '5179921863843075',
		type: 'THIRDPARTY_DEBIT_CARD',
		bank: 'SCOTIABANK'
	},
	name: 'Jack Jacobs Cruz',
	alias: 'The Fourth',
	url: '/beneficiaries/{beneficiary-key}'
};

export const DataFakeVoucher = {
	key: '4e20fbb243684d9eb19ff33a50ee422e',
	confirmation_number: '123456789',
	effective_date: '2019-02-16T23:38:45.408Z',
	status: 'PROCESSED',
	type: 'UNIQUE',
	from_account: {
		key: '4e20fbb243684d9eb19ff33a50ee422e',
		url: '/accounts/{account-key}',
		type: 'CHECKING',
		alias: 'My account fav',
		display_number: '9**1234',
		bank: 'Banamex',
		name: 'Ahorro',
		main_balance: {
			currency_code: 'MXN',
			amount: 123456
		}
	},
	to_payee: {
		key: '4e20fbb243684d9eb19ff33a50ee422e',
		url: '/accounts/{account-key}',
		type: 'CHECKING',
		alias: 'My account fav',
		display_number: '9**1234',
		bank: 'Santander',
		name: 'Súper cuenta santander',
		main_balance: {
			currency_code: 'MXN',
			amount: 123456
		}
	},
	amount: {
		currency_code: 'MXN',
		amount: 123456
	},
	concept: 'Pago de inscripción',
	reference: '3456789',
	creation_date: '2019-02-16T23:38:45.408Z',
  url_receipt: 'https://www.banxico.org.mx/cep/go?i=40127&s=20170913&d=FmKl6J4r7yTt200flFbMS6knW8a5nGsEMiESVKMPN9aVWW3UAMxpxlpVxvAFV%2B5RYgOVixbj5LULEctx7ylCTS%2BkTTYwU3ZQ73DHpjmFOzs%3D',
  customer_personal_identifier: 'HGTY311094FR7',
  tracking_number: '7834435',
  operation_type: 'SANTANDER_THIRD_PARTIES',
  personal_identifier_beneficiary: 'OCRJ9410319F4',
};
