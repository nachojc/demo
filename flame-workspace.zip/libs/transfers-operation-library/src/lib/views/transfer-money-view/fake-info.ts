export const PERSONAS: any[] = [
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	},
	{
		accountnumber: '759461390726548412', // fake info para clabe interbancaria
		bank: 'Bancomer',
		shortname: 'Daphna Elt',
		lastname: 'Elt',
		fullname: 'Daphna Elt Elt'
	},
	{
		accountnumber: '*9876', // fake info para cuenta
		bank: 'Scotiabank',
		shortname: 'Byrle Farfalameev',
		lastname: 'Farfalameev',
		fullname: 'Byrle Farfalameev Farfalameev'
	},
	{
		accountnumber: '77 2133 6196', // fake info para telefono
		bank: 'HSBC',
		shortname: 'Orella Towhey',
		lastname: 'Towhey',
		fullname: 'Orella Towhey Towhey'
	},
	{
		accountnumber: '3581-1581-9153-8146', // fake info para tarjeta de debito
		bank: 'Citibanamex',
		shortname: 'Leonhard Scalera',
		lastname: 'Scalera',
		fullname: 'Leonhard Scalera Scalera'
	}
];

export const accounts = [
	{
		key: '056722751246',
		alias: null,
		description: 'Súper cuenta nómina',
		url: null,
		display_number: '*3400',
		related_phone: null,
		status: 'AVAILABLE',
		balance: {
			currency_code: 'MXP',
			amount: 142900
		}
	},
	{
		key: '056722733565',
		alias: null,
		description: 'Súper cuenta nómina',
		url: null,
		display_number: '*3356',
		related_phone: null,
		status: 'AVAILABLE',
		balance: {
			currency_code: 'MXP',
			amount: 50.5
		}
	}
];

export const PayeeInfo = {
	key: '0m29qh0l7xy6oattzh65kq2jgn19fbx6',
	account: {
		number: '5179921863843075',
		type: 'THIRDPARTY_DEBIT_CARD',
		bank: 'SCOTIABANK'
	},
	name: 'Jack Jacobs Cruz',
	alias: 'The Fourth',
	url: '/beneficiaries/{beneficiary-key}'
};
