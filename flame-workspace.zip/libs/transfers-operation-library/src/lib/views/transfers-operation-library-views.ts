import { TransferSameBankViewComponent } from './transfer-money-view/transfers-same-bank/same-bank-view.component';
import { TransferEmptyStateViewComponent } from './transfer-money-view/transfers-empty-state/empty-state-view.component';
import { TransfersVoucherViewComponent } from './transfer-money-view/transfers-voucher/transfers-voucher-view.component';
import { TransfersSameAccountsComponent } from './transfer-money-view/transfers-same-accounts/transfers-same-accounts.component';
import { TranfersOthersBanksComponent } from './transfer-money-view/transfers-others-banks/tranfers-others-banks.component';
import { TranfersVoucherOthersBanksComponent } from './transfer-money-view/transfers-voucher-others-banks/voucher-others-banks.component';
import { TransferInitialViewComponent } from './transfer-money-view/transfer-initial-view/transfer-initial-view.component';


export const TransfersOperationLibraryViews = [
	TransferSameBankViewComponent,
	TransferEmptyStateViewComponent,
	TransfersVoucherViewComponent,
	TransfersSameAccountsComponent,
	TranfersOthersBanksComponent,
  TranfersVoucherOthersBanksComponent,
  TransferInitialViewComponent
];
