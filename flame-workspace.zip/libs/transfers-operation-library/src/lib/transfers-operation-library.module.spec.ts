import { async, TestBed } from '@angular/core/testing';
import { TransfersOperationLibraryModule } from './transfers-operation-library.module';

describe('TransfersOperationLibraryModule', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [TransfersOperationLibraryModule]
		}).compileComponents();
	}));

	// it('should create', () => {
	// 	expect(TransfersOperationLibraryModule).toBeDefined();
	// });
});
