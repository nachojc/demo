import {
	Component,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	ViewEncapsulation
} from '@angular/core';
import { timer } from 'rxjs';

@Component({
	selector: 'sn-tooltip',
	templateUrl: './tooltip.component.html',
	styleUrls: ['./tooltip.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
	encapsulation: ViewEncapsulation.None
})
export class TooltipComponent {
	/**
	 * Creates an instance of TooltipComponent.
	 * @param {ChangeDetectorRef} _changeDetectorRef
	 * @memberof TooltipComponent
	 */
	constructor(private _changeDetectorRef: ChangeDetectorRef) {}

	/**
	 * Indica el mensaje mostrado en <strong>tooltip</strong>.
	 *
	 * @type {string}
	 * @memberof TooltipComponent
	 */
	message: string;

	/**
	 * Indica si se muestra o no el <strong>tooltip</strong>.
	 *
	 * @type {boolean}
	 * @memberof TooltipComponent
	 */
	visibility = false;

	/**
	 * Indica la clase de tooltip.
	 *
	 * @type {string | string[] | Set<string> | { [key: string]: any }}
	 * @memberof TooltipComponent
	 */
	tooltipClass: string | string[] | Set<string> | { [key: string]: any };

	/**
	 * Muestra tooltip después del tiempo establecido en parámetro delay.
	 *
	 * @param {number} delay
	 * @memberof TooltipComponent
	 */
	show(delay: number) {
		timer(delay).subscribe(() => {
			this.visibility = true;
			this.markForCheck();
		});
	}

	/**
	 * Oculta tooltip después del tiempo establecido en parámetro delay.
	 *
	 * @param {number} delay
	 * @returns
	 * @memberof TooltipComponent
	 */
	hide(delay: number) {
		return new Promise(resolve => {
			timer(delay).subscribe(() => {
				resolve();
			});
		});
	}

	/**
	 * Cambia el estado del tooltip.
	 *
	 * @param {number} delay
	 * @memberof TooltipComponent
	 */
	toggle(delay: number) {
		timer(delay).subscribe(() => {
			this.visibility = !this.visibility;
			this.markForCheck();
		});
	}

	/**
	 *  Reinicia el estado del componente.
	 *
	 * @memberof TooltipComponent
	 */
	public markForCheck(): void {
		this._changeDetectorRef.markForCheck();
	}
}
