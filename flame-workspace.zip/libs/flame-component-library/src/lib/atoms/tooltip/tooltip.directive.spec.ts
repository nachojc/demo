import { TooltipModule } from './tooltip.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement, ChangeDetectorRef, Component } from '@angular/core';
import { SnTooltipDirective } from './tooltip.directive';

@Component({
	template: `
		<button snTooltip="Message Tooltip">Aceptar</button>
		<button snTooltipDisabled="true" snTooltip="Message Tooltip">
			Aceptar
		</button>
		<button
			snTooltipShowDelay="1000"
			snTooltipHideDelay="1000"
			snTooltip="Message Tooltip"
		>
			Aceptar
		</button>
		<button snTooltipPosition="right" snTooltip="Message Tooltip">
			Aceptar
		</button>
		<button snTooltip="Message Tooltip" snTooltipClass="example-tooltip-red">
			Aceptar
		</button>
		<button (mouseenter)="tooltip.hide()">Ocultar</button>
		<button id="show-tooltip" (mouseenter)="tooltip.show()">Mostrar</button>
		<button (mouseenter)="tooltip.toggle()">Toggle</button>
		<button #tooltip="SnTooltipDirective" snTooltip="Message Tooltip">
			Aceptar
		</button>
	`
})
class TooltipStubComponent {}

describe('TooltipComponent', () => {
	let component: TooltipStubComponent;
	let fixture: ComponentFixture<TooltipStubComponent>;
  let button: DebugElement;
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TooltipStubComponent],
			imports: [TooltipModule],
			providers: [ChangeDetectorRef]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TooltipStubComponent);
		component = fixture.componentInstance;
    fixture.detectChanges();
    button = fixture.debugElement.query(By.css('button'));
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('mouse in', () => {
    button.triggerEventHandler('mouseenter', null);
    fixture.detectChanges();
    const tooltipComponent = fixture.debugElement.query(By.css('.sn-tooltip'));
		expect(tooltipComponent).toBeDefined();
	});
	it('mouse out', () => {
    button.triggerEventHandler('mouseout', null);
    fixture.detectChanges();
    const tooltipComponent = fixture.debugElement.query(By.css('.sn-tooltip'));
		expect(tooltipComponent).toBeNull();
  });
	it('show function', () => {
    const showTooltipButton = fixture.debugElement.query(By.css('#show-tooltip')).nativeElement;
    showTooltipButton.click();
    const tooltipComponent = fixture.debugElement.query(By.css('.sn-tooltip'));
    fixture.detectChanges();
		expect(tooltipComponent).toBeDefined();
  });
});
