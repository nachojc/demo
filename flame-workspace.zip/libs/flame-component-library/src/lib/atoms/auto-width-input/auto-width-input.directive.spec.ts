
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AutoWidthInputDirective } from './auto-width-input.directive';
import { Component, ViewChild } from '@angular/core';

@Component({
  selector: 'sn-test-autowidth',
  template: `<input type="text" snAutowidthinput>`
})
class TestAutoWidthInputComponent {
  @ViewChild(AutoWidthInputDirective) autowidthinput: AutoWidthInputDirective;
  extraWidth = 0;
  includePlaceholder = true;
  includeBorders = false;
  includePadding = true;
  minWidth = 58;
  maxWidth = -1;
}

describe('AutoWidthInputDirective', () => {
  let component: TestAutoWidthInputComponent;
  let fixture: ComponentFixture<TestAutoWidthInputComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AutoWidthInputDirective, TestAutoWidthInputComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TestAutoWidthInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('onInput method', () => {
    spyOn(component.autowidthinput, 'adjustWidth');
    component.autowidthinput.onInput();
    expect(component.autowidthinput.adjustWidth).toHaveBeenCalled();
  });

  it('ngAfterContentChecked method', () => {
    spyOn(component.autowidthinput, 'adjustWidth');
    component.autowidthinput.ngAfterContentChecked();
    expect(component.autowidthinput.adjustWidth).toHaveBeenCalled();
  });

  it('ngOnChanges method', () => {
    spyOn(component.autowidthinput, 'adjustWidth');
    component.autowidthinput.ngOnChanges({});
    expect(component.autowidthinput.adjustWidth).toHaveBeenCalled();
  });

  it('setWidth method', () => {
    const width = 10
    component.autowidthinput.setWidth(width);
    expect(component.autowidthinput._element.nativeElement.style.width).toBe(width + 'px');
  });

  it('getStyle method with window style', () => {
    const windowStyle = Object({
      fontFamily: window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('font-family'),
      fontSize: window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('font-size'),
      fontWeight: window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('font-weight'),
      fontStyle: window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('font-style'),
      fontVariant: window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('font-variant')
    });
    expect(component.autowidthinput.getStyle()).toEqual(windowStyle);
  });

  it('getStyle method with window style', () => {
    const fontFamily = 'Times, "Times New Roman", serif';
    const fontSize = '14px';
    const fontWeight = '400';
    const fontNormal = 'normal';

    component.autowidthinput._element.nativeElement.style.fontFamily = fontFamily;
    component.autowidthinput._element.nativeElement.style.fontSize = fontSize;
    component.autowidthinput._element.nativeElement.style.fontStyle = fontNormal;
    component.autowidthinput._element.nativeElement.style.fontVariant = fontNormal;
    component.autowidthinput._element.nativeElement.style.fontWeight = fontWeight;
    const customStyle = Object({
      fontFamily: fontFamily,
      fontSize: fontSize,
      fontWeight: fontWeight,
      fontStyle: fontNormal,
      fontVariant: fontSize
    });
    expect(component.autowidthinput.getStyle()).toEqual(customStyle);
  });

  it('adjustWidth with includeBorders and includePadding', () => {
    component.autowidthinput.includeBorders = true;
    component.autowidthinput.includePadding = true;
    const border = 2 * parseInt(window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('border'), 10);
    const leftPadding = window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('padding-left');
    const rightPadding = window.getComputedStyle(component.autowidthinput._element.nativeElement, '').getPropertyValue('padding-right');
    const padding = parseInt(leftPadding, 10) + parseInt(rightPadding, 10);
    component.autowidthinput.adjustWidth();
    expect(component.autowidthinput.borderWidth).toBe(border);
    expect(component.autowidthinput.paddingWidth).toBe(padding);
  });

  it('adjustWidth without includeBorders and includePadding', () => {
    spyOn(component.autowidthinput, 'setWidthByValue');
    component.autowidthinput.minWidth = -1;
    component.autowidthinput.includeBorders = false;
    component.autowidthinput.includePadding = false;
    component.autowidthinput.adjustWidth();
    expect(component.autowidthinput.borderWidth).toBe(0);
    expect(component.autowidthinput.paddingWidth).toBe(0);
    expect(component.autowidthinput.setWidthByValue).toHaveBeenCalled();
  });

  it('adjustWidth for placeholder', () => {
    component.autowidthinput.includePlaceholder = true;
    spyOn(component.autowidthinput, 'setWidthByValue');
    component.autowidthinput.minWidth = 30;
    component.autowidthinput._element.nativeElement.value = 'Prueba';
    component.autowidthinput._element.nativeElement.placeholder = 'Transferencia';
    component.autowidthinput.adjustWidth();
    expect(component.autowidthinput.setWidthByValue).toHaveBeenCalled();
  });

  it('adjustWidth for input value width lesser than minWindth', () => {
    spyOn(component.autowidthinput, 'setWidth');
    component.autowidthinput.minWidth = 60;
    component.autowidthinput._element.nativeElement.value = 'Prueba';
    component.autowidthinput.adjustWidth();
    expect(component.autowidthinput.setWidth).toHaveBeenCalledWith(component.autowidthinput.minWidth);
  });

  it('adjustWidth for input value width greater than maxWindth', () => {
    spyOn(component.autowidthinput, 'setWidth');
    component.autowidthinput.minWidth = -1;
    component.autowidthinput.maxWidth = 2;
    component.autowidthinput._element.nativeElement.value = 'Prueba';
    component.autowidthinput.adjustWidth();
    expect(component.autowidthinput.setWidth).toHaveBeenCalledWith(component.autowidthinput.maxWidth);
  });

  it('setWidthByValue method', () => {
    const value = 'Fake Value'
    const text = component.autowidthinput.calculateTextWidth(value);
    const width = text + component.autowidthinput.extraWidth + component.autowidthinput.borderWidth + component.autowidthinput.paddingWidth;
    component.autowidthinput.setWidthByValue(value);
    expect(component.autowidthinput._element.nativeElement.style.width).toBe(width.toFixed(4)+'px');
  });
});
