import { NgModule } from '@angular/core';
import { AutoWidthInputDirective } from './auto-width-input.directive';

@NgModule({
	declarations: [ AutoWidthInputDirective ],
	exports: [ AutoWidthInputDirective ]
})
export class AutoWidthInputModule {}
