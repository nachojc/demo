import { 
  Directive,
  Input,
  ElementRef,
  HostListener,
  AfterContentChecked,
  OnChanges,
  SimpleChanges
} from '@angular/core';

@Directive({
  selector: 'input[snAutowidthinput]',
  exportAs: 'sn-autowidth'
})
export class AutoWidthInputDirective implements AfterContentChecked, OnChanges {
  
  constructor(public _element: ElementRef) {}

  public borderWidth: number;
  public paddingWidth: number;

  @Input() extraWidth = 0;
  @Input() includePlaceholder = true;
  @Input() includeBorders = false;
  @Input() includePadding = true;
  @Input() minWidth = 58;
  @Input() maxWidth = -1;

  @HostListener('input')
  public onInput(): void {
    this.adjustWidth();
  }

  public adjustWidth(): void {
    if (this.includeBorders){
      this.borderWidth = 2 * parseInt(window
        .getComputedStyle(this._element.nativeElement, '')
        .getPropertyValue('border'), 10);
    } else {
      this.borderWidth = 0;
    }

    if (this.includePadding) {
      this.paddingWidth = parseInt(window
              .getComputedStyle(this._element.nativeElement, '')
              .getPropertyValue('padding-left'), 10) +
          parseInt(window
              .getComputedStyle(this._element.nativeElement, '')
              .getPropertyValue('padding-right'), 10);
    } else {
        this.paddingWidth = 0;
    }

    let placeholderText = '';

    if (this._element.nativeElement.placeholder) {
      placeholderText = this._element.nativeElement.placeholder;
    }

    const inputText = this._element.nativeElement.value;

    const inputTextWidth = this.calculateTextWidth(inputText) + this.extraWidth + this.borderWidth + this.paddingWidth;
  
    if(this.includePlaceholder && placeholderText.length > 0 
      && (this.calculateTextWidth(placeholderText) > this.calculateTextWidth(inputText)) 
      && (this.calculateTextWidth(placeholderText) > this.minWidth)) {
      this.setWidthByValue(placeholderText);
      return
    }

    if(this.minWidth > 0 && (inputTextWidth < this.minWidth )) {
      this.setWidth(this.minWidth);
      return;
    }
    
    if (this.maxWidth > 0 && (inputTextWidth >this.maxWidth)) {
      this.setWidth(this.maxWidth);
      return;
    }

    this.setWidthByValue(inputText);
  }

  calculateTextWidth(value: string): number {
    const style = this.getStyle();
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    ctx.font = `${style.fontStyle} ${style.fontVariant} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
    return ctx.measureText(value).width;
  }

  getStyle() {
    const fontFamily = this._element.nativeElement.style.fontFamily ? this._element.nativeElement.style.fontFamily :
            window.getComputedStyle(this._element.nativeElement, '').getPropertyValue('font-family'),
        fontStyle = this._element.nativeElement.style.fontStyle ? this._element.nativeElement.style.fontStyle :
            window.getComputedStyle(this._element.nativeElement, '').getPropertyValue('font-style'),
        fontSize = this._element.nativeElement.style.fontSize ? this._element.nativeElement.style.fontSize :
            window.getComputedStyle(this._element.nativeElement, '').getPropertyValue('font-size'),
        fontVariant = this._element.nativeElement.style.fontSize ? this._element.nativeElement.style.fontSize :
            window.getComputedStyle(this._element.nativeElement, '').getPropertyValue('font-variant'),
        fontWeight = this._element.nativeElement.style.fontWeight ? this._element.nativeElement.style.fontWeight :
            window.getComputedStyle(this._element.nativeElement, '').getPropertyValue('font-weight');

    return {fontFamily: fontFamily, fontSize: fontSize, fontWeight: fontWeight, fontStyle: fontStyle, fontVariant: fontVariant};
  }

  setWidth(width: any) {
    this._element.nativeElement.style.width = width + 'px';
  }

  setWidthByValue(value: any) {
    this._element.nativeElement.style.width =
      this.calculateTextWidth(value) +
      this.extraWidth +
      this.borderWidth +
      this.paddingWidth + 'px';
  }

  ngAfterContentChecked(): void {
    this.adjustWidth();
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.adjustWidth();
  }
}
