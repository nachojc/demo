import {
	Directive,
	Input,
	ElementRef,
	HostListener,
	AfterContentChecked,
	OnChanges,
	SimpleChanges
} from '@angular/core';

@Directive({
	selector: 'input[snAutowidthinput]',
	exportAs: 'sn-autowidth'
})
export class AutoWidthInputDirective implements AfterContentChecked, OnChanges {
	/**
	 * Crea una instancia de AutoWidthInputDirective.
	 *
	 * @param {ElementRef} _element
	 * @memberof AutoWidthInputDirective
	 */
	constructor(public _element: ElementRef) {}

	/**
	 * Indica el tamaño del 'border' del elemento.
	 *
	 * @type {number}
	 * @memberof AutoWidthInputDirective
	 */
	public borderWidth: number;

	/**
	 * Indica el tamaño del 'padding' del elemento.
	 *
	 * @type {number}
	 * @memberof AutoWidthInputDirective
	 */
	public paddingWidth: number;

	/**
	 * Tamaño extra que se le puede añadir al elemento input para una correcta visualización.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	@Input() extraWidth = 0;

	/**
	 * Indica si se debe tener en cuenta el 'placeholder' para calcular el tamaño del elemento input. Por defecto es `true`.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	@Input() includePlaceholder = true;

	/**
	 * Indica si se debe tener en cuenta el 'border' para calcular el tamaño del elemento input. Por defecto es `true`.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	@Input() includeBorders = false;

	/**
	 * Indica si se debe tener en cuenta el 'padding' para calcular el tamaño del elemento input. Por defecto es `true`.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	@Input() includePadding = true;

	/**
	 * Indica el tamaño mínimo de un elemento input. Por defecto es de `58px`.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	@Input() minWidth = 58;

	/**
	 * Indica el tamaño máximo de un elemento input. Por defecto es de `-1px`.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	@Input() maxWidth = -1;

	/**
	 * Calcula el tamaño del elemento input con cada evento `input` que se dispara.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	@HostListener('input')
	public onInput(): void {
		this.adjustWidth();
	}

	/**
	 * Ajusta el tamaño del elemento input.
	 *
	 * @returns {void}
	 * @memberof AutoWidthInputDirective
	 */
	public adjustWidth(): void {
		if (this.includeBorders) {
			this.borderWidth =
				2 *
				parseInt(
					window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('border'),
					10
				);
		} else {
			this.borderWidth = 0;
		}

		if (this.includePadding) {
			this.paddingWidth =
				parseInt(
					window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('padding-left'),
					10
				) +
				parseInt(
					window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('padding-right'),
					10
				);
		} else {
			this.paddingWidth = 0;
		}

		let placeholderText = '';

		if (this._element.nativeElement.placeholder) {
			placeholderText = this._element.nativeElement.placeholder;
		}

		const inputText = this._element.nativeElement.value;

		const inputTextWidth =
			this.calculateTextWidth(inputText) +
			this.extraWidth +
			this.borderWidth +
			this.paddingWidth;

		if (
			this.includePlaceholder &&
			placeholderText.length > 0 &&
			this.calculateTextWidth(placeholderText) >
				this.calculateTextWidth(inputText) &&
			this.calculateTextWidth(placeholderText) > this.minWidth
		) {
			this.setWidthByValue(placeholderText);
			return;
		}

		if (this.minWidth > 0 && inputTextWidth < this.minWidth) {
			this.setWidth(this.minWidth);
			return;
		}

		if (this.maxWidth > 0 && inputTextWidth > this.maxWidth) {
			this.setWidth(this.maxWidth);
			return;
		}

		this.setWidthByValue(inputText);
	}

	/**
	 * Calcula el tamaño del valor del elemento input.
	 *
	 * @param {string} value
	 * @returns {number}
	 * @memberof AutoWidthInputDirective
	 */
	calculateTextWidth(value: string): number {
		const style = this.getStyle();
		const canvas = document.createElement('canvas');
		const ctx = canvas.getContext('2d');
		ctx.font = `${style.fontStyle} ${style.fontVariant} ${style.fontWeight} ${
			style.fontSize
		} ${style.fontFamily}`;
		return ctx.measureText(value).width;
	}

	/**
	 * Obtiene estilos asociados al elemento input.
	 *
	 * @returns
	 * @memberof AutoWidthInputDirective
	 */
	getStyle() {
		const fontFamily = this._element.nativeElement.style.fontFamily
				? this._element.nativeElement.style.fontFamily
				: window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('font-family'),
			fontStyle = this._element.nativeElement.style.fontStyle
				? this._element.nativeElement.style.fontStyle
				: window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('font-style'),
			fontSize = this._element.nativeElement.style.fontSize
				? this._element.nativeElement.style.fontSize
				: window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('font-size'),
			fontVariant = this._element.nativeElement.style.fontSize
				? this._element.nativeElement.style.fontSize
				: window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('font-variant'),
			fontWeight = this._element.nativeElement.style.fontWeight
				? this._element.nativeElement.style.fontWeight
				: window
						.getComputedStyle(this._element.nativeElement, '')
						.getPropertyValue('font-weight');

		return {
			fontFamily: fontFamily,
			fontSize: fontSize,
			fontWeight: fontWeight,
			fontStyle: fontStyle,
			fontVariant: fontVariant
		};
	}

	/**
	 * Setea el tamaño del elemento input.
	 *
	 * @param {*} width
	 * @memberof AutoWidthInputDirective
	 */
	setWidth(width: any) {
		this._element.nativeElement.style.width = width + 'px';
	}

	/**
	 * Setea el tamañao del elemento input en función de un valor.
	 *
	 * @param {*} value
	 * @memberof AutoWidthInputDirective
	 */
	setWidthByValue(value: any) {
		this._element.nativeElement.style.width =
			this.calculateTextWidth(value) +
			this.extraWidth +
			this.borderWidth +
			this.paddingWidth +
			'px';
	}

	/**
   * @ignore
	 * Una vez cargado el contenido del elemento input ajusta su tamaño.
	 *
	 * @memberof AutoWidthInputDirective
	 */
	ngAfterContentChecked(): void {
		this.adjustWidth();
	}

	/**
   * @ignore
	 * Ajusta el tamaño del elemento input con cada cambio.
	 *
	 * @param {SimpleChanges} changes
	 * @memberof AutoWidthInputDirective
	 */
	ngOnChanges(changes: SimpleChanges): void {
		this.adjustWidth();
	}
}
