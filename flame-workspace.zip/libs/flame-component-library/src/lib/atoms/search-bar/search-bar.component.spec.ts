import { FormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchBarComponent } from './search-bar.component';
import { By } from '@angular/platform-browser';
import { IconModule } from '../icon/icon.module';
import { DebugElement } from '@angular/core';

describe('SearchBarComponent ', () => {
	let component: SearchBarComponent;
	let fixture: ComponentFixture<SearchBarComponent>;
	// tslint:disable-next-line:prefer-const

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [SearchBarComponent],
			imports: [IconModule, FormsModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(SearchBarComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	}),

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('placeholder Input get and set', () => {
		expect(component.placeholder).toBe(component.placeholder);
		const placeholder = 'PlaceholderFake';
		component.placeholder = placeholder;
		expect(component.placeholder).toBe(placeholder);
	});

	it('changeValue method', () => {
		component.focusInput = true;
		component.changeValue();
		expect(component.show).toBeFalsy();
	});

	it('onFocus method', () => {
		const event = new Event('focus');
		spyOn(component.focusEv,'emit');
		component.onFocus(event);
		expect(component.focusInput).toBeTruthy();
		expect(component.focusEv.emit).toHaveBeenCalledWith(event);
	});

	it('onBlur method', () => {
		const event = new Event('blur');
		spyOn(component.blurEv,'emit');
		component.onBlur(event);
		expect(component.focusInput).toBeFalsy();
		expect(component.blurEv.emit).toHaveBeenCalledWith(event);
	});

	it('onChange method', () => {
		const event = new Event('change');
		spyOn(component.searchChange,'emit');
		component.onChange(event);
		expect(component.searchChange.emit).toHaveBeenCalledWith(event);
	});

	it('onSearchChange method with value', () => {
		const value = 'Testing';
		component.onSearchChange(value);
		expect(component.show).toBeFalsy();
	});

	it('onSearchChange method with value', () => {
		component.onSearchChange('');
		expect(component.show).toBeTruthy();
	});

	it('clear method', () => {
		component.clear();
		expect(component.input.nativeElement.value).toBe('');
		expect(component.show).toBeTruthy();
	});

	it('complete method', () => {
		component.focusInput = true;
		component.complete();
		expect(component.show).toBeFalsy();
	});

	it('should have sn-buscar', () => {
		fixture.componentInstance.show = true;
		fixture.detectChanges();
		const iconCancel = fixture.debugElement.query(By.css('#iconBuscar'));
		expect(iconCancel.nativeElement.id).toEqual('iconBuscar');
	});

	it('should have sn-cancel', () => {
		fixture.componentInstance.show = false;
		fixture.detectChanges();
		const iconCancel = fixture.debugElement.query(By.css('#iconCancel'));
		expect(iconCancel.nativeElement.id).toEqual('iconCancel');
	});
});
