import { Component, ViewChild, ElementRef, Input, Output, EventEmitter } from '@angular/core';
@Component({
	selector: 'sn-search-bar',
	templateUrl: './search-bar.component.html',
	styleUrls: ['./search-bar.component.scss']
})
export class SearchBarComponent {
  public focusInput = false;
  public searchInput: string;
	private _show = true;
	private _placeholder: string;

	@Input()
	public get show(): boolean {
		return this._show;
	}
	public set show(value: boolean) {
		this._show = value;
	}

	@Input()
	get placeholder(): string {
		return this._placeholder;
	}

	set placeholder(value: string) {
		this._placeholder = value;
	}
	@Output() focusEv = new EventEmitter<Event>();
	@Output() blurEv = new EventEmitter<Event>();
	@Output() searchChange = new EventEmitter<Event>();

	@ViewChild('input') input: ElementRef;

	constructor() {}

	changeValue() {
		if (this.focusInput === true) {
			this._show = false;
		}
	}
  onFocus(ev: Event){
    this.focusInput = true;
		this.focusEv.emit(ev);
  }
  onBlur(ev: Event){
    this.focusInput = false;
		this.blurEv.emit(ev);
  }
  onChange(ev: Event){
    this.searchChange.emit(ev);
  }
	onSearchChange(value: string) {
		if (value.length > 0) {
			this._show = false;
		} else {
			this._show = true;
		}
	}

	clear() {
		this.input.nativeElement.value = '';
		this._show = true;
  }

  complete() {
    if (this.focusInput === true) {
      this._show = false;
    }
  }
}
