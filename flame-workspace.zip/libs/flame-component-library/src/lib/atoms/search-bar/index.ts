export * from './search-bar.module';
