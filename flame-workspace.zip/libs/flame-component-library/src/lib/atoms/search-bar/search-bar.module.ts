import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconModule } from '../icon/icon.module';
import { SearchBarComponent } from './search-bar.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

@NgModule({
	imports: [CommonModule, IconModule,FormsModule,ReactiveFormsModule],
	declarations: [SearchBarComponent],
	exports: [SearchBarComponent]
})
export class SearchBarModule {}
