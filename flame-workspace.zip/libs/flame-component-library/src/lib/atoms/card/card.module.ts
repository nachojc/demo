import { NgModule } from '@angular/core';
import { CardComponent } from './card.component';
import { CommonModule } from '@angular/common';
import { IconModule } from '../icon/icon.module';

@NgModule({
	imports: [CommonModule, IconModule],
	declarations: [CardComponent],
	exports: [CardComponent]
})
export class CardModule {}
