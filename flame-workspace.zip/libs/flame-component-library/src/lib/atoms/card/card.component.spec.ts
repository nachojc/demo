import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CardComponent } from './card.component';

describe('CardComponent', () => {
	let component: CardComponent;
	let fixture: ComponentFixture<CardComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CardComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CardComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('type input get and set', () => {
		expect(component.type).toBe(component.type);
		const type = 'Fake type';
		component.type = type;
		expect(component.type).toBe(type);
	});

	it('flipped input get and set', () => {
		expect(component.flipped).toBe(component.flipped);
		const flipped = true;
		component.flipped = flipped;
		expect(component.flipped).toBe(flipped);
	});

	it('ngOnInit', () => {
		spyOn(component, 'setTemplate');
		component.ngOnInit();
		expect(component.shouldflip).toBeTruthy();
		expect(component.setTemplate).toHaveBeenCalledWith(component.type);
	});

	it('toggleFlip method', () => {
		const flip = component.flipped;
		component.shouldflip = true;
		component.toggleFlip();
		expect(component.flipped).toBe(!flip);
	});

	it('setTemplate method for type aero', () => {
		component.setTemplate('aero');
		expect(component.accountTypeText).toBe('Crédito disponible en MXN');
		expect(component.statusCopy).toBe('Tarjeta bloqueada temporalmente');
		expect(component.inverse).toBeFalsy();
	});

	it('setTemplate method for type amex', () => {
		component.setTemplate('amex');
		expect(component.accountTypeText).toBe('Crédito disponible en MXN');
		expect(component.statusCopy).toBe('Tarjeta bloqueada temporalmente');
		expect(component.inverse).toBeFalsy();
	});

	it('setTemplate method for type basic', () => {
		component.setTemplate('basic');
		expect(component.accountTypeText).toBe('Dinero disponible en MXN');
		expect(component.statusCopy).toBe('Cuenta bloqueada temporalmente');
		expect(component.inverse).toBeTruthy();
	});
});
