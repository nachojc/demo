import {
	Component,
	OnInit,
	TemplateRef,
	Input
} from '@angular/core';

@Component({
	selector: 'sn-card',
	templateUrl: './card.component.html',
	styleUrls: ['./card.component.scss']
})
export class CardComponent implements OnInit {
  private _type: string;
  public accountTypeText: string;
  public cuentaTypeText = '';
	@Input()
	get type(): string {
		return this._type;
	}
	set type(value: string) {
		this._type = value;
		this.setTemplate(this._type);
	}
	public _flipped = false;
	@Input()
	get flipped(): boolean {
		return this._flipped;
	}
	set flipped(value: boolean) {
		this._flipped = value;
	}

	@Input() available: string;
	@Input() name: string;
	@Input() currency: string;
	@Input() account = '---- ---- ---- ----';
	@Input() shouldflip: boolean;
	@Input() cvv = '---';
  @Input() dueDate = '--/--';
  @Input() blocked = false;

  public inverse = false;
  public statusCopy:string;
	public activeFront: TemplateRef<any>;
	public activeBack: TemplateRef<any>;

	constructor() {}

	ngOnInit() {
		this.shouldflip = this.shouldflip !== undefined;
		this.setTemplate(this._type);
	}

	toggleFlip() {
		if (this.shouldflip) {
			this._flipped = !this._flipped;
		}
	}
	setTemplate(type: string) {
    if (type === 'aero' || type === 'amex') {
      this.accountTypeText= 'Crédito disponible en MXN';
      this.statusCopy= 'Tarjeta bloqueada temporalmente';
    } else {
      this.accountTypeText= 'Dinero disponible en MXN';
      this.statusCopy= 'Cuenta bloqueada temporalmente';
    }
		if (type === 'basic') {
			this.inverse = true;
		} else {
			this.inverse = false;
		}
	}
}
