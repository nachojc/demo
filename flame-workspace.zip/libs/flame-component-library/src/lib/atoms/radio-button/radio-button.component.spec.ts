import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component, DebugElement, ViewChild } from '@angular/core';
import { By } from '@angular/platform-browser';
import {
	RadioButtonComponent,
	RadioGroupDirective,
	RadioButtonModule
} from './index';

@Component({
	template: `
		<sn-radio-group
			[disabled]="isGroupDisabled"
			[required]="isGroupRequired"
			[value]="groupValue"
			name="opt-list"
		>
			<sn-radio-button value="opt-1" [disabled]="isDisabled">
				Option list 1
			</sn-radio-button>
			<sn-radio-button value="opt-2"> Option list 2 </sn-radio-button>
			<sn-radio-button value="opt-3"> Option list 3 </sn-radio-button>
		</sn-radio-group>
	`
})
class RadiosInsideRadioGroupComponent {
	isDisabled = false;
	isGroupDisabled = false;
	isGroupRequired = false;
	groupValue: any;
}

@Component({
	template: `
		<sn-radio-button name="question" value="quest-1"
			>Question 1</sn-radio-button
		>
		<sn-radio-button name="question" value="quest-2"
			>Question 2</sn-radio-button
		>
		<sn-radio-button name="fruit" value="apple">Apple</sn-radio-button>
		<sn-radio-button name="fruit" value="watermelon"
			>Watermelon</sn-radio-button
		>
		<sn-radio-button name="sport" value="soccer">Soccer</sn-radio-button>
		<sn-radio-button name="sport" value="box">Box</sn-radio-button>
		<sn-radio-button name="sport" value="tennis">Tennis</sn-radio-button>
	`
})
class OnlyRadioButtonsComponent {}

@Component({
	template: `
		<sn-radio-button>Radio Button 1</sn-radio-button>
	`
})
class DisableableRadioButtonComponent {
	@ViewChild(RadioButtonComponent) radioButton: RadioButtonComponent;

	set disabled(value: boolean) {
		this.radioButton.disabled = value;
	}
}

@Component({
	template: `
		<sn-radio-group [formControl]="formControl">
			<sn-radio-button value="1">Radio Button 1</sn-radio-button>
		</sn-radio-group>
	`
})
class RadioGroupFormComponent {
	formControl = new FormControl();
}

describe('RadioButtonComponent', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [RadioButtonModule, FormsModule, ReactiveFormsModule],
			declarations: [
				DisableableRadioButtonComponent,
				RadiosInsideRadioGroupComponent,
				RadioGroupFormComponent,
				OnlyRadioButtonsComponent
			]
		}).compileComponents();
	}));

	describe('radios in a group', () => {
		let fixture: ComponentFixture<RadiosInsideRadioGroupComponent>;
		let groupDebugElement: DebugElement;
		let radioDebugElements: DebugElement[];
		let radioNativeElements: HTMLElement[];
		let radioLabelElements: HTMLLabelElement[];
		let radioInputElements: HTMLInputElement[];
		let groupInstance: RadioGroupDirective;
		let radioInstances: RadioButtonComponent[];
		let testComponent: RadiosInsideRadioGroupComponent;

		beforeEach(async(() => {
			fixture = TestBed.createComponent(RadiosInsideRadioGroupComponent);
			fixture.detectChanges();

			testComponent = fixture.debugElement.componentInstance;

			groupDebugElement = fixture.debugElement.query(
				By.directive(RadioGroupDirective)
			);
			groupInstance = groupDebugElement.injector.get<RadioGroupDirective>(
				RadioGroupDirective
			);

			radioDebugElements = fixture.debugElement.queryAll(
				By.directive(RadioButtonComponent)
			);
			radioNativeElements = radioDebugElements.map(
				debugEl => debugEl.nativeElement
			);
			radioInstances = radioDebugElements.map(
				debugEl => debugEl.componentInstance
			);

			radioLabelElements = radioDebugElements.map(
				debugEl => debugEl.query(By.css('label')).nativeElement
			);
			radioInputElements = radioDebugElements.map(
				debugEl => debugEl.query(By.css('input')).nativeElement
			);
		}));

		it('should set radio names based on the group name', () => {
			expect(groupInstance.name).toBeTruthy();
			for (const radio of radioInstances) {
				expect(radio.name).toBe(groupInstance.name);
			}
		});

		it('should coerce the disabled binding on the radio group', () => {
			// groupInstance.disabled = null;
			(groupInstance as any).disabled = '';
			fixture.detectChanges();

			radioLabelElements[0].click();
			fixture.detectChanges();

			expect(radioInstances[0].checked).toBe(false);
			expect(groupInstance.disabled).toBe(true);
		});

		it('should disable click interaction when group is disabled', () => {
			testComponent.isGroupDisabled = true;
			fixture.detectChanges();

			radioLabelElements[0].click();
			fixture.detectChanges();

			expect(radioInstances[0].checked).toBe(false);
		});

		it('should disable radios when group is disabled', () => {
			testComponent.isGroupDisabled = true;
			fixture.detectChanges();

			for (const radio of radioInstances) {
				expect(radio.disabled).toBe(true);
			}
		});

		it('should set required to each radio button when the group is required', () => {
			testComponent.isGroupRequired = true;
			fixture.detectChanges();

			for (const radio of radioInstances) {
				expect(radio.required).toBe(true);
			}
		});

		it('should update the group value when one of the radios changes', () => {
			expect(groupInstance.value).toBeFalsy();

			radioInstances[0].checked = true;
			fixture.detectChanges();

			expect(groupInstance.value).toBe('opt-1');
			expect(groupInstance.selected).toBe(radioInstances[0]);
		});

		it('should update the group and radios when one of the radios is clicked', () => {
			expect(groupInstance.value).toBeFalsy();

			radioLabelElements[0].click();
			fixture.detectChanges();

			expect(groupInstance.value).toBe('opt-1');
			expect(groupInstance.selected).toBe(radioInstances[0]);
			expect(radioInstances[0].checked).toBe(true);
			expect(radioInstances[1].checked).toBe(false);
			expect(radioInstances[2].checked).toBe(false);

			radioLabelElements[1].click();
			fixture.detectChanges();

			expect(groupInstance.value).toBe('opt-2');
			expect(groupInstance.selected).toBe(radioInstances[1]);
			expect(radioInstances[0].checked).toBe(false);
			expect(radioInstances[1].checked).toBe(true);
			expect(radioInstances[2].checked).toBe(false);
		});
	});

	describe('group with FormControl', () => {
		let fixture: ComponentFixture<RadioGroupFormComponent>;
		let groupDebugElement: DebugElement;
		let groupInstance: RadioButtonComponent;
		let testComponent: RadioGroupFormComponent;

		beforeEach(() => {
			fixture = TestBed.createComponent(RadioGroupFormComponent);
			fixture.detectChanges();

			testComponent = fixture.debugElement.componentInstance;
			groupDebugElement = fixture.debugElement.query(
				By.directive(RadioButtonComponent)
			);
			groupInstance = groupDebugElement.injector.get<RadioButtonComponent>(
				RadioButtonComponent
			);
		});

		it('should toggle the disabled state', () => {
			expect(groupInstance.disabled).toBeFalsy();

			testComponent.formControl.disable();
			fixture.detectChanges();

			expect(groupInstance.disabled).toBeTruthy();

			testComponent.formControl.enable();
			fixture.detectChanges();

			expect(groupInstance.disabled).toBeFalsy();
		});
	});

	describe('disableable', () => {
		let fixture: ComponentFixture<DisableableRadioButtonComponent>;
		let radioInstance: RadioButtonComponent;
		let radioNativeElement: HTMLInputElement;
		let testComponent: DisableableRadioButtonComponent;

		beforeEach(() => {
			fixture = TestBed.createComponent(DisableableRadioButtonComponent);
			fixture.detectChanges();

			testComponent = fixture.debugElement.componentInstance;
			const radioDebugElement = fixture.debugElement.query(
				By.directive(RadioButtonComponent)
			);
			radioInstance = radioDebugElement.injector.get<RadioButtonComponent>(
				RadioButtonComponent
			);
			radioNativeElement = radioDebugElement.nativeElement.querySelector(
				'input'
			);
		});

		it('should toggle the disabled state', () => {
			expect(radioInstance.disabled).toBeFalsy();
			expect(radioNativeElement.disabled).toBeFalsy();

			testComponent.disabled = true;
			fixture.detectChanges();
			expect(radioInstance.disabled).toBeTruthy();
			expect(radioNativeElement.disabled).toBeTruthy();

			testComponent.disabled = false;
			fixture.detectChanges();
			expect(radioInstance.disabled).toBeFalsy();
			expect(radioNativeElement.disabled).toBeFalsy();
		});
	});

	describe('only radio buttons', () => {
		let fixture: ComponentFixture<OnlyRadioButtonsComponent>;
		let radioDebugElements: DebugElement[];
		let questionRadioInstances: RadioButtonComponent[];
		let fruitRadioInstances: RadioButtonComponent[];
		let sportRadioInstances: RadioButtonComponent[];
		let fruitRadioNativeInputs: HTMLElement[];
		let testComponent: OnlyRadioButtonsComponent;

		beforeEach(() => {
			fixture = TestBed.createComponent(OnlyRadioButtonsComponent);
			fixture.detectChanges();

			testComponent = fixture.debugElement.componentInstance;

			radioDebugElements = fixture.debugElement.queryAll(
				By.directive(RadioButtonComponent)
			);
			questionRadioInstances = radioDebugElements
				.filter(debugEl => debugEl.componentInstance.name === 'question')
				.map(debugEl => debugEl.componentInstance);
			sportRadioInstances = radioDebugElements
				.filter(debugEl => debugEl.componentInstance.name === 'sport')
				.map(debugEl => debugEl.componentInstance);
			fruitRadioInstances = radioDebugElements
				.filter(debugEl => debugEl.componentInstance.name === 'fruit')
				.map(debugEl => debugEl.componentInstance);

			const fruitRadioNativeElements = radioDebugElements
				.filter(debugEl => debugEl.componentInstance.name === 'fruit')
				.map(debugEl => debugEl.nativeElement);

			fruitRadioNativeInputs = [];
			for (const element of fruitRadioNativeElements) {
				fruitRadioNativeInputs.push(<HTMLElement>(
					element.querySelector('input')
				));
			}
		});

		it('should select radios by a name', () => {
			questionRadioInstances[0].checked = true;
			fruitRadioInstances[1].checked = true;

			fixture.detectChanges();
			expect(questionRadioInstances[0].checked).toBe(true);
			expect(questionRadioInstances[1].checked).toBe(false);
			expect(fruitRadioInstances[0].checked).toBe(false);
			expect(fruitRadioInstances[1].checked).toBe(true);

			sportRadioInstances[2].checked = true;
			fixture.detectChanges();
			expect(sportRadioInstances[0].checked).toBe(false);
			expect(sportRadioInstances[1].checked).toBe(false);
			expect(sportRadioInstances[2].checked).toBe(true);

			questionRadioInstances[1].checked = true;
			expect(questionRadioInstances[0].checked).toBe(false);
			expect(questionRadioInstances[1].checked).toBe(true);
		});

		it('should add required on input element if defined', () => {
			const radioInstance = sportRadioInstances[0];
			radioInstance.required = true;
			fixture.detectChanges();

			expect(radioInstance.required).toBe(true);
		});
	});
});
