import {
	Component,
	OnInit,
	Input,
	EventEmitter,
	OnDestroy,
	ViewEncapsulation,
	ChangeDetectorRef,
	ElementRef,
	Output,
	ChangeDetectionStrategy,
	Optional
} from '@angular/core';
import { UniqueSelectionDispatcher } from '@angular/cdk/collections';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { RadioGroupDirective } from './radio-group.directive';
import { RadioButton, SnRadioChange } from './radio-button.interface';

/**
 * Option IDs need to be unique across components, so this counter exists outside of
 * the component definition.
 */
let _uniqueIdCounter = 0;

/**
 *
 *  Genera un componente radio-button
 * @export
 */
@Component({
	selector: 'sn-radio-button',
	templateUrl: './radio-button.component.html',
	styleUrls: ['./radio-button.component.scss'],
	encapsulation: ViewEncapsulation.None,
	host: {
		'[attr.id]': 'id',
		'[class.sn-radio-disabled]': 'disabled'
	},
	changeDetection: ChangeDetectionStrategy.OnPush
})
export class RadioButtonComponent
	implements OnInit, OnDestroy, RadioButton {
	/**
	 *  Crea una instancia del componente RadioButtonComponent.
	 *
	 * @param radioGroup
	 * @param elementRef
	 * @param changeDetectorRef
	 * @param radioDispatcher
	 * @memberof RadioButtonComponent
	 */
	constructor(
		@Optional() radioGroup: RadioGroupDirective,
		private elementRef: ElementRef<HTMLElement>,
		private changeDetectorRef: ChangeDetectorRef,
		private radioDispatcher: UniqueSelectionDispatcher
	) {
		this.radioGroup = radioGroup;
		this._removeUniqueSelectionListener = this.radioDispatcher.listen(
			(id: string, name: string) => {
				if (id !== this.id && name === this.name) {
					this.checked = false;
				}
			}
		);
	}

	/**
   * @ignore
	 *  Indica si el componente esta habilitado o deshabilitado.
	 *
	 * @private
	 * @memberof RadioButtonComponent
	 */
	private _disabled = false;

	/**
   * @ignore
	 *  Indica si el componente fue seleccionado.
	 *
	 * @private
	 * @memberof RadioButtonComponent
	 */
	private _checked = false;

	/**
   * @ignore
	 *  Indica si el componente es requerido o no.
	 *
	 * @private
	 * @memberof RadioButtonComponent
	 */
	private _required = false;

	/**
   * @ignore
	 *  Indica el valor del componente.
	 *
	 * @private
	 * @type {*}
	 * @memberof RadioButtonComponent
	 */
	private _value: any;

	/**
   * @ignore
	 *  Grupo al que pertenece el radio button.
	 *
	 * @private
	 * @type {RadioGroupDirective}
	 * @memberof RadioButtonComponent
	 */
	private radioGroup: RadioGroupDirective;

	/**
	 *  Parametro que establece el id único que tiene cada una de las
	 *   instancias del componente.
	 *
	 * @memberof RadioButtonComponent
	 */
	@Input() id = `sn-radio-button-${_uniqueIdCounter++}`;

	/**
	 *  Parametro que establece el nombre del componente que se usa
	 *  como identificador dentro de un grupo para mantener una seleccion unica.
	 *
	 * @memberof RadioButtonComponent
	 */
	@Input() name: any;

	/**
	 *  Parametro que establece el id unico que tiene cada input dentro del compo nente.
	 *
	 * @readonly
	 * @memberof RadioButtonComponent
	 */
	@Input()
	get inputId() {
		return `${this.id}-input`;
	}

	/**
	 *  Parametro que almacena el valor del compo nente.
	 *
	 * @readonly
	 * @memberof RadioButtonComponent
	 */
	@Input()
	get value(): any {
		return this._value;
	}
	set value(value: any) {
		if (this._value !== value) {
			this._value = value;
			if (this.radioGroup !== null) {
				if (!this.checked) {
					this.checked = this.radioGroup.value === value;
				}
				if (this.checked) {
					this.radioGroup.selected = this;
				}
			}
		}
	}

	/**
	 *  Parametro que indica si el componente ha sido seleccionado.
	 *  Set contiene la lógica para mantener una selección unica.
	 *
	 * @readonly
	 * @memberof RadioButtonComponent
	 */
	@Input()
	get checked(): boolean {
		return this._checked;
	}
	set checked(value: boolean) {
		const newState = coerceBooleanProperty(value);
		if (this._checked !== newState) {
			this._checked = newState;
			if (newState && this.radioGroup && this.radioGroup.value !== this.value) {
				this.radioGroup.selected = this;
			} else if (
				!newState &&
				this.radioGroup &&
				this.radioGroup.value === this.value
			) {
				// When unchecking the selected radio button, update the selected radio
				// property on the group.
				this.radioGroup.selected = null;
			}
			if (newState) {
				// Notify all radio buttons with the same name to un-check.
				this.radioDispatcher.notify(this.id, this.name);
			}
			this._markForCheck();
		}
	}

	/**
	 *  Parametro que indica si es necesaria la seleccion del componente
	 *  o de al menos uno si se encuentra dentro de un grupo.
	 *
	 * @readonly
	 * @memberof RadioButtonComponent
	 */
	@Input()
	get required(): boolean {
		return this._required || (this.radioGroup && this.radioGroup.required);
	}
	set required(value: boolean) {
		this._required = coerceBooleanProperty(value);
	}

	/**
	 *  Parametro que indica el atributo <code>disabled</code> del elemento.
	 *
	 * @readonly
	 * @memberof RadioButtonComponent
	 */
	@Input()
	get disabled(): boolean {
		return (
			this._disabled || (this.radioGroup !== null && this.radioGroup.disabled)
		);
	}
	set disabled(value: boolean) {
		const newDisabledState = coerceBooleanProperty(value);
		if (this._disabled !== newDisabledState) {
			this._disabled = newDisabledState;
			this._markForCheck();
		}
	}

	/**
	 *  Evento que se emite cuando hay un cambio en el componente.
	 *
	 * @memberof RadioButtonComponent
	 */
	@Output() readonly change: EventEmitter<SnRadioChange> = new EventEmitter<
		SnRadioChange
	>();

	/**
   * @ignore
	 *  Listener para remover la selección unica de radio buttons.
	 *
	 * @memberof RadioButtonComponent
	 */
	private _removeUniqueSelectionListener: () => void = () => {};

	/**
	 *  Cambia el estado del componente.
	 *
	 * @memberof RadioButtonComponent
	 */
	_markForCheck(): void {
		this.changeDetectorRef.markForCheck();
	}

	/**
	 *  Emite el cambio con el valor actual del componente.
	 *
	 * @memberof RadioButtonComponent
	 */
	_emitChangeEvent(): void {
		this.change.emit(new SnRadioChange(this, this._value));
	}

	/**
	 *  Detiene la propagación de eventos.
	 *
	 * @param event
	 * @memberof RadioButtonComponent
	 */
	_onInputClick(event: Event): void {
		event.stopPropagation();
	}

	/**
	 *  Se ejecuta cuando el componente es seleccionado mediante un click
	 * o el input dentro reconoce algun cambio.
	 *
	 * @param event
	 * @memberof RadioButtonComponent
	 */
	_onInputChange(event: Event): void {
		event.stopPropagation();
		const groupValueChanged =
			this.radioGroup && this.value !== this.radioGroup.value;
		this.checked = true;
		this._emitChangeEvent();

		if (this.radioGroup) {
			this.radioGroup._controlValueAccessorChangeFn(this.value);
			this.radioGroup._touch();
			if (groupValueChanged) {
				this.radioGroup._emitChangeEvent();
			}
		}
	}

	/**
   * @ignore
	 *  Inicializa las propiedades name y checked si el componente pertenece a un grupo,
	 * además añade el componente al grupo.
	 *
	 * @memberof RadioButtonComponent
	 */
	ngOnInit(): void {
		if (this.radioGroup) {
			this.radioGroup.addRadio(this);
			this.checked = this.radioGroup.value === this._value;
			this.name = this.radioGroup.name;
		}
	}

	/**
   * @ignore
	 * Detiene el monitor y deja de escuchar en el radioDispatcher.
	 *
	 * @memberof RadioButtonComponent
	 */
	ngOnDestroy(): void {
		this._removeUniqueSelectionListener();
	}
}
