import { NgModule } from '@angular/core';
import { RadioButtonComponent } from './radio-button.component';
import { RadioGroupDirective } from './radio-group.directive';

import { CommonModule } from '@angular/common';

@NgModule({
	imports: [CommonModule],
	declarations: [RadioButtonComponent, RadioGroupDirective],
	exports: [RadioButtonComponent, RadioGroupDirective]
})
export class RadioButtonModule {}
