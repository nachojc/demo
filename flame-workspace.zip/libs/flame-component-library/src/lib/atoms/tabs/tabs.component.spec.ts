import { By } from '@angular/platform-browser';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TabsComponent } from './tabs.component';
import { TabComponent } from '../tab/tab.component';
import { Component } from '@angular/core';


@Component({
  template:`
  <sn-tabs>
    <sn-tab tabTitle="Foo">
      Content of tab Foo
    </sn-tab>
    <sn-tab tabTitle="Bar">
      Content of tab Bar
    </sn-tab>
  </sn-tabs>
  `
})
class TabsComponentMockComponent {}

describe('TabsComponent', () => {
	let component: TabsComponent;
	let fixture: ComponentFixture<TabsComponentMockComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TabsComponentMockComponent, TabsComponent, TabComponent],
			providers: [TabsComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TabsComponentMockComponent);
		component = fixture.debugElement.children[0].componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
  });

	it('test tabs contents', () => {
    expect(component.tabs['_results'][0].tabTitle).toEqual('Foo');
    expect(component.tabs.length).toBe(2);
  });

	it('select second tab', () => {
    const tab = fixture.debugElement.queryAll(By.css('.sn-tab'));
    tab[0].nativeElement.click();
    fixture.detectChanges();
    expect(component.tabs['_results'][0].active).toBeTruthy();
    expect(component.tabs['_results'][1].active).toBeFalsy();
    tab[1].nativeElement.click();
    fixture.detectChanges();
    expect(component.tabs['_results'][1].active).toBeTruthy();
    expect(component.tabs['_results'][0].active).toBeFalsy();
	});
});
