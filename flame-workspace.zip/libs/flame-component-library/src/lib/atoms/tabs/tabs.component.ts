import { Component, ContentChildren, QueryList } from '@angular/core';
import { TabComponent } from '../tab/tab.component';

/**
 * El componente <code>sn-tabs</code> permite ver 
 * tabs según el sistema de diseño
 *
 * @export
 * @class TabsComponent
 */
@Component({
	selector: 'sn-tabs',
	templateUrl: './tabs.component.html',
	styleUrls: ['./tabs.component.scss']
})
export class TabsComponent {
	/**
	 * Lista de tabs visualizados
	 *
	 * @type {QueryList<TabComponent>}
	 * @memberof TabsComponent
	 */
	@ContentChildren(TabComponent) tabs: QueryList<TabComponent>;

	/**
	 * Activa el tab seleccionado con evento click y desactiva el resto
	 *
	 * @param {TabComponent} tab
	 * @memberof TabsComponent
	 */
	selectTab(tab: TabComponent) {
		this.tabs.forEach(_tab => {
			_tab.active = false;
		});
		tab.active = true;
	}
}
