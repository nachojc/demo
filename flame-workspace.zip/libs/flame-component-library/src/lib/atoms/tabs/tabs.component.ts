import { Component, ContentChildren, QueryList } from '@angular/core';
import { TabComponent } from '../tab/tab.component';

@Component({
	selector: 'sn-tabs',
	templateUrl: './tabs.component.html',
	styleUrls: ['./tabs.component.scss']
})
export class TabsComponent {
	constructor() {}

	@ContentChildren(TabComponent) tabs: QueryList<TabComponent>;

	selectTab(tab: TabComponent) {
		this.tabs.forEach(_tab => {
			_tab.active = false;
		});
		tab.active = true;
	}
}
