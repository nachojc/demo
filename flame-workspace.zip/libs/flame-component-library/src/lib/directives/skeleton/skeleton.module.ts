import { FormsModule } from '@angular/forms';
import { SkeletonDirective } from './skeleton.directive';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

@NgModule({
	declarations: [SkeletonDirective],
	imports: [CommonModule, FormsModule],
	exports: [SkeletonDirective]
})
export class SkeletonModule {}
