export * from './skeleton.module';
