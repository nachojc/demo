import {
  Directive,
  OnInit,
  ElementRef,
  OnChanges,
  Input,
  SimpleChanges,
  Renderer2
} from '@angular/core';

@Directive({
  selector: '[snSkeleton]'
})
export class SkeletonDirective implements OnInit, OnChanges {
  constructor(private elementRef: ElementRef, private renderer: Renderer2) { }
  @Input() skeletonValue: number | string;
  @Input() skeletonWidth = '100%';
  @Input() skeletonHeight = '100%';
  @Input() skeletonColor: string;
  ngOnInit() {
    if (this.skeletonValue === undefined) {
      this.renderer.addClass(this.elementRef.nativeElement, 'skeleton');
      this.renderer.setStyle(this.elementRef.nativeElement, 'width', this.skeletonWidth);
      this.renderer.setStyle(this.elementRef.nativeElement, 'height', this.skeletonHeight);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (this.skeletonValue !== undefined) {
      this.renderer.removeClass(this.elementRef.nativeElement, 'skeleton');
      this.renderer.setStyle(this.elementRef.nativeElement, 'width', 'inherit');
      this.renderer.setStyle(this.elementRef.nativeElement, 'height', 'inherit');
    }
  }
}
