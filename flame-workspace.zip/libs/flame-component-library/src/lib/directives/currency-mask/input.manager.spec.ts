import { InputManager } from './input.manager';
import { Component, ViewChild, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SnCurrencyMaskDirective } from './currency-mask.directive';
import { By } from '@angular/platform-browser';

@Component({
    selector: 'sn-test-currencymask',
    template: `<input type="text" snCurrencyMask>`
})

class TestSnCurrencyMaskComponent {
    @ViewChild(SnCurrencyMaskDirective) sncurrencymask: SnCurrencyMaskDirective;
    options = {align: "left"};
    optionsTemplate = {
        align: "right",
        allowNegative: true,
        allowZero: true,
        decimal: ".",
        precision: 2,
        prefix: "",
        suffix: "",
        thousands: ",",
        nullable: false
    };
}

describe('InputManager of SnCurrencyMask', () => {
    let inputManager: InputManager
    let component: TestSnCurrencyMaskComponent;
    let fixture: ComponentFixture<TestSnCurrencyMaskComponent>;
    let inputEl: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [SnCurrencyMaskDirective, TestSnCurrencyMaskComponent]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(TestSnCurrencyMaskComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    it('rawValue get and set', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        const preValue ='1234';
        const val = '5678';
        inputEl.nativeElement.value = preValue;
        inputManager = new InputManager(inputEl.nativeElement);
        expect(inputManager.rawValue).toBe(preValue);
        inputManager.rawValue = val;
        expect(inputManager.rawValue).toBe(val);
    })

    it('storedRawValue getter', () => {
        const val = '5678';
        inputEl = fixture.debugElement.query(By.css('input'));
        inputManager = new InputManager(inputEl.nativeElement);
        inputManager.rawValue = val;
        expect(inputManager.storedRawValue).toBe(val);
    });

    it('setCursorAt method with htmlInputElement.setSelectionRange', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.setSelectionRange = true;
        spyOn(inputEl.nativeElement,'focus');
        spyOn(inputEl.nativeElement,'setSelectionRange')
        inputManager = new InputManager(inputEl.nativeElement);
        const position = 2;
        inputManager.setCursorAt(position);
        expect(inputEl.nativeElement.focus).toHaveBeenCalled();
        expect(inputEl.nativeElement.setSelectionRange).toHaveBeenCalledWith(position,position);
    });

    // it('setCursorAt method with htmlInputElement.createTextRange', () => {
    //     const input =  document.createElement('body');
    //     document.body.createTextRnge()
    //     input.createTextRange();
    //     inputManager = new InputManager(anyEl.nativeElement);
    //     const position = 2;
    //     inputManager.setCursorAt(position);
    //     const text = inputEl.nativeElement.createTextRange();
    //     spyOn(inputEl.nativeElement,'createTextRange');
    //     const text = inputEl.nativeElement.createTextRange();
    //     spyOn(text,'collapse')

    //     spyOn(inputEl.nativeElement.createTextRange,'moveEnd');
    //     spyOn(inputEl.nativeElement.createTextRange,'moveStart');
    //     spyOn(inputEl.nativeElement.createTextRange,'select');
    //     inputManager = new InputManager(inputEl.nativeElement);
    //     const position = 2;
    //     inputManager.setCursorAt(position);
    //     expect(inputEl.nativeElement.createTextRange).toHaveBeenCalled();
    // });

    it('updateValueAndCursor method', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.value = '12312341234123';
        inputManager = new InputManager(inputEl.nativeElement);
        spyOn(inputManager,'setCursorAt')
        const newRawValue = '1234';
        const oldLength = 4;
        const selectionStart = 1;
        const dif = selectionStart - (oldLength-newRawValue.length);
        inputManager.updateValueAndCursor(newRawValue,oldLength,selectionStart);
        expect(inputManager.rawValue).toBe(newRawValue);
        expect(inputManager.setCursorAt).toHaveBeenCalledWith(dif);
    });

    it('inputSelection getter', () => {
        const start = 4;
        const end = 10;
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.value = '12312341234123';
        inputEl.nativeElement.setSelectionRange(start,end); 
        inputManager = new InputManager(inputEl.nativeElement);
        expect(inputManager.inputSelection).toEqual({
            selectionStart: start,
            selectionEnd: end
        });
    });

    it('canInputMoreNumbers getter when having reached max length', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.maxLength = 4;
        inputManager = new InputManager(inputEl.nativeElement);
        inputManager.rawValue = 'ABCDE';
        expect(inputManager.canInputMoreNumbers).toBeFalsy();
    });

    it('canInputMoreNumbers getter when not having number selected', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.value = '123';
        inputEl.nativeElement.setSelectionRange(2,2);
        inputEl.nativeElement.maxLength = 4; 
        inputManager = new InputManager(inputEl.nativeElement);
        inputManager.rawValue = 'ABCDEASDAS';
        expect(inputManager.canInputMoreNumbers).toBeFalsy();
    });

    it('canInputMoreNumbers getter when not starting with 0', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.value = '023';
        inputEl.nativeElement.setSelectionRange(2,2);
        inputEl.nativeElement.maxLength = 4; 
        inputManager = new InputManager(inputEl.nativeElement);
        inputManager.rawValue = 'ABCDEASDAS';
        expect(inputManager.canInputMoreNumbers).toBeFalsy();
    });
    
    it('canInputMoreNumbers getter is true', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.value = '023';
        inputManager = new InputManager(inputEl.nativeElement);
        inputManager.rawValue = 'ABC';
        expect(inputManager.canInputMoreNumbers).toBeTruthy();
    });

});
