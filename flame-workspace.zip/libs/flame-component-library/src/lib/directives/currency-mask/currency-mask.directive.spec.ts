import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SnCurrencyMaskDirective } from './currency-mask.directive';
import { Component, ViewChild } from '@angular/core';
import { InputHandler } from './input.handler';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

@Component({
    selector: 'sn-test-currencymask',
    template: `<input type="text" snCurrencyMask>`
})

class TestSnCurrencyMaskComponent {
    @ViewChild(SnCurrencyMaskDirective) sncurrencymask: SnCurrencyMaskDirective;
    options = {align: "left"};
    optionsTemplate = {
        align: "right",
        allowNegative: true,
        allowZero: true,
        decimal: ".",
        precision: 2,
        prefix: "",
        suffix: "",
        thousands: ",",
        nullable: false,
        integers: 2
    };
}

describe('SnCurrencyMaskDirective', async() => {
    let component: TestSnCurrencyMaskComponent;
    let fixture: ComponentFixture<TestSnCurrencyMaskComponent>;
    let inputEl: DebugElement;

    beforeEach(async() => {
        TestBed.configureTestingModule({
            declarations: [SnCurrencyMaskDirective, TestSnCurrencyMaskComponent]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(TestSnCurrencyMaskComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    })

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('ngAfterViewInit', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        component.sncurrencymask.optionsTemplate = component.optionsTemplate;
        component.sncurrencymask.options = null;
        component.sncurrencymask.ngAfterViewInit();
        expect(inputEl.nativeElement.style.textAlign).toBe(component.sncurrencymask.optionsTemplate.align);
        component.sncurrencymask.options = component.options;
        component.sncurrencymask.ngAfterViewInit();
        expect(inputEl.nativeElement.style.textAlign).toBe(component.sncurrencymask.options.align);
    });

    it('ngDoCheck', () => {
        spyOn(component.sncurrencymask.inputHandler,'updateOptions');
        inputEl = fixture.debugElement.query(By.css('input'));
        component.sncurrencymask.optionsTemplate = component.optionsTemplate;
        component.sncurrencymask.options.align = null;
        component.sncurrencymask.ngDoCheck();
        expect(inputEl.nativeElement.style.textAlign).toBe(component.sncurrencymask.optionsTemplate.align);
        component.sncurrencymask.options = component.options;
        component.sncurrencymask.ngDoCheck();
        expect(inputEl.nativeElement.style.textAlign).toBe(component.sncurrencymask.options.align);
        expect(component.sncurrencymask.inputHandler.updateOptions).toHaveBeenCalledWith((<any>Object).assign({}, component.sncurrencymask.optionsTemplate, component.sncurrencymask.options));

    })

    it('ngOnInit', () => {
        inputEl = fixture.debugElement.query(By.css('input'));
        const inputHandler = new InputHandler(inputEl.nativeElement, (<any>Object).assign({}, component.sncurrencymask.optionsTemplate, component.sncurrencymask.options));
        component.sncurrencymask.ngOnInit();
        expect(component.sncurrencymask.inputHandler).toEqual(inputHandler);
    });

    // it('handleBlur HostListener method', () => {
    //     component.sncurrencymask.inputHandler.setOnModelTouched((a: any)=>{a.toString()});
    //     console.log(component.sncurrencymask.inputHandler.getOnModelTouched())
    //     spyOn(component.sncurrencymask.inputHandler,'getOnModelTouched');
    //     const event = new Event('blur');
    //     component.sncurrencymask.handleBlur(event);
    //     expect(component.sncurrencymask.inputHandler.getOnModelTouched).toHaveBeenCalled();
    // });

    it('handleInput HostListener method', () => {
        spyOn(component.sncurrencymask.inputHandler,'handleInput');
        const event = new Event('input');
        component.sncurrencymask.handleInput(event);
        expect(component.sncurrencymask.inputHandler.handleInput).toHaveBeenCalledWith(event);
    });

    it('handleCut HostListener method', () => {
        spyOn(component.sncurrencymask.inputHandler,'handleCut');
        const event = new Event('cut');
        component.sncurrencymask.handleCut(event);
        expect(component.sncurrencymask.inputHandler.handleCut).toHaveBeenCalledWith(event);
    });

    it('handlePaste HostListener method', () => {
        spyOn(component.sncurrencymask.inputHandler,'handlePaste');
        const event = new Event('paste');
        component.sncurrencymask.handlePaste(event);
        expect(component.sncurrencymask.inputHandler.handlePaste).toHaveBeenCalledWith(event);
    });

    it('registerOnChange ControlValueAccessor interface method', () =>{
        const callbackFn: Function = () => {};
        spyOn(component.sncurrencymask.inputHandler,'setOnModelChange');
        component.sncurrencymask.registerOnChange(callbackFn);
        expect(component.sncurrencymask.inputHandler.setOnModelChange).toHaveBeenCalledWith(callbackFn);
    });

    it('registerOnTouched ControlValueAccessor interface method', () =>{
        const callbackFn: Function = () => {};
        spyOn(component.sncurrencymask.inputHandler,'setOnModelTouched');
        component.sncurrencymask.registerOnTouched(callbackFn);
        expect(component.sncurrencymask.inputHandler.setOnModelTouched).toHaveBeenCalledWith(callbackFn);
    });

    it('setDisabledState ControlValueAccessor interface method', () =>{
        component.sncurrencymask.setDisabledState(true);
        inputEl = fixture.debugElement.query(By.css('input'));
        expect(inputEl.nativeElement.disabled).toBeTruthy();
    });

    it('writeValue ControlValueAccessor interface method', () => {
        spyOn(component.sncurrencymask.inputHandler,'setValue');
        const value = 9;
        component.sncurrencymask.writeValue(value);
        expect(component.sncurrencymask.inputHandler.setValue).toHaveBeenCalledWith(value);
    });
});
