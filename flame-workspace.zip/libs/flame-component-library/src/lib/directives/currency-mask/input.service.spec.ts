import { Component, ViewChild, DebugElement } from '@angular/core';
import { InputService } from './input.service';
import { SnCurrencyMaskConfig } from './currency-mask.config';
import { SnCurrencyMaskDirective } from './currency-mask.directive';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

@Component({
    selector: 'sn-test-currencymask',
    template: `<input type="text" snCurrencyMask>`
})

class TestSnCurrencyMaskComponent {
    @ViewChild(SnCurrencyMaskDirective) sncurrencymask: SnCurrencyMaskDirective;
    options = {align: "left"};
    optionsTemplate = {
        align: "right",
        allowNegative: true,
        allowZero: true,
        decimal: ".",
        precision: 2,
        prefix: "",
        suffix: "",
        thousands: ",",
        nullable: false
    };
}

describe('InputService of SnCurrencyMask', () => {
    let options: any;
    let inputService: InputService
    let component: TestSnCurrencyMaskComponent;
    let fixture: ComponentFixture<TestSnCurrencyMaskComponent>;
    let inputEl: DebugElement;

    beforeEach(() => {
        TestBed.configureTestingModule({
            declarations: [SnCurrencyMaskDirective, TestSnCurrencyMaskComponent]
        })
        .compileComponents();
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(TestSnCurrencyMaskComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    });

    beforeEach(async() => {
        options = [{
            prefix: '',
            thousands: '.',
            decimal: ',',
            allowNegative: false,
            nullable: false
        }];
        inputEl = fixture.debugElement.query(By.css('input'));
        inputService = new InputService(inputEl.nativeElement,options);
    });

    it('addNumber method', () => {
        const noVal = '';
        inputService.rawValue = noVal;
        spyOn(inputService, 'updateFieldValue');
        inputService.addNumber(2);
        expect(inputService.rawValue).not.toBe(noVal);
        expect(inputService.updateFieldValue).toHaveBeenCalled();
    });

    // it('removeNumber when no value and nullable', () => {
    //     inputService.updateOptions({nullable:true});
    //     inputService.rawValue = '123';
    //     inputService.value = 0;
    //     inputService.removeNumber(2);
    //     expect(inputService.rawValue).toBe('');
    // });

    it('removeNumber method', () => {
        const options2: SnCurrencyMaskConfig  = {
            align: 'center',
            allowNegative: false,
            allowZero: true,
            decimal: '.',
            precision: 2,
            prefix: 'PRE',
            suffix: 'SUF',
            thousands: ',',
            nullable: true,
            integers: 2
        };
        inputService = new InputService(inputEl.nativeElement,options);
        inputService.updateOptions(options2);
        const val = '123';
        inputService.rawValue = val;
        spyOn(inputService, 'updateFieldValue');
        inputService.removeNumber(2);
        expect(inputService.updateFieldValue).toHaveBeenCalled();
    });

    it('clearMask method', () => {
        inputService.updateOptions({nullable: true});
        expect(inputService.clearMask("")).toBeNull();
        expect(inputService.clearMask('123')).toBe(123);
    });

    it('changeToNegative method', () => {
        const options2: SnCurrencyMaskConfig  = {
            align: 'center',
            allowNegative: true,
            allowZero: true,
            decimal: '.',
            precision: 2,
            prefix: 'PRE',
            suffix: 'SUF',
            thousands: ',',
            nullable: true,
            integers: 2
        };
        const val = '123';
        inputService.updateOptions(options2);
        inputService.value = 2
        inputService.rawValue = val;
        inputService.changeToNegative();
        expect(inputService.rawValue).toBe("-"+val);
    });

    it('changeToPositive method', () => {
        const rawVal = '-1';
        inputService.rawValue = rawVal;
        inputService.changeToPositive();
        expect(inputService.rawValue).toBe(rawVal.replace("-",""));
    });

    it('updateOptions method',() => {
        const options2: SnCurrencyMaskConfig  = {
            align: 'center',
            allowNegative: false,
            allowZero: true,
            decimal: '.',
            precision: 2,
            prefix: 'PRE',
            suffix: 'SUF',
            thousands: ',',
            nullable: true,
            integers: 2
        };

        inputService = new InputService(inputEl.nativeElement,options);
        const inputServicePrev = Object.assign({},inputService);
        inputService.updateOptions(options2);
        expect(inputService).not.toBe(inputServicePrev);
    });

    it('prefixLength method', () => {
        const opt = {prefix:'ABC'};
        const length = opt.prefix.length;
        inputService.updateOptions(opt);
        expect(inputService.prefixLength()).toBe(length);
    });

    it('isNullable method', () => {
        const opt = {nullable: true};
        inputService.updateOptions(opt);
        expect(inputService.isNullable()).toBeTruthy();
    });

    it('canInputMoreNumbers getter', () => {
        expect(inputService.canInputMoreNumbers).toBe(inputService.inputManager.canInputMoreNumbers);
    });

    it('inputSelection getter', () => {
        expect(inputService.inputSelection).toEqual(inputService.inputManager.inputSelection);
    });

    it('rawValue getter', () => {
        expect(inputService.rawValue).toBe(inputService.inputManager.rawValue);
    });

    it('rawValue setter', () => {
        const val = '123'
        inputService.rawValue = val;
        expect(inputService.inputManager.rawValue).toBe(val);
    });

    it('storedRawValue getter', () => {
        expect(inputService.storedRawValue).toBe(inputService.inputManager.storedRawValue);
    });

    it('value getter', () => {
       expect(inputService.value).toBe(inputService.clearMask(inputService.rawValue));
    });

    it('value setter', () => {
        const val = 2;
        inputService.value = val;
        expect(inputService.rawValue).toBe(inputService.applyMask(true,""+val));
    });

});
