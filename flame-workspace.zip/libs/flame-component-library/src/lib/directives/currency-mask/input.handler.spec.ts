import { InputHandler } from './input.handler';
import { Component, ViewChild } from '@angular/core';
import { DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { SnCurrencyMaskDirective } from './currency-mask.directive';
import { By } from '@angular/platform-browser';

@Component({
    selector: 'sn-test-currencymask',
    template: `<input type="text" snCurrencyMask>`
})

class TestSnCurrencyMaskComponent {
    @ViewChild(SnCurrencyMaskDirective) sncurrencymask: SnCurrencyMaskDirective;
    options = {align: "left"};
    optionsTemplate = {
        align: "right",
        allowNegative: true,
        allowZero: true,
        decimal: ".",
        precision: 2,
        prefix: "",
        suffix: "",
        thousands: ",",
        nullable: false,
        integers: 2
    };
}

describe('InputHandler of SnCurrencyMask', () => {
    let options: any;
    let inputHandler: InputHandler
    let component: TestSnCurrencyMaskComponent;
    let fixture: ComponentFixture<TestSnCurrencyMaskComponent>;
    let inputEl: DebugElement;

    beforeEach(async() => {
        TestBed.configureTestingModule({
            declarations: [SnCurrencyMaskDirective, TestSnCurrencyMaskComponent]
        })
        .compileComponents();
    });

    beforeEach(async() => {
        fixture = TestBed.createComponent(TestSnCurrencyMaskComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
    })

    beforeEach(async() => {
        options = [{
            prefix: '',
            thousands: '.',
            decimal: ',',
            allowNegative: false,
            nullable: false
        }];
        inputEl = fixture.debugElement.query(By.css('input'));
        inputHandler = new InputHandler(inputEl.nativeElement,options);
    });

    it('setOnModelChange and getOnModelChange method', async() => {
        const func = () => {};
        inputHandler.setOnModelChange(func);
        expect(inputHandler.getOnModelChange()).toEqual(func);
    });

    it('setOnModelTouched and getOnModelTouched method', async() => {
        const func = () => {};
        inputHandler.setOnModelTouched(func);
        expect(inputHandler.getOnModelTouched()).toEqual(func);
    });

    it('clearValue method', () => {
        spyOn(inputHandler,'setValue');
        const func = () => {};
        inputHandler.setOnModelChange(func);
        inputHandler.clearValue();
        expect(inputHandler.setValue).toHaveBeenCalled();
    });

    it('handleCut method', fakeAsync(() => {
        spyOn(inputHandler,'setValue');
        const event = new Event('cut');
        const func = () => {};
        inputHandler.setOnModelChange(func);
        inputHandler.handleCut(event);
        tick(100);
        expect(inputHandler.setValue).toHaveBeenCalled();
    }));

    it('clearValue method', () => {
        options = [{
            prefix: '',
            thousands: '.',
            decimal: ',',
            allowNegative: false,
            nullable: true
        }];
        inputHandler = new InputHandler(inputEl.nativeElement,options);
        spyOn(inputHandler,'setValue');
        const func = () => {};
        inputHandler.setOnModelChange(func);
        inputHandler.clearValue();
        expect(inputHandler.setValue).toHaveBeenCalled();
    });

    it('handlePaste method', fakeAsync(() => {
        spyOn(inputHandler,'setValue');
        const event = new Event('paste');
        const func = () => {};
        inputHandler.setOnModelChange(func);
        inputHandler.handlePaste(event);
        tick(100);
        expect(inputHandler.setValue).toHaveBeenCalled();
    }));

    it('setValue method', () => {
        inputHandler.setValue(1);
        expect(inputEl.nativeElement.value).toBe('undefinedundefined');
    });

    it('updateOptions method', () => {
        options = [{
            prefix: '',
            thousands: '.',
            decimal: ',',
            allowNegative: false,
            nullable: true
        }];
        inputHandler = new InputHandler(inputEl.nativeElement,options);
        const handlerPrev = Object.assign({},inputHandler);
        inputHandler.updateOptions({});
        expect(inputHandler).not.toBe(handlerPrev);
    });

    // it('handleInput method', fakeAsync(() => {
    //     const event =
    //     {
    //         target: {value:'123',
    //                 setSelectionRange: (a:any,b:any) => {}
    //                 }
    //     };
    //     const func = () => {};
    //     inputEl.nativeElement.value = '12312341234123';
    //     inputEl.nativeElement.setSelectionRange(2,4);
    //     inputHandler = new InputHandler(inputEl.nativeElement,options);
    //     inputHandler.setOnModelChange(func);
    //     inputHandler.handleInput(event);
    //     tick(200)
    // }));

});
