import {ModuleWithProviders, NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule} from '@angular/forms';
import {SnCurrencyMaskDirective} from "./currency-mask.directive";
import {SN_CURRENCY_MASK_CONFIG, SnCurrencyMaskConfig} from "./currency-mask.config";

@NgModule({
  imports: [ CommonModule, FormsModule ],
  declarations: [ SnCurrencyMaskDirective ],
  exports: [ SnCurrencyMaskDirective ]
})
export class SnCurrencyModule {
  static forRoot(config: SnCurrencyMaskConfig): ModuleWithProviders {
    return {
      ngModule: SnCurrencyModule,
      providers: [{
        provide: SN_CURRENCY_MASK_CONFIG,
        useValue: config,
      }]
    }
  }
}
