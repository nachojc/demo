import {
  AfterViewInit,
  Directive,
  DoCheck,
  ElementRef,
  forwardRef,
  HostListener,
  Inject,
  KeyValueDiffer,
  KeyValueDiffers,
  Input,
  OnInit,
  Optional
} from "@angular/core";

import { ControlValueAccessor, NG_VALUE_ACCESSOR } from "@angular/forms";
import { SnCurrencyMaskConfig, SN_CURRENCY_MASK_CONFIG } from "./currency-mask.config";
import { InputHandler } from "./input.handler";

/* tslint:disable */
export const SN_CURRENCYMASKDIRECTIVE_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => SnCurrencyMaskDirective),
  multi: true,
};
/* tslint:enable */

/**
 * Genera una mascara de currency para input.
 *
 * @export
 * @class SnCurrencyMaskDirective
 * @implements {AfterViewInit}
 * @implements {ControlValueAccessor}
 * @implements {DoCheck}
 * @implements {OnInit}
 */
@Directive({
  selector: "[snCurrencyMask]",
  providers: [SN_CURRENCYMASKDIRECTIVE_VALUE_ACCESSOR]
})

export class SnCurrencyMaskDirective implements AfterViewInit, ControlValueAccessor, DoCheck, OnInit {

  /**
   *Creates an instance of SnCurrencyMaskDirective.
   * @param {SnCurrencyMaskConfig} currencyMaskConfig
   * @param {ElementRef} elementRef
   * @param {KeyValueDiffers} keyValueDiffers
   * @memberof SnCurrencyMaskDirective
   */
  constructor(@Optional() @Inject(SN_CURRENCY_MASK_CONFIG) private currencyMaskConfig: SnCurrencyMaskConfig,
    private elementRef: ElementRef,
    private keyValueDiffers: KeyValueDiffers) {
    if (currencyMaskConfig) {
      this.optionsTemplate = currencyMaskConfig;
    }
    
    this.keyValueDiffer = keyValueDiffers.find({}).create();
  }

  /**
   * @ignore
   *  Indica la instancia del InputHandler.
   *
   * @type {InputHandler}
   * @memberof SnCurrencyMaskDirective
   */
  public inputHandler: InputHandler;

  /**
   * @ignore
   *  Indica la instancia del KeyValueDiffer
   *
   * @type {KeyValueDiffer<any, any>}
   * @memberof SnCurrencyMaskDirective
   */
  public keyValueDiffer: KeyValueDiffer<any, any>;

  /**
   * @ignore
   *  Indica la configuración inicial de la directiva.
   *
   * @memberof SnCurrencyMaskDirective
   */
  public optionsTemplate = {
    align: "right",
    allowNegative: true,
    allowZero: true,
    decimal: ".",
    precision: 2,
    prefix: "",
    suffix: "",
    thousands: ",",
    nullable: false,
    integers: 2
  };

  /**
   *  Parametro para cambiar las opciones de la directiva.
   *
   * @type {*}
   * @memberof SnCurrencyMaskDirective
   */
  @Input() options: any = {};

  /**
   *  Parametro que gestiona el evento blur.
   *
   * @param {*} event
   * @memberof SnCurrencyMaskDirective
   */
  @HostListener("blur", ["$event"])
  handleBlur(event: any) {
    this.inputHandler.getOnModelTouched().apply(event);
  }

  /**
   *  Parametro que gestiona el evento de input.
   *
   * @param {*} event
   * @memberof SnCurrencyMaskDirective
   */
  @HostListener("input", ["$event"])
  handleInput(event: any) {
      this.inputHandler.handleInput(event);
  }

  /**
   *  Parametero que gestiona el evento del cut.
   *
   * @param {*} event
   * @memberof SnCurrencyMaskDirective
   */
  @HostListener("cut", ["$event"])
  handleCut(event: any) {
      this.inputHandler.handleCut(event);
  }

  /**
   *  Parametro que gestiona el evento de <i>paste</i>.
   *
   * @param {*} event
   * @memberof SnCurrencyMaskDirective
   */
  @HostListener("paste", ["$event"])
  handlePaste(event: any) {
      this.inputHandler.handlePaste(event);
  }

  /**
   *  Registra el cambio del input.
   *
   * @param {Function} callbackFunction
   * @memberof SnCurrencyMaskDirective
   */
  registerOnChange(callbackFunction: Function): void {
    this.inputHandler.setOnModelChange(callbackFunction);
  }

  /**
   *  Registra el evento de touch en el elemento.
   *
   * @param {Function} callbackFunction
   * @memberof SnCurrencyMaskDirective
   */
  registerOnTouched(callbackFunction: Function): void {
    this.inputHandler.setOnModelTouched(callbackFunction);
  }

  /**
   * Establece el estado de deshabilitado.
   *
   * @param {boolean} value
   * @memberof SnCurrencyMaskDirective
   */
  setDisabledState(value: boolean): void {
    this.elementRef.nativeElement.disabled = value;
  }

  /**
   * establece el valor en el input.
   *
   * @param {number} value
   * @memberof SnCurrencyMaskDirective
   */
  writeValue(value: number): void {
    this.inputHandler.setValue(value);
  }

  /**
   *@ignore
   *  Inicializa el input con la mascara.
   * @memberof SnCurrencyMaskDirective
   */
  ngAfterViewInit() {
    this.elementRef.nativeElement.style.textAlign = this.options ? this.options.align : this.optionsTemplate.align;
  }

  /**
   *@ignore
   *  Verifica los cambios realizados en el input.
   * @memberof SnCurrencyMaskDirective
   */
  ngDoCheck() {
    if (this.keyValueDiffer.diff(this.options)) {
      this.elementRef.nativeElement.style.textAlign = this.options.align ? this.options.align : this.optionsTemplate.align;
      this.inputHandler.updateOptions((<any>Object).assign({}, this.optionsTemplate, this.options));
    }
  }

  /**
   *@ignore.
   *  Establece las opciones iniciales de la directiva.
   * @memberof SnCurrencyMaskDirective
   */
  ngOnInit() {
    this.inputHandler = new InputHandler(this.elementRef.nativeElement, (<any>Object).assign({}, this.optionsTemplate, this.options));
  }
}
