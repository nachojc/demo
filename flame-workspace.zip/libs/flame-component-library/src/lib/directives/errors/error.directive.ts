import { distinctUntilChanged, filter, map } from 'rxjs/operators';
import {
	Directive,
	Input,
	OnInit,
	OnDestroy,
	DoCheck,
	Inject,
	HostBinding,
	forwardRef
} from '@angular/core';
import { Observable, Subject, Subscription, combineLatest } from 'rxjs';
import { ErrorsDirective } from './errors.directive';
import { ErrorOptions } from './errors';
import { toArray } from './toArray';

@Directive({
	selector: '[snError]'
})
export class ErrorDirective implements OnInit, OnDestroy, DoCheck {
	@Input()
	set snError(value: ErrorOptions) {
		this.errorNames = toArray(value);
	}

	@Input()
	set when(value: ErrorOptions) {
		this.rules = toArray(value);
	}

	@HostBinding('hidden')
	hidden = true;

	rules: string[] = [];

	errorNames: string[] = [];

	subscription: Subscription;

	_states: Subject<string[]>;

	states: Observable<string[]>;

	constructor(
		@Inject(forwardRef(() => ErrorsDirective)) private errors: ErrorsDirective
	) {}

	ngOnInit() {
		this._states = new Subject<string[]>();
		this.states = this._states.asObservable().pipe(distinctUntilChanged());

		const errors = this.errors.subject.pipe(
			filter(error => error !== null),
			filter(obj => this.errorNames.indexOf(obj.errorName) !== -1)
		);

		const states = this.states.pipe(
			map(myStates => this.rules.every(rule => myStates.indexOf(rule) !== -1))
    );

		this.subscription = combineLatest(states, errors).subscribe(
			([myStates, myErrors]) => {
				this.hidden = !(
					myStates && myErrors.control.hasError(myErrors.errorName)
				);
			}
		);
	}

	ngDoCheck() {
		this._states.next(
			this.rules.filter(rule => (this.errors.control as any)[rule])
		);
	}

	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
}
