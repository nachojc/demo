import { ErrorDirective } from './error.directive';
import { ErrorsDirective } from './errors.directive';
import { NgModule } from '@angular/core';

@NgModule({
  declarations: [ErrorsDirective, ErrorDirective],
  exports: [ErrorsDirective, ErrorDirective]
})
export class ErrorsModule {}
