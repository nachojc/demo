import {
	Component,
	ViewEncapsulation,
	OnInit,
	Input,
	ElementRef,
	Renderer2
} from '@angular/core';

interface Circle {
	x: number;
	y: number;
	r: number;
}

interface Point {
	x: number;
	y: number;
	inversion?: Inversion;
}

export enum termFormatList {
	day = 'día',
	month = 'mes',
	year = 'año'
}

export interface Inversion {
	term: string;
	rate: string;
}

@Component({
	selector: 'sn-inversion',
	templateUrl: './inversion.component.html',
	styleUrls: ['./inversion.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class InversionComponent implements OnInit {

	constructor(private _elementRef: ElementRef, private _renderer: Renderer2) {}

	private _radius = 140;
	private _width = 320;
	private _height = 320;
	private _inversion: Inversion[];
	private _termFormatList = termFormatList;
	private _termFormat = this._termFormatList.day;
	private _term = '1';
	private _amount = 50000;

	public points: Point[] = [];
	public selectedPoint: Point;
	public dotRadius = 5;
	public activeRadius = 3 * this.dotRadius;
	public xPoints: number[] = [];
	public yPoints: number[] = [];
	public circle: Circle;
	public viewBox: string;
	public activeIndex = 0;
	public dPath: string;
	public dasharray: string;
	public calculatedAmount: number;
	public isActive = true;

	@Input()
	get amount(): number {
		return this._amount;
	}
	set amount(newValue: number) {
		this._amount = newValue;
	}

	@Input()
	get term(): string {
		return this._term;
	}
	set term(newValue: string) {
		this._term = newValue;
	}

	@Input()
	get inversion(): Inversion[] {
		return this._inversion;
	}

	set inversion(newValue: Inversion[]) {
		this._inversion = newValue;
	}

	@Input()
	get termFormat(): termFormatList {
		return this._termFormat;
	}
	set termFormat(newValue: termFormatList) {
		this._termFormat = this._termFormatList[newValue];
	}

	@Input()
	get width(): number {
		return this._width;
	}
	set width(newValue: number) {
		this._width = newValue;
	}

	@Input()
	get height(): number {
		return this._height;
	}
	set height(newValue: number) {
		this._height = newValue;
	}

	get progress(): string {
		return `${(Math.PI - this.calculatePointAngle(this.activeIndex + 1)) *
			this.circle.r},
                  ${2 * Math.PI * this.circle.r}`;
	}

	private sin(angle: number): number {
		return Math.sin(angle);
	}

	private cos(angle: number): number {
		return Math.cos(angle);
	}

	private calculateX(distance: number, angle: number): number {
		return distance + this.circle.r * this.sin(angle);
	}

	private calculateY(distance: number, angle: number): number {
		return distance + this.circle.r * this.cos(angle);
	}

	private calculatePointAngle(index: number): number {
		return (
			((this.inversion.length / 2 - index + 1) * Math.PI) /
			(this.inversion.length / 2)
		);
	}

	private pointX(index: number): number {
		return this.calculateX(this.circle.x, this.calculatePointAngle(index));
	}

	private pointY(index: number): number {
		return this.calculateY(this.circle.y, this.calculatePointAngle(index));
	}

	private getPoints(): void {
		this.inversion.forEach((element, index) => {
			this.xPoints.push(this.pointX(index + 1));
			this.yPoints.push(this.pointY(index + 1));
			if (index !== undefined) {
				this.points[index] = {
					x: this.xPoints[index],
					y: this.yPoints[index],
					inversion: this.inversion[index]
				};
			}
		});
	}

	private getPath(): void {
		this.dPath = `M${Math.round(this.xPoints[0])} ${this.yPoints[0]}
                    a ${this.circle.r} ${this.circle.r} 0 0 1 0 ${2 *
			this.circle.r}
                    a ${this.circle.r} ${this.circle.r} 0 0 1 0 ${-2 *
			this.circle.r}`;
	}

	private findSelectedTerm(): void {
		this.activeIndex = this.inversion.findIndex((element: Inversion) => {
			return element.term === this._term;
		});
		if (this.activeIndex === -1) {
			this.activeIndex = 0;
			throw new Error(
				`You must introduce a term that apprears on your inversion input`
			);
		}
	}

	private setSelectedPoint():void {
		this.selectedPoint = {
			x: -this.activeRadius + this.points[this.activeIndex].x,
			y: -this.activeRadius + this.points[this.activeIndex].y
		};
	}

	private distance(x1:number, y1:number, x2:number, y2:number): number {
		return Math.sqrt((x1-x2)*(x1-x2)+(y1-y2)*(y1-y2));
	}

	private calculateAmount(): void {
		this.calculatedAmount =
			this.amount * (1 + Number(this.inversion[this.activeIndex].rate) / 100);
	}

	public nextPoint(): void {
		this.isActive = true;
		if (this.activeIndex < this.inversion.length - 1) {
			this.activeIndex++;
		} else {
			this.activeIndex = 0;
		}
		this.calculateAmount();
		this.setSelectedPoint();
	}

	public backPoint(): void {
		this.isActive = true;
		if (this.activeIndex > 0 && this.activeIndex < this.inversion.length) {
			this.activeIndex--;
		}
		this.calculateAmount();
		this.setSelectedPoint();
	}

	public showTermFormat(): string {
		let finalFormat = this._termFormat.toString();
		if (this.points[this.activeIndex].inversion.term > '1') {
			if (this._termFormat === 'mes') {
				finalFormat = this._termFormat + 'es';
			} else {
				finalFormat = this._termFormat + 's';
			}
		}
		return `${this.points[this.activeIndex].inversion.term} ${finalFormat}`;
	}

	public onPanStart(): void {
		this.isActive = false;
		const el = this._elementRef.nativeElement.getElementsByClassName(
			'ghost-point active'
		)[0];
		this._renderer.setStyle(el, 'background-color', `var(--sn-color__red,#EC0000)`);
	}

	public onPanMove(event: any): void {
		const el = this._elementRef.nativeElement.getElementsByClassName('ghost-point active')[0];
		const path = this._elementRef.nativeElement.getElementsByTagName('path')[0];
		const points = this._elementRef.nativeElement.getElementsByClassName('dot');
		
		const dX = this.selectedPoint.x + event.deltaX;
		const dY = this.selectedPoint.y + event.deltaY;
		
		const x0 = dX - this.circle.x + this.activeRadius;
		const y0 = dY - this.circle.y + this.activeRadius;
		const angle = Math.atan2(x0,y0);
		const x1 = this.circle.x - this.activeRadius + this.circle.r * Math.sin(angle);
		const y1 = this.circle.y - this.activeRadius + this.circle.r * Math.cos(angle);

		const divPoints = JSON.parse(JSON.stringify(this.points))
		divPoints.map((point)=>{
			point.x = point.x - this.circle.x,
			point.y = point.y - this.circle.y
		});
		const angles = [];
		divPoints.forEach((point, i)=>{
			const ang = Math.atan2(point.x,point.y);
			angles[i] = ang;
		});
		
		this._renderer.setStyle(el, 'left', `${x1}px`);
		this._renderer.setStyle(el, 'top', `${y1}px`);
		this._renderer.setAttribute(path,'stroke-dasharray',`${(Math.PI - angle) * (this.circle.r)} ${2 * Math.PI * (this.circle.r)}`);
		
		angles.forEach((ang,i)=>{
			if(ang >= angle) {	
				this._renderer.addClass(points[i],'visited');
			} else {
				this._renderer.removeClass(points[i],'visited');
			}
		});
	}


	public onPanEnd(): void {
		const el = this._elementRef.nativeElement.getElementsByClassName(
			'ghost-point active'
		)[0];
		const path = this._elementRef.nativeElement.getElementsByTagName('path')[0];
		const points = this._elementRef.nativeElement.getElementsByClassName('dot');
		const x = Number(el.style.left.split('px')[0]);
		const y = Number(el.style.top.split('px')[0]);
		const divPoints = JSON.parse(JSON.stringify(this.points));
		divPoints.map((point)=>{
			point.x = -this.activeRadius + point.x,
			point.y = -this.activeRadius + point.y
		});
		const distList = [];
		divPoints.forEach((point,i)=>{
			const dist = this.distance(x,y,point.x,point.y)
			distList[i] = dist;
		});
		const minDist = Math.min(...distList);
		const minIndex = distList.findIndex((dist)=>{
			return dist === minDist;
		});	
		this.activeIndex = minIndex;
		this.isActive = true;
		this.selectedPoint.x = divPoints[minIndex].x;
		this.selectedPoint.y = divPoints[minIndex].y;
		const x0 = this.selectedPoint.x-this.circle.x+this.activeRadius;
		const y0 = this.selectedPoint.y-this.circle.y+this.activeRadius;
		const angle = Math.atan2(x0,y0);
		this._renderer.setAttribute(path,'stroke-dasharray',`${(Math.PI - angle) * (this.circle.r)} ${2 * Math.PI * (this.circle.r)}`);
		this._renderer.setStyle(el, 'left', `${this.selectedPoint.x}px`);
		this._renderer.setStyle(el, 'top', `${this.selectedPoint.y}px`);
		this._renderer.setStyle(el, 'background-color', 'transparent');

		const allVisited = this._elementRef.nativeElement.getElementsByClassName('dot visited');
		if(allVisited.length === divPoints.length && this.activeIndex === 0) {
			divPoints.forEach((point,i)=>{
				this._renderer.removeClass(points[i],'visited');
			})
		}
		this.calculateAmount();
	}

	ngOnInit() {
		if (this._termFormat === undefined) {
			console.warn(
				'El atributo termFormat debe ser del tipo "día" | "mes" | "año"'
			);
		}
		this.viewBox = `0 0 ${this._width} ${this.height}`;
		this.circle = {
			x: this._width / 2,
			y: this.height / 2,
			r: this._radius
		};
		this.getPoints();
		this.setSelectedPoint();
		this.getPath();
		this.findSelectedTerm();
		this.showTermFormat();
		this.calculateAmount();
	}
}
