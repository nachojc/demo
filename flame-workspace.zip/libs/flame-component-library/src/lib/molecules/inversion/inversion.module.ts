import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InversionComponent } from './inversion.component';
import { DragDropModule } from '@angular/cdk/drag-drop';

@NgModule({
    imports: [CommonModule, DragDropModule],
	declarations: [InversionComponent ],
	exports: [InversionComponent ]
})

export class InversionModule {}