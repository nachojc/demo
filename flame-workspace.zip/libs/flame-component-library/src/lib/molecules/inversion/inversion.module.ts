import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InversionComponent } from './inversion.component';

@NgModule({
    imports: [CommonModule],
	declarations: [InversionComponent ],
	exports: [InversionComponent ]
})

export class InversionModule {}