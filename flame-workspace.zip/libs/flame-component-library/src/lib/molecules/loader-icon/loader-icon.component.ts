import {
  Component,
  OnInit,
  Input
} from '@angular/core';
import { Router } from '@angular/router';
// import { DataTransferService } from 'sn-core-library';
// import { IdentityService } from '../../../services/identity.service';


@Component({
  selector: 'sn-loader-icon',
  template: `<section>
    <sn-top-bar title="SuperToken">
      <sn-icon sn-right icon="sn-close" (click)="goBack()"></sn-icon>
    </sn-top-bar>
    <div class="center-content">
      <sn-emoji [type]="emoji" variant="circle"></sn-emoji>
      <div [class]="'img-back-round '+emoji"></div><p>{{message}}</p></div>
    </section>`,
  styleUrls: ['./loader-icon.component.scss']
})
export class LoaderIconComponent implements OnInit {
  @Input() emoji: string;
  @Input() message: string;
  constructor(private _router: Router) {
   }

  ngOnInit(): void {}

  goBack() {
    this._router.navigate(['']);
  }

}
