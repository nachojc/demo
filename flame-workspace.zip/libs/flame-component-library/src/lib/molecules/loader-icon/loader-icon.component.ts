import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'sn-loader-icon',
  templateUrl: './loader-icon.component.html',
  styleUrls: ['./loader-icon.component.scss']
})
export class LoaderIconComponent {

  /**
   * Create an instance of LoaderIconComponent.
   * @param {Router} _router
   * @memberof LoaderIconComponent
   */
  constructor(private _router: Router) {}

  /**
   * Indica el nombre del emoji a mostrar.
   * @type {string}
   * @memberof LoaderIconComponent
   */
  @Input() emoji: string;

  /**
   * Indica el mensje mostrado debajo del emoji.
   * @type {string}
   * @memberof LoaderIconComponent
   */
  @Input() message: string;

  /**
   * Función que permite navegar a otra ruta
   * @memberof LoaderIconComponent
   */
  goBack() {
    this._router.navigate(['']);
  }
}
