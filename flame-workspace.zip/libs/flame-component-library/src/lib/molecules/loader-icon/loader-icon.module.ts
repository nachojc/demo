import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderIconComponent } from './loader-icon.component';
import { EmojiModule } from '../../atoms/emoji/emoji.module';
import { IconModule } from '../../atoms/icon/icon.module';
import { TopBarModule } from '../top-bar/top-bar.module';

@NgModule({
  entryComponents: [],
  imports: [EmojiModule, IconModule, TopBarModule],
	declarations: [LoaderIconComponent],
	exports: [LoaderIconComponent]
})
export class LoaderIconModule {}

