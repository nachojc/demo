import { DialogContentModule } from './dialog-content/dialog-content.module';
import { AccountSelectModule } from './accounts-select/account-select.module';
import { AmountFieldModule } from './amount-field/amount-field.module';
import { CardSliderModule } from './card-slider/card-slider.module';
import { LoaderModule } from './loader/loader.module'
import { LoaderIconModule } from './loader-icon/loader-icon.module';
import { MotiveFieldModule } from './motive-field/motive-field.module';
import { NavbarModule } from './navbar/navbar.module';
import { ProductModule } from './product/product.module';
import { TopBarModule } from './top-bar/top-bar.module';
import { TokenInputModule } from './token-input/token-input.module';
import { TokenDialogModule } from './token-dialog/token-dialog.module';
import { ContactListModule } from './contact-list/contact-list.module';
import { ContactDialogModule } from './contact-dialog';
import { InversionModule } from './inversion/inversion.module';

export const MOLECULES_COMPONENTS = [
	AccountSelectModule,
	AmountFieldModule,
	CardSliderModule,
	ContactDialogModule,
	LoaderModule,
	LoaderIconModule,
	MotiveFieldModule,
	NavbarModule,
	ProductModule,
	TopBarModule,
	TokenInputModule,
	TokenDialogModule,
  ContactListModule,
  DialogContentModule,
  InversionModule
];
