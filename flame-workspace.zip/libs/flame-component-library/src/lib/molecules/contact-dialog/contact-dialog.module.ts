import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { ContactDialogAbstractionComponent } from "./dialog-abstraction/dialog-abstraction.component";
import { SlideButtonModule } from "../../atoms/slide-button";
import { DialogModule } from '../../atoms/dialog';
import { ContactDialogDirective } from './contact-dialog.directive';
import { ConfirmContactService } from './dialog-abstraction/confirm-contact.service';
import { IconModule } from '../../atoms/icon';

@NgModule({
  entryComponents: [ContactDialogAbstractionComponent],
  declarations: [ContactDialogAbstractionComponent, ContactDialogDirective],
  imports: [
    DialogModule,
    SlideButtonModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    IconModule
  ],
  exports: [ContactDialogAbstractionComponent, ContactDialogDirective],
  providers: [ConfirmContactService]
})
export class ContactDialogModule { }
