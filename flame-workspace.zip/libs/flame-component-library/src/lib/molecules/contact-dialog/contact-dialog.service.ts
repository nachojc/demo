import { Injectable } from '@angular/core';
import { DialogReference, DialogService, CustomDialog } from '../../atoms/dialog';
import { ContactDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { Subject, Observable } from 'rxjs';
import { ConfirmContactService } from './dialog-abstraction/confirm-contact.service';

@Injectable()
export class ContactDialogService {
  /**
   *Creates an instance of ContactDialogService.
   * @param {DialogService} dialog
   * @param {ConfirmContactService} _statusSlide
   * @memberof ContactDialogService
   */
  constructor(private dialog: DialogService, private _statusSlide: ConfirmContactService){
  }

  /**
   * @ignore
   * Indica la referencia al dialogo creado.
   * 
   * @private
   * @type {DialogReference}
   * @memberof ContactDialogService
   */
  private dialogRef: DialogReference;

  /**
   * @ignore
   * Indica el estado abierto o cerrado del dialogo.
   *
   * @private
   * @type {Subject<string>}
   * @memberof ContactDialogService
   */
  private stateDialog = new Subject<string>();

  /**
   * Abre dialogo y crea suscripción a eventos de cerrar dialogo.
   *
   * @param {Event} data
   * @memberof ContactDialogService
   */
  openDialogContact(type: number){
    this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Santander Connect',
				enableHr: false,
        disabledButton: false,
        showButton: false,
        backdropClass: 'dark-backdrop',
        closeBackdropClick: false
			},
			new CustomDialog(ContactDialogAbstractionComponent, {
        type: type,
        statusObservable: this._statusSlide})
    );
    this.dialogRef.afterClosed().subscribe(() => {
      this.stateDialog.next('closed');
    })
    this.dialogRef.beforeClose().subscribe(() => {
      this.stateDialog.next('startclose');
    })
  }

  /**
   * Cierra el dialogo de contacto.
   * 
   * @memberof ContactDialogService
   */
  closeDialogContact(){
    this.dialogRef.close();
  }

  /**
   * Observable que devuelve un <strong>String</strong> con los distintos estados de animación del dialogo de contacto.
   * 
   * @returns {Observable<string>}
   * @memberof ContactDialogService
   */
  getStateDialog(): Observable<string> {
    return this.stateDialog.asObservable();
  }

  /**
   * Define el estado del slide de confirmación.
   * 
   * @param {string} value
   * @memberof ContactDialogService
   */
  setStatusSlide(value: string) {
    if (value) {
      this._statusSlide.setStatusSlide(value);
    } else {
      this._statusSlide.setStatusSlide('');
    }
  }
}
