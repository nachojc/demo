import { Injectable } from '@angular/core';
import { DialogReference, DialogService, CustomDialog } from '../../atoms/dialog';
import { ContactDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { Subject, Observable } from 'rxjs';
import { ConfirmContactService } from './dialog-abstraction/confirm-contact.service';

@Injectable()
export class ContactDialogService {

  private dialogRef: DialogReference;
  private stateDialog = new Subject<string>();

  /**
   * Muestra el Contact Dialog
   */
  openDialogContact(type: number){
    this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Santander Connect',
				enableHr: false,
        disabledButton: false,
        showButton: false,
        backdropClass: 'dark-backdrop',
        closeBackdropClick: false
			},
			new CustomDialog(ContactDialogAbstractionComponent, {
        type: type,
        statusObservable: this._statusSlide})
    );
    this.dialogRef.afterClosed().subscribe(() => {
      this.stateDialog.next('closed');
    })
    this.dialogRef.beforeClose().subscribe(() => {
      this.stateDialog.next('startclose');
    })
  }

  /**
   * Cierra el Contact Dialog
   */
  closeDialogContact(){
    this.dialogRef.close();
  }

  /**
   * Observable que devuelve un String con los distintos estados de animacion del Contact Dialog
   * @returns state dialog
   */
  getStateDialog(): Observable<string> {
    return this.stateDialog.asObservable();
  }

  setStatusSlide(value: string) {
    if (value) {
      this._statusSlide.setStatusSlide(value);
    } else {
      this._statusSlide.setStatusSlide('');
    }
  }

  constructor(private dialog: DialogService, private _statusSlide: ConfirmContactService){
  }
}
