import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ConfirmContactService } from './confirm-contact.service';
import { CustomDialogComponent } from "../../../atoms/dialog";
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { text } from '@angular/core/src/render3';

@Component({
  selector: 'sn-contact-dialog-abstraction',
  templateUrl: './dialog-abstraction.component.html',
  styleUrls: ['./dialog-abstraction.component.scss'],
  providers: [ConfirmContactService]
})
export class ContactDialogAbstractionComponent implements OnInit, CustomDialogComponent {
  public data: any;
  public statusSlide: string;

  public info = {
    title: '',
    phones: [],
    text : 'Servicio 24/7 días, nuestros ejecutivos te atenderán y resolverán cualquier duda que tengas. Llámanos!'
  };
  subscription: Subscription;

  @Output() readonly confirm: EventEmitter<any> = new EventEmitter<any>();

  constructor(private confirmService: ConfirmContactService) {
  }

  ngOnInit() {
    if (this.data) {
      if (this.data.hasOwnProperty('statusObservable')) {
        this.subscription = this.data.statusObservable.statusSlide.subscribe( (statusSlide: string) => {
          this.statusSlide = statusSlide;
        });
      }

      switch (this.data.type) {
        case 1:
          this.info.title = 'Superlínea';
          this.info.phones.push(
            {name: 'Desde la CDMX y área metropolitana', phone: '5169 4300'},
            {name: 'Desde cualquier otra parte del país', phone: '01 55 5169 4300'}
          );
          break;

        case 2:
          this.info.title = 'Superlínea Select';
          this.info.phones.push(
            {name: 'Desde México', phone: '01 55 5169 4304'},
            {name: 'Desde el extranjero', phone: '1 844 705 8077'}
          );
          break;

        case 3:
          this.info.title = 'Superlínea Private Banking';
          this.info.phones.push(
            {name: 'Superlínea Private Banking', phone: '01 55 5169 4302'}
          );
          break;

        default:
          break;
      }
    }
  }

  confirmationEvent() {
    this.confirmService.confirm();
    this.data.confirmevent();
  }
}
