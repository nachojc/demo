import { Injectable } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable()
export class ConfirmContactService {
  private statusSlide = new Subject<any>();
  private control = new Subject<any>();

  constructor() { }

  confirm() {
    this.control.next(true);
  }

  getResponse(): Observable<any> {
    return this.control.asObservable();
  }

  setStatusSlide(value: string) {
    this.statusSlide.next(value)
  }

  getStatusSlide(): Observable<any> {
    return this.statusSlide.asObservable();
  }
}
