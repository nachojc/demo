/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ContactDialogAbstractionComponent } from './dialog-abstraction.component';
import { ReactiveFormsModule } from '@angular/forms';

describe('ContactDialogAbstractionComponent', () => {
	let component: ContactDialogAbstractionComponent;
	let fixture: ComponentFixture<ContactDialogAbstractionComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
      declarations: [ContactDialogAbstractionComponent],
      imports: [ReactiveFormsModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ContactDialogAbstractionComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
 */
