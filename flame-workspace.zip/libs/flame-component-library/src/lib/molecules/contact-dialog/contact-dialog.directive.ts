import { Directive, Input, HostListener, EventEmitter, Output } from '@angular/core';
import { DialogReference, DialogService, CustomDialog } from '../../atoms/dialog';
import { ContactDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { ConfirmContactService } from './dialog-abstraction/confirm-contact.service';

@Directive({
  selector: '[smContactDialog]',
})
export class ContactDialogDirective {
  private _closeDialog = false;
  private dialogRef: DialogReference;
  /**
   * Callback que emite la informacion relacionada a la entrada de usuario, una vez deslizado el slidebutton
   */
  @Output() confirm = new EventEmitter<any>();
  /**
   * Callback que emite los estados "startclose" y "closed" propios de la animacion al ocultarse o cerrar el dialogo
   */
  @Output() dialogstate = new EventEmitter<string>();
  /**
   * Recibe el estado "true" si se desea cerrar el dialogo y "false" (por defecto) para inmutar el dialogo
   */
  @Input()
  set closedialog(value: boolean){
    this._closeDialog = value;
    if (this.dialogRef){
      this.dialogRef.close();
    }
  }
  get closedialog(){
    return this._closeDialog;
  }

  @Input()
  set statusSlide(value: string) {
    if (value) {
      this._statusSlide.setStatusSlide(value);
    } else {
      this._statusSlide.setStatusSlide('');
    }
  }

  constructor(private dialog: DialogService, private _statusSlide: ConfirmContactService){
  }

  @HostListener('click')
  clickEvent(data: Event){
    this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Santander Connect',
				enableHr: true,
        disabledButton: false,
        showButton: false,
        backdropClass: 'dark-backdrop',
        closeBackdropClick: false
			},
			new CustomDialog(ContactDialogAbstractionComponent, {
        confirmevent: () => this.confirmEventDispatcher(),
        statusObservable: this._statusSlide})
    );
    this.dialogRef.afterClosed().subscribe(() => {
      this.dialogstate.emit('closed');
    })
    this.dialogRef.beforeClose().subscribe(() => {
      this.dialogstate.emit('startclose');
    })
  }

  confirmEventDispatcher(){
    this.confirm.emit({ok: 200});
  }
}
