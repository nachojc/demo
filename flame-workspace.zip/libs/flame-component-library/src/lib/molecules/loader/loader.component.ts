import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
// import { DataTransferService } from 'sn-core-library';
// import { IdentityService } from '../../services/identity.service';

@Component({
	selector: 'sn-loader-molecule',
	template: `
		<section>
			<sn-spinner></sn-spinner>
			<div class="message">
				<p>{{ percentage }} %</p>
				<p>{{ message }}</p>
			</div>
		</section>
	`,
	styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {
	@Input() message: string;
	@Input() route: string;
	percentage: number;
	constructor(private _router: Router) {
		this.percentage = 0;
	}

	ngOnInit(): void {
		this.Progress();
	}

	delay(delay: number) {
		return new Promise(r => setTimeout(r, delay));
	}

	async Progress() {
		while (this.percentage !== 100) {
			for (let i = 0; i < 100; i++) {
				await this.delay(100);
				this.percentage = this.percentage + 1;
			}
			this._router.navigate([this.route]);
		}
	}
}
