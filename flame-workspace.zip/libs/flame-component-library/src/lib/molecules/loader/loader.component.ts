import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'sn-loader-molecule',
  template: `
		<section>
			<sn-spinner></sn-spinner>
			<div class="message">
				<p>{{ percentage }} %</p>
				<p>{{ message }}</p>
			</div>
		</section>
	`,
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {

  /**
   * Create an instance of LoaderComponent.
   * Inicializa porcentaje de avance.
   * 
   * @param {Router} _router
   * @memberof LoaderComponent
   */
  constructor(private _router: Router) {
    this.percentage = 0;
  }

  /**
   * Indica el porcentaje de avance.
   * 
   * @type {number}
   * @memberof LoaderComponent
   */
  percentage: number;

  /**
   * Indica el mensaje mostrado debajo del porcentaje.
   * 
   * @type {string}
   * @memberof LoaderComponent
   */
  @Input() message: string;

  /**
   * Indica la ruta a dirigir al termino de la carga.
   * 
   * @type {string}
   * @memberof LoaderComponent
   */
  @Input() route: string;

  /**
   * Función asíncrona que captura la carga del componente.
   * 
   * @memberof LoaderComponent
   */
  async Progress() {
    while (this.percentage !== 100) {
      for (let i = 0; i < 100; i++) {
        await this.delay(100);
        this.percentage = this.percentage + 1;
      }
      this._router.navigate([this.route]);
    }
  }

  /**
   * Obtiene una promesa con un retraso de n tiempo definido por parámetro de entrada.
   * 
   * @param {number} delay
   * @returns {Promise}
   * @memberof LoaderComponent
   */
  delay(delay: number) {
    return new Promise(r => setTimeout(r, delay));
  }

  /**
   * @ignore
   * Invoca el incio de carga de porcentaje.
   * 
   * @memberof LoaderComponent
   */
  ngOnInit(): void {
    this.Progress();
  }
}
