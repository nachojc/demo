import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from './loader.component';
import { SpinnerModule } from '../../atoms/spinner/spinner.module';

@NgModule({
	imports: [CommonModule, SpinnerModule],
	entryComponents: [],
	declarations: [LoaderComponent],
	exports: [LoaderComponent]
})
export class LoaderModule {}
