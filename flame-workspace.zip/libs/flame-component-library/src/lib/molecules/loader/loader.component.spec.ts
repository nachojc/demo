import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { LoaderComponent } from './loader.component';
import { SpinnerModule } from '../../atoms/spinner/spinner.module';
import { Router } from '@angular/router';

describe('LoaderComponent', () => {
    let component: LoaderComponent;
    let fixture: ComponentFixture<LoaderComponent>;
    let router: Router;
    const mockRouter = class {
        navigate = jasmine.createSpy("navigate")
    }

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [LoaderComponent],
            imports: [SpinnerModule],
            providers: [{ 
                provide: Router, 
                useClass: mockRouter
            }]
		}).compileComponents();
    }));
    
    beforeEach(() => {
		fixture = TestBed.createComponent(LoaderComponent);
		component = fixture.componentInstance;
        fixture.detectChanges();
        router = TestBed.get(Router);
    });

    it('should create', () => {
		expect(component).toBeTruthy();
    });

    it('ngOnInit', () => {
        spyOn(component, 'Progress');
        component.ngOnInit();
        expect(component.Progress).toHaveBeenCalled();
    });

});