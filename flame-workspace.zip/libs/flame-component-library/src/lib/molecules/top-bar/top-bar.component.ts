import { Component,
          Input,
          AfterViewInit} from '@angular/core';

@Component({
  selector: 'sn-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.scss']
})
export class TopBarComponent {

  @Input() title: string;

  constructor() {

  }

}
