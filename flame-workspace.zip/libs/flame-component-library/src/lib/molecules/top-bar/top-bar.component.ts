import { Component, Input, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'sn-top-bar',
  templateUrl: './top-bar.component.html',
  styleUrls: ['./top-bar.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TopBarComponent {
  /**
   * Indica el título de la barra.
   * 
   * @type {string}
   * @memberof TopBarComponent
   */
  @Input() title: string;
}
