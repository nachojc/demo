import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ProductComponent } from './product.component';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../atoms/icon/icon.module';
import { CapitalizeModule } from '../../pipes/capitalize/capitalize.module';
@NgModule({
  imports: [
    CommonModule,
    IconModule,
    CapitalizeModule
   ],
  declarations: [ ProductComponent ],
  exports: [ ProductComponent ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA]
})
export class ProductModule { }
