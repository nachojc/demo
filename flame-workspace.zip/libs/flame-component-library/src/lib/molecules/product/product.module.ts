import { NgModule } from '@angular/core';
import { ProductComponent } from './product.component';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../atoms/icon/icon.module';
import { CardNumberModule } from '../../pipes/card-number/card-number.module';

@NgModule({
  imports: [
    CommonModule,
    IconModule,
    CardNumberModule
   ],
  declarations: [ ProductComponent ],
  exports: [ ProductComponent ]
})
export class ProductModule { }
