import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'sn-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductComponent {

  /**
   * Indica el estado del componente.
   *
   * @type {boolean}
   * @memberof ProductComponent
   */
  public selected:boolean;

 /**
   * Propiedad del componente que recibe número de cuenta.
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() account: string;

  /**
   * Propiedad del componente que muestra el monto de la cuenta.
   * @type {number}
   * @memberof ProductComponent
   */
  @Input() amount ? : number;

  /**
   * Propiedad del componente que muestra el tipo de moneda.
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() currency: string;

  /**
   * Propiedad del componente que muestra el nombre de cuenta.
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() displayName: string;

  /**
   * Propiedad del componente que indica tipo de cuenta (imagen).
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() type: string;

  /**
   * Propiedad del componente que activa la clase active-arrow (activa flecha en el componente).
   * @memberof ProductComponent
   */
  @Input() accordion = false;

  /**
   * Propiedad del componente que minimiza la letra de la cuenta.
   * @memberof ProductComponent
   */
  @Input() transfer = false;

  /**
   * Propiedad del componente que permite el estado selected del componente.
   * @memberof ProductComponent
   */
  @Input() selectable = false;

  /**
   * Evento que emite los datos del click y los del componente.
   *
   * @memberof ProductComponent
   */
  @Output() selectProduct = new EventEmitter<any>();

  /**
   * Función que desencadena el evento de emición de datos y si el flag esta activo cambia el estado del componente.
   *
   * @param {Event} ev
   * @memberof ProductComponent
   */
  selectedProduct(ev:Event){
    if(this.selectable) this.selected = !this.selected;
    this.selectProduct.emit([{
      event:ev,
      account:this.account,
      amount:this.amount,
      currency:this.currency,
      displayName:this.displayName,
      type:this.type,
      accordion:this.accordion,
      transfer:this.transfer
     }]);
  }
}
