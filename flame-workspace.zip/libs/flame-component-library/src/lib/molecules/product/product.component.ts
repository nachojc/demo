import {
	Component,
	ViewEncapsulation,
	Input,
	OnInit,
	Output,
	EventEmitter,
	SimpleChanges,
	OnChanges
} from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { CARDS_IMAGE } from '../../core';

@Component({
	selector: 'sn-product',
	templateUrl: './product.component.html',
	styleUrls: ['./product.component.scss'],
	encapsulation: ViewEncapsulation.None,
	providers: [CurrencyPipe]
})
export class ProductComponent implements OnInit, OnChanges {
	/**
	 * Crea una instancia de ProductComponent.
	 * @param {CurrencyPipe} cp
	 * @memberof ProductComponent
	 */
	constructor(private cp: CurrencyPipe) { }

	/**
	 * Propiedad del componente que muestra el nombre de cuenta.
	 * @ignore
	 * @private
	 * @type {string}
	 * @memberof ProductComponent
	 */
	private _displayName: string;

	/**
	 * Indica el estado del componente.
	 *
	 * @type {boolean}
	 * @memberof ProductComponent
	 */
	public selected: boolean;

	/**
	 * Propiedad del componente que muestra la cantidad
	 * convertida a formato monetario de la cuenta.
	 * @type {string}
	 * @memberof ProductComponent
	 */
	public convertedAmount: string;

  /**
   *
   *
   * @type {string}
   * @memberof ProductComponent
   */
  public imageName: string;
	/**
	 * Propiedad del componente que recibe número de cuenta.
	 * @type {string}
	 * @memberof ProductComponent
	 */
	@Input() account: string;

	/**
	 * Propiedad del componente que muestra la cantidad de la cuenta.
	 * @type {number}
	 * @memberof ProductComponent
	 */
	@Input() amount?: number;

	/**
	 * Propiedad del componente que muestra el tipo de moneda.
	 * @type {string}
	 * @memberof ProductComponent
	 */
	@Input() currency: string;

	/**
	 * Propiedad del componente que muestra el nombre de cuenta, transformándolo al formato correcto.
	 * @type {string}
	 * @memberof ProductComponent
	 */
	@Input()
	get displayName(): string {
		return this._displayName;
	}

	set displayName(value: string) {
		this._displayName = value;
	}

	/**
	 * Propiedad del componente que indica tipo de cuenta (imagen).
	 * @type {string}
	 * @memberof ProductComponent
	 */
	@Input() imageId: string;

	/**
	 * Propiedad del componente que activa la clase active-arrow (activa flecha en el componente).
	 * @memberof ProductComponent
	 */
	@Input() accordion = false;

	/**
	 * Propiedad del componente que minimiza la letra de la cuenta.
	 * @memberof ProductComponent
	 */
	@Input() transfer = false;

	/**
	 * Propiedad del componente que permite el estado selected del componente.
	 * @memberof ProductComponent
	 */
	@Input() selectable = false;

	/**
	 * Evento que emite los datos del click y los del componente.
	 *
	 * @memberof ProductComponent
	 */
	@Output() selectProduct = new EventEmitter<any>();

	/**
	 * Función que desencadena el evento de emisión de datos y si el flag esta activo cambia el estado del componente.
	 *
	 * @param {Event} ev
	 * @memberof ProductComponent
	 */
	selectedProduct(ev: Event) {
		if (this.selectable) this.selected = !this.selected;
		this.selectProduct.emit([
			{
				event: ev,
				account: this.account,
				amount: this.amount,
				currency: this.currency,
				displayName: this.displayName,
				type: this.imageId,
				accordion: this.accordion,
				transfer: this.transfer
			}
		]);
	}

	/**
	 * @ignore
	 * Transforma el valor numérico del Input amount al correspondiente
	 *	formato monetario.
	 * @private
	 * @memberof ProductComponent
	 */
	private transformCurrency() {
		this.convertedAmount = this.cp.transform(
			this.amount,
			this.currency,
			'symbol-narrow'
		);
	}

	/**
	 * @ignore
	 * En la inicialización del componente se setea la propiedad convertedAmount
	 * a la moneda introducida en currency, a partir del amount recibido.
	 *
	 * @memberof ProductComponent
	 */
	ngOnInit() {
    	this.imageName = CARDS_IMAGE[this.imageId] === undefined ? 'default' : CARDS_IMAGE[this.imageId];
		this.transformCurrency();
	}

	/**
	 * @ignore
	 * En cada cambio se setea la propiedad convertedAmount
	 * a la moneda introducida en currency, a partir del amount recibido.
	 *
	 * @memberof ProductComponent
	 */
	ngOnChanges(changes: SimpleChanges) {
		this.transformCurrency();
	}
}
