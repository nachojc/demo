import { Component, ViewEncapsulation, Input } from '@angular/core';

@Component({
	selector: 'sn-product',
	templateUrl: './product.component.html',
	styleUrls: ['./product.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class ProductComponent {
	constructor() {}

	@Input() account: string;
	@Input() amount?: number;
	@Input() currency: string;
	@Input() displayName: string;
	@Input() type: string;
	@Input() accordion = false;
  @Input() transfer = false;
  @Input() selected = false;
}
