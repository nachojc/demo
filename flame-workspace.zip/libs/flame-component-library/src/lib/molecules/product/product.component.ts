import { Component, ViewEncapsulation, Input } from '@angular/core';
@Component({
  selector: 'sn-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ProductComponent {

  /**
   * Create an instance of ProductComponent.
   * @memberof ProductComponent
   */
  constructor() {}


  /**
   * Propiedad del componente que recibe número de cuenta.
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() account: string;

  /**
   * Propiedad del componente que muestra el monto de la cuenta.
   * @type {number}
   * @memberof ProductComponent
   */
  @Input() amount ? : number;

  /**
   * Propiedad del componente que muestra el tipo de moneda.
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() currency: string;

  /**
   * Propiedad del componente que muestra el nombre de cuenta.
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() displayName: string;

  /**
   * Propiedad del componente que indica tipo de cuenta (imagen).
   * @type {string}
   * @memberof ProductComponent
   */
  @Input() type: string;

  /**
   * Propiedad del componente que activa la clase active-arrow (activa flecha en el componente).
   * @memberof ProductComponent
   */
  @Input() accordion = false;

  /**
   * Propiedad del componente que minimiza la letra de la cuenta.
   * @memberof ProductComponent
   */
  @Input() transfer = false;

  /**
   * Propiedad del componente que activa la clase selected se inicializa en false.
   * @memberof ProductComponent
   */
  @Input() selected = false;
}
