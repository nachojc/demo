import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductModule } from './product.module';
import { ProductComponent } from './product.component';
import { IconModule } from '@santander/flame-component-library';
import { CardNumberModule } from '../../pipes/card-number';

describe('ProductComponent', () => {
	let component: ProductComponent;
	let fixture: ComponentFixture<ProductComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [IconModule, CardNumberModule],
			declarations: [ProductComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ProductComponent);
		component = fixture.componentInstance;
	});

	it('should create module', () => {
		const module =  new ProductModule();
		expect(module).toBeTruthy();
	});

	it('should create component', () => {
		expect(component).toBeTruthy();
	});

	it('displayName Input get and set', () => {
		expect(component.displayName).toBe(component.displayName);
		const name = 'Prueba DisplayName';
		const correctName = name.toLowerCase().charAt(0).toUpperCase()+name.toLowerCase().slice(1);
		component.displayName = name;
		expect(component.displayName).toBe(correctName);
	});

	it('should amount product-component', () => {
		component.amount = 5800.95;
		expect(component.amount).toBe(5800.95);
	});

	it('should acccount product-component', () => {
		component.account = '32**2345';
		expect(component.account).toBe('32**2345');
	});

	it('should type product-component', () => {
		component.type = './assets/icons/card-basic.svg';
		expect(component.type).toBe('./assets/icons/card-basic.svg');
	});

	it('selectedProduct method', () => {
		spyOn(component.selectProduct, 'emit');
		const ev =  new Event('click');
		component.selected = true;
		component.selectable = false;
		component.selectedProduct(ev);
		expect(component.selectProduct.emit).toHaveBeenCalled();
		component.selectable = true;
		const selected = component.selected;
		component.selectedProduct(ev);
		expect(component.selected).toBe(!selected);
	});
});
