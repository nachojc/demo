import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ProductModule } from './product.module';
import { ProductComponent } from './product.component';
import { CapitalizeModule } from '../../pipes/capitalize';
import { SimpleChanges } from '@angular/core';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { IconModule } from '../../atoms/icon';

describe('ProductComponent', () => {
	let component: ProductComponent;
	let fixture: ComponentFixture<ProductComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ProductComponent],
			imports: [IconModule, CapitalizeModule],
			schemas: [CUSTOM_ELEMENTS_SCHEMA]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ProductComponent);
		component = fixture.componentInstance;
	});

	it('should create module', () => {
		const module =  new ProductModule();
		expect(module).toBeTruthy();
	});

	it('should create component', () => {
		expect(component).toBeTruthy();
	});

	it('displayName Input get and set', () => {
		expect(component.displayName).toBe(component.displayName);
		const name = 'Prueba DisplayName';
		component.displayName = name;
		expect(component.displayName).toBe(name);
	});

	it('should amount product-component', () => {
		component.amount = 5800.95;
		expect(component.amount).toBe(5800.95);
	});

	it('should acccount product-component', () => {
		component.account = '32**2345';
		expect(component.account).toBe('32**2345');
	});

	it('selectedProduct method', () => {
		spyOn(component.selectProduct, 'emit');
		const ev =  new Event('click');
		component.selected = true;
		component.selectable = false;
		component.selectedProduct(ev);
		expect(component.selectProduct.emit).toHaveBeenCalled();
		component.selectable = true;
		const selected = component.selected;
		component.selectedProduct(ev);
		expect(component.selected).toBe(!selected);
	});

	it('ngOnInit set convertedAmount', () => {
		component.amount = 12345.67;
		component.currency = 'MXN';
		component.ngOnInit();
		expect(component.convertedAmount).toBe('$12,345.67');
	});

	it('ngOnChanges set convertedAmount', () => {
		let changes: SimpleChanges;
		changes = {}
		component.amount = 12345.67;
		component.currency = 'MXN';
		component.ngOnChanges(changes);
		expect(component.convertedAmount).toBe('$12,345.67');
	});
});
