import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductComponent } from './product.component';
import { IconModule } from '@santander/flame-component-library';

describe('ProductComponent', () => {
	let component: ProductComponent;
	let fixture: ComponentFixture<ProductComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [IconModule],
			declarations: [ProductComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ProductComponent);
		component = fixture.componentInstance;
	});
	it('should create', () => {
		expect(component).toBeTruthy();
	});
	it('should amount product-component', () => {
		component.amount = 5800.95;
		expect(component.amount).toBe(5800.95);
	});
	it('should displayName product-component', () => {
		component.displayName = 'Super Nomina';
		expect(component.displayName).toBe('Super Nomina');
	});
	it('should display a different test displayName', () => {
		component.displayName = 'Tarjeta Digital';
		fixture.detectChanges();
		expect(component.displayName).toContain('Tarjeta Digital');
	});
	it('should acccount product-component', () => {
		component.account = '32**2345';
		expect(component.account).toBe('32**2345');
	});
	it('should type product-component', () => {
		component.type = './assets/icons/card-basic.svg';
		expect(component.type).toBe('./assets/icons/card-basic.svg');
	});
});
