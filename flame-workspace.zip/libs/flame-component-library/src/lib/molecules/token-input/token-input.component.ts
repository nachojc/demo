import {
  Component,
  EventEmitter,
  Output,
  OnInit,
  Input,
  forwardRef
} from '@angular/core';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR
} from '@angular/forms';

@Component({
  selector: 'sn-token-input',
  templateUrl: './token-input.component.html',
  styleUrls: ['./token-input.component.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: forwardRef(() => TokenInputComponent),
    multi: true
  }]
})
export class TokenInputComponent implements OnInit, ControlValueAccessor {

  /**
   * Create an instance of TokenInputComponent.
   * @memberof TokenInputComponent
   * Inicializa status/ mask / current
   */
  constructor() {
    this.status = 'normal';
    this.mask = [];
    this.current = 0;
  }

  /**
   * Indica el estado del token.
   * @type {string}
   * @memberof TokenInputComponent
   */
  public status: string;

  /**
   * Indica el valor del token.
   *
   * @type {string}
   * @memberof TokenInputComponent
   */
  public token: string;

  /**
   * Indica la máscara del token.
   *
   * @type {Array<string>}
   * @memberof TokenInputComponent
   */
  public mask: Array<string>;

  /**
   * Indica el valor actual del token.
   *
   * @type {number}
   * @memberof TokenInputComponent
   */
  public current: number;

  /**
   * Propiedad del componente que indica la longitud del token.
   * @type {number}
   * @memberof TokenInputComponent
   */
  @Input() maxLength ? : number;

  /**
   * Leyenda informativa respectiva al uso del token.
   *
   * @type {string}
   * @memberof TokenInputComponent
   */
  @Input() message ? : string;

  /**
   * Propiedad del componente que permite deshabilitar.
   *
   * @type {boolean}
   * @memberof TokenInputComponent
   */
  @Input() disabled: boolean;

  /**
   * Propiedad del componente que activa la clase digit-error.
   *
   * @type {false}
   * @memberof TokenInputComponent
   */
  @Input() error: false;

 /**
   * Evento disparado en el momento en que se acepta el envio del token.
   *
   * @memberof TokenInputComponent
   */
  @Output() onFull = new EventEmitter();



  /**
   * Función invocada cuando hay un cambio en el input.
   *
   * @memberof TokenInputComponent
   */
  onChange = (value) => {}

  /**
   * Función invocada cuando el input tenga la propiedad blurred.
   *
   * @memberof TokenInputComponent
   */
  onTouched = () => {}

  /**
   * Método que establece la máscara del componente
   *
   * @memberof TokenInputComponent
   */
  setMask() {
    const tokenArray = this.token.split('');
    const max = (tokenArray.length) - 1;
    if (this.current > max) {
      for (let i = tokenArray.length; i < this.mask.length; i++) {
        this.mask[i] = '';
      }
    }
    this.mask[max] = tokenArray[max];
    this.mask[max] = '\*';
    this.current = max;
  }

  /**
   * Método que se encarga de validar si se establece la máscara o elimina el valor del componente.
   *
   * @memberof TokenInputComponent
   */
  onInputChange() {
    if (this.token.length > 0 && this.token.length <= this.maxLength && this.token !== null) {
      this.setMask();
      if (this.token.length === this.maxLength) {
        this.onInputFull();
      }
    } else {
      this.clearInput();
    }
  }

  /**
   * Método encargado de eliminar el valor.
   *
   * @memberof TokenInputComponent
   */
  clearInput() {
      this.mask.forEach(
        (ele, i) => this.mask[i] = ''
      );
      this.token = null;
      this.status = 'normal';
  }

  /**
   * Dispara un evento en el momento en que se acepta el envío del token.
   *
   * @memberof TokenInputComponent
   */
  onInputFull() {
    this.onFull.emit(this.token);
  }

  /**
   * Método que valida que no se encuentre vacío el arreglo mask.
   *
   * @memberof TokenInputComponent
   */
  onError() {
    this.mask.forEach(
      (ele, i) => this.mask[i] = ''
    );
    this.status = 'error';
    this.message = 'error';
  }

  /**
   * Define el valor seleccionado. Parte de la interfaz ControlValueAccessor requerida para
   * integrarse con el core del API de Angular forms.
   * @param {string} value
   * @memberof TokenInputComponent
   */
  writeValue(value: string): void {
    this.token = value ? value : '';
  }

  /**
   * Guarda una función callback para ser invocada cuando el valor seleccionado cambia
   * dada la entrada del usuario. Parte de la interfaz ControlValueAccessor requerida para
   * integrarse con el core del API de Angular forms.
   * @param {*} fn
   * @memberof TokenInputComponent
   */
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  /**
   * Guarda una función callback para ser invocada cuando el input tiene la propiedad <strong>blurred<strong>.
   * Parte de la interfaz ControlValueAccessor requerida para
   * integrarse con el core del API de Angular forms.
   * @param {*} fnCallback
   * @memberof TokenInputComponent
   */
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  /**
   * Desactiva el input.
   * @param {boolean} isDisabled
   * @memberof TokenInputComponent
   */
  setDisabledState ? (isDisabled: boolean) : void {
    this.disabled = isDisabled;
  }


  /**
   * @ignore
   *
   * Inicializa componente
   * Establecer valores predeterminados para enmascarar propiedad <strong>mask</strong> y maxLength.
   * @memberof TokenInputComponent
   */
  ngOnInit() {
    if (!this.maxLength) this.maxLength = 4;
    for (let i = 0; i < this.maxLength; i++) {
      this.mask[i] = '';
    }
  }
}
