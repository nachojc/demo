import {
  Component,
  EventEmitter,
  Output,
  OnInit,
  Input,
  forwardRef
  } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

@Component({
  selector: 'sn-token-input',
  templateUrl: './token-input.component.html',
  styleUrls: ['./token-input.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TokenInputComponent),
      multi: true
    }
  ]
})
export class TokenInputComponent implements OnInit, ControlValueAccessor {
  public status: string;
  public token: string;
  public mask: Array<string>;
  public current: number;
  @Output() onFull = new EventEmitter();
  @Input() maxLength?: number;
  @Input() message?: string;
  @Input() disabled: boolean;
  @Input() error: false;
  onChange = (value) => { }
  onTouched = () => { }

  constructor() {
    this.status = 'normal';
    this.mask = [];
    this.current = 0;
  }

  /**
   * Set Default values to mask, message and maxLength
   */
  ngOnInit() {
    if (!this.maxLength) this.maxLength = 4;
    for (let i = 0; i<this.maxLength;i++) {
      this.mask[i] = '';
    }
  }

  setMask() {
    const tokenArray  = this.token.split('');
    const max = (tokenArray.length) - 1;
    if (this.current > max) {
      for (let i = tokenArray.length; i < this.mask.length; i++) {
        this.mask[i] = '';
      }
    }
    this.mask[max] = tokenArray[max];
    this.mask[max] = '\*';
    this.current = max;
  }

  onInputChange() {
    if (this.token.length > 0 && this.token.length <= this.maxLength && this.token !== null) {
      this.setMask();
      if (this.token.length === this.maxLength) {
        this.onInputFull();
      }
    } else {
      this.clearInput();
    }
  }

  clearInput() {
    setTimeout( () => {
      this.mask.forEach(
        (ele, i) => this.mask[i] = ''
      );
      this.token = null;
      this.status = 'normal';
    }, 300);
  }

  onInputFull() {
    this.onFull.emit(this.token);
  }

  onError() {
    this.mask.forEach(
      (ele, i) => this.mask[i] = ''
    );
    this.status = 'error';
    this.message = 'error';
  }

  writeValue(value: string): void {
    this.token = value ? value : '';
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }
}
