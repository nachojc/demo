import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { TokenInputComponent } from './token-input.component';
import { FormsModule } from '@angular/forms';
import { SlideButtonModule } from '@santander/flame-component-library';

describe('TokenComponent', () => {
	let component: TokenInputComponent;
	let fixture: ComponentFixture<TokenInputComponent>;
	let p: HTMLElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [FormsModule, SlideButtonModule],
			declarations: [TokenInputComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TokenInputComponent);
		component = fixture.componentInstance;
		p = fixture.nativeElement.querySelector('p');
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('setMask method', fakeAsync(()=>{
		component.mask = ['1','2','3','4','5','1','2','3','4','5']
		component.token = '12345'
		component.current = 6;
		const tokenArray = component.token.split('');
		const max = tokenArray.length -1;
		component.setMask();
		tick(500);
		for(let i = tokenArray.length; i<component.mask.length; i++) {
			expect(component.mask[i]).toBe('');
		}
		expect(component.mask[max]).toBe('*');
		expect(component.current).toBe(max);
	}));

	it('onInputChange method with token.length = maxLenght', () => {
		component.token = '12345';
		component.maxLength = component.token.length;
		spyOn(component, 'setMask');
		spyOn(component, 'onInputFull');
		component.onInputChange();
		expect(component.setMask).toHaveBeenCalled();
		expect(component.onInputFull).toHaveBeenCalled();
	});

	it('onInputChange method with token.length > maxLenght', () => {
		component.token = '12345';
		component.maxLength = component.token.length-1;
		spyOn(component, 'clearInput');
		component.onInputChange();
		expect(component.clearInput).toHaveBeenCalled();
	});

	it('clearInput method', fakeAsync(() => {
		component.mask = ['1','2','3'];
		component.clearInput();
		expect(component.mask).toEqual(['','','']);
		expect(component.token).toBeNull();
		expect(component.status).toBe('normal');
	}));

	it('onInputFul method', () => {
		spyOn(component.onFull, 'emit');
		component.onInputFull();
		expect(component.onFull.emit).toHaveBeenCalledWith(component.token)
	});

	it('onError method', () => {
		component.mask = ['1','2','3'];
		component.onError();
		expect(component.mask).toEqual(['','','']);
		expect(component.status).toBe('error');
		expect(component.message).toBe('error');
	});

	it('writeValue ControlValueAccessor interface method', () => {
		const str = 'Fake'
		component.writeValue(str);
		expect(component.token).toBe(str);
	});

	it('registerOnChange ControlValueAccessor interface method', () => {
		component.onChange('');
		const fn = () =>  {};
		component.registerOnChange(fn);
		expect(component.onChange).toBe(fn);
	});

	it('registerOnTouched ControlValueAccessor interface method', () => {
		component.onTouched();
		const fn = () =>  {};
		component.registerOnTouched(fn);
		expect(component.onTouched).toBe(fn);
	});

	it('setDisabledState ControlValueAccessor interface method', () => {
		const dis = true;
		component.setDisabledState(dis);
		expect(component.disabled).toBe(dis);
	});

	it('should message', () => {
		component.message = 'Ingrese 4 digitos';
		fixture.detectChanges();
		expect(component.message).toContain('Ingrese 4 digitos');
	});
	it('should display a different test amount', () => {
		component.message = 'Digite los 4 Digitos';
		fixture.detectChanges();
		expect(p.textContent).toContain('Digite los 4 Digitos');
	});
	it('should status', () => {
		component.status = 'normal';
		fixture.detectChanges();
		expect(component.status).toBe('normal');
	});

	it('passes if arrays are equal', () => {
		component.mask = ['1', '2', '3', '4'];
		expect(component.mask).toEqual(['1', '2', '3', '4']);
	});
});
