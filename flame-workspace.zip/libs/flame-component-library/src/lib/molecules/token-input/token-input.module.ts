import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { TokenInputComponent } from './token-input.component';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
   ],
  declarations: [ TokenInputComponent ],
  exports: [ TokenInputComponent ]
})
export class TokenInputModule { }
