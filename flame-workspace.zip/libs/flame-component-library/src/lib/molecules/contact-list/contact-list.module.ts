import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { ContactListComponent } from './contact-list.component';
import { AvatarModule } from '../../atoms/avatar';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [ContactListComponent],
  imports: [
    // BrowserAnimationsModule,
    CommonModule,
    ScrollingModule,
    AvatarModule
  ],
  exports: [ContactListComponent]
})
export class ContactListModule { }
