import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Avatar } from '../../atoms/avatar/avatar.models';

@Component({
	selector: 'sn-contact-list',
	templateUrl: './contact-list.component.html',
	styleUrls: ['./contact-list.component.scss']
})
export class ContactListComponent implements OnInit {
	// Variables privadas
	private _contactArray;

	// Elementos DOM
	@ViewChild('scrollcontainer') scrollcontainer;

	// Inputs
	@Input()
	set contactArray(value: Array<object>) {
		const original = value;
		const finalcontactList = [];
		this.alphabetArray.map(letter => {
			const startindex =
				finalcontactList.length > 0 ? finalcontactList.length - 1 : 0;
			const indexsaved = false;
			original.forEach((element: any, index, array) => {
				if (element.fullname) {
					if (element.fullname.charAt(0) === letter.id) {
						finalcontactList.push(element);
						if (!indexsaved) {
							letter.startindex = startindex + 1;
						}
					}
				}
			});
			finalcontactList.sort();
			return letter;
		});
		this._contactArray = finalcontactList;
	}
	get contactArray() {
		return this._contactArray;
	}

	// Inputs
	@Output() contactSelected = new EventEmitter<Avatar>();

	// Variables
	public alphabetArray = [
		{ id: 'A', startindex: -1 },
		{ id: 'B', startindex: -1 },
		{ id: 'C', startindex: -1 },
		{ id: 'D', startindex: -1 },
		{ id: 'E', startindex: -1 },
		{ id: 'F', startindex: -1 },
		{ id: 'G', startindex: -1 },
		{ id: 'H', startindex: -1 },
		{ id: 'I', startindex: -1 },
		{ id: 'J', startindex: -1 },
		{ id: 'K', startindex: -1 },
		{ id: 'L', startindex: -1 },
		{ id: 'M', startindex: -1 },
		{ id: 'N', startindex: -1 },
		{ id: 'Ñ', startindex: -1 },
		{ id: 'O', startindex: -1 },
		{ id: 'P', startindex: -1 },
		{ id: 'Q', startindex: -1 },
		{ id: 'R', startindex: -1 },
		{ id: 'S', startindex: -1 },
		{ id: 'T', startindex: -1 },
		{ id: 'U', startindex: -1 },
		{ id: 'V', startindex: -1 },
		{ id: 'W', startindex: -1 },
		{ id: 'X', startindex: -1 },
		{ id: 'Y', startindex: -1 },
		{ id: 'Z', startindex: -1 }
	];

	// Control
	public controlLetterSelected = '';

	constructor() {}

	ngOnInit() {}

	touchLetter(letra: TouchEvent) {
		const elemento_temporal = document.elementFromPoint(
			letra.targetTouches[0].clientX,
			letra.targetTouches[0].clientY
    );
		if (elemento_temporal) {
      if (elemento_temporal.parentElement){
        if (
          elemento_temporal.nodeName === 'H4' &&
          elemento_temporal.parentElement.className === 'tooltip-sn' || elemento_temporal.parentElement.className === 'tooltip-sn ng-star-inserted'
        ) {
          this.controlLetterSelected = elemento_temporal.innerHTML;
        }
      }
		}
	}

	touchLetterEnd() {
    if (this.controlLetterSelected !== ''){
      const findletter = this.alphabetArray.find(
        letter => letter.id === this.controlLetterSelected
      );
      if (findletter.startindex > -1) {
        this.scrollcontainer.scrollToIndex(findletter.startindex);
      }
    }
		this.controlLetterSelected = '';
	}

	selectedItem(item){
		this.contactSelected = item;
	}
}
