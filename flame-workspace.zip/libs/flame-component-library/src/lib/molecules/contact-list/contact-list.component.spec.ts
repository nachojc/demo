import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContactListComponent } from './contact-list.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ScrollingModule } from '@angular/cdk/scrolling';
import { AvatarModule, Avatar } from '../../atoms/avatar';
import { EventEmitter } from '@angular/core';

describe('ContactListComponent', () => {
	let component: ContactListComponent;
	let fixture: ComponentFixture<ContactListComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ContactListComponent],
			imports: [
				BrowserAnimationsModule,
				ScrollingModule,
				AvatarModule
			]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ContactListComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('contactArray get', () => {
		expect(component.contactArray).toBe(component.contactArray);
	});

	it('contactArray set', () => {
		const contactList = [{
			fullname: 'Antonio Fake Test'
		}];
		component.contactArray = contactList;
		expect(component.contactArray).toEqual(contactList);
	});

	it('selectedItem method', () => {
		const item = new EventEmitter<Avatar>();
		component.selectedItem(item);
		expect(component.contactSelected).toBe(item);
	})
});
