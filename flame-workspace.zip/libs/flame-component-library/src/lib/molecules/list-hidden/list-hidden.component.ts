import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

/**
 * Crea una lista con titulos y elementos que contienen botones ocultos.
 *
 * @export
 * @class ListHiddenComponent
 * @implements {OnInit}
 */
@Component({
  selector: 'sn-list-hidden',
  templateUrl: './list-hidden.component.html',
  styleUrls: ['./list-hidden.component.scss']
})
export class ListHiddenComponent implements OnInit {

  /**
   * @ignore
   * Arreglo que contendra los titulos de la lista.
   *
   * @type {Array<string>}
   * @memberof ListHiddenComponent
   */
  public titles:Array<string>;

  /**
   * Parametro que contiene la lista de elementos a generar.
   *
   * @type {*}
   * @memberof ListHiddenComponent
   */
  @Input() list:any;

  /**
   *
   * Parametro que contiene el o los botones ocultos que se insertaran.
   * @type {*}
   * @memberof ListHiddenComponent
   */
  @Input() buttons:any;

  /**
   * Evento que se emite cuando se ha hecho click en un boton oculto. Regresa el id del elemento padre, el nombre del boton y el id del icono.
   *
   * @memberof ListHiddenComponent
   */
  @Output() selectedIconButton = new EventEmitter<any>();

  /**
   *  Evento que se emite cuando se ha hecho click en algun elemento de la lista. Regresa los datos del elemento.
   *
   * @memberof ListHiddenComponent
   */
  @Output() selectedMaskElement = new EventEmitter<any>();

  /**
   * Inicializa los datos para su visualización.
   *
   * @memberof ListHiddenComponent
   */
  initializeList(){
    const names = [];
    const index =  Object.keys(this.list);
    const modButtons = this.buttons;
    for (const name of index) {
      names.push(name);
      this.list[name].forEach(element => {
        modButtons.forEach(
          btn => btn.id = element.key
          );
        element.buttons = modButtons
      });
    }
    this.titles = names;
  }

  /**
   * Función que emite el evento de boton seleccionado.
   *
   * @param {Event} ev
   * @memberof ListHiddenComponent
   */
  selectHiddenButton(ev:Event){
    this.selectedIconButton.emit(ev);
  }

  /**
   * Función que emite el evento de elemento seleccionado.
   *
   * @param {*} ele
   * @memberof ListHiddenComponent
   */
  selectMaskElement(ele:any){
    this.selectedMaskElement.emit(ele);
  }

  /**
   *@ignore
   *  Inicializa la lista.
   * @memberof ListHiddenComponent
   */
  ngOnInit(){
    this.initializeList();
  }
}
