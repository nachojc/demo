import { NgModule } from '@angular/core';
import { ListHiddenComponent } from './list-hidden.component';
import { HiddenButtonsModule } from '../../atoms/hidden-buttons';
import { IconModule } from '../../atoms/icon/icon.module';
import { CommonModule } from '@angular/common';


@NgModule({
  entryComponents: [],
  imports: [IconModule, HiddenButtonsModule,CommonModule],
	declarations: [ListHiddenComponent],
	exports: [ListHiddenComponent]
})
export class ListHiddenModule {}

