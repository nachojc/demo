import { Injectable } from '@angular/core';
import { DialogReference, DialogService, CustomDialog } from '../../atoms/dialog';
import { TokenDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { Subject, Observable } from 'rxjs';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';

@Injectable()
export class TokenDialogService {

  private _dialogRef: DialogReference;

  private _confirm = new Subject<any>();
  private _stateDialog = new Subject<string>();
  
  constructor(private _dialog: DialogService, private _statusSlide: ConfirmTokenService){
  }
  
  setDialogRef(dialogRef: DialogReference) {
    this._dialogRef = dialogRef;
  }
  
  getDialogRef(): DialogReference {
    return this._dialogRef;
  }

  getConfirm(): Subject<any> {
    return this._confirm;
  }

  getSubjectStateDialog(): Subject<any> {
    return this._stateDialog;
  }

  getStatusSlide(): ConfirmTokenService {
    return this._statusSlide;
  }

  getDialog(): DialogService {
    return this._dialog;
  }

  /**
   * Muestra el Token Dialog
   */
  openDialogToken(){
    this._dialogRef = this._dialog.open(
			{
				closeLabel: 'Cancelar',
				title: 'Valida la operación',
				enableHr: false,
        disabledButton: false,
        showButton: false,
        backdropClass: 'dark-backdrop',
        closeBackdropClick: false
			},
			new CustomDialog(TokenDialogAbstractionComponent, {
        confirmevent: () => this.confirmEvent(),
        statusObservable: this._statusSlide})
    );
    this._dialogRef.afterClosed().subscribe(() => {
      this._stateDialog.next('closed');
    })
    this._dialogRef.beforeClose().subscribe(() => {
      this._stateDialog.next('startclose');
    })
  }

  /**
   * Cierra el Token Dialog
   */
  closeDialogToken(){
    this._dialogRef.close();
  }

  confirmEvent(){
    this._confirm.next({ok: 200});
  }

  /**
   * Observable que devuelve un Objeto al deslizar completamente el slidebutton
   * @returns Objeto Token
   */
  getConfirmEvent(): Observable<any> {
    return this._confirm.asObservable();
  }

  /**
   * Observable que devuelve un String con los distintos estados de animacion del Token Dialog
   * @returns state dialog
   */
  getStateDialog(): Observable<string> {
    return this._stateDialog.asObservable();
  }

  setStatusSlide(value: string) {
    if (value) {
      this._statusSlide.setStatusSlide(value);
    } else {
      this._statusSlide.setStatusSlide('');
    }
  }
}
