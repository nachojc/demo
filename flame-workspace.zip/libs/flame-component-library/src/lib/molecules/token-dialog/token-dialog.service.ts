import { Injectable } from '@angular/core';
import { DialogReference, DialogService, CustomDialog } from '../../atoms/dialog';
import { TokenDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { Subject, Observable } from 'rxjs';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';
import { CustomToken } from './token-dialog.interface';
@Injectable()
export class TokenDialogService {
  /**
   *Creates an instance of TokenDialogService.
   * @param {DialogService} _dialog
   * @param {ConfirmTokenService} _statusSlide
   * @memberof TokenDialogService
   */
  constructor(
    private _dialog: DialogService, 
    private _statusSlide: ConfirmTokenService
  ){}

  /**
   * @ignore
   * Indica la referencia al dialogo.
   * 
   * @private
   * @type {DialogReference}
   * @memberof TokenDialogDirective
   */
  private _dialogRef: DialogReference;

  /**
   * @ignore
   * Indica la subscrpción al evento ejecutado cuando se desliza el botón.
   *
   * @type {Subject<any>}
   * @memberof TokenDialogDirective
   */
  private _confirm = new Subject<any>();

  /**
   * @ignore
   * Indica la subscripción a los cambios de estado del dialogo.
   *
   * @type {Subject<string>}
   * @memberof TokenDialogDirective
   */
  private _stateDialog = new Subject<string>();

  /**
   * Define la referencia del dialogo.
   *
   * @param {DialogReference} dialogRef
   * @memberof TokenDialogService
   */
  setDialogRef(dialogRef: DialogReference) {
    this._dialogRef = dialogRef;
  }
  
  /**
   * Devuelve referencia del dialogo
   *
   * @param {DialogReference} dialogRef
   * @memberof TokenDialogService
   */
  getDialogRef(): DialogReference {
    return this._dialogRef;
  }

  /**
   * Devuelve la confirmación del dialogo
   *
   * @returns {Subject<any>}
   * @memberof TokenDialogService
   */
  getConfirm(): Subject<any> {
    return this._confirm;
  }

  /**
   * Devuelve estado del dialogo
   *
   * @returns {Subject<any>}
   * @memberof TokenDialogService
   */
  getSubjectStateDialog(): Subject<any> {
    return this._stateDialog;
  }

  /**
   * Devuelve estado del botón deslizable.
   *
   * @returns {ConfirmTokenService}
   * @memberof TokenDialogService
   */
  getStatusSlide(): ConfirmTokenService {
    return this._statusSlide;
  }

  /**
   * Devuelve el dialogo como servicio.
   *
   * @returns {DialogService}
   * @memberof TokenDialogService
   */
  getDialog(): DialogService {
    return this._dialog;
  }

  /**
   * Crea y abre dialogo, así como subscribe a eventos de cierre.
   *
   * @memberof TokenDialogService
   */
  openDialogToken(data?: CustomToken){
    const customDialog = new CustomDialog(TokenDialogAbstractionComponent, {
      confirmevent: () => this.confirmEvent(),
      statusObservable: this._statusSlide,
      typeButton: (data && data.typeButton) ? data.typeButton: 'slide',
      showTokenInput: (data && data.showTokenInput !== undefined) ? data.showTokenInput: false,
      customBody: (data && data.customBody) ? data.customBody: null,
      subtitle: (data && data.subtitle) ? data.subtitle: null});
    this._dialogRef = this._dialog.open(
			{
				closeLabel: (data && data.closeLabel) ? data.closeLabel:'Cerrar',
        title: (data && data.title) ? data.title:'Confirma con tu SuperToken',
				enableHr: false,
        disabledButton: false,
        showButton: false,
        backdropClass: 'dark-backdrop',
        closeBackdropClick: false
			}, customDialog
		);
    this._dialogRef.afterClosed().subscribe(() => {
      this._stateDialog.next('closed');
    })
    this._dialogRef.beforeClose().subscribe(() => {
      this._stateDialog.next('startclose');
    })
  }

  /**
   * Cierra el Token Dialog
   *
   * @memberof TokenDialogService
   */
  closeDialogToken(){
    this._dialogRef.close();
  }

  /**
   * Emite la confirmación del dialogo.
   *
   * @memberof TokenDialogDirective
   */
  confirmEvent(){
    this._confirm.next({ok: 200});
  }

  /**
   * Devuelve un observable del evento confirmar.
   *
   * @returns {Observable<any>}
   * @memberof TokenDialogService
   */
  getConfirmEvent(): Observable<any> {
    return this._confirm.asObservable();
  }

  /**
   * Obtiene observable que devuelve un String con los distintos estados de animación del <strong>token-dialog</strong>.
   *
   * @returns {Observable<string>}
   * @memberof TokenDialogService
   */
  getStateDialog(): Observable<string> {
    return this._stateDialog.asObservable();
  }

  /**
   * Cambia estado del botón deslizable.
   *
   * @param {string} value
   * @memberof TokenDialogService
   */
  setStatusSlide(value: string) {
    if (value) {
      this._statusSlide.setStatusSlide(value);
    } else {
      this._statusSlide.setStatusSlide('');
    }
  }
}
