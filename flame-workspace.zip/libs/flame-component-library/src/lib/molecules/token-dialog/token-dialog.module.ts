import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

import { TokenDialogAbstractionComponent } from "./dialog-abstraction/dialog-abstraction.component";
import { SlideButtonModule } from "../../atoms/slide-button";
import { TokenInputModule } from "../../molecules/token-input";
import { DialogModule } from '../../atoms/dialog';
import { TokenDialogDirective } from './token-dialog.directive';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';

@NgModule({
  entryComponents: [TokenDialogAbstractionComponent],
  declarations: [TokenDialogAbstractionComponent, TokenDialogDirective],
  imports: [
    DialogModule,
    TokenInputModule,
    SlideButtonModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule
  ],
  exports: [TokenDialogAbstractionComponent, TokenDialogDirective],
  providers: [ConfirmTokenService]
})
export class TokenDialogModule { }
