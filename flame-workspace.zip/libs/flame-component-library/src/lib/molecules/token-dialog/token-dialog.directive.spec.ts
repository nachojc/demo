
import { async, TestBed, ComponentFixture } from '@angular/core/testing';
import { DialogReference } from '../../atoms/dialog';
import { Overlay } from '@angular/cdk/overlay';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';
import { TokenDialogDirective } from './token-dialog.directive';
import { Component, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { TokenDialogModule } from '@santander/flame-component-library';

@Component({
	selector: `sn-test-app`,
	template: `<button sn-button smTokendialog [statusSlide]="statusSlide" 
	[closedialog]="hideDialogToken" (dialogstate)="dialogTokenEvent($event)" 
	(confirm)="confirmTokenEvent($event)" > Abrir Token Dialog </button>`
})
class TestAppComponent {
    public stateDialog = 'ok';
    public statusSlide = 'success';
}

describe('tokenDialogDirective', () => {
    let fixture: ComponentFixture<TestAppComponent>;
    let tokenDialogDirective: TokenDialogDirective;
    let component: TestAppComponent;
    let button: DebugElement;
    let dialogRef: DialogReference;

    beforeEach(async(() => {
		TestBed.configureTestingModule({
	  declarations: [TestAppComponent],
      providers: [
        TokenDialogDirective, 
        Overlay, 
        ConfirmTokenService],
        imports:  [TokenDialogModule]
		}).compileComponents();
    }));
    
    beforeEach( () => {
        fixture = TestBed.createComponent(TestAppComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
        tokenDialogDirective = TestBed.get(TokenDialogDirective);
        button = fixture.debugElement.query(By.css('button'));
        dialogRef = new DialogReference(null);
    });

    it('should create', () => {
		expect(tokenDialogDirective).toBeTruthy();
    });

    it('should declarate close Dialog', () => {
        expect(tokenDialogDirective.closedialog).toEqual(jasmine.any(Boolean));
    });

    it('should set close dialog value', () => {
        const value = true;
        tokenDialogDirective.closedialog = value;
        expect(tokenDialogDirective.closedialog).toBe(value);
    });

    it('should set and get typeButton', () => {
        const value = 'slide';
        tokenDialogDirective.typeButton = value;
        expect(tokenDialogDirective.typeButton).toBe(value);
    });

    it('should set and get showTokenInput', () => {
        const value = true;
        tokenDialogDirective.showTokenInput = value;
        expect(tokenDialogDirective.showTokenInput).toBe(value);
    });

    it('should set statusSlide', () => {
        spyOn(tokenDialogDirective.getStatusSlide(),'setStatusSlide');
        const value = 'success';
        tokenDialogDirective.statusSlide = value;
        expect(tokenDialogDirective.getStatusSlide().setStatusSlide).toHaveBeenCalledWith(value);
    });

    it('should set statusSlide by default value', () => {
        spyOn(tokenDialogDirective.getStatusSlide(),'setStatusSlide');
        const value = null;
        tokenDialogDirective.statusSlide = value;
        expect(tokenDialogDirective.getStatusSlide().setStatusSlide).toHaveBeenCalledWith('');
    });

    it('should invoque dialog ref when set close dialog', () => {
        tokenDialogDirective.setDialogRef(dialogRef);
        spyOn(tokenDialogDirective.getDialogRef(),'close');
        tokenDialogDirective.closedialog = true;
        expect(tokenDialogDirective.getDialogRef().close).toHaveBeenCalled();
    });

    it('should confirm event dispatcher', () => {
        spyOn(tokenDialogDirective.confirm,'emit');
        tokenDialogDirective.confirmEventDispatcher();
        expect(tokenDialogDirective.confirm.emit).toHaveBeenCalledWith({ok :200});
    });
    
    it('should host listener', () => {
        spyOn(tokenDialogDirective.getDialog(),'open').and.returnValue(dialogRef);
        button.triggerEventHandler('click',null);
        expect(tokenDialogDirective.getDialog()).toBeTruthy();
    });
}); 