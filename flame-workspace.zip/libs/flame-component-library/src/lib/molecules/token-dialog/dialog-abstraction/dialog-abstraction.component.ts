import { Component, EventEmitter, OnInit, Output, ViewChild, ViewContainerRef, ComponentFactoryResolver } from '@angular/core';
import { ConfirmTokenService } from './confirm-token.service';
import { CustomDialogComponent, CustomDialog } from "../../../atoms/dialog";
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'sn-token-dialog-abstraction',
  templateUrl: './dialog-abstraction.component.html',
  styleUrls: ['./dialog-abstraction.component.scss'],
  providers: [ConfirmTokenService]
})
export class TokenDialogAbstractionComponent implements OnInit, CustomDialogComponent {
  public tokenForm: FormGroup;
  public data: any;
  public tokenInput: string;
  public statusSlide: string;
  public showTokenInput = false;
  public typeButton = 'slide';
  public subtitle = '';

  /**
	 * Referencia a snHost que se encuentre dentro del template.
	 * @type {DialogDirective}
	 * @memberof DialogComponent
	 */
  @ViewChild('snHost', { read: ViewContainerRef }) snHost;

  @Output() readonly confirm: EventEmitter<any> = new EventEmitter<any>();

  constructor(private _confirmService: ConfirmTokenService, 
              private _componentFactoryResolver: ComponentFactoryResolver) {
  }

  ngOnInit() {
    this.tokenForm = new FormGroup({
			tokenInput: new FormControl('', {
				validators: [Validators.required, Validators.minLength(4)],
				updateOn: 'change'
			})
    });
    if (this.data) {
      if (this.data.hasOwnProperty('statusObservable')) {
        this.data.statusObservable.getObservableStatusSlide().subscribe( (status: string) => {
          this.statusSlide = status;
        });
      }
      if (this.data.hasOwnProperty('customBody') && this.data.customBody) {
        const bodyContent = new CustomDialog(this.data.customBody);
        const componentFactory = this._componentFactoryResolver.resolveComponentFactory(
          bodyContent.component
        );
        const viewContainerRef = this.snHost;
        viewContainerRef.clear();
        viewContainerRef.createComponent(componentFactory);
      }
      this.setProperty(this.data, 'showTokenInput');
      this.setProperty(this.data, 'typeButton');
      this.setProperty(this.data, 'subtitle');
    }
  }

  setProperty(object: any, name: string) {
    if (object.hasOwnProperty(name) && (object[name]) !== undefined) {
      this[name] = object[name];
    }
  }

  confirmationEvent() {
    this._confirmService.confirm();
    this.data.confirmevent();
  }
}
