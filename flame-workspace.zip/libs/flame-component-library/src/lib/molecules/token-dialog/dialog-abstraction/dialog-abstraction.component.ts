import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { ConfirmTokenService } from './confirm-token.service';
import { CustomDialogComponent } from "../../../atoms/dialog";
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'sn-token-dialog-abstraction',
  templateUrl: './dialog-abstraction.component.html',
  styleUrls: ['./dialog-abstraction.component.scss'],
  providers: [ConfirmTokenService]
})
export class TokenDialogAbstractionComponent implements OnInit, CustomDialogComponent {
  public tokenForm: FormGroup;
  public data: any;
  public tokenInput: string;
  public statusSlide: string;

  @Output() readonly confirm: EventEmitter<any> = new EventEmitter<any>();

  constructor(private confirmService: ConfirmTokenService) {
  }

  ngOnInit() {
    this.tokenForm = new FormGroup({
			tokenInput: new FormControl('', {
				validators: [Validators.required, Validators.minLength(4)],
				updateOn: 'change'
			})
    });
    if (this.data && this.data.hasOwnProperty('statusObservable')) {
      this.data.statusObservable.getObservableStatusSlide().subscribe( (status: string) => {
        this.statusSlide = status;
      });
    }
  }

  confirmationEvent() {
    this.confirmService.confirm();
    this.data.confirmevent();
  }
}
