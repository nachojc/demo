import { TokenInputModule } from './../../token-input/token-input.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TokenDialogAbstractionComponent } from './dialog-abstraction.component';
import { SlideButtonModule } from '../../../atoms/slide-button';
import { ReactiveFormsModule } from '@angular/forms';
import { ConfirmTokenService } from './confirm-token.service';
import { Component, NgModule } from '@angular/core';
import { By } from '@angular/platform-browser';

@Component({
	selector: 'sn-custom-html',
	template: `
		<style>
		.text {
			font-family: SantanderText;
			font-size: 16px;
			font-weight: normal;
			font-style: normal;
			font-stretch: normal;
			line-height: 1.5;
			letter-spacing: normal;
			color: #000000;
			text-align: left;
			}
		</style>
		<div class="text">
			El sistema está a punto de usar nuevamente la clave SuperToken que ya habías introducido.
		</div>
	`
})
	class CustomTokenContentComponent {
}

@NgModule({
	declarations: [CustomTokenContentComponent],
	entryComponents: [
		CustomTokenContentComponent,
	]
  })
class TestModule {}

describe('TokenDialogAbstractionComponent', () => {
	let component: TokenDialogAbstractionComponent;
	let fixture: ComponentFixture<TokenDialogAbstractionComponent>;
	let statusObservable: ConfirmTokenService;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [TokenDialogAbstractionComponent],
			providers: [ConfirmTokenService],
			imports: [TokenInputModule, SlideButtonModule, ReactiveFormsModule, TestModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TokenDialogAbstractionComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		statusObservable = new ConfirmTokenService();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should confirm event', async(() => {
		component.data = {confirmevent:()=>{}};
		spyOn(component.data, 'confirmevent');
		component.confirmationEvent();
		expect(component.data.confirmevent).toHaveBeenCalled();
	}));

	it('should change statusSlide', () => {
		component.data = {statusObservable: statusObservable};
		component.ngOnInit();
		statusObservable.setStatusSlide('success');
		expect(component.statusSlide).not.toBeUndefined();
	});

	it('should call setProperty function', () => {
		let value = true;
		component.setProperty({showTokenInput: value}, 'showTokenInput');
		expect(component.showTokenInput).toBe(value);
		value = false;
		component.setProperty({showTokenInput: value}, 'showTokenInput');
		expect(component.showTokenInput).toBe(value);
	});

	it('should create customBody', () => {
		component.data = {customBody : CustomTokenContentComponent};
		component.ngOnInit();
		const compiled = fixture.debugElement;
		expect(compiled.query(By.css('.text'))).toBeTruthy();
	});
});

describe('ConfirmTokenService', () => {
	let statusObservable: ConfirmTokenService;

	beforeEach(() => {
		statusObservable = new ConfirmTokenService();
	});

	it('should get Response observable', ()=> {
		const control = statusObservable.getControl();
		expect(statusObservable.getResponse()).toEqual(control.asObservable());
	});

	it('should get Status Slide', () => {
		const statusSlide = statusObservable.getStatusSlide();
		expect(statusObservable.getObservableStatusSlide()).toEqual(statusSlide.asObservable());
	});

	it('should set Status Slide', () => {
		let statusSlide: string;
		const response = 'success';
		statusObservable.getObservableStatusSlide().subscribe( (status: string) => {
			statusSlide = status;
		  });
		statusObservable.setStatusSlide(response);
		expect(statusSlide).toEqual(response);
	});
});