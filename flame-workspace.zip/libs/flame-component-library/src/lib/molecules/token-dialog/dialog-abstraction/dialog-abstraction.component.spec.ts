import { TokenInputModule } from './../../token-input/token-input.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TokenDialogAbstractionComponent } from './dialog-abstraction.component';
import { SlideButtonModule } from '../../../atoms/slide-button';
import { ReactiveFormsModule } from '@angular/forms';
import { Subscription, of, Observable } from 'rxjs';
import { ConfirmTokenService } from './confirm-token.service';
import { renderFlagCheckIfStmt } from '@angular/compiler/src/render3/view/template';

describe('TokenDialogAbstractionComponent', () => {
	let component: TokenDialogAbstractionComponent;
	let fixture: ComponentFixture<TokenDialogAbstractionComponent>;
	let statusObservable: ConfirmTokenService;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
	  declarations: [TokenDialogAbstractionComponent],
	  providers: [ConfirmTokenService],
      imports: [TokenInputModule, SlideButtonModule, ReactiveFormsModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(TokenDialogAbstractionComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		statusObservable = new ConfirmTokenService();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should confirm event', async(() => {
		component.data = {confirmevent:()=>{}};
		spyOn(component.data, 'confirmevent');
		component.confirmationEvent();
		expect(component.data.confirmevent).toHaveBeenCalled();
	}));

	it('should change statusSlide', () => {
		component.data = {statusObservable: statusObservable};
		component.ngOnInit();
		statusObservable.setStatusSlide('success');
		expect(component.statusSlide).not.toBeUndefined();
	});
});

describe('ConfirmTokenService', () => {
	let statusObservable: ConfirmTokenService;

	beforeEach(() => {
		statusObservable = new ConfirmTokenService();
	});

	it('should get Response observable', ()=> {
		const control = statusObservable.getControl();
		expect(statusObservable.getResponse()).toEqual(control.asObservable());
	});

	it('should get Status Slide', () => {
		const statusSlide = statusObservable.getStatusSlide();
		expect(statusObservable.getObservableStatusSlide()).toEqual(statusSlide.asObservable());
	});

	it('should set Status Slide', () => {
		let statusSlide: string;
		const response = 'success';
		statusObservable.getObservableStatusSlide().subscribe( (status: string) => {
			statusSlide = status;
		  });
		statusObservable.setStatusSlide(response);
		expect(statusSlide).toEqual(response);
	});
});