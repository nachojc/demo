
import { async, TestBed } from '@angular/core/testing';
import { TokenDialogService } from './token-dialog.service';
import { DialogReference } from '../../atoms/dialog';
import { Overlay } from '@angular/cdk/overlay';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';
import { TokenDialogModule } from '@santander/flame-component-library';

describe('TokenDialogService', () => {
    let tokenDialogService: TokenDialogService;
    let dialogRef: DialogReference;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
	  declarations: [],
	  providers: [
          TokenDialogService,
          ConfirmTokenService,
          Overlay
        ],
      imports:  [TokenDialogModule]
		}).compileComponents();
	}));

	beforeEach(() => {
        dialogRef = new DialogReference(null);
        tokenDialogService = TestBed.get(TokenDialogService);
    });

	it('should create', () => {
		expect(tokenDialogService).toBeTruthy();
    });
    
    it('should get Confirm event', () => {
        const confirm = tokenDialogService.getConfirm();
        expect(tokenDialogService.getConfirmEvent()).toEqual(confirm.asObservable());
    });

    it('should get state dialog event', () => {
        const stateDialog = tokenDialogService.getSubjectStateDialog();
        expect(tokenDialogService.getStateDialog()).toEqual(stateDialog.asObservable());
    });

    it('should set status slide event', () => {
        const statusSlide = tokenDialogService.getStatusSlide();
        const observerStatus = statusSlide.getObservableStatusSlide();
        const newStatus = 'success';
        observerStatus.subscribe( (status: string) => {
			expect(status).toBe(newStatus);
		  });
        tokenDialogService.setStatusSlide(newStatus);
    });

    it('should set default status slide event', () => {
        const statusSlide = tokenDialogService.getStatusSlide();
        const observerStatus = statusSlide.getObservableStatusSlide();
        const newStatus = '';
        observerStatus.subscribe( (status: string) => {
			expect(status).toBe(newStatus);
		  });
        tokenDialogService.setStatusSlide(newStatus);
    });

    it('should set default status slide event', () => {
        const statusSlide = tokenDialogService.getStatusSlide();
        const observerStatus = statusSlide.getObservableStatusSlide();
        const newStatus = null;
        observerStatus.subscribe( (status: string) => {
			expect(status).toBe('');
		  });
        tokenDialogService.setStatusSlide(newStatus);
    });

    it('should Confirm event', () => {
        const confirm = tokenDialogService.getConfirm();
        spyOn(confirm,'next');
        tokenDialogService.confirmEvent();
        expect(confirm.next).toHaveBeenCalled();
    });

    it('should close Dilaog token', () => {
        tokenDialogService.setDialogRef(dialogRef);
        const dialog = tokenDialogService.getDialogRef();
        spyOn(dialog,'close');
        tokenDialogService.closeDialogToken();
        expect(dialogRef.close).toHaveBeenCalled();
    });

    it('should get dialogRef from dialog instance', () => {
        spyOn(tokenDialogService.getDialog(),'open').and.returnValue(dialogRef);
        tokenDialogService.openDialogToken();
        expect(tokenDialogService.getDialog()).toBeTruthy();
    });
});
