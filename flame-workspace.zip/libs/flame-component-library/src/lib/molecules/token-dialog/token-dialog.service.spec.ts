
import { async, TestBed } from '@angular/core/testing';
import { TokenDialogService } from './token-dialog.service';
import { DialogReference } from '../../atoms/dialog';
import { Overlay } from '@angular/cdk/overlay';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';
import { TokenDialogModule } from '@santander/flame-component-library';
import { NgModule, Component } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@Component({
	selector: 'sn-custom-html',
	template: `
		<style>
		.text {
			font-family: SantanderText;
			font-size: 16px;
			font-weight: normal;
			font-style: normal;
			font-stretch: normal;
			line-height: 1.5;
			letter-spacing: normal;
			color: #000000;
			text-align: left;
			}
		</style>
		<div class="text">
			El sistema está a punto de usar nuevamente la clave SuperToken que ya habías introducido.
		</div>
	`
})
	class CustomTokenContentComponent {
}

@NgModule({
	declarations: [CustomTokenContentComponent],
	entryComponents: [
		CustomTokenContentComponent,
	]
  })
class TestModule {}

describe('TokenDialogService', () => {
    let tokenDialogService: TokenDialogService;
    let dialogRef: DialogReference;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
	  declarations: [],
	  providers: [
          TokenDialogService,
          ConfirmTokenService,
          Overlay
        ],
      imports:  [TokenDialogModule, TestModule, BrowserAnimationsModule]
		}).compileComponents();
	}));

	beforeEach(() => {
        dialogRef = new DialogReference(null);
        tokenDialogService = TestBed.get(TokenDialogService);
    });

	it('should create', () => {
		expect(tokenDialogService).toBeTruthy();
    });
    
    it('should get Confirm event', () => {
        const confirm = tokenDialogService.getConfirm();
        expect(tokenDialogService.getConfirmEvent()).toEqual(confirm.asObservable());
    });

    it('should get state dialog event', () => {
        const stateDialog = tokenDialogService.getSubjectStateDialog();
        expect(tokenDialogService.getStateDialog()).toEqual(stateDialog.asObservable());
    });

    it('should set status slide event', () => {
        const statusSlide = tokenDialogService.getStatusSlide();
        const observerStatus = statusSlide.getObservableStatusSlide();
        const newStatus = 'success';
        observerStatus.subscribe( (status: string) => {
			expect(status).toBe(newStatus);
		  });
        tokenDialogService.setStatusSlide(newStatus);
    });

    it('should set default status slide event', () => {
        const statusSlide = tokenDialogService.getStatusSlide();
        const observerStatus = statusSlide.getObservableStatusSlide();
        const newStatus = '';
        observerStatus.subscribe( (status: string) => {
			expect(status).toBe(newStatus);
		  });
        tokenDialogService.setStatusSlide(newStatus);
    });

    it('should set default status slide event', () => {
        const statusSlide = tokenDialogService.getStatusSlide();
        const observerStatus = statusSlide.getObservableStatusSlide();
        const newStatus = null;
        observerStatus.subscribe( (status: string) => {
			expect(status).toBe('');
		  });
        tokenDialogService.setStatusSlide(newStatus);
    });

    it('should Confirm event', () => {
        const confirm = tokenDialogService.getConfirm();
        spyOn(confirm,'next');
        tokenDialogService.confirmEvent();
        expect(confirm.next).toHaveBeenCalled();
    });

    it('should close Dilaog token', () => {
        tokenDialogService.setDialogRef(dialogRef);
        const dialog = tokenDialogService.getDialogRef();
        spyOn(dialog,'close');
        tokenDialogService.closeDialogToken();
        expect(dialogRef.close).toHaveBeenCalled();
    });

    it('should get dialogRef from dialog instance', () => {
        spyOn(tokenDialogService.getDialog(),'open').and.returnValue(dialogRef);
        tokenDialogService.openDialogToken({
            typeButton: 'slide',
            showTokenInput: false,
            customBody: CustomTokenContentComponent,
            subtitle: 'subtitle',
            closeLabel: 'closeLabel',
            title: 'title'
        });
        expect(tokenDialogService.getDialog()).toBeTruthy();
    });

    it('should get dialogRef from dialog instance by default params', () => {
        spyOn(tokenDialogService.getDialog(),'open').and.returnValue(dialogRef);
        tokenDialogService.openDialogToken();
        expect(tokenDialogService.getDialog()).toBeTruthy();
    });
});
