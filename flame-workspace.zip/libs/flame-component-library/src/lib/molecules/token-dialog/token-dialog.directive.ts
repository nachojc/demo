import { Directive, Input, HostListener, EventEmitter, Output } from '@angular/core';
import { DialogReference, DialogService, CustomDialog } from '../../atoms/dialog';
import { TokenDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';

@Directive({
  selector: '[smTokendialog]',
})
export class TokenDialogDirective {
  /**
   *Creates an instance of TokenDialogDirective.
   * @param {DialogService} dialog
   * @param {ConfirmTokenService} _statusSlide
   * @memberof TokenDialogDirective
   */
  constructor(private dialog: DialogService, private _statusSlide: ConfirmTokenService){}

  /**
   * @ignore
   * Indica si el dialogo está abierto o cerrado.
   * 
   * @private
   * @type {boolean}
   * @memberof TokenDialogDirective
   */
  private _closeDialog = false;

  /**
   * @ignore
   * Indica la referencia al dialogo.
   * 
   * @private
   * @type {DialogReference}
   * @memberof TokenDialogDirective
   */
  private dialogRef: DialogReference;

  /**
   * Callback que emite la informacion relacionada 
   * a la entrada de usuario, una vez deslizado el 
   * slidebutton.
   *
   * @type {EventEmitter<any>}
   * @memberof TokenDialogDirective
   */
  @Output() confirm = new EventEmitter<any>();

  /**
   * Callback que emite los estados "startclose" y 
   * "closed" propios de la animación al ocultarse 
   * o cerrar el dialogo.
   *
   * @type {EventEmitter<string>}
   * @memberof TokenDialogDirective
   */
  @Output() dialogstate = new EventEmitter<string>();
  
  /**
   * Recibe el estado "true" si se desea cerrar 
   * el dialogo y "false" (por defecto) para 
   * inmutar el dialogo.
   *
   * @type {boolean}
   * @memberof TokenDialogDirective
   */
  @Input()
  set closedialog(value: boolean){
    this._closeDialog = value;
    if (this.dialogRef){
      this.dialogRef.close();
    }
  }
  get closedialog(){
    return this._closeDialog;
  }

  /**
   * Indica el el estado del botón deslizable.
   *
   * @type {string}
   * @memberof TokenDialogDirective
   */
  @Input()
  set statusSlide(value: string) {
    if (value) {
      this._statusSlide.setStatusSlide(value);
    } else {
      this._statusSlide.setStatusSlide('');
    }
  }
  getStatusSlide(): ConfirmTokenService {
    return this._statusSlide;
  }

  /**
   * Devuelve la referencia al dialogo.
   *
   * @returns {DialogReference}
   * @memberof TokenDialogDirective
   */
  getDialogRef(): DialogReference {
    return this.dialogRef;
  }

  /**
   * Define la referencia al dialogo.
   *
   * @param {DialogReference} dialogRef
   * @memberof TokenDialogDirective
   */
  setDialogRef(dialogRef: DialogReference) {
    this.dialogRef = dialogRef;
  }

  /**
   * Devuelve el dialogo como servicio.
   *
   * @returns {DialogService}
   * @memberof TokenDialogDirective
   */
  getDialog(): DialogService {
    return this.dialog;
  }

  /**
   * Emite el evento cuando el usuario da 
   * click sobre el componente y se encarga de 
   * cerrar el dialogo.
   *
   * @param {Event} data
   * @memberof TokenDialogDirective
   */
  @HostListener('click')
  clickEvent(data: Event){
    this.dialogRef = this.dialog.open(
			{
				closeLabel: 'Cancelar',
				title: 'Valida la operación',
				enableHr: true,
        disabledButton: false,
        showButton: false,
        backdropClass: 'dark-backdrop',
        closeBackdropClick: false
			},
			new CustomDialog(TokenDialogAbstractionComponent, {
        confirmevent: () => this.confirmEventDispatcher(), 
        statusObservable: this._statusSlide})
    );
    this.dialogRef.afterClosed().subscribe(() => {
      this.dialogstate.emit('closed');
    })
    this.dialogRef.beforeClose().subscribe(() => {
      this.dialogstate.emit('startclose');
    })
  }

  /**
   * Emite la confirmación del dialogo
   *
   * @memberof TokenDialogDirective
   */
  confirmEventDispatcher(){
    this.confirm.emit({ok: 200});
  }
}
