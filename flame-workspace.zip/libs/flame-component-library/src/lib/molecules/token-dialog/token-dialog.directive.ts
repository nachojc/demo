import { Directive, Input, HostListener, EventEmitter, Output } from '@angular/core';
import { DialogReference, DialogService, CustomDialog } from '../../atoms/dialog';
import { TokenDialogAbstractionComponent } from './dialog-abstraction/dialog-abstraction.component';
import { ConfirmTokenService } from './dialog-abstraction/confirm-token.service';
import { Component } from '@angular/compiler/src/core';

@Directive({
  selector: '[smTokendialog]',
})
export class TokenDialogDirective {
  /**
   *Creates an instance of TokenDialogDirective.
   * @param {DialogService} dialog
   * @param {ConfirmTokenService} _statusSlide
   * @memberof TokenDialogDirective
   */
  constructor(private dialog: DialogService, private _statusSlide: ConfirmTokenService){}

  /**
   * @ignore
   * Indica si el diálogo está abierto o cerrado.
   * 
   * @private
   * @type {boolean}
   * @memberof TokenDialogDirective
   */
  private _closeDialog = false;

  /**
   * @ignore
   * Indica la referencia al diálogo.
   * 
   * @private
   * @type {DialogReference}
   * @memberof TokenDialogDirective
   */
  private dialogRef: DialogReference;

  /**
   * @ignore
   * Indica el tipo de botón a mostrar.
   * Puede ser slide o basic
   * 
   * @private
   * @type {string}
   * @memberof TokenDialogDirective
   */
  private _typeButton = 'slide';

    /**
   * @ignore
   * Indica si se muestra el token input o no.
   * 
   * @private
   * @type {boolean}
   * @memberof TokenDialogDirective
   */
  private _showTokenInput = false;

    /**
   * Callback que emite la informacion relacionada 
   * a la entrada de usuario, una vez deslizado el 
   * slidebutton.
   *
   * @type {EventEmitter<any>}
   * @memberof TokenDialogDirective
   */
  @Output() confirm = new EventEmitter<any>();

  /**
   * Callback que emite los estados "startclose" y 
   * "closed" propios de la animación al ocultarse 
   * o cerrar el diálogo.
   *
   * @type {EventEmitter<string>}
   * @memberof TokenDialogDirective
   */
  @Output() dialogstate = new EventEmitter<string>();

  /**
   * Indica el componente personalizado a renderizar dentro del diálogo.
   * 
   * @type {any}
   * @memberof TokenDialogDirective
   */
  @Input() customBody: any;

  /**
   * Indica el subtítulo del diálogo.
   * 
   * @type {string}
   * @memberof TokenDialogDirective
   */
  @Input() subtitle: string;
  
  /**
   * Indica el título del diálogo.
   * 
   * @type {string}
   * @memberof TokenDialogDirective
   */
  @Input() title = 'Confirma con tu SuperToken';
  
  /**
   * Indica el label en el botón cerrar diálogo.
   * 
   * @type {string}
   * @memberof TokenDialogDirective
   */
  @Input() closeLabel = 'Cerrar';

  /**
   * Recibe el estado "true" si se desea cerrar 
   * el diálogo y "false" (por defecto) para 
   * inmutar el diálogo.
   *
   * @type {boolean}
   * @memberof TokenDialogDirective
   */
  @Input()
  set closedialog(value: boolean){
    this._closeDialog = value;
    if (this.dialogRef){
      this.dialogRef.close();
    }
  }
  get closedialog(){
    return this._closeDialog;
  }

  /**
   * Indica el el estado del botón deslizable.
   *
   * @type {string}
   * @memberof TokenDialogDirective
   */
  @Input()
  set statusSlide(value: string) {
    if (value) {
      this._statusSlide.setStatusSlide(value);
    } else {
      this._statusSlide.setStatusSlide('');
    }
  }
  getStatusSlide(): ConfirmTokenService {
    return this._statusSlide;
  }

  /**
   * Indica el tipo de button a mostrar.
   * Ya sea slide o basic
   *
   * @returns {DialogReference}
   * @memberof TokenDialogDirective
   */
  @Input()
  set typeButton(value: string) {
    this._typeButton = value;
  }
  get typeButton(): string {
    return this._typeButton;
  }

    /**
   * Indica si token input es visible dentro del diálogo o no.
   *
   * @returns {DialogReference}
   * @memberof TokenDialogDirective
   */
  @Input()
  set showTokenInput(value: boolean) {
    this._showTokenInput = value;
  }
  get showTokenInput(): boolean {
    return this._showTokenInput;
  }

  /**
   * Devuelve la referencia al diálogo.
   *
   * @returns {DialogReference}
   * @memberof TokenDialogDirective
   */
  getDialogRef(): DialogReference {
    return this.dialogRef;
  }

  /**
   * Define la referencia al diálogo.
   *
   * @param {DialogReference} dialogRef
   * @memberof TokenDialogDirective
   */
  setDialogRef(dialogRef: DialogReference) {
    this.dialogRef = dialogRef;
  }

  /**
   * Devuelve el diálogo como servicio.
   *
   * @returns {DialogService}
   * @memberof TokenDialogDirective
   */
  getDialog(): DialogService {
    return this.dialog;
  }

  /**
   * Emite el evento cuando el usuario da 
   * click sobre el componente y se encarga de 
   * cerrar el diálogo.
   *
   * @param {Event} data
   * @memberof TokenDialogDirective
   */
  @HostListener('click')
  clickEvent(data: Event) {
    const customDialog = new CustomDialog(TokenDialogAbstractionComponent, {
      confirmevent: () => this.confirmEventDispatcher(), 
      statusObservable: this._statusSlide,
      typeButton: this._typeButton,
      showTokenInput: this.showTokenInput,
      customBody: this.customBody,
      subtitle: this.subtitle
    });
    this.dialogRef = this.dialog.open(
			{
				closeLabel: this.closeLabel,
        title: this.title,
				enableHr: true,
        disabledButton: false,
        showButton: false,
        backdropClass: 'dark-backdrop',
        closeBackdropClick: false
			}, customDialog);
    this.dialogRef.afterClosed().subscribe(() => {
      this.dialogstate.emit('closed');
    })
    this.dialogRef.beforeClose().subscribe(() => {
      this.dialogstate.emit('startclose');
    })
  }

  /**
   * Emite la confirmación del diálogo
   *
   * @memberof TokenDialogDirective
   */
  confirmEventDispatcher(){
    this.confirm.emit({ok: 200});
  }
}
