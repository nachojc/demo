export interface ITokenDialogConfirm {
  token?: string;
  stateDialog: TokenDialogInterfaceParams.StateDialog
}

export interface ITokenDialogState{
  stateDialog: TokenDialogInterfaceParams.StateDialog
}

export namespace TokenDialogInterfaceParams {
  export type StateDialog = 'startclose' | 'closed' | 'awaiting' | 'loadingbutton' | 'error' | 'success';
  export const StateDialog = {
    STARTCLOSE: 'startclose' as StateDialog,
    CLOSED: 'closed' as StateDialog,
    AWAITING: 'awaiting' as StateDialog,
    LOADING: 'loadingbutton' as StateDialog,
    ERROR: 'error' as StateDialog,
    SUCCESS: 'success' as StateDialog,
    LOST: 'lost' as StateDialog
  };
}

declare var TokenDialogConfirm: {
  prototype: ITokenDialogConfirm;
  new(stateDialog: TokenDialogInterfaceParams.StateDialog, token?: string): ITokenDialogConfirm;
};

declare var TokenDialogState: {
  prototype: ITokenDialogState;
  new(stateDialog: TokenDialogInterfaceParams.StateDialog): ITokenDialogState;
}
