import { NgModule } from '@angular/core';
import { CallButtonComponent } from './call-button.component';

@NgModule({
	imports: [],
	declarations: [CallButtonComponent],
	exports: [CallButtonComponent]
})
export class CallButtonModule {}
