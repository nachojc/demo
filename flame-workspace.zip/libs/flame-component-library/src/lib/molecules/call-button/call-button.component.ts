import { Component } from '@angular/core';

@Component({
	selector: 'sn-call-button',
	templateUrl: './call-button.component.html',
	styleUrls: ['./call-button.component.scss']
})
export class CallButtonComponent {
	constructor() {}
	phoneNumber = '+5215551694300';
}
