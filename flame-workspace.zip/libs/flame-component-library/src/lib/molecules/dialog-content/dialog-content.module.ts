import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogContentComponent } from './dialog-content.component';
import { InsertionDirective } from './insertion.directive';

@NgModule({
  imports: [CommonModule],
  declarations: [DialogContentComponent, InsertionDirective],
  entryComponents: [DialogContentComponent]
})
export class DialogContentModule {}
