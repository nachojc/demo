import { Injectable, ComponentFactoryResolver, ApplicationRef, Injector, Type, EmbeddedViewRef, ComponentRef } from '@angular/core';
import { DialogContentModule } from './dialog-content.module';
import { DialogContentComponent } from './dialog-content.component';
import { DialogContentInjector } from './dialog-content-injector';
import { DialogContentRef } from './dialog-content-ref';

@Injectable({
  providedIn: DialogContentModule
})
export class DialogContentService {
  dialogComponentRef: ComponentRef<DialogContentComponent>;

  constructor(private componentFactoryResolver: ComponentFactoryResolver, private appRef: ApplicationRef, private injector: Injector) {}

  public open(componentType: Type<any>) {
    const dialogRef = this.appendDialogComponentToBody();

    this.dialogComponentRef.instance.childComponentType = componentType;

    return dialogRef;
  }

  private appendDialogComponentToBody() {
    const map = new WeakMap();

    const dialogRef = new DialogContentRef();
    map.set(DialogContentRef, dialogRef);

    const sub = dialogRef.afterClosed.subscribe(() => {
      this.removeDialogComponentFromBody();
      sub.unsubscribe();
    });

    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(DialogContentComponent);
    const componentRef = componentFactory.create(new DialogContentInjector(this.injector, map));

    this.appRef.attachView(componentRef.hostView);

    const domElem = (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
    document.body.appendChild(domElem);

    this.dialogComponentRef = componentRef;

    this.dialogComponentRef.instance.onClose.subscribe(() => {
      this.removeDialogComponentFromBody();
    });

    return dialogRef;
  }

  private removeDialogComponentFromBody() {
    this.appRef.detachView(this.dialogComponentRef.hostView);
    this.dialogComponentRef.destroy();
  }
}
