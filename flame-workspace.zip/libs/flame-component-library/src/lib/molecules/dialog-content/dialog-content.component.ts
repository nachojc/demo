import { Component, Type, ComponentFactoryResolver, ViewChild, OnDestroy, ComponentRef, AfterViewInit, ChangeDetectorRef, EventEmitter } from '@angular/core';
import { InsertionDirective } from './insertion.directive';
import { Subject } from 'rxjs';
import { DialogContentRef } from './dialog-content-ref';
import { trigger, state, style, transition, animate, AnimationEvent } from '@angular/animations';

@Component({
  selector: 'sn-dialog-content',
  templateUrl: './dialog-content.component.html',
  styleUrls: ['./dialog-content.component.scss'],
  animations: [
		trigger('slideContent', [
			state('void', style({ transform: 'translate3d(0, 50%, 0)', opacity: 0 })),
			state('enter', style({ transform: 'none', opacity: 1 })),
			state('leave', style({ transform: 'translate3d(0, 100%, 0)' })),
			transition('* => *', animate('400ms cubic-bezier(0.25, 0.8, 0.25, 1)'))
		])
	]
})
export class DialogContentComponent implements AfterViewInit, OnDestroy {
  componentRef: ComponentRef<any>;
	animationStateChanged = new EventEmitter<AnimationEvent>();

  @ViewChild(InsertionDirective)
  insertionPoint: InsertionDirective;
	animationState: 'void' | 'enter' | 'leave' = 'enter';

  private readonly _onClose = new Subject<any>();
  public onClose = this._onClose.asObservable();

  childComponentType: Type<any>;

  constructor(private componentFactoryResolver: ComponentFactoryResolver, private cd: ChangeDetectorRef, private dialogRef: DialogContentRef) {}

  ngAfterViewInit() {
    this.loadChildComponent(this.childComponentType);
    this.cd.detectChanges();
  }

  onOverlayClicked(evt: MouseEvent) {
    this.dialogRef.close();
  }

  onDialogClicked(evt: MouseEvent) {
    evt.stopPropagation();
  }

  loadChildComponent(componentType: Type<any>) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentType);

    const viewContainerRef = this.insertionPoint.viewContainerRef;
    viewContainerRef.clear();

    this.componentRef = viewContainerRef.createComponent(componentFactory);
  }

  ngOnDestroy() {
    if (this.componentRef) {
      this.componentRef.destroy();
    }
  }

  close() {
    this._onClose.next();
  }

  onAnimationStart(event: AnimationEvent) {
		this.animationStateChanged.emit(event);
	}

	/**
	 * Emite un el evento cuando se termina alguna animación
	 * @param {AnimationEvent} event
	 * @memberof DialogComponent
	 */
	onAnimationDone(event: AnimationEvent) {
		this.animationStateChanged.emit(event);
	}
}
