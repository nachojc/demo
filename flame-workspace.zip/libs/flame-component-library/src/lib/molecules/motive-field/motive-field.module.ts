import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../atoms/icon/icon.module';
import { MotiveFieldComponent } from './motive-field.component';
import { FormsModule } from '@angular/forms';
import { AutoWidthInputModule } from '../../directives/auto-width-input/auto-width-input.module';

@NgModule({
	imports: [
		CommonModule,
		IconModule,
		FormsModule,
		AutoWidthInputModule
	],
	declarations: [MotiveFieldComponent],
	exports: [MotiveFieldComponent]
})
export class MotiveFieldModule { }