import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { MotiveFieldComponent } from './motive-field.component';
import { MotiveFieldModule } from './motive-field.module';
import { IconModule } from '../../atoms/icon';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('MotiveFieldComponent', () => {
	let component: MotiveFieldComponent;
	let fixture: ComponentFixture<MotiveFieldComponent>;
	let inputEl: DebugElement;
	let divEl: DebugElement;
	let labelEl: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [MotiveFieldComponent],
			imports: [IconModule, FormsModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(MotiveFieldComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create module', () => {
		const module = new MotiveFieldModule();
		expect(module).toBeTruthy();
	});

	it('should create component', () => {
		expect(component).toBeTruthy();
	});

	//Inputs

	it('placeholder Input get and set', () => {
		expect(component.placeholder).toBe(component.placeholder);
		const placeholder = 'Fake placeholder';
		component.placeholder = placeholder;
		expect(component.placeholder).toBe(placeholder);
	});

	it('infoButton Input get and set', () => {
		expect(component.infoButton).toBe(component.infoButton);
		const infoButton = 'Fake infoButton';
		component.infoButton = infoButton;
		expect(component.infoButton).toBe(infoButton);
	});

	it('iconButton Input get and set', () => {
		expect(component.iconButton).toBe(component.iconButton);
		const iconButton = 'Fake iconButton';
		component.iconButton = iconButton;
		expect(component.iconButton).toBe(iconButton);
	});

	it('min Input get and set', () => {
		expect(component.min).toBe(component.min);
		const length = 4;
		component.min = length;
		expect(component.min).toBe(length);
	});

	it('max Input get and set', () => {
		expect(component.max).toBe(component.max);
		const length = 7;
		component.max = length;
		expect(component.max).toBe(length);
	});

	it('label Input get and set', () => {
		expect(component.label).toBe(component.label);
		const label = 'ABCDEFG';
		component.label = label;
		expect(component.label).toBe(label);
	});

	it('value Input get and set', () => {
		expect(component.value).toBe(component.value);
		const motive = 'Motive';
		component.value = motive;
		expect(component.value).toBe(motive);
	});

	it('invalidChars Input get and set', () => {
		expect(component.invalidChars).toBe(component.invalidChars);
		const invalidChars = '-?_';
		component.invalidChars = invalidChars;
		expect(component.invalidChars).toBe(invalidChars);
	});

	it('enableReadOnly input get and set', () => {
		expect(component.readOnly).toBe(component.readOnly);
		component.readOnly = true;
		expect(component.readOnly).toBeTruthy();
	});

	it('disabled Input get and set', () => {
		expect(component.disabled).toBe(component.disabled);
		component.disabled = true;
		expect(component.disabled).toBeTruthy();
	});

	it('showError Input get and set', () => {
		expect(component.showError).toBe(component.showError);
		const showError = true;
		component.showError = showError;
		expect(component.showError).toBeTruthy();
	});

	it('error Input get and set', () => {
		expect(component.error).toBe(component.error);
		const error = 'Fake error';
		component.error = error;
		expect(component.error).toBe(error);
	});

	it('validate method for valid motive', () => {
		component.min = 2;
		component.max = 4;
		component.validate('ABC');
		expect(component.invalidMotive).toBeFalsy();
		expect(component.errorMessage).toBe('');
	});

	//Methods

	it('validate method for motive with invalid characters', () => {
		component.min = 2;
		component.max = 4;
		component.validate('A-C');
		expect(component.invalidMotive).toBeTruthy();
		expect(component.errorMessage).toBe(
			`La referencia no puede tener carácteres especiales (${
				component.invalidChars
			})`
		);
	});

	it('validate method for motive with less characters than minimum', () => {
		component.min = 2;
		component.max = 4;
		component.validate('A');
		expect(component.invalidMotive).toBeTruthy();
		expect(component.errorMessage).toBe(
			`El motivo no puede tener menos de ${component.min} carácteres`
		);
	});

	it('validate method for motive with more characters than maximum', () => {
		component.min = 2;
		component.max = 4;
		component.validate('ABCDEF');
		expect(component.invalidMotive).toBeTruthy();
		expect(component.errorMessage).toBe(
			`El motivo no puede tener más de ${component.max} carácteres`
		);
	});

	it('validate method for custom error message', () => {
		component.showError = true;
		component.error = 'Fake error message';
		component.validate('A');
		expect(component.invalidMotive).toBeTruthy();
		expect(component.errorMessage).toBe(component.error);
	});

	it('validate method with errorMessage emits onError output', () => {
		spyOn(component.onError, 'emit');
		component.showError = true;
		component.error = 'Fake error message';
		component.validate('A');
		expect(component.onError.emit).toHaveBeenCalledWith(component.errorMessage);
	});

	it('changeEvent method with value emits onChange output', () => {
		spyOn(component, 'validate');
		spyOn(component.onChange, 'emit');
		component.value = 'Motive';
		component.changeEvent();
		expect(component.validate).toHaveBeenCalledWith(component.value);
		expect(component.onChange.emit).toHaveBeenCalledWith(component.value);
	});

	it('changeEvent method with no value emits clearInput output', () => {
		spyOn(component, 'validate');
		spyOn(component.clearInput, 'emit');
		component.value = '';
		component.changeEvent();
		expect(component.validate).toHaveBeenCalledWith(component.value);
		expect(component.clearInput.emit).toHaveBeenCalledWith('');
	});

	it('focusEvent method with value emits onFocus output', () => {
		spyOn(component, 'validate');
		spyOn(component.onFocus, 'emit');
		component.value = 'Motive';
		component.focusEvent();
		expect(component.validate).toHaveBeenCalledWith(component.value);
		expect(component.onFocus.emit).toHaveBeenCalledWith(component.value);
	});

	it('focusEvent method with no value emits onFocus output', () => {
		spyOn(component, 'validate');
		spyOn(component.onFocus, 'emit');
		component.value = '';
		component.focusEvent();
		expect(component.validate).toHaveBeenCalledWith(component.value);
		expect(component.onFocus.emit).toHaveBeenCalledWith('');
	});

	it('blurEvent method with value emits onBlur output', () => {
		spyOn(component, 'validate');
		spyOn(component.onBlur, 'emit');
		component.value = 'Motive';
		component.blurEvent();
		expect(component.validate).toHaveBeenCalledWith(component.value);
		expect(component.onBlur.emit).toHaveBeenCalledWith(component.value);
	});

	it('value with accents is formatted on blur', () => {
		component.value = 'Mótive';
		component.blurEvent();
		expect(component.value).toBe('Motive');
	});

	it('focusEvent method with no value emits onFocus output', () => {
		spyOn(component, 'validate');
		spyOn(component.onBlur, 'emit');
		component.value = '';
		component.blurEvent();
		expect(component.validate).toHaveBeenCalledWith(component.value);
		expect(component.onBlur.emit).toHaveBeenCalledWith('');
	});

	it('enableClear method for disabled options', () => {
		component.readOnly = false;
		component.value = 'Fake concept';
		let enable: boolean;
		const disableValues = [true, false];
		disableValues.forEach(val => {
			component.disabled = val;
			enable = component.enableClear(component.value);
			if (component.disabled) {
				expect(enable).toBe(false);
			} else {
				expect(enable).toBe(true);
			}
		});
	});

	it('enableClear method for disabled options', () => {
		component.disabled = false;
		component.value = 'Fake concept';
		let enable: boolean;
		const readonlyValues = [true, false];
		readonlyValues.forEach(rea => {
			component.readOnly = rea;
			enable = component.enableClear(component.value);
			if (component.readOnly) {
				expect(enable).toBe(false);
			} else {
				expect(enable).toBe(true);
			}
		});
	});

	it('enableClear method for diferent values', () => {
		component.readOnly = false;
		component.disabled = false;
		let enable: boolean;
		const motives = ['', 'Fake concept'];
		motives.forEach(motive => {
			component.value = motive;
			enable = component.enableClear(component.value);
			if (component.value.length > 0) {
				expect(enable).toBe(true);
			} else {
				expect(enable).toBe(false);
			}
		});
	});

	it('clear method', () => {
		spyOn(component.clearButton, 'emit');
		component.clear();
		expect(component.value).toBe('');
		expect(component.invalidMotive).toBeFalsy();
		expect(component.clearButton.emit).toHaveBeenCalledWith(component.value);
	});

	it('iconClick method', () => {
		spyOn(component.iconPress, 'emit');
		const ev = new Event('click');
		component.iconClick(ev);
		expect(component.iconPress.emit).toHaveBeenCalledWith(ev);
	});

	it('infoClick method', () => {
		spyOn(component.infoPress, 'emit');
		const ev = new Event('click');
		component.infoClick(ev);
		expect(component.infoPress.emit).toHaveBeenCalledWith(ev);
	});

	it('ngOnInit', () => {
		spyOn(component, 'readonlyState');
		spyOn(component, 'validate');
		component.ngOnInit();
		expect(component.readonlyState).toHaveBeenCalled();
		expect(component.validate).toHaveBeenCalledWith(component.value);
	});

	it('input HTML element has readonly attribute when readOnly is true', () => {
		component.readOnly = true;
		component.readonlyState();
		fixture.detectChanges();
		const input = fixture.debugElement.query(By.css('input'));
		expect(input.nativeElement.getAttribute('readonly')).toBeTruthy();
		expect(input.nativeElement.getAttribute('tabindex')).toBe('-1');
	});

	it('change event over input element calls changeEvent() method', async () => {
		spyOn(component, 'changeEvent');
		fixture.detectChanges();
		inputEl = fixture.debugElement.query(By.css('input'));
		inputEl.nativeElement.dispatchEvent(new Event('input'));
		expect(component.changeEvent).toHaveBeenCalled();
	});

	it('blur event over input HTML element calls blurEvent() method', () => {
		spyOn(component, 'blurEvent');
		fixture.detectChanges();
		inputEl = fixture.debugElement.query(By.css('input'));
		inputEl.triggerEventHandler('blur', null);
		expect(component.blurEvent).toHaveBeenCalled();
	});

	it('focusout event over input HTML element calls blurEvent() method', () => {
		spyOn(component, 'blurEvent');
		fixture.detectChanges();
		inputEl = fixture.debugElement.query(By.css('input'));
		inputEl.triggerEventHandler('focusout', null);
		expect(component.blurEvent).toHaveBeenCalled();
	});

	it('focusin event over input HTML element calls focusEvent() method', () => {
		spyOn(component, 'focusEvent');
		fixture.detectChanges();
		inputEl = fixture.debugElement.query(By.css('input'));
		inputEl.triggerEventHandler('focusin', null);
		expect(component.focusEvent).toHaveBeenCalled();
	});

	it('disabled attribute on input element HTML is setted with disabled property', () => {
		fixture.detectChanges();
		inputEl = fixture.debugElement.query(By.css('input'));
		expect(inputEl.nativeElement.disabled).toBe(component.disabled);
	});

	it('placeholder attribute on input HTML element is setted', () => {
		fixture.detectChanges();
		inputEl = fixture.debugElement.query(By.css('input'));
		expect(inputEl.nativeElement.placeholder).toBe(component.placeholder);
	});

	it('clear-button div does not render when enableClear is false', () => {
		component.value = '';
		fixture.detectChanges();
		divEl = fixture.debugElement.query(By.css('.clear-button'));
		expect(component.enableClear(component.value)).toBe(false);
		expect(divEl).toBeNull();
	});

	it('clear-button div renders when enableClear is true', () => {
		component.value = 'Fake concept';
		fixture.detectChanges();
		divEl = fixture.debugElement.query(By.css('.clear-button'));
		expect(component.enableClear(component.value)).toBe(true);
		expect(divEl).not.toBeNull();
	});

	it('click event on clear-button div calls clear() method', () => {
		spyOn(component, 'clear');
		component.value = '1000';
		fixture.detectChanges();
		divEl = fixture.debugElement.query(By.css('.clear-button'));
		divEl.nativeElement.click();
		expect(component.clear).toHaveBeenCalled();
	});

	it('label tag renders label', () => {
		fixture.detectChanges();
		labelEl = fixture.debugElement.query(By.css('.motive-label'));
		expect(labelEl.nativeElement.innerHTML).toContain(component.label);
	});

	it('input HTML element has readonly attribute when readOnly is true', () => {
		component.readOnly = true;
		component.readonlyState();
		fixture.detectChanges();
		const input = fixture.debugElement.query(By.css('input'));
		expect(input.nativeElement.getAttribute('readonly')).toBeTruthy();
		expect(input.nativeElement.getAttribute('tabindex')).toBe('-1');
	});

	it('input HTML element has not readonly attribute when readOnly is true', () => {
		component.readOnly = false;
		component.readonlyState();
		fixture.detectChanges();
		const input = fixture.debugElement.query(By.css('input'));
		expect(input.nativeElement.getAttribute('readonly')).toBeFalsy();
	});
});
