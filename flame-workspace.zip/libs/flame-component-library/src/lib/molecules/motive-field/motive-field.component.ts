import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	HostBinding,
	ViewChild,
	Renderer2,
	ElementRef
} from '@angular/core';

/**
 * Component motive-field, that allows to capture motive or concept
 * @example
 * <sn-motive-field snTheme="flame-foundation" global="true"></sn-motive-field>
 * <sn-motive-field snTheme="flame-foundation" global="true" [disabled]="true"></sn-motive-field>
 * <sn-motive-field snTheme="flame-foundation" global="true" value="Traspaso de cuenta"></sn-motive-field>
 * <sn-motive-field snTheme="flame-foundation" global="true" label="Label custom"></sn-motive-field>
 * <sn-motive-field snTheme="flame-foundation" global="true" value="Transferencia" [max]="10"></sn-motive-field>
 * <sn-motive-field snTheme="flame-foundation" global="true" label="Label custom" [min]="20"></sn-motive-field>
 */
@Component({
	selector: 'sn-motive-field',
	templateUrl: './motive-field.component.html',
	styleUrls: ['./motive-field.component.scss']
})
/* tslint:disable */
export class MotiveFieldComponent implements OnInit {

	constructor(private renderer: Renderer2) { }

	// Private variables
	private _placeholder = 'Transferencia';
	private _iconButton: string;
	private _infoButton: string;
	private _min: number;
	private _max: number;
	private _label = 'Motivo o concepto';
	private _value = '';
	private _invalidChars = '*.-_,%$';
	private _readOnly = false;
	private _disable = false;
	private _showError = false;
	private _error = 'Custom error'

	//Public variables
	public invalidMotive = false;
	public errorMessage = '';

	// Inputs
	/**
    * Default motive value
    */
	@Input()
	get placeholder() {
		return this._placeholder;
	}
	set placeholder(newValue: string) {
		this._placeholder = newValue;
	}

	// Inputs

	/**
	 * Enables a button on the side
	 */
	@Input()
	get iconButton() {
		return this._iconButton;
	}
	set iconButton(newValue: string) {
		this._iconButton = newValue;
	}

	/**
	* enables info button on the label's side
	*/
	@Input()
	get infoButton() {
		return this._infoButton;
	}
	set infoButton(newValue: string) {
		this._infoButton = newValue;
	}

	/**
    * Minimum of charts allowed for motive value
    */
	@Input()
	get min() {
		return this._min;
	}
	set min(newValue: number) {
		this._min = newValue;
	}

	/**
    * Maximum of charts allowed for motive value
    */
	@Input()
	get max() {
		return this._max;
	}
	set max(newValue: number) {
		this._max = newValue;
	}

	/**
	* Description of type of motive
	*/
	@Input()
	get label() {
		return this._label;
	}
	set label(newValue: string) {
		this._label = newValue;
	}

	/**
    * Motive or concept value
    */
	@Input()
	get value() {
		return this._value;
	}
	set value(newValue: string) {
		this._value = newValue;
	}

	/**
    * String with chars not allowed for motive value
    */
	@Input()
	get invalidChars() {
		return this._invalidChars;
	}
	set invalidChars(newValue: string) {
		this._invalidChars = newValue;
	}

	/**
	 * Enable input's readonly attribute
	 */
	@Input()
	get readOnly() {
		return this._readOnly;
	}
	set readOnly(value: boolean) {
		this._readOnly = value;
	}

	/**
    * It controls if component is disabled or not
    */
	@Input()
	get disabled() {
		return this._disable;
	}
	set disabled(newValue: boolean) {
		this._disable = newValue;
	}

	/**
    * Enables custom error message
    */
	@Input()
	get showError() {
		return this._showError;
	}
	set showError(newValue: boolean) {
		this._showError = newValue;
	}

	/**
	 * Error message customizable for invalid amounts
	 */
	@Input()
	get error() {
		return this._error;
	}
	set error(newValue: string) {
		this._error = newValue;
	}

	// Outputs
	/**
	 * Event that emit amount value introduced in the input when focusin
	 */
	@Output() onFocus = new EventEmitter<string>();

	/**
	 * Event that emit amount value introduced in the input when blur and focusout
	 */
	@Output() onBlur = new EventEmitter<string>();

	/**
	 * Event that emit amount value introduced in the input
	 */
	@Output() onChange = new EventEmitter<string>();

	/**
	 * Event that emit the error message
	 */
	@Output() onError = new EventEmitter<string>();

	/**
	* Event that emit click icon event
	*/
	@Output() iconPress = new EventEmitter<Event>();

	/**
	 * Event that emit click info event
	 */
	@Output() infoPress = new EventEmitter<Event>();

	/**
	 * Event that emit click on clear button
	 */
	@Output() clearButton = new EventEmitter<string>();

	/**
	 * Event that emit when input is clear by keyboard
	 */
	@Output() clearInput = new EventEmitter<string>();

	// Host Bindings
	/**
	 * It applies CSS disabled class when component is disabled
	 */
	@HostBinding('class.disabled')
	get isDisabled() {
		return this._disable ? true : false;
	}

	/**
	 * It applies CSS invalid-motive class when motive is not valid
	 */
	@HostBinding('class.invalid-motive')
	get isInvalid() {
		return this.invalidMotive ? true : false;
	}

	/**
    * It takes input element
    */
	@ViewChild('motiveInput') input: ElementRef

	//Methods
	/**
   	* Method for validating motive
   	* It sets the corresponding error message if needed
   	* param {string} value
   	*/
	public validate(value: string): void {
		const charList = this.invalidChars.split('').map((char) => char = '\\' + char);
		const invalidCharsFormatted = charList.join();
		const format = new RegExp('[' + invalidCharsFormatted + ']', "i");
		if (format.test(value)) {
			this.invalidMotive = true;
			this.errorMessage = `La referencia no puede tener carácteres especiales (${this.invalidChars})`;
		} else if (this.min && value.length < this.min) {
			this.invalidMotive = true;
			this.errorMessage = `El motivo no puede tener menos de ${this.min} carácteres`
		} else if (this.max && value.length > this.max) {
			this.invalidMotive = true;
			this.errorMessage = `El motivo no puede tener más de ${this.max} carácteres`
		} else if (this.showError && this.error) {
			this.invalidMotive = true;
			this.errorMessage = this.error;
		} else {
			this.invalidMotive = false;
			this.errorMessage = '';
		}

		if (this.errorMessage) {
			this.onError.emit(this.errorMessage);
		}
	}

	/**
	* Method that emits value when input changes
	* if it's empty, emits clearInput with ''
	   */
	public changeEvent(): void {
		this.validate(this.value);
		if (this.value) {
			this.onChange.emit(this.value);
		} else {
			this.clearInput.emit('');
		}
	}

	/**
	 * Method that emits value when focusout and blur on input
	 */
	public focusEvent(): void {
		this.validate(this.value);
		if (this.value) {
			this.onFocus.emit(this.value);
		} else {
			this.onFocus.emit('');
		}
	}

	/**
 	* Method that emits value when focusout and blur on input
 	*/
	public blurEvent(): void {
		this.validate(this.value);
		if (this.value) {
			this.onBlur.emit(this.value);
		} else {
			this.onBlur.emit('');
		}
	}

	/**
	 * Method that enable clear button when amount value exists
	 * param {string} value
	 * returns {boolean}
	 */
	public enableClear(value: string): boolean {
		if (this.disabled || this.readOnly || !value || value.length === 0) {
			return false;
		} else {
			return true;
		}
	}

	/**
   	* Method that reset input value, emits event
   	*/
	public clear(): void {
		this.value = '';
		this.invalidMotive = false;
		this.clearButton.emit(this.value);
	}

	/**
   * Method that sets or unsets input to readonly 
   */
	public readonlyState(): void {
		if (this.readOnly) {
			this.renderer.setAttribute(this.input.nativeElement, 'readonly', 'true');
			this.renderer.setAttribute(this.input.nativeElement, 'tabindex', '-1');
		}
	}

	/**
    * Event emitter for the click icon
    */
	public iconClick(ev: Event): void {
		this.iconPress.emit(ev);
	}

	/**
    * Event emitter for the info icon
    */
	public infoClick(ev: Event): void {
		this.infoPress.emit(ev);
	}

	/**
	 * Initializes component calling motive event
	 */
	ngOnInit() {
		this.readonlyState();
		this.validate(this.value);
	}
}
