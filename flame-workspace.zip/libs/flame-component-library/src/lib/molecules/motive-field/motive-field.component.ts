import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	HostBinding,
	ViewChild,
	Renderer2,
	ElementRef
  } from '@angular/core';
  
  /**
   * Component motive-field, that allows to capture motive or concept
   * @example
   * <sn-motive-field></sn-motive-field>
   * <sn-motive-field [disabled]="true"></sn-motive-field>
   * <sn-motive-field value="Traspaso de cuenta"></sn-motive-field>
   * <sn-motive-field label="Label custom"></sn-motive-field>
   * <sn-motive-field value="Transferencia" [max]="10"></sn-motive-field>
   * <sn-motive-field label="Label custom" [min]="20"></sn-motive-field>
   */
  @Component({
	selector: 'sn-motive-field',
	templateUrl: './motive-field.component.html',
	styleUrls: ['./motive-field.component.scss']
  })
  
  /* tslint:disable */
  export class MotiveFieldComponent implements OnInit {
  
	/**
	 * Create an instance of MotiveFieldComponent.
	 * @param {Renderer2} renderer
	 * @memberof MotiveFieldComponent
	 */
	constructor(private renderer: Renderer2) {}
  
	/**
	 * @ignore
	 * Indica el valor que se muestra cuando el input está vacío.
	 * 
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _placeholder = 'Transferencia';
  
	/**
	 * @ignore
	 * Indica el nombre del icono que se muestra a la derecha del input.
	 * 
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _iconButton: string;
  
	/**
	 * @ignore
	 * Indica el tipo de icono (sn-icon) que se puede mostrar junto con el label del componente. Se llama al icono sin el prefijo sn-, por ejemplo 'aclaraciones'.
	 * 
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _infoButton: string;

	/**
	 * @ignore
	 * Indica la cantidad mínima de caracteres que se pueden escribir en el motivo.
	 * 
	 * @private
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	private _min: number;
  
	/**
	 * @ignore
	 * Indica la cantidad máxima de caracteres que se pueden escribir en el motivo.
	 * 
	 * @private
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	private _max: number;
  
	/**
	 * @ignore
	 * Indica la descripcion del motivo.
	 * 
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _label = 'Motivo o concepto';
  
	/**
	 * @ignore
	 * Indica el valor del motivo o concepto que recibe en el componente.
	 * 
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _value = '';
  
	/**
	 * @ignore
	 * Indica los caracteres inválidos dentro de input.
	 * 
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _invalidChars = '*.-_,%$';
  
	/**
	 * @ignore
	 * Indica si input será de solo lectura.
	 * 
	 * @private
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	private _readOnly = false;
  
	/**
	 * @ignore
	 * Indica si input está habilitado o no.
	 * 
	 * @private
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	private _disable = false;
  
	/**
	 * @ignore
	 * Permite el uso de un mensaje de error customizable.
	 * 
	 * @private
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	private _showError = false;
  
	/**
	 * @ignore
	 * Indica el error personalizado a mostrar.
	 * 
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _error = 'Custom error'
  
  
	/**
	 * Indica si el input motive es válido o no.
	 * 
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	public invalidMotive = false;
  
	/**
	 * Indica el mensaje de error a mostrar.
	 * 
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	public errorMessage = '';
  
  
	/**
	 * Indica el valor que se muestra cuando el input está vacío
	 * 
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get placeholder() {
	  return this._placeholder;
	}
	set placeholder(newValue: string) {
	  this._placeholder = newValue;
	}
  
	/**
	 * Indica el nombre del icono que se muestra a la derecha del input.
	 * 
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get iconButton() {
	  return this._iconButton;
	}
	set iconButton(newValue: string) {
	  this._iconButton = newValue;
	}
  
	/**
	 * Indica el tipo de icono (sn-icon) que se puede mostrar junto con el label del componente. Se llama al icono sin el prefijo sn-, por ejemplo 'acalaraciones'.
	 * 
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get infoButton() {
	  return this._infoButton;
	}
	set infoButton(newValue: string) {
	  this._infoButton = newValue;
	}
  
	/**
	 * Cantidad mínima de carácteres que se pueden escribir en el componente.
	 * 
	 * @readonly
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get min() {
	  return this._min;
	}
	set min(newValue: number) {
	  this._min = newValue;
	}
  
	/**
	 * Cantidad máxima de carácteres que se pueden escribir en el componente.
	 * 
	 * @readonly
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get max() {
	  return this._max;
	}
	set max(newValue: number) {
	  this._max = newValue;
	}
  
	/**
	 * Permite modificar la descripción del motivo.
	 * 
	 * @readonly
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get label() {
	  return this._label;
	}
	set label(newValue: string) {
	  this._label = newValue;
	}
  
	/**
	 * Valor del motivo o concepto que recibe en el componente.
	 * 
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get value() {
	  return this._value;
	}
	set value(newValue: string) {
	  this._value = newValue;
	}
  
  
	/**
	 * Cadena con caracteres no permitidos por el componente.
	 * 
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get invalidChars() {
	  return this._invalidChars;
	}
	set invalidChars(newValue: string) {
	  this._invalidChars = newValue;
	}
  
	/**
	 * Habilita o deshabilita el atributo readonly del input del componente.
	 * 
	 * @readonly
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get readOnly() {
	  return this._readOnly;
	}
	set readOnly(value: boolean) {
	  this._readOnly = value;
	}
  
	/**
	 * Habilita o deshabilita el input.
	 * 
	 * @readonly
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get disabled() {
	  return this._disable;
	}
	set disabled(newValue: boolean) {
	  this._disable = newValue;
	}
  
	/**
	 * Permite el uso de un mensaje de error customizable
	 * 
	 * @readonly
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get showError() {
	  return this._showError;
	}
	set showError(newValue: boolean) {
	  this._showError = newValue;
	}
  
	/**
	 * Permite ingresar mensaje de error personalizable
	 * 
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get error() {
	  return this._error;
	}
	set error(newValue: string) {
	  this._error = newValue;
	}
  
  
	/**
	 * Evento que emite el value con el formato moneda correspondiente cuando se hace focusin sobre el input del componente.
	 * 
	 * @memberof MotiveFieldComponent
	 * @type {EventEmitter<string>}
	 */
	@Output() onFocus = new EventEmitter < string > ();
  
  
	/**
	 * Evento que emite el value con el formato moneda correspondiente cuando se hace focusout y blur sobre el input del componente.
	 * 
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() onBlur = new EventEmitter < string > ();
  
  
	/**
	 * Evento que emite el value con el formato moneda correspondiente cuando se hace change sobre el input del componente.
	 * 
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() onChange = new EventEmitter < string > ();
  
  
	/**
	 * Evento que emite el mensaje de error cuando el value es inválido.
	 * 
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() onError = new EventEmitter < string > ();
  
  
	/**
	 * Emite el evento correspondiente cuando se presione el iconButton.
	 *
	 * @type {EventEmitter<Event>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() iconPress = new EventEmitter < Event > ();
  
  
	/**
	 * Emite el evento correspondiente cuando se presione el infoButton.
	 * 
	 * @type {EventEmitter<Event>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() infoPress = new EventEmitter < Event > ();
  
	/**
	 * Evento que emite el valor '' cuando se limpia el input del componente mediante el botón de limpiar.
	 *
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() clearButton = new EventEmitter < string > ();
  
  
	/**
	 * Evento que emite el valor del '' cuando se limpia el input del componente mediante el teclado.
	 * 
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() clearInput = new EventEmitter < string > ();
  
  
	/**
	 * Aplica la clase CSS disabled cuando el componente está deshabilitado.
	 * 
	 * @readonly
	 * @returns {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@HostBinding('class.disabled')
	get isDisabled() {
	  return this._disable ? true : false;
	}
  
  
	/**
	 * Aplica la clase CSS de invalid-motive cuando el motivo no es válido
	 * 
	 * @readonly
	 * @returns {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@HostBinding('class.invalid-motive')
	get isInvalid() {
	  return this.invalidMotive ? true : false;
	}
  
  
	/**
	 * Referencia a tag input dentro del template.
	 * 
	 * @type {ElementRef}
	 * @memberof MotiveFieldComponent
	 */
	@ViewChild('motiveInput') input: ElementRef
  
  
	/**
	 * Método para validar el motivo.
	 * Establece el mensaje de error correspondiente si es necesario.
	 * 
	 * @param {string} value
	 * @memberof MotiveFieldComponent
	 */
	public validate(value: string): void {
	  const charList = this.invalidChars.split('').map((char) => char = '\\' + char);
	  const invalidCharsFormatted = charList.join();
	  const format = new RegExp('[' + invalidCharsFormatted + ']', "i");
	  if (format.test(value)) {
		this.invalidMotive = true;
		this.errorMessage = `La referencia no puede tener carácteres especiales (${this.invalidChars})`;
	  } else if (this.min && value.length < this.min) {
		this.invalidMotive = true;
		this.errorMessage = `El motivo no puede tener menos de ${this.min} carácteres`
	  } else if (this.max && value.length > this.max) {
		this.invalidMotive = true;
		this.errorMessage = `El motivo no puede tener más de ${this.max} carácteres`
	  } else if (this.showError && this.error) {
		this.invalidMotive = true;
		this.errorMessage = this.error;
	  } else {
		this.invalidMotive = false;
		this.errorMessage = '';
	  }
	  if (this.errorMessage) {
		this.onError.emit(this.errorMessage);
	  }
	}
  
  
	/**
	 * Método que emite valor cuando cambia la entrada.
	 * Si está vacío, emite clearInput con ''.
	 * 
	 * @memberof MotiveFieldComponent
	 */
	public changeEvent(): void {
	  this.validate(this.value);
	  if (this.value) {
		this.onChange.emit(this.value);
	  } else {
		this.clearInput.emit('');
	  }
	}
  
	/**
	 * Método que emite valor cuando es onFocus.
	 * 
	 * @memberof MotiveFieldComponent
	 */
	public focusEvent(): void {
	  this.validate(this.value);
	  if (this.value) {
		this.onFocus.emit(this.value);
	  } else {
		this.onFocus.emit('');
	  }
	}
  
	/**
	 * Método que emite valor cuando es onBlur.
	 * 
	 * @memberof MotiveFieldComponent
	 */
	public blurEvent(): void {
	  this.validate(this.value);
	  if (this.value) {
		this.onBlur.emit(this.value);
	  } else {
		this.onBlur.emit('');
	  }
	}
  
	/**
	 * Método que habilita el botón de borrar cuando existe un valor de cantidad.
	 * 
	 * @param {string} value
	 * @returns {boolean}
	 * @memberof MotiveFieldComponent
	 */
	public enableClear(value: string): boolean {
	  if (this.disabled || this.readOnly || !value || value.length === 0) {
		return false;
	  } else {
		return true;
	  }
	}
  
	/**
	 * Método que restablece el valor de entrada y se emite un evento.
	 * 
	 * @memberof MotiveFieldComponent
	 */
	public clear(): void {
	  this.value = '';
	  this.invalidMotive = false;
	  this.clearButton.emit(this.value);
	}
  
	/**
	 * Método que establece o desactiva la entrada del readonly.
	 * 
	 * @memberof MotiveFieldComponent
	 */
	public readonlyState(): void {
	  if (this.readOnly) {
		this.renderer.setAttribute(this.input.nativeElement, 'readonly', 'true');
		this.renderer.setAttribute(this.input.nativeElement, 'tabindex', '-1');
	  }
	}
  
	/**
	 * Emite un evento al dar clic en el icono.
	 *
	 * @param {Event} ev
	 * @memberof MotiveFieldComponent
	 */
	public iconClick(ev: Event): void {
	  this.iconPress.emit(ev);
	}
  
	/**
	 * Emite un evento en el infoPress.
	 * @param {Event} ev
	 * @memberof MotiveFieldComponent
	 */
	public infoClick(ev: Event): void {
	  this.infoPress.emit(ev);
	}
  
  
	/**
	 * Inicializa componente
	 * @memberof MotiveFieldComponent
	 */
	ngOnInit() {
	  this.readonlyState();
	  this.validate(this.value);
	}
  }
  