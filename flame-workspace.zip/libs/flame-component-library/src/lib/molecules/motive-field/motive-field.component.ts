import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	HostBinding,
	ViewChild,
	Renderer2,
	ElementRef,
	ViewEncapsulation
} from '@angular/core';
import { stringify } from '@angular/core/src/render3/util';

/**
 * Component motive-field, that allows to capture motive or concept
 * @example
 * <sn-motive-field></sn-motive-field>
 * <sn-motive-field [disabled]="true"></sn-motive-field>
 * <sn-motive-field value="Traspaso de cuenta"></sn-motive-field>
 * <sn-motive-field label="Label custom"></sn-motive-field>
 * <sn-motive-field value="Transferencia" [max]="10"></sn-motive-field>
 * <sn-motive-field label="Label custom" [min]="20"></sn-motive-field>
 */
@Component({
	selector: 'sn-motive-field',
	templateUrl: './motive-field.component.html',
	styleUrls: ['./motive-field.component.scss'],
	encapsulation: ViewEncapsulation.None
})

/* tslint:disable */
export class MotiveFieldComponent implements OnInit {
	/**
	 * Create an instance of MotiveFieldComponent.
	 * @param {Renderer2} renderer
	 * @memberof MotiveFieldComponent
	 */
	constructor(private renderer: Renderer2) {}

	/**
	 * @ignore
	 * Indica el valor que se muestra cuando el input está vacío.
	 *
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _placeholder = 'Transferencia';

	/**
	 * @ignore
	 * Indica el nombre del icono que se muestra a la derecha del input.
	 *
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _iconButton: string;

	/**
	 * @ignore
	 * Indica el tipo de icono (sn-icon) que se puede mostrar junto con el label del componente. Se llama al icono sin el prefijo sn-, por ejemplo 'aclaraciones'.
	 *
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _infoButton: string;

	/**
	 * @ignore
	 * Indica la cantidad mínima de caracteres que se pueden escribir en el motivo.
	 *
	 * @private
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	private _min: number;

	/**
	 * @ignore
	 * Indica la cantidad máxima de caracteres que se pueden escribir en el motivo.
	 *
	 * @private
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	private _max: number;

	/**
	 * @ignore
	 * Indica la descripcion del motivo.
	 *
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _label = 'Motivo o concepto';

	/**
	 * @ignore
	 * Indica el valor del motivo o concepto que recibe en el componente.
	 *
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _value = '';

	/**
	 * @ignore
	 * Indica los caracteres inválidos dentro de input.
	 *
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _invalidChars = '*.-_,%$';

	/**
	 * @ignore
	 * Indica si input será de solo lectura.
	 *
	 * @private
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	private _readOnly = false;

	/**
	 * @ignore
	 * Indica si input está habilitado o no.
	 *
	 * @private
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	private _disable = false;

	/**
	 * @ignore
	 * Permite el uso de un mensaje de error customizable.
	 *
	 * @private
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	private _showError = false;

	/**
	 * @ignore
	 * Indica el error personalizado a mostrar.
	 *
	 * @private
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	private _error = 'Custom error';

	/**
	 * Indica si el input motive es válido o no.
	 *
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	public invalidMotive = false;

	/**
	 * Indica el mensaje de error a mostrar.
	 *
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	public errorMessage = '';

	/**
	 * Indica el valor que se muestra cuando el input está vacío
	 *
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get placeholder() {
		return this._placeholder;
	}
	set placeholder(newValue: string) {
		this._placeholder = newValue;
	}

	/**
	 * Indica el nombre del icono que se muestra a la derecha del input.
	 *
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get iconButton() {
		return this._iconButton;
	}
	set iconButton(newValue: string) {
		this._iconButton = newValue;
	}

	/**
	 * Indica el tipo de icono (sn-icon) que se puede mostrar junto con el label del componente. Se llama al icono sin el prefijo sn-, por ejemplo 'acalaraciones'.
	 *
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get infoButton() {
		return this._infoButton;
	}
	set infoButton(newValue: string) {
		this._infoButton = newValue;
	}

	/**
	 * Cantidad mínima de carácteres que se pueden escribir en el componente.
	 *
	 * @readonly
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get min() {
		return this._min;
	}
	set min(newValue: number) {
		this._min = newValue;
	}

	/**
	 * Cantidad máxima de carácteres que se pueden escribir en el componente.
	 *
	 * @readonly
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get max() {
		return this._max;
	}
	set max(newValue: number) {
		this._max = newValue;
	}

	/**
	 * Permite modificar la descripción del motivo.
	 *
	 * @readonly
	 * @type {number}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get label() {
		return this._label;
	}
	set label(newValue: string) {
		this._label = newValue;
	}

	/**
	 * Valor del motivo o concepto que recibe en el componente.
	 *
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get value() {
		return this._value;
	}
	set value(newValue: string) {
		this._value = newValue;
	}

	/**
	 * Cadena con caracteres no permitidos por el componente.
	 *
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get invalidChars() {
		return this._invalidChars;
	}
	set invalidChars(newValue: string) {
		this._invalidChars = newValue;
	}

	/**
	 * Habilita o deshabilita el atributo readonly del input del componente.
	 *
	 * @readonly
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get readOnly() {
		return this._readOnly;
	}
	set readOnly(value: boolean) {
		this._readOnly = value;
	}

	/**
	 * Habilita o deshabilita el input.
	 *
	 * @readonly
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get disabled() {
		return this._disable;
	}
	set disabled(newValue: boolean) {
		this._disable = newValue;
	}

	/**
	 * Permite el uso de un mensaje de error customizable
	 *
	 * @readonly
	 * @type {boolean}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get showError() {
		return this._showError;
	}
	set showError(newValue: boolean) {
		this._showError = newValue;
	}

	/**
	 * Permite ingresar mensaje de error personalizable
	 *
	 * @readonly
	 * @type {string}
	 * @memberof MotiveFieldComponent
	 */
	@Input()
	get error() {
		return this._error;
	}
	set error(newValue: string) {
		this._error = newValue;
	}

	/**
	 * Evento que emite el value con el formato moneda correspondiente cuando se hace focusin sobre el input del componente.
	 *
	 * @memberof MotiveFieldComponent
	 * @type {EventEmitter<string>}
	 */
	@Output() onFocus = new EventEmitter<string>();

	/**
	 * Evento que emite el value con el formato moneda correspondiente cuando se hace focusout y blur sobre el input del componente.
	 *
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() onBlur = new EventEmitter<string>();

	/**
	 * Evento que emite el value con el formato moneda correspondiente cuando se hace change sobre el input del componente.
	 *
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() onChange = new EventEmitter<string>();

	/**
	 * Evento que emite el mensaje de error cuando el value es inválido.
	 *
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() onError = new EventEmitter<string>();

	/**
	 * Emite el evento correspondiente cuando se presione el iconButton.
	 *
	 * @type {EventEmitter<Event>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() iconPress = new EventEmitter<Event>();

	/**
	 * Emite el evento correspondiente cuando se presione el infoButton.
	 *
	 * @type {EventEmitter<Event>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() infoPress = new EventEmitter<Event>();

	/**
	 * Evento que emite el valor '' cuando se limpia el input del componente mediante el botón de limpiar.
	 *
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() clearButton = new EventEmitter<string>();

	/**
	 * Evento que emite el valor del '' cuando se limpia el input del componente mediante el teclado.
	 *
	 * @type {EventEmitter<string>}
	 * @memberof MotiveFieldComponent
	 */
	@Output() clearInput = new EventEmitter<string>();

	/**
	 * Referencia a tag input dentro del template.
	 *
	 * @type {ElementRef}
	 * @memberof MotiveFieldComponent
	 */
	@ViewChild('motiveInput') input: ElementRef;

	/**
	 * Método para validar el motivo.
	 * Establece el mensaje de error correspondiente si es necesario.
	 *
	 * @param {string} value
	 * @memberof MotiveFieldComponent
	 */
	public validate(value: string): void {
		const charList = this.invalidChars
			.split('')
			.map(char => (char = '\\' + char));
		const invalidCharsFormatted = charList.join();
		const format = new RegExp('[' + invalidCharsFormatted + ']', 'i');
		if (format.test(value)) {
			this.invalidMotive = true;
			this.errorMessage = `La referencia no puede tener carácteres especiales (${
				this.invalidChars
			})`;
		} else if (this.min && value.length < this.min) {
			this.invalidMotive = true;
			this.errorMessage = `El motivo no puede tener menos de ${
				this.min
			} carácteres`;
		} else if (this.max && value.length > this.max) {
			this.invalidMotive = true;
			this.errorMessage = `El motivo no puede tener más de ${
				this.max
			} carácteres`;
		} else if (this.showError && this.error) {
			this.invalidMotive = true;
			this.errorMessage = this.error;
		} else {
			this.invalidMotive = false;
			this.errorMessage = '';
		}
		if (this.errorMessage) {
			this.onError.emit(this.errorMessage);
		}
	}

	/**
	 * Método que emite valor cuando cambia la entrada.
	 * Si está vacío, emite clearInput con ''.
	 *
	 * @memberof MotiveFieldComponent
	 */
	public changeEvent(): void {
		this.value = this.removeAccents(this.value);
		this.validate(this.value);
		if (this.value) {
			this.onChange.emit(this.value);
		} else {
			this.clearInput.emit('');
		}
	}

	/**
	 * Método que emite valor cuando es onFocus.
	 *
	 * @memberof MotiveFieldComponent
	 */
	public focusEvent(): void {
		this.validate(this.value);
		if (this.value) {
			this.onFocus.emit(this.value);
		} else {
			this.onFocus.emit('');
		}
	}

	/**
	 * Método que emite valor cuando es onBlur.
	 *
	 * @memberof MotiveFieldComponent
	 */
	public blurEvent(): void {
		this.value = this.removeAccents(this.value);
		this.validate(this.value);
		if (this.value) {
			this.onBlur.emit(this.value);
		} else {
			this.onBlur.emit('');
		}
	}

	/**
	 * Método que habilita el botón de borrar cuando existe un valor de cantidad.
	 *
	 * @param {string} value
	 * @returns {boolean}
	 * @memberof MotiveFieldComponent
	 */
	public enableClear(value: string): boolean {
		if (this.disabled || this.readOnly || !value || value.length === 0) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * Método que restablece el valor de entrada y se emite un evento.
	 *
	 * @memberof MotiveFieldComponent
	 */
	public clear(): void {
		this.value = '';
		this.invalidMotive = false;
		this.clearButton.emit(this.value);
	}

	/**
	 * Método que establece o desactiva la entrada del readonly.
	 *
	 * @memberof MotiveFieldComponent
	 */
	public readonlyState(): void {
		if (this.readOnly) {
			this.renderer.setAttribute(this.input.nativeElement, 'readonly', 'true');
			this.renderer.setAttribute(this.input.nativeElement, 'tabindex', '-1');
		}
	}

	/**
	 * Emite un evento al dar clic en el icono.
	 *
	 * @param {Event} ev
	 * @memberof MotiveFieldComponent
	 */
	public iconClick(ev: Event): void {
		this.iconPress.emit(ev);
	}

	/**
	 * Emite un evento en el infoPress.
	 * @param {Event} ev
	 * @memberof MotiveFieldComponent
	 */
	public infoClick(ev: Event): void {
		this.infoPress.emit(ev);
	}

	/**
	 *
	 * Método que elimina los acentos de un string
	 * @private
	 * @param {string} value
	 * @returns {string}
	 * @memberof MotiveFieldComponent
	 */
	private removeAccents(value: string): string {
		const characterMap = {
			À: 'A',
			Á: 'A',
			Â: 'A',
			Ã: 'A',
			Ä: 'A',
			Å: 'A',
			Ấ: 'A',
			Ắ: 'A',
			Ẳ: 'A',
			Ẵ: 'A',
			Ặ: 'A',
			Ầ: 'A',
			Ằ: 'A',
			Ȃ: 'A',
			Ḉ: 'Ç',
			È: 'E',
			É: 'E',
			Ê: 'E',
			Ë: 'E',
			Ế: 'E',
			Ḗ: 'E',
			Ề: 'E',
			Ḕ: 'E',
			Ḝ: 'E',
			Ȇ: 'E',
			Ì: 'I',
			Í: 'I',
			Î: 'I',
			Ï: 'I',
			Ḯ: 'I',
			Ȋ: 'I',
			Ò: 'O',
			Ó: 'O',
			Ô: 'O',
			Õ: 'O',
			Ö: 'O',
			Ø: 'O',
			Ố: 'O',
			Ṍ: 'O',
			Ṓ: 'O',
			Ȏ: 'O',
			Ù: 'U',
			Ú: 'U',
			Û: 'U',
			Ü: 'U',
			Ý: 'Y',
			à: 'a',
			á: 'a',
			â: 'a',
			ã: 'a',
			ä: 'a',
			å: 'a',
			ấ: 'a',
			ắ: 'a',
			ẳ: 'a',
			ẵ: 'a',
			ặ: 'a',
			ầ: 'a',
			ằ: 'a',
			ȃ: 'a',
			ḉ: 'c',
			è: 'e',
			é: 'e',
			ê: 'e',
			ë: 'e',
			ế: 'e',
			ḗ: 'e',
			ề: 'e',
			ḕ: 'e',
			ḝ: 'e',
			ȇ: 'e',
			ì: 'i',
			í: 'i',
			î: 'i',
			ï: 'i',
			ḯ: 'i',
			ȋ: 'i',
			ð: 'd',
			ò: 'o',
			ó: 'o',
			ô: 'o',
			õ: 'o',
			ö: 'o',
			ø: 'o',
			ố: 'o',
			ṍ: 'o',
			ṓ: 'o',
			ȏ: 'o',
			ù: 'u',
			ú: 'u',
			û: 'u',
			ü: 'u',
			ý: 'y',
			ÿ: 'y',
			Ā: 'A',
			ā: 'a',
			Ă: 'A',
			ă: 'a',
			Ą: 'A',
			ą: 'a',
			Ć: 'C',
			ć: 'c',
			Ĉ: 'C',
			ĉ: 'c',
			Ċ: 'C',
			ċ: 'c',
			Č: 'C',
			č: 'c',
			C̆: 'C',
			c̆: 'c',
			Ď: 'D',
			ď: 'd',
			Đ: 'D',
			đ: 'd',
			Ē: 'E',
			ē: 'e',
			Ĕ: 'E',
			ĕ: 'e',
			Ė: 'E',
			ė: 'e',
			Ę: 'E',
			ę: 'e',
			Ě: 'E',
			ě: 'e',
			Ĝ: 'G',
			Ǵ: 'G',
			ĝ: 'g',
			ǵ: 'g',
			Ğ: 'G',
			ğ: 'g',
			Ġ: 'G',
			ġ: 'g',
			Ģ: 'G',
			ģ: 'g',
			Ĥ: 'H',
			ĥ: 'h',
			Ħ: 'H',
			ħ: 'h',
			Ḫ: 'H',
			ḫ: 'h',
			Ĩ: 'I',
			ĩ: 'i',
			Ī: 'I',
			ī: 'i',
			Ĭ: 'I',
			ĭ: 'i',
			Į: 'I',
			į: 'i',
			İ: 'I',
			ı: 'i',
			Ĵ: 'J',
			ĵ: 'j',
			Ķ: 'K',
			ķ: 'k',
			Ḱ: 'K',
			ḱ: 'k',
			K̆: 'K',
			k̆: 'k',
			Ĺ: 'L',
			ĺ: 'l',
			Ļ: 'L',
			ļ: 'l',
			Ľ: 'L',
			ľ: 'l',
			Ḿ: 'M',
			ḿ: 'm',
			M̆: 'M',
			m̆: 'm',
			Ń: 'N',
			ń: 'n',
			Ņ: 'N',
			ņ: 'n',
			Ň: 'N',
			ň: 'n',
			ŉ: 'n',
			N̆: 'N',
			n̆: 'n',
			Ō: 'O',
			ō: 'o',
			Ŏ: 'O',
			ŏ: 'o',
			Ő: 'O',
			ő: 'o',
			P̆: 'P',
			p̆: 'p',
			Ŕ: 'R',
			ŕ: 'r',
			Ŗ: 'R',
			ŗ: 'r',
			Ř: 'R',
			ř: 'r',
			R̆: 'R',
			r̆: 'r',
			Ȓ: 'R',
			ȓ: 'r',
			Ś: 'S',
			ś: 's',
			Ŝ: 'S',
			ŝ: 's',
			Ş: 'S',
			Ș: 'S',
			ș: 's',
			ş: 's',
			Š: 'S',
			š: 's',
			Ţ: 'T',
			ţ: 't',
			ț: 't',
			Ț: 'T',
			Ť: 'T',
			ť: 't',
			Ŧ: 'T',
			ŧ: 't',
			T̆: 'T',
			t̆: 't',
			Ũ: 'U',
			ũ: 'u',
			Ū: 'U',
			ū: 'u',
			Ŭ: 'U',
			ŭ: 'u',
			Ů: 'U',
			ů: 'u',
			Ű: 'U',
			ű: 'u',
			Ų: 'U',
			ų: 'u',
			Ȗ: 'U',
			ȗ: 'u',
			V̆: 'V',
			v̆: 'v',
			Ŵ: 'W',
			ŵ: 'w',
			Ẃ: 'W',
			ẃ: 'w',
			X̆: 'X',
			x̆: 'x',
			Ŷ: 'Y',
			ŷ: 'y',
			Ÿ: 'Y',
			Y̆: 'Y',
			y̆: 'y',
			Ź: 'Z',
			ź: 'z',
			Ż: 'Z',
			ż: 'z',
			Ž: 'Z',
			ž: 'z',
			ſ: 's',
			ƒ: 'f',
			Ơ: 'O',
			ơ: 'o',
			Ư: 'U',
			ư: 'u',
			Ǎ: 'A',
			ǎ: 'a',
			Ǐ: 'I',
			ǐ: 'i',
			Ǒ: 'O',
			ǒ: 'o',
			Ǔ: 'U',
			ǔ: 'u',
			Ǖ: 'U',
			ǖ: 'u',
			Ǘ: 'U',
			ǘ: 'u',
			Ǚ: 'U',
			ǚ: 'u',
			Ǜ: 'U',
			ǜ: 'u',
			Ứ: 'U',
			ứ: 'u',
			Ṹ: 'U',
			ṹ: 'u',
			Ǻ: 'A',
			ǻ: 'a',
			Ǽ: 'AE',
			ǽ: 'ae',
			Ǿ: 'O',
			ǿ: 'o',
			Þ: 'TH',
			þ: 'th',
			Ṕ: 'P',
			ṕ: 'p',
			Ṥ: 'S',
			ṥ: 's',
			X́: 'X',
			x́: 'x',
			Ѓ: 'Г',
			ѓ: 'г',
			Ќ: 'К',
			ќ: 'к',
			A̋: 'A',
			a̋: 'a',
			E̋: 'E',
			e̋: 'e',
			I̋: 'I',
			i̋: 'i',
			Ǹ: 'N',
			ǹ: 'n',
			Ồ: 'O',
			ồ: 'o',
			Ṑ: 'O',
			ṑ: 'o',
			Ừ: 'U',
			ừ: 'u',
			Ẁ: 'W',
			ẁ: 'w',
			Ỳ: 'Y',
			ỳ: 'y',
			Ȁ: 'A',
			ȁ: 'a',
			Ȅ: 'E',
			ȅ: 'e',
			Ȉ: 'I',
			ȉ: 'i',
			Ȍ: 'O',
			ȍ: 'o',
			Ȑ: 'R',
			ȑ: 'r',
			Ȕ: 'U',
			ȕ: 'u',
			B̌: 'B',
			b̌: 'b',
			Č̣: 'C',
			č̣: 'c',
			Ê̌: 'E',
			ê̌: 'e',
			F̌: 'F',
			f̌: 'f',
			Ǧ: 'G',
			ǧ: 'g',
			Ȟ: 'H',
			ȟ: 'h',
			J̌: 'J',
			ǰ: 'j',
			Ǩ: 'K',
			ǩ: 'k',
			M̌: 'M',
			m̌: 'm',
			P̌: 'P',
			p̌: 'p',
			Q̌: 'Q',
			q̌: 'q',
			Ř̩: 'R',
			ř̩: 'r',
			Ṧ: 'S',
			ṧ: 's',
			V̌: 'V',
			v̌: 'v',
			W̌: 'W',
			w̌: 'w',
			X̌: 'X',
			x̌: 'x',
			Y̌: 'Y',
			y̌: 'y',
			A̧: 'A',
			a̧: 'a',
			B̧: 'B',
			b̧: 'b',
			Ḑ: 'D',
			ḑ: 'd',
			Ȩ: 'E',
			ȩ: 'e',
			Ɛ̧: 'E',
			ɛ̧: 'e',
			Ḩ: 'H',
			ḩ: 'h',
			I̧: 'I',
			i̧: 'i',
			Ɨ̧: 'I',
			ɨ̧: 'i',
			M̧: 'M',
			m̧: 'm',
			O̧: 'O',
			o̧: 'o',
			Q̧: 'Q',
			q̧: 'q',
			U̧: 'U',
			u̧: 'u',
			X̧: 'X',
			x̧: 'x',
			Z̧: 'Z',
			z̧: 'z'
		};

		const chars = Object.keys(characterMap).join('|');
		const allAccents = new RegExp(chars, 'g');
		const firstAccent = new RegExp(chars, '');

		if (value.match(firstAccent)) {
			return value.replace(
				allAccents,
				characterMap[value.match(firstAccent)[0]]
			);
		} else {
			return value;
		}
	}

	/**
	 * Inicializa componente
	 * @memberof MotiveFieldComponent
	 */
	ngOnInit() {
		this.readonlyState();
		this.validate(this.value);
	}
}
