import { Component, OnInit } from '@angular/core';
import { CustomDialogComponent } from '../../../atoms/dialog/dialog-custom';

import { SelectService } from '../select-service/select.service';

@Component({
	selector: 'sn-select-scroll',
	templateUrl: './select-scroll.component.html',
	styleUrls: ['./select-scroll.component.scss']
})
export class SelectScrollComponent implements OnInit, CustomDialogComponent {
	data: any;
	public selectedOption: any;
	selected: number;

	constructor(private selService: SelectService) {}

	ngOnInit() {}

	onSelectOption(optionSelected: any, index: number) {
		this.selected = index;
		this.selService.selectElement(optionSelected);
	}
}
