import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	OnDestroy,
	forwardRef
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subscription } from 'rxjs';
import {
	DialogService,
	DialogReference,
	CustomDialog
} from '../../atoms/dialog/index';
import { SelectScrollComponent } from './select-scroll/select-scroll.component';
import { SelectService } from './select-service/select.service';

export class SnDialogSelectChange {
	source: DialogSelectComponent;
	selected: any;
}

/**
 * Dialogo personalizado con título, botón principal y botón de cerrar.
 * 
 * @export
 * @class DialogSelectComponent
 * @implements {OnInit}
 * @implements {OnDestroy}
 * @implements {ControlValueAccessor}
 */
@Component({
	selector: 'sn-dialog-select',
	templateUrl: './dialog-select.component.html',
	styleUrls: ['./dialog-select.component.scss'],
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => DialogSelectComponent),
			multi: true
		}
	]
})
export class DialogSelectComponent
	implements OnInit, OnDestroy, ControlValueAccessor {
	/**
	 *Creates an instance of DialogSelectComponent.
	 * @param {DialogService} dialog
	 * @param {SelectService} selService
	 * @memberof DialogSelectComponent
	 */
	constructor(
		private dialog: DialogService,
		private selService: SelectService
	) { }

	/**
	 * @ignore
	 * Indica la opción seleccionada.
	 * 
	 * @private
	 * @type {string}
	 * @memberof DialogSelectComponent
	 */
	private _selectedOption = '';

	/**
	 * @ignore
	 * Indica la opción seleccionada antes de cerrar dialogo.
	 * 
	 * @private
	 * @type {*}
	 * @memberof DialogSelectComponent
	 */
	private _selectedOptionBefClosed;

	/**
	 * @ignore
	 * Indica la suscripción a SelectedService.
	 *
	 * @private
	 * @type {Subscription}
	 * @memberof DialogSelectComponent
	 */
	private subscription: Subscription;

	/**
	 * @ignore
	 * Indica la referencia al dialogo.
	 *
	 * @private
	 * @type {DialogReference}
	 * @memberof DialogSelectComponent
	 */
	private dialogRef: DialogReference;

	/**
	 * @ignore
	 * Indica si el dialogo está abierto o no.
	 * 
	 * @private
	 * @type {boolean}
	 * @memberof DialogSelectComponent
	 */
	public isDialogOpen: boolean;

	/**
	 * @ignore
	 * Indica propiedad <strong>disabled</strong> de input que abre el dialogo.
	 *
	 * @private
	 * @type {boolean}
	 * @memberof DialogSelectComponent
	 */
	private _disabled = false;
	
	/**
	 * Indica el título del dialogo.
	 *
	 * @type {string}
	 * @memberof DialogSelectComponent
	 */
	@Input() title: string;
	
	/**
	 * Indica el subtítulo del componente.
	 *
	 * @type {string}
	 * @memberof DialogSelectComponent
	 */
	@Input() subtitle: string; // TODO: especificar el tipo
	
	/**
	 * Indica las opciones de personalización de dialogo.
	 *
	 * @type {any[]}
	 * @memberof DialogSelectComponent
	 */
	@Input() options: any[]; // TODO: especificar el tipo
	
	/**
	 * Indica el valor del input que abre el dialogo.
	 *
	 * @type {*}
	 * @memberof DialogSelectComponent
	 */
	@Input() value: any; // TODO: especificar el tipo
	
	/**
	 * Indica el tipo del componente, las opciones son "arrow" e "input".
	 *
	 * @memberof DialogSelectComponent
	 */
	@Input() mode = 'input';
	
	/**
	 * Indica la leyenda mostrada sobre el botón cerrar dialogo.
	 *
	 * @type {*}
	 * @memberof DialogSelectComponent
	 */
	@Input() closeLabel: any;

	/**
	 * Indica si el encabezado del componente está activo o no.
	 *
	 * @type {*}
	 * @memberof DialogSelectComponent
	 */
	@Input() enableHr: any;

	/**
	 * Indica la propiedad placeholder del input que abre el dialogo.
	 *
	 * @type {string}
	 * @memberof DialogSelectComponent
	 */
	@Input() placeholder: string;
	
	/**
	 * Indica si el botón por default se muestra o no en el dialogo.
	 *
	 * @type {boolean}
	 * @memberof DialogSelectComponent
	 */
	@Input() disabledButton: boolean;

	/**
	 * Indica propiedad <strong>disabled</strong> de input que abre el dialogo.
	 *
	 * @readonly
	 * @type {*}
	 * @memberof DialogSelectComponent
	 */
	@Input()
	get disabled() {
		return this._disabled;
	}
	set disabled(value: any) {
		this._disabled = value;
	}

	/**
	 * Indica la opción seleccionada.
	 *
	 * @type {string}
	 * @memberof DialogSelectComponent
	 */
	get selectedOption() {
		if (this._selectedOption !== '') {
			return this._selectedOption;
		} else {
			return '';
		}
	}
	set selectedOption(value: string) {
		this._selectedOption = value;
	}

	/**
	 * Evento se emite cuando el usuario a 
	 * seleccionado alguna opción.
	 *
	 * @type {EventEmitter}
	 * @memberof DialogSelectComponent
	 */
	@Output() onSelection = new EventEmitter();

	/**
	 * Función vacía temporalmente con la capacidad de ser redefinida posteriormente.
	 *
	 * @memberof DialogSelectComponent
	 */
	_onChange: (value: any) => void = () => { };

	/**
	 * Selecciona la opción en el diálogo según sobre la que 
	 * el usuario haya dado click.
	 *
	 * @returns {void}
	 * @memberof DialogSelectComponent
	 */
	clickOnSelect() {
		if (this.disabled) {
			return;
		}
		this.dialogRef = this.dialog.open(
			{
				closeLabel: this.closeLabel,
				title: this.title,
				enableHr: this.enableHr,
				disabledButton: this.disabledButton
			},
			new CustomDialog(SelectScrollComponent, {
				options: this.options,
				subtitle: this.subtitle
			})
		);
		this.isDialogOpen = true;
		this.dialogRef.changeStatusButton(this.disabledButton);
		this.dialogRef.beforeClose().subscribe((cancel?: boolean) => {
			this.isDialogOpen = false;
			if (!cancel && this._selectedOptionBefClosed !== null) {
				this._selectedOption = this._selectedOptionBefClosed.text.name;
				this.onSelection.emit(this._selectedOptionBefClosed);
				this._onChange(this._selectedOptionBefClosed);
			}
			this._selectedOptionBefClosed = null;
		});
	}

	/**
	 * Establece el valor de selección. 
	 * Parte de la interfaz ControlValueAccessor 
	 * requerida para integrarse con la API de 
	 * formularios principales de Angular.
	 *
	 * @param {*} value Nuevo valor que se escribira en el modelo.
	 * @memberof DialogSelectComponent
	 */
	writeValue(value: any): void {
		if (value === null) {
			this._selectedOption = '';
		} else {
      this._selectedOption = value.name === undefined ?
      value : value.name;
		}
	}

	/**
	 * Guarda una función de devolución de llamada 
	 * que se invoca cuando el valor de la selección 
	 * cambia. Parte de la interfaz ControlValueAccessor 
	 * requerida para integrarse con la API de 
	 * formularios principales de Angular.
	 *
	 * @param {(value: any) => void} fn Devolución de llamada que se activará cuando el valor cambia.
	 * @memberof DialogSelectComponent
	 */
	registerOnChange(fn: (value: any) => void): void {
		this._onChange = fn;
	}

	/**
	 * Guarda una función de devolución de llamada 
	 * que se invocará cuando el usuario borre la 
	 * selección. Parte de la interfaz 
	 * ControlValueAccessor requerida para integrarse 
	 * con la API de formularios principales de Angular.
	 *
	 * @param {() => {}} fn La devolución de llamada se activa cuando se toca el componente.
	 * @memberof DialogSelectComponent
	 */
	registerOnTouched(fn: () => {}): void { }

	/**
	 * Desactiva la selección. Parte de la interfaz 
	 * ControlValueAccessor, es requerida para integrarse 
	 * con la API de formularios principales de Angular.
	 *
	 * @param {boolean} isDisabled Establece si el componente está deshabilitado.
	 * @memberof DialogSelectComponent
	 */
	setDisabledState(isDisabled: boolean): void {
		this.disabled = isDisabled;
	}

	/**
	 * @ignore
	 * Suscribe al servicio <strong>SelectedService</strong>
	 *
	 * @memberof DialogSelectComponent
	 */
	ngOnInit() {
		this.subscription = this.selService.selectedElement().subscribe(element => {
			this.dialogRef.changeStatusButton(false);
			this._selectedOptionBefClosed = element;
		});
	}

	/**
	 * @ignore
	 * Elimina suscripciones al servicio <strong>SelectedService</strong>
	 *
	 * @memberof DialogSelectComponent
	 */
	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
}
