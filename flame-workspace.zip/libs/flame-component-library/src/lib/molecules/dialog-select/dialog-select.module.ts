import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DialogSelectComponent } from './dialog-select.component';
import { SelectScrollComponent } from './select-scroll/select-scroll.component';
import { DialogModule } from '../../atoms/dialog/dialog.module';
import { InputModule } from '../../atoms/input/input.module';
import { FormFieldModule } from '../../atoms/form-field/form-field.module';
import { IconModule } from '../../atoms/icon';
import { RadioButtonModule } from '../../atoms/radio-button';

@NgModule({
	declarations: [DialogSelectComponent, SelectScrollComponent],
	imports: [CommonModule, DialogModule, InputModule, FormFieldModule, IconModule, RadioButtonModule],
	entryComponents: [SelectScrollComponent],
	exports: [DialogSelectComponent]
})
export class DialogSelectModule {}
