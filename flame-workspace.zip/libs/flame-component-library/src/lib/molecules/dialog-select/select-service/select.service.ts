import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
@Injectable({ providedIn: 'root' })
export class SelectService {
	private element = new Subject<any>();

	selectElement(element: string) {
		this.element.next({ text: element });
	}
	selectedElement(): Observable<any> {
		return this.element.asObservable();
	}
}
