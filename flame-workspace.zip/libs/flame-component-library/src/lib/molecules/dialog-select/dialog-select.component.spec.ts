import { IconModule } from './../../atoms/icon/icon.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogSelectComponent } from './dialog-select.component';
import { InputModule } from '../../atoms/input';
import { FormFieldModule } from '../../atoms/form-field';
import { DialogModule } from '../../atoms/dialog';

describe('DialogSelectComponent', () => {
	let component: DialogSelectComponent;
	let fixture: ComponentFixture<DialogSelectComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [DialogSelectComponent],
			imports: [ DialogModule, InputModule, FormFieldModule, IconModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogSelectComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
