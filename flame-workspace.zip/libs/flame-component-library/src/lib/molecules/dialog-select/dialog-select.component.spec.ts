import { IconModule } from './../../atoms/icon/icon.module';
import { DialogModule } from '@santander/flame-component-library';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogSelectComponent } from './dialog-select.component';
import { InputModule } from '../../atoms/input';
import { FormFieldModule } from '../../atoms/form-field';

describe('DialogSelectComponent', () => {
	let component: DialogSelectComponent;
	let fixture: ComponentFixture<DialogSelectComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [DialogSelectComponent],
			imports: [ DialogModule, InputModule, FormFieldModule, IconModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(DialogSelectComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
