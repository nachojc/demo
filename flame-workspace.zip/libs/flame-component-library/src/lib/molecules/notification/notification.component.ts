import { Component, EventEmitter, Input } from '@angular/core';
import { trigger, state, style, transition, animate } from '@angular/animations';
import { NotificationReference } from './notification.reference';

const ANIMATION_TIMINGS = '400ms cubic-bezier(0.25, 0.8, 0.25, 1)';
@Component({
  selector: 'sn-notification',
  templateUrl: './notification.component.html',
  styleUrls: ['./notification.component.scss'],
  animations: [
    trigger('slideContent', [
      state('void', style({
        transform: 'translate3d(0, 50%, 0)',
        opacity: 0
      })),
      state('enter', style({
        transform: 'none',
        opacity: 1
      })),
      state('leave', style({
        opacity: 0
      })),
      transition('* => *', animate(ANIMATION_TIMINGS))
    ])
  ]
})
export class NotificationComponent {

  /**
   * Create an instance of NotificationComponent.
   * @param {NotificationReference} notificationRef
   * @memberof NotificationComponent
   */
  constructor(private notificationRef: NotificationReference) {}

  /**
   * @ignore
   * Indica el texto de notificación.
   * 
   * @private
   * @type {string}
   * @memberof NotificationComponent
   */
  private _legend: string;

  /**
   * @ignore
   * Indica el nombre del icono mostrado.
   * 
   * @private
   * @type {string}
   * @memberof NotificationComponent
   */
  private _icon: string;

  /**
   * @ignore
   * Propiedad del componente que selecciona el emoji.
   * 
   * @private
   * @type {string}
   * @memberof NotificationComponent
   */
  private _type: string;

  /**
   * @ignore
   * Propiedad del componente que se encarga del tamaño del emoji.
   * 
   * @private
   * @type {string}
   * @memberof NotificationComponent
   */
  private _size: string;

  /**
   * @ignore
   * Selecciona el tipo de presentación del emoji regular o circle.
   * 
   * @private
   * @type {string}
   * @memberof NotificationComponent
   */
  private _variant: string;

  /**
   * Indica el estado de la animación.
   * 
   * @type {('void' | 'enter' | 'leave')}
   * @memberof NotificationComponent
   */
  animationState: 'void' | 'enter' | 'leave' = 'enter';

  /**
   * Evento que devuelve la animación cuando su estado cambió.
   * 
   * @type {EventEmitter<AnimationEvent>}
   * @memberof NotificationComponent
   */
  animationStateChanged = new EventEmitter < AnimationEvent > ();

  /**
   * Indica el texto de notificación.
   * 
   * @type {string}
   * @memberof NotificationComponent
   */
  @Input() legend: string = this._legend;

  /**
   * Indica el nombre del icono mostrado.
   * 
   * @type {string}
   * @memberof NotificationComponent
   */
  @Input() icon: string = this._icon;

  /**
   * Propiedad del componente que selecciona el emoji.
   * 
   * @type {string}
   * @memberof NotificationComponent
   */
  @Input() type: string = this._type;

  /**
   * Propiedad del componente que se encarga del tamaño del emoji.
   * 
   * @type {string}
   * @memberof NotificationComponent
   */
  @Input() size: string = this._size;

  /**
   * Selecciona el tipo de presentación del emoji regular o circle
   * 
   * @type {string}
   * @memberof NotificationComponent
   */
  @Input() variant: string = this._variant;

  /**
   * Funcion encargada de cerrar la notificación
   * 
   * @memberof NotificationComponent
   */
  close() {
    this.notificationRef.close();
  }

  /**
   * Función que controla la animación al cerrar la notificación.
   * 
   * @memberof NotificationComponent
   */
  startExitAnimation() {
    this.animationState = 'leave';
  }

  /**
   * Emite el evento cuando el estado de la animación comenzó.
   * 
   * @param {AnimationEvent} event
   * @memberof NotificationComponent
   */
  onAnimationStart(event: AnimationEvent) {
    this.animationStateChanged.emit(event);
  }

  /**
   * Emite el evento cuando el estado de la animación terminó.
   * 
   * @param {AnimationEvent} event
   * @memberof NotificationComponent
   */
  onAnimationDone(event: AnimationEvent) {
    this.animationStateChanged.emit(event);
  }
}
