import { Component, OnInit, EventEmitter, Input } from '@angular/core';
import {
	trigger,
	state,
	style,
	transition,
	animate
} from '@angular/animations';
import { NotificationReference } from './notification.reference';

const ANIMATION_TIMINGS = '400ms cubic-bezier(0.25, 0.8, 0.25, 1)';

@Component({
	selector: 'sn-notification',
	templateUrl: './notification.component.html',
	styleUrls: ['./notification.component.scss'],
	animations: [
		trigger('slideContent', [
			state('void', style({ transform: 'translate3d(0, 50%, 0)', opacity: 0 })),
			state('enter', style({ transform: 'none', opacity: 1 })),
			state('leave', style({ opacity: 0 })),
			transition('* => *', animate(ANIMATION_TIMINGS))
		])
	]
})
export class NotificationComponent implements OnInit {
	private _legend: string;
	private _icon: string;
	private _type: string;
	private _size: string;
	private _variant: string;

	animationState: 'void' | 'enter' | 'leave' = 'enter';
	animationStateChanged = new EventEmitter<AnimationEvent>();

	@Input() legend: string = this._legend;
	@Input() icon: string = this._icon;
	@Input() type: string = this._type;
	@Input() size: string = this._size;
	@Input() variant: string = this._variant;

	constructor(private notificationRef: NotificationReference) {}

	ngOnInit() {
		// this.createBodyOverlay();
	}

	// private createBodyOverlay(): ComponentRef<CustomDialog> {
	//   if (this.bodyContent instanceof CustomDialog) {
	//     const componentFactory = this.componentFactoryResolver.resolveComponentFactory(
	//       this.bodyContent.component
	//     );

	//     const viewContainerRef = this.snHost.viewContainerRef;
	//     viewContainerRef.clear();

	//     const componentRef: ComponentRef<CustomDialog> = viewContainerRef.createComponent(componentFactory);
	//     (<CustomDialogComponent>(componentRef.instance)).data = this.bodyContent.data;
	//     return componentRef;
	//   } else {
	//     this.overlayBody.nativeElement.innerHTML = this.bodyContent;
	//   }
	// }

	close() {
		this.notificationRef.close();
	}

	onAnimationStart(event: AnimationEvent) {
		this.animationStateChanged.emit(event);
	}

	onAnimationDone(event: AnimationEvent) {
		this.animationStateChanged.emit(event);
	}

	startExitAnimation() {
		this.animationState = 'leave';
	}
}
