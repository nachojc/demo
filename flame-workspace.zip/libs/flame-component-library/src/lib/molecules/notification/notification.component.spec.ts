import { NotificationService } from './notification.service';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotificationComponent } from './notification.component';
import { IconModule } from '../../atoms/icon/icon.module';
import { EmojiModule } from '../../atoms/emoji/emoji.module';
import { NotificationReference } from './notification.reference';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('NotificationComponent', () => {
	let component: NotificationComponent;
	let fixture: ComponentFixture<NotificationComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
      declarations: [NotificationComponent],
      imports: [IconModule, EmojiModule, BrowserAnimationsModule],
	    providers: [NotificationService, {provide: NotificationReference, useValue: {}}],
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(NotificationComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
