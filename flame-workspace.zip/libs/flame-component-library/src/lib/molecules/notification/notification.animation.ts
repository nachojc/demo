import {
	trigger,
	state,
	style,
	transition,
	animate
} from '@angular/animations';

export const NotificationAnimation = {
	slideTrigger: trigger('slideContent', [
		state(
			'void',
			style({
				transform: 'translate3d(0, 50%, 0)',
				opacity: 0
			})
		),
		state(
			'enter',
			style({
				transform: 'none',
				opacity: 1
			})
		),
		state(
			'leave',
			style({
				opacity: 0
			})
		),
		transition('* => *', animate('400ms cubic-bezier(0.25, 0.8, 0.25, 1)'))
	])
};
