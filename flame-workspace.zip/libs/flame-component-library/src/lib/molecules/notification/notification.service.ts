import { Injectable, Injector, ComponentRef } from '@angular/core';
import { OverlayRef } from '@angular/cdk/overlay';
import { ComponentPortal, PortalInjector } from '@angular/cdk/portal';

import { OverlayService } from '../../services/overlay/overlay.service';
import { NotificationReference } from './notification.reference';
import { NotificationComponent } from './notification.component';

export interface NotificationConfig {
	legend: string;
	icon?: string;
	hasBackdrop?: boolean;
	backdropClass?: string;
	panelClass?: string;
	type?: string,
	size?: string,
	variant?: string
}

const DEFAULT_CONFIG = {
	hasBackdrop: true,
	backdropClass: 'dark-backdrop',
	panelClass: 'tm-file-preview-notification-panel'
};

@Injectable({
	providedIn: 'root'
})
export class NotificationService {
	constructor(
		private _injector: Injector,
		private overlayService: OverlayService
	) {}

	open(config: NotificationConfig): NotificationReference {
		// Override default configuration
		const notificationConfig = { ...DEFAULT_CONFIG, ...config };

		const overlay: OverlayRef = this.overlayService.createOverlay(
			notificationConfig
		);

		// Instantiate remote control
		const notificationRef = new NotificationReference(overlay);

		const notificationComponent: NotificationComponent = this.attachDialogContainer(
			overlay,
			notificationRef
		);

		notificationComponent.legend = notificationConfig.legend;
		notificationComponent.icon = notificationConfig.icon;
		notificationComponent.type = notificationConfig.type;
		notificationComponent.size = notificationConfig.size;
		notificationComponent.variant = notificationConfig.variant;

		notificationRef.componentInstance = notificationComponent;

		overlay.backdropClick().subscribe(_ => notificationRef.close());

		return notificationRef;
	}

	private attachDialogContainer(
		overlay: OverlayRef,
		notificationRef: NotificationReference
	): NotificationComponent {
		const injector: PortalInjector = this.createInjector(notificationRef);

		const containerPortal = new ComponentPortal(
			NotificationComponent,
			null,
			injector
		);
		const containerRef: ComponentRef<NotificationComponent> = overlay.attach(
			containerPortal
		);

		return containerRef.instance;
	}

	private createInjector(
		notificationRef: NotificationReference
	): PortalInjector {
		const injectionTokens = new WeakMap();

		injectionTokens.set(NotificationReference, notificationRef);

		return new PortalInjector(this._injector, injectionTokens);
	}
}
