import { trigger, state, style } from '@angular/animations';

export const CardAnimations= {
	cardTrigger: trigger('moveCard', [
		state(
			'initial',
			style({
				transform: 'translateX(-100%)'
			})
		),
		state(
			'last',
			style({
				transform: 'translateX(100%)'
			})
		),
		state(
			'active',
			style({
				transform: 'translateX(0)'
			})
		),
		state(
			'prev',
			style({
				transform: 'translateX(-295px)', // translateX(calc(-100% + 25vw))
				'z-index': '999'
			})
		),
		state(
			'next',
			style({
				transform: 'translateX(295px)', // translateX(calc(100% - 25vw))
				'z-index': '999'
			})
		)
	]),
	textTrigger: trigger('moveText', [
		state(
			'initial',
			style({
				transform: 'translateX(-100%)'
			})
		),
		state(
			'last',
			style({
				transform: 'translateX(100%)'
			})
		),
		state(
			'active',
			style({
				transform: 'translateX(0)'
			})
		),
		state(
			'prev',
			style({
				transform: 'translateX(-100%)'
			})
		),
		state(
			'next',
			style({
				transform: 'translateX(100%)'
			})
		)
	])
};
