import {
	Component,
	Input,
	OnInit,
	Output,
	EventEmitter
} from '@angular/core';
import {
	trigger,
	state,
	style
} from '@angular/animations';

/**
 * El component <code>sn-card-slider</code>
 * despliega un arreglo de tarjetas en forma de carousel
 * @TODO: It can also use calc(-100% + 25vw) to translate the cards
 * @export
 */
@Component({
	selector: 'sn-card-slider',
	templateUrl: './card-slider.component.html',
	styleUrls: ['./card-slider.component.scss'],
	animations: [
		trigger('moveCard', [
			state(
				'initial',
				style({
					transform: 'translateX(-100%)'
				})
			),
			state(
				'last',
				style({
					transform: 'translateX(100%)'
				})
			),
			state(
				'active',
				style({
					transform: 'translateX(0)'
				})
			),
			state(
				'prev',
				style({
					transform: 'translateX(-295px)', // translateX(calc(-100% + 25vw))
					'z-index': '999'
				})
			),
			state(
				'next',
				style({
					transform: 'translateX(295px)',// translateX(calc(100% - 25vw))
					'z-index': '999'
				})
			)
		]),
		trigger('moveText', [
			state(
				'initial',
				style({
					transform: 'translateX(-100%)'
				})
			),
			state(
				'last',
				style({
					transform: 'translateX(100%)'
				})
			),
			state(
				'active',
				style({
					transform: 'translateX(0)'
				})
			),
			state(
				'prev',
				style({
					transform: 'translateX(-100%)'
				})
			),
			state(
				'next',
				style({
					transform: 'translateX(100%)'
				})
			)
		])
	]
})
export class CardSliderComponent implements OnInit {
	private _cards = [];
	private _card: any;

	/**
   * Evento que se emite cuando se cambia la tarjeta seleccionada
   * @memberof CardSlideComponent
   */
	@Output() cardChange: EventEmitter<any> = new EventEmitter<any>();

	/**
   * Tarjeta actual seleccionada
   * @readonly
   * @memberof CardSlideComponent
   */
	@Input()
	get card() {
		return this._card;
	}
	set card(card: any) {
		if (card !== undefined) {
			this._card = card;
			this.cardChange.emit(card);
		}
	}

	/**
   * Arreglo de tarjetas que se mostrará en el carrousel
   * @readonly
   * @memberof CardSlideComponent
   */
	@Input()
	get cards() {
		return this._cards;
	}
	set cards(cards: any) {
		if (cards === undefined) {
			return;
		}
		this._cards = cards;
		if (cards.length > 0) {
			this.cards.map((item: any, index: number) => {
				if (item.position === 'active') {
					this.selectCard(index);
				}
			});
			if (this.card === undefined) {
				this.card = this.cards[0];
				this.selectCard(0);
			}
		}
	}

	/**
   * Crea una instancia de CardSlideComponent.
   * @memberof CardSlideComponent
   */
	constructor() { }

	/**
   *
   * @memberof CardSlideComponent
   */
	ngOnInit() { }

	/**
   * Obtiene el indice de la tarjeta que se muestra actualmente
   *
   * @returns indice de la tarjeta actual
   * @memberof CardSliderComponent
   */
	getSelectedIndex(): number {
		for (let i = 0; i < this.cards.length; i++) {
			if (this.cards[i].position === 'active') {
				return i;
			}
		}

		return 0;
	}

	/**
   * Realiza el cambio de estado de las tarjetas y selecciona una
   *
   * @param i índice de la tarjeta que se desea mostrar
   * @memberof CardSliderComponent
   */
	public selectCard(i: number): void {
		if (i < 0 || i > this.cards.length - 1) {
			this.initState();
			return;
		}
		this.cards[i].position = 'active';
		this.card = this.cards[i];
		if (i !== 0) {
			this.cards[i - 1].position = 'prev';
		}
		if (i + 1 !== this.cards.length) {
			this.cards[i + 1].position = 'next';
		}
		for (let k = 0; k < this.cards.length; k++) {
			if (k < i - 1) {
				this.cards[k].position = 'initial';
			}
			if (k > i + 1) {
				this.cards[k].position = 'last';
			}
		}
	}

	/**
   * Devuelve las tarjetas y textos a su estado normal
   *
   * @memberof CardSliderComponent
   */
	public initState(): void {
		const sls = document.querySelectorAll('.sn-card-slide');
		const txts = document.querySelectorAll('.sn-card-payment');
		for (let i = 0; i < sls.length; i++) {
			(sls[i] as HTMLElement).style.transform = (sls[i] as HTMLElement).style.transform.split(' t')[0];
			(txts[i] as HTMLElement).style.transform = (txts[i] as HTMLElement).style.transform.split(' t')[0];
		}
	}

	/**
   * Comienza a mover las tarjetas y textos proporcionalmente
   *
   * @param e hammer event
   * @memberof CardSliderComponent
   */
	public startMoving(e: any): void {
		const percentage = 100 / this.cards.length * e.deltaX / window.innerWidth;
		const slides = document.querySelectorAll('.sn-card-slide');
		const textos = document.querySelectorAll('.sn-card-payment');
		for (let i = 0; i < slides.length; i++) {
			const transforms = (slides[i] as HTMLElement).style.transform.split(' t');
			const textTrans = (textos[i] as HTMLElement).style.transform.split(' t');
			transforms[1] = 'translateX(' + percentage + '% )';
			textTrans[1] = 'translateX(' + percentage + '% )';
			const trans = transforms.join(' ');
			const text = textTrans.join(' ');
			(slides[i] as HTMLElement).style.transform = trans;
			(textos[i] as HTMLElement).style.transform = text;
		}

		if (e.isFinal) {
			if (e.velocityX > 1) {
				this.selectCard(this.getSelectedIndex() - 1);
			} else if (e.velocityX < -1) {
				this.selectCard(this.getSelectedIndex() + 1);
			} else {
				if (percentage <= -(25 / this.cards.length)) {
					this.selectCard(this.getSelectedIndex() + 1);
				} else if (percentage >= 25 / this.cards.length) {
					this.selectCard(this.getSelectedIndex() - 1);
				} else {
					this.initState();
				}
			}
		}
	}
}
