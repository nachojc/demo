import {
	Component,
	ElementRef,
	EventEmitter,
	Input,
	Output,
	Renderer2
} from '@angular/core';

import { CardAnimations } from './card-slider.animations'

/**
 * El component <code>sn-card-slider</code>
 * despliega un arreglo de tarjetas en forma de carrusel.
 * @TODO: It can also use calc(-100% + 25vw) to translate the cards.
 * @export
 */
@Component({
	selector: 'sn-card-slider',
	templateUrl: './card-slider.component.html',
	styleUrls: ['./card-slider.component.scss'],
	animations: [CardAnimations.cardTrigger, CardAnimations.textTrigger]
})
export class CardSliderComponent {
	/**
	 *Creates an instance of CardSliderComponent.
	 * @param {Renderer2} _renderer
	 * @param {ElementRef} _elementRef
	 * @memberof CardSliderComponent
	 */
	constructor(private _renderer: Renderer2, private _elementRef: ElementRef) {}

	/**
	 * @ignore
	 * Indica la lista de cartas a mostrar.
	 *
	 * @private
	 * @type {Array}
	 * @memberof CardSliderComponent
	 */
	private _cards = [];

	/**
	 * @ignore
	 * Indica la carta seleccionada.
	 *
	 * @private
	 * @type {*}
	 * @memberof CardSliderComponent
	 */
	private _card: any;

	/**
	 * Evento emitido cuando cambia la tarjeta seleccionada.
	 *
	 * @type {EventEmitter<any>}
	 * @memberof CardSliderComponent
	 */
	@Output() cardChange: EventEmitter<any> = new EventEmitter<any>();

	/**
	 * Indica la tarjeta seleccionada.
	 *
	 * @readonly
	 * @type {*}
	 * @memberof CardSliderComponent
	 */
	@Input()
	get card() {
		return this._card;
	}
	set card(card: any) {
		if (card !== undefined) {
			this._card = card;
			this.cardChange.emit(card);
		}
	}

	/**
	 * Arreglo de tarjetas que se mostrará en el carrusel.
	 *
	 * @readonly
	 * @type {*}
	 * @memberof CardSliderComponent
	 */
	@Input()
	get cards() {
		return this._cards;
	}
	set cards(cards: any) {
		if (cards === undefined) {
			return;
		}
		this._cards = cards;
		if (cards.length > 0) {
			this.cards.map((item: any, index: number) => {
				if (item.position === 'active') {
					this.selectCard(index);
				}
			});
			if (this.card === undefined) {
				this.card = this.cards[0];
				this.selectCard(0);
			}
		}
	}

	/**
	 * Obtiene el índice de la tarjeta que se muestra actualmente.
	 *
	 * @returns {number}
	 * @memberof CardSliderComponent
	 */
	getSelectedIndex(): number {
		for (let i = 0; i < this.cards.length; i++) {
			if (this.cards[i].position === 'active') {
				return i;
			}
		}
		return 0;
	}

	/**
	 * Realiza el cambio de estado de las tarjetas y selecciona la que tenga en índice
	 * mandado por parametro.
	 *
	 * @param {number} i índice de la tarjeta que se desea mostrar
	 * @returns {void}
	 * @memberof CardSliderComponent
	 */
	public selectCard(i: number): void {
		if (i < 0 || i > this.cards.length - 1) {
			this.initState();
			return;
		}
		this.cards[i].position = 'active';
		this.card = this.cards[i];
		if (i !== 0) {
			this.cards[i - 1].position = 'prev';
		}
		if (i + 1 !== this.cards.length) {
			this.cards[i + 1].position = 'next';
		}
		for (let k = 0; k < this.cards.length; k++) {
			if (k < i - 1) {
				this.cards[k].position = 'initial';
			}
			if (k > i + 1) {
				this.cards[k].position = 'last';
			}
		}
	}

	/**
	 * Devuelve las tarjetas y textos a su estado default.
	 *
	 * @memberof CardSliderComponent
	 */
	public initState(): void {
		const cardsSlide = this._elementRef.nativeElement.querySelectorAll(
			'.sn-card-slide'
		);
		const cardsPayment = this._elementRef.nativeElement.querySelectorAll(
			'.sn-card-payment'
		);
		for (let i = 0; i < cardsSlide.length; i++) {
			this._renderer.setStyle(
				cardsSlide[i] as HTMLElement,
				'transform',
				(cardsSlide[i] as HTMLElement).style.transform.split(' t')[0]
			);
			this._renderer.setStyle(
				cardsPayment[i] as HTMLElement,
				'transform',
				(cardsPayment[i] as HTMLElement).style.transform.split(' t')[0]
			);
		}
	}

	/**
	 * Comienza a mover las tarjetas y textos proporcionalmente.
	 *
	 * @param {*} e hammer event
	 * @memberof CardSliderComponent
	 */
	public startMoving(e: any): void {
		const percentage =
			((100 / this.cards.length) * e.deltaX) / window.innerWidth;
		const cardsSlide = this._elementRef.nativeElement.querySelectorAll(
			'.sn-card-slide'
		);
		const cardsPayment = this._elementRef.nativeElement.querySelectorAll(
			'.sn-card-payment'
		);
		for (let i = 0; i < cardsSlide.length; i++) {
			const slideTransform = (cardsSlide[
				i
			] as HTMLElement).style.transform.split(' t');
			const paymentTransform = (cardsPayment[
				i
			] as HTMLElement).style.transform.split(' t');
			slideTransform[1] = 'translateX(' + percentage + '% )';
			paymentTransform[1] = 'translateX(' + percentage + '% )';
			this._renderer.setStyle(
				cardsSlide[i] as HTMLElement,
				'transform',
				slideTransform.join(' ')
			);
			this._renderer.setStyle(
				cardsPayment[i] as HTMLElement,
				'transform',
				paymentTransform.join(' ')
			);
		}

		if (e.isFinal) {
			if (e.velocityX > 1) {
				this.selectCard(this.getSelectedIndex() - 1);
			} else if (e.velocityX < -1) {
				this.selectCard(this.getSelectedIndex() + 1);
			} else {
				if (percentage <= -(25 / this.cards.length)) {
					this.selectCard(this.getSelectedIndex() + 1);
				} else if (percentage >= 25 / this.cards.length) {
					this.selectCard(this.getSelectedIndex() - 1);
				} else {
					this.initState();
				}
			}
		}
	}
}
