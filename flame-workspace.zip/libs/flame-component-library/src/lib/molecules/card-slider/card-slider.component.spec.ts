import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CardSliderComponent } from './card-slider.component';
import { CardComponent } from '../../atoms/card/card.component';
import { CardNumberModule } from '../../pipes/card-number';
import { SkeletonModule } from '../../directives/skeleton';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('CardSliderComponent', () => {
  let component: CardSliderComponent;
  let fixture: ComponentFixture<CardSliderComponent>;
  const cardActive = { name: 'Card 1', type: 'Credito', position: 'active', key: 'key1' };
  const cardPrev = { name: 'Card 2', type: 'Credito', position: 'prev', key: undefined };
  const cardLast = { name: 'Card 3', type: 'Credito', position: 'last', key: 'key3' };
  const cardInitial = { name: 'Card 4', type: 'Credito', position: 'initial', key: 'key4' };
  const cardNext = { name: 'Card 5', type: 'Credito', position: 'next', key: 'key5' };
  const cards = [cardActive, cardPrev, cardLast, cardInitial, cardNext];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [CardNumberModule, SkeletonModule],
      declarations: [CardSliderComponent, CardComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CardSliderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('card Input get and set', () => {
    expect(component.card).toBe(component.card);
    spyOn(component.cardChange, 'emit');
    component.card = cardActive;
    expect(component.card).toBe(cardActive);
    expect(component.cardChange.emit).toHaveBeenCalledWith(cardActive);
  });

  it('cards Input get and set', () => {
    expect(component.cards).toBe(component.cards);
    component.cards = undefined;
    expect(component.cards).toEqual([]);
    spyOn(component, 'selectCard');
    component.card = undefined;
    component.cards = cards;
    expect(component.cards).toBe(cards);
    expect(component.selectCard).toHaveBeenCalledTimes(2);
    expect(component.selectCard).toHaveBeenCalledWith(0);
    expect(component.card).toBe(cards[0]);
  });

  it('getSelectedIndex method', () => {
    component.cards = [cardPrev, cardActive, cardLast];
    expect(component.getSelectedIndex()).toBe(1);
    component.cards = [cardPrev, cardLast];
    expect(component.getSelectedIndex()).toBe(0);
  });

  it('selectCard method invalid card number', () => {
    spyOn(component, 'initState');
    component.selectCard(-1);
    expect(component.initState).toHaveBeenCalled();
  });

  it('selectCard method', () => {
    component.cards = [cardActive, cardPrev, cardLast, cardInitial, cardNext];
    const cardsLength = component.cards.length;
    const number = (cardsLength - 1) / 2;
    component.selectCard(number);
    expect(component.cards[number].position).toBe('active');
    expect(component.card).toBe(component.cards[number]);
    expect(component.cards[number - 1].position).toBe('prev');
    expect(component.cards[number + 1].position).toBe('next');
    expect(component.cards[number - 2].position).toBe('initial');
    expect(component.cards[number + 2].position).toBe('last');
  });
});

