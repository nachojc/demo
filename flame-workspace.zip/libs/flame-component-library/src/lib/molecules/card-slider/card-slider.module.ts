import { ButtonModule } from './../../atoms/button/button.module';
import { CardModule } from './../../atoms/card/card.module';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardSliderComponent } from './card-slider.component';

@NgModule({
	declarations: [CardSliderComponent],
	imports: [CommonModule, CardModule, ButtonModule],
	exports: [CardSliderComponent],
	schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CardSliderModule {}
