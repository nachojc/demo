import { ButtonModule } from './../../atoms/button/button.module';
import { CardModule } from './../../atoms/card/card.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardSliderComponent } from './card-slider.component';

@NgModule({
	declarations: [CardSliderComponent],
	imports: [CommonModule, CardModule, ButtonModule],
	exports: [CardSliderComponent]
})
export class CardSliderModule {}
