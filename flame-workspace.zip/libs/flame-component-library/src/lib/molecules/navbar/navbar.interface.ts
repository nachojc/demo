export interface NavbarElement {
	route: string;
	icon: string;
	name: string;
}
