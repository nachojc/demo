export interface NavbarElement {
	route: string;
	icon: string;
  name: string;
  animated?: boolean;
  animatedIcon?: any;
  disabled?: boolean;
}
