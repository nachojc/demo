import { NgModule } from '@angular/core';
import { NavbarComponent } from './navbar.component';
import { CommonModule } from '@angular/common';
import { IconModule } from '../../atoms/icon/icon.module';
import { LottieAnimationViewModule } from 'ng-lottie';

@NgModule({
	imports: [CommonModule, IconModule, LottieAnimationViewModule.forRoot()],
	declarations: [NavbarComponent],
	exports: [NavbarComponent]
})
export class NavbarModule {}
