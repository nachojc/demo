import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavbarElement } from './navbar.interface';
@Component({
  selector: 'sn-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  /**
   * Array de objetos con propiedades name / icon / path
   * 
   * @type {NavbarElement[]}
   * @memberof NavbarComponent
   */
  @Input() buttons: NavbarElement[];

  /**
   * Indica el índice de elemento activo.
   * 
   * @type {number}
   * @memberof NavbarComponent
   */
  @Input() active = 0;

  /**
   * Evento que devuelve la propiedad del router del objeto <strong>button</strong>.
   * 
   * @type {EventEmitter}
   * @memberof NavbarComponent
   */
  @Output() onSelection = new EventEmitter();

  /**
   * Indica el elemento activo y dispara el evento redireccionando a la ruta especifica.
   * 
   * @param {number} i
   * @param {string} route
   * @memberof NavbarComponent
   */
  public selectElement(i: number, route: string): void {
    this.active = i;
    this.onSelection.emit(route);
  }
}
