import { Component, Input, Output, EventEmitter } from '@angular/core';
import { NavbarElement } from './navbar.interface';
@Component({
  selector: 'sn-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {

  /**
   * Variable de control para alimentar @Input() animated
   * @type {number}
   * @memberof NavbarComponent
   */
  private _animated = false;

  /**
   * Array de elementos animados
   * @type {any[]}
   * @memberof NavbarComponent
   */
  private animatedElements = [];

  /**
   * Variable de control de icono activo
   * @type {number}
   * @memberof NavbarComponent
   */
  private _active = 0;

  /**
   * Array de objetos con propiedades name / icon / path
   *
   * @type {NavbarElement[]}
   * @memberof NavbarComponent
   */
  @Input() buttons: NavbarElement[];

  /**
   * Indica el índice de elemento activo.
   *
   * @type {number}
   * @memberof NavbarComponent
   */
  @Input()
  set active(value: number){
    this._active = value;
    //this.playAnimation(value);
  }
  get active(){
    return this._active;
  }

  /**
   * Evento que devuelve la propiedad del router del objeto <strong>button</strong>.
   *
   * @type {EventEmitter}
   * @memberof NavbarComponent
   */
  @Output() onSelection = new EventEmitter();

  /**
   * Indica el elemento activo y dispara el evento redireccionando a la ruta especifica.
   *
   * @param {number} i
   * @param {string} route
   * @memberof NavbarComponent
   */
  public selectElement(i: number, route: string, disabled: boolean, animated: boolean): void {
    if(!disabled){
      this.active = i;
      this.onSelection.emit(route);
    }
  }

  /**
   * Reproduce la animacion de un elemento animado manualmente
   * @param id
   */
  playAnimation(id: number){
    const animate = this.animatedElements.find(optionnav => optionnav.id === id);
    if (animate){
      animate.anim.setSpeed(0.5);
      animate.anim.play();
    }
  }

  handleAnimation(id: number, anim: any) {
    if (id === this.active){
      anim.setSpeed(0.9);
      anim.play();
    }
  }
}
