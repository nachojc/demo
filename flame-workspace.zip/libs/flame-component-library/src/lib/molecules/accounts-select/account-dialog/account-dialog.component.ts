import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { CustomDialogComponent } from '../../../atoms/dialog/dialog-custom';
import { AccountSelectService } from '../account-service/account-select.service';

@Component({
	selector: 'sn-account-dialog',
	templateUrl: './account-dialog.component.html',
	styleUrls: ['./account-dialog.component.scss']
})
export class AccountDialogComponent implements OnInit, CustomDialogComponent {
	public data: any;

	constructor() {}

	ngOnInit() {}

	selectProduct(product: any) {
		this.data.service.accountSelected(product);
	}
}
