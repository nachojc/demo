import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountSelectComponent } from './account-select.component';
import { AccountDialogComponent } from './account-dialog/account-dialog.component';
import { DialogModule } from '../../atoms/dialog/dialog.module';
import { ProductModule } from './../product/product.module';

@NgModule({
	declarations: [AccountSelectComponent, AccountDialogComponent],
	imports: [CommonModule, DialogModule, ProductModule],
	entryComponents: [AccountDialogComponent],
	exports: [AccountSelectComponent]
})
export class AccountSelectModule {}
