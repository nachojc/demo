import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class AccountSelectService {
	private control = new Subject<any>();

	accountSelected(product: any) {
		this.control.next(product);
	}

	getResponse(): Observable<any> {
		return this.control.asObservable();
	}
}
