/*
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AccountSelectComponent } from './account-select.component';
import { DialogModule } from '../../atoms/dialog/dialog.module';
import { ProductModule } from './../product/product.module';

describe('AccountSelectComponent', () => {
  let component: AccountSelectComponent;
  let fixture: ComponentFixture<AccountSelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccountSelectComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountSelectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
*/
