import { AccountDialogComponent } from './account-dialog/account-dialog.component';
import {
	Component,
	Input,
	OnInit,
	Output,
	EventEmitter,
	OnDestroy,
	ViewEncapsulation
} from '@angular/core';
import {
	DialogService,
	CustomDialog,
	DialogReference
} from '../../atoms/dialog/index';
import { AccountSelectService } from './account-service/account-select.service';
import { Subscription } from 'rxjs';

/**
 * El component <code>sn-accounts-select</code>
 * permite seleccionar una cuenta de una lista que
 * se despliega en un dialog.
 *
 * @export
 */
@Component({
	selector: 'sn-account-select',
	templateUrl: './account-select.component.html',
	styleUrls: ['./account-select.component.scss'],
	encapsulation: ViewEncapsulation.None,
	providers: [AccountSelectService]
})
export class AccountSelectComponent implements OnInit, OnDestroy {
	private accountSelectDialogRef: DialogReference;
	private subscription: Subscription;
	private _accounts = [];
	private _account: any;

	/**
	 * Habilita o desabilita que se muestra el producto seleccionado como un
	 * accordion y que se abra o no el dialogo para seleccionar.
	 *
	 * @memberof AccountSelectComponent
	 */
	@Input() disabled = false;
	/**
	 * Texto que se muestra como titulo del componente, justo arriba del
	 * <code>sn-product</code> seleccionado.
	 *
	 * @memberof AccountSelectComponent
	 */
	@Input() title: string;
	/**
	 * Texto que se muestra como titulo en el dialog.
	 *
	 * @memberof AccountSelectComponent
	 */
	@Input() dialogTitle: string;
	/**
	 * Texto que se muestra como subtitulo en el dialog
	 *
	 * @memberof AccountSelectComponent
	 */
	@Input() subtitle: string;
	/**
	 * Texto que se muestra en la etiqueta de cierre del dialog
	 *
	 * @memberof AccountSelectComponent
	 */
	@Input() closeLabel: string;
	/**
	 * Evento que emite el cambio de la cuenta seleccionada
	 *
	 * @memberof AccountSelectComponent
	 */

	@Input() description: string;
	/**
	 * Agrega un subtitulo al titulo
	 *
	 * @memberof AccountSelectComponent
	 */
	@Output() accountChange: EventEmitter<any> = new EventEmitter<any>();

	/**
	 * Cuenta seleccionada que se puede establecer desde el componente
	 * en el que se implemente o desde la selección de la lista.
	 *
	 * @readonly
	 * @memberof AccountSelectComponent
	 */
	@Input()
	get account() {
		return this._account;
	}
	set account(account: any) {
		if (account !== undefined) {
			this._account = account;
			this.accountChange.emit(account);
		}
	}

	/**
	 * Arreglo de cuentas que se muestra en el dialog y que se debe obtener de un servicio
	 *
	 * @readonly
	 * @memberof AccountSelectComponent
	 */
	@Input()
	get accounts() {
		return this._accounts;
	}
	set accounts(accounts: any) {
		this._accounts = accounts;
		if (accounts.length > 0 && this.account.key === undefined) {
			this.account = this.accounts[0];
		}
	}

	/**
	 * Crea una instancia de AccountSelectComponent.
	 * @param dialog Servicio de dialog para abrir uno
	 * @param accountService Servicio para recuperar la cuenta seleccionada en el dialog
	 * @memberof AccountSelectComponent
	 */
	constructor(
		private dialog: DialogService,
		private accountService: AccountSelectService
	) {}

	/**
	 * Se suscribe al servicio de account para obtener la selecciona del dialog
	 *
	 * @memberof AccountSelectComponent
	 */
	ngOnInit() {
		this.subscription = this.accountService.getResponse().subscribe(res => {
			if (this.accountSelectDialogRef !== undefined) {
				if (this.accountSelectDialogRef.componentInstance !== null) {
					this.accountSelectDialogRef.close();
				}
				this.initAccountRel(res);
			}
		});
	}

	/**
	 * Inicializa la cuenta a seleccionar y asigna una nueva si se envia el parametro
	 *
	 * @param initAccount=null Nueva cuenta a ser asignada
	 * @memberof AccountSelectComponent
	 */
	private initAccountRel(initAccount = null) {
		this.account = {
			product: {},
			related_phone: {},
			balance: {}
		};
		if (initAccount !== null) {
			this.account = Object.assign(this.account, initAccount);
			this.account.related_phone = {};
		}
	}

	/**
	 * Abre el dialogo para seleccionar una cuenta, si esta habilitado.
	 *
	 * @memberof AccountSelectComponent
	 */
	public openAccountSelect() {
		if (!this.disabled) {
			this.accountSelectDialogRef = this.dialog.open(
				{
					closeLabel: this.closeLabel ? this.closeLabel : ' ',
					title: this.dialogTitle,
					enableHr: false,
					disabledButton: false,
					showButton: false,
					buttons: []
				},
				new CustomDialog(AccountDialogComponent, {
					products: this.accounts,
					subtitle: this.subtitle,
					service: this.accountService
				})
			);
		}
	}

	/**
	 *
	 *
	 * @memberof AccountSelectComponent
	 */
	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
}
