import { AccountDialogComponent } from './account-dialog/account-dialog.component';
import {
	Component,
	Input,
	OnInit,
	Output,
	EventEmitter,
	OnDestroy,
  ViewEncapsulation
} from '@angular/core';
import {
	DialogService,
	CustomDialog,
	DialogReference
} from '../../atoms/dialog/index';
import { AccountSelectService } from './account-service/account-select.service';
import { Subscription } from 'rxjs';

/**
 * El component <code>sn-accounts-select</code>
 * permite seleccionar una cuenta de una lista
 * desplegada en un dialog.
 *
 * @export
 */
@Component({
	selector: 'sn-account-select',
	templateUrl: './account-select.component.html',
	styleUrls: ['./account-select.component.scss'],
	encapsulation: ViewEncapsulation.None,
	providers: [AccountSelectService]
})
export class AccountSelectComponent implements OnInit, OnDestroy {
	/**
	 * Creates an instance of AccountSelectComponent.
	 * @param dialog
	 * @param accountService
	 * @memberof AccountSelectComponent
	 */
	constructor(
		private dialog: DialogService,
    private accountService: AccountSelectService
	) {}

	/**
	 * @ignore
	 * Indica la referencia al dialogo mostrado.
	 *
	 * @private
	 * @type {DialogReference}
	 * @memberof AccountSelectComponent
	 */
	private accountSelectDialogRef: DialogReference;

	/**
	 * @ignore
	 * Indica la suscripción a un servicio.
	 *
	 * @private
	 * @type {Subscription}
	 * @memberof AccountSelectComponent
	 */
	private subscription: Subscription;

	/**
	 * @ignore
	 * Lista de cuentas a desplegarse.
	 *
	 * @private
	 * @type {Array}
	 * @memberof AccountSelectComponent
	 */
	private _accounts = [];

	/**
	 * @ignore
	 * Cuenta seleccionada que se puede establecer desde el componente
	 * en el que se implemente o desde la selección de la lista.
	 *
	 * @private
	 * @type {*}
	 * @memberof AccountSelectComponent
	 */
	private _account: any;

	/**
	 * Habilita o deshabilita que se muestra el producto seleccionado
	 * como un acordeón y que se abra o no el dialogo para seleccionar.
	 *
	 * @type {boolean}
	 * @memberof AccountSelectComponent
	 */
	@Input() disabled = false;

	/**
	 * Indica el texto que se muestra como título del componente, justo arriba
	 * del <code>sn-product</code> seleccionado.
	 *
	 * @type {string}
	 * @memberof AccountSelectComponent
	 */
	@Input() title: string;

	/**
	 * Indica el texto que se muestra como título en el dialog.
	 *
	 * @type {string}
	 * @memberof AccountSelectComponent
	 */
	@Input() dialogTitle: string;

	/**
	 * Indica el texto que se muestra como subtitulo en el dialog.
	 *
	 * @type {string}
	 * @memberof AccountSelectComponent
	 */
	@Input() subtitle: string;

	/**
	 * Indica el texto que se muestra en la etiqueta de cierre del dialog.
	 *
	 * @type {string}
	 * @memberof AccountSelectComponent
	 */
	@Input() closeLabel: string;

	/**
	 * Indica una descripción como subtitulo.
	 *
	 * @type {string}
	 * @memberof AccountSelectComponent
	 */
	@Input() description: string;

	/**
	 * Cuenta seleccionada que se puede establecer desde el componente
	 * en el que se implemente o desde la selección de la lista.
	 *
	 * @readonly
	 * @type {*}
	 * @memberof AccountSelectComponent
	 */
	@Input()
	get account() {
		return this._account;
	}
	set account(account: any) {
		if (account !== undefined) {
      this._account = account;
      this.accountChange.emit(account);
		}
	}

	/**
	 * Arreglo de cuentas que se muestra en dialog.
	 *
	 * @readonly
	 * @type {*}
	 * @memberof AccountSelectComponent
	 */
	@Input()
	get accounts() {
		return this._accounts;
	}
	set accounts(accounts: any) {
		this._accounts = accounts;
		if (accounts.length > 0 && this.account.key === undefined) {
			this.account = this.accounts[0];
		}
	}

	/**
	 * Evento que emite el cambio de la cuenta seleccionada.
	 * @type {EventEmitter<any>}
	 * @memberof AccountSelectComponent
	 */
	@Output() accountChange: EventEmitter<any> = new EventEmitter<any>();

	/**
	 * @ignore
	 * Inicializa la cuenta a seleccionar y asigna una nueva si se envía el parámetro.
	 *
	 * @param initAccount=null Nueva cuenta a ser asignada
	 * @memberof AccountSelectComponent
	 */
	private initAccountRel(initAccount = null) {
		this.account = {
			product: {},
			related_phone: {},
			balance: {}
		};
		if (initAccount !== null) {
			this.account = Object.assign(this.account, initAccount);
      this.account.related_phone = {};
		}
	}

	/**
	 * Abre el dialogo para seleccionar una cuenta, si está habilitada.
	 *
	 * @memberof AccountSelectComponent
	 */
	public openAccountSelect() {
		if (!this.disabled) {
			this.accountSelectDialogRef = this.dialog.open(
				{
					closeLabel: this.closeLabel ? this.closeLabel : ' ',
					title: this.dialogTitle,
					enableHr: false,
					disabledButton: false,
					showButton: false,
					buttons: []
				},
				new CustomDialog(AccountDialogComponent, {
					products: this._accounts,
					subtitle: this.subtitle,
					service: this.accountService
				})
			);
		}
	}

	/**
	 * @ignore
	 * Se suscribe al servicio de account para obtener la seleccion del dialog.
	 *
	 * @memberof AccountSelectComponent
	 */
	ngOnInit() {
		this.subscription = this.accountService.getResponse().subscribe(res => {
			if (
				this.accountSelectDialogRef &&
				this.accountSelectDialogRef.componentInstance
			) {
        this.accountChange.emit(res);
				this.accountSelectDialogRef.close();
				this.initAccountRel(res);
			}
		});
	}

	/**
	 * @ignore
	 * Cancelar suscripción al servicio account.
	 *
	 * @memberof AccountSelectComponent
	 */
	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
}
