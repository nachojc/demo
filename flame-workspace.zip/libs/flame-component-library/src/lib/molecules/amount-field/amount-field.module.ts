import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AmountFieldComponent } from './amount-field.component';
import { IconModule } from '../../atoms/icon/icon.module';
import { FormsModule } from '@angular/forms';
import { AutoWidthInputModule } from '../../directives/auto-width-input/auto-width-input.module';

export const customCurrencyMaskConfig = {
	align: "right",
    allowNegative: false,
    allowZero: true,
    decimal: ".",
    precision: 2,
    prefix: "",
    suffix: "",
    thousands: ",",
    nullable: true
}

@NgModule({
	imports: [
    CommonModule,
		IconModule,
		FormsModule,
		AutoWidthInputModule
	],
	declarations: [AmountFieldComponent],
	exports: [AmountFieldComponent]
})
export class AmountFieldModule {}
