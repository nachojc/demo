import { NgControl } from '@angular/forms';
import {
	Component,
	EventEmitter,
	Input,
	Output,
	ContentChild,
	ViewEncapsulation,
	AfterContentInit,
	ElementRef
} from '@angular/core';

/**
 * Componente que permite crear un wrapper sobre un input con unos estilos determinados.
 * @example
 * <sn-amount-field label="Ingresa una cantidad en MXN">
 *   <input
 *     snAutowidthinput
 *     snCurrencyMask
 *     [(ngModel)]="amount"
 *     type="text"
 *   />
 *  </sn-amount-field>
 */
@Component({
	selector: 'sn-amount-field',
	templateUrl: './amount-field.component.html',
	styleUrls: ['./amount-field.component.scss'],
	encapsulation: ViewEncapsulation.None
})
export class AmountFieldComponent implements AfterContentInit {
	constructor(private _elementRef: ElementRef) {}

	private _label: string;
	public invalidAmount: boolean;
	public disabled: boolean;
  public readOnly: boolean;
  public showIcon: boolean;

	@ContentChild(NgControl) input: NgControl;
	@ContentChild(NgControl, { read: ElementRef }) inputTag: ElementRef;
	/**
	 * Texto que se renderiza sobre el input
	 *
	 * @readonly
	 * @memberof AmountFieldComponent
	 */
	@Input()
	get label() {
		return this._label;
	}
	set label(newValue: string) {
		this._label = newValue;
	}

	/**
	 * Parametro que recive el código ISO 4207 que identifica el tipo de moneda que se utiliza.
	 *
	 * @type {string}
	 * @memberof AmountFieldComponent
	 */
	@Input() currencyCode: string;

	/**
	 * Parametro que recive el símbolo que representa el tipo de moneda que se utiliza ($, €, £, etc).
	 *
	 * @memberof AmountFieldComponent
	 */
	@Input() currencySymbol = '$';

	/**
	 * Evento que se envia cuando se limpia el valor del input.
	 *
	 * @memberof AmountFieldComponent
	 */
	@Output() clearInput = new EventEmitter<string>();

	/**
	 * Método que resetea el valor del input.
	 *
	 * @memberof AmountFieldComponent
	 */
	public cleanAmount(): void {
		if (!this.readOnly) {
			this.input.control.reset('0.00');
			this.clearInput.emit('0.00');
		}
	}

	/** @ignore */
	ngAfterContentInit() {
		if (this.input) {
			this.disabled =
				this.inputTag.nativeElement.disabled || this.input.control.disabled;
      this.readOnly = this.inputTag.nativeElement.readOnly;
      this.showIcon = this.input.control.value > 0 ? true : false;
      this.input.control.valueChanges.subscribe((newValue) => {
        this.showIcon = newValue > 0 ? true : false;
      });
			this.input.control.statusChanges.subscribe(status => {
				if (status === 'INVALID') {
					this.invalidAmount = true;
				} else {
					this.invalidAmount = false;
				}
			});
		} else {
			throw new Error(
				'No se ha añadido una instancia FormControl a la etiqueta (ngModel o formControlName)'
			);
		}
	}
}
