import {
  Component,
  OnInit,
  EventEmitter,
  Input,
  Output,
  HostBinding,
  ViewChild,
  ElementRef,
  Renderer2
} from '@angular/core';
import { CurrencyPipe } from '@angular/common';

/**
 * Component amount-field, that allows to capture amount value
 * @example
 * <sn-amount-field snTheme="flame-foundation" global="true"></sn-amount-field>
 * <sn-amount-field snTheme="flame-foundation" global="true" [disabled]="true"></sn-amount-field>
 * <sn-amount-field snTheme="flame-foundation" global="true" label="Escriba su importe en "></sn-amount-field>
 * <sn-amount-field snTheme="flame-foundation" global="true" [disabled]="true" value="1000.00"></sn-amount-field>
 * <sn-amount-field snTheme="flame-foundation" global="true" value="1000.00" max="90"></sn-amount-field>
 * <sn-amount-field snTheme="flame-foundation" global="true" value="-1" min="00.00"></sn-amount-field>
*/
@Component({
  selector: 'sn-amount-field',
  templateUrl: './amount-field.component.html',
  styleUrls: ['./amount-field.component.scss'],
  providers: [
    CurrencyPipe
  ],

})
/* tslint:disable */
export class AmountFieldComponent implements OnInit {

  /**
   *Creates an instance of AmountFieldComponent.
   */
  constructor(public cp: CurrencyPipe, private renderer: Renderer2) { }

  // Private variables
  private _placeholder = '00.00';
  private _iconButton: string;
  private _infoButton: string;
  private _min = 0;
  private _max = 0;
  private _label = 'Escribe una cantidad en ';
  private _value: string;
  private _currencySymbol = '$';
  private _currencyCode = 'MXN';
  private _disabled = false;
  private _readOnly = false;
  private _showError = false;
  private _error = 'No cuentas con dinero para poder realizar esta operación';

  // Public variables
  public border = false;
  public invalidAmount = false;
  public errorMessage = '';
  public minAmountCurr: string;
  public maxAmountCurr: string;

  @Input()
  get placeholder() {
    return this._placeholder;
  }
  set placeholder(newValue: string) {
    this._placeholder = newValue;
  }

	/**
	* Enables info button on the label's side
	*/
  @Input()
  get infoButton() {
    return this._infoButton;
  }
  set infoButton(newValue: string) {
    this._infoButton = newValue;
  }

  /**
   * Enables a button on the side
   */
  @Input()
  get iconButton() {
    return this._iconButton;
  }
  set iconButton(newValue: string) {
    this._iconButton = newValue;
  }

  /**
  * Minimum of amount value
  */
  @Input()
  get min() {
    return this._min;
  }
  set min(newValue: number) {
    this._min = newValue;
  }

  /**
   * Minimum of amount value
   */
  @Input()
  get max() {
    return this._max;
  }
  set max(newValue: number) {
    this._max = newValue;
  }

  /**
   * Description of type of amount
   */
  @Input()
  get label() {
    return this._label;
  }
  set label(newValue: string) {
    this._label = newValue;
  }

  /**
   * Input amount value
   */
  @Input()
  get value() {
    return this._value;
  }
  set value(newValue: string) {
    this._value = newValue;
  }

  /**
   * Symbol of the currency type
   */
  @Input()
  get currencySymbol() {
    return this._currencySymbol;
  }
  set currencySymbol(newValue: string) {
    this._currencySymbol = newValue;
  }

  /**
   * ISO 4217 code of the currency type
   */
  @Input()
  get currencyCode() {
    return this._currencyCode;
  }
  set currencyCode(newValue: string) {
    this._currencyCode = newValue;
  }

  /**
   * It controls if component is disabled or not
   */
  @Input()
  get disabled() {
    return this._disabled
  }
  set disabled(newValue: boolean) {
    this._disabled = newValue;
  }

	/**
	 * Enable input's readonly attribute
	 */
  @Input()
  get readOnly() {
    return this._readOnly;
  }
  set readOnly(value: boolean) {
    this._readOnly = value;
  }

  /**
   * Enables custom error message
   */
  @Input()
  get showError() {
    return this._showError;
  }
  set showError(newValue: boolean) {
    this._showError = newValue;
  }

  /**
   * Error message customizable for invalid amounts
   */
  @Input()
  get error() {
    return this._error;
  }
  set error(newValue: string) {
    this._error = newValue;
  }

  // Outputs
  /**
   * Event that emit amount value introduced in the input when focusin
   */
  @Output() onFocus = new EventEmitter<number>();

  /**
   * Event that emit amount value introduced in the input when blur and focusout
   */
  @Output() onBlur = new EventEmitter<number>();

  /**
   * Event that emit amount value introduced in the input
   */
  @Output() onChange = new EventEmitter<number>();

  /**
   * Event that emit the error message
   */
  @Output() onError = new EventEmitter<string>();

  /**
  * Event that emit click icon event
  */
  @Output() iconPress = new EventEmitter<Event>();

  /**
   * Event that emit click info event
   */
  @Output() infoPress = new EventEmitter<Event>();

  /**
   * Event that emit click on clear button
   */
  @Output() clearButton = new EventEmitter<number>();

  /**
   * Event that emit when input is clear by keyboard
   */
  @Output() clearInput = new EventEmitter<number>();

  // Host Bindings
  /**
   * It applies CSS disabled class when component is disabled
   */
  @HostBinding('class.disabled')
  get isDisabled() {
    return this._disabled ? true : false;
  }

  /**
   * It applies CSS invalid-amount class when amount is not valid
   */
  @HostBinding('class.invalid-amount')
  get isInvalid() {
    return this.invalidAmount ? true : false;
  }

  /**
   * It applies CSS bordered class when border is true
   */
  @HostBinding('class.bordered')
  get isBordered() {
    return this.border ? true : false;
  }

  /**
   * It takes input element
   */
  @ViewChild('amountInput') input: ElementRef

  // Methods
  /**
   * Method that transform a given value to correct format
   * (splitting thousand separators, according currency selected)
   * and parse it to float number
   * param {string} value
   * returns {number}
   */
  public amountToNumber(value: string): number {
    if (value) {
      value = this.amountToCurrency(value);
      value = value.split(',').join('');
      return parseFloat(value);
    } else {
      return 0;
    }
  }

  /**
   * Method that transform a given value to currency format
   * param {string} value
   * returns {string}
   */
  public amountToCurrency(value: string | number): string {
    if (value) {
      if (typeof value === 'number') {
        value = value.toString();
      }
      value = value.split(',').join('');
      return value = this.cp.transform(value, this.currencyCode, '');
    }
  }

  /**
   * Method for validating amounts
   * It sets the corresponding error message if needed
   * param {string} value
   */
  public validate(value: string): void {
    const amount = this.amountToNumber(value);
    this.minAmountCurr = this.amountToCurrency(this.min.toString());
    this.maxAmountCurr = this.amountToCurrency(this.max.toString());
    if (amount < this.min) {
      this.border = true;
      this.invalidAmount = true;
      this.errorMessage = `La cantidad introducida debe ser mayor a ${this.currencySymbol} ${this.minAmountCurr} ${this.currencyCode}`;
    } else if (this.max !== 0 && amount > this.max) {
      this.border = true;
      this.invalidAmount = true;
      this.errorMessage = `La cantidad introducida debe ser menor a ${this.currencySymbol} ${this.maxAmountCurr} ${this.currencyCode}`;
    } else if (this.showError && this.error) {
      this.border = true;
      this.invalidAmount = true;
      this.errorMessage = this.error;
    } else {
      this.invalidAmount = false;
      this.errorMessage = '';
    }

    if (this.errorMessage) {
      this.onError.emit(this.errorMessage);
    }
  }

  /**
   * Method that emits value when input changes
   * if it's empty, emits clearInput with placeholder value
   */
  public changeEvent(): void {
    this.validate(this.value);
    if (this.value) {
      this.onChange.emit(this.amountToNumber(this.value));
    } else {
      this.value = '';
      this.clearInput.emit(this.amountToNumber(this.placeholder));
    }
  }

  /**
   * Method that emits value when focusin on input
   */
  public focusEvent(): void {
    this.border = true;
    this.validate(this.value);
    if (this.value) {
      this.onFocus.emit(this.amountToNumber(this.value));
    } else {
      this.onFocus.emit(this.amountToNumber(this.placeholder));
    }
  }

  /**
   * Method that emits value when focusout and blur on input
   */
  public blurEvent(): void {
    this.border = false;
    this.validate(this.value);
    if (this.value) {
      this.onBlur.emit(this.amountToNumber(this.value));
    }
    else {
      this.onBlur.emit(this.amountToNumber(this.placeholder));
    }
  }

  /**
   * Method that enable clear button when amount value exists
   * param {string} value
   * returns {boolean}
   */
  public enableClear(value: string): boolean {
    if (this.disabled || this.readOnly || (value === this.min.toString() || !value))
      return false;
    else
      return true;
  }

  /**
   * Method that reset input value, emits event
   */
  public clear(): void {
    this.border = false;
    this.value = null;
    this.invalidAmount = false;
    this.clearButton.emit(this.amountToNumber(this.placeholder));
    this.validate(this.placeholder);
  }

  /**
   * Event emitter for the click button
   */
  public iconClick(ev: Event): void {
    this.iconPress.emit(ev);
  }

  /**
   * Event emitter for the info icon
   */
  public infoClick(ev: Event): void {
    this.infoPress.emit(ev);
  }

  /**
   * Method that sets input to readonly 
   */
  public readonlyState(): void {
    if (this.readOnly) {
      this.renderer.setAttribute(this.input.nativeElement, 'readonly', 'true');
      this.renderer.setAttribute(this.input.nativeElement, 'tabindex', '-1');
    }
  }

  /**
   * It calls readonlyState method,
   * initalizes amount value and validates it
   */
  ngOnInit() {
    this.readonlyState();
    if (this.value) {
      this.value = this.amountToNumber(this.value).toString();
    } 
    this.validate(this.value);
  }
}
