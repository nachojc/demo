import { OnInit, DebugElement } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AmountFieldModule } from './amount-field.module';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Component } from '@angular/core';
import { By } from '@angular/platform-browser';
import { SnCurrencyModule } from '../../directives/currency-mask';
import { IconModule } from '../../atoms/icon';

@Component({
  template: `
    <form [formGroup]="testForm">
      <sn-amount-field label="test" currencyCode="$" (infoPress)="testInfo()">
        <input snCurrencyMask formControlName="test" type="text"/>
      </sn-amount-field>
    </form>
  `
})
class MockAmountFieldComponent implements OnInit {
  public testForm: FormGroup;
  public info: boolean;
  constructor(private formBuilder: FormBuilder) {}

  testInfo() {
    this.info = true;
  }

  ngOnInit() {
    this.testForm = this.formBuilder.group({
      test: [10, Validators.max(12)]
    });
  }

}

describe('AmountFieldComponent', () => {
    let component: MockAmountFieldComponent;
    let fixture: ComponentFixture<MockAmountFieldComponent>;
    let amountField: DebugElement;
    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, IconModule, ReactiveFormsModule, AmountFieldModule, SnCurrencyModule],
            declarations: [MockAmountFieldComponent]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(MockAmountFieldComponent);
        component = fixture.componentInstance;
        amountField = fixture.debugElement;
        fixture.detectChanges();
    });

    it('should create component', () => {
        expect(component).toBeTruthy();
    });

    it('should content 10 value', () => {
      const cleanValue = amountField.query(By.css('.clean-button')).nativeElement;
      expect(component.testForm.value.test).toEqual(10);
      cleanValue.click();
      fixture.detectChanges();
      expect(component.testForm.value.test).toEqual('0.00');
    });

    it('should be input error', () => {
      component.testForm.controls.test.setValue(50)
      fixture.detectChanges();
      const invalidAmount = amountField.query(By.css('.invalid-amount')).nativeElement;
      expect(component.testForm.value.test).toEqual(50);
      fixture.detectChanges();
      expect(invalidAmount).toBeDefined();
    });

});
