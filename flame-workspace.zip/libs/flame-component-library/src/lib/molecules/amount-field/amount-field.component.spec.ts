import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AmountFieldComponent } from './amount-field.component';
import { CommonModule } from '@angular/common';
import { IconModule } from '@santander/flame-component-library';
import { FormsModule } from '@angular/forms';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('AmountFieldComponent', () => {
    let component: AmountFieldComponent;
    let fixture: ComponentFixture<AmountFieldComponent>;
    let inputEl: DebugElement;
    let spanEl: DebugElement;
    let labelEl: DebugElement;
    let divEl: DebugElement;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [CommonModule, IconModule, FormsModule],
            declarations: [AmountFieldComponent]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(AmountFieldComponent);
        component = fixture.componentInstance;
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    //Inputs

    it('placeholder Input get and set', () => {
        expect(component.placeholder).toBe(component.placeholder);
        const placeholder = 'Fake placeholder';
        component.placeholder = placeholder;
        expect(component.placeholder).toBe(placeholder);
    });

    it('infoButton Input get and set', () => {
        expect(component.infoButton).toBe(component.infoButton);
        const infoButton = 'Fake infoButton';
        component.infoButton = infoButton;
        expect(component.infoButton).toBe(infoButton);
    });

    it('iconButton Input get and set', () => {
        expect(component.iconButton).toBe(component.iconButton);
        const iconButton = 'Fake iconButton';
        component.iconButton = iconButton;
        expect(component.iconButton).toBe(iconButton);
    });

    it('min Input get and set', () => {
        expect(component.min).toBe(component.min);
        const amount = 123456;
        component.min = amount;
        expect(component.min).toBe(amount);
    });

    it('max Input get and set', () => {
        expect(component.max).toBe(component.max);
        const amount = 123456;
        component.max = amount;
        expect(component.max).toBe(amount);
    });

    it('label Input get and set', () => {
        expect(component.label).toBe(component.label);
        const label = 'ABCDEFG';
        component.label = label;
        expect(component.label).toBe(label);
    });

    it('value Input get and set', () => {
        expect(component.value).toBe(component.value);
        const amount = '123456';
        component.value = amount;
        expect(component.value).toBe(amount);
    });

    it('currencySymbol Input get and set', () => {
        expect(component.currencySymbol).toBe(component.currencySymbol);
        const symbol = '€';
        component.currencySymbol = symbol;
        expect(component.currencySymbol).toBe(symbol);
    });

    it('currencyCode Input get and set', () => {
        expect(component.currencyCode).toBe(component.currencyCode);
        const code = 'EUR';
        component.currencyCode = code;
        expect(component.currencyCode).toBe(code);
    });

    it('disabled Input get and set', () => {
        expect(component.disabled).toBe(component.disabled);
        component.disabled = true;
        expect(component.disabled).toBeTruthy();
    })

    it('readOnly input get and set', () => {
        expect(component.readOnly).toBe(component.readOnly);
        component.readOnly = true;
        expect(component.readOnly).toBeTruthy();
    });

    it('showError Input get and set', () => {
        expect(component.showError).toBe(component.showError);
        const showError = true;
        component.showError = showError;
        expect(component.showError).toBeTruthy();
    });

    it('error Input get and set', () => {
        expect(component.error).toBe(component.error);
        const error = 'Fake error';
        component.error = error;
        expect(component.error).toBe(error);
    });

    //Host Bindings

    it('isDisabled HostBinding method', () => {
        component.disabled = true;
        expect(component.isDisabled).toBeTruthy();
        component.disabled = false;
        expect(component.isDisabled).toBeFalsy();
    });

    it('isInvalid HostBinding method', () => {
        component.invalidAmount = true;
        expect(component.isInvalid).toBeTruthy();
        component.invalidAmount = false;
        expect(component.isInvalid).toBeFalsy();
    });

    it('isBordered HostBinding method', () => {
        component.border = true;
        expect(component.isBordered).toBeTruthy();
        component.border = false;
        expect(component.isBordered).toBeFalsy();
    });

    //Methods

    it('amountToCurrency method', () => {
        expect(component.amountToCurrency('')).toBeUndefined();
        expect(component.amountToCurrency(12)).toBe('12.00');
        expect(component.amountToCurrency('12123123.1200')).toBe('12,123,123.12');
        expect(component.amountToCurrency('12412')).toBe('12,412.00');
    });

    it('amountToNumber', () => {
        expect(component.amountToNumber('')).toBe(0);
        expect(component.amountToNumber('12,123,123.12')).toBe(12123123.12);
        expect(component.amountToNumber('12.00')).toBe(12);
        expect(component.amountToNumber('12,567,123')).toBe(12567123);
    });

    it('validate method calls amountToNumber and amountToCurrency methods', () => {
        spyOn(component, 'amountToNumber');
        spyOn(component, 'amountToCurrency');
        component.validate('1');
        expect(component.amountToNumber).toHaveBeenCalled();
        expect(component.amountToCurrency).toHaveBeenCalledTimes(2);
    });

    it('validate method for valid amount', () => {
        const amount = ((component.min + component.max) / 2).toString();
        component.validate(amount);
        expect(component.errorMessage).toBe('');
        expect(component.border).toBeFalsy();
    });

    it('validate method for amount lesser than min', () => {
        const amount = (component.min - 1).toString();
        component.validate(amount);
        expect(component.border).toBeTruthy();
        expect(component.invalidAmount).toBeTruthy();
        expect(component.errorMessage).toBe(`La cantidad introducida debe ser mayor a ${component.currencySymbol} ${component.minAmountCurr} ${component.currencyCode}`);
    });

    it('validate method for amount greater than max', () => {
        component.max = 1;
        const amount = (component.max + 1).toString();
        component.validate(amount);
        expect(component.border).toBeTruthy();
        expect(component.invalidAmount).toBeTruthy();
        expect(component.errorMessage).toBe(`La cantidad introducida debe ser menor a ${component.currencySymbol} ${component.maxAmountCurr} ${component.currencyCode}`);
    });

    it('validate method for custom error', () => {
        component.showError = true;
        component.error = 'FakeError';
        component.validate('1');
        expect(component.border).toBeTruthy();
        expect(component.invalidAmount).toBeTruthy();
        expect(component.errorMessage).toBe(component.error);
    });

    it('validate with errorMessage emits onError output', () => {
        spyOn(component.onError, 'emit');
        component.showError = true;
        component.error = 'FakeError';
        component.validate('1');
        expect(component.onError.emit).toHaveBeenCalledWith(component.errorMessage);
    });

    it('changeEvent method with value emits onChange output', () => {
        spyOn(component, 'validate');
        spyOn(component.onChange, 'emit');
        component.value = '100';
        component.changeEvent();
        expect(component.validate).toHaveBeenCalledWith(component.value);
        expect(component.onChange.emit).toHaveBeenCalledWith(component.amountToNumber(component.value));
    });

    it('changeEvent method with no value emits clearInput output', () => {
        spyOn(component, 'validate');
        spyOn(component.clearInput, 'emit');
        component.value = '';
        component.changeEvent()
        expect(component.validate).toHaveBeenCalledWith(component.value);
        expect(component.value).toBe('');
        expect(component.clearInput.emit).toHaveBeenCalledWith(component.amountToNumber(component.placeholder));
    });

    it('focusEvent method with value emits onFocus output', () => {
        spyOn(component, 'validate');
        spyOn(component.onFocus, 'emit');
        const value = '100';
        component.value = value;
        component.focusEvent();
        expect(component.border).toBeTruthy();
        expect(component.validate).toHaveBeenCalledWith(value);
        expect(component.onFocus.emit).toHaveBeenCalledWith(component.amountToNumber(component.value));
    });

    it('focusEvent method with no value emits onFocus output', () => {
        spyOn(component, 'validate');
        spyOn(component.onFocus, 'emit');
        component.value = '';
        component.focusEvent();
        expect(component.border).toBeTruthy();
        expect(component.validate).toHaveBeenCalledWith(component.value);
        expect(component.onFocus.emit).toHaveBeenCalledWith(component.amountToNumber(component.placeholder));
    });

    it('blurEvent method with value emits onBlur output', () => {
        spyOn(component, 'validate');
        spyOn(component.onBlur, 'emit');
        const value = '100';
        component.value = value;
        component.blurEvent();
        expect(component.border).toBeFalsy();
        expect(component.validate).toHaveBeenCalledWith(value);
        expect(component.onBlur.emit).toHaveBeenCalledWith(component.amountToNumber(component.value));
    });

    it('blurEvent method with no value emits onBlur output', () => {
        spyOn(component, 'validate');
        spyOn(component.onBlur, 'emit');
        component.value = '';
        component.blurEvent();
        expect(component.border).toBeFalsy();
        expect(component.validate).toHaveBeenCalledWith(component.value);
        expect(component.onBlur.emit).toHaveBeenCalledWith(component.amountToNumber(component.placeholder));
    });

    it('enableClear method for disabled options', () => {
        component.readOnly = false;
        let enable: boolean;
        const value = 'Fake concept';
        const disabledValues = [true, false];
        disabledValues.forEach((dis) => {
            component.disabled = dis;
            enable = component.enableClear(value);
            if (component.disabled) {
                expect(enable).toBeFalsy();
            } else {
                expect(enable).toBeTruthy();
            }
        });
    });

    it('enableClear method for readOnly options', () => {
        component.disabled = false;
        let enable: boolean;
        const value = 'Fake concept';
        const readonlyValues = [true, false];
        readonlyValues.forEach((rea) => {
            component.readOnly = rea;
            enable = component.enableClear(value);
            if (component.readOnly) {
                expect(enable).toBeFalsy();
            } else {
                expect(enable).toBeTruthy();
            }
        });
    });

    it('enableClear method for different values', () => {
        component.disabled = false;
        component.readOnly = false;
        let enable: boolean;
        const amounts = ['', component.min.toString(), '1234'];
        amounts.forEach((amount) => {
            enable = component.enableClear(amount);
            if (amount && amount !== component.min.toString()) {
                expect(enable).toBeTruthy();
            } else {
                expect(enable).toBeFalsy();
            }
        });
    });

    it('clear method', () => {
        spyOn(component.clearButton, 'emit');
        spyOn(component, 'validate');
        component.clear();
        expect(component.border).toBeFalsy();
        expect(component.value).toBeNull();
        expect(component.invalidAmount).toBeFalsy();
        expect(component.clearButton.emit).toHaveBeenCalledWith(component.amountToNumber(component.placeholder));
        expect(component.validate).toHaveBeenCalledWith(component.placeholder);
    });

    it('iconClick method', () => {
        spyOn(component.iconPress, 'emit');
        const ev = new Event('click');
        component.iconClick(ev);
        expect(component.iconPress.emit).toHaveBeenCalledWith(ev);
    });

    it('infoClick method', () => {
        spyOn(component.infoPress, 'emit');
        const ev = new Event('click');
        component.infoClick(ev);
        expect(component.infoPress.emit).toHaveBeenCalledWith(ev);
    });

    it('ngOnInit', () => {
        spyOn(component, 'readonlyState');
        spyOn(component, 'validate');
        const value = '100';
        component.value = value;
        component.ngOnInit();
        expect(component.readonlyState).toHaveBeenCalled();
        expect(component.value).toBe(component.amountToNumber(value).toString());
        expect(component.validate).toHaveBeenCalledWith(component.value);
    });

    it('input HTML element has readonly attribute when readOnly is true', () => {
        component.readOnly = true;
        component.readonlyState();
        fixture.detectChanges();
        const input = fixture.debugElement.query(By.css('input'));
        expect(input.nativeElement.getAttribute('readonly')).toBeTruthy();
        expect(input.nativeElement.getAttribute('tabindex')).toBe('-1');
    });

    it('change event over input element calls changeEvent() method', async () => {
        spyOn(component, 'changeEvent');
        fixture.detectChanges();
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.nativeElement.dispatchEvent(new Event('input'));
        expect(component.changeEvent).toHaveBeenCalled();
    });

    it('blur event over input HTML element calls blurEvent() method', () => {
        spyOn(component, 'blurEvent');
        fixture.detectChanges();
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.triggerEventHandler('blur', null);
        expect(component.blurEvent).toHaveBeenCalled();
    });

    it('focusout event over input HTML element calls blurEvent() method', () => {
        spyOn(component, 'blurEvent');
        fixture.detectChanges();
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.triggerEventHandler('focusout', null);
        expect(component.blurEvent).toHaveBeenCalled();
    });

    it('focusin event over input HTML element calls focusEvent() method', () => {
        spyOn(component, 'focusEvent');
        fixture.detectChanges();
        inputEl = fixture.debugElement.query(By.css('input'));
        inputEl.triggerEventHandler('focusin', null);
        expect(component.focusEvent).toHaveBeenCalled();
    });

    it('placeholder attribute on input HTML element is setted', () => {
		fixture.detectChanges();
		inputEl = fixture.debugElement.query(By.css('input'));
		expect(inputEl.nativeElement.placeholder).toBe(component.placeholder);
	});

    it('input element disabled attribute', () => {
        fixture.detectChanges();
        inputEl = fixture.debugElement.query(By.css('input'));
        const disabled = inputEl.nativeElement.disabled;
        expect(disabled).toBe(component.disabled);
    });

    it('clear-button div does not render when enableClean is false', () => {
        fixture.detectChanges();
        divEl = fixture.debugElement.query(By.css('.clear-button'));
        expect(component.enableClear(component.value)).toBe(false);
        expect(divEl).toBeNull();
    });

    it('clear-button div renders when enableClean is true', () => {
        component.value = '1000';
        fixture.detectChanges();
        divEl = fixture.debugElement.query(By.css('.clear-button'));
        expect(component.enableClear(component.value)).toBe(true);
        expect(divEl).not.toBeNull();
    });

    it('click event on clear-button div calls clear() method', () => {
        spyOn(component, 'clear');
        component.value = '1000';
        fixture.detectChanges();
        divEl = fixture.debugElement.query(By.css('.clear-button'));
        divEl.nativeElement.click();
        expect(component.clear).toHaveBeenCalled();
    });

    it('label tag renders label', () => {
        fixture.detectChanges();
        labelEl = fixture.debugElement.query(By.css('.amount-label'));
        expect(labelEl.nativeElement.innerHTML).toContain(component.label);
    });

    it('label tag renders currencyCode', () => {
        fixture.detectChanges();
        labelEl = fixture.debugElement.query(By.css('.amount-label'));
        expect(labelEl.nativeElement.innerHTML).toContain(component.currencyCode);
    });

    it('currency-symbol span renders currencySymbol', () => {
        fixture.detectChanges();
        spanEl = fixture.debugElement.query(By.css('.currency-symbol'));
        expect(spanEl.nativeElement.innerHTML).toContain(component.currencySymbol);
    });

	it('input HTML element has readonly attribute when readOnly is true', () => {
		component.readOnly = true;
		component.readonlyState();
		fixture.detectChanges();
		const input = fixture.debugElement.query(By.css('input'));
		expect(input.nativeElement.getAttribute('readonly')).toBeTruthy();
		expect(input.nativeElement.getAttribute('tabindex')).toBe('-1');
	});

	it('input HTML element has not readonly attribute when readOnly is true', () => {
		component.readOnly = false;
		component.readonlyState();
		fixture.detectChanges();
		const input = fixture.debugElement.query(By.css('input'));
		expect(input.nativeElement.getAttribute('readonly')).toBeFalsy();
	});
});
