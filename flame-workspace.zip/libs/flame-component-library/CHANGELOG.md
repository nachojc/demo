# flame-component-library
## (2019-07-05)
## Avatar.
  -Se reducen los tipos dentro del avatar. solo utiliza tipo 1 si se quiere mostrar la información en vertical.
  -El avatar ahora toma shortname si existe para generar el monograma dentro del circulo y mostrarlo en la primera linea de la descripción.
  -Ahora se muestran todos los inputs que recibe el avatar. si se requieren mostrar menos datos, se tiene el input lines que define cuantas lineas de las existentes se deben mostrar.
  -El componente ahora espera que fullname sea diferente de undefined para cambiar del estado _skeleton_
  -El orden en que se muestra los detalles del input es __shortname__, __fullname__, __accountnumber__, __bank__, __description__, __clientcode__. Ejemplo:
Antes:
```html
<sn-avatar 
fullname="Mayra Paola Romero Camacho" 
bank="BANCOMER" 
accountnumber="1111 2222 3333 4444" 
shortname="Mayra P" 
[typeavatar]="0" 
(selectedEvent)="catchEvent($event)">
</sn-avatar>
Ahora:
```html
<sn-avatar
[fullname]="clientName"
[bank]="clientBank"
[accountnumber]="clientAccount"
[shortname]="clientAlieas"
(selectedEvent)="catchEvent($event)">
</sn-avatar>
```

## (2019-07-08)
## Card
Se añadió catálogo de tarjetas dentro de catálogo de componentes, en el siguiente directorio: UI Components -> Atoms -> card
Para poder hacer uso, se ha cambiado la propiedad **type**, por **imageId**; que es el código obtenido en el catálogo de tarjetas.
Antes:
```html
<sn-card
	type="amex"
	[available]="1299.90"
	account="**** **** **** 3901"
	name="American Express"
	currency='MXN'
></sn-card>
```
Ahora:
```html
<sn-card
	imageId="75290302460"
	[available]="1299.90"
	account="**** **** **** 3901"
	name="American Express"
	currency='MXN'
></sn-card>

```

## Product

Se ha eliminado el pipe `cardNumber` del comportamiento interno del componente, en caso de querer separación del numbero de cuenta (`account`), se deberá usar en la llamada al componente. Por ejemplo, si se desea usar en `account-movement`:

```html
<sn-product
	readonly
	[displayName]="data.product.card_name"
	[account]="data.product.card_number ? (data.product.card_number | cardNumber) : (detail.display_number | cardNumber)"
	accordion="true"
	[type]="data.product.card_image"
	transfer="true"
>
</sn-product>
```

Recuerden que, para poder usar dicho Pipe, deben importar su módulo en el módulo de la libreria  correspondiente, como se detallo en el CHANGELOG (día 2019-06-14)

## (2019-07-02)
## snackbar
Se refactorizó el componente internamente. Se actualizó la documentación. El único cambio en la implementacion fué: **posMarker** (Propiedad) por **#posMaker** (Identificador).
Antes:
```html
<div class="example" [snSnackBar]="snackInterface">
	<div class="text-center" >
		<h3>Titulo</h3>
	</div>
	<p class="sn-number lvl-1" posMarker>
		Lorem ipsum, dolor sit amet consectetur adipisicing elit.
	</p>
</div>
```
Ahora:
```html
<div class="example" [snSnackBar]="snackInterface">
	<div class="text-center" >
		<h3>Titulo</h3>
	</div>
	<p class="sn-number lvl-1" #posMarker>
		Lorem ipsum, dolor sit amet consectetur adipisicing elit.
	</p>
</div>
```

## (2019-06-26)

## Icon-Button

Icon button ahora permite al desarrollador agregar sus propios estilos, totalmente personalizables, ya sea de tamaño, color, etc. Este cambio, deja de limitar a usar temas específicos así como tamaños definidos, ahora el desarrollador puede implementarlos según lo necesite.
Los estilos se deben agregar directamente en la operativa. Ejemplo:
Antes:

```html
<sn-icon-button
	title="Buscar"
	icon="sn-FUNC71"
	size="lg"
	theme="white"
></sn-icon-button>
Ahora:

```html
<sn-icon-button
	title="Buscar"
	icon="sn-FUNC71"
></sn-icon-button>
```

```css
:host ::ng-deep {
	.sn-icon-button-icon {
		width: 44px;
		height: 44px;
		background: var(--sn-icon-button__background-color-invert, #ffffff);

		sn-icon {
			font-size: 20px;
			.sn-FUNC71 {
				font-size: 20px;
			}
		}
	}

	.sn-icon-button-name {
		font-size: 10px;
	}
```

## (2019-06-21)

Se ha quitado el color del background del `sn-top-bar` `.sn-top-bar` del archivo `apps/user-mobile/src/styles.scss` porque creaba conflicto para cambiar el color del fondo del componente. Deberemos de definirlo siempre que queramos.

```css
//Lineas quitadas: apps/user-mobile/src/styles.scss
sn-top-bar {
  .sn-top-bar {
    background-color: #e5e5e5;
  }
}
```

Y también se ha quitado del `top-bar.component.scss` la clase `.sn-top-bar` donde se definia un color y puede crear un conflicto.

```css
//Lineas quitadas: libs/flame-component-library/src/lib/molecules/top-bar/top-bar.component.scss
.sn-topbar {
	background-color: var(--sn-background-color__secondary);
}
```

Revisad todos los `sn-top-bar` y la clase `.sn-top-bar` para ver si el color de fondo es correcto.

## Card

Se agregó el CurrencyPipe en el componente Card, a su input `available`. Al tratarse de un input numérico, el componente, a partir de ahora, convertirá el valor numérico a su correspondiente valor monetario, en función de la moneda elegida, a través del input `currency`.

 Antes: 
 ```html
<sn-card 
	[type]="card.type" 
	[available]="card.balance.amount | number: '.2'"
	[currency]="card.balance.currency_code" 
	[account]="card.display_number" 
	[flipped]="card.flipped"
	[blocked]="card.status !== 'AVAILABLE'" 
	(click)="card.action(i, smSliderView)">
 </sn-card>
 ```

 Ahora:
 ```html
<sn-card 
	[type]="card.type" 
	[available]="card.balance.amount"
	[currency]="card.balance.currency_code" 
	[account]="card.display_number" 
	[flipped]="card.flipped"
	[blocked]="card.status !== 'AVAILABLE'" 
	(click)="card.action(i, smSliderView)">
 </sn-card>
 ```

## (2019-06-21)

## SnLoaderOverlay

Se ha agregado el componente sn-loader-overlay a catálogo de servicios. Exponiendo dos métodos, open y close, dónde permite abrir o cerrar respectivamente un overlay que cubre toda la pantalla, que muestra un spinner cargando y un mensaje personalizado. Se ha agregado la documentación de uso respectiva en catálogo de componentes -> UI componentes -> Servicios -> Loader Overlay.
El ejemplo básico es el siguiente:
Importar LoaderOverlayModule en el módulo donde se desea usar el servicio.

```js
import { OverlayModule } from '@santander/flame-core-library';
	@NgModule({
		imports: [
		...,
		LoaderOverlayModule
	],
	providers: [
		LoaderOverlayService
	]
})
```
Se importa el servicio, creando una instancia en el constructor. Se puede invocar la función open y close para abrir y cerrar respectivamente el Overlay.

```js
import { LoaderOverlayService } from '@santander/flame-core-library';
	import { LoaderOverlayService } from '@santander/flame-component-library';
	import { timer } from 'rxjs';

	constructor(private _loaderOverlayService: LoaderOverlayService) { }

	openLoader() {
		const overlayRef = this._loaderOverlayService.open();
		timer(1000).subscribe(() => {
			overlayRef.close();
		});
	}
```

Agregar estilo del Overlay a styles.scss de la raiz de la aplicación.
```css
	.cdk-overlay-backdrop.cdk-overlay-backdrop-showing {
		&.loader-backdrop {
			opacity: 0.7;
			background-color: #000000;
		}
	}
```

Un ejemplo de uso a través del evento click de un botón.
`<button sn-button (click)="openLoader()">Abrir Loader Overlay</button>`;

## (2019-06-XX)

## SnCurrencyMaskConfig

Según la última versión de UX, el amount field tiene un formato de '0.00' por defecto, por lo que se ha actualizado la propiedad `intergers` a `1` del `SnCurrencyMaskConfig` en todo el proyecto.

## Chip

Se ha eliminado el cambio de estado del chip cuando se hace click sobre el componente de manera interna. Será el desarrollador quién, a partir de ahora, tendrá que configurar el cambio de estado si así se requiere en la funcionalidad de su operativa.

## Motive-field

Se ha añadido un filtro que sustituye los  carácteres acentuados por esos carácteres sin acentuar cuando se escribe o cuando se hace un blur. Por tanto, no es necesario introducir en `invalidChars` los carácteres acentuados, ya que se autocorrige.
Por favor, aquellos que empleais los acentos como carácteres invalidos, quitadlos de dicho input.


## (2019-06-17)

## Capitalize Pipe
Se ha añadido un Pipe `capitalize` para transformar cualquier string al formato primera letra en mayúscula y el resto en minúsculas.
Para implementarlo, en el module.ts correspondiente:

```js
import { CapitelizeModule } from '@santander/flame-component-library';
....
@NgModule({
  imports: [
    ....,
    CapitelizeModule
   ],
 ...
})
```

En el template se usa del siguiente modo:
```html
{{ displayName | capitalize }}
```

Se ha implementado en el componente Product (y por tanto las moléculas que dependen de estos).

Del mismo modo, si se usa el pipe, tambien hay que importarlo en el archivo de tests unitarios correspondiente (.spec.ts), del siguiente modo:

```js
import { CapitelizeModule } from '@santander/flame-component-library';
...
describe('...', () => {
	...
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [...,
				CapitelizeModule
				],
			...
		}).compileComponents();
	}));
})
```

## Refactor del componente Product (IMPORTANTE)

Se ha añadido el currency pipe dentro del componente Product. Como se muestra a continuación, hasta ahora era el desarrollador quien hacia la conversión sobre el atributo amount del componente. A partir de ahora, simplemente con poner correctamente el currency code, atributo `currency`, el componente se encarga de transformarlo.

Antes:

```html
<sn-product
    [account]="product.display_number"
    [amount]="(product.balance.amount | currency:'$':'symbol':'.2')"
    [currency]="product.balance.currency_code"
    [displayName]="product.description"
    [type]="product.image"
    (click)="navigateProduct(product)"
	accordion="true">
</sn-product>
```
Ahora:

```html
<sn-product
    [account]="product.display_number"
    [amount]="product.balance.amount"
    [currency]="product.balance.currency_code"
    [displayName]="product.description"
    [type]="product.image"
    (click)="navigateProduct(product)"
	accordion="true">
</sn-product>
```
A PARTIR DE AHORA NO TENEIS QUE PREOCUPAROS DE APLICAR UN PIPE AL `amount`, SE HACE INTERNAMENTE.
IMPORTANTE CAMBIARLO EN TODAS LAS OPERATIVAS QUE LLAMEN A `sn-prodcut`, DE LO CONTRARIO NO SE VISUALIZARA EL AMOUNT.


## (2019-06-14)

Se ha añadido un Pipe `cardNumber` para formatear y espaciar el número de cuenta.
Para implementarlo, en el module.ts correspondiente:

```js
import { CardNumberModule } from '@santander/flame-component-library';
....
@NgModule({
  imports: [
    ....,
    CardNumberModule
   ],
 ...
})
```

En el template se usa del siguiente modo:
```html
{{ account | cardNumber }}
```

Se ha implementado en los componentes: Card, Product (y por tanto las moléculas que dependen de estos).

Del mismo modo, si se usa el pipe, tambien hay que importarlo en el archivo de tests unitarios correspondiente (.spec.ts), del siguiente modo:

```js
import { CardNumberModule } from '@santander/flame-component-library';
...
describe('...', () => {
	...
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [...,
				CardNumberModule
				],
			...
		}).compileComponents();
	}));
})
```
## (2019-06-13)

### SnCurrencyMaskConfig

Se modificó la interfaz SnCurrencyMaskConfig. Se agregó un atributo llamado *integers*, por defecto = 2.
Este atributo permite controlar la cantidad de enteros (lado izquierda del punto) en la máscara Currency. Ejemplo:
integers = 1: 0.00
integers = 2: 00.00

El cambio se hace a nivel module de cada operativa, dentro de imports.

Antes:

```js
imports: [
	SnCurrencyModule.forRoot({
			align: 'right',
			allowNegative: false,
			allowZero: true,
			decimal: '.',
			precision: 2,
			prefix: '',
			suffix: '',
			thousands: ',',
			nullable: true
		})
]
```
Ahora:

```js
SnCurrencyModule.forRoot({
			align: 'right',
			allowNegative: false,
			allowZero: true,
			decimal: '.',
			precision: 2,
			prefix: '',
			suffix: '',
			thousands: ',',
			nullable: true,
			integers: 2
		})
```

## (2019-06-03)

### sn-icon-button

Se cambió el parámetro `invert_theme` por sólo `theme`, el cuál aceptará tipo "gray" (default) y "white" definidos en zeplin, esto con el objetivo que el nombre del parámetro sea intuitivo, acorde y bien; si más adeltante se agrega otro tema, sólo bastaría con ingresar el nuevo tipo.

Antes se realizaba de la siguiente manera:

```html
<sn-icon-button
  title="Buscar"
  icon="sn-FUNC71"
  invert_theme="true"
></sn-icon-button>
```

Ahora:

```html
<sn-icon-button title="Buscar" icon="sn-FUNC71" theme="white"></sn-icon-button>
```

### sn-token-dialog

Se modificó la forma de usar token dialog (Tanto para directiva como servicio) dados los nuevos requerimientos definidos de UX/UI.
Ahora se permite crear una clase personalizada (abstracción) para ser inyectada en el body del diálogo. De igual manera se parametrizó el tipo de botón (slide o básico), el texto del título, subtítulo, label del botón cerrar y opción a mostrar o no el token input.
Se agregó la documentación completa, así como ejemplos en el catálogo de componentes: ui-components/molecules/token-dialog.

Antes se realizaba de la siguiente manera en directiva:

```html
<button
  sn-button
  smTokendialog
  [statusSlide]="statusSlide"
  [closedialog]="hideDialogToken"
  (dialogstate)="dialogTokenEvent($event)"
  (confirm)="confirmTokenEvent($event)"
>
Abrir Token Dialog
</button>
```

Ahora:

```html
<button
  sn-button
  smTokendialog
  [statusSlide]="statusSlide"
  [closedialog]="hideDialogToken"
  (dialogstate)="dialogTokenEvent($event)"
  (confirm)="confirmTokenEvent($event)"
  [title]="'Confirma esta operación'"
  [subtitle]="'Transferencia sin costo'"
  [showTokenInput]="true"
  [typeButton]="'slide'"
  [customBody]="customBody"
>
Abrir Token confirm
</button>
```

Antes se realizaba de la siguiente manera para servicio:

```js
this.tokendialogService.openDialogToken();
```

Ahora

```js
const params: CustomToken = {
  subtitle: 'Transferencia sin costo',
  showTokenInput: true,
  typeButton: 'basic',
  customBody: CustomTokenContentComponent
};
this.tokendialogService.openDialogToken(params);
```

## (2019-05-20)

### sn-button

Se ha cambiado la forma de declarar los botones personalizados.

Antes se realizaba de la siguiente manera:

```html
<button sn-button class="small">small</button>
<button sn-button class="full">full</button>
<button sn-button class="large">large</button>
<button sn-button class="strech">strech</button>
<button sn-button class="outlined">outlined</button>
```

y ahora:

```html
<button sn-button-small>small</button> <button sn-button-full>full</button>
<button sn-button-large>large</button> <button sn-button-strech>strech</button>
<button sn-button-outlined>outlined</button>
```

Se han añadido botones secundarios:

```html
<button sn-button-secondary>Secondary</button>
<button sn-button-secondary disabled>Secondary</button>
```

### sn-theme

Las variables de estilos de tema viejas (Deprecated) han sido eliminadas.

### sn-form-field

Se ha suprimido el atributo clearable, ya que el icono clear se mostrará siempre que se introduzca algun valor sobre el input (y no esté disabled o readonly).

Antes:

```html
<sn-form-field clearable="true"></sn-form-field>
```

Ahora:

```html
<sn-form-field></sn-form-field>
```

El atributo list = “true” ya no existe, para aplicar los estilos de LIST se usará apparence, del siguiente modo:

Antes:

```html
<sn-form-field list="true" clearable="true">
	<input
		sn-input
		type="text"
		id="numReference"
		placeholder="No. de referencia"
		maxlength="7"
		autocomplete="off"
		formControlName="numReference"
	/>
</sn-form-field>
```

Ahora:

```html
<sn-form-field apparence="list">
	<input
		sn-input
		type="text"
		id="numReference"
		placeholder="No. de referencia"
		maxlength="7"
		autocomplete="off"
		formControlName="numReference"
	/>
</sn-form-field>
```

Se ha añadido una nueva apariencia GHOST, para usarla:

```html
<sn-form-field apparence="ghost">
	<input
		sn-input
		type="text"
		id="numReference"
		placeholder="No. de referencia"
		maxlength="7"
		autocomplete="off"
		formControlName="numReference"
	/>
</sn-form-field>
```

## (2019-05-8)

### sn-icon

Se ha homogeneizado el uso de los iconos, a partir de ahora, todas las llamadas a un icono se realizaran con el nombre estándar (sn-XXXX):

Antes:

```html
<sn-icon icon="close" />
```

Ahora:

```html
<sn-icon icon="sn-FUNC31" />
```

### sn-theme

Se ha reformulado el nombre de las variables de estilo, y se han añadido nuevas para poder aplicar nuevos temas.
En flame-foundation.theme.ts tenéis una lista de las nuevas variables que podéis usar a partir de ahora.

    IMPORTANTE
    Las variables que estan en *DEPRECATED* serán eliminadas en la siguiente versión.

### sn-amount-field

Refactor completo del componente amount-field

Se ha cambiado la forma de invocar al selector. Ahora se realizara de la siguiente forma:

```html
<sn-amount-field label="Ingresa una cantidad en MXN">
	<input snAutowidthinput snCurrencyMask [(ngModel)]="amount" type="text" />
</sn-amount-field>
```

Ahora el desarrollador tiene el control sobre el input, pudiendo añadir `ngModel`,o un `formControlName` de la siguiente forma:

```html
<form [formGroup]="formDefault">
	<sn-amount-field label="Ingresa una cantidad en MXN">
		<input
			snAutowidthinput
			snCurrencyMask
			formControlName="amount"
			type="text"
		/>
		<div errors snErrors="amount">
			<div snError="max" [when]="['dirty', 'touched']">
				No tienes suficiente dinero
			</div>
			<div snError="min" when="touched">
				La cantidad debe de ser mayor que 10
			</div>
		</div>
	</sn-amount-field>
</form>
```

```typescript
this.formDefault = this.formBuilder.group({
	amount: [14.12, [Validators.required, Validators.max(10)]]
});
```

Ahora se puede añadir validadores de Angular, para validar los valores maximos y minimos, los disabled, los required... y vaidadores custom.

Tambien se añade la posibilidad de poder crear varios mensajes para cada uno de los errores definidos.

    IMPORTANTE
    Es obligatorio el uso de un elemento de control (ngModel, o formControlName), ya que no tiene sentido el uso de este componente sin esas propiedades. (editado)
