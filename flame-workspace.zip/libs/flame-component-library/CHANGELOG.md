# flame-component-library

## (2019-06-03)

### sn-icon-button

Se cambió el parámetro `invert_theme` por sólo `theme`, el cuál aceptará tipo "gray" (default) y "white" definidos en zeplin, esto con el objetivo que el nombre del parámetro sea intuitivo, acorde y bien; si más adeltante se agrega otro tema, sólo bastaría con ingresar el nuevo tipo.

Antes se realizaba de la siguiente manera:

```html
<sn-icon-button
  title="Buscar"
  icon="sn-FUNC71"
  invert_theme="true"
></sn-icon-button>
```

Ahora:

```html
<sn-icon-button title="Buscar" icon="sn-FUNC71" theme="white"></sn-icon-button>
```

### sn-token-dialog

Se modificó la forma de usar token dialog (Tanto para directiva como servicio) dados los nuevos requerimientos definidos de UX/UI.
Ahora se permite crear una clase personalizada (abstracción) para ser inyectada en el body del diálogo. De igual manera se parametrizó el tipo de botón (slide o básico), el texto del título, subtítulo, label del botón cerrar y opción a mostrar o no el token input.
Se agregó la documentación completa, así como ejemplos en el catálogo de componentes: ui-components/molecules/token-dialog.

Antes se realizaba de la siguiente manera en directiva:

```html
<button
  sn-button
  smTokendialog
  [statusSlide]="statusSlide"
  [closedialog]="hideDialogToken"
  (dialogstate)="dialogTokenEvent($event)"
  (confirm)="confirmTokenEvent($event)"
>
	Abrir Token Dialog
</button>
```

Ahora:

```html
<button
  sn-button
  smTokendialog
  [statusSlide]="statusSlide"
  [closedialog]="hideDialogToken"
  (dialogstate)="dialogTokenEvent($event)"
  (confirm)="confirmTokenEvent($event)"
  [title]="'Confirma esta operación'"
  [subtitle]="'Transferencia sin costo'"
  [showTokenInput]="true"
  [typeButton]="'slide'"
  [customBody]="customBody"
>
Abrir Token confirm
</button>
```

Antes se realizaba de la siguiente manera para servicio:

```js
this.tokendialogService.openDialogToken();
```

Ahora

```js
const params: CustomToken = {
  subtitle: 'Transferencia sin costo',
  showTokenInput: true,
  typeButton: 'basic',
  customBody: CustomTokenContentComponent
};
this.tokendialogService.openDialogToken(params);
```

## (2019-05-20)

### sn-button

Se ha cambiado la forma de declarar los botones personalizados.

Antes se realizaba de la siguiente manera:

```html
<button sn-button class="small">small</button>
<button sn-button class="full">full</button>
<button sn-button class="large">large</button>
<button sn-button class="strech">strech</button>
<button sn-button class="outlined">outlined</button>
```

y ahora:

```html
<button sn-button-small>small</button> <button sn-button-full>full</button>
<button sn-button-large>large</button> <button sn-button-strech>strech</button>
<button sn-button-outlined>outlined</button>
```

Se han añadido botones secundarios:

```html
<button sn-button-secondary>Secondary</button>
<button sn-button-secondary disabled>Secondary</button>
```

### sn-theme

Las variables de estilos de tema viejas (Deprecated) han sido eliminadas.

### sn-form-field

Se ha suprimido el atributo clearable, ya que el icono clear se mostrará siempre que se introduzca algun valor sobre el input (y no esté disabled o readonly).

Antes:

```html
<sn-form-field clearable="true"></sn-form-field>
```

Ahora:

```html
<sn-form-field></sn-form-field>
```

El atributo list = “true” ya no existe, para aplicar los estilos de LIST se usará apparence, del siguiente modo:

Antes:

```html
<sn-form-field list="true" clearable="true">
	<input
		sn-input
		type="text"
		id="numReference"
		placeholder="No. de referencia"
		maxlength="7"
		autocomplete="off"
		formControlName="numReference"
	/>
</sn-form-field>
```

Ahora:

```html
<sn-form-field apparence="list">
	<input
		sn-input
		type="text"
		id="numReference"
		placeholder="No. de referencia"
		maxlength="7"
		autocomplete="off"
		formControlName="numReference"
	/>
</sn-form-field>
```

Se ha añadido una nueva apariencia GHOST, para usarla:

```html
<sn-form-field apparence="ghost">
	<input
		sn-input
		type="text"
		id="numReference"
		placeholder="No. de referencia"
		maxlength="7"
		autocomplete="off"
		formControlName="numReference"
	/>
</sn-form-field>
```

## (2019-05-8)

### sn-icon

Se ha homogeneizado el uso de los iconos, a partir de ahora, todas las llamadas a un icono se realizaran con el nombre estándar (sn-XXXX):

Antes:

```html
<sn-icon icon="close" />
```

Ahora:

```html
<sn-icon icon="sn-FUNC31" />
```

### sn-theme

Se ha reformulado el nombre de las variables de estilo, y se han añadido nuevas para poder aplicar nuevos temas.
En flame-foundation.theme.ts tenéis una lista de las nuevas variables que podéis usar a partir de ahora.

    IMPORTANTE
    Las variables que estan en *DEPRECATED* serán eliminadas en la siguiente versión.

### sn-amount-field

Refactor completo del componente amount-field

Se ha cambiado la forma de invocar al selector. Ahora se realizara de la siguiente forma:

```html
<sn-amount-field label="Ingresa una cantidad en MXN">
	<input snAutowidthinput snCurrencyMask [(ngModel)]="amount" type="text" />
</sn-amount-field>
```

Ahora el desarrollador tiene el control sobre el input, pudiendo añadir `ngModel`,o un `formControlName` de la siguiente forma:

```html
<form [formGroup]="formDefault">
	<sn-amount-field label="Ingresa una cantidad en MXN">
		<input
			snAutowidthinput
			snCurrencyMask
			formControlName="amount"
			type="text"
		/>
		<div errors snErrors="amount">
			<div snError="max" [when]="['dirty', 'touched']">
				No tienes suficiente dinero
			</div>
			<div snError="min" when="touched">
				La cantidad debe de ser mayor que 10
			</div>
		</div>
	</sn-amount-field>
</form>
```

```typescript
this.formDefault = this.formBuilder.group({
	amount: [14.12, [Validators.required, Validators.max(10)]]
});
```

Ahora se puede añadir validadores de Angular, para validar los valores maximos y minimos, los disabled, los required... y vaidadores custom.

Tambien se añade la posibilidad de poder crear varios mensajes para cada uno de los errores definidos.

    IMPORTANTE
    Es obligatorio el uso de un elemento de control (ngModel, o formControlName), ya que no tiene sentido el uso de este componente sin esas propiedades. (editado)
