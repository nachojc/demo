import { TransitionsBeneficiaryAnimations, VoucherBeneficiaryInAnimation } from './transitions/transitions.animations';

export const RouterBeneficiaryAnimations = [
  TransitionsBeneficiaryAnimations,
  VoucherBeneficiaryInAnimation
]
