import {
  trigger,
  animate,
  transition,
  animateChild,
  style,
  state,
  query,
  stagger
} from '@angular/animations';

export const easing = {
	standard: 'cubic-bezier(0.75, 0, 0.75, 1)',
	list : 'cubic-bezier(.8, -0.6, 0.2, 1.5)'
};
  
//Animacion del search bar
export const bottomToTopSlideUpAnimation = trigger('hideElementMove', [
    state('out', style({ opacity: '0', height: '0px', padding:'0 0 0 0', margin: '0 0 0 0' })),
    state('in', style({ height: '*'})),
    transition('* => out', animate('0.45s ' + easing.standard)),
    transition('out => in', animate('0.45s ' + easing.standard))
]);

//Animacion de cada elemento de la lista
export const bottomToTopItemAnimation = trigger('beneficiaryItemsMove',[
    transition(':enter',[
        style({transform: 'translateY(100px)', opacity: '0'}),
        animate('1s ' + easing.list, style({transform: 'translateY(0px)', opacity: '1'})),
    ]),
    transition(':leave', [
        style({ transform: 'translateY(100px)', opacity: '1' }),
        animate('.2s ' + easing.list, style({ transform: 'translateY(0px)', opacity: '0' })) 
    ]),
    
]);

//Animacion del container de la lista
export const childListAnimation = trigger('beneficiaryListMove', [
    transition('* => *', [
      query(':enter', style({ opacity: 0 }), { optional: true }),
      query('@beneficiaryItemsMove', stagger(30, animateChild()))
    ])
])



