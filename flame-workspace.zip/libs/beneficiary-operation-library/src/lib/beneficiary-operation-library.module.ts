import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {
	FlameFoundationTheme,
	ThemeModule,
	FormFieldModule,
	InputModule,
	IconButtonModule,
	IconModule,
	ButtonModule,
	TopBarModule,
	AvatarModule,
	EmojiModule,
	DialogSelectModule,
	TokenDialogService,
	TokenDialogModule,
	ChipModule,
	ProductModule,
	HiddenButtonsModule,
	SearchBarModule
} from '@santander/flame-component-library';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BeneficiaryViewComponents } from './views/beneficiary-views-components';
import { BeneficiaryOperationLibraryRoutingModule } from './beneficiary-operation-library.router.module';
import { BeneficiaryService } from './services/beneficiary-operation.service';
import { PayeesContainerComponent } from './views/payees-container/payees-container.component';
import { BeneficiaryFilterPipe } from './pipes/beneficiary-filter.pipe';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services';

@NgModule({
	imports: [
		AvatarModule,
		BeneficiaryOperationLibraryRoutingModule,
		ButtonModule,
		CommonModule,
		DialogSelectModule,
		EmojiModule,
		FormFieldModule,
		FormsModule,
		IconModule,
		IconButtonModule,
		InputModule,
		ReactiveFormsModule,
		ChipModule,
		ProductModule,
		ThemeModule.forRoot({
			themes: [FlameFoundationTheme],
			active: 'flame-foundation'
		}),
		TokenDialogModule,
		TopBarModule,
		HiddenButtonsModule,
		SearchBarModule
	],
	declarations: [...BeneficiaryViewComponents, BeneficiaryFilterPipe],
	entryComponents: [],
	providers: [BeneficiaryService, TokenDialogService, SummaryService],
	exports: [PayeesContainerComponent]
})
export class BeneficiaryOperationLibraryModule {}
