import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BeneficiaryViewComponent } from './views/beneficiary-view/beneficiary-view.component';
import { BeneficiaryInfoViewComponent } from './views/beneficiary-info/beneficiary-info-view.component';
import { BeneficiaryVoucherViewComponent } from './views/beneficiary-voucher/beneficiary-voucher-view.component';
import { BeneficiaryEditComponent } from './views/beneficiary-edit/beneficiary-edit.component';
import { PayeesContainerComponent } from './views/payees-container/payees-container.component';

const routes: Routes = [
  {
    path: 'user-account',
    component: BeneficiaryViewComponent
  },{
    path: 'info',
    component: BeneficiaryInfoViewComponent
  },{
    path: 'voucher',
    component: BeneficiaryVoucherViewComponent,
		data: { num: 82 }
  },
  {
    path: 'edit',
    component: BeneficiaryEditComponent
  },
  {
    path: 'payees',
    component: PayeesContainerComponent
  }
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class BeneficiaryOperationLibraryRoutingModule {}
