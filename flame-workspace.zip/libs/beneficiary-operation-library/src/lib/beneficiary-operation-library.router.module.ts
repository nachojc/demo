import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BeneficiaryViewComponent } from './views/beneficiary-view/beneficiary-view.component';
import { BeneficiaryInfoViewComponent } from './views/beneficiary-info/beneficiary-info-view.component';
import { BeneficiaryVoucherViewComponent } from './views/beneficiary-voucher/beneficiary-voucher-view.component';
import { BeneficiaryEditComponent } from './views/beneficiary-edit/beneficiary-edit.component';
import { PayeesContainerComponent } from './views/payees-container/payees-container.component';

const routes: Routes = [
  {
    path: 'info',
    component: BeneficiaryInfoViewComponent,
    data : { num: 41 }
  },
  {
    path: 'user-account',
    component: BeneficiaryViewComponent,
    data : { num: 42 }
  },
  {
    path: 'edit',
    component: BeneficiaryEditComponent,
    data : { num: 43 }
  },
  {
    path: 'payees',
    component: PayeesContainerComponent,
    data : { num: 44 }
  },
  {
    path: 'voucher',
    component: BeneficiaryVoucherViewComponent,
    data: { num: 49 }
  },
];

@NgModule({
	imports: [RouterModule.forChild(routes)],
	exports: [RouterModule]
})
export class BeneficiaryOperationLibraryRoutingModule {}
