export interface BeneficiaryInterface {
  identifier: {
    key: String;
    value: String;
  };
  bank: String;
  beneficiary: String;
  alias: String;
  limit: {
    amount: String;
    currency: String;
  };
  RFC: String;
  date: Date;
  reference: String;
}
