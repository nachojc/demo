import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'beneficiaryProductsFilter'})
export class BeneficiaryProductsFilterPipe implements PipeTransform {
  transform(value: Array<any>, filter: string): any {
    const newArray = {
      products : []
    };
    if (filter.length > 0){
        const search_products: Array<any> = value.filter((item) => {
          if(item.display_number.toLowerCase().includes(filter.toLowerCase())
          || item.description.toLowerCase().includes(filter.toLowerCase())){
            return true;
          } else {
            return false;
          }
        });
      
        newArray.products = search_products;
      return newArray;
    }else{
      return newArray;
    }
  }
}
