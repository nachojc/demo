import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
	name: 'beneficiaryFilter',
	pure: false
})
export class BeneficiaryFilterPipe implements PipeTransform {
    public itemArr:any[];

    transform(items: any[], term: string = ''): any {
        term = term.toLowerCase();
        return items.filter(item => {
            if( item.alias.toLowerCase().indexOf(term) !== -1 ||
                item.name.toLowerCase().indexOf(term) !== -1 ||
                item.account.number.toLowerCase().indexOf(term) !== -1 ||
                item.account.bank.toLowerCase().indexOf(term) !== -1)
                return true
            return false
        });
    }
}
