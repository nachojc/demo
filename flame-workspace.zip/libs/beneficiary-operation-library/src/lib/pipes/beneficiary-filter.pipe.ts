import { Pipe, PipeTransform } from '@angular/core';
import { PayeeSummary } from '../models/payee-summary';

@Pipe({name: 'beneficiaryFilter'})
export class BeneficiaryFilterPipe implements PipeTransform {
  transform(value: Array<any>, filter: string): any {
    const nuevo = {
      name: [],
      alias: [],
      account: [],
      bank: [],
      clabe: [],
      phone: [],
      card : [],
      results : 0
    };
    if (filter.length > 0){
      const search_name: Array<any> = value.filter((item)=> item.name.toLowerCase().includes(filter.toLowerCase()));
      const search_alias: Array<any> = value.filter((item)=> item.alias.toLowerCase().includes(filter.toLowerCase()));
      const search_account: Array<any> = value.filter((item)=> item.account.number.toLowerCase().includes(filter.toLowerCase()));
      const search_bank: Array<any> = value.filter((item)=> item.account.bank.toLowerCase().includes(filter.toLowerCase()));
      const search_clabe: Array<any> = value.filter((item)=> {
        if (item.account.account_type === 'CLABE'){
          if(item.account.number.toLowerCase().includes(filter.toLowerCase())){
            return true;
          }
        }else{
          return false;
        }
      });
      const search_phone: Array<any> = value.filter((item)=> {
        if (item.account.account_type === 'SANTANDER_MOBILE_ACCOUNT' || item.account.account_type === 'THIRDPARTY_MOBILE_ACCOUNT'){
          if(item.account.number.toLowerCase().includes(filter.toLowerCase())){
            return true;
          }
        }else{
          return false;
        }
      });
      const search_card: Array<any> = value.filter((item)=> {
        if (item.account.account_type === 'THIRDPARTY_DEBIT_CARD' || item.account.account_type === 'CREDIT_CARD'){
          if(item.account.number.toLowerCase().includes(filter.toLowerCase())){
            return true;
          }
        }else{
          return false;
        }
      });
      nuevo.results = search_account.length + search_alias.length +
                      search_bank.length + search_clabe.length +
                      search_name.length + search_phone.length +
                      search_card.length;
      nuevo.account = search_account;
      nuevo.alias = search_alias;
      nuevo.bank = search_bank;
      nuevo.clabe = search_clabe;
      nuevo.name = search_name;
      nuevo.phone = search_phone;
      nuevo.card = search_card;
      return nuevo;
    }else{
      return nuevo;
    }
  }
}
