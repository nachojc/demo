import { async, TestBed } from '@angular/core/testing';
import { BeneficiaryOperationLibraryModule } from './beneficiary-operation-library.module';

describe('BeneficiaryOperationLibraryModule', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [BeneficiaryOperationLibraryModule]
		}).compileComponents();
	}));

	it('should create', () => {
		expect(BeneficiaryOperationLibraryModule).toBeDefined();
	});
});
