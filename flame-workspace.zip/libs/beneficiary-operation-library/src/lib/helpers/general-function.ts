export class GeneralFunction {
  static isOnlyNumber(key: string) {
    return new RegExp(/^[0-9]+$/).test(key);
  }
}
