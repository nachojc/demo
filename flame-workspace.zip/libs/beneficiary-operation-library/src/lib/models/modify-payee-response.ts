/* tslint:disable */
import { PayeeDetailEdit } from './payee-detail-edit';
import { Notification } from './notification';
export interface ModifyPayeeResponse {
  data?: PayeeDetailEdit;
  notifications?: Array<Notification>;
}
