/* tslint:disable */
import { Account } from './account';
import { TransferMatrix } from './transfer-matrix';
export interface TransferAttemptInit {

  /**
   * The unique identifier could be sent for subsequent steps to complete the transfer
   */
  key?: string;

  /**
   * The customer accounts that can be used in the transfer. This  accounts could be used as 'from' or 'to' account in the transaction
   */
  accounts?: Array<Account>;

  /**
   * This matrix manage the 'from' and 'to' accounts combinations that can be used to transfer
   */
  transfer_matrix?: Array<TransferMatrix>;
}
