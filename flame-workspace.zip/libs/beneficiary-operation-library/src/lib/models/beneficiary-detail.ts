/* tslint:disable */
import { BeneficiaryAccount } from './beneficiary-account';
export interface BeneficiaryDetail {

  /**
   * The unique identifier of the beneficiary.
   */
  key?: string;
  to_target?: BeneficiaryAccount;

  /**
   * The status of the beneficiarie, those status indicates if the beneficiarie was created, pending for authorize, etc.
   */
  status?: 'CREATED' | 'NEW' | 'PENDING' | 'INACTIVE' | 'BLOCKED' | 'DELETED';

  /**
   * Name of the beneficiary.
   */
  name?: string;

  /**
   * Alias of the beneficiary.
   */
  alias?: string;

  /**
   * The maximum amount to be transferred per account
   */
  transfer_limit?: number;

  /**
   * CURP or RFC of the beneficiary,this information is optional. The CURP is composed of 18 characters and the RFC is composed of 12 to 13 characters
   */
  curp_rfc?: string;

  /**
   * Date the beneficiary was registered. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  operation_date?: string;
}
