/* tslint:disable */
import { TransferExecuteRequest } from './transfer-execute-request';
export interface TransferThirdpartiesExecuteRequest extends TransferExecuteRequest {
}
