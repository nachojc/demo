/* tslint:disable */
import { Money } from './money';
export interface DisposalRequest {

  /**
   * Action a scheduled transfer.
   */
  action?: string;

  /**
   * The unique identifier of the origin account that can be used to the transfer operation
   */
  from_account_key?: string;

  /**
   * The unique identifier of the destination account that can be used to the transfer operation
   */
  to_account_key?: string;
  import?: Money;

  /**
   * Brief description of the concept
   */
  concept?: string;
}
