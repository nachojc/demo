/* tslint:disable */
import { BeneficiaryAccount } from './beneficiary-account';
export interface BeneficiarySummary {

  /**
   * The unique identifier of the beneficiary.
   */
  key?: string;
  to_target?: BeneficiaryAccount;

  /**
   * Name of the beneficiary.
   */
  name?: string;

  /**
   * Alias of the beneficiary.
   */
  alias?: string;

  /**
   * The URL for the next call for information account
   */
  url?: string;
}
