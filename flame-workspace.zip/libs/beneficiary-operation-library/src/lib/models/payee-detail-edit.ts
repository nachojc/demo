/* tslint:disable */
import { PayeeInfo } from './payee-info';
export interface PayeeDetailEdit extends PayeeInfo {

  /**
   * The unique identifier of the beneficiary.
   */
  key?: string;

  /**
   * Date the beneficiary was registered. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  creation_date?: string;

  /**
   * The status of the beneficiarie, those status indicates if the beneficiarie was created, pending for authorize, etc.
   */
  status?: 'BLOCKED' | 'DELETED';
}
