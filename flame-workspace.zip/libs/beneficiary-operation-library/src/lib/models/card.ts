/* tslint:disable */
export interface Card {

  /**
   * The unique identifier of the account
   */
  key?: string;

  /**
   * Nickname of the card
   */
  alias?: string;

  /**
   * Obfuscated card number
   */
  display_id?: string;

  /**
   * The name of the bank of the destination account
   */
  bank_name?: string;

  /**
   * The default currency used to applicate a transfer
   */
  default_currency?: string;
}
