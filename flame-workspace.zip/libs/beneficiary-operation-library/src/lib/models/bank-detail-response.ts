/* tslint:disable */
import { BeneficiaryAccountTarget } from './beneficiary-account-target';
import { Notification } from './notification';
export interface BankDetailResponse {
  data?: BeneficiaryAccountTarget;
  notifications?: Array<Notification>;
}
