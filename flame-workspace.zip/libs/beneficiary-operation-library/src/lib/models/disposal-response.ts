/* tslint:disable */
import { DisposalExecute } from './disposal-execute';
export interface DisposalResponse {
  data?: DisposalExecute;
}
