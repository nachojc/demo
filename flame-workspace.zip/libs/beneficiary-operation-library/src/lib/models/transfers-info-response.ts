/* tslint:disable */
import { TransferAccountsDetail } from './transfer-accounts-detail';
import { Notification } from './notification';
import { Cursor } from './cursor';
export interface TransfersInfoResponse {

  /**
   * Lists the transfers information
   */
  data?: Array<TransferAccountsDetail>;
  notifications?: Array<Notification>;
  paging?: Cursor;
}
