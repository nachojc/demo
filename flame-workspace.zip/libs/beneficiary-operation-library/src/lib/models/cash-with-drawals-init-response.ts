/* tslint:disable */
import { CashWithDrawalsAttemptInit } from './cash-with-drawals-attempt-init';
import { Account } from './account';
import { Card } from './card';
export interface CashWithDrawalsInitResponse {
  data?: CashWithDrawalsAttemptInit;
  accounts?: Array<Account>;
  cards?: Array<Card>;
}
