/* tslint:disable */
export interface PayeeAccount {

  /**
   * The account number related to the payee
   */
  number?: string;

  /**
   * Refers to the bank name of the account number related to the payee
   */
  bank?: string;

  /**
   * Shows the type of payee account.
   * - SANTANDER_ACCOUNT *Santander account number to 11 digits
   * - CLABE *Interbank key to 18 digits
   * - SANTANDER_MOBILE_ACCOUNT *The mobile number that is associated with a Santander account
   * - THIRDPARTY_MOBILE_ACCOUNT *The mobile number that is associated with another bank's account
   * - THIRDPARTY_DEBIT_CARD *The debit card number to 18 digits
   * - CREDIT_CARD *The credit card number to 18 digits
   */
  type?: 'SANTANDER_ACCOUNT' | 'CLABE' | 'SANTANDER_MOBILE_ACCOUNT' | 'THIRDPARTY_MOBILE_ACCOUNT' | 'THIRDPARTY_DEBIT_CARD' | 'CREDIT_CARD';
}
