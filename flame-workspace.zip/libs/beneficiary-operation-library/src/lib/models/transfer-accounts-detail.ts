/* tslint:disable */
import { AccountTransferInfo } from './account-transfer-info';
import { Money } from './money';
export interface TransferAccountsDetail {

  /**
   * The unique transfer identifier of the transaction
   */
  key?: string;

  /**
   * Confirmation number for the transfer operation
   */
  confirmation_number?: string;

  /**
   * Date when the transfer was effective. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  effective_date?: string;

  /**
   * The status of the transfer attempt
   */
  status?: 'ACCEPTED' | 'REJECTED';

  /**
   * The transfer type identifier of the transfer
   */
  operation_type?: 'MY_ACCOUNTS' | 'THIRD_PARTY';
  from_account?: AccountTransferInfo;
  to_account?: AccountTransferInfo;
  amount?: Money;

  /**
   * Description of the transfer
   */
  concept?: string;

  /**
   * The transfer reference
   */
  reference?: string;
}
