/* tslint:disable */
export interface CashWithDrawalsAttemptInit {

  /**
   * The unique identifier could be sent for subsequent steps to complete the transfer
   */
  key?: string;
}
