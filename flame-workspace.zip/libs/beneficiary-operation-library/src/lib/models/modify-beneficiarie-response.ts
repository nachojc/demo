/* tslint:disable */
import { BeneficiaryDetail } from './beneficiary-detail';
import { Notification } from './notification';
export interface ModifyBeneficiarieResponse {
  data?: BeneficiaryDetail;
  notifications?: Array<Notification>;
}
