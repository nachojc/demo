/* tslint:disable */
import { PayeeAccount } from './payee-account';
export interface Payee {

  /**
   * Refers to the complete name of the payee
   */
  name?: string;
  account?: PayeeAccount;
}
