/* tslint:disable */
export interface Account {

  /**
   * The unique identifier of the account
   */
  key?: string;

  /**
   * The URL for the next step in the user experience for in formation account
   */
  url?: string;

  /**
   * The type identifier of the transfer
   */
  type?: 'CHEQUING' | 'DEBIT';

  /**
   * Nickname of the account
   */
  alias?: string;

  /**
   * Obfuscated card number
   */
  display_card?: string;

  /**
   * The name of the bank of the destination account
   */
  bank_name?: string;
}
