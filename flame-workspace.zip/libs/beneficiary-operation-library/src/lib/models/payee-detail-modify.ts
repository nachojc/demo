/* tslint:disable */
import { DetailModify } from './detail-modify';
export interface PayeeDetailModify {
  data?: DetailModify;
}
