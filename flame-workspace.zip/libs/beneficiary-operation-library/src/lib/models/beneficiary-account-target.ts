/* tslint:disable */

/**
 * The beneficiary bank product which will be used as a transfer destination.
 */
export interface BeneficiaryAccountTarget {

  /**
   * Name of the beneficiary.
   */
  name?: string;

  /**
   * Account, Card or CLABE number of the beneficiary.
   */
  number?: string;

  /**
   * Shows the type of beneficiary account.
   * - SANTANDER_ACCOUNT *Santander account number to 11 digits
   * - CLABE *Interbank key to 18 digits
   * - SANTANDER_MOBILE_ACCOUNT *The mobile number that is associated with a Santander account
   * - THIRDPARTY_MOBILE_ACCOUNT *The mobile number that is associated with another bank's account
   * - THIRDPARTY_DEBIT_CARD *The debit card number to 18 digits
   * - CREDIT_CARD *The credit card number to 18 digits
   */
  type?: 'SANTANDER_ACCOUNT' | 'CLABE' | 'SANTANDER_MOBILE_ACCOUNT' | 'THIRDPARTY_MOBILE_ACCOUNT' | 'THIRDPARTY_DEBIT_CARD' | 'CREDIT_CARD';

  /**
   * Name of the beneficiarie bank
   */
  bank_name?: string;
}
