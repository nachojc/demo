/* tslint:disable */
export interface TransferInitRequest {
  default_account_key?: string;
}
