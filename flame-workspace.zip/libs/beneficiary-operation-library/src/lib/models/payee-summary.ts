/* tslint:disable */
import { Payee } from './payee';
export interface PayeeSummary extends Payee {

  /**
   * The unique identifier of the beneficiary.
   */
  key?: string;

  /**
   * Alias of the beneficiary.
   */
  alias?: string;

  /**
   * The URL for the next call for information account
   */
  url?: string;
}
