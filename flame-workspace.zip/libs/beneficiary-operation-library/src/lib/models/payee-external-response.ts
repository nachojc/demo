/* tslint:disable */
import { Payee } from './payee';
import { Notification } from './notification';
export interface PayeeExternalResponse {
  data?: Array<Payee>;
  notifications?: Array<Notification>;
}
