/* tslint:disable */
import { Money } from './money';
export interface TransferExecuteRequest {

  /**
   * The type identifier of the transfer
   */
  transfer_type?: 'TRADITIONAL' | 'RECURRING' | 'QUICKLY_TRANSFER';

  /**
   * The unique identifier of the origin account that can be used to the transfer operation
   */
  from_account_key?: string;

  /**
   * The unique identifier of the destination account that can be used to the transfer operation
   */
  to_account_key?: string;
  amount?: Money;

  /**
   * Description of the transfer
   */
  concept?: string;

  /**
   * The transfer reference
   */
  reference?: string;

  /**
   * Date and time when the transfer was executed. [ISO 8601] (https://www.iso.org/iso-8601-date-and-time-format.html
   */
  effective_date?: string;
}
