/* tslint:disable */
import { BeneficiaryAccount } from './beneficiary-account';
export interface DataBeneficiary {
  to_target?: BeneficiaryAccount;

  /**
   * Name of the beneficiary.
   */
  name?: string;

  /**
   * Alias of the beneficiary.
   */
  alias?: string;

  /**
   * CURP or RFC of the beneficiary,this information is optional. The CURP is composed of 18 characters and the RFC is composed of 12 to 13 characters
   */
  curp_rfc?: string;

  /**
   * The status of the beneficiarie, those status indicates if the beneficiarie was created, pending for authorize, etc.
   */
  status?: 'NEW' | 'CREATED' | 'PENDING';

  /**
   * The maximum amount to be transferred per account
   */
  transfer_limit?: number;
}
