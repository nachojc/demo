/* tslint:disable */
import { TransferExecute } from './transfer-execute';
export interface TransferSuccessful extends TransferExecute {
}
