/* tslint:disable */
import { BeneficiaryDetail } from './beneficiary-detail';
import { Notification } from './notification';
export interface BeneficiariesResponse {
  data?: BeneficiaryDetail;
  notifications?: Array<Notification>;
}
