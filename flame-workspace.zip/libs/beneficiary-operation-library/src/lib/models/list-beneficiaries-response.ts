/* tslint:disable */
import { BeneficiarySummary } from './beneficiary-summary';
import { Notification } from './notification';
import { Cursor } from './cursor';
export interface ListBeneficiariesResponse {
  data?: Array<BeneficiarySummary>;
  notifications?: Array<Notification>;
  paging?: Cursor;
}
