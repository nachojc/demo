/* tslint:disable */
import { TransferSuccessful } from './transfer-successful';
import { Notification } from './notification';
export interface TransferReceiptResponse {
  data?: TransferSuccessful;
  notifications?: Array<Notification>;
}
