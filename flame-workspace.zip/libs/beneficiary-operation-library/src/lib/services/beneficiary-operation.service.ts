import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PayeesResponse } from '../models/payees-response';
import { ListPayeesResponse } from '../models/list-payees-response';
import { ModifyRequest } from '../models/modify-request';
import { PayeeDetailModify } from '../models/payee-detail-modify';
import { ModifyPayeeResponse } from '../models/modify-payee-response';
import { PayeeExternalResponse } from '../models/payee-external-response';
import { PayeeInfo } from '../models/payee-info';
import { ENV_CONFIG } from '@santander/flame-core-library';

@Injectable()
export class BeneficiaryService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient
	) {}
	private _urlBeneficiary = this.environment.api.url + '/transfers/payees/';

	getAllBeneficiaries() {
		return this._httpClient.get<ListPayeesResponse>(this._urlBeneficiary);
	}

	getInfoByKey(keyBeneficiary: string) {
		return this._httpClient.get<PayeesResponse>(
			this._urlBeneficiary + keyBeneficiary
		);
	}

	getPayeeLookup(serchType: string, searchValue: string) {
		const params = new HttpParams()
			.set('search_type', serchType)
      .set('search_value', searchValue);
		return this._httpClient.get<PayeeExternalResponse>(
			this._urlBeneficiary + 'lookup',
			{
				params: params
			}
		);
	}

	updateBeneficiary(keyToUpdate: string, dataUpdate: ModifyRequest) {
		return this._httpClient.put<PayeeDetailModify>(
			this._urlBeneficiary + keyToUpdate,
			dataUpdate
		);
	}

	deletePayee(keyToDelete: string) {
		return this._httpClient.put<ModifyPayeeResponse>(
			this._urlBeneficiary + keyToDelete + '/remove',
			{}
		);
	}

	postDataBeneficiary(request: PayeeInfo): Observable<PayeesResponse> {
		return this._httpClient.post(this._urlBeneficiary, request);
	}
}
