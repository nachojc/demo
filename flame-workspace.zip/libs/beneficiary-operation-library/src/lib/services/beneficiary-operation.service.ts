import { Injectable, Inject } from '@angular/core';
import {
	HttpClient,
	HttpParams,
	HttpErrorResponse
} from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { PayeesResponse } from '../models/payees-response';
import { ListPayeesResponse } from '../models/list-payees-response';
import { ModifyRequest } from '../models/modify-request';
import { PayeeDetailModify } from '../models/payee-detail-modify';
import { ModifyPayeeResponse } from '../models/modify-payee-response';
import { PayeeExternalResponse } from '../models/payee-external-response';
import { PayeeInfo } from '../models/payee-info';
import { ENV_CONFIG } from '@santander/flame-core-library';
import {
	DialogService,
	DialogReference,
	CustomDialog
} from '@santander/flame-component-library';
import { ErrorDialogComponent } from '../components/error-dialog/error-dialog.component';
import { mergeMap, catchError } from 'rxjs/operators';

@Injectable()
export class BeneficiaryService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _httpClient: HttpClient,
		private dialog: DialogService
	) {}
	private _urlBeneficiary = `${this.environment.api.url}/${this.environment.api.version.transfers}transfers/payees/`;
	private dialogRef: DialogReference;

	getAllBeneficiaries() {
		return this._httpClient.get<ListPayeesResponse>(this._urlBeneficiary);
	}

	getInfoByKey(keyBeneficiary: string) {
		return this._httpClient.get<PayeesResponse>(
			this._urlBeneficiary + keyBeneficiary
		);
	}

	getPayeeLookup(serchType: string, searchValue: string) {
		const params = new HttpParams()
			.set('search_type', serchType)
			.set('search_value', searchValue);
		return this._httpClient
			.get(this._urlBeneficiary + 'lookup', {
				params: params
			})
			.pipe(
				mergeMap((data: Response) => {
					return of(data);
				}),
				catchError((errHttp: HttpErrorResponse) => {
					this.showErrorDialog(
						'Error',
						'Servicio no disponible por el momento, intente mas tarde',
						null
					);
					return of();
				})
			);
	}

	updateBeneficiary(keyToUpdate: string, dataUpdate: ModifyRequest) {
		return this._httpClient.put<PayeeDetailModify>(
			this._urlBeneficiary + keyToUpdate,
			dataUpdate
		);
	}

	deletePayee(keyToDelete: string) {
		return this._httpClient.put<ModifyPayeeResponse>(
			this._urlBeneficiary + keyToDelete + '/remove',
			{}
		);
	}

	postDataBeneficiary(request: PayeeInfo): Observable<PayeesResponse> {
		return this._httpClient.post(this._urlBeneficiary, request);
	}

	showErrorDialog(title: string, message: string, url: string | null) {
		this.dialogRef = this.dialog.open(
			{
				title: 'Operación inválida',
				enableHr: true,
				disabledButton: true,
				closeBackdropClick: false,
				buttons: [
					{
						class: 'strech',
						label: 'Aceptar',
						action: scope => {
							this.dialogRef.close();
						}
					}
				]
			},
			new CustomDialog(ErrorDialogComponent, {
				titleInvalid: title,
				message: message,
				url: url
			})
		);
	}
}
