import { Injectable, Inject, Injector } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { PayeesResponse } from '../models/payees-response';
import { ListPayeesResponse } from '../models/list-payees-response';
import { ModifyRequest } from '../models/modify-request';
import { PayeeDetailModify } from '../models/payee-detail-modify';
import { ModifyPayeeResponse } from '../models/modify-payee-response';
import { PayeeExternalResponse } from '../models/payee-external-response';
import { PayeeInfo } from '../models/payee-info';
import { ENV_CONFIG, GlobileHttpClient } from '@santander/flame-core-library';
import { Platform } from '@angular/cdk/platform';

@Injectable()
export class BeneficiaryService {
	constructor(
		@Inject(ENV_CONFIG) private environment: any,
		private _injector: Injector
	) {
    const platform = new Platform();
		if (platform.IOS || platform.ANDROID) {
			this._httpClient = _injector.get<GlobileHttpClient>(GlobileHttpClient);
		} else {
			this._httpClient = _injector.get<HttpClient>(HttpClient);
		}
  }
  private _httpClient: any;
	private _urlBeneficiary = this.environment.baas.urlBeneficiary;

	createAuthorizationHeader() {
		return new HttpHeaders({
			Accept: 'application/json'
		});
	}

	getAllBeneficiaries(): Observable<ListPayeesResponse> {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();

		return this._httpClient.get(this._urlBeneficiary, {
			headers: headers
		});
	}

	getInfoByKey(keyBeneficiary: string): Observable<PayeesResponse> {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.get(
			this._urlBeneficiary + keyBeneficiary,
			{ headers: headers }
		);
	}

	getPayeeLookup(identifierKey: string): Observable<PayeeExternalResponse> {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.get(
			this._urlBeneficiary + 'lookup',
			{ headers: headers, params: { identifier: identifierKey } }
		);
	}

	updateBeneficiary(
		keyToUpdate: string,
		dataUpdate: ModifyRequest
	): Observable<PayeeDetailModify> {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.put(
			this._urlBeneficiary + keyToUpdate,
			dataUpdate,
			{ headers: headers }
		);
	}

	deletePayee(keyToDelete: string): Observable<ModifyPayeeResponse> {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.put(
			this._urlBeneficiary + keyToDelete + '/remove',
			{ headers: headers }
		);
	}

	postDataBeneficiary(request: PayeeInfo): Observable<PayeesResponse> {
		let headers = new HttpHeaders();
		headers = this.createAuthorizationHeader();
		return this._httpClient.post(this._urlBeneficiary, request, {
			headers: headers
		});
	}
}
