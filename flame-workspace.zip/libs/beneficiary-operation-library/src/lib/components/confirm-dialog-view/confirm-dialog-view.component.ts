import { Component } from '@angular/core';

@Component({
	selector: 'sm-confirm-payee-dialog-view',
	templateUrl: './confirm-dialog-view.component.html',
	styleUrls: ['./confirm-dialog-view.component.scss']
})
export class ConfirmPayeeDialogViewComponent {
	/**
	 * variables
	 *
	 * @type {*}
	 * @memberof RelateConfirmViewComponent
	 */
	public data: any;
	public statusSlide: string;
	public isAccept = false;
	public formatCase: string;

	/**
	 * metodo que emite un booleano de confirmacion del slide
	 *
	 * @param {*} e
	 * @memberof RelateConfirmViewComponent
	 */
	/* 	confirmationEvent(e: any) {
		if (e) {
			this.statusSlide = 'success';
			this._accountService.closeEventSlide.emit(e);
		}
	} */

	/**
	 * metodo para aceptar terminos
	 *
	 * @memberof RelateConfirmViewComponent
	 */
	acceptTerms() {
		this.isAccept = !this.isAccept;
	}

	textAccountCase(): string {
		let text: string;
		switch (true) {
			case (this.data.dataConfirm.account.account_type ===
				'SANTANDER_CREDIT_CARD' ||
				this.data.dataConfirm.account.account_type === 'CREDIT_CARD') &&
				this.data.dataConfirm.account.number.length === 16:
				this.formatCase = '0000 0000 0000 0000';
				text = 'No. de tarjeta de crédito';
				break;
			case (this.data.dataConfirm.account.account_type ===
				'SANTANDER_ACCOUNT' ||
				this.data.dataConfirm.account.account_type ===
					'THIRDPARTY_DEBIT_CARD') &&
				this.data.dataConfirm.account.number.length === 16:
				this.formatCase = '0000000000000000';
				text = 'No. de tarjeta de débito';
				break;
			case this.data.dataConfirm.account.account_type === 'CLABE':
				this.formatCase = '000000000000000000';
				text = 'Clabe';
				break;
			case this.data.dataConfirm.account.account_type === 'MOBILE_ACCOUNT':
				this.formatCase = '00 0000 0000';
				text = 'No. de celular';
				break;
		}
		return text;
	}

	confirmationEvent(event: boolean) {
		this.statusSlide = 'success';
		this.data.dataConfirm.event.emit(event);
	}
}
