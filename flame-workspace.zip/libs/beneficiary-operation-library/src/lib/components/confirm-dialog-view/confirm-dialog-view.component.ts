import { Component } from '@angular/core';


@Component({
	selector: 'sm-confirm-payee-dialog-view',
	templateUrl: './confirm-dialog-view.component.html',
	styleUrls: ['./confirm-dialog-view.component.scss']
})
export class ConfirmPayeeDialogViewComponent {

	/**
	 * variables
	 *
	 * @type {*}
	 * @memberof RelateConfirmViewComponent
	 */
	public data: any;
	public statusSlide: string;
	public isAccept = false;


	/**
	 * metodo que emite un booleano de confirmacion del slide
	 *
	 * @param {*} e
	 * @memberof RelateConfirmViewComponent
	 */
/* 	confirmationEvent(e: any) {
		if (e) {
			this.statusSlide = 'success';
			this._accountService.closeEventSlide.emit(e);
		}
	} */

	/**
	 * metodo para aceptar terminos
	 *
	 * @memberof RelateConfirmViewComponent
	 */
	acceptTerms() {
		this.isAccept = !this.isAccept;
  }

  confirmationEvent(event: boolean) {
    this.statusSlide = 'success';
    this.data.dataConfirm.event.emit(event);
  }
}
