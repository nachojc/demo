import {
	async,
	ComponentFixture,
	TestBed
} from '@angular/core/testing';
import {
	FlameFoundationTheme,
	ThemeModule,
	FormFieldModule,
	InputModule,
	IconButtonModule,
	IconModule,
	ButtonModule,
	TopBarModule,
	AvatarModule,
	EmojiModule,
	DialogSelectModule,
	TokenDialogModule,
	ChipModule,
	ProductModule,
	HiddenButtonsModule,
	SearchBarModule,
	SlideButtonModule,
	CheckboxModule,
	DialogService,
	ContactDialogService
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, EventEmitter } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';

import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';

import { BeneficiaryProductsFilterPipe } from '../../pipes/beneficiary-products-filter.pipe';
import { BeneficiaryOperationLibraryComponents } from '../../components/beneficiary-operation-library-components';

import { BeneficiaryViewComponents } from '../../views/beneficiary-views-components';
import { ConfirmPayeeDialogViewComponent } from './confirm-dialog-view.component';
import { NgxMaskModule } from 'ngx-mask';

describe('ConfirmPayeeDialogViewComponent', () => {
	let component: ConfirmPayeeDialogViewComponent;
	let fixture: ComponentFixture<ConfirmPayeeDialogViewComponent>;

	const dataPayeeClabeRes = {
		data: {
			"key": "1omfttw29olss0r9286tpgmyomeldijb",
			"account": {
				"number": "134567894563456789",
				"account_type": "CLABE",
				"bank": "SCOTIABANK"
			},
			"name": "Ida Sullivan",
			"alias": "Bachelor of Engineering",
			"url": "/beneficiaries/{beneficiary-key}"
		}
	};
	const dataPayeeMobileAccRes = {
		data: {
			"key": "1omfttw29olss0r9286tpgmyomeldijb",
			"account": {
				"number": "134567894563456789",
				"account_type": "MOBILE_ACCOUNT",
				"bank": "SCOTIABANK"
			},
			"name": "Ida Sullivan",
			"alias": "Bachelor of Engineering",
			"url": "/beneficiaries/{beneficiary-key}"
		}
	};
	const dataPayeeThirdPartyAccRes = {
		data: {
			"key": "1omfttw29olss0r9286tpgmyomeldijb",
			"account": {
				"number": "134567894563456789",
				"account_type": "THIRDPARTY_DEBIT_CARD",
				"bank": "SCOTIABANK"
			},
			"name": "Ida Sullivan",
			"alias": "Bachelor of Engineering",
			"url": "/beneficiaries/{beneficiary-key}"
		}
	};
	const dataPayeeSartanderAccRes = {
		data: {
			"key": "1omfttw29olss0r9286tpgmyomeldijb",
			"account": {
				"number": "1234567890123456",
				"account_type": "SANTANDER_ACCOUNT",
				"bank": "SCOTIABANK"
			},
			"name": "Ida Sullivan",
			"alias": "Bachelor of Engineering",
			"url": "/beneficiaries/{beneficiary-key}"
		}
	};
	const dataPayeeCCRes = {
		data: {
			"key": "1omfttw29olss0r9286tpgmyomeldijb",
			"account": {
				"number": "134567894563456789",
				"account_type": "CREDIT_CARD",
				"bank": "SCOTIABANK"
			},
			"name": "Ida Sullivan",
			"alias": "Bachelor of Engineering",
			"url": "/beneficiaries/{beneficiary-key}"
		}
	};
	const dataPayeeSartanderCCRes = {
		data: {
			"key": "1omfttw29olss0r9286tpgmyomeldijb",
			"account": {
				"number": "1234567890123456",
				"account_type": "SANTANDER_CREDIT_CARD",
				"bank": "SCOTIABANK"
			},
			"name": "Ida Sullivan",
			"alias": "Bachelor of Engineering",
			"url": "/beneficiaries/{beneficiary-key}"
		}
	};



	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
				RouterTestingModule,
				AvatarModule,
				BeneficiaryOperationLibraryRoutingModule,
				ButtonModule,
				CommonModule,
				DialogSelectModule,
				EmojiModule,
				FormFieldModule,
				FormsModule,
				IconModule,
				IconButtonModule,
				InputModule,
				ReactiveFormsModule,
				ChipModule,
				NgxMaskModule.forRoot(),
				ProductModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TokenDialogModule,
				TopBarModule,
				HiddenButtonsModule,
				SearchBarModule,
				SlideButtonModule,
				CheckboxModule,
				RouterModule.forRoot([])
			],
			declarations: [
				ConfirmPayeeDialogViewComponent,
				BeneficiaryFilterPipe,
				BeneficiaryProductsFilterPipe,
				...BeneficiaryViewComponents,
				...BeneficiaryOperationLibraryComponents
			],
			schemas: [
				CUSTOM_ELEMENTS_SCHEMA,
				NO_ERRORS_SCHEMA
			],
			providers: [
				DialogService,
				ContactDialogService,
				{provide: APP_BASE_HREF, useValue:'/'}
			]
		}).compileComponents();
	}));


	beforeEach(() => {
		fixture = TestBed.createComponent(ConfirmPayeeDialogViewComponent);
		component = fixture.componentInstance;
		component.data = {
			dataConfirm: dataPayeeSartanderCCRes.data
		}
		fixture.detectChanges();
	});

	it('should create a component err', () => {
		expect(component).toBeTruthy();
	});

	it('should validate textAccountCase', () => {
		let result = '';
		component.data.dataConfirm = dataPayeeSartanderCCRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de tarjeta de crédito');
		component.data.dataConfirm = dataPayeeCCRes.data;
		result = component.textAccountCase();
		component.data.dataConfirm = dataPayeeSartanderAccRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de tarjeta de débito');
		component.data.dataConfirm = dataPayeeThirdPartyAccRes.data;
		result = component.textAccountCase();
		component.data.dataConfirm = dataPayeeClabeRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('Clabe');
		component.data.dataConfirm = dataPayeeMobileAccRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de celular');
	});

	it('should change the status of accept terms', () => {
		component.acceptTerms();
		expect(component.acceptTerms).toBeTruthy();
	});

	it('should emit the event and change the status of slide', () => {
		fixture.detectChanges();
		component.data.dataConfirm.event = new EventEmitter();
		component.confirmationEvent(true);

		fixture.detectChanges();

		expect(component.statusSlide).toBeTruthy();
	});

});
