import { Component } from '@angular/core';
import { CustomDialogComponent } from '@santander/flame-component-library';

@Component({
	selector: 'sm-error-dialog',
	templateUrl: './error-dialog.component.html',
	styleUrls: ['./error-dialog.component.scss']
})
export class ErrorDialogComponent implements CustomDialogComponent {
	data: any;
}
