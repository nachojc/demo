import {
	async,
	ComponentFixture,
	TestBed
} from '@angular/core/testing';
import {
	FlameFoundationTheme,
	ThemeModule,
	FormFieldModule,
	InputModule,
	IconButtonModule,
	IconModule,
	ButtonModule,
	TopBarModule,
	AvatarModule,
	EmojiModule,
	DialogSelectModule,
	TokenDialogModule,
	ChipModule,
	ProductModule,
	HiddenButtonsModule,
	SearchBarModule,
	SlideButtonModule,
	CheckboxModule,
	DialogService,
	ContactDialogService
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import {
	FormsModule,
	ReactiveFormsModule,
} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';
import {  NgxMaskModule } from 'ngx-mask';
import { BeneficiaryProductsFilterPipe } from '../../pipes/beneficiary-products-filter.pipe';
import { BeneficiaryOperationLibraryComponents } from '../../components/beneficiary-operation-library-components';

import { ErrorDialogComponent } from './error-dialog.component';
import { BeneficiaryViewComponents } from '../../views/beneficiary-views-components';

describe('ErrorDialogComponent', () => {
	let component: ErrorDialogComponent;
	let fixture: ComponentFixture<ErrorDialogComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
                RouterTestingModule,
                AvatarModule,
                BeneficiaryOperationLibraryRoutingModule,
                ButtonModule,
                CommonModule,
                DialogSelectModule,
                EmojiModule,
                FormFieldModule,
                FormsModule,
                IconModule,
                IconButtonModule,
                InputModule,
                ReactiveFormsModule,
                ChipModule,
                NgxMaskModule.forRoot(),
                ProductModule,
                ThemeModule.forRoot({
                    themes: [FlameFoundationTheme],
                    active: 'flame-foundation'
                }),
                TokenDialogModule,
                TopBarModule,
                HiddenButtonsModule,
                SearchBarModule,
                SlideButtonModule,
                CheckboxModule,
				RouterModule.forRoot([])
			],
			declarations: [
				ErrorDialogComponent,
				BeneficiaryFilterPipe,
                BeneficiaryProductsFilterPipe,
                ...BeneficiaryViewComponents,
                ...BeneficiaryOperationLibraryComponents
			],
			schemas: [
                CUSTOM_ELEMENTS_SCHEMA,
                NO_ERRORS_SCHEMA
            ],
			providers: [
				DialogService,
				ContactDialogService,
				{provide: APP_BASE_HREF, useValue:'/'}
            ]
		}).compileComponents();
	}));


	beforeEach(() => {
		fixture = TestBed.createComponent(ErrorDialogComponent);
		component = fixture.componentInstance;
		component.data = { url : ''};
		fixture.detectChanges();
	});

	it('should create a component error', () => {
		
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});
});
