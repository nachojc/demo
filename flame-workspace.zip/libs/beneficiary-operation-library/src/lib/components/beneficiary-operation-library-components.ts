import { ConfirmPayeeDialogViewComponent } from './confirm-dialog-view/confirm-dialog-view.component';
import { ErrorDialogComponent } from './error-dialog/error-dialog.component';

export const BeneficiaryOperationLibraryComponents = [
	ConfirmPayeeDialogViewComponent,
	ErrorDialogComponent
];

export const BeneficiaryOperationLibraryEntryComponents = [
	ConfirmPayeeDialogViewComponent,
	ErrorDialogComponent
];
