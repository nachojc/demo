import {
	async,
	ComponentFixture,
	TestBed
} from '@angular/core/testing';
import {
	FlameFoundationTheme,
	ThemeModule,
	FormFieldModule,
	InputModule,
	IconButtonModule,
	IconModule,
	ButtonModule,
	TopBarModule,
	AvatarModule,
	EmojiModule,
	DialogSelectModule,
	TokenDialogService,
	TokenDialogModule,
	ChipModule,
	ProductModule,
	HiddenButtonsModule,
	SearchBarModule,
	SlideButtonModule,
	CheckboxModule,
	ContactDialogService,
	DialogService
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule, Router, ActivatedRoute } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Injector } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { DebugElement } from '@angular/core';
import { BeneficiaryViewComponent } from 'libs/beneficiary-operation-library/src/lib/views/beneficiary-view/beneficiary-view.component';
import {
	FormsModule,
	ReactiveFormsModule,
	FormBuilder,
	FormGroup
} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BeneficiaryViewComponents } from '../beneficiary-views-components';
import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';
import { ENV_CONFIG, DataTransferService } from '@santander/flame-core-library';
import { MaskPipe, NgxMaskModule } from 'ngx-mask';
import { BeneficiaryProductsFilterPipe } from '../../pipes/beneficiary-products-filter.pipe';
import { BeneficiaryOperationLibraryComponents } from '../../components/beneficiary-operation-library-components';
import { of, Observable } from 'rxjs';
import { ConfirmPayeeDialogViewComponent } from '../../components/confirm-dialog-view/confirm-dialog-view.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';
import { BeneficiaryVoucherViewComponent } from './beneficiary-voucher-view.component';

describe('BeneficiaryVoucherViewComponent', () => {
	let component: BeneficiaryVoucherViewComponent;
	let fixture: ComponentFixture<BeneficiaryVoucherViewComponent>;
	let router: Router;
	let route: ActivatedRoute;
	let contactDialogService: ContactDialogService;
	let beneficiaryService: BeneficiaryService;
	let dataTransferService: DataTransferService;

	const dataPayeeClabeRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "CLABE",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeMobileAccRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "MOBILE_ACCOUNT",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeThirdPartyAccRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "THIRDPARTY_DEBIT_CARD",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeSartanderAccRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "1234567890123456",
		  "account_type": "SANTANDER_ACCOUNT",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeCCRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "CREDIT_CARD",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeSartanderCCRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "1234567890123456",
		  "account_type": "SANTANDER_CREDIT_CARD",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};


	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
                RouterTestingModule,
                AvatarModule,
                BeneficiaryOperationLibraryRoutingModule,
                ButtonModule,
                CommonModule,
                DialogSelectModule,
				EmojiModule,
				BrowserAnimationsModule,
                FormFieldModule,
                FormsModule,
                IconModule,
                IconButtonModule,
                InputModule,
                ReactiveFormsModule,
                ChipModule,
                NgxMaskModule.forRoot(),
                ProductModule,
                ThemeModule.forRoot({
                    themes: [FlameFoundationTheme],
                    active: 'flame-foundation'
                }),
                TokenDialogModule,
                TopBarModule,
                HiddenButtonsModule,
                SearchBarModule,
                SlideButtonModule,
                CheckboxModule,
				RouterModule.forRoot([])
			],
			declarations: [
				BeneficiaryViewComponent,
				ConfirmPayeeDialogViewComponent,
				BeneficiaryFilterPipe,
                BeneficiaryProductsFilterPipe,
                ...BeneficiaryViewComponents,
                ...BeneficiaryOperationLibraryComponents
			],
			schemas: [
                CUSTOM_ELEMENTS_SCHEMA,
                NO_ERRORS_SCHEMA
            ],
			providers: [
                BeneficiaryService,
                TokenDialogService,
				ContactDialogService,
				DataTransferService,
				ConfirmPayeeDialogViewComponent,
                MaskPipe,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api/',
							version: {
								transfers : '1'
							}
						}
					}
				},
				{ provide: Injector, useValue: {} },
				{ provide: APP_BASE_HREF, useValue:'/' }             
            ]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(BeneficiaryVoucherViewComponent);
		component = fixture.componentInstance;
		router = TestBed.get(Router);

		dataTransferService = TestBed.get(DataTransferService);
		beneficiaryService = TestBed.get(BeneficiaryService);
		contactDialogService = TestBed.get(ContactDialogService);
		spyOn(dataTransferService, 'getData').and.returnValue(Promise.resolve('12345'));
		spyOn(beneficiaryService, 'getInfoByKey').and.returnValue(of(dataPayeeClabeRes));

	});

	it('should create a component', () => {
		component.ngOnInit();
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('should validate new contact', () => {
		const injector = TestBed;
		const routerActivated = injector.get(ActivatedRoute);
		routerActivated.queryParams = of({isNew:'true'}
		);
		component.ngOnInit();
		
		expect(component.isNew).toBeTruthy();
	});


	it('should validate textAccountCase',async( ()=>{
		component.ngOnInit();
		let result = '';
		component.beneficiary  = dataPayeeSartanderCCRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de tarjeta de crédito');
		component.beneficiary  = dataPayeeCCRes.data;
		result = component.textAccountCase();
		component.beneficiary  = dataPayeeSartanderAccRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de tarjeta de débito');
		component.beneficiary  = dataPayeeThirdPartyAccRes.data;
		result = component.textAccountCase();
		component.beneficiary  = dataPayeeClabeRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('Clabe');
		component.beneficiary  = dataPayeeMobileAccRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de celular');
	}));


	it('should close', ()=>{
		const routerSpy = spyOn(router,'navigate');
		component.close({totalTime:true});
		expect(routerSpy).toHaveBeenCalledWith(['/summary/global-position']);
	});

	

});
