import { Component, OnInit } from '@angular/core';
import { DataTransferService } from '@santander/flame-core-library';
import { ActivatedRoute } from '@angular/router';

@Component({
	selector: 'sm-beneficiary-voucher-view',
	templateUrl: './beneficiary-voucher-view.component.html',
	styleUrls: ['./beneficiary-voucher-view.component.scss']
})
export class BeneficiaryVoucherViewComponent implements OnInit {
	//Variables
	public isNew: boolean;
	//Control
  public beneficiary: any;
  public title: string;
  public textAction: string;

	constructor(private _dataTransferService: DataTransferService, private _activatedRoute: ActivatedRoute) {}

	ngOnInit(): void {
    this._activatedRoute.queryParams.subscribe(params => {
      this.evaluate(params.isNew);
    });
		this._dataTransferService.getData().then(response => {
      if (this.isNew) {
        this.beneficiary = response.data;
      } else {
        this.beneficiary = response;
      }
		});
  }

  evaluate(value: string){
    if (value === 'true') {
      this.isNew = true;
      this.title = 'Agregar contacto';
      this.textAction = 'Agregaste un contacto';
    } else {
      this.isNew = false;
      this.title = 'Comprobante';
      this.textAction = 'Eliminaste un contacto';
    }
  }
}
