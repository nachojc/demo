import { Component, OnInit } from '@angular/core';
import { DataTransferService } from '@santander/flame-core-library';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactDialogService } from '@santander/flame-component-library';
import { VoucherOutAnimation } from '@santander/flame-component-library';

@Component({
	selector: 'sm-beneficiary-voucher-view',
	templateUrl: './beneficiary-voucher-view.component.html',
	styleUrls: ['./beneficiary-voucher-view.component.scss'],
	animations: [VoucherOutAnimation]
})
export class BeneficiaryVoucherViewComponent implements OnInit {
	constructor(
		private _dataTransferService: DataTransferService,
		private _activatedRoute: ActivatedRoute,
		private _router: Router,
		private _contactDialogService: ContactDialogService
	) {}

	/**
	 *
	 * variables
	 * @type {boolean}
	 * @memberof BeneficiaryVoucherViewComponent
	 */
	public isNew: boolean;
	public beneficiary: any;
	public title: string;
	public textAction: string;
	public voucherExitMove = "";

	/**
   * metodo para el texto del titulo
   *
   * @param {string} value
   * @memberof BeneficiaryVoucherViewComponent
   */
  evaluate(value: string) {
		if (value === 'true') {
			this.isNew = true;
			this.title = 'Comprobante';
			this.textAction = 'Agregaste un contacto';
		} else {
			this.isNew = false;
			this.title = 'Comprobante';
			this.textAction = 'Eliminaste un contacto';
		}
	}

	/**
	 * Se inicializa la animación de salida del voucher
	 *
	 * @memberof BeneficiaryVoucherViewComponent
	 */
	public animationExit(){
		this.voucherExitMove = 'out';
	}

	/**
	 * Función que redirecciona al summary
	 *
	 * @param {*} event
	 * @memberof BeneficiaryVoucherViewComponent
	 */
	public close(event: any) {
		if(event.totalTime) {
			this._router.navigate(['/summary/global-position']); 
		}
	}

	ngOnInit(): void {
		this._activatedRoute.queryParams.subscribe(params => {
			this.evaluate(params.isNew);
		});
		this._dataTransferService.getData().then(response => {
			if (this.isNew) {
				this.beneficiary = response.data;
			} else {
        this.beneficiary = response.data;
			}
		});
	}
}
