import { Component, OnInit } from '@angular/core';
import { DataTransferService } from '@santander/flame-core-library';
import { ActivatedRoute, Router } from '@angular/router';
import { ContactDialogService } from '@santander/flame-component-library';

@Component({
	selector: 'sm-beneficiary-voucher-view',
	templateUrl: './beneficiary-voucher-view.component.html',
	styleUrls: ['./beneficiary-voucher-view.component.scss']
})
export class BeneficiaryVoucherViewComponent implements OnInit {
	/**
	 *
	 * variables
	 * @type {boolean}
	 * @memberof BeneficiaryVoucherViewComponent
	 */
	public isNew: boolean;
	public beneficiary: any;
	public title: string;
	public textAction: string;

	constructor(
		private _dataTransferService: DataTransferService,
		private _activatedRoute: ActivatedRoute,
		private _router: Router,
		private _contactDialogService: ContactDialogService
	) {}

	/**
	 *
	 *
	 * @param {string} action
	 * @memberof BeneficiaryVoucherViewComponent
	 */
	redirectTo(action: string) {
		if (action === 'close') {
			this._router.navigate(['/summary/global-position']);
		} else {
			this._contactDialogService.openDialogContact(1);
		}
	}

	/**
   * metodo para el texto del titulo
   *
   * @param {string} value
   * @memberof BeneficiaryVoucherViewComponent
   */
  evaluate(value: string) {
		if (value === 'true') {
			this.isNew = true;
			this.title = 'Crear nuevo contacto';
			this.textAction = 'Creación de contacto exitoso';
		} else {
			this.isNew = false;
			this.title = 'Comprobante';
			this.textAction = 'Eliminaste el siguiente contacto de tu lista';
		}
	}

	ngOnInit(): void {
		this._activatedRoute.queryParams.subscribe(params => {
			this.evaluate(params.isNew);
		});
		this._dataTransferService.getData().then(response => {
			if (this.isNew) {
				this.beneficiary = response.data;
			} else {
				this.beneficiary = response;
			}
		});
	}
}
