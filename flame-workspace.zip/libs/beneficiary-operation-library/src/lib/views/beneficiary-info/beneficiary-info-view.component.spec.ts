import {
	async,
	ComponentFixture,
	TestBed
} from '@angular/core/testing';
import {
	ButtonModule,
	IconModule,
	AvatarModule,
	DialogSelectModule,
	EmojiModule,
	FormFieldModule,
	IconButtonModule,
	InputModule,
	ChipModule,
	ProductModule,
	ThemeModule,
	FlameFoundationTheme,
	TokenDialogModule,
	TopBarModule,
	HiddenButtonsModule,
	SearchBarModule,
	TokenDialogService
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import {
	FormsModule,
	ReactiveFormsModule
} from '@angular/forms';
import { BeneficiaryInfoViewComponent } from './beneficiary-info-view.component';
import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';

describe('BeneficiaryInfoViewComponent', () => {
	let component: BeneficiaryInfoViewComponent;
  let fixture: ComponentFixture<BeneficiaryInfoViewComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				BeneficiaryOperationLibraryRoutingModule,
				ButtonModule,
				CommonModule,
				DialogSelectModule,
				EmojiModule,
				FormFieldModule,
				FormsModule,
				IconModule,
				IconButtonModule,
				InputModule,
				ReactiveFormsModule,
				ChipModule,
				ProductModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TokenDialogModule,
				TopBarModule,
				HiddenButtonsModule,
				SearchBarModule,
				RouterTestingModule.withRoutes([])
			],
			declarations: [BeneficiaryFilterPipe],
			providers: [BeneficiaryService, TokenDialogService]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(BeneficiaryInfoViewComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});
});
