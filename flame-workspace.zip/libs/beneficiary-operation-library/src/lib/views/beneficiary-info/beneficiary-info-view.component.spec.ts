import {
	async,
	ComponentFixture,
	TestBed
} from '@angular/core/testing';
import {
	FlameFoundationTheme,
	ThemeModule,
	FormFieldModule,
	InputModule,
	IconButtonModule,
	IconModule,
	ButtonModule,
	TopBarModule,
	AvatarModule,
	EmojiModule,
	DialogSelectModule,
	TokenDialogService,
	TokenDialogModule,
	ChipModule,
	ProductModule,
	HiddenButtonsModule,
	SearchBarModule,
	SlideButtonModule,
	CheckboxModule,
	DialogService,
	ContactDialogService
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule, Router } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Injector } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import {
	FormsModule,
	ReactiveFormsModule,
	FormBuilder,
	Validators,
	FormGroup
} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BeneficiaryViewComponents } from '../beneficiary-views-components';
import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';
import { ENV_CONFIG, DataTransferService } from '@santander/flame-core-library';
import { MaskPipe, NgxMaskModule } from 'ngx-mask';
import { BeneficiaryProductsFilterPipe } from '../../pipes/beneficiary-products-filter.pipe';
import { BeneficiaryOperationLibraryComponents } from '../../components/beneficiary-operation-library-components';
import { of } from 'rxjs';
import { BeneficiaryInfoViewComponent } from './beneficiary-info-view.component';
import { ConfirmPayeeDialogViewComponent } from '../../components/confirm-dialog-view/confirm-dialog-view.component';

describe('BeneficiaryInfoViewComponent', () => {
	let component: BeneficiaryInfoViewComponent;
	let fixture: ComponentFixture<BeneficiaryInfoViewComponent>;
	let formInfoBuilder: FormBuilder;
	let beneficiaryInfoForm : FormGroup;
	let router: Router;
	let contactDialogService: ContactDialogService;
	let beneficiaryService: BeneficiaryService;
	let dataTransferService: DataTransferService;
	let tokenService: TokenDialogService;
	let tokenServiceConfirmSpy;
	let tokenServiceStateSpy;
	let tokenServiceCloseDialogSpy;
	let dataTransferServiceSpy;
	let dialog: DialogService;
	let routerSpy;
	let beneficiaryServiceSpy;

	const tokenServiceConfirmRes = { ok:200 };
	const dataPayeeClabeRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "CLABE",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeMobileAccRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "MOBILE_ACCOUNT",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeThirdPartyAccRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "THIRDPARTY_DEBIT_CARD",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeSartanderAccRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "1234567890123456",
		  "account_type": "SANTANDER_ACCOUNT",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeCCRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "134567894563456789",
		  "account_type": "CREDIT_CARD",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};
	const dataPayeeSartanderCCRes = { data :  {
		"key": "1omfttw29olss0r9286tpgmyomeldijb",
		"account": {
		  "number": "1234567890123456",
		  "account_type": "SANTANDER_CREDIT_CARD",
		  "bank": "SCOTIABANK"
		},
		"name": "Ida Sullivan",
		"alias": "Bachelor of Engineering",
		"url": "/beneficiaries/{beneficiary-key}"
	  } 
	};

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
                RouterTestingModule,
                AvatarModule,
                BeneficiaryOperationLibraryRoutingModule,
                ButtonModule,
                CommonModule,
                DialogSelectModule,
                EmojiModule,
                FormFieldModule,
                FormsModule,
                IconModule,
                IconButtonModule,
                InputModule,
                ReactiveFormsModule,
                ChipModule,
                NgxMaskModule.forRoot(),
                ProductModule,
                ThemeModule.forRoot({
                    themes: [FlameFoundationTheme],
                    active: 'flame-foundation'
                }),
                TokenDialogModule,
                TopBarModule,
                HiddenButtonsModule,
                SearchBarModule,
                SlideButtonModule,
                CheckboxModule,
				RouterModule.forRoot([])
			],
			declarations: [
				ConfirmPayeeDialogViewComponent,
				BeneficiaryInfoViewComponent,
				BeneficiaryFilterPipe,
                BeneficiaryProductsFilterPipe,
                ...BeneficiaryViewComponents,
                ...BeneficiaryOperationLibraryComponents
			],
			schemas: [
                CUSTOM_ELEMENTS_SCHEMA,
                NO_ERRORS_SCHEMA
            ],
			providers: [
                BeneficiaryService,
				TokenDialogService,
				DialogService,
				ContactDialogService,
				DataTransferService,
				MaskPipe,
				ConfirmPayeeDialogViewComponent,
             
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api/',
							version: {
								transfers : '1'
							}

						}
					}
				},
				{ provide: Injector, useValue: {} },
				{ provide: APP_BASE_HREF, useValue:'/' }             
            ]
		}).compileComponents();
	}));

	beforeEach(() => {
		
		router = TestBed.get(Router);
		
		dataTransferService = TestBed.get(DataTransferService);
		beneficiaryService = TestBed.get(BeneficiaryService);
		contactDialogService = TestBed.get(ContactDialogService);
		dialog = TestBed.get(DialogService);
		
		formInfoBuilder = new FormBuilder();
		
		beneficiaryInfoForm = formInfoBuilder.group({
			alias: formInfoBuilder.control(''),
			limit: formInfoBuilder.control(''),
			rfc: formInfoBuilder.control(''),
			bank: formInfoBuilder.control('', [Validators.required]),
			name: formInfoBuilder.control('', [Validators.required])
		});

		routerSpy = spyOn(router, 'navigate');
		dataTransferServiceSpy = spyOn(dataTransferService, 'getData').and.returnValue(Promise.resolve(dataPayeeClabeRes));
		tokenService = TestBed.get(TokenDialogService);
		tokenServiceConfirmSpy = spyOn(tokenService, 'getConfirmEvent').and.returnValue(of(tokenServiceConfirmRes));
		tokenServiceStateSpy = spyOn(tokenService, 'getStateDialog').and.returnValue(of('closed'));
		tokenServiceCloseDialogSpy = spyOn(tokenService, 'closeDialogToken').and.callFake(()=>{});
		beneficiaryServiceSpy = spyOn(beneficiaryService, 'postDataBeneficiary').and.returnValue(of({}));
		spyOn(dataTransferService,'sendData').and.callFake(()=>{});
		

		fixture = TestBed.createComponent(BeneficiaryInfoViewComponent);
		component = fixture.componentInstance;
		component.dataPayeeLookup = dataPayeeClabeRes.data;
		component.beneficiaryInfoFormBuilder();
		fixture.detectChanges();
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
		
	});

	it('should validate service calls', ()=> {
		fixture.detectChanges();
		
		expect(tokenServiceConfirmSpy).toHaveBeenCalled();
		expect(tokenServiceStateSpy).toHaveBeenCalled();
		expect(tokenServiceStateSpy).toHaveBeenCalled();
		expect(tokenServiceConfirmSpy).toHaveBeenCalled();
		expect(dataTransferServiceSpy).toHaveBeenCalled();
		expect(beneficiaryServiceSpy).toHaveBeenCalled();
		expect(routerSpy).toHaveBeenCalledWith(['/beneficiary/voucher'], {
			queryParams: {
				isNew: true
			}
		});
	});

	it('should validate textAccountCase', ()=>{
		let result = '';
		component.dataPayeeLookup = dataPayeeSartanderCCRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de tarjeta');
		component.dataPayeeLookup = dataPayeeCCRes.data;
		result = component.textAccountCase();
		component.dataPayeeLookup = dataPayeeSartanderAccRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de tarjeta');
		component.dataPayeeLookup = dataPayeeThirdPartyAccRes.data;
		result = component.textAccountCase();
		component.dataPayeeLookup = dataPayeeClabeRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('Clabe');
		component.dataPayeeLookup = dataPayeeMobileAccRes.data;
		result = component.textAccountCase();
		expect(result).toEqual('No. de celular');
	});

	it('should redirect to', ()=>{
		component.redirectTo('back');
		expect(routerSpy).toHaveBeenCalledWith(['/beneficiary/user-account']);
		contactDialogService = TestBed.get(ContactDialogService);
		const serviceSpy = spyOn(contactDialogService, 'openDialogContact');
		component.redirectTo('s');
		expect(serviceSpy).toHaveBeenCalled();

	});
	

	it('should confirm new contact',()=>{
		component.beneficiaryInfoForm.controls['alias'].setValue('La cuenta');
		component.beneficiaryInfoForm.controls['limit'].setValue('1234567891');
		component.beneficiaryInfoForm.controls['rfc'].setValue('1234567891');
		component.beneficiaryInfoForm.controls['bank'].setValue('"Santander"');
		component.beneficiaryInfoForm.controls['name'].setValue('Mariana Jimenez Cruz');
		fixture.detectChanges(); 
		
		TestBed.get(ConfirmPayeeDialogViewComponent);   
		const dialog = TestBed.get(DialogService);
		spyOn(dialog, 'open').and.callFake(()=>{});

		spyOn(component.closeEventSlide, 'subscribe').and.returnValue(false);

		spyOn(component, 'confirm').and.callThrough();
		const button = fixture.debugElement.nativeElement.querySelector('button');
		button.click();
		fixture.detectChanges(); 
		expect(component.confirm).toHaveBeenCalled();

	});

	it('should select option', ()=>{
		const noBankAccount = {...dataPayeeClabeRes};
		noBankAccount.data.account.bank = undefined;

		component.onSelectedOption({"text":{"name":"Santander","value":"Santander"}});
		expect(component.bankValue).toEqual('Santander');
		expect(component.beneficiaryInfoForm.get('bank')).toBeTruthy();
	});


});
