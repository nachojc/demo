import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import {
	TokenDialogService,
	ContactDialogService,
  CustomToken
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { GeneralFunction } from '../../helpers/general-function';

@Component({
	selector: 'sm-beneficiary-info-view',
	templateUrl: './beneficiary-info-view.component.html',
	styleUrls: ['./beneficiary-info-view.component.scss']
})
export class BeneficiaryInfoViewComponent implements OnInit {
	/**
	 * variables
	 *
	 * @memberof BeneficiaryInfoViewComponent
	 */
	public generalFunction = GeneralFunction;
	public disabled = true;
	private _bankValue: string;
	public options = [
		{ value: 'Santander' },
		{ value: 'BBVA Bancomer' },
		{ value: 'Banamex' },
		{ value: 'Banorte' },
		{ value: 'Scotiabank' },
		{ value: 'HSBC' },
		{ value: 'Banco Azteca' },
		{ value: 'Banregio' },
		{ value: 'Inbursa' },
		{ value: 'Banco del Bajío' }
	];
	public optionsSended = this.options.map(option => {
		return {
			name: option.value,
			value: option.value
		};
	});
	public avatarName = 'S';
	public confirmedToken = false;
	public dataPayeeLookup: any;
	public key: String;
	public beneficiaryInfoForm: FormGroup;

	constructor(
		private _dataTransferService: DataTransferService,
		private formBuilder: FormBuilder,
		private _router: Router,
		private _tokenDialogService: TokenDialogService,
		private beneficiaryService: BeneficiaryService,
		private contactDialogService: ContactDialogService
	) {}

	/**
	 * se crea el formulario
	 *
	 * @private
	 * @memberof BeneficiaryInfoViewComponent
	 */
	private beneficiaryInfoFormBuilder() {
		this.beneficiaryInfoForm = this.formBuilder.group({
			alias: this.formBuilder.control('', []),
			limit: this.formBuilder.control('', []),
			rfc: this.formBuilder.control('', []),
			bank: this.formBuilder.control('', []),
			name: this.formBuilder.control('', [])
		});
	}

	/**
   * se revisa si el token es valido
   *
   * @memberof BeneficiaryInfoViewComponent
   */
  checkToken() {
		this._tokenDialogService.getConfirmEvent().subscribe(res => {
			this.confirmedToken = true;
			setTimeout(() => {
				if (res.ok === 200) {
					this._tokenDialogService.closeDialogToken();
				}
			}, 100);
		});
		this._tokenDialogService.getStateDialog().subscribe(res => {
			if (res === 'closed' && this.confirmedToken) {
				this.postData();
			}
		});
	}

	/**
   *
   *
   * @param {*} answer
   * @memberof BeneficiaryInfoViewComponent
   */
  public onSelectedOption(answer) {
		this.enableAnswer(answer);
	}

	public enableAnswer(answer) {
		this._bankValue = answer.text.value;
		this.beneficiaryInfoForm.get('bank').enable();
	}

	/**
   * se evalua para el texto del titulo tarjet, banco, telefo y cuenta
   *
   * @returns {string}
   * @memberof BeneficiaryInfoViewComponent
   */
  textAccountBankName(): string {
		if (
			this.dataPayeeLookup.account.account_type === 'SANTANDER_ACCOUNT' &&
			this.dataPayeeLookup.account.number.length !== 16
		)
			return 'Cuenta*';
		if (this.dataPayeeLookup.account.number.length === 16) return 'Tarjeta*';
		if (this.dataPayeeLookup.account.account_type === 'MOBILE_ACCOUNT')
			return 'Celular*';
		if (
			this.dataPayeeLookup.account.account_type === 'CLABE' &&
			this.dataPayeeLookup.account.number.length === 18
		)
			return 'CLABE*';
	}

	/**
   * metodo para regresar a la pantalla anterior o abrir el modal de contacto
   *
   * @param {string} action
   * @memberof BeneficiaryInfoViewComponent
   */
  redirectTo(action: string) {
		if (action === 'back') {
			this._router.navigate(['/beneficiary/user-account']);
		} else {
			this.contactDialogService.openDialogContact(1);
		}
	}

	confirm() {
    const params: CustomToken = {
      subtitle: 'Ingresa tu clave de 4 dígitos para confirmar',
      title: 'Confirma con tu SuperToken',
      closeLabel: 'Cancelar',
      showTokenInput: true,
      typeButton: 'basic'
    };
		this._tokenDialogService.openDialogToken(params);
	}

	/**
   * se crea el request del post
   *
   * @returns {*}
   * @memberof BeneficiaryInfoViewComponent
   */
  createRequest(): any {
		return {
			name:
				this.dataPayeeLookup.name === undefined ||
				this.dataPayeeLookup.name === ''
					? this.beneficiaryInfoForm.get('name').value
					: this.dataPayeeLookup.name,
			account: {
				number: this.dataPayeeLookup.account.number,
				bank:
					this.dataPayeeLookup.account.bank === undefined ||
					this.dataPayeeLookup.account.bank === ''
						? this._bankValue
						: this.dataPayeeLookup.account.bank,
				account_type: this.dataPayeeLookup.account.account_type
			},
			alias: this.beneficiaryInfoForm.get('alias').value,
			personal_identifier: this.beneficiaryInfoForm.get('rfc').value,
			transfer_limit: this.beneficiaryInfoForm.get('limit').value
		};
	}

	/**
   * sde envia los datos en el metodo post
   *
   * @memberof BeneficiaryInfoViewComponent
   */
  postData() {
		this.beneficiaryService
			.postDataBeneficiary(this.createRequest())
			.subscribe(resPost => {
				this._dataTransferService.sendData(resPost);
				this._router.navigate(['/beneficiary/voucher'], {
					queryParams: {
						isNew: true
					}
				});
			});
	}

	ngOnInit(): void {
		this.beneficiaryInfoFormBuilder();
		this.checkToken();
		this._dataTransferService.getData().then(res => {
			this.dataPayeeLookup = res.data;
			if (this.dataPayeeLookup.account.account_type === 'SANTANDER_ACCOUNT') {
				this.beneficiaryInfoForm.controls.name.setValidators(null);
				this.beneficiaryInfoForm.controls.bank.setValidators(null);
				this.beneficiaryInfoForm.controls.name.updateValueAndValidity();
				this.beneficiaryInfoForm.controls.bank.updateValueAndValidity();
			}
		});
	}
}
