import { Component, OnInit, EventEmitter } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
	TokenDialogService,
	ContactDialogService,
	CustomToken,
	DialogReference,
	DialogService,
	CustomDialog
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { GeneralFunction } from '../../helpers/general-function';
import { ConfirmPayeeDialogViewComponent } from '../../components/confirm-dialog-view/confirm-dialog-view.component';
import { timer } from 'rxjs';

@Component({
	selector: 'sm-beneficiary-info-view',
	templateUrl: './beneficiary-info-view.component.html',
	styleUrls: ['./beneficiary-info-view.component.scss']
})
export class BeneficiaryInfoViewComponent implements OnInit {
	/**
	 * variables
	 *
	 * @memberof BeneficiaryInfoViewComponent
	 */

	private _dialogRef: DialogReference;

	public bankValue: string;
	public generalFunction = GeneralFunction;
	public disabled = true;
	public options = [
		{ value: 'Santander' },
		{ value: 'BBVA Bancomer' },
		{ value: 'Banamex' },
		{ value: 'Banorte' },
		{ value: 'Scotiabank' },
		{ value: 'HSBC' },
		{ value: 'Banco Azteca' },
		{ value: 'Banregio' },
		{ value: 'Inbursa' },
		{ value: 'Banco del Bajío' }
	];
	public optionsSended = this.options.map(option => {
		return {
			name: option.value,
			value: option.value
		};
	});
	public avatarName = 'S';
	public formatCase: string;
	public selectTarjet = 'chip-2';
	public confirmedToken = false;
	public dataPayeeLookup: any;
	public key: String;
	public beneficiaryInfoForm: FormGroup;
	public closeEventSlide = new EventEmitter<boolean>();

	constructor(
		private _dataTransferService: DataTransferService,
		private formBuilder: FormBuilder,
		private _router: Router,
		private _tokenDialogService: TokenDialogService,
		private beneficiaryService: BeneficiaryService,
		private contactDialogService: ContactDialogService,
		private dialog: DialogService
	) {}

	/**
	 * se crea el formulario
	 *
	 * @private
	 * @memberof BeneficiaryInfoViewComponent
	 */
	public beneficiaryInfoFormBuilder() {
		this.beneficiaryInfoForm = this.formBuilder.group({
			alias: this.formBuilder.control(''),
			limit: this.formBuilder.control(''),
			rfc: this.formBuilder.control(''),
			bank: this.formBuilder.control('', [Validators.required]),
			name: this.formBuilder.control('', [Validators.required])
		});
	}

	/**
	 * se asigna validators
	 *
	 * @memberof BeneficiaryInfoViewComponent
	 */
	setValidatorForm() {
		if (this.dataPayeeLookup.account.bank && this.dataPayeeLookup.name) {
			this.beneficiaryInfoForm.controls.name.setValidators(null);
			this.beneficiaryInfoForm.controls.bank.setValidators(null);
		}
		if (this.dataPayeeLookup.account.bank) {
			this.beneficiaryInfoForm.controls.bank.setValidators(null);
		}
		if (this.dataPayeeLookup.name) {
			this.beneficiaryInfoForm.controls.name.setValidators(null);
		}
		this.beneficiaryInfoForm.get('alias').setValue(this.dataPayeeLookup.alias);
	}

	/**
	 * se revisa si el token es valido
	 *
	 * @memberof BeneficiaryInfoViewComponent
	 */
	checkToken() {
		this._tokenDialogService.getConfirmEvent().subscribe(res => {
			this.confirmedToken = true;
			if (res.ok === 200) {
				timer(500).subscribe(() => {
					this._tokenDialogService.closeDialogToken();
				});
			}
		});
		this._tokenDialogService.getStateDialog().subscribe(res => {
			if (res === 'closed' && this.confirmedToken) {
				this.postData();
			}
		});
	}

	/**
	 *
	 *
	 * @param {*} answer
	 * @memberof BeneficiaryInfoViewComponent
	 */
	public onSelectedOption(answer) {
		this.enableAnswer(answer);
	}

	/**
	 *
	 * evento que setea el chip seleccionado
	 * @param {*} evt
	 * @memberof BeneficiaryInfoViewComponent
	 */
	selectedChip(evt: any) {
		this.selectTarjet = evt.num;
	}

	/**
	 * se obtiene la respuesta del banco en caso de no tener
	 *
	 * @param {*} answer
	 * @memberof BeneficiaryInfoViewComponent
	 */
	public enableAnswer(answer) {
		this.bankValue = answer.text.value;
		this.beneficiaryInfoForm.get('bank').enable();
	}

	/**
	 * se evalua para el texto del titulo tarjet, banco, telefo y cuenta
	 *
	 * @returns {string}
	 * @memberof BeneficiaryInfoViewComponent
	 */
	textAccountCase(): string {
		let text: string;
		switch (true) {
			case (this.dataPayeeLookup.account.account_type ===
				'SANTANDER_CREDIT_CARD' ||
				this.dataPayeeLookup.account.account_type === 'CREDIT_CARD') &&
				this.dataPayeeLookup.account.number.length === 16:
				this.formatCase = '0000 0000 0000 0000';
				text = 'No. de tarjeta';
				break;
			case (this.dataPayeeLookup.account.account_type === 'SANTANDER_ACCOUNT' ||
				this.dataPayeeLookup.account.account_type ===
					'THIRDPARTY_DEBIT_CARD') &&
				this.dataPayeeLookup.account.number.length === 16:
				this.formatCase = '0000000000000000';
				text = 'No. de tarjeta';
				break;
			case this.dataPayeeLookup.account.account_type === 'CLABE':
				this.formatCase = '000000000000000000';
				text = 'Clabe';
				break;
			case this.dataPayeeLookup.account.account_type === 'MOBILE_ACCOUNT':
				this.formatCase = '00 0000 0000';
				text = 'No. de celular';
				break;
		}
		return text;
	}

	/**
	 * metodo para regresar a la pantalla anterior o abrir el modal de contacto
	 *
	 * @param {string} action
	 * @memberof BeneficiaryInfoViewComponent
	 */
	redirectTo(action: string) {
		if (action === 'back') {
			this._router.navigate(['/beneficiary/user-account']);
		} else {
			this.contactDialogService.openDialogContact(1);
		}
	}

	confirm() {
		const dataConfirm = this.createRequest();
		this.closeEventSlide.subscribe((response: boolean) => {
			if (response === true) {
				timer(500).subscribe(() => {
					this._dialogRef.close();
					this.postData();
				});
			} else {
				this._dialogRef.close();
			}
		});
		dataConfirm.event = this.closeEventSlide;

		this._dialogRef = this.dialog.open(
			{
				closeLabel: 'Cerrar',
				title: 'Confirma tus datos',
				enableHr: true,
				showButton: false,
				closeBackdropClick: true
			},
			new CustomDialog(ConfirmPayeeDialogViewComponent, {
				dataConfirm: dataConfirm
			})
		);
	}

	/**
	 * se crea el request del post
	 *
	 * @returns {*}
	 * @memberof BeneficiaryInfoViewComponent
	 */
	createRequest(): any {
		
		return {
			name:
				this.dataPayeeLookup.name === undefined ||
				this.dataPayeeLookup.name === ''
					? this.beneficiaryInfoForm.get('name').value
					: this.dataPayeeLookup.name,
			account: {
				number: this.dataPayeeLookup.account.number,
				bank:
					this.dataPayeeLookup.account.bank === undefined ||
					this.dataPayeeLookup.account.bank === ''
						? this.bankValue
						: this.dataPayeeLookup.account.bank,
				account_type: this.dataPayeeLookup.account.account_type
			},
			alias: this.beneficiaryInfoForm.get('alias').value,
			personal_identifier: this.beneficiaryInfoForm.get('rfc').value,
			transfer_limit: this.beneficiaryInfoForm.get('limit').value
		};
	}

	/**
	 * sde envia los datos en el metodo post
	 *
	 * @memberof BeneficiaryInfoViewComponent
	 */
	postData() {
		this.beneficiaryService
			.postDataBeneficiary(this.createRequest())
			.subscribe(resPost => {
				this._dataTransferService.sendData(resPost);
				this._router.navigate(['/beneficiary/voucher'], {
					queryParams: {
						isNew: true
					}
				});
			});
	}

	ngOnInit(): void {
		this.beneficiaryInfoFormBuilder();
		this.checkToken();
		this._dataTransferService.getData().then(response => {
			this.dataPayeeLookup = response.data;
			this.setValidatorForm();
		});
	}
}
