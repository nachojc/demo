import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TokenDialogService } from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryInterface } from '../../interfaces/beneficiary.interface';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { GeneralFunction } from '../../helpers/general-function';
import { PayeeExternalResponse } from '../../models/payee-external-response';
import { PayeeInfo } from '../../models/payee-info';

@Component({
	selector: 'sm-beneficiary-info-view',
	templateUrl: './beneficiary-info-view.component.html',
	styleUrls: ['./beneficiary-info-view.component.scss']
})
export class BeneficiaryInfoViewComponent implements OnInit {
	// control
	public generalFunction = GeneralFunction;
	public disabled = true;
	private _bankValue: string;
	public options = [
		{ value: 'Santander' },
		{ value: 'BBVA Bancomer' },
		{ value: 'Banamex' },
		{ value: 'Banorte' },
		{ value: 'Scotiabank' },
		{ value: 'HSBC' },
		{ value: 'Banco Azteca' },
		{ value: 'Banregio' },
		{ value: 'Inbursa' },
		{ value: 'Banco del Bajío' }
	];

	public optionsSended = this.options.map(option => {
		return {
			name: option.value,
			value: option.value
		};
	});

	public avatarName = 'S';
	public confirmedToken = false;
	public dataPayeeLookup: any;
	public key: String;
	public beneficiaryInfoForm: FormGroup;
	public beneficiary: PayeeInfo;

	constructor(
		private _dataTransferService: DataTransferService,
		private formBuilder: FormBuilder,
		private _router: Router,
		private _tokenDialogService: TokenDialogService,
		private beneficiaryService: BeneficiaryService
	) {}

	ngOnInit(): void {
		this._dataTransferService.getData().then(res => {
			this.dataPayeeLookup = res.data[0];
			if (this.dataPayeeLookup.account.type === 'SANTANDER_ACCOUNT') {
				this.beneficiaryInfoForm.controls.name.setValidators(null);
				this.beneficiaryInfoForm.controls.bank.setValidators(null);
				this.beneficiaryInfoForm.controls.name.updateValueAndValidity();
				this.beneficiaryInfoForm.controls.bank.updateValueAndValidity();
			}
		});

		this.beneficiaryInfoFormBuilder();
		//token input
		this._tokenDialogService.getConfirmEvent().subscribe(res => {
			this.confirmedToken = true;
			setTimeout(() => {
				if (res.ok === 200) {
					this._tokenDialogService.closeDialogToken();
				}
			}, 100);
		});
		this._tokenDialogService.getStateDialog().subscribe(res => {
			if (res === 'closed' && this.confirmedToken) {
				this.postData();
			}
		});
	}

	private beneficiaryInfoFormBuilder() {
		this.beneficiaryInfoForm = this.formBuilder.group({
			alias: this.formBuilder.control('', []),
			limit: this.formBuilder.control('', []),
			RFC: this.formBuilder.control('', []),
			bank: this.formBuilder.control('', []),
			name: this.formBuilder.control('', [])
		});
	}

	fieldReset(key: string) {
		this.beneficiaryInfoForm.controls[key].reset();
	}

	public onSelectedOption(answer) {
		this.enableAnswer(answer);
	}

	public enableAnswer(answer) {
		this._bankValue = answer.text.value;
		this.beneficiaryInfoForm.get('bank').enable();
  }

  textAccountBankName(): string {
    if(this.dataPayeeLookup.account.type === 'SANTANDER_ACCOUNT' && this.dataPayeeLookup.account.number.length !== 16 ) return 'Cuenta*';
    if(this.dataPayeeLookup.account.number.length === 16) return 'Tarjeta*';
    if(this.dataPayeeLookup.account.type === 'SANTANDER_MOBILE_ACCOUNT' || this.dataPayeeLookup.account.type === 'THIRDPARTY_MOBILE_ACCOUNT') return 'Celular*';
    if(this.dataPayeeLookup.account.type === 'CLABE' && this.dataPayeeLookup.account.number.length === 18 ) return 'CLABE*';
  }

	navigateBack() {
		this._router.navigate(['/beneficiary/user-account']);
	}

	confirm() {
		this._tokenDialogService.openDialogToken();
	}

	postData() {
		this.beneficiary = {
			name:
				this.dataPayeeLookup.name === undefined
					? this.beneficiaryInfoForm.get('name').value
					: this.dataPayeeLookup.name,
			account: {
				number: this.dataPayeeLookup.account.number,
				bank:
					this.dataPayeeLookup.account.bank === undefined
						? this._bankValue
						: this.dataPayeeLookup.account.bank,
				type: this.dataPayeeLookup.account.type
			},
			alias: this.beneficiaryInfoForm.get('alias').value,
			personal_identifier: this.beneficiaryInfoForm.get('RFC').value,
			transfer_limit: this.beneficiaryInfoForm.get('limit').value
		};
		this.beneficiaryService
			.postDataBeneficiary(this.beneficiary)
			.subscribe(resPost => {
				this._dataTransferService.sendData(resPost);
				this._router.navigate(['/beneficiary/voucher'], {
					queryParams: {
						isNew: true
					}
				});
			});
	}
}
