import { Component, OnInit, EventEmitter } from '@angular/core';
import { BeneficiaryInterface } from '../../interfaces/beneficiary.interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {
	DialogService,
	DialogReference,
	ContactDialogService,
  CustomDialog
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { DataTransferService } from '@santander/flame-core-library';
import { GeneralFunction } from '../../helpers/general-function';
import { PayeesResponse } from '../../models/payees-response';
import { ModifyRequest } from '../../models/modify-request';
import { timer } from 'rxjs';
import { ConfirmPayeeDialogViewComponent } from '../../components/confirm-dialog-view/confirm-dialog-view.component';

@Component({
	selector: 'sm-beneficiary-edit',
	templateUrl: './beneficiary-edit.component.html',
	styleUrls: ['./beneficiary-edit.component.scss']
})
export class BeneficiaryEditComponent implements OnInit {

  /**
   * variables
   *
   * @private
   * @type {DialogReference}
   * @memberof BeneficiaryEditComponent
   */
  private dialogRef: DialogReference;
  private _dialogRef: DialogReference;

	public isEdit = false;
	public generalFunction = GeneralFunction;
	public beneficiary: BeneficiaryInterface;
	public beneficiaryInfoForm: FormGroup;
	public beneficiaryData: any;
  public dataSend: ModifyRequest;
  public closeEventSlide = new EventEmitter<boolean>();

	constructor(
		private formBuilder: FormBuilder,
		private dialog: DialogService,
		private _router: Router,
		private beneficiaryService: BeneficiaryService,
		private _dataTransferService: DataTransferService,
		private contactDialogService: ContactDialogService
	) {}

	/**
	 * metodo para regresar a la pantalla anterior o abrir el modal de contacto
	 *
	 * @param {string} action
	 * @memberof BeneficiaryInfoViewComponent
	 */
	redirectTo(action: string) {
		if (action === 'back') {
			this._router.navigate(['/beneficiaries-services']);
		} else {
			this.contactDialogService.openDialogContact(1);
		}
	}

	/** metodo para obtener el key de la busqueda de contacto y asi llamar al servicio que regresa el detalle del contacto
   *
   *
   * @returns {Promise<any>}
   * @memberof BeneficiaryEditComponent
   */
  getInfoService(): Promise<any> {
		return new Promise(resolve => {
			this._dataTransferService.getData().then(keyBeneficiary => {
				resolve(
					this.beneficiaryService
						.getInfoByKey(keyBeneficiary)
						.subscribe(response => {
							this.beneficiaryData = response;
							this.setDataForm();
						})
				);
			});
		});
	}

	/**
   * metodo que setea valores en el input
   *
   * @memberof BeneficiaryEditComponent
   */
  setDataForm() {
		this.beneficiaryInfoForm
			.get('alias')
			.setValue(this.beneficiaryData.data.alias);
		this.beneficiaryInfoForm
			.get('rfc')
			.setValue(this.beneficiaryData.data.personal_identifier);
		this.beneficiaryInfoForm
			.get('limit')
			.setValue(this.beneficiaryData.data.transfer_limit);
	}

	/**
   * metodo para el aviso al eliminar el contacto
   *
   * @memberof BeneficiaryEditComponent
   */
  deleteContact() {
    const dataConfirm = this.createRequest();
    this.closeEventSlide.subscribe( (response: boolean) => {
      if (response === true) {
				timer(500).subscribe(() => {
          this._dialogRef.close();
          this.deleteAction();
				});
      } else {
        this._dialogRef.close();
      }
    });

    dataConfirm.event = this.closeEventSlide;

    this._dialogRef = this.dialog.open(
      {
        closeLabel: 'Cerrar',
        title: 'Eliminar contacto',
        enableHr: true,
        showButton: false,
        closeBackdropClick: true
      },
      new CustomDialog(ConfirmPayeeDialogViewComponent, {
        dataConfirm: dataConfirm
      })
    );
	}


  	/**
   * se crea el request del post
   *
   * @returns {*}
   * @memberof BeneficiaryInfoViewComponent
   */
  createRequest(): any {
		return {
			name: this.beneficiaryData.data.name,
			account: {
				number: this.beneficiaryData.data.account.number,
				bank:	this.beneficiaryData.data.account.bank,
				account_type: this.beneficiaryData.data.account.account_type
			},
			alias: this.beneficiaryData.data.alias,
			personal_identifier: this.beneficiaryData.data.personal_identifier
		};
  }


	/**
   * se llama al servicio de eliminar
   *
   * @memberof BeneficiaryEditComponent
   */
  deleteAction() {
		// falta una definición de apis de como dar de baja el beneficiario.
		this.beneficiaryService
			.deletePayee(this.beneficiaryData.data.key)
			.subscribe(
				response => {
					this._dataTransferService.sendData(response);
					// end
					this._router.navigate(['/beneficiary/voucher'], {
						queryParams: {
							isNew: false
						}
					});
				},
				error => {
					// error
				}
			);
	}

	/**
   * metodo que evalua si se va editar o  no
   *
   * @memberof BeneficiaryEditComponent
   */
  changeStateEdit() {
		this.isEdit = !this.isEdit;
		if (!this.isEdit) {
			this.beneficiaryInfoForm
				.get('alias')
				.setValue(this.beneficiaryData.data.alias);
			this.beneficiaryInfoForm
				.get('rfc')
				.setValue(this.beneficiaryData.data.personal_identifier);
			this.beneficiaryInfoForm
				.get('limit')
				.setValue(this.beneficiaryData.data.transfer_limit);
		}
	}

	/**
   * metodo para actualizar un c ontacto
   *
   * @memberof BeneficiaryEditComponent
   */
  updateInfoBeneficiary() {
		this.dataSend = {
			alias: this.beneficiaryInfoForm.get('alias').value,
			personal_identifier: this.beneficiaryInfoForm.get('rfc').value,
			transfer_limit: this.beneficiaryInfoForm.get('limit').value
		};
		this.beneficiaryService
			.updateBeneficiary(this.beneficiaryData.data.key, this.dataSend)
			.subscribe(resUpdate => {
				this.beneficiaryData = resUpdate;
				this.setDataForm();
				this.isEdit = false;
			});
	}

	/**
   * metoto que retorna el texto
   *
   * @returns {string}
   * @memberof BeneficiaryEditComponent
   */
  textAccountBankName(): string {
		if (
			this.beneficiaryData.data.account.account_type === 'SANTANDER_ACCOUNT' &&
			this.beneficiaryData.data.account.number.length !== 16
		)
			return 'Cuenta*';
		if (this.beneficiaryData.data.account.number.length === 16)
			return 'Tarjeta*';
		if (this.beneficiaryData.data.account.account_type === 'MOBILE_ACCOUNT')
			return 'Celular*';
		if (
			this.beneficiaryData.data.account.account_type === 'CLABE' &&
			this.beneficiaryData.data.account.number.length === 18
		)
			return 'CLABE*';
	}

	ngOnInit() {
		this.beneficiaryInfoForm = this.formBuilder.group({
			alias: this.formBuilder.control(null, [
				Validators.maxLength(20),
				Validators.required
			]),
			limit: this.formBuilder.control(null, [Validators.required]),
			rfc: this.formBuilder.control(null, [Validators.required])
		});
		this.getInfoService();
	}
}
