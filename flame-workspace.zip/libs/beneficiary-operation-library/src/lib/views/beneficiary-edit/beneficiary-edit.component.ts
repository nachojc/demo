import { Component, OnInit } from '@angular/core';
import { BeneficiaryInterface } from '../../interfaces/beneficiary.interface';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import {
	DialogService,
	DialogReference
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { DataTransferService } from '@santander/flame-core-library';
import { GeneralFunction } from '../../helpers/general-function';
import { PayeesResponse } from '../../models/payees-response';
import { ModifyRequest } from '../../models/modify-request';

@Component({
	selector: 'sm-beneficiary-edit',
	templateUrl: './beneficiary-edit.component.html',
	styleUrls: ['./beneficiary-edit.component.scss']
})
export class BeneficiaryEditComponent implements OnInit {
	//variables
	isEdit = false;
	public generalFunction = GeneralFunction;

	// control
	public beneficiary: BeneficiaryInterface;
	public beneficiaryInfoForm: FormGroup;
	private dialogRef: DialogReference;
	public beneficiaryData: any;
	public dataSend: ModifyRequest;

	constructor(
		private formBuilder: FormBuilder,
		private dialog: DialogService,
		private _router: Router,
		private beneficiaryService: BeneficiaryService,
		private _dataTransferService: DataTransferService
	) {}

	ngOnInit() {
		this.beneficiaryInfoForm = this.formBuilder.group({
			alias: this.formBuilder.control(null, [Validators.maxLength(20)]),
			limit: this.formBuilder.control(null, []),
			rfc: this.formBuilder.control(null, [])
		});
		this.getInfoService();
	}

	getInfoService(): Promise<any> {
		return new Promise(resolve => {
			this._dataTransferService.getData().then(keyBeneficiary => {
				resolve(
					this.beneficiaryService
						.getInfoByKey(keyBeneficiary)
						.subscribe(response => {
              this.beneficiaryData = response;
              this.setDataForm();
						})
				);
			});
		});
	}

	setDataForm() {
		this.beneficiaryInfoForm
			.get('alias')
			.setValue(this.beneficiaryData.data.alias);
		this.beneficiaryInfoForm
			.get('rfc')
			.setValue(this.beneficiaryData.data.personal_identifier);
		this.beneficiaryInfoForm
			.get('limit')
			.setValue(this.beneficiaryData.data.transfer_limit);
	}

	deleteContact() {
		this.dialogRef = this.dialog.open({
			closeLabel: 'Cancelar',
			title: 'Eliminar contacto',
			body: `<div>
                <img src="assets/icons/icon-nodisponible.jpg" alt="" />
                <p class="mb-4 mt-4">¿Estás seguro que deseas eliminar el siguiente contacto?</p>
                <div class="mb-5">
                  <p style="margin-bottom: 0px;"><strong>Nombre: ${
										this.beneficiaryData.data.name
									}</strong></p>
									<p style="margin-bottom: 0px;">Alias: ${
										this.beneficiaryData.data.alias
									}</p>
                  <p style="margin-bottom: 0px;">Banco ${
										this.beneficiaryData.data.account.bank
									}</p>
                  <p style="margin-bottom: 0px;">Cuenta: ${
										this.beneficiaryData.data.account.number
									}</p>
                </div>
            </div>`,
			enableHr: false,
			disabledButton: true,
			buttons: [
				{
					label: 'Eliminar contacto',
					class: 'strech',
					action: scope => {
						this.deleteAction();
					}
				}
			]
		});
	}

	deleteAction() {
		this.dialogRef.close();
		// falta una definición de apis de como dar de baja el beneficiario.
		this.beneficiaryService.deletePayee(this.beneficiaryData.data.key).subscribe(
      resDelete => {
        this._dataTransferService.sendData(resDelete);
        // end
        this._router.navigate(['/beneficiary/voucher'], {
          queryParams: {
            isNew: false
          }
        });
      },
      error => {
        // error
      }
    );
	}

	changeStateEdit() {
		this.isEdit = !this.isEdit;
		if (!this.isEdit) {
			this.beneficiaryInfoForm
				.get('alias')
				.setValue(this.beneficiaryData.data.alias);
			this.beneficiaryInfoForm
				.get('rfc')
				.setValue(this.beneficiaryData.data.personal_identifier);
			this.beneficiaryInfoForm
				.get('limit')
				.setValue(this.beneficiaryData.data.transfer_limit);
		}
	}

	updateInfoBeneficiary() {
		this.dataSend = {
			alias: this.beneficiaryInfoForm.get('alias').value,
			personal_identifier: this.beneficiaryInfoForm.get('rfc').value,
			transfer_limit: this.beneficiaryInfoForm.get('limit').value
		};
		this.beneficiaryService
			.updateBeneficiary(this.beneficiaryData.data.key, this.dataSend)
			.subscribe(resUpdate => {
        this.beneficiaryData = resUpdate;
        this.setDataForm();
				this.isEdit = false;
			});
	}

	clearInput(inputName: string) {
		this.beneficiaryInfoForm.get(inputName).reset();
  }

  textAccountBankName(): string {
    if(this.beneficiaryData.data.account.type === 'SANTANDER_ACCOUNT' && this.beneficiaryData.data.account.number.length !== 16 ) return 'Cuenta*';
    if(this.beneficiaryData.data.account.number.length === 16) return 'Tarjeta*';
    if(this.beneficiaryData.data.account.type === 'SANTANDER_MOBILE_ACCOUNT' || this.beneficiaryData.data.account.type === 'THIRDPARTY_MOBILE_ACCOUNT') return 'Celular*';
    if(this.beneficiaryData.data.account.type === 'CLABE' && this.beneficiaryData.data.account.number.length === 18 ) return 'CLABE*';
  }
}
