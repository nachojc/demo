import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { ListPayeesResponse } from '../../models/list-payees-response';
import { DialogReference, DialogService } from '@santander/flame-component-library';
import { bottomToTopSlideUpAnimation, bottomToTopItemAnimation, childListAnimation } from '../../animations/transitions/filter-list-transitions.animations';


@Component({
	selector: 'sm-payees-container',
	templateUrl: './payees-container.component.html',
	styleUrls: ['./payees-container.component.scss'],
	animations: [
		bottomToTopSlideUpAnimation,
		bottomToTopItemAnimation,
		childListAnimation
	]
})
export class PayeesContainerComponent implements OnInit {
	/**
	 * Crea una instancia de PayeesContainerComponent.
	 * @param {SummaryService} _summaryService
	 * @param {Router} _router
	 * @param {DataTransferService} _dataTransferService
	 * @param {BeneficiaryService} _beneficiaryService
	 * @memberof PayeesContainerComponent
	 */
	constructor(
		private _summaryService: SummaryService,
		private _router: Router,
		private _dataTransferService: DataTransferService,
		private _beneficiaryService: BeneficiaryService
	) {}
	// Variables privadas
	private cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
  ];

  // Variables publicas
  private _dialogRef: DialogReference;
	public searchBar = '';
	public categories = [];
	public beneficiaries: ListPayeesResponse;

	public closeEventSlide = new EventEmitter<boolean>();
	public elementState = '';
	public cards = [];

	// Inputs
	@Input() confirmedToken: boolean;

	/**
	 * Evento que se dispara cuando el usario presiona las teclas de salida
	 *
	 * @param {*} [el=null]
	 * @memberof PayeesContainerComponent
	 */
	public toggleSearch(el: any = null): void {
		this.elementState = 'in';
	}

	/**
	 * Evento que se dispara cuando el usuario cierra el campo de busqueda
	 *
	 * @param {*} [evt=any]
	 * @memberof PayeesContainerComponent
	 */
	public closeSearch(evt: any) {
		if (evt === 'sn-FUNC31') { //nombre del evento al presionar la X
			  this.searchBar = '';
			  this.elementState = 'in';
		}else{
			this.elementState = 'out';
		}
	}

	/**
	 * Permite navegar a editar un contacto o iniciar una transferencia
	 *
	 * @param {string} number
	 * @param {string} [idEvent]
	 * @memberof PayeesContainerComponent
	 */
	public navigateContact(beneficiary: any, idEvent?: string): void {
		if (idEvent && idEvent === '2') {
			this._router.navigate(['/transfers/initial']);
		} else if (idEvent && idEvent === '1') {
			
			this._router.navigate(['beneficiary/edit'], {
				queryParams: {
					key: beneficiary.key
				}
			});
		}else if (idEvent && idEvent === '3') {
			const card = this.getCardFromBeneficiary(beneficiary.account.number);
			this._dataTransferService.sendData(card);
			this._router.navigate(['/payments/card-payments']);
		} else {
			this._dataTransferService.sendData(beneficiary.key);
			this._router.navigate(['beneficiary/edit']);
		}
	}

	/**
	 * Permite obtener una tarjeta por medio de la cuenta de un beneficiario
	 *
	 * @param {string} beneficiaryNumber
	 * @memberof PayeesContainerComponent
	 */
	public getCardFromBeneficiary(beneficiaryNumber: string){
		
		const card = this.cards.find((product) =>{
			return product.display_number === beneficiaryNumber;
		});
		const cardImage = card.image.substring(20);
		card.cardType = cardImage.substr(0, cardImage.length - 4);
		card.name = card.description;
		return card;
	}

	/**
	 * Permite navegar al detalle de cuenta o tarjeta
	 *
	 * @param {*} product
	 * @param {string} category
	 * @memberof PayeesContainerComponent
	 */
	public navigateToProduct(product: any, category: string): void {
		const cardImage = product.image.substring(20);
		this._router.navigate(
			[
				category === 'CHECKING_ACCOUNTS' || category === 'CHECKING_ACCOUNTS_USD'
					? '/summary/account-detail'
					: '/summary/credit-card-detail'
			],
			{
				queryParams: {
					key: product.key,
					display_number: product.display_number,
         			cardType: cardImage.substr(0, cardImage.length - 4),
					status: product.status
				},
				queryParamsHandling: 'merge'
			}
		);
  }

	/**
	 * Modifica los elementos del array de beneficiarios para que cada elemento posea su propia logica con los botones ocultos
	 *
	 * @param {beneficiaries} any[]
	 * @memberof PayeesContainerComponent
	 */
	public setBeneficiaryButtonList(beneficiaries:any[]){
		const deleteButton = {
			id: '1',
			name: 'Eliminar',
			icon: 'sn-FUNC44'
		};
		let productButton = {};
		beneficiaries.map( beneficiary => {
			

			if(beneficiary.account.account_type === 'THIRDPARTY_DEBIT_CARD' || beneficiary.account.account_type === 'CREDIT_CARD'){
				 productButton = {
					id: '3',
					name: 'Pagar tarjeta',
					icon: 'sn-FUNC18'
				}
			}else{
				productButton = {
					id: '2',
					name: 'Transferir',
					icon: 'sn-BAN55'
				}
			}
				
			beneficiary['buttons'] = [deleteButton, productButton];
		});
		return beneficiaries;
	}

	/**
	 * Obtiene los productos (tarjetas y cuentas) y contactos necesarios para la vista
	 *
	 * @TODO Modificar el servicio para obtener los productos del endpoint correcto y dejar de usar summary
	 * @memberof PayeesContainerComponent
	 */
	ngOnInit(): void {
		this._summaryService.getSummary().subscribe((response: any) => {
			this.categories = response.data;
			// TODO: Change for real images
			this.categories.map((category: any) => {
				category.products.map((item: any) => {
					item.image = this.cardImages[
						Math.floor(Math.random() * this.cardImages.length)
					];
					item.category = category.category_name;
				});
				this.cards = [...this.cards, ...category.products];
			});
			
		});
		this._beneficiaryService.getAllBeneficiaries().subscribe((response: any) => {
			response.data = this.setBeneficiaryButtonList(response.data);
			this.beneficiaries = response;
			
		});
	}
}
