import { Component, OnInit, Input, EventEmitter } from '@angular/core';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { ListPayeesResponse } from '../../models/list-payees-response';
import { DialogReference, DialogService, CustomDialog } from '@santander/flame-component-library';
import { ConfirmPayeeDialogViewComponent } from '../../components/confirm-dialog-view/confirm-dialog-view.component';
import { timer } from 'rxjs';

@Component({
	selector: 'sm-payees-container',
	templateUrl: './payees-container.component.html',
	styleUrls: ['./payees-container.component.scss']
})
export class PayeesContainerComponent implements OnInit {
	/**
	 * Crea una instancia de PayeesContainerComponent.
	 * @param {SummaryService} _summaryService
	 * @param {Router} _router
	 * @param {DataTransferService} _dataTransferService
	 * @param {BeneficiaryService} _beneficiaryService
	 * @memberof PayeesContainerComponent
	 */
	constructor(
		private _summaryService: SummaryService,
		private _router: Router,
		private _dataTransferService: DataTransferService,
		private _beneficiaryService: BeneficiaryService,
		private dialog: DialogService
	) {}

	// Variables privadas
	private cardImages = [
		'./assets/icons/card-amex.svg',
		'./assets/icons/card-aero.svg',
		'./assets/icons/card-basic.svg',
		'./assets/icons/card-pref.svg'
  ];

  // Variables publicas
  private _dialogRef: DialogReference;
	public isOpen = false;
	public searchBar = '';
	public categories = [];
	public beneficiaries: ListPayeesResponse;
	public buttons = [
		{
			id: '1',
			name: 'Eliminar',
			icon: 'sn-FUNC44'
		},
		{
			id: '2',
			name: 'Transferir',
			icon: 'sn-BAN55'
		}
	];
  public closeEventSlide = new EventEmitter<boolean>();

	// Inputs
	@Input() confirmedToken: boolean;

	/**
	 * Permite modificar la vista para buscar un contacto con el componente sn-search-bar
	 *
	 * @param {*} [el=null]
	 * @memberof PayeesContainerComponent
	 */
	public toggleSearch(el: any = null): void {
		if (!this.isOpen) {
			this.searchBar = '';
			el.input.nativeElement.value = '';
		}
		this.isOpen = !this.isOpen;
	}

	closeSearch(evt: any) {
		if (evt === 'sn-SMOV11') {
      this.searchBar = '';
			this.isOpen = false;
		}
	}

	/**
	 * Permite navegar a editar un contacto o iniciar una transferencia
	 *
	 * @param {string} number
	 * @param {string} [idEvent]
	 * @memberof PayeesContainerComponent
	 */
	public navigateContact(beneficiary: any, idEvent?: string): void {
		if (idEvent && idEvent === '2') {
			this._router.navigate(['/transfers/initial']);
		} else if (idEvent && idEvent === '1') {
			this._openDeleteDialog(beneficiary);
		} else {
      this._dataTransferService.sendData(beneficiary.key);
      this._router.navigate(['beneficiary/edit']);
    }
	}

	/**
	 * Permite navegar al detalle de cuenta o tarjeta
	 *
	 * @param {*} product
	 * @param {string} category
	 * @memberof PayeesContainerComponent
	 */
	public navigateToProduct(product: any, category: string): void {
		const cardImage = product.image.substring(20);
		this._router.navigate(
			[
				category === 'CHECKING_ACCOUNTS' || category === 'CHECKING_ACCOUNTS_USD'
					? '/summary/account-detail'
					: '/summary/credit-card-detail'
			],
			{
				queryParams: {
					key: product.key,
					display_number: product.display_number,
          cardType: cardImage.substr(0, cardImage.length - 4),
          status: product.status
				},
				queryParamsHandling: 'merge'
			}
		);
  }

  private _openDeleteDialog(beneficiary: any) {

    const dataConfirm = this.createRequest(beneficiary);
    this.closeEventSlide.subscribe( (response: boolean) => {
      if (response === true) {
				timer(500).subscribe(() => {
          this._dialogRef.close();
          this.deleteAction(beneficiary);
				});
      } else {
        this._dialogRef.close();
      }
    });

    dataConfirm.event = this.closeEventSlide;

    this._dialogRef = this.dialog.open(
      {
        closeLabel: 'Cerrar',
        title: 'Eliminar contacto',
        enableHr: true,
        showButton: false,
        closeBackdropClick: true
      },
      new CustomDialog(ConfirmPayeeDialogViewComponent, {
        dataConfirm: dataConfirm
      })
    );
  }

  createRequest(beneficiary: any): any {
		return {
			name: beneficiary.name,
			account: {
				number: beneficiary.account.number,
				bank:	beneficiary.account.bank,
				account_type: beneficiary.account.account_type
			},
			alias: beneficiary.alias,
			personal_identifier: beneficiary.personal_identifier
		};
  }

  deleteAction(beneficiary: any) {
		// falta una definición de apis de como dar de baja el beneficiario.
		this._beneficiaryService
			.deletePayee(beneficiary.key)
			.subscribe(
				response => {
					this._dataTransferService.sendData(response);
					// end
					this._router.navigate(['/beneficiary/voucher'], {
						queryParams: {
							isNew: false
						}
					});
				},
				error => {
					// error
				}
			);
	}

	/**
	 * Obtiene los productos (tarjetas y cuentas) y contactos necesarios para la vista
	 *
	 * @TODO Modificar el servicio para obtener los productos del endpoint correcto y dejar de usar summary
	 * @memberof PayeesContainerComponent
	 */
	ngOnInit(): void {
		this._summaryService.getSummary().subscribe((response: any) => {
			this.categories = response.data;
			// TODO: Change for real images
			this.categories.map((category: any) => {
				category.products.map((item: any) => {
					item.image = this.cardImages[
						Math.floor(Math.random() * this.cardImages.length)
					];
				});
			});
		});
		this._beneficiaryService.getAllBeneficiaries().subscribe(response => {
			this.beneficiaries = response;
		});
	}
}
