import { Component, OnInit, Input } from '@angular/core';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from 'libs/beneficiary-operation-library/src/lib/services/beneficiary-operation.service';
import { ListPayeesResponse } from '../../models/list-payees-response';

@Component({
	selector: 'sm-payees-container',
	templateUrl: './payees-container.component.html',
	styleUrls: ['./payees-container.component.scss']
})
export class PayeesContainerComponent implements OnInit {
	// control
	public isOpen = false;
	public searchBar = '';
	public categories = [];
	public beneficiaries: ListPayeesResponse;
	public cardImages = [
		'../../assets/icons/card-amex.svg',
		'../../assets/icons/card-aero.svg',
		'../../assets/icons/card-basic.svg',
		'../../assets/icons/card-pref.svg'
	];
	public buttons = [
		{
			id: '1',
			name: 'Eliminar',
			icon: 'sn-cancel'
		},
		{
			id: '2',
			name: 'Transferir',
			icon: 'transferencia'
		}
	];

	//variables
	@Input() confirmedToken: boolean;

	constructor(
		private _summaryService: SummaryService,
		private _router: Router,
		private _dataTransferService: DataTransferService,
		private _beneficiaryService: BeneficiaryService
	) {}

	ngOnInit() {
		this._summaryService.getSummary().subscribe(response => {
			this.categories = response.data;
			// TODO: Change for real images
			this.categories.map((category: any) => {
				category.products.map((item: any) => {
					item.image = this.cardImages[
						Math.floor(Math.random() * this.cardImages.length)
					];
				});
			});
		});
		this._beneficiaryService.getAllBeneficiaries().subscribe(response => {
      this.beneficiaries = response;
		});
	}

	toggleSearch(el = null) {
		if(!this.isOpen){
			this.searchBar = '';
			el.input.nativeElement.value = "";
		}
		this.isOpen = !this.isOpen;
	}

	sendData(number: string) {
		this._dataTransferService.sendData(number);
		this._router.navigate(['/beneficiary/edit']);
	}

	actionSlide(idEvent, number: string) {
		if (idEvent === '2') {
			this._router.navigate(['/transfers/bank']);
		} else {
			this._dataTransferService.sendData(number);
			this._router.navigate(['/beneficiary/edit']);
		}
	}
}
