import { async, TestBed, ComponentFixture } from '@angular/core/testing';
import { PayeesContainerComponent } from './payees-container.component';
import { DataTransferService, ENV_CONFIG } from '@santander/flame-core-library';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Injector } from '@angular/core';
import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { BeneficiaryProductsFilterPipe } from '../../pipes/beneficiary-products-filter.pipe';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import {
	FlameFoundationTheme,
	ThemeModule,
	FormFieldModule,
	InputModule,
	IconButtonModule,
	IconModule,
	ButtonModule,
	TopBarModule,
	AvatarModule,
	EmojiModule,
	DialogSelectModule,
	TokenDialogService,
	TokenDialogModule,
	ChipModule,
	ProductModule,
	HiddenButtonsModule,
	SearchBarModule,
	SlideButtonModule,
	CheckboxModule,
  DialogService
} from '@santander/flame-component-library';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { BeneficiaryViewComponents } from '../../views/beneficiary-views-components';
import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';
import { MaskPipe, NgxMaskModule } from 'ngx-mask';
import {
	BeneficiaryOperationLibraryComponents,
	BeneficiaryOperationLibraryEntryComponents
} from '../../components/beneficiary-operation-library-components';
import { ConfirmPayeeDialogViewComponent } from '../../components/confirm-dialog-view/confirm-dialog-view.component';
import { Router } from '@angular/router';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

describe('BeneficiaryOperationLibraryModule', () => {
    let component: PayeesContainerComponent;
    let fixture: ComponentFixture<PayeesContainerComponent>;
    let summaryService: SummaryService;
    let beneficiaryService: BeneficiaryService;
    let beneficiaryFilterPipe: BeneficiaryFilterPipe;
    let beneficiaryProductsFilterPipe:BeneficiaryProductsFilterPipe;

    const mockSummaryList = {
        "data": [
          {
            "category_name": "CHECKING_ACCOUNTS",
            "total_balance": {
              "currency_code": "MXN",
              "amount": 69827.78
            },
            "products": [
              {
                "key": "056722751246",
                "alias": null,
                "cardImage": './assets/icons/card-aero.svg',
                "image": './assets/icons/card-aero.svg',
                "description": "SUPER NOMINA",
                "url": null,
                "display_number": "56*5124",
                "related_phone": {
                  "phone_number": "5510555143",
                  "company": "TELCEL"
                },
                "status": "AVAILABLE",
                "balance": {
                  "currency_code": "MXN",
                  "amount": 69827.78
                }
              },
              {
                "key": "056722733565",
                "alias": null,
                "description": "SUPER NOMINA",
                "url": null,
                "display_number": "56*3356",
                "related_phone": null,
                "status": "AVAILABLE",
                "balance": {
                  "currency_code": "USD",
                  "amount": 0
                }
              }
            ]
          }
          
        ],
        "notifications": null,
        "paging": null
      };

      const mockBeneficiaryList = {
        "data": [
          {
            "key": "0m29qh0l7xy6oattzh65kq2jgn19fbx6",
            "account": {
              "number": "56*5124",
              "account_type": "THIRDPARTY_MOBILE_ACCOUNT",
              "bank": "SCOTIABANK"
            },
            "name": "Jack Jacobs",
            "alias": "The Fourth",
            "url": "/beneficiaries/{beneficiary-key}",
            "personal_identifier": "MARE921122HJKDLN01"
          },
          {
            "key": "0m29qh0l7xy6oattzh65kq2jgn19fbx6",
            "account": {
              "number": "56*5124",
              "account_type": "THIRDPARTY_DEBIT_CARD",
              "bank": "SCOTIABANK"
            },
            "name": "Jack Jacobs",
            "alias": "The Fourth",
            "url": "/beneficiaries/{beneficiary-key}",
            "personal_identifier": "MARE921122HJKDLN01"
          }
        ],
        "notifications": [
          {
            "level": "WARNING",
            "code": "E422CDNPAYRCPTG001",
            "message": "Something happened.",
            "timestamp": "2019-05-31T16:26:26.534Z"
          }
        ],
        "paging": {
          "next_cursor_key": "10"
        }
      };

	beforeEach(async(() => {
		TestBed.configureTestingModule({
            declarations: [
                PayeesContainerComponent,
                BeneficiaryFilterPipe,
                BeneficiaryProductsFilterPipe,
                ...BeneficiaryViewComponents,
                ...BeneficiaryOperationLibraryComponents,
                ConfirmPayeeDialogViewComponent
            ],
            schemas: [
                CUSTOM_ELEMENTS_SCHEMA,
                NO_ERRORS_SCHEMA
            ],
            imports: [
              BrowserAnimationsModule,
                HttpClientModule,
                RouterTestingModule,
                AvatarModule,
                BeneficiaryOperationLibraryRoutingModule,
                ButtonModule,
                CommonModule,
                DialogSelectModule,
                EmojiModule,
                FormFieldModule,
                FormsModule,
                IconModule,
                IconButtonModule,
                InputModule,
                ReactiveFormsModule,
                ChipModule,
                NgxMaskModule.forRoot(),
                ProductModule,
                ThemeModule.forRoot({
                    themes: [FlameFoundationTheme],
                    active: 'flame-foundation'
                }),
                TokenDialogModule,
                TopBarModule,
                HiddenButtonsModule,
                SearchBarModule,
                SlideButtonModule,
                CheckboxModule
            ],
            providers: [
                BeneficiaryService,
                TokenDialogService,
                DialogService,
                SummaryService,
                MaskPipe,
                ConfirmPayeeDialogViewComponent,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api/',
							version: {
								transfers : '1'
							}

						}
					}
				},
				{ provide: Injector, useValue: {} },
                DataTransferService
            ]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(PayeesContainerComponent);
      component = fixture.componentInstance;
      summaryService = TestBed.get(SummaryService);
      beneficiaryService = TestBed.get(BeneficiaryService);
      beneficiaryProductsFilterPipe = new BeneficiaryProductsFilterPipe();
      beneficiaryFilterPipe = new BeneficiaryFilterPipe();
      spyOn(summaryService,'getSummary').and.returnValue(of(mockSummaryList));
      spyOn(beneficiaryService, 'getAllBeneficiaries').and.returnValue(of(mockBeneficiaryList));
      fixture.detectChanges();
	});

    afterAll(() => {
        TestBed.resetTestingModule();
      });


    it('debe crearse el componente', () => {
      expect(component).toBeTruthy();
    });

    it('debe cambiar el estado de la animacion', () => {
        component.elementState = '';
        component.toggleSearch();
        expect(component.elementState).toEqual('in');
        component.elementState = '';
        component.closeSearch('sn-FUNC31');
        expect(component.elementState).toEqual('in');
        component.elementState = '';
        component.closeSearch('');
        expect(component.elementState).toEqual('out');
    });

    it('Inyectar servicio SummaryService', ()=>{
        expect(summaryService).toBeTruthy();
    });

    it('Inyectar servicio BeneficiaryService', ()=>{
        expect(beneficiaryService).toBeTruthy();
    });

    it('Debe recibir los datos correctos de los servicios al iniciar el componente', ()=>{
      
        component.ngOnInit();
        expect(component.cards.length).toBeGreaterThan(0);
        expect(component.beneficiaries.data.length).toBeGreaterThan(0);
    });

    it('Debe aplicarse el filtro de beneficiarios correctamente', () => {
     
        component.ngOnInit();

        let result = beneficiaryFilterPipe.transform(component.beneficiaries.data, 'The');

        expect(result.alias.length).toBeGreaterThan(0);
        result = beneficiaryFilterPipe.transform(component.beneficiaries.data, '');
        expect(result.alias.length).toEqual(0)
        result = beneficiaryFilterPipe.transform(component.beneficiaries.data, 'Ja');
        expect(result.name.length).toBeGreaterThan(0);
        result = beneficiaryFilterPipe.transform(component.beneficiaries.data, '51');
        expect(result.phone.length).toBeGreaterThan(0);
    });

    it('Debe aplicarse el filtro de tarjetas correctamente', () => {
     
        component.ngOnInit();
       
        let result = beneficiaryProductsFilterPipe.transform(component.cards, 'SUP');
        expect(result.products.length).toBeGreaterThan(0);
        result = beneficiaryProductsFilterPipe.transform(component.cards, '56');
        expect(result.products.length).toBeGreaterThan(0);
        result = beneficiaryProductsFilterPipe.transform(component.cards, '');
        expect(result.products.length).toEqual(0)
    });

    it('should navigate to contact product', () =>{
      const router = TestBed.get(Router);
      const routerSpy = spyOn(router, 'navigate');
      const dataTransferService = TestBed.get(DataTransferService);
      spyOn(dataTransferService, 'sendData').and.callFake(()=>{});

      let result = component.navigateContact({},'2');
      expect(routerSpy).toHaveBeenCalledWith(['/transfers/initial']);
    
      result = component.navigateContact({},'5');
      expect(routerSpy).toHaveBeenCalledWith(['beneficiary/edit']);
    
      TestBed.get(ConfirmPayeeDialogViewComponent);   
      const dialog = TestBed.get(DialogService);
      spyOn(dialog, 'open').and.callFake(()=>{})
      
      const beneficiaryObject = mockBeneficiaryList.data[0];
      result = component.navigateContact(beneficiaryObject,'1');

      component.ngOnInit();
      result = component.navigateContact(beneficiaryObject,'3');
      expect(routerSpy).toHaveBeenCalledWith(['/payments/card-payments']);

    });

    it('it should navigate to product', ()=>{
      const router = TestBed.get(Router);
      const routerSpy = spyOn(router, 'navigate');
      component.ngOnInit();
      const product = component.cards[0];
      const cardImage = product.image.substring(20);

      const result = {
          queryParams: {
            key: product.key,
            display_number: product.display_number,
            cardType:  cardImage.substr(0, cardImage.length - 4),
            status: product.status
          },
          queryParamsHandling: 'merge'
      };
      component.navigateToProduct(product,'CHECKING_ACCOUNTS');
      expect(routerSpy).toHaveBeenCalledWith( ['/summary/account-detail'],result);

      component.navigateToProduct(product,'CHECKING_ACCOUNTS_USD');
      expect(routerSpy).toHaveBeenCalledWith( ['/summary/account-detail'],result);

      component.navigateToProduct(product,'CREDIT_CARD');
      expect(routerSpy).toHaveBeenCalledWith( ['/summary/credit-card-detail'],result);
    });
    
});
