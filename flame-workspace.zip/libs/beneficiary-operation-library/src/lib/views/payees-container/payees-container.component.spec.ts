import { async, TestBed, ComponentFixture } from '@angular/core/testing';
import { PayeesContainerComponent } from './payees-container.component';
import { DataTransferService, ENV_CONFIG } from '@santander/flame-core-library';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { SummaryService } from 'libs/summary-operation-library/src/lib/services/summary.service';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Injector } from '@angular/core';
import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';

describe('BeneficiaryOperationLibraryModule', () => {
    let component: PayeesContainerComponent;
    let fixture: ComponentFixture<PayeesContainerComponent>;
    
	beforeEach(async(() => {
		TestBed.configureTestingModule({
            declarations: [
                PayeesContainerComponent,
                BeneficiaryFilterPipe
            ],
            schemas: [
                CUSTOM_ELEMENTS_SCHEMA,
                NO_ERRORS_SCHEMA
            ],
            imports: [
                HttpClientModule,
                RouterTestingModule
            ],
            providers: [
                BeneficiaryService,
                SummaryService,
				{
					provide: ENV_CONFIG,
					useValue: {
						baas: {}
					}
				},
				{ provide: Injector, useValue: {} },
                DataTransferService
            ]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(PayeesContainerComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

    afterAll(() => {
        TestBed.resetTestingModule();
      });

	it('should create component', () => {
		expect(component).toBeTruthy();
    });

    it('should call actionSlide', () => {
        spyOn((component as any)._router,'navigate');
        component.actionSlide('1','1');
        expect((component as any)._router.navigate).toHaveBeenCalled();
    });

    it('should call actionSlide with idEvent 2', () => {
        spyOn((component as any)._router,'navigate');
        component.actionSlide('2','1');
        expect((component as any)._router.navigate).toHaveBeenCalled();
    });

    it('should action slide function', () => {
        spyOn(component,'actionSlide');
        component.actionSlide('2', '1');
		expect(component.actionSlide).toHaveBeenCalled();
    });

    it('should call sendData function', () => {
        spyOn((component as any)._router,'navigate');
        component.sendData('');
        expect((component as any)._router.navigate).toHaveBeenCalled();
    });

    it('should call toggle search', () => {
        component.isOpen = true;
        component.toggleSearch();
        expect(component.isOpen).toBeFalsy();
        component.isOpen = false;
        component.searchBar = 'search'
        const el = {
            input: {
                nativeElement: {
                    value: ''
                }
            }
        }
        component.toggleSearch(el);
        expect(component.searchBar).toBe('');
    });

    // it('should call init function', () => {
    //     const responseSubs = '';
    //     (component as any)._beneficiaryService.getAllBeneficiaries().subscribe(response => {
    //         expect(response).toBe(responseSubs);
    //         expect(component.beneficiaries).toBe(response);
    //     });
    //     (component as any)._beneficiaryService.postDataBeneficiary(null);
    // });
});
