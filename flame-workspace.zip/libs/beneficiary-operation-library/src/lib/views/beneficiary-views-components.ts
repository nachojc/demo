import { BeneficiaryViewComponent } from './beneficiary-view/beneficiary-view.component';
import { BeneficiaryInfoViewComponent } from './beneficiary-info/beneficiary-info-view.component';
import { BeneficiaryVoucherViewComponent } from './beneficiary-voucher/beneficiary-voucher-view.component';
import { BeneficiaryEditComponent } from './beneficiary-edit/beneficiary-edit.component';
import { PayeesContainerComponent } from './payees-container/payees-container.component';

export const BeneficiaryViewComponents = [
  BeneficiaryViewComponent,
  BeneficiaryInfoViewComponent,
  BeneficiaryVoucherViewComponent,
  BeneficiaryEditComponent,
  PayeesContainerComponent
];
