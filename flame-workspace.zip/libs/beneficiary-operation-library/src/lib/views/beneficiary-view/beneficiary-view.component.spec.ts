import {
	async,
	ComponentFixture,
	TestBed,
	fakeAsync
} from '@angular/core/testing';
import {
	ButtonModule,
	IconModule,
	AvatarModule,
	DialogSelectModule,
	EmojiModule,
	FormFieldModule,
	IconButtonModule,
	InputModule,
	ChipModule,
	ProductModule,
	ThemeModule,
	FlameFoundationTheme,
	TokenDialogModule,
	TopBarModule,
	HiddenButtonsModule,
	SearchBarModule,
	TokenDialogService
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule, Location } from '@angular/common';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { BeneficiaryViewComponent } from 'libs/beneficiary-operation-library/src/lib/views/beneficiary-view/beneficiary-view.component';
import {
	FormsModule,
	ReactiveFormsModule,
	FormBuilder,
	Validators
} from '@angular/forms';
import { BeneficiaryViewComponents } from '../beneficiary-views-components';
import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { PayeesContainerComponent } from '../payees-container/payees-container.component';
import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';
import { numberLengthValidator } from '@santander/flame-core-library';

describe('BeneficiaryViewComponent', () => {
	let component: BeneficiaryViewComponent;
	let fixture: ComponentFixture<BeneficiaryViewComponent>;
	let button: DebugElement;
	let formBuilder: FormBuilder;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				AvatarModule,
				BeneficiaryOperationLibraryRoutingModule,
				ButtonModule,
				CommonModule,
				DialogSelectModule,
				EmojiModule,
				FormFieldModule,
				FormsModule,
				IconModule,
				IconButtonModule,
				InputModule,
				ReactiveFormsModule,
				ChipModule,
				ProductModule,
				ThemeModule.forRoot({
					themes: [FlameFoundationTheme],
					active: 'flame-foundation'
				}),
				TokenDialogModule,
				TopBarModule,
				HiddenButtonsModule,
				SearchBarModule,
				RouterTestingModule.withRoutes([])
			],
			declarations: [...BeneficiaryViewComponents, BeneficiaryFilterPipe],
			providers: [BeneficiaryService, TokenDialogService]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(BeneficiaryViewComponent);
		component = fixture.componentInstance;
		formBuilder = new FormBuilder();
		button = fixture.debugElement.query(By.css('button'));
		fixture.detectChanges();
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('should be ngOnInit', () => {
		spyOn(component, 'ngOnInit');
		expect(component.beneficiaryIdForm).toHaveBeenCalled();
		component.ngOnInit();
	});

	it('should be beneficiaryIdFormBuilder', () => {
    spyOn(component, 'beneficiaryIdFormBuilder');
		component.beneficiaryIdFormBuilder();
		component.beneficiaryIdForm = formBuilder.group({
			key: this.formBuilder.control('', [
				Validators.required,
				numberLengthValidator([10, 11, 15, 16, 18])
			])
		});
		expect(component.beneficiaryIdForm).toHaveBeenCalled();
	});
});
