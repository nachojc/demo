import {
	async,
	ComponentFixture,
	TestBed
} from '@angular/core/testing';
import {
	FlameFoundationTheme,
	ThemeModule,
	FormFieldModule,
	InputModule,
	IconButtonModule,
	IconModule,
	ButtonModule,
	TopBarModule,
	AvatarModule,
	EmojiModule,
	DialogSelectModule,
	TokenDialogService,
	TokenDialogModule,
	ChipModule,
	ProductModule,
	HiddenButtonsModule,
	SearchBarModule,
	SlideButtonModule,
	CheckboxModule,
	ContactDialogService
} from '@santander/flame-component-library';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule, Router } from '@angular/router';
import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, Injector } from '@angular/core';
import { CommonModule, APP_BASE_HREF } from '@angular/common';
import { DebugElement } from '@angular/core';
import { BeneficiaryViewComponent } from 'libs/beneficiary-operation-library/src/lib/views/beneficiary-view/beneficiary-view.component';
import {
	FormsModule,
	ReactiveFormsModule,
	FormBuilder,
	FormGroup
} from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BeneficiaryViewComponents } from '../beneficiary-views-components';
import { BeneficiaryFilterPipe } from '../../pipes/beneficiary-filter.pipe';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { BeneficiaryOperationLibraryRoutingModule } from '../../beneficiary-operation-library.router.module';
import { ENV_CONFIG, DataTransferService } from '@santander/flame-core-library';
import { MaskPipe, NgxMaskModule } from 'ngx-mask';
import { BeneficiaryProductsFilterPipe } from '../../pipes/beneficiary-products-filter.pipe';
import { BeneficiaryOperationLibraryComponents } from '../../components/beneficiary-operation-library-components';
import { of } from 'rxjs';

describe('BeneficiaryViewComponent', () => {
	let component: BeneficiaryViewComponent;
	let fixture: ComponentFixture<BeneficiaryViewComponent>;
	let router: Router;
	let contactDialogService: ContactDialogService;
	let beneficiaryService: BeneficiaryService;
	let dataTransferService: DataTransferService;
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [
				HttpClientModule,
                RouterTestingModule,
                AvatarModule,
                BeneficiaryOperationLibraryRoutingModule,
                ButtonModule,
                CommonModule,
                DialogSelectModule,
                EmojiModule,
                FormFieldModule,
                FormsModule,
                IconModule,
                IconButtonModule,
                InputModule,
                ReactiveFormsModule,
                ChipModule,
                NgxMaskModule.forRoot(),
                ProductModule,
                ThemeModule.forRoot({
                    themes: [FlameFoundationTheme],
                    active: 'flame-foundation'
                }),
                TokenDialogModule,
                TopBarModule,
                HiddenButtonsModule,
                SearchBarModule,
                SlideButtonModule,
                CheckboxModule,
				RouterModule.forRoot([])
			],
			declarations: [
				BeneficiaryViewComponent,
				BeneficiaryFilterPipe,
                BeneficiaryProductsFilterPipe,
                ...BeneficiaryViewComponents,
                ...BeneficiaryOperationLibraryComponents
			],
			schemas: [
                CUSTOM_ELEMENTS_SCHEMA,
                NO_ERRORS_SCHEMA
            ],
			providers: [
                BeneficiaryService,
                TokenDialogService,
				ContactDialogService,
				DataTransferService,
                MaskPipe,
				{
					provide: ENV_CONFIG,
					useValue: {
						api: {
							url: 'http://localhost:3000/api/',
							version: {
								transfers : '1'
							}

						}
					}
				},
				{ provide: Injector, useValue: {} },
				{ provide: APP_BASE_HREF, useValue:'/' }
              
            ]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(BeneficiaryViewComponent);
		component = fixture.componentInstance;
		router = TestBed.get(Router)
		component.ngOnInit();
		
	});

	it('should create a component', () => {
		expect(component).toBeTruthy();
		fixture.detectChanges();
	});

	it('should be ngOnInit', () => {
		expect(component.beneficiaryIdForm).toBeTruthy();
		
	});

	it('should get the selected search type', () => {
		let searchType = '';
		component.beneficiaryIdForm.controls['key'].setValue('1234567891');
		searchType = component.setSerchType();
		expect(searchType).toEqual('MOBILE_ACCOUNT');
		component.beneficiaryIdForm.controls['key'].setValue('12345678912');
		searchType = component.setSerchType();
		expect(searchType).toEqual('SANTANDER_ACCOUNT');

		component.beneficiaryIdForm.controls['key'].setValue('123456789123456');
		searchType = component.setSerchType();
		expect(searchType).toEqual('THIRDPARTY_DEBIT_CARD');
		component.beneficiaryIdForm.controls['key'].setValue('1234567890123456');
		searchType = component.setSerchType();
		expect(searchType).toEqual('THIRDPARTY_DEBIT_CARD');

		component.beneficiaryIdForm.controls['key'].setValue('123456789012345678');
		searchType = component.setSerchType();
		expect(searchType).toEqual('CLABE');
	});

	it('should validates enabled button', () => {
		let enabledButton : boolean;
		component.beneficiaryIdForm.controls['key'].setValue('1234567891');
		enabledButton = component.enableButton();
		expect(enabledButton).toBeFalsy();
		component.beneficiaryIdForm.controls['key'].setValue('12345678912');
		enabledButton = component.enableButton();
		expect(enabledButton).toBeFalsy();
		component.beneficiaryIdForm.controls['key'].setValue('123456789123456');
		enabledButton = component.enableButton();
		expect(enabledButton).toBeFalsy();
		component.beneficiaryIdForm.controls['key'].setValue('1234567890123456');
		enabledButton = component.enableButton();
		expect(enabledButton).toBeFalsy();
		component.beneficiaryIdForm.controls['key'].setValue('123456789012345678');
		enabledButton = component.enableButton();
		expect(enabledButton).toBeFalsy();
		component.beneficiaryIdForm.controls['key'].setValue('1');
		enabledButton = component.enableButton();
		expect(enabledButton).toBeTruthy();
	});

	it('should redirect to', ()=>{
		const routerSpy = spyOn(router, 'navigate');
		component.redirectTo('back');
		
		contactDialogService = TestBed.get(ContactDialogService);
		const serviceSpy = spyOn(contactDialogService, 'openDialogContact');
		component.redirectTo('s');
		expect(serviceSpy).toHaveBeenCalled();

	});

	it('should post beneficiary data', () => {
		const routerSpy = spyOn(router, 'navigate');
		beneficiaryService = TestBed.get(BeneficiaryService);
		dataTransferService = TestBed.get(DataTransferService);
		const beneficiaryServiceSpy = spyOn(beneficiaryService, 'getPayeeLookup').and.returnValue(of({}));
		const dataTransferServiceSpy = spyOn(dataTransferService, 'sendData');
		component.postData();
		expect(routerSpy).toHaveBeenCalledWith(['/beneficiary/info']);
		expect(beneficiaryServiceSpy).toHaveBeenCalled();
		expect(dataTransferServiceSpy).toHaveBeenCalled();
		
	});
	


});
