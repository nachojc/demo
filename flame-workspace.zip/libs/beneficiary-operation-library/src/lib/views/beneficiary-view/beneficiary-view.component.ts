import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
	ShowOnDirtyErrorStateMatcher,
	DialogReference,
	DialogService
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import {
	numberLengthValidator,
	DataTransferService
} from '@santander/flame-core-library';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { GeneralFunction } from '../../helpers/general-function';

declare var require: any;
const bines = require('../../environments/bines.json');

@Component({
	selector: 'sm-beneficiary-view',
	templateUrl: './beneficiary-view.component.html',
	styleUrls: ['./beneficiary-view.component.scss']
})
export class BeneficiaryViewComponent implements OnInit {
	//control
	public generalFunction = GeneralFunction;
	public beneficiaryIdForm: FormGroup;
	public matcher = new ShowOnDirtyErrorStateMatcher();
	public showHintKey = false;
	public keyValue: String;
	public mass = '';
	private dialogRef: DialogReference;

	constructor(
		private formBuilder: FormBuilder,
		private _router: Router,
		private _beneficiarySrv: BeneficiaryService,
		private _dataTransferService: DataTransferService,
		private dialog: DialogService
	) {}

	ngOnInit() {
		this.beneficiaryIdFormBuilder();
	}

	private beneficiaryIdFormBuilder() {
		this.beneficiaryIdForm = this.formBuilder.group({
			key: this.formBuilder.control('', [
				Validators.required,
				numberLengthValidator([10, 11, 15, 16, 18])
			])
		});
	}

	navigate() {
		this._beneficiarySrv
			.getPayeeLookup(this.beneficiaryIdForm.get('key').value)
			.subscribe(
				response => {
          // se conmenta esta linea de codigo que es por los bines, lo manejara bass.
					// this._beneficiarySrv.getInfoByKey(this.beneficiaryIdForm.get('key').value)
					// .subscribe((data: any) => {
					//   if (this.beneficiaryIdForm.get('key').value.length === 15 || this.beneficiaryIdForm.get('key').value.length === 16) {
					//     const value = bines.find((bin) => {
					//       return bin.number === this.beneficiaryIdForm.get('key').value.substring(0, bin.number.length);
					//     });
					//     if (value) {
					//       data.data.bank_name = value.bank;
					//     }
					//   }
					// });
					this._dataTransferService.sendData(response);
					this._router.navigate(['/beneficiary/info']);
				},
				error => {
					this.dialogRef = this.dialog.open({
						closeLabel: 'Cancelar',
						title: 'Dato inválido',
						body: `<div>
                    <img src="assets/icons/icon-nodisponible.jpg" alt="" />
                    <p class="mb-4 mt-4">´${error}´</p>
                  </div>`,
						enableHr: false,
						disabledButton: true,
						buttons: [
							{
								label: 'Intentar de nuevo',
								class: 'strech',
								action: scope => {
									this.dialogRef.close();
								}
							}
						]
					});
				}
			);
	}
}
