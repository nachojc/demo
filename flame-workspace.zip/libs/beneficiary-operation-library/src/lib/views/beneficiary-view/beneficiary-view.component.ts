import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {
	ShowOnDirtyErrorStateMatcher,
	DialogReference,
	DialogService,
	ContactDialogService
} from '@santander/flame-component-library';
import { Router } from '@angular/router';
import { DataTransferService } from '@santander/flame-core-library';
import { BeneficiaryService } from '../../services/beneficiary-operation.service';
import { GeneralFunction } from '../../helpers/general-function';

@Component({
	selector: 'sm-beneficiary-view',
	templateUrl: './beneficiary-view.component.html',
	styleUrls: ['./beneficiary-view.component.scss']
})
export class BeneficiaryViewComponent implements OnInit {
	/**
	 * Variables publicas y privadas
	 *
	 * @memberof BeneficiaryViewComponent
	 */
	public generalFunction = GeneralFunction;
	public beneficiaryIdForm: FormGroup;
	public matcher = new ShowOnDirtyErrorStateMatcher();
	public showHintKey = false;
	public keyValue: String;
	private dialogRef: DialogReference;

	constructor(
		private formBuilder: FormBuilder,
		private _router: Router,
		private _beneficiarySrv: BeneficiaryService,
		private _dataTransferService: DataTransferService,
		private dialog: DialogService,
		private contactDialogService: ContactDialogService,
		private _location: Location
	) {}

	/**
	 * Función para crear el formulario
	 *
	 *
	 * @memberof BeneficiaryViewComponent
	 */
	beneficiaryIdFormBuilder() {
		this.beneficiaryIdForm = this.formBuilder.group({
			key: this.formBuilder.control('', [Validators.required])
		});
	}

	redirectTo(action: string) {
		if (action === 'back') {
			this._location.back();
		} else {
			this.contactDialogService.openDialogContact(1);
		}
	}

	/**
	 * metodo para evaluar si el boton se habilita
	 *
	 * @returns
	 * @memberof BeneficiaryViewComponent
	 */
	enableButton() {
		return !(
			this.beneficiaryIdForm.get('key').value.length === 10 ||
			this.beneficiaryIdForm.get('key').value.length === 11 ||
			this.beneficiaryIdForm.get('key').value.length === 15 ||
			this.beneficiaryIdForm.get('key').value.length === 16 ||
			this.beneficiaryIdForm.get('key').value.length === 18
		);
	}

	/**
	 * Metodo que envia el post de las tarjeta, cuenta, telefono o clabe
	 *
	 * @memberof BeneficiaryViewComponent
	 */
	postData() {
		this._beneficiarySrv
			.getPayeeLookup(
				this.setSerchType(),
				this.beneficiaryIdForm.get('key').value
			)
			.subscribe((response: any) => {
				this._dataTransferService.sendData(response);
				this._router.navigate(['/beneficiary/info']);
			});
	}

	/**
	 * metodo que te regresa los datos para dar de alta el contacto
	 *
	 * @returns {string}
	 * @memberof BeneficiaryViewComponent
	 */
	setSerchType(): string {
		let typeSearch: string;
		switch (this.beneficiaryIdForm.get('key').value.length) {
			case 10:
				typeSearch = 'MOBILE_ACCOUNT';
				break;
			case 11:
				typeSearch = 'SANTANDER_ACCOUNT';
				break;
			case 15:
			case 16:
				typeSearch = 'THIRDPARTY_DEBIT_CARD'; // solo es un identificador para bass
				break;
			case 18:
				typeSearch = 'CLABE';
				break;
		}
		return typeSearch;
	}

	ngOnInit() {
		this.beneficiaryIdFormBuilder();
	}
}
