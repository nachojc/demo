export const environment = {
	production: false,
	certification: true,
	baas: {
		urlBeneficiary: 'http://localhost:3000/beneficiaries'
	}
};
