export const environment = {
	production: false,
  certification: true,
  api: {
    url: 'http://localhost:3000/api'
  },
	baas: {
		urlBeneficiary: 'http://localhost:3000/beneficiaries'
	}
};
