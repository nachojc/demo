export const environment = {
	production: false,
	baas: {
		urlBeneficiary: 'http://localhost:3000/beneficiaries'
	}
};
