export const environment = {
  production: false,
  api: {
    url: 'http://localhost:3000/api'
  },
	baas: {
		urlBeneficiary: 'http://localhost:3000/beneficiaries'
	}
};
