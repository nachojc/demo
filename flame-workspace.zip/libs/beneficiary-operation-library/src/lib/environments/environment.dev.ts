export const environment = {
	production: false,
	development: true,
	baas: {
		urlBeneficiary: 'http://localhost:3000/beneficiaries'
	}
};
