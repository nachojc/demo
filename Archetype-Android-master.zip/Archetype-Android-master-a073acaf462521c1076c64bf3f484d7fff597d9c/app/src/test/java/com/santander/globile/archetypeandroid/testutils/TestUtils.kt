package com.santander.globile.archetypeandroid.testutils

import android.app.Activity
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.launch

// Mock component
open class TestComponentFacade {

    fun parseInput(params: String?, resultChannel: Channel<String>) {
        GlobalScope.launch {
            resultChannel.send("response")
            resultChannel.close()
        }
    }

    open fun mustLaunchActivity(params: String?): Boolean = false

    fun launchActivity(activity: Activity, params: String?) {

    }

}

// Mock component that
class TestActivityComponentFacade : TestComponentFacade() {

    override fun mustLaunchActivity(params: String?): Boolean = true

}