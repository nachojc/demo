# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2019-02-28
### Added
- This CHANGELOG
- Reference to gradle for Workspace scaffolding

### Changed
- README file now includes user manual

## [0.3.0] - 2018-01-31
### Changed
- Completely disassociated Webview Bridge from Archetype

## [0.2.0] - 2018-12-31
### Added
- Santander Fonts and Colors
### Changed
- Several fixes to support Mexico app

## [0.1.0] - 2018-12-10
### Added
- Base filesystem structure
- Hybrid container (webview)
