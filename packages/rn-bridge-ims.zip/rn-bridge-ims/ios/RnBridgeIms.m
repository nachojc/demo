//
//  IMSBridge.m
//  MyAviva IMS
//
//  Created by Filippo Minelle on 09/03/2023.
//

#import <React/RCTBridgeModule.h>
#import <React/RCTEventEmitter.h>
@interface RCT_EXTERN_MODULE(RnBridgeImsEvents, RCTEventEmitter)
+ (BOOL)requiresMainQueueSetup
{
    return YES;
}
@end

@interface RCT_EXTERN_MODULE(RnBridgeImsTokenEvents, RCTEventEmitter)
+ (BOOL)requiresMainQueueSetup
{
    return YES;
}
@end

@interface RCT_EXTERN_MODULE(RnBridgeIms, NSObject)

#pragma mark - Init

RCT_EXTERN_METHOD(initialise:(NSString)apiKey
                  withExternalReferenceID:(NSString)externalReferenceID)

RCT_EXTERN_METHOD(disable)

#pragma mark - RCTBridgeModule

//Puts everything onto the main thread
- (dispatch_queue_t)methodQueue {
    return dispatch_get_main_queue();
}

+ (BOOL)requiresMainQueueSetup
{
    return YES;
}

#pragma mark - Trips
RCT_EXTERN_METHOD(fetchTripById:(NSString)tripId
                  withResolver:(RCTPromiseResolveBlock)resolve
                  withRejector:(RCTPromiseRejectBlock)reject)

RCT_EXTERN_METHOD(fetchAllTripsByDate:(nonnull NSNumber)startdate
                  withEndDate:(nonnull NSNumber)endDate
                  withResolver:(RCTPromiseResolveBlock)resolve
                  withRejector:(RCTPromiseRejectBlock)reject)

RCT_EXTERN_METHOD(fetchScoringAverage:(nonnull NSNumber)startdate
                  withEndDate:(nonnull NSNumber)endDate
                  withResolver:(RCTPromiseResolveBlock)resolve
                  withRejector:(RCTPromiseRejectBlock)reject)

RCT_EXTERN_METHOD(updateTrip:(NSString)tripId
                  withTransportMode:(NSString)transportMode
                  withResolver:(RCTPromiseResolveBlock)resolve
                  withRejector:(RCTPromiseRejectBlock)reject)

#pragma mark - Methods

RCT_EXTERN_METHOD(setSignedToken:(NSString)signedToken)

RCT_EXTERN_METHOD(printInImsLogs:(NSString)message)

RCT_EXTERN_METHOD(enableTripDetection:(RCTPromiseResolveBlock)resolve
                  withRejecter:(RCTPromiseRejectBlock)reject)

RCT_EXTERN_METHOD(disableTripDetection:(RCTPromiseResolveBlock)resolve
                  withRejecter:(RCTPromiseRejectBlock)reject)

RCT_EXTERN_METHOD(beginTrip)
RCT_EXTERN_METHOD(endTrip)

RCT_EXTERN_METHOD(uploadAllTrips:(RCTPromiseResolveBlock)resolve
                  withRejecter:(RCTPromiseRejectBlock)reject)

RCT_EXTERN_METHOD(tripsToUpload:(RCTPromiseResolveBlock)resolve
                  withRejecter:(RCTPromiseRejectBlock)reject)

RCT_EXTERN_METHOD(isTripDetectionManagerEnabled:(RCTPromiseResolveBlock)resolve
                  withRejecter:(RCTPromiseRejectBlock)reject)

@end
