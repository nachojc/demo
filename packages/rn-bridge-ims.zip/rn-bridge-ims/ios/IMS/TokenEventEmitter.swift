//
//  EventEmitter.swift
//  RnBridgeIms
//
//  Created by Matthew Robertson on 08/06/2023.
//  Copyright © 2023 Facebook. All rights reserved.
//

import Foundation

@available(iOS 13.0, *)
class TokenEventEmitter {
    public static var sharedInstance = TokenEventEmitter()
    private static var eventEmitter: RnBridgeImsTokenEvents!

    func registerEventEmitter(eventEmitter: RnBridgeImsTokenEvents) {
        TokenEventEmitter.eventEmitter = eventEmitter
    }

    func dispatch(name: String, body: Any?) {
        if (TokenEventEmitter.eventEmitter.canSendEvent) {
            TokenEventEmitter.eventEmitter.sendEvent(withName: name, body: body)
        }
    }
    
    private func forceDispatch(name: String, body: Any?) {
        TokenEventEmitter.eventEmitter.sendEvent(withName: name, body: body)
    }

    
    func dispatchWithTimeout(timeout: Double, name: String, body: Any?, cancel: @escaping () -> Void) {
        TokenEventEmitter.eventEmitter.waitForSendEvent(timeout: timeout, action: {
            print("[TokenEventEmitter] dispatching event \(name) - \(body ?? "")")
            self.forceDispatch(name: name, body: body)
        }, cancel: cancel)
    }
    
    func canSendEvents() -> Bool {
        return TokenEventEmitter.eventEmitter.canSendEvent
    }

    lazy var allEvents: [String] = {
        var allEventNames: [String] = ["signToken"]
        return allEventNames
    }()
}
