//
//  IMSBridge+TripDetection.swift
//  RnBridgeIms
//
//  Created by Matthew Robertson on 15/01/2024.
//

import Foundation
import Common
import CoreMotion
import CoreLocation
import TripDetection
import TripDetectionUmbrella
import Portal
import DistractedDriving

@available(iOS 13.0, *)
extension IMSBridge {

    var tripsToUpload: Int {
        IMSBridge.tripDetectionManager?.tripsToUpload() ?? 0
    }

    static func initialiseTripDetectionManager(apiKey: String, externalReferenceID: String) {
        print("[IMSInitialiseBridge] [initialiseTripDetectionManager] Is on main Thread \(Thread.current.isMainThread)")

        identity = Identity(apiKey: apiKey, externalReferenceID: externalReferenceID)

        let telemetryEvents: Set<TelemetryEvent> = [.gps,
                                                    .speed,
                                                    .gyroscope(.oneHz),
                                                    .gravity(.oneHz),
                                                    .accelerometer(.oneHz),
                                                    .userAcceleration(.oneHz),
                                                    .magnetometer(.oneHz)]
        // Feature for phone-only and device trip detection
        let features: [Feature] = [Feature.Geofence,
                                   Feature.PhoneOnlyValidation]

        if let i = identity, IMSBridge.tripDetectionManager == nil {
                IMSBridge.tripDetectionManager = TripDetectionManager(identity: i, uploadRoute: UploadRoute.anyNetwork, telemetryEvents: telemetryEvents, externalRecordProviders: [{DistractedDrivingRecordProvider()}], features: features )
            IMSBridge.tripDetectionManager?.setStatusHandler { status in
                print("[IMSInitialiseBridge] [initialiseTripDetectionManager] Trip detection status: \(status)")
            }
        }
    }

    // Activate Trip Device
    static func activateDevice() {
        print("[IMSInitialiseBridge] ActivateDevice Is on main Thread \(Thread.current.isMainThread)")
        guard let i = IMSBridge.identity else {
            print("[IMSInitialiseBridge Identity nil]")
            return
        }
        let deviceService = DeviceService(identity: i)
        if !isDeviceActivated {
            deviceService.activate { result in
                switch result {
                case let .failure(error):
                    print("[IMSInitialiseBridge] device not activated: \(error)")
                case let .success(device):
                    isDeviceActivated = true
                    print("[IMSInitialiseBridge] device activated: \(device)")
                }
            }
        } else {
            print("[IMSInitialiseBridge] device already activated")
        }
    }

    //Deactivate Trip Device
    func deactivateDevice() {
        print("[IMSInitialiseBridge] deactivateDevice Is on main Thread \(Thread.current.isMainThread)")
        guard let i = IMSBridge.identity else {
            print("[IMSInitialiseBridge Identity nil]")
            return
        }
        let deviceService = DeviceService(identity: i)
        deviceService.deactivate() { result in
            switch result {
            case let .failure(error):
                print("[IMSInitialiseBridge] device not deactivated: \(error)")
            case let .success(device):
                IMSBridge.isDeviceActivated = false
                print("[IMSInitialiseBridge] device deactivated: \(device)")
            }
        }
    }

    func deinitialiseTripDetectionManager() {
        IMSBridge.tripDetectionManager = nil
    }

    static func enableTripDetection() {
        print("[IMSInitialiseBridge] [enableTripDetection] Is on main Thread \(Thread.current.isMainThread)")

        guard !isTripDetectionEnabled else {
            print("[IMSInitialiseBridge] [enableTripDetection] trip detection already enabled")
            return
        }

        // IMS requires the "Motion Activity" and "Location" permissions to
        // detect and record a trip. It is important to ensure these
        // permissions are available at the time of enabling trip detection;
        // otherwise, it will remain inactive even if the permissions are
        // granted later.
        guard CMMotionActivityManager.authorizationStatus() == .authorized else {
            print ("[IMSInitialiseBridge] [enableTripDetection] motion activity permission not granted")
            return
        }
        guard CLLocationManager.authorizationStatus() == .authorizedAlways else {
            print ("[IMSInitialiseBridge] [enableTripDetection] background location permission not granted")
            return
        }

        IMSBridge.tripDetectionManager?.enable { (state, date) in
            switch state {
            case .potentialTrip:
                print("[IMSInitialiseBridge] potential trip detected at \(date)")
            case .confirmedTrip:
                print("[IMSInitialiseBridge] trip started at \(date)")
                TripEventEmitter.sharedInstance.dispatch(name: "tripConfirmed", body: ["date": date.timeIntervalSince1970])
            case .endedTrip:
                print("[IMSInitialiseBridge] trip completed at \(date)")
                TripEventEmitter.sharedInstance.dispatch(name: "tripEnded", body: ["date": date.timeIntervalSince1970])
            @unknown default:
                print("[IMSInitialiseBridge] unknown trip state: \(state)")
            }
        }
        isTripDetectionEnabled = true
        print("[IMSInitialiseBridge] trip detection enabled")
    }

    static func disableTripDetection() {
        IMSBridge.tripDetectionManager?.disable()
        IMSBridge.isTripDetectionEnabled = false
        print("[IMSInitialiseBridge] trip detection disabled")
    }

    func beginTrip() {
        IMSBridge.tripDetectionManager?.beginTripRecording()
    }

    func endTrip() {
        IMSBridge.tripDetectionManager?.endTripRecording()
    }

    func uploadAllTrips() {
        IMSBridge.tripDetectionManager?.uploadAll()
    }

    func tripsToUpload(resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        let promise = Promise(resolver: resolver, rejector: rejector)
        promise.resolve(IMSBridge.tripDetectionManager?.tripsToUpload() ?? 0)
    }

    func isTripDetectionManagerEnabled(resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        let promise = Promise(resolver: resolver, rejector: rejector)
        promise.resolve(IMSBridge.isTripDetectionEnabled)
    }
}
