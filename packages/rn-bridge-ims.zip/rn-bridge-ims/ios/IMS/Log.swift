//
//  Log.swift
//  RnBridgeIms
//
//  Created by Filippo Minelle on 16/03/2023.
//  Copyright © 2023 Facebook. All rights reserved.
//

import Foundation
import os.log
import OSLog
import Common

func print(_ items: Any..., separator: String = " ", terminator: String = "\n") {
//    #if DEBUG - Uncomment when finished IMS implementations as logging not needed for release
    let output = items.compactMap { "\($0)" }.joined(separator: separator)
    DispatchQueue.main.async {
        Common.log.i(output)
    }
    if #available(iOS 14.0, *) {
        let log = Logger()
        log.log("\(output)")
    } else {
        Swift.print(output)
    }
//    #endif
}
