//
//  AvivaTrip.swift
//  RnBridgeIms
//
//  Created by Matthew Robertson on 24/01/2024.
//

import Foundation
import Portal

struct AvivaTrip: Encodable {
    let dateEnded: String?
    let dateStarted: String?
    let duration: Double?
    let distance: Double?
    let events: AvivaEvents
    let geometry: [AvivaPoint]?
    let id: String
    let reconstructedStartGeometry: [AvivaPoint]?
    let score: Double?
    let scores: AvivaTripScores?
    let status: String?
    let timeZoneOffset: Double?
    let transportMode: String
    
    init(trip: Trip) {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'hh:mm:ss.sssZ a"
        if let d = trip.dateEnded {
            dateEnded = dateFormatter.string(from: d)
        } else {
            dateEnded = nil
        }
        if let d = trip.dateStarted {
            dateStarted = dateFormatter.string(from: d)
        } else {
            dateStarted = nil
        }
        if let d = trip.duration {
            duration = d
        } else {
            duration = nil
        }
        
        distance = trip.distance?.magnitude
        events = AvivaEvents(events: trip.events)
        geometry = trip.geometry?.map { AvivaPoint(latitude: $0.latitude, longitude: $0.longitude) }
        id = trip.id
        reconstructedStartGeometry = trip.reconstructedStartGeometry?.map { AvivaPoint(latitude: $0.latitude, longitude: $0.longitude) }
        score = trip.score
        if let overall = trip.scores?.overall, let subScores = trip.scores?.subScores {
            scores = AvivaTripScores(overall: overall, subScores: subScores )
        } else {
            scores = nil
        }
        status = getStatus(status: trip.status)
        timeZoneOffset = trip.timeZone?.daylightSavingTimeOffset() ?? 0.0
        transportMode = trip.transportMode == .driver ? "driver" : "notDriver"
    }
}


fileprivate func getStatus(status: Trip.Status?) -> String? {
    switch(status) {
    case .complete: "complete"
    case .inProgress: "inProgress"
    case .unknown : "unknown"
    default: nil
    }
}
    
fileprivate func getSeverity(severity: Event.Severity?) -> String? {
    switch (severity) {
    case .veryLow: "veryLow"
    case .low: "low"
    case .medium: "medium"
    case .high: "high"
    case .veryHigh: "veryHigh"
    default: nil
    }
}

struct AvivaTripScores: Encodable {
    let overall: Double
    let subScores: AvivaSubScores?
    init (overall: Double, subScores: [TripScores.SubScore: Double?]) {
        self.overall = overall
        self.subScores = AvivaSubScores(subScores: subScores)
    }
}

struct AvivaSubScores: Encodable {
    let acceleration: Double?
    let braking: Double?
    let cornering: Double?
    let distractedDriving: Double?
    let speeding: Double?
    init(subScores:[TripScores.SubScore: Double?]) {
        acceleration = subScores[.acceleration] ?? nil //Weirdness with Double?? and Double?
        braking = subScores[.braking] ?? nil
        cornering = subScores[.cornering] ?? nil
        distractedDriving = subScores[.other(key: "distracted.driving")] ?? nil
        speeding = subScores[.speeding] ?? nil
    }
    
    init(componentScores: TripScoringComponents) {
        acceleration = componentScores.harshAcceleration
        braking = componentScores.harshBraking
        cornering = componentScores.harshCornering
        distractedDriving = componentScores.distractedDriving
        speeding = componentScores.speeding
    }
}

struct AvivaEvents: Encodable {
    let acceleration: [AvivaEvent]?
    let braking: [AvivaEvent]?
    let cornering: [AvivaEvent]?
    let distractedDriving: [AvivaEvent]?
    let speeding: [AvivaEvent]?

    init(events: [Event.EventType : [Event]]?) {
        acceleration = AvivaEvents.mapValues(events?[Event.EventType.acceleration])
        braking = AvivaEvents.mapValues(events?[Event.EventType.braking])
        cornering = AvivaEvents.mapValues(events?[Event.EventType.cornering])
        distractedDriving = AvivaEvents.mapValues(events?[Event.EventType.other(key: "DistractedDrivingViolation")])
        speeding = AvivaEvents.mapValues(events?[Event.EventType.postedSpeedLimit])
    }

    private static func mapValues(_ events: [Event]?) -> [AvivaEvent]? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.sssZ"
        return events?.compactMap { event in AvivaEvent(averageSpeed: event.averageSpeed, date: dateFormatter.string(from: event.date), duration: event.duration, longitude: event.longitude, latitude: event.latitude, severity: getSeverity(severity: event.severity), speed: event.speed, speedLimit: event.speedLimit)
        }
    }
}

struct AvivaEvent: Encodable {
    let averageSpeed: Double?
    let date: String
    let duration: Double?
    let longitude: Double
    let latitude: Double
    let severity: String?
    let speed: Double?
    let speedLimit: Double?
}

struct AvivaPoint: Encodable {
    let latitude: Double
    let longitude: Double
}

enum AvivaEventType: String, Encodable {
    case acceleration = "acceleration"
    case braking = "braking"
    case cornering = "cornering"
    case distracted_driving = "distractedDriving"
    case speeding = "speeding"
    case unknown = "unknown"
    
    static func fromEventType(eventType: Event.EventType) -> AvivaEventType {
        switch (eventType) {
        case .acceleration: .acceleration
        case .braking: .braking
        case .cornering: .cornering
        case .speeding: .speeding
        case .other(key: "DistractedDrivingViolation"): .distracted_driving
        default: .unknown
        }
    }
}
