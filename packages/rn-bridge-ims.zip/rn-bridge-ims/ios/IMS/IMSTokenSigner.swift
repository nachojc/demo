//
//  IMSTokenSigner.swift
//  MyAviva IMS
//
//  Created by Filippo Minelle on 08/03/2023.
//

import Foundation
import Common
import Combine

@objc
public protocol IMSTokenSignerDelegate: AnyObject {
    func getSignedToken(_ unsignedToken: String) // Event to RN to sign the token
}

/// https://sdk.ims.tech/security#token-signer
@available(iOS 13.0, *)
final class IMSTokenSigner: TokenSigner {

    private static var instance: IMSTokenSigner? = nil

    /// The error sent when there was a problem signing a token.
    struct SigningError: Error {
        let message: String
    }

    // MARK: - Properties

    private weak var delegate: IMSTokenSignerDelegate?

    /// value 1 indicate only one task will be performed at once.
    private let semaphore = DispatchSemaphore(value: 1)
    private let dispatchQueue = DispatchQueue(label: "taskQueue", qos: .background)

    @Published private var signedToken: String = "" //Observable for the token signing

    private var subscription: AnyCancellable?;
    private var signingHandler: ResultHandler<String> = {_ in }

    func setSignedToken(signedToken: NSString) {
        self.signedToken = signedToken as String
    }

    static func tokenSignerFactory() -> IMSTokenSigner {
        if (instance == nil) {
            instance = .init()
        }
        return instance!
    }

    private init() {
        subscription = $signedToken
            .receive(on: dispatchQueue)
            .sink(receiveValue: { [weak self] token in //Another thing that might be worth trying is PassThroughRelay from CombineExt
            // Even better might be https://github.com/CombineCommunity/CombineExt#anypublishercreate AnyPublisher.create
            // Since with that you can send the completion events...
                if (token != "") {
                    print("[IMSInitialiseBridge] Good Token")
                    self?.signingHandler(.success(token))
                    self?.semaphore.signal()
                } else {
                    print("[IMSInitialiseBridge] Blank Token")
                    self?.signingHandler(.failure(SigningError(message: "Problem signing token"))) //potentially need to send a failure result to the signing handler if there's a problem with the token signing (maybe the user is not logged on)
                    self?.semaphore.signal()
                }
            })
    }

    func sign(_ unsignedToken: String, resultHandler: @escaping ResultHandler<String>) {
        print("[IMSInitialiseBridge] [IMSTokenSigner] Request Signed Token")
        dispatchQueue.async { [self] in
            semaphore.wait()
            signingHandler = resultHandler
            self.getSignedToken(unsignedToken); //Event sent to RN to sign token
        }
    }

    // Used for react native to pick up and call into setSignedToken
    public func getSignedToken(_ unsignedToken: String) {
        print("[IMSInitialiseBridge] [IMSTokenSigner] Sign Token \(unsignedToken)")
        print("[IMSInitialiseBridge] [IMSTokenSigner] Can send Event \(TokenEventEmitter.sharedInstance.canSendEvents())")

        TokenEventEmitter.sharedInstance.dispatchWithTimeout(timeout: 10, name: "signToken", body: unsignedToken) {
            self.setSignedToken(signedToken: "")
        }
    }
}
