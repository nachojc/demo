//
//  IMSBridge.swift
//  RnBridgeIms
//
//  Created by Filippo Minelle on 16/03/2023.
//  Copyright © 2023 Facebook. All rights reserved.
//

import Foundation

import Common
import Portal
import TripDetectionUmbrella

// IMS SDK Bridge class for iOS. IMS SDK is a collection of Connected Car frameworks written in Swift.
// https://sdk.ims.tech/getting-started/ios/initializing-the-sdk
@available(iOS 13.0, *)
final class IMSBridge {

    // Initialise the sdk only once
    private static var isInitialised: Bool = false
    // Trip
    public static var tripDetectionManager: TripDetectionManager?
    var tripService: TripService?
    var scoringService: ScoringService?
    public static var identity: Identity?
    static var isDeviceActivated: Bool = false // These should not be persisted into defaults
    static var isTripDetectionEnabled: Bool = false
    

    public func setSignedToken(signedToken: NSString) {
        IMSTokenSigner.tokenSignerFactory().setSignedToken(signedToken: signedToken)
    }
    
    public static func getTripDetectionManager() -> TripDetectionManager? {
        return tripDetectionManager
    }

    public static func initialise() {
        print("[IMSInitialiseBridge] Is on main Thread \(Thread.current.isMainThread)")
        if !isInitialised {
            let sdkRootDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
                        .first!.appendingPathComponent("sdk", isDirectory: true)
            try! initialize(Directories(root: sdkRootDirectory),
                            logLevel: .verbose,
                            tokenSignerFactory: { IMSTokenSigner.tokenSignerFactory() })
            isInitialised = true
            print("[IMSInitialiseBridge] IMS SDK initialised")

            TripDetectionManager.enableLogScheduler()
            
        } else {
            print("[IMSInitialiseBridge] IMS SDK has already been initialised")
        }
    }
}
