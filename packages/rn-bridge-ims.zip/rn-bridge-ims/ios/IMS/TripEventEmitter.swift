//
//  EventEmitter.swift
//  RnBridgeIms
//
//  Created by Matthew Robertson on 08/06/2023.
//  Copyright © 2023 Facebook. All rights reserved.
//

import Foundation

@available(iOS 13.0, *)
class TripEventEmitter {
    static var sharedInstance = TripEventEmitter()
    private static var eventEmitter: RnBridgeImsEvents!

    func registerEventEmitter(eventEmitter: RnBridgeImsEvents) {
        TripEventEmitter.eventEmitter = eventEmitter
    }

    func dispatch(name: String, body: Any?) {
        if (TripEventEmitter.eventEmitter.canSendEvent) {
            TripEventEmitter.eventEmitter.sendEvent(withName: name, body: body)
        }
    }

    private func forceDispatch(name: String, body: Any?) {
        TripEventEmitter.eventEmitter.sendEvent(withName: name, body: body)
    }


    func dispatchWithTimeout(timeout: Double, name: String, body: Any?, cancel: @escaping () -> Void) {
        TripEventEmitter.eventEmitter.waitForSendEvent(timeout: timeout, action: {
            print("[TripEventEmitter] dispatching event \(name) - \(body ?? "")")
            self.forceDispatch(name: name, body: body)
        }, cancel: cancel)
    }

    func canSendEvents() -> Bool {
        return TripEventEmitter.eventEmitter.canSendEvent
    }

    lazy var allEvents: [String] = {
        var allEventNames: [String] = ["isReady", "tripConfirmed", "tripEnded"]
        return allEventNames
    }()
}
