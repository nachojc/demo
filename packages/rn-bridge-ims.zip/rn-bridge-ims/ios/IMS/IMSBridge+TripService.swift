//
//  IMSBridge+TripService.swift
//  RnBridgeIms
//
//  Created by Matthew Robertson on 15/01/2024.
//

import Foundation
import Portal
import Common

// MARK: Trip management
@available(iOS 13.0, *)
extension IMSBridge {

    func updateTrip(tripId: String, transportMode: String, resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        let promise = Promise(resolver: resolver, rejector: rejector)
        var newMode: TransportMode
        switch(transportMode.lowercased()) {
            case "passenger": newMode = TransportMode.passenger
            case "driver":  newMode = TransportMode.driver
            default:
                newMode = TransportMode.unknown
        }
        if let i = IMSBridge.identity {
            tripService = TripService(identity: i)
            tripService?.fetch(id: tripId) { tripToUpdate in
                guard tripToUpdate.error == nil && tripToUpdate.value != nil else {
                    promise.reject("fetch_trip_error", "", tripToUpdate.error)
                    return
                }
                self.tripService?.update(tripToUpdate.value!, transportMode: newMode) { updateResult in
                    guard updateResult.error == nil else {
                        promise.reject("update_trip_error", "", updateResult.error)
                        return
                    }
                    promise.resolve(updateResult.value?.transportMode == newMode)
                }
            }
        } else {
            promise.reject("identity_fail","Identity not set", nil)
        }

    }

    func fetchScoringAverage(startDate: NSNumber, endDate: NSNumber,  resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        let promise = Promise(resolver: resolver, rejector: rejector)
        let start = Date(timeIntervalSince1970: Double(truncating: startDate)/1000)
        let end = Date(timeIntervalSince1970: Double(truncating: endDate)/1000)

        if let i = IMSBridge.identity {
            scoringService = ScoringService(identity: i)
            scoringService?.custom(from: start, to: end, then: { scoringResult in
                guard scoringResult.error == nil else { //TODO: Unify these errors in a single error handling function to handle other error conditions
                    print("[IMSInitialiseBridge] Fetch All Error")
                    if let err = scoringResult.error as? NetworkError {
                        if (err == .noData) {
                            print("[IMSInitialiseBridge] Empty Scoring Average")
                            promise.resolve(nil)
                            return
                        }
                    }
                    promise.reject("fetch_scores_error", "", scoringResult.error)
                    return
                }
                if let scoringAverage = scoringResult.value {
                    let scoring = AvivaScoring(scoringAverage: scoringAverage)
                    do {
                        let scoringJson = try JSONSerialization.jsonObject(with: try JSONEncoder().encode(scoring), options: [])
                        promise.resolve(scoringJson)
                    } catch {
                        promise.reject("fetch_scores_error", "Problem serialising scores", nil)
                    }
                } else {
                    promise.reject("fetch_scores_error", "result is nil", nil)
                }
            })
        } else {
            promise.reject("identity_fail","Identity not set", nil)
        }
    }

    func fetchTripById(tripId: String, resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        let promise = Promise(resolver: resolver, rejector: rejector)
        if let i = IMSBridge.identity {
            tripService = TripService(identity: i)
            let expansions: Set<TripService.Expansion> = [.events, .geometry, .scores, .user]
            tripService?.fetch(id: tripId, expansions: expansions) { tripResult in
                guard tripResult.error == nil else {
                    promise.reject("fetch_trip_error", "", tripResult.error)
                    return
                }
                if let trip = tripResult.value {
                    let avivaTrip = AvivaTrip(trip: trip)
                    do {
                        let tripJson = try JSONSerialization.jsonObject(with: try JSONEncoder().encode(avivaTrip), options: [])
                        promise.resolve(tripJson)
                    } catch {
                        promise.reject("fetch_trip_error", "Problem serialising trip", nil)
                    }
                } else {
                    promise.reject("fetch_trip_error", "trip result nil", nil)
                }
            }
        } else {
            promise.reject("identity_fail","Identity not set", nil)
        }

    }

    func fetchAllTripsByDate(startDate: NSNumber, endDate: NSNumber,  resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        print("[IMSInitialiseBridge] Fetch All Trips By Date")
        let promise = Promise(resolver: resolver, rejector: rejector)
        let start = Date(timeIntervalSince1970: Double(truncating: startDate)/1000)
        let end = Date(timeIntervalSince1970: Double(truncating: endDate)/1000)

        let filters: Set = [Portal.TripService.Filter.date(start: start, end: end)]
        if let i = IMSBridge.identity {
            tripService = TripService(identity: i)
            print("[IMSInitialiseBridge] Fetch All")
            tripService?.fetchAll(filters: filters, then: { tripsResult in

                guard tripsResult.error == nil else {
                    if let err = tripsResult.error as? NetworkError {
                        if (err == .noData) {
                            print("[IMSInitialiseBridge] Empty Trips")
                            promise.resolve([])
                            return
                        }
                    }
                    print("[IMSInitialiseBridge] Fetch All Error")
                    promise.reject("fetch_trip_error", "", tripsResult.error)
                    return
                }


                print("[IMSInitialiseBridge] Fetch All Good")
                let avivaTrips = tripsResult.value?.map { trip in
                    AvivaTrip(trip: trip)
                }

                do {
                    let tripJson = try JSONSerialization.jsonObject(with: try JSONEncoder().encode(avivaTrips), options: [])
                    print("[IMSInitialiseBridge] Fetch All Resolve")
                    promise.resolve(tripJson)
                } catch {
                    promise.reject("fetch_trip_error", "Problem serialising trips", nil)
                }

            })
        } else {
            print("[IMSInitialiseBridge] Fetch All Identity Issue")
            promise.reject("identity_fail","Identity not set", nil)
        }
    }
}
