//
//  AvivaScoring.swift
//  RnBridgeIms
//
//  Created by Matthew Robertson on 05/02/2024.
//

import Foundation
import Portal

struct AvivaScoring: Encodable {
    let averageScore: Double?
    let tripScoringAverage: AvivaTripScoringAverage?
    
    init(scoringAverage: ScoringAverage) {
        averageScore = scoringAverage.averageScore
        if let componentScores = scoringAverage.tripScoringAverage?.componentScores {
            tripScoringAverage = AvivaTripScoringAverage(componentScore: AvivaSubScores(componentScores: componentScores))
        } else {
            tripScoringAverage = nil
        }
    }
}

struct AvivaTripScoringAverage: Encodable {
    let componentScore: AvivaSubScores
}

