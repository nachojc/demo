//
//  Promise.swift
//  RnBridgeIms
//
//  Created by Daniel on 10/07/2024.
//

import Foundation

class Promise {
  private var hasInvoked: Bool = false
  private var resolver: RCTPromiseResolveBlock
  private var rejector: RCTPromiseRejectBlock

  init(resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
    self.resolver = resolver
    self.rejector = rejector
  }

  private func synchronised(closure: () -> ()) {
    objc_sync_enter(self)
    closure()
    objc_sync_exit(self)
  }

  func resolve(_ result: Any?) {
    synchronised {
      if !hasInvoked {
        resolver(result)
        hasInvoked = true
      }
    }
  }

  func reject(_ code: String?, _ message: String?, _ error: Error?) {
    synchronised {
      if !hasInvoked {
        rejector(code, message, error)
        hasInvoked = true
      }
    }
  }
}
