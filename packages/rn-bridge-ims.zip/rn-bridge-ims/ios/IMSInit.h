#import <Foundation/Foundation.h>

@interface IMSInit : NSObject
+ (void)initIMS;
@end
