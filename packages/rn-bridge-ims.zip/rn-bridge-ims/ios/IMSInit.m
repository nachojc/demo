//
//  IMSInit.m
//  RnBridgeIms
//
//  Created by Matthew Robertson on 21/11/2023.
//

#import <Foundation/Foundation.h>
#import "IMSInit.h"
#import "RnBridgeIms-Swift.h"


@implementation IMSInit

+ (void)initIMS {
//initialises common via SDK
    [RnBridgeIms initSDK];
    [RnBridgeIms intialiseWithNils];
}

@end
