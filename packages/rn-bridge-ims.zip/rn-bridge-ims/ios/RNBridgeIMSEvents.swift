//
//  RNBridgeIMSEvents.swift
//  RnBridgeIms
//
//  Created by Matthew Robertson on 15/01/2024.
//

import Foundation
import Combine


@objc(RnBridgeImsEvents)
class RnBridgeImsEvents: RCTEventEmitter {

    override init() {
        super.init()
        TripEventEmitter.sharedInstance.registerEventEmitter(eventEmitter: self)
    }

    @Published private var hasListeners = false
    private let listenerQueue = DispatchQueue(label: "hasTripListeners", qos: .background)
    
    var canSendEvent: Bool {
        hasListeners
    }
    
    func waitForSendEvent(timeout: Double, action: @escaping () -> Void, cancel: @escaping () -> Void){
        var subscription: AnyCancellable?
        subscription = $hasListeners.receive(on: listenerQueue )
            .removeDuplicates()
            .filter({ $0 })
            .sink(receiveValue: { _ in
                print("[RnBridgeImsEvents] RN is listening firing action()")
                action()
                subscription?.cancel()
                subscription = nil
            })
        listenerQueue.asyncAfter(deadline: .now() + timeout) {
            if ( subscription != nil ) {
                print("[RnBridgeImsEvents] Timed out waiting for RN to listen")
                cancel()
                subscription?.cancel()
                subscription = nil
            }
        }
    }
    

    @objc override func startObserving() {
        super.startObserving()
        hasListeners = true
    }

    @objc override func stopObserving() {
        hasListeners = false
        super.stopObserving()
    }

    @objc override func supportedEvents() -> [String] {
        return TripEventEmitter.sharedInstance.allEvents
    }
}
