//
//  Portal.h
//  Portal
//
//  Created by Matthew Snow on 2017-01-18.
//  Copyright © 2017 Intelligent Mechatronic Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Portal.
FOUNDATION_EXPORT double PortalVersionNumber;

//! Project version string for Portal.
FOUNDATION_EXPORT const unsigned char PortalVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Portal/PublicHeader.h>


