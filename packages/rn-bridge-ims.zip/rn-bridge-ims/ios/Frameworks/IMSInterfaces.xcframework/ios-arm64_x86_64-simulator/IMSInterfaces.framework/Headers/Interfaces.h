//
//  Interfaces.h
//  Interfaces
//
//  Created by Lyubomir Vezev on 15.08.22.
//

#import <Foundation/Foundation.h>

//! Project version number for Interfaces.
FOUNDATION_EXPORT double InterfacesVersionNumber;

//! Project version string for Interfaces.
FOUNDATION_EXPORT const unsigned char InterfacesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Interfaces/PublicHeader.h>


