//
//  Gateway.h
//  Gateway
//
//  Created by Matthew Snow on 2017-03-11.
//  Copyright © 2017 Intelligent Mechatronic Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Gateway.
FOUNDATION_EXPORT double GatewayVersionNumber;

//! Project version string for Gateway.
FOUNDATION_EXPORT const unsigned char GatewayVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Gateway/PublicHeader.h>

#import "zconf.h"
