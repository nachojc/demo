//
//  TripDetectionUmbrella.h
//  TripDetectionUmbrella
//
//  Created by Matthew Snow on 2017-03-25.
//  Copyright © 2017 Intelligent Mechatronic Systems, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TripDetectionUmbrella.
FOUNDATION_EXPORT double TripDetectionUmbrellaVersionNumber;

//! Project version string for TripDetectionManager.
FOUNDATION_EXPORT const unsigned char TripDetectionUmbrellaVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TripDetectionUmbrella/PublicHeader.h>


