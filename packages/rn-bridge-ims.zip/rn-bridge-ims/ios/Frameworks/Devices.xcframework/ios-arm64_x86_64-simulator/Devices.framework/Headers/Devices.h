//
//  Devices.h
//  Devices
//
//  Created by Alexey Art on 23.08.22.
//

#import <Foundation/Foundation.h>

//! Project version number for Devices.
FOUNDATION_EXPORT double DevicesVersionNumber;

//! Project version string for Devices.
FOUNDATION_EXPORT const unsigned char DevicesVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Devices/PublicHeader.h>


