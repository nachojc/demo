//
//  DistractedDriving.h
//  DistractedDriving
//
//  Created by Yohann Melo on 8/11/16.
//  Copyright © 2016 IMS. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for DistractedDriving.
FOUNDATION_EXPORT double DistractedDrivingVersionNumber;

//! Project version string for DistractedDriving.
FOUNDATION_EXPORT const unsigned char DistractedDrivingVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DistractedDriving/PublicHeader.h>
