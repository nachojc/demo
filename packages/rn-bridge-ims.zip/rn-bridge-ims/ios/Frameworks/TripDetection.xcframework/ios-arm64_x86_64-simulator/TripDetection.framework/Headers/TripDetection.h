//
//  GlobalTrackingAlgorithm.h
//  GlobalTrackingAlgorithm
//
//  Created by Yohann Melo on 8/11/16.
//  Copyright © 2016 IMS. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GlobalTrackingAlgorithm.
FOUNDATION_EXPORT double GlobalTrackingAlgorithmVersionNumber;

//! Project version string for GlobalTrackingAlgorithm.
FOUNDATION_EXPORT const unsigned char GlobalTrackingAlgorithmVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GlobalTrackingAlgorithm/PublicHeader.h>


