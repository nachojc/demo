//
//  IMSBridge.swift
//  MyAviva IMS
//
//  Created by Filippo Minelle on 09/03/2023.
//

import Foundation

@available(iOS 13.0, *)
@objc(RnBridgeIms)
public class RnBridgeIms: NSObject {

    private let imsbridge = IMSBridge()

    private static var storedApiKey: String? {
        get { return UserDefaults.standard.string(forKey: "MYDRIVE_API_KEY")}
        set { UserDefaults.standard.set(newValue, forKey: "MYDRIVE_API_KEY")}
    }

    private static var activationId: String? {
        get { return UserDefaults.standard.string(forKey: "MYDRIVE_ACTIVATION_ID")}
        set { UserDefaults.standard.set(newValue, forKey: "MYDRIVE_ACTIVATION_ID")}
    }

    @objc(initSDK)
    public static func initSDK() {
        DispatchQueue.main.async {
            IMSBridge.initialise()
        }
    }


    @objc public static func intialiseWithNils() {
        initialiseAll(nil, externalReferenceID: nil)
    }

    @objc(initialise:withExternalReferenceID:)
    public func initialise(_ apiKey: String, externalReferenceID: String) {
        RnBridgeIms.initialiseAll(apiKey, externalReferenceID: externalReferenceID)
    }

    private static func initialiseAll(_ apiKey: String?, externalReferenceID: String?) {
        // Check if values are nil
        // Save if not nil (as coming from RN)
        // Use values if not nil stored, but nil passed (as coming from AppDelegate)

        let shouldActivateDevice =  apiKey != nil || externalReferenceID != nil
        if (apiKey != nil) {
            storedApiKey = apiKey
        }

        if (externalReferenceID != nil) {
            activationId = externalReferenceID
        }

        if let key = storedApiKey, let id = activationId {
            DispatchQueue.main.async {
                IMSBridge.initialiseTripDetectionManager(apiKey: key, externalReferenceID: id)
                IMSBridge.enableTripDetection()
                if (shouldActivateDevice) { IMSBridge.activateDevice() }
            }
        }
    }

    private static func removeStoredValues() {
        storedApiKey = nil
        activationId = nil
    }

    @objc(disable)
    func disable() {
        DispatchQueue.main.async {
            self.imsbridge.deactivateDevice()
            IMSBridge.disableTripDetection()
            self.imsbridge.deinitialiseTripDetectionManager()
            RnBridgeIms.removeStoredValues()
        }
    }

    @objc(setSignedToken:)
    func setSignedToken(token: NSString) {
        imsbridge.setSignedToken(signedToken: token)
    }

    @objc(initialiseTripDetectionManager:withExternalReferenceID:withResolver:withRejecter:)
    func initialiseTripDetectionManager(_ apiKey: String,
                                        externalReferenceID: String,
                                        resolve: RCTPromiseResolveBlock, reject: RCTPromiseRejectBlock) {
        IMSBridge.initialiseTripDetectionManager(apiKey: apiKey,
                                                 externalReferenceID: externalReferenceID)
    }

    @objc(enableTripDetection:withRejecter:)
    func enableTripDetection(resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        DispatchQueue.main.async {
            IMSBridge.enableTripDetection()
            resolver(nil)
        }
    }

    @objc(disableTripDetection:withRejecter:)
    func disableTripDetection(resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        DispatchQueue.main.async {
            IMSBridge.disableTripDetection()
            resolver(nil)
        }
    }

    @objc(beginTrip)
    func beginTrip() {
        imsbridge.beginTrip()
    }

    @objc(endTrip)
    func endTrip() {
        imsbridge.endTrip()
    }

    @objc(tripsToUpload:withRejecter:)
    func tripsToUpload(resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        imsbridge.tripsToUpload(resolver: resolver, rejector: rejector)
    }

    @objc(isTripDetectionManagerEnabled:withRejecter:)
    func isTripDetectionManagerEnabled(resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        imsbridge.isTripDetectionManagerEnabled(resolver: resolver, rejector: rejector)
    }

    @objc(uploadAllTrips:withRejecter:)
    func uploadAllTrips(_ resolve: RCTPromiseResolveBlock, reject: RCTPromiseRejectBlock) {
        imsbridge.uploadAllTrips()
    }

    @objc(printInImsLogs:)
    func printInImsLogs(message: String) {
        print(message)
    }

    // MARK: Trips


    @objc(updateTrip:withTransportMode:withResolver:withRejector:)
    func updateTrip(tripId: String, transportMode: String, resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        imsbridge.updateTrip(tripId: tripId, transportMode: transportMode, resolver: resolver, rejector: rejector)
    }

    @objc(fetchTripById:withResolver:withRejector:)
    func fetchTripById(tripId: String, resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        imsbridge.fetchTripById(tripId: tripId, resolver: resolver, rejector: rejector)
    }

    @objc(fetchAllTripsByDate:withEndDate:withResolver:withRejector:)
    func fetchAllTripsByDate(startDate: NSNumber, endDate: NSNumber, resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        imsbridge.fetchAllTripsByDate(startDate: startDate, endDate: endDate, resolver: resolver, rejector: rejector)
    }

    @objc(fetchScoringAverage:withEndDate:withResolver:withRejector:)
    func fetchScoringAverage(startDate: NSNumber, endDate: NSNumber, resolver: @escaping RCTPromiseResolveBlock, rejector: @escaping RCTPromiseRejectBlock) {
        imsbridge.fetchScoringAverage(startDate: startDate, endDate: endDate, resolver: resolver, rejector: rejector)
    }
}
