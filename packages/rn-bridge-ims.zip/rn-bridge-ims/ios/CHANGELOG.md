# Changelog

Record notable changes to the IMS project in this file as it can be difficult to track what version the file should be at when it doesn't have a version against it
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),

## [29-07-2024]
- IMS Frameworks version 1.21
- Remove Heartbeat Framework
- Add IMSAppMisuse Framework

## [06-12-2023]
- IMS Frameworks version 1.18
- Add Bluetooth Framework
- Add IMS Interfaces
- Add IMS Permissions
- Add IMS Heartbeat
- Add Devices

## [Unknown]
- IMS Frameworks version 1.16
