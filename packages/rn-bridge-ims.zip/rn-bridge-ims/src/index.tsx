import { NativeEventEmitter, NativeModules, Platform } from 'react-native';

const LINKING_ERROR =
  `The package 'rn-bridge-ims' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo Go\n';
const RnBridgeIms = NativeModules.RnBridgeIms
  ? NativeModules.RnBridgeIms
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

const RnBridgeImsEvents = NativeModules.RnBridgeImsEvents
  ? NativeModules.RnBridgeImsEvents
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

const RnBridgeImsTokenEvents = NativeModules.RnBridgeImsTokenEvents
  ? NativeModules.RnBridgeImsTokenEvents
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );
//Android implementation is a mixed emitter/module ios is a split event emitter
export const eventEmitter = new NativeEventEmitter(
  Platform.OS === 'ios' ? RnBridgeImsEvents : RnBridgeIms
);

export const tokenEventEmitter = new NativeEventEmitter(
  Platform.OS === 'ios' ? RnBridgeImsTokenEvents : RnBridgeIms
);

export function initialise(apiKey: string, userId: string): Promise<boolean> {
  return RnBridgeIms.initialise(apiKey, userId);
}

export function disable() {
  return RnBridgeIms.disable();
}

export function printInImsLogs(message: string) {
  return RnBridgeIms.printInImsLogs?.(message);
}

export function enableTripDetection(): Promise<void> {
  return RnBridgeIms.enableTripDetection();
}

export function disableTripDetection(): Promise<void> {
  return RnBridgeIms.disableTripDetection();
}

export function tripsToUpload(): Promise<number> {
  return RnBridgeIms.tripsToUpload();
}

export function isTripDetectionManagerEnabled(): Promise<boolean> {
  return RnBridgeIms.isTripDetectionManagerEnabled();
}

export function fetchAllTrips(
  startDate: Date,
  endDate: Date
): Promise<Object[]> {
  const startTimestamp = startDate.getTime();
  const endTimestamp = endDate.getTime();
  return RnBridgeIms.fetchAllTripsByDate(startTimestamp, endTimestamp);
}

export function fetchTripById(tripId: string): Promise<Object> {
  return RnBridgeIms.fetchTripById(tripId);
}

export async function fetchScoringAverage(
  startDate: Date,
  endDate: Date
): Promise<Object> {
  console.log(`fetchScoringAverage ${startDate} ${endDate} `); //The Type of this will change when the actual implementation is created
  return await RnBridgeIms.fetchScoringAverage(
    startDate.getTime(),
    endDate.getTime()
  );
}

export async function updateTrip(
  tripId: string,
  transportMode: string
): Promise<boolean> {
  return await RnBridgeIms.updateTrip(tripId, transportMode);
}

export function testSignToken(token: string): void {
  return RnBridgeIms.testSignToken(token);
}

export function setSignedToken(signedToken: string): void {
  return RnBridgeIms.setSignedToken(signedToken);
}

export function beginTrip(): void {
  return RnBridgeIms.beginTrip();
}

export function endTrip(): void {
  return RnBridgeIms.endTrip();
}

export function uploadAllTrips(): void {
  return RnBridgeIms.uploadAllTrips();
}

export function copyImsLogs(): void {
  return RnBridgeIms.copyLogsToDownloads()
}
