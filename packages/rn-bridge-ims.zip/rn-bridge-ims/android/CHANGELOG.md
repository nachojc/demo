# Changelog

Record notable changes to the IMS project in this file as it can be difficult to track what version the file should be at when it doesn't have a version against it
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),

## [15-07-2024]
- IMS Frameworks version 1.21

## [Unknown]
- IMS Frameworks version 1.16
