package com.rnbridgeims

import androidx.annotation.Keep
import com.intellimec.mobile.android.portal.scoring.ScoringAverage
import com.intellimec.mobile.android.portal.trip.Event
import com.intellimec.mobile.android.portal.trip.TransportMode
import com.intellimec.mobile.android.portal.trip.Trip
import com.intellimec.mobile.android.portal.trip.TripScores
import java.text.SimpleDateFormat
import java.util.Locale

@Keep
data class AvivaTrip(
  val dateEnded: String,
  val dateStarted: String,
  val duration: Double,
  val distance: Double,
  val events: Map<String, List<AvivaEvent>>?,
  val geometry: List<AvivaPoint>?,
  val id: String,
  val reconstructedStartGeometry: List<AvivaPoint>?,
  val score: Double,
  val scores: AvivaTripScores?,
  val status: String?,
  val timeZoneOffset: Double?,
  val transportMode: String?,
) {

  constructor(trip: Trip) : this(
    trip.dateEnded?.let {
      SimpleDateFormat(formatString, Locale.UK)
        .format(it)
    } ?: "", //These shouldn't be null from IMS data
    trip.dateStarted?.let {
      SimpleDateFormat(formatString, Locale.UK)
        .format(it)
    } ?: "",
    nullifyNaN(trip.duration.toDouble()) ?: 0.0,
    nullifyNaN(trip.distance) ?: 0.0,
    mapEvents(trip, formatString),
    trip.geometry?.map { AvivaPoint(it.latitude, it.longitude) },
    trip.id,
    trip.reconstructedStartGeometry?.map { AvivaPoint(it.latitude, it.longitude) },
    nullifyNaN(trip.score) ?: 0.0,
    trip.scores?.let { AvivaTripScores(it) },
    AvivaTripStatus.fromTripStatus(trip.status).status,
    trip.timeZoneOffset.toDouble(),
    if (trip.transportMode == TransportMode.DRIVER) "driver" else "notDriver"
  )

  constructor(tripDateEnded: String, tripDateStarted: String, tripDuration: Double, tripDistance: Double,
              tripEvents: Map<String, List<AvivaEvent>>, tripGeometry: List<AvivaPoint>, tripId: String,
              tripReconstructedStartGeometry: List<AvivaPoint>, tripScore: Double, tripScores: AvivaTripScores,
              tripStatus: String, tripTimeZoneOffset: Double, tripTransportMode: String) : this(
    dateEnded = tripDateEnded,
    dateStarted = tripDateStarted,
    duration = tripDuration,
    distance = tripDistance,
    events = tripEvents,
    geometry = tripGeometry,
    id = tripId,
    reconstructedStartGeometry = tripReconstructedStartGeometry,
    score = tripScore,
    scores = tripScores,
    status = tripStatus,
    timeZoneOffset = tripTimeZoneOffset,
    transportMode = tripTransportMode
  )

  companion object {
    private fun mapEvents(
      trip: Trip, formatString: String
    ) = trip.events?.mapKeys { AvivaEventType.fromEvent(it.key) }
      ?.filter { it.key != AvivaEventType.UNKNOWN }?.mapKeys { it.key.type }?.mapValues {
        it.value.map { e ->
          AvivaEvent(nullifyNaN(e.averageSpeed),
            e.date?.let { SimpleDateFormat(formatString, Locale.UK).format(it) } ?: "",
            e.duration.toDouble(),
            e.longitude,
            e.latitude,
            e.severity?.let { severity -> AvivaSeverity.fromSeverity(severity).severity } ?: "",
            nullifyNaN(e.speed),
            nullifyNaN(e.speedLimit))
        }
      }

    private const val formatString = "yyyy-MM-dd'T'hh:mm:ss.sssZ a"
  }
}

fun tryConvertTrip(trip: Trip): AvivaTrip {
  try {
    return AvivaTrip(trip)
  } catch (e: Throwable) {
    val tripEvents = mapOf<String, List<AvivaEvent>>();
    val tripGeometry = listOf<AvivaPoint>();
    val tripReconstructedStartGeometry = listOf<AvivaPoint>();
    return AvivaTrip(
      "",
      "",
      0.0,
      0.0,
      tripEvents,
      tripGeometry,
      "",
      tripReconstructedStartGeometry,
      0.0,
      AvivaTripScores(0.0, AvivaSubScores(0.0, 0.0, 0.0, 0.0, 0.0)),
      "",
      0.0,
      "unknown");
  }
}

@Keep
data class AvivaPoint(val latitude: Double, val longitude: Double)

@Keep
data class AvivaEvent(
  val averageSpeed: Double?,
  val date: String,
  val duration: Double?,
  val longitude: Double,
  val latitude: Double,
  val severity: String,
  val speed: Double?,
  val speedLimit: Double?
)

@Keep
data class AvivaTripScores(val overall: Double, val subScores: AvivaSubScores) {
  constructor(tripScores: TripScores) : this(
    nullifyNaN(tripScores.overall) ?: 0.0, AvivaSubScores(tripScores.subScores)
  )
}

@Keep
data class AvivaSubScores(
  val acceleration: Double?,
  val braking: Double?,
  val cornering: Double?,
  val distractedDriving: Double?,
  val speeding: Double?
) {
  constructor(componentScore: ScoringAverage.TripScoringAverage.ComponentScore) : this(
    nullifyNaN(componentScore.acceleration),
    nullifyNaN(componentScore.braking),
    nullifyNaN(componentScore.cornering),
    nullifyNaN(componentScore.distractedDriving),
    nullifyNaN(componentScore.map["speeding"] as? Double) //IMS Bug meaning the speeding is being replaced by speed_subscore
  )

  constructor(subScores: Map<TripScores.SubScoreType, Double>) : this(
    nullifyNaN(subScores[TripScores.CoreSubScoreType.ACCELERATION]),
    nullifyNaN(subScores[TripScores.CoreSubScoreType.BRAKING]),
    nullifyNaN(subScores[TripScores.CoreSubScoreType.CORNERING]),
    nullifyNaN(subScores[TripScores.OtherSubScoreType("distracted.driving")]),
    nullifyNaN(subScores[TripScores.CoreSubScoreType.SPEEDING])
  )

  fun isEmpty(): Boolean = listOfNotNull(
    acceleration, braking, cornering, distractedDriving, speeding
  ).isEmpty() //Check if any of the items are not null (if they're all null then there are no scores)
}

enum class AvivaEventType(val type: String) {
  ACCELERATION("acceleration"), BRAKING("braking"), CORNERING("cornering"), DISTRACTED_DRIVING("distractedDriving"), SPEEDING(
    "speeding"
  ),
  UNKNOWN("unknown");

  companion object {
    fun fromEvent(e: Event.EventType): AvivaEventType {
      return when (e) {
        Event.CoreEventType.ACCELERATION -> ACCELERATION
        Event.CoreEventType.BRAKING -> BRAKING
        Event.CoreEventType.CORNERING -> CORNERING
        Event.CoreEventType.POSTED_SPEED_LIMIT -> SPEEDING
        Event.OtherEventType("OTHER.DistractedDrivingViolation") -> DISTRACTED_DRIVING //Might not be quite right this might be the Scores version
        else -> UNKNOWN
      }
    }
  }
}

enum class AvivaSeverity(val severity: String) {
  VERY_LOW("veryLow"), LOW("low"), MEDIUM("medium"), HIGH("high"), VERY_HIGH("veryHigh");

  companion object {
    fun fromSeverity(e: Event.Severity): AvivaSeverity {
      return when (e) {
        Event.Severity.VERY_HIGH -> VERY_HIGH
        Event.Severity.HIGH -> HIGH
        Event.Severity.MEDIUM -> MEDIUM
        Event.Severity.LOW -> LOW
        Event.Severity.VERY_LOW -> VERY_LOW
      }
    }
  }
}

enum class AvivaTripStatus(val status: String) {
  IN_PROGRESS("inProgress"), COMPLETE("complete"), UNKNOWN("unknown");

  companion object {
    fun fromTripStatus(status: Trip.Status): AvivaTripStatus {
      return when (status) {
        Trip.Status.IN_PROGRESS -> IN_PROGRESS
        Trip.Status.COMPLETE -> COMPLETE
        Trip.Status.UNKNOWN -> UNKNOWN
      }
    }
  }
}
