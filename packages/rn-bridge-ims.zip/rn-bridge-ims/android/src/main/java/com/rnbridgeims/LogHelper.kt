package com.rnbridgeims

import com.drivesync.android.log.Log

object LogHelper {

  fun d(tag: String, message: String) {
    Log.i(tag, message)
    android.util.Log.d(tag, message)
  }

  fun e(tag: String, message: String) {
    Log.e(tag, message)
    android.util.Log.e(tag, message)
  }

  fun i(tag: String, message: String) {
    Log.i(tag, message)
    android.util.Log.i(tag, message)
  }

  fun w(tag: String, message: String) {
    Log.e(tag, message)
    android.util.Log.w(tag, message)
  }
}
