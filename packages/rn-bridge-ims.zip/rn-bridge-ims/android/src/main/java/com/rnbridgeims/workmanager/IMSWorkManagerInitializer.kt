package com.rnbridgeims.workmanager

import android.content.Context
import android.util.Log
import androidx.startup.Initializer
import androidx.work.Configuration
import androidx.work.WorkManager

class IMSWorkManagerInitializer : Initializer<WorkManager> {
  override fun create(context: Context): WorkManager {
    val configuration = Configuration.Builder().build()
    try {
      Log.d("IMSWorkManagerInitializer", "Initialising Work Manager")
      WorkManager.initialize(context, configuration)
    } catch (e: Exception) {
      Log.d(
        "IMSWorkManagerInitializer",
        "WorkManager initialization threw an error; likely already initialized. Error: $e"
      )
    }
    return WorkManager.getInstance(context)
  }

  override fun dependencies() = emptyList<Class<out Initializer<*>>>()
}
