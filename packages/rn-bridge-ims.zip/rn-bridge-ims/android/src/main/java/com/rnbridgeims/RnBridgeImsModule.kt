package com.rnbridgeims

import android.content.Context
import android.os.Environment
import com.drivesync.android.trips.ImsTripManager
import com.drivesync.android.trips.ImsTripStatus
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.modules.core.DeviceEventManagerModule.RCTDeviceEventEmitter
import com.google.gson.Gson
import com.intellimec.mobile.android.common.Identity
import com.intellimec.mobile.android.common.ImsSdkManager
import com.intellimec.mobile.android.common.Result
import com.intellimec.mobile.android.portal.device.DeviceService
import com.intellimec.mobile.android.portal.scoring.ScoringService
import com.intellimec.mobile.android.portal.trip.TransportMode
import com.intellimec.mobile.android.portal.trip.TripService
import com.intellimec.mobile.android.tripdetection.SamplingRate.ONE_HZ
import com.intellimec.mobile.android.tripdetection.TripDetector
import com.intellimec.mobile.android.tripdetection.TripTelemetry
import com.intellimec.mobile.android.tripdetection.TripValidator
import java.io.File
import java.time.Instant
import java.util.Date

class RnBridgeImsModule(private val reactContext: ReactApplicationContext) :
  ReactContextBaseJavaModule(reactContext) {
  override fun getName(): String {
    return NAME
  }

  init {
    INSTANCE = this
  }

  // The identity of the user.
  private var currentIdentity =
    if (ImsSdkManager.isConfigured) ImsSdkManager.configuration.identity else null

  private fun getEmitter(): RCTDeviceEventEmitter? {
    return reactContext.getJSModule(RCTDeviceEventEmitter::class.java)
  }

  private var isTripDetectionEnabled: Boolean
    get() {
      with(reactContext) {
        val prefs = getSharedPreferences(
          getString(R.string.shared_prefs_file), Context.MODE_PRIVATE
        )
        return prefs.getBoolean(getString(R.string.trip_detection_key), false)
      }
    }
    set(value) {
      with(reactContext) {
        val prefs = getSharedPreferences(
          getString(R.string.shared_prefs_file), Context.MODE_PRIVATE
        )
        prefs.edit().putBoolean(getString(R.string.trip_detection_key), value).apply()
      }
    }

  @ReactMethod
  fun initialise(apiKey: String, userIdentifier: String) {
    reactContext.runOnNativeModulesQueueThread {
      initialiseSDK(apiKey, userIdentifier)
      configureTrips(reactContext) //Configure the trip manager after initialisation, no need to have RN call it
      tripStatusListener() //Set up the trip status listener
      activateDevice() //Activate the device after init
      enableTripDetectionIms() //Enable Trip Detection
    }
  }

  @ReactMethod
  fun disable() {
    disableTripDetectionIms()
    removeTripStatusListener()
    deactivateDevice()
  }

  @ReactMethod
  fun printInImsLogs(message: String) {
    LogHelper.d("$NAME+RN", message)
  }

  @ReactMethod
  fun tripsToUpload(promise: Promise) {
    promise.resolve(if (ImsSdkManager.isConfigured) ImsTripManager.tripManagerStatus.tripsToUpload else 0)
  }

  @ReactMethod
  fun isTripDetectionManagerEnabled(promise: Promise) {
    promise.resolve(ImsSdkManager.isConfigured && ImsTripManager.tripManagerStatus.isEnabled)
  }

  private fun initialiseSDK(apiKey: String, userIdentifier: String) {
    currentIdentity = Identity(apiKey, userIdentifier)

    if (!ImsSdkManager.isConfigured || ImsSdkManager.configuration.apiKey != apiKey) { // if not already configured, or the api key has changed then configure the SDK
      ImsSdkManager.setSdkConfiguration(
        reactContext,
        ImsSdkManager.Builder().setApiKey(apiKey)
          .setSdkFolder(File(reactContext.filesDir, "ims_sdk"))
          .setTokenSigner(IMSTokenSigner::class.java)
          .setUploadWiFiOnly(false).setIdentity(currentIdentity).build()
      )
    }
    if (ImsSdkManager.configuration.identity != currentIdentity) { //Given the configuration only needs to be set once, update the current identity if it's changed.
      ImsSdkManager.setIdentity(reactContext, currentIdentity)
    }
  }

  @ReactMethod
  fun copyLogsToDownloads() {
    LogHelper.d(NAME, "Copy Logs to Download")

    val sdkDirectory = File(reactContext.filesDir, "ims_sdk")
    val logsFolder = File(sdkDirectory, "logs")

    val downloadsFolder = File(
      Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
      "ims_logs"
    )
    if (!downloadsFolder.exists()) downloadsFolder.mkdir()
    logsFolder.copyRecursively(downloadsFolder, overwrite = true)
  }

  private fun activateDevice() {
    /**********************
     * Activate the device.
     **********************/
    val deviceService = currentIdentity?.let { DeviceService(it) }
    deviceService?.activate() {
      when (it) {
        is Result.Failure -> LogHelper.e(NAME, "Something went wrong.")
        is Result.Success -> LogHelper.i(NAME, "Device is activated.")
      }
    }
  }

  private fun deactivateDevice() {
    currentIdentity?.let {
      DeviceService(it)
    }?.deactivate {
      when (it) {
        is Result.Failure -> LogHelper.e(NAME, "Something went wrong")
        is Result.Success -> LogHelper.i(NAME, "Device deactivated")
      }
    }
  }

  private fun enableTripDetectionIms() {
    enableTripDetectionIms(reactContext, currentIdentity)
    isTripDetectionEnabled = true
  }

  @ReactMethod
  fun enableTripDetection(promise: Promise) {
    enableTripDetectionIms()
    promise.resolve(null)
  }

  private fun disableTripDetectionIms() {
    disableTripDetectionIms(reactContext)
    isTripDetectionEnabled = false
  }

  @ReactMethod
  fun disableTripDetection(promise: Promise) {
    disableTripDetectionIms()
    promise.resolve(null)
  }

  private val tripStatusListener = object : ImsTripManager.TripStatusListener {
    override fun onTripStatusUpdate(tripStatus: ImsTripStatus) {
      when (tripStatus.tripState) {
        ImsTripStatus.TripState.ENABLED -> LogHelper.d(NAME, "Trip Enabled")
        ImsTripStatus.TripState.CHECKING -> LogHelper.d(NAME, "Checking Trip")
        ImsTripStatus.TripState.STARTED -> {
          LogHelper.d(NAME, "Trip Started.")
          val now = System.currentTimeMillis() / 1000.0
          val data = Arguments.createMap()
          data.putDouble("date", now)
          getEmitter()?.emit("tripConfirmed", data)
        }

        ImsTripStatus.TripState.STOPPED -> {
          LogHelper.d(NAME, "Trip Ended.")
          val now = System.currentTimeMillis() / 1000.0
          val data = Arguments.createMap()
          data.putDouble("date", now)
          getEmitter()?.emit("tripEnded", data)
        }

        ImsTripStatus.TripState.DISABLED -> LogHelper.d(NAME, "Trip Disabled")
      }
    }
  }

  private fun tripStatusListener() {
    ImsTripManager.addTripStatusListener(tripStatusListener)
  }

  private fun removeTripStatusListener() {
    ImsTripManager.removeTripStatusListener(tripStatusListener)
  }

  @ReactMethod
  fun setSignedToken(token: String) {
    LogHelper.d(NAME, "signed token recieved")
    reactContext.runOnNativeModulesQueueThread {
      (ImsSdkManager.configuration.tokenSigner as IMSTokenSigner).signedToken = token
    }
  }

  @ReactMethod
  fun beginTrip() {
    reactContext.runOnNativeModulesQueueThread {
      LogHelper.d(NAME, "Starting Trip")
      ImsTripManager.startTrip(reactContext, 0, null)
    }
  }

  @ReactMethod
  fun endTrip() {
    reactContext.runOnNativeModulesQueueThread {
      LogHelper.d(NAME, "Ending Trip")
      ImsTripManager.stopTrip(reactContext, 0, null)
    }
  }

  @ReactMethod
  fun fetchScoringAverage(start: Double, end: Double, promise: Promise) {
    currentIdentity?.let {
      val scoringService = ScoringService(it)
      scoringService.fetchAverage(start.toLong(), end.toLong()) { result ->
        if (result.throwable != null) {
          promise.reject("fetch_scores_error", result.throwable)
          return@fetchAverage
        }
        if (result.value == null) {
          promise.reject("fetch_scores_error", "value null")
          return@fetchAverage
        }
        val scoringAverage = AvivaScoring(averageScores = result.value!!) //Checked above
        if (scoringAverage.isEmpty()) {
          promise.resolve(false)
          return@fetchAverage
        }
        with(Gson()) {
          val scoringAverageMap = fromJson(toJson(scoringAverage), HashMap::class.java)
          promise.resolve(fromMap(scoringAverageMap))
        }
      }
    } ?: promise.reject("identity_fail", "Identity not set")
  }

  @ReactMethod
  fun fetchTripById(tripId: String, promise: Promise) {
    val expansions = setOf(
      TripService.Expansion.EVENTS,
      TripService.Expansion.GEOMETRY,
      TripService.Expansion.SCORES,
      TripService.Expansion.USER
    )
    currentIdentity?.let {
      val tripService = TripService(identity = it)
      tripService.fetch(tripId, expansions) { result ->
        if (result.throwable != null) {
          promise.reject("fetch_trip_error", result.throwable)
          return@fetch
        }
        if (result.value == null) {
          promise.reject("fetch_trip_error", "value null")
          return@fetch
        }
        val avivaTrip = tryConvertTrip(result.value!!) //Checked above
        with(Gson()) {
          val avivaTripMap = fromJson(toJson(avivaTrip), HashMap::class.java)
          promise.resolve(fromMap(avivaTripMap))
        }
      }
    } ?: promise.reject("identity_fail", "Identity not set")
  }

  @ReactMethod
  fun fetchAllTripsByDate(start: Double, end: Double, promise: Promise) {
    val startDate = Date.from(Instant.ofEpochMilli(start.toLong()))
    val endDate = Date.from(Instant.ofEpochMilli(end.toLong()))

    val filters = setOf(TripService.Filter.Date(startDate, endDate))
    currentIdentity?.let {
      val tripService = TripService(identity = it)
      tripService.fetchAll(filters) { result ->
        if (result.throwable != null) {
          promise.reject("fetch_trip_error", result.throwable)
          return@fetchAll
        }
        if (result.value == null) {
          promise.reject("fetch_trip_error", "value null")
          return@fetchAll
        }

        with(Gson()) {
          result.value?.map { trip -> tryConvertTrip(trip) }
            ?.map { avivaTrip -> toJson(avivaTrip) }
            ?.map { tripString -> fromJson(tripString, HashMap::class.java) }
            ?.let { tripList -> fromArray(tripList) }
        }?.let { tripArray ->
          promise.resolve(tripArray)
        } ?: promise.reject("fetch_trip_error", "problem converting trip object")
      }

    } ?: promise.reject("identity_fail", "Identity not set")
  }

  @ReactMethod
  fun uploadAllTrips() {
    LogHelper.d(NAME, "Upload All Trips Called")
    com.intellimec.mobile.android.gateway.UploadManager.uploadAllTripFiles(reactContext)
  }

  @ReactMethod
  fun updateTrip(tripId: String, transportMode: String, promise: Promise) {
    val newMode = when (transportMode.lowercase()) {
      "passenger" -> TransportMode.PASSENGER
      "driver" -> TransportMode.DRIVER
      else -> TransportMode.UNKNOWN
    }
    currentIdentity?.let {
      val tripService = TripService(it)
      tripService.fetch(tripId) { result ->
        val resultValue = result.value
        if (result.throwable != null) {
          promise.reject("fetch_trip_error", result.throwable)
          return@fetch
        }
        if (resultValue == null) {
          promise.reject("fetch_trip_error", "value null")
          return@fetch
        }
        tripService.updateTrip(resultValue, newMode) { newTrip ->
          if (newTrip.throwable != null) {
            promise.reject("update_trip_error", newTrip.throwable)
            return@updateTrip
          }
          if (newTrip.value == null) {
            promise.reject("update_trip_error", "value null")
            return@updateTrip
          }
          promise.resolve(newTrip.value?.transportMode == newMode)
        }
      }
    } ?: promise.reject("identity_fail", "Identity not set")
  }


  @ReactMethod
  fun addListener(eventName: String) {
    LogHelper.d(NAME, "adding listener for $eventName")
    IMSTokenSigner.emitter = getEmitter()
    IMSTokenSigner.incrementListeners(eventName)
  }

  @ReactMethod
  fun removeListeners(count: Int) {
    LogHelper.d(NAME, "removing $count listener${if (count > 1 || count == 0) "s" else ""}")
    IMSTokenSigner.decrementListeners(count)
  }

  companion object {
    var INSTANCE: RnBridgeImsModule? = null
    const val NAME = "RnBridgeIms"

    fun enableTripDetectionIms(context: Context, identity: Identity?) {
      identity?.let {
        if (!ImsTripManager.tripManagerStatus.isEnabled) {
          ImsTripManager.enableTripManager(context, it)
        }
      }
    }

    fun disableTripDetectionIms(context: Context) {
      // Disable Trip Detection but do not delete pending trip files
      ImsTripManager.disableTripManager(context, false)
    }

    fun configureTrips(context: Context) {
      if (!ImsTripManager.isConfigured) {
        ImsTripManager.configureTripManager(
          context, ImsTripManager.Builder().setTripDetectors(
            TripDetector.ACTIVITY,
            TripDetector.GEOFENCE// Might need to add the Awareness API in here?
          ).setTripValidators(
            TripValidator.PHONE,
          ).setTripTelemetry(
            TripTelemetry.LOCATION,
            TripTelemetry.SPEED,
            TripTelemetry.DISTRACTED_DRIVING,
            TripTelemetry.ACCELEROMETER(ONE_HZ),
            TripTelemetry.GYROSCOPE(ONE_HZ),
            TripTelemetry.GRAVITY(ONE_HZ),
            TripTelemetry.MAGNETOMETER(ONE_HZ),
            TripTelemetry.USER_ACCELERATION(ONE_HZ)
          ).setTripNotification(IMSTripNotificationFactory::class.java).build()
        )
      }
    }
  }
}
