package com.rnbridgeims

import androidx.annotation.Keep
import com.intellimec.mobile.android.portal.scoring.ScoringAverage

@Keep
data class AvivaScoring(val averageScore: Double?, val tripScoringAverage: AvivaTripScoringAverage) {
  constructor(averageScores: ScoringAverage) : this(
    nullifyNaN(averageScores.averageScore),
    AvivaTripScoringAverage(AvivaSubScores(averageScores.tripScoringAverage.componentScore))
  )

  fun isEmpty() = averageScore == null && tripScoringAverage.isEmpty()
}

@Keep
data class AvivaTripScoringAverage(val componentScore: AvivaSubScores) {
  fun isEmpty() = componentScore.isEmpty()
}


