package com.rnbridgeims

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.NotificationManager.IMPORTANCE_HIGH
import android.content.Context
import androidx.core.app.NotificationCompat
import com.intellimec.mobile.android.tripdetection.TripNotificationFactory

// Trip notification here
// https://sdk.ims.tech/readme/android/using-the-sdk/trip-detection-and-recording/trip-manager-configuration

class IMSTripNotificationFactory: TripNotificationFactory {
  private val channelId = "MD"
  private val channelName = "MyDrive"
  private val channel: NotificationChannel =
    NotificationChannel(channelId, channelName, IMPORTANCE_HIGH)

  override fun createPotentialTripNotification(context: Context): Notification {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (!manager.notificationChannels.contains(channel)) manager.createNotificationChannel(channel)
    return NotificationCompat.Builder(context, channelId)
      .setSmallIcon(R.drawable.ic_notification_icon)
      .setDefaults(NotificationCompat.DEFAULT_ALL)
      .setContentTitle(context.getString(R.string.notification_title))
      .setContentText(context.getString(R.string.potential_notification_content))
      .setStyle(NotificationCompat.BigTextStyle().bigText(context.getString(R.string.potential_notification_content)))
      .build()
  }

  override fun createValidatedTripNotification(context: Context): Notification {
    val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (!manager.notificationChannels.contains(channel)) manager.createNotificationChannel(channel)
    return NotificationCompat.Builder(context, channelId)
      .setSmallIcon(R.drawable.ic_notification_icon)
      .setDefaults(NotificationCompat.DEFAULT_ALL)
      .setContentTitle(context.getString(R.string.notification_title))
      .setContentText(context.getString(R.string.validated_notification_content))
      .setStyle(NotificationCompat.BigTextStyle().bigText(context.getString(R.string.validated_notification_content)))
      .build()
  }
}
