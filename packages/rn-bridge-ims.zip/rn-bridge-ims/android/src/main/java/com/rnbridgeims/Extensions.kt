package com.rnbridgeims

import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.WritableArray
import com.facebook.react.bridge.WritableMap
import com.google.gson.GsonBuilder

fun fromArray(inputArray: List<*>): WritableArray {
  val arr = Arguments.createArray()
  inputArray.forEach {
    when (it) {
      is String -> arr.pushString(it)
      is Boolean -> arr.pushBoolean(it)
      is Int -> arr.pushInt(it)
      is Map<*, *> -> arr.pushMap(fromMap(it))
      is List<*> -> arr.pushArray(fromArray(it))
      is Double -> arr.pushDouble(it)
      is Float -> arr.pushDouble(it.toDouble())
    }
  }
  return arr
}

fun fromMap(inputMap: Map<*, *>): WritableMap {
  val map = Arguments.createMap()
  inputMap.entries.forEach {
    when (val value = it.value) {
      is String -> map.putString(it.key as String, value)
      is Boolean -> map.putBoolean(it.key as String, value)
      is Int -> map.putInt(it.key as String, value)
      is Map<*, *> -> map.putMap(it.key as String, fromMap(value))
      is Double -> map.putDouble(it.key as String, value)
      is Float -> map.putDouble(it.key as String, value.toDouble())
      is List<*> -> map.putArray(it.key as String, fromArray(value))
    }
  }
  return map
}

fun getTripSerializer() = GsonBuilder().setFieldNamingStrategy {
  when (it.name) {
    "id" -> "tripId"
    "status" -> "tripStatus"
    else -> it.name
  }
}.create()!!

fun nullifyNaN(value: Double?) = if (value != null && value.isNaN()) null else value

