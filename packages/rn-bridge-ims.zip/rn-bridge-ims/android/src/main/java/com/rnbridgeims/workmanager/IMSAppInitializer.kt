package com.rnbridgeims.workmanager

import android.content.Context
import android.util.Log
import androidx.startup.Initializer
import com.intellimec.mobile.android.common.ImsSdkInitializer
import com.intellimec.mobile.android.gateway.ImsUploadManagerInitializer

class IMSAppInitializer : Initializer<Any> {

  override fun create(context: Context) {
    Log.d("IMSAppInitializer", "create(context)")
    Log.d("IMSAppInitializer", "ImsSdkInitializer().create(context)")
    ImsSdkInitializer().create(context)
    Log.d("IMSAppInitializer", "ImsUploadManagerInitializer().create(context)")
    ImsUploadManagerInitializer().create(context)
  }

  override fun dependencies(): List<Class<out Initializer<*>>> {
    Log.d("IMSAppInitializer", "dependencies")
    return listOf(IMSWorkManagerInitializer::class.java)
  }
}
