package com.rnbridgeims.workmanager

import android.content.Context
import android.util.Log
import androidx.startup.Initializer
import com.intellimec.mobile.android.common.ImsSdkManager
import com.rnbridgeims.R
import com.rnbridgeims.RnBridgeImsModule

class IMSTripManagerInitializer : Initializer<Any> {
  override fun create(context: Context) {
    Log.d("IMSTripManagerInitializer", "create(context)")
    with(context) {
      if (getSharedPreferences(
          getString(R.string.shared_prefs_file),
          Context.MODE_PRIVATE
        ).getBoolean(
          getString(
            R.string.trip_detection_key
          ), false
        )
      ) {
        Log.i("IMSTripManagerInitializer", "restoring trip detection")
        RnBridgeImsModule.configureTrips(context)
        RnBridgeImsModule.enableTripDetectionIms(this, ImsSdkManager.identity)
      }
    }
  }

  override fun dependencies() = listOf(com.intellimec.mobile.android.common.ImsSdkInitializer::class.java)
}
