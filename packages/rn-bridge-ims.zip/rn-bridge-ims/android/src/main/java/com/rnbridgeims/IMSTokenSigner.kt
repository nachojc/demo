package com.rnbridgeims


import android.os.Handler
import android.os.Looper
import com.facebook.react.modules.core.DeviceEventManagerModule.RCTDeviceEventEmitter
import com.intellimec.mobile.android.common.Result
import com.intellimec.mobile.android.common.TokenSigner
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.filter
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.properties.Delegates

typealias ResultCallback<T> = (Result<T>) -> Unit

class IMSTokenSigner : TokenSigner {
  companion object {
    var emitter: RCTDeviceEventEmitter? = null

    private var listenerCount = 0
    private var signedTokenCallback: ResultCallback<String>? = null

    private val mutableSignTokenCountFlow = MutableStateFlow(0)
    private val signTokenCountFlow = mutableSignTokenCountFlow.asStateFlow()

    private var signTokenCount: Int by Delegates.observable(0) { _, oldValue, newValue ->
      mutableSignTokenCountFlow.value = newValue
    }

    fun incrementListeners(eventName: String) {
      if (eventName == "signToken") {
        signTokenCount++
      }
      listenerCount++
    }

    fun decrementListeners(count: Int) {
      listenerCount -= count
      if (listenerCount <= 0) {
        signTokenCount = 0
        listenerCount = 0
      }
    }
  }

  var signedToken: String by Delegates.observable("") { _, oldValue, newValue ->
    signedTokenCallback?.invoke(
      if (newValue != oldValue && newValue != "") {
        Result.Success(newValue)
      } else {
        Result.Failure(Throwable("Failed to sign token - token not changed or present"))
      }
    )
  }

  private fun dispatchWhenListening(name: String, body: String, cancelFn: () -> Unit) {
    var scope: CoroutineScope?
    scope = CoroutineScope(Job() + Dispatchers.Default)
    scope.launch {
      signTokenCountFlow.filter { it > 0 }
        .distinctUntilChanged()
        .collect {
          val localEmitter = emitter
          if (localEmitter == null) {
            LogHelper.d("IMSTokenSigner", "Emitter is null")
            signedTokenCallback?.invoke(Result.Failure(Throwable("Failed to sign token - emitter is null")))
          } else {
            LogHelper.d("IMSTokenSigner", "RN is listening, emitting unsigned")
            localEmitter.emit(name, body)
          }
          cancel()
          scope = null
        }
    }
    Handler(Looper.getMainLooper()).postDelayed({
      LogHelper.d("IMSTokenSigner", "Cleaning up scope")
      if (scope?.isActive == true) {
        LogHelper.d("IMSTokenSigner", "No one listened Cancelling ")
        cancelFn()
        scope?.cancel()
        scope = null
      }
    }, 10000)
  }


  override fun sign(unsignedToken: String, callback: ResultCallback<String>) {
    LogHelper.d("IMSTokenSigner", "Request to sign")

    signedTokenCallback = callback
    // wait for someone to listen
    dispatchWhenListening("signToken", unsignedToken) {
      LogHelper.d("IMSTokenSigner", "Cancelling, no one listening")

      callback.invoke(Result.Failure(Throwable("Failed to sign token - no one listening")))
    }
  }
}

