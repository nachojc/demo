import * as React from 'react';

interface State {
  dataJson: any;
  schemaJson: any;
}

declare class FusionCharts extends React.Component<any, State> {}

export default FusionCharts;
