export default {
    'fusioncharts': require('./modules/fusioncharts/fusioncharts.fcscript'),
    'fusioncharts.charts': require('./modules/fusioncharts/fusioncharts.charts.fcscript'),
    'fusioncharts.theme.fusion': require('./modules/fusioncharts/themes/fusioncharts.theme.fusion.fcscript'),
    'fusioncharts.excelexport': require('./modules/fusioncharts/fusioncharts.excelexport.fcscript'),
    modules: {
    }
}