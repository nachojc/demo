
import { FusionChartStatic } from 'fusioncharts';

declare namespace Widgets {}
declare var Widgets: (H: FusionChartStatic) => FusionChartStatic;
export = Widgets;
export as namespace Widgets;

