
import { FusionChartStatic } from 'fusioncharts';

declare namespace Umber {}
declare var Umber: (H: FusionChartStatic) => FusionChartStatic;
export = Umber;
export as namespace Umber;

