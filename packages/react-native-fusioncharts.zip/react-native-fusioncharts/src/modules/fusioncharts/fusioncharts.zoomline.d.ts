
import { FusionChartStatic } from 'fusioncharts';

declare namespace Zoomline {}
declare var Zoomline: (H: FusionChartStatic) => FusionChartStatic;
export = Zoomline;
export as namespace Zoomline;

