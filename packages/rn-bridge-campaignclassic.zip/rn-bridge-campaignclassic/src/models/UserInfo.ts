export class UserInfo {
  _mId: string | undefined;
  _dId: string | undefined;
  [key: string]: any;
}
