#import "MyDriveTestHarness.h"
#import "CESimulatorEnhancements.h"

#define USER_DEFAULTS_SENSOR_SIMULATION_ENABLED_KEY @"sensorSimulationEnabled"

static BOOL isEnabled = NO;

@implementation MyDriveTestHarness
RCT_EXPORT_MODULE()

+ (BOOL) requiresMainQueueSetup {
  return YES;
}


+ (void) enable {
#ifdef SIMULATE_SENSORS
  // note: restart is required to take effect
  if (!isEnabled) {
    @synchronized(self) {
      if (!isEnabled) {
        [[CESimulatorEnhancements instance] enable];
        isEnabled = YES;
        [[NSUserDefaults standardUserDefaults] setBool:isEnabled forKey:USER_DEFAULTS_SENSOR_SIMULATION_ENABLED_KEY];
        [[NSUserDefaults standardUserDefaults] synchronize];
      }
    }
  }
#endif
}


+ (void) disable {
#ifdef SIMULATE_SENSORS
  // note: restart is required to take effect
  isEnabled = NO;
  [[NSUserDefaults standardUserDefaults] setBool:isEnabled forKey:USER_DEFAULTS_SENSOR_SIMULATION_ENABLED_KEY];
  [[NSUserDefaults standardUserDefaults] synchronize];
#endif
}


+ (void) setup {
#ifdef SIMULATE_SENSORS
  BOOL wasEnabled = [[NSUserDefaults standardUserDefaults] boolForKey:USER_DEFAULTS_SENSOR_SIMULATION_ENABLED_KEY];
  if (wasEnabled) {
    [self enable];
  }
#endif
}


- (BOOL) requiresMainQueueSetup {
  return YES;
}


- (NSDictionary *) constantsToExport
{
#ifdef SIMULATE_SENSORS
  BOOL isAvailable = YES;
#else
  BOOL isAvailable = NO;
#endif
  return @{ @"isAvailable": @(isAvailable) };
}


RCT_EXPORT_METHOD(isEnabled:(RCTPromiseResolveBlock)resolve reject:(RCTPromiseRejectBlock)reject) {
#ifdef SIMULATE_SENSORS
  resolve(@(isEnabled));
#else
  resolve(@(NO));
#endif
}


RCT_EXPORT_METHOD(enable:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject)
{
#ifdef SIMULATE_SENSORS
  [MyDriveTestHarness enable];
  resolve(@(YES));
#endif
}


RCT_EXPORT_METHOD(disable:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject)
{
#ifdef SIMULATE_SENSORS
  [MyDriveTestHarness disable];
  resolve(@(YES));
#endif
}


RCT_EXPORT_METHOD(injectSensorData:(NSDictionary *)data
                  resolve:(RCTPromiseResolveBlock)resolve
                  reject:(RCTPromiseRejectBlock)reject)
{
#ifdef SIMULATE_SENSORS
  [[CESimulatorEnhancements instance] receiveSimulatorData:data];
  resolve(@(YES));
#endif
}

@end
