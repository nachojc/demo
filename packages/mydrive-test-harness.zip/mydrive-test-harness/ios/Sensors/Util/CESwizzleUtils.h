//
//  SwizzleUtils.h
//  DayNineteen
//
//  Created by Colin Eberhardt on 18/02/2014.
//  Copyright (c) 2014 Chris Risner. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifdef SIMULATE_SENSORS

@interface CESwizzleUtils : NSObject

/**
 Swizzle the given method so that it is replaced with a method named 'override_methodName'.
 */
+ (void) swizzleClass:(Class)class method:(NSString*)methodName;

/**
 Swizzle the given class method so that it is replaced with a method named 'override_methodName'.
 */
+ (void) swizzleClass:(Class)class classMethod:(NSString*)methodName;

@end

#endif
