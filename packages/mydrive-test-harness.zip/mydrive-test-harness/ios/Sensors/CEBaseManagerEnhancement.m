//
//  CEManagerEnhancement.m
//  DayNineteen
//
//  Created by Colin Eberhardt on 23/02/2014.
//  Copyright (c) 2014 Chris Risner. All rights reserved.
//

#import "CEBaseManagerEnhancement.h"

#ifdef SIMULATE_SENSORS

@implementation CEBaseManagerEnhancement {
  NSPointerArray *_managers;
}

-(id) init {
  if ( self = [super init] ) {
    _managers = [NSPointerArray weakObjectsPointerArray];
  }
  return self;
}

- (NSArray *) getManagers {
  @synchronized (self) {
    // iterates over the managers - removing any 'nil' references
    NSMutableArray *managers = [NSMutableArray new];
    for (NSInteger i = _managers.count-1; i >= 0; i--) {
      id manager = [_managers pointerAtIndex:i];
      if (!manager) {
        [_managers removePointerAtIndex:i];
      } else {
        [managers insertObject:manager atIndex:0];
      }
    }
    return managers;
  }
}


- (void) addManager:(id)manager {
  @synchronized (self) {
    // check to see if we already have a reference
    for (NSInteger i = 0; i < _managers.count; i++) {
      id existingManager = [_managers pointerAtIndex:i];
      if (manager == existingManager)
        return;
    }
    
    // adds a weak reference to the manager
    [_managers addPointer:(__bridge void *)manager];
  }
}

@end

#endif
