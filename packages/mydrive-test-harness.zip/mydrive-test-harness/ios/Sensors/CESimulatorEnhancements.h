//
//  CESimulatorEnhancements.h
//  SimulatorEnhancements
//
//  Created by Colin Eberhardt on 16/02/2014.
//  Copyright (c) 2014 Colin Eberhardt. All rights reserved.
//

#import <Foundation/Foundation.h>

#ifdef SIMULATE_SENSORS

@interface CESimulatorEnhancements : NSObject

/**
 Enabled the simulator enhancements, allowing geolocation, accelerometer and other
 hardware-dependant services to be simulated.
 */
- (void) enable;

/**
 Receives simulator data in JSON format and updates the current geolocation accelerometer etc ...
 */
- (void) receiveSimulatorData:(NSDictionary *)data;

/**
 Retrieves the singleton instance of this class.
 */
+ (CESimulatorEnhancements *) instance;

@end

#endif
