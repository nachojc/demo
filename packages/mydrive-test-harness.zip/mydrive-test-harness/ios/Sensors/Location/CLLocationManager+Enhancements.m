//
//  CLLocationManager+Enhancements.m
//  SimulatorEnhancements
//
//  Created by Colin Eberhardt on 16/02/2014.
//  Copyright (c) 2014 Colin Eberhardt. All rights reserved.
//

#import <objc/runtime.h>
#import "CLLocationManager+Enhancements.h"
#import "CELocationEnhancements.h"

#define PROP_LAST_LOCATION @"avLastLocation"
#define PROP_LAST_HEADING @"avLastHeading"
#define PROP_GEOFENCE_REGIONS @"avGeofenceRegions"
#define PROP_LOCATION_HISTORY @"avLocationHistory"
#define PROP_LOCATION_UPDATE_STARTED @"avLocationUpdateStarted"
#define PROP_SIGIFICANT_LOCATION_CHANGE_STARTED @"avSignificantLocationChangeStarted"

#ifdef SIMULATE_SENSORS

@interface MyLocationEntry : NSObject

@property (nonatomic, retain) CLLocation * location;
@property (nonatomic, retain) NSDate * timestamp;
@property (nonatomic, assign) BOOL inside;

@end

@implementation MyLocationEntry
@end



typedef enum {
  RegionSideUndefined,
  RegionSideInside,
  RegionSideOutside
} RegionSide;

@interface MyLocationHistory : NSObject

@property (nonatomic, assign) BOOL wasInside;
@property (nonatomic, assign) BOOL wasOutside;
@property (nonatomic, retain) NSMutableArray * locations;

- (instancetype) initWithLocation:(CLLocation *)location region:(CLRegion *)region;
- (void) addLocation:(CLLocation *)location;
- (RegionSide) checkForRegion:(CLRegion *)region minDistance:(double)distance;

@end

@implementation MyLocationHistory

- (instancetype) init {
  self = [super init];
  if (self) {
    _locations = [[NSMutableArray alloc] init];
  }
  return self;
}

- (void) addLocation:(CLLocation *)location {
  MyLocationEntry * entry = [[MyLocationEntry alloc] init];
  entry.location = location;
  entry.timestamp = [NSDate date];
  [self.locations addObject:entry];
}

- (RegionSide) checkForRegion:(CLRegion *)region minDistance:(double)distance {

  CLCircularRegion * target = [[CLCircularRegion alloc] initWithCenter:region.center radius:region.radius + distance identifier:@""];

  BOOL allInside = YES;
  BOOL allOutside = YES;
  BOOL hasEnoughEntries = NO;
  NSInteger cutoff = NSNotFound;

  // there must be at least 20 seconds of data and all on the same side
  for (NSInteger i = self.locations.count - 1; i >= 0; i--) {
    MyLocationEntry * entry = [self.locations objectAtIndex:i];
    double secondsAgo = -[entry.timestamp timeIntervalSinceNow];
    if (secondsAgo >= 20) {
      hasEnoughEntries = YES;
    }
    if (secondsAgo <= 20) {
      BOOL inside = [target containsCoordinate:entry.location.coordinate];
      BOOL outside = !inside;
      allInside = allInside && inside;
      allOutside = allOutside && outside;
    } else {
      cutoff = i;
      break;
    }
  }

  if (cutoff != NSNotFound) {
    [self.locations removeObjectsInRange:NSMakeRange(0, cutoff + 1)];
  }

  if (allOutside) {
    return RegionSideOutside;
  } else if (allInside) {
    return RegionSideInside;
  }
  return RegionSideUndefined;
}

@end



@implementation CLLocationManager (Enhancements)

+ (BOOL) override_headingAvailable {
  return YES;
}

- (void) override_startUpdatingLocation {
  objc_setAssociatedObject(self, PROP_LOCATION_UPDATE_STARTED, @(YES), OBJC_ASSOCIATION_RETAIN);
  [self override_startUpdatingLocation];
}

- (void) override_stopUpdatingLocation {
  objc_setAssociatedObject(self, PROP_LOCATION_UPDATE_STARTED, @(NO), OBJC_ASSOCIATION_RETAIN);
  [self override_stopUpdatingLocation];
}

- (void) override_startMonitoringSignificantLocationChanges {
  objc_setAssociatedObject(self, PROP_SIGIFICANT_LOCATION_CHANGE_STARTED, @(YES), OBJC_ASSOCIATION_RETAIN);
  [self override_startMonitoringSignificantLocationChanges];
}

- (void) override_stopMonitoringSignificantLocationChanges {
  objc_setAssociatedObject(self, PROP_SIGIFICANT_LOCATION_CHANGE_STARTED, @(NO), OBJC_ASSOCIATION_RETAIN);
  [self override_stopMonitoringSignificantLocationChanges];
}

- (void) override_onClientEventLocation:(id)foo {
  // no-op - this suppresses location change events that are raised
  // by CLLocationManager
  NSLog(@">> onClientEventLocation %@", foo);
}

-(void) override_setDelegate:(id<CLLocationManagerDelegate>)delegate {
  if (![self simx_getLastLocation]) {
    NSDictionary * lastLocationDict = [[CELocationEnhancements instance] lastLocationDictionary];
    if (lastLocationDict) {
      CLLocation * lastLocation = [[CELocationEnhancements instance] locationFromDictionary:lastLocationDict];
      CLHeading * lastHeading = [[CELocationEnhancements instance] headingFromDictionary:lastLocationDict];
      objc_setAssociatedObject(self, PROP_LAST_LOCATION, lastLocation, OBJC_ASSOCIATION_RETAIN);
      objc_setAssociatedObject(self, PROP_LAST_HEADING, lastHeading, OBJC_ASSOCIATION_RETAIN);
    }
  }

  [[CELocationEnhancements instance] addManager:self];
  [self override_setDelegate:delegate];
}

- (CLLocation *) simx_getLastLocation {
  return objc_getAssociatedObject(self, PROP_LAST_LOCATION);
}

- (CLHeading *) simx_getLastHeading {
  return objc_getAssociatedObject(self, PROP_LAST_HEADING);
}

- (void) simx_didUpdateLocation:(CLLocation *)location heading:(CLHeading *)heading {
  CLLocation * lastLocation = [self simx_getLastLocation];
  objc_setAssociatedObject(self, PROP_LAST_LOCATION, location, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_LAST_HEADING, heading, OBJC_ASSOCIATION_RETAIN);
  id delegate = self.delegate;

  BOOL started = [objc_getAssociatedObject(self, PROP_LOCATION_UPDATE_STARTED) boolValue];
  BOOL monitorSigificantChange = [objc_getAssociatedObject(self, PROP_SIGIFICANT_LOCATION_CHANGE_STARTED) boolValue];
  BOOL isSignificant = NO;
  if (monitorSigificantChange) {
    if (!lastLocation) {
      isSignificant = YES;
    } else {
      if ([location distanceFromLocation:lastLocation] >= 400.0) {
        isSignificant = YES;
      }
    }
  }
  BOOL sendLocation = started || isSignificant;

  if (sendLocation && [delegate respondsToSelector:@selector(locationManager:didUpdateLocations:)]) {
    [delegate locationManager:self didUpdateLocations:location ? @[location] : @[]];
  }

  if (heading && [delegate respondsToSelector:@selector(locationManager:didUpdateHeading:)]) {
    [delegate locationManager:self didUpdateHeading:heading];
  }

  BOOL monitorEntry = [delegate respondsToSelector:@selector(locationManager:didEnterRegion:)];
  BOOL monitorExit = [delegate respondsToSelector:@selector(locationManager:didExitRegion:)];

  if (location && (monitorEntry || monitorExit)) {
    for (CLRegion * r in [[self simx_getGeofenceRegions] copy]) {

      // get location history
      MyLocationHistory * history = objc_getAssociatedObject(r, PROP_LOCATION_HISTORY);
      if (!history) {
        history = [[MyLocationHistory alloc] init];
        BOOL inside = [r containsCoordinate:location.coordinate];
        history.wasInside = inside;
        history.wasOutside = !inside;
        objc_setAssociatedObject(r, PROP_LOCATION_HISTORY, history, OBJC_ASSOCIATION_RETAIN);
      }

      // add to history
      [history addLocation:location];

      // check flip side
      RegionSide side = [history checkForRegion:r minDistance:5];
      if (side == RegionSideInside && history.wasOutside) {
        // entered region
        history.wasOutside = NO;
        history.wasInside = YES;
        if (monitorEntry && r.notifyOnEntry) {
          [delegate locationManager:self didEnterRegion:r];
        }
      } else if (side == RegionSideOutside && history.wasInside) {
        // exited region
        history.wasInside = NO;
        history.wasOutside = YES;
        if (monitorExit && r.notifyOnExit) {
          [delegate locationManager:self didExitRegion:r];
        }
      }
    }
  }
}

- (CLLocation *) override_location {
  return [self simx_getLastLocation];
}

- (CLHeading *) override_heading {
  return [self simx_getLastHeading];
}

- (NSSet *) override_monitoredRegions {
  return [NSSet setWithArray:[self simx_getGeofenceRegions]];
}

- (void) override_requestLocation {
  dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
    [self simx_didUpdateLocation:[self simx_getLastLocation] heading:[self simx_getLastHeading]];
  });
}

- (NSMutableArray *) simx_getGeofenceRegions {
  @synchronized (self) {
    NSMutableArray * regions = objc_getAssociatedObject(self, PROP_GEOFENCE_REGIONS);
    if (!regions) {
      regions = [NSMutableArray array];
      objc_setAssociatedObject(self, PROP_GEOFENCE_REGIONS, regions, OBJC_ASSOCIATION_RETAIN);
    }
    return regions;
  }
}

- (void) simx_addGeofenceRegion:(CLRegion *)region {
  @synchronized (self) {
    NSMutableArray * regions = [self simx_getGeofenceRegions];
    if (region) {
      // find existing region
      NSInteger idx = [regions indexOfObjectWithOptions:0 passingTest:^BOOL(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        CLRegion * testRegion = obj;
        BOOL matched = [testRegion.identifier isEqualToString:region.identifier];
        if (matched) {
          *stop = YES;
          return YES;
        }
        return NO;
      }];

      // replace or add region
      if (idx != NSNotFound) {
        [regions replaceObjectAtIndex:idx withObject:region];
      } else {
        [regions addObject:region];
      }
    }
  }
}

- (void) override_startMonitoringForRegion:(CLRegion *)region {
  [self simx_addGeofenceRegion:region];
}

- (void) override_stopMonitoringForRegion:(CLRegion *)region {
  @synchronized (self) {
    NSMutableArray * regions = [self simx_getGeofenceRegions];
    NSInteger idx = [regions indexOfObject:region];
    if (idx >= 0) {
      [regions removeObjectAtIndex:idx];
    }
  }
}

@end

#endif
