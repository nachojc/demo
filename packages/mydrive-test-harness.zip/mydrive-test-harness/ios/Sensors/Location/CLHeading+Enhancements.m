//
//  CLHeading+Enhancements.m
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 27/12/2023.
//

#import <objc/runtime.h>
#import "CLHeading+Enhancements.h"

#define PROP_HEADING @"avHeading"

#ifdef SIMULATE_SENSORS

@implementation MyMutableHeading
@end


@implementation CLHeading (Enhancements)

- (void) simx_setHeading:(MyMutableHeading *)heading; {
  objc_setAssociatedObject(self, PROP_HEADING, heading, OBJC_ASSOCIATION_RETAIN);
}

- (MyMutableHeading *) simx_getHeading {
  return objc_getAssociatedObject(self, PROP_HEADING);
}

- (CLLocationDirection) override_magneticHeading {
  return [self simx_getHeading].magneticHeading;
}

- (CLLocationDirection) override_trueHeading {
  return [self simx_getHeading].trueHeading;
}

- (CLLocationDirection) override_headingAccuracy {
  return [self simx_getHeading].headingAccuracy;
}

- (CLHeadingComponentValue) override_x {
  return [self simx_getHeading].x;
}

- (CLHeadingComponentValue) override_y {
  return [self simx_getHeading].y;
}

- (CLHeadingComponentValue) override_z {
  return [self simx_getHeading].z;
}

- (NSDate *) override_timestamp {
  return [self simx_getHeading].timestamp;
}

@end

#endif
