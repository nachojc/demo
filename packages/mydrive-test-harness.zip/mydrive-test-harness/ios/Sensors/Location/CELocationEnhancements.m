//
//  CELocationEnhancements.m
//  SimulatorEnhancements
//
//  Created by Colin Eberhardt on 16/02/2014.
//  Copyright (c) 2014 Colin Eberhardt. All rights reserved.
//

#import <objc/runtime.h>
#import <CoreLocation/CoreLocation.h>
#import "CELocationEnhancements.h"
#import "CLLocationManager+Enhancements.h"
#import "CLHeading+Enhancements.h"
#import "NSDictionary+Helpers.h"
#import "CESwizzleUtils.h"

#define NS_DEFAULT_KEY_LAST_LOCATION @"simulatedLastLocation"

#ifdef SIMULATE_SENSORS

@interface CELocationEnhancements ()
@end

@implementation CELocationEnhancements

- (void) enable {
  [CESwizzleUtils swizzleClass:[CLLocationManager class] classMethod:@"headingAvailable"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"startUpdatingLocation"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"stopUpdatingLocation"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"startMonitoringSignificantLocationChanges"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"stopMonitoringSignificantLocationChanges"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"setDelegate:"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"onClientEventLocation:"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"location"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"heading"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"monitoredRegions"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"requestLocation"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"startMonitoringForRegion:"];
  [CESwizzleUtils swizzleClass:[CLLocationManager class] method:@"stopMonitoringForRegion"];

  [CESwizzleUtils swizzleClass:[CLHeading class] method:@"magneticHeading"];
  [CESwizzleUtils swizzleClass:[CLHeading class] method:@"trueHeading"];
  [CESwizzleUtils swizzleClass:[CLHeading class] method:@"headingAccuracy"];
  [CESwizzleUtils swizzleClass:[CLHeading class] method:@"x"];
  [CESwizzleUtils swizzleClass:[CLHeading class] method:@"y"];
  [CESwizzleUtils swizzleClass:[CLHeading class] method:@"z"];
  [CESwizzleUtils swizzleClass:[CLHeading class] method:@"timestamp"];

  NSDictionary *locationData = [[NSUserDefaults standardUserDefaults] dictionaryForKey:NS_DEFAULT_KEY_LAST_LOCATION];
  if (locationData) {
    [self receiveSimulatorData:locationData];
  }
}

- (NSDictionary *) lastLocationDictionary {
  return [[NSUserDefaults standardUserDefaults] dictionaryForKey:NS_DEFAULT_KEY_LAST_LOCATION];
}

- (CLLocation *) locationFromDictionary:(NSDictionary *)dictionary {
  double lat = [[dictionary NSNumberForKey:@"latitude"] doubleValue];
  double lng = [[dictionary NSNumberForKey:@"longitude"] doubleValue];
  double alt = [[dictionary NSNumberForKey:@"altitude"] doubleValue];
  double speed = [[dictionary NSNumberForKey:@"speed"] doubleValue];
  double hAccuracy = [[dictionary NSNumberForKey:@"hAccuracy"] doubleValue];
  double vAccuracy = [[dictionary NSNumberForKey:@"vAccuracy"] doubleValue];
  double course = [[dictionary NSNumberForKey:@"course"] doubleValue];
  NSDate *timestamp = [NSDate dateWithTimeIntervalSince1970:[[dictionary NSNumberForKey:@"timestamp"] doubleValue]];
  CLLocationCoordinate2D coor = CLLocationCoordinate2DMake(lat, lng);

  return [[CLLocation alloc] initWithCoordinate:coor
                                       altitude:alt
                             horizontalAccuracy:hAccuracy
                               verticalAccuracy:vAccuracy
                                         course:course
                                          speed:speed
                                      timestamp:timestamp];
}

- (CLHeading *) headingFromDictionary:(NSDictionary *)dictionary {
  CLHeading *heading;
  if ([dictionary objectForKey:@"heading"]) {
    MyMutableHeading *h = [[MyMutableHeading alloc] init];
    h.magneticHeading = [[dictionary NSNumberForKey:@"magneticHeading"] doubleValue];
    h.trueHeading = [[dictionary NSNumberForKey:@"trueHeading"] doubleValue];
    h.headingAccuracy = [[dictionary NSNumberForKey:@"headingAccuracy"] doubleValue];
    h.x = [[dictionary NSNumberForKey:@"x"] doubleValue];
    h.y = [[dictionary NSNumberForKey:@"y"] doubleValue];
    h.z = [[dictionary NSNumberForKey:@"z"] doubleValue];
    h.timestamp = [NSDate dateWithTimeIntervalSince1970:[[dictionary NSNumberForKey:@"timestamp"] doubleValue]];
    heading = [[CLHeading alloc] init];
    [heading simx_setHeading:h];
  }
  return heading;
}

- (void) receiveSimulatorData:(NSDictionary *)locationData {
  [[NSUserDefaults standardUserDefaults] setObject:locationData forKey:NS_DEFAULT_KEY_LAST_LOCATION];

  CLLocation *location = [self locationFromDictionary:locationData];
  CLHeading *heading = [self headingFromDictionary:locationData];

  NSArray *managers = [self getManagers];
  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
    for (CLLocationManager *locationManager in managers) {
      [locationManager simx_didUpdateLocation:location heading:heading];
    }
  });
}


+ (CELocationEnhancements *) instance {
  static CELocationEnhancements *instance = nil;
  static dispatch_once_t onceToken;
  dispatch_once(&onceToken, ^{
    instance = [CELocationEnhancements new];
  });
  return instance;
}

@end

#endif
