//
//  CLHeading+Enhancements.h
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 27/12/2023.
//

#import <CoreLocation/CoreLocation.h>

#ifdef SIMULATE_SENSORS

@interface MyMutableHeading : NSObject

@property (nonatomic, assign) CLLocationDirection magneticHeading;
@property (nonatomic, assign) CLLocationDirection trueHeading;
@property (nonatomic, assign) CLLocationDirection headingAccuracy;
@property (nonatomic, assign) CLHeadingComponentValue x;
@property (nonatomic, assign) CLHeadingComponentValue y;
@property (nonatomic, assign) CLHeadingComponentValue z;
@property (nonatomic, strong) NSDate* timestamp;

@end


@interface CLHeading (Enhancements)

- (void) simx_setHeading:(MyMutableHeading *)heading;

@end

#endif
