//
//  CMDeviceMotion+Enhancements.h
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 21/12/2023.
//

#import <CoreMotion/CoreMotion.h>

#ifdef SIMULATE_SENSORS

@interface CMDeviceMotion (Enhancements)

- (void) simx_setAttitude:(CMAttitude *)attitude;
- (void) simx_setRotationRate:(CMRotationRate)rotationRate;
- (void) simx_setGravity:(CMAcceleration)gravity;
- (void) simx_setUserAcceleration:(CMAcceleration)userAcceleration;
- (void) simx_setMagneticField:(CMCalibratedMagneticField)magneticField;
- (void) simx_setHeading:(double)heading;
- (void) simx_setSensorLocation:(CMDeviceMotionSensorLocation)sensorLocation;

@end

#endif
