//
//  CMGyroData+Enhancements.h
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 21/12/2023.
//

#import <CoreMotion/CoreMotion.h>

#ifdef SIMULATE_SENSORS

/**
 A category on CMGyroData that modifies its behaviour via swizzled methods.
 */
@interface CMGyroData (Enhancements)

- (void) simx_setRotationRate:(CMRotationRate)rotationRate;

@end

#endif
