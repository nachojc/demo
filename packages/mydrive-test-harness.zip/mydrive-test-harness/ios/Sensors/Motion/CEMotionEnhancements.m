//
//  CEMotionEnhancements.m
//  Maze
//
//  Created by Colin Eberhardt on 18/02/2014.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import "CEMotionEnhancements.h"
#import "NSDictionary+Helpers.h"
#import "CESwizzleUtils.h"
#import "CMMotionManager+Enhancements.h"
#import "CMAccelerometerData+Enhancements.h"
#import "CMGyroData+Enhancements.h"
#import "CMMagnetometerData+Enhancements.h"
#import "CMDeviceMotion+Enhancements.h"

#define G 9.8

#ifdef SIMULATE_SENSORS

@implementation CEMotionEnhancements

- (void) receiveSimulatorData:(NSDictionary *)jsonData {
  if ([jsonData objectForKey:@"accelerometer"]) {
    NSDictionary *dict = jsonData[@"accelerometer"];

    CMAcceleration acc;
    acc.x = [[dict objectForKey:@"x"] doubleValue] / G;
    acc.y = [[dict objectForKey:@"y"] doubleValue] / G;
    acc.z = [[dict objectForKey:@"z"] doubleValue] / G;

    CMAccelerometerData *data = [[CMAccelerometerData alloc] init];
    [data simx_setAcceleration:acc];

    for (CMMotionManager *motionManager in [self getManagers]) {
      [motionManager simx_accelerometerUpdate:data];
    }
  }

  if ([jsonData objectForKey:@"gyro"]) {
    NSDictionary *dict = jsonData[@"gyro"];

    CMRotationRate rotation;
    rotation.x = [[dict objectForKey:@"x"] doubleValue];
    rotation.y = [[dict objectForKey:@"y"] doubleValue];
    rotation.z = [[dict objectForKey:@"z"] doubleValue];

    CMGyroData *data = [[CMGyroData alloc] init];
    [data simx_setRotationRate:rotation];

    for (CMMotionManager *motionManager in [self getManagers]) {
      [motionManager simx_gyroUpdate:data];
    }
  }

  if ([jsonData objectForKey:@"magnetometer"]) {
    NSDictionary *dict = jsonData[@"magnetometer"];

    CMMagneticField magneticField;
    magneticField.x = [[dict objectForKey:@"x"] doubleValue];
    magneticField.y = [[dict objectForKey:@"y"] doubleValue];
    magneticField.z = [[dict objectForKey:@"z"] doubleValue];

    CMMagnetometerData *data = [[CMMagnetometerData alloc] init];
    [data simx_setMagneticField:magneticField];

    for (CMMotionManager *motionManager in [self getManagers]) {
      [motionManager simx_magnetometerUpdate:data];
    }
  }

  if ([jsonData objectForKey:@"deviceMotion"]) {
    NSDictionary *dict = jsonData[@"deviceMotion"];

    CMAcceleration gravity;
    NSDictionary *gravityDict = [dict objectForKey:@"gravity"];
    gravity.x = [[gravityDict objectForKey:@"x"] doubleValue] / G;
    gravity.y = [[gravityDict objectForKey:@"y"] doubleValue] / G;
    gravity.z = [[gravityDict objectForKey:@"z"] doubleValue] / G;

    double heading = [[dict objectForKey:@"heading"] doubleValue];

    CMAttitude *attitude = [[CMAttitude alloc] init];
    // fill in the details if it's necessary

    CMRotationRate rotationRate;
    NSDictionary *rotationRateDict = [dict objectForKey:@"rotationRate"];
    rotationRate.x = [[rotationRateDict objectForKey:@"x"] doubleValue];
    rotationRate.y = [[rotationRateDict objectForKey:@"y"] doubleValue];
    rotationRate.z = [[rotationRateDict objectForKey:@"z"] doubleValue];

    CMCalibratedMagneticField magneticField;
    NSDictionary *magneticFieldDict = [dict objectForKey:@"magneticField"];
    magneticField.field.x = [[magneticFieldDict objectForKey:@"x"] doubleValue];
    magneticField.field.y = [[magneticFieldDict objectForKey:@"y"] doubleValue];
    magneticField.field.z = [[magneticFieldDict objectForKey:@"z"] doubleValue];
    magneticField.accuracy = [[magneticFieldDict objectForKey:@"accuracy"] doubleValue];

    CMDeviceMotionSensorLocation location = [[dict objectForKey:@"sensorLocation"] unsignedIntValue];

    CMAcceleration userAcceleration;
    NSDictionary *userAccelerationDict = [dict objectForKey:@"userAcceleration"];
    userAcceleration.x = [[userAccelerationDict objectForKey:@"x"] doubleValue] / G;
    userAcceleration.y = [[userAccelerationDict objectForKey:@"y"] doubleValue] / G;
    userAcceleration.z = [[userAccelerationDict objectForKey:@"z"] doubleValue] / G;

    CMDeviceMotion *data = [[CMDeviceMotion alloc] init];
    [data simx_setGravity:gravity];
    [data simx_setHeading:heading];
    [data simx_setAttitude:attitude];
    [data simx_setRotationRate:rotationRate];
    [data simx_setMagneticField:magneticField];
    [data simx_setSensorLocation:location];
    [data simx_setUserAcceleration:userAcceleration];

    for (CMMotionManager *motionManager in [self getManagers]) {
      [motionManager simx_deviceMotionUpdate:data];
    }
  }
}

- (void) enable {
  CMMotionManager *m = [[CMMotionManager alloc] init];

  // Accelerometer

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"isAccelerometerAvailable"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"startAccelerometerUpdatesToQueue:withHandler:"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"stopAccelerometerUpdates"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"accelerometerData"];

  [CESwizzleUtils swizzleClass:[CMAccelerometerData class]
                        method:@"acceleration"];

  // Gyroscope

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"isGyroAvailable"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"startGyroUpdatesToQueue:withHandler:"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"stopGyroUpdates"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"gyroData"];

  [CESwizzleUtils swizzleClass:[CMGyroData class]
                        method:@"rotationRate"];

  // Magnetometer

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"isMagnetometerAvailable"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"startMagnetometerUpdatesToQueue:withHandler:"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"stopMagnetometerUpdates"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"magnetometerData"];

  [CESwizzleUtils swizzleClass:[CMMagnetometerData class]
                        method:@"magneticField"];

  // Device Motion

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"isDeviceMotionAvailable"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"startDeviceMotionUpdatesUsingReferenceFrame:"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"startDeviceMotionUpdatesToQueue:withHandler:"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"startDeviceMotionUpdatesUsingReferenceFrame:toQueue:withHandler:"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"stopDeviceMotionUpdates"];

  [CESwizzleUtils swizzleClass:[CMMotionManager class]
                        method:@"deviceMotion"];

  [CESwizzleUtils swizzleClass:[CMDeviceMotion class]
                        method:@"attitude"];

  [CESwizzleUtils swizzleClass:[CMDeviceMotion class]
                        method:@"rotationRate"];

  [CESwizzleUtils swizzleClass:[CMDeviceMotion class]
                        method:@"gravity"];

  [CESwizzleUtils swizzleClass:[CMDeviceMotion class]
                        method:@"userAcceleration"];

  [CESwizzleUtils swizzleClass:[CMDeviceMotion class]
                        method:@"magneticField"];

  [CESwizzleUtils swizzleClass:[CMDeviceMotion class]
                        method:@"heading"];

  [CESwizzleUtils swizzleClass:[CMDeviceMotion class]
                        method:@"sensorLocation"];
}

+ (CEMotionEnhancements *) instance {
  static CEMotionEnhancements *instance = nil;
  static dispatch_once_t onceToken;
  dispatch_once(&onceToken, ^{
    instance = [CEMotionEnhancements new];
  });
  return instance;
}

@end

#endif
