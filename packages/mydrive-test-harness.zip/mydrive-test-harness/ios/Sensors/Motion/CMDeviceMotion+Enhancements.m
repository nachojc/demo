//
//  CMDeviceMotion+Enhancements.m
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 21/12/2023.
//

#import <objc/runtime.h>
#import "CMDeviceMotion+Enhancements.h"

#define PROP_ATTITUDE @"avAttitude"
#define PROP_ROTATION_RATE @"avRotationRate"
#define PROP_GRAVITY @"avGravity"
#define PROP_USER_ACCELERATION @"avUserAcceleration"
#define PROP_MAGNETIC_FIELD @"avMagneticField"
#define PROP_HEADING @"avHeading"
#define PROP_SENSOR_LOCATION @"avSensorLocation"

#ifdef SIMULATE_SENSORS

@implementation CMDeviceMotion (Enhancements)

- (void) simx_setAttitude:(CMAttitude *)attitude; {
  objc_setAssociatedObject(self, PROP_ATTITUDE, attitude, OBJC_ASSOCIATION_RETAIN);
}

- (CMAttitude *) override_attitude {
  return objc_getAssociatedObject(self, PROP_ATTITUDE);
}

- (void) simx_setRotationRate:(CMRotationRate)rotationRate; {
  NSValue *value = [NSValue value:&rotationRate withObjCType:@encode(CMRotationRate)];
  objc_setAssociatedObject(self, PROP_ROTATION_RATE, value, OBJC_ASSOCIATION_RETAIN);
}

- (CMRotationRate) override_rotationRate {
  NSValue *value = objc_getAssociatedObject(self, PROP_ROTATION_RATE);
  CMRotationRate rotationRate;
  [value getValue:&rotationRate];
  return rotationRate;
}

- (void) simx_setGravity:(CMAcceleration)gravity; {
  NSValue *value = [NSValue value:&gravity withObjCType:@encode(CMAcceleration)];
  objc_setAssociatedObject(self, PROP_GRAVITY, value, OBJC_ASSOCIATION_RETAIN);
}

- (CMAcceleration) override_gravity {
  NSValue *value = objc_getAssociatedObject(self, PROP_GRAVITY);
  CMAcceleration gravity;
  [value getValue:&gravity];
  return gravity;
}

- (void) simx_setUserAcceleration:(CMAcceleration)userAcceleration; {
  NSValue *value = [NSValue value:&userAcceleration withObjCType:@encode(CMAcceleration)];
  objc_setAssociatedObject(self, PROP_USER_ACCELERATION, value, OBJC_ASSOCIATION_RETAIN);
}

- (CMAcceleration) override_userAcceleration {
  NSValue *value = objc_getAssociatedObject(self, PROP_USER_ACCELERATION);
  CMAcceleration userAcceleration;
  [value getValue:&userAcceleration];
  return userAcceleration;
}

- (void) simx_setMagneticField:(CMCalibratedMagneticField)magneticField; {
  NSValue *value = [NSValue value:&magneticField withObjCType:@encode(CMCalibratedMagneticField)];
  objc_setAssociatedObject(self, PROP_MAGNETIC_FIELD, value, OBJC_ASSOCIATION_RETAIN);
}

- (CMCalibratedMagneticField) override_magneticField {
  NSValue *value = objc_getAssociatedObject(self, PROP_MAGNETIC_FIELD);
  CMCalibratedMagneticField magneticField;
  [value getValue:&magneticField];
  return magneticField;
}

- (void) simx_setHeading:(double)heading; {
  objc_setAssociatedObject(self, PROP_HEADING, @(heading), OBJC_ASSOCIATION_RETAIN);
}

- (double) override_heading {
  NSNumber *value = objc_getAssociatedObject(self, PROP_HEADING);
  return [value doubleValue];
}

- (void) simx_setSensorLocation:(CMDeviceMotionSensorLocation)sensorLocation; {
  NSValue *value = [NSValue value:&sensorLocation withObjCType:@encode(CMDeviceMotionSensorLocation)];
  objc_setAssociatedObject(self, PROP_SENSOR_LOCATION, value, OBJC_ASSOCIATION_RETAIN);
}

- (CMDeviceMotionSensorLocation) override_sensorLocation {
  NSValue *value = objc_getAssociatedObject(self, PROP_SENSOR_LOCATION);
  CMDeviceMotionSensorLocation sensorLocation;
  [value getValue:&sensorLocation];
  return sensorLocation;
}

@end

#endif
