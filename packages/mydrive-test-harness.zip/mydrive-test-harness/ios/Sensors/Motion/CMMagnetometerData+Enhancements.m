//
//  CMMagnetometerData+Enhancements.m
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 21/12/2023.
//

#import <objc/runtime.h>
#import "CMMagnetometerData+Enhancements.h"

#define PROP_MAGNETIC_FIELD @"avMagneticField"

#ifdef SIMULATE_SENSORS

@implementation CMMagnetometerData (Enhancements)

- (void) simx_setMagneticField:(CMMagneticField)magneticField; {
  NSValue *value = [NSValue value:&magneticField withObjCType:@encode(CMMagneticField)];
  objc_setAssociatedObject(self, PROP_MAGNETIC_FIELD, value, OBJC_ASSOCIATION_RETAIN);
}

- (CMMagneticField) override_magneticField {
  NSValue *value = objc_getAssociatedObject(self, PROP_MAGNETIC_FIELD);
  CMMagneticField magneticField;
  [value getValue:&magneticField];
  return magneticField;
}

@end

#endif
