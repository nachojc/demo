//
//  CMMagnetometerData+Enhancements.h
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 21/12/2023.
//

#import <CoreMotion/CoreMotion.h>

#ifdef SIMULATE_SENSORS

/**
 A category on CMMagnetometerData that modifies its behaviour via swizzled methods.
 */
@interface CMMagnetometerData (Enhancements)

- (void) simx_setMagneticField:(CMMagneticField)magneticField;

@end

#endif
