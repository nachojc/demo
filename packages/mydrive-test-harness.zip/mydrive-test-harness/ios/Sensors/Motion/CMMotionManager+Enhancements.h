//
//  CMMotionManager+Enhancements.h
//  Maze
//
//  Created by Colin Eberhardt on 18/02/2014.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import <CoreMotion/CoreMotion.h>

#ifdef SIMULATE_SENSORS

/**
 A category on CMMotionManager that modifies its behaviour via swizzled methods.
 */
@interface CMMotionManager (Enhancements)

/**
 Updates the current accelerometer reading.
 */
- (void) simx_accelerometerUpdate:(CMAccelerometerData *)accelerometerData;

/**
 Updates the current gyroscope reading.
 */
- (void) simx_gyroUpdate:(CMGyroData *)gyroData;

/**
 Updates the current magnetometer reading.
 */
- (void) simx_magnetometerUpdate:(CMMagnetometerData *)magnetometerData;

/**
 Updates the current device motion reading.
 */
- (void) simx_deviceMotionUpdate:(CMDeviceMotion *)deviceMotionData;

@end

#endif
