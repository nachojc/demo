//
//  CMGyroData+Enhancements.m
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 21/12/2023.
//

#import <objc/runtime.h>
#import "CMGyroData+Enhancements.h"

#define PROP_ROTATION_RATE @"avRotationRate"

#ifdef SIMULATE_SENSORS

@implementation CMGyroData (Enhancements)

- (void) simx_setRotationRate:(CMRotationRate)rotationRate {
  NSValue *value = [NSValue value:&rotationRate withObjCType:@encode(CMRotationRate)];
  objc_setAssociatedObject(self, PROP_ROTATION_RATE, value, OBJC_ASSOCIATION_RETAIN);
}

- (CMRotationRate) override_rotationRate {
  NSValue *value = objc_getAssociatedObject(self, PROP_ROTATION_RATE);
  CMRotationRate rotationRate;
  [value getValue:&rotationRate];
  return rotationRate;
}

@end

#endif
