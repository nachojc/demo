//
//  CMMotionManager+Enhancements.m
//  Maze
//
//  Created by Colin Eberhardt on 18/02/2014.
//  Copyright (c) 2014 Appcoda. All rights reserved.
//

#import "CMMotionManager+Enhancements.h"
#import "CEMotionEnhancements.h"
#import <objc/runtime.h>

#define PROP_ACCELEROMETER_HANDLER @"avAccelerometerHandler"
#define PROP_ACCELEROMETER_QUEUE @"avAccelerometerQueue"
#define PROP_ACCELEROMETER_DATA @"avAccelerometerData"
#define PROP_GYRO_HANDLER @"avGyroHandler"
#define PROP_GYRO_QUEUE @"avGyroQueue"
#define PROP_GYRO_DATA @"avGyroData"
#define PROP_MAGNETOMETER_HANDLER @"avMagnetometerHandler"
#define PROP_MAGNETOMETER_QUEUE @"avMagnetometerQueue"
#define PROP_MAGNETOMETER_DATA @"avMagnetometerData"
#define PROP_DEVICE_MOTION_HANDLER @"avDeviceMotionHandler"
#define PROP_DEVICE_MOTION_QUEUE @"avDeviceMotionQueue"
#define PROP_DEVICE_MOTION_REFERENCE_FRAME @"avDeviceMotionReferenceFrame"
#define PROP_DEVICE_MOTION_DATA @"avDeviceMotionData"

#ifdef SIMULATE_SENSORS

@implementation CMMotionManager (Enhancements)


#pragma mark - Determining the Availability of Services

- (BOOL) override_isAccelerometerAvailable {
  return YES;
}

- (BOOL) override_isGyroAvailable {
  return YES;
}

- (BOOL) override_isMagnetometerAvailable {
  return YES;
}

- (BOOL) override_isDeviceMotionAvailable {
  return YES;
}


#pragma mark - Triggering Device Motion Updates

- (void) simx_accelerometerUpdate:(CMAccelerometerData *)accelerometerData {
  objc_setAssociatedObject(self, PROP_ACCELEROMETER_DATA, accelerometerData, OBJC_ASSOCIATION_RETAIN);
  NSOperationQueue* queue = objc_getAssociatedObject(self, PROP_ACCELEROMETER_QUEUE);
  CMAccelerometerHandler handler = objc_getAssociatedObject(self, PROP_ACCELEROMETER_HANDLER);
  if (queue && handler) {
    [queue addOperationWithBlock:^{
      handler(accelerometerData, nil);
    }];
  }
}

- (void) simx_gyroUpdate:(CMGyroData *)gyroData {
  objc_setAssociatedObject(self, PROP_GYRO_DATA, gyroData, OBJC_ASSOCIATION_RETAIN);
  NSOperationQueue* queue = objc_getAssociatedObject(self, PROP_GYRO_QUEUE);
  CMGyroHandler handler = objc_getAssociatedObject(self, PROP_GYRO_HANDLER);
  if (queue && handler) {
    [queue addOperationWithBlock:^{
      handler(gyroData, nil);
    }];
  }
}

- (void) simx_magnetometerUpdate:(CMMagnetometerData *)magnetometerData {
  objc_setAssociatedObject(self, PROP_MAGNETOMETER_DATA, magnetometerData, OBJC_ASSOCIATION_RETAIN);
  NSOperationQueue* queue = objc_getAssociatedObject(self, PROP_MAGNETOMETER_QUEUE);
  CMMagnetometerHandler handler = objc_getAssociatedObject(self, PROP_MAGNETOMETER_HANDLER);
  if (queue && handler) {
    [queue addOperationWithBlock:^{
      handler(magnetometerData, nil);
    }];
  }
}

- (void) simx_deviceMotionUpdate:(CMDeviceMotion *)deviceMotionData {
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_DATA, deviceMotionData, OBJC_ASSOCIATION_RETAIN);
  CMDeviceMotionHandler handler = objc_getAssociatedObject(self, PROP_DEVICE_MOTION_HANDLER);
  NSOperationQueue *queue = objc_getAssociatedObject(self, PROP_DEVICE_MOTION_QUEUE);
  NSNumber *refFrame = objc_getAssociatedObject(self, PROP_DEVICE_MOTION_REFERENCE_FRAME);
  if (queue && handler) {
    [queue addOperationWithBlock:^{
      handler(deviceMotionData, nil);
    }];
  }
}


#pragma mark - Managing Accelerometer Updates

- (void) override_startAccelerometerUpdatesToQueue:(NSOperationQueue *)queue
                                     withHandler:(CMAccelerometerHandler)handler {
  objc_setAssociatedObject(self, PROP_ACCELEROMETER_QUEUE, queue, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_ACCELEROMETER_HANDLER, handler, OBJC_ASSOCIATION_RETAIN);
  [[CEMotionEnhancements instance] addManager:self];
}

- (void) override_stopAccelerometerUpdates {
  objc_setAssociatedObject(self, PROP_ACCELEROMETER_QUEUE, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_ACCELEROMETER_HANDLER, nil, OBJC_ASSOCIATION_RETAIN);
}

- (CMAccelerometerData *) override_accelerometerData {
  return objc_getAssociatedObject(self, PROP_ACCELEROMETER_DATA);
}


#pragma mark - Managing Gyroscope Updates

- (void) override_startGyroUpdatesToQueue:(NSOperationQueue *)queue withHandler:(CMGyroHandler)handler {
  objc_setAssociatedObject(self, PROP_GYRO_QUEUE, queue, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_GYRO_HANDLER, handler, OBJC_ASSOCIATION_RETAIN);
  [[CEMotionEnhancements instance] addManager:self];
}

- (void) override_stopGyroUpdates {
  objc_setAssociatedObject(self, PROP_GYRO_QUEUE, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_GYRO_HANDLER, nil, OBJC_ASSOCIATION_RETAIN);
}

- (CMGyroData *) override_gyroData {
  return objc_getAssociatedObject(self, PROP_GYRO_DATA);
}


#pragma mark - Managing Magnetometer Updates

- (void) override_startMagnetometerUpdatesToQueue:(NSOperationQueue *)queue withHandler:(CMMagnetometerHandler)handler {
  objc_setAssociatedObject(self, PROP_MAGNETOMETER_QUEUE, queue, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_MAGNETOMETER_HANDLER, handler, OBJC_ASSOCIATION_RETAIN);
  [[CEMotionEnhancements instance] addManager:self];
}

- (void) override_stopMagnetometerUpdates {
  objc_setAssociatedObject(self, PROP_MAGNETOMETER_QUEUE, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_MAGNETOMETER_HANDLER, nil, OBJC_ASSOCIATION_RETAIN);
}

- (CMMagnetometerData *) override_magnetometerData {
  return objc_getAssociatedObject(self, PROP_MAGNETOMETER_DATA);
}


#pragma mark - Managing Device Motion Updates

- (void) override_startDeviceMotionUpdatesUsingReferenceFrame:(CMAttitudeReferenceFrame)referenceFrame {
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_HANDLER, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_REFERENCE_FRAME, @(referenceFrame), OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_QUEUE, nil, OBJC_ASSOCIATION_RETAIN);
}

- (void) override_stopDeviceMotionUpdates {
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_HANDLER, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_REFERENCE_FRAME, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_QUEUE, nil, OBJC_ASSOCIATION_RETAIN);
}

- (void) override_startDeviceMotionUpdatesToQueue:(NSOperationQueue *)queue withHandler:(CMDeviceMotionHandler)handler {
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_HANDLER, handler, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_REFERENCE_FRAME, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_QUEUE, nil, OBJC_ASSOCIATION_RETAIN);
  [[CEMotionEnhancements instance] addManager:self];
}

- (void) override_startDeviceMotionUpdatesUsingReferenceFrame:(CMAttitudeReferenceFrame)referenceFrame toQueue:(NSOperationQueue *)queue withHandler:(CMDeviceMotionHandler)handler {
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_HANDLER, handler, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_REFERENCE_FRAME, @(referenceFrame), OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_DEVICE_MOTION_QUEUE, queue, OBJC_ASSOCIATION_RETAIN);
  [[CEMotionEnhancements instance] addManager:self];
}

- (CMDeviceMotion *) override_deviceMotion {
  return objc_getAssociatedObject(self, PROP_DEVICE_MOTION_DATA);
}

@end

#endif
