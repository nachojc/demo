//
//  AviMotionActivityEnhancements.h
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 29/12/2023.
//

#import <Foundation/Foundation.h>
#import "CEBaseManagerEnhancement.h"

#ifdef SIMULATE_SENSORS

@interface AviMotionActivityEnhancements : CEBaseManagerEnhancement

+ (AviMotionActivityEnhancements *) instance;
- (void) enable;
- (void) receiveSimulatorData:(NSDictionary *)data;

@end

#endif
