//
//  AviMotionActivityEnhancements.m
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 29/12/2023.
//

#import "AviMotionActivityEnhancements.h"
#import "CMMotionActivity+Enhancements.h"
#import "CMMotionActivityManager+Enhancements.h"
#import "NSDictionary+Helpers.h"
#import "CESwizzleUtils.h"

#ifdef SIMULATE_SENSORS

@implementation AviMotionActivityEnhancements

+ (AviMotionActivityEnhancements *) instance; {
  static AviMotionActivityEnhancements *instance = nil;
  static dispatch_once_t onceToken;
  dispatch_once(&onceToken, ^{
    instance = [AviMotionActivityEnhancements new];
  });
  return instance;
}

- (void) enable {
  [CESwizzleUtils swizzleClass:[CMMotionActivityManager class] classMethod:@"isActivityAvailable"];
  [CESwizzleUtils swizzleClass:[CMMotionActivityManager class] method:@"queryActivityStartingFromDate:toDate:toQueue:withHandler:"];
  [CESwizzleUtils swizzleClass:[CMMotionActivityManager class] method:@"startActivityUpdatesToQueue:withHandler:"];
  [CESwizzleUtils swizzleClass:[CMMotionActivityManager class] method:@"stopActivityUpdates"];

  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"timestamp"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"confidence"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"startDate"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"unknown"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"stationary"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"walking"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"running"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"automotive"];
  [CESwizzleUtils swizzleClass:[CMMotionActivity class] method:@"cycling"];
}

- (void) receiveSimulatorData:(NSDictionary *)data; {
  MyMutableMotionActivity *act = [[MyMutableMotionActivity alloc] init];
  act.timestamp = [[NSProcessInfo processInfo] systemUptime];
  act.confidence = [[data objectForKey:@"confidence"] integerValue];
  act.startDate = [NSDate dateWithTimeIntervalSince1970:[[data NSNumberForKey:@"startDate"] doubleValue]];
  act.unknown = [[data objectForKey:@"unknown"] boolValue];
  act.stationary = [[data objectForKey:@"stationary"] boolValue];
  act.walking = [[data objectForKey:@"walking"] boolValue];
  act.running = [[data objectForKey:@"running"] boolValue];
  act.automotive = [[data objectForKey:@"automotive"] boolValue];
  act.cycling = [[data objectForKey:@"cycling"] boolValue];

  CMMotionActivity *activity = [[CMMotionActivity alloc] init];
  [activity simx_setActivity:act];

  NSArray *managers = [self getManagers];
  for (CMMotionActivityManager *manager in managers) {
    [manager simx_didUpdateActivity:activity];
  }
}

@end

#endif
