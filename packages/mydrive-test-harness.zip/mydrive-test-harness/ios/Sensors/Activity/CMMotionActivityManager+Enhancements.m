//
//  CMMotionActivityManager+Enhancements.m
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 29/12/2023.
//

#import <objc/runtime.h>
#import "CMMotionActivityManager+Enhancements.h"
#import "AviMotionActivityEnhancements.h"

#define PROP_ACTIVITY_HISTORY @"avActivityHistory"
#define PROP_QUEUE @"avQueue"
#define PROP_HANDLER @"avHandler"

#ifdef SIMULATE_SENSORS

@implementation CMMotionActivityManager (Enhancements)

+ (BOOL) override_isActivityAvailable; {
  return YES;
}

- (NSMutableArray *) simx_getActivityHistory {
  @synchronized (self) {
    NSMutableArray* history = objc_getAssociatedObject(self, PROP_ACTIVITY_HISTORY);
    if (!history) {
      history = [[NSMutableArray alloc] init];
      objc_setAssociatedObject(self, PROP_ACTIVITY_HISTORY, history, OBJC_ASSOCIATION_RETAIN);
    }
    return history;
  }
}

- (void) simx_addActivity:(CMMotionActivity *)activity; {
  if (activity) {
    @synchronized (self) {
      [[self simx_getActivityHistory] addObject:activity];
    }
  }
}

- (void) simx_didUpdateActivity:(CMMotionActivity *)activity; {
  [self simx_addActivity:activity];

  NSOperationQueue* queue = objc_getAssociatedObject(self, PROP_QUEUE);
  CMMotionActivityHandler handler = objc_getAssociatedObject(self, PROP_HANDLER);
  if (queue && handler) {
    [queue addOperationWithBlock:^{
      handler(activity);
    }];
  }
}

- (void) override_queryActivityStartingFromDate:(NSDate *)start
                                         toDate:(NSDate *)end
                                        toQueue:(NSOperationQueue *)queue
                                    withHandler:(CMMotionActivityQueryHandler)handler; {
  // call the original method to trigger the permission dialog
  [self override_queryActivityStartingFromDate:start toDate:end toQueue:queue withHandler:^(NSArray<CMMotionActivity *> * _Nullable activities, NSError * _Nullable error) {
    // no-op
  }];
  
  NSArray* history = [[self simx_getActivityHistory] copy];
  NSMutableArray* ret = [[NSMutableArray alloc] init];
  for (CMMotionActivity* entry in history) {
    BOOL afterStart = !start || ([entry.startDate compare:start] != NSOrderedAscending);
    BOOL beforeEnd = !end || ([entry.startDate compare:end] != NSOrderedDescending);
    if (afterStart && beforeEnd) {
      [ret addObject:entry];
    }
  }
  [queue addOperationWithBlock:^{
    handler(ret, nil);
  }];
}

- (void) override_startActivityUpdatesToQueue:(NSOperationQueue *)queue
                        withHandler:(CMMotionActivityHandler)handler; {
  objc_setAssociatedObject(self, PROP_QUEUE, queue, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_HANDLER, handler, OBJC_ASSOCIATION_RETAIN);
  [[AviMotionActivityEnhancements instance] addManager:self];
}

- (void) override_stopActivityUpdates; {
  objc_setAssociatedObject(self, PROP_QUEUE, nil, OBJC_ASSOCIATION_RETAIN);
  objc_setAssociatedObject(self, PROP_HANDLER, nil, OBJC_ASSOCIATION_RETAIN);
}

@end

#endif
