//
//  CMMotionActivity+Enhancements.m
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 29/12/2023.
//

#import <objc/runtime.h>
#import "CMMotionActivity+Enhancements.h"

#define PROP_ACTIVITY @"avActivity"

#ifdef SIMULATE_SENSORS

@implementation MyMutableMotionActivity
@end


@implementation CMMotionActivity (Enhancements)


- (void) simx_setActivity:(MyMutableMotionActivity *)activity; {
  objc_setAssociatedObject(self, PROP_ACTIVITY, activity, OBJC_ASSOCIATION_RETAIN);
}

- (MyMutableMotionActivity *) simx_getActivity {
  return objc_getAssociatedObject(self, PROP_ACTIVITY);
}

- (NSTimeInterval) override_timestamp {
  return [self simx_getActivity].timestamp;
}

- (CMMotionActivityConfidence) override_confidence {
  return [self simx_getActivity].confidence;
}

- (NSDate *) override_startDate {
  return [self simx_getActivity].startDate;
}

- (BOOL) override_unknown {
  return [self simx_getActivity].unknown;
}

- (BOOL) override_stationary {
  return [self simx_getActivity].stationary;
}

- (BOOL) override_walking {
  return [self simx_getActivity].walking;
}

- (BOOL) override_running {
  return [self simx_getActivity].running;
}

- (BOOL) override_automotive {
  return [self simx_getActivity].automotive;
}

- (BOOL) override_cycling {
  return [self simx_getActivity].cycling;
}

@end

#endif
