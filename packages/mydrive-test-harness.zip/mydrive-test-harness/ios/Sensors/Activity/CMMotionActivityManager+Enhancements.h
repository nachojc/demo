//
//  CMMotionActivityManager+Enhancements.h
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 29/12/2023.
//

#import <CoreMotion/CoreMotion.h>

#ifdef SIMULATE_SENSORS

@interface CMMotionActivityManager (Enhancements)

- (void) simx_didUpdateActivity:(CMMotionActivity *)activity;

@end

#endif
