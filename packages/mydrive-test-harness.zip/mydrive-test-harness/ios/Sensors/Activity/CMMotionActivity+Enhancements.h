//
//  CMMotionActivity+Enhancements.h
//  MyDriveTestHarness
//
//  Created by Kwok Cheung Poon on 29/12/2023.
//

#import <CoreMotion/CoreMotion.h>

#ifdef SIMULATE_SENSORS

@interface MyMutableMotionActivity : NSObject

@property (nonatomic, assign) NSTimeInterval timestamp;
@property (nonatomic, assign) BOOL stationary;
@property (nonatomic, assign) BOOL walking;
@property (nonatomic, assign) BOOL running;
@property (nonatomic, assign) BOOL automotive;
@property (nonatomic, assign) BOOL cycling;
@property (nonatomic, assign) BOOL unknown;
@property (nonatomic, strong) NSDate *startDate;
@property (nonatomic, assign) CMMotionActivityConfidence confidence;

@end



@interface CMMotionActivity (Enhancements)

- (void) simx_setActivity:(MyMutableMotionActivity *)activity;

@end

#endif
