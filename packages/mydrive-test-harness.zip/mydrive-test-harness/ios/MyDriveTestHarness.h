
#ifdef RCT_NEW_ARCH_ENABLED
#import "RNMyDriveTestHarnessSpec.h"

@interface MyDriveTestHarness : NSObject <NativeMyDriveTestHarnessSpec>
#else
#import <React/RCTBridgeModule.h>

@interface MyDriveTestHarness : NSObject <RCTBridgeModule>
#endif

+ (void) setup;

@end
