# mydrive-test-harness

Sensor Simulator

## Installation

```sh
npm install mydrive-test-harness
```

## Usage

```js
import { enable } from 'mydrive-test-harness';

// ...

await enable;
```

## Contributing

See the [contributing guide](CONTRIBUTING.md) to learn how to contribute to the repository and the development workflow.

## License

UNLICENSE

---

Made with [create-react-native-library](https://github.com/callstack/react-native-builder-bob)
