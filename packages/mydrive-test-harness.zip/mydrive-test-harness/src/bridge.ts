import { NativeModules, Platform } from 'react-native';
import type { SensorData } from './types';

const LINKING_ERROR =
  `The package 'mydrive-test-harness' doesn't seem to be linked. Make sure: \n\n` +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo Go\n';

const MyDriveTestHarness = NativeModules.MyDriveTestHarness
  ? NativeModules.MyDriveTestHarness
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

const { isAvailable } = MyDriveTestHarness.getConstants();

export { isAvailable };

export function enable(): Promise<boolean> {
  return MyDriveTestHarness.enable();
}

export function disable(): Promise<boolean> {
  return MyDriveTestHarness.disable();
}

export function isEnabled(): Promise<boolean> {
  return MyDriveTestHarness.isEnabled();
}

export function injectSensorData(data: SensorData): Promise<boolean> {
  return MyDriveTestHarness.injectSensorData(data);
}
