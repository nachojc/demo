import { observable } from '@legendapp/state';
import { injectSensorData } from './bridge';
import type { SensorData } from './types';
import sleep from './utils/sleep';

export const replayStarted = observable(false);
export const lastPayload = observable<SensorData | null>(null);

export const replayTrip = async (series: SensorData[], referenceTime: Date | null = null, replaySpeed = 1.0) => {
  replayStarted.set(true);
  lastPayload.set(null);

  let idx;
  for (idx = 0; idx < series.length; idx++) {
    const data = series[idx];
    if (!data) {
      break;
    }

    const payload = {...data};
    const tsBase = series[0]?.ts ?? 0;
    const ts0 = (idx > 0 ? series[idx - 1]?.ts ?? 0 : payload.ts) - tsBase;
    const ts1 = payload.ts - tsBase;
    const delay = (ts1 - ts0 || 0) / replaySpeed;
    if (isNaN(delay)) {
      throw new Error(`Invalid delay value: ${delay}`);
    }

    await sleep(delay);
    if (!replayStarted.get()) {
      break;
    }
    const timestamp = (referenceTime ? (referenceTime.getTime() + ts1) : Date.now()) / 1000;

    // set dates/timestamps to reference time + offset
    if (payload.location) {
      payload.location = {
        ...payload.location,
        timestamp,
        heading: {
          ...payload.location.heading,
          timestamp
        }
      }
    }
    if (payload.activity) {
      payload.activity = {
        ...payload.activity,
        startDate: timestamp,
      }
    }

    console.log('Injecting sensor data', JSON.stringify(payload, (key: string, value: any) => {
      if (key === 'timestamp' || key === 'startDate') {
        const dt = new Date(value * 1000);
        return dt.toISOString().replace('T', ' ');
      }
      return value;
    }, 2));
    lastPayload.set(payload);
    injectSensorData(payload);
  }

  replayStarted.set(false);
  console.log('Ended replaying trip data');
};

export const stopReplayingTrip = () => {
  replayStarted.set(false);
};
