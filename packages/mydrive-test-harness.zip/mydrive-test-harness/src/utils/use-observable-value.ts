import { type Observable } from '@legendapp/state';
import { useEffect, useState } from 'react';

export function useObservableValue<T>(o: Observable<T>) {
  // From the documentation of @legendapp/state@1.2.6 we should be able to do something like
  //   observable$.use()
  // but in reality such method does not exist.
  // So we need to implement our own.

  const [value, setValue] = useState<T>(o.get());

  useEffect(() => {
    return o.onChange(({ value: newValue }) => {
      setValue(newValue);
    });
  }, [o]);

  return value;
}
