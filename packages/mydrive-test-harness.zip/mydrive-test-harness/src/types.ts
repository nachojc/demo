export type SensorData = {
  ts: number;
  location?: {
    latitude: number;
    longitude: number;
    altitude: number;
    speed: number;
    hAccuracy: number;
    vAccuracy: number;
    course: number;
    timestamp?: number;
    heading: {
      magneticHeading: number;
      trueHeading: number;
      headingAccuracy: number;
      x: number;
      y: number;
      z: number;
      timestamp?: number;
    };
  };
  motion?: {
    accelerometer: {
      x: number;
      y: number;
      z: number;
    };
    gyro: {
      x: number;
      y: number;
      z: number;
    };
    magnetometer: {
      x: number;
      y: number;
      z: number;
    };
    deviceMotion: {
      gravity: {
        x: number;
        y: number;
        z: number;
      };
      userAcceleration: {
        x: number;
        y: number;
        z: number;
      };
    };
  };
  activity?: {
    confidence: number;
    startDate?: number;
    stationary?: boolean;
    walking?: boolean;
    running?: boolean;
    automotive?: boolean;
    cycling?: boolean;
    unknown?: boolean;
  };
};
