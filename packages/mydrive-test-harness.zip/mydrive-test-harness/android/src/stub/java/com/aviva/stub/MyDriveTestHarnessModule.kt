package com.aviva.mydrivetestharness

import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.Promise

class MyDriveTestHarnessModule(reactContext: ReactApplicationContext) :
  ReactContextBaseJavaModule(reactContext) {

  override fun getName(): String {
    return NAME
  }

  override fun getConstants(): MutableMap<String, Any> =
    hashMapOf("isAvailable" to false)

  @ReactMethod
  fun enable(promise: Promise) {
    promise.resolve(false)
  }

  @ReactMethod
  fun isEnabled(promise: Promise) {
    promise.resolve(false)
  }

  @ReactMethod
  fun injectSensorData(data: ReadableMap, promise: Promise) {
    promise.resolve(false)
  }

  companion object {
    const val NAME = "MyDriveTestHarness"
  }
}
