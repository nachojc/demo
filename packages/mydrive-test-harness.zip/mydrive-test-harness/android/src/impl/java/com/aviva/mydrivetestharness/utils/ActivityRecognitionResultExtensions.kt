package com.aviva.mydrivetestharness.utils

import com.google.android.gms.location.ActivityRecognitionResult
import com.google.android.gms.location.ActivityTransition
import com.google.android.gms.location.ActivityTransitionEvent
import com.google.android.gms.location.ActivityTransitionResult
import millisToNano

fun ActivityRecognitionResult.transitionFrom(
  from: ActivityRecognitionResult?
): ActivityTransitionResult? {
  if (from?.mostProbableActivity?.type == this.mostProbableActivity.type) {
    return null
  }

  val time = millisToNano(this.elapsedRealtimeMillis)
  val events = ArrayList<ActivityTransitionEvent>()

  if (from != null) {
    events.add(
      ActivityTransitionEvent(
        from.mostProbableActivity.type,
        ActivityTransition.ACTIVITY_TRANSITION_EXIT,
        time
      )
    )
  }
  events.add(
    ActivityTransitionEvent(
      this.mostProbableActivity.type,
      ActivityTransition.ACTIVITY_TRANSITION_ENTER,
      time
    )
  )
  return ActivityTransitionResult(events)
}
