package com.aviva.mydrivetestharness.utils

import android.os.Parcel
import com.google.android.gms.location.ActivityTransitionResult

fun ActivityTransitionResult.toByteArray(): ByteArray {
  val parcel = Parcel.obtain()
  try {
    this.writeToParcel(parcel, 0)
    return parcel.marshall()
  } finally {
    parcel.recycle()
  }
}
