package com.aviva.mydrivetestharness.sensors

import android.content.Context
import android.content.Intent
import android.util.Log
import com.aviva.mydrivetestharness.MyDriveTestHarnessModule.Companion.NAME
import com.aviva.mydrivetestharness.utils.toActivityRecognitionResult
import com.aviva.mydrivetestharness.utils.toByteArray
import com.aviva.mydrivetestharness.utils.transitionFrom
import com.facebook.react.bridge.ReadableMap
import com.google.android.gms.location.ActivityRecognitionResult
import com.google.android.gms.location.ActivityTransitionResult

class ActivityRecognitionSimulator(private val context: Context) {
  private var previousResult: ActivityRecognitionResult? = null
  private var enabled: Boolean = false

  fun enable() {
    enabled = true
  }

  fun disable() {
    enabled = false
  }

  fun injectActivityRecognition(map: ReadableMap) {
    if (!enabled) {
      return
    }

    val result = map.toActivityRecognitionResult()
    val transition = result.transitionFrom(previousResult)
    previousResult = result

    // from com.intellimec.mobile.android.tripdetection.StartActivityDetector.start
    sendResults(
      "com.drivesync.android.ACTION_ACTIVITY_UPDATE",
      null,
      result,
      null
    )

    // from com.intellimec.mobile.android.tripdetection.ActivityMonitor.start
    sendResults(
      "ims.sdk.ACTION_ACTIVITY",
      "com.intellimec.mobile.android.tripdetection.ActivityBroadcastReceiver",
      result,
      transition
    )

    // from com.intellimec.mobile.android.tripdetection.ActivityMonitor.start
    sendResults(
      "c.i.gta.ActivityMonitor",
      "com.drivesync.android.provider.mobile.AbstractProviderRequest\$requestUpdates\$1",
      result,
      transition
    )

    // from com.intellimec.mobile.android.tripdetection.ActivityTransitionDetector.start
    sendResults(
      "c.i.gta.ActivityProvider",
      "com.drivesync.android.provider.mobile.AbstractProviderRequest\$requestUpdates\$1",
      result,
      transition
    )
  }

  private fun sendBroadcast(
    action: String,
    receiverClassName: String?,
    intentCustomiser: (intent: Intent) -> Unit
  ) {
    try {
      val intent: Intent
      if (receiverClassName != null) {
        val receiverClass = Class.forName(receiverClassName)
        intent = Intent(context, receiverClass)
        intent.action = action
      } else {
        intent = Intent(action)
      }
      intentCustomiser(intent)
      context.sendOrderedBroadcast(intent, null)
    } catch (e: ClassNotFoundException) {
      Log.w(NAME, "IMS activity receiver class not found: $receiverClassName")
    }
  }

  private fun sendRecognitionResult(
    action: String,
    receiverClassName: String?,
    result: ActivityRecognitionResult
  ) {
    sendBroadcast(
      action,
      receiverClassName
    ) { it.putExtra("com.google.android.location.internal.EXTRA_ACTIVITY_RESULT", result) }
  }

  private fun sendTransitionResult(
    action: String,
    receiverClassName: String?,
    result: ActivityTransitionResult?
  ) {
    if (result != null) {
      sendBroadcast(
        action,
        receiverClassName
      ) {
        it.putExtra(
          "com.google.android.location.internal.EXTRA_ACTIVITY_TRANSITION_RESULT",
          result.toByteArray()
        )
      }
    }
  }

  private fun sendResults(
    action: String,
    receiverClassName: String?,
    recognition: ActivityRecognitionResult?,
    transition: ActivityTransitionResult?
  ) {
    if (transition != null) {
      sendTransitionResult(action, receiverClassName, transition)
    }
    if (recognition != null) {
      sendRecognitionResult(action, receiverClassName, recognition)
    }
  }
}
