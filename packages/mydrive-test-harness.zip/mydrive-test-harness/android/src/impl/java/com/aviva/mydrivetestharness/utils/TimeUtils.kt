import android.os.SystemClock
import java.util.concurrent.TimeUnit

fun timeToElapsedRealtimeNanos(timeInMillis: Long): Long {
  return SystemClock.elapsedRealtimeNanos() + TimeUnit.MILLISECONDS.toNanos(timeInMillis - System.currentTimeMillis())
}

fun timeToElapsedRealtimeMillis(timeInMillis: Long): Long {
  return SystemClock.elapsedRealtime() + timeInMillis - System.currentTimeMillis()
}

fun millisToNano(timeInMillis: Long): Long {
  return TimeUnit.MILLISECONDS.toNanos(timeInMillis)
}
