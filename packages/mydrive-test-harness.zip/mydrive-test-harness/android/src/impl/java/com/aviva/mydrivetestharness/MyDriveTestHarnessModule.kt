package com.aviva.mydrivetestharness

import android.content.Context
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.facebook.react.bridge.ReadableMap
import com.facebook.react.bridge.Promise
import com.aviva.mydrivetestharness.utils.getMapValue
import com.aviva.mydrivetestharness.sensors.ActivityRecognitionSimulator
import com.aviva.mydrivetestharness.sensors.LocationSimulator

class MyDriveTestHarnessModule(private val context: ReactApplicationContext) :
  ReactContextBaseJavaModule(context) {

  private val locationSimulator: LocationSimulator = LocationSimulator(context)
  private val activityRecognitionSimulator: ActivityRecognitionSimulator = ActivityRecognitionSimulator(context)
  private var enabled: Boolean = false

  init {
    val pref = context.getSharedPreferences(NAME, Context.MODE_PRIVATE)
    if (pref.getBoolean("enabled", false)) {
      // restore state
      enable()
    }
  }

  override fun getName(): String {
    return NAME
  }

  override fun getConstants(): MutableMap<String, Any> =
    hashMapOf("isAvailable" to true)

  fun hasDeclaredPermissions(): Boolean {
    return try {
      android.Manifest.permission::class.java.getField("ACCESS_MOCK_LOCATION")
      true
    } catch (ignored: NoSuchFieldException) {
      false
    }
  }

  fun enable(): Boolean {
    if (enabled) {
      return true
    }
    if (!hasDeclaredPermissions()) {
      return false
    }

    return try {
      locationSimulator.enable()
      activityRecognitionSimulator.enable()
      enabled = true
      context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply()
      true
    } catch (e: Exception) {
      false
    }
  }

  fun disable(): Boolean {
    return try {
      locationSimulator.disable()
      activityRecognitionSimulator.disable()
      enabled = false
      context.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled).apply()
      true
    } catch (e: Exception) {
      false
    }
  }

  @ReactMethod
  fun enable(promise: Promise) {
    promise.resolve(enable())
  }

  @ReactMethod
  fun disable(promise: Promise) {
    promise.resolve(disable())
  }

  @ReactMethod
  fun isEnabled(promise: Promise) {
    promise.resolve(enabled)
  }

  @ReactMethod
  fun injectSensorData(data: ReadableMap, promise: Promise) {
    if (!enabled) {
      promise.resolve(false)
      return
    }

    val loc = data.getMapValue("location")
    if (loc != null) {
      locationSimulator.injectLocation(loc)
    }
    val act = data.getMapValue("activity")
    if (act != null) {
      activityRecognitionSimulator.injectActivityRecognition(act)
    }
    promise.resolve(true)
  }

  companion object {
    const val NAME = "MyDriveTestHarness"
  }
}
