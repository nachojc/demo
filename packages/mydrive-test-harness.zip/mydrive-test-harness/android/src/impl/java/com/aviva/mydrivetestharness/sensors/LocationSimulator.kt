package com.aviva.mydrivetestharness.sensors

import android.content.Context
import android.location.LocationManager
import android.location.provider.ProviderProperties
import com.aviva.mydrivetestharness.utils.toLocation
import com.facebook.react.bridge.ReadableMap

const val mockLocationProviderName = LocationManager.GPS_PROVIDER

class LocationSimulator(private val context: Context) {
  var locationManager: LocationManager? = null
  var enabled: Boolean = false

  fun enable() {
    if (enabled) {
      return
    }
    if (locationManager == null) {
      locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    }
    locationManager?.addTestProvider(mockLocationProviderName, false, false, false, false, true, true, true, ProviderProperties.POWER_USAGE_MEDIUM, ProviderProperties.ACCURACY_FINE)
    locationManager?.setTestProviderEnabled(mockLocationProviderName, true)
    enabled = true
  }

  fun disable() {
    locationManager?.removeTestProvider(mockLocationProviderName)
    enabled = false
  }

  fun injectLocation(map: ReadableMap) {
    locationManager?.setTestProviderLocation(mockLocationProviderName, map.toLocation())
  }
}
