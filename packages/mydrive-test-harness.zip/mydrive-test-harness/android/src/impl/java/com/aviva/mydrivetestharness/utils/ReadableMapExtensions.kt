package com.aviva.mydrivetestharness.utils

import android.annotation.SuppressLint
import android.location.Location
import android.location.LocationManager
import com.facebook.react.bridge.ReadableMap
import com.google.android.gms.location.ActivityRecognitionResult
import com.google.android.gms.location.DetectedActivity
import timeToElapsedRealtimeMillis
import timeToElapsedRealtimeNanos

fun ReadableMap.getIntValue(key: String): Int? {
  return if (this.hasKey(key) && !this.isNull(key)) {
    this.getInt(key)
  } else {
    null
  }
}

fun ReadableMap.getFloatValue(key: String): Float? {
  return if (this.hasKey(key) && !this.isNull(key)) {
    this.getDouble(key).toFloat()
  } else {
    null
  }
}

fun ReadableMap.getDoubleValue(key: String): Double? {
  return if (this.hasKey(key) && !this.isNull(key)) {
    this.getDouble(key)
  } else {
    null
  }
}

fun ReadableMap.getBoolValue(key: String, defaultValue: Boolean = false): Boolean {
  return if (this.hasKey(key) && !this.isNull(key)) {
    this.getBoolean(key) ?: defaultValue
  } else {
    defaultValue
  }
}

fun ReadableMap.getTimestampMillis(key: String): Long? {
  return if (this.hasKey(key) && !this.isNull(key)) {
    (this.getDouble(key) * 1000).toLong()
  } else {
    null
  }
}

fun ReadableMap.getMapValue(key: String): ReadableMap? {
  return if (this.hasKey(key) && !this.isNull(key)) {
    this.getMap(key)
  } else {
    null
  }
}

fun ReadableMap.toLocation(): Location {
  val loc = Location(LocationManager.GPS_PROVIDER)
  loc.latitude = this.getDoubleValue("latitude") ?: .0
  loc.longitude = this.getDoubleValue("longitude") ?: .0
  loc.altitude = this.getDoubleValue("altitude") ?: .0
  loc.speed = this.getFloatValue("speed") ?: .0f
  loc.accuracy = this.getFloatValue("hAccuracy") ?: .0f
  loc.verticalAccuracyMeters = this.getFloatValue("vAccuracy") ?: .0f
  loc.bearing = this.getFloatValue("course") ?: .0f
  loc.time = this.getTimestampMillis("timestamp") ?: System.currentTimeMillis()
  loc.elapsedRealtimeNanos = timeToElapsedRealtimeNanos(loc.time)
  return loc
}

@SuppressLint("VisibleForTests")
fun ReadableMap.toActivityRecognitionResult(): ActivityRecognitionResult {
  val confidence = when (this.getIntValue("confidence")) {
    2 -> 100
    1 -> 60
    0 -> 20
    else -> 0
  }

  val type = when {
    this.getBoolValue("stationary") -> DetectedActivity.STILL
    this.getBoolValue("walking") -> DetectedActivity.WALKING
    this.getBoolValue("running") -> DetectedActivity.RUNNING
    this.getBoolValue("automotive") -> DetectedActivity.IN_VEHICLE
    this.getBoolValue("cycling") -> DetectedActivity.ON_BICYCLE
    this.getBoolValue("unknown") -> DetectedActivity.UNKNOWN
    else -> DetectedActivity.UNKNOWN
  }

  val time = this.getTimestampMillis("startDate") ?: System.currentTimeMillis()

  val act = DetectedActivity(type, confidence)

  return ActivityRecognitionResult(act, time, timeToElapsedRealtimeMillis(time))
}
