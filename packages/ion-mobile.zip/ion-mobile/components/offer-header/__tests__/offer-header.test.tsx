import { render, screen } from '@src/jest/testing-library';

import { OfferHeader } from '../offer-header';

describe('OfferHeader', () => {
  it('should render with primary icon, title and subtitle', () => {
    render(
      <OfferHeader
        image={0}
        icon="home"
        iconVariant="primary"
        title="Home Insurance"
        subtitle="Home insurance from £160"
      />
    );
    const offerHeader = screen.getByTestId('offer-header');
    expect(offerHeader).toBeOnTheScreen();

    const iconContainer = screen.getByTestId('icon-container');
    expect(iconContainer).toHaveStyle({
      backgroundColor: '#FFD900',
    });

    const image = screen.getByTestId('test:id/icon-home', {
      includeHiddenElements: true,
    });
    expect(image).toBeOnTheScreen();

    const textElements = screen.getAllByRole('text');
    expect(textElements.length).toBe(2);
  });

  it('should render with directWealth icon styling when iconVariant prop is set to directWealth', () => {
    render(
      <OfferHeader
        image={0}
        iconVariant="directWealth"
        icon="home"
        title="Home Insurance"
        subtitle="Home insurance from £160"
      />
    );

    const iconContainer = screen.getByTestId('icon-container');
    expect(iconContainer).toHaveStyle({
      backgroundColor: '#122D44',
    });
  });

  it('should render without subtitle', () => {
    render(
      <OfferHeader
        image={0}
        iconVariant="primary"
        icon="home"
        title="Home Insurance"
      />
    );
    const textElements = screen.getAllByRole('text');
    expect(textElements.length).toBe(1);
  });
});
