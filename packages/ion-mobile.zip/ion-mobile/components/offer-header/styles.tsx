import { styled, YStack } from 'tamagui';

export const OfferHeaderIconContainer = styled(YStack, {
  width: '$8',
  height: '$8',
  borderRadius: 50,
  marginTop: '$-xxl',
  alignItems: 'center',
  justifyContent: 'center',
  variants: {
    iconVariant: {
      primary: { backgroundColor: '$Primary500' },
      directWealth: { backgroundColor: '$Secondary800' },
    },
  } as const,
});
