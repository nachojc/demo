import { tokens } from '@src/theme/tokens';
import { isIpad } from '@src/utils/is-ipad';
import { FastImageProps } from 'react-native-fast-image';
import { YStack } from 'tamagui';

import { Icon, IconName } from '../icon';
import { Image } from '../image';
import { Text } from '../text';
import { OfferHeaderIconContainer } from './styles';

export type OfferHeaderProps = {
  icon?: IconName;
  iconVariant: 'primary' | 'directWealth';
  image: FastImageProps['source'];
  subtitle?: string;
  title: string;
};

export const OfferHeader = ({
  icon,
  iconVariant = 'primary',
  image,
  subtitle,
  title,
}: OfferHeaderProps) => {
  const iconColor =
    iconVariant === 'directWealth'
      ? tokens.color.White.val
      : tokens.color.Secondary800.val;

  return (
    <YStack testID="offer-header" alignItems="center">
      <Image
        accessibilityIgnoresInvertColors
        accessibilityLabel="Offer Header Image"
        style={{
          width: '100%',
          aspectRatio: isIpad ? '2.5/1' : undefined,
          height: isIpad ? undefined : tokens.size[15].val,
        }}
        resizeMode="cover"
        source={image}
      />
      <OfferHeaderIconContainer
        iconVariant={iconVariant}
        testID="icon-container"
      >
        {icon && <Icon name={icon} color={iconColor} />}
      </OfferHeaderIconContainer>
      <Text
        fontVariant="heading3-semibold-Secondary800"
        tamaguiTextProps={{
          marginHorizontal: '$xxxl',
          marginTop: '$xl',
          textAlign: 'center',
        }}
      >
        {title}
      </Text>
      {subtitle && (
        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{
            marginHorizontal: '$xxxl',
            marginTop: '$sm',
            textAlign: 'center',
          }}
        >
          {subtitle}
        </Text>
      )}
    </YStack>
  );
};
