import { styled, YStack } from 'tamagui';

const Container = styled(YStack, {
  name: 'Header Container',
  justifyContent: 'center',
  padding: '$xl',
  minHeight: 78,
  backgroundColor: '$Primary500',

  variants: {
    variant: {
      directWealth: {
        backgroundColor: '$DWPrimary500',
      },
      white: {
        backgroundColor: '$White',
      },
      tertiary800: {
        backgroundColor: '$Tertiary800',
      },
    },
  } as const,
});

export { Container };
