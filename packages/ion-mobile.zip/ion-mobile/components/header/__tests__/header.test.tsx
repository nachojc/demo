import { render, screen } from '@src/jest/testing-library';

import { Header } from '../header';

describe('HeaderComponent', () => {
  it.each`
    variant           | headerTextColor | backgroundColor
    ${'primary'}      | ${'#141D31'}    | ${'#FFD900'}
    ${'directWealth'} | ${'#FFFFFF'}    | ${'#141D31'}
    ${'white'}        | ${'#122D44'}    | ${'#FFFFFF'}
  `(
    'should display correct colors for $variant',
    ({ variant, headerTextColor, backgroundColor }) => {
      render(<Header testID="headerTest" copy="test copy" variant={variant} />);

      expect(screen.getByText('test copy', { hidden: true })).toHaveStyle({
        color: headerTextColor,
      });
      expect(screen.getByTestId('headerTest')).toHaveStyle({ backgroundColor });
    }
  );
});
