import { tokens } from '@theme/tokens';
import { ReactNode } from 'react';

import { Text } from '../text';
import { Container } from './header.styles';

type Color = keyof typeof tokens.color;

type FontColors = {
  primary: Color;
  directWealth: Color;
  white: Color;
  tertiary800: Color;
};

const fontColors: FontColors = {
  primary: 'DWPrimary500',
  directWealth: 'White',
  white: 'Secondary800',
  tertiary800: 'White',
};

export type Variant = 'directWealth' | 'white' | 'tertiary800';

export const Header = ({
  copy,
  variant,
  testID,
}: {
  copy: string;
  variant?: Variant;
  testID?: string;
}) => {
  const color = fontColors[variant || 'primary'];
  return (
    <Container testID={testID} variant={variant}>
      <Text fontVariant={`heading5-regular-${color}`}>{copy}</Text>
    </Container>
  );
};

export const ExtendableHeader = ({
  variant = 'directWealth',
  children,
  testID,
}: {
  variant?: Variant;
  testID?: string;
  children: ReactNode;
}) => {
  return (
    <Container testID={testID} variant={variant}>
      {children}
    </Container>
  );
};
