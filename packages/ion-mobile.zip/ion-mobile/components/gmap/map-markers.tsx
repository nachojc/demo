import { MyDriveEvent } from '@src/validation/schemas/mydrive';
import { Marker } from 'react-native-maps';

import { Icon, IconName } from '../icon';
import { MapMarkerLabel } from './map-marker-label';

export type MapMarkersProps = {
  events?: MyDriveEvent[];
  markerPinInfo: {
    title: string;
    iconName: IconName;
    labelIconName: IconName;
  };
  onPress: (args: { latitude: number; longitude: number }) => void;
};

export const MapMarkers = ({
  events,
  markerPinInfo,
  onPress,
}: MapMarkersProps) => {
  const { title, iconName, labelIconName } = markerPinInfo;

  return (
    <>
      {events?.map(({ date, latitude, longitude }) => {
        const description = new Date(date).toTimeString().slice(0, 5);
        return (
          <Marker
            key={date.toString()}
            coordinate={{ latitude, longitude }}
            onPress={() => onPress({ latitude, longitude })}
            anchor={{ x: 0.5, y: 0.88 }}
            calloutAnchor={{ x: 0.5, y: 0.25 }}
            tracksViewChanges={false}
          >
            <Icon name={iconName} width={49} height={45} />
            <MapMarkerLabel
              icon={labelIconName}
              label={title}
              time={description}
            />
          </Marker>
        );
      })}
    </>
  );
};
