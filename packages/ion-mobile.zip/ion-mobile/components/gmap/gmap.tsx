import { useSnapPoints } from '@src/features/mydrive/mydrive-map-overlay-sheet/hooks/use-snappoints';
import { Journey, MyDriveEvent } from '@src/validation/schemas/mydrive';
import { useMemo, useRef, useState } from 'react';
import { DimensionValue, SafeAreaView } from 'react-native';
import MapView, {
  Marker,
  Polyline,
  PROVIDER_GOOGLE,
  Region,
} from 'react-native-maps';

import { Icon, IconName } from '../icon';
import { MapMarkerLabel } from './map-marker-label';
import { MapMarkers, MapMarkersProps } from './map-markers';

type MapProps = {
  journey: Journey;
  handleMarkerPressed: () => void;
};
export const MyDriveTripMap = ({ journey, handleMarkerPressed }: MapProps) => {
  const { geometry, events, startDate, endDate } = journey;
  const tripStartDate = new Date(startDate).toTimeString().slice(0, 5);
  const tripEndDate = new Date(endDate).toTimeString().slice(0, 5);

  const { latitude: startLatitude, longitude: startLongitude } = geometry[0];
  const { latitude: endLatitude, longitude: endLongitude } =
    geometry[geometry.length - 1];
  const { acceleration, braking, cornering, distractedDriving, speeding } =
    events;

  const mapReference = useRef<MapView>(null);
  const [currentLatitudeDelta, setCurrentLatitudeDelta] = useState(0);
  const [currentLongitudeDelta, setCurrentLongitudeDelta] = useState(0);
  const { snapPoints } = useSnapPoints();

  const mapMarkersDetails: {
    markerEvents?: MyDriveEvent[];
    markerPinInfo: {
      title: string;
      iconName: IconName;
      labelIconName: IconName;
    };
  }[] = [
    {
      markerEvents: acceleration,
      markerPinInfo: {
        title: 'Harsh acceleration',
        iconName: 'acceleration-pin',
        labelIconName: 'acceleration',
      },
    },
    {
      markerEvents: braking,
      markerPinInfo: {
        title: 'Harsh braking',
        iconName: 'braking-pin',
        labelIconName: 'braking',
      },
    },
    {
      markerEvents: cornering,
      markerPinInfo: {
        title: 'Harsh cornering',
        iconName: 'cornering-pin',
        labelIconName: 'cornering',
      },
    },
    {
      markerEvents: distractedDriving,
      markerPinInfo: {
        title: 'Phone distraction',
        iconName: 'phone-distraction-pin',
        labelIconName: 'phone-distraction',
      },
    },
    {
      markerEvents: speeding,
      markerPinInfo: {
        title: 'Speeding',
        iconName: 'speeding-pin',
        labelIconName: 'speed',
      },
    },
  ];

  const initialRegionCords = useMemo(() => {
    const bounds = geometry.reduce(
      (acc, coords) => ({
        minLat: Math.min(acc.minLat, coords.latitude),
        maxLat: Math.max(acc.maxLat, coords.latitude),
        minLong: Math.min(acc.minLong, coords.longitude),
        maxLong: Math.max(acc.maxLong, coords.longitude),
      }),
      {
        minLat: Infinity,
        maxLat: -Infinity,
        minLong: Infinity,
        maxLong: -Infinity,
      }
    );

    const { maxLat, maxLong, minLat, minLong } = bounds;

    const latitudeDelta = maxLat - minLat + 0.04; // add y padding
    const longitudeDelta = maxLong - minLong + 0.04; // add x padding

    setCurrentLatitudeDelta(latitudeDelta);
    setCurrentLongitudeDelta(longitudeDelta);

    return {
      latitude: (minLat + maxLat) / 2, // get mid point
      longitude: (minLong + maxLong) / 2, // get mid point
      latitudeDelta,
      longitudeDelta,
    };
  }, [geometry]);

  const anchor = { x: 0.5, y: 0.5 };
  const calloutAnchor = { x: 0.5, y: 0.4 };

  const onRegionChangeComplete = (region: Region) => {
    setCurrentLatitudeDelta(region.latitudeDelta);
    setCurrentLongitudeDelta(region.longitudeDelta);
  };

  const handleCenter = (latitude: number, longitude: number) => {
    mapReference?.current?.animateToRegion({
      latitude,
      longitude,
      latitudeDelta: currentLatitudeDelta,
      longitudeDelta: currentLongitudeDelta,
    });
  };

  const onEventPressed: MapMarkersProps['onPress'] = ({
    latitude,
    longitude,
  }) => {
    handleMarkerPressed();
    handleCenter(latitude, longitude);
  };

  const calculateMapHeight = (): DimensionValue => {
    const sheetCollapsedHeightPercentage = snapPoints[1];
    const totalScreenPercentage = 100;
    const overlapAllowancePercentage = 5;

    const mapHeightPercentage =
      totalScreenPercentage -
      sheetCollapsedHeightPercentage +
      overlapAllowancePercentage;

    return `${mapHeightPercentage}%`;
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <MapView
        toolbarEnabled={false}
        onRegionChangeComplete={onRegionChangeComplete}
        ref={mapReference}
        provider={PROVIDER_GOOGLE}
        style={{
          width: '100%',
          height: calculateMapHeight(),
        }}
        initialRegion={initialRegionCords}
        accessibilityElementsHidden
        importantForAccessibility={'no-hide-descendants'}
      >
        <Polyline coordinates={geometry} strokeColor={'#000'} strokeWidth={3} />
        {mapMarkersDetails.map(({ markerEvents, markerPinInfo }) => (
          <MapMarkers
            key={markerPinInfo.title}
            events={markerEvents}
            markerPinInfo={markerPinInfo}
            onPress={onEventPressed}
          />
        ))}
        <Marker
          coordinate={{
            latitude: startLatitude,
            longitude: startLongitude,
          }}
          onPress={() =>
            onEventPressed({
              latitude: startLatitude,
              longitude: startLongitude,
            })
          }
          anchor={anchor}
          calloutAnchor={calloutAnchor}
        >
          <Icon name="trip-start-circle" width={10} height={10} />
          <MapMarkerLabel label="Journey start" time={tripStartDate} />
        </Marker>
        <Marker
          coordinate={{
            latitude: endLatitude,
            longitude: endLongitude,
          }}
          onPress={() =>
            onEventPressed({
              latitude: endLatitude,
              longitude: endLongitude,
            })
          }
          anchor={anchor}
          calloutAnchor={calloutAnchor}
        >
          <Icon name="trip-end-circle" width={10} height={10} />
          <MapMarkerLabel label="Journey end" time={tripEndDate} />
        </Marker>
      </MapView>
    </SafeAreaView>
  );
};
