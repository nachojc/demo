import { tokens } from '@src/theme/tokens';
import { Callout } from 'react-native-maps';
import { XStack, YStack } from 'tamagui';

import { Icon, IconName } from '../icon';
import { Text } from '../text';

type MapMarkerLabelProps = {
  label: string;
  time: string;
  icon?: IconName;
};

export const MapMarkerLabel = ({ icon, label, time }: MapMarkerLabelProps) => {
  return (
    <Callout>
      <XStack
        f={1}
        width={icon ? '$14' : '$13'}
        backgroundColor="$White"
        alignItems="center"
        margin="$md"
      >
        {icon && (
          <YStack marginRight="$xl" marginTop="$-xxl">
            <Icon
              name={icon}
              width={tokens.size[5].val}
              height={tokens.size[5].val}
            />
          </YStack>
        )}
        <YStack>
          <Text fontVariant="body-semibold-Secondary800">{label}</Text>
          <Text fontVariant="body-regular-Gray800">{time}</Text>
        </YStack>
      </XStack>
    </Callout>
  );
};
