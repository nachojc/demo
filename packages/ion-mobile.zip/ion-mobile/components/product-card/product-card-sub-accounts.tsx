import { getTestId } from '@src/utils/get-test-id';
import { Fragment } from 'react';
import { Pressable } from 'react-native';
import { getTokens, Separator, Stack } from 'tamagui';

import { Icon, IconName } from '../icon';
import { Text } from '../text';

export type ProductCardSubAccountsProps = {
  subAccounts?: {
    title: string;
    value: string;
    icon: IconName;
    onSubAccountPress: () => void;
  }[];
};

export const ProductCardSubAccounts = ({
  subAccounts,
}: ProductCardSubAccountsProps) => {
  const tokens = getTokens();

  if (!subAccounts?.length) {
    return null;
  }

  return (
    <Stack px="$xl">
      <Text
        fontVariant="small-semibold-Gray800"
        tamaguiTextProps={{ pb: '$xl' }}
      >
        Your account is made up of:
      </Text>

      {subAccounts?.map(({ title, onSubAccountPress, value, icon }, index) => (
        <Fragment key={`${title}-${index}`}>
          <Separator />
          <Pressable
            testID={getTestId(`platform-action-item-${index}`)}
            accessibilityRole="link"
            onPress={onSubAccountPress}
            style={{
              flexDirection: 'row',
              paddingVertical: tokens.space.md.val,
            }}
          >
            <Text
              fontVariant="body-regular-Gray800"
              tamaguiTextProps={{
                flex: 1,
                testID: getTestId(`platform-action-item-${index}-title`),
              }}
            >
              {title}
            </Text>
            <Text
              fontVariant="body-semibold-Secondary800"
              tamaguiTextProps={{ px: '$xl' }}
            >
              {value}
            </Text>
            <Stack testID={getTestId(`card-icon-${icon ?? 'chevron-right'}`)}>
              <Icon color={tokens.color.Gray400.val} name={icon} />
            </Stack>
          </Pressable>
        </Fragment>
      ))}
    </Stack>
  );
};
