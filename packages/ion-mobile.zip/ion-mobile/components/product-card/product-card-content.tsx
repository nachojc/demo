import { getTestId } from '@src/utils/get-test-id';
import { getTokens, Stack, XStack, YStack } from 'tamagui';

import { CardGenericContentProps } from '../cards';
import { AlertChip, AlertChipProps } from '../chip/alert-chips';
import { DataItem, DataItemProps } from '../data-item/data-item';
import { Icon, IconName } from '../icon';
import { Text } from '../text';

export type ProductCardContentProps = {
  leftIconName?: IconName | null;
  leftCircleColor?: string;
  rightIconName?: IconName | null;
  heading?: string | null;
  subheading?: string | null;
  dataItemsProps?: DataItemProps[];
  chipProps?: AlertChipProps;
  currentElementCount?: { index: number; length: number };
  showUnavailableMessage?: boolean;
} & Pick<CardGenericContentProps, 'accessible'>;

export const ProductCardContent = ({
  leftIconName,
  leftCircleColor,
  rightIconName,
  heading,
  subheading,
  dataItemsProps,
  chipProps,
  currentElementCount = { index: 1, length: 1 },
  showUnavailableMessage,
  accessible,
}: ProductCardContentProps) => {
  const tokens = getTokens();

  return (
    <Stack
      accessible={accessible}
      testID={getTestId('card-generic-content')}
      p="$xl"
      gap="$xl"
    >
      <XStack testID={getTestId('card-generic-content-inner')}>
        {(!!leftIconName || !!leftCircleColor) && (
          <Stack mr="$md" alignSelf="center">
            <CardIcon
              cardLeftIcon={leftIconName}
              cardLeftCircle={leftCircleColor}
            />
          </Stack>
        )}

        <Stack flex={1}>
          {!!heading && (
            <Text
              fontVariant="heading5-semibold-Secondary900"
              testID={getTestId(
                `card-title-${
                  subheading ? `${heading} ${subheading}` : heading
                }`
              )}
              tamaguiTextProps={{
                accessibilityLabel: `${heading}, ${
                  currentElementCount.index
                } of ${currentElementCount.length.toString()}`,
              }}
            >
              {heading}
            </Text>
          )}
          {!!subheading && (
            <Text fontVariant="small-regular-Secondary800">{subheading}</Text>
          )}
        </Stack>

        {rightIconName && (
          <Stack ml="$xl" testID={getTestId(`card-icon-${rightIconName}`)}>
            <Icon name={rightIconName} color={tokens.color.$Gray400.val} />
          </Stack>
        )}
      </XStack>

      <YStack
        gap="$md"
        justifyContent="space-between"
        flex={1}
        testID={getTestId(`card-generic-content-data`)}
      >
        {dataItemsProps?.map((dataItemProps, index) => (
          <DataItem
            key={`${dataItemProps.heading}-${index}`}
            {...dataItemProps}
          />
        ))}
        {showUnavailableMessage && (
          <Text fontVariant="small-light-DWBlack">
            Sorry, we were unable to retrieve your account value at this time.
          </Text>
        )}
        {chipProps && (
          <AlertChip
            {...chipProps}
            fontSize="$small"
            alignSelf="flex-start"
            mt="$sm"
          />
        )}
      </YStack>
    </Stack>
  );
};

type CardIconProps = {
  cardLeftIcon?: IconName | null;
  cardLeftCircle?: string;
};
const CardIcon = ({ cardLeftIcon, cardLeftCircle }: CardIconProps) => {
  if (cardLeftIcon) {
    return <Icon name={cardLeftIcon} />;
  }
  if (cardLeftCircle) {
    return <Icon name="circle" width={9} height={9} color={cardLeftCircle} />;
  }
  return null;
};
