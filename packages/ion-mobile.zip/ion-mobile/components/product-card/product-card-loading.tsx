import { getTestId } from '@src/utils/get-test-id';
import { Stack } from 'tamagui';

import { Card } from '../cards';
import { Shimmer } from '../shimmer';

export const ProductCardLoading = () => (
  <Card testID={getTestId('loading-product-card')}>
    <Card.Generic.Content>
      <Shimmer width={150} height={22} />
      <Stack gap="$sm" my="$md">
        <Shimmer width={111} height={12} />
        <Shimmer width={100} height={18} />
        <Shimmer width={142} height={12} />
      </Stack>
      <Shimmer width={220} height={18} />
    </Card.Generic.Content>
  </Card>
);
