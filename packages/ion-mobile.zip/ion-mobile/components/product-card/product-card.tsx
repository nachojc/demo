import { getTestId } from '@src/utils/get-test-id';
import { ElementRef, forwardRef } from 'react';
import { Stack } from 'tamagui';

import { Card, CardProps } from '../cards';
import { ProductCardContent } from './product-card-content';
import { ProductCardLoading } from './product-card-loading';
import { ProductCardSubAccounts } from './product-card-sub-accounts';

export type ProductCardProps = {
  isLoading?: boolean;
  stripColor?: string;
} & CardProps;

export const ProductCard = Object.assign(
  forwardRef<ElementRef<typeof Card>, ProductCardProps>(
    ({ isLoading, stripColor = 'transparent', children, ...rest }, ref) => {
      if (isLoading) {
        return <ProductCardLoading />;
      }

      return (
        <Card ref={ref} {...rest}>
          <Stack
            borderLeftWidth="$lg"
            flex={1}
            borderLeftColor={stripColor}
            testID={getTestId('color-strip')}
          >
            {children}
          </Stack>
        </Card>
      );
    }
  ),
  {
    Content: ProductCardContent,
    SubAccounts: ProductCardSubAccounts,
  }
);
