import { fireEvent, render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { ProductCard } from '../product-card';

jest.mock('@src/utils/device-info', () => {
  const actualDeviceInfo = jest.requireActual('@src/utils/device-info');
  return {
    ...actualDeviceInfo,
    getVersion: () => '3.2.1',
    getSystemName: () => 'TestSystemName',
    getCarrier: () => 'TestCarrier',
    getSystemVersion: () => '1.2.3',
  };
});

jest.mock('@src/api-mock/use-mock-service-worker', () => ({
  __esModule: true,
  useMockServiceWorkerEnabled: jest.fn().mockImplementation(() => {
    return true;
  }),
}));

const mockOnPress = jest.fn();

afterEach(jest.clearAllMocks);

describe('ProductCard', () => {
  it('should render correctly with passed props', () => {
    render(
      <ProductCard onPress={mockOnPress}>
        <ProductCard.Content
          heading="Home"
          dataItemsProps={[
            { heading: 'Account number:', value: 'MTM069297139' },
            {
              heading: 'Insured address:',
              value: '28-30 Hoxton Square, N1 6NN',
            },
          ]}
          chipProps={{ variant: 'warning', title: 'Expires soon' }}
        />
      </ProductCard>
    );

    expect(screen.getByText('Home')).toBeOnTheScreen();
    expect(screen.getByText('Account number:')).toBeOnTheScreen();
    expect(screen.getByText('Insured address:')).toBeOnTheScreen();
    expect(screen.getByText('Expires soon')).toBeOnTheScreen();
  });

  it('should trigger the passed onPress function on press of the card', () => {
    render(
      <ProductCard onPress={mockOnPress} accessibilityLabel="View Home">
        <ProductCard.Content />
      </ProductCard>
    );

    fireEvent.press(screen.getByLabelText('View Home'));

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it('should have shadow border styling', () => {
    render(
      <ProductCard
        accessibilityLabel="View Home"
        testID={getTestId('product-card')}
      >
        <ProductCard.Content />
      </ProductCard>
    );

    expect(screen.getByTestId(getTestId('product-card'))).toHaveStyle({
      shadowOpacity: 0.15,
    });
  });

  it('should render color strip when stripColor is provided', () => {
    render(
      <ProductCard stripColor="#294682">
        <ProductCard.Content />
      </ProductCard>
    );

    expect(screen.getByTestId(getTestId('color-strip'))).toHaveStyle({
      borderLeftColor: '#294682',
      borderLeftWidth: 12,
    });
  });

  it('should render unable to retrieve message with showUnavailableMessage is true', () => {
    render(
      <ProductCard>
        <ProductCard.Content showUnavailableMessage />
      </ProductCard>
    );

    expect(
      screen.getByText(
        'Sorry, we were unable to retrieve your account value at this time.'
      )
    ).toBeOnTheScreen();
  });

  it('should not render unable to retrieve message with showUnavailableMessage is false', () => {
    render(
      <ProductCard>
        <ProductCard.Content />
      </ProductCard>
    );

    expect(
      screen.queryByText(
        'Sorry, we were unable to retrieve your account value at this time.'
      )
    ).not.toBeOnTheScreen();
  });

  it.each([['Some title'], ['Some title', 'Some subtitle']])(
    'should have correct test id',
    (...args) => {
      render(
        <ProductCard>
          <ProductCard.Content heading={args[0]} subheading={args[1]} />
        </ProductCard>
      );

      expect(
        screen.getByTestId(getTestId('card-title-' + args.join(' ')))
      ).toBeOnTheScreen();
    }
  );
});
