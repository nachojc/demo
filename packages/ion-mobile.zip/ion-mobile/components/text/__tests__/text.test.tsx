import { render, screen } from '@src/jest/testing-library';

import { parseFontVariant, Text } from '../text';

describe('Text Accessibility', () => {
  it('should have body style', () => {
    render(
      <>
        <Text fontVariant="labelSmall-regular-Gray500">labelSmall</Text>
        <Text fontVariant="overline-semibold-Gray800">overline</Text>
        <Text fontVariant="small-bold-Gray800">small</Text>
        <Text fontVariant="body-regular-Gray800">body</Text>
        <Text fontVariant="heading5-regular-Gray800">heading5</Text>
        <Text fontVariant="heading4-regular-Gray800">heading4</Text>
        <Text fontVariant="heading3-regular-Gray800">heading3</Text>
        <Text fontVariant="heading2-regular-Gray800">heading2</Text>
        <Text fontVariant="heading1-regular-Gray800">heading1</Text>
        <Text fontVariant="heading0-regular-Gray800">heading0</Text>
        <Text fontVariant="headingMax-regular-Gray800">headingMax</Text>
      </>
    );
    const labelSmall = screen.getByText('labelSmall');
    const overline = screen.getByText('overline');
    const small = screen.getByText('small');
    const body = screen.getByText('body');
    const heading5 = screen.getByText('heading5');
    const heading4 = screen.getByText('heading4');
    const heading3 = screen.getByText('heading3');
    const heading2 = screen.getByText('heading2');
    const heading1 = screen.getByText('heading1');
    const heading0 = screen.getByText('heading0');
    const headingMax = screen.getByText('headingMax');

    expect(labelSmall).toHaveStyle({
      color: '#717171',
      fontSize: 10,
      lineHeight: 15,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(overline).toHaveStyle({
      color: '#373737',
      fontSize: 12,
      lineHeight: 18,
      fontFamily: 'SourceSansPro-SemiBold',
    });
    expect(small).toHaveStyle({
      color: '#373737',
      fontSize: 14,
      lineHeight: 22,
      fontFamily: 'SourceSansPro-Bold',
    });
    expect(body).toHaveStyle({
      color: '#373737',
      fontSize: 16,
      lineHeight: 24,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(heading5).toHaveStyle({
      color: '#373737',
      fontSize: 18,
      lineHeight: 22,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(heading4).toHaveStyle({
      color: '#373737',
      fontSize: 20,
      lineHeight: 28,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(heading3).toHaveStyle({
      color: '#373737',
      fontSize: 24,
      lineHeight: 32,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(heading2).toHaveStyle({
      color: '#373737',
      fontSize: 32,
      lineHeight: 42,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(heading1).toHaveStyle({
      color: '#373737',
      fontSize: 40,
      lineHeight: 46,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(heading0).toHaveStyle({
      color: '#373737',
      fontSize: 48,
      lineHeight: 56,
      fontFamily: 'SourceSansPro-Regular',
    });
    expect(headingMax).toHaveStyle({
      color: '#373737',
      fontSize: 56,
      lineHeight: 60,
      fontFamily: 'SourceSansPro-Regular',
    });
  });

  it('should have an accessibility label and hint', () => {
    render(
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{
          accessibilityLabel: 'Hello-Label',
        }}
      >
        Hello
      </Text>
    );

    const text = screen.getAllByLabelText('Hello-Label');
    expect(text).toHaveLength(1);
  });
});

describe('Parse Font Variant Function', () => {
  it('should return font properties', () => {
    const fontProperties = parseFontVariant('labelSmall-regular-Gray500');
    expect(fontProperties).toMatchObject({
      color: {
        key: '$Gray500',
        val: '#717171',
      },
      fontSize: 10,
      fontWeight: '400',
      lineHeight: 15,
    });
  });
});
