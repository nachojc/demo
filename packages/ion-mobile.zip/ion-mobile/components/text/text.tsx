import { fonts } from '@theme/fonts';
import { tokens } from '@theme/tokens';
import { ReactNode } from 'react';
import { Text as TamaguiText, TextProps as TamaguiTextProps } from 'tamagui';

type Size = keyof (typeof fonts.body)['size'];
type Weight = keyof (typeof fonts.body)['weight'];
type Color = keyof (typeof tokens)['color'];

/** This sets the font-size, font-weight, line-height and color of the text */
export type FontVariant = `${Size}-${Weight}-${Color}`;
type TextProps = {
  numberOfLines?: number;
  children?: ReactNode;
  fontVariant: FontVariant;
  tamaguiTextProps?: TamaguiTextProps;
  decoration?: 'none' | 'underline' | 'line-through' | 'underline line-through';
  testID?: string;
};

export const parseFontVariant = (variant: FontVariant) => {
  const [fontSize, fontWeight, color] = variant.split('-') as [
    Size,
    Weight,
    Color
  ];

  return {
    fontSize: fonts.body.size[fontSize],
    lineHeight: fonts.body.lineHeight[fontSize],
    color: tokens.color[color],
    fontWeight: fonts.body.weight[fontWeight],
  };
};

export const Text = ({
  tamaguiTextProps,
  fontVariant,
  children,
  decoration,
  testID,
}: TextProps) => {
  const { fontSize, lineHeight, fontWeight, color } =
    parseFontVariant(fontVariant);
  return (
    <TamaguiText
      fontFamily={'$body'}
      fontSize={fontSize}
      fontWeight={fontWeight}
      lineHeight={lineHeight}
      color={color}
      accessibilityRole={tamaguiTextProps?.accessibilityRole || 'text'}
      textDecorationLine={decoration}
      testID={testID}
      {...tamaguiTextProps}
    >
      {children}
    </TamaguiText>
  );
};
