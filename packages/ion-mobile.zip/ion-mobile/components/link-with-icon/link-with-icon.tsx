import { Icon, IconName, Text } from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';
import { ColorValue, Pressable } from 'react-native';
import { GetProps, getTokens, XStack } from 'tamagui';

type LinkProps = GetProps<typeof XStack>;

type LinkWithIconProps = LinkProps & {
  linkText: string;
  iconName?: IconName;
  iconColor?: ColorValue;
  onPress: () => void;
  accessibilityHint?: string;
};

const tokens = getTokens();

export const LinkWithIcon = ({
  linkText,
  iconName = 'chevron-right',
  iconColor = tokens.color.Tertiary800.val,
  onPress,
  accessibilityHint,
  ...containerProps
}: LinkWithIconProps) => {
  return (
    <Pressable
      testID={getTestId('link-with-icon')}
      accessibilityRole="link"
      accessible
      onPress={onPress}
      accessibilityHint={accessibilityHint}
    >
      <XStack alignItems="center" marginVertical="$xl" {...containerProps}>
        <Text
          tamaguiTextProps={{ lineHeight: '$overline' }}
          fontVariant="body-semibold-Tertiary800"
        >
          {linkText}
        </Text>
        <Icon name={iconName} color={iconColor} />
      </XStack>
    </Pressable>
  );
};
