import { fireEvent, render, screen } from '@src/jest/testing-library';

import { LinkWithIcon } from '../link-with-icon';

const mockOnPress = jest.fn();

const props = { linkText: `I can't see my policy`, onPress: mockOnPress };

describe('LinkWithIcon', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render CantSeeMyPolicyButton', () => {
    render(<LinkWithIcon {...props} />);
    expect(screen.getByText(`I can't see my policy`)).toBeVisible();
  });

  it('should call mockOnPress on button tap', () => {
    render(<LinkWithIcon {...props} />);
    fireEvent.press(screen.getByText(`I can't see my policy`));
    expect(mockOnPress).toHaveBeenCalled();
  });
});
