import { FlatList } from '@src/components/flatlist/flatlist';
import { getTokens, getVariableValue, Stack, XStack } from 'tamagui';

import { ActionChip } from '../chip';

type FilterListProps = {
  listName?: string;
  filters: string[];
  onFiltersChange: (selectedFilter: string, isSelected: boolean) => void;
  selectedFilters?: string[];
  accessibilityLabel?: string;
  accessibilityHint?: string;
};

export const FilterList = ({
  listName,
  filters,
  onFiltersChange,
  selectedFilters = [],
  accessibilityLabel,
  accessibilityHint,
}: FilterListProps) => {
  const isSelectedFiltersEmpty = selectedFilters.length === 0;
  const tokens = getTokens();

  return (
    <XStack backgroundColor={getVariableValue(tokens.color.WealthBlue)}>
      <Stack
        accessible
        accessibilityRole="list"
        accessibilityLabel={accessibilityLabel}
        accessibilityHint={accessibilityHint}
        style={{
          position: 'absolute',
          top: 0,
          bottom: 0,
          right: 0,
          left: 0,
          width: 1,
          height: 1,
        }}
      />
      <FlatList
        testID="filter-list-test"
        estimatedItemSize={80}
        contentContainerStyle={{
          paddingVertical: getVariableValue(tokens.space.$xl),
          paddingHorizontal: getVariableValue(tokens.space.$lg),
          backgroundColor: getVariableValue(tokens.color.WealthBlue),
        }}
        horizontal
        listHeight={64}
        showsHorizontalScrollIndicator={false}
        data={['All', ...filters]}
        keyExtractor={(item: string) => item}
        extraData={[selectedFilters]}
        renderItem={({ item, index }: { item: string; index: number }) =>
          index === 0 ? (
            <ActionChip
              title={'All'}
              testID="all-filter-chip"
              accessibilityLabel="All"
              accessibilityHint={`Applies all the filters to the ${listName}`}
              preselected={isSelectedFiltersEmpty}
              lightTheme
              disableToggle={isSelectedFiltersEmpty}
              onPressChip={(isSelected: boolean) =>
                isSelected &&
                !isSelectedFiltersEmpty &&
                onFiltersChange('All', true)
              }
            />
          ) : (
            <ActionChip
              marginRight={10}
              title={item}
              testID={`${item}-filter-chip`}
              accessibilityLabel={item}
              accessibilityHint={
                selectedFilters.includes(item)
                  ? `Deselects the filter of ${item}`
                  : `Adds ${item} as a filter`
              }
              variant="close"
              preselected={selectedFilters.includes(item)}
              lightTheme
              trailingIcon
              onPressChip={(isSelected) => {
                onFiltersChange(item, isSelected);
              }}
            />
          )
        }
      />
    </XStack>
  );
};
