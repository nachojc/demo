import { fireEvent, render, screen } from '@src/jest/testing-library';

import { FilterList } from '../filter-list';

const FILTERS = ['Purchase', 'Sale', 'Internal transfer', 'External transfer'];

describe('Filter list component', () => {
  it('should render a set number of filters passed by the prop filters', () => {
    render(<FilterList filters={FILTERS} onFiltersChange={() => null} />);

    expect(screen.getByTestId('Purchase-filter-chip')).toBeOnTheScreen();
    expect(screen.getByTestId('Sale-filter-chip')).toBeOnTheScreen();
    expect(
      screen.getByTestId('Internal transfer-filter-chip')
    ).toBeOnTheScreen();
    expect(
      screen.getByTestId('External transfer-filter-chip')
    ).toBeOnTheScreen();
  });

  it('should add a "All" chip to the filter list', () => {
    render(<FilterList filters={FILTERS} onFiltersChange={() => null} />);
    const filterList = screen.getByTestId('filter-list-test');

    expect(filterList).toHaveTextContent('All');
  });

  it("should call onFilterChange with selectedFilter as All and isSelected as true when the 'All' chip is pressed", () => {
    const mockOnFiltersChange = jest.fn();

    render(
      <FilterList
        filters={FILTERS}
        onFiltersChange={mockOnFiltersChange}
        selectedFilters={['Purchase', 'Sale']}
      />
    );

    fireEvent.press(screen.getByTestId('all-filter-chip'));

    expect(mockOnFiltersChange).toHaveBeenCalledWith('All', true);
  });

  it("should call onFilterChange with selectedFilter as Purchase and isSelected as true when the 'Purchase' chip is first pressed", () => {
    const mockOnFiltersChange = jest.fn();

    render(
      <FilterList
        filters={FILTERS}
        onFiltersChange={mockOnFiltersChange}
        selectedFilters={['Sale']}
      />
    );

    fireEvent.press(screen.getByTestId('Purchase-filter-chip'));

    expect(mockOnFiltersChange).toHaveBeenCalledWith('Purchase', true);
  });

  it("should call onFilterChange with selectedFilter as Purchase and isSelected as false when the active 'Purchase' chip is pressed again", () => {
    const mockOnFiltersChange = jest.fn();

    render(
      <FilterList
        filters={FILTERS}
        onFiltersChange={mockOnFiltersChange}
        selectedFilters={['Sale']}
      />
    );

    fireEvent.press(screen.getByTestId('Purchase-filter-chip'));

    expect(mockOnFiltersChange).toHaveBeenCalledWith('Purchase', true);

    fireEvent.press(screen.getByTestId('Purchase-filter-chip'));

    expect(mockOnFiltersChange).toHaveBeenCalledWith('Purchase', false);
  });

  it('should have the "All" filter preselected when no other filters are active', () => {
    render(
      <FilterList
        filters={FILTERS}
        onFiltersChange={() => null}
        selectedFilters={[]}
      />
    );
    expect(screen.getByTestId('all-filter-chip')).toHaveStyle({
      backgroundColor: '#FFD900',
    });
  });

  it('should have the "All" filter unselected when at least a filter has been selected', () => {
    render(
      <FilterList
        filters={FILTERS}
        onFiltersChange={() => null}
        selectedFilters={['Purchase-filter-chip']}
      />
    );

    expect(screen.getByTestId('all-filter-chip')).toHaveStyle({
      backgroundColor: 'transparent',
    });
  });

  it('should have some filters preselected if the selectedFilters prop has been passed with some filters', () => {
    const SELECTED_FILTERS = ['Purchase', 'Sale'];

    render(
      <FilterList
        filters={FILTERS}
        selectedFilters={SELECTED_FILTERS}
        onFiltersChange={() => null}
      />
    );
    expect(screen.getByTestId('Purchase-filter-chip')).toHaveStyle({
      backgroundColor: '#FFD900',
    });
    expect(screen.getByTestId('Sale-filter-chip')).toHaveStyle({
      backgroundColor: '#FFD900',
    });
  });

  it('should have accessibility label for the component', () => {
    render(
      <FilterList
        filters={FILTERS}
        onFiltersChange={() => null}
        accessibilityLabel="Holdings transaction types filter"
      />
    );

    expect(
      screen.getByLabelText('Holdings transaction types filter')
    ).toBeOnTheScreen();
  });

  it(`should have accessibility label and hint for the "All" filter option`, () => {
    render(
      <FilterList
        listName="transactions"
        filters={FILTERS}
        onFiltersChange={() => null}
      />
    );

    expect(screen.getByLabelText('All')).toBeOnTheScreen();
    expect(
      screen.getByAccessibilityHint(
        'Applies all the filters to the transactions'
      )
    ).toBeOnTheScreen();
  });

  it(`should have accessibility label and hint for filter options when they are not selected`, () => {
    render(
      <FilterList
        listName="transactions"
        filters={FILTERS}
        onFiltersChange={() => null}
      />
    );

    expect(screen.getByLabelText('Purchase')).toBeOnTheScreen();
    expect(
      screen.getByAccessibilityHint(`Adds Purchase as a filter`)
    ).toBeOnTheScreen();
  });

  it(`should have accessibility label and hint for filter options when they are selected`, () => {
    const PRESELECTED_FILTERS = ['Purchase'];

    render(
      <FilterList
        listName="transactions"
        filters={FILTERS}
        selectedFilters={PRESELECTED_FILTERS}
        onFiltersChange={() => null}
      />
    );

    expect(screen.getByLabelText('Purchase')).toBeOnTheScreen();
    expect(
      screen.getByAccessibilityHint(`Deselects the filter of Purchase`)
    ).toBeOnTheScreen();
  });
});
