import { tokens } from '@src/theme/tokens';
import { styled, XStack } from 'tamagui';

const FloatingButtonSize = 56;
const FloatingButtonTopMargin = 40;
export const FloatingButtonBottomMargin = 16;
export const FloatingButtonIpadBottomMargin = 32;
export const FloatingButtonTotalHeight =
  FloatingButtonTopMargin + FloatingButtonSize + FloatingButtonBottomMargin;

export const FloatingButton = styled(XStack, {
  alignItems: 'center',
  backgroundColor: '$Primary500',
  borderRadius: 100,
  height: FloatingButtonSize,
  justifyContent: 'center',
  width: FloatingButtonSize,
  pressStyle: { backgroundColor: '$Gray200' },
  elevation: 20,
  shadowColor: tokens.color.Gray900.val,
  shadowRadius: 10,
  shadowOpacity: 0.15,

  variants: {
    variant: {
      brand: {
        backgroundColor: '$Primary500',
        android_ripple: { color: '$Primary600' },
      },
      subBrand: {
        backgroundColor: '$DWPrimary500',
      },
    },
  },
});
