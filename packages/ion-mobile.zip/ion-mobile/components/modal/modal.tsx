import { useAccessibility } from '@src/common/providers/accessibility';
import { Color, tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { ReactNode } from 'react';
import {
  ScrollView,
  TouchableWithoutFeedback,
  useWindowDimensions,
} from 'react-native';
import RNModal from 'react-native-modal';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getVariableValue, SpaceTokens, Stack, XStack } from 'tamagui';

import { CloseButton } from '../close-button';
import { DropdownBaseProps } from '../dropdown-types/dropdown/types';
import { YStack } from '../stacks';

type ModalHeightValue = 0.3 | 0.5 | 0.75 | 0.9 | 1;

export type ModalProps = Pick<DropdownBaseProps, 'modalStyles'> & {
  backgroundColor: Color;
  bottomPadding?: SpaceTokens;
  children: ReactNode;
  closeIconColor?: Color;
  isOpen: boolean;
  modalHeight?: ModalHeightValue;
  isIpadWidth?: boolean;
  onClose: () => void;
  onModalHide?: () => void;
  onShow?: () => void;
  testId?: string;
  hasTextInput?: boolean;
};

export const Modal = ({
  backgroundColor,
  bottomPadding,
  children,
  closeIconColor,
  isOpen,
  modalHeight,
  isIpadWidth,
  onClose,
  onModalHide,
  onShow,
  testId,
  modalStyles,
  hasTextInput,
}: ModalProps) => {
  const { height: deviceHeight, width: deviceWidth } = useWindowDimensions();
  const { isScreenReaderEnabled } = useAccessibility();
  const { top } = useSafeAreaInsets();

  const setMarginTop = (height: ModalHeightValue | undefined) => {
    if (height) {
      return 'auto';
    }
    return top;
  };

  return (
    <Stack>
      <RNModal
        avoidKeyboard={hasTextInput ?? deviceWidth < deviceHeight}
        testID={getTestId(testId ?? 'modal')}
        isVisible={isOpen}
        style={{
          margin: 0,
          marginTop: setMarginTop(modalHeight),
          ...(typeof modalStyles === 'object' && modalStyles),
        }}
        onBackdropPress={onClose}
        backdropOpacity={0.5}
        backdropColor="black"
        onModalShow={onShow}
        onModalHide={onModalHide}
        {...(isScreenReaderEnabled && {
          customBackdrop: (
            <TouchableWithoutFeedback
              testID={getTestId('modal-backdrop')}
              accessible={false}
              importantForAccessibility="no"
              onPress={onClose}
            >
              <YStack f={1} backgroundColor="black" opacity={0.5} />
            </TouchableWithoutFeedback>
          ),
        })}
      >
        <YStack
          tablet={isIpadWidth ? isIpad : undefined}
          backgroundColor={getVariableValue(tokens.color[backgroundColor])}
          flex={modalHeight ? modalHeight : 1}
          maxHeight={isIpad ? '100%' : undefined}
          paddingHorizontal={isIpad ? '$xxxl' : '$xl'}
          paddingTop={modalHeight === 1 ? top : '$xxl'}
          borderTopLeftRadius={24}
          borderTopRightRadius={24}
          justifyContent="space-between"
          marginTop="auto"
          testID={getTestId('modal-content')}
        >
          <Stack flex={1}>
            <XStack flexDirection="row-reverse" paddingBottom="$md">
              <CloseButton
                onPress={onClose}
                accessibilityHint={'Close the overlay'}
                testID="close-button"
                iconProps={{
                  name: 'close',
                  color: getVariableValue(
                    tokens.color[closeIconColor ?? 'White']
                  ),
                }}
              />
            </XStack>

            <ScrollView
              keyboardShouldPersistTaps="handled"
              contentContainerStyle={{
                flexGrow: 1,
                paddingBottom: bottomPadding
                  ? bottomPadding
                  : getVariableValue(tokens.space.xxxl),
                paddingRight: getVariableValue(tokens.space.md),
              }}
            >
              {children}
            </ScrollView>
          </Stack>
        </YStack>
      </RNModal>
    </Stack>
  );
};
