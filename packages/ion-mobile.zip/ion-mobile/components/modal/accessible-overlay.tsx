import { useAccessibility } from '@src/common/providers/accessibility';
import { ReactElement, useEffect, useState } from 'react';
import { Modal, ModalProps } from 'react-native';

export type AccessibleOverlayProps = ModalProps & {
  render: (isScreenReaderEnabled: boolean) => ReactElement;
  isDialog?: boolean;
};

export const AccessibleOverlay = ({
  animationType = 'none',
  onRequestClose,
  render,
  visible,
  isDialog = false,
  ...props
}: AccessibleOverlayProps): ReactElement => {
  const { isScreenReaderEnabled } = useAccessibility();

  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (isScreenReaderEnabled) {
      if (visible) {
        setOpen(true);
      } else {
        setTimeout(() => {
          setOpen(false);
        }, 200);
      }
    } else {
      setOpen(!!visible);
    }
  }, [isScreenReaderEnabled, visible]);

  // Pop ups were not working on certain android devices, using react native modal if its a dialog.
  // https://jira.aviva.co.uk/browse/DW-7023
  if (isScreenReaderEnabled || isDialog) {
    return (
      <Modal
        {...props}
        animationType={animationType}
        onRequestClose={onRequestClose}
        statusBarTranslucent
        transparent
        visible={open}
      >
        {render(isScreenReaderEnabled)}
      </Modal>
    );
  }

  return render(isScreenReaderEnabled);
};
