import { useAccessibility } from '@src/common/providers/accessibility';
import { Color, tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { ReactNode, useCallback, useState } from 'react';
import {
  Dimensions,
  LayoutChangeEvent,
  TouchableWithoutFeedback,
} from 'react-native';
import RNModal from 'react-native-modal';
import { getVariableValue, ScrollView, SpaceTokens, XStack } from 'tamagui';

import { CloseButton } from '../close-button';
import { YStack } from '../stacks';

export type DynamicModalProps = {
  backgroundColor: Color;
  bottomPadding?: SpaceTokens;
  paddingHorizontal?: SpaceTokens;
  children: ReactNode;
  closeIconAccessibilityHint?: string;
  closeIconColor?: Color;
  isOpen: boolean;
  verticalPadding?: SpaceTokens;
  hasBackdrop?: boolean;
  onClose: () => void;
  onShow?: () => void;
  onModalHide?: () => void;
  disableBackdropPress?: boolean;
  showOnCloseButton?: boolean;
};

export const DynamicHeightModal = ({
  backgroundColor = 'White',
  bottomPadding,
  paddingHorizontal = '$xl',
  children,
  closeIconAccessibilityHint,
  closeIconColor,
  isOpen,
  verticalPadding,
  hasBackdrop = true,
  disableBackdropPress,
  onClose,
  onShow,
  onModalHide,
  showOnCloseButton = true,
}: DynamicModalProps) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const screenHeight = Dimensions.get('window').height;
  const maximumModalHeight = screenHeight * 0.83; // Take maximum of 83% of screen
  const [modalHeight, setModalHeight] = useState<number>(maximumModalHeight);

  const onContentLayout = useCallback(
    (event: LayoutChangeEvent) => {
      const contentHeight = event.nativeEvent.layout.height;
      const modalheight = Math.min(contentHeight + 16, maximumModalHeight);
      setModalHeight(modalheight);
    },
    [maximumModalHeight]
  );

  return (
    <RNModal
      testID="rnmodal"
      isVisible={isOpen}
      style={{
        margin: 0,
        marginTop: 'auto',
      }}
      hasBackdrop={hasBackdrop}
      onBackButtonPress={onClose}
      onModalShow={onShow}
      onBackdropPress={disableBackdropPress ? undefined : onClose}
      onModalHide={onModalHide}
      backdropOpacity={0.5}
      backdropColor="black"
      {...(isScreenReaderEnabled && {
        customBackdrop: (
          <TouchableWithoutFeedback
            testID={getTestId('dynamic-height-modal-backdrop')}
            accessible={false}
            importantForAccessibility="no"
            onPress={onClose}
          >
            <YStack f={1} backgroundColor="black" opacity={0.5} />
          </TouchableWithoutFeedback>
        ),
      })}
    >
      <YStack
        tablet={isIpad}
        backgroundColor={getVariableValue(tokens.color[backgroundColor])}
        paddingHorizontal={paddingHorizontal}
        paddingVertical={
          verticalPadding ? verticalPadding : getVariableValue(tokens.space.xxl)
        }
        borderTopLeftRadius={24}
        borderTopRightRadius={24}
        justifyContent="space-between"
        marginTop="auto"
        testID={getTestId('modal-content')}
      >
        {showOnCloseButton && (
          <XStack flexDirection="row-reverse" paddingBottom="$md">
            <CloseButton
              onPress={onClose}
              accessibilityHint={
                closeIconAccessibilityHint ?? 'Close the overlay'
              }
              testID="close-button"
              iconProps={{
                name: 'close',
                color: getVariableValue(
                  tokens.color[closeIconColor ?? 'White']
                ),
              }}
            />
          </XStack>
        )}
        <ScrollView
          style={{ maxHeight: modalHeight }}
          contentContainerStyle={{
            paddingBottom: bottomPadding ?? getVariableValue(tokens.space.xxxl),
            paddingRight: getVariableValue(tokens.space.md),
          }}
        >
          <YStack
            testID={getTestId('contentContainer')}
            onLayout={onContentLayout}
            paddingHorizontal={isIpad ? tokens.space.xxxl : undefined}
          >
            {children}
          </YStack>
        </ScrollView>
      </YStack>
    </RNModal>
  );
};
