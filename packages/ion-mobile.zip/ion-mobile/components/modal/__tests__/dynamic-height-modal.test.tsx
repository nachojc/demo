import { fireEvent, render, screen } from '@src/jest/testing-library';
import { DynamicHeightModal, DynamicModalProps } from '@aviva/ion-mobile';
import { getTestId } from '@src/utils/get-test-id';
import * as isIpadModule from '@src/utils/is-ipad';
import { Text } from 'react-native';

jest.mock('@src/utils/is-ipad');

const onClose = jest.fn();
const modalName = 'test:id/modal-content';
const renderComponent = (props: Partial<DynamicModalProps> = {}) => {
  return render(
    <DynamicHeightModal
      isOpen
      onClose={onClose}
      backgroundColor="DWPrimary500"
      {...props}
    >
      <Text>Hello</Text>
    </DynamicHeightModal>
  );
};

describe('Dynamic Height Modal', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render with default configuration', () => {
    renderComponent();

    expect(screen.getByTestId(modalName)).toBeDefined();
    expect(screen.getByText('Hello')).toBeDefined();
  });

  it('should have testID on the Modal', () => {
    renderComponent();
    expect(screen.getByTestId(modalName)).toBeOnTheScreen();
  });

  it('should render with default top bar and content view styling', () => {
    renderComponent({
      backgroundColor: 'DWPrimary500',
    });

    const content = screen.getByTestId(modalName);

    expect(content).toHaveStyle({
      backgroundColor: '#141D31',
    });
  });

  it('should not have modal visible when visible prop is false', () => {
    renderComponent({ isOpen: false });

    expect(screen.queryByText('Hello')).toBeFalsy();
  });

  it('should run supplied onClose function when close button is pressed', () => {
    renderComponent();
    const closeButton = screen.getByLabelText('Close');
    fireEvent.press(closeButton);

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('should apply passed background color to content view', () => {
    renderComponent({ backgroundColor: 'White' });

    const content = screen.getByTestId(modalName);

    expect(content).toHaveStyle({
      backgroundColor: '#FFFFFF',
    });
  });

  it('should call the correct accessibility hint when passed as a prop', () => {
    renderComponent({
      closeIconAccessibilityHint: 'Navigates back to the previous screen',
    });
    const closeButton = screen.getByLabelText('Close');

    expect(closeButton).toHaveProp(
      'accessibilityHint',
      'Navigates back to the previous screen'
    );
  });

  it('should call the default accessibility hint when no prop is passed', () => {
    renderComponent();
    const closeButton = screen.getByLabelText('Close');

    expect(closeButton).toHaveProp('accessibilityHint', 'Close the overlay');
  });

  it('ystack should have vertical padding set to 24', () => {
    renderComponent({ isOpen: true });

    const modelContent = screen.getByTestId('test:id/modal-content');

    expect(modelContent.props.style.paddingTop).toEqual(24);
  });

  it('ystack should have vertical padding set to 0', () => {
    renderComponent({ isOpen: true, verticalPadding: '$0' });

    const modelContent = screen.getByTestId('test:id/modal-content');

    expect(modelContent.props.style.paddingTop).toEqual(0);
  });

  it('ystack should have vertical padding set to 2', () => {
    renderComponent({ isOpen: true, verticalPadding: '$xs' });

    const modelContent = screen.getByTestId('test:id/modal-content');

    expect(modelContent.props.style.paddingTop).toEqual(2);
  });

  it('should show the close icon when showCloseButton is true', () => {
    renderComponent({ showOnCloseButton: true });

    expect(screen.getByLabelText('Close')).toBeOnTheScreen();
  });

  it('should not show the close icon when showCloseButton is false', () => {
    renderComponent({ showOnCloseButton: false });

    expect(screen.queryByLabelText('Close')).not.toBeOnTheScreen();
  });

  describe('style', () => {
    it('has xxxl padding if its iPad', () => {
      (isIpadModule as any).isIpad = true;
      renderComponent();
      expect(screen.getByTestId(getTestId('contentContainer'))).toHaveStyle({
        paddingLeft: 32,
        paddingRight: 32,
      });
    });

    it('does not have xxxl padding if its not iPad', () => {
      (isIpadModule as any).isIpad = false;
      renderComponent();

      expect(screen.getByTestId(getTestId('contentContainer'))).not.toHaveStyle(
        {
          paddingLeft: 32,
          paddingRight: 32,
        }
      );
    });
  });
});
