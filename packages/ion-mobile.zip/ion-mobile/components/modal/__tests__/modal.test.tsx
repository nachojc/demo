import { fireEvent, render, screen } from '@src/jest/testing-library';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { Text } from 'react-native';

import { Modal, ModalProps } from '../modal';

const onClose = jest.fn();
const onModalHide = jest.fn();
const modalName = 'test:id/modal-content';
const renderComponent = (props: Partial<ModalProps> = {}) => {
  return render(
    <Modal
      isOpen
      onClose={onClose}
      onModalHide={onModalHide}
      backgroundColor="DWPrimary500"
      {...props}
    >
      <Text>Hello</Text>
    </Modal>
  );
};

describe('Modal', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render with default configuration', () => {
    renderComponent();

    expect(screen.getByTestId(modalName)).toBeDefined();
    expect(screen.getByText('Hello')).toBeDefined();
  });

  it('should have testID on  the Modal', () => {
    renderComponent();
    expect(screen.getByTestId(modalName)).toBeOnTheScreen();
  });

  it('should not have modal visible when visible prop is false', () => {
    renderComponent({ isOpen: false });

    expect(screen.queryByText('Hello')).toBeFalsy();
  });

  it('should run supplied onClose function when close button is pressed', () => {
    renderComponent();
    const closeButton = screen.getByLabelText('Close');
    fireEvent.press(closeButton);

    expect(onClose).toHaveBeenCalledTimes(1);
  });

  it('should run supplied onModalHide function when close button is pressed', () => {
    renderComponent();
    fireEvent(screen.getByTestId(getTestId('modal')), 'onModalHide');

    expect(onModalHide).toHaveBeenCalledTimes(1);
  });

  describe('styles', () => {
    it('should render with default top bar and content view styling', () => {
      renderComponent({
        backgroundColor: 'DWPrimary500',
      });

      const content = screen.getByTestId(modalName);

      expect(content).toHaveStyle({
        backgroundColor: tokens.color.DWPrimary500.val,
      });
    });

    it('should apply passed background color to content view', () => {
      renderComponent({ backgroundColor: 'White' });
      const content = screen.getByTestId(modalName);

      expect(content).toHaveStyle({
        backgroundColor: tokens.color.White.val,
      });
    });
  });
});
