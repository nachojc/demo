import { fireEvent, render, screen } from '@src/jest/testing-library';
import {
  DynamicHeightCenteredModal,
  DynamicHeightCenteredModalProps,
  Text,
} from '@aviva/ion-mobile';

const screenHeight = 932;
const iosInsets = { top: 59, bottom: 34 };
const androidInsets = { top: 54, bottom: 0 };

let mockPlatform = 'ios';
jest.mock('react-native/Libraries/Utilities/Platform', () => ({
  ...jest.requireActual('react-native/Libraries/Utilities/Platform'),
  OS: mockPlatform,
  select: jest.fn().mockImplementation((obj) => {
    const value = obj[mockPlatform];
    return value ? value : obj.default;
  }),
}));

jest.mock('react-native/Libraries/Utilities/Dimensions', () => ({
  ...jest.requireActual('react-native/Libraries/Utilities/Dimensions'),
  get: () => ({ height: screenHeight }),
  addEventListener: jest.fn(),
}));

let mockUseSafeAreaInsets = iosInsets;
jest.mock('react-native-safe-area-context', () => ({
  useSafeAreaInsets: () => mockUseSafeAreaInsets,
  initialWindowMetrics: { frame: { height: screenHeight } },
}));

const setIsVisibleMock = jest.fn();
const renderModal = ({
  isVisible,
  title,
}: Pick<DynamicHeightCenteredModalProps, 'isVisible' | 'title'>) =>
  render(
    <DynamicHeightCenteredModal
      isVisible={isVisible}
      setIsVisible={setIsVisibleMock}
      title={title}
    >
      <Text fontVariant="body-regular-Gray800">Hello</Text>
    </DynamicHeightCenteredModal>
  );

describe('Dynamic Height Centered Modal', () => {
  it('does not render modal if isVisible is false', () => {
    renderModal({ isVisible: false });

    expect(screen.queryByText('Hello')).not.toBeOnTheScreen();
  });

  it('renders modal with content and title', () => {
    renderModal({ isVisible: true, title: 'Title' });

    expect(screen.getByText('Hello')).toBeVisible();
    expect(screen.getByText('Title')).toBeVisible();
  });

  it('renders modal without title', () => {
    renderModal({ isVisible: true });

    expect(screen.getByText('Hello')).toBeVisible();
    expect(screen.queryByText('Title')).not.toBeOnTheScreen();
  });

  it('closes modal on onBackdropPress', () => {
    renderModal({ isVisible: true });

    const modal = screen.getByTestId('modal');

    fireEvent(modal, 'backdropPress');

    expect(setIsVisibleMock).toHaveBeenCalledWith(false);
  });

  it('closes modal on onBackButtonPress', () => {
    renderModal({ isVisible: true });

    const modal = screen.getByTestId('modal');

    fireEvent(modal, 'backButtonPress');

    expect(setIsVisibleMock).toHaveBeenCalledWith(false);
  });

  it('renders content with white backgroundColor', () => {
    renderModal({ isVisible: true });

    const content = screen.getByTestId('modal-content');

    expect(content).toHaveStyle({
      backgroundColor: '#FFFFFF',
    });
  });

  describe('IOS', () => {
    beforeEach(() => {
      mockPlatform = 'ios';
      mockUseSafeAreaInsets = iosInsets;
    });
    it('disables scroll if the content height less than max modal height', () => {
      renderModal({ isVisible: true });

      const scrollView = screen.getByTestId('modal-scroll-view');

      fireEvent(scrollView, 'layout', {
        nativeEvent: {
          layout: {
            height: screenHeight * 0.82,
          },
        },
      });

      expect(scrollView).toHaveProp('scrollEnabled', false);
    });

    it('enables scroll if the content height more than max modal height', () => {
      renderModal({ isVisible: true });

      const scrollView = screen.getByTestId('modal-scroll-view');

      fireEvent(scrollView, 'layout', {
        nativeEvent: {
          layout: {
            height: screenHeight * 0.85,
          },
        },
      });

      expect(scrollView).toHaveProp('scrollEnabled', true);
    });

    it('enables scroll if the content height equal max modal height', () => {
      renderModal({ isVisible: true });

      const scrollView = screen.getByTestId('modal-scroll-view');

      fireEvent(scrollView, 'layout', {
        nativeEvent: {
          layout: { height: screenHeight * 0.83 },
        },
      });

      expect(scrollView).toHaveProp('scrollEnabled', true);
    });
  });

  describe('Android', () => {
    beforeEach(() => {
      mockPlatform = 'android';
      mockUseSafeAreaInsets = androidInsets;
    });

    it('disables scroll if the content height less than max modal height', () => {
      renderModal({ isVisible: true });

      const scrollView = screen.getByTestId('modal-scroll-view');

      fireEvent(scrollView, 'layout', {
        nativeEvent: {
          layout: { height: screenHeight * 0.82 },
        },
      });

      expect(scrollView).toHaveProp('scrollEnabled', false);
    });

    it('enables scroll if the content height more than max modal height', () => {
      renderModal({ isVisible: true });

      const scrollView = screen.getByTestId('modal-scroll-view');

      fireEvent(scrollView, 'layout', {
        nativeEvent: {
          layout: { height: screenHeight * 0.85 },
        },
      });

      expect(scrollView).toHaveProp('scrollEnabled', true);
    });

    it('enables scroll if the content height equal max modal height', () => {
      renderModal({ isVisible: true });

      const scrollView = screen.getByTestId('modal-scroll-view');

      fireEvent(scrollView, 'layout', {
        nativeEvent: {
          layout: { height: screenHeight * 0.83 },
        },
      });

      expect(scrollView).toHaveProp('scrollEnabled', true);
    });
  });
});
