import { tokens } from '@src/theme/tokens';
import { Dispatch, SetStateAction, useState } from 'react';
import { Platform, useWindowDimensions } from 'react-native';
import Modal, { ModalProps } from 'react-native-modal';
import {
  initialWindowMetrics,
  useSafeAreaInsets,
} from 'react-native-safe-area-context';
import { ScrollView, Stack } from 'tamagui';

import { Text } from '../text';

export type DynamicHeightCenteredModalProps = Pick<
  ModalProps,
  'isVisible' | 'children'
> & {
  setIsVisible: Dispatch<SetStateAction<boolean>>;
  title?: string;
};

export const DynamicHeightCenteredModal = ({
  isVisible,
  setIsVisible,
  children,
  title,
}: DynamicHeightCenteredModalProps) => {
  const { height } = useWindowDimensions();
  const { top, bottom } = useSafeAreaInsets();
  const [isScrollable, setIsScrollable] = useState(false);

  const basePadding = tokens.space.xxl.val;
  const paddingTop = Platform.select({ android: basePadding, default: top });
  const paddingBottom = bottom || basePadding;

  const maxModalHeight =
    Math.round(initialWindowMetrics?.frame.height || height) * 0.83;

  const onClose = () => setIsVisible(false);
  return (
    <Modal
      deviceHeight={initialWindowMetrics?.frame.height}
      testID="modal"
      isVisible={isVisible}
      style={{ margin: 0, paddingBottom, paddingTop }}
      onBackButtonPress={onClose}
      onBackdropPress={onClose}
      backdropOpacity={0.5}
      backdropColor={tokens.color.Gray900.val}
    >
      <Stack
        testID="modal-content"
        backgroundColor={tokens.color.White.val}
        borderRadius={tokens.space.sm.val}
        mx="$xl"
        maxHeight={maxModalHeight}
      >
        <ScrollView
          testID="modal-scroll-view"
          scrollEnabled={isScrollable}
          contentContainerStyle={{ padding: tokens.space.xl.val }}
          onLayout={(e) => {
            setIsScrollable(maxModalHeight <= e.nativeEvent.layout.height);
          }}
        >
          {!!title && (
            <Text
              testID="modal-title"
              tamaguiTextProps={{ mb: tokens.space.sm.val }}
              fontVariant="heading4-semibold-Secondary800"
            >
              {title}
            </Text>
          )}
          {children}
        </ScrollView>
      </Stack>
    </Modal>
  );
};
