import { styled, XStack, YStack } from 'tamagui';

const TransactionListItemContainer = styled(YStack, {
  backgroundColor: '$White',
  padding: '$xl',
  flexDirection: 'row',
  justifyContent: 'space-between',
});

const TransactionListItemLeft = styled(XStack, {
  flexDirection: 'column',
});

const TransactionListItemRight = styled(XStack, {
  alignSelf: 'center',
});

export {
  TransactionListItemContainer,
  TransactionListItemLeft,
  TransactionListItemRight,
};
