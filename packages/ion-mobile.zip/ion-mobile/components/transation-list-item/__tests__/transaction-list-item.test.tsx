import { render, screen } from '@src/jest/testing-library';

import { TransactionListItem } from '../transaction-list-item';

const props = {
  date: 'today',
  transferType: 'transfer in',
  transferValue: '+£1,000,000.00',
};

describe('Testing the information tab screen', () => {
  it('should render whole component', () => {
    render(<TransactionListItem {...props} />);

    const container = screen.getByTestId('transaction-list-item');
    expect(container).toBeOnTheScreen();
  });

  it('should render the date, transfer type and value', () => {
    render(<TransactionListItem {...props} />);

    const [date, type, value] = screen.queryAllByRole('text');
    expect(date).toHaveTextContent('today');
    expect(type).toHaveTextContent('transfer in');
    expect(value).toHaveTextContent('+£1,000,000.00');
  });
});
