import { Text } from '../text';
import {
  TransactionListItemContainer,
  TransactionListItemLeft,
  TransactionListItemRight,
} from './transaction-list-item.style';

export type TransactionListItemProps = {
  date?: string;
  transferType?: string;
  transferValue: string;
  onPress?: () => void;
};

export const TransactionListItem = ({
  date,
  transferType,
  transferValue,
  onPress,
}: TransactionListItemProps) => {
  return (
    <TransactionListItemContainer
      testID="transaction-list-item"
      onPress={onPress}
      accessibilityLabel={`${date}, ${transferType}, ${transferValue}`}
      accessible
    >
      <TransactionListItemLeft>
        <Text
          tamaguiTextProps={{
            letterSpacing: 1,
            paddingBottom: '$md',
          }}
          fontVariant="small-regular-Gray500"
        >
          {date}
        </Text>
        <Text
          tamaguiTextProps={{ letterSpacing: 1 }}
          fontVariant="small-semibold-Gray900"
        >
          {transferType}
        </Text>
      </TransactionListItemLeft>
      <TransactionListItemRight>
        <Text
          tamaguiTextProps={{
            letterSpacing: 1,
          }}
          fontVariant="heading3-semibold-Gray800"
        >
          {transferValue}
        </Text>
      </TransactionListItemRight>
    </TransactionListItemContainer>
  );
};
