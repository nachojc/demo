import { vehicleImageMapper } from '../vehicle-image-mapper';

describe('vehicleImageMapper', () => {
  it('should return undefined when no image exists for manufacturer', () => {
    const imageAsset = vehicleImageMapper('sausages');
    expect(imageAsset).toBeUndefined();
  });

  it.each`
    manufacturer
    ${'Alfa Romeo'}
    ${'Aston Martin'}
    ${'Audi'}
    ${'Bentley'}
    ${'BMW'}
    ${'Chevrolet'}
    ${'Chrysler'}
    ${'Citroen'}
    ${'Dacia'}
    ${'Daewoo'}
    ${'Daihatsu'}
    ${'Datsun'}
    ${'Ferrari'}
    ${'Fiat'}
    ${'Ford'}
    ${'Honda'}
    ${'Hyundai'}
    ${'Jaguar'}
    ${'Jeep'}
    ${'Kia'}
    ${'Lamborghini'}
    ${'Lancia'}
    ${'Land Rover'}
    ${'Lexus'}
    ${'Lotus'}
    ${'Mazda'}
    ${'Mercedes-Benz'}
    ${'MG'}
    ${'Mini'}
    ${'Mitsubishi'}
    ${'Nissan'}
    ${'Opel'}
    ${'Peugeot'}
    ${'Porsche'}
    ${'Renault'}
    ${'Rover'}
    ${'Saab'}
    ${'Seat'}
    ${'Skoda'}
    ${'Smart'}
    ${'Ssangyong'}
    ${'Subaru'}
    ${'Suzuki'}
    ${'Tesla'}
    ${'Toyota'}
    ${'Vauxhall'}
    ${'Volvo'}
    ${'Volkswagen'}
  `(
    'should return defined image for manufacturer $manufacturer',
    ({ manufacturer }) => {
      const imageAsset = vehicleImageMapper(manufacturer);
      expect(imageAsset).toBeDefined();
    }
  );
});
