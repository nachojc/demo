import { render, screen } from '@src/jest/testing-library';

import { VehicleDetailHeader } from '../vehicle-detail-header';

const TestVehicleDetailHeader = () => {
  return (
    <VehicleDetailHeader
      manufacturer="Volkswagen"
      model="Golf VR6 Highline"
      registrationNumber="R476 LGJ"
    />
  );
};

describe('Testing VehicleDetailHeader', () => {
  it('renders header items correctly', async () => {
    render(<TestVehicleDetailHeader />);

    expect(await screen.findByText('Volkswagen')).toBeOnTheScreen();
    expect(await screen.findByText('Golf VR6 Highline')).toBeOnTheScreen();
    expect(await screen.findByText('R476 LGJ')).toBeOnTheScreen();
  });
});
