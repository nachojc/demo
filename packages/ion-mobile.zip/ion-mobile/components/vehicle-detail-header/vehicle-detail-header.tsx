import { Image } from '../image';
import { Text } from '../text';
import {
  ContentContainer,
  LeftContainer,
  RegistrationContainer,
  RightContainer,
} from './vehicle-detail-header.style';
import { vehicleImageMapper } from './vehicle-image-mapper';

type ImageProps = {
  manufacturer: string;
};

type RegistrationProps = {
  registrationNumber: string;
};

export type VehicleDetailHeaderProps = {
  manufacturer: string;
  model: string;
  registrationNumber: string;
};

export const VehicleDetailHeader = ({
  manufacturer,
  model,
  registrationNumber,
}: VehicleDetailHeaderProps) => (
  <ContentContainer>
    <LeftContainer>
      <Text fontVariant="heading3-bold-Secondary800">{manufacturer}</Text>
      <Text fontVariant="heading5-regular-Gray800">{model}</Text>
      <RegistrationPlate registrationNumber={registrationNumber} />
    </LeftContainer>

    <RightContainer>
      <ManufacturerImageContent manufacturer={manufacturer} />
    </RightContainer>
  </ContentContainer>
);

const ManufacturerImageContent = ({ manufacturer }: ImageProps) => {
  const imageSize = 84;
  const imageAsset = vehicleImageMapper(manufacturer);

  return (
    <Image
      accessibilityIgnoresInvertColors
      style={{
        width: imageSize,
        height: imageSize,
      }}
      source={imageAsset}
    />
  );
};

const RegistrationPlate = ({ registrationNumber }: RegistrationProps) => {
  return (
    <RegistrationContainer>
      <Text fontVariant="small-bold-Gray800">{registrationNumber}</Text>
    </RegistrationContainer>
  );
};
