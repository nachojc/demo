const imageLookup = new Map<string, number>([
  ['alfa', require('assets/vehicle-manufacturer/alfa.webp')],
  ['aston', require('assets/vehicle-manufacturer/aston.webp')],
  ['audi', require('assets/vehicle-manufacturer/audi.webp')],
  ['bentley', require('assets/vehicle-manufacturer/bentley.webp')],
  ['bmw', require('assets/vehicle-manufacturer/bmw.webp')],
  ['chevrolet', require('assets/vehicle-manufacturer/chevrolet.webp')],
  ['chrysler', require('assets/vehicle-manufacturer/chrysler.webp')],
  ['citroen', require('assets/vehicle-manufacturer/citroen.webp')],
  ['dacia', require('assets/vehicle-manufacturer/dacia.webp')],
  ['daewoo', require('assets/vehicle-manufacturer/daewoo.webp')],
  ['daihatsu', require('assets/vehicle-manufacturer/daihatsu.webp')],
  ['datsun', require('assets/vehicle-manufacturer/datsun.webp')],
  ['ferrari', require('assets/vehicle-manufacturer/ferrari.webp')],
  ['fiat', require('assets/vehicle-manufacturer/fiat.webp')],
  ['ford', require('assets/vehicle-manufacturer/ford.webp')],
  ['honda', require('assets/vehicle-manufacturer/honda.webp')],
  ['hyundai', require('assets/vehicle-manufacturer/hyundai.webp')],
  ['jaguar', require('assets/vehicle-manufacturer/jaguar.webp')],
  ['jeep', require('assets/vehicle-manufacturer/jeep.webp')],
  ['kia', require('assets/vehicle-manufacturer/kia.webp')],
  ['lamborghini', require('assets/vehicle-manufacturer/lamborghini.webp')],
  ['lancia', require('assets/vehicle-manufacturer/lancia.webp')],
  ['land', require('assets/vehicle-manufacturer/land.webp')],
  ['lexus', require('assets/vehicle-manufacturer/lexus.webp')],
  ['lotus', require('assets/vehicle-manufacturer/lotus.webp')],
  ['mazda', require('assets/vehicle-manufacturer/mazda.webp')],
  ['mercedes-benz', require('assets/vehicle-manufacturer/mercedes-benz.webp')],
  ['mg', require('assets/vehicle-manufacturer/mg.webp')],
  ['mini', require('assets/vehicle-manufacturer/mini.webp')],
  ['mitsubishi', require('assets/vehicle-manufacturer/mitsubishi.webp')],
  ['nissan', require('assets/vehicle-manufacturer/nissan.webp')],
  ['opel', require('assets/vehicle-manufacturer/opel.webp')],
  ['peugeot', require('assets/vehicle-manufacturer/peugeot.webp')],
  ['porsche', require('assets/vehicle-manufacturer/porsche.webp')],
  ['renault', require('assets/vehicle-manufacturer/renault.webp')],
  ['rover', require('assets/vehicle-manufacturer/rover.webp')],
  ['saab', require('assets/vehicle-manufacturer/saab.webp')],
  ['seat', require('assets/vehicle-manufacturer/seat.webp')],
  ['skoda', require('assets/vehicle-manufacturer/skoda.webp')],
  ['smart', require('assets/vehicle-manufacturer/smart.webp')],
  ['ssangyong', require('assets/vehicle-manufacturer/ssangyong.webp')],
  ['subaru', require('assets/vehicle-manufacturer/subaru.webp')],
  ['suzuki', require('assets/vehicle-manufacturer/suzuki.webp')],
  ['tesla', require('assets/vehicle-manufacturer/tesla.webp')],
  ['toyota', require('assets/vehicle-manufacturer/toyota.webp')],
  ['vauxhall', require('assets/vehicle-manufacturer/vauxhall.webp')],
  ['volvo', require('assets/vehicle-manufacturer/volvo.webp')],
  ['volkswagen', require('assets/vehicle-manufacturer/volkswagen.webp')],
]);

export const vehicleImageMapper = (
  manufacturer: string
): number | undefined => {
  const lookupKey = manufacturer
    .split(' ')
    .find((x) => x !== undefined)
    ?.toLowerCase();

  return lookupKey && imageLookup.has(lookupKey)
    ? imageLookup.get(lookupKey)
    : undefined;
};
