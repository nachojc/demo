import { Stack, styled, XStack, YStack } from 'tamagui';

const ContentContainer = styled(XStack, {
  padding: '$xl',
});

const LeftContainer = styled(YStack, {
  justifyContent: 'flex-start',
  flex: 1,
});

const RightContainer = styled(YStack, {
  justifyContent: 'center',
});

const RegistrationContainer = styled(Stack, {
  paddingHorizontal: '$lg',
  paddingVertical: '$xs',
  marginTop: '$md',
  alignSelf: 'flex-start',
  bg: '$White',
  borderColor: '$Gray800',
  borderWidth: 1,
  borderRadius: 2,
});

export {
  ContentContainer,
  LeftContainer,
  RegistrationContainer,
  RightContainer,
};
