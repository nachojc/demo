export * from './vehicle-detail-header';
