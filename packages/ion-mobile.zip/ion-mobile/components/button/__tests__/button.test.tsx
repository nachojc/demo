import { fireEvent, render, screen } from '@src/jest/testing-library';

import { Button } from '../index';

describe('Button', () => {
  it('should render button with default configuration', () => {
    render(<Button>Press Me</Button>);

    expect(screen.getByText('Press Me')).toBeDefined();
  });

  it('should call onPress when the button is pressed', () => {
    const mockOnPress = jest.fn();
    render(<Button onPress={mockOnPress}>Press Me</Button>);

    fireEvent.press(screen.getByRole('button'));

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  // This test fails, the issue may be in Tamagui (try to replace TamaguiButton with Pressable and it'll pass)
  it.skip('should not call onPress when the button is disabled', () => {
    const mockOnPress = jest.fn();
    render(
      <Button onPress={mockOnPress} disabled>
        Press Me
      </Button>
    );

    fireEvent.press(screen.getByRole('button'));

    expect(mockOnPress).not.toHaveBeenCalled();
  });

  describe('accessibility', () => {
    it('should set the accessibility label of the button based on props if passed', () => {
      render(
        <Button accessibilityLabel="override">AccessibilityLabelTest</Button>
      );

      expect(screen.getAllByLabelText('override')).toHaveLength(1);
    });

    it('correctly render accessibility state', () => {
      render(
        <>
          <Button testID="btn-normal" />
          <Button testID="btn-disabled" disabled />
          <Button
            testID="btn-state"
            disabled
            accessibilityState={{ checked: true }}
          />
        </>
      );

      expect(screen.getByTestId('btn-normal')).toHaveAccessibilityState({
        disabled: undefined,
      });
      expect(screen.getByTestId('btn-disabled')).toHaveAccessibilityState({
        disabled: true,
      });
      expect(screen.getByTestId('btn-state')).toHaveAccessibilityState({
        checked: true,
      });
    });
  });
});
