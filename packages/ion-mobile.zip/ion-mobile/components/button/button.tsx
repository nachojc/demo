import { forwardRef } from 'react';
import { PressableAndroidRippleConfig } from 'react-native/types';
import {
  Button as TamaguiButton,
  ButtonProps as TamaguiButtonProps,
  ButtonText,
  styled,
  TamaguiElement,
} from 'tamagui';
import { ValueOf } from 'type-fest';

export type ButtonVariant = ValueOf<typeof ButtonVariant>;
export const ButtonVariant = {
  BRAND: 'brand',
  SUB_BRAND: 'subBrand',
  OUTLINED: 'outlined',
  OUTLINED_WHITE: 'outlinedWhite',
  OUTLINED_ERROR: 'outlinedError',
  LINK_TEXT: 'linkText',
  SUB_BRAND_LINK: 'subBrandLink',
  DIRECT_WEALTH: 'directWealth',
  QUICK_LINKS: 'quickLinks',
} as const;

const disabledStyles = {
  backgroundColor: '$Gray200',
  android_ripple: { color: '$Gray200' },
  pressStyle: { backgroundColor: '$Gray200' },
};

const variants: Record<
  ButtonVariant,
  TamaguiButtonProps & {
    android_ripple?: PressableAndroidRippleConfig;
  }
> = {
  [ButtonVariant.BRAND]: {
    backgroundColor: '$Primary500',
    android_ripple: { color: '$Primary600' },
    pressStyle: { backgroundColor: '$Primary600' },
  },
  [ButtonVariant.SUB_BRAND]: {
    backgroundColor: '$SubBrandPrimary',
    android_ripple: { color: '$SubBrandAccent' },
    pressStyle: { backgroundColor: '$SubBrandAccent' },
  },
  [ButtonVariant.OUTLINED]: {
    backgroundColor: 'transparent',
    borderColor: '$Secondary800',
    borderStyle: 'solid',
    borderWidth: '$xxs',
    android_ripple: { color: '$Gray200' },
    pressStyle: { backgroundColor: '$Gray200' },
  },
  [ButtonVariant.OUTLINED_WHITE]: {
    backgroundColor: 'transparent',
    borderColor: '$White',
    borderStyle: 'solid',
    borderWidth: '$xxs',
  },
  [ButtonVariant.OUTLINED_ERROR]: {
    backgroundColor: 'transparent',
    borderColor: '$Error',
    borderStyle: 'solid',
    borderWidth: '$xxs',
    android_ripple: { color: '$Gray200' },
    pressStyle: { backgroundColor: '$Gray200' },
  },
  [ButtonVariant.LINK_TEXT]: {
    backgroundColor: 'transparent',
    android_ripple: { color: '$Gray200' },
    pressStyle: { backgroundColor: 'transparent' },
  },
  [ButtonVariant.SUB_BRAND_LINK]: {
    backgroundColor: 'transparent',
    android_ripple: { color: '$Gray200' },
    pressStyle: { backgroundColor: 'transparent' },
  },
  [ButtonVariant.DIRECT_WEALTH]: {
    backgroundColor: '$DWPrimary500',
    android_ripple: { color: '$DWPrimary500' },
    pressStyle: { backgroundColor: '$DWPrimary500' },
  },
  [ButtonVariant.QUICK_LINKS]: {
    backgroundColor: '$Teal600',
    android_ripple: { color: '$White' },
    pressStyle: { backgroundColor: '$Teal600' },
  },
};

const StyledButtonText = styled(ButtonText, {
  color: '$Secondary800',
  fontFamily: '$body',
  fontSize: '$body',
  fontWeight: '600',

  variants: {
    variant: {
      [ButtonVariant.BRAND]: {},
      [ButtonVariant.OUTLINED]: {},
      [ButtonVariant.SUB_BRAND]: {
        color: '$SubBrandContrast',
      },
      [ButtonVariant.LINK_TEXT]: {
        color: '$Tertiary800',
      },
      [ButtonVariant.SUB_BRAND_LINK]: {
        color: '$SubBrandLink',
      },
      [ButtonVariant.OUTLINED_ERROR]: {
        color: '$Error',
      },
      [ButtonVariant.DIRECT_WEALTH]: {
        color: '$DWPrimary500',
      },
      [ButtonVariant.QUICK_LINKS]: {
        color: '$White',
      },
      [ButtonVariant.OUTLINED_WHITE]: {
        color: '$White',
      },
    },
  },
  defaultVariants: {
    variant: ButtonVariant.BRAND,
  },
});

export type ButtonProps = Omit<TamaguiButtonProps, 'variant'> & {
  variant?: ButtonVariant;
  useStyledButtonText?: boolean;
};

export const Button = forwardRef<TamaguiElement, ButtonProps>(
  ({ children, variant, useStyledButtonText = true, size, ...rest }, ref) => {
    const variantBtnProps = variants[variant ?? 'brand'];
    return (
      <TamaguiButton
        size={size}
        ref={ref}
        accessibilityRole="button"
        accessible
        alignItems="center"
        borderRadius={55}
        borderWidth={0}
        height="$9"
        justifyContent="center"
        accessibilityState={
          rest.accessibilityState ?? {
            disabled: rest.disabled,
          }
        }
        {...variantBtnProps}
        {...(rest.disabled && disabledStyles)}
        {...rest}
      >
        {useStyledButtonText ? (
          <StyledButtonText variant={variant}>{children}</StyledButtonText>
        ) : (
          children
        )}
      </TamaguiButton>
    );
  }
);

Button.displayName = 'Button';
