import {
  A11yCount,
  NotificationCard,
  RadioButton,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { spellOutString } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';

import { CardContainer } from '../cards/base-card/base-card.style';

type BankDetails = {
  bankName: string;
  sortCode: string;
  accountNumber: string;
  accountName: string;
};

type BankRadioCardProps = {
  selected?: boolean;
  onSelect: () => void;
  bankDetails: BankDetails;
  errorMessage?: string;
  disabled?: boolean;
} & A11yCount;

export const BankRadioCard = ({
  selected,
  onSelect,
  disabled = false,
  bankDetails,
  a11yOpts,
  errorMessage,
}: BankRadioCardProps) => {
  const { t } = useTranslation();

  const [isSelected, setIsSelected] = useState(selected);

  const content = [
    { title: t('bankRadioCard.sortCode'), description: bankDetails.sortCode },
    {
      title: t('bankRadioCard.accountNumber'),
      description: bankDetails.accountNumber,
    },
    {
      title: t('bankRadioCard.accountName'),
      description: bankDetails.accountName,
    },
  ];

  const accessibilityLabel = `${t('bankRadioCard.listItem', a11yOpts)} ${
    bankDetails.bankName
  }. ${content[0].title} ${spellOutString(content[0].description)}. ${
    content[1].title
  } ${spellOutString(content[1].description)}. ${content[2].title} ${
    content[2].description
  }${errorMessage ? ' ' + errorMessage : ''}`;

  const { elementRef, focus } = useA11yFocus();

  const onPress = () => {
    setIsSelected(true);
    onSelect();
  };

  useEffect(() => {
    setIsSelected(selected);
    if (selected) {
      focus();
    }
  }, [selected]);

  return (
    <CardContainer
      testID={getTestId('bank-radio-card')}
      showBorder
      borderColor={isSelected ? '$Success' : '$Gray300'}
      selected={isSelected}
      disabled={disabled}
      error={!!errorMessage && isSelected}
      onPress={onPress}
      accessibilityLabel={`${
        isSelected
          ? t('bankRadioCard.selectedAccessibility')
          : t('bankRadioCard.notSelectedAccessibility')
      }. ${accessibilityLabel}${
        isSelected ? '' : t('bankRadioCard.notSelectedAccessibilitySubfix')
      }`}
      accessibilityRole="radio"
      accessibilityState={{ disabled }}
      role="radio"
      ref={elementRef}
    >
      <YStack space={'$xl'} flex={1}>
        <XStack
          accessibilityElementsHidden
          importantForAccessibility="no-hide-descendants"
          space={'$lg'}
        >
          <RadioButton
            testID="bank-radio-card-radiobutton"
            selected={!!isSelected}
            error={!!errorMessage && isSelected}
            disabled={disabled}
            onPress={onPress}
          />
          <YStack space={'$md'}>
            <Text fontVariant="body-semibold-Gray800">
              {bankDetails.bankName}
            </Text>
            {content.map((item) => (
              <YStack key={`${item.title}-${item.description}`}>
                <Text fontVariant="small-regular-Gray800">{item.title}</Text>
                <Text fontVariant="body-semibold-Secondary800">
                  {item.description}
                </Text>
              </YStack>
            ))}
          </YStack>
        </XStack>
        {errorMessage && (
          <NotificationCard
            iconVariant="error"
            backgroundColor={'$ErrorTint'}
            showBorder={false}
            subtitle={errorMessage}
            borderRadius="$1"
          />
        )}
      </YStack>
    </CardContainer>
  );
};
