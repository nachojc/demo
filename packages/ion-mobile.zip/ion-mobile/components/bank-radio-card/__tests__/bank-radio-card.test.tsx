import { fireEvent, render, screen } from '@src/jest/testing-library';

import { BankRadioCard } from '../bank-radio-card';

const selectedColor = '#4F9F31';
const unselectedColor = '#CCCCCC';
const radioUnselectedColor = '#7E7E7E';

const mockBankDetails = {
  bankName: 'Lloyds Bank',
  sortCode: '12-34-56',
  accountNumber: '1234567890',
  accountName: 'Jane Smith',
};

const mockOnSelect = jest.fn();

const renderComponent = (
  selected: boolean,
  errorMessage?: string,
  onSelect: () => void = mockOnSelect
) => {
  return render(
    <BankRadioCard
      selected={selected}
      bankDetails={mockBankDetails}
      onSelect={onSelect}
      a11yOpts={{
        item: 1,
        total: 1,
      }}
      errorMessage={errorMessage}
    />
  );
};

describe('BankRadioCard', () => {
  it('should display the component content correctly', () => {
    renderComponent(true);

    const expectedTexts = [
      'Sort code:',
      'Account number:',
      'Account name:',
      'Lloyds Bank',
      '12-34-56',
      '1234567890',
      'Jane Smith',
    ];

    expectedTexts.forEach((text) => {
      expect(
        screen.getByText(text, {
          includeHiddenElements: true,
        })
      ).toBeOnTheScreen();
    });
  });

  it('should display the component in selected state', () => {
    renderComponent(true);

    const baseCard = screen.getByTestId('test:id/bank-radio-card');
    expect(baseCard).toHaveStyle({
      borderTopColor: selectedColor,
      borderRightColor: selectedColor,
      borderLeftColor: selectedColor,
      borderBottomColor: selectedColor,
    });

    const radioButton = screen.getByTestId('bank-radio-card-radiobutton', {
      includeHiddenElements: true,
    });
    expect(radioButton).toHaveStyle({
      borderTopColor: selectedColor,
      borderRightColor: selectedColor,
      borderLeftColor: selectedColor,
      borderBottomColor: selectedColor,
    });
  });

  it('should display the component in unselected state', () => {
    renderComponent(false);

    const baseCard = screen.getByTestId('test:id/bank-radio-card');
    expect(baseCard).toHaveStyle({
      borderTopColor: unselectedColor,
      borderRightColor: unselectedColor,
      borderLeftColor: unselectedColor,
      borderBottomColor: unselectedColor,
    });

    const radioButton = screen.getByTestId('bank-radio-card-radiobutton', {
      includeHiddenElements: true,
    });
    expect(radioButton).toHaveStyle({
      borderTopColor: radioUnselectedColor,
      borderRightColor: radioUnselectedColor,
      borderLeftColor: radioUnselectedColor,
      borderBottomColor: radioUnselectedColor,
    });
  });

  it('should display the change of component from unselected state to selected state when tapping the component', () => {
    renderComponent(false);

    const baseCard = screen.getByTestId('test:id/bank-radio-card');
    expect(baseCard).toHaveStyle({
      borderTopColor: unselectedColor,
      borderRightColor: unselectedColor,
      borderLeftColor: unselectedColor,
      borderBottomColor: unselectedColor,
    });

    const radioButton = screen.getByTestId('bank-radio-card-radiobutton', {
      includeHiddenElements: true,
    });
    expect(radioButton).toHaveStyle({
      borderTopColor: radioUnselectedColor,
      borderRightColor: radioUnselectedColor,
      borderLeftColor: radioUnselectedColor,
      borderBottomColor: radioUnselectedColor,
    });

    fireEvent.press(baseCard);

    expect(baseCard).toHaveStyle({
      borderTopColor: selectedColor,
      borderRightColor: selectedColor,
      borderLeftColor: selectedColor,
      borderBottomColor: selectedColor,
    });

    expect(radioButton).toHaveStyle({
      borderTopColor: selectedColor,
      borderRightColor: selectedColor,
      borderLeftColor: selectedColor,
      borderBottomColor: selectedColor,
    });
  });

  it('should fire the onSelect event when tapping the component', () => {
    renderComponent(true);

    const baseCard = screen.getByTestId('test:id/bank-radio-card');
    fireEvent.press(baseCard);
    expect(mockOnSelect).toHaveBeenNthCalledWith(1);
  });

  it('should fire the onSelect event when tapping the radio button', () => {
    renderComponent(true);

    const radioButton = screen.getByTestId('bank-radio-card-radiobutton', {
      includeHiddenElements: true,
    });
    fireEvent.press(radioButton);
    expect(mockOnSelect).toHaveBeenNthCalledWith(1);
  });

  it('should have the correct accessibility without error message', () => {
    renderComponent(true);

    const baseCard = screen.getByTestId('test:id/bank-radio-card');

    expect(baseCard).toHaveProp(
      'accessibilityLabel',
      'Selected. Bank account 1 of 1. Lloyds Bank. Sort code: 1 2 3 4 5 6. Account number: 1 2 3 4 5 6 7 8 9 0. Account name: Jane Smith'
    );
  });

  it('should have the correct accessibility for radio card that is not selected', () => {
    renderComponent(false);

    const baseCard = screen.getByTestId('test:id/bank-radio-card');

    expect(baseCard).toHaveProp(
      'accessibilityLabel',
      'Not selected. Bank account 1 of 1. Lloyds Bank. Sort code: 1 2 3 4 5 6. Account number: 1 2 3 4 5 6 7 8 9 0. Account name: Jane Smith. Double tap to select'
    );
  });

  it('should have the correct accessibility with error message', () => {
    renderComponent(true, 'error message testing');

    const baseCard = screen.getByTestId('test:id/bank-radio-card');

    expect(baseCard).toHaveProp(
      'accessibilityLabel',
      'Selected. Bank account 1 of 1. Lloyds Bank. Sort code: 1 2 3 4 5 6. Account number: 1 2 3 4 5 6 7 8 9 0. Account name: Jane Smith error message testing'
    );
  });
});
