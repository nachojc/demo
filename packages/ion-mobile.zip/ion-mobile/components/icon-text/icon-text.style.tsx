import { styled, YStack } from 'tamagui';

export const TextIconContainer = styled(YStack, {
  flexDirection: 'row',
  paddingVertical: '$md',
});

export const TextIconContainerLeft = styled(YStack, {
  paddingRight: '$xl',
  maxHeight: '$xxl',
  justifyContent: 'center',
});
