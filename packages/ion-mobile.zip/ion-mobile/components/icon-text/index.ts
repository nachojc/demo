export * from './icon-text';
