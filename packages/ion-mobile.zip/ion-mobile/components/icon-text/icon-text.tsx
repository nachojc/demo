import { ColorValue, FlexAlignType } from 'react-native';
import { YStack } from 'tamagui';

import { Icon, IconName } from '../icon/icon';
import { FontVariant, Text } from '../text';
import { TextIconContainer, TextIconContainerLeft } from './icon-text.style';

type TextIconProps = {
  alignRight?: boolean;
  alignIcon?: 'auto' | FlexAlignType;
  description?: string | React.ReactNode;
  descriptionAccessibilityLabel?: string;
  fontVariant?: FontVariant;
  iconColor?: ColorValue;
  iconName: IconName;
  iconSizeOption: keyof typeof iconSize;
  subtitle?: string;
  textColor?: ColorValue;
  title?: string;
  titleFontVariant?: FontVariant;
  accessible?: boolean;
};

const iconSize = {
  small: 8,
  medium: 16,
  large: 20,
  larger: 24,
  xlarge: 26,
};

export const IconText = ({
  alignRight,
  alignIcon,
  description,
  descriptionAccessibilityLabel,
  fontVariant = 'body-regular-Gray800',
  iconColor,
  iconName,
  iconSizeOption,
  subtitle,
  title,
  titleFontVariant,
  accessible = true,
}: TextIconProps) => {
  return (
    <TextIconContainer
      testID="icon-text-card"
      accessible={accessible}
      importantForAccessibility="yes"
    >
      <TextIconContainerLeft alignSelf={alignIcon}>
        <Icon
          name={iconName}
          width={iconSize[iconSizeOption]}
          height={iconSize[iconSizeOption]}
          color={iconColor}
          accessibilityLabel={iconAccessibilityLabels[iconName]}
        />
      </TextIconContainerLeft>
      <YStack flex={alignRight ? 0 : 1}>
        {title && (
          <Text
            tamaguiTextProps={{ lineHeight: 20, marginBottom: 8 }}
            fontVariant={titleFontVariant || fontVariant}
          >
            {title}
          </Text>
        )}
        {subtitle && (
          <Text tamaguiTextProps={{ lineHeight: 20 }} fontVariant={fontVariant}>
            {subtitle}
          </Text>
        )}
        {description && typeof description === 'string' ? (
          <Text
            tamaguiTextProps={{
              lineHeight: 20,
              accessibilityLabel: descriptionAccessibilityLabel,
            }}
            fontVariant={fontVariant}
          >
            {description}
          </Text>
        ) : (
          description
        )}
      </YStack>
    </TextIconContainer>
  );
};

const iconAccessibilityLabels: Partial<Record<IconName, string>> = {
  'alert-circle': 'alert,',
  'alert-circle-outline': 'alert,',
};
