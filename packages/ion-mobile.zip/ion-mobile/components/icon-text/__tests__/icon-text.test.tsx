import { render, screen } from '@src/jest/testing-library';

import { IconText } from '../icon-text';

const iconTestID = 'test:id/icon-tick';

it('should render the titleBold, titleSemiBold, content and the icon', () => {
  render(
    <IconText
      iconSizeOption="large"
      iconName="tick"
      title="title"
      description="description"
    />
  );
  const icon = screen.getByTestId(iconTestID, {
    includeHiddenElements: true,
  });
  const [title, description] = screen.getAllByRole('text');

  expect(icon).toBeOnTheScreen();
  expect(title).toHaveTextContent('title');
  expect(description).toHaveTextContent('description');
});

it('should render only icon with title', () => {
  render(<IconText iconSizeOption="large" iconName="tick" title="title" />);
  const icon = screen.getByTestId(iconTestID, {
    includeHiddenElements: true,
  });
  const [title, description] = screen.getAllByRole('text');

  expect(icon).toBeOnTheScreen();
  expect(title).toHaveTextContent('title');
  expect(description).toBeUndefined();
});

it('should render only icon with subtitle', () => {
  render(
    <IconText iconSizeOption="large" iconName="tick" subtitle="subtitle" />
  );
  const icon = screen.getByTestId(iconTestID, {
    includeHiddenElements: true,
  });
  const [subtitle, title] = screen.getAllByRole('text');

  expect(icon).toBeOnTheScreen();
  expect(title).toBeUndefined();
  expect(subtitle).toHaveTextContent('subtitle');
});

it('should render only icon with description', () => {
  render(
    <IconText
      iconSizeOption="large"
      iconName="tick"
      description="description"
    />
  );
  const icon = screen.getByTestId(iconTestID, {
    includeHiddenElements: true,
  });
  const [description, title] = screen.getAllByRole('text');

  expect(icon).toBeOnTheScreen();
  expect(title).toBeUndefined();
  expect(description).toHaveTextContent('description');
});

it('should render only icon with title, subtitle or descripition', () => {
  render(
    <IconText
      iconSizeOption="large"
      iconName="tick"
      title=""
      subtitle=""
      description=""
    />
  );
  const icon = screen.getByTestId(iconTestID, {
    includeHiddenElements: true,
  });
  const [title, subtitle, description] = screen.queryAllByRole('text');

  expect(icon).toBeOnTheScreen();
  expect(title).toBeUndefined();
  expect(subtitle).toBeUndefined();
  expect(description).toBeUndefined();
});
