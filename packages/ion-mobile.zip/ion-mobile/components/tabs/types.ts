import { ReactNode } from 'react';
import {
  Route,
  SceneRendererProps,
  TabBarProps as RNTabBarProps,
  TabViewProps as RNTabViewProps,
} from 'react-native-tab-view';

export type TabRoute = Route & {
  title: string;
  // react-native-collapsible-tab-view want's ReactNode
  // and react-native-tab-view  want's React.ComponentType
  component: () => ReactNode;
};

export type TabBarColorSetup = {
  backgroundColor: string;
  indicator: string;
  text: string;
  pressColor: string;
  inactiveColor: string;
};
export type TabBarVariant = 'white' | 'blue' | 'dwBlue' | 'yellow' | 'plain';
export type TabBarProps = RNTabBarProps<TabRoute>;
export type TabBarStyles = Pick<
  TabBarProps,
  | 'activeColor'
  | 'inactiveColor'
  | 'pressColor'
  | 'indicatorStyle'
  | 'style'
  | 'labelStyle'
>;

export type BaseTabsProps = {
  tabRoutes: TabRoute[];
  tabBarScrollEnabled?: boolean;
  tabBarVariant?: TabBarVariant;
  lazy?: boolean;
  tabsAlign?: boolean;
  onTabChange?: (name: string) => void;
  onTabPress?: (name: string) => void;
  onIndexChange?: (index: number) => void;
};

export type TabsProps = BaseTabsProps &
  Pick<TabBarProps, 'tabStyle'> &
  Omit<
    RNTabViewProps<TabRoute>,
    'navigationState' | 'renderScene' | 'onIndexChange'
  >;

export type RenderSceneProps = SceneRendererProps & { route: TabRoute };
