import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useWindowDimensions } from 'react-native';
import { SceneMap, TabView } from 'react-native-tab-view';

import { tabAccessibilityLabel } from './helpers';
import { TabBar } from './tab-bar';
import { TabRoute, TabsProps } from './types';

export const Tabs = ({
  lazy,
  tabRoutes,
  tabBarScrollEnabled,
  tabBarVariant,
  onTabChange,
  onIndexChange,
  tabStyle,
  ...props
}: TabsProps) => {
  const { t } = useTranslation();
  const [index, setIndex] = useState(0);
  const { width } = useWindowDimensions();

  const routesMap: TabRoute[] = tabRoutes.map(
    ({ key, title, component }, i) => {
      return {
        key,
        title,
        testID: `test:id/${title.toLowerCase()}`,
        accessibilityLabel: tabAccessibilityLabel(
          t,
          i + 1,
          title,
          tabRoutes.length
        ),
        component,
      };
    }
  );

  const keys = routesMap.map((route) => route.key);
  const sceneMapper = Object.fromEntries(
    keys.map((_, i) => [keys[i], routesMap[i].component])
  );

  const renderScene = SceneMap(sceneMapper);

  return (
    <TabView
      {...props}
      lazy={lazy}
      navigationState={{ index, routes: routesMap }}
      renderScene={renderScene}
      renderTabBar={(tabBarProps) => (
        <TabBar
          {...tabBarProps}
          tabStyle={tabStyle}
          theme={tabBarVariant}
          scrollEnabled={tabBarScrollEnabled}
          onTabPress={({ route }) => onTabChange?.(route.title)}
        />
      )}
      onIndexChange={(tabIndex) => {
        onIndexChange?.(tabIndex);
        setIndex(tabIndex);
      }}
      initialLayout={{ width }}
    />
  );
};
