import { tokens } from '@src/theme/tokens';

import { TabBarColorSetup, TabBarStyles, TabBarVariant } from './types';

const tabColors: Record<TabBarVariant, TabBarColorSetup> = {
  white: {
    backgroundColor: tokens.color.White.val,
    indicator: tokens.color.Secondary800.val,
    text: tokens.color.Secondary800.val,
    pressColor: tokens.color.Gray200.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
  },
  blue: {
    backgroundColor: tokens.color.Secondary800.val,
    indicator: tokens.color.Primary500.val,
    text: tokens.color.White.val,
    pressColor: tokens.color.Gray200.val,
    inactiveColor: tokens.color.WhiteOpacity67.val,
  },
  dwBlue: {
    backgroundColor: tokens.color.WealthBlue.val,
    indicator: tokens.color.Primary500.val,
    text: tokens.color.White.val,
    pressColor: tokens.color.Gray200.val,
    inactiveColor: tokens.color.WhiteOpacity67.val,
  },
  // TODO: Check this variant is used or not
  yellow: {
    backgroundColor: tokens.color.Primary500.val,
    indicator: tokens.color.Secondary800.val,
    text: tokens.color.Secondary800.val,
    pressColor: tokens.color.Primary600.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
  },
  // TODO: Do we need this?
  // pensions: {
  //   bg: tokens.color.Secondary800.val,
  //   indicator: tokens.color.Primary500.val,
  //   text: tokens.color.White.val,
  //   pressColor: tokens.color.Primary500.val,
  //   inactiveColor: tokens.color.WhiteOpacity50.val,
  // },
  plain: {
    backgroundColor: tokens.color.White.val,
    indicator: tokens.color.Primary500.val,
    text: tokens.color.Secondary800.val,
    pressColor: tokens.color.Gray200.val,
    inactiveColor: tokens.color.Secondary800Opacity67.val,
  },
};

export const getTabBarStyles = (theme: TabBarVariant) => {
  const tabHeaderColors = tabColors[theme];

  return {
    activeColor: tabHeaderColors.text,
    inactiveColor: tabHeaderColors.inactiveColor,
    // TODO: Does pressColor work?
    pressColor: tabHeaderColors.pressColor,
    indicatorStyle: {
      height: tokens.size[1].val,
      backgroundColor: tabHeaderColors.indicator,
    },
    style: {
      backgroundColor: tabHeaderColors.backgroundColor,
      height: tokens.size[8].val,
    },
    labelStyle: {
      fontSize: tokens.size[4].val,
      fontWeight: '600',
      // FIXME: MaterialTabBar doesn't override it if we put "none".
      textTransform: 'capitalize',
    },
  } satisfies TabBarStyles;
};
