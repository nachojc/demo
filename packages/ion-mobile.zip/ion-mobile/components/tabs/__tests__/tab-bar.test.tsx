import { render, screen, waitFor } from '@src/jest/testing-library';
import { tokens } from '@src/theme/tokens';
import { TabBar as RNTabBar } from 'react-native-tab-view';

import { Tabs } from '../tabs';
import { TabRoute } from '../types';

const getTestId = ({ title }: TabRoute) => `test:id/${title.toLowerCase()}`;

describe('RNTabBar', () => {
  it.each([
    [
      'white',
      tokens.color.Secondary800.val,
      tokens.color.Secondary800Opacity67.val,
      tokens.color.Gray200.val,
      { backgroundColor: tokens.color.Secondary800.val },
      { backgroundColor: tokens.color.White.val },
    ],
    [
      'blue',
      tokens.color.White.val,
      tokens.color.WhiteOpacity67.val,
      tokens.color.Gray200.val,
      { backgroundColor: tokens.color.Primary500.val },
      { backgroundColor: tokens.color.Secondary800.val },
    ],
    [
      'dwBlue',
      tokens.color.White.val,
      tokens.color.WhiteOpacity67.val,
      tokens.color.Gray200.val,
      { backgroundColor: tokens.color.Primary500.val },
      { backgroundColor: tokens.color.WealthBlue.val },
    ],
    [
      'yellow',
      tokens.color.Secondary800.val,
      tokens.color.Secondary800Opacity67.val,
      tokens.color.Primary600.val,
      { backgroundColor: tokens.color.Secondary800.val },
      { backgroundColor: tokens.color.Primary500.val },
    ],
    [
      'plain',
      tokens.color.Secondary800.val,
      tokens.color.Secondary800Opacity67.val,
      tokens.color.Gray200.val,
      { backgroundColor: tokens.color.Primary500.val },
      { backgroundColor: tokens.color.White.val },
    ],
  ] as const)(
    'renders correctly with %s theme',
    async (
      tabVariant,
      activeColor,
      inactiveColor,
      pressColor,
      indicatorStyle,
      style
    ) => {
      const tabRoutes = [
        {
          key: 'route1',
          title: 'Manga Tab one',
          component: () => <></>,
        },
        {
          key: 'route2',
          title: 'Manga Tab two',
          component: () => <></>,
        },
        {
          key: 'route3',
          title: 'Manga Tab three',
          component: () => <></>,
        },
      ];

      render(<Tabs tabRoutes={tabRoutes} tabBarVariant={tabVariant} />);

      await waitFor(() => {
        expect(screen.getByTestId(getTestId(tabRoutes[0]))).toBeOnTheScreen();
      });

      await waitFor(() => {
        expect(screen.getByTestId(getTestId(tabRoutes[1]))).toBeOnTheScreen();
      });

      await waitFor(() => {
        expect(screen.getByTestId(getTestId(tabRoutes[2]))).toBeOnTheScreen();
      });

      // This is because RNTabBar's internal implementation for testID
      const tabBar = screen.UNSAFE_getByType(RNTabBar);

      expect(tabBar).toHaveProp('activeColor', activeColor);
      expect(tabBar).toHaveProp('inactiveColor', inactiveColor);
      expect(tabBar).toHaveProp('pressColor', pressColor);
      expect(tabBar).toHaveProp('indicatorStyle', {
        ...indicatorStyle,
        height: tokens.size[1].val,
      });
      expect(tabBar).toHaveProp('style', {
        ...style,
        height: tokens.size[8].val,
      });
      expect(tabBar).toHaveProp('labelStyle', {
        fontSize: tokens.size[4].val,
        fontWeight: '600',
        textTransform: 'capitalize',
      });
    }
  );
});
