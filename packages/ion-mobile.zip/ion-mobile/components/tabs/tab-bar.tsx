import { TabBar as RNTabBar } from 'react-native-tab-view';

import { getTabBarStyles } from './theme';
import { TabBarProps, TabBarVariant } from './types';

export const TabBar = ({
  theme = 'white',
  ...rest
}: TabBarProps & { theme?: TabBarVariant }) => {
  return (
    <RNTabBar
      {...rest}
      {...getTabBarStyles(theme)}
      getAccessibilityLabel={({ route }) =>
        route.accessibilityLabel ?? route.title
      }
    />
  );
};
