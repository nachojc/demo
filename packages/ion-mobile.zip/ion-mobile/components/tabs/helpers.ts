import { defaultNS } from '@src/i18n/i18n';
import { TFunction } from 'i18next';

export const tabAccessibilityLabel = (
  t: TFunction<typeof defaultNS, undefined>,
  index: number,
  label: string,
  count: number
) => {
  return t('common.tab.label', {
    index,
    label,
    count,
  });
};
