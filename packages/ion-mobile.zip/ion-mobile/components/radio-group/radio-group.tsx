import { useTranslation } from 'react-i18next';
import { getTokens, Stack, StackProps, XStack } from 'tamagui';

import { Icon } from '../icon';
import { A11yCount } from '../radio-button';
import { Text } from '../text';

type RadioGroupProps = {
  accessibilityLabel: StackProps['accessibilityLabel'];
  a11yOpts: Pick<A11yCount['a11yOpts'], 'total'>;
  errorMessage?: string;
} & StackProps;

export const RadioGroup = ({
  accessibilityLabel,
  children,
  a11yOpts,
  errorMessage,
  ...props
}: RadioGroupProps) => {
  const { t } = useTranslation();

  const headerA11y = t('common.forms.radio.groupLabel', a11yOpts);
  const tokens = getTokens();

  return (
    <Stack
      {...props}
      accessibilityLabel={`${accessibilityLabel}. ${headerA11y}`}
      accessibilityRole="radiogroup"
    >
      {children}

      {!!errorMessage && (
        <XStack
          testID="error-message-container"
          my="$md"
          mr="$xl"
          ai="flex-start"
        >
          <Stack mt="$sm">
            <Icon name="alert-circle" color={tokens.color.Error.val} />
          </Stack>
          <Text
            fontVariant="body-regular-Error"
            tamaguiTextProps={{ pl: '$md' }}
          >
            {errorMessage}
          </Text>
        </XStack>
      )}
    </Stack>
  );
};
