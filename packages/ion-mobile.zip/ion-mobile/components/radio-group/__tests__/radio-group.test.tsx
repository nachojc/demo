import { render, screen } from '@src/jest/testing-library';

import { RadioGroup } from '../radio-group';

describe('RadioGroup Component', () => {
  it('should render correctly with the label', () => {
    render(
      <RadioGroup
        accessibilityLabel="This is a test"
        testID="test"
        a11yOpts={{ total: 3 }}
      />
    );

    expect(screen.getByTestId('test')).toBeOnTheScreen();
    expect(
      screen.getByLabelText('This is a test. There are 3 options.')
    ).toBeOnTheScreen();
  });
});
