import { YStack } from 'tamagui';

import { InsightsBar } from '../../progress/mydrive-progress-bars/insights-bar';
import { Card } from '../card';

export type ScoreCardInsightsProps = {
  scoreBraking: number;
  scoreAcceleration: number;
  scoreCornering: number;
  scoreSpeed: number;
  scorePhoneDistraction: number;
  comparisonBraking: number;
  comparisonAcceleration: number;
  comparisonCornering: number;
  comparisonSpeed: number;
  comparisonPhoneDistraction: number;
};

export const ScoreCardInsights = ({
  scoreBraking,
  scoreAcceleration,
  scoreCornering,
  scoreSpeed,
  scorePhoneDistraction,
  comparisonBraking,
  comparisonAcceleration,
  comparisonCornering,
  comparisonSpeed,
  comparisonPhoneDistraction,
}: ScoreCardInsightsProps) => {
  return (
    <Card>
      <Card.Generic.Content>
        <YStack gap="$xxl">
          <InsightsBar
            title={'Braking'}
            iconName={'braking'}
            score={scoreBraking}
            comparison={comparisonBraking}
          />
          <InsightsBar
            title={'Acceleration'}
            iconName={'acceleration'}
            score={scoreAcceleration}
            comparison={comparisonAcceleration}
          />
          <InsightsBar
            title={'Cornering'}
            iconName={'cornering'}
            score={scoreCornering}
            comparison={comparisonCornering}
          />
          <InsightsBar
            title={'Speed'}
            iconName={'speed'}
            score={scoreSpeed}
            comparison={comparisonSpeed}
          />
          <InsightsBar
            title={'Phone distraction'}
            iconName={'phone-distraction'}
            score={scorePhoneDistraction}
            comparison={comparisonPhoneDistraction}
          />
        </YStack>
      </Card.Generic.Content>
    </Card>
  );
};
