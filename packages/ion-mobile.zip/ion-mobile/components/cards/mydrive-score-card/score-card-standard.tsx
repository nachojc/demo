import { YStack } from 'tamagui';

import { IconName } from '../../icon';
import { ScoreBar } from '../../progress/mydrive-progress-bars/score-bar';
import { Card } from '../card';

export type ScoreCardProps = {
  scoreBraking: number;
  scoreAcceleration: number;
  scoreCornering: number;
  scoreSpeed: number;
  scorePhoneDistraction: number;
  scrollable?: boolean;
  onListPress?: () => void;
  onListPressEnd?: () => void;
};

export type ScoreCardData = {
  title: string;
  iconName: IconName;
  data: number;
}[];

export const ScoreCard = ({
  scoreBraking,
  scoreAcceleration,
  scoreCornering,
  scoreSpeed,
  scorePhoneDistraction,
}: ScoreCardProps) => {
  const scoreCardData: ScoreCardData = [
    {
      title: 'Braking',
      iconName: 'braking',
      data: scoreBraking,
    },
    {
      title: 'Acceleration',
      iconName: 'acceleration',
      data: scoreAcceleration,
    },
    {
      title: 'Cornering',
      iconName: 'cornering',
      data: scoreCornering,
    },
    {
      title: 'Speed',
      iconName: 'speed',
      data: scoreSpeed,
    },
    {
      title: 'Phone distraction',
      iconName: 'phone-distraction',
      data: scorePhoneDistraction,
    },
  ];

  return (
    <Card>
      <Card.Generic.Content>
        <YStack gap="$xxl">
          {scoreCardData.map((item) => (
            <ScoreBar
              key={item.title}
              title={item.title}
              iconName={item.iconName}
              score={item.data}
            />
          ))}
        </YStack>
      </Card.Generic.Content>
    </Card>
  );
};
