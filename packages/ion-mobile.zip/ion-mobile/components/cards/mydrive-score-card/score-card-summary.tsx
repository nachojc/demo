import { Stack } from 'tamagui';

import { SummaryBar } from '../../progress/mydrive-progress-bars/summary-bar';
import { Text } from '../../text';
import { Card } from '../card';

export type ScoreCardSummaryProps = {
  scoreLatest: number;
  scorePrevious: number;
};

export const ScoreCardSummary = ({
  scoreLatest,
  scorePrevious,
}: ScoreCardSummaryProps) => {
  return (
    <Card>
      <Card.Generic.Content>
        <Stack gap="$xl">
          <Text fontVariant={'small-regular-Gray500'}>
            Check out this week’s driving score and compare it to how you did
            last week.
          </Text>
          <SummaryBar title={'Latest score'} score={scoreLatest} />
          <SummaryBar title={'Previous score'} score={scorePrevious} />
        </Stack>
      </Card.Generic.Content>
    </Card>
  );
};
