import { render, screen } from '@src/jest/testing-library';

import { ScoreCardInsights } from '../score-card-insights';
import { ScoreCard } from '../score-card-standard';
import { ScoreCardSummary } from '../score-card-summary';

const renderScoreCard = () => {
  render(
    <ScoreCard
      scoreBraking={10}
      scoreAcceleration={20}
      scoreCornering={30}
      scoreSpeed={40}
      scorePhoneDistraction={50}
    />
  );
};

const renderScoreCardInsights = () => {
  render(
    <ScoreCardInsights
      scoreBraking={60}
      scoreAcceleration={70}
      scoreCornering={80}
      scoreSpeed={90}
      scorePhoneDistraction={100}
      comparisonBraking={-10}
      comparisonAcceleration={-9}
      comparisonCornering={-8}
      comparisonSpeed={+5}
      comparisonPhoneDistraction={+6}
    />
  );
};

const renderScoreCardSummary = () => {
  render(<ScoreCardSummary scoreLatest={75} scorePrevious={68} />);
};

describe('ScoreCard', () => {
  it('ScoreCard renders the required score bars', () => {
    renderScoreCard();
    expect(
      screen.getByText('Braking', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Acceleration', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Cornering', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Speed', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Phone distraction', { includeHiddenElements: true })
    ).toBeTruthy();
  });

  it('ScoreCard renders correct scores', () => {
    renderScoreCard();
    expect(
      screen.getByText('10', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('20', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('30', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('40', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('50', { includeHiddenElements: true })
    ).toBeTruthy();
  });
});

describe('ScoreCardInsights', () => {
  it('ScoreCardInsights renders the required score bars', () => {
    renderScoreCardInsights();
    expect(
      screen.getByText('Braking', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Acceleration', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Cornering', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Speed', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Phone distraction', { includeHiddenElements: true })
    ).toBeTruthy();
  });

  it('ScoreCardInsights renders correct scores', () => {
    renderScoreCardInsights();
    expect(
      screen.getByText('60', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('70', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('80', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('90', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('100', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('-10', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('-9', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('-8', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('+5', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('+6', { includeHiddenElements: true })
    ).toBeTruthy();
  });
});

describe('ScoreCardSummary', () => {
  it('ScoreCardSummary renders the required score bars', () => {
    renderScoreCardSummary();
    expect(
      screen.getByText('Latest score', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('Previous score', { includeHiddenElements: true })
    ).toBeTruthy();
  });

  it('ScoreCardSummary renders correct scores', () => {
    renderScoreCardSummary();
    expect(
      screen.getByText('75', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('68', { includeHiddenElements: true })
    ).toBeTruthy();
  });
});
