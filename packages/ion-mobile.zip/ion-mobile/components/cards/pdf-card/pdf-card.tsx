import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import {
  getTokens,
  getVariableValue,
  StackProps,
  XStack,
  YStack,
} from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import {
  ACCESSIBILITY_HINT,
  defaultAccessibilityLabelFromTitle,
} from './constants';

type PDFCardProps = StackProps & {
  title: string;
  subtitle?: string | null;
  boldTitle?: boolean;
  onPress: () => void;
};

export const PDFCard = ({
  title,
  subtitle,
  boldTitle = false,
  accessibilityLabel,
  testID: customTestID,
  onPress,
  ...stackProps
}: PDFCardProps) => {
  const tokens = getTokens();
  const testID = getTestId(customTestID ?? `pdf-card-${title}`);

  return (
    <Pressable
      testID={testID}
      accessibilityLabel={
        accessibilityLabel ??
        `${defaultAccessibilityLabelFromTitle(title)}${
          subtitle ? `, ${subtitle}` : ''
        }`
      }
      accessibilityRole="link"
      accessibilityHint={ACCESSIBILITY_HINT}
      onPress={onPress}
    >
      <XStack
        p="$xl"
        borderRadius={5}
        borderColor="$Gray300"
        borderWidth={1}
        backgroundColor="white"
        elevation="$1"
        shadowOpacity={0.15}
        alignItems="center"
        {...stackProps}
        testID={getTestId('pdf-card-stack')}
      >
        <Icon name="pdf" />
        <YStack flex={1} ml={16} mr={8}>
          <Text
            fontVariant={
              boldTitle
                ? 'body-semibold-Secondary800'
                : 'body-regular-Secondary800'
            }
            tamaguiTextProps={{
              lineHeight: undefined,
              testID: `${testID}--title`,
            }}
          >
            {title}
          </Text>
          {subtitle ? (
            <Text
              fontVariant="small-regular-Gray800"
              tamaguiTextProps={{
                mt: 8,
                lineHeight: undefined,
                testID: `${testID}--subtitle`,
              }}
            >
              {subtitle}
            </Text>
          ) : null}
        </YStack>
        <Icon
          name="chevron-right"
          color={getVariableValue(tokens.color.Gray400)}
        />
      </XStack>
    </Pressable>
  );
};
