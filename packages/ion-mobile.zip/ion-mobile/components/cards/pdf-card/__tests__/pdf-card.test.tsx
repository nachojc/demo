import { fireEvent, render, screen } from '@src/jest/testing-library';

import { PDFCard } from '../pdf-card';

const pressableSpy = jest.fn();

const renderPdfCard = () =>
  render(
    <PDFCard
      testID="pdf-card"
      onPress={pressableSpy}
      title="Insurance Certificate"
      subtitle="A summary of what's covered and what's not covered"
    />
  );

it('Renders PDF Card', () => {
  renderPdfCard();
  const pdfCard = screen.getByTestId('test:id/pdf-card');
  expect(pdfCard).toBeOnTheScreen();
});

it('Renders title', () => {
  renderPdfCard();
  const cardTitle = screen.getByTestId('test:id/pdf-card--title');
  expect(cardTitle).toHaveTextContent('Insurance Certificate');
});

it('Renders title with bold props', () => {
  render(
    <PDFCard
      testID="pdf-card"
      onPress={pressableSpy}
      title="Insurance Certificate"
      boldTitle
      subtitle="A summary of what's covered and what's not covered"
    />
  );
  const cardTitle = screen.getByTestId('test:id/pdf-card--title');
  expect(cardTitle).toHaveTextContent('Insurance Certificate');
  expect(cardTitle).toHaveStyle({
    color: '#122D44',
    fontFamily: 'SourceSansPro-SemiBold',
    fontSize: 16,
  });
});
it('Renders subtitle', () => {
  renderPdfCard();
  const cardSubtitle = screen.getByTestId('test:id/pdf-card--subtitle');
  expect(cardSubtitle).toHaveTextContent(
    "A summary of what's covered and what's not covered"
  );
});

it('Renders shadow correctly', () => {
  renderPdfCard();
  const pdfCard = screen.getByTestId('test:id/pdf-card-stack');
  expect(pdfCard).toHaveStyle({ shadowOpacity: 0.15 });
});

it('Handles press', () => {
  renderPdfCard();
  const pdfCard = screen.getByTestId('test:id/pdf-card');
  fireEvent.press(pdfCard);
  expect(pressableSpy).toHaveBeenCalledTimes(1);
});

it('Automatically adds accessibility label', () => {
  renderPdfCard();
  const pdfCard = screen.getByTestId('test:id/pdf-card');
  expect(pdfCard).toHaveProp(
    'accessibilityLabel',
    "Insurance Certificate PDF, A summary of what's covered and what's not covered"
  );
  expect(pdfCard).toHaveProp('accessibilityRole', 'link');
  expect(pdfCard).toHaveProp('accessibilityHint', 'Opens PDF');
});

it('Automatically adds accessibility label without subtitle', () => {
  renderPdfCard();
  render(
    <PDFCard
      testID="pdf-card"
      onPress={pressableSpy}
      title="Insurance Certificate"
    />
  );
  const pdfCard = screen.getByTestId('test:id/pdf-card');
  expect(pdfCard).toHaveProp('accessibilityLabel', 'Insurance Certificate PDF');
});

it('Overrides accessibility label when provided', () => {
  renderPdfCard();
  render(
    <PDFCard
      onPress={() => null}
      testID="pdf-card"
      title="title"
      accessibilityLabel="custom-label"
    />
  );
  const pdfCard = screen.getByTestId('test:id/pdf-card');
  expect(pdfCard).toHaveProp('accessibilityLabel', 'custom-label');
});
