export const defaultAccessibilityLabelFromTitle = (title: string) =>
  `${title} PDF`;
export const ACCESSIBILITY_HINT = 'Opens PDF';
