import { CommonBeneficiary } from '@src/navigation/types';
import { Control } from 'react-hook-form';

export type BeneficiaryBaseCardProps = {
  beneficiaryData: CommonBeneficiary;
  testID?: string;
  error?: boolean;
};

export type ManageBeneficiaryFormValues = {
  data: {
    internal_id: CommonBeneficiary['__id'];
    percentage: CommonBeneficiary['percentageOfBeneficiary'];
  }[];
};

export type BeneficiaryEditCardProps = BeneficiaryBaseCardProps & {
  onPressEdit: () => void;
  onPressDelete: () => void;
  index: number;
  total: number;
  control: Control<ManageBeneficiaryFormValues>;
  onEditValue: () => void;
  allowDecimal: boolean;
};
