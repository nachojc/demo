import { render, screen } from '@src/jest/testing-library';
import mockData from '@api-mock/responses/Pension/Beneficiaries/Beneficiaries_one.json';

import { BeneficiaryCard } from '../beneficiary-card';

const beneficiaryMockData = {
  ...mockData.content.beneficiaries[0],
  __id: 'test',
};

const mockText = [
  'Siddiqa Anjum',
  'Relationship:',
  'Friend',
  'Date of birth:',
  '25/11/1996',
  'Address:',
  '15 Kings street, Norwich, Norfolk, American Samoa',
  'Percentage:',
  '100%',
];

describe('BeneficiaryCard', () => {
  it.each(mockText)(`should render '%s' text correctly`, (text) => {
    render(<BeneficiaryCard beneficiaryData={beneficiaryMockData} />);
    expect(screen.getByText(text)).toBeOnTheScreen();
  });
});
