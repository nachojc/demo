import { Stack, styled } from 'tamagui';

export const BeneficiaryCardContainer = styled(Stack, {
  backgroundColor: '$White',
  paddingTop: '$xl',
  paddingHorizontal: '$xl',
  paddingBottom: '$xl',
  width: '100%',
});
