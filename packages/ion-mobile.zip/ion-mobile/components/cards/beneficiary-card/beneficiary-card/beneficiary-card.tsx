import { formatPostalAddress } from '@src/utils/format-pension-data';
import { getTestId } from '@src/utils/get-test-id';
import { Stack, XStack } from 'tamagui';

import { Text } from '../../../text';
import { BeneficiaryBaseCardProps } from '../types';
import { BeneficiaryCardContainer } from './beneficiary-card.style';

export const BeneficiaryCard = ({
  beneficiaryData,
  testID,
}: BeneficiaryBaseCardProps) => {
  const {
    name,
    relationshipToPolicyHolder,
    dateOfBirth,
    postalAddress,
    percentageOfBeneficiary,
  } = beneficiaryData;

  const postalAddressFormatted =
    postalAddress && formatPostalAddress(postalAddress);

  const beneficiaryPercentageFormatted =
    percentageOfBeneficiary && parseFloat(percentageOfBeneficiary);

  return (
    <BeneficiaryCardContainer>
      <Text
        fontVariant="heading5-semibold-Secondary800"
        testID={getTestId(`${testID}-title`)}
      >
        {name}
      </Text>
      <Stack pt="$0">
        <XStack flex={1} pt="$md" space={6}>
          <Text fontVariant="body-regular-Gray800">Relationship:</Text>
          <Text
            fontVariant="body-semibold-Gray800"
            testID={getTestId(`${testID}-relationship`)}
            tamaguiTextProps={{ flex: 1, flexWrap: 'wrap' }}
          >
            {relationshipToPolicyHolder}
          </Text>
        </XStack>
        <XStack flex={1} pt="$md" space={6}>
          <Text fontVariant="body-regular-Gray800">Date of birth:</Text>
          <Text
            fontVariant="body-semibold-Gray800"
            testID={getTestId(`${testID}-date-of-birth`)}
            tamaguiTextProps={{ flex: 1, flexWrap: 'wrap' }}
          >
            {dateOfBirth}
          </Text>
        </XStack>
        <XStack flex={1} pt="$md" space={6}>
          <Text fontVariant="body-regular-Gray800">Address:</Text>
          <Text
            fontVariant="body-semibold-Gray800"
            testID={getTestId(`${testID}-address`)}
            tamaguiTextProps={{ flex: 1, flexWrap: 'wrap' }}
          >
            {postalAddress?.isSameAsPolicyHolder
              ? 'Same as policy holder'
              : postalAddressFormatted}
          </Text>
        </XStack>
        <XStack flex={1} pt="$md" space={6}>
          <Text fontVariant="body-regular-Gray800">Percentage:</Text>
          <Text
            fontVariant="body-semibold-Gray800"
            tamaguiTextProps={{ flex: 1, flexWrap: 'wrap' }}
          >
            {beneficiaryPercentageFormatted ?? 0}%
          </Text>
        </XStack>
      </Stack>
    </BeneficiaryCardContainer>
  );
};
