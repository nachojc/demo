import { formatPostalAddress } from '@src/utils/format-pension-data';
import { getTestId } from '@src/utils/get-test-id';
import { Controller } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Pressable } from 'react-native';
import { Separator, Stack, XStack } from 'tamagui';

import { Icon } from '../../../icon';
import { Text } from '../../../text';
import { NumberInput } from '../../../text-input';
import { BeneficiaryEditCardProps } from '../types';
import { Container } from './beneficiary-edit-card.style';

export const BeneficiaryEditCard = ({
  beneficiaryData,
  index,
  total,
  onPressEdit,
  onPressDelete,
  control,
  onEditValue,
  allowDecimal,
}: BeneficiaryEditCardProps) => {
  const { t } = useTranslation(undefined, {
    keyPrefix: 'pension.manage.edit-beneficiary-card',
  });

  const {
    firstname,
    lastname,
    relationshipToPolicyHolder,
    dateOfBirth,
    postalAddress,
  } = beneficiaryData;

  const beneficiaryDetails = [
    { 'Relationship: ': relationshipToPolicyHolder },
    { 'Date of birth: ': dateOfBirth },
    {
      'Address: ': postalAddress?.isSameAsPolicyHolder
        ? 'Same as policy holder'
        : postalAddress && formatPostalAddress(postalAddress),
    },
  ];

  return (
    <Container>
      <XStack height="$8" justifyContent="space-between" alignItems="center">
        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{ fontSize: '$small' }}
        >
          {t('heading', { item: index + 1, total })}
        </Text>
        <XStack alignItems="center" space="$xxxl" mr="$lg">
          <Pressable
            onPress={onPressEdit}
            testID={getTestId(`beneficiary[${index}]-edit`)}
            accessibilityRole="button"
          >
            <Icon name="edit" />
          </Pressable>
          <Pressable
            onPress={onPressDelete}
            testID={getTestId(`beneficiary[${index}]-delete`)}
            accessibilityRole="button"
          >
            <Icon name="delete" />
          </Pressable>
        </XStack>
      </XStack>
      <Text
        fontVariant="heading5-semibold-Secondary800"
        testID={getTestId(`manage-beneficiaries-title[${index}]`)}
      >
        {`${firstname} ${lastname}`}
      </Text>
      <Stack pt="$xl" pb="$md">
        {beneficiaryDetails.map((details) => (
          <XStack
            flex={1}
            pb="$md"
            key={`ben-details-${index}-${Object.keys(details)}`}
          >
            <Text fontVariant="body-regular-Gray800">
              {Object.keys(details)}
            </Text>
            <Text
              fontVariant="body-semibold-Gray800"
              tamaguiTextProps={{ flex: 1, flexWrap: 'wrap' }}
            >
              {Object.values(details)}
            </Text>
          </XStack>
        ))}
      </Stack>
      <Separator borderColor="$Gray300" />
      <Stack pt="$xl" pb="$md">
        <Text fontVariant="body-semibold-Secondary800">{t('share')}</Text>
      </Stack>
      <Controller
        name={`data.${index}`}
        control={control}
        render={({ field: { value, onChange } }) => (
          <NumberInput
            testID={getTestId(`beneficiaries-share[${index}]`)}
            allowDecimal={!!allowDecimal}
            symbol="suffix"
            tamaguiInputProps={{
              placeholder: '0',
              onChangeText: (val) => {
                onChange({ ...value, percentage: val });
                onEditValue();
              },
              value: value.percentage ?? undefined,
              maxLength: allowDecimal ? 5 : 3,
            }}
          />
        )}
      />
    </Container>
  );
};
