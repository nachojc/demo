import { fireEvent, render, screen } from '@src/jest/testing-library';
import mockData from '@api-mock/responses/Pension/Beneficiaries/Beneficiaries_one.json';
import { useForm } from 'react-hook-form';

import {
  BeneficiaryBaseCardProps,
  ManageBeneficiaryFormValues,
} from '../../types';
import { BeneficiaryEditCard } from '../beneficiary-edit-card';

const mockOnEdit = jest.fn();
const mockOnDelete = jest.fn();

const beneficiaryMockData = {
  __id: 'someUniqId',
  ...mockData.content.beneficiaries[0],
};

const BeneficiaryEditCardTestScreen = (
  overrides: Partial<BeneficiaryBaseCardProps> = {}
) => {
  const form = useForm<ManageBeneficiaryFormValues>({
    defaultValues: {
      data: [{ internal_id: 'someUniqId', percentage: '0' }],
    },
  });

  return (
    <BeneficiaryEditCard
      control={form.control}
      beneficiaryData={beneficiaryMockData}
      onPressDelete={mockOnDelete}
      onPressEdit={mockOnEdit}
      onEditValue={jest.fn()}
      index={0}
      total={3}
      allowDecimal={false}
      {...overrides}
    />
  );
};

describe('BeneficiaryEditCard', () => {
  it('should render correctly on number between 1-100', () => {
    render(<BeneficiaryEditCardTestScreen error />);

    const numberInputContainer = screen.getByTestId(
      'test:id/number-input-container'
    );
    const input = screen.getByTestId('test:id/beneficiaries-share[0]');

    fireEvent.changeText(input, '2');

    expect(numberInputContainer).toHaveStyle({
      borderBottomColor: '#D9D9D9',
      borderLeftColor: '#D9D9D9',
      borderRightColor: '#D9D9D9',
      borderTopColor: '#D9D9D9',
      borderBottomWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderTopWidth: 1,
    });
  });
});
