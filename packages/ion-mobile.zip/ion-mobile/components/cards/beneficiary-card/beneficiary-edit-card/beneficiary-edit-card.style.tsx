import { Stack, styled } from 'tamagui';

export const Container = styled(Stack, {
  backgroundColor: '$White',
  padding: '$xl',
  paddingTop: '$md',
  width: '100%',
  borderColor: '$Grey500',
});
