import { tokens } from '@src/theme/tokens';

import { Button, ButtonVariant } from '../../button';
import { Icon } from '../../icon';
import { Text } from '../../text';
import { Card } from '../card';

export type MyDriveNotificationCardCopyVariant =
  | 'LocationPrecise'
  | 'ActivityRecognition'
  | 'LocationAllTime'
  | 'Location'
  | 'PhoneActivity'
  | 'MotionAndFitness'
  | 'BatteryOptimisation'
  | 'None';

type MyDriveNotificationCardProps = {
  copyVariant: MyDriveNotificationCardCopyVariant;
  onPress: () => void;
};

const notificationCardData: Record<
  MyDriveNotificationCardProps['copyVariant'],
  {
    subtitle: JSX.Element;
  }
> = {
  LocationPrecise: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">
        {
          "We're unable to record your journeys. Please set Location Services to"
        }
        <Text fontVariant="body-semibold-Gray800">{" 'Always' "}</Text>
        and then make sure
        <Text fontVariant="body-semibold-Gray800">
          {" 'Precise Location' "}
        </Text>
        is turned on.
      </Text>
    ),
  },
  ActivityRecognition: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">
        {"We're unable to monitor and record your driving. Please"}
        <Text fontVariant="body-semibold-Gray800">{" 'Allow' "}</Text>
        Activity Recognition.
      </Text>
    ),
  },
  LocationAllTime: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">
        {
          "We're unable to record your journeys. Please enable your Location Services and set to"
        }
        <Text
          fontVariant="body-semibold-Gray800"
          tamaguiTextProps={{ lineHeight: '$small' }}
        >
          {" 'Allow all the time' "}
        </Text>
        .
      </Text>
    ),
  },
  Location: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">
        {
          "We're unable to record your journeys. Please enable your Location Services and set to"
        }
        <Text fontVariant="body-semibold-Gray800">{" 'Allow'"}</Text>.
      </Text>
    ),
  },
  MotionAndFitness: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">
        {"We're unable to monitor and record your driving. Please"}
        <Text fontVariant="body-semibold-Gray800">{" 'Allow' "}</Text>
        Motion and Fitness tracking.
      </Text>
    ),
  },
  PhoneActivity: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">
        {
          "We're unable to accurately record your journeys for any phone distraction. Please"
        }
        <Text fontVariant="body-semibold-Gray800">{" 'Allow' "}</Text>
        Phone Activity.
      </Text>
    ),
  },
  BatteryOptimisation: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">
        We’re unable to accurately record your journeys. Please turn off Battery
        Optimisation so that MyDrive can run in the background.
      </Text>
    ),
  },
  None: {
    subtitle: (
      <Text fontVariant="body-regular-Gray800">No missing permissions</Text>
    ),
  },
};

export const MyDriveNotificationCard = ({
  copyVariant,
  onPress,
}: MyDriveNotificationCardProps) => {
  const data = notificationCardData[copyVariant];

  return (
    <Card>
      <Card.Generic.Content
        left={
          <Icon
            accessible={false}
            name="alert-circle"
            color={tokens.color.Error.val}
          />
        }
      >
        {data.subtitle}
        <Button
          variant={ButtonVariant.LINK_TEXT}
          alignSelf="flex-start"
          onPress={onPress}
          height="$5"
          mt="$lg"
        >
          Fix this now
        </Button>
      </Card.Generic.Content>
    </Card>
  );
};
