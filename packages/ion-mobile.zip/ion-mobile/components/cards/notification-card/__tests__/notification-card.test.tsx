import { fireEvent, render, screen } from '@src/jest/testing-library';

import { NotificationCard } from '../notification-card';

jest.useFakeTimers();

const testTitleText = 'This is test title text';
const testCopyText = 'This is test copy text';

const onPressMock = jest.fn();
beforeEach(() => {
  jest.clearAllMocks();
});
describe('Notification Component', () => {
  it('expect text to render correctly', () => {
    render(
      <NotificationCard
        iconVariant="success"
        title={testTitleText}
        subtitle={testCopyText}
      />
    );

    const titleText = screen.getByTestId('card-title');
    const copyText = screen.getByTestId('card-subtitle');
    const commaText = screen.queryByText('.');

    expect(titleText).toHaveTextContent('This is test title text');
    expect(copyText).toHaveTextContent('This is test copy text');
    expect(commaText).toBeNull();
  });

  // TODO: Test closeIcon onPress - mocking strategy for external libraries needs to agreed as an org first
  it('closeIcon renders correctly if passed as a prop', () => {
    render(
      <NotificationCard
        iconVariant="success"
        subtitle={testCopyText}
        closeIcon
      />
    );

    const closeIcon = screen.getByTestId('test:id/close-icon');
    expect(closeIcon).toBeDefined();
  });

  it('actionButtons renders correctly if passed as a prop', () => {
    render(
      <NotificationCard
        iconVariant="success"
        subtitle={testCopyText}
        actionButtons={[{ text: 'Test Button', onPress: onPressMock }]}
      />
    );

    const actionButton = screen.getByTestId('test:id/card-button');
    fireEvent.press(actionButton);

    expect(actionButton).toHaveTextContent('Test Button');
    expect(onPressMock).toHaveBeenCalledTimes(1);
  });

  it('should have correct border color', () => {
    const notificationBorderColor = '#D9D9D9';
    render(<NotificationCard iconVariant="success" />);

    const outerBorder = screen.getByTestId('container');

    expect(outerBorder).toHaveStyle({
      borderBottomColor: notificationBorderColor,
      borderTopColor: notificationBorderColor,
      borderRightColor: notificationBorderColor,
      borderLeftColor: notificationBorderColor,
    });
  });

  it('should have a link at the end of subtitle text and call a function when its pressed', () => {
    render(
      <NotificationCard
        subtitle={'Text'}
        link={'link to somewhere'}
        onLinkPress={onPressMock}
      />
    );
    const link = screen.getByTestId('subtitle-link');
    expect(link).toHaveTextContent('link to somewhere');
    expect(screen.getByText('.')).toBeOnTheScreen();

    fireEvent.press(link);
    expect(onPressMock).toHaveBeenCalledTimes(1);
  });

  it('should override the static props with props passed from the parent', () => {
    render(
      <NotificationCard
        subtitle={'Text'}
        link={'link to somewhere'}
        onLinkPress={onPressMock}
        marginBottom={20}
      />
    );
    expect(screen.getByTestId('container')).toHaveStyle({
      marginBottom: 20,
    });
  });
});
