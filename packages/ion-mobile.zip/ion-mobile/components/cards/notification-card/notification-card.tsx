import { getTestId } from '@src/utils/get-test-id';
import { ReactNode, useState } from 'react';
import Animated, {
  Easing,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import { getTokens, getVariableValue, Stack, Tokens } from 'tamagui';

import { CloseButton } from '../../close-button';
import { Icon } from '../../icon';
import { Link } from '../../link';
import { PhoneCallBox, PhoneCallBoxProps } from '../../phone-call-box';
import { BaseCard, BaseCardProps } from '../base-card';

export type NotificationCardIconVariant =
  | 'success'
  | 'information'
  | 'warning'
  | 'error';

export type NotificationButton = 'Phone' | 'Button';

type ButtonProps = {
  text: string;
  onPress?: () => void;
  data?:
    | {
        element?: 'Button';
      }
    | ({
        element: 'Phone';
      } & PhoneCallBoxProps);
};

type NotificationButtonsProps = [ButtonProps] | [ButtonProps, ButtonProps];

type NotificationCardProps = BaseCardProps & {
  title?: string | ReactNode;
  actionButtons?: NotificationButtonsProps;
  phoneBox?: ReactNode;
  closeIcon?: boolean;
  iconVariant?: NotificationCardIconVariant;
  optionalOnClose?: () => void;
};

const renderLeftIcon = (
  tokens: Tokens,
  iconVariant?: NotificationCardIconVariant
) => {
  switch (iconVariant) {
    case 'success':
      return <Icon accessible={false} name="tick" />;
    case 'warning':
      return (
        <Icon
          accessible={false}
          name="alert-circle"
          color={getVariableValue(tokens.color.Warning)}
        />
      );
    case 'error':
      return (
        <Icon
          accessible={false}
          name="alert-circle"
          color={getVariableValue(tokens.color.Error)}
        />
      );
    case 'information':
      return (
        <Icon
          accessible={false}
          name="info"
          color={getVariableValue(tokens.color.Information)}
        />
      );
    default:
      return null;
  }
};

export const NotificationCard = ({
  title,
  actionButtons,
  closeIcon,
  iconVariant,
  marginTop = '$sm',
  optionalOnClose,
  showBorder = true,
  ...props
}: NotificationCardProps) => {
  const tokens = getTokens();
  const [isVisible, setIsVisible] = useState<boolean>(true);
  const [pressed, setPressed] = useState<boolean>(false);

  const AnimatedNotification = Animated.createAnimatedComponent(Stack);
  const animatedOpacity = useSharedValue(1);
  const animatedTranslate = useSharedValue(0);

  const closeComponent = () => {
    setIsVisible(false);
    optionalOnClose?.();
  };

  const animationStyle = useAnimatedStyle(() => {
    return {
      opacity: withTiming(animatedOpacity.value, {
        duration: 400,
        easing: Easing.linear,
      }),
      transform: [
        {
          translateX: withTiming(
            animatedTranslate.value,
            {
              duration: 400,
              easing: Easing.linear,
            },
            () => {
              if (pressed) {
                runOnJS(closeComponent)();
              }
            }
          ),
        },
      ],
    };
  });

  const startAnimation = () => {
    animatedOpacity.value = 0;
    animatedTranslate.value = -500;
    setPressed(true);
  };

  return (
    <>
      {isVisible && (
        <AnimatedNotification
          style={animationStyle}
          testID={`anim-${props?.testID}`}
        >
          <BaseCard
            accessible={false}
            showBorder={showBorder}
            title={title}
            subtitleTextProps={{ lineHeight: 20.11 }}
            notification
            justifyContent="flex-start"
            marginTop={marginTop}
            marginBottom="$0"
            renderItemLeft={renderLeftIcon(tokens, iconVariant)}
            actions={
              actionButtons && (
                <Stack
                  flexDirection="row"
                  ac="space-between"
                  jc="space-between"
                  paddingTop="$lg"
                  paddingBottom="$xs"
                >
                  {actionButtons?.map((action) => {
                    return (
                      <Stack key={action.text}>
                        {action?.data?.element === 'Phone' ? (
                          <PhoneCallBox
                            {...action.data}
                            containerProps={{
                              marginBottom: '$xl',
                              paddingLeft: 0,
                              paddingRight: 0,
                            }}
                            callUs
                            text="Call us"
                          />
                        ) : (
                          <Link
                            key={action?.text}
                            onPress={action?.onPress}
                            height="$5"
                            min-width="$xxxl"
                            marginRight="$xl"
                            testID={getTestId('card-button')}
                          >
                            {action?.text}
                          </Link>
                        )}
                      </Stack>
                    );
                  })}
                </Stack>
              )
            }
            renderItemRight={
              closeIcon && (
                <CloseButton
                  onPress={startAnimation}
                  testID={getTestId('close-icon')}
                  iconProps={{
                    color: getVariableValue(tokens.color.Gray400),
                    height: tokens.size[5].val,
                    width: tokens.size[5].val,
                  }}
                />
              )
            }
            {...props}
          />
        </AnimatedNotification>
      )}
    </>
  );
};
