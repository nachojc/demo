import { getTestId } from '@src/utils/get-test-id';
import { ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { getTokens, Stack, StackProps, YStack } from 'tamagui';

import { Chip } from '../../chip';
import { Icon } from '../../icon';
import { LevelIndicator, LevelIndicatorProps } from '../../progress';
import { A11yCount, RadioButton } from '../../radio-button';
import { Text } from '../../text';
import { BaseCard, BaseCardProps } from '../base-card';
import { ErrorIconContainer, ErrorMessage } from './radio-card.style';

export type RadioCardProps = BaseCardProps & {
  tripTitle?: string;
  errorText?: ReactNode;
  levelIndicator?: LevelIndicatorProps;
  renderItemLeftProps?: StackProps;
} & A11yCount;

export const RadioCard = ({
  accessibilityHint,
  accessibilityLabel,
  disabled,
  error,
  errorText,
  onPress,
  selected = false,
  tripTitle,
  selectionCard,
  descriptiveCopy,
  descriptiveCopyTextProps,
  title,
  levelIndicator,
  a11yOpts,
  renderItemLeftProps,
  ...props
}: RadioCardProps) => {
  const { t } = useTranslation();
  const tokens = getTokens();

  const headerA11y = t('common.forms.radio.listItem', a11yOpts);

  const fallbackA11yTitle = typeof title === 'string' ? title : '';

  const getRightItem = () => {
    if (tripTitle) {
      return <Chip variant="selection-card" title={tripTitle} />;
    }
    if (levelIndicator) {
      return (
        <LevelIndicator
          numLevels={levelIndicator.numLevels}
          currentLevel={levelIndicator.currentLevel}
        />
      );
    }
    return null;
  };

  return (
    <YStack m={selected || error ? 0 : 1}>
      <BaseCard
        mt={0}
        mb="$lg"
        {...props}
        selected={selected}
        disabled={disabled}
        error={error}
        selectionCard={selectionCard}
        onPress={onPress}
        accessibilityRole="radio"
        accessibilityState={{ checked: selected }}
        accessibilityLabel={`${headerA11y} ${
          accessibilityLabel ?? fallbackA11yTitle
        }`}
        accessibilityHint={accessibilityHint}
        accessible
        renderItemLeft={
          <Stack
            importantForAccessibility="no-hide-descendants"
            justifyContent="center"
            {...renderItemLeftProps}
          >
            <RadioButton
              disabled={disabled}
              onPress={onPress}
              testID="radio-card-radiobutton"
              selected={selected}
              error={error}
            />
          </Stack>
        }
        renderItemRight={getRightItem()}
        title={title}
        descriptiveCopy={descriptiveCopy}
        descriptiveCopyTextProps={descriptiveCopyTextProps}
      />

      {error && errorText && (
        <ErrorMessage testID="error-message-container">
          <ErrorIconContainer>
            <Icon name="alert-circle" color={tokens.color.Error.val} />
          </ErrorIconContainer>
          <Text
            fontVariant="body-regular-Error"
            tamaguiTextProps={{ pl: '$md' }}
            testID={getTestId('error-message')}
          >
            {errorText}
          </Text>
        </ErrorMessage>
      )}
    </YStack>
  );
};
