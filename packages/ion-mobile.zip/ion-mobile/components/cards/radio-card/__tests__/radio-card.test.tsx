import { render, screen } from '@src/jest/testing-library';

import { RadioCard } from '../radio-card';

describe('Testing a Radio Card', () => {
  it('renders radio button when variant passed as a prop', () => {
    render(<RadioCard a11yOpts={{ item: 1, total: 1 }} />);

    expect(
      screen.getByTestId('radio-card-radiobutton', { hidden: true })
    ).toBeDefined();
  });
});
