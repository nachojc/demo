import { Stack, styled, XStack } from 'tamagui';

export const ErrorMessage = styled(XStack, {
  marginVertical: '$md',
  marginRight: '$xl',
  alignItems: 'flex-start',
});

export const ErrorIconContainer = styled(Stack, {
  marginTop: '$sm',
});
