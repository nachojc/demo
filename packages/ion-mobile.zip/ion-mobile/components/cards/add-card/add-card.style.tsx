import { styled, YStack } from 'tamagui';

export const Container = styled(YStack, {
  backgroundColor: '$White',
  padding: '$xl',
  width: '100%',
  borderColor: '$Gray300',
  borderBottomWidth: '$xxs',
  borderTopWidth: '$xxs',
  space: '$md',
});
