import { getTokens, getVariableValue, Stack, XStack, YStack } from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import { Container } from './add-card.style';

export type AddCardProps = {
  heading?: string | null;
  onPress?: () => void;
  testID?: string;
};

export const AddCard = ({ heading, onPress, testID }: AddCardProps) => {
  const tokens = getTokens();
  return (
    <Container
      onPress={onPress}
      accessibilityLabel="Add Card"
      accessibilityHint="Add Card"
      testID={testID}
    >
      <XStack justifyContent="space-between">
        <Stack mr="$md" alignItems="center" justifyContent="center">
          <Icon
            name="plus"
            color={getVariableValue(tokens.color.Tertiary800)}
            width={getVariableValue(tokens.size['5'])}
          />
        </Stack>
        {heading ? (
          <YStack flex={1}>
            {heading && (
              <Text fontVariant="body-regular-Tertiary800">{heading}</Text>
            )}
          </YStack>
        ) : null}
      </XStack>
    </Container>
  );
};
