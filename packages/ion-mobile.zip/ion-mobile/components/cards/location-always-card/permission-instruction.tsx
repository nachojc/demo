import { XStack, YStack } from 'tamagui';

import { Icon, IconName } from '../../icon';
import { Text } from '../../text';

type PermissionInstructionProps = {
  firstText: string;
  secondTextBold: string;
  thirdText?: string;
  fourthText?: string;
  iconName: IconName;
};

export const PermissionInstruction = ({
  firstText,
  secondTextBold,
  thirdText,
  fourthText,
  iconName,
}: PermissionInstructionProps) => {
  return (
    <YStack>
      <XStack justifyContent="flex-start">
        <XStack>
          <Icon name={iconName} />
          <YStack marginLeft={'$xl'}>
            <XStack>
              <Text fontVariant={'body-regular-Secondary800'}>{firstText}</Text>
              <Text fontVariant={'body-semibold-Secondary800'}>
                {secondTextBold}
              </Text>
              <Text fontVariant={'body-regular-Secondary800'}>{thirdText}</Text>
            </XStack>
            {!!fourthText && (
              <Text fontVariant={'body-regular-Secondary800'}>
                {fourthText}
              </Text>
            )}
          </YStack>
        </XStack>
      </XStack>
    </YStack>
  );
};
