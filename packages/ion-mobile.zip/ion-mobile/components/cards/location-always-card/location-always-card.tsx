import { Platform } from 'expo-modules-core';
import { YStack } from 'tamagui';

import { PermissionInstruction } from './permission-instruction';

type LocationAlwaysCardProps = {
  showPrecision: boolean;
};

export const LocationAlwaysCard = ({
  showPrecision,
}: LocationAlwaysCardProps) => {
  return (
    <YStack
      backgroundColor="$White"
      borderRadius={'$2'}
      elevation={'$1'}
      width={'100%'}
    >
      <YStack justifyContent="center" backgroundColor="$White" margin="$xl">
        <YStack marginBottom="$md">
          <PermissionInstruction
            firstText={'Tap '}
            secondTextBold={'Go to settings'}
            thirdText={' at the bottom of this'}
            fourthText={'screen'}
            iconName={'ios-settings'}
          />
        </YStack>
        <YStack marginVertical="$md">
          <PermissionInstruction
            firstText={'Tap '}
            secondTextBold={'Location'}
            iconName={Platform.OS === 'ios' ? 'ios-gps-arrow' : 'location'}
          />
        </YStack>
        <YStack marginVertical="$md">
          <PermissionInstruction
            firstText={'Choose '}
            secondTextBold={
              Platform.OS === 'ios' ? 'Always' : 'Allow all the time'
            }
            iconName={Platform.OS === 'ios' ? 'ios-tick' : 'tick'}
          />
        </YStack>
        {showPrecision && (
          <YStack marginTop="$md">
            <PermissionInstruction
              firstText={'Turn on '}
              secondTextBold={'Precise Location'}
              iconName={Platform.OS === 'ios' ? 'ios-tick' : 'tick'}
            />
          </YStack>
        )}
      </YStack>
    </YStack>
  );
};
