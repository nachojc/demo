import { getTokens } from 'tamagui';

import { Image as IonImage, ImageProps } from '../../image';
import { useCardImageContext } from './card-context';
import { cardTokens } from './card-tokens';

export type CardGenericImageProps = {
  mode: 'small' | 'big' | 'fill';
} & Pick<ImageProps, 'source'>;

export const CardGenericImage = ({ mode, source }: CardGenericImageProps) => {
  const { position } = useCardImageContext();
  const { space } = getTokens();

  const imageStyles = {
    small: { width: 40, height: 40 },
    big: { width: 56, height: 56 },
    fill: {
      width: 80,
      marginVertical: space[cardTokens.spacingNegative].val,
      marginLeft:
        position === 'left' ? space[cardTokens.spacingNegative].val : 0,
      marginRight:
        position === 'right' ? space[cardTokens.spacingNegative].val : 0,
    },
  } as const;

  return (
    <IonImage source={source} style={imageStyles[mode]} resizeMode="cover" />
  );
};
