import { getTestId } from '@src/utils/get-test-id';
import { forwardRef, ReactNode } from 'react';
import { View } from 'react-native';
import { Stack, StackProps, YStack } from 'tamagui';

import { CardGenericContent } from './card-generic-content';
import { CardGenericImage } from './card-generic-image';
import {
  createPressableContainer,
  PressableContainerProps,
} from './create-pressable-container';

export type CardProps = {
  children: ReactNode;
  mode?: 'elevated' | 'outlined';
  /**
   * Only works with `mode = "outlined"`
   */
  borderProps?: BorderProps;
} & Pick<StackProps, 'backgroundColor'> &
  PressableContainerProps;

type BorderProps = Pick<
  StackProps,
  | 'borderStyle'
  | 'borderColor'
  | 'borderTopColor'
  | 'borderRightColor'
  | 'borderBottomColor'
  | 'borderLeftColor'
  | 'borderWidth'
  | 'borderTopWidth'
  | 'borderRightWidth'
  | 'borderBottomWidth'
  | 'borderLeftWidth'
  | 'borderRadius'
>;

export const Card = Object.assign(
  forwardRef<View, CardProps>(
    (
      {
        children,
        mode = 'elevated',
        backgroundColor = '$White',
        borderProps,
        ...rest
      },
      ref
    ) => {
      const cardStyles = {
        elevated: {
          outer: {
            elevation: '$1',
            shadowOpacity: 0.15,
            borderStyle: 'solid',
          },
          inner: { borderRadius: '$2' },
        },
        outlined: {
          outer: {},
          inner: {
            borderRadius: '$2',
            borderWidth: '$xxs',
            borderColor: '$Gray300',
            ...borderProps,
          },
        },
      } as const;

      return createPressableContainer(
        <YStack
          ref={ref}
          {...cardStyles[mode].outer}
          // Don't use this testId for unit tests, it's only needed for Appium
          testID={getTestId('card-container')}
        >
          <Stack
            bg={backgroundColor}
            overflow="hidden"
            {...cardStyles[mode].inner}
          >
            {children}
          </Stack>
        </YStack>,
        rest
      );
    }
  ),
  {
    Generic: {
      Content: CardGenericContent,
      Image: CardGenericImage,
    },
  }
);
