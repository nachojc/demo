import { getTestId } from '@src/utils/get-test-id';
import { cloneElement } from 'react';
import { AccessibilityProps, Pressable } from 'react-native';
import { StackProps } from 'tamagui';

export type PressableContainerProps = {
  onPress?: () => void;
} & AccessibilityProps &
  Pick<StackProps, 'testID'>;

export const createPressableContainer = (
  element: JSX.Element,
  { onPress, ...rest }: PressableContainerProps
) => {
  if (onPress) {
    return (
      <Pressable
        testID={getTestId('pressable-container')}
        onPress={onPress}
        accessibilityRole="link"
        {...rest}
      >
        {element}
      </Pressable>
    );
  }

  return cloneElement<StackProps>(element, rest);
};
