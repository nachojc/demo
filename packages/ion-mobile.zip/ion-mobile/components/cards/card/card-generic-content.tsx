import { ReactNode } from 'react';
import { Stack, StackProps, XStack } from 'tamagui';

import { CardImageContext } from './card-context';
import { cardTokens } from './card-tokens';

export type CardGenericContentProps = {
  children: ReactNode;
  left?: ReactNode;
  right?: ReactNode;
} & Pick<StackProps, 'testID' | 'accessible'>;

const leftImagePositionContextValue = { position: 'left' } as const;
const rightImagePositionContextValue = { position: 'right' } as const;

export const CardGenericContent = ({
  children,
  left,
  right,
  ...rest
}: CardGenericContentProps) => {
  return (
    <XStack p={cardTokens.spacing} gap={cardTokens.spacing} {...rest}>
      {left && (
        <CardImageContext.Provider value={leftImagePositionContextValue}>
          {left}
        </CardImageContext.Provider>
      )}
      <Stack flex={1}>{children}</Stack>
      {right && (
        <CardImageContext.Provider value={rightImagePositionContextValue}>
          {right}
        </CardImageContext.Provider>
      )}
    </XStack>
  );
};
