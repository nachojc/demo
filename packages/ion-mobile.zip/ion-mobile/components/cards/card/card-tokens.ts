export const cardTokens = {
  spacing: '$xl',
  spacingNegative: '$-xl',
} as const;
