import { createContext, useContext } from 'react';

type CardImageContextType = {
  position: 'left' | 'right';
};

export const CardImageContext = createContext(
  undefined as unknown as CardImageContextType
);

export const useCardImageContext = () => {
  const context = useContext(CardImageContext);

  if (!context) {
    throw new Error(
      '<Card.Generic.Image /> must be used within <Card.Generic.Content /> in "left" or "right" prop'
    );
  }

  return context;
};
