import { getTokens, getVariableValue } from 'tamagui';

import { Icon } from '../../icon';
import { BaseCard, BaseCardProps } from '../base-card';

export const IDVCard = ({
  title,
  subtitle,
  renderItemLeft,
  onPress,
}: BaseCardProps) => {
  const tokens = getTokens();

  return (
    <BaseCard
      onPress={onPress}
      title={title}
      subtitle={subtitle}
      renderItemLeft={renderItemLeft}
      renderItemRight={
        <Icon
          name="chevron-right"
          color={getVariableValue(tokens.color.Gray400)}
        />
      }
      shadowColor={tokens.color.Secondary800.val}
      shadowRadius={5}
      shadowOpacity={0.25}
      containerRightProps={{
        marginRight: '$-xs',
        marginTop: '$lg',
      }}
      marginVertical="$xs"
      titleTextProps={{ color: tokens.color.Secondary800.val }}
    />
  );
};
