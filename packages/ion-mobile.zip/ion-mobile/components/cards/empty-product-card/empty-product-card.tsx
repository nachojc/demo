import { Icon, Separator, Text, XStack, YStack } from '@aviva/ion-mobile';
import { tokens } from '@src/theme/tokens';
import { RefObject } from 'react';

// Please keep all styles inline with the master component here: https://www.figma.com/file/dqw5MuY2Uza1SByJXkYMXe/Tigris---Cross-Platform?type=design&node-id=9727%3A2146&mode=design&t=vQUYoKdQSpBr24JE-1
export const EmptyProductCard = ({
  title,
  description,
  onPress,
  cardRef,
}: {
  title: string;
  description: string;
  onPress: () => void;
  cardRef?: RefObject<any>;
}) => {
  return (
    <YStack
      accessible
      accessibilityLabel={`${title}, ${description}`}
      accessibilityRole="button"
      onPress={onPress}
      borderRadius={4}
      padding="$xl"
      borderStyle="dotted"
      borderColor={tokens.color.Gray300.val}
      backgroundColor={'$White'}
      borderWidth={'$xxs'}
      ref={cardRef}
    >
      <Text fontVariant="heading5-semibold-Secondary900">{title}</Text>
      <Separator marginVertical="$xl" />
      <XStack alignItems="center" space="$md" paddingVertical="$lg">
        <Icon
          name={'plus'}
          width={tokens.size[6].val}
          height={tokens.size[6].val}
        />
        <Text fontVariant="body-semibold-Tertiary800">{description}</Text>
      </XStack>
    </YStack>
  );
};
