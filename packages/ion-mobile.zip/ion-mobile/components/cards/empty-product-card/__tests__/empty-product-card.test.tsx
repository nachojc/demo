import { fireEvent, render, screen } from '@src/jest/testing-library';

import { EmptyProductCard } from '../empty-product-card';

const mockOnPress = jest.fn();

const renderCard = () => {
  render(
    <EmptyProductCard
      title={'Empty Product Card'}
      description={'Add first pension'}
      onPress={mockOnPress}
    />
  );
};
describe('EmptyProductCard', () => {
  it('renders the card correctly', () => {
    renderCard();
    const card = screen.getByLabelText('Empty Product Card, Add first pension');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      backgroundColor: '#FFFFFF',
      borderStyle: 'dotted',
      borderBottomColor: '#CCCCCC',
      borderLeftColor: '#CCCCCC',
      borderRightColor: '#CCCCCC',
      borderTopColor: '#CCCCCC',
      borderBottomWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderTopWidth: 1,
      borderBottomLeftRadius: 4,
      borderBottomRightRadius: 4,
      borderTopLeftRadius: 4,
      borderTopRightRadius: 4,
      paddingBottom: 16,
      paddingLeft: 16,
      paddingRight: 16,
      paddingTop: 16,
    });
  });

  it('renders the title correctly', () => {
    renderCard();

    const title = screen.getByText('Empty Product Card');
    expect(title).toBeOnTheScreen();
    expect(title).toHaveStyle({
      color: '#0A1F32',
      fontFamily: 'SourceSansPro-SemiBold',
      fontSize: 18,
      lineHeight: 22,
    });
  });

  it('renders the description correctly', () => {
    renderCard();
    const description = screen.getByText('Add first pension');
    expect(description).toBeOnTheScreen();
    expect(description).toHaveStyle({
      color: '#004FB6',
      fontFamily: 'SourceSansPro-SemiBold',
      fontSize: 16,
      lineHeight: 24,
    });
  });

  it('renders the icon button correctly', () => {
    renderCard();
    const icon = screen.getByTestId('test:id/icon-plus', {
      includeHiddenElements: true,
    });
    expect(icon).toBeOnTheScreen();
    expect(icon).toHaveStyle({
      height: 24,
      width: 24,
    });
  });

  it('fires the correct onPress when pressed', () => {
    renderCard();
    fireEvent.press(screen.getByText('Add first pension'));
    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });
});
