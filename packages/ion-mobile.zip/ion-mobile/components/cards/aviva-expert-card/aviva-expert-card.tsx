import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import { getTokens, getVariableValue, YStack } from 'tamagui';

import { Image, ImageProps } from '../../image';
import { BaseCard } from '../base-card';

type AvivaExpertCardProps = {
  image: ImageProps['source'];
  title: string;
  onPress?: () => void;
  cardWidth: number;
};

export const AvivaExpertCard = ({
  image,
  title,
  cardWidth,
  onPress,
}: AvivaExpertCardProps) => {
  const tokens = getTokens();

  return (
    <YStack>
      <Pressable
        testID={getTestId('aviva-expert-card-icon')}
        accessibilityRole="link"
        accessibilityLabel={`${title}. Watch`}
        onPress={onPress}
      >
        <Image
          accessibilityIgnoresInvertColors
          accessibilityElementsHidden
          importantForAccessibility="no-hide-descendants"
          source={image}
          style={{
            height: 120,
            width: cardWidth,
            borderRadius: getVariableValue(tokens.radius['2']),
          }}
        />
        <BaseCard
          generic
          subtitle={title}
          accessible={false}
          subtitleTextProps={{
            ellipse: true,
            numberOfLines: 2,
            fontSize: getVariableValue(tokens.size['4']),
            mx: '$-lg',
          }}
          descriptiveCopy={'Watch'}
          descriptiveCopyTextProps={{
            color: '$Tertiary800',
            mx: '$-lg',
          }}
          elevationAndroid="$0"
          width={cardWidth}
          backgroundColor="transparent"
        />
      </Pressable>
    </YStack>
  );
};
