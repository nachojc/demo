import { fireEvent, render, screen } from '@src/jest/testing-library';

import { AvivaExpertCard } from '../aviva-expert-card';

const mockOnPress = jest.fn();

describe('Aviva Expert Card', () => {
  it('should render expected <AvivaExpertCard/> attributes', async () => {
    render(
      <AvivaExpertCard title="Test title" image={undefined} cardWidth={100} />
    );

    expect(screen.getByText('Test title')).toBeOnTheScreen();
    expect(screen.getByText('Watch')).toBeOnTheScreen();
  });
  it('should call onPress, when card is tapped', async () => {
    render(
      <AvivaExpertCard
        title="Test title"
        image={undefined}
        cardWidth={100}
        onPress={mockOnPress}
      />
    );
    const card = screen.getByTestId('container');

    fireEvent.press(card);

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });
});
