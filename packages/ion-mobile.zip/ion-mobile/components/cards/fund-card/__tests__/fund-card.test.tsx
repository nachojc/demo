import { fireEvent, render, screen } from '@src/jest/testing-library';
import { Stack } from '@aviva/ion-mobile';
import { AlertChip } from '@aviva/ion-mobile/components/chip';
import { FundCardPensionData } from '@src/features/pension/common/fund-card-sections/pension-data';
import { PensionEditAllocation } from '@src/features/pension/common/fund-card-sections/pension-edit-allocation';
import { useState } from 'react';

import { FundCard } from '../fund-card';

const fund = {
  fundName: 'name',
  unitPrice: 2.73,
  value: 54291.1,
  fundRiskLevel: 4,
  fundReference: 'a',
  noOfUnit: 8512,
  percentage: 60,
  risks: [
    { highestPossibleScore: '7', riskRatingSystem: 'random', riskScore: 4 },
  ],
  suggestedAllocation: null,
  isSoftClosed: false,
  closureDate: null,
  factSheetUrl: 'about:blank',
};

const StandardFundCard = () => {
  return (
    <FundCard blc="red">
      <FundCard.Header>
        <FundCard.Title>Standard FundCard</FundCard.Title>
      </FundCard.Header>
    </FundCard>
  );
};

const ExpandableFundCard = () => {
  return (
    <FundCard blc="green">
      <FundCard.Header>
        <FundCard.Title expandable>Expandable FundCard</FundCard.Title>
      </FundCard.Header>
      <FundCard.ExpandableContent>
        <FundCardPensionData fund={fund} baseAnalyticsTag="test-tag" />
      </FundCard.ExpandableContent>
    </FundCard>
  );
};

const MultipleExpandableFundCard = () => {
  const [selectedCard, setSelectedCard] = useState<'foo' | 'bar' | undefined>();

  return (
    <>
      <FundCard
        blc="green"
        expanded={selectedCard === 'foo'}
        setExpanded={() => setSelectedCard('foo')}
      >
        <FundCard.Header testID="header-foo">
          <FundCard.Title expandable>Foo title</FundCard.Title>
        </FundCard.Header>
        <FundCard.ExpandableContent>
          <Stack testID="test-foo" />
        </FundCard.ExpandableContent>
      </FundCard>
      <FundCard
        blc="blue"
        expanded={selectedCard === 'bar'}
        setExpanded={() => setSelectedCard('bar')}
      >
        <FundCard.Header testID="header-bar">
          <FundCard.Title expandable>Bar title</FundCard.Title>
        </FundCard.Header>
        <FundCard.ExpandableContent>
          <Stack testID="test-bar" />
        </FundCard.ExpandableContent>
      </FundCard>
    </>
  );
};

const AllocationFundCard = () => {
  return (
    <FundCard blc="blue">
      <FundCard.Header>
        <FundCard.Title percentage={50}>Allocation FundCard</FundCard.Title>
      </FundCard.Header>
      <FundCard.Footer>
        <PensionEditAllocation />
      </FundCard.Footer>
    </FundCard>
  );
};

const ExpandableFundCardWarningAndValue = () => {
  return (
    <FundCard blc="orange">
      <FundCard.Header>
        <FundCard.Title percentage={50} expandable>
          Expandable FundCard w/ Value And Warning
        </FundCard.Title>
        <AlertChip
          variant="warning"
          title="Show important fund information"
          alignSelf="flex-start"
        />
      </FundCard.Header>
      <FundCard.ExpandableContent>
        <FundCardPensionData fund={fund} baseAnalyticsTag="test-tag" />
      </FundCard.ExpandableContent>
    </FundCard>
  );
};

const AllocationFundCardWarningAndValue = () => {
  return (
    <FundCard blc="orange">
      <FundCard.Header>
        <FundCard.Title percentage={50}>
          Allocation FundCard w/ Value And Warning
        </FundCard.Title>
        <AlertChip
          variant="warning"
          title="Show important fund information"
          alignSelf="flex-start"
        />
      </FundCard.Header>
    </FundCard>
  );
};

describe('Testing a Fund Card', () => {
  it('renders standard variant correctly', async () => {
    render(<StandardFundCard />);

    expect(await screen.findByText('Standard FundCard')).toBeOnTheScreen();
  });

  it('renders expandable variant correctly when closed', async () => {
    render(<MultipleExpandableFundCard />);

    // Titles show
    expect(await screen.findByText('Foo title')).toBeOnTheScreen();
    expect(await screen.findByText('Bar title')).toBeOnTheScreen();

    // Expanded content does not
    expect(screen.queryByTestId('test-foo')).toBeNull();
    expect(screen.queryByTestId('test-bar')).toBeNull();

    // Toggle Foo card
    fireEvent.press(screen.queryByText('Foo title'));
    expect(screen.getByTestId('test-foo')).toBeOnTheScreen();
    expect(screen.queryByTestId('test-bar')).toBeNull();

    // Toggle Bar card
    fireEvent.press(screen.queryByText('Bar title'));
    expect(screen.getByTestId('test-bar')).toBeOnTheScreen();
    expect(screen.queryByTestId('test-foo')).toBeNull();
  });

  it('renders only one expandable when manually set', async () => {
    render(<ExpandableFundCard />);

    expect(await screen.findByText('Expandable FundCard')).toBeOnTheScreen();
    expect(
      await screen.findByTestId('test:id/icon-fund-card-expand-toggle', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });

  it('renders expandable variant correctly when open', async () => {
    render(<ExpandableFundCard />);

    const title = screen.queryByText('Expandable FundCard');
    fireEvent.press(title);

    expect(await screen.findByText('Units held:')).toBeOnTheScreen();
    expect(await screen.findByText('8,512.00')).toBeOnTheScreen();
    expect(await screen.findByText('Unit price:')).toBeOnTheScreen();
    expect(await screen.findByText('£2.73')).toBeOnTheScreen();
    expect(await screen.findByText('Fund value:')).toBeOnTheScreen();
    expect(await screen.findByText('£54,291.10')).toBeOnTheScreen();
    expect(await screen.findByText('Allocation:')).toBeOnTheScreen();
    expect(await screen.findByText('60%')).toBeOnTheScreen();
    expect(await screen.findByText('Fund risk level:')).toBeOnTheScreen();
    expect(await screen.findByText('Fund fact sheet')).toBeOnTheScreen();
  });

  it('renders View fund facts and performance, when showPerformanceOverview props passed through', async () => {
    render(
      <FundCard blc="green">
        <FundCard.Header>
          <FundCard.Title expandable>Expandable FundCard</FundCard.Title>
        </FundCard.Header>
        <FundCard.ExpandableContent>
          <FundCardPensionData
            fund={fund}
            baseAnalyticsTag="test-tag"
            showPerformanceOverview
          />
        </FundCard.ExpandableContent>
      </FundCard>
    );

    const title = screen.queryByText('Expandable FundCard');
    fireEvent.press(title);

    expect(
      await screen.findByText('View fund facts and performance')
    ).toBeOnTheScreen();
  });

  it('renders allocation variant correctly', async () => {
    render(<AllocationFundCard />);

    expect(await screen.findByText('Allocation FundCard')).toBeOnTheScreen();
    expect(await screen.findByText('50%')).toBeOnTheScreen();
    expect(
      await screen.findByPlaceholderText('Enter new fund allocation')
    ).toBeOnTheScreen();
  });

  it('renders expandable variant correctly with percentage value and warning label', async () => {
    render(<ExpandableFundCardWarningAndValue />);

    expect(
      await screen.findByText('Expandable FundCard w/ Value And Warning')
    ).toBeOnTheScreen();
    expect(await screen.findByText('50%')).toBeOnTheScreen();
    expect(
      await screen.findByText('Show important fund information')
    ).toBeOnTheScreen();
    expect(await screen.findByTestId('test:id/alert-chip')).toBeOnTheScreen();
  });

  it('renders allocation variant correctly with percentage value and warning label', async () => {
    render(<AllocationFundCardWarningAndValue />);

    expect(
      await screen.findByText('Allocation FundCard w/ Value And Warning')
    ).toBeOnTheScreen();
    expect(await screen.findByText('50%')).toBeOnTheScreen();
    expect(
      await screen.findByText('Show important fund information')
    ).toBeOnTheScreen();
    expect(await screen.findByTestId('test:id/alert-chip')).toBeOnTheScreen();
  });
});
