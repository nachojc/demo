import { useAnalytics } from '@hooks/use-analytics';
import { formatPercentageValue } from '@src/utils/format-percentage-value';
import { getTestId } from '@src/utils/get-test-id';
import { createContext, useContext, useMemo, useState } from 'react';
import {
  getTokens,
  Stack,
  StackProps,
  TextProps,
  XStack,
  YStack,
} from 'tamagui';

import { Chip } from '../../chip';
import { Icon } from '../../icon';
import { Text } from '../../text';

const defaultContext = {
  expanded: false,
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  setExpanded: (_value: boolean) => {},
};

const ToggleContext = createContext(defaultContext);

type FundCardProps = {
  elevated?: boolean;
} & StackProps &
  Partial<typeof defaultContext>;

const FundCard = ({ elevated, ...props }: FundCardProps) => {
  const [expanded, setExpanded] = useState(false);

  // Use expanded/setExpanded from props for a manual override (ie allowing only one item toggled at a time)
  // otherwise context used for the component handle its toggle state
  const toggleValues = useMemo(
    () =>
      props?.expanded !== undefined && props?.setExpanded !== undefined
        ? { expanded: props.expanded, setExpanded: props.setExpanded }
        : { expanded, setExpanded },
    [expanded, props?.expanded, props?.setExpanded]
  );

  return (
    <ToggleContext.Provider value={toggleValues}>
      <XStack
        borderLeftWidth={10}
        borderLeftColor="$Pension03"
        bg="$White"
        borderRadius="$2"
        {...(elevated && { elevation: '$1' })}
        {...props}
        testID={getTestId(`fund-card-${props?.testID}`)}
      >
        <YStack width="100%" p="$lg" gap="$lg">
          {props?.children}
        </YStack>
      </XStack>
    </ToggleContext.Provider>
  );
};

const Header = (
  props?: StackProps & { tag?: string } & Partial<typeof defaultContext>
) => {
  const { expanded, setExpanded } = useContext(ToggleContext);
  const { trackUserEvent } = useAnalytics();

  const onToggleExpand = () => {
    setExpanded(!expanded);

    props?.tag && trackUserEvent(props.tag);
  };

  return (
    <Stack gap="$xl" alignItems="center" onPress={onToggleExpand} {...props}>
      {props?.children}
    </Stack>
  );
};

const Title = (
  props?: TextProps & {
    expandable?: boolean;
    percentage?: number | string;
    percentageDecimal?: number;
    trend?: 'up' | 'down';
  }
) => {
  const tokens = getTokens();
  const { expanded } = useContext(ToggleContext);

  return (
    <XStack space="$md" alignItems="center">
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ flex: 1, ...props }}
      >
        {props?.children}
      </Text>

      {props?.percentage !== undefined && (
        <Chip
          variant="fund-card"
          title={
            typeof props.percentage === 'string'
              ? props.percentage
              : formatPercentageValue(
                  props.percentage,
                  props.percentageDecimal ?? 0
                ) ?? ''
          }
        />
      )}
      {props?.trend && <Trend trend={props.trend} />}
      {props?.expandable && (
        <Icon
          testID={'fund-card-expand-toggle'}
          name={expanded ? 'chevron-up' : 'chevron-down'}
          color={tokens.color.Gray400.val}
        />
      )}
    </XStack>
  );
};

const Trend = ({ trend }: { trend: 'up' | 'down' }) => {
  const tokens = getTokens();
  return (
    <Icon
      name={`trending-${trend}`}
      height={tokens.size[6].val}
      width={tokens.size[6].val}
      color={tokens.color[trend === 'up' ? 'Success' : 'Error'].val}
    />
  );
};

const Content = (props?: StackProps) => <Stack {...props} />;

const Row = (props?: StackProps) => (
  <XStack alignItems="center" jc="space-between" ml="$sm" gap="$sm" {...props}>
    <XStack flex={1}>{props?.children[0]}</XStack>
    {props?.children[1]}
  </XStack>
);

const ExpandableContent = (props?: StackProps) => {
  const { expanded } = useContext(ToggleContext);

  return expanded ? <Stack {...props}>{props?.children}</Stack> : null;
};

const Footer = (props?: StackProps) => <Stack {...props} />;

FundCard.Header = Header;
FundCard.Title = Title;
FundCard.Trend = Trend;
FundCard.Content = Content;
FundCard.Row = Row;
FundCard.ExpandableContent = ExpandableContent;
FundCard.Footer = Footer;

export { FundCard };
