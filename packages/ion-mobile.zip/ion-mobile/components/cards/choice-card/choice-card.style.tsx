import { styled, YStack } from 'tamagui';

const ChoiceCardContainer = styled(YStack, {
  backgroundColor: '$White',
  borderRadius: 5,
  overflow: 'hidden',
  borderWidth: '$xs',
  borderColor: '$Gray300',
  variants: {
    selected: {
      true: {
        borderColor: '$Success',
      },
    },
    error: {
      true: {
        borderColor: '$Error',
      },
    },
  } as const,
});

const ChoiceCardBody = styled(YStack, {
  borderTopWidth: '$xs',
  borderTopColor: '$Gray300',
  variants: {
    selected: {
      true: {
        borderTopColor: '$Success',
      },
    },
    error: {
      true: {
        borderTopWidth: '$xs',
        borderTopColor: '$Error',
        borderBottomWidth: '$xs',
        borderBottomColor: '$Error',
        paddingVertical: 0,
      },
    },
  } as const,
});

const ChoiceCardFooter = styled(YStack, {
  minHeight: 68,
});

export { ChoiceCardBody, ChoiceCardContainer, ChoiceCardFooter };
