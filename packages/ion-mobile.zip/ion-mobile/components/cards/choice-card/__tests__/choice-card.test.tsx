import { fireEvent, render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { Text } from '../../../text';
import { ChoiceCard, ChoiceCardProps } from '../choice-card';

const mockOnPress = jest.fn();

const renderComponent = (props: Partial<ChoiceCardProps> = {}) => {
  return render(
    <ChoiceCard
      headerTitle="I'll choose my investments"
      variant="directWealth"
      footerComponent={
        <Text fontVariant="heading5-regular-Secondary800">Test footer</Text>
      }
      onPress={mockOnPress}
      {...props}
    >
      <Text fontVariant="heading5-regular-Secondary800">
        This is a test card body
      </Text>
    </ChoiceCard>
  );
};

describe('Choice Card', () => {
  describe('Without customised props', () => {
    it('should render the card header', () => {
      renderComponent();
      expect(
        screen.getByTestId(getTestId('choice-card-content'))
      ).toBeOnTheScreen();
    });

    it('should render the card body', () => {
      renderComponent();

      expect(screen.getByText('This is a test card body')).toBeOnTheScreen();
    });

    it('should render the card footer', () => {
      renderComponent();

      expect(screen.getByText('Test footer')).toBeOnTheScreen();
    });

    it('should call the passed onPress function on press of the button', () => {
      renderComponent();

      fireEvent.press(screen.getByTestId(getTestId('choice-card-content')));

      expect(mockOnPress).toHaveBeenCalledTimes(1);
    });
  });

  describe('With customised props', () => {
    it('should apply a green border when the selected state is passed', () => {
      renderComponent({ selected: true });

      expect(screen.getByTestId(getTestId('choice-card-content'))).toHaveStyle({
        borderBottomColor: '#4F9F31',
      });
    });

    it('should apply a red border when the error state is passed', () => {
      renderComponent({ error: true });

      expect(screen.getByTestId(getTestId('choice-card-content'))).toHaveStyle({
        borderBottomColor: '#BD2624',
      });
    });
  });
});
