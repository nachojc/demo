import { getTestId } from '@src/utils/get-test-id';
import { ReactNode } from 'react';
import { Pressable } from 'react-native';

import { Header, Variant } from '../../header';
import {
  ChoiceCardBody,
  ChoiceCardContainer,
  ChoiceCardFooter,
} from './choice-card.style';

export type ChoiceCardProps = {
  headerTitle: string;
  variant?: Variant;
  children: ReactNode;
  footerComponent?: ReactNode;
  error?: boolean;
  selected?: boolean;
  minHeight?: number;
  onPress?: () => void;
};

const ChoiceCardContent = ({
  headerTitle,
  variant,
  children,
  footerComponent,
  selected,
  error,
  minHeight,
}: Omit<ChoiceCardProps, 'onPress'>) => (
  <ChoiceCardContainer
    testID={getTestId('choice-card-content')}
    selected={selected}
    error={error}
    accessible
  >
    <Header copy={headerTitle} variant={variant} />
    <ChoiceCardBody
      selected={selected}
      error={error}
      style={{
        minHeight,
        borderBottomWidth: !footerComponent ? 0 : undefined,
      }}
    >
      {children}
    </ChoiceCardBody>
    {footerComponent ? (
      <ChoiceCardFooter>{footerComponent}</ChoiceCardFooter>
    ) : null}
  </ChoiceCardContainer>
);

export const ChoiceCard = ({
  headerTitle,
  variant,
  children,
  footerComponent,
  selected,
  error,
  minHeight = 192,
  onPress,
}: ChoiceCardProps) => {
  if (onPress) {
    return (
      <Pressable
        testID={getTestId('choice-card')}
        accessibilityRole="button"
        onPress={onPress}
      >
        <ChoiceCardContent
          headerTitle={headerTitle}
          variant={variant}
          footerComponent={footerComponent}
          selected={selected}
          error={error}
          minHeight={minHeight}
        >
          {children}
        </ChoiceCardContent>
      </Pressable>
    );
  }

  return (
    <ChoiceCardContent
      headerTitle={headerTitle}
      variant={variant}
      footerComponent={footerComponent}
      selected={selected}
      error={error}
      minHeight={minHeight}
    >
      {children}
    </ChoiceCardContent>
  );
};
