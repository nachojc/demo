import { render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';
import { Offer } from '@src/validation/schemas/offers';

import { OfferCard } from '../offer-card';

describe('Offer Card', () => {
  it('should render expected Offer Card components', async () => {
    render(
      <OfferCard
        onPress={jest.fn}
        offer={
          {
            Category: 'Test category',
            Title: 'Test title',
            Summary: 'Test summary',
          } as Offer
        }
        note="Note"
      />
    );

    expect(
      screen.getByTestId(getTestId('icon-offercard-chevron-right'), {
        hidden: true,
      })
    ).toBeDefined();

    expect(screen.getByText('Test category')).toBeOnTheScreen();
    expect(screen.getByText('Test title')).toBeOnTheScreen();
    expect(screen.getByText('Test summary')).toBeOnTheScreen();
    expect(screen.getByText('Note')).toBeOnTheScreen();
  });
});
