import { Offer } from '@src/validation/schemas/offers';
import { getTokens, Stack, StackProps } from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import { Card, CardProps } from '../card';

type OfferCardProps = {
  offer: Offer;
  note?: string;
  onPress: () => void;
} & Pick<CardProps, 'testID'> &
  Pick<StackProps, 'height'>;

export const OfferCard = ({
  offer,
  note,
  height,
  testID,
  onPress,
}: OfferCardProps) => {
  const tokens = getTokens();

  return (
    <Card onPress={onPress} testID={testID}>
      <Card.Generic.Content
        left={
          <Card.Generic.Image
            mode="fill"
            source={
              previewImageMapping[
                offer.PreviewImageName as keyof typeof previewImageMapping
              ]
            }
          />
        }
        right={
          <Icon
            name="chevron-right"
            color={tokens.color.Gray400.val}
            testID="offercard-chevron-right"
          />
        }
      >
        <Stack height={height} gap="$sm">
          <Text fontVariant="overline-semibold-Gray800">{offer.Category}</Text>
          <Text
            fontVariant="body-semibold-Secondary800"
            tamaguiTextProps={{ numberOfLines: 1 }}
          >
            {offer.Title}
          </Text>
          <Text
            fontVariant="small-regular-Gray800"
            tamaguiTextProps={{ lineHeight: '$overline', numberOfLines: 2 }}
          >
            {offer.Summary}
          </Text>
          {note && <Text fontVariant="small-regular-Gray800">{note}</Text>}
        </Stack>
      </Card.Generic.Content>
    </Card>
  );
};

const previewImageMapping = {
  avivascore_image: require('assets/offer_avivascore/offer_avivascore.png'),
  offer_breakdown_cover: require('assets/offer_breakdown_cover/offer_breakdown_cover.webp'),
  offer_critical_illness_cover: require('assets/offer_critical_illness_cover/offer_critical_illness_cover.webp'),
  offer_equity_release: require('assets/offer_equity_release/offer_equity_release.webp'),
  offer_flexible_income: require('assets/offer_flexible_income/offer_flexible_income.webp'),
  offer_free_parent_life_cover: require('assets/offer_free_parent_life_cover/offer_free_parent_life_cover.webp'),
  offer_health_insurance: require('assets/offer_health_insurance/offer_health_insurance.webp'),
  offer_home: require('assets/offer_home/offer_home.webp'),
  offer_income_protection_insurance: require('assets/offer_income_protection_insurance/offer_income_protection_insurance.webp'),
  offer_investment_account: require('assets/offer_investment_account/offer_investment_account.webp'),
  offer_life_insurance: require('assets/offer_life_insurance/offer_life_insurance.webp'),
  offer_motor: require('assets/offer_motor/offer_motor.webp'),
  offer_header_multicar: require('assets/offer_multicar/offer_multicar.webp'),
  offer_multicar: require('assets/offer_multicar/offer_multicar.webp'),
  offer_pet_insurance: require('assets/offer_pet_insurance/offer_pet_insurance.webp'),
  offer_pension_annuity: require('assets/offer_pension_annuity/offer_pension_annuity.webp'),
  offer_personal_accident_insurance: require('assets/offer_personal_accident_insurance/offer_personal_accident_insurance.webp'),
  offer_saving_for_retirement: require('assets/offer_saving_for_retirement/offer_saving_for_retirement.webp'),
  offer_stocks_shares_isa: require('assets/offer_stocks_shares_isa/offer_stocks_shares_isa.webp'),
  offer_travel_insurance: require('assets/offer_travel_insurance/offer_travel_insurance.webp'),
  offer_van_insurance: require('assets/offer_van_insurance/offer_van_insurance.webp'),
};
