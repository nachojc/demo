type ProductImage = {
  [key: string]: number | undefined;
};
export const headerImageMapping: ProductImage = {
  offer_header_critical_illness: require('assets/offer_header_critical_illness/offer_header_critical_illness.png'),
  offer_header_free_parent_life: require('assets/offer_header_free_parent_life/offer_header_free_parent_life.png'),
  offer_header_health: require('assets/offer_header_health/offer_header_health.png'),
  offer_header_home: require('assets/offer_header_home/offer_header_home.png'),
  offer_header_life: require('assets/offer_header_life/offer_header_life.png'),
  offer_header_motor: require('assets/offer_header_motor/offer_header_motor.png'),
  offer_header_multicar: require('assets/offer_header_multicar/offer_header_multicar.png'),
  offer_header_travel: require('assets/offer_header_travel/offer_header_travel.png'),
  offer_header_van: require('assets/offer_header_van/offer_header_van.png'),
};
