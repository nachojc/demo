import { styled, XStack, YStack } from 'tamagui';

const Container = styled(YStack, {
  backgroundColor: '$White',
  padding: '$xl',
  borderRadius: '$1',
  elevation: '$1',
  shadowOpacity: 0.15,
});

const TopContainer = styled(XStack, {
  justifyContent: 'space-between',
  paddingBottom: '$xl',
});

const BottomContainer = styled(XStack, {
  justifyContent: 'space-between',
  alignItems: 'flex-end',
});

export { BottomContainer, Container, TopContainer };
