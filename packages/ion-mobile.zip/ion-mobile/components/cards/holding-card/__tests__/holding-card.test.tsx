import { fireEvent, render, screen } from '@src/jest/testing-library';

import { HoldingCard } from '../holding-card';

const PressableHoldingCard = jest.fn();

const label =
  'Product Card. HSBC Holdings Account, 1 of 1, Double tap to activate. Total account value, 99010 pounds. You have gained 250 pounds, 0.12 percent increase. 55 shares, 54 percent.';

const setup = () => {
  render(
    <HoldingCard
      title="HSBC Holdings"
      value="£99,010"
      dataItemsProps={{
        gainOrLoss: { raw: 250, formatted: '+£250.00' },
        gainOrLossPercentage: { raw: 0.12, formatted: '0.12%' },
      }}
      sharesAmount={55}
      sharesPercentage="54%"
      onPress={PressableHoldingCard}
      quantityType="Shares "
      accessibilityLabel={label}
    />
  );
};

it('Should render the holding card', () => {
  setup();
  const holdingCardContainer = screen.getByLabelText(label);
  expect(holdingCardContainer).toBeOnTheScreen();
});

it('Should render the title, value, share amount and share percentage', () => {
  setup();
  expect(screen.getByText('HSBC Holdings')).toBeOnTheScreen();
  expect(screen.getByText('£99,010')).toBeOnTheScreen();
  expect(screen.getByText('+£250.00 (0.12%)')).toBeOnTheScreen();
  expect(screen.getByText('55 Shares • 54%')).toBeOnTheScreen();
});

it('Should render the icon', () => {
  setup();
  const icon = screen.getByTestId('test:id/icon-chevron-right', {
    hidden: true,
  });
  expect(icon).toBeOnTheScreen();
});

it('Should fire OnPress when whole card is pressed', () => {
  setup();
  const holdingCardContainer = screen.getByLabelText(label);
  fireEvent.press(holdingCardContainer);
  expect(PressableHoldingCard).toHaveBeenCalledTimes(1);
});
