import { A11yProps } from '@src/common/types/a11y';
import { getTokens, getVariableValue, YStack } from 'tamagui';

import { DataItem, DataItemProps } from '../../data-item';
import { Icon } from '../../icon';
import { Text } from '../../text';
import { BottomContainer, Container, TopContainer } from './holding-card.style';

type HoldingCardProps = {
  title?: string;
  value?: string;
  dataItemsProps: DataItemProps;
  sharesAmount?: number;
  sharesPercentage?: string;
  onPress: () => void;
  quantityType?: string;
} & A11yProps;

export const HoldingCard = ({
  title,
  value,
  dataItemsProps,
  sharesAmount,
  sharesPercentage,
  quantityType,
  onPress,
  accessibilityLabel,
  accessibilityHint,
  accessibilityRole = 'button',
}: HoldingCardProps) => {
  const tokens = getTokens();

  return (
    <Container
      accessible
      accessibilityLabel={accessibilityLabel}
      accessibilityHint={accessibilityHint}
      accessibilityRole={accessibilityRole}
      onPress={onPress}
    >
      <TopContainer>
        <Text
          fontVariant="heading5-regular-Secondary900"
          tamaguiTextProps={{
            numberOfLines: 2,
            flex: 1,
          }}
        >
          {title}
        </Text>
        <Icon
          name="chevron-right"
          color={getVariableValue(tokens.color.Gray400)}
        />
      </TopContainer>
      <BottomContainer>
        <YStack>
          <Text fontVariant="heading4-semibold-Gray800">{value}</Text>
          <DataItem {...dataItemsProps} />
        </YStack>
        <Text
          fontVariant="small-regular-Gray600"
          tamaguiTextProps={{ numberOfLines: 1, flex: 1, textAlign: 'right' }}
        >
          {sharesAmount && quantityType
            ? `${sharesAmount} ${quantityType} • `
            : ''}
          {sharesPercentage}
        </Text>
      </BottomContainer>
    </Container>
  );
};
