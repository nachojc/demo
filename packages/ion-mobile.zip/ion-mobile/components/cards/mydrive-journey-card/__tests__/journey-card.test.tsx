import { fireEvent, render, screen } from '@src/jest/testing-library';

import { JourneyCard } from '../journey-card';

jest.unmock('react-native-reanimated');

const date = new Date(2023, 0, 1, 8, 8).toISOString();
const distanceMetres = 2000;
const durationSeconds = 3660;
const mockPress = jest.fn();

describe('JourneyCard', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    jest.useFakeTimers();
  });

  it('should render all expected attributes', () => {
    render(
      <JourneyCard
        date={date}
        distanceMetres={distanceMetres}
        durationSeconds={durationSeconds}
        score={10}
        onPress={jest.fn()}
      />
    );

    expect(screen.getByText('Sun 1 Jan 08:08')).toBeDefined();
    expect(screen.getByText('1.2 miles')).toBeDefined();
    expect(screen.getByText('1h 1m')).toBeDefined();
  });

  it('should not be clickable if onPress is undefined', () => {
    render(
      <JourneyCard
        date={date}
        distanceMetres={distanceMetres}
        durationSeconds={durationSeconds}
        score={10}
      />
    );

    const link = screen.queryByRole('link');
    expect(link).not.toBeOnTheScreen();
  });

  it('should be clickable if onPress is defined', () => {
    render(
      <JourneyCard
        date={date}
        distanceMetres={distanceMetres}
        durationSeconds={durationSeconds}
        score={10}
        onPress={mockPress}
      />
    );

    const link = screen.getByRole('link');
    fireEvent.press(link);
    expect(link).toBeOnTheScreen();
    expect(mockPress).toHaveBeenCalledTimes(1);
  });
});
