import { getJourneyCardAccessibilityLabel } from '@src/features/mydrive/utils';
import {
  getDateString,
  getDurationString,
  getMilesString,
  stringToDate,
} from '@src/features/mydrive/utils/format-string';
import { convertSeconds } from '@src/utils/convert-seconds/convert-seconds';
import { getTestId } from '@src/utils/get-test-id';
import { getTokens, XStack, YStack } from 'tamagui';

import { Icon } from '../../icon';
import { RoundelWithoutAnimation as Roundel } from '../../roundel';
import { Text } from '../../text';
import { Card } from '../card';

export type JourneyCardProps = {
  date: string;
  distanceMetres: number;
  durationSeconds: number;
  score: number;
  startAddress?: string;
  endAddress?: string;
  onPress?: () => void;
};

export const JourneyCard = ({
  date,
  distanceMetres,
  durationSeconds,
  score,
  onPress,
  startAddress,
  endAddress,
}: JourneyCardProps) => {
  const tokens = getTokens();
  const { hours, minutes } = convertSeconds(durationSeconds);
  const dateObject = stringToDate(date);
  const formattedDate = getDateString(dateObject);
  const miles = getMilesString(distanceMetres);
  const duration = getDurationString(hours, minutes);
  const accessibilityLabel = getJourneyCardAccessibilityLabel({
    date: dateObject,
    miles: parseFloat(miles),
    duration: { hours, minutes },
    score,
    pressable: !!onPress,
    route: { startAddress, endAddress },
  });

  return (
    <Card
      accessible
      accessibilityLabel={accessibilityLabel}
      testID={getTestId('journey-card')}
      onPress={onPress}
    >
      <Card.Generic.Content right={<Roundel value={score} size={'small'} />}>
        <YStack flex={1} justifyContent="space-between">
          <Text fontVariant="body-semibold-Secondary900">{formattedDate}</Text>
          <XStack alignItems="center">
            <Icon
              name="map"
              width={tokens.size[4].val}
              height={tokens.size[4].val}
            />
            <Text
              tamaguiTextProps={{ ml: '$md', minWidth: 100 }}
              fontVariant="small-regular-Gray500"
            >
              {miles}
            </Text>

            <Icon
              name="clock"
              width={tokens.size[4].val}
              height={tokens.size[4].val}
              strokeWidth={3}
            />
            <Text
              fontVariant="small-regular-Gray500"
              tamaguiTextProps={{ ml: '$md' }}
            >
              {duration}
            </Text>
          </XStack>
        </YStack>
      </Card.Generic.Content>
    </Card>
  );
};
