import { fireEvent, render, screen } from '@src/jest/testing-library';

import { CMSCard } from '../cms-card';

const onPressSpy = jest.fn();

describe('CMS Card', () => {
  it('should render expected <CMSCard/> attributes', async () => {
    render(
      <CMSCard
        title="Test title"
        description="Test description"
        link="Test link"
        image={undefined}
        testID="container"
      />
    );

    expect(screen.getByText('Test title')).toBeOnTheScreen();
    expect(screen.getByText('Test description')).toBeOnTheScreen();
    expect(screen.getByText('Test link')).toBeOnTheScreen();
  });

  it('should call onPress, when card is tapped', async () => {
    render(
      <CMSCard
        title="Test title"
        link="Test link"
        image={undefined}
        onPress={onPressSpy}
        testID="container"
      />
    );
    const card = screen.getByTestId('container');

    fireEvent.press(card);

    expect(onPressSpy).toHaveBeenCalledTimes(1);
  });
});
