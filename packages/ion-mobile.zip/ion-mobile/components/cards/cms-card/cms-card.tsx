import { getTestId } from '@src/utils/get-test-id';
import { Stack, StackProps } from 'tamagui';

import { Image, ImageProps } from '../../image';
import { Text } from '../../text';
import { Card, CardProps } from '../card';

export type CMSCardItem = {
  image: ImageProps['source'];
  title: string;
  description?: string;
  link: string;
};

type CMSCardProps = CMSCardItem &
  Omit<CardProps, 'children'> &
  Pick<StackProps, 'height'>;

export const CMSCard = ({
  image,
  title,
  description,
  link,
  height,
  accessibilityElementsHidden,
  testID = getTestId('container'),
  ...rest
}: CMSCardProps) => {
  return (
    <Card testID={getTestId(`${testID}-button`)} {...rest}>
      <Stack height={height}>
        <Image
          accessibilityIgnoresInvertColors
          accessibilityElementsHidden={accessibilityElementsHidden}
          importantForAccessibility={
            accessibilityElementsHidden ? 'no-hide-descendants' : 'yes'
          }
          source={image}
          style={{ height: 140 }}
        />
        <Stack testID={testID} flex={1} p="$xl">
          <Text fontVariant="body-semibold-Secondary800">{title}</Text>
          {description && (
            <Text
              fontVariant="small-regular-Gray800"
              tamaguiTextProps={{
                numberOfLines: 3,
                minHeight: '$8',
                mt: '$md',
              }}
            >
              {description}
            </Text>
          )}
          <Stack flex={1} mt="$xl" />
          <Text fontVariant="small-semibold-Tertiary800">{link}</Text>
        </Stack>
      </Stack>
    </Card>
  );
};
