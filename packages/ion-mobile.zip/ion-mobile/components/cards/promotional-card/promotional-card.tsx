import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import { AccessibilityRole } from 'react-native/types';
import { Circle, Stack, XStack } from 'tamagui';

import { Text } from '../../text';
import {
  LeftIconContainer,
  PromotionalCardContainer,
  styles,
  TextContainer,
} from './promotional-card-styles';

export type PromotionalCardProps = {
  heading: string | null;
  text: string | null;
  linkText: string | null;
  onPress: () => void;
  cardWidth?: number;
  accessibilityLabel?: string;
  accessibilityHint?: string;
  accessibilityRole?: AccessibilityRole;
  testID?: string;
  index?: number;
};

export const PromotionalCard = ({
  heading,
  text,
  linkText,
  onPress,
  cardWidth,
  accessibilityLabel,
  accessibilityHint,
  accessibilityRole = 'button',
  testID,
  index,
}: PromotionalCardProps) => {
  const suffix = index ? `-${index}` : '';
  return (
    /* Leave press event on Pressable so it does not conflict with
    drag gesture on the ScrollView (MANGA-4700)*/
    <Pressable
      testID={getTestId('promotion-product-card')}
      onPress={onPress}
      accessibilityRole={accessibilityRole}
      accessibilityLabel={accessibilityLabel}
      accessibilityHint={accessibilityHint}
    >
      <PromotionalCardContainer
        testID={testID}
        space={'$sm'}
        width={cardWidth}
        style={styles.dashedBorder}
      >
        <Stack>
          <XStack>
            <LeftIconContainer>
              <Circle size={9} borderColor="black" borderWidth={2} />
            </LeftIconContainer>
            <Text
              testID={getTestId(`promotion-product-title${suffix}`)}
              fontVariant="heading5-semibold-Secondary900"
            >
              {heading}
            </Text>
          </XStack>
          <TextContainer>
            <Text
              testID={getTestId(`promotion-product-text${suffix}`)}
              fontVariant="small-regular-Gray600"
            >
              {text}
            </Text>
          </TextContainer>
        </Stack>
        <Text
          testID={getTestId(`promotion-product-link${suffix}`)}
          fontVariant="small-regular-Tertiary800"
        >
          {linkText}
        </Text>
      </PromotionalCardContainer>
    </Pressable>
  );
};
