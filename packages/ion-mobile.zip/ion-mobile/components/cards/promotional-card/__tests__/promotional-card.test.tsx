import { fireEvent, render, screen } from '@src/jest/testing-library';

import { PromotionalCard } from '../promotional-card';

const mockOnPress = jest.fn();

const setup = () => {
  render(
    <PromotionalCard
      heading="Test Heading"
      text="Open a new account with us!"
      linkText="Test Link"
      onPress={mockOnPress}
      testID="Testing"
    />
  );
};

describe('PromotionalCard', () => {
  it('should render correctly with passed props', () => {
    setup();

    expect(screen.getByText('Test Heading')).toBeOnTheScreen();
    expect(screen.getByText('Open a new account with us!')).toBeOnTheScreen();
    expect(screen.getByText('Test Link')).toBeOnTheScreen();
  });

  it('should trigger the passed onPress function on press of the card', () => {
    setup();

    const promotionalCard = screen.getByTestId('Testing');

    fireEvent.press(promotionalCard);

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it('should have dashedBorder border styling', () => {
    setup();

    const promotionalCard = screen.getByTestId('Testing');

    expect(promotionalCard).toHaveStyle({
      borderStyle: 'dashed',
      shadowOpacity: 0,
    });
  });

  it('should render gray text with correct fontSize for the text prop', () => {
    setup();

    const text = screen.getByText('Open a new account with us!');

    expect(text).toHaveStyle({
      color: '#616161',
      fontSize: 14,
      fontFamily: 'SourceSansPro-Regular',
    });
  });

  it('should render blue text with correct fontSize for the linkText prop', () => {
    setup();

    const link = screen.getByText('Test Link');

    expect(link).toHaveStyle({
      color: '#004FB6',
      fontSize: 14,
    });
  });
});
