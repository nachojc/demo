import { StyleSheet } from 'react-native';
import { Stack, styled, YStack } from 'tamagui';

export const PromotionalCardHeight = 156;

export const PromotionalCardContainer = styled(YStack, {
  backgroundColor: '$White',
  padding: '$xl',
  maxWidth: 392,
  height: PromotionalCardHeight,
  justifyContent: 'space-between',
});

export const styles = StyleSheet.create({
  dashedBorder: {
    borderStyle: 'dashed',
    borderWidth: 1,
    borderRadius: 5,
    borderColor: '$WealthBlue95',
    shadowOpacity: 0,
    elevation: 0,
  },
});

export const LeftIconContainer = styled(Stack, {
  marginRight: '$md',
  justifyContent: 'center',
});

export const TextContainer = styled(Stack, {
  marginTop: '$md',
});
