import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import { Separator, Stack, XStack } from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import { Card } from '../card';

type KeyValueCardProps = {
  keyValuePairs: KeyValuePair;
  link?: Link;
  title: string;
  testID?: string;
};
export type Link = { copy: string; onPress: () => void };
export type KeyValuePair = {
  key: string;
  value?: string | React.ReactNode;
  accessibilityLabel?: string;
}[];

export const KeyValueCard = ({
  keyValuePairs,
  link,
  title,
  testID,
}: KeyValueCardProps) => {
  return (
    <Card mode="outlined" testID={testID ?? getTestId('key-value-card')}>
      <Stack padding={'$xl'}>
        <Stack accessible>
          <Text
            fontVariant="heading5-semibold-Secondary800"
            tamaguiTextProps={{ mb: '$lg' }}
          >
            {title}
          </Text>
        </Stack>
        <Stack gap={'$lg'}>
          {keyValuePairs.map(({ key, value, accessibilityLabel }) => (
            <KeyValueRow
              key={`${key}-${value}`}
              leftText={key}
              rightElement={value}
              accessibilityLabel={accessibilityLabel}
            />
          ))}
        </Stack>
        {link && <Link link={link} />}
      </Stack>
    </Card>
  );
};

const KeyValueRow = ({
  leftText,
  rightElement,
  accessibilityLabel,
}: {
  leftText: string;
  rightElement?: string | React.ReactNode;
  accessibilityLabel?: string;
}) => (
  <XStack
    accessible
    accessibilityLabel={accessibilityLabel}
    justifyContent={'space-evenly'}
  >
    <Text
      fontVariant="body-regular-Gray800"
      tamaguiTextProps={{ flex: 2, marginRight: '$sm' }}
    >
      {leftText}
    </Text>
    {typeof rightElement === 'string' ? (
      <Text
        fontVariant="body-semibold-Gray800"
        tamaguiTextProps={{ flex: 1, textAlign: 'right' }}
      >
        {rightElement}
      </Text>
    ) : (
      <Stack alignItems="flex-end" flex={1}>
        {rightElement}
      </Stack>
    )}
  </XStack>
);

const Link = ({ link }: { link: Link }) => {
  return (
    <Stack testID={getTestId('key-value-card-link')}>
      <Separator
        marginTop={20}
        marginBottom={'$md'}
        borderColor="$Gray300"
        testID={getTestId('separator')}
      />
      <Pressable
        onPress={link.onPress}
        style={{
          flexDirection: 'row',
          justifyContent: 'space-between',
          paddingVertical: tokens.space.md.val,
        }}
        accessibilityRole="link"
        testID={getTestId('pressable')}
      >
        <Text fontVariant="body-semibold-Tertiary800">{link.copy}</Text>
        <Icon name={'external-link'} color={tokens.color.Tertiary800.val} />
      </Pressable>
    </Stack>
  );
};
