import { fireEvent, render, screen } from '@src/jest/testing-library';
import { Text } from '@aviva/ion-mobile';

import { KeyValueCard, KeyValuePair, Link } from '../key-value-card';

const mockLinkOnPress = jest.fn();
const link = {
  copy: 'This is the card link',
  onPress: mockLinkOnPress,
};
const keyValuePairString = [
  {
    key: 'This is the card key',
    value: 'This is the card value as a string',
  },
];
const keyValuePairNode = [
  {
    key: 'This is the card key',
    value: (
      <Text fontVariant="heading5-semibold-Secondary800">
        This is the card value as a node
      </Text>
    ),
  },
];
const keyValuePairNoValue = [{ key: 'This is the card key' }];

const renderCard = (value?: KeyValuePair, link?: Link) => {
  render(
    <KeyValueCard
      title={'Key value card title'}
      keyValuePairs={value ?? keyValuePairString}
      link={link}
    />
  );
};

describe('Cost and Charges Screen', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render the card', () => {
    renderCard();
    expect(screen.getByTestId('test:id/key-value-card')).toBeOnTheScreen();
  });

  it('should render the title, this is mandatory', () => {
    renderCard();
    expect(screen.getByText('Key value card title')).toBeOnTheScreen();
  });

  it('should render the key value pairs key, this is mandatory', () => {
    renderCard();
    expect(screen.getByText('This is the card key')).toBeOnTheScreen();
  });

  it('should render the key value pairs value when passed as a string', () => {
    renderCard();
    expect(
      screen.getByText('This is the card value as a string')
    ).toBeOnTheScreen();
  });

  it('should not render the key value pairs value when it is not passed, there is no fallback', () => {
    renderCard(keyValuePairNoValue);
    expect(
      screen.queryByText('This is the card value as a string')
    ).not.toBeOnTheScreen();
  });

  it('should render the key value pairs when passed', () => {
    renderCard();
    expect(screen.getByText('This is the card key')).toBeOnTheScreen();
    expect(
      screen.getByText('This is the card value as a string')
    ).toBeOnTheScreen();
  });

  it('should render the key value pairs value when passed as a node', () => {
    renderCard(keyValuePairNode);
    expect(
      screen.getByText('This is the card value as a node')
    ).toBeOnTheScreen();
  });

  it('should render the link UI when a link prop is passed', () => {
    renderCard(undefined, link);
    expect(screen.getByTestId('test:id/key-value-card-link')).toBeOnTheScreen();
    expect(screen.getByTestId('test:id/separator')).toBeOnTheScreen();
    expect(screen.getByTestId('test:id/pressable')).toBeOnTheScreen();
  });

  it('should have the correct role for the link', () => {
    renderCard(undefined, link);
    expect(screen.getByRole('link')).toBeOnTheScreen();
  });

  it('should fire the passed in onPress prop when the link is pressed', () => {
    renderCard(undefined, link);
    const pressable = screen.getByTestId('test:id/pressable');
    fireEvent.press(pressable);
    expect(mockLinkOnPress).toHaveBeenCalledTimes(1);
  });
});
