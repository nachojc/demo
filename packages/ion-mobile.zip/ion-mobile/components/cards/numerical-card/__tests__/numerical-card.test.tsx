import { render, screen } from '@src/jest/testing-library';

import { NumericalCard } from '../numerical-card';

describe('NumericalCard', () => {
  it('renders correctly with provided props', () => {
    render(<NumericalCard value="42" label="Miles" />);

    expect(screen.getByText('42')).toBeOnTheScreen();
    expect(screen.getByText('Miles')).toBeOnTheScreen();
  });
});
