import { Stack } from 'tamagui';

import { Text } from '../../text';
import { Card } from '../card';

export type NumericalCardProps = {
  value: string | number;
  label: string;
  accessibilityLabel?: string;
};

export const NumericalCard = ({
  value,
  label,
  accessibilityLabel,
}: NumericalCardProps) => {
  return (
    <Card accessible accessibilityLabel={accessibilityLabel}>
      <Stack height="$11">
        <Stack
          flex={1}
          alignItems="center"
          justifyContent="center"
          bg="$Secondary100"
        >
          <Text fontVariant="heading5-semibold-Secondary800">{value}</Text>
        </Stack>
        <Stack alignItems="center" p="$md">
          <Text fontVariant="small-semibold-Gray400">{label}</Text>
        </Stack>
      </Stack>
    </Card>
  );
};
