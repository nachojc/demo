import { render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { PensionSnapshotCard } from '../pension-snap-shot-card';

const title = 'PX43284729';

const cardBgColor = {
  plumLight: '#7b5182',
  tertiary700: '#276CC3',
  teal600: '#408291',
  white: '#FFFFFF',
};
describe('Pension Card', () => {
  it('title should render as expected', () => {
    render(<PensionSnapshotCard variant="plum-light" title={title} />);
    expect(screen.getByText(title)).toBeOnTheScreen();
  });

  it('Should render the right variant color plum-light', () => {
    render(
      <PensionSnapshotCard
        variant="plum-light"
        title={title}
        testID={getTestId('pension-card')}
      />
    );
    const backgroundColor = screen.getByTestId('test:id/pension-card');
    expect(backgroundColor).toHaveStyle({
      backgroundColor: cardBgColor.plumLight,
    });
  });

  it('Should render the right variant color tertiary-700', () => {
    render(
      <PensionSnapshotCard
        variant="tertiary-700"
        title={title}
        testID={getTestId('pension-card')}
      />
    );
    const backgroundColor = screen.getByTestId('test:id/pension-card');
    expect(backgroundColor).toHaveStyle({
      backgroundColor: cardBgColor.tertiary700,
    });
  });

  it('Should render the right variant color teal-600', () => {
    render(
      <PensionSnapshotCard
        variant="teal-600"
        title={title}
        testID={getTestId('pension-card')}
      />
    );
    const backgroundColor = screen.getByTestId('test:id/pension-card');
    expect(backgroundColor).toHaveStyle({
      backgroundColor: cardBgColor.teal600,
    });
  });

  it('Should render font color white', () => {
    render(<PensionSnapshotCard variant="teal-600" title={title} />);
    const fontColor = screen.getByTestId('card-title');
    expect(fontColor).toHaveStyle({
      color: cardBgColor.white,
    });
  });
});
