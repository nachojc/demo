import { ReactNode } from 'react';
import { getTokens, getVariableValue } from 'tamagui';

import { Icon } from '../../icon';
import { BaseCard, BaseCardProps } from '../base-card';

type PensionSnapshotProps = BaseCardProps & {
  variant: 'plum-light' | 'tertiary-700' | 'teal-600';
  title: string | ReactNode;
};

export const PensionSnapshotCard = ({
  title,
  variant,
  ...rest
}: PensionSnapshotProps) => {
  const tokens = getTokens();

  const backgroundColorVariant = {
    'plum-light': `${getVariableValue(tokens.color.PlumLight)}`,
    'tertiary-700': `${getVariableValue(tokens.color.Tertiary700)}`,
    'teal-600': `${getVariableValue(tokens.color.Teal600)}`,
  };

  return (
    <BaseCard
      {...rest}
      title={title}
      genericSecondary
      generic
      renderItemRight={
        <Icon
          name="chevron-right"
          color={getVariableValue(tokens.color.White)}
        />
      }
      backgroundColor={backgroundColorVariant[variant]}
    />
  );
};
