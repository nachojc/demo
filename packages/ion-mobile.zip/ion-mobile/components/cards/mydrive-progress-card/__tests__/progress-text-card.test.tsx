import { render, screen } from '@src/jest/testing-library';

import { myDriveMessages, ProgressTextCard } from '../progress-text-card';

describe('ProgressTextCard', () => {
  it('renders MissedTime copy', () => {
    render(<ProgressTextCard message="MissedTime" onPress={() => null} />);
    expect(screen.getByText(myDriveMessages.MissedTime)).toBeOnTheScreen();
  });

  it('renders MissedMiles copy', () => {
    render(<ProgressTextCard message="MissedMiles" onPress={() => null} />);
    expect(screen.getByText(myDriveMessages.MissedMiles)).toBeOnTheScreen();
  });

  it('renders GoalsReached copy', () => {
    render(<ProgressTextCard message="GoalsReached" onPress={() => null} />);
    expect(screen.getByText(myDriveMessages.GoalsReached)).toBeOnTheScreen();
  });
});
