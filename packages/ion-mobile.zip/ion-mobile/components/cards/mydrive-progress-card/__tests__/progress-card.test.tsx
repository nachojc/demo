import { render, screen } from '@src/jest/testing-library';

import { ProgressCard } from '../progress-card';

describe('ProgressCard', () => {
  it('should render all expected attributes', () => {
    render(
      <ProgressCard
        title="test header"
        deadline="deadline"
        scoreOne={200}
        scoreTwo={10}
        metricOne={'mile'}
        metricTwo={'day'}
        goalOne={400}
        goalTwo={60}
        onPress={() => null}
      />
    );
    expect(screen.getByText('test header')).toBeDefined();
    expect(screen.getByText('Complete before: deadline')).toBeDefined();
    expect(screen.getByText('200 miles completed')).toBeDefined();
    expect(screen.getByText('10 days completed')).toBeDefined();
    expect(screen.getByText('Goal: 400 miles')).toBeDefined();
    expect(screen.getByText('Goal: 60 days')).toBeDefined();
  });
});
