import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import { Separator, Stack } from 'tamagui';

import { Text } from '../../text';
import { Card } from '../card';

export const myDriveMessages = {
  MissedTime:
    'There’s not enough time before your renewal to be eligible for a potential discount. But use MyDrive for a chance next time (once you’ve met the requirements), plus immediate help to improve your driving.',
  MissedMiles:
    'You haven’t completed the 400 miles needed to be eligible for a renewal discount this year. But use MyDrive for a chance next time (once you’ve met the requirements), plus immediate help to improve your driving.',
  GoalsReached:
    'Well done! You’re eligible for a potential renewal discount. Keep on using MyDrive for help to improve, because the better your driving score, the less you could pay.',
};

export type ProgressTextCardProps = {
  message: keyof typeof myDriveMessages;
  onPress: () => void;
};

export const ProgressTextCard = ({
  message,
  onPress,
}: ProgressTextCardProps) => {
  const bodyText = myDriveMessages[message];

  return (
    <Card>
      <Card.Generic.Content>
        <Stack gap="$md">
          <Text fontVariant="heading5-bold-Secondary800">Your progress</Text>
          <Separator borderColor="$Gray300" />
          <Text fontVariant="body-regular-Gray800">{bodyText}</Text>

          <Pressable
            accessibilityRole="link"
            onPress={onPress}
            testID={getTestId('learn-more-link')}
          >
            <Text
              fontVariant="small-semibold-Tertiary800"
              decoration="underline"
            >
              Learn more
            </Text>
          </Pressable>
        </Stack>
      </Card.Generic.Content>
    </Card>
  );
};
