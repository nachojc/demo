import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import { Stack } from 'tamagui';

import {
  MyDriveMetrics,
  MyDriveProgressBar,
} from '../../progress/mydrive-progress-bars/mydrive-progress-bar';
import { Text } from '../../text';
import { Card } from '../card';

export type ProgressCardProps = {
  title: string;
  deadline: string;
  scoreOne: number;
  scoreTwo: number;
  metricOne: MyDriveMetrics;
  metricTwo: MyDriveMetrics;
  goalOne: number;
  goalTwo: number;
  onPress: () => void;
};

export const ProgressCard = ({
  title,
  deadline,
  scoreOne,
  scoreTwo,
  metricOne,
  metricTwo,
  goalOne,
  goalTwo,
  onPress,
}: ProgressCardProps) => {
  return (
    <Card>
      <Card.Generic.Content>
        <Text
          fontVariant="heading5-bold-Secondary800"
          tamaguiTextProps={{ mb: '$sm' }}
        >
          {title}
        </Text>
        <Text fontVariant="overline-regular-Gray800">{`Complete before: ${deadline}`}</Text>

        <Stack my="$md">
          <Pressable
            accessibilityRole="link"
            onPress={onPress}
            testID={getTestId('learn-more-link')}
          >
            <Text
              decoration="underline"
              fontVariant="small-semibold-Tertiary800"
            >
              Learn more
            </Text>
          </Pressable>
        </Stack>

        <Stack gap="$xl">
          <MyDriveProgressBar
            goal={goalOne}
            metric={metricOne}
            score={scoreOne}
          />

          <MyDriveProgressBar
            goal={goalTwo}
            metric={metricTwo}
            score={scoreTwo}
          />
        </Stack>
      </Card.Generic.Content>
    </Card>
  );
};
