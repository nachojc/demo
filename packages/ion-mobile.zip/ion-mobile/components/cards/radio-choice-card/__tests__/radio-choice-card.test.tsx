import { fireEvent, render, screen } from '@src/jest/testing-library';

import { Text } from '../../../text';
import { RadioChoiceCard, RadioChoiceCardProps } from '../radio-choice-card';

const mockOnRadioCardPress = jest.fn();

const renderRadioChoiceComponent = (
  props: Partial<RadioChoiceCardProps> = {}
) => {
  return render(
    <RadioChoiceCard
      a11yOpts={{ item: 1, total: 1 }}
      headerTitle="choose my investments"
      headerVariant="directWealth"
      onPress={mockOnRadioCardPress}
      testID="test-card"
      {...props}
    >
      <Text fontVariant="heading5-regular-Secondary800">
        This is a test card body
      </Text>
    </RadioChoiceCard>
  );
};
describe('Radio Choice Card', () => {
  describe('Without customised props', () => {
    it('should render the card header', () => {
      renderRadioChoiceComponent();

      expect(
        screen.getByTestId('test:id/rc-header-container-test-card', {
          hidden: true,
        })
      ).toBeOnTheScreen();
    });

    it('should render the card body', () => {
      renderRadioChoiceComponent();

      expect(screen.getByText('This is a test card body')).toBeOnTheScreen();
    });

    it('should call the passed onPress function on press of the button', () => {
      renderRadioChoiceComponent();

      fireEvent.press(
        screen.getByTestId('test:id/rc-header-container-test-card')
      );

      expect(mockOnRadioCardPress).toHaveBeenCalledTimes(1);
    });
  });

  describe('With customised props', () => {
    it('should apply a green border when the selected state is passed', () => {
      renderRadioChoiceComponent({ isSelected: true });

      expect(
        screen.getByTestId('test:id/rc-choices-test-card', { hidden: true })
      ).toHaveStyle({ borderTopColor: '#4F9F31' });
    });
  });
});
