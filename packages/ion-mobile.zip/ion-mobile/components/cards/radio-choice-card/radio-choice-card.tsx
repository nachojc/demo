import { getTestId } from '@src/utils/get-test-id';
import { ReactNode } from 'react';
import { useTranslation } from 'react-i18next';
import { GetProps, StackProps, YStack } from 'tamagui';

import { Container } from '../../header/header.styles';
import { A11yCount, RadioButton } from '../../radio-button';
import { Text } from '../../text';
import {
  ChoiceCardBody,
  ChoiceCardContainer,
} from '../choice-card/choice-card.style';

export type RadioChoiceCardProps = {
  isSelected?: boolean;
  headerTitle?: string;
  headerVariant?: GetProps<typeof Container>['variant'];
  onPress?: () => void;
  children: ReactNode;
} & StackProps &
  A11yCount;

export const RadioChoiceCard = ({
  headerTitle,
  children,
  headerVariant = 'directWealth',
  isSelected = false,
  onPress,
  a11yOpts,
  ...stackProps
}: RadioChoiceCardProps) => {
  const { t } = useTranslation();

  const headerA11y = t('common.forms.radio.listItem', a11yOpts);

  return (
    <ChoiceCardContainer selected={isSelected} {...stackProps}>
      <Container
        variant={headerVariant}
        onPress={onPress}
        testID={getTestId(`rc-header-container-${stackProps.testID}`)}
        accessibilityRole="radio"
        accessibilityState={{ selected: isSelected }}
        accessibilityLabel={`${headerA11y} ${headerTitle}`}
        accessible
      >
        <YStack
          fd="row"
          ai="center"
          flex={1}
          p="$xs"
          importantForAccessibility="no-hide-descendants"
        >
          <RadioButton selected={isSelected} onPress={onPress} />
          <Text
            tamaguiTextProps={{ paddingHorizontal: '$xl' }}
            fontVariant={`heading5-regular-White`}
            testID={getTestId(`rc-header-${stackProps.testID}`)}
          >
            {headerTitle}
          </Text>
        </YStack>
      </Container>
      <ChoiceCardBody
        selected={isSelected}
        onPress={onPress}
        testID={getTestId(`rc-choices-${stackProps.testID}`)}
      >
        {children}
      </ChoiceCardBody>
    </ChoiceCardContainer>
  );
};
