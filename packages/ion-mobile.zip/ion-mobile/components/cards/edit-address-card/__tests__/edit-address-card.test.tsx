import { fireEvent, render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { EditAddressCard, EditAddressCardProps } from '../edit-address-card';

const onPressHandler = jest.fn();

const editAddessCardProps: EditAddressCardProps = {
  cardContent: {
    firstLineOfAddress: 'Address Line 1',
    secondLineOfAddress: 'Address Line 2',
    thirdLineOfAddress: 'Address Line 3',
    townOrCity: 'London',
    postcode: 'CR03BZ',
  },
  onCardPress: onPressHandler,
};

describe('EditAddressCard', () => {
  it('should render the edit address card component', () => {
    render(<EditAddressCard {...editAddessCardProps} />);

    const cardContainer = screen.getByA11yHint('Edit this address');

    expect(cardContainer).toBeOnTheScreen();
    expect(cardContainer).toHaveStyle({
      backgroundColor: '#FFFFFF',
      paddingTop: 16,
      paddingRight: 16,
      paddingBottom: 16,
      paddingLeft: 16,
      borderTopLeftRadius: 5,
      borderTopRightRadius: 5,
      borderBottomLeftRadius: 5,
      borderBottomRightRadius: 5,
    });
  });

  it('should render the passed heading', () => {
    render(<EditAddressCard {...editAddessCardProps} />);

    const heading = screen.getByText('Address');

    expect(heading).toBeOnTheScreen();
    expect(heading).toHaveStyle({
      fontSize: 16,
      color: '#122D44',
    });
  });

  it('should render the passed card content', () => {
    render(<EditAddressCard {...editAddessCardProps} />);

    const firstLineOfAddress = screen.getByText('Address Line 1');
    expect(firstLineOfAddress).toBeOnTheScreen();
    expect(firstLineOfAddress).toHaveStyle({
      fontSize: 14,
      color: '#373737',
    });

    expect(screen.getByText('Address Line 2')).toBeOnTheScreen();
    expect(screen.getByText('Address Line 3')).toBeOnTheScreen();
    expect(screen.getByText('London')).toBeOnTheScreen();
    expect(screen.getByText('CR03BZ')).toBeOnTheScreen();
  });

  it('should render the actionButton', () => {
    render(<EditAddressCard {...editAddessCardProps} />);

    expect(screen.getByRole('button', { name: 'Edit' })).toBeOnTheScreen();

    const editIcon = screen.getByTestId('test:id/icon-edit', {
      includeHiddenElements: true,
    });
    expect(editIcon).toHaveStyle({
      width: 24,
      height: 24,
    });
  });

  it('should call passed onPressHandler function on address card press', () => {
    render(<EditAddressCard {...editAddessCardProps} />);

    fireEvent.press(screen.getByA11yHint('Edit this address'));

    expect(onPressHandler).toHaveBeenCalledTimes(1);
  });

  it('should not render undefined card content values', () => {
    render(
      <EditAddressCard
        {...{
          ...editAddessCardProps,
          cardContent: {
            firstLineOfAddress: 'Address Line 1',
            secondLineOfAddress: undefined,
            thirdLineOfAddress: undefined,
            townOrCity: 'London',
            postcode: 'CR03BZ',
          },
        }}
      />
    );

    expect(screen.getAllByRole('text')).toHaveLength(5);
  });

  it('edit button should have empty accessibility label to hide it from screen reader', () => {
    render(<EditAddressCard {...editAddessCardProps} />);

    fireEvent.press(screen.getByTestId(getTestId('edit-button')));

    expect(screen.getByTestId(getTestId('edit-button'))).toHaveProp(
      'accessibilityLabel',
      ''
    );
  });

  it('should return formatted accessibilityLabel for postcode', () => {
    render(<EditAddressCard {...editAddessCardProps} />);
    expect(screen.getByLabelText('C R 0 3 B Z,')).toBeOnTheScreen();
  });
});
