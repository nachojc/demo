import { styled, YStack } from 'tamagui';

export const CardContainer = styled(YStack, {
  backgroundColor: '$White',
  padding: '$xl',
  borderRadius: '$2',
  elevation: '$2',
});
