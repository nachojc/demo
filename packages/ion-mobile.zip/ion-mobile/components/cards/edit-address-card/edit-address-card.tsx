import { tokens } from '@src/theme/tokens';
import { spellOutString } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { useTranslation } from 'react-i18next';
import { XStack } from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import { CardContainer } from './edit-address-card.style';

export type EditAddressCardProps = {
  cardContent: object;
  onCardPress: () => void;
};

// Figma Master Component: https://www.figma.com/file/dqw5MuY2Uza1SByJXkYMXe/Tigris---Cross-Platform?type=design&node-id=8088-24654&mode=design&t=tfAAV9MCbATgkaB4-0

/**
 * Edit Address Card component
 * @param cardContent Param to accept card content as an object eg. { firstLineOfAddress: 'Address Line 1', secondLineOfAddress: 'Address Line 2' }
 * @param onCardPress Param to accept on card press handler
 */

export const EditAddressCard = ({
  cardContent,
  onCardPress,
}: EditAddressCardProps) => {
  const { t } = useTranslation(undefined, { keyPrefix: 'editAddressCard' });

  const formatLabel = (key: string, value: string) => {
    return `${key === 'postcode' ? spellOutString(value) : value},`;
  };

  return (
    <CardContainer
      testID={getTestId('address-card')}
      role="button"
      onPress={onCardPress}
      accessible
      accessibilityHint={t('editAddressA11YHint')}
    >
      <XStack justifyContent="space-between" marginBottom="$md">
        <Text fontVariant="body-semibold-Secondary800">
          {t('addressCardTitle')}
        </Text>
        <XStack accessibilityLabel="" testID={getTestId('edit-button')}>
          <Icon
            name="edit"
            width={tokens.size[6].val}
            height={tokens.size[6].val}
          />
          <Text
            fontVariant="body-semibold-Tertiary800"
            tamaguiTextProps={{ marginLeft: '$md' }}
          >
            {t('editCTA')}
          </Text>
        </XStack>
      </XStack>
      {Object.entries(cardContent).map(([key, value]) => {
        return (
          value && (
            <Text
              key={key}
              fontVariant="small-regular-Gray800"
              tamaguiTextProps={{
                accessibilityLabel: formatLabel(key, value),
              }}
            >
              {value}
            </Text>
          )
        );
      })}
    </CardContainer>
  );
};
