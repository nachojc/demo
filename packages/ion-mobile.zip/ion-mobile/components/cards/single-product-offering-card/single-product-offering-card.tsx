import { getTestId } from '@src/utils/get-test-id';
import { Dimensions, Linking, Pressable } from 'react-native';
import { Card, styled, XStack } from 'tamagui';

import { Image } from '../../image';
import { SkeletonContent } from '../../skeleton-content';
import { Text } from '../../text';

type SingleProductOfferingCardTextProps = {
  headline: string;
  summary: string;
  ctaText: string;
};

type SingleProductOfferingCardProps = SingleProductOfferingCardTextProps & {
  ctaUrl: string;
  imageUrl: string;
  isLoading?: boolean;
  ctaActionTag?: string;
  disabled?: boolean;
};

const SingleProductOfferingCardText = ({
  headline,
  summary,
  ctaText,
}: SingleProductOfferingCardTextProps) => {
  return (
    <>
      <Text
        fontVariant="body-semibold-White"
        tamaguiTextProps={{ color: '$White' }}
      >
        {headline ? headline : null}
      </Text>

      <Text
        fontVariant="body-regular-White"
        tamaguiTextProps={{ color: '$White', paddingVertical: '$space.md' }}
      >
        {summary ? summary : null}
      </Text>

      <Text
        tamaguiTextProps={{ paddingVertical: '$space.md' }}
        fontVariant="body-semibold-Primary500"
      >
        {ctaText ? ctaText : null}
      </Text>
    </>
  );
};

const cardHeight = 200;
const cardWidth = '100%';

export const SingleProductOfferingCard = ({
  headline,
  summary,
  ctaText,
  ctaUrl,
  imageUrl,
  isLoading,
  disabled,
}: SingleProductOfferingCardProps) => {
  const screenWidth = Dimensions.get('window').width;
  if (isLoading) {
    return (
      <SkeletonContent
        height={cardHeight}
        width={cardWidth}
        layout={[
          {
            key: 'skeleton-line-1',
            width: screenWidth - 235,
            height: 16,
            marginTop: 32,
          },
          {
            key: 'skeleton-line-2',
            width: screenWidth - 70,
            height: 16,
            marginTop: 16,
          },
          {
            key: 'skeleton-line-3',
            width: screenWidth - 95,
            height: 16,
            marginTop: 8,
          },
          {
            key: 'skeleton-line-4',
            width: screenWidth - 175,
            height: 24,
            marginTop: 16,
          },
        ]}
      />
    );
  }

  const onPress = () => {
    Linking.openURL(ctaUrl);
  };

  return (
    <Pressable
      testID={getTestId('single-product-offering-image-pressable')}
      accessibilityRole={disabled ? 'none' : 'button'}
      disabled={disabled}
      onPress={onPress}
    >
      <CardContainer>
        <Card.Background>
          <Image
            accessibilityIgnoresInvertColors
            style={{ width: '100%', height: cardHeight, alignSelf: 'center' }}
            resizeMode="cover"
            source={{ uri: imageUrl }}
            testID="image"
          />
        </Card.Background>

        <Card.Header flex={1} alignItems="flex-start" justifyContent="flex-end">
          <SingleProductOfferingCardText
            headline={headline}
            summary={summary}
            ctaText={ctaText}
          />
        </Card.Header>

        <CardTintOverlay />
      </CardContainer>
    </Pressable>
  );
};

export const CardContainer = styled(Card, {
  elevation: '$1',
  shadowOpacity: 0.15,
  width: cardWidth,
  padding: '$xl',
  borderRadius: 8,
  height: cardHeight,
});

export const CardTintOverlay = styled(XStack, {
  position: 'absolute',
  height: cardHeight,
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
  backgroundColor: '#333',
  opacity: 0.3,
  flex: 0,
  borderRadius: 8,
});
