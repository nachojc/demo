import { render, screen } from '@src/jest/testing-library';
import { config } from '@config';

import { SingleProductOfferingCard } from '../single-product-offering-card';

const mockProps = {
  imageUrl:
    'https://cdn.aviva.com/shared/images/myaviva-app/classic-motor-insurance-v1.jpg',
  headline: 'Motor',
  summary: 'Cover that keeps your car on the road.',
  ctaUrl:
    config.BASE_URL.get() +
    '/quote/direct/motor?source=CAPC%26cmp=welcome-view-motor-quote',
  ctaText: 'Get a quote',
  ctaActionTag: 'ukmyaviva|welcome|motor-tapped',
};

describe('SingleProductOfferingCard', () => {
  it('renders title and content', () => {
    render(<SingleProductOfferingCard {...mockProps} />);

    const [title, content] = screen.getAllByRole('text');
    expect(title).toHaveTextContent(mockProps.headline);
    expect(content).toHaveTextContent(mockProps.summary);
  });

  it('renders background image', () => {
    render(<SingleProductOfferingCard {...mockProps} />);

    expect(screen.getByTestId('image')).toBeOnTheScreen();
  });
});
