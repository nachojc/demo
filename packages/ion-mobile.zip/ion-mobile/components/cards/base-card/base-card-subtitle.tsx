import { isValidElement } from 'react';

import { Text } from '../../text';
import { BaseCardProps } from './base-card';
import { SubtitleText } from './base-card.style';

type BaseCardSubtitleProps = Pick<
  BaseCardProps,
  'subtitle' | 'link' | 'onLinkPress' | 'genericSecondary' | 'subtitleTextProps'
>;

export const BaseCardSubtitle = ({
  subtitle,
  link,
  onLinkPress,
  genericSecondary,
  subtitleTextProps,
}: BaseCardSubtitleProps) => {
  if (isValidElement(subtitle)) {
    return subtitle;
  }

  return (
    <SubtitleText
      {...subtitleTextProps}
      genericSecondary={genericSecondary}
      testID="card-subtitle"
    >
      {subtitle}
      {link && (
        <>
          <Text
            tamaguiTextProps={{
              testID: 'subtitle-link',
              onPress: onLinkPress,
              textDecorationLine: 'underline',
              accessibilityRole: 'link',
            }}
            fontVariant="small-regular-Tertiary800"
          >
            {link}
          </Text>
          <Text fontVariant="small-regular-Gray800">.</Text>
        </>
      )}
    </SubtitleText>
  );
};
