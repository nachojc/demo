import { Stack, styled, Text, XStack } from 'tamagui';

export const CardContainer = styled(XStack, {
  accessible: true,
  flexDirection: 'row',
  alignItems: 'center',
  marginBottom: '$xl',
  paddingVertical: '$xl',
  paddingHorizontal: '$xl',
  bg: '$White',
  variants: {
    showBorder: {
      true: {
        borderRadius: '$2',
        borderColor: '$Gray200',
        borderWidth: '$xxs',
        borderStyle: 'solid',
      },
    },
    selected: {
      true: {
        borderColor: '$Success',
        borderWidth: '$xs',
      },
    },
    disabled: {
      true: {
        borderColor: '$Gray300',
        borderWidth: '$xxs',
      },
    },
    error: {
      true: {
        borderColor: '$Error',
        borderWidth: '$xs',
      },
    },
    subtitleIncluded: {
      true: {
        padding: '$xl',
      },
    },
    generic: {
      true: {
        alignItems: 'flex-start',
        elevation: '$1',
        shadowOpacity: 0.15,
        borderWidth: '$0',
        p: 0,
      },
    },
    genericSecondary: {
      true: {
        bg: '$Secondary800',
      },
    },
    notification: {
      true: {
        alignItems: 'flex-start',
        padding: '$xl',
      },
    },
    snackbar: {
      true: {
        elevation: '$1',
        mb: '$xl',
        py: '$0',
        pr: '$0',
      },
    },
    snackbarSingleLine: {
      true: {
        h: '$8',
      },
    },
    snackbarSingleLineNoPadding: {
      true: {
        h: '$8',
        marginVertical: '$0',
        paddingVertical: '$0',
      },
    },
    snackbarTwoLine: {
      true: {
        h: '$9',
      },
    },
    snackbarMultiLine: {
      true: {
        alignItems: 'flex-start',
        flexDirection: 'column',
        pt: '$xl',
        pb: '$sm',
      },
    },
  } as const,
});

export const ContainerLeft = styled(Stack, {
  paddingRight: '$lg',
  flexDirection: 'row',
  height: '100%',
  variants: {
    generic: {
      true: {
        py: '$3.5',
        pl: '$3.5',
        pr: '$0',
      },
    },
    snackbar: {
      true: {
        ai: 'center',
        f: 1,
      },
    },
  } as const,
});

export const TextContainer = styled(Stack, {
  alignItems: 'flex-start',
  paddingRight: '$xl',
  f: 10,
  variants: {
    generic: {
      true: {
        p: '$xl',
      },
    },
    notification: {
      true: {
        marginRight: '$md',
        p: '$0',
      },
    },
    snackbar: {
      true: {
        f: 1,
        pr: '$0',
      },
    },
    snackbarMultiLine: {
      true: {
        f: 0,
      },
    },
  } as const,
});

export const OverlineText = styled(Text, {
  color: '$Gray800',
  fontWeight: '400',
  variants: {
    genericSecondary: {
      true: {
        color: '$White',
        fontFamily: '$heading',
      },
    },
  },
});

export const LabelTextContainer = styled(Stack, {
  variants: {
    notification: {
      true: {
        paddingBottom: '$sm',
      },
    },
  },
});

export const LabelText = styled(Text, {
  color: '$Gray800',
  fontWeight: '600',
  fontSize: 12,
  variants: {
    generic: {
      true: {
        pb: '$sm',
      },
    },
    genericSecondary: {
      true: {
        color: '$Primary500',
      },
    },
  } as const,
});

export const TitleTextContainer = styled(Stack, {
  variants: {
    notification: {
      true: {
        paddingBottom: '$sm',
      },
    },
  },
});

export const TitleText = styled(Text, {
  color: '$Gray800',
  fontWeight: '$bold',
  variants: {
    generic: {
      true: {
        pb: '$sm',
        fontWeight: '$semibold',
        color: '$Secondary800',
        fontSize: '$body',
        fontFamily: '$heading',
      },
    },
    genericSecondary: {
      true: {
        color: '$White',
      },
    },
    notification: {
      true: {
        fontWeight: '$semibold',
        fontFamily: '$heading',
      },
    },
    snackbar: {
      true: {
        fontWeight: '$regular',
        fontFamily: '$body',
        color: '$White',
        pb: '$sm',
        pr: '$xl',
      },
    },
    selectionCard: {
      true: {
        fontWeight: '$semibold',
        fontFamily: '$body',
        fontSize: '$body',
      },
    },
  } as const,
});

export const SubtitleContainer = styled(Stack, {
  flexDirection: 'row',
  variants: {
    generic: {
      true: {
        pt: '$0',
        color: '$Gray800',
        fontSize: '$small',
      },
    },
    notification: {
      true: {
        paddingTop: '$0',
      },
    },
  } as const,
});

export const SubtitleText = styled(Text, {
  color: '$Gray800',
  fontWeight: '400',
  fontFamily: '$body',
  variants: {
    genericSecondary: {
      true: {
        color: '$White',
        fontFamily: '$heading',
      },
    },
  } as const,
});

export const DescriptiveCopyContainer = styled(Stack, {
  variants: {
    generic: {
      true: {
        pt: '$md',
        color: '$Gray800',
        fontSize: '$small',
      },
    },
  } as const,
});

export const DescriptiveCopyText = styled(Text, {
  color: '$Secondary800',
  fontWeight: '$semibold',
  fontFamily: '$body',
  variants: {
    genericSecondary: {
      true: {
        color: '$White',
      },
    },
  } as const,
});

export const ActionsContainer = styled(Stack, {
  variants: {
    notification: {
      true: {
        margin: '$0',
        padding: '$0',
      },
    },
  },
});

export const ContainerRight = styled(Stack, {
  position: 'absolute',
  right: '0%',
  top: '0%',
  mr: '$xl',
  paddingLeft: '$lg',
  paddingRight: '$xl',
  paddingVertical: '$md',
  variants: {
    subtitleIncluded: {
      true: {
        paddingTop: '$xl',
      },
    },
    generic: {
      true: {
        position: 'relative',
        p: '$0',
        mt: '$xl',
        h: '$6',
      },
    },
    notification: {
      true: {
        position: 'relative',
        p: '$0',
        ml: '$xs',
        h: '$6',
        mr: '$0',
      },
    },
    snackbar: {
      true: {
        position: 'relative',
        jc: 'center',
        ai: 'center',
        mr: '$0',
      },
    },
    snackbarMultiLine: {
      true: {
        ai: 'flex-end',
        w: '100%',
        h: '$8',
      },
    },
    selectionCard: {
      true: {
        px: '$0',
      },
    },
  } as const,
});
