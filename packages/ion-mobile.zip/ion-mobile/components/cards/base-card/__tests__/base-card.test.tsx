import { render, screen } from '@src/jest/testing-library';
import { Icon } from '@aviva/ion-mobile';
import { Image } from 'tamagui';

import { BaseCard } from '../base-card';

const imageURL = 'test.jpg';

describe('Base Card', () => {
  it('renders default base card', () => {
    render(<BaseCard />);

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: '#FFFFFF',
      borderTopWidth: 1,
      borderBottomWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
      borderStyle: 'solid',
      paddingTop: 16,
      paddingBottom: 16,
      paddingLeft: 16,
      paddingRight: 16,
    });
  });

  it('renders default base card with custom background and marginVertical', () => {
    render(<BaseCard bg="$Error" my="$xl" />);

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      backgroundColor: '#BD2624',
      marginTop: 16,
      marginBottom: 16,
    });
  });

  it('renders base card with text content', () => {
    render(
      <BaseCard
        title="it-title"
        subtitle="it-subtitle"
        descriptiveCopy="it-descriptiveCopy"
        renderItemLeft={<Icon name="alert-circle" />}
        renderItemRight={
          <Image
            accessibilityIgnoresInvertColors
            source={{ uri: imageURL }}
            width={40}
            height={40}
            resizeMode="contain"
            resizeMethod="resize"
          />
        }
      />
    );

    const icon = screen.getByTestId('left-container');
    expect(icon).toBeOnTheScreen();

    const image = screen.getByTestId('right-container');
    expect(image).toBeOnTheScreen();

    const title = screen.getByTestId('card-title');
    expect(title).toHaveTextContent('it-title');

    const subtitle = screen.getByTestId('card-subtitle');
    expect(subtitle).toHaveTextContent('it-subtitle');

    const descriptiveCopy = screen.getByTestId('card-descriptiveCopy');
    expect(descriptiveCopy).toHaveTextContent('it-descriptiveCopy');
  });

  it('renders base card with a label', () => {
    render(<BaseCard label="it-label" />);
    expect(screen.getByText('it-label')).toBeOnTheScreen();
  });

  it('renders default base card with subtitle included', () => {
    render(<BaseCard subtitleIncluded />);

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      paddingTop: 16,
      paddingBottom: 16,
      paddingLeft: 16,
      paddingRight: 16,
    });
  });

  it('renders selected base card', () => {
    render(<BaseCard selected />);

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      borderBottomColor: '#4F9F31',
      borderTopColor: '#4F9F31',
      borderRightColor: '#4F9F31',
      borderLeftColor: '#4F9F31',
      borderTopWidth: 2,
      borderBottomWidth: 2,
      borderLeftWidth: 2,
      borderRightWidth: 2,
    });
  });

  it('renders disabled base card', () => {
    render(<BaseCard disabled />);

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      borderBottomColor: '#CCCCCC',
      borderTopColor: '#CCCCCC',
      borderRightColor: '#CCCCCC',
      borderLeftColor: '#CCCCCC',
      borderTopWidth: 1,
      borderBottomWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
    });
  });

  it('renders default errored base card', () => {
    render(<BaseCard error />);

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      borderBottomColor: '#BD2624',
      borderTopColor: '#BD2624',
      borderRightColor: '#BD2624',
      borderLeftColor: '#BD2624',
      borderTopWidth: 2,
      borderBottomWidth: 2,
      borderLeftWidth: 2,
      borderRightWidth: 2,
    });
  });
});

it('renders base card without border style using showBorder', () => {
  render(<BaseCard showBorder={false} />);

  const card = screen.getByTestId('container');
  expect(card).toBeOnTheScreen();
  expect(card).not.toHaveStyle({
    borderStyle: 'solid',
  });
});

describe('Base Card variant: generic card', () => {
  it('renders base card as generic card type', () => {
    render(
      <BaseCard
        generic
        title="it-title"
        subtitle="it-subtitle"
        descriptiveCopy="it-descriptiveCopy"
        renderItemLeft={<Icon name="alert-circle" />}
        renderItemRight={
          <Image
            accessibilityIgnoresInvertColors
            source={{ uri: imageURL }}
            width={40}
            height={40}
            resizeMode="contain"
            resizeMethod="resize"
          />
        }
      />
    );

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      alignItems: 'flex-start',
      shadowOpacity: 0.15,
      borderTopWidth: 0,
      borderBottomWidth: 0,
      borderLeftWidth: 0,
      borderRightWidth: 0,
      paddingTop: 0,
      paddingBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
    });

    const textContainer = screen.getByTestId('text-container');
    expect(textContainer).toHaveStyle({
      paddingTop: 16,
      paddingBottom: 16,
      paddingLeft: 16,
      paddingRight: 16,
    });

    const title = screen.getByTestId('card-title');
    expect(title).toHaveStyle({
      paddingBottom: 4,
      color: '#122D44',
    });

    const subtitleTextContainer = screen.getByTestId('subtitle-text-container');
    expect(subtitleTextContainer).toHaveStyle({
      paddingTop: 0,
    });

    const descriptieCopyTextContainer = screen.getByTestId(
      'descriptiveCopy-text-container'
    );
    expect(descriptieCopyTextContainer).toHaveStyle({
      paddingTop: 8,
    });

    const descriptieCopyText = screen.getByTestId('card-descriptiveCopy');
    expect(descriptieCopyText).toHaveStyle({
      color: '#122D44',
    });

    const leftContainer = screen.getByTestId('left-container');
    expect(leftContainer).toHaveStyle({
      paddingTop: 0,
      paddingBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
    });

    const rightContainer = screen.getByTestId('right-container');
    expect(rightContainer).toHaveStyle({
      paddingTop: 0,
      paddingBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
      marginTop: 16,
      height: 24,
    });
  });

  it('renders base card as generic secondary card type', () => {
    render(
      <BaseCard
        generic
        title="it-title"
        subtitle="it-subtitle"
        descriptiveCopy="it-descriptiveCopy"
        genericSecondary
        renderItemLeft={<Icon name="alert-circle" />}
        renderItemRight={
          <Image
            accessibilityIgnoresInvertColors
            source={{ uri: imageURL }}
            width={40}
            height={40}
            resizeMode="contain"
            resizeMethod="resize"
          />
        }
      />
    );

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      backgroundColor: '#122D44',
    });

    const title = screen.getByTestId('card-title');
    expect(title).toHaveStyle({
      paddingBottom: 4,
      color: '#FFFFFF',
    });

    const subtitle = screen.getByTestId('card-subtitle');
    expect(subtitle).toHaveStyle({
      color: '#FFFFFF',
    });

    const descriptieCopyText = screen.getByTestId('card-descriptiveCopy');
    expect(descriptieCopyText).toHaveStyle({
      color: '#FFFFFF',
    });
  });
});

describe('Base Card variant: notification card', () => {
  it.skip('renders base card as notification card type', () => {
    render(
      <BaseCard
        notification
        actions
        title="it-title"
        subtitle="it-subtitle"
        descriptiveCopy="it-descriptiveCopy"
        renderItemLeft={<Icon name="alert-circle" />}
        renderItemRight={
          <Image
            accessibilityIgnoresInvertColors
            source={{ uri: imageURL }}
            width={40}
            height={40}
            resizeMode="contain"
            resizeMethod="resize"
          />
        }
      />
    );

    const card = screen.getByTestId('container');
    expect(card).toBeOnTheScreen();
    expect(card).toHaveStyle({
      alignItems: 'flex-start',
      paddingTop: 16,
      paddingBottom: 16,
      paddingLeft: 16,
      paddingRight: 16,
    });

    const textContainer = screen.getByTestId('text-container');
    expect(textContainer).toHaveStyle({
      marginRight: 8,
      paddingTop: 0,
      paddingBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
    });

    const titleTextContainer = screen.getByTestId('title-text-container');
    expect(titleTextContainer).toHaveStyle({
      paddingBottom: 4,
    });

    const title = screen.getByTestId('card-title');
    expect(title).toHaveStyle({
      fontWeight: '600',
    });

    const subtitleTextContainer = screen.getByTestId('subtitle-text-container');
    expect(subtitleTextContainer).toHaveStyle({
      paddingTop: 0,
    });

    const actionContainer = screen.getByTestId('action-container');
    expect(actionContainer).toHaveStyle({
      paddingTop: 0,
      paddingBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
      marginTop: 0,
      marginBottom: 0,
      marginLeft: 0,
      marginRight: 0,
    });

    const rightContainer = screen.getByTestId('right-container');
    expect(rightContainer).toHaveStyle({
      position: 'relative',
      paddingTop: 0,
      paddingBottom: 0,
      paddingLeft: 0,
      paddingRight: 0,
      marginLeft: 2,
      marginRight: 0,
      height: 24,
    });
  });
});
