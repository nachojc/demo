import { removeSlash } from '@src/utils/accessibility/remove-slash';
import { forwardRef, ReactNode } from 'react';
import { GestureResponderEvent } from 'react-native/types';
import { GetProps, TamaguiElement } from 'tamagui';

import { Text } from '../../text';
import {
  ActionsContainer,
  CardContainer,
  ContainerLeft,
  ContainerRight,
  DescriptiveCopyContainer,
  DescriptiveCopyText,
  LabelText,
  LabelTextContainer,
  SubtitleContainer,
  SubtitleText,
  TextContainer,
  TitleText,
  TitleTextContainer,
} from './base-card.style';
import { BaseCardSubtitle } from './base-card-subtitle';

export type BaseCardProps = GetProps<typeof CardContainer> & {
  label?: string;
  title?: ReactNode;
  subtitle?: ReactNode;
  overline?: string;
  descriptiveCopy?: ReactNode;
  renderItemLeft?: ReactNode;
  renderItemRight?: ReactNode;
  textContainerProps?: GetProps<typeof TextContainer>;
  labelTextProps?: GetProps<typeof LabelText>;
  titleTextProps?: GetProps<typeof TitleText>;
  subtitleContainerProps?: GetProps<typeof SubtitleContainer>;
  subtitleTextProps?: GetProps<typeof SubtitleText>;
  descriptiveCopyContainerProps?: GetProps<typeof DescriptiveCopyContainer>;
  descriptiveCopyTextProps?: GetProps<typeof DescriptiveCopyText>;
  containerLeftProps?: GetProps<typeof ContainerLeft>;
  containerRightProps?: GetProps<typeof ContainerRight>;
  actions?: ReactNode;
  selectionCard?: boolean;
  link?: ReactNode;
  onLinkPress?: (event: GestureResponderEvent) => void;
};

/**
 * @deprecated use Card instead
 */
export const BaseCard = forwardRef<TamaguiElement, BaseCardProps>(
  (
    {
      label,
      title,
      subtitle,
      overline,
      descriptiveCopy,
      selected,
      disabled,
      error,
      subtitleIncluded,
      generic,
      genericSecondary,
      renderItemLeft,
      renderItemRight,
      textContainerProps,
      labelTextProps,
      titleTextProps,
      subtitleContainerProps,
      subtitleTextProps,
      descriptiveCopyContainerProps,
      descriptiveCopyTextProps,
      containerLeftProps,
      containerRightProps,
      notification,
      actions,
      showBorder = true,
      snackbar,
      snackbarSingleLine,
      snackbarSingleLineNoPadding,
      snackbarTwoLine,
      snackbarMultiLine,
      selectionCard,
      link,
      onLinkPress,
      ...cardProps
    }: BaseCardProps,
    ref
  ) => (
    <CardContainer
      showBorder={showBorder}
      selected={selected}
      disabled={disabled}
      error={error}
      subtitleIncluded={subtitleIncluded}
      generic={generic}
      notification={notification}
      genericSecondary={genericSecondary}
      snackbar={snackbar}
      snackbarSingleLine={snackbarSingleLine}
      snackbarSingleLineNoPadding={snackbarSingleLineNoPadding}
      snackbarTwoLine={snackbarTwoLine}
      snackbarMultiLine={snackbarMultiLine}
      testID="container"
      ref={ref}
      {...cardProps}
    >
      {renderItemLeft && (
        <ContainerLeft
          {...containerLeftProps}
          generic={generic}
          snackbar={snackbar}
          testID="left-container"
        >
          {renderItemLeft}
        </ContainerLeft>
      )}
      <TextContainer
        {...textContainerProps}
        generic={generic}
        notification={notification}
        snackbar={snackbar}
        snackbarMultiLine={snackbarMultiLine}
        testID="text-container"
      >
        {overline && (
          <Text fontVariant="overline-regular-Gray800">{overline}</Text>
        )}
        {label && (
          <LabelTextContainer
            notification={notification}
            testID="label-text-container"
          >
            <LabelText
              {...labelTextProps}
              generic={generic}
              genericSecondary={genericSecondary}
              testID="card-label"
            >
              {label}
            </LabelText>
          </LabelTextContainer>
        )}
        {title && (
          <TitleTextContainer
            notification={notification}
            testID="title-text-container"
          >
            <TitleText
              {...titleTextProps}
              generic={generic}
              genericSecondary={genericSecondary}
              notification={notification}
              snackbar={snackbar}
              selectionCard={selectionCard}
              accessibilityLabel={removeSlash(title)}
              testID="card-title"
            >
              {title}
            </TitleText>
          </TitleTextContainer>
        )}
        {subtitle && (
          <SubtitleContainer
            {...subtitleContainerProps}
            generic={generic}
            notification={notification}
            testID="subtitle-text-container"
          >
            <BaseCardSubtitle
              subtitle={subtitle}
              link={link}
              onLinkPress={onLinkPress}
              genericSecondary={genericSecondary}
              subtitleTextProps={subtitleTextProps}
            />
          </SubtitleContainer>
        )}
        {descriptiveCopy && (
          <DescriptiveCopyContainer
            {...descriptiveCopyContainerProps}
            generic={generic}
            testID="descriptiveCopy-text-container"
          >
            <DescriptiveCopyText
              {...descriptiveCopyTextProps}
              genericSecondary={genericSecondary}
              testID="card-descriptiveCopy"
            >
              {descriptiveCopy}
            </DescriptiveCopyText>
          </DescriptiveCopyContainer>
        )}
        {actions && (
          <ActionsContainer
            notification={notification}
            testID="action-container"
          >
            {actions}
          </ActionsContainer>
        )}
      </TextContainer>
      {renderItemRight && (
        <ContainerRight
          {...containerRightProps}
          subtitleIncluded={subtitleIncluded}
          generic={generic}
          notification={notification}
          snackbar={snackbar}
          snackbarMultiLine={snackbarMultiLine}
          selectionCard={selectionCard}
          testID="right-container"
        >
          {renderItemRight}
        </ContainerRight>
      )}
    </CardContainer>
  )
);
