import { getTestId } from '@src/utils/get-test-id';
import { ReactNode, useState } from 'react';
import { getTokens, getVariableValue, Stack, Tokens, XStack } from 'tamagui';

import { ExpansionPanel } from '../../expansion-panel';
import { Icon } from '../../icon';
import { Text } from '../../text/text';
import { NotificationCardIconVariant } from '../notification-card';
import { Container, MiddleContainer } from './expandable-notification.style';

type ExpandableNotificationProps = {
  expandableSections: {
    title: string;
    contentString?: string;
    content?: ReactNode;
  }[];
  iconVariant: NotificationCardIconVariant;
  title?: string;
  copy?: string;
  initialyOpenIndex?: number;
};

const renderLeftIcon = (
  iconVariant: NotificationCardIconVariant,
  tokens: Tokens
) => {
  switch (iconVariant) {
    case 'success':
      return <Icon name="tick" />;
    case 'warning':
      return (
        <Icon
          name="alert-circle"
          color={getVariableValue(tokens.color.Warning)}
        />
      );
    case 'error':
      return (
        <Icon
          name="alert-circle"
          color={getVariableValue(tokens.color.Error)}
        />
      );
    case 'information':
      return (
        <Icon name="info" color={getVariableValue(tokens.color.Information)} />
      );
    default:
      return null;
  }
};

const renderContent = (content?: ReactNode, contentString?: string) => {
  if (content) {
    return content;
  }
  if (contentString) {
    return (
      <Text
        fontVariant="body-regular-Gray800"
        tamaguiTextProps={{ mb: '$xl', mx: '$xl' }}
      >
        {contentString}
      </Text>
    );
  }
  return '';
};

export const ExpandableNotification = ({
  title,
  copy,
  iconVariant,
  expandableSections,
  initialyOpenIndex,
}: ExpandableNotificationProps) => {
  const tokens = getTokens();
  const [selectedIndex, setSelectedIndex] = useState<number | undefined>(
    initialyOpenIndex
  );

  const handlePress = (index: number) => {
    if (selectedIndex === index) {
      setSelectedIndex(undefined);
    } else {
      setSelectedIndex(index);
    }
  };

  return (
    <Container>
      <XStack mb="$md" px="$xl">
        <Stack>{renderLeftIcon(iconVariant, tokens)}</Stack>
        <Text
          fontVariant="body-semibold-Gray800"
          testID="change-your-retirement-age-title"
          tamaguiTextProps={{ ml: '$md', flex: 1 }}
        >
          {title}
        </Text>
      </XStack>
      <MiddleContainer>
        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{ mb: '$xl', mx: '$xl' }}
        >
          {copy}
        </Text>
      </MiddleContainer>
      {expandableSections.map((section, index) => (
        <ExpansionPanel
          key={section.title}
          index={index}
          selectedIndex={index}
          isExpanded={selectedIndex === index}
          onPress={handlePress}
          title={section.title}
          titleTextStyle={{ fontWeight: '$semibold' }}
          content={renderContent(section.content, section.contentString)}
          noBorder={index === expandableSections.length - 1}
          testID={getTestId(`expansion-panel-${index}`)}
        />
      ))}
    </Container>
  );
};
