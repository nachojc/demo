import { fireEvent, render, screen } from '@src/jest/testing-library';

import { ExpandableNotification } from '../expandable-notification';

jest.useFakeTimers();

const expandableSections = [
  {
    title: 'This is first heading',
    content: 'First copy text',
  },
  {
    title: 'This is second heading',
    content: 'Second copy text',
  },
  {
    title: 'This is third heading',
    content: 'Third copy text',
  },
  {
    title: 'This is fourth heading',
    content: 'Fourth copy text',
  },
];

describe('ExpandableNotification Component', () => {
  it('expect all of the text to render correctly and press each expandable panel', () => {
    render(
      <ExpandableNotification
        copy="Lorem ipsum"
        title="This is a heading"
        iconVariant="warning"
        expandableSections={expandableSections}
      />
    );

    expect(screen.getByText('Lorem ipsum')).toBeOnTheScreen();
    expect(screen.getByText('This is a heading')).toBeOnTheScreen();

    expect(screen.getByText('This is first heading')).toBeOnTheScreen();
    expect(screen.getByText('This is second heading')).toBeOnTheScreen();
    expect(screen.getByText('This is third heading')).toBeOnTheScreen();
    expect(screen.getByText('This is fourth heading')).toBeOnTheScreen();

    const expandableHeader0 = screen.getByTestId(
      'test:id/expansion-panel-0--header'
    );
    fireEvent.press(expandableHeader0);

    const expandableHeader1 = screen.getByTestId(
      'test:id/expansion-panel-1--header'
    );
    fireEvent.press(expandableHeader1);

    const expandableHeader2 = screen.getByTestId(
      'test:id/expansion-panel-2--header'
    );
    fireEvent.press(expandableHeader2);

    const expandableHeader3 = screen.getByTestId(
      'test:id/expansion-panel-3--header'
    );
    fireEvent.press(expandableHeader3);

    const content = screen.getByTestId('test:id/expansion-panel-3--content');
    expect(content).toBeDefined();
  });
});
