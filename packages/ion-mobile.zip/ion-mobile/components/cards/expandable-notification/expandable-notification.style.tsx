import { Stack, styled } from 'tamagui';

export const MiddleContainer = styled(Stack, {
  borderColor: '$Gray200',
  borderBottomWidth: '$xxs',
  borderStyle: 'solid',
});

export const Container = styled(Stack, {
  paddingTop: '$xl',
  bg: '$White',
  borderRadius: '$2',
  borderColor: '$Gray200',
  borderWidth: '$xxs',
  borderStyle: 'solid',
});
