import { ChoiceCard, ChoiceCardProps } from '../choice-card/choice-card';

export type ChargesCardProps = Pick<
  ChoiceCardProps,
  'headerTitle' | 'variant' | 'children' | 'minHeight'
>;

export const ChargesCard = ({
  headerTitle,
  variant,
  children,
  minHeight,
}: ChargesCardProps) => {
  return (
    <ChoiceCard
      headerTitle={headerTitle}
      variant={variant}
      minHeight={minHeight}
    >
      {children}
    </ChoiceCard>
  );
};
