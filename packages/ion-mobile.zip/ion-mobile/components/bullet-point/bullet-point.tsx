import { SizeTokens, SpaceTokens, ThemeValueFallback } from 'tamagui';

import { FontVariant, Text } from '../text';

type BulletPointProps = {
  fontVariant?: FontVariant;
  size?: SizeTokens | ThemeValueFallback;
  marginLeft?: SpaceTokens | ThemeValueFallback;
  accessible?: boolean;
};

export const BulletPoint = ({
  fontVariant = 'body-regular-White',
  size = '$xl',
  marginLeft = '$md',
  accessible = true,
}: BulletPointProps) => {
  return (
    <Text
      fontVariant={fontVariant}
      tamaguiTextProps={{ width: size, marginLeft, accessible }}
    >
      •
    </Text>
  );
};
