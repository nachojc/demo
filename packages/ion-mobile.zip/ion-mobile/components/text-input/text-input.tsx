import { useA11yFocus } from '@hooks/use-a11y-focus';
import { MutableRefObject, useState } from 'react';
import {
  GetProps,
  getTokens,
  getVariableValue,
  Input,
  InputProps,
  styled,
  TamaguiElement,
  XStack,
} from 'tamagui';

import { ErrorMessage } from '../error-message';
import { Icon, IconName } from '../icon';

type ContainerProps = GetProps<typeof Container>;

export type TextInputProps = {
  containerProps?: ContainerProps;
  tamaguiInputProps?: InputProps & {
    ref?: MutableRefObject<TamaguiElement | undefined>;
  };
  leadingIcon?: IconName;
  error?: boolean;
  errorText?: string;
  disabled?: boolean;
  pressed?: boolean;
  active?: boolean;
  testID?: string;
  required?: boolean;
  textContentType?: InputProps['textContentType'];
};

export const TextInput = ({
  containerProps = {},
  tamaguiInputProps = {},
  leadingIcon,
  error,
  errorText,
  disabled,
  pressed,
  active,
  testID,
  required = false,
  textContentType = 'none',
}: TextInputProps) => {
  const tokens = getTokens();
  const [focused, setFocused] = useState(false);
  const {
    onFocus,
    onEndEditing,
    ref,
    accessibilityLabel,
    accessibilityHint,
    ...rest
  } = tamaguiInputProps;

  const { elementRef, focus } = useA11yFocus(ref);

  let borderColor = active || disabled ? '$Gray300' : '$Gray200';
  if (error) {
    borderColor = '$Error';
  } else if (pressed) {
    borderColor = '$Gray800';
  } else if (focused) {
    borderColor = '$Secondary800';
  }

  return (
    <>
      <Container
        testID="text-input-container"
        {...containerProps}
        borderColor={borderColor}
        borderWidth={error ? '$xs' : '$xxs'}
      >
        {leadingIcon && (
          <IconContainer error={error} testID="icon container">
            <Icon
              name={leadingIcon}
              accessibilityLabel={leadingIcon}
              accessibilityHint="Leading icon"
              color={getVariableValue(
                tokens.color[disabled ? '$Gray300' : '$Secondary800']
              )}
            />
          </IconContainer>
        )}
        <Input
          ref={elementRef}
          testID={testID}
          // TODO: move all of these styles to values from our theme
          accessibilityLabel={accessibilityLabel}
          accessibilityHint={
            required ? `Required ${accessibilityHint ?? ''}` : accessibilityHint
          }
          flex={5}
          size={getVariableValue(tokens.size['8'])}
          bc="$backgroundTransparent"
          style={{ paddingLeft: getVariableValue(tokens.space.md) }}
          fontWeight="$regular"
          bw={'$0'}
          fos="$body"
          ff="$body"
          blurOnSubmit={false}
          placeholderTextColor={getVariableValue(tokens.color.Gray500)}
          focusStyle={{ bw: 0 }}
          onFocus={(e) => {
            setFocused(true);
            if (onFocus) {
              onFocus(e);
            }
          }}
          onEndEditing={(e) => {
            setFocused(false);
            onEndEditing?.(e);
            error && focus(errorText);
          }}
          editable={!disabled}
          focusable={!disabled}
          disabled={disabled}
          textContentType={textContentType}
          {...rest}
        />
      </Container>
      {error ? <ErrorMessage error={errorText} /> : null}
    </>
  );
};

export const Container = styled(XStack, {
  backgroundColor: '$White',
  borderWidth: '$xxs',
  paddingHorizontal: '$sm',
  borderRadius: 5,
  borderColor: '$Gray200',
});

export const IconContainer = styled(XStack, {
  flex: 1,
  marginLeft: '$-sm',
  marginRight: '$sm',
  alignItems: 'center',
  justifyContent: 'center',
  height: '99%',
  borderTopLeftRadius: 5,
  borderBottomLeftRadius: 5,
  borderRightWidth: '$xxs',
  borderRightColor: '$Gray200',
  backgroundColor: '$Gray100',
  variants: {
    error: {
      true: {
        borderRightWidth: '$xs',
        borderRightColor: '$Error',
      },
    },
  },
});
