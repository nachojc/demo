import { MaskedNumberInput } from './masked-number-input';
import { NumberInputProps } from './number-input';

const sortCodeMask = [/\d/, /\d/, '-', /\d/, /\d/, '-', /\d/, /\d/, /\d/];

export const SortCodeInput = (props: NumberInputProps) => {
  return (
    <MaskedNumberInput
      {...props}
      mask={sortCodeMask}
      tamaguiInputProps={props.tamaguiInputProps}
    />
  );
};
