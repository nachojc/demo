import { render, screen, waitFor } from '@src/jest/testing-library';

import { MaskedNumberInput } from '../masked-number-input';

describe('<MaskedNumberInput />', () => {
  it('should format input value based on the mask', async () => {
    const maskedInput = [
      '(',
      /\d/,
      /\d/,
      ')',
      ' ',
      /\d/,
      /\d/,
      /\d/,
      /\d/,
      /\d/,
      '-',
      /\d/,
      /\d/,
      /\d/,
      /\d/,
    ];

    const onChangeTextMock = jest.fn();

    render(
      <MaskedNumberInput
        mask={maskedInput}
        tamaguiInputProps={{
          onChangeText: (val) => {
            onChangeTextMock(val);
          },
          value: '99999999999',
          testID: 'numeric-input',
        }}
      />
    );

    const input = await screen.findByTestId('numeric-input');
    expect(input).toBeOnTheScreen();

    await waitFor(() =>
      expect(screen.getByDisplayValue('(99) 99999-9999')).toBeVisible()
    );
  });
});
