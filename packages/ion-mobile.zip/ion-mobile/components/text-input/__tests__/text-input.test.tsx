import { fireEvent, render, screen } from '@src/jest/testing-library';
import { useState } from 'react';

import { TextInput, TextInputProps } from '../text-input';

describe('<TextInput />', () => {
  describe('Error States', () => {
    it('should have non-focused border colour, when text input is non-focused state', () => {
      render(<TextInput tamaguiInputProps={{ accessibilityLabel: 'input' }} />);

      expect(screen.getByTestId('text-input-container')).toHaveStyle({
        borderLeftColor: '#D9D9D9',
        borderBottomWidth: 1,
      });
    });

    it('should have error styling applied, when error is true', () => {
      render(
        <TextInput tamaguiInputProps={{ accessibilityLabel: 'input' }} error />
      );

      expect(screen.getByTestId('text-input-container')).toHaveStyle({
        borderLeftColor: '#BD2624',
        borderBottomWidth: 2,
      });
    });

    it('should not display custom error message when error is false', () => {
      render(
        <TextInput
          tamaguiInputProps={{ accessibilityLabel: 'input' }}
          error={false}
          errorText="Some error message"
        />
      );

      expect(
        screen.queryByRole('text', { name: 'Some error message' })
      ).toBeFalsy();
    });

    it('should display custom error text when errorText is passed and error is true', () => {
      render(
        <TextInput
          tamaguiInputProps={{ accessibilityLabel: 'input' }}
          error
          errorText="CustomErrorText"
        />
      );

      expect(
        screen.getByRole('text', { name: 'CustomErrorText' })
      ).toBeOnTheScreen();
    });
  });

  describe('Focus States', () => {
    it('should have focused border colour, when text input is focused state', () => {
      render(<TextInput tamaguiInputProps={{ accessibilityLabel: 'input' }} />);

      const textInputContainer = screen.getByTestId('text-input-container');
      const textInputField = screen.getByLabelText('input');

      fireEvent(textInputField, 'onFocus');

      expect(textInputContainer).toHaveStyle({
        borderLeftColor: '#122D44',
        borderBottomWidth: 1,
      });

      fireEvent(textInputField, 'onEndEditing');
      expect(textInputContainer).toHaveStyle({
        borderLeftColor: '#D9D9D9',
        borderBottomWidth: 1,
      });
    });
  });

  describe('Pressed State', () => {
    it('should have pressed styling applied, when pressed is true', () => {
      render(
        <TextInput
          tamaguiInputProps={{
            accessibilityLabel: 'input',
          }}
          pressed
        />
      );

      const textInputContainer = screen.getByTestId('text-input-container');

      expect(textInputContainer).toHaveStyle({
        borderLeftColor: '#373737',
        borderBottomWidth: 1,
      });
    });
  });

  describe('Icon', () => {
    it('should not display icon if not passed in', () => {
      render(
        <TextInput
          tamaguiInputProps={{
            accessibilityLabel: 'input',
          }}
        />
      );
      const icon = screen.queryByTestId('icon container');
      expect(icon).toBeNull();
    });

    it('should have icon displayed on button, when isIcon is true', () => {
      render(
        <TextInput
          tamaguiInputProps={{
            accessibilityLabel: 'input',
          }}
          leadingIcon="alert-circle"
        />
      );
      const icon = screen.getByTestId('test:id/icon-alert-circle', {
        includeHiddenElements: true,
      });
      expect(icon).toBeDefined();
    });
  });

  describe('Disabled States', () => {
    const TextInputWithState = (props: TextInputProps) => {
      const [text, setText] = useState('');
      return (
        <TextInput
          {...props}
          tamaguiInputProps={{
            value: text,
            onChangeText: setText,
            ...props.tamaguiInputProps,
          }}
        />
      );
    };

    it('should not allow to be edited when disabled is true', async () => {
      render(
        <TextInputWithState
          tamaguiInputProps={{ accessibilityLabel: 'input' }}
          disabled
        />
      );

      const input = screen.getByLabelText('input');

      expect(input).toHaveProp('focusable', false);
      expect(input).toHaveProp('editable', false);
      expect(input).toBeDisabled();

      const CHANGE_TEXT = 'some new text';
      fireEvent.changeText(input, CHANGE_TEXT);
      expect(screen.queryByDisplayValue(CHANGE_TEXT)).toBeNull();
    });

    it('should allow to be edited when disabled is false', async () => {
      render(
        <TextInputWithState
          tamaguiInputProps={{ accessibilityLabel: 'input' }}
          disabled={false}
        />
      );

      const input = screen.getByLabelText('input');

      expect(input).toHaveProp('focusable', true);
      expect(input).toHaveProp('editable', true);
      expect(input).not.toBeDisabled();

      const CHANGE_TEXT = 'some new text';

      fireEvent.changeText(input, CHANGE_TEXT);
      expect(screen.getByDisplayValue(CHANGE_TEXT)).toBeOnTheScreen();
    });
  });
});
