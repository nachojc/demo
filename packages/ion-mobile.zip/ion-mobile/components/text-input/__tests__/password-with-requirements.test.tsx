import { PasswordValidationRequirements } from '@src/validation/schemas/set-password';

import {
  createRequirementsAccessibilityLabel,
  PasswordRequirementState,
} from '../password-with-requirements';

const [
  MinimumNumbersInvalid,
  MinimumCharactersInvalid,
  CasingInvalid,
  SymbolsInvalid,
] = PasswordValidationRequirements.map((r) => ({
  ...r,
  state: 'invalid' as PasswordRequirementState,
}));

describe('createRequirementsAccessibilityLabel', () => {
  describe('All', () => {
    it('should create a label when all requirements are untouched', () => {
      const result = createRequirementsAccessibilityLabel(
        PasswordValidationRequirements
      );

      expect(result).toBe(
        'Password must contain At least 1 number, Minimum of 8 characters, Uppercase & lowercase characters and No < or > symbols'
      );
    });

    it('should create a label when all requirements are valid', () => {
      const result = createRequirementsAccessibilityLabel(
        PasswordValidationRequirements.map((r) => ({ ...r, state: 'valid' }))
      );

      expect(result).toBe(
        'Password must contain At least 1 number, Minimum of 8 characters, Uppercase & lowercase characters and No < or > symbols'
      );
    });

    it('should create a label when all requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
        MinimumCharactersInvalid,
        CasingInvalid,
        SymbolsInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain At least 1 number, Minimum of 8 characters, Uppercase & lowercase characters and No < or > symbols'
      );
    });
  });

  describe('MinimumNumbers', () => {
    it('should create a label when MinimumNumbers, MinimumCharacters and Casing requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
        MinimumCharactersInvalid,
        CasingInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain At least 1 number, Minimum of 8 characters and Uppercase & lowercase characters'
      );
    });

    it('should create a label when MinimumNumbers and MinimumCharacters are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
        MinimumCharactersInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain At least 1 number and Minimum of 8 characters'
      );
    });

    it('should create a label when MinimumNumbers are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
      ]);

      expect(result).toBe('Error, Password must contain At least 1 number');
    });

    it('should create a label when MinimumNumbers, Casing and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
        CasingInvalid,
        SymbolsInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain At least 1 number, Uppercase & lowercase characters and No < or > symbols'
      );
    });

    it('should create a label when MinimumNumbers and Casing requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
        CasingInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain At least 1 number and Uppercase & lowercase characters'
      );
    });

    it('should create a label when MinimumNumbers, MinimumCharacters and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
        MinimumCharactersInvalid,
        SymbolsInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain At least 1 number, Minimum of 8 characters and No < or > symbols'
      );
    });

    it('should create a label when MinimumNumbers and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumNumbersInvalid,
        SymbolsInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain At least 1 number and No < or > symbols'
      );
    });
  });

  describe('MinimumCharacters', () => {
    it('should create a label when MinimumCharacters, Casing and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumCharactersInvalid,
        CasingInvalid,
        SymbolsInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain Minimum of 8 characters, Uppercase & lowercase characters and No < or > symbols'
      );
    });

    it('should create a label when MinimumCharacters and Casing requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumCharactersInvalid,
        CasingInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain Minimum of 8 characters and Uppercase & lowercase characters'
      );
    });

    it('should create a label when MinimumCharacters and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumCharactersInvalid,
        SymbolsInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain Minimum of 8 characters and No < or > symbols'
      );
    });

    it('should create a label when MinimumCharacters', () => {
      const result = createRequirementsAccessibilityLabel([
        MinimumCharactersInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain Minimum of 8 characters'
      );
    });
  });

  describe('Casing', () => {
    it('should create a label when Casing and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([
        CasingInvalid,
        SymbolsInvalid,
      ]);

      expect(result).toBe(
        'Error, Password must contain Uppercase & lowercase characters and No < or > symbols'
      );
    });

    it('should create a label when MinimumCharacters and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([CasingInvalid]);

      expect(result).toBe(
        'Error, Password must contain Uppercase & lowercase characters'
      );
    });
  });

  describe('Symbols', () => {
    it('should create a label when Casing and Symbols requirements are invalid', () => {
      const result = createRequirementsAccessibilityLabel([SymbolsInvalid]);

      expect(result).toBe('Error, Password must contain No < or > symbols');
    });
  });
});
