import { fireEvent, render, screen } from '@src/jest/testing-library';

import { NumberInput } from '../number-input';

describe('Numeric Input', () => {
  it('should render with £ prefix when symbol prop is passed with prefix', () => {
    render(<NumberInput symbol="prefix" />);

    const text = screen.getByRole('text', { name: '£' });
    expect(text).toBeOnTheScreen();
  });

  it('should render with % suffix when symbol prop is passed with suffix', () => {
    render(<NumberInput symbol="suffix" />);

    const text = screen.getByRole('text', { name: '%' });
    expect(text).toBeOnTheScreen();
  });
  it('render without prefix or suffix when no symbol prop passed', () => {
    render(<NumberInput testID="numeric-input" />);

    const input = screen.getByTestId('numeric-input');
    expect(input).toBeOnTheScreen();
    expect(screen.queryByRole('text', { name: '%' })).toBeNull();
    expect(screen.queryByRole('text', { name: '£' })).toBeNull();
  });

  it('should format the input value with 2 decimal points when finished editing', () => {
    const onFinishedMock = jest.fn();

    render(
      <NumberInput
        testID="numeric-input"
        tamaguiInputProps={{
          value: '4500',
          onEndEditing: (e) => {
            onFinishedMock(Number(e.nativeEvent.text).toFixed(2));
          },
        }}
      />
    );
    const input = screen.getByTestId('numeric-input');

    fireEvent(input, 'onEndEditing', { nativeEvent: { text: '4500' } });

    expect(onFinishedMock).toHaveBeenCalledWith('4500.00');
  });

  it('should remove non numeric characters when entered', () => {
    const onChangeTextMock = jest.fn();

    render(
      <NumberInput
        testID="numeric-input"
        tamaguiInputProps={{
          onChangeText: (val) => {
            onChangeTextMock(val);
          },
        }}
      />
    );

    const input = screen.getByTestId('numeric-input');
    fireEvent(input, 'onChangeText', '123cheese456');

    expect(onChangeTextMock).toHaveBeenCalledWith('123456');
  });

  it('should replace value by min limit value if value < min limit value', () => {
    const onChangeTextMock = jest.fn();

    render(
      <NumberInput
        testID="numeric-input"
        limits={{ min: 1, max: 100 }}
        tamaguiInputProps={{
          onChangeText: (val) => {
            onChangeTextMock(val);
          },
        }}
      />
    );

    const input = screen.getByTestId('numeric-input');
    fireEvent(input, 'onChangeText', '0');

    expect(onChangeTextMock).toHaveBeenCalledWith('1');
  });

  it('should replace value by max limit value if value > max limit value', () => {
    const onChangeTextMock = jest.fn();

    render(
      <NumberInput
        testID="numeric-input"
        limits={{ min: 1, max: 100 }}
        tamaguiInputProps={{
          onChangeText: (val) => {
            onChangeTextMock(val);
          },
        }}
      />
    );

    const input = screen.getByTestId('numeric-input');
    fireEvent(input, 'onChangeText', '123cheese456');

    expect(onChangeTextMock).toHaveBeenCalledWith('100');
  });

  it('should not allow to be edited when disabled is true', () => {
    render(<NumberInput testID="numeric-input" disabled />);

    const input = screen.getByTestId('numeric-input');

    expect(input).toHaveProp('focusable', false);
    expect(input).toHaveProp('editable', false);
  });

  it('should allow to be edited when disabled is false', () => {
    render(<NumberInput testID="numeric-input" />);

    const input = screen.getByTestId('numeric-input');

    expect(input).toHaveProp('focusable', true);
    expect(input).toHaveProp('editable', true);
  });

  it('should display custom error message when error is true and errorText is passed', () => {
    render(
      <NumberInput
        symbol="prefix"
        error
        errorText="Test error"
        tamaguiInputProps={{
          value: '4500',
        }}
      />
    );

    expect(screen.getByRole('text', { name: 'Test error' })).toBeOnTheScreen();
  });

  it('should not display custom error message when error is false', () => {
    render(
      <NumberInput
        symbol="prefix"
        error={false}
        errorText="Test error"
        tamaguiInputProps={{
          value: '4500',
        }}
      />
    );

    expect(screen.queryByRole('text', { name: 'Test error' })).toBeFalsy();
  });
});
