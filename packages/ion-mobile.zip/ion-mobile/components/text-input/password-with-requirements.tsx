import { getTestId } from '@src/utils/get-test-id';
import { useTranslation } from 'react-i18next';
import {
  Circle,
  getTokens,
  getVariableValue,
  styled,
  Text,
  XStack,
  YStack,
  YStackProps,
} from 'tamagui';

import { Icon } from '../icon';
import { Password, PasswordProps } from './password';

export type PasswordRequirementState = 'untouched' | 'valid' | 'invalid';

export type PasswordRequirement = {
  id: number;
  text: string;
  state: PasswordRequirementState;
  validation: (bool: string) => boolean;
};

export type PasswordWithRequirementsProps = PasswordProps & {
  requirements: PasswordRequirement[];
  containerProps?: YStackProps;
};

export const createRequirementsAccessibilityLabel = (
  requirements: PasswordRequirement[]
) => {
  const prefix = 'Password must contain';
  const formatText = (r: PasswordRequirement[]): string =>
    r.reduce((acc, { text }, index, arr) => {
      if (arr.length > 1 && index === arr.length - 1) {
        return `${acc} and ${text}`;
      }

      const t = index === 0 ? text : `, ${text}`;

      return `${acc}${t}`;
    }, '');
  const invalidRequirements = requirements.filter(
    ({ state }) => state === 'invalid'
  );

  return invalidRequirements.length
    ? `Error, ${prefix} ${formatText(invalidRequirements)}`
    : `${prefix} ${formatText(requirements)}`;
};

/** Password validation is done on screen/form level */
export const PasswordWithRequirements = ({
  requirements,
  containerProps,
  tamaguiInputProps,
  ...props
}: PasswordWithRequirementsProps) => {
  const tokens = getTokens();
  const { t } = useTranslation(undefined, {
    keyPrefix: 'common.forms.passwordWithRequirements',
  });
  return (
    <>
      <Password
        {...props}
        tamaguiInputProps={{
          ...tamaguiInputProps,
          accessibilityHint: t('accessibilityHint'),
        }}
        containerProps={{ marginTop: '$md' }}
      />
      <Container
        {...containerProps}
        accessible
        accessibilityLabel={createRequirementsAccessibilityLabel(requirements)}
        accessibilityRole="text"
      >
        {requirements.map((requirement) => (
          <RequirementRow key={requirement.id}>
            {['valid', 'invalid'].includes(requirement.state) ? (
              <Icon
                name={requirement.state === 'valid' ? 'tick' : 'x-circle'}
                height={getVariableValue(tokens.size['4'])}
              />
            ) : (
              <GrayCircle testID={getTestId('gray-circle')} />
            )}
            <Requirement>{requirement.text}</Requirement>
          </RequirementRow>
        ))}
      </Container>
    </>
  );
};

const Container = styled(YStack, {
  mt: '$lg',
});

const RequirementRow = styled(XStack, {
  marginBottom: '$md',
  marginLeft: '$-sm',
});

const GrayCircle = styled(Circle, {
  size: '$4',
  backgroundColor: '$Gray200',
  marginHorizontal: '$sm',
});

const Requirement = styled(Text, {
  fontSize: 14,
  color: '$Gray800',
  fontWeight: '600',
  marginLeft: '$lg',
});
