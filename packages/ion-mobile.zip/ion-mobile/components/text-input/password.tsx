import { useA11yFocus } from '@hooks/use-a11y-focus';
import { getTestId } from '@src/utils/get-test-id';
import { useState } from 'react';
import { AccessibilityInfo, Keyboard, Platform } from 'react-native';
import {
  getTokens,
  getVariableValue,
  Stack,
  styled,
  YStack,
  YStackProps,
} from 'tamagui';

import { Icon } from '../icon';
import { TextInput, TextInputProps } from './text-input';

export type PasswordProps = TextInputProps & {
  iconContainerProps?: YStackProps;
  containerProps?: YStackProps;
};

export const Password = ({
  tamaguiInputProps,
  iconContainerProps,
  containerProps,
  error,
  errorText,
  required,
}: PasswordProps) => {
  const tokens = getTokens();
  const [isVisible, setIsVisible] = useState(false);
  const { elementRef, focus } = useA11yFocus();

  const onPress = () => {
    if (Platform.OS === 'android') {
      AccessibilityInfo.announceForAccessibilityWithOptions(
        isVisible ? 'Show Password, button' : 'Hide Password, button',
        { queue: true }
      );
    }
    setIsVisible(!isVisible);
  };
  return (
    <YStack {...containerProps}>
      <TextInput
        testID={getTestId('password-input')}
        required={required}
        tamaguiInputProps={{
          autoCapitalize: 'none',
          spellCheck: false,
          ...tamaguiInputProps,
          autoComplete: tamaguiInputProps?.autoComplete || 'off',
          secureTextEntry: !isVisible,
          returnKeyType: 'done',
          onSubmitEditing: (e) => {
            tamaguiInputProps?.onSubmitEditing?.(e);
            Keyboard.dismiss();
            focus();
          },
        }}
        error={error}
        errorText={errorText}
      />
      <IconContainer
        ref={elementRef}
        accessible
        accessibilityLabel={isVisible ? 'Hide password' : 'Show password'}
        accessibilityRole="button"
        onPress={onPress}
        {...iconContainerProps}
      >
        <Icon
          accessible={false}
          importantForAccessibility="no-hide-descendants"
          name={isVisible ? 'eye' : 'eye-off'}
          color={getVariableValue(tokens.color.Gray200)}
        />
      </IconContainer>
    </YStack>
  );
};

const IconContainer = styled(Stack, {
  right: '$xl',
  marginTop: '$lg',
  position: 'absolute',
});
