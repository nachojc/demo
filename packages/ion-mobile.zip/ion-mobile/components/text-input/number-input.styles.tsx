import { styled, XStack } from 'tamagui';

export const SuffixSymbolContainer = styled(XStack, {
  flex: 1,
  alignItems: 'center',
  justifyContent: 'center',
  height: '99%',
  borderLeftWidth: 0.5,
  marginRight: '$-sm',
  borderTopRightRadius: 5,
  borderBottomRightRadius: 5,
  borderLeftColor: '$Gray200',
  backgroundColor: '$Gray100',
});
