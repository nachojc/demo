import { useA11yFocus } from '@hooks/use-a11y-focus';
import { getTestId } from '@src/utils/get-test-id';
import {
  removeLeadingZeroNonNumericNonIntegerValues,
  removeNonNumericValues,
} from '@src/utils/string-manipulation';
import { ReactNode, useState } from 'react';
import { getTokens, Input } from 'tamagui';

import { ErrorMessage } from '../error-message';
import { Text } from '../text/text';
import { SuffixSymbolContainer } from './number-input.styles';
import { Container, IconContainer, TextInputProps } from './text-input';

export type NumberInputProps = TextInputProps & {
  symbol?: 'prefix' | 'suffix';
  allowDecimal?: boolean;
  precision?: number;
  errorText?: ReactNode;
  testID?: string;
  limits?: { min: number; max: number };
};

export const NumberInput = ({
  containerProps = {},
  tamaguiInputProps = {},
  error,
  symbol,
  disabled,
  allowDecimal = true,
  precision = 2,
  errorText,
  testID,
  pressed,
  active,
  required,
  limits,
}: NumberInputProps) => {
  const tokens = getTokens();
  const [focused, setFocused] = useState(false);
  const { elementRef, focus } = useA11yFocus();

  const { accessibilityLabel, accessibilityHint } = tamaguiInputProps;

  let borderColor = active || disabled ? '$Gray300' : '$Gray200';
  if (pressed) {
    borderColor = '$Gray800';
  } else if (focused && !error) {
    borderColor = '$Secondary800';
  } else if (error) {
    borderColor = '$Error';
  }

  const checkLimits = (value: string) => {
    if (!value || !limits) {
      return value;
    }

    if (Number(value) < limits.min) {
      return limits.min.toString();
    }
    if (Number(value) > limits.max) {
      return limits.max.toString();
    }

    return value;
  };

  return (
    <>
      <Container
        {...containerProps}
        borderColor={borderColor}
        borderWidth={error ? '$xs' : '$xxs'}
        testID={getTestId('number-input-container')}
      >
        {symbol === 'prefix' && (
          <IconContainer
            accessible
            accessibilityLabel="£"
            borderRightColor={borderColor}
            borderRightWidth={error ? '$xs' : '$xxs'}
          >
            <Text fontVariant={'body-regular-Secondary800'}>£</Text>
          </IconContainer>
        )}
        <Input
          testID={testID}
          ref={elementRef}
          // TODO: move all of these styles to values from our theme
          {...tamaguiInputProps}
          accessibilityLabel={accessibilityLabel}
          accessibilityHint={
            required ? `Required ${accessibilityHint ?? ''}` : accessibilityHint
          }
          returnKeyType="done"
          keyboardType="numeric"
          flex={5}
          size={tokens.size[8].val}
          bc="$backgroundTransparent"
          bw={0}
          fos="$body"
          fontWeight="$regular"
          placeholderTextColor={tokens.color.Gray500.val}
          focusStyle={{ bw: 0 }}
          onFocus={(e) => {
            tamaguiInputProps.onFocus?.(e);
            setFocused(true);
          }}
          onEndEditing={(e) => {
            tamaguiInputProps.onEndEditing?.(e);
            setFocused(false);
            error && focus(errorText);
          }}
          onChangeText={(e) => {
            const filtered = allowDecimal
              ? removeNonNumericValues(e, precision)
              : removeLeadingZeroNonNumericNonIntegerValues(e);
            tamaguiInputProps.onChangeText?.(checkLimits(filtered));
          }}
          editable={!disabled}
          focusable={!disabled}
          ml="$md"
        />
        {symbol === 'suffix' && (
          <SuffixSymbolContainer
            accessible
            accessibilityLabel="%"
            borderLeftColor={borderColor}
            borderLeftWidth={error ? '$xs' : '$xxs'}
          >
            <Text fontVariant={'body-regular-Secondary800'}>%</Text>
          </SuffixSymbolContainer>
        )}
      </Container>
      {error ? <ErrorMessage error={errorText} /> : null}
    </>
  );
};
