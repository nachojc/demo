import { formatWithMask, Mask } from 'react-native-mask-input';

import { NumberInput, NumberInputProps } from './number-input';

type MaskedNumberInputProps = NumberInputProps & {
  mask: Mask;
};

export const MaskedNumberInput = ({
  mask,
  tamaguiInputProps,
  ...props
}: MaskedNumberInputProps) => {
  const { masked } = formatWithMask({
    text: tamaguiInputProps?.value,
    mask,
  });

  return (
    <NumberInput
      {...props}
      tamaguiInputProps={{
        ...tamaguiInputProps,
        value: masked,
      }}
    />
  );
};
