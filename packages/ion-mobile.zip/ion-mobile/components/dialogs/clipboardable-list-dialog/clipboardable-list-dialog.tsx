import { Stack, YStack } from 'tamagui';

import { ClipboardableList, ClipboardableListRow } from '../../list';
import {
  ContentContainer,
  Divider,
  TextContainer,
  TextVerticalSpacer,
} from '../../list/clipboardable-list.style';
import { Text } from '../../text';
import { Dialog, DialogTrigger } from '../dialogs';

export type ClipboardableListDialogItem = {
  item: ClipboardableListRow;
  onCopyPressed: (textToCopy: string) => void;
};

export type ClipboardableListDialogProps = {
  isOpen?: boolean;
  title: string;
  titleValueList?: ClipboardableListRow[];
  clipboardableList: ClipboardableListDialogItem[];
  closeButtonText: string;
  closeButtonAnalyticsTag: string;
  dialogTriggerTitle: string;
  dialogTrigger?: () => void;
};

export const ClipboardableListDialog = ({
  isOpen,
  title,
  titleValueList,
  clipboardableList,
  closeButtonText,
  closeButtonAnalyticsTag,
  dialogTriggerTitle,
  dialogTrigger,
}: ClipboardableListDialogProps) => {
  return (
    <>
      <Dialog
        open={isOpen}
        title={title}
        dialogTrigger={
          <DialogTrigger onPress={dialogTrigger} title={dialogTriggerTitle} />
        }
        actions={[
          {
            title: closeButtonText,
            analyticsTag: closeButtonAnalyticsTag,
          },
        ]}
      >
        <>
          {titleValueList && (
            <YStack backgroundColor={'$Gray050Opacity20'}>
              <Divider marginTop="$lg" marginHorizontal={'$-xl'} />
              {titleValueList.map((item) => (
                <Stack key={`${item.header}-${item.detail}`}>
                  <ContentContainer>
                    <TextContainer>
                      <Text fontVariant="body-semibold-Secondary800">
                        {item.header}
                      </Text>
                      <TextVerticalSpacer />
                      <Text fontVariant="small-regular-Gray800">
                        {item.detail}
                      </Text>
                    </TextContainer>
                  </ContentContainer>
                  <Divider />
                </Stack>
              ))}
            </YStack>
          )}
          <YStack>
            {clipboardableList.map((listItem, index, rows) => (
              <ClipboardableList
                items={[listItem.item]}
                onCopyPressed={listItem.onCopyPressed}
                key={`${listItem.item.header}-${listItem.item.detail}`}
                embedded
                lastItem={index + 1 === rows.length}
              />
            ))}
          </YStack>
        </>
      </Dialog>
    </>
  );
};
