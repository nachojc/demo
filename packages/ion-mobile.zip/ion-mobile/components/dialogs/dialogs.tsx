import { useAnalytics } from '@hooks/use-analytics';
import { useAppInBackground } from '@hooks/use-app-in-background';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { ReactNode } from 'react';
import { Freeze } from 'react-freeze';
import { useTranslation } from 'react-i18next';
import { AccessibilityRole, Modal } from 'react-native';
import {
  Dialog as TamaguiDialog,
  DialogProps as TamaguiDialogProps,
  getTokens,
  getVariableValue,
  Stack,
  styled,
  Text as TamaguiText,
  YStack,
} from 'tamagui';

import { Button, ButtonVariant } from '../button';
import { CloseButton } from '../close-button';
import { FocusAwareStatusBar } from '../focus-aware-status-bar';
import { FontVariant, Text } from '../text';

export type DialogTriggerProps = {
  title: string;
  onPress?: () => void;
  testID?: string;
  myDrive?: boolean;
  fontVariant?: FontVariant;
  accessibilityRole?: AccessibilityRole;
};

export const DialogTrigger = ({
  title,
  onPress,
  testID,
  fontVariant,
  myDrive = false,
  accessibilityRole,
}: DialogTriggerProps) => {
  const newFontVariant = myDrive
    ? 'small-semibold-Tertiary800'
    : fontVariant ?? 'body-regular-Tertiary800';
  return (
    <TamaguiDialog.Trigger asChild accessibilityRole={accessibilityRole}>
      <TextLinkStyle onPress={onPress} testID={testID}>
        <Text fontVariant={newFontVariant}>{title}</Text>
      </TextLinkStyle>
    </TamaguiDialog.Trigger>
  );
};

export type Action = {
  title: string;
  analyticsTag?: string;
  actionOnPress?: () => void;
  variant?: number;
};

const variant: Record<string, ButtonVariant> = {
  0: ButtonVariant.BRAND,
  1: ButtonVariant.OUTLINED,
  2: ButtonVariant.LINK_TEXT,
};

export const DialogActions = ({ actions }: { actions: Action[] }) => {
  const { trackUserEvent } = useAnalytics();

  const customOnPress = (action: Action) => {
    if (action.actionOnPress) {
      action.actionOnPress();
    }

    if (!action.analyticsTag) {
      return;
    }

    trackUserEvent(action.analyticsTag);
  };

  return (
    <>
      {actions.map((action, i) => (
        <YStack key={action.title} marginTop="$xl">
          <TamaguiDialog.Close
            accessibilityLabel={action.title}
            displayWhenAdapted
            asChild
          >
            <Button
              variant={action.variant ? variant[action.variant] : variant[i]}
              height={44}
              aria-label={action.title}
              onPress={() => customOnPress(action)}
            >
              {action.title}
            </Button>
          </TamaguiDialog.Close>
        </YStack>
      ))}
    </>
  );
};

export type DialogProps = TamaguiDialogProps & {
  title: string | ReactNode;
  copy?: ReactNode;
  children?: ReactNode;
  dialogTrigger?: ReactNode;
  center?: boolean;
  icon?: ReactNode;
  child?: ReactNode;
  actions?: Action[];
  cancelButton?: boolean;
  cancelButtonText?: string;
  cancelButtonHint?: string;
  cancelButtonTag?: string;
  onPressCancel?: () => void;
  onPressClose?: () => void;
  testID?: string;
  copyTestID?: string;
  hideGrey?: boolean;
};

export const Dialog = ({
  title,
  copy,
  center,
  icon,
  child,
  dialogTrigger,
  children,
  actions = [],
  cancelButton,
  cancelButtonText,
  cancelButtonHint,
  cancelButtonTag,
  open,
  onPressCancel,
  onPressClose,
  copyTestID,
  hideGrey = false, // set true when persisting grey background is a problem
  ...props
}: DialogProps) => {
  const { trackUserEvent } = useAnalytics();
  const { showSecurityScreen } = useAppInBackground();
  const tokens = getTokens();

  const { t } = useTranslation();
  // TODO: remove it once decided to keep the close icon
  const showCloseIcon = false;
  const showDialog = hideGrey ? open : true;

  return (
    <>
      {!showSecurityScreen && showDialog && (
        <Freeze freeze={showSecurityScreen}>
          <TamaguiDialog {...props} open={open}>
            {dialogTrigger}
            <TamaguiDialog.Portal>
              <TamaguiDialog.Overlay
                key="overlay"
                animation="fast"
                o={0.67}
                bg="$Gray800"
                enterStyle={{ o: 0 }}
                exitStyle={{ o: 0 }}
                forceMount
              />
              <Modal
                key="modal"
                animationType="none"
                onRequestClose={onPressClose}
                statusBarTranslucent
                transparent
                visible
                supportedOrientations={['portrait', 'landscape']}
              >
                <YStack
                  key="contentContainer"
                  {...{
                    alignItems: 'center',
                    justifyContent: 'center',
                    flex: 1,
                  }}
                >
                  <TamaguiDialog.Content
                    key="content"
                    mx="$xl"
                    borderRadius={6}
                    bordered
                    elevate
                    space="$xl"
                    {...(isIpad
                      ? {
                          minWidth: tokens.size['$17.5'].val,
                          maxWidth: tokens.size['$17.5'].val,
                        }
                      : { width: '92%' })}
                    testID="dialog"
                  >
                    <YStack
                      padding="$xl"
                      testID={
                        props.testID ? props.testID : getTestId('call-us-modal')
                      }
                    >
                      {showCloseIcon && onPressClose ? (
                        <CloseButton
                          onPress={onPressClose}
                          position="absolute"
                          right="$xl"
                          top="$xl"
                          zIndex={'$5'}
                          iconProps={{
                            color: getVariableValue(tokens.color.Tertiary800),
                          }}
                        />
                      ) : undefined}
                      <YStack>
                        <FocusAwareStatusBar
                          translucent
                          backgroundColor="transparent"
                        />

                        {center && <YStack ai="center">{icon}</YStack>}

                        <Text
                          fontVariant={
                            typeof title === 'string'
                              ? 'heading4-semibold-Secondary800'
                              : 'overline-black-Gray500'
                          }
                          tamaguiTextProps={{
                            testID: getTestId('modal-title'),
                            fontFamily: '$heading',
                            style: {
                              textAlign: center ? 'center' : 'left',
                              marginTop: tokens.space.md.val,
                            },
                            ...(typeof title === 'string'
                              ? {
                                  accessibilityLabel: `${t(
                                    'common.dialog.titleAccessibilityLabel'
                                  )}${title}`,
                                  accessibilityRole: 'header',
                                }
                              : {}),
                            accessibilityElementsHidden: !title ? true : false,
                            importantForAccessibility: !title
                              ? 'no-hide-descendants'
                              : 'yes',
                          }}
                        >
                          {title}
                        </Text>

                        {copy ? (
                          <Text
                            testID={
                              copyTestID ? copyTestID : getTestId('modal-copy')
                            }
                            fontVariant="body-regular-Gray800"
                            tamaguiTextProps={{
                              marginVertical: '$sm',
                              style: {
                                textAlign: center ? 'center' : 'left',
                              },
                            }}
                          >
                            {copy}
                          </Text>
                        ) : null}

                        {child}
                        {children}

                        <DialogActions actions={actions} />
                        {cancelButton ? (
                          <Stack
                            alignItems="center"
                            marginTop="$xxl"
                            marginBottom="$xl"
                            testID={getTestId('modal-cancel-btn')}
                          >
                            <TamaguiDialog.Close
                              alignSelf="stretch"
                              alignItems="center"
                              accessible
                              accessibilityLabel={
                                cancelButtonText ?? t('common.buttons.cancel')
                              }
                              accessibilityHint={cancelButtonHint}
                              accessibilityRole="button"
                              onPress={() => {
                                cancelButtonTag &&
                                  trackUserEvent(cancelButtonTag);
                                if (onPressCancel) {
                                  onPressCancel();
                                }
                              }}
                            >
                              <Text fontVariant="body-semibold-Tertiary800">
                                {cancelButtonText ?? t('common.buttons.cancel')}
                              </Text>
                            </TamaguiDialog.Close>
                          </Stack>
                        ) : null}
                      </YStack>
                    </YStack>
                  </TamaguiDialog.Content>
                </YStack>
              </Modal>
            </TamaguiDialog.Portal>
          </TamaguiDialog>
        </Freeze>
      )}
    </>
  );
};

export const TextLinkStyle = styled(TamaguiText, {
  borderBottomColor: '$Tertiary800',
  textDecorationLine: 'underline',
});
