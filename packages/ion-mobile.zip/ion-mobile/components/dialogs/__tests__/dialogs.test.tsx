import { render, screen } from '@src/jest/testing-library';
import { Dialog, Text } from '@aviva/ion-mobile';

jest.mock('@hooks/use-app-in-background', () => ({
  useAppInBackground: () => ({ showSecurityScreen: false }),
}));

describe('Dialogs A11y', () => {
  it('should render the correct title when a title is provided as a string', () => {
    render(<Dialog open title={'My String Title'} />);
    expect(screen.getByText('My String Title')).toBeOnTheScreen();
  });

  it('should render the correct title when a title is provided as a Node', () => {
    render(
      <Dialog
        open
        title={<Text fontVariant="heading3-bold-Gray800">My Node Title</Text>}
      />
    );
    expect(screen.getByText('My Node Title')).toBeOnTheScreen();
  });

  it('should render the correct accessibility props and card title when a title is provided as a string', () => {
    render(<Dialog open title={'My String Title'} />);
    const titleContainer = screen.getByTestId('test:id/modal-title');
    const title = screen.getByText('My String Title');

    expect(title).toBeOnTheScreen();
    expect(titleContainer).toHaveProp('accessibilityElementsHidden', false);
    expect(titleContainer).toHaveProp('importantForAccessibility', 'yes');
    expect(title).toHaveProp(
      'accessibilityLabel',
      'Alert dialog. My String Title'
    );
    expect(title).toHaveProp('accessibilityRole', 'header');
  });

  it('should render the correct accessibility props and card title when a title is provided as a Node', () => {
    render(
      <Dialog
        open
        title={<Text fontVariant="heading3-bold-Gray800">My Node Title</Text>}
      />
    );
    const titleContainer = screen.getByTestId('test:id/modal-title');
    const title = screen.getByText('My Node Title');

    expect(title).toBeOnTheScreen();
    expect(titleContainer).toHaveProp('accessibilityElementsHidden', false);
    expect(titleContainer).toHaveProp('importantForAccessibility', 'yes');
    expect(title).not.toHaveProp(
      'accessibilityLabel',
      'Alert dialog. My Node Title'
    );
    expect(title).not.toHaveProp('accessibilityRole', 'header');
  });

  it('should set the accessible props to hidden when the card title is not a populated string', () => {
    render(<Dialog open title={''} />);
    const title = screen.getByTestId('test:id/modal-title', {
      includeHiddenElements: true,
    });
    expect(title).toHaveProp('accessibilityElementsHidden', true);
    expect(title).toHaveProp(
      'importantForAccessibility',
      'no-hide-descendants'
    );
  });
});
