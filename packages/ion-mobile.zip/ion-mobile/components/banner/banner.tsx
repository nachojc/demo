import { getTokens, Stack, StackProps, styled, XStack, YStack } from 'tamagui';

import { Icon, IconName } from '../icon';
import { PhoneCallBox, PhoneCallBoxProps } from '../phone-call-box';
import { Text } from '../text';

type ButtonProps = {
  label: string;
  onPress?: () => void;
  data?:
    | {
        element?: 'Button';
      }
    | ({
        element: 'Phone';
      } & PhoneCallBoxProps);
};

type BannerProps = {
  icon?: IconName;
  message: string;
  buttons: ButtonProps[];
} & StackProps;

type MessageProps = {
  icon?: IconName;
  message: string;
};

const MessageContainer = ({ icon, message }: MessageProps) => {
  const tokens = getTokens();
  return (
    <XStack space={'$xl'} alignItems="center">
      {icon ? (
        <Icon
          name={icon}
          height={tokens.size[7].val}
          width={tokens.size[7].val}
        />
      ) : null}
      <Text
        tamaguiTextProps={{ flex: 1 }}
        fontVariant="body-regular-Secondary800"
      >
        {message}
      </Text>
    </XStack>
  );
};

const ButtonsContainer = ({ buttons }: { buttons: ButtonProps[] }) => (
  <XStack jc="flex-end" ai="center" gap="$xl" py="$xl">
    {buttons?.map((button: ButtonProps, index: number) => (
      <Stack key={button.label}>
        {button?.data?.element === 'Phone' ? (
          <PhoneCallBox {...button.data} callUs text="Call us" />
        ) : (
          <Text
            testID={`test:id-text-button-${index}`}
            fontVariant="body-semibold-Tertiary800"
            tamaguiTextProps={{ onPress: button.onPress }}
          >
            {button.label}
          </Text>
        )}
      </Stack>
    ))}
  </XStack>
);

export const Banner = ({ icon, message, buttons, ...props }: BannerProps) => (
  <Container {...props}>
    <MessageContainer icon={icon} message={message} />
    <ButtonsContainer buttons={buttons} />
  </Container>
);

const Container = styled(YStack, {
  name: 'Banner container',
  backgroundColor: '$White',
  paddingHorizontal: '$xl',
  paddingTop: '$xxl',
  paddingBottom: '$md',
  borderBottomWidth: 1,
  borderColor: '$Gray200',
  borderStyle: 'solid',
});
