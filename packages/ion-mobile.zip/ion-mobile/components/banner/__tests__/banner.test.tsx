import { fireEvent, render, screen } from '@src/jest/testing-library';

import { Banner } from '../banner';

const testMessage = 'This is a test message';

const onDismissClick = jest.fn();
const onUnlockProductClick = jest.fn();

const buttons = [
  { label: 'Dismiss', onPress: onDismissClick },
  { label: 'Unlock Product', onPress: onUnlockProductClick },
];

describe('Banner Component', () => {
  it('a message should be visible on the banner', () => {
    render(<Banner message={testMessage} buttons={buttons} />);
    expect(screen.getByText(testMessage)).toBeTruthy();
  });

  it('Icon is visible if icon is passed as a prop', () => {
    render(
      <Banner message={testMessage} buttons={buttons} icon="alert-circle" />
    );
    const icon = screen.getByTestId('test:id/icon-alert-circle', {
      includeHiddenElements: true,
    });
    expect(icon).toBeDefined();
  });

  it('Icon is not visible if icon is not passed as a prop', () => {
    render(<Banner message={testMessage} buttons={buttons} />);
    const icon = screen.queryByRole('image');
    expect(icon).toBeNull();
  });

  it('Function is called when unlock/dismiss button is pressed', () => {
    render(<Banner message={testMessage} buttons={buttons} />);
    const [dismissBtn, unlockBtn] =
      screen.getAllByTestId(/test:id-text-button-/);
    expect(unlockBtn).toHaveTextContent('Unlock Product');
    expect(dismissBtn).toHaveTextContent('Dismiss');

    fireEvent.press(unlockBtn);
    fireEvent.press(dismissBtn);

    expect(onDismissClick).toHaveBeenCalledTimes(1);
    expect(onUnlockProductClick).toHaveBeenCalledTimes(1);
  });
});
