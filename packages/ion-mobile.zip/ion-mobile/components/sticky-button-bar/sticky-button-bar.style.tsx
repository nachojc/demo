import { isIpad } from '@src/utils/is-ipad';
import { View } from 'react-native';
import { styled, XStack } from 'tamagui';

import { YStack } from '../stacks';

export const Container = styled(YStack, {
  width: '100%',
  flex: 0,
  flexGrow: 0,
  flexShrink: 1,
});

export const Content = styled(YStack, {
  paddingHorizontal: '$xl',
  paddingTop: '$xl',
  paddingBottom: '$xxxxl',
  width: '100%',
  backgroundColor: '$White',
});

export const ContentPanels = styled(YStack, {
  tabletNarrow: isIpad,
  paddingVertical: isIpad ? '$xxl' : undefined,
});

export const Divider = styled(View, {
  marginTop: 0,
  marginLeft: 0,
  marginRight: 0,
  width: '100%',
  height: 1,
  backgroundColor: '$Gray100',
});

export const ErrorPanel = styled(XStack, {
  width: '100%',
  marginBottom: '$md',
  paddingBottom: isIpad ? '$xl' : undefined,
});

export const ErrorMessage = styled(View, {
  marginLeft: '$md',
});

export const ErrorValue = styled(View, {
  position: 'absolute',
  marginLeft: '$md',
  marginRight: 0,
  right: 0,
});

export const MessagePanel = styled(XStack, {
  width: '100%',
  marginBottom: '$xl',
});

export const TitlePanel = styled(View, {
  marginLeft: 0,
});

export const ValuePanel = styled(View, {
  position: 'absolute',
  marginLeft: '$md',
  marginRight: 0,
  right: 0,
});

export const StickyButtonPanel = styled(View, {});
