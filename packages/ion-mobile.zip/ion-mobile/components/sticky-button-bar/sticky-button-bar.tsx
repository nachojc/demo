import { tokens } from '@src/theme/tokens';
import { ReactElement } from 'react';
import { Stack } from 'tamagui';

import { Button, ButtonVariant } from '../button';
import { Icon } from '../icon';
import { Text } from '../text';
import {
  Container,
  Content,
  ContentPanels,
  Divider,
  ErrorMessage,
  ErrorPanel,
  ErrorValue,
  MessagePanel,
  TitlePanel,
  ValuePanel,
} from './sticky-button-bar.style';

type StickyButtonBarProps = {
  title?: string;
  percentage: number;
  errorMessage?: string;
  errorValue?: number;
  isDirty?: boolean;
  buttonText: string;
  onButtonPress: () => void;
  testID?: string;
  children?: ReactElement;
  inlineError?: boolean;
  expectedPercentage?: number;
};

export const StickyButtonBar = ({
  title,
  percentage,
  buttonText,
  isDirty,
  errorMessage,
  errorValue,
  onButtonPress,
  testID,
  children,
  inlineError = false,
  expectedPercentage = 100,
}: StickyButtonBarProps) => {
  const showErrorPanel =
    !!errorMessage && percentage !== 100 && percentage !== 0;

  const valueStyle = !showErrorPanel
    ? 'body-regular-Gray800'
    : 'body-regular-Error';
  return (
    <Container testID={testID}>
      <Divider />
      <Content>
        <ContentPanels>
          {showErrorPanel && (
            <ErrorPanel>
              <Icon name="alert-circle" color={tokens.color.Error.val} />
              <ErrorMessage>
                <Text
                  testID={`${testID}-error-message`}
                  fontVariant="body-regular-Error"
                  tamaguiTextProps={{
                    fontWeight: '400',
                    numberOfLines: 0,
                    textAlignVertical: 'center',
                    lineHeight: 20.11,
                  }}
                >
                  {errorMessage}
                </Text>
              </ErrorMessage>
              {!!errorValue && (
                <ErrorValue>
                  <Text
                    testID={`${testID}-error-value`}
                    fontVariant="body-regular-Error"
                    tamaguiTextProps={{
                      fontWeight: '600',
                      numberOfLines: 0,
                      textAlignVertical: 'center',
                      lineHeight: 20.11,
                    }}
                  >
                    {`${errorValue ?? 0}%`}
                  </Text>
                </ErrorValue>
              )}
            </ErrorPanel>
          )}
          {((!!title && !inlineError) ||
            (!!title && !!inlineError && !showErrorPanel)) && (
            <>
              <MessagePanel>
                <TitlePanel>
                  <Text
                    testID={`${testID}-title`}
                    fontVariant="body-regular-Gray800"
                    tamaguiTextProps={{
                      fontWeight: '400',
                      numberOfLines: 0,
                      textAlignVertical: 'center',
                      lineHeight: 18.75,
                    }}
                  >
                    {title}
                  </Text>
                </TitlePanel>
                <ValuePanel>
                  <Text
                    testID={`${testID}-value`}
                    fontVariant={valueStyle}
                    tamaguiTextProps={{
                      fontWeight: '600',
                      numberOfLines: 0,
                      textAlignVertical: 'center',
                      lineHeight: 18.75,
                    }}
                  >
                    {`${percentage}%`}
                  </Text>
                </ValuePanel>
              </MessagePanel>
            </>
          )}
          {!!children && (
            <Stack
              justifyContent="center"
              alignSelf="center"
              paddingBottom="$lg"
            >
              {children}
            </Stack>
          )}
          <Stack>
            <Button
              testID={`${testID}-button`}
              variant={ButtonVariant.BRAND}
              onPress={onButtonPress}
              disabled={expectedPercentage - percentage !== 0 || !isDirty}
            >
              {buttonText}
            </Button>
          </Stack>
        </ContentPanels>
      </Content>
    </Container>
  );
};
