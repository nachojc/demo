import { fireEvent, render, screen, waitFor } from '@src/jest/testing-library';
import { Text } from '@aviva/ion-mobile';

import { StickyButtonBar } from '../sticky-button-bar';

describe('StickyButtonBar Component', () => {
  const mockOnPress = jest.fn();

  it('expect title and button text to render correctly', () => {
    render(
      <StickyButtonBar
        percentage={0}
        testID="sticky-test"
        title="Percentage left to allocate:"
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    expect(screen.getByText('Percentage left to allocate:')).toBeDefined();
    expect(screen.getByText('Continue')).toBeDefined();
  });

  it('expect title, percentage, and button text to render correctly', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        title="Percentage left to allocate:"
        percentage={-100}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    expect(screen.getByText('Percentage left to allocate:')).toBeDefined();
    expect(screen.getByText('-100%')).toBeDefined();
    expect(screen.getByText('Continue')).toBeDefined();
  });

  it('expect button text and button state to render correctly', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        percentage={0}
        buttonText="Continue"
        onButtonPress={() => {
          console.log('Press me! Press me!');
        }}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect button text and button state enabled to render correctly', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        buttonText="Continue"
        percentage={100}
        onButtonPress={mockOnPress}
        isDirty
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeEnabled();
  });

  it('expect error text, button text and button state to render correctly (under 0 percent)', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        errorMessage="You've under-allocated by: xxx%"
        percentage={-100}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    expect(screen.getByText("You've under-allocated by: xxx%")).toBeDefined();
    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect NO error text, button text and button state to render correctly (when 0 percent)', async () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        errorMessage="You've under-allocated by 100%"
        percentage={0}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    await waitFor(() => {
      expect(screen.queryByText("You've under-allocated by 100%")).toBeNull();
    });
    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect error text, button text and button state to render correctly (over 100 percent)', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        errorMessage="You've over-allocated by: xxx%"
        percentage={1000}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    expect(screen.getByText("You've over-allocated by: xxx%")).toBeDefined();
    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect error text, error value, button text and button state to render correctly', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        errorMessage="You've over-allocated by:"
        errorValue={900}
        percentage={1000}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    expect(screen.getByText("You've over-allocated by:")).toBeDefined();
    expect(screen.getByText('900%')).toBeDefined();
    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect error text, error value, title, percentage, button text, and button state to render correctly', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        errorMessage="You've over-allocated by 900%"
        title="Percentage left to allocate:"
        percentage={1000}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    expect(screen.getByText("You've over-allocated by 900%")).toBeDefined();
    expect(screen.getByText('Percentage left to allocate:')).toBeDefined();
    expect(screen.getByText('1000%')).toBeDefined();
    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect error text, error value correctly when inlineError', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        errorMessage="You've over-allocated by 900%"
        title="Percentage left to allocate:"
        inlineError
        percentage={1000}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    expect(screen.getByText("You've over-allocated by 900%")).toBeDefined();
    expect(
      screen.queryByText('Percentage left to allocate:')
    ).not.toBeOnTheScreen();
    expect(screen.queryByText('1000%')).not.toBeOnTheScreen();
    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect error text, error value correctly when the expected percentage does not met', async () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        errorMessage="You've under-allocated by 99%"
        percentage={0}
        expectedPercentage={99}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    await waitFor(() => {
      expect(screen.queryByText("You've under-allocated by 99%")).toBeNull();
    });
    expect(screen.getByText('Continue')).toBeDefined();
    expect(button).toBeDisabled();
  });

  it('expect button to be fired correctly', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        percentage={0}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      />
    );

    const button = screen.getByTestId('sticky-test-button');

    fireEvent.press(button);

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it('expect children to be rendered correctly if children is passed through', () => {
    render(
      <StickyButtonBar
        testID="sticky-test"
        percentage={0}
        buttonText="Continue"
        onButtonPress={mockOnPress}
      >
        <Text fontVariant={'body-regular-Secondary800'}>Test Children</Text>
      </StickyButtonBar>
    );

    expect(screen.getByText('Test Children')).toBeOnTheScreen();
  });
});
