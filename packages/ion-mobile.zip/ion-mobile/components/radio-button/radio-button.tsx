import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import { Circle, getTokens, Stack, StackProps, styled } from 'tamagui';

// Used by the container to count the items out
// ie `Radio option {{item}} of {{total}}.`
export type A11yCount = { a11yOpts: { item: number; total: number } };

type RadioButtonProps = {
  testID?: string;
  selected: boolean;
  disabled?: boolean;
  onPress?: StackProps['onPress'];
  error?: boolean;
};

export const RadioButton = ({
  testID,
  selected,
  disabled = false,
  onPress,
  error,
}: RadioButtonProps) => {
  const tokens = getTokens();

  return (
    <Pressable
      testID={getTestId('radio-button')}
      accessibilityRole="radio"
      android_ripple={{
        color: selected ? '$Success' : '$Gray300',
        borderless: true,
      }}
      style={{
        height: tokens.size[5].val,
        width: tokens.size[5].val,
        borderRadius: tokens.size[5].val,
      }}
      onPress={(e) => {
        if (!disabled) {
          onPress?.(e);
        }
      }}
    >
      <OuterRing
        testID={testID}
        selected={selected}
        disabled={disabled}
        accessibilityState={{ disabled, checked: selected }}
        error={error}
      >
        {selected && (
          <StyledCircle
            size={'$3'}
            disabled={disabled}
            testID={`${testID}-circle`}
            error={error}
          />
        )}
      </OuterRing>
    </Pressable>
  );
};

export const OuterRing = styled(Stack, {
  height: '$5',
  width: '$5',
  borderRadius: '$5',
  borderWidth: '$xs',
  borderColor: '$Gray400',
  justifyContent: 'center',
  alignItems: 'center',

  variants: {
    error: {
      true: {
        borderColor: '$Error',
      },
    },
    selected: {
      true: {
        borderColor: '$Success',
      },
    },
    disabled: {
      true: {
        borderColor: '$Gray300',
      },
    },
  },
});

export const StyledCircle = styled(Circle, {
  backgroundColor: '$Success',

  variants: {
    disabled: {
      true: {
        backgroundColor: '$Gray300',
      },
    },
    error: {
      true: {
        backgroundColor: '$Error',
      },
    },
  },
});
