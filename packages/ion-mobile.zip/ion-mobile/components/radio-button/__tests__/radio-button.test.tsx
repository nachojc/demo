import { fireEvent, render, screen } from '@src/jest/testing-library';

import { RadioButton } from '../radio-button';

const success = '#4F9F31';
const gray400 = '#7E7E7E';
const lightGray = '#CCCCCC';

const TEST_ID = 'test-radio';

describe('RadioButton Component', () => {
  it('should render correctly with basic props', () => {
    render(<RadioButton selected={false} testID={TEST_ID} />);
    expect(screen.getByTestId(TEST_ID)).toBeOnTheScreen();
  });

  it('should render with correct styling when not selected', () => {
    render(<RadioButton testID={TEST_ID} selected={false} />);

    const outerRing = screen.getByTestId(TEST_ID);
    expect(outerRing).toHaveStyle({
      borderBottomColor: gray400,
      borderTopColor: gray400,
      borderRightColor: gray400,
      borderLeftColor: gray400,
    });
  });

  it('should render with correct styling when selected', () => {
    render(<RadioButton testID={TEST_ID} selected />);

    const outerRing = screen.getByTestId(TEST_ID);
    expect(outerRing).toHaveStyle({
      borderBottomColor: success,
      borderTopColor: success,
      borderRightColor: success,
      borderLeftColor: success,
    });

    const innerCircle = screen.getByTestId(`${TEST_ID}-circle`);
    expect(innerCircle).toHaveStyle({
      backgroundColor: success,
    });
  });

  it('should render with correct styling when disabled and not selected', () => {
    render(<RadioButton testID={TEST_ID} selected={false} disabled />);

    const outerRing = screen.getByTestId(TEST_ID);

    expect(outerRing).toHaveStyle({
      borderBottomColor: lightGray,
      borderTopColor: lightGray,
      borderRightColor: lightGray,
      borderLeftColor: lightGray,
    });

    expect(screen.queryByTestId(`${TEST_ID}-circle`)).toBeFalsy();
  });

  it('should render with correct styling when disabled and selected', () => {
    render(<RadioButton testID={TEST_ID} selected disabled />);

    const outerRing = screen.getByTestId(TEST_ID);

    expect(outerRing).toHaveStyle({
      borderBottomColor: lightGray,
      borderTopColor: lightGray,
      borderRightColor: lightGray,
      borderLeftColor: lightGray,
    });

    const innerCircle = screen.getByTestId(`${TEST_ID}-circle`);

    expect(innerCircle).toHaveStyle({
      backgroundColor: lightGray,
    });
  });

  it('should call the passed onPress function when pressed', () => {
    const mockPress = jest.fn();

    render(
      <RadioButton testID={TEST_ID} selected={false} onPress={mockPress} />
    );

    const radioButton = screen.getByTestId(TEST_ID);

    fireEvent.press(radioButton);

    expect(mockPress).toHaveBeenCalledTimes(1);
  });

  it('should not call the passed onPress function when pressed and radio button is disabled', () => {
    const mockPress = jest.fn();

    render(
      <RadioButton
        testID={TEST_ID}
        selected={false}
        disabled
        onPress={mockPress}
      />
    );

    const radioButton = screen.getByTestId(TEST_ID);
    fireEvent.press(radioButton);

    expect(mockPress).not.toHaveBeenCalled();
  });
});
