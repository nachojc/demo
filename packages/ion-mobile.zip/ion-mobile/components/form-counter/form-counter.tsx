import { getTestId } from '@src/utils/get-test-id';
import { isNumber } from '@src/utils/is-number';
import { AccessibilityActionEvent } from 'react-native';
import { getTokens, Input, Stack, XStack } from 'tamagui';

import { Button, ButtonVariant } from '../button';
import { Icon } from '../icon';
import { Text } from '../text';
import { Container, StepperContainer } from './form-counter.styles';

type Props = {
  title: string;
  subTitle?: string;
  accessibilityLabel?: string;
  directWealth?: boolean;
  min?: number;
  max?: number;
  value?: number | null;
  defaultValue?: number;
  buttonVariant?: ButtonVariant;
  error?: boolean;
  required?: boolean;
  onIncrease: () => void;
  onDecrease: () => void;
  onChange?: (text: string) => void;
};

export const FormCounter = ({
  title,
  subTitle,
  accessibilityLabel,
  min = 55,
  max = 99,
  buttonVariant = ButtonVariant.BRAND,
  error = false,
  onIncrease,
  onDecrease,
  onChange,
  defaultValue = 67,
  value,
  required,
}: Props) => {
  const isDecreaseDisabled = Boolean(value && value <= min);
  const isIncreaseDisabled = Boolean(value && value >= max);

  const onAccessibilityAction = ({ nativeEvent }: AccessibilityActionEvent) => {
    if (nativeEvent.actionName === 'increment' && !isIncreaseDisabled) {
      onIncrease();
    } else if (nativeEvent.actionName === 'decrement' && !isDecreaseDisabled) {
      onDecrease();
    }
  };

  return (
    <Container testID={getTestId('form-counter')}>
      <Text
        fontVariant={`body-semibold-Secondary800`}
        tamaguiTextProps={{
          accessibilityHint: required ? 'Required' : '',
        }}
      >
        {title}
      </Text>
      {subTitle && (
        <Text
          testID="subtitle"
          fontVariant={`small-regular-Gray800`}
          tamaguiTextProps={{ paddingTop: '$sm' }}
        >
          {subTitle}
        </Text>
      )}
      <Stack
        testID={getTestId('form-counter-accessibility-container')}
        accessible
        accessibilityRole="adjustable"
        accessibilityLabel={
          accessibilityLabel ? accessibilityLabel : 'Retirement age'
        }
        accessibilityValue={{
          text: `${value ?? defaultValue}`,
        }}
        onAccessibilityAction={onAccessibilityAction}
        accessibilityActions={[{ name: 'increment' }, { name: 'decrement' }]}
      >
        <StepperContainer importantForAccessibility="no-hide-descendants">
          <StepperControls
            onDecrease={isDecreaseDisabled ? null : onDecrease}
            onIncrease={isIncreaseDisabled ? null : onIncrease}
            onChange={onChange}
            error={error}
            min={min}
            max={max}
            buttonVariant={buttonVariant}
            value={value ?? defaultValue}
          />
        </StepperContainer>
      </Stack>
    </Container>
  );
};

type StepperControlsProps = {
  error: boolean;
  onDecrease: (() => unknown) | null;
  onIncrease: (() => unknown) | null;
  onChange: ((text: string) => unknown) | undefined;
  buttonVariant: ButtonVariant;
  max: number;
  min: number;
  value: number;
};

const StepperControls = ({
  onDecrease,
  onIncrease,
  onChange,
  buttonVariant,
  value,
  min,
  max,
  error,
}: StepperControlsProps) => {
  const tokens = getTokens();

  const onChangeLocal = (inputValue: string) => {
    if (onChange !== undefined) {
      if (isNumber(inputValue)) {
        if (parseInt(inputValue, 10) > max) {
          onChange(max.toString());
        } else {
          onChange(inputValue);
        }
      } else {
        onChange(min.toString());
      }
    }
  };

  const iconColor: Record<ButtonVariant, string> = {
    [ButtonVariant.BRAND]: tokens.color.Secondary800.val,
    [ButtonVariant.SUB_BRAND]: tokens.color.White.val,
    [ButtonVariant.LINK_TEXT]: tokens.color.Tertiary800.val,
    [ButtonVariant.SUB_BRAND_LINK]: tokens.color.Tertiary800.val,
    [ButtonVariant.OUTLINED]: tokens.color.Secondary800.val,
    [ButtonVariant.OUTLINED_WHITE]: tokens.color.White.val,
    [ButtonVariant.OUTLINED_ERROR]: tokens.color.Error.val,
    [ButtonVariant.DIRECT_WEALTH]: tokens.color.DWPrimary500.val,
    [ButtonVariant.QUICK_LINKS]: tokens.color.White.val,
  };
  return (
    <>
      <Button
        testID={getTestId('decrease-minus-icon')}
        borderRadius={5}
        variant={buttonVariant}
        height={48}
        paddingHorizontal="$lg"
        paddingTop="$sm"
        disabled={value === min || !onDecrease}
        onPress={onDecrease}
      >
        <XStack accessible={false}>
          <Icon name="minus" color={iconColor[buttonVariant]} />
        </XStack>
      </Button>

      <Input
        testID={getTestId('form-counter-input')}
        keyboardType="numeric"
        flex={1}
        size={tokens.size[8].val}
        bc="$backgroundTransparent"
        bw={1}
        fos="$body"
        bg="$White"
        value={`${value}`}
        textAlign="center"
        onChangeText={onChangeLocal}
        marginHorizontal={8}
        color="$DWPrimary500"
        fontWeight="$regular"
        editable
        focusable={false}
        boc={error ? '$Error' : '$Gray300'}
      />

      <Button
        testID={getTestId('increase-plus-icon')}
        borderRadius={5}
        variant={buttonVariant}
        disabled={!onIncrease}
        height={48}
        paddingHorizontal="$lg"
        paddingTop="$sm"
        onPress={onIncrease}
      >
        <XStack accessible={false}>
          <Icon name="plus" color={iconColor[buttonVariant]} />
        </XStack>
      </Button>
    </>
  );
};
