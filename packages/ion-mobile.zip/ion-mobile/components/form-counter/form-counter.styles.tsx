import { styled, XStack, YStack } from 'tamagui';

const Container = styled(YStack, {
  name: 'Header Container',
  justifyContent: 'flex-start',
  flex: 1,

  variants: {
    directWealth: {
      backgroundColor: '$DWPrimary500',
    },
    white: {
      backgroundColor: '$White',
    },
  } as const,
});

const StepperContainer = styled(XStack, {
  justifyContent: 'space-between',
  paddingVertical: '$xl',

  variants: {
    directWealth: {
      backgroundColor: '$DWPrimary500',
    },
    white: {
      backgroundColor: '$White',
    },
  } as const,
});
export { Container, StepperContainer };
