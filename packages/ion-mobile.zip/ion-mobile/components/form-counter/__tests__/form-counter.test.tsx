import { fireEvent, render, screen } from '@src/jest/testing-library';
import { Theme } from 'tamagui';

import { ButtonVariant } from '../../button';
import { FormCounter } from '../form-counter';

const mockOnDecrease = jest.fn();
const mockOnIncrease = jest.fn();
const mockOnChangeValue = jest.fn();

const renderFormCounter = ({ value }: { value?: number } = {}) =>
  render(
    <FormCounter
      onDecrease={mockOnDecrease}
      onIncrease={mockOnIncrease}
      title="test form counter"
      value={value ?? 59}
      min={55}
      max={99}
    />
  );

const renderErrorFormCounter = ({ value }: { value?: number } = {}) =>
  render(
    <FormCounter
      onDecrease={mockOnDecrease}
      onIncrease={mockOnIncrease}
      title="test form counter"
      value={value ?? 59}
      min={55}
      max={99}
      error
    />
  );

const renderMinFormCounter = ({ value }: { value?: number } = {}) =>
  render(
    <FormCounter
      onDecrease={mockOnDecrease}
      onIncrease={mockOnIncrease}
      onChange={mockOnChangeValue}
      title="test form counter"
      value={value ?? 59}
      min={0}
      max={100}
    />
  );

const getInput = () =>
  screen.getByTestId('test:id/form-counter-input', {
    includeHiddenElements: true,
  });
const getMinusButton = () =>
  screen.getByTestId('test:id/decrease-minus-icon', {
    includeHiddenElements: true,
  });
const getPlusButton = () =>
  screen.getByTestId('test:id/increase-plus-icon', {
    includeHiddenElements: true,
  });
const getAccessibilityContainer = () =>
  screen.getByTestId('test:id/form-counter-accessibility-container');
const performAccessibilityAction = (actionName: 'increment' | 'decrement') => {
  const container = getAccessibilityContainer();
  container.props.onAccessibilityAction({
    nativeEvent: {
      actionName,
    },
  });
};

describe('FormCounterComponent', () => {
  const whiteColor = '#FFFFFF';
  const primary500Color = '#FFD900';
  const dWPrimary500Color = '#141D31';
  const gray200Color = '#D9D9D9';
  const gray300Color = '#CCCCCC';

  afterEach(() => {
    jest.resetAllMocks();
  });

  it('should display correctly for direct wealth variant', () => {
    render(
      <Theme name="wealth">
        <FormCounter
          onDecrease={() => null}
          onIncrease={() => null}
          title="test form counter"
          buttonVariant={ButtonVariant.SUB_BRAND}
          value={60}
        />
      </Theme>
    );

    const minusButton = getMinusButton();
    const plusButton = getPlusButton();
    const ageInput = getInput();
    expect(screen.getByText('test form counter')).toBeOnTheScreen();
    expect(ageInput).toHaveProp('value', '60');
    expect(minusButton).toHaveStyle({
      backgroundColor: dWPrimary500Color,
    });
    expect(ageInput).toHaveStyle({
      backgroundColor: whiteColor,
      borderBottomColor: gray300Color,
    });
    expect(plusButton).toHaveStyle({
      backgroundColor: dWPrimary500Color,
    });
  });

  it('should display correctly for default primary variant', () => {
    renderFormCounter();
    const minusButton = getMinusButton();
    const plusButton = getPlusButton();
    const ageInput = getInput();

    expect(minusButton).toHaveStyle({
      backgroundColor: primary500Color,
    });
    expect(ageInput).toHaveStyle({
      backgroundColor: whiteColor,
      borderBottomColor: gray300Color,
    });
    expect(plusButton).toHaveStyle({
      backgroundColor: primary500Color,
    });
  });

  it('should display disabled button when min value reached', () => {
    renderFormCounter({ value: 55 });

    const minusButton = getMinusButton();

    expect(minusButton).toHaveStyle({
      backgroundColor: gray200Color,
    });
  });

  it('should display disabled button when max value reached', () => {
    renderFormCounter({ value: 99 });

    const plusButton = getPlusButton();

    expect(plusButton).toHaveStyle({
      backgroundColor: gray200Color,
    });
  });

  it('should not go below 0', () => {
    renderMinFormCounter({ value: 0 });

    const minusButton = getMinusButton();

    fireEvent.press(minusButton);

    expect(mockOnDecrease).toHaveBeenCalled();
  });

  it('should clamp the value of text when entered quantity exceeds maximum', () => {
    renderMinFormCounter({ value: 55 });

    const textInputButton = getInput();

    fireEvent.changeText(textInputButton, '101');
    expect(mockOnChangeValue).toHaveBeenCalled();
    expect(mockOnChangeValue.mock.calls).toHaveLength(1);
    expect(mockOnChangeValue.mock.calls[0][0]).toBe('100');
  });

  it('should be able to deal with non-numeric input', () => {
    renderMinFormCounter({ value: 55 });

    const textInputButton = getInput();

    fireEvent.changeText(textInputButton, 'test');
    expect(mockOnChangeValue).toHaveBeenCalled();
    expect(mockOnChangeValue.mock.calls).toHaveLength(1);
    expect(mockOnChangeValue.mock.calls[0][0]).toBe('0');
  });

  it('should have a red border when in error state', () => {
    renderErrorFormCounter({ value: 55 });

    const ageInput = getInput();

    expect(ageInput).toHaveStyle({
      borderBottomColor: '#BD2624',
    });
  });

  it('should call onIncrease when press plus button', () => {
    renderFormCounter();

    const plusButton = getPlusButton();

    fireEvent.press(plusButton);
    expect(mockOnIncrease).toHaveBeenCalled();
  });

  it('should call onDecrease when press plus button', () => {
    renderFormCounter();

    const minusButton = getMinusButton();

    fireEvent.press(minusButton);
    expect(mockOnDecrease).toHaveBeenCalled();
  });

  it('should show a subtitle when given a subtitle', () => {
    render(
      <FormCounter
        onDecrease={() => null}
        onIncrease={() => null}
        title="test form counter"
        subTitle="This is a subtitle for the form counter"
        value={59}
      />
    );

    const subtitle = screen.getByText(
      'This is a subtitle for the form counter'
    );

    expect(subtitle).toBeOnTheScreen();
  });

  it('should not show a subtitle when not given a subtitle', () => {
    renderFormCounter();

    const subtitle = screen.queryByTestId('subtitle');

    expect(subtitle).not.toBeOnTheScreen();
  });

  it('should be an adjustable element', () => {
    renderFormCounter();

    const container = getAccessibilityContainer();
    expect(container).toHaveProp('accessible', true);
    expect(container).toHaveProp('accessibilityRole', 'adjustable');
    expect(container).toHaveProp('accessibilityLabel', 'Retirement age');
    expect(container).toHaveProp('accessibilityValue', { text: '59' });
    expect(container).toHaveProp('accessibilityActions', [
      { name: 'increment' },
      { name: 'decrement' },
    ]);
  });

  it('should increment when using accessibility action', () => {
    renderFormCounter({ value: 98 });
    performAccessibilityAction('increment');
    expect(mockOnIncrease).toHaveBeenCalledTimes(1);
  });

  it('should not increment when using accessibility action and max reached', () => {
    renderFormCounter({ value: 99 });
    performAccessibilityAction('increment');
    expect(mockOnIncrease).toHaveBeenCalledTimes(0);
  });

  it('should decrement when using accessibility action', () => {
    renderFormCounter({ value: 56 });
    performAccessibilityAction('decrement');
    expect(mockOnDecrease).toHaveBeenCalledTimes(1);
  });

  it('should not decrement when using accessibility action and min reached', () => {
    renderFormCounter({ value: 55 });
    performAccessibilityAction('decrement');
    expect(mockOnDecrease).toHaveBeenCalledTimes(0);
  });

  it('text input should not be disabled', () => {
    renderFormCounter({ value: 55 });
    const ageInput = getInput();

    expect(ageInput).toHaveProp('editable');

    expect(ageInput).not.toBeDisabled();
  });
});
