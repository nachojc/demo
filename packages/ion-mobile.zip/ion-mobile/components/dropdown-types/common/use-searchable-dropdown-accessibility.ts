import { i18n } from '@src/i18n/i18n';
import { useEffect, useMemo } from 'react';
import { AccessibilityInfo } from 'react-native';
import { debounce } from 'tamagui';

import { DEBOUNCE_WAIT } from './dropdown-elements';

const announce = (count: number) => {
  AccessibilityInfo.announceForAccessibility(
    i18n.t('common.dropdown.accessibilityAnnounceSearchItemsCount', {
      count,
    })
  );
};

export const useSearchableDropdownAccessibility = ({
  items,
  searchable,
  searchTerm,
}: {
  items: unknown[];
  searchable: boolean;
  searchTerm: string;
}) => {
  const debouncedAnnounce = useMemo(
    // Multiplier gives additional time for previous annoucements to be overriden.
    // This is mainly for Android which, unlike iOS, doesn't empty the announcement queue
    // when making a new annoucement
    () => debounce(announce, DEBOUNCE_WAIT * 3),
    []
  );

  useEffect(() => {
    if (!searchable || searchTerm === '') {
      return;
    }

    debouncedAnnounce(items.length);
  }, [items.length, searchable, searchTerm]);
};
