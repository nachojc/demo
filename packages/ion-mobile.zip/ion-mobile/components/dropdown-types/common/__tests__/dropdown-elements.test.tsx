import { render, screen } from '@src/jest/testing-library';
import * as isIpadModule from '@src/utils/is-ipad';

import { DropdownHeader } from '../dropdown-elements';

jest.mock('@src/utils/is-ipad');
const mockOnOpenChange = jest.fn();
const mockSetSearchTerm = jest.fn();

const renderDropdownHeader = (searchBar: boolean) => {
  render(
    <DropdownHeader
      accessibilityLabel="Search"
      accessibilityHint="Search for items"
      onOpenChange={mockOnOpenChange}
      setSearchTerm={mockSetSearchTerm}
      searchTerm=""
      selectInputProps={{ searchTextPlaceholder: 'Search...' }}
      searchBar={searchBar}
    />
  );
};

describe('DropdownHeader', () => {
  beforeEach(() => {
    (isIpadModule as any).isIpad = false;
  });

  describe('styles', () => {
    it('should have the correct iPad styles for the header if tablet', () => {
      (isIpadModule as any).isIpad = true;
      renderDropdownHeader(true);
      expect(screen.getByTestId('test:id/search-bar')).toHaveStyle({
        paddingRight: 32,
        paddingLeft: 32,
      });
    });

    it('should not have iPad styles for the header if not tablet', () => {
      renderDropdownHeader(true);
      expect(screen.getByTestId('test:id/search-bar')).toHaveStyle({
        paddingRight: 16,
        paddingLeft: 16,
      });
    });
  });
});
