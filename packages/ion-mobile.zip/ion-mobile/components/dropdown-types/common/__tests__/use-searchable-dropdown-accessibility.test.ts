import { renderHook, waitFor } from '@src/jest/testing-library';
import { AccessibilityInfo } from 'react-native';

import { useSearchableDropdownAccessibility } from '../use-searchable-dropdown-accessibility';

jest.useFakeTimers();

describe('useSearchableDropdownAccessibility', () => {
  it('should not announce if not searchable', async () => {
    renderHook(() =>
      useSearchableDropdownAccessibility({
        items: [],
        searchable: false,
        searchTerm: 'howdy',
      })
    );

    jest.advanceTimersByTime(1000);

    await waitFor(() => {
      expect(AccessibilityInfo.announceForAccessibility).not.toHaveBeenCalled();
    });
  });

  it('should not announce if search term is empty', async () => {
    renderHook(() =>
      useSearchableDropdownAccessibility({
        items: [],
        searchable: true,
        searchTerm: '',
      })
    );

    jest.advanceTimersByTime(1000);

    await waitFor(() => {
      expect(AccessibilityInfo.announceForAccessibility).not.toHaveBeenCalled();
    });
  });

  it('should announce message for no items', async () => {
    renderHook(() =>
      useSearchableDropdownAccessibility({
        items: [],
        searchable: true,
        searchTerm: 'dddddd',
      })
    );

    await waitFor(() => {
      expect(AccessibilityInfo.announceForAccessibility).toHaveBeenCalledWith(
        'There are 0 items'
      );
    });
  });

  it('should announce message for single item', async () => {
    renderHook(() =>
      useSearchableDropdownAccessibility({
        items: ['item1'],
        searchable: true,
        searchTerm: 'item1',
      })
    );

    await waitFor(() => {
      expect(AccessibilityInfo.announceForAccessibility).toHaveBeenCalledWith(
        'There is 1 item'
      );
    });
  });

  it('should announce message for multiple items', async () => {
    renderHook(() =>
      useSearchableDropdownAccessibility({
        items: ['item1', 'item2'],
        searchable: true,
        searchTerm: 'item',
      })
    );

    await waitFor(() => {
      expect(AccessibilityInfo.announceForAccessibility).toHaveBeenCalledWith(
        'There are 2 items'
      );
    });
  });
});
