import { useAccessibility } from '@src/common/providers/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import {
  Keyboard,
  Platform,
  TouchableWithoutFeedback,
  useWindowDimensions,
} from 'react-native';
import RNModal, { ModalProps } from 'react-native-modal';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Adapt,
  getTokens,
  getVariableValue,
  ScrollView,
  Select,
  Sheet,
  Stack,
  XStack,
} from 'tamagui';

import { CloseButton } from '../../close-button';
import { FocusAwareStatusBar } from '../../focus-aware-status-bar';
import { Icon } from '../../icon';
import { YStack } from '../../stacks';
import { Text } from '../../text';
import { TextInput } from '../../text-input';
import { DropdownBaseProps, DropdownSelectInputProps } from '../dropdown/types';

export const DEBOUNCE_WAIT = 300;

type DropdownSuggestedCountryProps = {
  suggestedCountryName: string;
  suggestedCountryCode: string;
  valueCountryName?: string;
};

export const DropdownSuggestedCountry = ({
  suggestedCountryName,
  suggestedCountryCode,
  valueCountryName = '',
}: DropdownSuggestedCountryProps) => {
  const tokens = getTokens();

  const isSelected = valueCountryName === suggestedCountryName;

  return (
    <>
      <Text fontVariant={'overline-semibold-Secondary800'}>
        Suggested Country
      </Text>
      <Select.Item
        index={0}
        value={suggestedCountryName}
        borderBottomWidth={1}
        paddingVertical="$xl"
        backgroundColor="$White"
        accessible
        accessibilityLabel={`${suggestedCountryName} ${suggestedCountryCode}`}
        accessibilityRole="button"
        accessibilityState={{
          selected: isSelected,
        }}
      >
        <Text fontVariant="body-semibold-Gray800">
          {suggestedCountryName}
          <Text fontVariant="body-regular-Gray800">{suggestedCountryCode}</Text>
        </Text>
        {isSelected && (
          <XStack ml="auto">
            <Icon
              name="tick2"
              width={getVariableValue(tokens.size['5'])}
              height={getVariableValue(tokens.size['5'])}
            />
          </XStack>
        )}
      </Select.Item>
      <Text
        fontVariant={'overline-semibold-Secondary800'}
        tamaguiTextProps={{ mt: '$xl' }}
      >
        All Countries
      </Text>
    </>
  );
};

type DropdownHeaderProps = {
  accessibilityLabel?: string;
  accessibilityHint?: string;
  onOpenChange?: (open?: boolean) => void;
  setSearchTerm?: (searchInput: string) => void;
  searchTerm?: string;
  selectInputProps?: DropdownSelectInputProps;
  searchBar?: boolean;
  isExpanded?: boolean;
  snapPoints?: number[];
};

export const DropdownHeader = ({
  accessibilityLabel,
  accessibilityHint,
  onOpenChange,
  setSearchTerm,
  searchTerm,
  selectInputProps,
  searchBar,
}: DropdownHeaderProps) => {
  return (
    <Stack
      pb="$xl"
      backgroundColor={'$White'}
      borderTopLeftRadius={24}
      borderTopRightRadius={24}
    >
      <XStack justifyContent="flex-end">
        <CloseButton
          onPress={() => onOpenChange?.(false)}
          px="$xl"
          pt="$xl"
          pb="$md"
          testID={getTestId('dropdown-header-close')}
        />
      </XStack>
      {searchBar && (
        <Stack
          testID={getTestId('searchBar')}
          px={isIpad ? '$xxxl' : '$xl'}
          pt="$md"
        >
          <TextInput
            testID={getTestId('dropdown-element-search-bar')}
            active
            tamaguiInputProps={{
              accessible: searchBar,
              accessibilityLabel,
              accessibilityHint,
              accessibilityRole: 'search',
              placeholder: selectInputProps?.searchTextPlaceholder,
              onChange: (e) => {
                setSearchTerm?.(e.nativeEvent.text);
              },
              value: searchTerm,
              onSubmitEditing: () => {
                Keyboard.dismiss();
              },
            }}
          />
        </Stack>
      )}
    </Stack>
  );
};

export const DropdownAdapt = ({
  isExpanded,
  onOpenChange,
  searchBar,
  searchTerm,
  selectInputProps,
  setSearchTerm,
  snapPoints = [85],
}: DropdownHeaderProps) => {
  return (
    <Adapt>
      {Platform.OS === 'android' && isExpanded && (
        <FocusAwareStatusBar style="dark" />
      )}

      <Sheet
        snapPoints={snapPoints}
        modal
        animationConfig={{
          type: 'spring',
          damping: 50,
          mass: 1.2,
          stiffness: 250,
        }}
      >
        <Sheet.Overlay />
        <Sheet.Frame
          alignSelf="center"
          backgroundColor="transparent"
          borderTopLeftRadius={20}
          borderTopRightRadius={20}
          maxWidth={isIpad ? '$20' : '100%'}
        >
          <Stack f={1}>
            <DropdownHeader
              onOpenChange={onOpenChange}
              setSearchTerm={setSearchTerm}
              searchTerm={searchTerm}
              selectInputProps={selectInputProps}
              searchBar={searchBar}
            />
            <Sheet.ScrollView
              keyboardShouldPersistTaps="handled"
              backgroundColor="$White"
            >
              <Adapt.Contents />
            </Sheet.ScrollView>
          </Stack>
        </Sheet.Frame>
      </Sheet>
    </Adapt>
  );
};

export type DropdownModalProps = DropdownHeaderProps &
  Pick<DropdownBaseProps, 'modalStyles'> & {
    isVisible: ModalProps['isVisible'];
    children: ModalProps['children'];
    isScrollView?: boolean;
    height?: number;
  };

export const DropdownModal = ({
  isVisible,
  onOpenChange,
  setSearchTerm,
  searchTerm,
  selectInputProps,
  searchBar,
  children,
  isScrollView = true,
  height = 0.85,
  modalStyles,
}: DropdownModalProps) => {
  const tokens = getTokens();
  const { isScreenReaderEnabled } = useAccessibility();
  const { height: deviceHeight, width: deviceWidth } = useWindowDimensions();
  const { top } = useSafeAreaInsets();

  const setMarginTop = (h: number | undefined) => {
    if (h) {
      return 'auto';
    }
    return top;
  };

  return (
    <RNModal
      avoidKeyboard={isScreenReaderEnabled && deviceWidth < deviceHeight}
      isVisible={isVisible}
      style={{
        margin: 0,
        marginTop: setMarginTop(height),
        ...(typeof modalStyles === 'object' && modalStyles),
      }}
      onBackdropPress={() => onOpenChange?.(false)}
      backdropOpacity={0.5}
      backdropColor="black"
      customBackdrop={
        <TouchableWithoutFeedback
          accessible={false}
          importantForAccessibility="no"
          onPress={() => onOpenChange?.(false)}
          testID={getTestId('dropdown-modal-overlay')}
        >
          <YStack f={1} backgroundColor="black" opacity={0.5} />
        </TouchableWithoutFeedback>
      }
    >
      <YStack
        backgroundColor={getVariableValue(tokens.color.White)}
        flex={height} ///change this to change the modal
        borderTopLeftRadius={24}
        borderTopRightRadius={24}
        justifyContent="space-between"
        marginTop="auto"
        testID={getTestId('modal-content')}
      >
        <DropdownHeader
          onOpenChange={onOpenChange}
          setSearchTerm={setSearchTerm}
          searchTerm={searchTerm}
          selectInputProps={selectInputProps}
          searchBar={searchBar}
        />
        {isScrollView ? (
          <ScrollView
            contentContainerStyle={{
              flexGrow: 1,
              paddingHorizontal: getVariableValue(tokens.size[5]),
            }}
          >
            {children}
          </ScrollView>
        ) : (
          children
        )}
      </YStack>
    </RNModal>
  );
};
