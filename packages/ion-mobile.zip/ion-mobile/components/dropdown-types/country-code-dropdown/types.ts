import { ReactNode } from 'react';
import { TouchableNativeFeedbackProps } from 'react-native';
import { SelectProps } from 'tamagui';

import { TextInputProps } from '../../text-input';
import { DropdownBaseProps } from '../dropdown/types';

export type CountryCode = { name: string; code: string };

type SelectInputProps = TextInputProps & {
  errorText?: ReactNode;
  searchTextPlaceholder?: string;
  numberTextPlaceholder?: string;
};

export type CountryNumber = { country: CountryCode; number: string };
export type Country = { name: string; code: string };

export type CountryCodeDropdownProps = Pick<
  DropdownBaseProps,
  'dropdownContentStyles'
> & {
  phoneNumberFieldLength?: number;
  selectInputProps?: SelectInputProps;
  containerProps?: SelectProps;
  searchBar?: boolean;
  hasSuggestedCountry?: boolean;
  onValueChange: ({ country, number }: CountryNumber) => void;
  value: CountryNumber;
  touchablaNativeFeedbackProps?: TouchableNativeFeedbackProps;
  required?: boolean;
};
