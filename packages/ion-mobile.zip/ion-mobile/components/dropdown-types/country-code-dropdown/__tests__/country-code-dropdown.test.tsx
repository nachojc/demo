import { fireEvent, render, screen, within } from '@src/jest/testing-library';

import { CountryCodeDropdown } from '../country-code-dropdown';

const onValueChangeMock = jest.fn();
const country = { code: '+44', name: 'United Kingdom' };

jest.mock('react-native-safe-area-context', () => ({
  useSafeAreaInsets: () => ({}),
}));

describe('CountryCodeDropdown', () => {
  it('should render the component', () => {
    render(
      <CountryCodeDropdown
        onValueChange={onValueChangeMock}
        value={{
          number: '',
          country: { code: '', name: '' },
        }}
        selectInputProps={{
          numberTextPlaceholder: 'Enter text here',
          searchTextPlaceholder: 'Select Country',
        }}
      />
    );

    const component = screen.getByTestId('country-codes');
    const trigger = screen.getByTestId('country-code-trigger');
    const inputField = screen.getByTestId(
      'test:id/country-code-number-input-container'
    );

    expect(component).toBeOnTheScreen();
    expect(trigger).toBeOnTheScreen();
    expect(inputField).toBeOnTheScreen();

    expect(inputField).toHaveProp('placeholder', 'Enter text here');
    expect(inputField).toHaveProp('placeholderTextColor', '#717171');
  });

  it('should call valid phone number change event', async () => {
    render(
      <CountryCodeDropdown
        onValueChange={onValueChangeMock}
        value={{
          number: '',
          country,
        }}
        selectInputProps={{
          numberTextPlaceholder: 'Enter text here',
          searchTextPlaceholder: 'Select Country',
        }}
      />
    );

    const component = screen.getByTestId('country-codes');
    const trigger = screen.getByTestId('country-code-trigger');
    const inputField = screen.getByTestId(
      'test:id/country-code-number-input-container'
    );

    expect(component).toBeOnTheScreen();
    expect(trigger).toBeOnTheScreen();
    expect(inputField).toBeOnTheScreen();

    expect(inputField).toHaveProp('placeholder', 'Enter text here');
    expect(inputField).toHaveProp('placeholderTextColor', '#717171');

    fireEvent.changeText(inputField, '012345hkj67890');

    expect(onValueChangeMock).toHaveBeenCalledWith({
      country,
      number: '1234567890',
    });
  });

  it('should render the active state', () => {
    render(
      <CountryCodeDropdown
        onValueChange={onValueChangeMock}
        value={{
          number: '1234567890',
          country: { code: '+44', name: 'United Kingdom' },
        }}
      />
    );

    const trigger = screen.getByTestId('country-code-trigger');
    const inputField = screen.getByTestId(
      'test:id/country-code-number-input-container'
    );

    expect(trigger).toHaveTextContent('+44');
    expect(inputField).toHaveProp('value', '1234567890');
  });

  it('should render the error state', () => {
    render(
      <CountryCodeDropdown
        onValueChange={onValueChangeMock}
        value={{
          number: '',
          country: { code: '', name: '' },
        }}
        selectInputProps={{
          error: true,
          errorText: 'Test Error Text',
        }}
      />
    );
    const trigger = screen.getByTestId('country-code-trigger');
    const errorMessageContainer = screen.getByTestId('error-message-container');
    const errorMessage = screen.getByTestId('test:id/error-message');

    expect(errorMessageContainer).toBeOnTheScreen();
    expect(errorMessage).toHaveTextContent('Test Error Text');

    const inputField = within(screen.getByTestId('country-codes')).getByTestId(
      'text-input-container'
    );
    expect(inputField).toHaveStyle({
      borderBottomColor: '#BD2624',
      borderTopColor: '#BD2624',
      borderLeftColor: '#BD2624',
      borderRightColor: '#BD2624',
    });

    expect(trigger).toHaveStyle({
      borderBottomColor: '#BD2624',
      borderTopColor: '#BD2624',
      borderLeftColor: '#BD2624',
      borderRightColor: '#BD2624',
    });
  });

  it('should render the disabled state', () => {
    render(
      <CountryCodeDropdown
        onValueChange={onValueChangeMock}
        value={{
          number: '',
          country: { code: '', name: '' },
        }}
        selectInputProps={{
          disabled: true,
        }}
      />
    );

    const trigger = screen.getByTestId('country-code-trigger');
    const inputField = within(screen.getByTestId('country-codes')).getByTestId(
      'text-input-container'
    );

    expect(inputField).toHaveStyle({
      borderBottomColor: '#CCCCCC',
      borderTopColor: '#CCCCCC',
      borderLeftColor: '#CCCCCC',
      borderRightColor: '#CCCCCC',
    });

    expect(trigger).toHaveStyle({
      borderBottomColor: '#CCCCCC',
      borderTopColor: '#CCCCCC',
      borderLeftColor: '#CCCCCC',
      borderRightColor: '#CCCCCC',
    });
  });
});
