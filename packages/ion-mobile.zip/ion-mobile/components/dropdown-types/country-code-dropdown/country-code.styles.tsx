import { Select, Stack, styled, XStack } from 'tamagui';

const SelectTrigger = styled(Select.Trigger, {
  width: 76,
  backgroundColor: '$Gray100',
  borderTopRightRadius: 0,
  borderBottomRightRadius: 0,
  borderBottomLeftRadius: 5,
  borderTopLeftRadius: 5,
  borderColor: '$Gray300',
  zIndex: 1,
  paddingLeft: '$lg',
  variants: {
    error: {
      true: {
        borderWidth: '$xs',
        borderColor: '$Error',
        borderRightWidth: '$0',
      },
    },
    pressed: {
      true: {
        borderColor: '$Gray800',
      },
    },
  },
});

const DropdownArrowContainer = styled(XStack, {
  paddingRight: '$lg',
  flex: 1,
  justifyContent: 'center',
  alignItems: 'center',
});

const ErrorMessage = styled(XStack, {
  marginVertical: '$md',
  marginRight: '$xl',
  paddingRight: '$xl',
  alignItems: 'flex-start',
});

const ErrorIconContainer = styled(Stack, {
  marginTop: '$sm',
});

const ListCloseButton = styled(XStack, {
  paddingBottom: '$xl',
});

export {
  DropdownArrowContainer,
  ErrorIconContainer,
  ErrorMessage,
  ListCloseButton,
  SelectTrigger,
};
