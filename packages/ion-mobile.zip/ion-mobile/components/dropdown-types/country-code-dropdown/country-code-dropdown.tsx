import { FlatList } from '@components/flatlist';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useDropdownChevron } from '@hooks/use-dropdown-chevron';
import { countries } from '@src/common/constants/country-codes.json';
import { useAccessibility } from '@src/common/providers/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { PropsWithChildren, useMemo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Animated,
  Keyboard,
  Platform,
  TouchableNativeFeedback,
  useWindowDimensions,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Adapt,
  getTokens,
  getVariableValue,
  Select,
  Sheet,
  Stack,
  useDebounceValue,
  XStack,
  YStack,
} from 'tamagui';

import { FocusAwareStatusBar } from '../../focus-aware-status-bar';
import { Icon } from '../../icon';
import { Text } from '../../text';
import { TextInput } from '../../text-input';
import {
  DEBOUNCE_WAIT,
  DropdownHeader,
  DropdownModal,
  DropdownModalProps,
  DropdownSuggestedCountry,
} from '../common/dropdown-elements';
import { useSearchableDropdownAccessibility } from '../common/use-searchable-dropdown-accessibility';
import {
  DropdownArrowContainer,
  ErrorIconContainer,
  ErrorMessage,
  SelectTrigger,
} from './country-code.styles';
import { Country, CountryCode, CountryCodeDropdownProps } from './types';

const sheetPercentageFromTopOfScreen = 0.07;
const sheetTopSnapPoint = sheetPercentageFromTopOfScreen * 100;

type ModalSelectorProps = PropsWithChildren<DropdownModalProps>;

const ModalSelector = ({ children, ...rest }: ModalSelectorProps) => {
  const { isScreenReaderEnabled } = useAccessibility();

  if (isScreenReaderEnabled) {
    return <DropdownModal {...rest}>{children}</DropdownModal>;
  }

  return (
    <Select.Content>
      <Select.Viewport>{children}</Select.Viewport>
    </Select.Content>
  );
};

export const CountryCodeDropdown = ({
  phoneNumberFieldLength = 10,
  selectInputProps,
  onValueChange,
  value,
  searchBar = true,
  containerProps,
  touchablaNativeFeedbackProps,
  hasSuggestedCountry = true,
  required = false,
  dropdownContentStyles,
}: CountryCodeDropdownProps) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const { t } = useTranslation();
  const { elementRef, focus } = useA11yFocus();

  const suggestedCountry: CountryCode = {
    name: 'United Kingdom',
    code: ' (+44)',
  };
  const minSearchTermLength = 2;
  const { country, number } = value;
  const tokens = getTokens();
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounceValue(
    searchTerm.toLowerCase(),
    DEBOUNCE_WAIT
  );
  const [isFocussed, setIsFocussed] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const { value: chevronAnimationValue } = useDropdownChevron(isExpanded);
  const insets = useSafeAreaInsets();
  const { height: windowHeight } = useWindowDimensions();
  const viewportMarginBottom = windowHeight * sheetPercentageFromTopOfScreen;
  const accessibilityHint = t('common.dropdown.accessibilityHint');

  const filteredCountries = useMemo(() => {
    if (debouncedSearchTerm.length > 1) {
      return countries.filter((countryItem) =>
        countryItem.name.toLowerCase().includes(debouncedSearchTerm)
      ) as Country[];
    }
    return countries;
  }, [debouncedSearchTerm]);

  useSearchableDropdownAccessibility({
    items: filteredCountries,
    searchable: searchBar,
    searchTerm: debouncedSearchTerm,
  });

  const handleFocussed = () => {
    if (selectInputProps?.error) {
      return;
    }

    setIsFocussed(!isFocussed);
  };

  const handleCountryCodeChange = (newSelectedCountry: string) => {
    const foundCountry =
      countries.find(({ name }) => name === newSelectedCountry) || country;
    onValueChange({
      country: foundCountry,
      number,
    });
  };

  const handlePhoneNumberChange = (newNumber: string) => {
    const phoneNumber = newNumber.replace(/^0|[^\d]/g, '');
    onValueChange({
      country,
      number: phoneNumber,
    });
  };

  const onOpenChange = () => {
    if (selectInputProps?.disabled) {
      return;
    }

    setIsExpanded(!isExpanded);

    if (searchTerm) {
      setSearchTerm('');
    }
  };

  const getCountryCodeFontVariant = () => {
    if (isExpanded || isFocussed || selectInputProps?.error) {
      return 'body-regular-Gray800';
    }
    return selectInputProps?.disabled
      ? 'body-regular-Gray300'
      : 'body-regular-Gray500';
  };

  return (
    <YStack>
      <XStack {...containerProps} testID="country-codes">
        <Select
          value={country.name}
          onValueChange={handleCountryCodeChange}
          onOpenChange={onOpenChange}
          open={isExpanded}
        >
          <SelectTrigger
            ref={elementRef}
            accessible
            accessibilityLabel={`Country code: ${country.code}`}
            accessibilityRole="button"
            accessibilityHint={
              required
                ? `${t('common.required')} ${accessibilityHint ?? ''}`
                : accessibilityHint
            }
            borderColor={selectInputProps?.error ? '$Error' : '$Gray300'}
            borderWidth={selectInputProps?.error ? '$xs' : '$xxs'}
            borderRightWidth={0}
            testID="country-code-trigger"
            iconAfter={
              <DropdownArrowContainer>
                <Animated.View
                  style={{ transform: [{ rotate: chevronAnimationValue }] }}
                >
                  <Icon
                    name="chevron-down"
                    color={
                      selectInputProps?.disabled
                        ? getVariableValue(tokens.color.$Gray300)
                        : getVariableValue(tokens.color.Secondary800)
                    }
                  />
                </Animated.View>
              </DropdownArrowContainer>
            }
            pointerEvents={selectInputProps?.disabled ? 'none' : 'auto'}
            error={selectInputProps?.error}
            pressed={!selectInputProps?.error && (isExpanded || isFocussed)}
            pressTheme={false}
            onPress={Keyboard.dismiss}
          >
            <Text fontVariant={getCountryCodeFontVariant()}>
              {country.code}
            </Text>
          </SelectTrigger>

          {!isScreenReaderEnabled && (
            <Adapt>
              {Platform.OS === 'android' && isExpanded && (
                <FocusAwareStatusBar style="dark" />
              )}
              <Sheet
                snapPoints={[100 - sheetTopSnapPoint]}
                modal
                disableDrag
                animationConfig={{
                  type: 'spring',
                  damping: 35,
                  mass: 1.2,
                  stiffness: 250,
                }}
              >
                <Sheet.Frame
                  borderTopRightRadius={20}
                  borderTopLeftRadius={20}
                  alignSelf="center"
                  backgroundColor={'transparent'}
                >
                  <DropdownHeader
                    onOpenChange={onOpenChange}
                    setSearchTerm={setSearchTerm}
                    searchTerm={searchTerm}
                    selectInputProps={selectInputProps}
                    searchBar={searchBar}
                  />
                  <Stack bg="white" flex={1}>
                    <Adapt.Contents />
                  </Stack>
                </Sheet.Frame>
                <Sheet.Overlay />
              </Sheet>
            </Adapt>
          )}

          <ModalSelector
            isVisible={isExpanded}
            onOpenChange={onOpenChange}
            setSearchTerm={setSearchTerm}
            searchTerm={searchTerm}
            selectInputProps={selectInputProps}
            searchBar={searchBar}
            isScrollView={false}
            height={1 - sheetPercentageFromTopOfScreen}
          >
            <Stack
              flex={1}
              {...(!isScreenReaderEnabled && {
                marginBottom: viewportMarginBottom,
              })}
            >
              <FlatList
                keyboardShouldPersistTaps="handled"
                alwaysBounceVertical={false}
                estimatedItemSize={53}
                keyExtractor={(item, index) => `${item.name}_${index}`}
                contentContainerStyle={{
                  paddingHorizontal: tokens.space.xl.val,
                  ...(typeof dropdownContentStyles === 'object' &&
                    dropdownContentStyles),
                }}
                scrollIndicatorInsets={{ bottom: insets.bottom }}
                contentInset={{ bottom: insets.bottom }}
                data={filteredCountries}
                extraData={{ countryName: country.name }}
                ListHeaderComponent={
                  hasSuggestedCountry &&
                  searchTerm.length < minSearchTermLength ? (
                    <DropdownSuggestedCountry
                      suggestedCountryName={suggestedCountry.name}
                      suggestedCountryCode={suggestedCountry.code}
                      valueCountryName={value.country.name}
                    />
                  ) : null
                }
                renderItem={(info) => {
                  const {
                    item: { name, code },
                    index,
                  } = info;
                  const isSelected = country.name === name;
                  const countryCode = ' (' + code + ')';

                  return (
                    <XStack
                      key={name}
                      accessible
                      accessibilityLabel={`${name} ${countryCode} ${
                        index + 1
                      } of ${filteredCountries.length}`}
                      accessibilityRole="button"
                      accessibilityHint={
                        !isSelected
                          ? t('common.dropdown.unselected')
                          : undefined
                      }
                      accessibilityState={{ selected: isSelected }}
                      flex={1}
                      justifyContent="flex-start"
                      padding="$xl"
                      paddingLeft={0}
                      paddingRight={'$sm'}
                      borderBottomWidth={1}
                      borderColor="$borderColor"
                      backgroundColor="$White"
                      pressStyle={{ backgroundColor: '$Gray050' }}
                      onPress={() => {
                        onValueChange({
                          country: {
                            code,
                            name,
                          },
                          number,
                        });
                        setIsExpanded(false);
                        focus();
                        Keyboard.dismiss();
                      }}
                    >
                      <Text fontVariant="body-semibold-Gray800">
                        {name}
                        <Text fontVariant="body-regular-Gray800">
                          {countryCode}
                        </Text>
                      </Text>
                      {isSelected && (
                        <XStack ml="auto" mt="auto">
                          <Icon
                            name="tick2"
                            width={getVariableValue(tokens.size['5'])}
                            height={getVariableValue(tokens.size['5'])}
                          />
                        </XStack>
                      )}
                    </XStack>
                  );
                }}
              />
            </Stack>
          </ModalSelector>
        </Select>

        <TouchableNativeFeedback
          testID={getTestId('country-code-number-input-container')}
          background={TouchableNativeFeedback.Ripple(
            getVariableValue(tokens.color.$Gray800),
            true
          )}
          {...touchablaNativeFeedbackProps}
        >
          <TextInput
            testID={getTestId('country-code-number-input')}
            tamaguiInputProps={{
              onChangeText: handlePhoneNumberChange,
              value: number,
              keyboardType: 'number-pad',
              maxLength: phoneNumberFieldLength,
              placeholder: selectInputProps?.numberTextPlaceholder,
              onFocus: handleFocussed,
              onBlur: handleFocussed,
              returnKeyType: 'done',
              onSubmitEditing: () => Keyboard.dismiss(),
            }}
            containerProps={{
              flex: 1,
              borderTopLeftRadius: 0,
              borderBottomLeftRadius: 0,
            }}
            required={required}
            error={selectInputProps?.error}
            disabled={selectInputProps?.disabled}
            active={!selectInputProps?.disabled || isExpanded}
            pressed={isExpanded}
          />
        </TouchableNativeFeedback>
      </XStack>

      {selectInputProps?.error && (
        <ErrorMessage testID="error-message-container">
          <ErrorIconContainer>
            <Icon
              name="alert-circle"
              color={getVariableValue(tokens.color.Error)}
            />
          </ErrorIconContainer>
          <Text
            fontVariant="body-regular-Error"
            tamaguiTextProps={{
              pl: '$md',
              pt: '$sm',
              accessibilityLabel: `Error, ${selectInputProps.errorText}`,
            }}
            testID={getTestId('error-message')}
          >
            {selectInputProps?.errorText}
          </Text>
        </ErrorMessage>
      )}
    </YStack>
  );
};
