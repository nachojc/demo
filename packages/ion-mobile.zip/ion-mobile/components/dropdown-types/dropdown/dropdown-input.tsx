import { useDropdownChevron } from '@hooks/use-dropdown-chevron';
import { Animated } from 'react-native';
import { getTokens, getVariableValue, Stack, XStack } from 'tamagui';

import { Icon } from '../../icon';
import { SmallDropdownArrowContainer } from './dropdown.styles';
import { DropdownTextInput } from './dropdown-text-input';
import { DropdownBaseProps } from './types';

type DropdownInputProps = Pick<
  DropdownBaseProps,
  | 'selectInputProps'
  | 'value'
  | 'placeHolderText'
  | 'isExpanded'
  | 'accessibilityLabel'
>;

export const DropdownInput = ({
  selectInputProps,
  value,
  placeHolderText,
  isExpanded,
  accessibilityLabel,
}: DropdownInputProps) => {
  const tokens = getTokens();
  const { value: chevronAnimationValue } = useDropdownChevron(isExpanded);

  return (
    <XStack>
      <Stack w="100%" pointerEvents="none">
        <DropdownTextInput
          disabled
          {...selectInputProps}
          tamaguiInputProps={{
            value,
            testID: 'list-input',
            color: selectInputProps?.disabled ? '$Gray500' : '$Gray800',
            placeholder: placeHolderText,
            selection: { start: 0 },
            ...selectInputProps?.tamaguiInputProps,
          }}
          pressed={isExpanded}
          accessibilityLabel={accessibilityLabel}
        />
      </Stack>
      <SmallDropdownArrowContainer
        testID="small-container"
        pressed={isExpanded}
        error={selectInputProps?.error}
      >
        <Animated.View
          style={{ transform: [{ rotate: chevronAnimationValue }] }}
        >
          <Icon
            name="chevron-down"
            color={
              selectInputProps?.disabled
                ? getVariableValue(tokens.color.$Gray300)
                : getVariableValue(tokens.color.$Secondary800)
            }
          />
        </Animated.View>
      </SmallDropdownArrowContainer>
    </XStack>
  );
};
