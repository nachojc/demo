import { Select, Separator, Stack, styled, XStack } from 'tamagui';

const SelectTrigger = styled(Select.Trigger, {
  position: 'absolute',
  right: 0,
  height: '100%',
  width: 48,
  borderWidth: 1,
  backgroundColor: '$Gray100',
  borderTopRightRadius: 5,
  borderBottomRightRadius: 5,
  borderBottomLeftRadius: 0,
  borderTopLeftRadius: 0,
  borderColor: '$Gray300',
  zIndex: 1,

  variants: {
    error: {
      true: {
        borderWidth: '$xs',
        borderColor: '$Error',
      },
    },
    pressed: {
      true: {
        borderColor: '$Gray800',
      },
    },
  },
});

const DropdownArrowContainer = styled(XStack, {
  paddingRight: '$lg',
  alignItems: 'center',
});

const ErrorMessage = styled(XStack, {
  marginVertical: '$md',
  marginRight: '$xl',
  alignItems: 'flex-start',
});

const ErrorIconContainer = styled(Stack, {
  marginTop: '$sm',
});

const SelectGroupList = styled(Select.Group, {
  paddingHorizontal: '$xl',
});

const SeparatorStyled = styled(Separator, {
  borderColor: '$Gray300',
  width: '95%',
  alignSelf: 'center',
});

const SmallDropdownArrowContainer = styled(DropdownArrowContainer, {
  position: 'absolute',
  width: 48,
  height: '100%',

  right: 0,
  backgroundColor: '$Gray100',
  paddingLeft: '$lg',

  borderWidth: 1,
  borderTopRightRadius: 5,
  borderBottomRightRadius: 5,
  borderBottomLeftRadius: 0,
  borderTopLeftRadius: 0,
  borderColor: '$Gray300',

  variants: {
    error: {
      true: {
        borderWidth: '$xs',
        borderColor: '$Error',
      },
    },
    pressed: {
      true: {
        borderColor: '$Gray800',
      },
    },
  },
});

export {
  DropdownArrowContainer,
  ErrorIconContainer,
  ErrorMessage,
  SelectGroupList,
  SelectTrigger,
  SeparatorStyled,
  SmallDropdownArrowContainer,
};
