import { useState } from 'react';
import { Platform } from 'react-native';
import { AccessibilityProps } from 'react-native/types';
import {
  GetProps,
  getTokens,
  getVariableValue,
  Input,
  InputProps as TamaguiInputProps,
  styled,
  XStack,
} from 'tamagui';

import { Icon, IconName } from '../../icon';

type ContainerProps = GetProps<typeof Container>;

export type TextInputProps = AccessibilityProps & {
  containerProps?: ContainerProps;
  tamaguiInputProps?: TamaguiInputProps;
  leadingIcon?: IconName;
  error?: boolean;
  disabled?: boolean;
  pressed?: boolean;
  active?: boolean;
};

export const DropdownTextInput = ({
  accessibilityLabel,
  accessibilityHint,
  containerProps = {},
  tamaguiInputProps = {},
  leadingIcon,
  error,
  disabled,
  pressed,
  active,
}: TextInputProps) => {
  const tokens = getTokens();
  const [focused, setFocused] = useState(false);
  const { onFocus, onEndEditing, ...rest } = tamaguiInputProps;

  const getBorderColor = () => {
    let borderColor = '$Gray200';

    if (error) {
      borderColor = '$Error';
    } else if (focused) {
      borderColor = '$Secondary800';
    } else if (pressed) {
      borderColor = '$Gray800';
    } else if (active || disabled) {
      borderColor = '$Gray300';
    }

    return borderColor;
  };

  return (
    <Container
      testID="text-input-container"
      {...containerProps}
      borderColor={getBorderColor()}
      borderWidth={error ? '$xs' : '$xxs'}
      accessibilityLabel={
        Platform.OS === 'android' ? accessibilityLabel : undefined
      }
      accessibilityHint={
        Platform.OS === 'android' ? accessibilityHint : undefined
      }
    >
      {leadingIcon && (
        <IconContainer error={error} testID="icon container">
          <Icon
            name={leadingIcon}
            accessibilityLabel={leadingIcon}
            accessibilityHint="Leading icon"
            color={getVariableValue(
              tokens.color[disabled ? '$Gray300' : '$Secondary800']
            )}
          />
        </IconContainer>
      )}
      <Input
        // TODO: move all of these styles to values from our theme
        accessibilityLabel={accessibilityLabel}
        accessibilityHint={accessibilityHint}
        importantForAccessibility="no"
        flex={5}
        size={getVariableValue(tokens.size['8'])}
        bc="$backgroundTransparent"
        style={{ paddingLeft: getVariableValue(tokens.space.md) }}
        fontWeight="$regular"
        bw={'$0'}
        fos="$body"
        ff="$body"
        blurOnSubmit={false}
        placeholderTextColor={getVariableValue(tokens.color.Gray500)}
        focusStyle={{ bw: 0 }}
        onFocus={(e) => {
          setFocused(true);
          if (onFocus) {
            onFocus(e);
          }
        }}
        onEndEditing={(e) => {
          setFocused(false);
          if (onEndEditing) {
            onEndEditing(e);
          }
        }}
        editable={!disabled}
        focusable={!disabled}
        disabled={disabled}
        color={focused ? '$Gray800' : '$Gray500'}
        {...rest}
      />
    </Container>
  );
};

export const Container = styled(XStack, {
  backgroundColor: '$White',
  borderWidth: '$xxs',
  paddingHorizontal: '$sm',
  borderRadius: 5,
  borderColor: '$Gray200',
});

export const IconContainer = styled(XStack, {
  flex: 1,
  marginLeft: '$-sm',
  marginRight: '$sm',
  alignItems: 'center',
  justifyContent: 'center',
  height: '99%',
  borderTopLeftRadius: 5,
  borderBottomLeftRadius: 5,
  borderRightWidth: '$xxs',
  borderRightColor: '$Gray200',
  backgroundColor: '$Gray100',
  variants: {
    error: {
      true: {
        borderRightWidth: '$xs',
        borderRightColor: '$Error',
      },
    },
  },
});
