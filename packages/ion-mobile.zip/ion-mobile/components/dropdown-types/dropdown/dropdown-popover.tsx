import { getTestId } from '@src/utils/get-test-id';
import { Platform } from 'expo-modules-core';
import { useTranslation } from 'react-i18next';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  getTokens,
  getVariableValue,
  ListItem,
  Popover,
  XStack,
  YGroup,
} from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import { SeparatorStyled } from './dropdown.styles';
import { DropdownBaseProps } from './types';

export function DropdownPopover({
  value,
  items,
  isExpanded,
  onOpenChange,
  onValueChange,
  children,
  focusRef,
  accessibilityLabelFormatter,
  required,
}: DropdownBaseProps) {
  const tokens = getTokens();
  const { t } = useTranslation();
  const { length } = items;
  const accessibilityHint = t('common.dropdown.accessibilityHint');
  const insets = useSafeAreaInsets();
  return (
    <Popover placement="bottom" open={isExpanded} onOpenChange={onOpenChange}>
      <Popover.Trigger
        accessible
        accessibilityLabel={
          accessibilityLabelFormatter && value
            ? accessibilityLabelFormatter(value)
            : value
        }
        accessibilityRole="button"
        accessibilityHint={
          required
            ? `${t('common.required')} ${accessibilityHint ?? ''}`
            : accessibilityHint
        }
        ref={focusRef}
      >
        {children}
      </Popover.Trigger>

      <Popover.Content
        elevate
        marginHorizontal="$xl"
        marginTop={Platform.OS === 'android' ? insets.top : 0}
        animation={'fast'}
        enterStyle={{ opacity: 0 }}
        opacity={1}
        exitStyle={{ opacity: 0 }}
        bg="transparent"
      >
        <YGroup
          width={'100%'}
          borderWidth={1}
          borderColor="$Gray800"
          borderRadius={5}
          marginTop="$md"
        >
          {items.map((item, index) => {
            const isSelected = item === value;
            return (
              <YGroup.Item key={item}>
                <ListItem
                  backgroundColor="$White"
                  padding="$xl"
                  testID={getTestId(`dropdown-item-${item}`)}
                  hoverTheme
                  onPress={() => onValueChange(item)}
                  borderRadius={5}
                  paddingRight="$xxxl"
                  accessible
                  accessibilityLabel={`${
                    accessibilityLabelFormatter
                      ? accessibilityLabelFormatter(item)
                      : item
                  } ${index + 1} of ${length}`}
                  accessibilityRole="button"
                  accessibilityHint={
                    !isSelected ? t('common.dropdown.unselected') : undefined
                  }
                  accessibilityState={{
                    selected: isSelected,
                  }}
                >
                  <XStack width="100%">
                    <Text
                      testID="item-open"
                      fontVariant="body-semibold-Gray800"
                    >
                      {item}
                    </Text>
                  </XStack>
                  {isSelected && (
                    <Icon
                      name="tick2"
                      width={getVariableValue(tokens.size['4'])}
                      height={getVariableValue(tokens.size['4'])}
                    />
                  )}
                </ListItem>
                {items.length - 1 !== index && <SeparatorStyled />}
              </YGroup.Item>
            );
          })}
        </YGroup>
      </Popover.Content>
    </Popover>
  );
}
