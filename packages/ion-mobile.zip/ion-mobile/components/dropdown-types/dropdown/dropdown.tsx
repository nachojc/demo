import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useToggle } from '@hooks/use-toggle';
import { getTestId } from '@src/utils/get-test-id';
import { useMemo, useState } from 'react';
import { Keyboard } from 'react-native';
import {
  getTokens,
  getVariableValue,
  SelectProps,
  Stack,
  useDebounceValue,
  XStack,
  YStack,
} from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import { DEBOUNCE_WAIT } from '../common/dropdown-elements';
import { useSearchableDropdownAccessibility } from '../common/use-searchable-dropdown-accessibility';
import { ErrorIconContainer } from './dropdown.styles';
import {
  DropdownActionSheet,
  DropDownContentProps,
} from './dropdown-action-sheet';
import { DropdownInput } from './dropdown-input';
import { DropdownBaseProps } from './types';

export type DropdownProps = Omit<DropdownBaseProps, 'isExpanded'> &
  Pick<DropDownContentProps, 'dropdownContentStyles'> & {
    searchTextPlaceholder?: string;
    containerProps?: SelectProps;
    searchBar?: boolean;
    hasSuggestedCountry?: boolean;
    onExpand?: () => void;
    testID?: string;
  };

export const Dropdown = ({
  containerProps,
  selectInputProps,
  onValueChange,
  onOpenChange,
  value,
  items,
  searchBar,
  hasSuggestedCountry = false,
  placeHolderText,
  onExpand,
  testID,
  accessibilityLabel,
  accessibilityLabelFormatter,
  required = false,
  modalStyles,
  dropdownContentStyles,
}: DropdownProps) => {
  const { elementRef, focus } = useA11yFocus();

  const tokens = getTokens();
  const [isExpanded, toggleIsExpanded] = useToggle(false);
  const [searchTerm, setSearchTerm] = useState('');
  const debouncedSearchTerm = useDebounceValue(
    searchTerm.toLowerCase(),
    DEBOUNCE_WAIT
  );
  const filteredItems: string[] = useMemo(() => {
    if (debouncedSearchTerm.length > 1) {
      return items.filter((item) =>
        item.toLowerCase().includes(debouncedSearchTerm)
      );
    }

    return items;
  }, [items, debouncedSearchTerm]);

  useSearchableDropdownAccessibility({
    items: filteredItems,
    searchable: !!searchBar,
    searchTerm: debouncedSearchTerm,
  });

  const onOpenChangeDrop = async (isOpen?: boolean) => {
    if (selectInputProps?.disabled) {
      return;
    }
    onOpenChange?.(isOpen);
    !isExpanded && onExpand && onExpand();

    toggleIsExpanded();

    if (searchTerm) {
      setSearchTerm('');
    }

    isExpanded && Keyboard.dismiss();

    if (!isOpen) {
      setTimeout(focus, 1000);
    }
  };

  const handleValueChange = (item: string) => {
    onValueChange(item);
    setSearchTerm('');

    isExpanded && Keyboard.dismiss();
  };

  const hardcodedTestID = getTestId('dropdown-action-sheet');

  const dropdownTestID = testID ?? hardcodedTestID;

  return (
    <YStack gap="$md">
      <Stack testID={dropdownTestID} position="relative">
        <DropdownActionSheet
          dropdownContentStyles={dropdownContentStyles}
          modalStyles={modalStyles}
          focusRef={elementRef}
          accessibilityLabelFormatter={accessibilityLabelFormatter}
          placeHolderText={placeHolderText}
          items={items}
          filteredItems={filteredItems}
          isExpanded={isExpanded}
          onValueChange={handleValueChange}
          searchTerm={searchTerm}
          value={value}
          selectInputProps={selectInputProps}
          onOpenChange={onOpenChangeDrop}
          setSearchTerm={setSearchTerm}
          containerProps={containerProps}
          searchBar={searchBar}
          hasSuggestedCountry={hasSuggestedCountry}
          required={required}
          testID={testID}
        >
          <DropdownInput
            selectInputProps={selectInputProps}
            value={value}
            placeHolderText={placeHolderText}
            isExpanded={isExpanded}
            accessibilityLabel={accessibilityLabel}
          />
        </DropdownActionSheet>
      </Stack>

      {selectInputProps?.error && selectInputProps?.errorText && (
        <XStack testID="error-message-container" gap="$md">
          <ErrorIconContainer>
            <Icon
              name="alert-circle"
              color={getVariableValue(tokens.color.Error)}
            />
          </ErrorIconContainer>
          <Stack flex={1}>
            {typeof selectInputProps.errorText === 'string' ? (
              <Text
                fontVariant="body-regular-Error"
                testID={getTestId('error-message')}
              >
                {selectInputProps.errorText}
              </Text>
            ) : (
              selectInputProps.errorText
            )}
          </Stack>
        </XStack>
      )}
    </YStack>
  );
};
