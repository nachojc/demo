import { useDropdownChevron } from '@hooks/use-dropdown-chevron';
import { getTestId } from '@src/utils/get-test-id';
import { RefObject, useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import {
  Animated,
  FlatList,
  Keyboard,
  Pressable,
  StyleProp,
  ViewStyle,
} from 'react-native';
import {
  getTokens,
  getVariableValue,
  Select,
  SelectProps,
  Stack,
  XStack,
  YStack,
} from 'tamagui';

import { Icon } from '../../icon';
import { Text } from '../../text';
import {
  DropdownModal,
  DropdownSuggestedCountry,
} from '../common/dropdown-elements';
import { DropdownArrowContainer, SelectTrigger } from './dropdown.styles';
import { DropdownBaseProps } from './types';

type DropdownActionSheetProps = DropdownBaseProps &
  Pick<DropDownContentProps, 'dropdownContentStyles'> & {
    setSearchTerm: (searchInput: string) => void;
    filteredItems: string[];
    searchTerm: string;
    searchBar?: boolean;
    containerProps?: SelectProps;
    hasSuggestedCountry?: boolean;
    focusRef?: RefObject<unknown>;
    testID?: string;
  };

export type DropDownContentProps = Pick<
  DropdownBaseProps,
  'value' | 'isExpanded' | 'accessibilityLabelFormatter'
> & {
  filteredItems: string[];
  hasSuggestedCountry?: boolean;
  searchTerm: string;
  testID?: string;
  dropdownContentStyles?: StyleProp<ViewStyle>;
};

const DropdownContent = ({
  hasSuggestedCountry,
  filteredItems,
  isExpanded,
  searchTerm,
  value,
  testID,
  accessibilityLabelFormatter,
  dropdownContentStyles,
}: DropDownContentProps) => {
  const { t } = useTranslation();
  const tokens = getTokens();
  const suggestedCountry = 'United Kingdom';
  const minSearchTermLength = 2;

  if (!isExpanded) {
    return null;
  }

  return (
    // Set minHeight to solve a warning https://stackoverflow.com/questions/73516978/flashlists-rendered-size-is-not-usable
    <Stack
      paddingHorizontal={getVariableValue(tokens.size[5])}
      flex={1}
      style={typeof dropdownContentStyles === 'object' && dropdownContentStyles}
    >
      {filteredItems.length > 0 &&
        hasSuggestedCountry &&
        searchTerm.length < minSearchTermLength && (
          <DropdownSuggestedCountry
            suggestedCountryName={suggestedCountry}
            suggestedCountryCode={''}
            valueCountryName={value}
          />
        )}

      {filteredItems.length > 0 ? (
        <FlatList
          keyboardShouldPersistTaps="handled"
          data={filteredItems}
          keyExtractor={(item, index) => `${item}_${index}`}
          showsVerticalScrollIndicator={false}
          renderItem={({ item: name, index: i }) => {
            const isSelected = name === value;
            const defaultBottomMargin = i === filteredItems.length - 1 ? 24 : 0;
            return (
              <Select.Item
                index={i}
                key={name}
                value={name}
                padding="$xl"
                paddingHorizontal={0}
                borderBottomWidth={1}
                backgroundColor="$White"
                mb={defaultBottomMargin}
                accessible
                accessibilityLabel={`${
                  accessibilityLabelFormatter
                    ? accessibilityLabelFormatter(name)
                    : name
                } ${i + 1} of ${filteredItems.length}`}
                accessibilityRole="button"
                accessibilityHint={
                  !isSelected ? t('common.dropdown.unselected') : undefined
                }
                accessibilityState={{
                  selected: isSelected,
                }}
                testID={getTestId(`dropdown-item-sheet-${name}`)}
              >
                <Text
                  testID={testID ?? `${testID}${i}`}
                  fontVariant="body-semibold-Gray800"
                >
                  {name}
                </Text>
                {isSelected && (
                  <Icon
                    name="tick2"
                    width={getVariableValue(tokens.size['5'])}
                    height={getVariableValue(tokens.size['5'])}
                  />
                )}
              </Select.Item>
            );
          }}
        />
      ) : (
        <YStack
          alignItems="center"
          justifyContent="center"
          height={getVariableValue(tokens.size['18'])}
        >
          <Icon
            name="alert-circle-outline"
            width={getVariableValue(tokens.size['8'])}
            height={getVariableValue(tokens.size['8'])}
          />
          <Text
            tamaguiTextProps={{ mt: '$lg' }}
            fontVariant="body-regular-Gray800"
          >
            {t('common.dropdown.emptyResults')}
          </Text>
        </YStack>
      )}
    </Stack>
  );
};

export const DropdownActionSheet = ({
  onOpenChange,
  setSearchTerm,
  onValueChange,
  filteredItems,
  searchTerm,
  searchBar,
  value,
  selectInputProps,
  isExpanded,
  containerProps,
  children,
  hasSuggestedCountry = false,
  accessibilityLabelFormatter,
  focusRef,
  required,
  modalStyles,
  dropdownContentStyles,
  placeHolderText,
}: DropdownActionSheetProps) => {
  const { t } = useTranslation();
  const tokens = getTokens();
  const { value: chevronAnimationValue } = useDropdownChevron(isExpanded);
  const accessibilityHint = t('common.dropdown.accessibilityHint');

  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);

  useEffect(() => {
    const showSubscription = Keyboard.addListener('keyboardDidShow', () => {
      setIsKeyboardVisible(true);
    });
    const hideSubscription = Keyboard.addListener('keyboardDidHide', () => {
      setIsKeyboardVisible(false);
    });

    return () => {
      showSubscription.remove();
      hideSubscription.remove();
    };
  }, []);

  const height = isKeyboardVisible || filteredItems.length > 5 ? 0.85 : 0.5;

  const getAccessibilityLabel = () => {
    if (!value) {
      return placeHolderText;
    }

    if (accessibilityLabelFormatter && value) {
      return accessibilityLabelFormatter(value);
    }

    return value;
  };

  return (
    <XStack {...containerProps}>
      <Select
        id="dropdown"
        value={value}
        onValueChange={onValueChange}
        onOpenChange={onOpenChange}
        open={isExpanded}
      >
        <SelectTrigger
          importantForAccessibility="no-hide-descendants"
          testID={getTestId('dropdown-select')}
          iconAfter={
            <DropdownArrowContainer>
              <Animated.View
                style={{ transform: [{ rotate: chevronAnimationValue }] }}
              >
                <Icon
                  name="chevron-down"
                  color={
                    selectInputProps?.disabled
                      ? getVariableValue(tokens.color.$Gray300)
                      : getVariableValue(tokens.color.Secondary800)
                  }
                />
              </Animated.View>
            </DropdownArrowContainer>
          }
          error={selectInputProps?.error}
          pressed={isExpanded}
          pointerEvents={selectInputProps?.disabled ? 'none' : 'auto'}
        />

        <DropdownModal
          modalStyles={modalStyles}
          isVisible={isExpanded}
          onOpenChange={onOpenChange}
          setSearchTerm={setSearchTerm}
          searchTerm={searchTerm}
          isScrollView={false}
          selectInputProps={selectInputProps}
          searchBar={searchBar}
          height={height}
        >
          <DropdownContent
            dropdownContentStyles={dropdownContentStyles}
            filteredItems={filteredItems}
            hasSuggestedCountry={hasSuggestedCountry}
            isExpanded={isExpanded}
            searchTerm={searchTerm}
            value={value}
            accessibilityLabelFormatter={accessibilityLabelFormatter}
          />
        </DropdownModal>
      </Select>
      <Pressable
        testID={getTestId('dropdown-trigger')}
        accessibilityLabel={getAccessibilityLabel()}
        accessibilityRole="button"
        accessibilityHint={
          required
            ? `${t('common.required')}. ${accessibilityHint ?? ''}`
            : accessibilityHint
        }
        onPress={() => {
          Keyboard.dismiss();
          onOpenChange?.(true);
        }}
        ref={focusRef}
      >
        {children}
      </Pressable>
    </XStack>
  );
};
