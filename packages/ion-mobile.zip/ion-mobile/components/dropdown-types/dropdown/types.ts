import { ReactNode } from 'react';
import { StyleProp, ViewStyle } from 'react-native';

import { TextInputProps } from './dropdown-text-input';

export type DropdownSelectInputProps = TextInputProps & {
  errorText?: ReactNode;
  searchTextPlaceholder?: string;
};

/**
 * These are the base props for the instances of
 * DropdownPopover and DropdownActionSheet to extend from
 */
export type DropdownBaseProps = {
  focusRef?: any;
  value?: string;
  items: string[];
  selectInputProps?: DropdownSelectInputProps;
  isExpanded: boolean;
  onValueChange: (item: string) => void;
  onOpenChange?: (open?: boolean) => void;
  placeHolderText?: string;
  children?: ReactNode;
  required?: boolean;
  accessibilityLabel?: string;
  accessibilityLabelFormatter?: (input: string) => string;
  modalStyles?: StyleProp<ViewStyle>;
  dropdownContentStyles?: StyleProp<ViewStyle>;
};
