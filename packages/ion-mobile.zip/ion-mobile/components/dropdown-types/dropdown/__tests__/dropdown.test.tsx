import { render, screen } from '@src/jest/testing-library';

import { Dropdown } from '../dropdown';

jest.mock('@src/utils/is-ipad');

const onValueChangeMock = jest.fn();

const smallList = ['Apple', 'Pear', 'Kale', 'Peach'];
const largeList = [
  'Apple',
  'Pear',
  'Kale',
  'Peach',
  'Banana',
  'Guava',
  'Tomato',
  'Power Bank',
];

const listTitle = 'Please select an option';
const listTestId = 'list-input';
const errorText = 'This is error text';
describe('Dropdown small', () => {
  it('should render small dropdown', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        value={listTitle}
        items={smallList}
      />
    );

    const dropdownSmall = screen.getByTestId('test:id/dropdown-action-sheet');
    const listInput = screen.getByTestId('list-input');

    expect(dropdownSmall).toBeOnTheScreen();
    expect(listInput).toHaveProp('value', listTitle);
    expect(listInput).toHaveStyle({ color: '#373737' });
  });

  it('should render disabled state', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        value={listTitle}
        items={smallList}
        selectInputProps={{ disabled: true }}
      />
    );

    const listInput = screen.getByTestId(listTestId);

    expect(listInput).toHaveProp('value', listTitle);
    expect(listInput).toHaveStyle({ color: '#717171' });
  });

  it('should render error state', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        value={listTitle}
        items={smallList}
        selectInputProps={{
          error: true,
          errorText,
        }}
      />
    );

    const input = screen.getByTestId('small-container');
    const error = screen.getByTestId('error-message-container');
    const errorMessage = screen.getByTestId('test:id/error-message');

    expect(input).toHaveStyle({
      borderBottomColor: '#BD2624',
      borderTopColor: '#BD2624',
      borderLeftColor: '#BD2624',
      borderRightColor: '#BD2624',
    });

    expect(error).toBeOnTheScreen();
    expect(errorMessage).toHaveTextContent(errorText);
  });

  it('should have the correct accessibility label', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        value={listTitle}
        items={smallList}
        accessibilityLabel={'Select option'}
      />
    );

    const listInput = screen.getByTestId('list-input');
    expect(listInput).toHaveProp('accessibilityLabel', 'Select option');
  });

  it('should have placeholder as the accessibility label if no input value in the dropdown', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        items={smallList}
        placeHolderText="Test placeholder"
      />
    );

    const listInput = screen.getByRole('button');
    expect(listInput).toHaveProp('accessibilityLabel', 'Test placeholder');
  });
});

describe('Dropdown large', () => {
  it('should render large dropdown', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        value={listTitle}
        items={largeList}
      />
    );

    const dropdownLarge = screen.getByTestId('test:id/dropdown-action-sheet');
    const listInput = screen.getByTestId('list-input');
    const inputValue = listInput._fiber.memoizedProps.value;

    expect(dropdownLarge).toBeOnTheScreen();
    expect(inputValue).toEqual(listTitle);
  });

  it('should render disabled state', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        value={listTitle}
        items={largeList}
        selectInputProps={{ disabled: true }}
      />
    );

    const listInput = screen.getByTestId(listTestId);

    expect(listInput).toHaveProp('value', listTitle);
    expect(listInput).toHaveStyle({ color: '#717171' });
  });

  it('should render error state', () => {
    render(
      <Dropdown
        onValueChange={onValueChangeMock}
        value={listTitle}
        items={largeList}
        selectInputProps={{
          error: true,
          errorText,
        }}
      />
    );

    const input = screen.getByTestId('test:id/dropdown-select', {
      includeHiddenElements: true,
    });
    const error = screen.getByTestId('error-message-container');
    const errorMessage = screen.getByTestId('test:id/error-message');

    expect(input).toHaveStyle({
      borderBottomColor: '#BD2624',
      borderTopColor: '#BD2624',
      borderLeftColor: '#BD2624',
      borderRightColor: '#BD2624',
    });

    expect(error).toBeOnTheScreen();
    expect(errorMessage).toHaveTextContent(errorText);
  });
});
