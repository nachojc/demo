import { fireEvent, render, screen } from '@src/jest/testing-library';
import { useState } from 'react';

import { DropdownTextInput, TextInputProps } from '../dropdown-text-input';

describe('DropdownTextInput', () => {
  describe('Error States', () => {
    it('should have non-focused border colour, when text input is non-focused state', () => {
      render(<DropdownTextInput accessibilityLabel="input" />);

      expect(screen.getByTestId('text-input-container')).toHaveStyle({
        borderLeftColor: '#D9D9D9',
        borderBottomWidth: 1,
      });
    });

    it('should have error styling applied, when error is true', () => {
      render(<DropdownTextInput accessibilityLabel="input" error />);

      expect(screen.getByTestId('text-input-container')).toHaveStyle({
        borderLeftColor: '#BD2624',
        borderBottomWidth: 2,
      });
    });
  });

  describe('Focus States', () => {
    it('should have focused border colour, when text input is focused state', () => {
      render(<DropdownTextInput accessibilityLabel="input" />);

      const textInputContainer = screen.getByTestId('text-input-container');
      const textInputField = screen.getByLabelText('input');
      fireEvent(textInputField, 'onFocus');

      expect(textInputContainer).toHaveStyle({
        borderLeftColor: '#122D44',
        borderBottomWidth: 1,
      });

      fireEvent(textInputField, 'onEndEditing');
      expect(textInputContainer).toHaveStyle({
        borderLeftColor: '#D9D9D9',
        borderBottomWidth: 1,
      });
    });

    it('should have focused text colour, when text input is focused state', () => {
      render(<DropdownTextInput accessibilityLabel="input" />);

      const textInputField = screen.getByLabelText('input');

      fireEvent(textInputField, 'onFocus');
      expect(textInputField).toHaveStyle({ color: '#373737' });

      fireEvent(textInputField, 'onEndEditing');
      expect(textInputField).toHaveStyle({ color: '#717171' });
    });
  });

  describe('Pressed State', () => {
    it('should have pressed styling applied, when pressed is true', () => {
      render(<DropdownTextInput accessibilityLabel="input" pressed />);

      expect(screen.getByTestId('text-input-container')).toHaveStyle({
        borderLeftColor: '#373737',
        borderBottomWidth: 1,
      });
    });
  });

  describe('Icon', () => {
    it('should not display icon if not passed in', () => {
      render(<DropdownTextInput accessibilityLabel="input" />);

      expect(screen.queryByTestId('icon container')).toBeNull();
    });

    it('should have icon displayed on button, when isIcon is true', () => {
      render(
        <DropdownTextInput
          accessibilityLabel="input"
          leadingIcon="alert-circle"
        />
      );
      expect(
        screen.getByTestId('test:id/icon-alert-circle', {
          includeHiddenElements: true,
        })
      ).toBeDefined();
    });
  });

  describe('Disabled States', () => {
    const DropdownTextInputWithState = (props: TextInputProps) => {
      const [text, setText] = useState('');
      return (
        <DropdownTextInput
          {...props}
          tamaguiInputProps={{
            value: text,
            onChangeText: setText,
            ...props.tamaguiInputProps,
          }}
        />
      );
    };

    it('should not allow to be edited when disabled is true', async () => {
      render(
        <DropdownTextInputWithState accessibilityLabel="input" disabled />
      );

      const input = screen.getByLabelText('input');

      expect(input).toHaveProp('focusable', false);
      expect(input).toHaveProp('editable', false);
      expect(input).toBeDisabled();

      const CHANGE_TEXT = 'some new text';
      fireEvent.changeText(input, CHANGE_TEXT);
      expect(screen.queryByDisplayValue(CHANGE_TEXT)).toBeNull();
    });

    it('should allow to be edited when disabled is false', async () => {
      render(
        <DropdownTextInputWithState
          accessibilityLabel="input"
          disabled={false}
        />
      );

      const input = screen.getByLabelText('input');

      expect(input).toHaveProp('focusable', true);
      expect(input).toHaveProp('editable', true);
      expect(input).not.toBeDisabled();

      const CHANGE_TEXT = 'some new text';

      fireEvent.changeText(input, CHANGE_TEXT);
      expect(screen.getByDisplayValue(CHANGE_TEXT)).toBeOnTheScreen();
    });
  });
});
