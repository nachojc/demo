import { styled, XStack, YStack } from 'tamagui';

const CustomSegmentedControl = styled(YStack, {
  bg: '$White',
  br: 5,
  borderColor: '$Gray200',
  bw: '$xxs',
  py: '$sm',
  variants: {
    error: {
      true: {
        borderColor: '$Error',
        bw: '$xs',
      },
    },
  },
});

const ErrorMessage = styled(XStack, {
  my: '$md',
  ai: 'center',
});

export { CustomSegmentedControl, ErrorMessage };
