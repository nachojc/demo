import { useRoute } from '@react-navigation/native';
import { getTestId } from '@src/utils/get-test-id/get-test-id';
import { useState } from 'react';
import {
  getTokens,
  getVariableValue,
  Separator,
  StackProps,
  ToggleGroup,
} from 'tamagui';
import { ValueOf } from 'type-fest';

import { Icon } from '../icon';
import { Text } from '../text';
import {
  CustomSegmentedControl,
  ErrorMessage,
} from './segmented-controls.style';

type SegmentedControlProps = {
  optionOne: string;
  optionTwo: string;
  error?: boolean;
  defaultValue?: boolean | null;
  onChange?: (value: boolean | undefined) => void;
  styles?: StackProps;
};

const options = {
  true: 'optionOne',
  false: 'optionTwo',
} as const;
type Option = ValueOf<typeof options>;

export const SegmentedControls = ({
  optionOne,
  optionTwo,
  error,
  onChange,
  defaultValue,
  styles,
}: SegmentedControlProps) => {
  const [selectedControl, setSelectedControl] = useState(defaultValue);
  const route = useRoute();

  const onValueChange = (value: Option) => {
    const val = optionToBoolean(value);
    onChange?.(val);
    setSelectedControl(val);
  };

  return (
    <>
      <CustomSegmentedControl
        error={error}
        testID="segmented-control"
        {...styles}
      >
        <ToggleGroup
          type="single"
          orientation="horizontal"
          accessibilityRole="radiogroup"
          accessibilityLabel="Radio button group"
          defaultValue={booleanToOption(defaultValue)}
          onValueChange={onValueChange}
          unstyled
          bg={'$White'}
          disablePassBorderRadius
          disableDeactivation
        >
          <ToggleGroup.Item
            testID={getTestId(`${optionOne} button`, route?.name)}
            unstyled
            flex={1}
            jc={'center'}
            ai={'center'}
            mx={'$sm'}
            br={5}
            bg={selectedControl ? '$Success' : '$White'}
            value={options.true}
            accessibilityState={{
              selected: !!selectedControl,
            }}
            accessibilityRole="radio"
            accessibilityLabel={`${optionOne}, option 1 of 2`}
            accessible
          >
            <Text
              tamaguiTextProps={{ padding: 8 }}
              fontVariant={`body-${selectedControl ? 'semibold' : 'regular'}-${
                selectedControl ? 'White' : 'Gray900'
              }`}
            >
              {optionOne}
            </Text>
          </ToggleGroup.Item>
          <Separator als="stretch" vertical borderColor={'$Gray200'} />
          <ToggleGroup.Item
            testID={getTestId(`${optionTwo} button`, route?.name)}
            unstyled
            flex={1}
            jc={'center'}
            ai={'center'}
            mx={'$sm'}
            br={5}
            bg={selectedControl === false ? '$Success' : '$White'}
            value={options.false}
            accessibilityState={{
              selected: selectedControl === false,
            }}
            accessibilityRole="radio"
            accessibilityLabel={`${optionTwo}, option 2 of 2`}
            accessible
          >
            <Text
              fontVariant={`body-${
                selectedControl === false ? 'semibold' : 'regular'
              }-${selectedControl === false ? 'White' : 'Gray900'}`}
            >
              {optionTwo}
            </Text>
          </ToggleGroup.Item>
        </ToggleGroup>
      </CustomSegmentedControl>
      {error && (
        <ErrorMessage testID={getTestId('error-message')}>
          <Icon
            name={'alert-circle'}
            color={getVariableValue(getTokens().color.Error)}
          />
          <Text
            fontVariant={'body-regular-Error'}
            tamaguiTextProps={{ pl: '$md' }}
          >
            Please select an option.
          </Text>
        </ErrorMessage>
      )}
    </>
  );
};

const optionToBoolean = (value?: Option) => {
  if (typeof value === 'string') {
    return value === options.true;
  }
  return undefined;
};

const booleanToOption = (value?: boolean | null): Option | undefined => {
  if (value === undefined) {
    return undefined;
  }
  return value ? options.true : options.false;
};
