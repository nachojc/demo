import { fireEvent, render, screen } from '@src/jest/testing-library';

import { SegmentedControls } from '../segmented-controls';

const yesButtonQuery = () =>
  screen.getByRole('radio', { name: /Yes, option 1 of 2/i });

const noButtonQuery = () =>
  screen.getByRole('radio', { name: /No, option 2 of 2/i });

const colors = {
  checked: '#4F9F31',
  unchecked: '#FFFFFF',
};

describe('Segmented controls', () => {
  it('renders correctly', () => {
    render(<SegmentedControls optionOne="Yes" optionTwo="No" />);

    expect(yesButtonQuery()).toBeOnTheScreen();
    expect(noButtonQuery()).toBeOnTheScreen();

    const segmetedControl = screen.getByTestId('segmented-control');
    expect(segmetedControl).toHaveStyle({
      backgroundColor: '#FFFFFF',
      borderBottomColor: '#D9D9D9',
      borderTopColor: '#D9D9D9',
      borderRightColor: '#D9D9D9',
      borderLeftColor: '#D9D9D9',
      borderTopWidth: 1,
      borderBottomWidth: 1,
      borderLeftWidth: 1,
      borderRightWidth: 1,
    });
  });

  it('renders selected state correctly', async () => {
    const mockOnChange = jest.fn();
    render(
      <SegmentedControls
        optionOne="Yes"
        optionTwo="No"
        onChange={mockOnChange}
      />
    );

    fireEvent.press(yesButtonQuery());

    expect(mockOnChange).toHaveBeenCalledWith(true);

    // Weird RNTL behaviour here, after the state change above, attempting to re-use a variable for the
    // element query results in 'Unable to find node on an unmounted component.'
    expect(yesButtonQuery()).toHaveStyle({ backgroundColor: colors.checked });
    expect(noButtonQuery()).toHaveStyle({ backgroundColor: colors.unchecked });

    fireEvent.press(noButtonQuery());

    expect(mockOnChange).toHaveBeenCalledWith(false);

    expect(yesButtonQuery()).toHaveStyle({ backgroundColor: colors.unchecked });
    expect(noButtonQuery()).toHaveStyle({ backgroundColor: colors.checked });
  });

  it('renders error state correctly', () => {
    render(<SegmentedControls optionOne="Yes" optionTwo="No" error />);

    const segmentedControl = screen.getByTestId('segmented-control');
    const errorControl = screen.getByTestId('test:id/error-message');
    const errorText = 'Please select an option.';

    expect(segmentedControl).toHaveStyle({
      backgroundColor: '#FFFFFF',
      borderBottomColor: '#BD2624',
      borderTopColor: '#BD2624',
      borderRightColor: '#BD2624',
      borderLeftColor: '#BD2624',
      borderTopWidth: 2,
      borderBottomWidth: 2,
      borderLeftWidth: 2,
      borderRightWidth: 2,
    });
    expect(errorControl).toBeDefined();
    expect(errorControl).toHaveTextContent(errorText);
  });
});
