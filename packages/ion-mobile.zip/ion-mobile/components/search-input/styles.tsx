import { styled, XStack } from 'tamagui';

export const Container = styled(XStack, {
  ai: 'center',
  space: '$md',
});

export const InputContainer = styled(XStack, {
  borderWidth: '$xxs',
  borderColor: '$Gray200',
  borderRadius: 5,
  f: 1,
  variants: {
    error: {
      true: {
        borderColor: '$Error',
        borderWidth: '$xs',
      },
    },

    focused: {
      true: {
        borderColor: '$Secondary800',
      },
    },
  } as const,
});
