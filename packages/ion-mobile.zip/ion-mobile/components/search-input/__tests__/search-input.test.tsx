import { fireEvent, render, screen } from '@src/jest/testing-library';

import { SearchInput } from '../search-input';

describe('Testing a Search Input', () => {
  it('should have non-focused border colour, when search input is non-focused state', () => {
    render(<SearchInput onSearch={jest.fn()} />);
    const searchInputContainer = screen.getByTestId('search-input-container');

    expect(searchInputContainer).toHaveStyle({
      borderLeftColor: '#D9D9D9',
      borderBottomWidth: 1,
    });
  });

  it('should have focused border colour, when search input is focused state', () => {
    render(<SearchInput onSearch={jest.fn()} />);

    const searchInputContainer = screen.getByTestId('search-input-container');
    const searchInputField = screen.getByTestId('search-input-field');
    fireEvent(searchInputField, 'onFocus');

    expect(searchInputContainer).toHaveStyle({
      borderLeftColor: '#122D44',
      borderBottomWidth: 1,
    });
  });

  it('should call onTouchStart, when search button is touch', () => {
    const onSearch = jest.fn();
    render(<SearchInput onTouchStart={onSearch} onSearch={onSearch} hasIcon />);

    const searchInputButton = screen.getByRole('button');
    fireEvent.press(searchInputButton, {
      key: 'Enter',
      code: 'Enter',
      charCode: 13,
    });

    expect(onSearch).toHaveBeenCalledTimes(1);
  });

  it('should call onSearch, when search button is pressed', () => {
    const onSearch = jest.fn();
    render(<SearchInput onSearch={onSearch} hasIcon />);

    const searchInputButton = screen.getByRole('button');
    fireEvent.press(searchInputButton);

    expect(onSearch).toHaveBeenCalledTimes(1);
  });

  it('should have error styling applied, when error is true', () => {
    render(<SearchInput onSearch={jest.fn()} error />);

    const searchInputContainer = screen.getByTestId('search-input-container');

    expect(searchInputContainer).toHaveStyle({
      borderLeftColor: '#BD2624',
      borderBottomWidth: 2,
    });
  });

  it('should have no icon displayed on button, when hasIcon is false', () => {
    render(<SearchInput onSearch={jest.fn()} hasIcon={false} />);

    const searchInputText = screen.getByText('Search');
    const searchInputButton = screen.getByRole('button');

    expect(searchInputButton).toContainElement(searchInputText);
  });

  it('should have icon displayed on button, when hasIcon is true', () => {
    render(<SearchInput onSearch={jest.fn()} hasIcon />);

    const icon = screen.getByTestId('test:id/icon-search', {
      includeHiddenElements: true,
    });

    expect(icon).toBeDefined();
    expect(screen.queryByText('Search')).toBeNull();
  });

  it('should not display custom error message when error is false', () => {
    render(
      <SearchInput
        error={false}
        errorText="Some error message"
        onSearch={jest.fn()}
      />
    );

    expect(
      screen.queryByRole('text', { name: 'Some error message' })
    ).toBeFalsy();
  });

  it('should display custom error message when error is true', () => {
    render(
      <SearchInput error errorText="Some error message" onSearch={jest.fn()} />
    );

    expect(
      screen.getByRole('text', { name: 'Some error message' })
    ).toBeOnTheScreen();
  });

  it('should override the input accessibility when inputAccessibilityLabel prop is passed in', () => {
    render(
      <SearchInput onSearch={jest.fn()} inputAccessibilityLabel="Testing 123" />
    );

    const searchInputContainer = screen.getByTestId('search-input-container');
    expect(searchInputContainer).toHaveProp('accessible', true);
    expect(searchInputContainer).toHaveProp(
      'accessibilityLabel',
      'Testing 123'
    );
  });
});
