import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useState } from 'react';
import { ColorValue } from 'react-native';
import {
  getTokens,
  getVariableValue,
  Input,
  InputProps as TamaguiInputProps,
} from 'tamagui';

import { Button, ButtonVariant } from '../button';
import { ErrorMessage } from '../error-message';
import { Icon } from '../icon';
import { Container, InputContainer } from './styles';

export type SearchInputProps = {
  buttonAccessibilityLabel?: string;
  inputAccessibilityLabel?: string;
  error?: boolean;
  tamaguiInputProps?: TamaguiInputProps;
  onFocus?: () => void;
  onBlur?: () => void;
  onTouchStart?: () => void;
  onSearch: (searchTerm?: string) => void;
  hasIcon?: boolean;
  buttonVariant?: ButtonVariant;
  primary?: boolean;
  directWealth?: boolean;
  buttonText?: string;
  buttonTestID?: string;
  errorText?: string;
  iconColor?: ColorValue;
  maxLength?: number;
  innerRef?: any;
};

export const SearchInput = ({
  buttonAccessibilityLabel,
  inputAccessibilityLabel,
  tamaguiInputProps = {},
  error,
  onFocus = () => {
    return;
  },
  onBlur,
  onSearch,
  onTouchStart,
  hasIcon,
  buttonVariant,
  buttonText,
  buttonTestID,
  errorText,
  iconColor,
  maxLength,
  innerRef,
}: SearchInputProps) => {
  const tokens = getTokens();
  const [focused, setFocused] = useState(false);
  const { elementRef, focus } = useA11yFocus(innerRef);

  const searchBtnText = buttonText ?? 'Search';

  return (
    <>
      <Container>
        <InputContainer
          focused={focused}
          error={error}
          testID="search-input-container"
          accessible={!!inputAccessibilityLabel}
          accessibilityLabel={inputAccessibilityLabel}
        >
          <Input
            ref={elementRef}
            f={1}
            size={getVariableValue(tokens.size['8'])}
            style={{ paddingLeft: getVariableValue(tokens.space.md) }}
            bc="$White"
            fos="$body"
            ff="$body"
            fontWeight="$regular"
            placeholderTextColor={getVariableValue(tokens.color.Gray400)}
            focusStyle={{ bw: 0 }}
            borderRadius={5}
            onFocus={() => {
              setFocused(true);
              onFocus();
            }}
            onBlur={onBlur}
            testID="search-input-field"
            {...tamaguiInputProps}
            onEndEditing={(e) => {
              tamaguiInputProps.onEndEditing?.(e);
              setFocused(false);
              error && focus(errorText);
            }}
            maxLength={maxLength}
            returnKeyType="search"
          />
        </InputContainer>
        <Button
          accessibilityLabel={buttonAccessibilityLabel}
          variant={buttonVariant}
          borderRadius={5}
          height={'100%'}
          paddingHorizontal="$lg"
          useStyledButtonText={!hasIcon}
          onPress={() => onSearch(tamaguiInputProps.value)}
          onTouchStart={onTouchStart}
          testID={buttonTestID}
        >
          {hasIcon ? (
            <Icon
              name="search"
              color={iconColor}
              onPress={() => onSearch(tamaguiInputProps.value)}
            />
          ) : (
            searchBtnText
          )}
        </Button>
      </Container>
      {error ? <ErrorMessage error={errorText} /> : null}
    </>
  );
};
