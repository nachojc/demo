import { useState } from 'react';
import {
  GetProps,
  getTokens,
  getVariableValue,
  styled,
  TextArea as TamaguiTextArea,
  TextAreaProps as TamaguiTextAreaProps,
  XStack,
} from 'tamagui';

type ContainerProps = GetProps<typeof Container>;

export type TextBoxProps = {
  accessibilityLabel?: string;
  accessibilityHint?: string;
  containerProps?: ContainerProps;
  textAreaProps?: TamaguiTextAreaProps;
  error?: boolean;
  disabled?: boolean;
  pressed?: boolean;
  active?: boolean;
};

export const TextBox = ({
  accessibilityLabel,
  accessibilityHint,
  containerProps = {},
  textAreaProps = {},
  error,
  disabled,
  pressed,
  active,
}: TextBoxProps) => {
  const tokens = getTokens();
  const [focused, setFocused] = useState(false);
  const { onFocus, onEndEditing, ...rest } = textAreaProps;

  const activeColor = active || disabled ? '$Gray300' : '$Gray200';
  const pressActiveColor = pressed ? '$Gray800' : activeColor;
  const focusPressActiveColor = focused ? '$Secondary800' : pressActiveColor;

  return (
    <>
      <Container
        testID="text-area-container"
        {...containerProps}
        borderColor={error ? '$Error' : focusPressActiveColor}
        borderWidth={error ? '$xs' : '$xxs'}
      >
        <StyledTextArea
          accessibilityLabel={accessibilityLabel}
          accessibilityHint={accessibilityHint}
          style={{
            paddingLeft: getVariableValue(tokens.space.md),
          }}
          blurOnSubmit={false}
          focusStyle={{ bw: 0 }}
          placeholderTextColor={getVariableValue(tokens.color.Gray500)}
          onFocus={(e) => {
            setFocused(true);
            onFocus?.(e);
          }}
          onEndEditing={(e) => {
            setFocused(false);
            onEndEditing?.(e);
          }}
          editable={!disabled}
          focusable={!disabled}
          disabled={disabled}
          {...rest}
        />
      </Container>
    </>
  );
};

const StyledTextArea = styled(TamaguiTextArea, {
  f: 1,
  fontWeight: '$regular',
  ff: '$body',
  fos: '$body',
  bc: '$backgroundTransparent',
  bw: '$0',
  // by default TextArea vertically aling the text on center
  textAlignVertical: 'top',
});

const Container = styled(XStack, {
  padding: '$lg',
  backgroundColor: '$White',
  borderWidth: '$xxs',
  paddingHorizontal: '$sm',
  borderRadius: 5,
  borderColor: '$Gray200',
  minHeight: '$12',
});
