import { fireEvent, render, screen } from '@src/jest/testing-library';
import { useState } from 'react';

import { TextBox, TextBoxProps } from '../text-box';

describe('<TextBox />', () => {
  describe('Error States', () => {
    it('should have non-focused border colour, when text box is non-focused state', () => {
      render(<TextBox accessibilityLabel="text box" />);

      expect(screen.getByTestId('text-area-container')).toHaveStyle({
        borderLeftColor: '#D9D9D9',
        borderBottomWidth: 1,
      });
    });

    it('should have error styling applied, when error is true', () => {
      render(<TextBox accessibilityLabel="text box" error />);

      expect(screen.getByTestId('text-area-container')).toHaveStyle({
        borderLeftColor: '#BD2624',
        borderBottomWidth: 2,
      });
    });
  });

  describe('Focus States', () => {
    it('should have focused border colour, when text box is focused state', () => {
      render(<TextBox accessibilityLabel="text box" />);

      const textBoxContainer = screen.getByTestId('text-area-container');
      const textBoxField = screen.getByLabelText('text box');

      fireEvent(textBoxField, 'onFocus');

      expect(textBoxContainer).toHaveStyle({
        borderLeftColor: '#122D44',
        borderBottomWidth: 1,
      });

      fireEvent(textBoxField, 'onEndEditing');

      expect(textBoxContainer).toHaveStyle({
        borderLeftColor: '#D9D9D9',
        borderBottomWidth: 1,
      });
    });
  });

  describe('Pressed State', () => {
    it('should have pressed styling applied, when pressed is true', () => {
      render(<TextBox accessibilityLabel="input" pressed />);

      const textBoxContainer = screen.getByTestId('text-area-container');

      expect(textBoxContainer).toHaveStyle({
        borderLeftColor: '#373737',
        borderBottomWidth: 1,
      });
    });
  });

  describe('Disabled States', () => {
    const TextBoxWithState = (props: TextBoxProps) => {
      const [text, setText] = useState('');
      return (
        <TextBox
          {...props}
          textAreaProps={{
            value: text,
            onChangeText: setText,
            ...props.textAreaProps,
          }}
        />
      );
    };

    it('should not allow to be edited when disabled is true', async () => {
      render(<TextBoxWithState accessibilityLabel="textBox" disabled />);

      const textBox = screen.getByLabelText('textBox');

      expect(textBox).toHaveProp('focusable', false);
      expect(textBox).toHaveProp('editable', false);
      expect(textBox).toBeDisabled();

      const CHANGE_TEXT = 'some new text';
      fireEvent.changeText(textBox, CHANGE_TEXT);
      expect(screen.queryByDisplayValue(CHANGE_TEXT)).toBeNull();
    });

    it('should allow to be edited when disabled is false', async () => {
      render(<TextBoxWithState accessibilityLabel="input" disabled={false} />);

      const input = screen.getByLabelText('input');

      expect(input).toHaveProp('focusable', true);
      expect(input).toHaveProp('editable', true);
      expect(input).not.toBeDisabled();

      const CHANGE_TEXT = 'some new text';

      fireEvent.changeText(input, CHANGE_TEXT);
      expect(screen.getByDisplayValue(CHANGE_TEXT)).toBeOnTheScreen();
    });
  });
});
