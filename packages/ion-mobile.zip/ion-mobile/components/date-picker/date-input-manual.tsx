import { UK_DATE_FORMAT } from '@constants/string-formats';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { tokens } from '@src/theme/tokens';
import { spellOutString } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { isEmptyString } from '@src/utils/string-manipulation';
import { isValid, parse } from 'date-fns';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Keyboard } from 'react-native';
import { InputProps, Stack, XStack, YStack } from 'tamagui';

import { Icon } from '../icon';
import { IconContainer, TextInput } from '../text-input';
import { DatePickerNative, DatePickerNativeProps } from './date-picker-native';

const getDateFromString = (value?: string) => {
  const noDate = { day: '', month: '', year: '' };
  if (!value) {
    return noDate;
  }
  try {
    const parsedDate = parse(value, UK_DATE_FORMAT, new Date());
    return {
      day: parsedDate.getDate().toString().padStart(2, '0'),
      month: (parsedDate.getMonth() + 1).toString().padStart(2, '0'),
      year: parsedDate.getFullYear().toString(),
    };
  } catch {
    return noDate;
  }
};

type Props = {
  datePickerProps?: DatePickerNativeProps['datePickerProps'];
  tamaguiInputProps?: InputProps;
  onFocus?: () => void;
  onExpand?: () => void;
  error?: boolean;
  required?: boolean;
};

export const DateInputManual = ({
  tamaguiInputProps,
  datePickerProps,
  onFocus,
  onExpand,
  error,
  required,
}: Props) => {
  const { t } = useTranslation();
  const [open, setOpen] = useState(false);

  const initValue = getDateFromString(tamaguiInputProps?.value);

  const [dateInput, setDateInput] = useState(initValue);

  const { elementRef: monthRef, focus: focusOnMonth } = useA11yFocus();
  const { elementRef: yearRef, focus: focusOnYear } = useA11yFocus();

  const setUserInput = (part: keyof typeof dateInput, value: string) => {
    const sanitizedValue = value.replace(/[^\d]+/g, '');
    const newUserDate = { ...dateInput, [part]: sanitizedValue };
    setDateInput(newUserDate);

    const completeDate = [
      newUserDate.day.padStart(2, '0'),
      newUserDate.month.padStart(2, '0'),
      newUserDate.year,
    ].join('/');

    const parsedUserInput = parse(completeDate, UK_DATE_FORMAT, new Date());

    if (isValid(parsedUserInput)) {
      tamaguiInputProps?.onChangeText?.(
        parsedUserInput.toLocaleDateString('en-GB')
      );
    } else {
      tamaguiInputProps?.onChangeText?.('');
    }
  };

  const yearAccessibility = (input: string) =>
    `${t('common.forms.datepickerManual.yearLabel')} ${
      isEmptyString(input)
        ? spellOutString(t('common.forms.datepickerManual.yearPlaceholder'))
        : input
    }`;

  return (
    <>
      <XStack alignItems="center">
        <Stack flex={1}>
          <XStack space="$md">
            <YStack space="$sm" w="$10">
              <TextInput
                testID={getTestId('manual-date-day-text-input')}
                required={required}
                tamaguiInputProps={{
                  accessibilityLabel: t(
                    'common.forms.datepickerManual.dayLabel'
                  ),
                  maxLength: 2,
                  placeholder: t(
                    'common.forms.datepickerManual.dayPlaceholder'
                  ),
                  onChangeText: (x) => setUserInput('day', x),
                  value: dateInput?.day ?? '',
                  keyboardType: 'numeric',
                  returnKeyType: 'done',
                  onSubmitEditing: () => {
                    monthRef?.current?.focus();
                    focusOnMonth();
                  },
                }}
              />
            </YStack>
            <YStack space="$sm" w="$10">
              <TextInput
                testID={getTestId('manual-date-month-text-input')}
                required={required}
                tamaguiInputProps={{
                  ref: monthRef,
                  accessibilityLabel: t(
                    'common.forms.datepickerManual.monthLabel'
                  ),
                  maxLength: 2,
                  placeholder: t(
                    'common.forms.datepickerManual.monthPlaceholder'
                  ),
                  onChangeText: (x) => setUserInput('month', x),
                  value: dateInput?.month ?? '',
                  keyboardType: 'numeric',
                  returnKeyType: 'done',
                  onSubmitEditing: () => {
                    yearRef?.current?.focus();
                    focusOnYear();
                  },
                }}
              />
            </YStack>
            <YStack space="$sm" w="$11">
              <YStack
                accessible
                accessibilityLabel={yearAccessibility(dateInput?.year)}
              >
                <TextInput
                  testID={getTestId('manual-date-year-text-input')}
                  required={required}
                  tamaguiInputProps={{
                    ref: yearRef,
                    placeholder: t(
                      'common.forms.datepickerManual.yearPlaceholder'
                    ),
                    maxLength: 4,
                    onChangeText: (x) => setUserInput('year', x),
                    value: dateInput?.year ?? '',
                    keyboardType: 'numeric',
                    returnKeyType: 'done',
                    onSubmitEditing: () => {
                      Keyboard.dismiss();
                      focusOnYear();
                    },
                  }}
                />
              </YStack>
            </YStack>
          </XStack>
        </Stack>

        <Stack
          onPress={() => {
            onExpand?.();
            setOpen(true);
          }}
          alignItems="center"
          justifyContent="center"
        >
          <IconContainer error={error} borderRightWidth={0}>
            <Icon
              name="calendar"
              color={
                tokens.color[
                  tamaguiInputProps?.disabled ? 'Gray300' : 'Secondary800'
                ].val
              }
            />
          </IconContainer>
        </Stack>
      </XStack>

      <DatePickerNative
        open={open}
        setOpen={setOpen}
        datePickerProps={datePickerProps}
        tamaguiInputProps={tamaguiInputProps}
        onConfirm={(newdate) => {
          setOpen(false);
          const chosenDate = newdate.toLocaleDateString('en-GB');
          tamaguiInputProps?.onChangeText?.(chosenDate);

          setDateInput(getDateFromString(chosenDate));

          onFocus?.();
        }}
      />
    </>
  );
};
