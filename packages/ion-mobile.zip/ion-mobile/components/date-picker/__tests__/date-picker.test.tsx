import { fireEvent, render, screen, waitFor } from '@src/jest/testing-library';
import { UK_DATE_SHORT_FORMAT } from '@constants/string-formats';
import { parse } from 'date-fns';
import { useState } from 'react';

import { DatePicker, DatePickerProps } from '../date-picker';

const testProps = { tamaguiInputProps: { testID: 'date-picker' } };

const mockPressed = jest.fn();

const mockFocus = jest.fn();

jest.mock('@hooks/use-a11y-focus', () => ({
  useA11yFocus: () => ({ focus: mockFocus }),
}));

describe('Testing a DatePicker', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should have icon displayed on button, when hasIcon is true', () => {
    render(<DatePicker {...testProps} />);

    const icon = screen.getByTestId('test:id/icon-calendar', {
      includeHiddenElements: true,
    });

    expect(icon).toBeDefined();
  });

  it('should have error styling applied, when error is true', () => {
    render(<DatePicker {...testProps} error />);

    const datePickerContainer = screen.getByTestId('date-picker-container');

    expect(datePickerContainer).toHaveStyle({
      borderLeftColor: '#BD2624',
      borderBottomWidth: 2,
    });
  });

  it('should call focus with error message on submit, when error is true', () => {
    render(<DatePicker {...testProps} error errorText="testError" />);

    const selector = screen.getByTestId('date-picker');

    fireEvent(selector, 'onConfirm', new Date());

    expect(mockFocus).toHaveBeenCalledWith('testError');
  });

  it('should not display custom error message when error is false', () => {
    render(
      <DatePicker {...testProps} error={false} errorText="Some error message" />
    );

    expect(
      screen.queryByRole('text', { name: 'Some error message' })
    ).toBeFalsy();
  });

  it('should display custom error message when error is true', () => {
    render(<DatePicker {...testProps} error errorText="Some error message" />);

    expect(
      screen.getByRole('text', { name: 'Some error message' })
    ).toBeOnTheScreen();
  });

  it('should call expand action when pressed', () => {
    render(<DatePicker {...testProps} onExpand={mockPressed} />);

    const pressable = screen.getByRole('button');

    fireEvent.press(pressable);

    expect(mockPressed).toHaveBeenCalled();
  });

  it('should have placeholder accessibilityLabel if text has not been edited', () => {
    render(<DatePicker {...testProps} />);

    expect(screen.getByLabelText('Date format DD MM YYYY')).toBeOnTheScreen();
  });

  it('should have the date as the accessibilityLabel if date has been set', () => {
    render(<DatePicker tamaguiInputProps={{ value: '24/01/10' }} />);

    expect(screen.getByLabelText('24/01/10')).toBeOnTheScreen();
  });

  it('should use accessibilityLabel provided as placeholder, if given this as prop', () => {
    render(
      <DatePicker tamaguiInputProps={{ accessibilityLabel: 'CoolLabel' }} />
    );

    expect(screen.getByLabelText('CoolLabel')).toBeOnTheScreen();
  });

  it('should have combined text and accessibility label, if text has been edited and given accesibilty label prop', () => {
    render(
      <DatePicker
        tamaguiInputProps={{
          value: '24/01/10',
          accessibilityLabel: 'CoolLabel',
        }}
      />
    );

    expect(screen.getByLabelText('CoolLabel 24/01/10')).toBeOnTheScreen();
  });

  it('should format date when date submitted', () => {
    render(<DateWithState />);

    const selector = screen.getByTestId('date-picker');

    const validDate = parse('24/01/99', UK_DATE_SHORT_FORMAT, new Date());

    fireEvent(selector, 'onConfirm', validDate);

    expect(screen.getByTestId('date-picker-container')).toHaveTextContent(
      '24/01/1999'
    );
  });

  it('should be disabled when disabled prop is passed in as true', async () => {
    render(
      <DatePicker
        disabled
        tamaguiInputProps={{
          value: '24/01/10',
          accessibilityLabel: 'CoolLabel',
        }}
      />
    );

    await waitFor(() => {
      expect(screen.getByLabelText('CoolLabel 24/01/10')).toBeDisabled();
    });
  });

  it('should be active when disabled prop is passed in as false', async () => {
    render(
      <DatePicker
        disabled={false}
        tamaguiInputProps={{
          value: '24/01/10',
          accessibilityLabel: 'CoolLabel',
        }}
      />
    );

    await waitFor(() => {
      expect(screen.getByLabelText('CoolLabel 24/01/10')).toBeEnabled();
    });
  });
});

const DateWithState = (props: DatePickerProps) => {
  const [date, setDate] = useState('');
  return (
    <DatePicker
      {...props}
      tamaguiInputProps={{
        ...testProps.tamaguiInputProps,
        value: date,
        onChangeText: setDate,
        ...props.tamaguiInputProps,
      }}
    />
  );
};
