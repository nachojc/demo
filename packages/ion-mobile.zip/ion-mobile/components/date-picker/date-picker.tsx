import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useAccessibility } from '@src/common/providers/accessibility';
import { tokens } from '@src/theme/tokens';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Pressable } from 'react-native';
import { DatePickerProps as RNDPProps } from 'react-native-date-picker';
import { getVariableValue, InputProps, Text, XStack } from 'tamagui';

import { ErrorMessage } from '../error-message';
import { Icon } from '../icon';
import { IconContainer } from '../text-input';
import { DateInputManual } from './date-input-manual';
import { DatePickerNative } from './date-picker-native';

export type DatePickerProps = {
  datePickerProps?: RNDPProps;
  tamaguiInputProps?: InputProps;
  onExpand?: () => void;
  error?: boolean;
  errorText?: string;
  required?: boolean;
  disabled?: boolean;
};

export const DatePicker = ({
  datePickerProps,
  tamaguiInputProps,
  onExpand,
  error,
  errorText,
  required = false,
  disabled = false,
}: DatePickerProps) => {
  const { isScreenReaderEnabled } = useAccessibility();

  const [open, setOpen] = useState(false);
  const { t } = useTranslation();
  const { elementRef, focus } = useA11yFocus();

  const iconColor = tamaguiInputProps?.disabled ? 'Gray300' : 'Secondary800';

  const accessibilityHint = `${tamaguiInputProps?.accessibilityHint ?? ''} ${t(
    'common.forms.datepickerA11yHint'
  )}`;

  const requiredAccessibilityHint = required
    ? `Required ${accessibilityHint}`
    : accessibilityHint;

  const isPlaceholder = !tamaguiInputProps?.value;

  let accessibilityLabel = `${tamaguiInputProps?.accessibilityLabel ?? ''} ${t(
    'common.forms.datepickerA11y',
    {
      value: tamaguiInputProps?.value,
    }
  )}`;

  if (isPlaceholder) {
    accessibilityLabel =
      tamaguiInputProps?.accessibilityLabel ??
      t('common.forms.datepickerPlaceholderA11y');
  }

  return (
    <>
      {isScreenReaderEnabled ? (
        <DateInputManual
          required={required}
          tamaguiInputProps={tamaguiInputProps}
          datePickerProps={datePickerProps}
          onFocus={() => focus(error ? errorText : undefined)}
          onExpand={onExpand}
        />
      ) : (
        <>
          <Pressable
            accessibilityRole="button"
            disabled={disabled}
            onPress={() => {
              onExpand?.();
              setOpen(true);
            }}
            ref={elementRef}
            accessibilityLabel={accessibilityLabel}
            accessibilityHint={requiredAccessibilityHint}
            testID={
              tamaguiInputProps?.testID && `${tamaguiInputProps?.testID}_btn`
            }
          >
            <XStack
              pointerEvents="none"
              borderColor={error ? '$Error' : '$Gray200'}
              borderWidth={error ? '$xs' : '$xxs'}
              bg="white"
              alignItems="center"
              overflow="hidden"
              borderRadius="$2"
              testID={
                tamaguiInputProps?.testID &&
                `${tamaguiInputProps?.testID}-container`
              }
            >
              <IconContainer
                error={error}
                flex={0}
                p="$md"
                my="$sm"
                ml="$0"
                mr="$md"
                accessible={false}
              >
                <Icon
                  name="calendar"
                  color={getVariableValue(tokens.color[iconColor])}
                />
              </IconContainer>

              <Text
                fos="$body"
                ff="$body"
                fontWeight="$regular"
                ml="$md"
                color={getVariableValue(tokens.color.Gray800)}
              >
                {isPlaceholder
                  ? tamaguiInputProps?.placeholder ??
                    t('common.forms.datepickerPlaceholder')
                  : tamaguiInputProps?.value}
              </Text>
            </XStack>
          </Pressable>
          <DatePickerNative
            open={open}
            setOpen={setOpen}
            datePickerProps={datePickerProps}
            tamaguiInputProps={tamaguiInputProps}
            onConfirm={(newdate) => {
              setOpen(false);
              tamaguiInputProps?.onChangeText?.(
                newdate.toLocaleDateString('en-GB')
              );
              focus(error ? errorText : undefined);
            }}
          />
        </>
      )}

      {error ? <ErrorMessage error={errorText} /> : null}
    </>
  );
};
