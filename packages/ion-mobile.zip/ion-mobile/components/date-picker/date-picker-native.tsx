import { Platform } from 'react-native';
import RNDatePicker, {
  DatePickerProps as RNDPProps,
} from 'react-native-date-picker';
import { InputProps } from 'tamagui';

export type DatePickerNativeProps = {
  datePickerProps?: Partial<RNDPProps>;
  tamaguiInputProps?: InputProps;
  onConfirm: (value: Date) => void;
  open: boolean;
  setOpen: (open: boolean) => void;
};

export const DatePickerNative = ({
  datePickerProps,
  tamaguiInputProps,
  onConfirm,
  open,
  setOpen,
}: DatePickerNativeProps) => (
  <RNDatePicker
    mode="date"
    locale="en-GB"
    modal
    theme="light"
    title={Platform.OS === 'ios' ? 'Select date' : null}
    open={open}
    onConfirm={onConfirm}
    onCancel={() => setOpen(false)}
    testID={tamaguiInputProps?.testID}
    {...datePickerProps}
    date={datePickerProps?.date ?? new Date()}
  />
);
