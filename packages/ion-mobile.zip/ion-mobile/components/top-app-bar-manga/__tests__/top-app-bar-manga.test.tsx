import {
  createNavigationMock,
  fireEvent,
  render,
  screen,
} from '@src/jest/testing-library';
import { ParamListBase } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';

import { Icon } from '../../icon/icon';
import { TopAppBarManga } from '../top-app-bar-manga';

const insetTop = 2;

const TOP_APP_BAR = 'test:id/top-app-bar';

jest.mock('react-native-safe-area-context', () => ({
  useSafeAreaInsets: () => ({ top: insetTop }),
}));

const navMock =
  createNavigationMock<
    NativeStackNavigationProp<ParamListBase, string, undefined>
  >();

beforeEach(() => {
  jest.clearAllMocks();
  navMock.canGoBack = () => true;
});

describe('TopAppBarManga', () => {
  it('should use correct styles with default theme', () => {
    render(<TopAppBarManga />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#FFD900',
      borderBottomWidth: 0,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with white theme', () => {
    render(<TopAppBarManga theme="white" />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#FFFFFF',
      borderBottomWidth: 1,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with pensions theme', () => {
    render(<TopAppBarManga theme="pensions" isDarkTheme />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#122D44',
      borderBottomWidth: 0,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with plum color theme', () => {
    render(<TopAppBarManga theme="plum" isDarkTheme />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#4E1758',
      borderBottomWidth: 0,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with tertiary theme', () => {
    render(<TopAppBarManga theme="tertiary" isDarkTheme />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#00459F',
      borderBottomWidth: 0,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with mydrive theme', () => {
    render(
      <TopAppBarManga
        theme="mydrive"
        back={{ title: 'homepage' }}
        isDarkTheme
      />
    );

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#005A6C',
      borderBottomWidth: 0,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with motor theme', () => {
    render(<TopAppBarManga theme="motor" isDarkTheme />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#00475A',
      borderBottomWidth: 0,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with travel theme', () => {
    render(<TopAppBarManga theme="travel" isDarkTheme />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#00475A',
      borderBottomWidth: 0,
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with webView configuration', () => {
    render(<TopAppBarManga webView />);

    const topAppBarManga = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBarManga).toHaveStyle({
      backgroundColor: '#FFFFFF',
    });
  });

  it('should render with title passed in options prop when it exists as default', () => {
    render(
      <TopAppBarManga
        options={{ title: 'Test Title' }}
        textLabel="Label Title"
        route={{ key: 'key', name: 'Route Title' }}
      />
    );

    const title = screen.getByText('Test Title');

    expect(title).toBeDefined();
  });

  it('should render with title passed in textLabel prop when no options prop is passed', () => {
    render(
      <TopAppBarManga
        textLabel="Label Title"
        route={{ key: 'key', name: 'Route Title' }}
      />
    );

    const title = screen.getByText('Label Title');

    expect(title).toBeDefined();
  });

  it('should render with title passed in route when no options or textLabel props are passed', () => {
    render(<TopAppBarManga route={{ key: 'key', name: 'Route Title' }} />);

    const title = screen.getByText('Route Title');

    expect(title).toBeDefined();
  });

  it('should set borderBottomWidth to 0 when a dark theme is passed', () => {
    render(<TopAppBarManga />);

    const topAppBar = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBar).toHaveStyle({
      borderBottomWidth: 0,
    });
  });

  it('should render an actionIcon when passed', () => {
    render(<TopAppBarManga actionIcons={<Icon name="close" />} />);

    const icon = screen.getByTestId('test:id/icon-close', {
      includeHiddenElements: true,
    });

    expect(icon).toBeDefined();
  });

  it('should render an array of actionIcons when passed', () => {
    render(
      <TopAppBarManga
        actionIcons={[
          <Icon key="1" name="close" />,
          <Icon key="2" name="alert-circle" />,
        ]}
      />
    );

    const icon1 = screen.getByTestId('test:id/icon-close', {
      includeHiddenElements: true,
    });
    const icon2 = screen.getByTestId('test:id/icon-alert-circle', {
      includeHiddenElements: true,
    });

    expect(icon1).toBeDefined();
    expect(icon2).toBeDefined();
  });

  it('should render a back button with title when passed', () => {
    render(
      <TopAppBarManga navigation={navMock} back={{ title: 'Previous' }} />
    );

    const backButton = screen.getByLabelText('Back');

    expect(backButton).toBeDefined();
  });

  it('should run the goBack navigation function when back button is pressed', () => {
    render(
      <TopAppBarManga back={{ title: 'Previous' }} navigation={navMock} />
    );

    const backButton = screen.getByLabelText('Back');
    fireEvent.press(backButton);

    expect(navMock.goBack).toHaveBeenCalled();
  });

  it('should render image instead of text when image is passed', () => {
    render(
      <TopAppBarManga
        textLabel="Test Title"
        image={require('assets/aviva-inline/aviva-inline.png')}
      />
    );

    const title = screen.queryByLabelText('Test Title');
    const image = screen.getByTestId('image');

    expect(title).not.toBeOnTheScreen();
    expect(image).toBeOnTheScreen();
  });

  it('should render with large title passed in options prop when it exists as default', () => {
    render(
      <TopAppBarManga
        options={{
          title:
            'Large title for testing purpose Large title for testing purpose Large title for testing purpose',
        }}
        textLabel="Label Title"
        route={{ key: 'key', name: 'Route Title' }}
      />
    );

    const title = screen.getByText(
      'Large title for testing purpose Large title for testing purpose Large title for testing purpose'
    );

    expect(title).toBeDefined();
  });

  it('should not render back button when canGoBack is false', () => {
    navMock.canGoBack = () => false;
    render(
      <TopAppBarManga navigation={navMock} back={{ title: 'Previous' }} />
    );
    const backButton = screen.queryAllByLabelText('Back');
    expect(backButton).toHaveLength(0);
  });
});

describe('Accessibility', () => {
  it('should have an accessibilityId on the back button', () => {
    render(
      <TopAppBarManga navigation={navMock} back={{ title: 'Previous' }} />
    );
    const backButton = screen.getAllByLabelText('Back');
    expect(backButton.length).toBe(1);
  });
});
