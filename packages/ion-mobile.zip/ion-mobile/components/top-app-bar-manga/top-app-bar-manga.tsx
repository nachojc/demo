import { isDemoBuild, isDevMode } from '@config';
import { useAnalytics } from '@hooks/use-analytics';
import { BottomTabHeaderProps } from '@react-navigation/bottom-tabs';
import { NativeStackHeaderProps } from '@react-navigation/native-stack';
import { getTestId } from '@src/utils/get-test-id';
import { ReactNode } from 'react';
import { Source } from 'react-native-fast-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getTokens, getVariableValue, Stack, XStack, YStack } from 'tamagui';

import { CloseButton } from '../close-button';
import { FocusAwareStatusBar } from '../focus-aware-status-bar';
import { Image } from '../image';
import { Text } from '../text';

type Theme =
  | 'default'
  | 'white'
  | 'whiteNoBorder'
  | 'pensions'
  | 'plum'
  | 'home'
  | 'contribution'
  | 'health'
  | 'motor'
  | 'travel'
  | 'groupaccounts'
  | 'tertiary'
  | 'mydrive'
  | 'teal';

export type TopAppBarMangaProps = {
  webView?: boolean;
  isFullScreenModal?: boolean;
  textLabel?: string;
  actionIcons?: ReactNode[] | ReactNode;
  image?: number | Source;
  isDarkTheme?: boolean;
  theme?: Theme;
  showDevMode?: boolean;
  backAnalyticsTag?: string;
} & (
  | Partial<NativeStackHeaderProps>
  | Partial<
      BottomTabHeaderProps &
        Omit<NativeStackHeaderProps, keyof BottomTabHeaderProps>
    >
);

const getBackgroundColor = (theme: Theme, isWebView: boolean) => {
  if (isWebView) {
    return getVariableValue(getTokens().color.$White);
  }
  switch (theme) {
    case 'white':
    case 'whiteNoBorder':
      return getVariableValue(getTokens().color.$White);
    case 'pensions':
      return getVariableValue(getTokens().color.$Secondary800);
    case 'groupaccounts':
      return getVariableValue(getTokens().color.$Wealth600);
    case 'plum':
      return getVariableValue(getTokens().color.$PlumMain);
    case 'tertiary':
      return getVariableValue(getTokens().color.$Tertiary900);
    case 'motor':
    case 'travel':
    case 'health':
    case 'home':
      return getVariableValue(getTokens().color.$Teal800);
    case 'mydrive':
    case 'contribution':
    case 'teal':
      return getVariableValue(getTokens().color.$Teal700);
    default:
      return getVariableValue(getTokens().color.$Primary500);
  }
};

export const TopAppBarManga = ({
  webView = false,
  isFullScreenModal = false,
  textLabel,
  actionIcons,
  back,
  navigation,
  route,
  image,
  theme = 'default',
  isDarkTheme = false,
  showDevMode = false,
  backAnalyticsTag,
  ...rest
}: TopAppBarMangaProps) => {
  const tokens = getTokens();
  const insets = useSafeAreaInsets();

  const title = rest?.options?.title ?? textLabel ?? route?.name ?? '';

  const { trackUserEvent } = useAnalytics();
  const handleBackButtonPress = () => {
    if (backAnalyticsTag) {
      trackUserEvent(backAnalyticsTag);
    }
    if (back?.title === 'homepage') {
      return navigation?.navigate('Bottom tabs', {
        screen: 'Summary Tab',
      });
    }
    return navigation?.goBack();
  };

  return (
    <>
      <FocusAwareStatusBar
        style={isDarkTheme ? 'light' : 'dark'}
        backgroundColor={getBackgroundColor(theme, webView)}
      />
      <XStack
        paddingHorizontal={'$xl'}
        paddingTop={webView ? insets.top : insets.top + 8}
        backgroundColor={getBackgroundColor(theme, webView)}
        paddingBottom={'$md'}
        borderBottomWidth={theme === 'white' ? 1 : 0}
        borderBottomColor="$Gray200"
        testID={getTestId('top-app-bar')}
      >
        <XStack flexGrow={1} flexBasis={1} justifyContent="flex-start">
          {back && !isFullScreenModal && navigation?.canGoBack() && (
            <CloseButton
              onPress={handleBackButtonPress}
              accessibilityLabel="Back"
              accessibilityHint={
                back?.title ? `Go back to ${back.title} screen` : 'Go back'
              }
              testID={getTestId('back-button')}
              iconProps={{
                strokeWidth: 2,
                name: webView ? 'close' : 'chevron-left',
                color:
                  !isDarkTheme || webView
                    ? getVariableValue(tokens.color.Secondary800)
                    : getVariableValue(tokens.color.White),
              }}
            />
          )}
        </XStack>
        <XStack flexGrow={2} justifyContent="center">
          {image ? (
            <Image
              accessibilityIgnoresInvertColors
              testID="image"
              source={image}
              style={{
                width: 100,
                height: 30,
              }}
              resizeMode="contain"
            />
          ) : (
            <Text
              tamaguiTextProps={{
                numberOfLines: 1,
                accessibilityRole: 'header',
                marginHorizontal: '$xxl',
              }}
              fontVariant={`heading5-semibold-${
                isDarkTheme ? 'White' : 'Secondary800'
              }`}
              testID={getTestId('heading-title')}
            >
              {title}
            </Text>
          )}
        </XStack>
        <XStack flexGrow={1} flexBasis={1} justifyContent="flex-end">
          {isDevMode() && !isDemoBuild() && showDevMode && (
            <YStack
              accessibilityLabel="dev mode link"
              onPress={() => navigation?.navigate('Dev Mode')}
            >
              <Text
                fontVariant={'small-semibold-iOSNativeBlue'}
                tamaguiTextProps={{
                  importantForAccessibility: 'no',
                }}
              >
                Dev Mode
              </Text>
            </YStack>
          )}
          {actionIcons && Array.isArray(actionIcons)
            ? actionIcons.map((icon, index) => (
                <Stack key={`${textLabel}-${index}`} marginHorizontal={'$sm'}>
                  {icon}
                </Stack>
              ))
            : actionIcons}
        </XStack>
      </XStack>
    </>
  );
};
