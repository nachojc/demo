import { fireEvent, render, screen } from '@src/jest/testing-library';

import { CardActionButton } from '../card-action-button';

const mockOnPress = jest.fn();
const renderButton = () =>
  render(<CardActionButton icon="edit" onPress={mockOnPress} text="Title" />);

describe('CardActionButton', () => {
  afterEach(() => {
    jest.resetAllMocks();
  });

  it('should be accessible', () => {
    renderButton();

    const button = screen.getByTestId('test:id/card-action-button');
    expect(button).toHaveProp('accessible', true);
    expect(button).toHaveProp('accessibilityLabel', 'Title');
    expect(button).toHaveProp('accessibilityRole', 'button');
  });

  it('should be pressable', () => {
    renderButton();

    fireEvent.press(screen.getByTestId('test:id/card-action-button'));
    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it('Icon component should have width and height', () => {
    renderButton();

    const icon = screen.getByTestId('test:id/icon-edit', {
      includeHiddenElements: true,
    });
    expect(icon).toBeDefined();

    expect(icon).toHaveProp('width');
    expect(icon).toHaveProp('height');
  });

  it('passes iconWidth and iconHeight to the Icon component', () => {
    render(
      <CardActionButton
        icon="edit"
        onPress={mockOnPress}
        text="Title"
        iconWidth={20}
        iconHeight={20}
      />
    );

    const icon = screen.getByTestId('test:id/icon-edit', {
      includeHiddenElements: true,
    });
    expect(icon).toBeDefined();

    expect(icon.props.width).toBe(20);
    expect(icon.props.height).toBe(20);
  });
});
