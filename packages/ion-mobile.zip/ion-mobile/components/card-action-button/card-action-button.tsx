import { TextProps, XStack, XStackProps } from 'tamagui';

import { Icon, IconName } from '../icon';
import { Text } from '../text';

type CardActionButtonProps = Omit<XStackProps, 'children'> & {
  icon: IconName;
  text: string;
  textProps?: TextProps;
  onPress: () => unknown;
  iconWidth?: number;
  iconHeight?: number;
};

export const CardActionButton = ({
  icon,
  onPress,
  text,
  textProps,
  iconWidth,
  iconHeight,
  ...props
}: CardActionButtonProps) => (
  <XStack
    accessible
    accessibilityLabel={text}
    accessibilityRole="button"
    alignItems="center"
    space="$md"
    onPress={onPress}
    testID="test:id/card-action-button"
    {...props}
  >
    <Icon name={icon} width={iconWidth ?? 16} height={iconHeight ?? 16} />
    <Text fontVariant="body-semibold-Tertiary800" tamaguiTextProps={textProps}>
      {text}
    </Text>
  </XStack>
);
