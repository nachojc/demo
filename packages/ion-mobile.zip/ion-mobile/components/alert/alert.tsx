import { useAnalytics } from '@hooks/use-analytics';
import { toKebabCaseWithoutSpecialCharecter } from '@src/utils';
import { useEffect } from 'react';
import { YStack } from 'tamagui';

import { Button, ButtonProps } from '../button';
import { Dialog } from '../dialogs';

type VoidFunction = { preventDefault: () => void };
type OnPressFunction = (props: Partial<VoidFunction>) => void;
export type AlertProps = {
  title?: string;
  message?: string;
  onClose?: () => void;
  buttons?: (ButtonProps & {
    text: string;
    onPress?: OnPressFunction;
  })[];
  open?: boolean;
  sendAnalytics?: boolean;
};

export const Alert = ({
  title,
  message,
  buttons,
  open = false,
  sendAnalytics = false,
  onClose,
}: AlertProps) => {
  const { trackStateEvent } = useAnalytics();
  const handleOnPressButton = (onPressFn?: OnPressFunction) => {
    let cancelDefault = false;
    const preventDefault = () => {
      cancelDefault = true;
    };
    onPressFn?.({ preventDefault });
    if (!cancelDefault) {
      onClose?.();
    }
  };

  useEffect(() => {
    if (!open || !title) {
      return;
    }

    sendAnalytics &&
      trackStateEvent(`ukmyaviva|${toKebabCaseWithoutSpecialCharecter(title)}`);
  }, [open, title]);

  return (
    <Dialog open={open} title={title} copy={message}>
      <YStack space="$md" marginTop="$xl">
        {buttons?.length ? (
          buttons.map(({ text, onPress, ...restProps }) => (
            <Button
              key={text}
              onPress={() => handleOnPressButton(onPress)}
              {...restProps}
            >
              {text}
            </Button>
          ))
        ) : (
          <Button onPress={onClose}>Ok</Button>
        )}
      </YStack>
    </Dialog>
  );
};
