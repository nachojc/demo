import {
  fireEvent,
  mockTrackStateEvent,
  render,
  screen,
} from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { Alert } from '../index';

const dialogTitlesWithTags = [
  {
    title: `Sorry Batman, you've got no internet in the cave`,
    tag: `ukmyaviva|sorry-batman-youve-got-no-internet-in-the-cave`,
  },
  {
    title: `There are not 9 special characters here %$!@^&*?<`,
    tag: `ukmyaviva|there-are-not-9-special-characters-here`,
  },
] as const;

describe('Button', () => {
  it('should render alert with default configuration', () => {
    render(<Alert open />);
    expect(screen.getByText('Ok')).toBeDefined();
  });

  it.each(dialogTitlesWithTags)(
    'should send page tag when alert is open',
    ({ title, tag }) => {
      render(<Alert title={title} open sendAnalytics />);
      expect(mockTrackStateEvent).toHaveBeenCalledWith(tag);
    }
  );

  it('should call onPress when the alert is pressed', () => {
    const mockOnPress = jest.fn();

    render(<Alert open onClose={mockOnPress} />);

    const alert = screen.getByRole('button');
    fireEvent.press(alert);

    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });

  it('should display the buttons defined and onPress button onPress event and onClose event need to be trigger', async () => {
    const mockOnPress = jest.fn();
    const mockOnClose = jest.fn();
    render(
      <Alert
        open
        title="Title Demo"
        message="Hello Demo"
        buttons={[
          { text: 'demo', onPress: mockOnPress, testID: getTestId('demo') },
        ]}
        onClose={mockOnClose}
      />
    );

    const alert = screen.getByTestId(getTestId('demo'));
    fireEvent.press(alert);

    expect(await screen.findByText('Title Demo')).toBeOnTheScreen();
    expect(await screen.findByText('Hello Demo')).toBeOnTheScreen();
    expect(mockOnPress).toHaveBeenCalledTimes(1);
    expect(mockOnClose).toHaveBeenCalledTimes(1);
  });

  it('should display the buttons defined and prevent the close event if preventDefault execute in onPress', async () => {
    const mockOnPress = jest.fn((e) => {
      e.preventDefault();
    });
    const mockOnClose = jest.fn();
    render(
      <Alert
        open
        title="Title Demo"
        message="Hello Demo"
        buttons={[
          { text: 'demo', onPress: mockOnPress, testID: getTestId('demo') },
        ]}
        onClose={mockOnClose}
      />
    );

    const alert = screen.getByTestId(getTestId('demo'));
    fireEvent.press(alert);

    expect(await screen.findByText('Title Demo')).toBeOnTheScreen();
    expect(await screen.findByText('Hello Demo')).toBeOnTheScreen();
    expect(mockOnPress).toHaveBeenCalledTimes(1);
    expect(mockOnClose).not.toHaveBeenCalled();
  });
});
