import { getTestId } from '@src/utils/get-test-id';
import { KeyboardAvoidingView, Platform, ViewProps } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

type FocusKeyboardViewProps = ViewProps & {
  behavior?: 'padding' | 'height' | 'position' | undefined;
  keyboardVerticalOffset?: number;
};

export const HEADER_HEIGHT = 65;

export const FocusKeyboardAvoidingView = ({
  behavior = Platform.OS === 'ios' ? 'padding' : 'height',
  keyboardVerticalOffset = 0,
  ...props
}: FocusKeyboardViewProps) => {
  const { bottom } = useSafeAreaInsets();

  const kvOffset = Platform.OS === 'ios' ? HEADER_HEIGHT + bottom : 0;

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={behavior}
      keyboardVerticalOffset={kvOffset + keyboardVerticalOffset}
      testID={getTestId('focus-keyboard-view')}
      {...props}
    />
  );
};
