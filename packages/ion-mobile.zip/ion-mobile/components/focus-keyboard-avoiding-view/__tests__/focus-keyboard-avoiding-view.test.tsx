import { fireEvent, render, screen } from '@src/jest/testing-library';
import { TextInput, View } from 'react-native';

import { FocusKeyboardAvoidingView } from '../focus-keyboard-avoiding-view';

type Behavior = 'height' | 'position' | 'padding' | undefined;

const headerHeight = 65;
let behavior: Behavior = 'padding';
const renderComponent = () => {
  render(
    <FocusKeyboardAvoidingView
      behavior={behavior}
      keyboardVerticalOffset={headerHeight} // this offsets the height of the navigation header
      testID="keyboard-avoiding-view"
    >
      <TextInput placeholder="username" />
    </FocusKeyboardAvoidingView>
  );
};

describe('FocusKeyboardView', () => {
  it('should have "paddingBottom" in style if behavior is "padding"', () => {
    renderComponent();
    const inputEl = screen.getByPlaceholderText('username');
    fireEvent(inputEl, 'focus');

    const viewEl = screen.getByTestId('keyboard-avoiding-view');
    expect(viewEl).toHaveStyle({
      paddingBottom: 0,
    });
  });

  it('should have no style if behavior is "height"', () => {
    behavior = 'height';
    renderComponent();
    const inputEl = screen.getByPlaceholderText('username');
    fireEvent(inputEl, 'focus');

    const viewEl = screen.getByTestId('keyboard-avoiding-view');
    expect(viewEl).toHaveStyle({});
  });

  it('should have "bottom" in style if behavior is "position"', () => {
    behavior = 'position';
    renderComponent();
    const inputEl = screen.getByPlaceholderText('username');
    fireEvent(inputEl, 'focus');

    const [, viewEl] = screen.UNSAFE_getAllByType(View);
    expect(viewEl).toHaveStyle({
      bottom: 0,
    });
  });
});
