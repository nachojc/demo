import { getTestId } from '@src/utils/get-test-id';
import { Fragment } from 'react';
import { ListItemProps, Stack, TextProps, YStack, YStackProps } from 'tamagui';

import { FontVariant, Text } from '../text';
import { List, ListItem } from './list';

/**
 * @description
 * This component is intended to be used for small section lists
 */

export type SectionListItem = { title: string; data: ListItem[] };

type SectionListProps = {
  items: SectionListItem[];
  titleProps?: TextProps;
  listProps?: YStackProps;
  listItemProps?: ListItemProps;
  listItemTitleProps?: TextProps;
  listTitleFontVariant?: FontVariant;
  itemSeparator?: JSX.Element;
};

export const SectionList = ({
  items,
  listProps,
  titleProps,
  listItemProps,
  listItemTitleProps,
  listTitleFontVariant = 'body-semibold-Secondary800',
  itemSeparator = (
    <Stack
      borderBottomWidth={'$xxs'}
      borderBottomColor={'$Gray200'}
      marginLeft={'$xl'}
    />
  ),
}: SectionListProps) => {
  return (
    <YStack testID={getTestId('contact-us-list')}>
      {items.map(({ title, data }) => (
        <Fragment key={title}>
          <Text
            fontVariant={'heading5-semibold-Secondary800'}
            tamaguiTextProps={{
              marginLeft: '$xl',
              marginBottom: '$xl',
              marginTop: '$xl',
              ...titleProps,
            }}
          >
            {title}
          </Text>
          <List
            items={data}
            listItemProps={listItemProps}
            listItemTitleProps={listItemTitleProps}
            listTitleFontVariant={listTitleFontVariant}
            itemSeparator={itemSeparator}
            listProps={{
              borderTopWidth: '$xxs',
              borderTopColor: '$Gray200',
              borderBottomWidth: '$xxs',
              borderBottomColor: '$Gray200',
              ...listProps,
            }}
          />
        </Fragment>
      ))}
    </YStack>
  );
};
