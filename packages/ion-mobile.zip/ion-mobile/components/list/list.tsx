import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import {
  getTokens,
  ListItem,
  ListItemProps,
  Stack,
  TextProps,
  YStack,
  YStackProps,
} from 'tamagui';

import { Icon } from '../icon';
import { FontVariant, Text } from '../text';

/**
 * @description
 * This component is intended to be used for small lists
 */

export type ListItem = {
  accessibilityHint?: string;
  accessibilityLabel?: string;
  title: string;
  subTitle?: string;
  onPress?: () => void;
};

export type ListProps = {
  items: ListItem[];
  listProps?: YStackProps;
  listItemProps?: ListItemProps;
  listItemTitleProps?: TextProps;
  listItemSubTitleProps?: TextProps;
  listTitleFontVariant?: FontVariant;
  listSubTitleFontVariant?: FontVariant;
  itemSeparator?: JSX.Element;
};

export const List = ({
  items,
  listProps,
  listItemProps,
  listItemTitleProps,
  listTitleFontVariant = 'body-semibold-Secondary800',
  listItemSubTitleProps,
  listSubTitleFontVariant = 'small-regular-Gray400',
  itemSeparator = (
    <Stack
      testID="item-separator"
      borderBottomWidth={'$xxs'}
      borderBottomColor={'$Gray300'}
      marginLeft={'$xl'}
    />
  ),
}: ListProps) => {
  const tokens = getTokens();
  return (
    <YStack {...listProps}>
      {items.map(
        (
          {
            title,
            subTitle,
            onPress,
            accessibilityLabel,
            accessibilityHint = '',
          },
          index
        ) => (
          <Pressable
            testID={getTestId(`list-item-${title}-${index}`)}
            key={`${title}-${index}`}
            accessibilityLabel={accessibilityLabel || title}
            accessibilityHint={accessibilityHint}
            accessibilityRole="link"
            onPress={onPress}
          >
            <ListItem
              paddingVertical={'$lg'}
              paddingHorizontal={'$xl'}
              testID={getTestId(title)}
              title={
                <Text
                  fontVariant={listTitleFontVariant}
                  tamaguiTextProps={listItemTitleProps}
                >
                  {title}
                </Text>
              }
              subTitle={
                subTitle && (
                  <Text
                    fontVariant={listSubTitleFontVariant}
                    tamaguiTextProps={listItemSubTitleProps}
                  >
                    {subTitle}
                  </Text>
                )
              }
              iconAfter={
                <Icon name="chevron-right" color={tokens.color.Gray400.val} />
              }
              {...listItemProps}
            />
            {index !== items.length - 1 && itemSeparator}
          </Pressable>
        )
      )}
    </YStack>
  );
};
