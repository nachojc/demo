import { fireEvent, render, screen } from '@src/jest/testing-library';

import {
  ClipboardableList,
  ClipboardableListItem,
  ClipboardableListRow,
} from '../clipboardable-list';

const clipboardableListItems: ClipboardableListRow[] = [
  {
    header: 'Account number',
    detail: '34821992',
    copy: true,
  },
  {
    header: 'Sort code',
    detail: '08-21-56',
    copy: true,
  },
];

const mockOnCopyPressed = jest.fn();

const ClipboardableListWithMultipleItems = () => {
  return (
    <ClipboardableList
      items={clipboardableListItems}
      onCopyPressed={mockOnCopyPressed}
    />
  );
};

const ClipboardableListSingleItem = () => {
  return (
    <ClipboardableListItem
      item={clipboardableListItems[0]}
      onCopyPressed={mockOnCopyPressed}
    />
  );
};

describe('Testing ClipboardableList', () => {
  it('renders single item correctly', async () => {
    render(<ClipboardableListSingleItem />);

    expect(await screen.findByText('Account number')).toBeOnTheScreen();
    expect(await screen.findByText('34821992')).toBeOnTheScreen();
    expect(await screen.findByText('Copy')).toBeOnTheScreen();
  });

  it('renders multiple items correctly', async () => {
    render(<ClipboardableListWithMultipleItems />);

    expect(await screen.findByText('Account number')).toBeOnTheScreen();
    expect(await screen.findByText('34821992')).toBeOnTheScreen();

    expect(await screen.findByText('Sort code')).toBeOnTheScreen();
    expect(await screen.findByText('08-21-56')).toBeOnTheScreen();
  });

  it('copy callback passes correct prop', async () => {
    render(<ClipboardableListSingleItem />);

    const copyButton = await screen.findByText('Copy');
    fireEvent.press(copyButton);

    expect(mockOnCopyPressed).toHaveBeenNthCalledWith(1, '34821992');
  });
});
