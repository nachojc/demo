import { fireEvent, render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';
import { Stack } from 'tamagui';

import { List } from '../list';

const MOCK_ITEM = {
  title: 'Item 1',
};
const ANOTHER_MOCK_ITEM = {
  title: 'Item 2',
};

const mockListItems = [MOCK_ITEM, ANOTHER_MOCK_ITEM];

describe('List', () => {
  it('should render with a list of provided items', () => {
    render(<List items={mockListItems} />);

    const item = screen.getByText(MOCK_ITEM.title);
    const anotherItem = screen.getByText(ANOTHER_MOCK_ITEM.title);
    expect(item).toBeOnTheScreen();
    expect(anotherItem).toBeOnTheScreen();
  });
  it('should render with the correct testID', () => {
    render(<List items={mockListItems} />);

    const expectedTestId = getTestId(`list-item-item-1-0`);
    const listItem = screen.getByTestId(expectedTestId);
    expect(listItem).toBeOnTheScreen();
  });
  it('should render with a default item separator if none provided', () => {
    render(<List items={mockListItems} />);

    const separator = screen.getByTestId('item-separator');
    expect(separator).toBeOnTheScreen();
  });

  it('should render with a custom item separator if provided', () => {
    const ItemSeparator = <Stack testID="mock-separator" />;
    render(<List items={mockListItems} itemSeparator={ItemSeparator} />);

    const customSeparator = screen.getByTestId('mock-separator');
    expect(customSeparator).toBeOnTheScreen();
  });

  it('should not render with an item separator if only 1 item in the list', () => {
    render(<List items={[MOCK_ITEM]} />);

    const separator = screen.queryByTestId('item-separator');
    expect(separator).not.toBeOnTheScreen();
  });

  it('should render list items with any provided accessibility props', () => {
    render(
      <List
        items={[
          {
            ...MOCK_ITEM,
            accessibilityHint: 'This is a mock item',
            accessibilityLabel: 'Mock item',
          },
        ]}
      />
    );

    expect([
      screen.getByLabelText('Mock item'),
      screen.getByA11yHint('This is a mock item'),
    ]).toHaveLength(2);
  });

  it('should render with a subtitle if provided', () => {
    render(<List items={[{ ...MOCK_ITEM, subTitle: 'Mock item subtitle' }]} />);

    const subtitle = screen.getByText('Mock item subtitle');
    expect(subtitle).toBeOnTheScreen();
  });

  it('should call onPress function passed to an item when item is pressed', () => {
    const mockOnPress = jest.fn();
    render(<List items={[{ ...MOCK_ITEM, onPress: mockOnPress }]} />);

    const item = screen.getByText(MOCK_ITEM.title);
    fireEvent.press(item);
    expect(mockOnPress).toHaveBeenCalled();
  });
});
