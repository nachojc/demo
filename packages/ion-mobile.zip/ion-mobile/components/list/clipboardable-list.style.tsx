import { Stack, styled, XStack, YStack } from 'tamagui';

const ListItemContainer = styled(YStack, {
  bg: '$White',
  paddingLeft: '$xl',
});

const ContentContainer = styled(XStack, {
  paddingVertical: '$xl',
  paddingRight: '$xl',
});

const TextContainer = styled(YStack, {
  paddingRight: '$xl',
  justifyContent: 'flex-start',
  flex: 1,
});

const ClipboardContainer = styled(XStack, {
  alignItems: 'center',
});

const ClipboardHorizontalSpacer = styled(Stack, {
  width: '$md',
});

const TextVerticalSpacer = styled(Stack, {
  height: '$sm',
});

const Divider = styled(Stack, {
  bg: '$Gray200',
  paddingLeft: '$xl',
  height: 1,
});

export {
  ClipboardContainer,
  ClipboardHorizontalSpacer,
  ContentContainer,
  Divider,
  ListItemContainer,
  TextContainer,
  TextVerticalSpacer,
};
