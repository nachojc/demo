import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import { getVariableValue, YStack } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text';
import {
  ClipboardContainer,
  ClipboardHorizontalSpacer,
  ContentContainer,
  Divider,
  ListItemContainer,
  TextContainer,
  TextVerticalSpacer,
} from './clipboardable-list.style';

export type ClipboardableListRow = {
  header: string;
  detail: string;
  backgroundColour?: string;
  copy?: boolean;
};

export type ClipboardableListProps = {
  items: ClipboardableListRow[];
  onCopyPressed: (textToCopy: string) => void;
  backgroundColor?: string;
  embedded?: boolean;
  lastItem?: boolean;
};

export const ClipboardableList = ({
  items,
  onCopyPressed,
  embedded = false,
  lastItem,
}: ClipboardableListProps) => {
  return (
    <YStack>
      {items.map((item, index) => (
        <ClipboardableListItem
          item={item}
          onCopyPressed={onCopyPressed}
          key={`clipboard-item-${index}`}
          embedded={embedded}
          lastItem={lastItem}
        />
      ))}
    </YStack>
  );
};

export const ClipboardableListItem = ({
  item,
  onCopyPressed,
  embedded,
  lastItem = false,
}: Omit<ClipboardableListProps, 'items'> & {
  item: ClipboardableListProps['items'][0];
}) => (
  <ListItemContainer
    backgroundColor={item.backgroundColour ?? '$White'}
    paddingHorizontal={embedded ? '$0' : '$xl'}
  >
    <ContentContainer>
      <TextContainer>
        <Text fontVariant="body-semibold-Secondary800">{item.header}</Text>
        <TextVerticalSpacer />
        <Text fontVariant="small-regular-Gray800">{item.detail}</Text>
      </TextContainer>

      {item.copy ? (
        <Pressable
          testID={getTestId('clipboard-item-copy')}
          accessibilityRole="button"
          onPress={() => onCopyPressed(item.detail)}
        >
          <YStack justifyContent="center" flex={1}>
            <RightContainerContent />
          </YStack>
        </Pressable>
      ) : null}
    </ContentContainer>
    <Divider marginHorizontal={embedded && lastItem ? '$-xl' : '$0'} />
  </ListItemContainer>
);

const RightContainerContent = () => {
  const imageSize = 24;

  return (
    <ClipboardContainer>
      <Icon
        name="copy"
        width={imageSize}
        height={imageSize}
        color={getVariableValue(tokens.color.Tertiary800)}
      />
      <ClipboardHorizontalSpacer />
      <Text fontVariant="small-semibold-Tertiary800">Copy</Text>
    </ClipboardContainer>
  );
};
