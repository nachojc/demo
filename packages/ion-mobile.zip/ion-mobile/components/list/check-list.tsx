import { AppStackNavigation } from '@src/navigation/app/hooks';
import { tokens } from '@src/theme/tokens';
import { Item } from '@src/validation/schemas/offers';
import { SpaceTokens, XStack, YStack } from 'tamagui';

import { Icon, IconName } from '../icon';
import { FontVariant, Text } from '../text';

type CheckListProps = {
  items: string[];
  icon: IconName;
  width?: number;
  height?: number;
  typography: FontVariant;
  space: SpaceTokens;
  itemsSpace?: SpaceTokens;
};

type CheckListItemProps = {
  item: Item;
  icon: IconName;
  width?: number;
  height?: number;
  typography: FontVariant;
  space: SpaceTokens;
  itemsSpace?: SpaceTokens;
  navigation?: AppStackNavigation;
};

export const ChecksList = ({ items, ...props }: CheckListProps) => {
  return (
    <YStack>
      {items.map((item) => (
        <ChecksListItem
          item={{ Description: item }}
          {...props}
          key={item}
          icon={props.icon || 'tick4'}
        />
      ))}
    </YStack>
  );
};

export const ChecksListItem = ({
  item,
  icon,
  width = 24,
  height = 24,
  typography = 'body-regular-Gray800',
  space = '$xl',
  itemsSpace = '$xxl',
  navigation,
}: CheckListItemProps) => {
  const actionLink = item.Actions?.find((action) => action.Uri !== undefined);

  if (actionLink?.Title && navigation) {
    const indexOfLinkStart = item.Description.indexOf(actionLink.Title);
    const indexOfLinkEnd = indexOfLinkStart + actionLink.Title.length;

    const startText = item.Description.substring(0, indexOfLinkStart);
    const url = item.Description.substring(indexOfLinkStart, indexOfLinkEnd);
    const endText = item.Description.substring(
      indexOfLinkEnd,
      item.Description.length
    );

    return (
      <XStack space={space} width={'90%'}>
        <Icon
          width={width}
          height={height}
          name={icon}
          color={tokens.color.Success.val}
        />
        <Text
          fontVariant={typography}
          tamaguiTextProps={{
            marginBottom: itemsSpace,
          }}
        >
          {startText}
          <Text
            fontVariant={'body-semibold-Tertiary800'}
            tamaguiTextProps={{
              onPress: () => {
                navigation.navigate('Web View', {
                  url: actionLink.Uri,
                });
              },
            }}
            decoration="underline"
          >
            {url}
          </Text>
          {endText}
        </Text>
      </XStack>
    );
  } else {
    return (
      <XStack space={space} width={'90%'}>
        <Icon
          width={width}
          height={height}
          name={icon}
          color={tokens.color.Success.val}
        />
        <Text
          fontVariant={typography}
          tamaguiTextProps={{
            marginBottom: itemsSpace,
          }}
        >
          {item.Description}
        </Text>
      </XStack>
    );
  }
};
