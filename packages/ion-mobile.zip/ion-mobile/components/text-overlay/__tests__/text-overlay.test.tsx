import { render, screen } from '@src/jest/testing-library';

import { TextOverlay } from '../text-overlay';

const props = { topText: 'STEPS', middleText: 'IN THE', bottomText: 'PROCESS' };

it('Should render Text Overlay', () => {
  render(<TextOverlay {...props} />);

  const textOverlay = screen.getByLabelText('STEPS IN THE PROCESS');
  expect(textOverlay).toBeOnTheScreen();
});

it('Should show correct text', () => {
  render(<TextOverlay {...props} />);

  expect(screen.getByText('STEPS')).toBeOnTheScreen();
  expect(screen.getByText('IN THE')).toBeOnTheScreen();
  expect(screen.getByText('PROCESS')).toBeOnTheScreen();
});

it('Should render Text Overlay with correct styles', () => {
  render(<TextOverlay {...props} />);

  const topText = screen.getByText('STEPS');
  const middleText = screen.getByText('IN THE');
  const bottomText = screen.getByText('PROCESS');

  expect(topText).toHaveStyle({
    textAlign: 'left',
    letterSpacing: 6,
  });
  expect(middleText).toHaveStyle({
    textAlign: 'center',
    letterSpacing: 6,
  });
  expect(bottomText).toHaveStyle({
    textAlign: 'right',
    paddingLeft: 32,
    letterSpacing: 6,
  });
});
