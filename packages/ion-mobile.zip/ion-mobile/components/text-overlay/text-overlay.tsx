import { YStack } from 'tamagui';

import { Text } from '../text';

type TextOverlayProps = {
  topText: string;
  middleText: string;
  bottomText: string;
  width?: number;
};

export const TextOverlay = ({
  topText,
  middleText,
  bottomText,
  width,
}: TextOverlayProps) => {
  return (
    <YStack
      accessibilityLabel={`${topText} ${middleText} ${bottomText}`}
      accessibilityHint={`${topText} ${middleText} ${bottomText}`}
      space="$lg"
      margin={'auto'}
      width={width}
      testID="textOverlay"
      accessible
    >
      <Text
        fontVariant="heading0-semibold-White"
        tamaguiTextProps={{
          textAlign: 'left',
          letterSpacing: 6,
        }}
      >
        {topText}
      </Text>
      <Text
        fontVariant="heading2-semibold-White"
        tamaguiTextProps={{ textAlign: 'center', letterSpacing: 6 }}
      >
        {middleText}
      </Text>
      <Text
        fontVariant="heading0-semibold-White"
        tamaguiTextProps={{
          textAlign: 'right',
          paddingLeft: '$xxxl',
          letterSpacing: 6,
        }}
      >
        {bottomText}
      </Text>
    </YStack>
  );
};
