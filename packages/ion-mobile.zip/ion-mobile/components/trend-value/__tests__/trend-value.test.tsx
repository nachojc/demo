import { render, screen } from '@src/jest/testing-library';

import { TrendValue } from '../trend-value';

describe('Trend Value Component', () => {
  it('should render positive value in green colour', () => {
    render(
      <TrendValue
        colorNegative={'Red30'}
        colorZero={'Gray300'}
        colorPositive={'Positive'}
        gainOrLoss={{ raw: 1234.56, formatted: '+£1,234.56' }}
        gainOrLossPercentage={{ raw: 12.3, formatted: '12.30%' }}
      />
    );

    const trendValueCopy = screen.getByText('+£1,234.56 (12.30%)');

    expect(trendValueCopy).toBeOnTheScreen();
    expect(trendValueCopy).toHaveStyle({ color: '#6AC748' });
  });

  it('should render zero in grey colour', () => {
    render(
      <TrendValue
        colorNegative={'Red30'}
        colorZero={'Gray300'}
        colorPositive={'Positive'}
        gainOrLoss={{ raw: 0.0, formatted: '+£0.00' }}
        gainOrLossPercentage={{ raw: 0.0, formatted: '0.00%' }}
      />
    );

    const trendValueCopy = screen.getByText('+ £0.00');

    expect(trendValueCopy).toBeOnTheScreen();
    expect(trendValueCopy).toHaveStyle({ color: '#CCCCCC' });
  });

  it('should render positive value in green color but no percentage when showPercentage is false', () => {
    render(
      <TrendValue
        colorNegative={'Red30'}
        colorZero={'Gray300'}
        colorPositive={'Positive'}
        showPercentage={false}
        gainOrLoss={{ raw: 1234.56, formatted: '+£1,234.56' }}
        gainOrLossPercentage={{ raw: 10, formatted: '10%' }}
      />
    );

    const trendValueCopy = screen.getByText('+£1,234.56');

    expect(trendValueCopy).toBeOnTheScreen();
    expect(trendValueCopy).toHaveStyle({ color: '#6AC748' });
  });

  it('should render empty string if gainOrLoss.raw is null and showZeroValue false', () => {
    render(
      <TrendValue
        colorNegative={'Red30'}
        colorZero={'Gray300'}
        colorPositive={'Positive'}
        gainOrLoss={{ raw: 0, formatted: '+£0.00' }}
        gainOrLossPercentage={{ raw: 0.0, formatted: '0.00%' }}
        showZeroValue={false}
      />
    );

    const trendValueCopy = screen.queryByText('+ £0.00');

    expect(trendValueCopy).toBeNull();
  });

  it('should render negative value in red colour', () => {
    render(
      <TrendValue
        colorNegative={'Red30'}
        colorZero={'Gray300'}
        colorPositive={'Positive'}
        gainOrLoss={{ raw: -1234.56, formatted: '-£1,234.56' }}
        gainOrLossPercentage={{ raw: -12.3, formatted: '-12.30%' }}
      />
    );

    const trendValueCopy = screen.getByText('-£1,234.56 (-12.30%)');

    expect(trendValueCopy).toBeOnTheScreen();
    expect(trendValueCopy).toHaveStyle({ color: '#FF3030' });
  });

  it('should render value with bold text when textFormat bold', () => {
    render(
      <TrendValue
        colorNegative={'ErrorSecondary'}
        colorZero={'Gray300'}
        colorPositive={'Positive'}
        gainOrLoss={{ raw: -1234.56, formatted: '-£1,234.56' }}
        gainOrLossPercentage={{ raw: -12.3, formatted: '-12.30%' }}
        textFormat="bold"
      />
    );

    const trendValueCopy = screen.getByTestId('TrendValueCopy');

    expect(trendValueCopy).toHaveStyle({
      color: '#FF5757',
      fontFamily: 'SourceSansPro-Bold',
    });
  });

  it('should render value with bold text when textFormat regular', () => {
    render(
      <TrendValue
        colorNegative={'ErrorSecondary'}
        colorZero={'Gray300'}
        colorPositive={'Positive'}
        gainOrLoss={{ raw: 1234.56, formatted: '+£1,234.56' }}
        gainOrLossPercentage={{ raw: 12.3, formatted: '12.30%' }}
        textFormat="regular"
      />
    );

    const trendValueCopy = screen.getByTestId('TrendValueCopy');

    expect(trendValueCopy).toHaveStyle({
      color: '#6AC748',
      fontFamily: 'SourceSansPro-Regular',
    });
  });
});
