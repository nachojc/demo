import { Color } from '@theme/tokens';
import { getTokens, getVariableValue, XStack } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text';

export type FormattedValue = {
  raw: number | null;
  formatted: string | null;
};

export type GainLossTextFormat = 'regular' | 'bold';
export type TrendValueProps = {
  gainOrLoss: FormattedValue;
  gainOrLossPercentage: FormattedValue;
  colorNegative?: Color;
  colorZero?: Color;
  colorPositive?: Color;
  showZeroValue?: boolean;
  showPercentage?: boolean;
  textFormat?: GainLossTextFormat;
};

export const TrendValue = ({
  gainOrLoss,
  gainOrLossPercentage,
  colorNegative = 'DWRed',
  colorZero = 'Gray500',
  colorPositive = 'Success',
  showZeroValue = true,
  showPercentage = true,
  textFormat = 'regular',
}: TrendValueProps) => {
  const tokens = getTokens();
  const trendIcon =
    gainOrLoss.raw && gainOrLoss.raw < 0 ? 'trending-down' : 'trending-up';
  const TextAndIconColor =
    gainOrLoss.raw && gainOrLoss.raw < 0 ? colorNegative : colorPositive;
  const visiblePercentage = showPercentage
    ? `(${gainOrLossPercentage.formatted})`
    : '';

  return (
    <XStack accessible={false}>
      {gainOrLoss.raw && gainOrLoss.raw !== 0 ? (
        <>
          <Text
            fontVariant={`overline-${textFormat}-${TextAndIconColor}`}
            testID="TrendValueCopy"
            tamaguiTextProps={{
              accessible: false,
              importantForAccessibility: 'no',
              letterSpacing: getVariableValue(tokens.space.xs),
            }}
          >
            {`${gainOrLoss.formatted} ${visiblePercentage}`}
          </Text>
          <Icon
            accessible={false}
            name={trendIcon}
            height={getVariableValue(tokens.size[4])}
            width={getVariableValue(tokens.size[6])}
            color={getVariableValue(tokens.color[TextAndIconColor])}
          />
        </>
      ) : (
        <Text
          fontVariant={`overline-${textFormat}-${colorZero}`}
          testID="TrendValueCopy"
          tamaguiTextProps={{
            accessible: false,
            importantForAccessibility: 'no',
          }}
        >
          {showZeroValue ? '+ £0.00' : ''}
        </Text>
      )}
    </XStack>
  );
};
