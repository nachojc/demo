import { render, screen } from '@src/jest/testing-library';

import { HeadingGroup } from '../heading-group';

describe('HeaderComponent', () => {
  it('should show heading and subheading', () => {
    render(<HeadingGroup heading="title" subHeading="subtitle" />);

    const [heading, subHeading] = screen.getAllByRole('text');

    expect(heading).toHaveTextContent('title');
    expect(subHeading).toHaveTextContent('subtitle');
  });

  it('should have the correct styling', () => {
    render(<HeadingGroup heading="title" subHeading="subtitle" />);

    const [heading, subHeading] = screen.getAllByRole('text');

    expect(heading).toHaveStyle({
      color: '#122D44',
      fontFamily: 'SourceSansPro-Regular',
      fontSize: 32,
      lineHeight: 42,
    });
    expect(subHeading).toHaveStyle({
      color: '#373737',
      fontFamily: 'SourceSansPro-Light',
      fontSize: 20,
      lineHeight: 28,
    });
  });

  it('should only show the heading, when subheading props not provided', () => {
    render(<HeadingGroup heading="title" />);

    const [heading, subHeading] = screen.getAllByRole('text');

    expect(heading).toHaveTextContent('title');
    expect(subHeading).toBeUndefined();
  });
});
