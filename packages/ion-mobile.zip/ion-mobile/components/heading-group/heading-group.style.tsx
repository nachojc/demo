import { styled, YStack } from 'tamagui';

export const SubtitleContainer = styled(YStack, {
  paddingTop: '$sm',
});
