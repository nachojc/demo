import { getTestId } from '@src/utils/get-test-id';
import { YStack, YStackProps } from 'tamagui';

import { Text } from '../text';
import { SubtitleContainer } from './heading-group.style';

export type HeadingGroupProps = YStackProps & {
  heading: string;
  subHeading?: string;
};

export const HeadingGroup = ({
  heading,
  subHeading,
  ...props
}: HeadingGroupProps) => {
  return (
    <YStack testID="HeadingGroup" {...props}>
      <Text
        testID={getTestId(heading)}
        fontVariant="heading2-regular-Secondary800"
        tamaguiTextProps={{ letterSpacing: -0.77 }}
      >
        {heading}
      </Text>
      {subHeading && (
        <SubtitleContainer>
          <Text
            fontVariant="heading4-light-Gray800"
            tamaguiTextProps={{ mt: '$sm' }}
          >
            {subHeading}
          </Text>
        </SubtitleContainer>
      )}
    </YStack>
  );
};
