import { fireEvent, render, screen, waitFor } from '@src/jest/testing-library';

import { Tooltip } from '../tooltip';

const tooltipContent = 'Lorem Ipsum dolor sit amet';

describe('Testing the Tooltip', () => {
  it('should have the tooltip icon', () => {
    render(<Tooltip content={tooltipContent} />);

    expect(
      screen.getByTestId('tooltip-icon', { includeHiddenElements: true })
    ).toBeDefined();
    expect(
      screen.getByTestId('test:id/icon-info', { includeHiddenElements: true })
    ).toBeDefined();
  });

  it('should show the label when label is defined', () => {
    render(
      <Tooltip content={tooltipContent} label="This will be tooltip label" />
    );

    expect(screen.getByText('This will be tooltip label')).toBeDefined();
  });

  it("when tooltip isn't activated, the content is not in the dom by default", () => {
    render(<Tooltip content={tooltipContent} />);

    expect(screen.queryByText(tooltipContent)).toBeNull();
  });

  it.skip('should open the tooltip, by clicking on the icon', async () => {
    render(<Tooltip content={tooltipContent} />);

    fireEvent.press(screen.getByTestId('tooltip-icon'));
    await waitFor(() => {
      expect(screen.getByTestId('tooltip-content')).toBeDefined();
    });
  });
});
