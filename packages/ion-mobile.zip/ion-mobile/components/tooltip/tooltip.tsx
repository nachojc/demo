import { getTokens, getVariableValue, Popover, Text } from 'tamagui';

import { Icon } from '../icon';
import {
  StyledContentWrapper,
  StyledPopoverClose,
  StyledText,
  StyledTriggerWrapper,
} from './tooltip.styles';

type Props = {
  label?: string;
  content: string;
};

export function Tooltip({ label, content }: Props) {
  const tokens = getTokens();
  return (
    <Popover placement="bottom-start" size={'$1'} stayInFrame allowFlip>
      <StyledTriggerWrapper centered={!label}>
        {label && <Text>{label}</Text>}
        <Popover.Trigger paddingVertical={'$1'} testID="tooltip-icon">
          <Icon name="info" height={getVariableValue(tokens.size['4'])} />
        </Popover.Trigger>
      </StyledTriggerWrapper>
      <Popover.Content
        elevate
        width={'98%'}
        borderRadius={'$1'}
        backgroundColor={'$White'}
      >
        <Popover.Arrow size={'$4'} backgroundColor={'$White'} />
        <StyledContentWrapper>
          <StyledText>{content}</StyledText>
          <StyledPopoverClose testID="tooltip-close">
            <Icon
              name="close"
              color={getVariableValue(tokens.color.Gray400)}
              height={getVariableValue(tokens.size['4'])}
            />
          </StyledPopoverClose>
        </StyledContentWrapper>
      </Popover.Content>
    </Popover>
  );
}
