import { View } from 'react-native';
import { Popover, styled, Text, YStack } from 'tamagui';

export const StyledTriggerWrapper = styled(YStack, {
  flexDirection: 'row',
  alignItems: 'center',
  justifyContent: 'space-between',
  borderStartColor: 'white',

  variants: {
    centered: {
      true: { justifyContent: 'center' },
    },
  } as const,
});

export const StyledContentWrapper = styled(View, {
  padding: '$lg',
  display: 'flex',
  flexDirection: 'row',
  backgroundColor: '$White',
});

export const StyledText = styled(Text, {
  width: '90%',
});

export const StyledPopoverClose = styled(Popover.Close, {
  width: '10%',
  display: 'flex',
  alignItems: 'flex-end',
});
