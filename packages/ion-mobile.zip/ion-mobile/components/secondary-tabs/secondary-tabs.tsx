import { useAnimatedTabs } from '@hooks/use-animated-tabs';
import Animated from 'react-native-reanimated';
import { getTokens } from 'tamagui';

import { Container, Tab, TabText } from './styles';

type Tab = { label: string; onPress: (index: number) => void };

export const SecondaryTabs = ({
  tabs,
  initialSelection,
}: {
  tabs: Tab[];
  initialSelection?: number;
}) => {
  const tokens = getTokens();
  const initialTabIndex =
    initialSelection && tabs.length >= initialSelection ? initialSelection : 0;
  const { animatedStyles, selectedTabIndex, tabWidth, handleTabSelect } =
    useAnimatedTabs(initialTabIndex);

  return (
    <Container>
      <Animated.View
        accessibilityLabel="Animated View"
        style={[
          animatedStyles,
          {
            width: `${100 / tabs.length}%`,
            position: 'absolute',
            height: '100%',
            backgroundColor: tokens.color.DWPrimary500.val,
            borderWidth: 1,
            borderRadius: 6,
          },
        ]}
      />
      {tabs.map((tab, index) => (
        <Tab
          key={tab.label}
          accessibilityRole="tab"
          accessibilityLabel="Tab"
          onLayout={(event) => {
            tabWidth.current = event.nativeEvent.layout.width;
          }}
          onPress={() => {
            handleTabSelect(index);
            tab.onPress(index);
          }}
          inactive={selectedTabIndex !== index}
          active={selectedTabIndex === index}
        >
          <TabText active={selectedTabIndex === index}>{tab.label}</TabText>
        </Tab>
      ))}
    </Container>
  );
};
