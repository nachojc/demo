import { styled, Text, XStack } from 'tamagui';

export const Container = styled(XStack, {
  borderWidth: '$xxs',
  borderColor: '$Secondary800',
  borderRadius: 7,
});

export const Tab = styled(XStack, {
  flex: 1,
  padding: '$md',
  borderRadius: 6,
  justifyContent: 'center',
  alignItems: 'center',
  borderColor: '$Secondary800',
  variants: {
    active: {
      true: {
        backgroundColor: '$Secondary800',
      },
    },
    inactive: {
      true: {
        backgroundColor: '$White',
      },
    },
  },
});

export const TabText = styled(Text, {
  color: '$Secondary800',
  fontWeight: '600',
  fontSize: 16,
  variants: {
    active: {
      true: {
        color: '$White',
      },
    },
  },
});
