import { fireEvent, render, screen } from '@src/jest/testing-library';

import { SecondaryTabs } from '../secondary-tabs';

const Secondary800 = '#122D44';
const white = '#FFFFFF';

const tabPress = jest.fn();

const mockTabs = [
  { label: 'Option 1', onPress: tabPress },
  { label: 'Option 2', onPress: jest.fn },
  { label: 'Option 3', onPress: jest.fn },
];

describe('Secondary Tabs', () => {
  it('should render the tabs passed in tabs config prop', () => {
    render(<SecondaryTabs tabs={mockTabs} />);

    const tabs = screen.getAllByLabelText('Tab');
    expect(tabs).toHaveLength(3);

    mockTabs.forEach((tab) => {
      expect(screen.getByText(tab.label)).toBeTruthy();
    });
  });

  it('should trigger the onPress when pressing on a tab', () => {
    render(<SecondaryTabs tabs={mockTabs} />);

    const tab = screen.getByText('Option 1');
    fireEvent.press(tab);

    expect(tabPress).toHaveBeenCalledTimes(1);
  });

  it('should set the first tab as active by default', () => {
    render(<SecondaryTabs tabs={mockTabs} />);

    const animatedView = screen.getByLabelText('Animated View');

    expect(animatedView).toHaveStyle({
      backgroundColor: '#141D31',
    });

    expect(screen.getByText('Option 1')).toHaveStyle({
      color: white,
    });
    expect(screen.getByText('Option 2')).toHaveStyle({
      color: Secondary800,
    });
    expect(screen.getByText('Option 3')).toHaveStyle({
      color: Secondary800,
    });
  });

  it('should set the the initial active tab to the passed initialSelection prop', () => {
    render(<SecondaryTabs tabs={mockTabs} initialSelection={2} />);

    const animatedView = screen.getByLabelText('Animated View');

    expect(animatedView).toHaveStyle({
      backgroundColor: '#141D31',
    });

    expect(screen.getByText('Option 1')).toHaveStyle({
      color: Secondary800,
    });
    expect(screen.getByText('Option 2')).toHaveStyle({
      color: Secondary800,
    });
    expect(screen.getByText('Option 3')).toHaveStyle({
      color: white,
    });
  });

  it('should set the the initial active tab to first tab on invalid initialSelection prop (index > tabs)', () => {
    render(<SecondaryTabs tabs={mockTabs} initialSelection={5} />);

    const animatedView = screen.getByLabelText('Animated View');

    expect(animatedView).toHaveStyle({
      backgroundColor: '#141D31',
    });

    expect(screen.getByText('Option 1')).toHaveStyle({
      color: white,
    });
    expect(screen.getByText('Option 2')).toHaveStyle({
      color: Secondary800,
    });
    expect(screen.getByText('Option 3')).toHaveStyle({
      color: Secondary800,
    });
  });

  it('should update the active tab to the tab pressed', () => {
    render(<SecondaryTabs tabs={mockTabs} />);

    const tabs = screen.getAllByLabelText('Tab');

    fireEvent.press(tabs[1]);

    const animatedView = screen.getByLabelText('Animated View');

    expect(animatedView).toHaveStyle({
      backgroundColor: '#141D31',
    });

    expect(screen.getByText('Option 1')).toHaveStyle({
      color: Secondary800,
    });
    expect(screen.getByText('Option 2')).toHaveStyle({
      color: white,
    });
    expect(screen.getByText('Option 3')).toHaveStyle({
      color: Secondary800,
    });
  });

  it('should update the active animated view tab to the tab pressed', () => {
    render(<SecondaryTabs tabs={mockTabs} />);

    fireEvent.press(screen.getByText('Option 2'));

    const animatedView = screen.getByLabelText('Animated View');

    expect(animatedView).toHaveStyle({
      backgroundColor: '#141D31',
    });
  });
});
