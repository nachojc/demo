import { render, screen } from '@src/jest/testing-library';
import { Theme } from 'tamagui';

import { CarouselBottomNavigation } from '../carousel-navigation';

const mockSharedValue = {
  value: 0,
  addListener: jest.fn(),
  removeListener: jest.fn(),
  modify: jest.fn(),
};

const getLabel = (page: number, btnName: 'Next' | 'Back' | 'Start') => {
  const labels = {
    Next: `Next. Go to carousel content item ${page + 1} of 3`,
    Back: `Back. Go to carousel content item ${page - 1} of 3`,
    Start: `Start. End of carousel`,
  };
  return labels[btnName];
};

describe('should display navigation button with accesibility', () => {
  it('should display right button and label on screen 1', () => {
    render(
      <Theme name={'insurance'}>
        <CarouselBottomNavigation
          progressValue={mockSharedValue}
          currentPage={1}
          itemsLength={3}
          onLeftLabelPress={jest.fn()}
          onRightLabelPress={jest.fn()}
          rightLabel="Next"
        />
      </Theme>
    );

    expect(
      screen.queryByRole('button', { name: 'Back' })
    ).not.toBeOnTheScreen();
    expect(screen.getByRole('button', { name: 'Next' })).toBeOnTheScreen();
    expect(
      screen.getByLabelText('Next. Go to carousel content item 2 of 3')
    ).toBeOnTheScreen();
  });

  it.each`
    page | leftbtn   | rightbtn
    ${2} | ${'Back'} | ${'Next'}
    ${3} | ${'Back'} | ${'Start'}
  `(
    'should display right button and labels on screen $page with $leftbtn and $rightbtn',
    ({ page, leftbtn, rightbtn }) => {
      render(
        <Theme name={'insurance'}>
          <CarouselBottomNavigation
            progressValue={mockSharedValue}
            currentPage={page}
            itemsLength={3}
            onLeftLabelPress={jest.fn()}
            onRightLabelPress={jest.fn()}
            leftLabel={leftbtn}
            rightLabel={rightbtn}
          />
        </Theme>
      );
      expect(screen.getByRole('button', { name: leftbtn })).toBeOnTheScreen();
      expect(screen.getByLabelText(getLabel(page, leftbtn))).toBeOnTheScreen();
      expect(screen.getByRole('button', { name: rightbtn })).toBeOnTheScreen();
      expect(screen.getByLabelText(getLabel(page, rightbtn))).toBeOnTheScreen();
    }
  );
});
