import { fireEvent, render, screen, waitFor } from '@src/jest/testing-library';
import { Platform } from 'react-native';
import { Text } from 'tamagui';

import { FullScreenCarouselModal } from '../fullscreen-carousel-modal';

const screenWidth = 1000;
jest.mock('react-native/Libraries/Utilities/Dimensions', () => ({
  ...jest.requireActual('react-native/Libraries/Utilities/Dimensions'),
  get: () => ({ width: screenWidth }),
  addEventListener: jest.fn(),
}));

Platform.OS = 'android';

const page1 = 'Placeholder page 1';
const page2 = 'Placeholder page 2';
const page3 = 'Placeholder page 3';
const mockData = [
  <Text key="page-1">{page1}</Text>,
  <Text key="page-2">{page2}</Text>,
  <Text key="page-3">{page3}</Text>,
];
const leftLabel = 'leftLabel';
const rightLabel = 'rightLabel';
const lastRightLabel = 'lastRightLabel';

const mockOnLeftLabelPress = jest.fn();
const mockOnRightLabelPress = jest.fn();
const mockOnLastRightLabelPress = jest.fn();
const mockOnPageLoad = jest.fn();

describe('FullScreenCarouselModal', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('switches pages correctly', async () => {
    render(
      <FullScreenCarouselModal
        items={mockData}
        leftLabel={leftLabel}
        rightLabel={rightLabel}
        lastRightLabel={lastRightLabel}
      />
    );
    const rightLabelElement = screen.getByText(rightLabel);

    expect(screen.getByText(page1)).toBeOnTheScreen();
    expect(screen.queryByText(page2)).not.toBeOnTheScreen();
    expect(screen.queryByText(page3)).not.toBeOnTheScreen();

    fireEvent.press(rightLabelElement);

    await waitFor(() => {
      expect(screen.getByText(page2)).toBeOnTheScreen();
    });
    expect(screen.queryByText(page1)).not.toBeOnTheScreen();
    expect(screen.queryByText(page3)).not.toBeOnTheScreen();

    fireEvent.press(rightLabelElement);

    await waitFor(() => {
      expect(screen.getByText(page3)).toBeOnTheScreen();
    });
    expect(screen.queryByText(page1)).not.toBeOnTheScreen();
    expect(screen.queryByText(page2)).not.toBeOnTheScreen();
  });

  it('renders labels correctly', async () => {
    render(
      <FullScreenCarouselModal
        items={mockData}
        leftLabel={leftLabel}
        rightLabel={rightLabel}
        lastRightLabel={lastRightLabel}
      />
    );
    const rightLabelElement = screen.getByText(rightLabel);

    expect(screen.getByText(rightLabel)).toBeOnTheScreen();
    expect(screen.queryByText(leftLabel)).not.toBeOnTheScreen();
    expect(screen.queryByText(lastRightLabel)).not.toBeOnTheScreen();

    fireEvent.press(rightLabelElement);

    await waitFor(() => {
      expect(screen.getByText(leftLabel)).toBeOnTheScreen();
    });
    expect(screen.getByText(rightLabel)).toBeOnTheScreen();
    expect(screen.queryByText(lastRightLabel)).not.toBeOnTheScreen();

    fireEvent.press(rightLabelElement);

    await waitFor(() => {
      expect(screen.getByText(lastRightLabel)).toBeOnTheScreen();
    });
    expect(screen.getByText(leftLabel)).toBeOnTheScreen();
    expect(screen.queryByText(rightLabel)).not.toBeOnTheScreen();
  });

  it('invokes mockOnPageLoad correctly', async () => {
    render(
      <FullScreenCarouselModal
        items={mockData}
        leftLabel={leftLabel}
        rightLabel={rightLabel}
        onPageLoad={mockOnPageLoad}
      />
    );
    const rightLabelElement = screen.getByText(rightLabel);

    expect(mockOnPageLoad).toHaveBeenCalledWith(0);
    expect(mockOnPageLoad).toHaveBeenCalledTimes(1);

    fireEvent.press(rightLabelElement);

    await waitFor(() => {
      expect(mockOnPageLoad).toHaveBeenCalledWith(1);
    });
    expect(mockOnPageLoad).toHaveBeenCalledTimes(2);

    fireEvent.press(rightLabelElement);

    await waitFor(() => {
      expect(mockOnPageLoad).toHaveBeenCalledWith(2);
    });
    expect(mockOnPageLoad).toHaveBeenCalledTimes(3);
  });

  it('invokes onLeftLabelPress, onRightLabelPress, onLastRightLabelPress correctly', async () => {
    render(
      <FullScreenCarouselModal
        items={mockData}
        leftLabel={leftLabel}
        rightLabel={rightLabel}
        lastRightLabel={lastRightLabel}
        onLeftLabelPress={mockOnLeftLabelPress}
        onRightLabelPress={mockOnRightLabelPress}
        onLastRightLabelPress={mockOnLastRightLabelPress}
      />
    );

    fireEvent.press(screen.getByText(rightLabel));

    await waitFor(() => {
      expect(mockOnRightLabelPress).toHaveBeenCalledWith(0);
    });
    expect(mockOnRightLabelPress).toHaveBeenCalledTimes(1);

    fireEvent.press(screen.getByText(rightLabel));

    await waitFor(() => {
      expect(mockOnRightLabelPress).toHaveBeenCalledWith(1);
    });
    expect(mockOnRightLabelPress).toHaveBeenCalledTimes(2);

    fireEvent.press(screen.getByText(lastRightLabel));

    await waitFor(() => {
      expect(mockOnLastRightLabelPress).toHaveBeenCalledWith();
    });
    expect(mockOnLastRightLabelPress).toHaveBeenCalledTimes(1);

    fireEvent.press(screen.getByText(leftLabel));

    await waitFor(() => {
      expect(mockOnLeftLabelPress).toHaveBeenCalledWith(2);
    });
    expect(mockOnLeftLabelPress).toHaveBeenCalledTimes(1);

    fireEvent.press(screen.getByText(leftLabel));

    await waitFor(() => {
      expect(mockOnLeftLabelPress).toHaveBeenCalledWith(1);
    });
    expect(mockOnLeftLabelPress).toHaveBeenCalledTimes(2);
  });
});
