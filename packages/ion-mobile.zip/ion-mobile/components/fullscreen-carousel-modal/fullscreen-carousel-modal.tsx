import { useA11yFocus } from '@hooks/use-a11y-focus';
import { isIpad } from '@src/utils/is-ipad';
import { useEffect, useRef, useState } from 'react';
import {
  InteractionManager,
  Platform,
  ScrollView as RNScrollView,
  useWindowDimensions,
} from 'react-native';
import { useSharedValue } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { getTokens, ScrollView, Stack, TamaguiElement, YStack } from 'tamagui';

import { CloseButton } from '../close-button';
import { CarouselBottomNavigation } from './carousel-navigation';

type HeaderIconVariant = 'light' | 'dark';

type CarouselProps = {
  showHeader?: boolean;
  headerIconVariant?: HeaderIconVariant;
  carouselAccessibilityTitle?: string;
  onClose?: (index: number) => void;
  items: JSX.Element[];
  leftLabel: string;
  rightLabel: string;
  lastRightLabel?: string;
  onLeftLabelPress?: (index: number) => void;
  onRightLabelPress?: (index: number) => void;
  onLastRightLabelPress?: () => void;
  onPageLoad?: (index: number) => void;
  bgScreens?: { key: number; bg: string }[];
};

export const FullScreenCarouselModal = ({
  showHeader = true,
  headerIconVariant = 'dark',
  carouselAccessibilityTitle = '',
  onClose,
  items,
  leftLabel,
  rightLabel,
  lastRightLabel,
  onLeftLabelPress,
  onRightLabelPress,
  onLastRightLabelPress,
  onPageLoad,
  bgScreens,
}: CarouselProps) => {
  const scrollRef = useRef<TamaguiElement & RNScrollView>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const progressValue = useSharedValue(0);
  const { width } = useWindowDimensions();
  const insets = useSafeAreaInsets();
  // Needed to prevent multiple onMomentumScrollEnd calls on Android
  const [canMomentum, setCanMomentum] = useState(false);

  const isAndroid = Platform.OS === 'android';
  const isIos = Platform.OS === 'ios';

  const isLastPage = currentIndex + 1 === items.length;
  const isFirstPage = currentIndex === 0;

  const { elementRef, focus } = useA11yFocus();

  useEffect(() => {
    onPageLoad?.(currentIndex);
  }, [currentIndex, onPageLoad]);

  const onRightLabelPressHandler = async () => {
    if (isLastPage) {
      onLastRightLabelPress?.();
      return;
    }

    const xPosition = width * (currentIndex + 1);

    await InteractionManager.runAfterInteractions(() =>
      scrollRef.current?.scrollTo({ x: xPosition, animated: true })
    );

    if (isAndroid) {
      // onMomentumScrollEnd doesn't work on Android when scrolling is triggered via ref
      updatePage(xPosition);
    }
  };

  const onLeftLabelPressHandler = async () => {
    if (isFirstPage) {
      return;
    }

    const xPosition = width * (currentIndex + 1) - width * 2;

    await InteractionManager.runAfterInteractions(() =>
      scrollRef.current?.scrollTo({ x: xPosition, animated: true })
    );

    if (isAndroid) {
      // onMomentumScrollEnd doesn't work on Android when scrolling is triggered via ref
      updatePage(xPosition);
    }
  };

  const updatePage = (contentOffsetX: number) => {
    const index = Math.round(contentOffsetX / width);

    setCurrentIndex(index);

    index > currentIndex
      ? onRightLabelPress?.(currentIndex)
      : onLeftLabelPress?.(currentIndex);

    // There seems to be a delay on iOS to wait for A11Y Labels with dynamic text in to update
    isIos ? setTimeout(focus, 1000) : focus();
  };

  const syncronisePage = async () => {
    const xPosition = width * currentIndex;
    await InteractionManager.runAfterInteractions(() =>
      scrollRef.current?.scrollTo({ x: xPosition, animated: true })
    );
  };

  return (
    <YStack fullscreen alignItems="center" bg={bgScreens?.[currentIndex].bg}>
      {showHeader && (
        <YStack
          alignItems="flex-end"
          alignSelf="stretch"
          paddingHorizontal="$xl"
          paddingTop={insets.top}
          paddingBottom="$md"
        >
          <CloseButton
            ref={elementRef}
            onPress={() => onClose?.(currentIndex)}
            accessibilityLabel={`${carouselAccessibilityTitle} ${
              currentIndex + 1
            } of ${items.length}, close`}
            iconProps={{ color: getHeaderIconColor(headerIconVariant) }}
          />
        </YStack>
      )}

      <ScrollView
        ref={scrollRef}
        scrollEnabled={items.length > 1}
        scrollEventThrottle={16}
        horizontal
        pagingEnabled
        accessibilityRole="adjustable"
        showsHorizontalScrollIndicator={false}
        onLayout={syncronisePage}
        onScroll={(e) => {
          setCanMomentum(true);

          const value =
            e.nativeEvent.contentOffset.x /
            e.nativeEvent.layoutMeasurement.width;

          // getRangedValue is used to prevent animation overscrolling on iOS when ScrollView is used with bounces
          progressValue.value = getRangedValue(value, 0, items.length - 1);
        }}
        onMomentumScrollEnd={(e) => {
          if (canMomentum) {
            updatePage(e.nativeEvent.contentOffset.x);
            setCanMomentum(false);
          }
        }}
      >
        {items.map((item, index) => (
          <Stack
            key={item?.key}
            justifyContent={isIpad ? 'center' : undefined}
            width={width}
            importantForAccessibility={
              index === currentIndex ? 'auto' : 'no-hide-descendants'
            }
            accessibilityElementsHidden={index !== currentIndex}
          >
            {item}
          </Stack>
        ))}
      </ScrollView>

      <CarouselBottomNavigation
        progressValue={progressValue}
        currentPage={currentIndex + 1}
        leftLabel={isFirstPage ? undefined : leftLabel}
        rightLabel={isLastPage ? lastRightLabel : rightLabel}
        itemsLength={items.length}
        onLeftLabelPress={onLeftLabelPressHandler}
        onRightLabelPress={onRightLabelPressHandler}
      />
    </YStack>
  );
};

const getHeaderIconColor = (headerIconVariant: HeaderIconVariant) => {
  const tokens = getTokens();

  switch (headerIconVariant) {
    case 'dark':
      return tokens.color.Secondary800.val;
    case 'light':
      return tokens.color.White.val;
  }
};

const getRangedValue = (value: number, min: number, max: number) => {
  if (value < min) {
    return min;
  }
  if (value > max) {
    return max;
  }
  return value;
};
