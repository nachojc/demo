import { getTestId } from '@src/utils/get-test-id';
import { SharedValue } from 'react-native-reanimated';
import { Stack, XStack } from 'tamagui';

import { Button, ButtonVariant } from '../button';
import { PaginationDots } from './pagination-dots';

type CarouselNavigationProps = {
  progressValue: SharedValue<number>;
  currentPage: number;
  itemsLength: number;
  leftLabel?: string;
  rightLabel?: string;
  onLeftLabelPress: () => void;
  onRightLabelPress: () => void;
};

export const CarouselBottomNavigation = ({
  progressValue,
  leftLabel,
  rightLabel,
  itemsLength,
  onLeftLabelPress,
  onRightLabelPress,
  currentPage,
}: CarouselNavigationProps) => {
  return (
    <XStack justifyContent="space-between" alignSelf="stretch" padding="$xl">
      <Stack flex={1} flexDirection="row" justifyContent="flex-start">
        {leftLabel && (
          <Button
            accessible
            accessibilityLabel={`${leftLabel}. Go to carousel content item ${
              currentPage - 1
            } of ${itemsLength}`}
            testID={getTestId(`${leftLabel.toLowerCase()}-button`)}
            variant={ButtonVariant.SUB_BRAND_LINK}
            onPress={onLeftLabelPress}
          >
            {leftLabel}
          </Button>
        )}
      </Stack>

      <Stack flex={1} alignItems="center" justifyContent="center">
        {itemsLength > 1 && (
          <PaginationDots
            progressValue={progressValue}
            itemsLength={itemsLength}
          />
        )}
      </Stack>

      <Stack flex={1} flexDirection="row" justifyContent="flex-end">
        {rightLabel && (
          <Button
            accessible
            accessibilityLabel={
              currentPage < itemsLength
                ? `${rightLabel}. Go to carousel content item ${
                    currentPage + 1
                  } of ${itemsLength}`
                : `${rightLabel}. End of carousel`
            }
            testID={getTestId(`${rightLabel.toLowerCase()}-button`)}
            variant={ButtonVariant.SUB_BRAND_LINK}
            onPress={onRightLabelPress}
          >
            {rightLabel}
          </Button>
        )}
      </Stack>
    </XStack>
  );
};
