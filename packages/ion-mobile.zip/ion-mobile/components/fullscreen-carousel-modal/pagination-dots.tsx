import { getTestId } from '@src/utils/get-test-id';
import { View } from 'react-native';
import Animated, {
  Extrapolate,
  interpolate,
  SharedValue,
  useAnimatedStyle,
} from 'react-native-reanimated';
import { getTokens, Stack, XStack } from 'tamagui';

type PaginationDotsProps = {
  itemsLength: number;
  progressValue: SharedValue<number>;
};

export const PaginationDots = ({
  itemsLength,
  progressValue,
}: PaginationDotsProps) => (
  <XStack
    justifyContent="space-between"
    testID={getTestId('pagination-dots')}
    gap="$md"
  >
    {Array(itemsLength)
      .fill(null)
      .map((_, index) => (
        <Dot
          animatedValue={progressValue}
          testID={getTestId('pagination-dot')}
          index={index}
          key={index}
          length={itemsLength}
        />
      ))}
  </XStack>
);

type DotProps = {
  index: number;
  length: number;
  animatedValue: SharedValue<number>;
  testID?: string;
};

const AnimatedStack = Animated.createAnimatedComponent(Stack);
const DOT_SIZE = 10;

const Dot = ({ animatedValue, index, length, testID }: DotProps) => {
  const tokens = getTokens();
  const style = useAnimatedStyle(() => {
    const inputRange = [index - 1, index + 1];
    const outputRange = [-DOT_SIZE, DOT_SIZE];

    return {
      transform: [
        {
          translateX: interpolate(
            animatedValue.value,
            inputRange,
            outputRange,
            Extrapolate.CLAMP
          ),
        },
      ],
    };
  }, [animatedValue, index, length]);

  return (
    <View
      {...{ testID }}
      style={{
        backgroundColor: tokens.color.Gray200.val,
        width: DOT_SIZE,
        height: DOT_SIZE,
        borderRadius: DOT_SIZE / 2,
        overflow: 'hidden',
      }}
    >
      <AnimatedStack
        flex={1}
        borderRadius={DOT_SIZE / 2}
        backgroundColor="$Primary500"
        style={style}
      />
    </View>
  );
};
