import { tokens } from '@theme/tokens';
import { styled, XStack, YStack } from 'tamagui';

// Changing these styles will likely break the design of App FAQs view.
const HeadingTextContainer = styled(YStack, {
  paddingHorizontal: tokens.space.xl,
  paddingTop: tokens.space.xxl,
  paddingBottom: tokens.space.md,
  borderBottomWidth: tokens.space.xxs,
  borderBottomColor: '$Gray300',
});

const AccordionItemTitle = styled(XStack, {
  padding: tokens.space.xl,
  justifyContent: 'space-between',
});

const AccordionItemContent = styled(XStack, {
  borderTopWidth: tokens.space.xxs,
  borderTopColor: '$Gray300',
  padding: tokens.space.xl,
  backgroundColor: '$white',
});

const AccordionItemContainer = styled(YStack, {
  backgroundColor: '$White',
  variants: {
    noBorder: {
      true: {
        borderRadius: '$2',
      },
      false: {
        borderBottomWidth: tokens.space.xxs,
        borderBottomColor: '$Gray300',
      },
    },
  } as const,
});

export {
  AccordionItemContainer,
  AccordionItemContent,
  AccordionItemTitle,
  HeadingTextContainer,
};
