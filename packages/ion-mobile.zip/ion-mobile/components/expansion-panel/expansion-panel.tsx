import { getTestId } from '@src/utils/get-test-id';
import { LayoutAnimation, Platform, UIManager } from 'react-native';
import { getTokens } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text';
import {
  AccordionItemContainer,
  AccordionItemContent,
  AccordionItemTitle,
  HeadingTextContainer,
} from './expansion-panel.style';
import { ExpansionPanelProps } from './types';

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export const ExpansionPanel = ({
  containerStyle,
  content,
  heading,
  index,
  isExpanded,
  disabled,
  noBorder = false,
  onPress,
  selectedIndex,
  testID: customTestID,
  title,
  titleStyle,
  headingStyle,
  titleTextStyle,
  contentStyle,
  accessibilityLabel = title,
}: ExpansionPanelProps) => {
  const tokens = getTokens();

  const handlePress = () => {
    onPress(selectedIndex);
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
  };

  const testID = customTestID ?? getTestId('expansion-panel');

  return (
    // The fontVariants used here are correct for App FAQs page. Changing them will break the design.
    <>
      {heading && (
        <HeadingTextContainer
          paddingTop={index === 0 ? 0 : '$xxl'}
          {...headingStyle}
        >
          <Text fontVariant={'heading5-semibold-Secondary800'}>{heading}</Text>
        </HeadingTextContainer>
      )}
      <AccordionItemContainer
        noBorder={noBorder}
        testID={testID}
        {...containerStyle}
      >
        <AccordionItemTitle
          accessible
          accessibilityRole="button"
          accessibilityLabel={accessibilityLabel}
          accessibilityState={{ expanded: isExpanded ?? disabled }}
          accessibilityLiveRegion="assertive"
          onPress={handlePress}
          disabled={disabled}
          testID={`${testID}--header`}
          {...titleStyle}
        >
          <Text
            tamaguiTextProps={{
              flex: 1,
              ...titleTextStyle,
            }}
            fontVariant={'body-regular-Gray800'}
          >
            {title}
          </Text>
          {!disabled && (
            <Icon
              testID="chevron"
              name={isExpanded ? 'chevron-up' : 'chevron-down'}
              color={tokens.color.Gray400.val}
            />
          )}
        </AccordionItemTitle>
        {(isExpanded || disabled) && (
          <AccordionItemContent testID={`${testID}--content`} {...contentStyle}>
            {content}
          </AccordionItemContent>
        )}
      </AccordionItemContainer>
    </>
  );
};
