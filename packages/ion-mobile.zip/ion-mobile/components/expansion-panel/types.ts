import { ReactNode } from 'react';
import { TextProps, XStackProps, YStackProps } from 'tamagui';

export type ExpansionPanelProps = {
  headingStyle?: YStackProps;
  containerStyle?: YStackProps;
  content: string | ReactNode;
  heading?: string;
  index: number;
  isExpanded: boolean;
  disabled?: boolean;
  noBorder?: boolean;
  onPress: (index: number) => void;
  selectedIndex: number;
  testID?: string;
  title: string;
  titleStyle?: XStackProps;
  titleTextStyle?: TextProps;
  contentStyle?: XStackProps;
  accessibilityLabel?: string;
};
