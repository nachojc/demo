import { fireEvent, render, screen } from '@src/jest/testing-library';
import { Text } from '@aviva/ion-mobile';

import { ExpansionPanel } from '../expansion-panel';
import { ExpansionPanelProps } from '../types';

const defaultExpansionPanelProps = {
  index: 0,
  onPress: jest.fn,
  title: 'title',
  content: 'content',
  isExpanded: false,
  selectedIndex: 0,
} satisfies ExpansionPanelProps;

describe('Testing an accordion item (Expansion Panel)', () => {
  it('Expansion Panel renders on icon, title and content when isExpanded', async () => {
    render(<ExpansionPanel {...defaultExpansionPanelProps} />);
    const title = screen.getByRole('text');
    const expansionPanelComponentIcon = screen.getByTestId(
      'test:id/icon-chevron',
      { includeHiddenElements: true }
    );

    expect(title).toHaveTextContent('title');
    expect(expansionPanelComponentIcon).toBeOnTheScreen();
  });

  it('Expansion Panel content to be correct', async () => {
    render(
      <ExpansionPanel
        {...defaultExpansionPanelProps}
        isExpanded
        content={<Text fontVariant={'body-regular-Gray800'}>content</Text>}
      />
    );
    const content = screen.getByText('content');

    expect(content).toBeOnTheScreen();
  });

  it('Expansion Panel to have title, also content to equal undefined when closed', async () => {
    const handlePress = jest.fn();
    const { rerender } = render(
      <ExpansionPanel {...defaultExpansionPanelProps} onPress={handlePress} />
    );
    const pressable = screen.getByTestId('test:id/expansion-panel--header');
    fireEvent.press(pressable);

    expect(handlePress).toHaveBeenCalledTimes(1);

    rerender(
      <ExpansionPanel
        {...defaultExpansionPanelProps}
        onPress={handlePress}
        isExpanded
      />
    );

    const content = screen.queryByTestId('expaneion-panel-element');
    expect(content).toBeNull();

    fireEvent.press(pressable);

    expect(handlePress).toHaveBeenCalledTimes(2);
  });
});
