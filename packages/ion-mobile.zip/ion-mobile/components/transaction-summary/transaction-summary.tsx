import { formatPensionFunds } from '@src/utils/format-pension-data';
import { getTestId } from '@src/utils/get-test-id';
import { removeLastChar } from '@src/utils/string-manipulation';
import { Pressable } from 'react-native';

import { Text } from '../text';
import {
  CardContainer,
  Container,
  TextContainer,
  TitleTextContainer,
  ValueTextContainer,
} from './transaction-summary-styles';

type FormatNumber = 'capital' | 'percentage';

export type TransactionDataItemProps = {
  title: string;
  value: number | null;
  format?: FormatNumber;
  extraSpace?: boolean;
  onPress?: () => void;
};

type TransactionSummaryProps = {
  items: TransactionDataItemProps[];
  hasBorder?: boolean;
};

const formatValue = (value: number, format?: FormatNumber) => {
  if (format === 'capital') {
    return formatPensionFunds(value);
  }
  if (format === 'percentage') {
    return value + '%';
  }
  return value;
};

export const TransactionSummary = ({
  hasBorder = true,
  items,
}: TransactionSummaryProps) => {
  return (
    <CardContainer hasBorder={hasBorder} testID="transaction-summary">
      {items.map((transactionSummary) => {
        const { title, onPress, value, format, extraSpace } =
          transactionSummary;

        return (
          <Container key={title}>
            <TitleTextContainer>
              {typeof onPress === 'function' ? (
                <Pressable
                  testID={getTestId('transaction-summary-link')}
                  accessibilityRole="link"
                  accessibilityLabel={`${title}`}
                  accessibilityHint="Opens an external page with more details about Investment Charges"
                  onPress={onPress}
                >
                  <TextContainer extraSpace={extraSpace}>
                    <Text
                      fontVariant="small-semibold-Tertiary800"
                      decoration="underline"
                    >
                      {title}
                    </Text>
                  </TextContainer>
                </Pressable>
              ) : (
                <TextContainer extraSpace={extraSpace}>
                  <Text
                    fontVariant="small-regular-DWPrimary500"
                    tamaguiTextProps={{ accessibilityLabel: title }}
                  >
                    {title}
                  </Text>
                </TextContainer>
              )}
            </TitleTextContainer>
            <ValueTextContainer>
              <Text
                fontVariant="body-semibold-Secondary800"
                testID={getTestId(removeLastChar(title))}
              >
                {typeof value === 'number'
                  ? formatValue(value, format)
                  : 'Unavailable'}
              </Text>
            </ValueTextContainer>
          </Container>
        );
      })}
    </CardContainer>
  );
};
