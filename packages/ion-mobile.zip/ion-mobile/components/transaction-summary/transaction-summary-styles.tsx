import { styled, XStack, YStack } from 'tamagui';

const TitleTextContainer = styled(XStack, {
  alignItems: 'flex-start',
  padding: '$md',
});

const ValueTextContainer = styled(XStack, {
  alignItems: 'flex-end',
  padding: '$md',
});

const Container = styled(XStack, {
  justifyContent: 'space-between',
  alignItems: 'center',
});

const CardContainer = styled(YStack, {
  backgroundColor: '$White',
  padding: '$md',
  borderRadius: '$2',
  variants: {
    hasBorder: {
      true: {
        borderColor: '$Gray300',
        borderWidth: '$xxs',
        borderStyle: 'solid',
      },
    },
  } as const,
});

const TextContainer = styled(YStack, {
  variants: {
    extraSpace: {
      true: {
        paddingVertical: '$md',
      },
    },
  } as const,
});

export {
  CardContainer,
  Container,
  TextContainer,
  TitleTextContainer,
  ValueTextContainer,
};
