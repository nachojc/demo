import { fireEvent, render, screen } from '@src/jest/testing-library';

import { TransactionSummary } from '../transaction-summary';

const pressable = jest.fn();

const setup = (hasBorder?: boolean) => {
  render(
    <TransactionSummary
      items={[
        { title: 'Title One', value: 4596 },
        { title: 'Title Two', value: 34332, onPress: pressable },
        { title: 'Title Three', value: null },
        { title: 'Title Four', value: 0 },
      ]}
      hasBorder={hasBorder}
    />
  );
};

it('Should render Transaction Summary', () => {
  setup();

  const transactionSummary = screen.getByTestId('transaction-summary');
  expect(transactionSummary).toBeOnTheScreen();
});

it('Should show correct title/value text', () => {
  setup();

  expect(screen.getByText('Title One')).toBeOnTheScreen();
  expect(screen.getByText('4596')).toBeOnTheScreen();
  expect(screen.getByText('Title Two')).toBeOnTheScreen();
  expect(screen.getByText('34332')).toBeOnTheScreen();
});

it('shows unavailable if value is null or undefined', () => {
  setup();

  expect(screen.getAllByText('Unavailable')).toHaveLength(1);
});

it('shows the correct value if value is 0', () => {
  setup();

  expect(screen.getAllByText('0')).toHaveLength(1);
});

it('Should show non pressable with correct style', () => {
  setup();

  const titleOne = screen.getByText('Title One');
  expect(titleOne).toHaveStyle({
    color: '#141D31',
    fontFamily: 'SourceSansPro-Regular',
    fontSize: 14,
  });
});

it('Should show pressable with correct style', () => {
  setup();

  const titleTwo = screen.getByText('Title Two');
  expect(titleTwo).toHaveStyle({
    color: '#004FB6',
    fontFamily: 'SourceSansPro-SemiBold',
    textDecorationLine: 'underline',
    fontSize: 14,
  });
});

it('Should call onPress when pressable is pressed', () => {
  setup();

  const titleTwo = screen.getByText('Title Two');
  fireEvent.press(titleTwo);
  expect(pressable).toHaveBeenCalledTimes(1);
});

it('Should present with a border', () => {
  setup();

  const transactionSummary = screen.getByTestId('transaction-summary');
  expect(transactionSummary).toHaveStyle({
    borderTopColor: '#CCCCCC',
    borderRightColor: '#CCCCCC',
    borderBottomColor: '#CCCCCC',
    borderLeftColor: '#CCCCCC',
  });
});

it('Should present without a border', () => {
  setup(false);

  const transactionSummary = screen.getByTestId('transaction-summary');
  expect(transactionSummary).not.toHaveStyle({
    borderTopColor: '#CCCCCC',
    borderRightColor: '#CCCCCC',
    borderBottomColor: '#CCCCCC',
    borderLeftColor: '#CCCCCC',
  });
});
