import { render, screen } from '@src/jest/testing-library';
import { LoadingSpinner } from '@aviva/ion-mobile/components/loading-spinner';

jest.mock('../loading-state-spinner.json', () => 'default');

describe('LoadingSpinner', () => {
  it('should resize by half', () => {
    render(<LoadingSpinner size={70} />);

    expect(screen.getByTestId('test:id/loading-spinner-container')).toHaveStyle(
      { width: 70, height: 70 }
    );
    expect(screen.getByTestId('LoadingSpinner')).toHaveStyle({
      width: 100,
      height: 100,
    });
  });
});
