import { getTestId } from '@src/utils/get-test-id';
import Lottie from 'lottie-react-native';
import { Stack } from 'tamagui';

const originalSizeIncludingPadding = 200;
const originalSpinnerSize = 140;

type LoadingSpinnerProps = { size?: number };

// Reusable global loading spinner, keep style inline with design system in Figma:
// https://www.figma.com/file/8CFtMGrVmDa0LH6wcl0sCl/MobileFrameworkMigration?type=design&node-id=1429-23777&mode=design&t=YWFegXHulS1ZKWJq-0
export const LoadingSpinner = ({ size = 120 }: LoadingSpinnerProps) => {
  // This lottie contains padding (30pt) which is problematic. During development,
  // we want to specify a size excluding padding, so we can copy the values directly from Figma.
  // Therefore, we use a parent view to set the required size and center the lottie,
  // then we calculate the size of the lottie required to fit to required size of the spinner.

  const lottieSize =
    originalSizeIncludingPadding * (size / originalSpinnerSize);

  return (
    <Stack
      w={size}
      h={size}
      justifyContent="center"
      alignItems="center"
      testID={getTestId('LoadingSpinnerContainer')}
    >
      <Lottie
        style={{
          width: lottieSize,
          height: lottieSize,
        }}
        source={require('./loading-state-spinner.json')}
        autoPlay
        loop
        resizeMode="contain"
        testID="LoadingSpinner"
      />
    </Stack>
  );
};
