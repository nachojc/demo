import { render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { ScreenReaderOnly } from '../screen-reader-only';

describe('ScreenReaderOnly', () => {
  it('renders text with correcting styling', () => {
    const accessibilityLabel = 'Test Label';
    render(<ScreenReaderOnly accessibilityLabel={accessibilityLabel} />);
    expect(screen.getByText(accessibilityLabel)).toBeOnTheScreen();
    expect(screen.getByTestId(getTestId('screen-reader-only'))).toHaveStyle({
      position: 'absolute',
      top: 0,
      bottom: 0,
      left: 0,
      right: 0,
      marginTop: -1,
      zIndex: -10000,
      overflow: 'hidden',
      opacity: 0.00000001,
    });
  });

  it('renders text with correct styling when includeSelectableEmptySpace prop is true', () => {
    const accessibilityLabel = 'Test Label';
    render(
      <ScreenReaderOnly
        accessibilityLabel={accessibilityLabel}
        includeSelectableEmptySpace
      />
    );
    expect(screen.getByText(accessibilityLabel)).toBeOnTheScreen();
    expect(screen.getByTestId(getTestId('screen-reader-only'))).toHaveStyle({
      position: 'relative',
      width: 'auto',
      height: 'auto',
    });
  });
});
