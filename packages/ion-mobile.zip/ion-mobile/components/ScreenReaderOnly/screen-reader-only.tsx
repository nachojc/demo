import { getTestId } from '@src/utils/get-test-id';
import { Stack, styled, Text } from 'tamagui';

type ScreenReaderOnlyProps = {
  accessibilityLabel: string;

  /**
   * Adds empty space where the label is positioned. This screen reader will select this when reading the label.
   */
  includeSelectableEmptySpace?: boolean;
};

export const ScreenReaderOnly = ({
  accessibilityLabel,
  includeSelectableEmptySpace,
}: ScreenReaderOnlyProps) => {
  return (
    <ScreenReaderOnlyParent
      accessible
      preserveDimensions={includeSelectableEmptySpace}
      testID={`${getTestId('screen-reader-only')}`}
    >
      <Text>{accessibilityLabel}</Text>
    </ScreenReaderOnlyParent>
  );
};

export const ScreenReaderOnlyParent = styled(Stack, {
  position: 'absolute',
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  margin: -1,
  zIndex: -10000,
  overflow: 'hidden',
  opacity: 0.00000001,
  pointerEvents: 'none',

  variants: {
    preserveDimensions: {
      true: {
        position: 'relative',
        width: 'auto',
        height: 'auto',
      },
    },
  } as const,
});
