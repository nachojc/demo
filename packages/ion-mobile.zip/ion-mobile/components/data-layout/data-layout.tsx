import { ReactNode } from 'react';
import { Separator, Stack, StackProps, XStack, YStack } from 'tamagui';

import { TextLinkStyle } from '../dialogs';
import { Text } from '../text';

type DataLayoutItemProps = {
  title: string;
  value: ReactNode;
  multiline?: boolean;
  textLink?: string;
  textLinkOnPress?: () => void;
} & StackProps;

export const DataLayoutItem = ({
  title,
  value,
  multiline,
  textLink,
  textLinkOnPress,
  ...rest
}: DataLayoutItemProps) => {
  const ContainerComp = multiline ? YStack : XStack;
  return (
    <ContainerComp
      alignItems={multiline ? 'baseline' : 'flex-start'}
      my={multiline ? 4 : 0}
      {...rest}
    >
      <Text
        fontVariant="small-regular-Gray800"
        tamaguiTextProps={{
          width: multiline ? 'auto' : '60%',
        }}
      >
        {title}
        {textLink && (
          <TextLinkStyle onPress={textLinkOnPress}>
            <Text fontVariant="small-regular-Tertiary800">{textLink}</Text>
          </TextLinkStyle>
        )}
      </Text>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{
          width: multiline ? 'auto' : '40%',
          textAlign: 'right',
        }}
      >
        {value}
      </Text>
    </ContainerComp>
  );
};

type DataLayoutProps = {
  sections?: {
    id: string;
    heading?: string;
    actions?: ReactNode;
    rows: DataLayoutItemProps[];
  }[];
  children?: ReactNode;
  footer?: ReactNode;
} & StackProps;

export const DataLayout = ({
  sections,
  children,
  footer,
  ...stackProps
}: DataLayoutProps) => (
  <Stack
    bg="white"
    borderColor="$Gray200"
    borderTopWidth={1}
    borderBottomWidth={1}
    p={16}
    marginTop="$-xl"
    {...stackProps}
  >
    {sections ? (
      <YStack>
        {sections.map((section, sectionIndex) => (
          <Stack key={`data-layout-section=${section.id}`}>
            {section.heading ? (
              <XStack alignItems="center">
                <Text
                  fontVariant="heading5-semibold-Secondary800"
                  tamaguiTextProps={{ mb: 12, flex: 1 }}
                >
                  {section.heading}
                </Text>
                {section.actions}
              </XStack>
            ) : null}
            <YStack space={12}>
              {section.rows.map((row, index) => (
                <DataLayoutItem key={`${section.id}-${index}`} {...row} />
              ))}
            </YStack>
            {sections.length !== sectionIndex + 1 && <Separator my={8} />}
          </Stack>
        ))}
      </YStack>
    ) : (
      children
    )}
    {footer}
  </Stack>
);
