import { fireEvent, render, screen } from '@src/jest/testing-library';
import { Button, Pressable, Text, View } from 'react-native';

import { DataLayout } from '../data-layout';

describe('DataLayout', () => {
  it('should render simple options', async () => {
    render(
      <DataLayout
        sections={[
          {
            id: '8590abe0-842b-4687-a18b-30c5c972210c',
            rows: [
              { title: 'Cover level:', value: 'Aviva Online' },
              { title: 'Cover type:', value: 'Comprehensive' },
            ],
          },
        ]}
      />
    );

    expect(await screen.findByText('Cover level:')).toBeOnTheScreen();
    expect(await screen.findByText('Aviva Online')).toBeOnTheScreen();
  });

  it('should render more complex options', async () => {
    const handlePressable = jest.fn();
    const handleBtn = jest.fn();

    render(
      <DataLayout
        footer={
          <View>
            <Text>Footer text</Text>
            <Button onPress={handleBtn} title="Test" testID="testBtn" />
          </View>
        }
        sections={[
          {
            id: 'ee7fe8c0-4a52-4bd7-bb08-e22b6ed7573d',
            heading: 'Further details',
            actions: (
              <Pressable onPress={handlePressable} testID="testPressable" />
            ),
            rows: [
              { title: 'Cover level:', value: 'Aviva Online', multiline: true },
              { title: 'Cover type:', value: 'Comprehensive', multiline: true },
              {
                title: 'No claims discount:',
                value: '3 years not protected',
                multiline: true,
              },
            ],
          },
          {
            id: '6928d9fa-0366-49b8-a7e9-e38711a9555b',
            heading: 'Payment allocation:',
            rows: [
              { title: 'Aviva Pension Property Fund:', value: '65%' },
              { title: 'Aviva Mixed Bond Fund:', value: '20%' },
              { title: 'Aviva Global Equity Fund:', value: '15%' },
            ],
          },
        ]}
      />
    );

    fireEvent.press(screen.getByTestId('testPressable'));
    expect(handlePressable).toHaveBeenCalledTimes(1);

    fireEvent.press(screen.getByTestId('testBtn'));
    expect(handleBtn).toHaveBeenCalledTimes(1);

    expect(await screen.findByText('Footer text')).toBeOnTheScreen();
    expect(await screen.findByText('Further details')).toBeOnTheScreen();
    expect(
      await screen.findByText('Aviva Pension Property Fund:')
    ).toBeOnTheScreen();
    expect(await screen.findByText('65%')).toBeOnTheScreen();
  });
});
