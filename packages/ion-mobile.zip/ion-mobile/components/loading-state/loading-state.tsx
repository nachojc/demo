import { I18nKeys } from '@src/i18n/types';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { useTranslation } from 'react-i18next';
import { StackProps, YStack } from 'tamagui';

import { FocusAwareStatusBar } from '../focus-aware-status-bar';
import { FullScreenLoadingState } from './fullscreen-loading-state';
import { LoadingStateContent } from './loading-state-content';

export type LoadingKeys = I18nKeys<'loading'>;

type LoadingStateProps = {
  text?: LoadingKeys;
  fullscreen?: boolean;
} & StackProps;

export const LoadingState = ({
  fullscreen = !isIpad,
  text,
  ...stackProps
}: LoadingStateProps) => {
  const { t } = useTranslation();

  const Content = (
    <LoadingStateContent
      text={text ? t(`loading.${text}`) : undefined}
      {...stackProps}
    />
  );

  return (
    <>
      <FocusAwareStatusBar style="light" />
      {fullscreen ? (
        <FullScreenLoadingState>{Content}</FullScreenLoadingState>
      ) : (
        <YStack
          pos="absolute"
          w="100%"
          h="100%"
          ai="center"
          jc="center"
          flex={1}
          zi={9999999}
          testID={getTestId('loading-view')}
        >
          {Content}
        </YStack>
      )}
    </>
  );
};
