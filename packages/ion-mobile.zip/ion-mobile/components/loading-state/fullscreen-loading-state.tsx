import { getTestId } from '@src/utils/get-test-id';
import { PropsWithChildren } from 'react';
import { Dialog } from 'tamagui';

export const FullScreenLoadingState = ({ children }: PropsWithChildren) => (
  <Dialog modal defaultOpen>
    <Dialog.Portal testID={getTestId('loading-modal')}>
      <Dialog.Overlay
        key="overlay"
        // TODO Temporary fix whilst we work out test config needed
        animation={process.env.NODE_ENV === 'test' ? null : 'fast'}
        backgroundColor="$Gray900"
        enterStyle={{ o: 0 }}
        opacity={0.67}
        exitStyle={{ o: 0 }}
      />
      <Dialog.Content key="content" borderRadius={8}>
        {children}
      </Dialog.Content>
    </Dialog.Portal>
  </Dialog>
);
