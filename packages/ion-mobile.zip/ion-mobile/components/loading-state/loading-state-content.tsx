import { isIpad } from '@src/utils/is-ipad';
import { Stack, StackProps, YStack } from 'tamagui';

import { LoadingSpinner } from '../loading-spinner';
import { Text } from '../text';

type Props = { text?: string } & StackProps;

const tabletModalWidth = 311;

export const LoadingStateContent = ({ text, ...stackProps }: Props) => (
  <YStack
    py="$xxxl"
    px="$xl"
    maxWidth={isIpad ? tabletModalWidth : '90%'}
    minWidth={isIpad ? tabletModalWidth : '60%'}
    bg="$White"
    borderRadius={8}
    accessibilityLabel={text}
    accessibilityRole="image"
    {...stackProps}
  >
    <Stack jc="center" ai="center">
      <LoadingSpinner />
    </Stack>
    {text && (
      <YStack mt="$xxl">
        <Text
          fontVariant="small-regular-Gray800"
          tamaguiTextProps={{ textAlign: 'center' }}
        >
          {text}
        </Text>
      </YStack>
    )}
  </YStack>
);
