import { getTestId } from '@src/utils/get-test-id';
import { Circle, Svg } from 'react-native-svg';
import { getTokens, Stack, YStack } from 'tamagui';

import { Text } from '../text';
import { RoundelSizeProp } from './roundel';
import { getRoundelColor } from './utils';

export type RoundelWithoutAnimationProps = {
  value: number;
  size: RoundelSizeProp;
};
const tokens = getTokens();
export const roundelWithoutAnimationDefaultProps = (size: RoundelSizeProp) => {
  switch (size) {
    case 'small':
      return {
        radius: 30,
        fontVariant: `body-semibold-Secondary900`,
        textColor: tokens.color.$Secondary900.val,
        strokeWidth: 4,
      } as const;
    case 'large':
      return {
        radius: 76,
        fontVariant: 'heading1-regular-Secondary900',
        strokeWidth: 10,
      } as const;
    case 'medium':
    default:
      return {
        radius: 53,
        fontVariant: `heading1-regular-Secondary900`,
        strokeWidth: 5,
      } as const;
  }
};

export const RoundelWithoutAnimation = (
  props: RoundelWithoutAnimationProps
) => {
  const { value, size = 'medium' } = props;

  const progressAdjustment = () => {
    switch (true) {
      case value <= 5:
        return value;
      case value >= 25 && value < 50:
        return value - 2;
      case value >= 75 && value < 83:
        return value - 3;
      case value >= 95 && value < 98:
        return value - 6;
      case value === 98:
        return value - 6.5;
      case value === 99:
        return value - 6.5;
      default:
        return value - 4;
    }
  };
  const { radius, fontVariant, strokeWidth } =
    roundelWithoutAnimationDefaultProps(size);
  const circumference = Math.round(2 * Math.PI * radius);
  const activeCircumference = progressAdjustment() / 100;
  const strokeDashboffset = Math.round(
    circumference - (circumference - 4) * activeCircumference
  );
  return (
    <YStack
      justifyContent="center"
      alignItems="center"
      testID={getTestId('roundel')}
    >
      <Svg height={radius * 2} width={radius * 2}>
        <Circle
          cx={radius}
          cy={radius}
          r={radius - strokeWidth / 2}
          fill="none"
          stroke={tokens.color.$Gray300.val}
          strokeWidth={strokeWidth}
        />
        <Circle
          cx={radius}
          cy={radius}
          r={radius - strokeWidth / 2}
          origin={`${radius}, ${radius}`}
          rotation={`-90`}
          fill="none"
          stroke={getRoundelColor(value)} //ProgressColor
          strokeLinecap="round"
          strokeWidth={strokeWidth}
          strokeDasharray={`${circumference} ${circumference}`}
          strokeDashoffset={strokeDashboffset}
        />
      </Svg>
      <Stack position="absolute">
        <Text fontVariant={fontVariant}>{value}</Text>
      </Stack>
    </YStack>
  );
};
