import { getTokens } from 'tamagui';

export const getRoundelColor = (value: number) => {
  const tokens = getTokens();
  if (value > 0 && value < 59) {
    return tokens.color.$Error.val;
  }
  if (value >= 59 && value < 80) {
    return tokens.color.$Warning.val;
  }
  return tokens.color.$Success.val;
};
