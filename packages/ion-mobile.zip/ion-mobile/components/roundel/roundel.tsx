import { getTestId } from '@src/utils/get-test-id';
import { memo } from 'react';
import CircularProgress from 'react-native-circular-progress-indicator';
import { getTokens, Stack } from 'tamagui';

import { getRoundelColor } from './utils';

export type RoundelSizeProp = 'large' | 'medium' | 'small';
export type RoundelProps = {
  value: number;
  initialValue?: number;
  size: RoundelSizeProp;
};
const tokens = getTokens();

export const roundelDefaultProps = (size: RoundelSizeProp) => {
  switch (size) {
    case 'small':
      return {
        radius: 30,
        fontWeight: '600',
        color: tokens.color.$Secondary900.val,
        activeStrokeWidth: 5,
        inActiveStrokeWidth: 5,
      } as const;
    case 'large':
      return {
        radius: 76,
        fontWeight: '400',
        duration: 2000,
        color: tokens.color.$Secondary900.val,
        activeStrokeWidth: 10,
        inActiveStrokeWidth: 10,
      } as const;
    case 'medium':
    default:
      return {
        radius: 53,
        fontWeight: '400',
        duration: 2000,
        color: tokens.color.$Secondary900.val,
        activeStrokeWidth: 8,
        inActiveStrokeWidth: 8,
      } as const;
  }
};

export const Roundel = memo((props: RoundelProps) => {
  const { value, initialValue = 0, size = 'medium' } = props;
  const { radius, inActiveStrokeWidth, activeStrokeWidth, duration, ...rest } =
    roundelDefaultProps(size);

  return (
    <Stack testID={getTestId('roundel')}>
      <CircularProgress
        value={value}
        initialValue={initialValue}
        radius={radius}
        duration={duration}
        activeStrokeWidth={activeStrokeWidth}
        inActiveStrokeWidth={inActiveStrokeWidth}
        inActiveStrokeColor={tokens.color.$Gray300.val}
        progressValueStyle={{ ...rest }}
        activeStrokeColor={getRoundelColor(value)}
      />
    </Stack>
  );
});
Roundel.displayName = 'Roundel';
