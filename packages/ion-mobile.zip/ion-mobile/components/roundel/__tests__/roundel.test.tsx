import { render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';
import { getTokens } from 'tamagui';

import { Roundel, roundelDefaultProps } from '../roundel';
import { getRoundelColor } from '../utils';

jest.unmock('react-native-reanimated');

const tokens = getTokens();

describe('Roundel', () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  it('renders with the default props', () => {
    render(<Roundel value={50} size="small" />);

    expect(screen.getByTestId(getTestId('roundel'))).toBeOnTheScreen();
  });
});

describe('roundelDefaultProps', () => {
  it('returns the correct props for the small size', () => {
    const size = 'small';
    const result = roundelDefaultProps(size);

    const expectProps = {
      radius: 30,
      fontWeight: '600',
      color: tokens.color.$Secondary900.val,
      activeStrokeWidth: 5,
      inActiveStrokeWidth: 5,
    };
    expect(result).toEqual(expectProps);
  });

  it('returns the correct props for the large size', () => {
    const size = 'large';
    const result = roundelDefaultProps(size);

    const expectProps = {
      radius: 76,
      fontWeight: '400',
      duration: 2000,
      color: tokens.color.$Secondary900.val,
      activeStrokeWidth: 10,
      inActiveStrokeWidth: 10,
    };
    expect(result).toEqual(expectProps);
  });
});

describe('getRoundelColor', () => {
  it.each([1, 58])(
    'returns red colour when value is between 0 and 58',
    (value) => {
      const result = getRoundelColor(value);
      const expectedColor = tokens.color.$Error.val;
      expect(result).toBe(expectedColor);
    }
  );
  it.each([59, 79])(
    'returns orange colour when value is between 59 and 80',
    (value) => {
      const result = getRoundelColor(value);
      const expectedColor = tokens.color.$Warning.val;
      expect(result).toBe(expectedColor);
    }
  );
  it.each([80, 100])(
    'returns green colour when value is between above 80',
    (value) => {
      const result = getRoundelColor(value);
      const expectedColor = tokens.color.$Success.val;
      expect(result).toBe(expectedColor);
    }
  );
});
