import { render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';
import { getTokens } from 'tamagui';

import {
  RoundelWithoutAnimation as Roundel,
  roundelWithoutAnimationDefaultProps,
} from '../roundel-without-animation';
import { getRoundelColor } from '../utils';

const tokens = getTokens();

describe('Roundel without animation', () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  it('renders with the default props', () => {
    render(<Roundel value={50} size="small" />);

    expect(screen.getByTestId(getTestId('roundel'))).toBeOnTheScreen();
  });
});

describe('roundelDefaultProps', () => {
  it('returns the correct props for the small size', () => {
    const size = 'small';
    const result = roundelWithoutAnimationDefaultProps(size);

    const expectProps = {
      radius: 30,
      fontVariant: `body-semibold-Secondary900`,
      textColor: tokens.color.$Secondary900.val,
      strokeWidth: 4,
    };
    expect(result).toEqual(expectProps);
  });

  it('returns the correct props for the large size', () => {
    const size = 'large';
    const result = roundelWithoutAnimationDefaultProps(size);

    const expectProps = {
      radius: 76,
      fontVariant: 'heading1-regular-Secondary900',
      strokeWidth: 10,
    };
    expect(result).toEqual(expectProps);
  });
});

describe('getRoundelColor', () => {
  it.each([1, 58])(
    'returns red colour when value is between 0 and 58',
    (value) => {
      const result = getRoundelColor(value);
      const expectedColor = tokens.color.$Error.val;
      expect(result).toBe(expectedColor);
    }
  );
  it.each([59, 79])(
    'returns orange colour when value is between 59 and 80',
    (value) => {
      const result = getRoundelColor(value);
      const expectedColor = tokens.color.$Warning.val;
      expect(result).toBe(expectedColor);
    }
  );
  it.each([80, 100])(
    'returns green colour when value is between above 80',
    (value) => {
      const result = getRoundelColor(value);
      const expectedColor = tokens.color.$Success.val;
      expect(result).toBe(expectedColor);
    }
  );
});
