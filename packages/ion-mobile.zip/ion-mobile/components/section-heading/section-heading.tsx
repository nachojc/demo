import { getTokens, getVariableValue } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text';
import { Container, PressableContainer } from './section-heading.style';

type SectionHeadingProps = {
  heading: string;
  linkTitle?: string;
  showIcon?: boolean;
  onPress?: () => void;
  variant?: 'transaction';
};

export const SectionHeading = ({
  heading,
  showIcon,
  onPress,
  linkTitle,
  variant,
}: SectionHeadingProps) => {
  const tokens = getTokens();

  return (
    <Container testID="section-heading-container" variant={variant}>
      {variant === 'transaction' ? (
        <Text
          tamaguiTextProps={{ letterSpacing: 1 }}
          fontVariant="small-regular-Gray900"
        >
          {heading}
        </Text>
      ) : (
        <Text fontVariant="heading5-semibold-Secondary800">{heading}</Text>
      )}
      <PressableContainer
        onPress={onPress}
        accessibilityLabel="section-heading-pressable"
      >
        <Text fontVariant="body-semibold-Tertiary800">{linkTitle}</Text>
        {showIcon && (
          <Icon
            name="chevron-right"
            color={getVariableValue(tokens.color.Tertiary800)}
          />
        )}
      </PressableContainer>
    </Container>
  );
};
