import { styled, XStack } from 'tamagui';

const Container = styled(XStack, {
  justifyContent: 'space-between',
  paddingVertical: '$xl',
  variants: {
    variant: {
      transaction: {
        backgroundColor: '$Gray050',
        paddingVertical: '$xl',
        paddingHorizontal: '$xl',
      },
    },
  } as const,
});

const PressableContainer = styled(XStack, {
  alignItems: 'center',
});

export { Container, PressableContainer };
