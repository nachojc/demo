import { fireEvent, render, screen } from '@src/jest/testing-library';

import { SectionHeading } from '../section-heading';

const mockOnPress = jest.fn();

const setup = (props: { showIcon?: boolean; variant?: 'transaction' } = {}) => {
  render(
    <SectionHeading
      heading="heading test"
      linkTitle="description test"
      onPress={mockOnPress}
      {...props}
    />
  );
};

it('Should render section heading', () => {
  setup();

  const sectionHeadingContainer = screen.getByTestId(
    'section-heading-container'
  );
  expect(sectionHeadingContainer).toBeOnTheScreen();
});

it('Should render Section Heading with heading, linkTitle and icon', () => {
  setup();

  const [title, description] = screen.getAllByRole('text');
  expect(title).toHaveTextContent('heading test');
  expect(description).toHaveTextContent('description test');
});

it('Should not render icon if showIcon is false', () => {
  setup({ showIcon: false });

  const icon = screen.queryByRole('chevron-right');
  expect(icon).toBeNull();
});

it('Should call onPress when linkTitle/icon is pressed', () => {
  setup();

  const textIconRight = screen.getByLabelText('section-heading-pressable');
  fireEvent.press(textIconRight);
  expect(mockOnPress).toHaveBeenCalledTimes(1);
});

it('Should render the correct title and styling when variant is transaction', () => {
  setup({ showIcon: false, variant: 'transaction' });

  const [title] = screen.getAllByRole('text');
  const sectionHeadingContainer = screen.getByTestId(
    'section-heading-container'
  );
  expect(title).toHaveTextContent('heading test');
  expect(sectionHeadingContainer).toHaveStyle({
    backgroundColor: '#F9F9F9',
  });
});
