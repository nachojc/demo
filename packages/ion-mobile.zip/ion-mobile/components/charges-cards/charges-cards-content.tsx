import { XStack } from 'tamagui';

import { Text } from '../text';
import { ChargesCardContent } from './charges-cards.style';

export const AvivaContent = () => {
  return (
    <ChargesCardContent>
      <Text fontVariant="body-regular-Gray800">
        This is our annual charge for holding your assets. You&apos;ll pay an
        Aviva Charge of up to 0.40% of the total value of funds and cash held in
        the Aviva Pension, ISA and Investment Account. This is calculated daily
        and taken monthly from each product separately. The more money you
        invest with us, the lower the percentage you&apos;ll pay.
      </Text>

      <Text tamaguiTextProps={{ mt: '$xl' }} fontVariant="body-bold-Gray800">
        Annual charges:
      </Text>

      <Text fontVariant="body-regular-Gray800">First £50,000 - 0.40%</Text>
      <Text fontVariant="body-regular-Gray800">Next £200,000 - 0.35%</Text>
      <Text fontVariant="body-regular-Gray800">Next £250,000 - 0.25%</Text>
      <Text fontVariant="body-regular-Gray800">Over £500,000 - 0%</Text>

      <Text tamaguiTextProps={{ mt: '$xl' }} fontVariant="body-regular-Gray800">
        This means that if you hold assets of £10,000 with us you&apos;d pay £40
        a year.
      </Text>
    </ChargesCardContent>
  );
};

export const FundManagementContent = () => {
  return (
    <ChargesCardContent>
      <Text fontVariant="body-regular-Gray800">
        A fund is like a {'\u2018'}basket{'\u2019'} of different investments
        chosen by a professional fund manager, who is responsible for managing
        the {'\u2018'}basket{'\u2019'} and how it performs. Funds make it quick
        to start investing even if you don&apos;t have much experience.{'\n\n'}
        We won&apos;t charge you for buying and selling funds, but each fund has
        an annual charge, which is included in the price of the fund.
        You&apos;ll be able to see it when you choose your investments.{'\n\n'}
        You can find the Fund Manager Charge in the Key Investor Information
        Document (KIID) and you&apos;ll see it on your statement, as an ongoing
        charges figure (OCF).
      </Text>
    </ChargesCardContent>
  );
};

export const SharesContent = () => {
  return (
    <ChargesCardContent>
      <Text fontVariant="body-regular-Gray800">
        Share dealing is buying and selling equities in public listed companies
        and other exchange traded investments (ETIs). These include shares,
        Exchange Traded Funds (ETFs) and Investment Trusts. ETIs are charged for
        separately from the Aviva Charge:
      </Text>

      <XStack mr="$xxl">
        <Text
          tamaguiTextProps={{ width: '$xl', ml: '$md' }}
          fontVariant="body-bold-Gray800"
        >
          {'\u2022'}
        </Text>
        <Text fontVariant="body-regular-Gray800">
          <Text fontVariant="body-bold-Gray800">Aviva Share Charge</Text> -
          annual charge of 0.40% of the investment value (max £120)
        </Text>
      </XStack>

      <XStack mr="$xxl">
        <Text
          tamaguiTextProps={{ width: '$xl', ml: '$md' }}
          fontVariant="body-bold-Gray800"
        >
          {'\u2022'}
        </Text>
        <Text fontVariant="body-regular-Gray800">
          <Text fontVariant="body-bold-Gray800">Trading charge</Text> - £7.50
          each time you buy or sell
        </Text>
      </XStack>

      <XStack mr="$xxl">
        <Text
          tamaguiTextProps={{ width: '$xl', ml: '$md' }}
          fontVariant="body-bold-Gray800"
        >
          {'\u2022'}
        </Text>
        <Text fontVariant="body-regular-Gray800">
          <Text fontVariant="body-bold-Gray800">Other charges</Text> - ETFs and
          Investment Trusts will have fund-specific charges which will be shown
          in the fund documentation
        </Text>
      </XStack>

      <Text tamaguiTextProps={{ mt: '$xl' }} fontVariant="body-regular-Gray800">
        If you want to use this service, you can do so once your transfer is
        complete.
      </Text>
    </ChargesCardContent>
  );
};
