import { tokens } from '@src/theme/tokens';
import { styled, YStack } from 'tamagui';

export const ChargesCardContent = styled(YStack, {
  margin: tokens.space.xl,
});
