import { Stack, YStack } from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { ReactNode } from 'react';
import { useWindowDimensions } from 'react-native';

import { ChargesCard } from '../cards';
import { Carousel } from '../carousel';
import { Variant } from './../header';
import {
  AvivaContent,
  FundManagementContent,
  SharesContent,
} from './charges-cards-content';

type ChargesCardDataItem = {
  title: string;
  variant?: Variant;
  content: () => ReactNode;
};

type ChargesCardData = ChargesCardDataItem[];

type ChargesProps = {
  analyticTag?: string;
};

type CardProps = {
  index: number;
  item: ChargesCardDataItem;
  cardWidth?: number;
  cardHeight?: number;
};

const chargesCardData: ChargesCardData = [
  { title: 'Aviva Charge', content: AvivaContent },
  {
    title: 'Fund Management Charge',
    variant: 'directWealth',
    content: FundManagementContent,
  },
  {
    title: 'Charges for share holding and dealing',
    variant: 'tertiary800',
    content: SharesContent,
  },
];

const Card = ({ item, cardWidth, cardHeight, index }: CardProps) => (
  <YStack
    marginRight={isIpad ? undefined : '$xl'}
    pb={isIpad ? '$xl' : undefined}
    width={cardWidth}
    testID={getTestId(`charges-card-${index}`)}
  >
    <ChargesCard
      headerTitle={item.title}
      variant={item.variant}
      minHeight={cardHeight}
    >
      {item.content()}
    </ChargesCard>
  </YStack>
);

export const ChargesCards = ({ analyticTag }: ChargesProps) => {
  const { width: screenWidth } = useWindowDimensions();

  const cardWidth = screenWidth - 48;
  let carouselHeight = 530;

  if (screenWidth <= 380) {
    carouselHeight = 570;
  }

  const cardHeight = carouselHeight - 82;

  const analytics = useAnalytics();

  return isIpad ? (
    <YStack testID={getTestId('ChargesCardStack')}>
      {chargesCardData.map((item, index) => (
        <Card key={`${item.title}-${index}`} item={item} index={index} />
      ))}
    </YStack>
  ) : (
    <Carousel
      testID={getTestId('ChargesCardsCarousel')}
      height={carouselHeight + 10}
      contentWidth={cardWidth}
      onNext={
        analyticTag ? () => analytics.trackUserEvent(analyticTag) : undefined
      }
      onPrev={
        analyticTag ? () => analytics.trackUserEvent(analyticTag) : undefined
      }
      showDots
    >
      {chargesCardData.map((item, index) => (
        <Stack key={`${item.title}-${index}`}>
          <Card
            item={item}
            index={index}
            cardWidth={cardWidth}
            cardHeight={cardHeight}
          />
        </Stack>
      ))}
    </Carousel>
  );
};
