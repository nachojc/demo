import { render, screen } from '@src/jest/testing-library';
import * as isIpadModule from '@src/utils/is-ipad';

import { ChargesCards } from '../charges-cards';

jest.mock('@src/utils/is-ipad');

describe('ChargesCards component', () => {
  it('should render it correctly', () => {
    render(<ChargesCards />);
    const cardsTitles = [
      'Aviva Charge',
      'Fund Management Charge',
      'Charges for share holding and dealing',
    ];

    cardsTitles.forEach((title) => {
      expect(
        screen.getByText(title, { includeHiddenElements: true })
      ).toBeOnTheScreen();
    });
  });

  it('should render carousel correctly in mobile', () => {
    (isIpadModule as any).isIpad = false;

    render(<ChargesCards />);

    expect(
      screen.getByTestId('test:id/charges-cards-carousel')
    ).toBeOnTheScreen();
  });

  it('should render stack correctly in iPad', () => {
    (isIpadModule as any).isIpad = true;

    render(<ChargesCards />);

    expect(screen.getByTestId('test:id/charges-card-stack')).toBeOnTheScreen();
  });
});
