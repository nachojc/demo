import { icons } from '@assets';
import { tokens } from '@theme/tokens';
import { getTestId } from '@utils/get-test-id';
import { SvgProps } from 'react-native-svg';

export type IconName = keyof typeof icons;

type IconProps = SvgProps & { name: IconName };

/**
 * Icon component which return an SVG icon.
 *
 * The icon can be styled inline with the help of `fill`, `stroke` and `color` props.
 * The `color` represents a general theme and corresponds to `currentColor` value in SVG.
 * This is usually the general color of the icon and can be applied to both stroke and fill.
 * For a more granular control use `fill` and `stroke` to style these attributes separately.
 * The icons generally set the default values for those attributes at the root of the SVG which
 * allows them to be overridden by this component.
 *
 * The `fill` and `stroke` props override the `color` prop.
 */

export const Icon = ({
  name,
  width,
  height,
  color,
  accessibilityRole,
  accessibilityElementsHidden,
  importantForAccessibility,
  testID,
  ...props
}: IconProps) => {
  let SvgIcon = icons[name];
  let defaultSvgProps: SvgProps = {};

  // Icons declared as tuples can pass initial custom properties
  if (Array.isArray(SvgIcon)) {
    [SvgIcon, defaultSvgProps] = SvgIcon;
  }

  // The order of overriding props is: defaultSvgProps -> Icon props -> default values
  const iconProps = {
    ...defaultSvgProps,
    ...props,
    // Order of overriding prop we want to set a default value:
    // prop -> defaultSvgProp -> default value
    color: color ?? defaultSvgProps.color ?? tokens.color.Secondary800.val,
    width: width ?? defaultSvgProps.width ?? tokens.size[6].val,
    height: height ?? defaultSvgProps.height ?? tokens.size[6].val,
    accessibilityRole:
      accessibilityRole ?? defaultSvgProps.accessibilityRole ?? 'image',
    accessibilityElementsHidden:
      accessibilityElementsHidden ??
      defaultSvgProps.accessibilityElementsHidden ??
      true,
    importantForAccessibility:
      importantForAccessibility ??
      defaultSvgProps.importantForAccessibility ??
      'no',
    testID: getTestId(`icon-${testID ?? defaultSvgProps.testID ?? name}`),
    key: name,
  };

  if (typeof SvgIcon === 'function') {
    return <SvgIcon {...iconProps} />;
  }

  throw new Error(`Icon '${name}' was not found.`);
};
