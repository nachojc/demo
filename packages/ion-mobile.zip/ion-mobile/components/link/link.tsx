import { getTestId } from '@src/utils/get-test-id';
import { Pressable } from 'react-native';
import {
  getTokens,
  getVariableValue,
  styled,
  Text,
  TextProps,
  XStack,
  XStackProps,
} from 'tamagui';

import { Icon, IconName } from '../icon';

type LinkVariant = 'link' | 'dwPrimaryLink';
type LinkTextProps = TextProps & { variant?: LinkVariant };
type Props = XStackProps & {
  variant?: LinkVariant;
  icon?: IconName;
  LinkTextProps?: LinkTextProps;
};

export const Link = ({
  variant = 'link',
  disabled = false,
  icon,
  onPress,
  children,
  LinkTextProps,
  ...containerProps
}: Props) => {
  const tokens = getTokens();

  return (
    <StyledLink variant={variant} disabled={disabled} {...containerProps}>
      <Pressable
        testID={getTestId('link-pressable')}
        accessible
        accessibilityRole={containerProps.accessibilityRole ?? 'link'}
        accessibilityLabel={typeof children === 'string' ? children : undefined}
        accessibilityHint={typeof children === 'string' ? children : undefined}
        onPress={onPress}
        disabled={disabled}
      >
        {icon ? (
          <Icon
            name={icon}
            color={getVariableValue(tokens.color.Secondary800)}
          />
        ) : (
          <LinkText variant={variant} disabled={disabled} {...LinkTextProps}>
            {children}
          </LinkText>
        )}
      </Pressable>
    </StyledLink>
  );
};

const StyledLinkParent = styled(XStack, {
  backgroundColor: 'transparent',
  padding: '$0',
  margin: '$0',
  alignSelf: 'baseline',
  alignItems: 'flex-start',
  justifyContent: 'center',
  borderRadius: 55,
  pressStyle: {
    backgroundColor: 'transparent',
  },

  variants: {
    variant: {
      link: {},
      dwPrimaryLink: {
        backgroundColor: 'transparent',
        padding: '$0',
        margin: '$0',
        alignSelf: 'baseline',
        alignItems: 'center',
        pressStyle: {
          backgroundColor: 'transparent',
        },
      },
    },
  } as const,
});

const StyledLink = styled(StyledLinkParent, {
  variants: {
    disabled: (val: boolean) => {
      if (val) {
        return {
          backgroundColor: 'transparent',
          borderColor: undefined,
        };
      }
      return null;
    },
  },
});

const LinkTextParent = styled(Text, {
  color: '$Secondary800',
  fontFamily: '$body',
  fontSize: '$body',
  fontWeight: '600',

  variants: {
    variant: {
      link: { color: '$Tertiary800' },
      dwPrimaryLink: { color: '$Primary500' },
    },
  },
});

export const LinkText = styled(LinkTextParent, {
  variants: {
    disabled: (val: boolean) => {
      if (val) {
        return {
          color: '$Gray300',
        };
      }
      return null;
    },
  },
});
