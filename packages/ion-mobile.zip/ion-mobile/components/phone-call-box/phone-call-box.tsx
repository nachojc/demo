import { useAnalytics } from '@hooks/use-analytics';
import { removePhoneNumberFormatting } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import { callPhoneNumber } from '@src/utils/phone-link';
import { splitPhoneNumber } from '@src/utils/phone-number';
import { useState } from 'react';
import { Stack, StackProps, XStack } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text';
import { PhoneCallDialog } from './phone-call-dialog';

type PhoneTags = Partial<{
  onCall: string;
  onOpen: string;
  onCancel: string;
}>;

const getDefaultTags = (tag?: string): PhoneTags | undefined => {
  if (!tag) {
    return undefined;
  }
  const baseTag = tag.includes('|')
    ? tag.substring(0, tag.lastIndexOf('|'))
    : tag;
  return {
    onCall: `${baseTag}|call-tapped`,
    onOpen: tag,
    onCancel: `${baseTag}|cancel-tapped`,
  };
};

export type PhoneCallBoxProps = {
  isLoading?: boolean;
  callUs?: boolean;
  containerProps?: StackProps;
  phone?: string;
  text?: string;
  hasDialog?: boolean; // Show a `confirm/cancel` dialog before calling,
  tags?: PhoneTags;
  isError?: boolean;
};

export const PhoneCallBox = ({
  isLoading,
  callUs,
  containerProps,
  phone = '',
  text = 'call us',
  hasDialog = true,
  tags,
  isError,
}: PhoneCallBoxProps) => {
  const { trackUserEvent } = useAnalytics();
  const [showDialog, setShowDialog] = useState(false);

  if (isIpad) {
    hasDialog = false;
    phone = splitPhoneNumber(phone);
    text = text === 'Call us' ? `Call ${phone}` : `call ${phone}`;
  }

  const handlePress = () => (hasDialog ? setShowDialog(true) : onCall());

  const finalTags = { ...getDefaultTags(tags?.onOpen), ...tags };

  const onCall = () => {
    if (isIpad) {
      return;
    }
    if (hasDialog) {
      setShowDialog(false);
    }

    finalTags?.onCall && trackUserEvent(finalTags.onCall);

    callPhoneNumber(phone);
  };

  const getFontVariant = () => {
    if (isIpad) {
      return isError ? 'body-regular-Error' : 'body-regular-Gray800';
    }

    return 'body-semibold-Tertiary800';
  };

  return (
    <>
      {callUs ? (
        <Text
          tamaguiTextProps={{
            testID: getTestId('call-us-modal-container'),
            onPress: () => handlePress(),
          }}
          fontVariant={getFontVariant()}
          decoration={text === 'Call us' || isIpad ? 'none' : 'underline'}
        >
          {isLoading ? 'Loading ...' : text}
        </Text>
      ) : (
        <XStack
          testID={getTestId('phone-container')}
          justifyContent="space-between"
          alignItems="center"
          padding="$xl"
          backgroundColor="$White"
          borderBottomColor="$Gray300"
          borderBottomWidth={1}
          borderTopColor="$Gray300"
          borderTopWidth={1}
          marginHorizontal="$-xl"
          onPress={() => handlePress()}
          accessible
          accessibilityLabel={`Phone number ${removePhoneNumberFormatting(
            phone
          )}`}
          accessibilityHint="Call this number"
          accessibilityRole="button"
          {...containerProps}
        >
          <Text
            fontVariant="body-semibold-Secondary800"
            testID={getTestId('phone-number')}
            tamaguiTextProps={{ ml: '$xl', f: 1 }}
          >
            {isLoading ? 'Loading ...' : phone}
          </Text>
          <Stack marginRight="$xl">
            <Icon name="phone" />
          </Stack>
        </XStack>
      )}
      {hasDialog && (
        <PhoneCallDialog
          phone={phone}
          open={!isIpad && showDialog}
          tags={finalTags}
          onCallPress={() => onCall()}
          onCancelPress={() => {
            finalTags?.onCancel && trackUserEvent(finalTags.onCancel);
            setShowDialog(false);
          }}
        />
      )}
    </>
  );
};
