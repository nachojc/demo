import {
  fireEvent,
  mockTrackUserEvent,
  render,
  screen,
  waitFor,
} from '@src/jest/testing-library';
import { Linking } from 'react-native';

import { PhoneCallBox } from '../phone-call-box';

const number = '0555765';

const mockMakeCall = jest
  .spyOn(Linking, 'openURL')
  .mockImplementation(() => Promise.resolve());

describe('Phone Call Box', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render the phone number', () => {
    render(<PhoneCallBox phone={number} />);

    expect(screen.getByTestId('test:id/phone-number')).toHaveTextContent(
      number
    );
  });

  it('should call the phone number directly and send analytics based on actionTag', async () => {
    render(
      <PhoneCallBox
        phone={number}
        tags={{ onOpen: 'analyticsTag' }}
        hasDialog={false}
      />
    );

    fireEvent.press(screen.getByText('0555765'));

    await waitFor(() => {
      expect(mockMakeCall).toHaveBeenCalledWith(`tel:${number}`);
    });
    expect(mockTrackUserEvent).toHaveBeenCalledWith('analyticsTag|call-tapped');
  });

  it('should call the phone number throughout the dialog and send analytics based on actionTag', async () => {
    render(<PhoneCallBox phone={number} tags={{ onOpen: 'analyticsTag' }} />);

    fireEvent.press(screen.getByText('0555765'));
    fireEvent.press(screen.getByAccessibilityHint('Call Help'));

    await waitFor(() => {
      expect(mockMakeCall).toHaveBeenCalledWith(`tel:${number}`);
    });
    expect(mockTrackUserEvent).toHaveBeenCalledWith('analyticsTag');
  });

  it('should not send analytics if action tag is not present throughout the dialog', () => {
    render(<PhoneCallBox phone={number} />);

    fireEvent.press(screen.getByText('0555765'));

    expect(mockTrackUserEvent).not.toHaveBeenCalled();

    fireEvent.press(screen.getByAccessibilityHint('Call Help'));

    expect(mockTrackUserEvent).not.toHaveBeenCalled();
  });

  it('should not send analytics if action tag is not present directly', () => {
    render(<PhoneCallBox phone={number} hasDialog={false} />);

    fireEvent.press(screen.getByText('0555765'));

    expect(mockTrackUserEvent).not.toHaveBeenCalled();
  });

  it('should track user event with the action tag specified', () => {
    render(<PhoneCallBox phone={number} tags={{ onOpen: 'action|tag' }} />);

    fireEvent.press(screen.getByTestId('test:id/phone-container'));
    fireEvent.press(screen.getByTestId('call-button'));

    expect(mockTrackUserEvent).toHaveBeenNthCalledWith(1, 'action|tag');
  });

  it('should not track user event if the action tag is not specified', () => {
    render(<PhoneCallBox phone={number} />);

    fireEvent.press(screen.getByTestId('test:id/phone-container'));
    fireEvent.press(screen.getByTestId('call-button'));

    expect(mockTrackUserEvent).not.toHaveBeenCalled();
  });
});
