import { useAnalytics } from '@hooks/use-analytics';
import { useEffect } from 'react';
import { SetOptional } from 'type-fest';

import { Button, ButtonVariant } from '../button';
import { Dialog, DialogProps } from '../dialogs';
import { PhoneCallBoxProps } from './phone-call-box';

type PhoneCallDialogProps = Pick<PhoneCallBoxProps, 'phone'> &
  SetOptional<DialogProps, 'title'> & {
    onCallPress: () => void;
    onCancelPress: () => void;
    tags?: {
      onOpen?: string;
    };
  };

export const PhoneCallDialog = ({
  onCallPress,
  onCancelPress,
  tags,
  ...dialogProps
}: PhoneCallDialogProps) => {
  const { trackUserEvent } = useAnalytics();

  useEffect(() => {
    if (dialogProps.open && tags?.onOpen) {
      trackUserEvent(tags.onOpen);
    }
  }, [dialogProps.open, tags?.onOpen, trackUserEvent]);

  return (
    <Dialog
      title="Calls may be charged"
      copy="Charges from mobiles will vary. Calls may be recorded and/or monitored."
      {...dialogProps}
    >
      <Button
        testID="call-button"
        height={44}
        mt="$xl"
        onPress={onCallPress}
        accessibilityLabel="Call Help"
        accessibilityHint="Call Help"
      >
        Call
      </Button>
      <Button
        variant={ButtonVariant.LINK_TEXT}
        mt="$md"
        onPress={onCancelPress}
        accessibilityLabel="Cancel Call Help"
        accessibilityHint="Cancel Call Help"
      >
        Cancel
      </Button>
    </Dialog>
  );
};
