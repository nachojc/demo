import {
  fireEvent,
  render,
  renderHook,
  screen,
  waitFor,
} from '@src/jest/testing-library';
import { AddressFormSchema } from '@aviva/ion-mobile/components/address-form/types';
import { zodResolver } from '@hookform/resolvers/zod';
import { setMock } from '@src/api-mock/helpers';
import { useForm } from 'react-hook-form';

import { AddressForm } from '../../address-form/types';
import { PostcodeLookup } from '../postcode-lookup';

const modalTestId = 'test:id/modal-content';
const postcodeError = 'Please enter a valid postcode.';
const postcodeSearchPlaceholder = 'Enter postcode';

const { result } = renderHook(() =>
  useForm<AddressForm>({
    resolver: zodResolver(AddressFormSchema),
    mode: 'onChange',
    defaultValues: {
      lineOne: undefined,
      lineTwo: undefined,
      lineThree: undefined,
      town: undefined,
      postcode: undefined,
    },
  })
);

const defaultProps = {
  form: result.current,
  onPostcodeSearchTapped: jest.fn(),
  onAddressSelect: jest.fn(),
};

const renderPostcodeLookup = () => {
  render(<PostcodeLookup {...defaultProps} />);
};

describe('Postcode Lookup Component', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should display the search header and input placeholder', () => {
    renderPostcodeLookup();
    expect(screen.getByText('Find address')).toBeOnTheScreen();
    expect(
      screen.getByPlaceholderText(postcodeSearchPlaceholder)
    ).toBeOnTheScreen();
  });

  it('should display appropriate error message if postcode input has error state on form when clicking the search button', async () => {
    renderPostcodeLookup();
    const postcodeSearchButton = screen.getByRole('button');
    fireEvent.press(postcodeSearchButton);
    expect(await screen.findByText(postcodeError)).toBeOnTheScreen();
  });

  it('should display no errors if a valid postcode is provided and search button is pressed', async () => {
    renderPostcodeLookup();
    const postcodeSearchInput = screen.getByPlaceholderText(
      postcodeSearchPlaceholder
    );
    fireEvent.changeText(postcodeSearchInput, 'SW1A 1AA');
    const postcodeSearchButton = screen.getByRole('button');
    fireEvent.press(postcodeSearchButton);
    await waitFor(() => {
      expect(screen.getByTestId(modalTestId)).toBeOnTheScreen();
    });
    expect(screen.queryByText(postcodeError)).not.toBeOnTheScreen();
  });

  it('should display error on "onBlur" if a invalid postcode is provided', async () => {
    renderPostcodeLookup();
    const postcodeSearchInput = screen.getByPlaceholderText(
      postcodeSearchPlaceholder
    );
    fireEvent.changeText(postcodeSearchInput, 'SW1A');
    fireEvent(postcodeSearchInput, 'blur');
    await waitFor(() => {
      expect(screen.getByText(postcodeError)).toBeOnTheScreen();
    });
  });

  it('should open modal and display results when success returned from postcodelookup hook', async () => {
    renderPostcodeLookup();
    const postcodeSearchInput = screen.getByPlaceholderText(
      postcodeSearchPlaceholder
    );
    fireEvent.changeText(postcodeSearchInput, 'NR13NS');
    const postcodeSearchButton = screen.getByRole('button');
    fireEvent.press(postcodeSearchButton);
    await screen.findByTestId(modalTestId);
    expect(screen.getByText('1 Tilley Close, Devizes')).toBeOnTheScreen();
    expect(screen.getByText('2 Tilley Close, Devizes')).toBeOnTheScreen();
    expect(screen.getByText('3 Tilley Close, Devizes')).toBeOnTheScreen();
  });

  it('should show selected address from modal in component and return address', async () => {
    renderPostcodeLookup();
    const postcodeSearchInput = screen.getByPlaceholderText(
      postcodeSearchPlaceholder
    );
    fireEvent.changeText(postcodeSearchInput, 'NR13NS');
    const postcodeSearchButton = screen.getByRole('button');
    fireEvent.press(postcodeSearchButton);

    await waitFor(() => {
      expect(screen.getByText('1 Tilley Close, Devizes')).toBeOnTheScreen();
    });

    const selectAddress = screen.getByText('2 Tilley Close, Devizes');
    fireEvent.press(selectAddress);
    expect(result.current.getValues().lineOne).toBe('2 Tilley Close');
    expect(result.current.getValues().town).toBe('Devizes');
    expect(result.current.getValues().postcode).toBe('SN10 3SJ');
  });

  it('should show modal loading screen', async () => {
    setMock('PostcodeLookup', { status_code: 200, delay: 1000 });
    renderPostcodeLookup();

    const postcodeSearchInput = screen.getByPlaceholderText(
      postcodeSearchPlaceholder
    );
    fireEvent.changeText(postcodeSearchInput, 'NR13NS');
    const postcodeSearchButton = screen.getByRole('button');
    fireEvent.press(postcodeSearchButton);
    expect(await screen.findByTestId(modalTestId)).toBeOnTheScreen();
    expect(
      screen.getByText('Please wait, loading results...')
    ).toBeOnTheScreen();
  });

  it('should show modal error when error returned from hook', async () => {
    setMock('PostcodeLookup', 'Success', { status_code: 500 });
    renderPostcodeLookup();

    const postcodeSearchInput = screen.getByPlaceholderText(
      postcodeSearchPlaceholder
    );
    fireEvent.changeText(postcodeSearchInput, 'NR13NS');
    const postcodeSearchButton = screen.getByRole('button');
    fireEvent.press(postcodeSearchButton);
    expect(await screen.findByTestId(modalTestId)).toBeOnTheScreen();
    expect(
      screen.getByText(
        'Sorry, we were unable to return results for ‘NR13NS’. Please try again.'
      )
    ).toBeOnTheScreen();
  });

  it('should show modal invalid postcode error when error returned from hook is bad request', async () => {
    setMock('PostcodeLookup', 'Success', { status_code: 500 });

    renderPostcodeLookup();
    const postcodeSearchInput = screen.getByPlaceholderText(
      postcodeSearchPlaceholder
    );
    fireEvent.changeText(postcodeSearchInput, 'NR13NS');
    const postcodeSearchButton = screen.getByRole('button');
    fireEvent.press(postcodeSearchButton);
    expect(await screen.findByTestId(modalTestId)).toBeOnTheScreen();
    expect(
      screen.getByText(
        'Sorry, we were unable to return results for ‘NR13NS’. Please try again.'
      )
    ).toBeOnTheScreen();
  });
});
