import {
  ButtonVariant,
  Icon,
  Modal,
  SearchInput,
  Stack,
  Text,
  YStack,
} from '@aviva/ion-mobile';
import {
  PostcodeSearchForm,
  PostcodeSearchSchema,
} from '@aviva/ion-mobile/components/address-input/address-form';
import { LoadingSpinner } from '@aviva/ion-mobile/components/loading-spinner';
import { zodResolver } from '@hookform/resolvers/zod';
import { useAddressServiceGetApiV1Address } from '@src/api/generated/queries';
import { Aviva_Digital_MobileApi_Endpoints_PostcodeLookup_V1_Model_AddressModel } from '@src/api/generated/requests';
import { spellOutString } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { t } from 'i18next';
import { useCallback, useEffect, useState } from 'react';
import { Controller, useForm, UseFormReturn } from 'react-hook-form';
import { Keyboard } from 'react-native';

import { AddressForm } from '../address-form/types';
import { DropdownBaseProps } from '../dropdown-types/dropdown/types';

export const AddressFieldName = {
  AddressLineOne: 'addressLine1',
  AddressLineTwo: 'addressLine2',
  AddressLineThree: 'addressLine3',
  PostalTownCity: 'postalTownCity',
  Postcode: 'postcode',
  PostcodeLookup: 'PostcodeLookup',
} as const;

type AddressInputProps = Pick<DropdownBaseProps, 'modalStyles'> & {
  form: UseFormReturn<AddressForm>;
  onAddressSelect: (address: AddressForm) => void;
  onPostcodeSearchTapped: () => void;
  innerRef?: any;
};

export const PostcodeLookup = ({
  modalStyles,
  form,
  onPostcodeSearchTapped = () => undefined,
  onAddressSelect,
  innerRef,
}: AddressInputProps) => {
  const [showModal, setShowModal] = useState(false);
  const [postcode, setPostcode] = useState('');

  const postcodeSearchForm = useForm<PostcodeSearchForm>({
    resolver: zodResolver(PostcodeSearchSchema),
    mode: 'onBlur',
    defaultValues: { postcodeSearch: undefined },
  });

  const { trigger, getFieldState, control, reset, formState } =
    postcodeSearchForm;

  const { data, isFetching, isError, error, refetch } =
    useAddressServiceGetApiV1Address(
      { postcode },
      ['AddressServiceGetApiV1Address', postcode],
      {
        enabled: false,
        cacheTime: 0,
        staleTime: 0,
      }
    );

  const handleAddressSelection = useCallback(
    async (index: number) => {
      const selectedAddressResponse = data?.Addresses?.[index];

      const address = {
        lineOne: selectedAddressResponse?.AddressLineOne ?? '',
        lineTwo: selectedAddressResponse?.AddressLineTwo ?? '',
        lineThree: selectedAddressResponse?.AddressLineThree ?? '',
        town: selectedAddressResponse?.PostalTownCity ?? '',
        postcode: selectedAddressResponse?.Postcode ?? '',
      } as AddressForm;

      form.reset(address);
      reset();

      if (onAddressSelect) {
        onAddressSelect(address);
      }
      setShowModal(false);
    },
    [onAddressSelect, data?.Addresses, form, reset]
  );

  useEffect(() => {
    if (postcode.length) {
      refetch();
    }
  }, [postcode, refetch]);

  const formatLabel = (value: string | null, placeholder: string) => {
    return value ? spellOutString(value) : placeholder ?? undefined;
  };

  const placeholder = t('postcodeLookup.directWealth.searchPlaceholder');

  return (
    <>
      <Stack mb="$xl">
        <Text
          fontVariant="body-semibold-Secondary800"
          tamaguiTextProps={{ mb: '$md' }}
        >
          {t('postcodeLookup.header')}
        </Text>
        <Controller
          name="postcodeSearch"
          control={control}
          render={({ field: { onChange, onBlur, value } }) => (
            <SearchInput
              buttonAccessibilityLabel={t(
                'postcodeLookup.directWealth.buttonAccessibilityLabel'
              )}
              buttonTestID={getTestId('search-postcode')}
              buttonText={t('pension.add-beneficiary.address.postcodeButton')}
              buttonVariant={ButtonVariant.DIRECT_WEALTH}
              error={!!formState.errors.postcodeSearch}
              errorText={formState.errors.postcodeSearch?.message}
              hasIcon
              iconColor={'white'}
              innerRef={innerRef}
              inputAccessibilityLabel={formatLabel(value, placeholder)}
              onSearch={async (val) => {
                onPostcodeSearchTapped();
                await trigger('postcodeSearch');
                if (!getFieldState('postcodeSearch').invalid) {
                  setPostcode(val ?? '');
                  setShowModal(true);
                }
                Keyboard.dismiss();
              }}
              tamaguiInputProps={{
                value,
                testID: 'test:id/postcode-textfield',
                onChangeText: onChange,
                onBlur,
                placeholder,
              }}
            />
          )}
        />
      </Stack>
      <Modal
        modalStyles={modalStyles}
        isOpen={showModal}
        onClose={() => {
          setShowModal(false);
        }}
        backgroundColor="White"
        closeIconColor="DWPrimary500"
        modalHeight={0.9}
      >
        {isFetching && (
          <YStack flex={1} alignItems="center" justifyContent="center">
            <LoadingSpinner size={40} />
            <Stack marginTop="$xxl">
              <Text fontVariant="body-regular-Gray800">
                {t('postcodeLookup.directWealth.loadingResults')}
              </Text>
            </Stack>
          </YStack>
        )}
        {isError && !isFetching && (
          <YStack flex={1} alignItems="center" justifyContent="center">
            <Icon name="alert-circle-outline" width={40} height={40} />
            <Text
              fontVariant="body-regular-Gray800"
              tamaguiTextProps={{ textAlign: 'center', marginTop: '$xxl' }}
            >
              {String(error).includes('Bad Request')
                ? t('postcodeLookup.directWealth.invalidPostcodeServiceError')
                : t('postcodeLookup.directWealth.invalidPostcodeOtherError', {
                    postcode,
                  })}
            </Text>
          </YStack>
        )}
        {!isFetching &&
          !isError &&
          data?.Addresses &&
          data?.Addresses.map(
            (
              returnedAddress: Aviva_Digital_MobileApi_Endpoints_PostcodeLookup_V1_Model_AddressModel,
              index: number
            ) => (
              <YStack
                testID={getTestId(`address-${index}`)}
                key={`address-${index}`}
                paddingVertical="$xl"
                borderBottomWidth={1}
                borderColor="$Gray300"
                onPress={() => handleAddressSelection(index)}
              >
                <Text fontVariant="body-semibold-Gray800">
                  {`${returnedAddress.AddressLineOne}, ${returnedAddress.PostalTownCity}`}
                </Text>
              </YStack>
            )
          )}
      </Modal>
    </>
  );
};
