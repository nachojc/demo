import { Stack, StackProps, Text, TextProps } from 'tamagui';

type LinkButtonProps = StackProps & {
  children: string;
  tamaguiTextProps?: Omit<TextProps, 'onPress'>;
};

export const LinkButton = ({
  children,
  tamaguiTextProps,
  ...stackProps
}: LinkButtonProps) => {
  return (
    <Stack
      accessible
      accessibilityLabel={children}
      accessibilityRole="link"
      {...stackProps}
    >
      <Text
        textDecorationLine="underline"
        fontFamily={'$body'}
        accessible={false}
        fontWeight="$semibold"
        color="$Tertiary800"
        {...(tamaguiTextProps ?? {})}
      >
        {children}
      </Text>
    </Stack>
  );
};
