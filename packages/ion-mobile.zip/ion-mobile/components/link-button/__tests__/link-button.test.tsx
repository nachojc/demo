import { fireEvent, render, screen } from '@src/jest/testing-library';

import { LinkButton } from '../link-button';

const mockOnPress = jest.fn();

const LinkButtonComponent = () => {
  render(<LinkButton onPress={mockOnPress}> Test Link Button </LinkButton>);
};

describe('LinkButton', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  it('should render Test Link Button text link', () => {
    LinkButtonComponent();

    expect(screen.getByText('Test Link Button')).toBeVisible();
  });

  it('should render font with correct font and colour', () => {
    LinkButtonComponent();

    const text = screen.getByText('Test Link Button');
    expect(text).toHaveStyle({
      color: '#004FB6',
      fontFamily: 'SourceSansPro-SemiBold',
    });
  });
  it('Should call onPress when text link is pressed', () => {
    LinkButtonComponent();

    const text = screen.getByText('Test Link Button');
    fireEvent.press(text);
    expect(mockOnPress).toHaveBeenCalledTimes(1);
  });
});
