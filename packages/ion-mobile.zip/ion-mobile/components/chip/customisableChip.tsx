import { getTestId } from '@src/utils/get-test-id';
import { ColorValue } from 'react-native';

import { Icon, IconName } from '../icon';
import { CustomisableChipContainer, CustomisableChipText } from './chip.styles';

type Props = {
  text: string;
  iconName: IconName;
  iconColor?: ColorValue;
  backgroundColor: ColorValue;
  textColor?: ColorValue;
};

export const CustomisableChip = ({
  text,
  iconName,
  iconColor,
  backgroundColor,
  textColor,
}: Props) => {
  return (
    <CustomisableChipContainer
      testID={getTestId('customisable-chip')}
      backgroundColor={backgroundColor}
    >
      <Icon name={iconName} color={iconColor} />
      <CustomisableChipText color={textColor}>{text}</CustomisableChipText>
    </CustomisableChipContainer>
  );
};
