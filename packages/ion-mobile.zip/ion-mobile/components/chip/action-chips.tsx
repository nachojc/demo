import { Color } from '@theme/tokens';
import { useCallback, useEffect, useState } from 'react';
import { GetProps, getTokens, getVariableValue } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text';
import { ActionChipContainer } from './chip.styles';

type ChipVariant = 'clock' | 'credit-card' | 'camera' | 'close';

type ChipPropsCustom = {
  title: string;
  onPressChip: (selected: boolean) => void;
  trailingIcon?: boolean;
  lightTheme?: boolean;
  variant?: ChipVariant;
  preselected?: boolean;
  disableToggle?: boolean;
  disabled?: boolean;
};
type ChipProps = GetProps<typeof ActionChipContainer>;

type ChipPropsAll = ChipPropsCustom & ChipProps;

const getActionIcon = (
  disabled?: boolean,
  selected?: boolean,
  variant?: ChipVariant,
  lightTheme?: boolean
) => {
  const tokens = getTokens();

  let color = getVariableValue(tokens.color.Secondary800);

  if (lightTheme && !selected) {
    color = getVariableValue(tokens.color.White);
  }

  if (disabled) {
    color = getVariableValue(tokens.color.Gray400);
  }

  if (variant === 'clock') {
    return <Icon name="clock" color={color} />;
  } else if (variant === 'credit-card') {
    return <Icon name="credit-card" color={color} />;
  } else if (variant === 'camera') {
    return <Icon name="camera" color={color} />;
  } else if (variant === 'close' && selected) {
    return (
      <Icon
        name="close"
        color={color}
        width={getVariableValue(tokens.size['5'])}
        height={getVariableValue(tokens.size['5'])}
      />
    );
  } else {
    return;
  }
};

export const ActionChip = (props: ChipPropsAll) => {
  const {
    variant,
    title,
    disabled,
    disableToggle,
    preselected,
    trailingIcon,
    lightTheme,
    onPressChip,
    ...rest
  } = props;
  const [selected, setSelected] = useState<boolean>(false);

  const chipColor: Color = lightTheme && !selected ? 'White' : 'Secondary800';
  const whiteBorder = lightTheme && !disabled;

  const onPressHandler = useCallback(() => {
    if (!disableToggle) {
      setSelected(!selected);
      onPressChip(!selected);
    } else {
      onPressChip(selected);
    }
  }, [selected, setSelected, onPressChip, disableToggle]);

  useEffect(() => {
    if (preselected !== undefined) {
      setSelected(preselected);
    }
  }, [preselected]);

  return (
    <ActionChipContainer
      accessible
      disabled={disabled}
      selected={selected}
      whiteBorder={whiteBorder}
      testID="test-action-chip"
      trailingIcon={trailingIcon}
      onPress={onPressHandler}
      {...rest}
    >
      {getActionIcon(disabled, selected, variant, lightTheme)}
      <Text
        fontVariant={`small-regular-${disabled ? 'Gray400' : chipColor}`}
        tamaguiTextProps={{ textAlign: 'center' }}
      >
        {title}
      </Text>
    </ActionChipContainer>
  );
};
