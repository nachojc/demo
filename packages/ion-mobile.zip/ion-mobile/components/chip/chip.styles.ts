import { styled, Text, XStack, YStack } from 'tamagui';

const ActionChipContainer = styled(XStack, {
  boc: '$Secondary800',
  borderRadius: 50,
  alignItems: 'center',
  height: '$7',
  paddingVertical: '$sm',
  paddingHorizontal: '$lg',
  space: '$md',
  alignSelf: 'center',
  justifyContent: 'center',

  variants: {
    disabled: () => ({
      bg: 'transparent',
      boc: '$Gray400',
      bw: '$xs',
    }),
    selected: (val: boolean) => ({
      bg: val ? '$Primary500' : 'transparent',
      bw: val ? 0 : '$xs',
    }),
    whiteBorder: (val: boolean) => ({
      boc: val ? '$White' : '$Gray400',
    }),
    trailingIcon: () => ({
      flexDirection: 'row-reverse',
    }),
  },
});

const AlertChipContainer = styled(XStack, {
  alignItems: 'center',
  bg: '$Gray200',
  space: '$md',
  alignSelf: 'center',
  justifyContent: 'center',

  variants: {
    variant: {
      information: {
        bg: '$InformationTint',
        paddingLeft: '$sm',
      },
      success: {
        bg: '$SuccessTint',
        paddingLeft: '$sm',
      },
      warning: {
        bg: '$WarningTint',
        paddingLeft: '$sm',
      },
      error: {
        bg: '$ErrorTint',
        paddingLeft: '$sm',
      },
    },
    size: {
      sm: {
        borderRadius: 50,
        height: '$7',
        paddingVertical: '$sm',
        paddingLeft: '$sm',
        paddingRight: '$lg',
      },
      lg: {
        borderRadius: 9,
        padding: '$lg',
        alignItems: 'flex-start',
      },
    },
  } as const,
});

const ChipContainer = styled(XStack, {
  space: '$md',
  marginVertical: '$sm',
  alignSelf: 'flex-start',
  variants: {
    variant: {
      information: {
        bg: '$InformationTint',
        paddingLeft: '$sm',
      },
      success: {
        bg: '$SuccessTint',
        paddingLeft: '$sm',
      },
      warning: {
        bg: '$WarningTint',
        paddingLeft: '$sm',
      },
      error: {
        bg: '$ErrorTint',
        paddingLeft: '$sm',
      },
    },
    size: {
      sm: {
        borderRadius: 50,
        height: '$7',
        paddingVertical: '$sm',
        paddingLeft: '$sm',
        paddingRight: '$lg',
      },
      lg: {
        borderRadius: 9,
        padding: '$lg',
        alignItems: 'flex-start',
      },
    },
  } as const,
});
const CustomisableChipContainer = styled(XStack, {
  bg: '$Gray200',
  space: '$md',
  alignSelf: 'flex-start',
  borderRadius: 50,
  paddingVertical: '$sm',
  height: '$7',
  paddingLeft: '$sm',
  paddingRight: '$lg',
  alignItems: 'center',
});

const CustomisableChipText = styled(Text, {
  fontFamily: '$body',
  fontWeight: '$regular',
  color: '$Secondary900',
  accessibilityRole: 'text',
});

const AlertChipText = styled(Text, {
  fontFamily: '$body',
  fontWeight: '$regular',
  color: '$Secondary800',
  accessibilityRole: 'text',
  alignSelf: 'center',
  variants: {
    size: {
      sm: { textAlign: 'center' },
      lg: { textAlign: 'left' },
    },
  } as const,
});

const Container = styled(YStack, {
  borderRadius: 50,
  paddingTop: '$sm',
  paddingBottom: '$sm',
  paddingRight: '$lg',
  paddingLeft: '$lg',
  alignItems: 'center',

  variants: {
    variant: {
      'selection-card': {
        bg: '$SuccessTint',
        py: '$md',
        px: '$lg',
      },
      'fund-card': {
        bg: '$Secondary800Opacity10',
      },
    },
  },
});

export {
  ActionChipContainer,
  AlertChipContainer,
  AlertChipText,
  ChipContainer,
  Container,
  CustomisableChipContainer,
  CustomisableChipText,
};
