import { getTestId } from '@src/utils/get-test-id';

import { Text } from '../text';
import { Container } from './chip.styles';

type Props = {
  variant: 'selection-card' | 'fund-card';
  title: string;
};

export const Chip = ({ variant, title }: Props) => {
  const fontVariant =
    variant === 'fund-card'
      ? 'body-semibold-Secondary800'
      : 'small-regular-Gray800';

  return (
    <Container variant={variant}>
      <Text testID={getTestId('chip-percentage')} fontVariant={fontVariant}>
        {title}
      </Text>
    </Container>
  );
};
