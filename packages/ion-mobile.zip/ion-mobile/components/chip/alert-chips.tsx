import { tokens } from '@src/theme/tokens';
import { formatDates } from '@src/utils/format-dates';
import { getTestId } from '@src/utils/get-test-id';
import { ReactNode } from 'react';
import { AccessibilityProps } from 'react-native';
import { FontSizeTokens, StackProps } from 'tamagui';

import { Icon, IconName } from '../icon';
import {
  AlertChipContainer,
  AlertChipText,
  ChipContainer,
} from './chip.styles';

const pickIconColor = (variant: ChipVariant) => {
  switch (variant) {
    case 'information':
      return tokens.color.Information.val;
    case 'success':
      return tokens.color.Success.val;
    case 'warning':
      return tokens.color.Warning.val;
    case 'error':
      return tokens.color.Error.val;
    case undefined: {
      return undefined;
    }
  }
};

export type ChipVariant =
  | 'information'
  | 'success'
  | 'error'
  | 'warning'
  | undefined;

type ChipBaseProps = Pick<StackProps, 'testID'> & {
  variant: ChipVariant;
  size?: 'sm' | 'lg';
  fontSize?: FontSizeTokens;
} & Pick<
    AccessibilityProps,
    'accessible' | 'accessibilityLabel' | 'accessibilityHint'
  >;

export type AlertChipProps = ChipBaseProps & StackProps & { title: string };

export const AlertChip = ({
  size = 'sm',
  fontSize = '$body',
  testID = getTestId('alert-chip'),
  variant,
  title,
  ...rest
}: AlertChipProps) => {
  const iconName = variant === 'success' ? 'tick' : 'alert-circle';

  const accessibilityLabel =
    iconName === 'tick' ? formatDates(title) : `warning. ${formatDates(title)}`;

  return (
    <AlertChipContainer testID={testID} variant={variant} size={size} {...rest}>
      <Icon name={iconName} color={pickIconColor(variant)} />
      <AlertChipText
        size={size}
        fontSize={fontSize}
        accessibilityLabel={accessibilityLabel}
      >
        {title}
      </AlertChipText>
    </AlertChipContainer>
  );
};

export type AlertChipExtendableProps = ChipBaseProps & {
  name?: IconName;
  text?: ReactNode;
  accessible?: boolean;
};

export const AlertChipExtendable = ({
  testID = getTestId('alert-chip'),
  name = 'alert-circle',
  size = 'sm',
  accessible = true,
  variant,
  text,
  ...rest
}: AlertChipExtendableProps) => {
  return (
    <ChipContainer
      testID={testID}
      variant={variant}
      accessible={accessible}
      accessibilityRole="alert"
      size={size}
      {...rest}
    >
      <Icon name={name} color={pickIconColor(variant)} />
      {text}
    </ChipContainer>
  );
};
