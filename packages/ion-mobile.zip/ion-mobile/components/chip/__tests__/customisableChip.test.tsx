import { render, screen } from '@src/jest/testing-library';

import { CustomisableChip } from '../customisableChip';

const testTitleText = 'This is test title text';

describe('Customisable Chip component', () => {
  it('expect customisable chip to render text correctly', () => {
    render(
      <CustomisableChip
        text={testTitleText}
        iconName={'acceleration'}
        backgroundColor={'$White'}
      />
    );
    const title = screen.getByText(testTitleText);
    expect(title).toBeOnTheScreen();
    const testIDElm = screen.getByTestId('test:id/customisable-chip');
    expect(testIDElm).toBeOnTheScreen();
  });
  it('expect customisable chip to render icon correctly', () => {
    render(
      <CustomisableChip
        text={testTitleText}
        iconName={'acceleration'}
        backgroundColor={'$White'}
      />
    );
    expect(
      screen.getByTestId('test:id/icon-acceleration', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });
  it('expect customisable chip to have the correct colour background', () => {
    render(
      <CustomisableChip
        text={testTitleText}
        iconName={'acceleration'}
        backgroundColor={'$Error'}
      />
    );
    expect(screen.getByTestId('test:id/customisable-chip')).toHaveStyle({
      backgroundColor: '#BD2624',
    });
  });
});
