import { render, screen } from '@src/jest/testing-library';

import { AlertChip, AlertChipExtendable } from '../alert-chips';
import { AlertChipText } from '../chip.styles';

const testTitleText = 'This is test title text';

describe('Alert chips component', () => {
  it('expect title to render correctly', () => {
    render(<AlertChip variant={'information'} title={testTitleText} />);

    const title = screen.getByText('This is test title text');
    expect(title).toBeOnTheScreen();

    const testIDElm = screen.getByTestId('test:id/alert-chip');
    expect(testIDElm).toBeOnTheScreen();
  });

  it('expect information action chip to render icon', () => {
    render(
      <AlertChip variant={'information'} title={'This is test title text'} />
    );

    expect(
      screen.getByTestId('test:id/icon-alert-circle', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });

  it('expect success action chip to render icon', () => {
    render(<AlertChip variant={'success'} title={'This is test title text'} />);

    expect(
      screen.getByTestId('test:id/icon-tick', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });

  it('expect warning action chip to render icon', () => {
    render(<AlertChip variant={'warning'} title={'This is test title text'} />);

    expect(
      screen.getByTestId('test:id/icon-alert-circle', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });

  it('expect error action chip to render icon', () => {
    render(<AlertChip variant={'error'} title={'This is test title text'} />);

    expect(
      screen.getByTestId('test:id/icon-alert-circle', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });

  it('expect information chip to have InformationTint colour background', () => {
    render(
      <AlertChip variant={'information'} title={'This is test title text'} />
    );

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#ECF9FF',
    });
  });

  it('expect success chip to have SuccessTint colour background', () => {
    render(<AlertChip variant={'success'} title={'This is test title text'} />);

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#EBF2E9',
    });
  });

  it('expect warning chip to have WarningTint colour background', () => {
    render(<AlertChip variant={'warning'} title={'This is test title text'} />);

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#FFF5E5',
    });
  });

  it('expect error chip to have ErrorTint colour background', () => {
    render(<AlertChip variant={'error'} title={'This is test title text'} />);

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#F8E9E9',
    });
  });

  it('expect accessibility label and hint are available', () => {
    render(
      <AlertChip
        variant={'error'}
        title={'This is test title text'}
        accessibilityLabel={'accessibility label text'}
        accessibilityHint={'accessibility hint text'}
      />
    );

    expect(screen.getByLabelText('accessibility label text')).toBeOnTheScreen();
    expect(
      screen.getByAccessibilityHint('accessibility hint text')
    ).toBeOnTheScreen();
  });
});

describe('Alert Chip Extendable component', () => {
  it('should render the text correctly', () => {
    render(
      <AlertChipExtendable
        variant={'success'}
        text={<AlertChipText size={'sm'}>{`0 of 3`}</AlertChipText>}
        name="tick"
      />
    );

    expect(screen.getByTestId('test:id/alert-chip')).toBeOnTheScreen();

    expect(screen.getByText('0 of 3')).toBeOnTheScreen();

    expect(
      screen.getByTestId('test:id/icon-tick', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#EBF2E9',
    });
  });

  it('should render component with the correct style - warning', () => {
    render(
      <AlertChipExtendable
        variant={'warning'}
        text={<AlertChipText size={'sm'}>{`0 of 3`}</AlertChipText>}
        name="alert-circle"
      />
    );

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#FFF5E5',
    });
  });

  it('should render component with the correct style - information', () => {
    render(
      <AlertChipExtendable
        variant={'information'}
        text={<AlertChipText size={'sm'}>{`0 of 3`}</AlertChipText>}
        name="alert-circle"
      />
    );

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#ECF9FF',
    });
  });

  it('should render component with the correct style - error', () => {
    render(
      <AlertChipExtendable
        variant={'error'}
        text={<AlertChipText size={'sm'}>{`0 of 3`}</AlertChipText>}
        name="alert-circle"
      />
    );

    expect(screen.getByTestId('test:id/alert-chip')).toHaveStyle({
      backgroundColor: '#F8E9E9',
    });
  });

  it('should render the component with the correct accessibility props', () => {
    render(
      <AlertChipExtendable
        variant={'success'}
        text={<AlertChipText size={'sm'}>{`0 of 3`}</AlertChipText>}
        name="tick"
      />
    );

    expect(screen.getByTestId('test:id/alert-chip')).toHaveProp(
      'accessible',
      true
    );
    expect(screen.getByTestId('test:id/alert-chip')).toHaveProp(
      'accessibilityRole',
      'alert'
    );
  });

  it('should render the component with accessible false', () => {
    render(
      <AlertChipExtendable
        variant={'success'}
        text={<AlertChipText size={'sm'}>{`0 of 3`}</AlertChipText>}
        name="tick"
        accessible={false}
      />
    );

    expect(screen.getByTestId('test:id/alert-chip')).toHaveProp(
      'accessible',
      false
    );
  });
});
