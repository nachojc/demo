import { render, screen } from '@src/jest/testing-library';

import { Chip } from '../chip';

describe('Chip component', () => {
  it('expect title to render correctly', () => {
    render(
      <Chip variant={'selection-card'} title={'This is test title text'} />
    );
    const title = screen.getByText('This is test title text');
    expect(title).toBeOnTheScreen();
  });
});
