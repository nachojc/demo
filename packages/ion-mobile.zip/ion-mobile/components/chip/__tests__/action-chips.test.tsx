import { fireEvent, render, screen } from '@src/jest/testing-library';

import { ActionChip } from '../action-chips';

const testTitleText = 'This is test title text';
const defaultBorderColor = '#7E7E7E';
const whiteBorderColor = '#FFFFFF';

describe('Chip action component', () => {
  it('should render title correctly', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={testTitleText}
        onPressChip={() => null}
      />
    );

    const title = screen.getByText('This is test title text');
    expect(title).toBeOnTheScreen();

    const testIDElm = screen.getByTestId('test-action-chip');
    expect(testIDElm).toBeOnTheScreen();
  });

  it('should render icon', () => {
    render(
      <ActionChip
        variant={'clock'}
        title={'This is test title text'}
        onPressChip={() => null}
      />
    );
    expect(
      screen.getByTestId('test:id/icon-clock', { includeHiddenElements: true })
    ).toBeOnTheScreen();
  });

  it('should render credit-card variant of the action chip matching the right icon', () => {
    render(
      <ActionChip
        variant={'credit-card'}
        title={'This is test title text'}
        onPressChip={() => null}
      />
    );

    expect(
      screen.getByTestId('test:id/icon-credit-card', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });

  it('should render clock variant of the action chip matching the right icon', () => {
    render(
      <ActionChip
        variant={'clock'}
        title={'This is test title text'}
        onPressChip={() => null}
      />
    );
    expect(
      screen.getByTestId('test:id/icon-clock', { includeHiddenElements: true })
    ).toBeOnTheScreen();
  });

  it('should render camera variant of the action chip matching the right icon', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        onPressChip={() => null}
      />
    );
    expect(
      screen.getByTestId('test:id/icon-camera', { includeHiddenElements: true })
    ).toBeOnTheScreen();
  });

  it('should add the close icon variant just when the chip has been selected', () => {
    render(
      <ActionChip
        variant={'close'}
        title={'This is test title text'}
        onPressChip={() => null}
      />
    );

    expect(screen.queryByText('test:id/icon-close')).not.toBeOnTheScreen();

    fireEvent.press(screen.getByTestId('test-action-chip'));

    expect(
      screen.getByTestId('test:id/icon-close', { includeHiddenElements: true })
    ).toBeOnTheScreen();
  });

  it('should render action chip with selected colour when in selected state', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        selected
        onPressChip={() => null}
      />
    );
    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      backgroundColor: '#FFD900',
    });
  });

  it('should toggle the action chip with selected colour when in selected state and back', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        onPressChip={() => null}
      />
    );

    const actionChip = screen.getByTestId('test-action-chip');
    fireEvent.press(actionChip);

    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      backgroundColor: '#FFD900',
    });

    fireEvent.press(actionChip);

    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      backgroundColor: 'transparent',
    });
  });

  it('should pass the "selected" chip state to the onPressChip handler when toggling', () => {
    let selectedStateTest;
    const testOnPressHandler = (selected: boolean) => {
      selectedStateTest = selected;
    };

    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        onPressChip={testOnPressHandler}
      />
    );

    const actionChip = screen.getByTestId('test-action-chip');

    fireEvent.press(actionChip);

    expect(selectedStateTest).toBeTruthy();

    fireEvent.press(actionChip);

    expect(selectedStateTest).toBeFalsy();
  });

  it('should preselect the action chip programmatically if the preselect prop has been passed', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        onPressChip={() => null}
        preselected
      />
    );

    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      backgroundColor: '#FFD900',
    });
  });

  it('should disable the toggling if the disableToggle prop has been passed', () => {
    let selectedStateTest;

    const testOnPressHandler = (selected: boolean) => {
      selectedStateTest = selected;
    };

    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        onPressChip={testOnPressHandler}
        disableToggle
      />
    );
    const actionChip = screen.getByTestId('test-action-chip');
    fireEvent.press(actionChip);

    expect(selectedStateTest).toBeFalsy();

    fireEvent.press(actionChip);

    expect(selectedStateTest).toBeFalsy();
  });

  it('should render action chip with disabled colour when in disabled state', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        disabled
        onPressChip={() => null}
      />
    );

    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      backgroundColor: 'transparent',
    });
  });

  it('should render action chip with default colour', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        onPressChip={() => null}
      />
    );

    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      borderTopColor: defaultBorderColor,
      borderRightColor: defaultBorderColor,
      borderBottomColor: defaultBorderColor,
      borderLeftColor: defaultBorderColor,
    });
  });

  it('should render action chip with white colour in lightTheme', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        lightTheme
        onPressChip={() => null}
      />
    );

    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      borderTopColor: whiteBorderColor,
      borderRightColor: whiteBorderColor,
      borderBottomColor: whiteBorderColor,
      borderLeftColor: whiteBorderColor,
    });
  });

  it('should render action chip with trailing icon', () => {
    render(
      <ActionChip
        variant={'camera'}
        title={'This is test title text'}
        trailingIcon
        onPressChip={() => null}
      />
    );

    expect(screen.getByTestId('test-action-chip')).toHaveStyle({
      flexDirection: 'row-reverse',
    });
  });
});
