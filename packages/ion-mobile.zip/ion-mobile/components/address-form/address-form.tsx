import {
  Stack,
  TamaguiElement,
  Text,
  TextInput,
  YStack,
} from '@aviva/ion-mobile';
import { spellOutString } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { MutableRefObject, ReactNode } from 'react';
import { Controller, UseFormReturn } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Keyboard, ReturnKeyTypeOptions } from 'react-native';
import { ValueOf } from 'type-fest';

import { AddressForm } from './types';
/**
 * Reusable Address Input Form with validation.
 * Keep styles inline with the reusable master component in Figma: Tbc
 */

type AddressInputFieldProps = {
  name: 'lineOne' | 'lineTwo' | 'lineThree' | 'town' | 'postcode';
  label: string;
  returnKeyType?: ReturnKeyTypeOptions;
  onSubmitEditing?: () => void;
  onFocus?: () => void;
  placeholder: string;
  errorText?: string;
  accessibilityHint?: string;
};

export const AddressInputForm = ({
  form,
  onFieldFocus = () => undefined,
}: {
  form: UseFormReturn<AddressForm>;
  onFieldFocus?: (fieldType: ValueOf<AddressForm>) => void;
}) => {
  const { t } = useTranslation();

  const { control, setFocus } = form;

  const inputFields: AddressInputFieldProps[] = [
    {
      name: 'lineOne',
      label: t('addressForm.lineOne'),
      returnKeyType: 'next',
      onSubmitEditing: () => setFocus('lineTwo'),
      onFocus: () => onFieldFocus('lineOne'),
      placeholder: t('addressForm.lineOnePlaceholder'),
      errorText: t('addressForm.addressError'),
      accessibilityHint: t('common.required'),
    },
    {
      name: 'lineTwo',
      label: t('addressForm.lineTwo'),
      returnKeyType: 'next',
      onSubmitEditing: () => setFocus('lineThree'),
      onFocus: () => onFieldFocus('lineTwo'),
      placeholder: t('addressForm.lineTwoPlaceholder'),
    },
    {
      name: 'lineThree',
      label: t('addressForm.lineThree'),
      returnKeyType: 'next',
      onSubmitEditing: () => setFocus('town'),
      onFocus: () => onFieldFocus('lineThree'),
      placeholder: t('addressForm.lineThreePlaceholder'),
    },
    {
      name: 'town',
      label: t('addressForm.town'),
      returnKeyType: 'next',
      onSubmitEditing: () => setFocus('postcode'),
      onFocus: () => onFieldFocus('town'),
      placeholder: t('addressForm.town'),
      errorText: t('addressForm.townError'),
      accessibilityHint: t('common.required'),
    },
    {
      name: 'postcode',
      label: t('addressForm.postcode'),
      returnKeyType: 'next',
      onSubmitEditing: Keyboard.dismiss,
      onFocus: () => onFieldFocus('postcode'),
      placeholder: t('addressForm.postcode'),
      errorText: t('addressForm.postcodeError'),
      accessibilityHint: t('common.required'),
    },
  ];

  const formatLabel = (
    value: string | null | undefined,
    placeholder: string
  ) => {
    return value ? spellOutString(value) : placeholder ?? '';
  };

  return (
    <>
      {Array.from({ length: inputFields.length }, (_, i) => {
        return (
          <Controller
            key={inputFields[i].name}
            name={inputFields[i].name}
            control={control}
            render={({
              field: { onChange, value, ref, onBlur },
              fieldState,
            }) => {
              return (
                <InputField
                  accessibilityHint={inputFields[i].accessibilityHint}
                  label={inputFields[i].label}
                  field={
                    <Stack
                      {...(inputFields[i].name === 'postcode' && {
                        accessible: true,
                        accessibilityLabel: formatLabel(
                          value,
                          inputFields[i].placeholder
                        ),
                      })}
                    >
                      <TextInput
                        testID={getTestId('address-form-text-input')}
                        tamaguiInputProps={{
                          value: value === null ? undefined : value,
                          returnKeyType: inputFields[i].returnKeyType,
                          onSubmitEditing: inputFields[i].onSubmitEditing,
                          onChangeText: onChange,
                          onBlur,
                          onFocus: inputFields[i].onFocus,
                          placeholder: inputFields[i].placeholder,
                          ref: ref as unknown as MutableRefObject<
                            TamaguiElement | undefined
                          >,
                          ...(inputFields[i].name === 'postcode'
                            ? {
                                accessibilityElementsHidden: true,
                                importantForAccessibility: 'no',
                              }
                            : {}),
                        }}
                        error={fieldState.invalid}
                        errorText={inputFields[i].errorText}
                      />
                    </Stack>
                  }
                />
              );
            }}
          />
        );
      })}
    </>
  );
};

type InputFieldProps = {
  label: string;
  field: ReactNode;
} & Pick<AddressInputFieldProps, 'accessibilityHint'>;

const InputField = ({ accessibilityHint, label, field }: InputFieldProps) => {
  return (
    <YStack space="$md" marginBottom={'$xl'}>
      <Text
        fontVariant="body-semibold-Secondary800"
        tamaguiTextProps={{ accessibilityHint }}
      >
        {label}
      </Text>
      {field}
    </YStack>
  );
};
