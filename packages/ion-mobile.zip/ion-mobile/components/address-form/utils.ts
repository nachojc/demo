export const postcodeRegex =
  '^(([gG][iI][rR] *0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?\\d\\d?)|(([a-pr-uwyzA-PR-UWYZ]\\d[a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) *\\d[abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$';
