import { z } from 'zod';

import { postcodeRegex } from './utils';

export const AddressFormSchema = z.object({
  lineOne: z.string().min(1),
  lineTwo: z.string().nullable().optional(),
  lineThree: z.string().nullable().optional(),
  town: z.string().min(1),
  postcode: z.string().min(1).max(8).regex(new RegExp(postcodeRegex)),
});

export type AddressForm = z.infer<typeof AddressFormSchema>;
