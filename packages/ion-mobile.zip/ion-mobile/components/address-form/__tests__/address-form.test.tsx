import {
  act,
  fireEvent,
  render,
  renderHook,
  screen,
  within,
} from '@src/jest/testing-library';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';

import { AddressInputForm } from '../address-form';
import { AddressForm, AddressFormSchema } from '../types';

const lineOne = 'First line of address';
const lineOnePlaceholder = 'Address line 1';
const addressError = 'Please enter your address.';
const lineTwo = 'Second line of address (optional)';
const lineTwoPlaceholder = 'Address line 2';
const lineThree = 'Third line of address (optional)';
const lineThreePlaceholder = 'Address line 3';
const town = 'Town or city';
const townError = 'Please enter town or city.';
const postcode = 'Postcode';
const postcodeError = 'Please enter a valid postcode.';

const dummyAddress = {
  lineOne: '2 Tilley Close',
  town: 'Devizes',
  postcode: 'SN10 3SJ',
};

const formFields = [
  { name: lineOne, placeholder: lineOnePlaceholder },
  { name: lineTwo, placeholder: lineTwoPlaceholder },
  { name: lineThree, placeholder: lineThreePlaceholder },
  { name: town, placeholder: town },
  { name: postcode, placeholder: postcode },
] as const;

const { result } = renderHook(() =>
  useForm<AddressForm>({
    resolver: zodResolver(AddressFormSchema),
    mode: 'onChange',
    defaultValues: {
      lineOne: undefined,
      lineTwo: undefined,
      lineThree: undefined,
      town: undefined,
      postcode: undefined,
    },
  })
);

const renderAddressForm = () => {
  const props = { form: result.current };
  render(<AddressInputForm {...props} />);
};

describe('Address Input Component', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it.each(formFields)('should display "%s" field', (formEntry) => {
    renderAddressForm();
    const fieldLabel = screen.getByRole('text', { name: formEntry.name });
    const field = screen.getByPlaceholderText(formEntry.placeholder, {
      includeHiddenElements: true,
    });
    expect(fieldLabel).toBeOnTheScreen();
    expect(field).toBeOnTheScreen();
  });

  it('should display appropriate error message if field has error state on form when submitted', async () => {
    renderAddressForm();
    await act(async () => {
      await result.current.trigger();
    });
    expect(screen.getByText(addressError)).toBeOnTheScreen();
    expect(screen.getByText(townError)).toBeOnTheScreen();
    expect(screen.getByText(postcodeError)).toBeOnTheScreen();
  });

  it('should display no errors on form when submitted if fields are filled', async () => {
    renderAddressForm();

    const lineOneField = screen.getByPlaceholderText(lineOnePlaceholder);
    const townField = screen.getByPlaceholderText(town);
    const postcodeField = screen.getByPlaceholderText(postcode, {
      includeHiddenElements: true,
    });

    fireEvent.changeText(lineOneField, dummyAddress.lineOne);
    fireEvent.changeText(townField, dummyAddress.town);
    fireEvent.changeText(postcodeField, dummyAddress.postcode);

    await act(async () => {
      await result.current.trigger();
    });

    expect(screen.queryAllByText(addressError)).toHaveLength(0);
    expect(screen.queryByText(postcodeError)).toBeNull();
  });

  it('should return the entered values from the form', () => {
    renderAddressForm();

    const lineOneField = screen.getByPlaceholderText(lineOnePlaceholder);
    const townField = screen.getByPlaceholderText(town);
    const postcodeField = screen.getByPlaceholderText(postcode, {
      includeHiddenElements: true,
    });

    fireEvent.changeText(lineOneField, dummyAddress.lineOne);
    fireEvent.changeText(townField, dummyAddress.town);
    fireEvent.changeText(postcodeField, dummyAddress.postcode);

    expect(result.current.getValues().lineOne).toBe(dummyAddress.lineOne);
    expect(result.current.getValues().town).toBe(dummyAddress.town);
    expect(result.current.getValues().postcode).toBe(dummyAddress.postcode);
  });

  it('should return formatted accessibilityLabel for postcode field', () => {
    renderAddressForm();

    const postcodeField = screen.getByPlaceholderText(postcode, {
      includeHiddenElements: true,
    });
    fireEvent.changeText(postcodeField, dummyAddress.postcode);
    expect(screen.getByLabelText('S N 1 0 3 S J')).toBeOnTheScreen();
  });

  it('should have accessibility required hints when applicable', () => {
    renderAddressForm();

    const firstLine = screen.getByText('First line of address');
    const firstLineHint = within(firstLine).getByAccessibilityHint('Required');
    expect(firstLineHint).toBeTruthy();

    const secondLine = screen.getByText('Second line of address (optional)');
    const secondLineHint =
      within(secondLine).queryByAccessibilityHint('Required');
    expect(secondLineHint).toBeFalsy();

    const thirdLine = screen.getByText('Third line of address (optional)');
    const thirdLineHint =
      within(thirdLine).queryByAccessibilityHint('Required');
    expect(thirdLineHint).toBeFalsy();

    const townOrCity = screen.getByText('Town or city');
    const townOrCityHint =
      within(townOrCity).getByAccessibilityHint('Required');
    expect(townOrCityHint).toBeTruthy();

    const postCode = screen.getByText('Postcode');
    const postCodeHint = within(postCode).getByAccessibilityHint('Required');
    expect(postCodeHint).toBeTruthy();
  });
});
