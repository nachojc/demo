import { useMemo } from 'react';
import {
  styled,
  TextProps,
  XStack,
  XStackProps,
  YStack,
  YStackProps,
} from 'tamagui';

import { Text } from '../text';

export type IndependentProgressLabels = {
  id: number;
  label: string;
};

export type IndependentProgressProps = {
  step: number;
  labels: IndependentProgressLabels[];
  containerProps?: XStackProps;
  sectionProps?: YStackProps;
  stepIndicatorProps?: XStackProps;
  labelProps?: TextProps;
};

export const IndependentProgress = ({
  step,
  labels,
  containerProps,
  sectionProps,
  stepIndicatorProps,
  labelProps,
}: IndependentProgressProps) => {
  const sections = useMemo(() => {
    return labels.map((item, index) => {
      const active = item.id <= step;
      return (
        <Section key={item.id} first={index === 0} {...sectionProps}>
          <StepIndicator
            active={active}
            {...stepIndicatorProps}
            accessibilityLabel={`step-indicator-${active}`}
          />
          <Text
            fontVariant="overline-regular-Gray800"
            tamaguiTextProps={{
              textAlign: 'center',
              marginTop: '$md',
              ...labelProps,
            }}
          >
            {item.label}
          </Text>
        </Section>
      );
    });
  }, [labels, sectionProps, step, stepIndicatorProps, labelProps]);

  return <Container {...containerProps}>{sections}</Container>;
};

const Container = styled(XStack, {
  justifyContent: 'space-between',
  paddingVertical: '$xl',
  testID: 'test-style-container',
});

const Section = styled(YStack, {
  flex: 1,
  marginLeft: '$md',
  variants: {
    first: {
      true: {
        marginLeft: '$0',
      },
    },
  },
});

const StepIndicator = styled(XStack, {
  backgroundColor: '$Gray200',
  h: '$1',
  variants: {
    active: {
      true: {
        backgroundColor: '$Success',
      },
    },
  },
});
