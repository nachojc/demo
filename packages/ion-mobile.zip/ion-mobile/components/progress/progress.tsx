import {
  Progress as RNProgress,
  ProgressIndicatorProps,
  ProgressProps as RNProgressProps,
  styled,
  TextProps,
  XStack,
  XStackProps,
  YStack,
  YStackProps,
} from 'tamagui';

import { Text } from '../text';

export type ProgressProps = RNProgressProps & {
  label?: string;
  containerProps?: YStackProps;
  labelContainerProps?: XStackProps;
  labelProps?: TextProps;
  valueProps?: TextProps;
  progressIndicatorProps?: ProgressIndicatorProps;
};

export const Progress = ({
  label,
  value,
  containerProps,
  valueProps,
  labelProps,
  labelContainerProps,
  progressIndicatorProps,
  ...props
}: ProgressProps) => {
  return (
    <Container {...containerProps} testID="progress-container">
      <RNProgress
        value={value}
        borderRadius={0}
        height="$1"
        backgroundColor="$Gray200"
        {...props}
      >
        <RNProgress.Indicator
          backgroundColor="$Success"
          {...progressIndicatorProps}
        />
      </RNProgress>
      {label && (
        <LabelContainer {...labelContainerProps}>
          <Text
            fontVariant="overline-regular-Gray800"
            tamaguiTextProps={{ ...labelProps }}
          >
            {label}
          </Text>
          <Text
            fontVariant="overline-semibold-Gray800"
            tamaguiTextProps={{ ...valueProps }}
          >
            {`${value}%`}
          </Text>
        </LabelContainer>
      )}
    </Container>
  );
};

const Container = styled(YStack, {
  paddingVertical: '$xl',
});

const LabelContainer = styled(XStack, {
  paddingTop: '$md',
  space: '$sm',
});
