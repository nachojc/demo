import { getTestId } from '@src/utils/get-test-id';
import { tokens } from '@tamagui/themes';
import { Stack, styled, XStack } from 'tamagui';

export type LevelIndicatorProps = {
  numLevels: number;
  currentLevel: number;
};

export const LevelIndicator = ({
  numLevels,
  currentLevel,
}: LevelIndicatorProps) => {
  return (
    <LevelContainer
      testID={getTestId('level-indicator')}
      aria-valuemax={numLevels}
      role="presentation"
    >
      {[...Array(numLevels)].map((_, index) => {
        return (
          <LevelBar
            key={`level-${index + 1}`}
            testID={getTestId(`level-bar-${index + 1}`)}
            barColor={{ currentLevel, index }}
          />
        );
      })}
    </LevelContainer>
  );
};

const LevelBar = styled(Stack, {
  flex: 1,
  height: 6,
  maxWidth: tokens.size['2'],
  minWidth: tokens.size['0.75'],
  borderRadius: 4,
  variants: {
    barColor: ({ currentLevel, index }) => ({
      backgroundColor: index < currentLevel ? '$WealthBlue80' : '$WealthBlue25',
    }),
  } as const,
});

const LevelContainer = styled(XStack, {
  gap: '$sm',
  width: tokens.size[12],
  alignItems: 'center',
  height: tokens.size[3],
  justifyContent: 'flex-end',
});
