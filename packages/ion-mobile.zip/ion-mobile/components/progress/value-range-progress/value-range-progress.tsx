import { useMemo } from 'react';
import {
  Progress as ValueRangeProgressBar,
  ProgressIndicatorProps,
  ProgressProps,
  TextProps,
  XStack,
  XStackProps,
} from 'tamagui';

import { Text } from '../../text';
import {
  ValueRangeContainer,
  ValueRangeLabelContainer,
} from './value-range-style';

type ValueRangeProgressProps = ProgressProps & {
  startValue: number;
  endValue: number;
  currentValue: number;
  startLabel?: string;
  endLabel?: string;
  progressIndicatorColor: '$Error' | '$Primary500' | '$Success';
  labelContainerProps?: XStackProps;
  labelContainerLeftProps?: XStackProps;
  labelContainerRightProps?: XStackProps;
  valueProps?: TextProps;
  progressIndicatorProps?: ProgressIndicatorProps;
};

export const ValueRangeProgress = ({
  startValue,
  endValue,
  currentValue,
  startLabel,
  endLabel,
  progressIndicatorColor,
  progressIndicatorProps,
  labelContainerLeftProps,
  labelContainerRightProps,
  ...rest
}: ValueRangeProgressProps) => {
  const valueRangeIndicatorPercentage = useMemo(() => {
    const fullRange = endValue - startValue;
    const complete = currentValue - startValue;
    const percentage = Math.floor((complete / fullRange) * 100);
    return percentage <= 0 ? null : Math.min(100, percentage);
  }, [startValue, endValue, currentValue]);

  return (
    <ValueRangeContainer>
      <ValueRangeProgressBar
        testID={'value-range-progress-bar'}
        value={valueRangeIndicatorPercentage}
        borderRadius="$2"
        height="$2"
        backgroundColor={'$Gray300'}
        {...rest}
      >
        <ValueRangeProgressBar.Indicator
          testID="value-range-indicator"
          backgroundColor={progressIndicatorColor}
          borderRadius={'$2'}
          {...progressIndicatorProps}
        />
      </ValueRangeProgressBar>
      <ValueRangeLabelContainer>
        {startLabel && (
          <XStack {...labelContainerLeftProps}>
            <Text fontVariant={'body-regular-Pension11'}>{startLabel}</Text>
          </XStack>
        )}
        {endLabel && (
          <XStack {...labelContainerRightProps}>
            <Text fontVariant={'body-regular-Pension11'}>{endLabel}</Text>
          </XStack>
        )}
      </ValueRangeLabelContainer>
    </ValueRangeContainer>
  );
};
