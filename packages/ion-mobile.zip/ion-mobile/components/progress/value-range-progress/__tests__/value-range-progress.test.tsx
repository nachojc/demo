import { render, screen } from '@src/jest/testing-library';

import { ValueRangeProgress } from '../value-range-progress';

const setup = () => {
  render(
    <ValueRangeProgress
      startValue={0}
      endValue={1000}
      currentValue={250}
      startLabel={'Start'}
      endLabel={'End'}
      progressIndicatorColor="$Primary500"
    />
  );
};

describe('Value Range Progress Component', () => {
  it('renders the timeline with start and end tags', () => {
    setup();

    const startsText = screen.getByText('Start');
    expect(startsText).toBeTruthy();

    const endsText = screen.getByText('End');
    expect(endsText).toBeTruthy();
  });

  it('renders the progress bar background with correct style', () => {
    setup();

    const progressbarBackground = screen.getByTestId(
      'value-range-progress-bar'
    );
    expect(progressbarBackground).toHaveStyle({
      borderTopLeftRadius: 5,
      borderTopRightRadius: 5,
      borderBottomRightRadius: 5,
      borderBottomLeftRadius: 5,
      backgroundColor: '#CCCCCC',
    });
  });

  it('renders the progress indicator with correct style', () => {
    setup();

    const indicator = screen.getByTestId('value-range-indicator');
    expect(indicator).toHaveStyle({
      borderTopLeftRadius: 5,
      borderTopRightRadius: 5,
      borderBottomRightRadius: 5,
      borderBottomLeftRadius: 5,
      backgroundColor: '#FFD900',
    });
  });
});
