import { styled, XStack, YStack } from 'tamagui';

export const ValueRangeContainer = styled(YStack, {
  width: '100%',
});

export const ValueRangeLabelContainer = styled(XStack, {
  marginTop: '$sm',
  flex: 1,
  justifyContent: 'space-between',
});
