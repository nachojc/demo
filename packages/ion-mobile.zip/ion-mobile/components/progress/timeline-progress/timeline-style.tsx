import { styled, Text, XStack, YStack } from 'tamagui';

export const TimelineContainer = styled(YStack, {
  minHeight: '$10',
  width: '100%',
});

export const TitleText = styled(Text, {
  color: '$Gray800',
  fontWeight: '600',
  fontSize: 16,
  fontFamily: '$heading',
  pb: '$md',
  variants: {
    generic: {
      true: {
        color: '$Secondary800',
      },
    },
    genericSecondary: {
      true: {
        color: '$White',
      },
    },
  } as const,
});

export const TimelineLabelContainer = styled(XStack, {
  space: '$sm',
  marginTop: '$sm',
  flex: 1,
  justifyContent: 'space-between',
});
