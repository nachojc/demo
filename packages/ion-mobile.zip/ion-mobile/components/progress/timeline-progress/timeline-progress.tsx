import { UK_DATE_FORMAT } from '@constants/string-formats';
import { getTestId } from '@src/utils/get-test-id';
import { differenceInMilliseconds, format, parse, sub } from 'date-fns';
import { useMemo } from 'react';
import {
  Progress as TimelineProgressBar,
  ProgressIndicatorProps,
  ProgressProps,
  TextProps,
  XStack,
  XStackProps,
} from 'tamagui';

import { Text } from '../../text';
import {
  TimelineContainer,
  TimelineLabelContainer,
  TitleText,
} from './timeline-style';

type TimelineProgressProps = ProgressProps & {
  startDate: string;
  endDate: string;
  progressIndicatorColor: '$Error' | '$Primary500' | '$Success';
  title?: string;
  generic?: boolean;
  genericSecondary?: boolean;
  labelContainerProps?: XStackProps;
  labelContainerLeftProps?: XStackProps;
  labelContainerRightProps?: XStackProps;
  valueProps?: TextProps;
  progressIndicatorProps?: ProgressIndicatorProps;
};

export const TimelineProgress = ({
  title,
  startDate,
  endDate,
  progressIndicatorColor,
  generic,
  genericSecondary,
  progressIndicatorProps,
  labelContainerLeftProps,
  labelContainerRightProps,
  valueProps,
  ...rest
}: TimelineProgressProps) => {
  const formatDate = (date: string) => parse(date, UK_DATE_FORMAT, new Date());

  const startDateTimeStamp = useMemo(
    () => new Date(formatDate(startDate)).getTime(),
    [startDate]
  );
  const endDateTimeStamp = useMemo(
    () => new Date(formatDate(endDate)).getTime(),
    [endDate]
  );

  const timelineIndicatorPercentage = useMemo(() => {
    const now = new Date().getTime();
    const fullTimeLength = differenceInMilliseconds(
      endDateTimeStamp,
      startDateTimeStamp
    );
    const timeAlreadySpent = differenceInMilliseconds(now, startDateTimeStamp);

    differenceInMilliseconds(now, startDateTimeStamp);

    const percentage = Math.floor((timeAlreadySpent / fullTimeLength) * 100);
    if (percentage <= 0) {
      return null;
    } else if (percentage >= 100) {
      return 100;
    } else {
      return percentage;
    }
  }, [endDateTimeStamp, startDateTimeStamp]);

  const getDateString = (date: string, yesterday?: boolean) => {
    const timestamp = formatDate(date);
    const dateToFormat = yesterday ? sub(timestamp, { days: 1 }) : timestamp;
    return format(dateToFormat, 'dd MMM YYY');
  };

  const startLabel =
    startDateTimeStamp > new Date().getTime() ? 'Cover begins:' : 'Start:';

  return (
    <TimelineContainer>
      {title ? (
        <TitleText generic={generic} genericSecondary={genericSecondary}>
          {title}
        </TitleText>
      ) : null}
      <TimelineProgressBar
        value={timelineIndicatorPercentage}
        borderRadius="$2"
        height="$2"
        backgroundColor={genericSecondary ? '$WhiteOpacity50' : '$Gray200'}
        {...rest}
      >
        <TimelineProgressBar.Indicator
          testID="timeline-indicator"
          backgroundColor={progressIndicatorColor}
          borderRadius={'$2'}
          {...progressIndicatorProps}
        />
      </TimelineProgressBar>
      <TimelineLabelContainer>
        <XStack {...labelContainerLeftProps}>
          <Text
            testID={getTestId(startDate)}
            fontVariant={`overline-regular-${
              genericSecondary ? 'White' : 'Secondary800'
            }`}
            tamaguiTextProps={{ ...valueProps }}
          >
            {`${startLabel} ${getDateString(startDate)}`}
          </Text>
        </XStack>
        <XStack {...labelContainerRightProps}>
          <Text
            testID={getTestId(endDate)}
            fontVariant={`overline-regular-${
              genericSecondary ? 'White' : 'Secondary800'
            }`}
            tamaguiTextProps={{ ...valueProps }}
          >
            {`End: ${getDateString(endDate, true)}`}
          </Text>
        </XStack>
      </TimelineLabelContainer>
    </TimelineContainer>
  );
};
