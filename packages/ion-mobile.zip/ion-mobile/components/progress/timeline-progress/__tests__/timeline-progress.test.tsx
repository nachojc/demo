import { cleanup, render, screen } from '@src/jest/testing-library';

import { TimelineProgress } from '../timeline-progress';

const mockNowDate = new Date('2023-01-08T13:33:25.494Z');

beforeAll(() => {
  jest.useFakeTimers();
  jest.setSystemTime(mockNowDate);
});
afterAll(() => {
  jest.useRealTimers();
});
afterEach(cleanup);

describe('Timeline Component', () => {
  it('renders correctly with title', () => {
    render(
      <TimelineProgress
        title="Pension Details"
        startDate="01/01/2023"
        endDate="10/01/2024"
        progressIndicatorColor="$Primary500"
      />
    );

    expect(screen.getByText('Pension Details')).toBeOnTheScreen();
  });

  it('renders correctly without title', () => {
    render(
      <TimelineProgress
        title="Pension Details"
        startDate="01/01/2023"
        endDate="10/01/2024"
        progressIndicatorColor="$Primary500"
      />
    );

    screen.getByText('Pension Details');

    screen.rerender(
      <TimelineProgress
        startDate="01/01/2023"
        endDate="10/01/2024"
        progressIndicatorColor="$Primary500"
      />
    );
    expect(screen.queryByText('Pension Details')).toBeNull();
  });

  it('renders the timeline with "Starts:" text, and with indicator if the policy is in progress', async () => {
    render(
      <TimelineProgress
        title="Pension Details"
        startDate="01/01/2023"
        endDate="10/01/2023"
        progressIndicatorColor="$Primary500"
      />
    );
    expect(await screen.findByText('Start: 01 Jan 2023')).toBeOnTheScreen();

    expect(await screen.findByText('End: 09 Jan 2023')).toBeOnTheScreen();
  });

  it('renders the timeline with "Cover begins:" text and empty indicator, if the policy has not yet started', async () => {
    render(
      <TimelineProgress
        title="Pension Details"
        startDate="10/06/2023"
        endDate="10/06/2024"
        progressIndicatorColor="$Primary500"
      />
    );
    expect(
      await screen.findByText('Cover begins: 10 Jun 2023')
    ).toBeOnTheScreen();

    expect(await screen.findByText('End: 09 Jun 2024')).toBeOnTheScreen();
  });

  it('renders the timeline with fully filled indicator, when the policy time is over', async () => {
    render(
      <TimelineProgress
        title="Pension Details"
        startDate="01/01/2022"
        endDate="10/01/2022"
        progressIndicatorColor="$Primary500"
      />
    );
    expect(await screen.findByText('Start: 01 Jan 2022')).toBeOnTheScreen();

    expect(await screen.findByText('End: 09 Jan 2022')).toBeOnTheScreen();
  });
});
