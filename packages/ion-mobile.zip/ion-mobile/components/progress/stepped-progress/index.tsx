import { getTestId } from '@src/utils/get-test-id';
import { Progress, Stack, styled, XStack, YStack, YStackProps } from 'tamagui';

import { Text } from '../../text';

export type SteppedProgressProps = {
  boldLabel?: string;
  containerProps?: YStackProps;
  currentStep: number;
  isAnimated?: boolean;
  label?: string;
  theme?: 'dark' | 'light';
  totalSteps: number;
};

// This is a reusable component across MANGA and DW. Keep inline with Figma spec here:
// https://www.figma.com/file/8CFtMGrVmDa0LH6wcl0sCl/MobileFrameworkMigration?type=design&node-id=340%3A19289&mode=design&t=xq9RytGtoRQF76sE-1
export const SteppedProgress = ({
  boldLabel,
  currentStep,
  containerProps,
  isAnimated = false,
  label,
  theme = 'light',
  totalSteps,
}: SteppedProgressProps) => {
  const fontVariantColor = theme === 'light' ? 'Gray800' : 'White';
  const activeBackgroundColor = theme === 'light' ? '$Success' : '$Primary500';

  const sections = Array.from({ length: totalSteps }, (_x, i) => i + 1).map(
    (i) => {
      const active = i <= currentStep;
      const backgroundColor = active ? activeBackgroundColor : '$Gray300';
      return (
        <StepIndicator
          key={i}
          testID={getTestId(`step-indicator-${i}`)}
          marginLeft={i === 1 ? '$0' : '$md'}
          backgroundColor={backgroundColor}
        >
          {isAnimated && (
            <Stack flex={1} overflow="hidden">
              <Progress value={active ? 100 : 0} backgroundColor={'$Gray300'}>
                <Progress.Indicator
                  animation="slower"
                  backgroundColor={backgroundColor}
                />
              </Progress>
            </Stack>
          )}
        </StepIndicator>
      );
    }
  );

  return (
    <Container {...containerProps}>
      <Section>{sections}</Section>
      <XStack
        accessible
        accessibilityLabel={`Progress bar. ${label}. ${boldLabel ?? ''}`}
        testID={getTestId('steps-label-container')}
      >
        <Text
          fontVariant={`overline-regular-${fontVariantColor}`}
          tamaguiTextProps={{
            testID: getTestId('step-indicator-text'),
            accessible: false,
          }}
        >
          {label}
        </Text>
        {!!boldLabel && (
          <Text
            tamaguiTextProps={{ marginLeft: 4, accessible: false }}
            fontVariant={`overline-semibold-${fontVariantColor}`}
          >
            {boldLabel}
          </Text>
        )}
      </XStack>
    </Container>
  );
};

const Container = styled(YStack, { paddingVertical: '$xl' });
const Section = styled(XStack, {
  justifyContent: 'space-between',
  marginBottom: '$md',
});
const StepIndicator = styled(XStack, {
  height: '$1',
  flex: 1,
  backgroundColor: '$Gray200',
});
