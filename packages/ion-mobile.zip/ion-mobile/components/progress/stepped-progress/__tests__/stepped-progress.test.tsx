import { cleanup, render, screen } from '@src/jest/testing-library';

import { SteppedProgress } from '..';

const backgroundColor = {
  lightDefault: '#4F9F31',
  darkDefault: '#FFD900',
  background: '#CCCCCC',
};

const fontColor = {
  light: '#373737',
  dark: '#FFFFFF',
};

describe('SteppedProgress Component', () => {
  afterEach(cleanup);

  it('should render with the given label in regular font weight', () => {
    render(
      <SteppedProgress
        label={'Progress label'}
        currentStep={2}
        totalSteps={5}
      />
    );
    expect(screen.getByText('Progress label')).toHaveStyle({
      fontFamily: 'SourceSansPro-Regular',
    });
  });

  it('should render with the given bold label in semiBold font weight', () => {
    render(
      <SteppedProgress
        boldLabel={'step 3 of 4'}
        currentStep={3}
        totalSteps={4}
      />
    );

    expect(screen.getByText('step 3 of 4')).toHaveStyle({
      color: '#373737',
      fontFamily: 'SourceSansPro-SemiBold',
    });
  });

  it("should render the text in 'White' when the given theme is 'dark'", () => {
    render(
      <SteppedProgress
        label={'step 3 of 4'}
        currentStep={3}
        totalSteps={4}
        theme="dark"
      />
    );

    expect(screen.getByText('step 3 of 4')).toHaveStyle({
      color: fontColor.dark,
    });
  });

  it("should render the text in 'Gray800' when the given theme is 'light'", () => {
    render(
      <SteppedProgress
        label={'step 3 of 4'}
        currentStep={3}
        totalSteps={4}
        theme="light"
      />
    );

    expect(screen.getByText('step 3 of 4')).toHaveStyle({
      color: fontColor.light,
    });
  });

  it('should render with the correct color for the inactive steps', () => {
    render(<SteppedProgress currentStep={1} totalSteps={4} />);
    const step3 = screen.getByTestId('test:id/step-indicator-3');

    expect(step3).toHaveStyle({ backgroundColor: backgroundColor.background });
  });

  it('should render with the correct color for the active steps when the theme is light', () => {
    render(<SteppedProgress currentStep={2} totalSteps={4} />);

    const step1 = screen.getByTestId('test:id/step-indicator-1');
    expect(step1).toHaveStyle({
      backgroundColor: backgroundColor.lightDefault,
    });
  });

  it('should render with the correct color for the active steps when the theme is dark', () => {
    render(<SteppedProgress currentStep={2} totalSteps={4} theme="dark" />);

    const step1 = screen.getByTestId('test:id/step-indicator-1');
    expect(step1).toHaveStyle({ backgroundColor: backgroundColor.darkDefault });
  });

  it('should render with the correct number of progress bars given a totalCount', () => {
    render(<SteppedProgress currentStep={3} totalSteps={7} />);
    expect(screen.getByTestId('test:id/step-indicator-7')).toBeOnTheScreen();
  });

  it('should render with the correct accessibility label for steps when both labels present', () => {
    render(
      <SteppedProgress
        currentStep={3}
        totalSteps={7}
        label="Step text"
        boldLabel="Step 3 of 7"
      />
    );

    const container = screen.getByTestId('test:id/steps-label-container');

    expect(container).toHaveProp(
      'accessibilityLabel',
      'Progress bar. Step text. Step 3 of 7'
    );
  });

  it('should render with the correct accessibility label for steps when only one label is present', () => {
    render(
      <SteppedProgress
        currentStep={3}
        totalSteps={7}
        label="Step text"
        boldLabel="Step 3 of 7"
      />
    );

    const container = screen.getByTestId('test:id/steps-label-container');

    expect(container).toHaveProp(
      'accessibilityLabel',
      'Progress bar. Step text. Step 3 of 7'
    );
  });
});
