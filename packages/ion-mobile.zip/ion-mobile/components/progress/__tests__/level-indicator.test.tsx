import { render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { LevelIndicator } from '../level-indicator';

describe('Level indicator component', () => {
  it('renders indicator with the correct number of levels and the correct styling', () => {
    render(<LevelIndicator numLevels={4} currentLevel={3} />);

    expect(screen.getByTestId(getTestId('level-indicator'))).toBeOnTheScreen();

    const bars = screen.getAllByTestId(/level-bar/);
    expect(bars).toHaveLength(4);

    const bar3 = screen.getByTestId(getTestId('level-bar-3'));
    expect(bar3).toHaveStyle({ backgroundColor: '#364357' });

    const bar4 = screen.getByTestId(getTestId('level-bar-4'));
    expect(bar4).toHaveStyle({ backgroundColor: '#C0C4CA' });
  });
});
