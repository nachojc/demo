import { render, screen } from '@src/jest/testing-library';

import { IndependentProgress } from '../independent-progress';

describe('IndependentProgress', () => {
  const labels = [
    { id: 1, label: 'Step 1' },
    { id: 2, label: 'Step 2' },
    { id: 3, label: 'Step 3' },
  ];

  it('marks the correct steps active', () => {
    render(<IndependentProgress step={2} labels={labels} />);
    const activeSteps = screen.getAllByLabelText('step-indicator-true');
    expect(activeSteps).toHaveLength(2);
  });

  it('renders the container and with the correct style', () => {
    render(<IndependentProgress step={1} labels={labels} />);

    const container = screen.getByTestId('test-style-container');
    expect(container).toHaveStyle({
      justifyContent: 'space-between',
    });
  });

  it('renders steps correctly', () => {
    render(<IndependentProgress step={1} labels={labels} />);
    const step1 = screen.getByText(labels[0].label);
    expect(step1).toBeDefined();
    const step2 = screen.getByText(labels[1].label);
    expect(step2).toBeDefined();
    const step3 = screen.getByText(labels[2].label);
    expect(step3).toBeDefined();
  });
});
