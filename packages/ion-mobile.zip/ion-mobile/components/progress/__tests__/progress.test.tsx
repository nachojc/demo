import { render, screen } from '@src/jest/testing-library';

import { Progress } from '../progress';

describe('Progress component', () => {
  it('renders label and value correctly', () => {
    const label = 'Progress Label';
    const value = 3;
    render(<Progress label={label} value={value} />);

    expect(screen.getByText(label)).toBeOnTheScreen();
    expect(screen.getByText(`${value}%`)).toBeOnTheScreen();
  });

  it('renders with containerProps', () => {
    const containerTestId = 'progress-container';
    render(
      <Progress
        label="Progress Label"
        value={3}
        containerProps={{ testID: containerTestId }}
      />
    );

    expect(screen.getByTestId(containerTestId)).toBeOnTheScreen();
  });
});
