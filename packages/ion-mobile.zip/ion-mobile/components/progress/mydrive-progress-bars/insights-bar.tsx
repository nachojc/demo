import { getRagStatusAccessibilityLabel } from '@src/features/mydrive/utils';
import { pluraliseWord } from '@src/features/mydrive/utils/format-string';
import { Stack, XStack, YStack } from 'tamagui';

import { Icon, IconName } from '../../icon';
import { Text } from '../../text';
import { Progress } from '../progress';

type InsightsBarProps = {
  title: string;
  iconName: IconName;
  comparison: number;
  score: number;
};

const getScoreColor = (score: number) => {
  if (score >= 80 && score <= 100) {
    return 'heading5-semibold-Success';
  }
  if (score >= 59 && score <= 79) {
    return 'heading5-semibold-FeedbackWarningText';
  }
  return 'heading5-semibold-Error';
};

const getComparisonColor = (comparison: number) => {
  if (comparison === 0) {
    return 'heading5-semibold-Secondary800';
  }
  if (comparison > 0) {
    return 'heading5-semibold-Success';
  }
  return 'heading5-semibold-Error';
};

const getAccessibilityLabel = (
  title: string,
  score: number,
  comparison: number
) => {
  const ragAccessibilityLabel = getRagStatusAccessibilityLabel(score);
  let comparisonText: string;
  switch (true) {
    case comparison > 0:
      comparisonText = `${comparison} ${pluraliseWord(
        comparison,
        'point'
      )} higher than`;
      break;
    case comparison < 0:
      comparisonText = `${comparison * -1} ${pluraliseWord(
        comparison,
        'point'
      )} lower than`;
      break;
    default:
      comparisonText = 'no change from';
      break;
  }
  return `${title} score, ${score} out of 100, ${comparisonText} last week. ${ragAccessibilityLabel}`;
};

export const InsightsBar = ({
  title,
  iconName,
  comparison,
  score,
}: InsightsBarProps) => {
  const scoreOutColor = getScoreColor(score);
  const comparisonColor = getComparisonColor(comparison);
  const accessibilityLabel = getAccessibilityLabel(title, score, comparison);
  return (
    <YStack accessible accessibilityLabel={accessibilityLabel}>
      <Stack
        accessibilityElementsHidden
        importantForAccessibility="no-hide-descendants"
        gap="$sm"
      >
        <XStack justifyContent="space-between">
          <XStack gap="$md">
            <Icon name={iconName} />
            <Text fontVariant="body-semibold-Secondary800">{title}</Text>
          </XStack>
          <Text fontVariant="heading5-semibold-Secondary800">
            <Text fontVariant={scoreOutColor}>{score}</Text>
            {' ' + '('}
            <Text fontVariant={comparisonColor}>
              {(comparison > 0 ? '+' : '') + comparison}
            </Text>
            {')'}
          </Text>
        </XStack>

        <Progress
          value={score}
          containerProps={{ py: '$-xl' }}
          borderRadius="$2"
          height="$2"
          backgroundColor="$Gray300"
          progressIndicatorProps={{ bg: '$Secondary800', borderRadius: '$2' }}
        />

        <XStack justifyContent="space-between">
          <Text fontVariant="labelSmall-semibold-Secondary800">UNSAFE</Text>
          <Text fontVariant="labelSmall-semibold-Secondary800">SAFE</Text>
        </XStack>
      </Stack>
    </YStack>
  );
};
