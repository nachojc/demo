import { pluraliseWord } from '@src/features/mydrive/utils/format-string';
import { useState } from 'react';
import { XStack, YStack } from 'tamagui';

import { Text } from '../../text';
import { Progress } from '../progress';

export type MyDriveMetrics = 'day' | 'mile';

type MyDriveProgressBarProps = {
  goal: number;
  metric: MyDriveMetrics;
  score: number;
};

const getProgressValue = (
  score: number,
  goal: number,
  minProgressValue: number
) => {
  if (score >= goal) {
    return 100;
  }
  return (
    Math.round((score / goal) * (100 - minProgressValue)) + minProgressValue
  );
};

export const MyDriveProgressBar = ({
  goal,
  metric,
  score,
}: MyDriveProgressBarProps) => {
  const [minProgressValue, setMinProgressValue] = useState(0);

  const scorePlural = pluraliseWord(score, metric);
  const goalPlural = pluraliseWord(goal, metric);
  const metricPlural =
    metric === 'mile' ? scorePlural : `${scorePlural} driving`;

  return (
    <YStack
      space={8}
      accessible
      accessibilityLabel={`${score} ${metricPlural} completed. Your goal is ${goal} ${metricPlural}`}
    >
      <Progress
        value={getProgressValue(score, goal, minProgressValue)}
        containerProps={{ paddingVertical: '$-xl' }}
        borderRadius="$2"
        height="$2"
        onLayout={(e) =>
          setMinProgressValue(
            (e.nativeEvent.layout.height / e.nativeEvent.layout.width) * 100
          )
        }
        backgroundColor="$Gray300"
        progressIndicatorProps={{ bg: '$Secondary800', borderRadius: '$2' }}
      />
      <XStack justifyContent="space-between">
        <Text fontVariant="overline-regular-Gray800">{`${score} ${scorePlural} completed`}</Text>
        <Text fontVariant="overline-regular-Gray800">{`Goal: ${goal} ${goalPlural}`}</Text>
      </XStack>
    </YStack>
  );
};
