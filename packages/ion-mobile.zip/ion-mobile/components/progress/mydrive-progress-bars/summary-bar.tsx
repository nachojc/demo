import { getRagStatusAccessibilityLabel } from '@src/features/mydrive/utils';
import { XStack, YStack } from 'tamagui';

import { Text } from '../../text';
import { Progress } from '../progress';

type SummaryBarProps = {
  title: string;
  score: number;
};

const getScoreColor = (score: number) => {
  if (score >= 80 && score <= 100) {
    return 'heading4-semibold-Success';
  }
  if (score >= 59 && score <= 79) {
    return 'heading4-semibold-FeedbackWarningText';
  }
  return 'heading4-semibold-Error';
};

export const SummaryBar = ({ title, score }: SummaryBarProps) => {
  const scoreOutColor = getScoreColor(score);
  const ragAccessibilityLabel = getRagStatusAccessibilityLabel(score);
  const accessibilityLabel = `${title} is ${score} out of 100. ${ragAccessibilityLabel}`;
  return (
    <YStack space={4} accessible accessibilityLabel={accessibilityLabel}>
      <XStack
        justifyContent="space-between"
        alignItems="center"
        accessibilityElementsHidden
        importantForAccessibility="no-hide-descendants"
      >
        <XStack space={8}>
          <Text fontVariant={'small-regular-Gray900'}>{title}</Text>
        </XStack>
        <Text fontVariant="heading4-semibold-Secondary800">
          <Text fontVariant={scoreOutColor}>{score}</Text>
          <Text fontVariant={'heading4-semibold-Secondary800'}>/100</Text>
        </Text>
      </XStack>
      <Progress
        value={score}
        containerProps={{ paddingVertical: '$-xl' }}
        borderRadius="$2"
        height="$2"
        backgroundColor="$Gray300"
        progressIndicatorProps={{
          backgroundColor: '$Secondary800',
          borderRadius: '$2',
        }}
      />
    </YStack>
  );
};
