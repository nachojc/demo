import { getScoreWithRagStatusAccessibilityLabel } from '@src/features/mydrive/utils';
import { Stack, XStack, YStack } from 'tamagui';

import { Icon, IconName } from '../../icon';
import { Text } from '../../text';
import { Progress } from '../progress';

type ScoreBarProps = {
  title: string;
  iconName: IconName;
  score: number;
};

const getScoreTextColor = (score: number) => {
  if (score >= 80 && score <= 100) {
    return 'heading5-semibold-Success';
  }
  if (score >= 59 && score <= 79) {
    return 'heading5-semibold-FeedbackWarningText';
  }
  return 'heading5-semibold-Error';
};

const getScoreProgressIndicatorColor = (score: number) => {
  if (score >= 80 && score <= 100) {
    return '$Success';
  }
  if (score >= 59 && score <= 79) {
    return '$Warning';
  }
  return '$Error';
};

export const ScoreBar = ({ title, iconName, score }: ScoreBarProps) => {
  const scoreTextColor = getScoreTextColor(score);
  const scoreProgressColor = getScoreProgressIndicatorColor(score);
  const accessibilityLabel = getScoreWithRagStatusAccessibilityLabel(
    title,
    score
  );
  return (
    <YStack accessible accessibilityLabel={accessibilityLabel}>
      <Stack
        accessibilityElementsHidden
        importantForAccessibility="no-hide-descendants"
        gap="$sm"
      >
        <XStack justifyContent="space-between">
          <XStack gap="$md">
            <Icon name={iconName} />
            <Text fontVariant="body-semibold-Secondary800">{title}</Text>
          </XStack>
          <Text fontVariant={scoreTextColor}>{score}</Text>
        </XStack>

        <Progress
          value={score}
          containerProps={{ py: '$-xl' }}
          borderRadius="$2"
          height="$2"
          backgroundColor="$Gray300"
          progressIndicatorProps={{
            bg: scoreProgressColor,
            borderRadius: '$2',
          }}
        />

        <XStack justifyContent="space-between">
          <Text fontVariant="labelSmall-semibold-Secondary800">UNSAFE</Text>
          <Text fontVariant="labelSmall-semibold-Secondary800">SAFE</Text>
        </XStack>
      </Stack>
    </YStack>
  );
};
