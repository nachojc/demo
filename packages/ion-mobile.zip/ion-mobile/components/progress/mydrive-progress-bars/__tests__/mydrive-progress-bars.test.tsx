import { render, screen } from '@src/jest/testing-library';

import { InsightsBar } from '../insights-bar';
import { MyDriveProgressBar } from '../mydrive-progress-bar';
import { ScoreBar } from '../score-bar';
import { SummaryBar } from '../summary-bar';

const title = 'test title';
const greenAccessibilityLabel =
  "This is green, which means you're driving well";
const amberAccessibilityLabel =
  'This is amber, which means you are driving well but there is room for improvement';
const redAccessibilityLabel =
  'This is red, which means there is room for improvement';

describe('SummaryBar', () => {
  it('renders the title and score correctly', () => {
    render(<SummaryBar title={title} score={90} />);
    expect(
      screen.getByText(title, { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('90/100', { includeHiddenElements: true })
    ).toBeTruthy();
  });
  it.each`
    score  | colour       | accessibilityLabel
    ${0}   | ${'#BD2624'} | ${'This is red, which means there is room for improvement'}
    ${58}  | ${'#BD2624'} | ${'This is red, which means there is room for improvement'}
    ${59}  | ${'#F16E00'} | ${'This is amber, which means you are driving well but there is room for improvement'}
    ${79}  | ${'#F16E00'} | ${'This is amber, which means you are driving well but there is room for improvement'}
    ${80}  | ${'#4F9F31'} | ${"This is green, which means you're driving well"}
    ${100} | ${'#4F9F31'} | ${"This is green, which means you're driving well"}
  `(
    'should be $colour with accessibility label $accessibilityLabel when the score is $score',
    ({ score, colour, accessibilityLabel }) => {
      render(<SummaryBar title={title} score={score} />);
      expect(
        screen.getByText(`${score}`, { includeHiddenElements: true })
      ).toHaveStyle({
        color: colour,
      });
      expect(
        screen.getByLabelText(
          `${title} is ${score} out of 100. ${accessibilityLabel}`
        )
      ).toBeTruthy();
    }
  );
});

describe('ScoreBar', () => {
  it('renders the title, icon and score correctly', () => {
    render(<ScoreBar title={title} iconName={'acceleration'} score={5} />);
    expect(
      screen.getByText(title, { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByTestId('test:id/icon-acceleration', {
        includeHiddenElements: true,
      })
    ).toBeTruthy();
    expect(screen.getByText('5', { includeHiddenElements: true })).toBeTruthy();
  });
  it.each`
    score  | colour       | accessibilityLabel
    ${0}   | ${'#BD2624'} | ${redAccessibilityLabel}
    ${58}  | ${'#BD2624'} | ${redAccessibilityLabel}
    ${59}  | ${'#F16E00'} | ${amberAccessibilityLabel}
    ${79}  | ${'#F16E00'} | ${amberAccessibilityLabel}
    ${80}  | ${'#4F9F31'} | ${greenAccessibilityLabel}
    ${100} | ${'#4F9F31'} | ${greenAccessibilityLabel}
  `(
    'should be $colour with accessibility label $accessibilityLabel when the score is $score',
    ({ score, colour, accessibilityLabel }) => {
      render(
        <ScoreBar title={title} iconName={'acceleration'} score={score} />
      );
      expect(
        screen.getByText(`${score}`, { includeHiddenElements: true })
      ).toHaveStyle({
        color: colour,
      });
      expect(
        screen.getByLabelText(
          `Your ${title} score is ${score} out of 100. ${accessibilityLabel}`
        )
      ).toBeTruthy();
    }
  );
});

describe('MyDriveProgressBar', () => {
  it('renders the text for goal/score singular correctly', () => {
    render(<MyDriveProgressBar goal={1} score={1} metric="day" />);
    expect(screen.getByText('Goal: 1 day', { exact: true })).toBeTruthy();
    expect(screen.getByText('1 day completed', { exact: true })).toBeTruthy();
  });
  it('renders the text for goal/score plural correctly', () => {
    render(<MyDriveProgressBar goal={100} score={56} metric="mile" />);
    expect(screen.getByText('Goal: 100 miles', { exact: true })).toBeTruthy();
    expect(
      screen.getByText('56 miles completed', { exact: true })
    ).toBeOnTheScreen();
  });
  it('renders the accessibility label for goal/score singular correctly', () => {
    render(<MyDriveProgressBar goal={1} score={1} metric="day" />);
    expect(
      screen.getByLabelText(
        '1 day driving completed. Your goal is 1 day driving'
      )
    ).toBeOnTheScreen();
  });
  it('renders the accessibility label for goal/score plural correctly', () => {
    render(<MyDriveProgressBar goal={100} score={56} metric="mile" />);
    expect(
      screen.getByLabelText('56 miles completed. Your goal is 100 miles')
    ).toBeOnTheScreen();
  });
});

describe('InsightsBar', () => {
  it('renders the title, icon and the score correctly', () => {
    render(
      <InsightsBar
        title={title}
        iconName={'speed'}
        comparison={-45}
        score={67}
      />
    );
    expect(
      screen.getByText('test title', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByTestId('test:id/icon-speed', { includeHiddenElements: true })
    ).toBeTruthy();
    expect(
      screen.getByText('67', { includeHiddenElements: true })
    ).toBeTruthy();
  });
  it('renders the negative comparison number correctly', () => {
    render(
      <InsightsBar
        title={title}
        iconName={'speed'}
        comparison={-45}
        score={67}
      />
    );
    expect(
      screen.getByText('-45', { includeHiddenElements: true })
    ).toBeTruthy();
  });
  it('renders the positive comparison number correctly', () => {
    render(
      <InsightsBar
        title={title}
        iconName={'speed'}
        comparison={+45}
        score={67}
      />
    );
    expect(
      screen.getByText('+45', { includeHiddenElements: true })
    ).toBeTruthy();
  });

  describe('comparison number renders right colors', () => {
    it('when positive', () => {
      render(
        <InsightsBar
          title={title}
          iconName={'speed'}
          comparison={+45}
          score={67}
        />
      );
      expect(
        screen.getByText('+45', { includeHiddenElements: true })
      ).toHaveStyle({
        color: '#4F9F31',
      });
    });
    it('when negative', () => {
      render(
        <InsightsBar
          title={title}
          iconName={'speed'}
          comparison={-45}
          score={67}
        />
      );
      expect(
        screen.getByText('-45', { includeHiddenElements: true })
      ).toHaveStyle({
        color: '#BD2624',
      });
    });
    it('when zero', () => {
      render(
        <InsightsBar
          title={title}
          iconName={'speed'}
          comparison={0}
          score={67}
        />
      );
      expect(
        screen.getByText('0', { includeHiddenElements: true })
      ).toHaveStyle({
        color: '#122D44',
      });
    });
  });

  it.each`
    score  | colour       | accessibilityLabel         | comparison | comparisonText
    ${0}   | ${'#BD2624'} | ${redAccessibilityLabel}   | ${5}       | ${'5 points higher than'}
    ${58}  | ${'#BD2624'} | ${redAccessibilityLabel}   | ${-5}      | ${'5 points lower than'}
    ${59}  | ${'#F16E00'} | ${amberAccessibilityLabel} | ${1}       | ${'1 point higher than'}
    ${79}  | ${'#F16E00'} | ${amberAccessibilityLabel} | ${-1}      | ${'1 point lower than'}
    ${80}  | ${'#4F9F31'} | ${greenAccessibilityLabel} | ${0}       | ${'no change from'}
    ${100} | ${'#4F9F31'} | ${greenAccessibilityLabel} | ${0}       | ${'no change from'}
  `(
    'should be $colour with accessibility label $accessibilityLabel when the score is $score',
    ({ score, colour, accessibilityLabel, comparison, comparisonText }) => {
      render(
        <InsightsBar
          title={title}
          iconName={'speed'}
          comparison={comparison}
          score={score}
        />
      );
      expect(
        screen.getByText(`${score}`, { includeHiddenElements: true })
      ).toHaveStyle({
        color: colour,
      });
      expect(
        screen.getByLabelText(
          `${title} score, ${score} out of 100, ${comparisonText} last week. ${accessibilityLabel}`
        )
      ).toBeTruthy();
    }
  );
});
