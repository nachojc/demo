import { getTestId } from '@src/utils/get-test-id';
import { XStack, YStack } from 'tamagui';

import { Text } from '../../text';

export type StepperTheme = 'dark' | 'light' | undefined;

export type SteppedProgressProps = {
  boldLabel?: string;
  currentStep: number;
  label?: string;
  theme?: StepperTheme;
  totalSteps: number;
};

// This is a reusable component, keep inline with Figma spec here:
// https://www.figma.com/file/Rwqute4FOfY8VsJIYrTler/Navigator-%7C-Advice-Summary?type=design&node-id=190%3A14791&mode=design&t=oZPSyLwoBGXAFRxn-1
export const SimpleWealthProgressStepper = ({
  boldLabel,
  currentStep,
  label,
  theme = 'light',
  totalSteps,
}: SteppedProgressProps) => {
  const fontVariantColor = theme === 'light' ? 'White' : 'WealthBlue';
  const activeBackgroundColor = theme === 'light' ? '$White' : '$WealthBlue';

  const sections = Array.from({ length: totalSteps }, (_x, i) => i + 1).map(
    (i) => {
      const active = i <= currentStep;
      const backgroundColor = active ? activeBackgroundColor : '$Gray400';
      return (
        <XStack
          height={'$1'}
          flex={1}
          key={i}
          testID={getTestId(`progress-step-${i}`)}
          marginLeft={i === 1 ? '$0' : '$md'}
          backgroundColor={backgroundColor}
        />
      );
    }
  );

  return (
    <YStack
      testID={getTestId('navigator-progress-stepper')}
      paddingVertical={'$xl'}
    >
      <XStack justifyContent={'space-between'} marginBottom={'$md'}>
        {sections}
      </XStack>
      <XStack
        accessible
        accessibilityLabel={`${boldLabel}. ${label}`}
        gap={'$sm'}
      >
        <Text fontVariant={`overline-semibold-${fontVariantColor}`}>
          {boldLabel}
        </Text>
        <Text fontVariant={`overline-semibold-${fontVariantColor}`}>•</Text>
        <Text
          fontVariant={`overline-regular-${fontVariantColor}`}
          tamaguiTextProps={{ testID: getTestId('step-indicator-text') }}
        >
          {label}
        </Text>
      </XStack>
    </YStack>
  );
};
