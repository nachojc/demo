import { cleanup, render, screen } from '@src/jest/testing-library';

import { SimpleWealthProgressStepper } from '../simple-wealth-progress-stepper';

const boldLabel = 'Current Screen';
const label = 'Step 2 of 10';
const fontColor = {
  light: '#FFFFFF',
  dark: '#05142D',
};
const backgroundColor = {
  default: '#7E7E7E',
  light: '#FFFFFF',
  dark: '#05142D',
};

const renderScreen = (theme?: 'light' | 'dark') => {
  render(
    <SimpleWealthProgressStepper
      boldLabel={boldLabel}
      currentStep={2}
      label={label}
      theme={theme}
      totalSteps={10}
    />
  );
};

describe('Simple Wealth Progress Stepper Component', () => {
  afterEach(cleanup);

  it('should render with the given label in regular font weight', () => {
    renderScreen();
    expect(screen.getByText(label)).toHaveStyle({
      fontFamily: 'SourceSansPro-Regular',
    });
  });

  it('should render with the given bold label in semiBold font weight', () => {
    renderScreen();
    expect(screen.getByText(boldLabel)).toHaveStyle({
      fontFamily: 'SourceSansPro-SemiBold',
    });
  });

  it("should render the text in 'White' when the given theme is 'light'", () => {
    renderScreen();
    expect(screen.getByText(label)).toHaveStyle({
      color: fontColor.light,
    });
  });

  it("should render the text in 'WealthBlue' when the given theme is 'dark'", () => {
    renderScreen('dark');
    expect(screen.getByText(label)).toHaveStyle({
      color: fontColor.dark,
    });
  });

  it('should render with the correct color for the inactive steps', () => {
    renderScreen();
    const step3 = screen.getByTestId('test:id/progress-step-3');
    expect(step3).toHaveStyle({ backgroundColor: backgroundColor.default });
  });

  it('should render with the correct color for the active steps when the theme is "light"', () => {
    renderScreen();
    const step1 = screen.getByTestId('test:id/progress-step-1');
    expect(step1).toHaveStyle({
      backgroundColor: backgroundColor.light,
    });
  });

  it('should render with the correct color for the active steps when the theme is dark', () => {
    renderScreen('dark');
    const step1 = screen.getByTestId('test:id/progress-step-1');
    expect(step1).toHaveStyle({ backgroundColor: backgroundColor.dark });
  });

  it('should render with the correct number of progress bars given a totalCount', () => {
    renderScreen();
    const step7 = screen.getByTestId('test:id/progress-step-7');
    expect(step7).toBeOnTheScreen();
  });
});
