import { forwardRef } from 'react';
import FastImage, { FastImageProps } from 'react-native-fast-image';

export type ImageProps = FastImageProps;

export const Image = forwardRef(function Image(props: ImageProps, _ref) {
  return <FastImage {...props} />;
});
