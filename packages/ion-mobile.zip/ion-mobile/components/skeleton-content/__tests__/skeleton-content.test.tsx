import { render, screen } from '@src/jest/testing-library';

import { SkeletonContent } from '../skeleton-content';

const layout = [
  { key: 'skeleton-line-1', width: 200, height: 16, marginTop: 32 },
  { key: 'skeleton-line-2', width: 240, height: 16, marginTop: 16 },
  { key: 'skeleton-line-3', width: 300, height: 16, marginTop: 8 },
  { key: 'skeleton-line-4', width: 140, height: 24, marginTop: 16 },
];

const mockProps = { height: 200, width: 100, layout };

describe('SkeletonContent', () => {
  it('renders with accesibility labelling that indicates the purpose of the element', () => {
    render(<SkeletonContent {...mockProps} />);

    expect(screen.getByLabelText('content-loading')).toHaveAccessibilityValue(
      'aria-busy'
    );
  });

  it('renders the skeleton content lines with the desired dimensions', () => {
    render(<SkeletonContent {...mockProps} />);

    expect(screen.getByTestId('skeleton-line-1')).toHaveStyle({
      width: 200,
      height: 16,
      marginTop: 32,
    });
    expect(screen.getByTestId('skeleton-line-2')).toHaveStyle({
      width: 240,
      height: 16,
      marginTop: 16,
    });
  });
});
