export * from './skeleton-content';
