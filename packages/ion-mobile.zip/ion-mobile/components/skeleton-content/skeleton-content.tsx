import { XStack, YStack } from 'tamagui';

// TO DO Add shimmering animation effect when an animation library has been decided upon and configured

type SkeletonLayout = {
  key: string;
  width: number | `${number}%`;
  height: number;
  marginTop: number;
};

export const SkeletonContent = ({
  height,
  width,
  // You must define the layout of the skeleton content and define the dimensions of the skeleton bones
  // The width can be a percentage or a unit value
  layout,
}: {
  width: number | `${number}%`;
  height: number;
  layout: SkeletonLayout[];
}) => {
  return (
    <XStack
      height={height}
      width={width}
      backgroundColor="$Gray400"
      borderRadius={8}
      aria-busy
      accessibilityLabel="content-loading"
    >
      <YStack justifyContent="flex-end" padding={16} fullscreen flex={1}>
        {layout?.map((dimensions) => {
          return (
            <XStack
              bc="$Gray200"
              {...dimensions}
              key={dimensions.key}
              testID={dimensions.key}
              overflow="hidden"
            />
          );
        })}
      </YStack>
    </XStack>
  );
};
