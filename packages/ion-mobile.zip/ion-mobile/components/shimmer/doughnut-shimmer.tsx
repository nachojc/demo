import { TokensMerged } from '@tamagui/web';
import { getTokens, getVariableValue, Stack } from 'tamagui';

import { ColorScheme, getColors, Shimmer } from './shimmer';

type DoughnutShimmerProps = {
  colorScheme?: ColorScheme;
  radius?: number;
  thickness?: number;
};

const getCircleCenterColor = (
  colorScheme: ColorScheme,
  tokens: TokensMerged
) => {
  if (colorScheme === 'light') {
    return getVariableValue(tokens.color.White);
  } else {
    return getColors(tokens, colorScheme).highlightColor;
  }
};

const defaultRadius = 107;
const defaultThickness = 66;

/** provides an animated doughnut shaped loading effect component. */
export const DoughnutShimmer = ({
  colorScheme = 'light',
  radius = defaultRadius,
  thickness = defaultThickness,
}: DoughnutShimmerProps) => {
  const tokens = getTokens();
  const outerSize = radius * 2;
  const innerSize = outerSize - thickness;
  const shimmerSize = radius * 2;
  const topPositionForInnerCircle = thickness / 2;

  return (
    <Stack
      style={{
        borderRadius: radius,
        width: outerSize,
        height: outerSize,
        overflow: 'hidden',
      }}
      accessibilityLabel="Loading visual"
    >
      <Shimmer
        width={shimmerSize}
        height={shimmerSize}
        colorScheme={colorScheme}
      />
      <Stack
        backgroundColor={getCircleCenterColor(colorScheme, tokens)}
        style={{
          borderRadius: innerSize / 2,
          width: innerSize,
          height: innerSize,
          position: 'absolute',
          top: topPositionForInnerCircle,
          alignSelf: 'center',
        }}
      />
    </Stack>
  );
};
