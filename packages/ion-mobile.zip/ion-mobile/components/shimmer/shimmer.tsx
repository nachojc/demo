import { TokensMerged } from '@tamagui/web';
import { useEffect, useRef, useState } from 'react';
import { Animated, Dimensions, Easing, View } from 'react-native';
import { getTokens, getVariableValue, Stack } from 'tamagui';
import { LinearGradient } from 'tamagui/linear-gradient';

const SCREEN_WIDTH = Dimensions.get('screen').width;
const START = -1;
const END = 1;
const DURATION = 2000;
const LOCATIONS = [0.3, 0.5, 0.7];

export type ColorScheme = 'light' | 'dark';

type ShimmerProps = {
  width: number | string;
  height: number | string;
  borderRadius?: number;
  colorScheme?: ColorScheme;
  shimmerWidth?: number;
  testID?: string;
  linearOpts?: Partial<{
    locations: number[];
    colors: string[];
  }>;
  animationOpts?: Omit<
    Animated.TimingAnimationConfig,
    'toValue' | 'useNativeDriver'
  >;
};

export const getColors = (tokens: TokensMerged, colorScheme: ColorScheme) => {
  if (colorScheme === 'dark') {
    return {
      backgroundColor: getVariableValue(tokens.color.ShimmerGrayDark),
      highlightColor: getVariableValue(tokens.color.WealthBlue95),
    };
  }

  return {
    backgroundColor: getVariableValue(tokens.color.GrayShimmerBG),
    highlightColor: getVariableValue(tokens.color.Gray300),
  };
};

/**
 * @description
 * Shimmer provides an animated loading effect for components.
 * @example
 * A rectangular shaped shimmer using the default colour scheme (light)
 * <Shimmer width={140} height={20} />
 *
 * A rectangular shaped shimmer using the dark colour scheme
 * <Shimmer width={140} height={20} colorScheme={'dark'} />
 *
 * * A rectangular shaped shimmer using the light colour scheme
 * <Shimmer width={140} height={20} colorScheme={'light'} />
 *
 */

export const Shimmer = ({
  width,
  height,
  colorScheme = 'light',
  borderRadius,
  animationOpts,
  linearOpts,
  shimmerWidth = SCREEN_WIDTH,
  testID,
}: ShimmerProps) => {
  // with these variables being global before, it is enterfered by one implementation
  // thus causing unexpected behaviour for multiple implementations
  const ANIMATION = useRef(new Animated.Value(START));

  const linear = ANIMATION.current.interpolate({
    inputRange: [START, END],
    outputRange: [-SCREEN_WIDTH, SCREEN_WIDTH],
  });
  const tokens = getTokens();
  const [positionX, setPositionX] = useState<number | null>(null);
  const themeColors = getColors(tokens, colorScheme);
  const viewRef = useRef<View>(null);

  useEffect(() => {
    const shimmerAnimation = (opts: Animated.TimingAnimationConfig) =>
      Animated.loop(Animated.timing(ANIMATION.current, opts));

    const opts = {
      easing: Easing.linear,
      duration: DURATION,
      toValue: END,
      useNativeDriver: false,
      ...animationOpts,
    };

    shimmerAnimation(opts).start();
    return () => {
      shimmerAnimation(opts).stop();
    };
  }, [ANIMATION, animationOpts]);

  return (
    <Stack
      accessibilityLabel="Loading"
      style={{
        overflow: 'hidden',
        width,
        height,
        borderRadius,
        backgroundColor: themeColors.backgroundColor,
      }}
      testID={testID}
      ref={viewRef}
      onLayout={() => {
        if (viewRef.current) {
          viewRef.current.measure((_x, _y, _width, _height, pageX) => {
            setPositionX(pageX);
          });
        }
      }}
    >
      {positionX !== null && positionX !== undefined && (
        <Animated.View
          style={{
            flex: 1,
            left: -positionX,
            transform: [{ translateX: linear }],
          }}
        >
          <LinearGradient
            testID={'gradient'}
            style={{
              flex: 1,
              width: shimmerWidth,
            }}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            locations={linearOpts?.locations ?? LOCATIONS}
            colors={
              linearOpts?.colors ?? [
                themeColors.backgroundColor,
                themeColors.highlightColor,
                themeColors.backgroundColor,
              ]
            }
          />
        </Animated.View>
      )}
    </Stack>
  );
};
