import { fireEvent, render, screen } from '@src/jest/testing-library';
import { getTokens, getVariableValue } from 'tamagui';

import { Shimmer } from '../shimmer';

describe('Shimmer', () => {
  it('should render with the correct width and height', () => {
    render(<Shimmer width={100} height={100} />);

    expect(screen.getByLabelText('Loading')).toHaveStyle({
      width: 100,
      height: 100,
    });
  });

  it('should render with custom colours passed via props', () => {
    const tokens = getTokens();
    render(<Shimmer width={100} height={100} colorScheme="dark" />);

    const measureMockFn = jest.fn().mockImplementation((f) => {
      f(1, 2, 3, 4, 5, 6);
    });
    const shimmerContainer = screen.getByLabelText('Loading');
    shimmerContainer.parent.instance.measure = measureMockFn;

    fireEvent(shimmerContainer, 'onLayout', {
      nativeEvent: {
        layout: {
          width: 100,
          height: 100,
          pageX: 200,
        },
      },
    });

    expect(shimmerContainer).toHaveStyle({
      width: 100,
      height: 100,
      backgroundColor: getVariableValue(tokens.color.ShimmerGrayDark),
    });
    expect(screen.getByTestId('gradient')).toBeOnTheScreen();
  });
});
