import { render, screen } from '@src/jest/testing-library';
import { getTokens, getVariableValue } from 'tamagui';

import { DoughnutShimmer } from '../doughnut-shimmer';

describe('DoughnutShimmer', () => {
  it('should render correctly', async () => {
    render(<DoughnutShimmer />);

    expect(screen.getByLabelText('Loading visual')).toBeOnTheScreen();
    expect(screen.getByLabelText('Loading')).toBeOnTheScreen();
  });
  it('should render with a custom radius, custom thickness and dark colorScheme', async () => {
    const tokens = getTokens();
    render(<DoughnutShimmer colorScheme="dark" thickness={50} radius={120} />);

    expect(screen.getByLabelText('Loading visual')).toHaveStyle({
      borderRadius: 120,
      width: 240,
      height: 240,
      overflow: 'hidden',
    });
    expect(screen.getByLabelText('Loading')).toHaveStyle({
      width: 240,
      height: 240,
      backgroundColor: getVariableValue(tokens.color.ShimmerGrayDark),
    });
  });
});
