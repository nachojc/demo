import {
  act,
  fireEvent,
  render,
  screen,
  waitFor,
} from '@src/jest/testing-library';

import { Snackbar } from '../snackbar';

jest.useFakeTimers();

const testTitleText = 'This is test title text';
const testActionButtonText = 'test button';

const mockOnActionPress = jest.fn();

describe('Snackbar Component', () => {
  it('expect text to render correctly', () => {
    render(
      <Snackbar
        snackbar
        snackbarSingleLine
        enterTime={0}
        exitTime={4000}
        title={testTitleText}
      />
    );

    const titleText = screen.getByTestId('card-title');

    expect(titleText).toHaveTextContent('This is test title text');
  });

  it('actionButton renders correctly if passed as a prop', () => {
    render(
      <Snackbar
        snackbar
        snackbarSingleLine
        enterTime={0}
        exitTime={4000}
        title={testTitleText}
        actionButton={testActionButtonText}
      />
    );

    const titleText = screen.getByTestId('card-title');
    const buttonText = screen.getByTestId('right-container');

    expect(titleText).toHaveTextContent('This is test title text');
    expect(buttonText).toHaveTextContent('test button');
  });

  it('with exitTime and enterTime, opacity should be 0', () => {
    render(
      <Snackbar
        snackbar
        snackbarSingleLine
        enterTime={0}
        exitTime={4000}
        title={testTitleText}
        actionButton={testActionButtonText}
      />
    );

    const snackbar = screen.getByTestId('snackbar');

    expect(snackbar).toHaveStyle({ opacity: 0 });
  });

  it('Should call completion handler when it reach the exit time without action', async () => {
    let hasCompleted = false;
    const onCompletion = () => {
      hasCompleted = true;
    };

    render(
      <Snackbar
        snackbar
        snackbarSingleLine
        enterTime={0}
        exitTime={4000}
        completionHandler={onCompletion}
        title={testTitleText}
        actionButton={testActionButtonText}
      />
    );

    const snackbar = screen.getByTestId('snackbar-button');
    fireEvent.press(snackbar);

    act(() => {
      jest.runAllTimers();
    });

    await waitFor(() => {
      expect(hasCompleted).toBeTruthy();
    });
  });
});

describe('Snackbar Component Error handling', () => {
  it('expect error to be thrown for exitTime not being large enough', () => {
    expect(() => {
      render(
        <Snackbar
          snackbar
          snackbarSingleLine
          enterTime={0}
          exitTime={3999}
          title={testTitleText}
        />
      );
    }).toThrow(
      'Please set exitTime to be greater than enterTime for at least 4 seconds.'
    );
  });

  it('should run passed onActionPress function when action button is pressed', () => {
    render(
      <Snackbar
        snackbar
        snackbarSingleLine
        enterTime={0}
        exitTime={4000}
        title={testTitleText}
        actionButton={testActionButtonText}
        snackbarOnPress={{
          onActionPress: mockOnActionPress,
          accessibilityAnnouncementDuration: 1000,
        }}
      />
    );

    const snackbar = screen.getByTestId('snackbar-button');

    fireEvent.press(snackbar);

    expect(mockOnActionPress).toHaveBeenCalledTimes(1);
  });
});
