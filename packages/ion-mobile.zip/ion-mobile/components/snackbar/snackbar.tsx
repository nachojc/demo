import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useAccessibility } from '@src/common/providers/accessibility';
import { useCallback, useEffect, useState } from 'react';
import { Platform, Pressable } from 'react-native';
import Animated, {
  Easing,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import { Stack } from 'tamagui';

import { BaseCard, BaseCardProps } from '../cards';
import { Text } from '../text';

type SnackbarProps = BaseCardProps & {
  snackbar: boolean;
  snackbarSingleLine?: boolean;
  snackbarSingleLineNoPadding?: boolean;
  snackbarTwoLine?: boolean;
  snackbarMultiLine?: boolean;
  actionButton?: string;
  snackbarOnPress?: {
    onActionPress: () => void;
    accessibilityAnnouncementDuration: number; //Duration in ms for accessibility to announce the snackbar element
  };
  completionHandler?: () => void;
  enterTime: number;
  exitTime: number;
  // Made optional for testability
  backgroundColor?: string;
  accessibilityFocusWhenVisible?: boolean;
};

const accessibilityFocusDelayiOS = 500; // Tested on physical iOS device as the minimum delay time for effective accessibilty focus attempt
const accessibilityFocusDelayAndroid = 1000; // Tested in physical Android device as the minimum delay time for effective accessibilty focus attempt
const startingOpactiy = 0;

export const Snackbar = ({
  actionButton,
  snackbarOnPress,
  completionHandler,
  enterTime,
  exitTime,
  snackbar,
  snackbarSingleLine,
  snackbarSingleLineNoPadding,
  snackbarTwoLine,
  snackbarMultiLine,
  backgroundColor = '$Secondary800',
  accessibilityFocusWhenVisible = false,
  ...props
}: SnackbarProps) => {
  const [isVisible, setIsVisible] = useState<boolean>(true);
  const [pressed, setPressed] = useState<boolean>(false);

  const { isScreenReaderEnabled } = useAccessibility();

  const AnimatedSnackbar = Animated.createAnimatedComponent(Stack);
  const animatedOpacity = useSharedValue(startingOpactiy);
  const animatedTranslate = useSharedValue(0);

  const { elementRef, focus } = useA11yFocus();

  const closeComponent = () => {
    setIsVisible(false);
  };

  const animationStyle = useAnimatedStyle(() => {
    return {
      opacity: withTiming(animatedOpacity.value, {
        duration: 200,
        easing: Easing.linear,
      }),
      transform: [
        {
          translateX: withTiming(
            animatedTranslate.value,
            {
              duration: 100,
              easing: Easing.linear,
            },
            () => {
              if (pressed && isVisible) {
                runOnJS(closeComponent)();
              }
            }
          ),
        },
      ],
    };
  });

  const enterAnimation = useCallback(() => {
    animatedOpacity.value = 1;
  }, [animatedOpacity]);

  const exitAnimation = () => {
    if (completionHandler !== undefined) {
      completionHandler();
    }

    animatedOpacity.value = 0;
    setPressed(true);
  };

  useEffect(() => {
    if (isVisible) {
      setTimeout(enterAnimation, enterTime);
      if (accessibilityFocusWhenVisible) {
        setTimeout(
          focus,
          Platform.OS === 'ios'
            ? accessibilityFocusDelayiOS
            : accessibilityFocusDelayAndroid
        );
      }
    }
  }, [isVisible, enterAnimation, enterTime]);

  const exitTimeDuration = isScreenReaderEnabled
    ? (snackbarOnPress?.accessibilityAnnouncementDuration ?? 0) + exitTime // Extend the exit time when screen reader is on so user will have enough time to interact
    : exitTime;

  setTimeout(exitAnimation, exitTimeDuration);
  if (exitTime < enterTime + 4000) {
    throw new Error(
      'Please set exitTime to be greater than enterTime for at least 4 seconds.'
    );
  }

  return (
    <>
      {isVisible && (
        <AnimatedSnackbar style={animationStyle} testID="snackbar">
          <BaseCard
            snackbar={snackbar}
            snackbarSingleLine={snackbarSingleLine}
            snackbarSingleLineNoPadding={snackbarSingleLineNoPadding}
            snackbarTwoLine={snackbarTwoLine}
            snackbarMultiLine={snackbarMultiLine}
            backgroundColor={backgroundColor}
            {...props}
            renderItemRight={
              actionButton && (
                <Pressable
                  accessibilityRole="button"
                  onPress={() => {
                    snackbarOnPress?.onActionPress();
                  }}
                  testID="snackbar-button"
                >
                  <Text fontVariant={'body-semibold-Primary500'}>
                    {actionButton}
                  </Text>
                </Pressable>
              )
            }
            onPress={() => {
              if (isScreenReaderEnabled) {
                snackbarOnPress?.onActionPress();
              }
            }}
            ref={elementRef}
          />
        </AnimatedSnackbar>
      )}
    </>
  );
};
