import { t } from 'i18next';
import { z } from 'zod';

export const postcodeRegex =
  '^(([gG][iI][rR] *0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?\\d\\d?)|(([a-pr-uwyzA-PR-UWYZ]\\d[a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]\\d[abehmnprv-yABEHMNPRV-Y]))) *\\d[abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$';

export const PostcodeSearchSchema = z.object({
  postcodeSearch: z
    .string({ required_error: t('postcodeLookup.invalidPostcode') })
    .regex(new RegExp(postcodeRegex), t('postcodeLookup.invalidPostcode')),
});

export const AddressFormSchema = z.object({
  addressLine1: z.string().min(1),
  addressLine2: z.string().optional(),
  addressLine3: z.string().optional(),
  postalTownCity: z.string().min(1),
  postcode: PostcodeSearchSchema.shape.postcodeSearch,
});

export type AddressForm = z.infer<typeof AddressFormSchema>;
export type PostcodeSearchForm = z.infer<typeof PostcodeSearchSchema>;
