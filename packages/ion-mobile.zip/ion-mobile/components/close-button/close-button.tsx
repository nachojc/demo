import { ElementRef, forwardRef } from 'react';
import { useTranslation } from 'react-i18next';
import { SvgProps } from 'react-native-svg';
import { Stack, StackProps } from 'tamagui';

import { Icon, IconName } from '../icon';

type CloseButtonProps = {
  iconProps?: SvgProps & { name?: Extract<IconName, 'close' | 'chevron-left'> };
} & StackProps;

export type CloseButton = ElementRef<typeof Stack>;

export const CloseButton = forwardRef<CloseButton, CloseButtonProps>(
  ({ iconProps, ...stackProps }, ref) => {
    const { t } = useTranslation();

    return (
      <Stack
        ref={ref}
        hitSlop={{ bottom: 8, left: 8, right: 8, top: 8 }}
        role="button"
        accessibilityRole="button"
        accessibilityLabel={
          stackProps?.accessibilityLabel || t('common.buttons.close')
        }
        accessible
        {...stackProps}
      >
        <Icon testID="close" name={iconProps?.name ?? 'close'} {...iconProps} />
      </Stack>
    );
  }
);

CloseButton.displayName = 'CloseButton';
