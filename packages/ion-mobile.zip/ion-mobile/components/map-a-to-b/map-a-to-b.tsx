import { Stack, XStack, YStack } from 'tamagui';

import { Text } from '../text';

type MapAtoBProps = {
  startAddress: string;
  endAddress: string;
};

const CIRCLE_SIZE = 10;
const LINE_WIDTH = 1;

export const MapAtoB = ({ startAddress, endAddress }: MapAtoBProps) => {
  return (
    <YStack>
      <XStack paddingBottom={12} position="relative">
        <Stack
          backgroundColor={'$DWBlack'}
          width={LINE_WIDTH}
          position="absolute"
          top={4}
          bottom={0}
          left={CIRCLE_SIZE / 2 - LINE_WIDTH / 2}
        />
        <Stack
          height={CIRCLE_SIZE}
          width={CIRCLE_SIZE}
          borderRadius={CIRCLE_SIZE / 2}
          borderColor={'$DWBlack'}
          borderWidth={2}
          marginRight={12}
          backgroundColor={'$White'}
          marginTop={3}
        />
        <Text fontVariant={'overline-regular-Gray500'}>{startAddress}</Text>
      </XStack>

      <XStack position="relative">
        <Stack
          backgroundColor={'$DWBlack'}
          height={3}
          width={LINE_WIDTH}
          position="absolute"
          top={0}
          left={CIRCLE_SIZE / 2 - LINE_WIDTH / 2}
        />
        <Stack
          height={CIRCLE_SIZE}
          width={CIRCLE_SIZE}
          borderRadius={CIRCLE_SIZE / 2}
          backgroundColor={'$DWBlack'}
          marginRight={12}
          marginTop={3}
        />
        <Text fontVariant={'overline-regular-Gray500'}>{endAddress}</Text>
      </XStack>
    </YStack>
  );
};
