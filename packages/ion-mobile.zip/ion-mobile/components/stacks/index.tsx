import { tokens } from '@src/theme/tokens';
import {
  GetProps,
  styled,
  XStack as TXStack,
  YStack as TYStack,
} from 'tamagui';

const maxCentered = {
  alignSelf: 'center',
  width: '100%',
  paddingHorizontal: tokens.space.xl.val,
} as const;

export const variants = {
  tablet: {
    true: {
      ...maxCentered,
      maxWidth: tokens.size['19.5'].val,
    },
  },
  tabletNarrow: {
    true: {
      ...maxCentered,
      maxWidth: '$17.5',
    },
  },
} as const;

export const YStack = styled(TYStack, {
  variants,
});

export const XStack = styled(TXStack, {
  variants,
});

export type YStackProps = GetProps<typeof YStack>;
export type XStackProps = YStackProps;
