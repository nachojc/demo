import { render, screen } from '@src/jest/testing-library';
import { StyleProps } from 'react-native-reanimated';

import { XStack, YStack } from '../index';

const tabletStyles = {
  alignSelf: 'center',
  width: '100%',
  paddingRight: 16,
  paddingLeft: 16,
} as StyleProps;

describe.each([
  { Component: XStack, name: '<XStack/>' },
  { Component: YStack, name: '<YStack/>' },
])('$name', ({ Component }) => {
  it('should have maxWidth as 720 and other styles if tablet', () => {
    render(<Component testID="TEST_ID" tablet />);
    const stackID = screen.getByTestId('TEST_ID');
    expect(stackID).toHaveStyle({
      ...tabletStyles,
      maxWidth: 720,
    });
  });
  it('should have not maxWidth as 720 and other styles if not tablet', () => {
    render(<Component testID="TEST_ID" tablet={false} />);
    const stackID = screen.getByTestId('TEST_ID');
    expect(stackID).not.toHaveStyle({
      ...tabletStyles,
      maxWidth: 720,
    });
  });
  it('should have maxWidth as 350 and other styles if tabletNarrow', () => {
    render(<Component testID="TEST_ID" tabletNarrow />);
    const stackID = screen.getByTestId('TEST_ID');
    expect(stackID).toHaveStyle({
      ...tabletStyles,
      maxWidth: 350,
    });
  });
  it('should have not maxWidth as 350 and other styles if not tabletNarrow', () => {
    render(<Component testID="TEST_ID" tablet={false} />);
    const stackID = screen.getByTestId('TEST_ID');
    expect(stackID).not.toHaveStyle({
      ...tabletStyles,
      maxWidth: 350,
    });
  });
});
