import { ReactElement } from 'react';
import { StackProps, XStack, YStack } from 'tamagui';

import { Image } from '../image';
import { Text } from '../text';

type Bullet = {
  title: string;
  linkTitle?: string;
};

type ContextualListProps = {
  imageName: string;
  title: string;
  copy?: string;
  link?: string;
  copyPart2?: string;
  showDialogLink?: boolean;
  linkOnPress?: () => void;
  bullets?: Bullet[];
  renderDialog?: () => ReactElement;
} & StackProps;

const getImage = (imageName: string) => {
  switch (imageName) {
    case 'calendar':
      return require('assets/calendar.png');
    case 'phone':
      return require('assets/phone/phone.png');
    case 'moneypot':
      return require('assets/moneypot.png');
    case 'chart':
      return require('assets/chart.png');
    case 'value':
      return require('assets/value.png');
    case 'credit-card':
      return require('assets/credit-card.png');
    case 'envelope':
      return require('assets/envelope.png');
    case 'idv-complete':
      return require('assets/idv-complete.png');
  }
};

const renderTextLink = (
  linkToRender: string,
  testID: string,
  onPress: () => void
) => (
  <Text
    fontVariant="body-regular-Tertiary800"
    decoration="underline"
    tamaguiTextProps={{ onPress }}
    testID={testID}
    key={linkToRender}
  >
    {linkToRender}
  </Text>
);

export const ContextualList = ({
  imageName,
  title,
  copy,
  link,
  copyPart2,
  showDialogLink = false,
  linkOnPress,
  bullets,
  renderDialog,
  ...stackProps
}: ContextualListProps) => {
  const image = getImage(imageName);

  const onPress = () => {
    if (linkOnPress) {
      linkOnPress();
    }
  };

  return (
    <XStack
      mb={stackProps.marginBottom ? stackProps.marginBottom : '$xxl'}
      {...stackProps}
    >
      <YStack
        marginLeft="$0"
        marginRight="$xl"
        marginBottom={stackProps.marginBottom ? stackProps.marginBottom : '$xl'}
        paddingVertical="$xs"
      >
        <Image
          accessibilityIgnoresInvertColors
          accessibilityLabel="image"
          source={image}
          style={{
            width: 60,
            height: 60,
          }}
          resizeMode="contain"
        />
      </YStack>

      <YStack flex={1}>
        <Text
          fontVariant="body-semibold-Gray800"
          tamaguiTextProps={{ marginBottom: '$md' }}
          testID="title-text"
        >
          {title}
        </Text>

        <Text
          fontVariant="body-regular-Gray800"
          tamaguiTextProps={{ marginBottom: '$sm' }}
          testID="copy-text"
        >
          {copy}
          {link && <> {renderTextLink(link, 'link-text', onPress)}</>}
          {!showDialogLink && !link && renderDialog && <> {renderDialog()}</>}
          {copyPart2}
        </Text>
        {bullets && bullets.length > 0 && (
          <YStack paddingLeft="$sm">
            {bullets.map(({ title, linkTitle }, index) => (
              <XStack key={title}>
                <Text
                  fontVariant="body-regular-Gray800"
                  tamaguiTextProps={{
                    marginBottom: '$sm',
                    marginLeft: '$md',
                  }}
                  key={title}
                  testID={`bullet-text${index}`}
                >
                  {`\u2022   ${title}`}
                  {linkTitle &&
                    renderTextLink(linkTitle, `bullet-link${index}`, onPress)}
                  {!linkTitle && renderDialog && renderDialog()}
                </Text>
              </XStack>
            ))}
          </YStack>
        )}
      </YStack>
    </XStack>
  );
};
