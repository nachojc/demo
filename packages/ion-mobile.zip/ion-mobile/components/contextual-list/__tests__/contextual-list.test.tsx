import { render, screen } from '@src/jest/testing-library';

import { ContextualList } from '../contextual-list';

const setup = () => {
  render(
    <ContextualList
      imageName="value"
      title="Choosing a retirement age"
      bullets={[
        { title: 'bullet text one', linkTitle: 'this is a bullet link' },
        { title: 'bullet text two' },
      ]}
      copy="copy test"
      link="this is a link"
    />
  );
};

it('renders correctly with all the text', async () => {
  setup();

  const titleWrapper = screen.getByTestId('title-text');
  const copyWrapper = screen.getByTestId('copy-text');
  expect(titleWrapper).toHaveTextContent('Choosing a retirement age');
  expect(copyWrapper).toHaveTextContent('copy test');
});

it('renders correctly with bullets', async () => {
  setup();

  const bullet1 = screen.getByTestId('bullet-text0');
  const bullet2 = screen.getByTestId('bullet-text1');
  expect(bullet1).toHaveTextContent('bullet text one');
  expect(bullet2).toHaveTextContent('bullet text two');
});
it('renders correctly with link in copy', async () => {
  setup();

  const link = screen.getByTestId('link-text');
  expect(link).toHaveTextContent('this is a link');
});
it('renders correctly with link in bullet', async () => {
  setup();

  const bulletLink = screen.getByTestId('bullet-link0');
  expect(bulletLink).toHaveTextContent('this is a bullet link');
});
