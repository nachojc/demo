import {
  SortCodeInput,
  Stack,
  TamaguiElement,
  Text,
  TextInput,
  YStack,
} from '@aviva/ion-mobile';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useAccessibility } from '@src/common/providers/accessibility';
import { spellOutString } from '@src/utils/accessibility';
import { getTestId } from '@src/utils/get-test-id';
import { MutableRefObject, useState } from 'react';
import { Controller } from 'react-hook-form';
import { useTranslation } from 'react-i18next';
import { Keyboard } from 'react-native';

import {
  ACCOUNT_NUMBER_LENGTH,
  NAME_MAX_CHARACTERS,
  ROLL_NUMBER_MAX_LENGTH,
  SORT_CODE_LENGTH,
} from './constants';
import { BankDetailsManualEntryFormProps } from './types';

const formatLabel = (value: string | undefined, placeholder?: string) => {
  return value ? spellOutString(value) : placeholder ?? '';
};

/**
 * Reusable Bank Details Manual Entry Form with validation.
 */
export const BankDetailsManualEntryForm = ({
  form,
  onFieldFocus = () => undefined,
}: BankDetailsManualEntryFormProps) => {
  const { t } = useTranslation();
  const { control, setFocus } = form;
  const {
    elementRef: accountHolderNameRef,
    focus: accountHolderNameA11yFocus,
  } = useA11yFocus();
  const { elementRef: sortCodeRef, focus: sortCodeA11yFocus } = useA11yFocus();
  const { elementRef: accountNumberRef, focus: accountNumberA11yFocus } =
    useA11yFocus();
  const { elementRef: bankNameRef, focus: bankNameA11yFocus } = useA11yFocus();
  const { isScreenReaderEnabled } = useAccessibility();
  const [isSubmitted, setIsSubmitted] = useState({
    accountHolderName: false,
    sortCode: false,
    accountNumber: false,
    bankName: false,
  });

  const setSubmittedFlag = (
    property: keyof typeof isSubmitted,
    value: boolean
  ) => {
    setIsSubmitted((prev) => ({ ...prev, [property]: value }));
  };

  return (
    <YStack>
      <Controller
        key="accountHolderName"
        name="accountHolderName"
        control={control}
        render={({ field: { onChange, onBlur, value, ref }, fieldState }) => {
          return (
            <YStack
              space="$xl"
              marginBottom={fieldState.invalid ? '$xl' : '$xxl'}
            >
              <Text fontVariant="body-semibold-Secondary800">
                {t('bankDetailsForm.accountHolderName')}
              </Text>
              <Stack
                onPress={() => {
                  setFocus('accountHolderName');
                }}
                ref={accountHolderNameRef}
              >
                <TextInput
                  testID={getTestId('bank-details-form-account-holder-name')}
                  tamaguiInputProps={{
                    value: value === null ? undefined : value,
                    returnKeyType: 'done',
                    accessibilityHint: `${t(
                      'bankDetailsForm.accountHolderNameError'
                    )}.`,
                    onSubmitEditing: () => {
                      form.trigger('accountHolderName');
                      setSubmittedFlag('accountHolderName', true);
                      if (!isScreenReaderEnabled) {
                        setFocus('sortCode');
                      }
                    },
                    blurOnSubmit: true,
                    onChangeText: onChange,
                    maxLength: NAME_MAX_CHARACTERS,
                    onBlur: () => {
                      onBlur();
                      if (
                        isScreenReaderEnabled &&
                        isSubmitted.accountHolderName
                      ) {
                        accountHolderNameA11yFocus();
                        setSubmittedFlag('accountHolderName', false);
                      }
                    },
                    onFocus: () => onFieldFocus('accountHolderName'),
                    placeholder: t(
                      'bankDetailsForm.accountHolderNamePlaceholder'
                    ),
                    keyboardType: 'default',
                    ref: ref as unknown as MutableRefObject<
                      TamaguiElement | undefined
                    >,
                  }}
                  error={fieldState.invalid}
                  errorText={t('bankDetailsForm.accountHolderNameError')}
                  required
                />
              </Stack>
            </YStack>
          );
        }}
      />

      <Controller
        key="sortCode"
        name="sortCode"
        control={control}
        render={({ field: { onChange, onBlur, value, ref }, fieldState }) => {
          return (
            <YStack
              space="$xl"
              marginBottom={fieldState.invalid ? '$xl' : '$xxl'}
            >
              <Text fontVariant="body-semibold-Secondary800">
                {t('bankDetailsForm.sortCode')}
              </Text>
              <Stack
                onPress={() => {
                  setFocus('sortCode');
                }}
                ref={sortCodeRef}
              >
                <SortCodeInput
                  tamaguiInputProps={{
                    value: value === null ? undefined : value,
                    returnKeyType: 'done',
                    accessibilityHint: `${t('bankDetailsForm.sortCodeError')}.`,
                    onSubmitEditing: () => {
                      form.trigger('sortCode');
                      setSubmittedFlag('sortCode', true);
                      if (!isScreenReaderEnabled) {
                        setFocus('accountNumber');
                      }
                    },
                    onChangeText: (text) => {
                      if (text.length <= SORT_CODE_LENGTH) {
                        onChange(text);
                      }
                    },
                    onBlur: () => {
                      onBlur();
                      if (isScreenReaderEnabled && isSubmitted.sortCode) {
                        sortCodeA11yFocus();
                        setSubmittedFlag('sortCode', false);
                      }
                    },
                    onFocus: () => onFieldFocus('sortCode'),
                    placeholder: t('bankDetailsForm.sortCodePlaceholder'),
                    ref: ref as unknown as MutableRefObject<
                      TamaguiElement | undefined
                    >,
                  }}
                  error={fieldState.invalid}
                  errorText={t('bankDetailsForm.sortCodeError')}
                  required
                />
              </Stack>
            </YStack>
          );
        }}
      />

      <Controller
        key="accountNumber"
        name="accountNumber"
        control={control}
        render={({ field: { onChange, onBlur, value, ref }, fieldState }) => {
          return (
            <YStack
              space="$xl"
              marginBottom={fieldState.invalid ? '$xl' : '$xxl'}
            >
              <Text fontVariant="body-semibold-Secondary800">
                {t('bankDetailsForm.accountNumber')}
              </Text>
              <Stack
                onPress={() => {
                  setFocus('accountNumber');
                }}
                ref={accountNumberRef}
              >
                <TextInput
                  testID={getTestId('bank-details-form-account-number')}
                  tamaguiInputProps={{
                    value: value === null ? undefined : value,
                    returnKeyType: 'done',
                    accessibilityHint: `${t(
                      'bankDetailsForm.accountNumberError'
                    )}.`,
                    onSubmitEditing: () => {
                      form.trigger('accountNumber');
                      setSubmittedFlag('accountNumber', true);
                      if (!isScreenReaderEnabled) {
                        setFocus('bankName');
                      }
                    },
                    blurOnSubmit: true,
                    onChangeText: onChange,
                    maxLength: ACCOUNT_NUMBER_LENGTH,
                    onBlur: () => {
                      onBlur();
                      if (isScreenReaderEnabled && isSubmitted.accountNumber) {
                        accountNumberA11yFocus();
                        setSubmittedFlag('accountNumber', false);
                      }
                    },
                    onFocus: () => onFieldFocus('accountNumber'),
                    placeholder: t('bankDetailsForm.accountNumberPlaceholder'),
                    keyboardType: 'numeric',
                    ref: ref as unknown as MutableRefObject<
                      TamaguiElement | undefined
                    >,
                  }}
                  error={fieldState.invalid}
                  errorText={t('bankDetailsForm.accountNumberError')}
                  required
                />
              </Stack>
            </YStack>
          );
        }}
      />

      <Controller
        key="bankName"
        name="bankName"
        control={control}
        render={({ field: { onChange, onBlur, value, ref }, fieldState }) => {
          return (
            <YStack
              space="$xl"
              marginBottom={fieldState.invalid ? '$xl' : '$xxl'}
            >
              <Text fontVariant="body-semibold-Secondary800">
                {t('bankDetailsForm.bankName')}
              </Text>
              <Stack
                onPress={() => {
                  setFocus('bankName');
                }}
                ref={bankNameRef}
              >
                <TextInput
                  testID={getTestId('bank-details-form-bank-name')}
                  tamaguiInputProps={{
                    value: value === null ? undefined : value,
                    returnKeyType: 'done',
                    accessibilityHint: `${t('bankDetailsForm.bankNameError')}.`,
                    onSubmitEditing: () => {
                      form.trigger('bankName');
                      setSubmittedFlag('bankName', true);
                      if (!isScreenReaderEnabled) {
                        setFocus('rollNumber');
                      }
                    },
                    blurOnSubmit: true,
                    onChangeText: onChange,
                    maxLength: NAME_MAX_CHARACTERS,
                    onBlur: () => {
                      onBlur();
                      if (isScreenReaderEnabled && isSubmitted.bankName) {
                        bankNameA11yFocus();
                        setSubmittedFlag('bankName', false);
                      }
                    },
                    onFocus: () => onFieldFocus('bankName'),
                    placeholder: t('bankDetailsForm.bankNamePlaceholder'),
                    keyboardType: 'default',
                    ref: ref as unknown as MutableRefObject<
                      TamaguiElement | undefined
                    >,
                  }}
                  error={fieldState.invalid}
                  errorText={t('bankDetailsForm.bankNameError')}
                  required
                />
              </Stack>
            </YStack>
          );
        }}
      />

      <Controller
        key="rollNumber"
        name="rollNumber"
        control={control}
        render={({ field: { onChange, onBlur, value, ref }, fieldState }) => {
          return (
            <YStack
              space="$xl"
              marginBottom={fieldState.invalid ? '$xl' : '$xxl'}
            >
              <Text fontVariant="body-semibold-Secondary800">
                {t('bankDetailsForm.rollNumber')}
              </Text>
              <Stack
                accessible
                accessibilityLabel={formatLabel(
                  value,
                  t('bankDetailsForm.rollNumberPlaceholder')
                )}
              >
                <TextInput
                  testID={getTestId('bank-details-form-roll-number')}
                  tamaguiInputProps={{
                    value: value === null ? undefined : value,
                    returnKeyType: 'done',
                    onSubmitEditing: Keyboard.dismiss,
                    onChangeText: onChange,
                    maxLength: ROLL_NUMBER_MAX_LENGTH,
                    onBlur,
                    onFocus: () => onFieldFocus('rollNumber'),
                    placeholder: t('bankDetailsForm.rollNumberPlaceholder'),
                    keyboardType: 'default',
                    accessibilityElementsHidden: true,
                    importantForAccessibility: 'no',
                    ref: ref as unknown as MutableRefObject<
                      TamaguiElement | undefined
                    >,
                  }}
                  error={fieldState.invalid}
                  errorText={t('bankDetailsForm.rollNumberError')}
                />
              </Stack>
            </YStack>
          );
        }}
      />
    </YStack>
  );
};
