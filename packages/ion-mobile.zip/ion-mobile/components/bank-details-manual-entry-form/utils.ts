/**
 * Adds a hyphen after every two numbers in a given input string.
 * For example, if the input is "12345678", the function will return "12-34-56-78".
 * If the input is "987654321", the function will return "98-76-54-32-1".
 * @param input The input string to process.
 * @returns The input string with hyphens added after every two numbers.
 */
export const addHyphenAfterTwoNumbers = (input: string) => {
  const regex = /(\d{2})(?=\d)/g;
  return input.replace(regex, '$1-');
};
