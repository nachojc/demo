export const ROLL_NUMBER_MAX_LENGTH = 18;
export const ACCOUNT_NUMBER_LENGTH = 8;
export const SORT_CODE_LENGTH = 6;
export const NAME_MIN_CHARACTERS = 2;
export const NAME_MAX_CHARACTERS = 50;
