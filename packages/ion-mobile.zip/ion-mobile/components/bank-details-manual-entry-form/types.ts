import { UseFormReturn } from 'react-hook-form';
import { ValueOf } from 'type-fest';
import { z } from 'zod';

import {
  ACCOUNT_NUMBER_LENGTH,
  NAME_MAX_CHARACTERS,
  NAME_MIN_CHARACTERS,
  ROLL_NUMBER_MAX_LENGTH,
  SORT_CODE_LENGTH,
} from './constants';

export const BankDetailsFormSchema = z.object({
  accountHolderName: z
    .string()
    .refine(
      (accountHolderName) =>
        accountHolderName.trim().length > 0 &&
        accountHolderName.length >= NAME_MIN_CHARACTERS &&
        accountHolderName.length <= NAME_MAX_CHARACTERS &&
        /^[a-zA-Z0-9\s]+$/.test(accountHolderName)
    ),
  sortCode: z
    .string()
    .refine(
      (sortCode) =>
        sortCode.length === SORT_CODE_LENGTH && /^\d+$/.test(sortCode)
    ),
  accountNumber: z
    .string()
    .refine(
      (accountNumber) =>
        accountNumber.length === ACCOUNT_NUMBER_LENGTH &&
        /^\d+$/.test(accountNumber)
    ),
  bankName: z
    .string()
    .refine(
      (bankName) =>
        bankName.trim().length > 0 &&
        bankName.length >= NAME_MIN_CHARACTERS &&
        bankName.length <= NAME_MAX_CHARACTERS &&
        /^[a-zA-Z\s]+$/.test(bankName)
    ),
  rollNumber: z
    .string()
    .refine(
      (rollNumber) =>
        rollNumber === undefined ||
        rollNumber.length === 0 ||
        (rollNumber.length <= ROLL_NUMBER_MAX_LENGTH &&
          /^[a-zA-Z0-9]+$/.test(rollNumber))
    )
    .optional(),
  accountType: z.enum(['Individual', 'Joint']),
});

export type BankDetailsForm = z.infer<typeof BankDetailsFormSchema>;

export type BankDetailsManualEntryFormProps = {
  form: UseFormReturn<BankDetailsForm>;
  onFieldFocus?: (fieldType: ValueOf<BankDetailsForm>) => void;
};
