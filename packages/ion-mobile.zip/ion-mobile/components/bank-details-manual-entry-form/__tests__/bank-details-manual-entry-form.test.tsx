import {
  act,
  fireEvent,
  render,
  renderHook,
  screen,
  within,
} from '@src/jest/testing-library';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';

import { BankDetailsManualEntryForm } from '../bank-details-manual-entry-form';
import { BankDetailsForm, BankDetailsFormSchema } from '../types';
import { addHyphenAfterTwoNumbers } from '../utils';

const defaultBankDetails = {
  accountHolderName: '',
  sortCode: '',
  accountNumber: '',
  rollNumber: undefined,
};

const dummyBankDetails = {
  accountHolderName: 'John Doe',
  sortCode: '123456',
  accountNumber: '12345678',
  bankName: 'Monzo',
  rollNumber: '123456789123456789',
};

const renderBankDetailsManualEntryForm = () => {
  const { result } = renderHook(() =>
    useForm<BankDetailsForm>({
      resolver: zodResolver(BankDetailsFormSchema),
      mode: 'onChange',
      defaultValues: defaultBankDetails,
    })
  );
  render(<BankDetailsManualEntryForm form={result.current} />);
  return result;
};

describe('BankDetailsManualEntryForm', () => {
  afterEach(() => {
    jest.clearAllMocks();
  });

  it('should render all input fields', () => {
    renderBankDetailsManualEntryForm();

    expect(screen.getByText('Account holder name')).toBeOnTheScreen();
    expect(screen.getByText('Sort code')).toBeOnTheScreen();
    expect(screen.getByText('Account number')).toBeOnTheScreen();
    expect(
      screen.getByText('Roll number (For Building Society accounts only)')
    ).toBeOnTheScreen();

    expect(
      screen.getByPlaceholderText('Enter name', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
    expect(
      screen.getByPlaceholderText('Enter sort code', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
    expect(
      screen.getByPlaceholderText('Enter account number', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
    expect(
      screen.getByPlaceholderText('Enter name of your bank', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
    expect(
      screen.getByPlaceholderText('Enter roll number', {
        includeHiddenElements: true,
      })
    ).toBeOnTheScreen();
  });

  it('should display appropriate error message if field has error state on form when submitted', async () => {
    const result = renderBankDetailsManualEntryForm();
    await act(async () => {
      await result.current.trigger();
    });

    expect(
      screen.getAllByText('Please enter between 2 and 50 valid characters')
    ).toHaveLength(2);
    expect(
      screen.getByText('This needs to be a 6 digit number')
    ).toBeOnTheScreen();
    expect(
      screen.getByText('This needs to be an 8 digit number')
    ).toBeOnTheScreen();
  });

  it('should return the entered values from the form', () => {
    const result = renderBankDetailsManualEntryForm();

    const accountHolderNameField = screen.getByPlaceholderText('Enter name', {
      includeHiddenElements: true,
    });
    const sortCodeField = screen.getByPlaceholderText('Enter sort code', {
      includeHiddenElements: true,
    });
    const accountNumberField = screen.getByPlaceholderText(
      'Enter account number',
      {
        includeHiddenElements: true,
      }
    );
    const bankNameField = screen.getByPlaceholderText(
      'Enter name of your bank',
      {
        includeHiddenElements: true,
      }
    );
    const rollNumberField = screen.getByPlaceholderText('Enter roll number', {
      includeHiddenElements: true,
    });

    fireEvent.changeText(
      accountHolderNameField,
      dummyBankDetails.accountHolderName
    );
    fireEvent.changeText(
      sortCodeField,
      addHyphenAfterTwoNumbers(dummyBankDetails.sortCode)
    );
    fireEvent.changeText(accountNumberField, dummyBankDetails.accountNumber);
    fireEvent.changeText(bankNameField, dummyBankDetails.bankName);
    fireEvent.changeText(rollNumberField, dummyBankDetails.rollNumber);

    expect(result.current.getValues().accountHolderName).toBe('John Doe');
    expect(addHyphenAfterTwoNumbers(result.current.getValues().sortCode)).toBe(
      '12-34-56'
    );
    expect(result.current.getValues().accountNumber).toBe('12345678');
    expect(result.current.getValues().bankName).toBe('Monzo');
    expect(result.current.getValues().rollNumber).toBe('123456789123456789');
  });

  it('should display no errors on form when submitted if fields are filled', async () => {
    const result = renderBankDetailsManualEntryForm();

    const accountHolderNameField = screen.getByPlaceholderText('Enter name', {
      includeHiddenElements: true,
    });
    const sortCodeField = screen.getByPlaceholderText('Enter sort code', {
      includeHiddenElements: true,
    });
    const accountNumberField = screen.getByPlaceholderText(
      'Enter account number',
      {
        includeHiddenElements: true,
      }
    );
    const bankNameField = screen.getByPlaceholderText(
      'Enter name of your bank',
      {
        includeHiddenElements: true,
      }
    );
    const rollNumberField = screen.getByPlaceholderText('Enter roll number', {
      includeHiddenElements: true,
    });

    fireEvent.changeText(
      accountHolderNameField,
      dummyBankDetails.accountHolderName
    );
    fireEvent.changeText(sortCodeField, dummyBankDetails.sortCode);
    fireEvent.changeText(accountNumberField, dummyBankDetails.accountNumber);
    fireEvent.changeText(bankNameField, dummyBankDetails.bankName);
    fireEvent.changeText(rollNumberField, dummyBankDetails.rollNumber);

    await act(async () => {
      await result.current.trigger();
    });

    expect(
      screen.queryByText('Please enter between 2 and 50 valid characters')
    ).not.toBeOnTheScreen();
    expect(
      screen.queryByText('Please enter a value between 1 and 18 digits long')
    ).not.toBeOnTheScreen();
  });

  it('should display appropriate error message if optional field "Roll number"  has error state on form when submitted', async () => {
    const result = renderBankDetailsManualEntryForm();

    const rollNumberField = screen.getByPlaceholderText('Enter roll number', {
      includeHiddenElements: true,
    });
    fireEvent.changeText(rollNumberField, '!!!!');
    await act(async () => {
      await result.current.trigger();
    });

    expect(
      screen.getByText('Please enter a value between 1 and 18 digits long')
    ).toBeOnTheScreen();
  });

  it('should no display error message if optional field "Roll number" is blank on form when submitted', async () => {
    const result = renderBankDetailsManualEntryForm();

    const rollNumberField = screen.getByPlaceholderText('Enter roll number', {
      includeHiddenElements: true,
    });
    fireEvent.changeText(rollNumberField, undefined);
    await act(async () => {
      await result.current.trigger();
    });

    expect(
      screen.queryByText('Please enter a value between 1 and 18 digits long')
    ).not.toBeOnTheScreen();
  });

  it('should have accessibility required hints on mandatory fields', () => {
    renderBankDetailsManualEntryForm();

    const name = screen.getByPlaceholderText('Enter name');
    const nameHint = within(name).getByAccessibilityHint(
      'Required Please enter between 2 and 50 valid characters.'
    );

    expect(nameHint).toBeOnTheScreen();

    const sortCode = screen.getByPlaceholderText('Enter sort code');
    const sortCodeHint = within(sortCode).getByAccessibilityHint(
      'Required This needs to be a 6 digit number.'
    );

    expect(sortCodeHint).toBeOnTheScreen();

    const account = screen.getByPlaceholderText('Enter account number');
    const accountHint = within(account).getByAccessibilityHint(
      'Required This needs to be an 8 digit number.'
    );

    expect(accountHint).toBeOnTheScreen();

    const bankName = screen.getByPlaceholderText('Enter name of your bank');
    const bankNameHint = within(bankName).getByAccessibilityHint(
      'Required Please enter between 2 and 50 valid characters.'
    );

    expect(bankNameHint).toBeOnTheScreen();
  });
});
