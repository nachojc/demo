import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { ZodSchema } from 'zod';

import { BankDetailsForm, BankDetailsFormSchema } from '../types';

export const useBankDetailsManualEntryForm = (
  refineBankDetailsFormSchema?: (
    bankDetailsFormSchema: typeof BankDetailsFormSchema
  ) => ZodSchema
) => {
  const form = useForm<BankDetailsForm>({
    resolver: zodResolver(
      refineBankDetailsFormSchema?.(BankDetailsFormSchema) ||
        BankDetailsFormSchema
    ),
    mode: 'onBlur',
    defaultValues: {
      accountHolderName: '',
      sortCode: '',
      accountNumber: '',
      rollNumber: undefined,
      accountType: 'Individual',
    },
  });

  const clearBankDetailsForm = () => {
    form.reset();
  };

  const getBankDetailsValues = () => form.getValues();

  const isBankDetailsFormValid = form.formState.isValid;

  return {
    bankDetailsForm: form,
    clearBankDetailsForm,
    getBankDetailsValues,
    isBankDetailsFormValid,
  };
};
