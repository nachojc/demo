import { act, renderHook } from '@src/jest/testing-library';

import { addHyphenAfterTwoNumbers } from '../../utils';
import { useBankDetailsManualEntryForm } from '../use-bank-details-manual-entry-form';

describe('useBankDetailsManualEntryForm hook', () => {
  it('should return default bank details and form methods', () => {
    const { result } = renderHook(() => useBankDetailsManualEntryForm());

    expect(result.current.getBankDetailsValues()).toEqual({
      accountHolderName: '',
      sortCode: '',
      accountNumber: '',
      rollNumber: undefined,
      accountType: 'Individual',
    });

    expect(result.current.bankDetailsForm).toBeDefined();
    expect(result.current.bankDetailsForm.handleSubmit).toBeInstanceOf(
      Function
    );
    expect(result.current.bankDetailsForm.register).toBeInstanceOf(Function);
  });

  it('should update bank details when form inputs change', () => {
    const { result } = renderHook(() => useBankDetailsManualEntryForm());

    act(() => {
      result.current.bankDetailsForm.register('accountHolderName');
      result.current.bankDetailsForm.register('sortCode');
      result.current.bankDetailsForm.register('accountNumber');
      result.current.bankDetailsForm.register('rollNumber');
      result.current.bankDetailsForm.register('accountType');
    });

    act(() => {
      result.current.bankDetailsForm.setValue('accountHolderName', 'John Doe');
      result.current.bankDetailsForm.setValue(
        'sortCode',
        addHyphenAfterTwoNumbers('123456')
      );
      result.current.bankDetailsForm.setValue('accountNumber', '12345678');
      result.current.bankDetailsForm.setValue(
        'rollNumber',
        '123456789123456789'
      );
      result.current.bankDetailsForm.setValue('accountType', 'Individual');
    });

    expect(result.current.getBankDetailsValues()).toEqual({
      accountHolderName: 'John Doe',
      sortCode: '12-34-56',
      accountNumber: '12345678',
      rollNumber: '123456789123456789',
      accountType: 'Individual',
    });
  });
});
