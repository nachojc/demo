import {
  createNavigationMock,
  fireEvent,
  render,
  screen,
} from '@src/jest/testing-library';
import { Icon } from '@aviva/ion-mobile';
import { isManga } from '@hooks/use-expo-config';
import { ParamListBase } from '@react-navigation/native';
import {
  NativeStackNavigationOptions,
  NativeStackNavigationProp,
} from '@react-navigation/native-stack';
import { NavbarProvider } from '@src/common/providers/nav-control';

import { TopAppBarDW } from '../top-app-bar-dw';

const insetTop = 2;
jest.mock('react-native-safe-area-context', () => ({
  useSafeAreaInsets: () => ({ top: insetTop }),
}));

const TOP_APP_BAR = 'test:id/top-app-bar';

const navMock =
  createNavigationMock<
    NativeStackNavigationProp<ParamListBase, string, undefined>
  >();

describe('TopAppBarDW', () => {
  it('should use correct styles with default configuration', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW />
      </NavbarProvider>
    );

    const topAppBar = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBar).toHaveStyle({
      backgroundColor: '#05142D',
      paddingTop: insetTop + 8,
    });
  });

  it('should use correct styles with webView configuration', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW webView />
      </NavbarProvider>
    );

    const topAppBar = screen.getByTestId(TOP_APP_BAR);

    expect(topAppBar).toHaveStyle({
      backgroundColor: '#FFFFFF',
    });
  });

  it('should render with title passed in options prop when it exists as default', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW
          options={{ title: 'Test Title' }}
          textLabel="Label Title"
          route={{ key: 'key', name: 'Route Title' }}
        />
      </NavbarProvider>
    );

    const title = screen.getByText('Test Title');
    expect(title).toBeDefined();

    const accessibleTitle = screen.getByLabelText('Test Title');
    expect(accessibleTitle).toBeDefined();
  });

  it('should render with title passed in textLabel prop when no options prop is passed', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW
          textLabel="Label Title"
          route={{ key: 'key', name: 'Route Title' }}
        />
      </NavbarProvider>
    );

    const title = screen.getByText('Label Title');

    expect(title).toBeDefined();
  });

  it('should render with title passed in route when no options or textLabel props are passed', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW route={{ key: 'key', name: 'Route Title' }} />
      </NavbarProvider>
    );

    const title = screen.getByText('Route Title');

    expect(title).toBeDefined();
  });

  it('should render an actionIcon when passed', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW actionIcons={<Icon name="close" />} />
      </NavbarProvider>
    );

    const icon = screen.getByTestId('test:id/icon-close', {
      includeHiddenElements: true,
    });

    expect(icon).toBeDefined();
  });

  it('should render an array of actionIcons when passed', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW
          actionIcons={[
            <Icon key="1" name="close" />,
            <Icon key="2" name="alert-circle" />,
          ]}
        />
      </NavbarProvider>
    );

    const icon1 = screen.getByTestId('test:id/icon-close', {
      includeHiddenElements: true,
    });
    const icon2 = screen.getByTestId('test:id/icon-alert-circle', {
      includeHiddenElements: true,
    });

    expect(icon1).toBeDefined();
    expect(icon2).toBeDefined();
  });

  it('should render a back button with title when passed', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW back={{ title: 'Previous' }} />{' '}
      </NavbarProvider>
    );

    const backButton = screen.getByLabelText('Back');

    expect(backButton).toBeDefined();
  });

  it('should run the goBack navigation function when back button is pressed', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW back={{ title: 'Previous' }} navigation={navMock} />
      </NavbarProvider>
    );

    const backButton = screen.getByLabelText('Back');
    fireEvent.press(backButton);

    expect(navMock.goBack).toHaveBeenCalled();
  });

  it('should not display the back button when shouldShowBackIcon is false', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW
          back={{ title: 'Previous' }}
          navigation={navMock}
          shouldShowBackIcon={false}
        />
      </NavbarProvider>
    );

    const backButton = screen.queryByLabelText('Back');

    expect(backButton).not.toBeOnTheScreen();
  });

  it('should navigate to Summary screen when title is homepage and click back button for Manga', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW back={{ title: 'homepage' }} navigation={navMock} />
      </NavbarProvider>
    );

    const backButton = screen.getByAccessibilityHint('Navigates to homepage');

    fireEvent.press(backButton);

    expect(navMock.navigate).toHaveBeenCalledTimes(1);
    expect(navMock.navigate).toHaveBeenCalledWith('Summary Tab');
  });

  if (!isManga()) {
    it('should navigate to PortfolioSummary screen when title is homepage and click back button for DW', () => {
      render(
        <NavbarProvider>
          <TopAppBarDW back={{ title: 'homepage' }} navigation={navMock} />
        </NavbarProvider>
      );

      const backButton = screen.getByAccessibilityHint('Navigates to homepage');

      fireEvent.press(backButton);

      expect(navMock.navigate).toHaveBeenCalledWith('PortfolioSummary');
    });
  }

  it('should render image instead of text when image is passed', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW
          textLabel="Test Title"
          image={require('assets/aviva-inline/aviva-inline.png')}
        />
      </NavbarProvider>
    );

    const title = screen.queryByLabelText('Test Title');
    const image = screen.getByTestId('image');

    expect(title).not.toBeOnTheScreen();
    expect(image).toBeOnTheScreen();
  });
});

describe('Accessibility', () => {
  it('should have an accessibility label on the back button for full screen modal page', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW navigation={navMock} back={{ title: 'Previous' }} />
      </NavbarProvider>
    );
    const backButton = screen.getAllByLabelText('Back');
    expect(backButton.length).toBe(1);
  });

  it('should have accessibility label and hint on the back button', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW navigation={navMock} back={{ title: 'Previous' }} />
      </NavbarProvider>
    );
    expect(screen.getByLabelText('Back')).toBeOnTheScreen();
    expect(
      screen.getByAccessibilityHint('Navigates to Previous')
    ).toBeOnTheScreen();
  });

  it('should have accessibility label for title with no options', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW options={{ title: 'Test Title' }} />
      </NavbarProvider>
    );

    const title = screen.getByLabelText('Test Title');

    expect(title).toBeDefined();
  });

  it('should have accessibility label for title with heading options', () => {
    render(
      <NavbarProvider>
        <TopAppBarDW
          options={
            {
              title: 'Test Title',
              titleAccessibilityLabelSuffix:
                ': Before you start your application',
            } as NativeStackNavigationOptions
          }
        />
      </NavbarProvider>
    );

    const title = screen.getByLabelText(
      'Test Title: Before you start your application'
    );

    expect(title).toBeDefined();
  });
});
