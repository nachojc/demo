import { isDevMode } from '@config';
import {
  ColorScheme,
  theme as createTheme,
} from '@direct-wealth/components/tabs/tabsTheme';
import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useAnalytics } from '@hooks/use-analytics';
import { isManga } from '@hooks/use-expo-config';
import { useFocusEffect } from '@react-navigation/native';
import {
  NativeStackHeaderProps,
  NativeStackNavigationOptions,
} from '@react-navigation/native-stack';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { ReactNode, useCallback, useEffect, useMemo } from 'react';
import { BackHandler } from 'react-native';
import { Source } from 'react-native-fast-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Stack, XStack, YStack } from 'tamagui';

import { CloseButton } from '../close-button';
import { FocusAwareStatusBar } from '../focus-aware-status-bar';
import { Image } from '../image';
import { Text } from '../text';

export type TopAppBarProps = Partial<NativeStackHeaderProps> & {
  webView?: boolean;
  theme?: ColorScheme;
  isFullScreenModal?: boolean;
  textLabel?: string;
  actionIcons?: ReactNode[] | ReactNode;
  image?: number | Source;
  handleBackButton?: () => void;
  isDarkTheme?: boolean;
  showDevMode?: boolean;
  isSipp?: boolean;
  backAnalyticsTag?: string;
  backgroundColor?: string;
  shouldShowBackIcon?: boolean;
};

type AccessibleNavigationOptions =
  | (NativeStackNavigationOptions & {
      titleAccessibilityLabelSuffix?: string;
    })
  | undefined;

export const TopAppBarDW = ({
  webView = false,
  theme = 'directWealth',
  isFullScreenModal = false,
  textLabel,
  actionIcons,
  back,
  handleBackButton,
  navigation,
  route,
  image,
  isDarkTheme = true,
  showDevMode = false,
  isSipp = false,
  backAnalyticsTag,
  backgroundColor,
  shouldShowBackIcon = true,
  ...rest
}: TopAppBarProps) => {
  const insets = useSafeAreaInsets();
  const headerTheme = createTheme(webView ? 'plain' : theme);

  const { trackUserEvent } = useAnalytics();
  const { elementRef, focus } = useA11yFocus();

  const handleBackButtonPress = useCallback(() => {
    if (backAnalyticsTag) {
      trackUserEvent(backAnalyticsTag);
    }
    if (handleBackButton) {
      handleBackButton();
      return;
    }
    if (back?.title === 'homepage') {
      navigation?.navigate(isManga() ? 'Summary Tab' : 'PortfolioSummary');
      return;
    }
    navigation?.goBack();
  }, [
    back?.title,
    backAnalyticsTag,
    handleBackButton,
    navigation,
    trackUserEvent,
  ]);

  useEffect(() => {
    focus();
  }, []);

  useFocusEffect(
    useCallback(() => {
      const onBackPress = () => {
        handleBackButtonPress();
        return true;
      };

      const backHandler = BackHandler.addEventListener(
        'hardwareBackPress',
        onBackPress
      );
      return () => backHandler.remove();
    }, [handleBackButtonPress])
  );

  const navigationOptions = rest?.options as AccessibleNavigationOptions;
  const title = navigationOptions?.title ?? textLabel ?? route?.name ?? '';
  const mainAccessibilityLabel =
    title + (navigationOptions?.titleAccessibilityLabelSuffix ?? '');

  const accessibilityTitle = useMemo(() => {
    if (back == null) {
      return 'Navigates back';
    } else if (back.title === 'Bottom tabs') {
      return 'Navigates to Portfolio Summary';
    } else {
      return `Navigates to ${back.title}`;
    }
  }, [back]);

  return (
    <>
      <FocusAwareStatusBar
        style={isDarkTheme ? 'light' : 'dark'}
        backgroundColor={headerTheme.bg}
      />
      <XStack
        importantForAccessibility={'no'}
        paddingHorizontal={'$xl'}
        paddingTop={webView ? insets.top : insets.top + 8}
        backgroundColor={backgroundColor ?? headerTheme.bg}
        paddingBottom={'$md'}
        testID={getTestId('top-app-bar')}
        justifyContent="space-between"
        alignItems="center"
      >
        <XStack flexGrow={1} flexBasis={1} justifyContent="flex-start">
          {back && !isFullScreenModal && shouldShowBackIcon && (
            <CloseButton
              flex={1}
              onPress={handleBackButtonPress}
              accessibilityLabel="Back"
              accessibilityHint={accessibilityTitle}
              testID={getTestId('back-button')}
              iconProps={{
                name: webView ? 'close' : 'chevron-left',
                color: isSipp ? tokens.color.White.val : headerTheme.iconColor,
                strokeWidth: isSipp ? 2 : 1,
              }}
              ref={elementRef}
            />
          )}
        </XStack>
        <XStack flexGrow={2} justifyContent="center">
          {image && (
            <Image
              accessibilityIgnoresInvertColors
              testID="image"
              source={image}
              style={{
                width: 100,
                height: 30,
              }}
              resizeMode="contain"
            />
          )}
          {!image && title && (
            <Text
              fontVariant={`heading5-semibold-${
                webView ? 'Secondary800' : 'White'
              }`}
              tamaguiTextProps={{
                accessibilityLabel: mainAccessibilityLabel,
                color: headerTheme.headerTextColor,
              }}
              testID={getTestId('heading-title')}
            >
              {title}
            </Text>
          )}
        </XStack>
        <XStack flexGrow={1} flexBasis={1} justifyContent="flex-end">
          {isDevMode() && showDevMode && (
            <YStack
              accessible
              accessibilityLabel="dev mode link"
              onPress={() => navigation?.navigate('Dev Mode')}
            >
              <Text
                fontVariant={'small-semibold-iOSNativeBlue'}
                tamaguiTextProps={{
                  importantForAccessibility: 'no',
                }}
              >
                Dev Mode
              </Text>
            </YStack>
          )}
          {isFullScreenModal && (
            <XStack justifyContent="flex-end">
              <CloseButton
                onPress={navigation?.goBack}
                accessibilityLabel="Back"
                accessibilityHint="Go back"
                iconProps={{ color: headerTheme.iconColor }}
              />
            </XStack>
          )}

          {actionIcons && Array.isArray(actionIcons)
            ? actionIcons.map((icon, index) => (
                <Stack key={`${textLabel}-${index}`} marginHorizontal={'$sm'}>
                  {icon}
                </Stack>
              ))
            : actionIcons}
        </XStack>
      </XStack>
    </>
  );
};
