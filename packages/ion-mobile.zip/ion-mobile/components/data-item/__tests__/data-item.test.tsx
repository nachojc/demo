import { render, screen } from '@src/jest/testing-library';

import { DataItem } from '../data-item';

let mockIsManga = true;
jest.mock('@hooks/use-expo-config', () => ({
  isManga: () => mockIsManga,
  getAppID: () => 'co.uk.aviva.myaviva',
}));

afterEach(() => {
  jest.clearAllMocks();
});
describe('DataItem', () => {
  it('should render with heading and value passed', () => {
    render(<DataItem heading="Test Heading" value="£123,000" />);

    expect(screen.getByText('Test Heading')).toBeDefined();
    expect(screen.getByText('£123,000')).toBeDefined();
  });

  it('should render with heading, value and subHeading passed', () => {
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        subHeading="Last updated. 19 April 2023"
      />
    );

    expect(screen.getByText('Test Heading')).toBeDefined();
    expect(screen.getByText('£123,000')).toBeDefined();
    expect(screen.getByText('Last updated. 19 April 2023')).toBeDefined();
  });

  it('should render a datestamp formatted correctly', () => {
    render(<DataItem dateStamp="2023-05-25" />);

    const dateText = screen.getByText('Last updated, 25 May 2023');
    expect(dateText).toBeOnTheScreen();
  });

  it('should render value (policy number) with size 20 when isValueTextSmall is not passed for MANGA', () => {
    mockIsManga = true;
    render(
      <DataItem
        heading="Test Heading"
        value="POLICY123"
        gainOrLoss={{ raw: 1.0, formatted: '+$1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
      />
    );
    const valueText = screen.getByText('POLICY123');

    expect(valueText).toHaveStyle({
      fontSize: 20,
    });
  });

  it('should render value (fund value) with size 24 when isValueTextSmall is not passed for MANGA', () => {
    mockIsManga = true;
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLoss={{ raw: 1.0, formatted: '+$1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
      />
    );
    const valueText = screen.getByText('£123,000');

    expect(valueText).toHaveStyle({
      fontSize: 24,
    });
  });

  it('should render value (policy number) with size 14 when isValueTextSmall is passed for MANGA', () => {
    mockIsManga = true;
    render(
      <DataItem
        heading="Test Heading"
        value="POLICY123"
        gainOrLoss={{ raw: 1.0, formatted: '+$1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
        isValueTextSmall
      />
    );
    const valueText = screen.getByText('POLICY123');

    expect(valueText).toHaveStyle({
      fontSize: 14,
    });
  });

  it('should render value (fund value) with size 24 when isValueTextSmall is passed for MANGA', () => {
    mockIsManga = true;
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLoss={{ raw: 1.0, formatted: '+£1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
        isValueTextSmall
      />
    );
    const valueText = screen.getByText('£123,000');

    expect(valueText).toHaveStyle({
      fontSize: 24,
    });
  });

  it('should render text with size 20 if isValueTextSmall is not passed for DW', () => {
    mockIsManga = false;
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLoss={{ raw: 1.0, formatted: '+$1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
      />
    );
    const valueText = screen.getByText('£123,000');
    expect(valueText).toHaveStyle({
      fontSize: 20,
    });
  });

  it('should render text with size 14 if isValueTextSmall is passed for DW', () => {
    mockIsManga = false;
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLoss={{ raw: 1.0, formatted: '+£1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
        isValueTextSmall
      />
    );
    const valueText = screen.getByText('£123,000');
    expect(valueText).toHaveStyle({
      fontSize: 14,
    });
  });

  it('should render gray heading text', () => {
    render(<DataItem heading="Test Heading" value="£123,000" />);
    const grayHeading = screen.getByText('Test Heading');
    expect(grayHeading).toHaveStyle({
      color: '#616161',
    });
  });

  it('should render Stack vertically if isValueHorizontal is not passed', () => {
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLoss={{ raw: 1.0, formatted: '+£1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
      />
    );
    const stack = screen.getByTestId('data-item-value-container');
    expect(stack).toHaveStyle({
      flexDirection: 'column',
    });
  });

  it('should render Stack horizontally if isValueHorizontal is passed', () => {
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLoss={{ raw: 1.0, formatted: '+£1.00' }}
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
        isValueHorizontal
      />
    );
    const stack = screen.getByTestId('data-item-value-container');
    expect(stack).toHaveStyle({
      flexDirection: 'row',
    });
  });

  it('should not render trendvalue when either gainOrLoss or gainOrLossPercentage is null', () => {
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLoss={{ raw: 1.0, formatted: '+£1.00' }}
        gainOrLossPercentage={{ raw: null, formatted: null }}
      />
    );
    const trendValueContainer = screen.queryByLabelText('Trend Value');
    expect(trendValueContainer).not.toBeOnTheScreen();
  });

  it('should not render trendvalue when either gainOrLoss or gainOrLossPercentage is undefined', () => {
    render(
      <DataItem
        heading="Test Heading"
        value="£123,000"
        gainOrLossPercentage={{ raw: 0.13, formatted: '0.13%' }}
      />
    );
    const trendValueContainer = screen.queryByLabelText('Trend Value');
    expect(trendValueContainer).not.toBeOnTheScreen();
  });
});
