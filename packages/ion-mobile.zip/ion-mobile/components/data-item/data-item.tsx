import { isManga } from '@hooks/use-expo-config';
import { convertISODateToShortMonthFormat } from '@src/utils/date-converters/convert-iso-date-to-short-month-format';
import { getTestId } from '@src/utils/get-test-id';
import { splitNumbers } from '@src/utils/splitNumber';
import { Stack, XStack } from 'tamagui';

import { Text } from '../text';
import { FormattedValue, TrendValue } from '../trend-value';

export type DataItemProps = {
  heading?: string;
  subHeading?: string;
  value?: string | null;
  dateStamp?: string | null;
  isValueHorizontal?: boolean;
  isValueTextSmall?: boolean;
  gainOrLoss?: FormattedValue;
  gainOrLossPercentage?: FormattedValue;
  productName?: string;
  accessibilityLabel?: string;
  accessibilityHint?: string;
  secureAccountNumber?: string;
};

export const DataItem = ({
  heading,
  subHeading,
  value,
  dateStamp,
  isValueHorizontal,
  isValueTextSmall,
  gainOrLoss,
  gainOrLossPercentage,
}: DataItemProps) => {
  const showTrendValue =
    gainOrLoss?.formatted != null && gainOrLossPercentage?.formatted != null;

  const getMangaTextSize = () => {
    if (isValueTextSmall && value?.[0] !== '£') {
      return 'small-semibold-Gray800';
    } else if (value?.[0] === '£') {
      return 'heading3-semibold-Gray800';
    } else {
      return 'heading4-semibold-Gray800';
    }
  };

  const getDwTextSize = () => {
    if (isValueTextSmall) {
      return 'small-semibold-Gray800';
    } else {
      return 'heading4-semibold-Gray800';
    }
  };

  return (
    <>
      {heading || value ? (
        <Stack
          flexDirection={isValueHorizontal ? 'row' : 'column'}
          space={isValueHorizontal ? '$sm' : '$xs'}
          testID="data-item-value-container"
        >
          {heading && (
            <Text fontVariant={'small-regular-Gray600'}>{heading}</Text>
          )}
          {value && (
            <Text
              tamaguiTextProps={{
                testID: getTestId(value),
                accessibilityLabel:
                  value?.[0] === '£' ? value : `${splitNumbers(value)}`,
              }}
              fontVariant={isManga() ? getMangaTextSize() : getDwTextSize()}
            >
              {value}
            </Text>
          )}
        </Stack>
      ) : null}

      {subHeading && (
        <Text fontVariant="overline-regular-Gray800">{subHeading}</Text>
      )}
      {dateStamp && (
        <Text fontVariant="overline-regular-Gray800">
          {`Last updated, ${convertISODateToShortMonthFormat(dateStamp)}`}
        </Text>
      )}
      {showTrendValue ? (
        <XStack alignItems="center" testID="trendValue">
          <TrendValue
            gainOrLoss={gainOrLoss}
            gainOrLossPercentage={gainOrLossPercentage}
          />
        </XStack>
      ) : null}
    </>
  );
};
