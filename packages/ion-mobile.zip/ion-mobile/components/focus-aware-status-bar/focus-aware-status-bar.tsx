import { useIsFocused } from '@react-navigation/native';
// eslint-disable-next-line no-restricted-imports
import { StatusBar, StatusBarProps } from 'expo-status-bar';

export const FocusAwareStatusBar = (props: StatusBarProps) => {
  const isFocused = useIsFocused();
  return isFocused ? <StatusBar {...props} /> : null;
};
