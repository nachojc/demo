import { render, screen } from '@src/jest/testing-library';

import { TextWithLinks } from '../text-with-links';

const NO_LINK_TEMPLATE = 'No links here';
const PHONE_LINK_TEMPLATE = 'Call us on {{phone}}';
const TWO_LINKS_TEMPLATE =
  'Call us on {{phone}} or visit our website {{website}}';
const onPress = () => null;
const onPress2 = () => null;

const renderNoLinks = () =>
  render(
    <TextWithLinks<typeof NO_LINK_TEMPLATE>
      fontVariant="body-regular-Gray800"
      template={NO_LINK_TEMPLATE}
      links={{}}
    />
  );

const renderPhoneLink = () =>
  render(
    <TextWithLinks<typeof PHONE_LINK_TEMPLATE>
      fontVariant="body-regular-Gray800"
      testID="text-with-links"
      template={PHONE_LINK_TEMPLATE}
      links={{
        phone: {
          text: '0800 123 4567',
          accessibilityLabel: 'Activate call function',
          accessibilityHint: 'Opens link',
          onPress,
        },
      }}
    />
  );

const renderTwoLinks = () =>
  render(
    <TextWithLinks<typeof TWO_LINKS_TEMPLATE>
      fontVariant="body-regular-Gray800"
      testID="text-with-links"
      template={TWO_LINKS_TEMPLATE}
      links={{
        phone: {
          text: '0800 123 4567',
          accessibilityLabel: 'Activate call function',
          accessibilityHint: 'Opens link', // Not used when two links but added to prove it
          onPress,
        },
        website: {
          text: 'https://example.com',
          accessibilityLabel: 'Open web link',
          accessibilityHint: 'Opens link', // Not used when two links but added to prove it
          onPress: onPress2,
        },
      }}
    />
  );

describe('TextWithLinks', () => {
  it('should render plain text', () => {
    renderNoLinks();
    const text = screen.getByTestId('text-with-links');
    expect(text).toHaveTextContent('No links here');
    expect(text).toHaveProp('children', ['No links here']);
    expect(text).toHaveStyle({
      color: '#373737',
      fontSize: 16,
      lineHeight: 24,
      fontFamily: 'SourceSansPro-Regular',
    });
  });

  it('should render text with nested link', () => {
    renderPhoneLink();
    const wrapper = screen.getByTestId('text-with-links-view-wrapper');
    const text = screen.getByTestId('text-with-links');
    const links = screen.getAllByTestId('text-with-links-link');
    expect(wrapper).toHaveProp('accessibilityLabel', 'Call us on 08001234567');
    expect(wrapper).toHaveProp('accessibilityRole', 'link');
    expect(wrapper).toHaveProp('accessibilityHint', 'Opens link');
    expect(wrapper).toHaveProp('accessible', true);
    expect(text).toHaveTextContent('Call us on 0800 123 4567');
    expect(links.length).toBe(1);
  });

  it('should render text with two nested links', () => {
    renderTwoLinks();
    const wrapper = screen.getByTestId('text-with-links-view-wrapper');
    const text = screen.getByTestId('text-with-links');
    const links = screen.getAllByTestId('text-with-links-link');
    expect(text).toHaveTextContent(
      'Call us on 0800 123 4567 or visit our website https://example.com'
    );
    expect(links.length).toBe(2);
    expect(wrapper).toHaveProp('accessible', true);
    expect(wrapper).not.toHaveProp('accessibilityHint');
    expect(wrapper).toHaveProp('accessibilityActions', [
      { name: 'phone', label: 'Activate call function' },
      { name: 'website', label: 'Open web link' },
    ]);
  });
});
