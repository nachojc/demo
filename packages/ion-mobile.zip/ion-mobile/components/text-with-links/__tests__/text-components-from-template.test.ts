/* eslint-disable @typescript-eslint/no-explicit-any */
import { textComponentsFromTemplate } from '../text-components-from-template';

const onPress = () => null;
const links: any = {
  link0: {
    text: 'link-0',
    props: { prop1: true },
    onPress,
  },
  link1: { text: 'link-1' },
  link2: { text: 'link-2' },
};

const link0WithProps: any = {
  key: 'link0',
  link: { ...links.link0 },
  props: {
    children: 'link-0',
    prop1: true,
    onPress,
  },
};

const link1WithProps: any = {
  key: 'link1',
  link: { ...links.link1 },
  props: {
    children: 'link-1',
  },
};

const link2WithProps: any = {
  key: 'link2',
  link: { ...links.link2 },
  props: {
    children: 'link-2',
  },
};

describe('textComponentsFromTemplate', () => {
  it('should make array of text and links', () => {
    const components = textComponentsFromTemplate('Text {{link0}} text', links);
    expect(components).toEqual({
      accessibilityLabel: 'Text link-0 text',
      stringsOrLinks: ['Text ', link0WithProps, ' text'],
    });
  });

  it('should make single text array when no matches', () => {
    const components = textComponentsFromTemplate('Text', links);
    expect(components).toEqual({
      accessibilityLabel: 'Text',
      stringsOrLinks: ['Text'],
    });
  });

  it('should match only link', () => {
    const components = textComponentsFromTemplate('{{link0}}', links);
    expect(components).toEqual({
      accessibilityLabel: 'link-0',
      stringsOrLinks: [link0WithProps],
    });
  });

  it('should match multiple links', () => {
    const components = textComponentsFromTemplate(
      '{{link0}} text {{link1}} text {{link2}}',
      links
    );
    expect(components).toEqual({
      accessibilityLabel: 'link-0 text link-1 text link-2',
      stringsOrLinks: [
        link0WithProps,
        ' text ',
        link1WithProps,
        ' text ',
        link2WithProps,
      ],
    });
  });

  it('should fill missing link with empty string', () => {
    const components = textComponentsFromTemplate(
      'text {{link0}} text',
      {} as any
    );
    expect(components).toEqual({
      accessibilityLabel: 'text  text',
      stringsOrLinks: ['text ', ' text'],
    });
  });

  it('removes phone formatting', () => {
    const components = textComponentsFromTemplate('Contact us {{phone}}', {
      phone: {
        text: 'by phone on (0800) 123 4567',
        onPress,
      },
    });
    expect(components).toEqual({
      accessibilityLabel: 'Contact us by phone on 08001234567',
      stringsOrLinks: [
        'Contact us ',
        {
          key: 'phone',
          link: {
            text: 'by phone on (0800) 123 4567',
            onPress,
          },
          props: {
            children: 'by phone on (0800) 123 4567',
            onPress,
          },
        },
      ],
    });
  });
});
