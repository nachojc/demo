import { screenReaderTranslate } from '@src/utils/accessibility/accessibility-label';
import { AccessibilityInfo, Pressable, View } from 'react-native';
import { Text as TamaguiText, TextProps } from 'tamagui';

import { FontVariant, Text } from '../text';
import { textComponentsFromTemplate } from './text-components-from-template';
import { Link, LinkWithProps, TemplateParams } from './types';

const DEFAULT_TEST_ID = 'text-with-links';
const ACCESSIBLE_VIEW_WRAPPER_TEST_ID = 'text-with-links-view-wrapper';

type TextWithLinksProps<T> = {
  template: string & T;
  links: Record<TemplateParams<T>, Link>;
  fontVariant: FontVariant;
  tamaguiTextProps?: Omit<TextProps, 'children' | 'onPress'>;
  testID?: string;
};

/**
 * Making nested links in text accessible is difficult and inconsistent between the two platforms.
 * Links are handled differently depending on whether there is zero, one, or many.
 *
 * If you change anything in this file, be sure to test thoroughly on devices and on both platforms.
 */
export const TextWithLinks = <T,>({
  template,
  links,
  fontVariant,
  tamaguiTextProps,
  testID: customTestID,
}: TextWithLinksProps<T>) => {
  const testID = customTestID ?? DEFAULT_TEST_ID;
  const linkTestID = `${testID}-link`;
  const { accessibilityLabel, stringsOrLinks } = textComponentsFromTemplate(
    template,
    links
  );
  const linksWithProps = stringsOrLinks.filter(
    (s): s is LinkWithProps => typeof s !== 'string'
  );
  const children = stringsOrLinks.map((stringOrLink) =>
    typeof stringOrLink === 'string' ? (
      stringOrLink
    ) : (
      <TamaguiText
        testID={linkTestID}
        fontFamily={'$body'}
        {...stringOrLink.props}
        key={stringOrLink.key}
      />
    )
  );

  // When no links, no accessibility additions required
  if (linksWithProps.length === 0) {
    return (
      <Text
        fontVariant={fontVariant}
        tamaguiTextProps={{
          ...tamaguiTextProps,
          accessibilityLabel: screenReaderTranslate(accessibilityLabel),
        }}
        testID={testID}
      >
        {children}
      </Text>
    );
  }

  // When one link, act like a link
  if (linksWithProps.length === 1) {
    const linkWithProps = linksWithProps[0];
    // We wrap in a `Pressable` because `Text` with role `link` behaves differently to everything else on Android.
    return (
      <Pressable
        testID={ACCESSIBLE_VIEW_WRAPPER_TEST_ID}
        accessible
        accessibilityLabel={screenReaderTranslate(accessibilityLabel)}
        accessibilityHint={linkWithProps.link.accessibilityHint}
        accessibilityRole="link"
        onPress={onAccessibilityPress(linkWithProps.link.onPress)}
      >
        <Text
          fontVariant={fontVariant}
          tamaguiTextProps={tamaguiTextProps}
          testID={testID}
        >
          {children}
        </Text>
      </Pressable>
    );
  }

  // When > 1 links, uses actions to make multiple links accessible
  return (
    <View
      testID={ACCESSIBLE_VIEW_WRAPPER_TEST_ID}
      accessible
      accessibilityLabel={screenReaderTranslate(accessibilityLabel)}
      onAccessibilityAction={(e) => {
        links[e.nativeEvent.actionName as TemplateParams<T>]?.onPress();
      }}
      accessibilityActions={linksWithProps.map(({ link, key }) => ({
        name: key,
        label: link.accessibilityLabel,
      }))}
    >
      <Text
        testID={testID}
        fontVariant={fontVariant}
        tamaguiTextProps={tamaguiTextProps}
      >
        {children}
      </Text>
    </View>
  );
};

const onAccessibilityPress = (onPress: () => unknown) => {
  return () =>
    AccessibilityInfo.isScreenReaderEnabled().then((enabled) => {
      enabled && onPress();
    });
};
