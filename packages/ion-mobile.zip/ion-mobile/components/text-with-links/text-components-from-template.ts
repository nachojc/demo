import { removePhoneNumberFormatting } from '@src/utils/accessibility';

import { Link, LinkWithProps, TemplateParams } from './types';

type StringOrLink = string | LinkWithProps;

export const textComponentsFromTemplate = <T>(
  template: string & T,
  links: Record<TemplateParams<T>, Link>
): { accessibilityLabel: string; stringsOrLinks: StringOrLink[] } => {
  const components: StringOrLink[] = [];
  const matches = template.matchAll(/([^}]*)\{\{(\w+)}}/g);
  let lastIndex = 0;
  for (const match of matches) {
    components.push(match[1]);
    const link = links[match[2] as TemplateParams<T>];
    if (link) {
      components.push({
        key: match[2],
        link,
        props: {
          children: link.text,
          onPress: link.onPress,
          ...(link.props ?? {}),
        },
      });
    }
    lastIndex = (match.index ?? 0) + match[0].length;
  }
  components.push(template.slice(lastIndex));
  const stringsOrLinks = components.filter((s) => s !== '');
  const accessibilityLabel = removePhoneNumberFormatting(
    joinStringsOrLinksText(stringsOrLinks)
  );
  return { accessibilityLabel, stringsOrLinks };
};

const joinStringsOrLinksText = (stringsOrLinks: StringOrLink[]) =>
  stringsOrLinks
    .map((stringOrLink) =>
      typeof stringOrLink === 'string'
        ? stringOrLink
        : stringOrLink.props.children
    )
    .join('');
