import { TextProps } from 'tamagui';

/**
 * Type extracts marked links in some text.
 *
 * Example: `Template<'Call us on {{phone}} or visit our website {{website}}'>`
 * will be transformed to `'phone' | 'website'`
 */
export type TemplateParams<T> = T extends `${string}{{${infer P}}}${infer Rest}`
  ? P | TemplateParams<Rest>
  : never;

export type TextWithLinksTemplate<T extends string> =
  `${string}{{${T}}}${string}`;

export type Link = {
  /**
   * This text will replace the {{key}} pattern in the template string
   */
  text: string;
  /**
   * Called when user taps, or accessibility taps, the link.
   */
  onPress: () => unknown;
  /**
   * Only used when > 1 links
   * Used to read out the link action.
   */
  accessibilityLabel?: string;
  /**
   * Only used when exactly 1 link
   * Used to read out the hint for the block of text
   */
  accessibilityHint?: string;
  /**
   * Props to pass to the nested tamagui text component
   */
  props?: Omit<TextProps, 'children' | 'onPress'>;
};

export type LinkWithProps = {
  key: string;
  link: Link;
  props: TextProps & {
    children: string;
  };
};
