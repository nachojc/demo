import { forwardRef, RefObject, useImperativeHandle, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Sheet, SheetProps, Stack, XStack, YStack } from 'tamagui';

import { CloseButton } from '../close-button';
import { AccessibleOverlay } from '../modal/accessible-overlay';

export type BottomSheetActions = {
  present: () => void;
  dismiss: () => void;
};

export type BottomSheetProps = SheetProps & {
  ref?: RefObject<BottomSheetActions>;
  closeIcon?: boolean;
  onOpenChange?: () => void;
  handleEnabled?: boolean;
};

export type SheetHandleProps = {
  onClose: () => void;
  closeIcon?: boolean;
};

const SheetHandle = ({ onClose, closeIcon }: SheetHandleProps) => {
  const { t } = useTranslation();
  return (
    <Stack
      width="100%"
      accessible
      accessibilityRole="menu"
      onAccessibilityEscape={onClose}
      onPress={onClose}
      accessibilityHint={t('sheetHandle.accessibilityHint')}
    >
      {closeIcon ? (
        <XStack justifyContent="flex-end">
          <CloseButton onPress={onClose} px="$xl" pt="$xl" pb="$md" />
        </XStack>
      ) : (
        <YStack
          alignSelf="center"
          height="$1"
          width="$7"
          marginVertical="$md"
          backgroundColor={'$Gray400'}
          borderRadius="$1"
        />
      )}
    </Stack>
  );
};

export const BottomSheet = forwardRef<BottomSheetActions, BottomSheetProps>(
  (
    {
      snapPoints,
      defaultPosition,
      children,
      closeIcon,
      onOpenChange,
      handleEnabled = true,
      dismissOnSnapToBottom = true,
      dismissOnOverlayPress = true,
    },
    ref
  ) => {
    const [open, setOpen] = useState(false);

    useImperativeHandle(ref, () => ({
      dismiss: () => onClose(),
      present: () => setOpen(true),
    }));

    const onClose = () => {
      setOpen(false);
    };

    const onDismiss = () => {
      if (onOpenChange !== undefined) {
        onOpenChange();
      }
      onClose();
    };

    return (
      <AccessibleOverlay
        onRequestClose={onClose}
        visible={!!open}
        render={(isScreenReaderEnabled) => (
          <Sheet
            defaultPosition={defaultPosition}
            forceRemoveScrollEnabled={open}
            modal={!isScreenReaderEnabled}
            open={open}
            onOpenChange={onDismiss}
            snapPoints={snapPoints}
            dismissOnSnapToBottom={dismissOnSnapToBottom}
            dismissOnOverlayPress={dismissOnOverlayPress}
            zIndex={100_000}
            animationConfig={{
              type: 'spring',
              damping: 35,
              mass: 1.2,
              stiffness: 250,
            }}
          >
            <Sheet.Overlay />
            <Sheet.Frame
              backgroundColor={'$White'}
              borderTopRightRadius={20}
              borderTopLeftRadius={20}
            >
              {handleEnabled && (
                <SheetHandle onClose={onClose} closeIcon={closeIcon} />
              )}
              {children}
            </Sheet.Frame>
          </Sheet>
        )}
      />
    );
  }
);

BottomSheet.displayName = 'BottomSheet';
