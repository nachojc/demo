import { ReactElement } from 'react';

import { BottomSheetActions, BottomSheetProps } from './bottom-sheet';

export const mockPresent = jest.fn();
export const mockDismiss = jest.fn();

export const mockBottomSheet = () => {
  const mockReact = jest.requireActual<typeof import('react')>('react');
  const MockBottomSheet = mockReact.forwardRef<
    BottomSheetActions,
    BottomSheetProps & { children: ReactElement }
  >(({ children }, ref) => {
    mockReact.useImperativeHandle(ref, () => ({
      present: mockPresent,
      dismiss: mockDismiss,
    }));
    return children;
  });

  MockBottomSheet.displayName = 'BottomSheet';

  return {
    BottomSheet: MockBottomSheet,
  };
};
