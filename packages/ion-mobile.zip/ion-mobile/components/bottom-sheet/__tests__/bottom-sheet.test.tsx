import { render, screen } from '@src/jest/testing-library';
import { BottomSheet } from '@aviva/ion-mobile';

describe('Bottom Sheet Component', () => {
  it('should render with sheetHandle', async () => {
    render(<BottomSheet />);

    expect(await screen.findByRole('menu')).toHaveAccessibilityValue({
      hint: 'Double tap to close',
    });
  });

  it('should render without sheetHandle', () => {
    render(<BottomSheet handleEnabled={false} />);

    const value = screen.queryByRole('menu');

    expect(value).toBe(null);
  });
});
