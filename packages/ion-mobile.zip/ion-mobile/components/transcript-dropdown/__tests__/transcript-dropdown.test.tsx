import { fireEvent, render, screen } from '@src/jest/testing-library';

import {
  TranscriptDropdown,
  TranscriptDropdownProps,
} from '../transcript-dropdown';

const defaultTranscriptDropdownProps = {
  index: 0,
  content: 'content',
  isExpanded: false,
  onPress: jest.fn,
  selectedIndex: 0,
  title: 'title',
} satisfies TranscriptDropdownProps;

const handlePress = jest.fn();

describe('Testing an accordion item (Transcript Dropdown)', () => {
  it('Transcript dropdown renders on icon, title and content when isExpanded', async () => {
    render(<TranscriptDropdown {...defaultTranscriptDropdownProps} />);
    const title = screen.getByRole('text');
    const transcriptDropdownComponentIcon = screen.getByTestId(
      'test:id/icon-chevron-down',
      { includeHiddenElements: true }
    );

    expect(title).toHaveTextContent('title');
    expect(transcriptDropdownComponentIcon).toBeOnTheScreen();
  });

  it('Transcript dropdown to have title, also content to equal undefined when closed', async () => {
    const { rerender } = render(
      <TranscriptDropdown
        {...defaultTranscriptDropdownProps}
        onPress={handlePress}
      />
    );
    const pressable = screen.getByLabelText('header1');
    fireEvent.press(pressable);

    expect(handlePress).toHaveBeenCalledTimes(1);

    rerender(
      <TranscriptDropdown
        {...defaultTranscriptDropdownProps}
        onPress={handlePress}
        isExpanded
      />
    );

    const content = screen.queryByTestId('transcript-dropdown-element');
    expect(content).toBeNull();

    fireEvent.press(pressable);

    expect(handlePress).toHaveBeenCalledTimes(2);
  });
});
