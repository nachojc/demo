import { tokens } from '@theme/tokens';
import { styled, XStack, YStack } from 'tamagui';

// Changing these styles will likely break the design of App FAQs view.
const HeadingTextContainer = styled(YStack, {
  paddingHorizontal: tokens.space.xl,
  paddingTop: tokens.space.xxl,
  paddingBottom: tokens.space.md,
  borderBottomWidth: tokens.space.xxs,
  borderBottomColor: '$Gray300',
});

const AccordionItemTitle = styled(XStack, {
  padding: tokens.space.xl,
  justifyContent: 'space-between',
});

const AccordionItemTitleText = styled(XStack, {
  maxWidth: '100%',
});

const AccordionItemContent = styled(XStack, {
  borderTopColor: tokens.color.Gray200,
  borderTopWidth: 1,
  paddingHorizontal: tokens.space.xl,
  paddingBottom: tokens.space.xl,
});

const AccordionItemContainer = styled(YStack, {
  backgroundColor: '$White',

  variants: {
    noBorder: {
      true: {
        borderRadius: '$2',
      },
      false: {
        borderBottomWidth: tokens.space.xxs,
        borderBottomColor: '$Gray300',
      },
    },
  } as const,
});

export {
  AccordionItemContainer,
  AccordionItemContent,
  AccordionItemTitle,
  AccordionItemTitleText,
  HeadingTextContainer,
};
