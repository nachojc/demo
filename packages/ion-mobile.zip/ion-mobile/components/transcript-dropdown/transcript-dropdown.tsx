import { ReactNode } from 'react';
import { LayoutAnimation, Platform, UIManager } from 'react-native';
import { getTokens } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text';
import {
  AccordionItemContainer,
  AccordionItemContent,
  AccordionItemTitle,
  AccordionItemTitleText,
  HeadingTextContainer,
} from './transcript-dropdown.style';

export type TranscriptDropdownProps = {
  title: string | ReactNode;
  content: string | ReactNode;
  heading?: string;
  isExpanded: boolean;
  selectedIndex: number;
  index: number;
  onPress: (index: number) => void;
  noBorder?: boolean;
  bottomBorderRadius?: number;
  borderColor?: string;
  borderWidth?: number;
};

if (
  Platform.OS === 'android' &&
  UIManager.setLayoutAnimationEnabledExperimental
) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export const TranscriptDropdown = ({
  title,
  content,
  heading,
  isExpanded,
  selectedIndex,
  index,
  onPress,
  noBorder = false,
  bottomBorderRadius = 0,
  borderColor = 'transparent',
  borderWidth = 0,
}: TranscriptDropdownProps) => {
  const tokens = getTokens();
  const handlePress = () => {
    onPress(selectedIndex);
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
  };

  const iconName = isExpanded ? 'chevron-up' : 'chevron-down';

  return (
    // The fontVariants used here are correct for App FAQs page. Changing them will break the design.
    <>
      {heading && (
        <HeadingTextContainer paddingTop={index === 0 ? 0 : '$xxl'}>
          <Text fontVariant={'heading5-semibold-Secondary800'}>{heading}</Text>
        </HeadingTextContainer>
      )}
      <AccordionItemContainer
        noBorder={noBorder}
        borderBottomLeftRadius={bottomBorderRadius}
        borderBottomRightRadius={bottomBorderRadius}
        borderTopLeftRadius={0}
        borderTopRightRadius={0}
        borderColor={borderColor}
        borderWidth={borderWidth}
      >
        <AccordionItemTitle
          accessibilityLabel={`header${index + 1}`}
          onPress={handlePress}
        >
          <AccordionItemTitleText>
            <Text fontVariant={'body-regular-Gray800'}>{title}</Text>
          </AccordionItemTitleText>
          <Icon name={iconName} color={tokens.color.Gray400.val} />
        </AccordionItemTitle>
        {isExpanded && (
          <AccordionItemContent testID="expansion-panel-content">
            {content}
          </AccordionItemContent>
        )}
      </AccordionItemContainer>
    </>
  );
};
