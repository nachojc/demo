import { tokens } from '@theme/tokens';
import { Stack, styled } from 'tamagui';

const TooltipContainer = styled(Stack, {
  width: 'auto',
  minWidth: tokens.size[12].val,
  position: 'absolute',
  borderRadius: tokens.space.md,
  zIndex: 9,
  shadowColor: 'rgba(0, 0, 0, 0.1)',
  backgroundColor: '$White',
  shadowRadius: 10,
});

const TooltipLabelContainer = styled(Stack, {
  justifyContent: 'center',
  minHeight: tokens.size[7].val,
  borderTopLeftRadius: tokens.space.md,
  borderTopRightRadius: tokens.space.md,
  overflow: 'hidden',
  backgroundColor: '$White',
});

const TooltipValueContainer = styled(Stack, {
  minHeight: tokens.size[7].val,
  borderBottomLeftRadius: tokens.space.md,
  borderBottomRightRadius: tokens.space.md,
  justifyContent: 'center',
  backgroundColor: '$WealthBlue80',
});

export { TooltipContainer, TooltipLabelContainer, TooltipValueContainer };
