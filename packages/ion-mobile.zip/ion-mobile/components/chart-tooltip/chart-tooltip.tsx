import { useMemo } from 'react';
import { useWindowDimensions } from 'react-native';

import { Text } from '../text/text';
import {
  TooltipContainer,
  TooltipLabelContainer,
  TooltipValueContainer,
} from './chart-tooltip.styles';
import { ChartTooltipProps } from './chart-tooltip.types';

// Offset required in order to position tooltip above the anchor point
const Y_OFFSET = -100;
const X_OFFSET = 55;
const X_OFFSET_ON_EDGE = 10;
const LEFT_EDGE = 38;
const DEFAULT = 100;
const TOP_EDGE = 70;
const Y_OFFSET_ON_TOP = -30;

/**
 * If using in conjunction with rollover events, recommend to use alongside useDebouncedValue for smoother performance
 */
export const ChartTooltip = ({ dataPoint, valueFn }: ChartTooltipProps) => {
  const { chartX, chartY, displayValue, dataValue } = dataPoint;
  const { width: windowWidth } = useWindowDimensions();

  const horizontalPosition = useMemo(() => {
    if (windowWidth - chartX > DEFAULT) {
      return chartX < LEFT_EDGE ? chartX - X_OFFSET_ON_EDGE : chartX - X_OFFSET;
    } else {
      return chartX - DEFAULT;
    }
  }, [chartX, windowWidth]);
  const verticalPosition = useMemo(() => {
    if (windowWidth - chartY > DEFAULT) {
      return chartY < TOP_EDGE ? chartY - Y_OFFSET_ON_TOP : chartY + Y_OFFSET;
    } else {
      return chartY ? chartY + Y_OFFSET : DEFAULT;
    }
  }, [chartY, windowWidth]);

  if (!chartX || !chartY || !displayValue || typeof dataValue !== 'number') {
    return null;
  }
  return (
    <TooltipContainer
      role="tooltip"
      testID="chart-tooltip-container"
      top={verticalPosition}
      left={horizontalPosition}
    >
      <TooltipLabelContainer>
        <Text
          fontVariant="body-semibold-DWPrimary500"
          tamaguiTextProps={{
            textAlign: 'center',
            fontSize: '$small',
          }}
        >
          {displayValue}
        </Text>
      </TooltipLabelContainer>
      <TooltipValueContainer>
        <Text
          fontVariant="heading5-semibold-White"
          tamaguiTextProps={{
            textAlign: 'center',
            padding: '$sm',
          }}
        >
          {valueFn ? valueFn(dataValue) : dataValue}
        </Text>
      </TooltipValueContainer>
    </TooltipContainer>
  );
};
