import { DataPlotClick } from 'react-native-fusioncharts';

export const ChartType = {
  fundPerformance: 'fundPerformance',
  investmentProduct: 'investmentProduct',
} as const;

export type DataPoint = Pick<
  DataPlotClick,
  'displayValue' | 'dataValue' | 'chartX' | 'chartY'
> | null;

export type ChartTooltipProps = {
  dataPoint: NonNullable<DataPoint>;
  valueFn?: (x: number) => string | number;
};
