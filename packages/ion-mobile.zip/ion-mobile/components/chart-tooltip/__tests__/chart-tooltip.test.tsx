import { render, screen } from '@src/jest/testing-library';
import { formatCurrencyValue } from '@src/utils/format-currency-value';

import { ChartTooltip } from '../chart-tooltip';
import { DataPoint } from '../chart-tooltip.types';

const mockDataPoint: DataPoint = {
  displayValue: 1234,
  dataValue: 75000.23,
  chartX: 56,
  chartY: 56,
};

describe('Chart tooltip', () => {
  it('should render chart tooltip with correct data', () => {
    render(
      <ChartTooltip dataPoint={mockDataPoint} valueFn={formatCurrencyValue} />
    );

    const label = screen.getByText(`${mockDataPoint.displayValue}`);
    const value = screen.getByText(/£75,000.23/);

    expect(label).toBeOnTheScreen();
    expect(value).toBeOnTheScreen();
  });

  it('should render chart tooltip with valueFn', () => {
    render(
      <ChartTooltip dataPoint={mockDataPoint} valueFn={(x: number) => x * 2} />
    );

    const label = screen.getByText(`${mockDataPoint.displayValue}`);
    const value = screen.getByText('150000.46');

    expect(label).toBeOnTheScreen();
    expect(value).toBeOnTheScreen();
  });

  it('should render chart tooltip with correct styling', () => {
    render(
      <ChartTooltip dataPoint={mockDataPoint} valueFn={formatCurrencyValue} />
    );

    const tooltip = screen.getByTestId('chart-tooltip-container');
    const label = screen.getByText(`${mockDataPoint.displayValue}`);
    const value = screen.getByText(/£75,000.23/);

    expect(tooltip).toBeOnTheScreen();
    expect(label).toBeOnTheScreen();
    expect(value).toBeOnTheScreen();
    expect(tooltip).toHaveStyle([
      {
        left: 1,
        top: 86,
      },
    ]);
    expect(label).toHaveStyle([
      {
        color: '#141D31',
      },
    ]);
    expect(value).toHaveStyle([
      {
        color: '#FFFFFF',
      },
    ]);
  });

  it('should render chart tooltip with correct positioning when chartX value is below 38', () => {
    const newMockDataPoint = {
      ...mockDataPoint,
      chartX: 10,
    };

    render(
      <ChartTooltip
        dataPoint={newMockDataPoint}
        valueFn={formatCurrencyValue}
      />
    );

    const tooltip = screen.getByTestId('chart-tooltip-container');
    const label = screen.getByText(`${newMockDataPoint.displayValue}`);
    const value = screen.getByText(/£75,000.23/);

    expect(tooltip).toBeOnTheScreen();
    expect(label).toBeOnTheScreen();
    expect(value).toBeOnTheScreen();
    expect(tooltip).toHaveStyle([
      {
        left: 0,
        top: 86,
      },
    ]);
    expect(label).toHaveStyle([
      {
        color: '#141D31',
      },
    ]);
    expect(value).toHaveStyle([
      {
        color: '#FFFFFF',
      },
    ]);
  });

  it('should render chart tooltip with correct positioning when chartY value is below 70', () => {
    const newMockDataPointt = {
      ...mockDataPoint,
      chartY: 80,
    };
    render(
      <ChartTooltip
        dataPoint={newMockDataPointt}
        valueFn={formatCurrencyValue}
      />
    );

    const tooltip = screen.getByTestId('chart-tooltip-container');
    const label = screen.getByText(`${mockDataPoint.displayValue}`);
    const value = screen.getByText(/£75,000.23/);

    expect(tooltip).toBeOnTheScreen();
    expect(label).toBeOnTheScreen();
    expect(value).toBeOnTheScreen();
    expect(tooltip).toHaveStyle([
      {
        left: 1,
        top: -20,
      },
    ]);
    expect(label).toHaveStyle([
      {
        color: '#141D31',
      },
    ]);
    expect(value).toHaveStyle([
      {
        color: '#FFFFFF',
      },
    ]);
  });
});
