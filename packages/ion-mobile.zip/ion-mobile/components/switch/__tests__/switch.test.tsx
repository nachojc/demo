import { fireEvent, render, screen } from '@src/jest/testing-library';

import { Switch } from '../switch';

const toggleSwitch = jest.fn();
describe('Testing a Toggle Switch', () => {
  it('when the switch is clicked, the toggle function is fired', () => {
    render(<Switch value onValueChange={toggleSwitch} />);

    fireEvent(screen.getByRole('switch'), 'onValueChange', true);

    expect(toggleSwitch).toHaveBeenCalledTimes(1);
  });

  it('switch renders on screen', () => {
    render(<Switch value onValueChange={toggleSwitch} />);

    expect(screen.getByRole('switch')).toBeOnTheScreen();
  });

  it('switch TintColor get the Aviva success green', () => {
    render(<Switch value={false} onValueChange={toggleSwitch} />);

    expect(screen.getByRole('switch')).toHaveProp('onTintColor', '#4F9F31');
  });

  it('That the switch is disabled', () => {
    render(<Switch disabled value onValueChange={toggleSwitch} />);

    expect(screen.getByRole('switch')).toHaveProp('disabled', true);
  });

  it('That the switch is enabled', () => {
    render(<Switch value onValueChange={toggleSwitch} />);

    expect(screen.getByRole('switch')).toHaveProp('value', true);
  });

  it('That the switch is NOT enabled', () => {
    render(<Switch value={false} onValueChange={toggleSwitch} />);

    expect(screen.getByRole('switch')).toHaveProp('value', false);
  });
});
