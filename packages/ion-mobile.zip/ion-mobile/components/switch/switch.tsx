import { Switch as ReactNativeSwitch, SwitchProps } from 'react-native';
import { getTokens } from 'tamagui';

// Used React Native Swtich due to issues with Tamagui switch rendering
export const Switch = (props: SwitchProps) => {
  const tokens = getTokens();
  return (
    <ReactNativeSwitch
      role="switch"
      trackColor={{ true: tokens.color.Success.val }}
      thumbColor={tokens.color.White.val}
      ios_backgroundColor={tokens.color.Gray300.val}
      {...props}
    />
  );
};
