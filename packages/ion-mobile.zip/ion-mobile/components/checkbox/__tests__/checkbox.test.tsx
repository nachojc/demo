import { render, screen } from '@src/jest/testing-library';

import { Checkbox } from '../checkbox';

const testProps = { testID: 'checkbox-container' };

describe('Testing a Checkbox', () => {
  it('should not display custom error message when error is false', () => {
    render(
      <Checkbox {...testProps} error={false} errorText="Some error message" />
    );

    expect(
      screen.queryByRole('text', { name: 'Some error message' })
    ).toBeFalsy();
  });

  it('should display custom error message when error is true', () => {
    render(<Checkbox {...testProps} error errorText="Some error message" />);

    expect(
      screen.getByRole('text', { name: 'Some error message' })
    ).toBeOnTheScreen();
  });
});
