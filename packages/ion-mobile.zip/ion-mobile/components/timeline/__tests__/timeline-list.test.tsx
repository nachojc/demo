import { render, screen } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';

import { TimelineCard, TimelineList } from '../timeline-list';
import { TimelineItem } from '../timeline-types';

const TimelineListData: TimelineItem[] = [
  {
    title: 'Enter your information',
    time: '5 mins to complete',
    description: 'Tell us what you know about your pensions.',
  },
  {
    title: 'Leave us to do the hard work',
    time: '4-12 weeks for us to check',
    description:
      'We’ll let you know when we have your pension details ready in the app.',
  },
  {
    title: 'Review your pension details',
    time: '90 days to decide what to do',
    description:
      'You can choose to combine pensions into an Aviva Self-Invested Personal Pension (SIPP). Combining can take another 3-6 weeks until your money is with Aviva.',
  },
];

const TimelineListNoTimeframeData: TimelineItem[] = [
  {
    title: "You've told us about your pensions",
    description:
      'We’ll now get in touch with the pension companies for details on your behalf.',
  },
  {
    title: 'Review your pension results',
    description:
      'We’ll let you know when we have your pension details ready in the app.',
  },
  {
    title: 'Combine your pensions',
    description:
      'You can choose to combine pensions into a new Aviva Self-Invested Personal Pension (SIPP). Combining can take another 4-6 weeks until your money is with Aviva.',
  },
];

const TimelineListNoDescriptionData: TimelineItem[] = [
  {
    title: 'Review your pension results',
    time: '4-12 weeks for us to check',
  },
];

describe('Timeline List Component', () => {
  it('renders the list comp whem called', () => {
    render(<TimelineList items={TimelineListData} />);
    expect(screen.getByTestId(getTestId('timeline-list'))).toBeOnTheScreen();
  });

  it('renders the list comp with multiple cards', () => {
    render(<TimelineList items={TimelineListData} />);
    expect(screen.getByText('Enter your information')).toBeOnTheScreen();
    expect(screen.getByText('Leave us to do the hard work')).toBeOnTheScreen();
    expect(screen.getByText('Review your pension details')).toBeOnTheScreen();
  });

  it('renders the timeline card title, timeframe and description correctly', () => {
    render(
      <TimelineCard
        count={1}
        darkMode
        item={TimelineListData[0]}
        totalItemsCount={3}
      />
    );

    expect(screen.getByText('Enter your information')).toBeOnTheScreen();
    expect(screen.getByText('5 mins to complete')).toBeOnTheScreen();
    expect(
      screen.getByText('Tell us what you know about your pensions.')
    ).toBeOnTheScreen();
  });

  it('renders the timeline card title and description correctly when timeframe is not given', () => {
    render(
      <TimelineCard
        count={1}
        darkMode
        item={TimelineListNoTimeframeData[0]}
        totalItemsCount={3}
      />
    );

    expect(
      screen.getByText("You've told us about your pensions")
    ).toBeOnTheScreen();
    expect(
      screen.getByText(
        'We’ll now get in touch with the pension companies for details on your behalf.'
      )
    ).toBeOnTheScreen();
  });

  it('renders the clock icon when a timeframe is given', () => {
    render(
      <TimelineCard
        count={1}
        darkMode
        item={TimelineListData[0]}
        totalItemsCount={3}
      />
    );

    const icon = screen.getByTestId('test:id/icon-clock-circle', {
      includeHiddenElements: true,
    });
    expect(icon).toBeOnTheScreen();
  });

  it('does not render the clock icon when no timeframe is given', () => {
    render(
      <TimelineCard
        count={1}
        darkMode
        item={TimelineListNoTimeframeData[0]}
        totalItemsCount={3}
      />
    );

    const icon = screen.queryByTestId('test:id/icon-clock-circle', {
      includeHiddenElements: true,
    });

    expect(icon).not.toBeOnTheScreen();
  });

  it('renders the timeline card title and time correctly when description is not given', () => {
    render(
      <TimelineCard
        count={1}
        darkMode
        item={TimelineListNoDescriptionData[0]}
        totalItemsCount={1}
      />
    );

    expect(screen.getByText('Review your pension results')).toBeOnTheScreen();
    expect(screen.getByText('4-12 weeks for us to check')).toBeOnTheScreen();
  });

  it('renders the text in white when darkmode is true', () => {
    render(
      <TimelineCard
        count={1}
        darkMode
        item={TimelineListData[0]}
        totalItemsCount={3}
      />
    );

    const title = screen.getByText('Enter your information');
    expect(title).toBeOnTheScreen();
    expect(title).toHaveStyle({ color: '#FFFFFF' });
  });

  it('renders the text in wealth blue when darkmode is false', () => {
    render(
      <TimelineCard
        count={1}
        darkMode={false}
        item={TimelineListData[0]}
        totalItemsCount={3}
      />
    );

    const title = screen.getByText('Enter your information');
    expect(title).toBeOnTheScreen();
    expect(title).toHaveStyle({ color: '#05142D' });
  });
});
