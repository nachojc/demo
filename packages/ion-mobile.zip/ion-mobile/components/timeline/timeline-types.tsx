export type TimelineItem = {
  title: string;
  time?: string;
  description?: string;
};

export type TimelineCardProps = {
  count: number;
  darkMode: boolean;
  item: TimelineItem;
  totalItemsCount: number;
};

export type TimelineListProps = {
  items: TimelineItem[];
  darkMode?: boolean;
};
