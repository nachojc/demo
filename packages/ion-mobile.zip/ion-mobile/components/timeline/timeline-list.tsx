import { Icon, Text } from '@aviva/ion-mobile';
import { replaceDashesInNumberStrings } from '@src/utils/accessibility/replace-dashes-in-number-strings';
import { getTestId } from '@src/utils/get-test-id';
import { memo, useMemo } from 'react';
import { getTokens, Stack, XStack, YStack } from 'tamagui';

import { TimelineCardProps, TimelineListProps } from './timeline-types';
// Figma Master Comp: https://www.figma.com/file/8CFtMGrVmDa0LH6wcl0sCl/MobileFrameworkMigration?type=design&node-id=15432%3A1146&mode=design&t=4ZAzQF3rQSPO955u-1

/**
 * TimelineList Component renders a numbered list of steps which have a title, description and an optional timeframe.
 * You can pass in darkMode={true} to render the text and icons in a lighter shade to work on dark backgrounds.
 */
export const TimelineList = memo(function TimelineList({
  items,
  darkMode = false,
}: TimelineListProps) {
  return (
    <Stack testID={getTestId('timeline-list')}>
      <YStack gap={'$xl'}>
        {items?.map((item, i) => (
          <TimelineCard
            key={`${item.title}-${i}`}
            count={i + 1}
            darkMode={darkMode}
            item={item}
            totalItemsCount={items.length}
          />
        ))}
      </YStack>
    </Stack>
  );
});

export const TimelineCard = memo(function TimelineCard({
  count,
  darkMode,
  item,
  totalItemsCount,
}: TimelineCardProps) {
  const tokens = getTokens();
  const { title, time, description } = item;

  const color = useMemo(() => {
    return darkMode ? 'White' : 'WealthBlue';
  }, [darkMode]);

  const invertedColor = useMemo(() => {
    return !darkMode ? 'White' : 'WealthBlue';
  }, [darkMode]);

  const accessibilityTitle = replaceDashesInNumberStrings(title);
  const accessibilityTime = time ? replaceDashesInNumberStrings(time) : '';
  const accessibilityDescription = description
    ? replaceDashesInNumberStrings(description)
    : '';
  const accessibilityLabel = `Step ${count} of ${totalItemsCount}. ${accessibilityTitle}: ${accessibilityTime}. ${accessibilityDescription}`;
  return (
    <XStack accessible accessibilityLabel={accessibilityLabel} padding={'$md'}>
      <YStack alignItems="center" marginRight={6}>
        <Stack
          borderRadius={100}
          height={'$6'}
          width={'$6'}
          alignItems="center"
          backgroundColor={'$Primary500'}
        >
          <Text fontVariant="body-semibold-WealthBlue">{count}</Text>
        </Stack>
        <Stack
          marginTop={'$md'}
          flex={1}
          width={'$0.25'}
          backgroundColor={`$${color}`}
        />
      </YStack>
      <YStack marginRight={6} flex={1}>
        <Text
          fontVariant={`heading5-semibold-${color}`}
          tamaguiTextProps={{ paddingBottom: '$md' }}
        >
          {title}
        </Text>
        {time && (
          <XStack alignItems="center" gap={'$md'}>
            <Icon
              name="clock-circle"
              width={15}
              height={15}
              color={tokens.color[color].val}
              stroke={tokens.color[invertedColor].val}
              fill={tokens.color[color].val}
            />
            <Text
              fontVariant={`heading5-regular-${color}`}
              tamaguiTextProps={{
                paddingVertical: '$md',
              }}
            >
              {time}
            </Text>
          </XStack>
        )}
        {description && (
          <Text fontVariant={`body-regular-${darkMode ? color : 'Gray800'}`}>
            {description}
          </Text>
        )}
      </YStack>
    </XStack>
  );
});
