import { render } from '@src/jest/testing-library';
import { getTestId } from '@src/utils/get-test-id';
import { InteractionManager, Text, View } from 'react-native';

import { Carousel } from '../carousel';

let mockIsScreenReaderEnabled = false;
jest.mock('@src/common/providers/accessibility', () => ({
  useAccessibility: () => ({
    isScreenReaderEnabled: mockIsScreenReaderEnabled,
  }),
}));

const MocElement = ({ text }: { text: string }) => (
  <View>
    <Text testID={getTestId(text)}>{text}</Text>
  </View>
);

describe('Carousel', () => {
  afterEach(() => {
    jest.resetAllMocks();
    mockIsScreenReaderEnabled = false;
  });

  it('build by def', async () => {
    const screen = render(
      <Carousel contentWidth={0}>
        <MocElement text="demo" />
        <MocElement text="demo" />
        <MocElement text="demo3" />
      </Carousel>
    );
    expect(
      screen.getByText('demo3', { includeHiddenElements: true })
    ).toBeOnTheScreen();
    expect(
      screen.getAllByText('demo', { includeHiddenElements: true }).length
    ).toBe(2);
  });

  it('should be accessible', async () => {
    mockIsScreenReaderEnabled = true;
    const screen = render(
      <Carousel contentWidth={0} showDots>
        <MocElement text="demo" />
        <MocElement text="demo" />
        <MocElement text="demo3" />
      </Carousel>
    );
    const prevBtn = screen.getByTestId(getTestId('previous-button'));
    const nextBtn = screen.getByTestId(getTestId('next-button'));
    expect(nextBtn).toBeOnTheScreen();
    expect(prevBtn).toBeOnTheScreen();
  });

  it('buttons should be accessible', async () => {
    jest
      .spyOn(InteractionManager, 'runAfterInteractions')
      .mockResolvedValue(() => ({}));
    mockIsScreenReaderEnabled = true;
    const mockNext = jest.fn();
    const mockPrev = jest.fn();

    const screen = render(
      <Carousel
        contentWidth={0}
        showDots
        onNext={mockNext}
        onPrev={mockPrev}
        invertedColorForButton
      >
        <MocElement text="demo" />
        <MocElement text="demo" />
        <MocElement text="demo3" />
      </Carousel>
    );
    const text = screen.getByTestId(getTestId('text-accesibility'));

    expect(text).toHaveProp(
      'accessibilityLabel',
      'Carousel content item 1 of 3'
    );
  });
});
