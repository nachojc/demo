import { useA11yFocus } from '@hooks/use-a11y-focus';
import { useAccessibility } from '@src/common/providers/accessibility';
import { tokens } from '@src/theme/tokens';
import { getTestId } from '@src/utils/get-test-id';
import { isIpad } from '@src/utils/is-ipad';
import {
  Children,
  cloneElement,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import {
  Dimensions,
  InteractionManager,
  LayoutChangeEvent,
  Platform,
  ScrollView as ScrollViewType,
} from 'react-native';
import { useSharedValue } from 'react-native-reanimated';
import { getVariableValue, ScrollView, Stack, XStack, YStack } from 'tamagui';

import { PaginationDots } from '../fullscreen-carousel-modal/pagination-dots';
import { Icon } from '../icon';
import { YStackProps } from '../stacks';

type CarouselProps = {
  onPrev?: (index: number) => void;
  onNext?: (index: number) => void;
  leftLabel?: string;
  rightLabel?: string;
  testID?: string;
  height?: number;
  snapToInterval?: number;
  ItemSeparatorComponent?: () => JSX.Element;
  contentWidth: number;
  children: JSX.Element[];
  showDots?: boolean;
  invertedColorForButton?: boolean;
  styles?: YStackProps;
};

type CardPosition = {
  [key: number]: number;
};

const IS_ANDROID_OR_IPAD = Platform.OS === 'android' || isIpad;

const ENABLED_COLOR = '#122D44';
const DISABLED_COLOR = '#D9D9D9';

export const Carousel = ({
  testID,
  height,
  contentWidth,
  children,
  snapToInterval,
  onPrev,
  onNext,
  ItemSeparatorComponent,
  showDots = false,
  invertedColorForButton,
  styles,
}: CarouselProps) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const { width: windowWidth } = Dimensions.get('window');
  const { focus, elementRef } = useA11yFocus();

  const progressValue = useSharedValue(0);

  const childrenItems = useMemo(
    () => children.filter((v) => v !== null),
    [children]
  );
  const scrollRef = useRef<ScrollViewType>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [moveTo, setMoveTo] = useState(-1);
  const [cardPosition, setCardPosition] = useState<CardPosition>({});

  const enabledColor = invertedColorForButton ? DISABLED_COLOR : ENABLED_COLOR;
  const disabledColor = invertedColorForButton ? ENABLED_COLOR : DISABLED_COLOR;

  const showControls = showDots || isScreenReaderEnabled;
  const contentLength = childrenItems.length;

  const carouselBreakdonwA11yLabel = useMemo(
    () => `Carousel content item ${currentIndex + 1} of ${contentLength}`,
    [contentLength, currentIndex]
  );

  const onNextPressHandler = () => {
    if (currentIndex < contentLength) {
      setMoveTo(currentIndex + 1);
    }
  };

  const onPrevPressHandler = () => {
    if (currentIndex > 0) {
      setMoveTo(currentIndex - 1);
    }
  };

  const updatePage = useCallback(
    (contentOffsetX: number) => {
      let pageNumber: number;
      if (moveTo >= 0) {
        pageNumber = moveTo;
        setMoveTo(-1);
      } else {
        pageNumber = 0;
        Object.values(cardPosition).forEach((card, i) => {
          if (contentOffsetX > card) {
            pageNumber = i + 1;
          }
        });
      }

      if (pageNumber !== currentIndex) {
        progressValue.value = pageNumber;
        if (pageNumber < currentIndex) {
          onPrev?.(pageNumber);
        } else {
          onNext?.(pageNumber);
        }
        setCurrentIndex(pageNumber);
        setTimeout(() => focus(), 100);
      }
    },
    [cardPosition, currentIndex, focus, moveTo, onNext, onPrev, progressValue]
  );

  const onLayoutGetCardPosition = useCallback(
    (index: number) => (event: LayoutChangeEvent) => {
      const { x, width } = event.nativeEvent.layout;
      const currentPos = { [index]: Math.round(x) };
      if (index === contentLength - 1) {
        currentPos[contentLength] = x + Math.round(width);
      }

      setCardPosition((prev) => ({ ...prev, ...currentPos }));
    },
    [contentLength]
  );

  useEffect(() => {
    if (moveTo >= 0) {
      const xPosition = cardPosition[moveTo] - cardPosition[0];
      // Because we need to know if InteractionManager will move the View
      const shouldMove =
        moveTo > currentIndex
          ? cardPosition[contentLength] - cardPosition[moveTo - 1] > windowWidth
          : cardPosition[contentLength] - cardPosition[moveTo] > windowWidth ||
            xPosition === 0;

      if (shouldMove) {
        InteractionManager.runAfterInteractions(() =>
          scrollRef.current?.scrollTo({
            x: xPosition,
            animated: true,
          })
        ).then(() => {
          if (IS_ANDROID_OR_IPAD) {
            // Because onMomentumScrollEnd refuses to work in Android :-(
            updatePage(xPosition);
          } else {
            Promise.resolve();
          }
        });
      } else {
        updatePage(xPosition);
      }
    }
  }, [
    cardPosition,
    contentLength,
    currentIndex,
    focus,
    moveTo,
    updatePage,
    windowWidth,
  ]);

  return (
    <YStack ai={'center'} flex={1} gap={'$xl'} {...styles}>
      {isScreenReaderEnabled && (
        <Stack
          testID={getTestId('text-accesibility')}
          w={24}
          h={8}
          bc={'grey'}
          accessible
          accessibilityLabel={carouselBreakdonwA11yLabel}
          ref={elementRef}
          als={'center'}
        />
      )}
      <ScrollView
        separator={ItemSeparatorComponent?.()}
        horizontal
        decelerationRate={'normal'}
        snapToInterval={
          snapToInterval ?? contentWidth + getVariableValue(tokens.space.xl)
        }
        showsHorizontalScrollIndicator={false}
        showsVerticalScrollIndicator={false}
        testID={testID}
        height={height}
        width={windowWidth}
        ref={scrollRef}
        onMomentumScrollEnd={(e) => updatePage(e.nativeEvent.contentOffset.x)}
        accessibilityRole="adjustable"
        contentContainerStyle={{
          paddingHorizontal: getVariableValue(tokens.space.xl),
        }}
      >
        {Children.map(childrenItems, (child, i) => {
          return cloneElement(child, {
            onLayout: onLayoutGetCardPosition(i),
            importantForAccessibility:
              i === currentIndex ? 'yes' : 'no-hide-descendants',
            accessibilityElementsHidden: i !== currentIndex,
          });
        })}
      </ScrollView>
      {showControls && (
        <XStack mx="$xl">
          {isScreenReaderEnabled && (
            <Stack
              accessible
              accessibilityLabel={
                currentIndex > 0
                  ? `Go to previous carousel content item ${currentIndex} of ${contentLength}`
                  : 'Start of carousel'
              }
              accessibilityState={{
                disabled: currentIndex === 0,
              }}
              accessibilityRole="button"
              testID={getTestId('previous-button')}
              onPress={onPrevPressHandler}
              disabled={currentIndex === 0}
              width={60}
              height={60}
              borderWidth={1}
              borderColor={'#D9D9D9'}
              borderRadius={4}
              justifyContent="center"
              alignItems="center"
            >
              <Icon
                name="chevron-left"
                width={24}
                height={24}
                color={currentIndex === 0 ? disabledColor : enabledColor}
              />
            </Stack>
          )}

          {showControls && (
            <YStack
              height={60}
              flex={1}
              alignItems="center"
              justifyContent="center"
            >
              <PaginationDots
                progressValue={progressValue}
                itemsLength={contentLength}
              />
            </YStack>
          )}

          {isScreenReaderEnabled && (
            <Stack
              accessible
              accessibilityLabel={
                currentIndex < contentLength - 1
                  ? `Go to next carousel content item ${
                      currentIndex + 2
                    } of ${contentLength}`
                  : 'End of carousel'
              }
              accessibilityState={{
                disabled: currentIndex === contentLength - 1,
              }}
              accessibilityRole="button"
              testID={getTestId('next-button')}
              onPress={onNextPressHandler}
              disabled={currentIndex === contentLength - 1}
              width={60}
              height={60}
              borderWidth={1}
              borderColor={'#D9D9D9'}
              borderRadius={4}
              justifyContent="center"
              alignItems="center"
            >
              <Icon
                name="chevron-right"
                width={24}
                height={24}
                color={
                  currentIndex === contentLength - 1
                    ? disabledColor
                    : enabledColor
                }
              />
            </Stack>
          )}
        </XStack>
      )}
    </YStack>
  );
};
