import { getTestId } from '@src/utils/get-test-id';
import { getTokens, getVariableValue, Stack, XStack } from 'tamagui';

import { Icon } from '../icon';
import { Text } from '../text/text';

export const ErrorMessage = ({ error }: { error?: string }) => {
  if (!error) {
    return null;
  }
  const tokens = getTokens();
  return (
    <XStack my="$md" mr="$xl" ai="center" testID="error-message-container">
      <Stack mt="$sm" alignSelf="flex-start">
        <Icon
          name="alert-circle"
          color={getVariableValue(tokens.color.Error)}
        />
      </Stack>
      <Text
        fontVariant={'body-regular-Error'}
        tamaguiTextProps={{ pl: '$md', accessibilityLabel: `Error, ${error}` }}
        testID={getTestId('error-message')}
      >
        {error}
      </Text>
    </XStack>
  );
};
