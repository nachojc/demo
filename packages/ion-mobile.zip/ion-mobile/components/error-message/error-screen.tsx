import { useNavigation } from '@react-navigation/native';
import { getTestId } from '@src/utils/get-test-id';
import { useTranslation } from 'react-i18next';
import { SafeAreaView } from 'react-native';
import { getTokens, Stack, XStack, YStack } from 'tamagui';

import { CloseButton } from '../close-button';
import { Image } from '../image';
import { Text } from '../text/text';

export const ErrorScreen = () => {
  const { t } = useTranslation();
  const tokens = getTokens();
  const { canGoBack, goBack } = useNavigation();

  return (
    <Stack flex={1} testID="error-screen-container">
      <SafeAreaView style={{ flex: 1 }}>
        {canGoBack() && (
          <XStack jc="flex-end" p="$xl">
            <CloseButton
              onPress={() => goBack()}
              accessibilityLabel="Back"
              testID={getTestId('error-back-button')}
            />
          </XStack>
        )}
        <Stack jc="center" space="$xxxl" ai="center" flex={1} p="$xl">
          <Image
            source={require('assets/chair-empty/chair-empty.png')}
            accessibilityLabel="Error icon"
            accessibilityIgnoresInvertColors
            resizeMode="contain"
            style={{
              width: tokens.size[12].val,
              height: tokens.size[12].val,
            }}
          />
          <YStack space="$md" ai="center" mx="$xxl">
            <Text
              fontVariant={'heading5-semibold-Secondary800'}
              tamaguiTextProps={{ ta: 'center' }}
            >
              {t(`errorBoundary.title`)}
            </Text>
            <Text
              fontVariant={'body-regular-Gray800'}
              tamaguiTextProps={{ mb: '$lg', ta: 'center' }}
            >
              {t(`errorBoundary.copy`)}
            </Text>
          </YStack>
        </Stack>
      </SafeAreaView>
    </Stack>
  );
};
