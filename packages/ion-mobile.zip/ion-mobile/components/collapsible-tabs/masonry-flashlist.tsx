import { MasonryFlashList, MasonryFlashListProps } from '@shopify/flash-list';
import { useAccessibility } from '@src/common/providers/accessibility';
import { Tabs } from 'react-native-collapsible-tab-view';
import Animated from 'react-native-reanimated';

import { useTabsContext } from './context';

const AnimatedMasonryFlashList =
  Animated.createAnimatedComponent<MasonryFlashListProps<any>>(
    MasonryFlashList
  );

export const AccessibleTabsMasonryFlashList = <T,>(
  props: MasonryFlashListProps<T>
) => {
  const { scrollHandler } = useTabsContext();

  return (
    <AnimatedMasonryFlashList
      {...props}
      bounces={false}
      onScroll={scrollHandler}
    />
  );
};

export const MasonryFlashListAdapter = <T,>(
  props: MasonryFlashListProps<T>
) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const Component = isScreenReaderEnabled
    ? AccessibleTabsMasonryFlashList
    : Tabs.MasonryFlashList;

  return <Component {...props} />;
};
