import { PropsWithChildren } from 'react';
import { Platform, StyleProp, ViewStyle } from 'react-native';
import { useTabsContext } from 'react-native-collapsible-tab-view';
import Animated, { useAnimatedStyle } from 'react-native-reanimated';

export type TabsHeaderWrapperProps = PropsWithChildren<{
  accessibilityEnabled: boolean;
  layoutType?: 'container' | 'flashList' | 'scrollView';
  scrollViewTopPadding?: number;
}>;

export type TabsHeaderWrapperCollapsibleTabsProps = PropsWithChildren<{
  layoutType?: 'container' | 'flashList' | 'scrollView';
  scrollViewTopPadding?: number;
}>;
const TabsHeaderWrapperCollapsibleTabs = ({
  layoutType,
  scrollViewTopPadding,
  children,
}: TabsHeaderWrapperCollapsibleTabsProps) => {
  const { indexDecimal, headerHeight, tabBarHeight, headerTranslateY } =
    useTabsContext();
  const isInsideTab = layoutType !== 'container';

  const animatedStyle = useAnimatedStyle(() => {
    // android sometimes keeps headerTranslateY positive after scroll to top
    // need to consider it to avoid header flickering while transitioning between tabs
    let translateY = 0;
    if (Platform.OS === 'android') {
      translateY = headerTranslateY.value > 0 ? headerTranslateY.value : 0;
    }
    const style: StyleProp<ViewStyle> = {};
    // if header is in flashlist, we need to shift it up on headerHeight + tabBarHeight value
    if (layoutType === 'flashList') {
      style.position = 'absolute';
      style.left = 0;
      style.right = 0;
      style.top =
        -(headerHeight.value ?? 0) - (tabBarHeight.value ?? 0) + translateY;
      style.width = '100%';
    }
    // if header is in scrollview, we need to shift it up on scrollViewTopPadding value
    if (layoutType === 'scrollView') {
      style.position = 'absolute';
      style.left = 0;
      style.right = 0;
      style.top = -(scrollViewTopPadding ?? 0) + translateY;
      style.width = '100%';
    }
    const isTransitioning = indexDecimal.value % 1 !== 0;
    if (isInsideTab) {
      // if header is inside tab (e.g. flashList or scrollView), we need to hide it while transitioning
      style.opacity = isTransitioning ? 0 : 1;
    } else {
      // if header in tab container (e.g. layoutType is container), we need to show it while transitioning
      style.opacity = isTransitioning ? 1 : 0;
    }
    return style;
  });
  return (
    <Animated.View
      style={animatedStyle}
      pointerEvents={isInsideTab ? 'auto' : 'none'}
    >
      {children}
    </Animated.View>
  );
};
export const TabsHeaderWrapper = ({
  accessibilityEnabled,
  layoutType,
  scrollViewTopPadding,
  children,
}: TabsHeaderWrapperProps) => {
  if (accessibilityEnabled) {
    return layoutType === 'container' ? children : null;
  }
  return (
    <TabsHeaderWrapperCollapsibleTabs
      layoutType={layoutType}
      scrollViewTopPadding={scrollViewTopPadding}
    >
      {children}
    </TabsHeaderWrapperCollapsibleTabs>
  );
};
