import { useTranslation } from 'react-i18next';
import { MaterialTabItem } from 'react-native-collapsible-tab-view';

import { tabAccessibilityLabel } from '../tabs';
import { TabItemProps } from './types';

export const TabItem = ({ selectedIndex, ...rest }: TabItemProps) => {
  const { t } = useTranslation();
  const { index, name, count } = rest;
  const selected = index === selectedIndex;

  return (
    <MaterialTabItem
      {...rest}
      accessible
      accessibilityLabel={tabAccessibilityLabel(t, index + 1, name, count)}
      accessibilityRole="tab"
      accessibilityState={{ selected }}
    />
  );
};
