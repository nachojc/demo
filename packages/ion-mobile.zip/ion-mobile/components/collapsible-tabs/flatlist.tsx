import { useAccessibility } from '@src/common/providers/accessibility';
import { FlatListProps } from 'react-native';
import { Tabs } from 'react-native-collapsible-tab-view';
import Animated from 'react-native-reanimated';

import { useTabsContext } from './context';

export const AccessibleTabsFlatList = <T,>(props: FlatListProps<T>) => {
  const { scrollHandler } = useTabsContext();

  return (
    <Animated.FlatList {...props} bounces={false} onScroll={scrollHandler} />
  );
};

export const FlatListAdapter = <T,>(props: FlatListProps<T>) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const Component = isScreenReaderEnabled
    ? AccessibleTabsFlatList
    : Tabs.FlatList;

  return <Component {...props} />;
};
