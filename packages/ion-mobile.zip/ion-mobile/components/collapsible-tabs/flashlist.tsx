import { FlashList as SPFlashList, FlashListProps } from '@shopify/flash-list';
import { useAccessibility } from '@src/common/providers/accessibility';
import { Tabs } from 'react-native-collapsible-tab-view';
import Animated from 'react-native-reanimated';

import { useTabsContext } from './context';

const AnimatedFlashList =
  Animated.createAnimatedComponent<FlashListProps<any>>(SPFlashList);

export const AccessibleTabsFlashList = <T,>(props: FlashListProps<T>) => {
  const { scrollHandler } = useTabsContext();

  return (
    <AnimatedFlashList {...props} bounces={false} onScroll={scrollHandler} />
  );
};

export const FlashListAdapter = <T,>(props: FlashListProps<T>) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const Component = isScreenReaderEnabled
    ? AccessibleTabsFlashList
    : Tabs.FlashList;

  return <Component {...props} />;
};
