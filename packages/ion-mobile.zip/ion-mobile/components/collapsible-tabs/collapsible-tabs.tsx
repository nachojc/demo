import { useAccessibility } from '@src/common/providers/accessibility';
import { tokens } from '@src/theme/tokens';
import { useCallback, useState } from 'react';
import { useWindowDimensions } from 'react-native';
import {
  MaterialTabBarProps,
  MaterialTabItemProps,
  Tabs,
} from 'react-native-collapsible-tab-view';
import { IndexChangeEventData } from 'react-native-collapsible-tab-view/lib/typescript/src/types';
import { debounce } from 'tamagui';

import { TabBarVariant } from '../tabs';
import { AccessibleTabs } from './accessible-tabs';
import { FlashListAdapter } from './flashlist';
import { FlatListAdapter } from './flatlist';
import { MasonryFlashListAdapter } from './masonry-flashlist';
import { MaterialTabBar } from './material-tab-bar';
import { TabItem } from './material-tab-item';
import { ScrollViewAdapter } from './scroll-view';
import { CollapsibleTabsProps } from './types';

export const DEBOUNCE_WAIT_TIME = 300;

const TabItemComponent = (
  selectedIndex: number,
  count: number,
  props: MaterialTabItemProps<string>
) => {
  return <TabItem {...props} selectedIndex={selectedIndex} count={count} />;
};

const TabBarComponent = ({
  selectedIndex,
  count,
  ...rest
}: MaterialTabBarProps<string> & {
  theme?: TabBarVariant;
  scrollEnabled?: boolean;
  selectedIndex: number;
  count: number;
}) => (
  <MaterialTabBar
    {...rest}
    TabItemComponent={(props) => TabItemComponent(selectedIndex, count, props)}
  />
);

export const CollapsibleTabs = ({
  header,
  tabRoutes,
  tabBarScrollEnabled,
  tabBarVariant,
  lazy,
  collapseThreshold = 30,
  onTabChange,
  onTabPress,
  accessibleTabsProps,
  tabsAlign,
  ...props
}: CollapsibleTabsProps) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const [selectedIndex, setSelectedIndex] = useState(0);
  const { width: windowWidth } = useWindowDimensions();

  const switchTabs = useCallback(
    (properties: IndexChangeEventData<string>) => {
      onTabChange?.(properties.tabName);
      setSelectedIndex(properties.index);
    },
    [onTabChange]
  );

  const debouncedSwitchTabs = debounce(switchTabs, DEBOUNCE_WAIT_TIME);

  if (isScreenReaderEnabled) {
    return (
      <AccessibleTabs
        {...accessibleTabsProps}
        lazy={lazy}
        header={header}
        collapseThreshold={collapseThreshold}
        onTabChange={onTabChange}
        tabBarScrollEnabled={tabBarScrollEnabled}
        tabBarVariant={tabBarVariant}
        tabRoutes={tabRoutes}
      />
    );
  }

  return (
    <Tabs.Container
      allowHeaderOverscroll
      {...props}
      lazy={lazy}
      renderHeader={header}
      renderTabBar={(tabBarProps) => (
        <TabBarComponent
          {...tabBarProps}
          theme={tabBarVariant}
          selectedIndex={selectedIndex}
          count={tabRoutes.length}
          scrollEnabled={tabBarScrollEnabled}
          tabStyle={
            tabsAlign ? { width: windowWidth / tabRoutes.length } : undefined
          }
          onTabPress={(name) => {
            onTabPress?.(name);
            tabBarProps?.onTabPress(name);
          }}
        />
      )}
      headerContainerStyle={{
        shadowColor: tokens.color.Gray900.val,
        shadowOpacity: 0.1,
        shadowRadius: tokens.size[1].val,
      }}
      onTabChange={(eventData) => {
        debouncedSwitchTabs(eventData);
      }}
    >
      {tabRoutes.map(({ key, title, component }) => {
        return (
          <Tabs.Tab name={title} key={key}>
            {component()}
          </Tabs.Tab>
        );
      })}
    </Tabs.Container>
  );
};

CollapsibleTabs.FlashList = FlashListAdapter;
CollapsibleTabs.FlatList = FlatListAdapter;
CollapsibleTabs.ScrollView = ScrollViewAdapter;
CollapsibleTabs.MasonryFlashList = MasonryFlashListAdapter;
