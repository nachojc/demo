import { render, screen } from '@src/jest/testing-library';
import { routes } from '@src/features/dev-mode/components/tabs/manga-collapsible-tabs';
import { tokens } from '@src/theme/tokens';
import { Tabs } from 'react-native-collapsible-tab-view';

import { MaterialTabBar } from '../material-tab-bar';

describe('MaterialTabBar', () => {
  it('has the correct accessibilityRole', () => {
    render(
      <Tabs.Container
        renderHeader={jest.fn()}
        renderTabBar={(props) => <MaterialTabBar {...props} />}
        onTabChange={jest.fn}
      >
        {routes.map(({ key, title, component }) => (
          <Tabs.Tab name={title} key={key}>
            {component()}
          </Tabs.Tab>
        ))}
      </Tabs.Container>
    );

    expect(
      screen.getByTestId('test:id/material-tab-bar-wrapper', {
        includeHiddenElements: true,
      })
    ).toHaveProp('accessibilityRole', 'tablist');
  });

  it.each([
    [
      'white',
      tokens.color.Secondary800.val,
      tokens.color.Secondary800Opacity67.val,
      tokens.color.Gray200.val,
      { backgroundColor: tokens.color.Secondary800.val },
      { backgroundColor: tokens.color.White.val },
    ],
    [
      'blue',
      tokens.color.White.val,
      tokens.color.WhiteOpacity67.val,
      tokens.color.Gray200.val,
      { backgroundColor: tokens.color.Primary500.val },
      { backgroundColor: tokens.color.Secondary800.val },
    ],
    [
      'yellow',
      tokens.color.Secondary800.val,
      tokens.color.Secondary800Opacity67.val,
      tokens.color.Primary600.val,
      { backgroundColor: tokens.color.Secondary800.val },
      { backgroundColor: tokens.color.Primary500.val },
    ],
    [
      'plain',
      tokens.color.Secondary800.val,
      tokens.color.Secondary800Opacity67.val,
      tokens.color.Gray200.val,
      { backgroundColor: tokens.color.Primary500.val },
      { backgroundColor: tokens.color.White.val },
    ],
  ] as const)(
    'renders correctly with %s theme',
    (
      tabVariant,
      activeColor,
      inactiveColor,
      pressColor,
      indicatorStyle,
      style
    ) => {
      render(
        <Tabs.Container
          renderHeader={jest.fn()}
          renderTabBar={(props) => (
            <MaterialTabBar {...props} theme={tabVariant} />
          )}
          onTabChange={jest.fn}
        >
          {routes.map(({ key, title, component }) => (
            <Tabs.Tab name={title} key={key}>
              {component()}
            </Tabs.Tab>
          ))}
        </Tabs.Container>
      );

      const tabBar = screen.getByTestId('MaterialTabBar');

      expect(tabBar).toHaveProp('activeColor', activeColor);
      expect(tabBar).toHaveProp('inactiveColor', inactiveColor);
      expect(tabBar).toHaveProp('pressColor', pressColor);
      expect(tabBar).toHaveProp('indicatorStyle', {
        ...indicatorStyle,
        height: tokens.size[1].val,
      });
      expect(tabBar).toHaveProp('style', {
        ...style,
        height: tokens.size[8].val,
      });
      expect(tabBar).toHaveProp('labelStyle', {
        fontSize: tokens.size[4].val,
        fontWeight: '600',
        textTransform: 'capitalize',
      });
    }
  );
});
