import { act, renderHook } from '@src/jest/testing-library';

import { useSize } from '../use-size';

describe('useSize', () => {
  it('should update size on layout change', () => {
    const { result } = renderHook(() => useSize());

    act(() => {
      result.current[1]({
        nativeEvent: {
          layout: {
            width: 100,
            height: 200,
          },
        },
      });
    });

    expect(result.current[0]).toEqual({ width: 100, height: 200 });
  });
});
