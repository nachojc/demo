import { useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import Animated, {
  FadeInUp,
  FadeOutUp,
  runOnJS,
  useAnimatedScrollHandler,
  useSharedValue,
} from 'react-native-reanimated';

import { Tabs } from '../tabs';
import { TabsContext } from './context';
import { AccessibleTabsFlashList } from './flashlist';
import { AccessibleTabsFlatList } from './flatlist';
import { AccessibleTabsMasonryFlashList } from './masonry-flashlist';
import { AccessibleTabsScrollView } from './scroll-view';
import { AccessibleTabsProps } from './types';

const Enter = FadeInUp.duration(300);
const Exit = FadeOutUp.duration(300);

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    zIndex: 1,
  },
});

export const useScrollManager = (collapseThreshold: number) => {
  const [headerOpen, setHeaderOpen] = useState(true);
  const scrollY = useSharedValue(0);

  const scrollHandler = useAnimatedScrollHandler((event) => {
    scrollY.value = event.contentOffset.y;

    runOnJS(setHeaderOpen)(scrollY.value < collapseThreshold);
  }, []);

  return { scrollHandler, headerOpen, setHeaderOpen };
};

export const AccessibleTabs = ({
  header,
  tabRoutes,
  tabBarScrollEnabled,
  tabBarVariant,
  lazy,
  collapseThreshold = 30,
  onTabChange,
  ...props
}: AccessibleTabsProps) => {
  const { scrollHandler, headerOpen, setHeaderOpen } =
    useScrollManager(collapseThreshold);
  const providerValue = useMemo(() => ({ scrollHandler }), [scrollHandler]);

  const onIndexChange = () => {
    setHeaderOpen(true);
  };

  return (
    <TabsContext.Provider value={providerValue}>
      <View style={styles.container}>
        {headerOpen && (
          <Animated.View style={styles.header} entering={Enter} exiting={Exit}>
            {header()}
          </Animated.View>
        )}
        <Tabs
          {...props}
          lazy={lazy}
          tabRoutes={tabRoutes}
          tabBarScrollEnabled={tabBarScrollEnabled}
          tabBarVariant={tabBarVariant}
          onTabChange={onTabChange}
          onIndexChange={onIndexChange}
        />
      </View>
    </TabsContext.Provider>
  );
};

AccessibleTabs.FlashList = AccessibleTabsFlashList;
AccessibleTabs.FlatList = AccessibleTabsFlatList;
AccessibleTabs.ScrollView = AccessibleTabsScrollView;
AccessibleTabs.MasonryFlashList = AccessibleTabsMasonryFlashList;
