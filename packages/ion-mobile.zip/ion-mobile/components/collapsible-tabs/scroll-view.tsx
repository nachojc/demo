import { useAccessibility } from '@src/common/providers/accessibility';
import { ScrollViewProps } from 'react-native';
import { Tabs } from 'react-native-collapsible-tab-view';
import Animated from 'react-native-reanimated';

import { useTabsContext } from './context';

export const AccessibleTabsScrollView = ({
  children,
  ...rest
}: ScrollViewProps) => {
  const { scrollHandler } = useTabsContext();

  return (
    <Animated.ScrollView
      {...rest}
      bounces={false}
      onScroll={scrollHandler}
      scrollEventThrottle={1}
      showsVerticalScrollIndicator={false}
    >
      {children}
    </Animated.ScrollView>
  );
};

export const ScrollViewAdapter = ({ children, ...rest }: ScrollViewProps) => {
  const { isScreenReaderEnabled } = useAccessibility();
  const Component = isScreenReaderEnabled
    ? AccessibleTabsScrollView
    : Tabs.ScrollView;

  return <Component {...rest}>{children}</Component>;
};
