import { getTestId } from '@src/utils/get-test-id';
import {
  MaterialTabBar as TabBar,
  MaterialTabBarProps,
} from 'react-native-collapsible-tab-view';
import { Stack } from 'tamagui';

import { TabBarVariant } from '../tabs';
import { getTabBarStyles } from '../tabs/theme';

export const MaterialTabBar = ({
  theme = 'white',
  ...rest
}: MaterialTabBarProps<string> & { theme?: TabBarVariant }) => {
  return (
    <Stack
      accessibilityRole="tablist"
      testID={getTestId('material-tab-bar-wrapper')}
    >
      <TabBar {...rest} {...getTabBarStyles(theme)} />
    </Stack>
  );
};
