import { ScrollViewProps as RNScrollViewProps } from 'react-native';
import {
  CollapsibleProps,
  MaterialTabItemProps,
} from 'react-native-collapsible-tab-view';

import { BaseTabsProps, TabsProps } from '../tabs/types';

export type BaseCollapsibleTabsProps = BaseTabsProps & {
  header: () => JSX.Element;
  collapseThreshold?: number;
};

export type AccessibleTabsProps = BaseCollapsibleTabsProps & TabsProps;

export type CollapsibleTabsProps = BaseCollapsibleTabsProps &
  Omit<CollapsibleProps, 'children' | 'onTabChange'> & {
    accessibleTabsProps?: TabsProps;
  };

export type TabContextType = { scrollHandler: RNScrollViewProps['onScroll'] };

export type TabItemProps = MaterialTabItemProps<string> & {
  count: number;
  selectedIndex: number;
};
