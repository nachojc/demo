import {
  getTokens,
  Icon,
  IconName,
  Separator,
  StackProps,
  Text,
  XStack,
  YStack,
} from '@aviva/ion-mobile';
import { useAnalytics } from '@hooks/use-analytics';
import { ACTION_HOME_DASHBOARD_WEALTH_SEE_MORE_TAPPED } from '@src/features/dashboard/screen/wealth/analytics';
import { getTestId } from '@src/utils/get-test-id';
import { memo, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { ColorValue, Pressable, View } from 'react-native';

export type LimitViewItem = {
  color?: ColorValue;
  name: string;
  value: string;
};

type LimitViewProps = {
  items: LimitViewItem[];
  minItems?: number;
  maxItems?: number;
  moreLabel?: string;
  lessLabel?: string;
  moreIcon?: IconName;
  lessIcon?: IconName;
  displayRow?: number;
  styles?: StackProps;
};

const DefaultText = () => {
  const { t } = useTranslation();

  return {
    moreLabelDefault: t('limitView.seeMore'),
    moreIconDefault: t('limitView.chevronDown'),
    lessLabelDefault: t('limitView.seeLess'),
    lessIconDefault: t('limitView.chevronUp'),
  };
};

export const LimitView = memo(
  ({
    items,
    minItems = 2,
    maxItems = 10,
    moreLabel,
    moreIcon,
    lessLabel,
    lessIcon,
    displayRow = 3,
    styles,
  }: LimitViewProps) => {
    const { trackUserEvent } = useAnalytics();
    const {
      moreLabelDefault,
      moreIconDefault,
      lessLabelDefault,
      lessIconDefault,
    } = DefaultText();
    const tokens = getTokens();
    const [expanded, setExpanded] = useState<boolean>(false);

    const underMinLimit = minItems > 0 && items.length < minItems;
    const overMaxLimit = maxItems && items?.length > maxItems;

    const isInvalidItem = !items?.length || overMaxLimit || underMinLimit;

    if (isInvalidItem) {
      return null;
    }

    const slicedItems = items.slice(0, expanded ? items.length : displayRow);

    const accessibilityLabel = `List contains ${items.length} items. ${items
      .map(({ name, value }) => `${name}, ${parseFloat(value)}%`)
      .join('. ')}. End of list.`;

    const handleToggleShow = () => {
      trackUserEvent(ACTION_HOME_DASHBOARD_WEALTH_SEE_MORE_TAPPED);
      setExpanded(!expanded);
    };

    return (
      <YStack
        paddingHorizontal={tokens.size[4].val}
        f={1}
        ai="stretch"
        testID={getTestId('limit-view')}
        {...styles}
      >
        <YStack
          testID={getTestId('breakdown-list-wrapper')}
          accessible
          accessibilityLabel={accessibilityLabel}
        >
          {slicedItems.map((item, index: number) => (
            <YStack
              key={`${item.name}-${index}`}
              testID={getTestId(`item-${index}`)}
              ai="stretch"
            >
              <XStack py={tokens.size[2].val} ai={'center'}>
                <View
                  testID={getTestId('circle-wrapper')}
                  style={{ paddingRight: tokens.size[1].val }}
                >
                  <Icon width={8} height={8} name="circle" color={item.color} />
                </View>
                <Text
                  fontVariant="body-regular-White"
                  tamaguiTextProps={{
                    flex: 1,
                    testID: getTestId(`label-${item.name}`),
                  }}
                >
                  {item.name}
                </Text>
                <Text
                  fontVariant="body-semibold-White"
                  tamaguiTextProps={{
                    pl: tokens.size[4].val,
                    testID: getTestId(`value-${item.value}`),
                  }}
                >
                  {item.value}
                </Text>
              </XStack>
              <Separator testID={getTestId(`separator-${index}`)} />
            </YStack>
          ))}
        </YStack>
        {items.length > displayRow && (
          <Pressable
            accessibilityElementsHidden
            importantForAccessibility="no-hide-descendants"
            testID={getTestId('show-hide')}
            onPress={handleToggleShow}
          >
            <XStack pt={tokens.size[2].val} ai={'center'} jc={'center'}>
              <Text fontVariant="body-semibold-White">
                {expanded
                  ? lessLabel ?? lessLabelDefault
                  : moreLabel ?? moreLabelDefault}
              </Text>
              <Icon
                color={tokens.color.White.val}
                name={
                  expanded
                    ? lessIcon ?? (lessIconDefault as IconName)
                    : moreIcon ?? (moreIconDefault as IconName)
                }
              />
            </XStack>
          </Pressable>
        )}
      </YStack>
    );
  }
);
