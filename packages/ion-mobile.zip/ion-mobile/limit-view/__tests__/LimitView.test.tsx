import {
  fireEvent,
  mockTrackUserEvent,
  render,
  screen,
} from '@src/jest/testing-library';
import { ACTION_HOME_DASHBOARD_WEALTH_SEE_MORE_TAPPED } from '@src/features/dashboard/screen/wealth/analytics';
import { getTestId } from '@src/utils/get-test-id';

import { LimitView } from '..';

const mockItem = [
  { color: '#1A61BD', name: 'MyMoney Account', value: '10.90%' },
  { color: '#44C0FF', name: 'Stocks & Shares ISA', value: '10%' },
  { color: '#009AB1', name: 'Savings & Investments', value: '12%' },
  { color: '#BFE6EB', name: 'Savings & Investments', value: '12%' },
  { color: '#FFBC00', name: 'Savings & Investments', value: '8%' },
  { color: '#F20098', name: 'Savings & Investments', value: '15%' },
  { color: '#AA12B8', name: 'Savings & Investments', value: '18.9%' },
  { color: '#FFBC00', name: 'Savings & Investments', value: '8%' },
  { color: '#F20098', name: 'Savings & Investments', value: '15%' },
  { color: '#AA12B8', name: 'Savings & Investments', value: '18%' },
];

jest.mock('@src/features/dashboard/hooks/use-dashboard-theme', () => ({
  useDashboardTheme: () => ({
    tabBackgroundColor: 'white',
    headerBackgroundColor: 'white',
  }),
}));

describe('LimitView component with 10 item-element', () => {
  it('should render 3 items only if the length is more than 3', async () => {
    render(<LimitView items={mockItem} />);

    const items = await screen.findAllByTestId(/test:id\/item-/);

    expect(items).toHaveLength(3);
  });

  it('should See more button with chevron-down if the length is more than 3', () => {
    render(<LimitView items={mockItem} />);

    const chevronDownIcon = screen.getByTestId('test:id/icon-chevron-down', {
      includeHiddenElements: true,
    });

    expect(chevronDownIcon).toBeOnTheScreen();
    expect(
      screen.getByTestId(getTestId('show-hide'), {
        includeHiddenElements: true,
      })
    ).toHaveTextContent('See more');
  });

  it('should fire the See more button, display - 10 elements, See less, and chevron-up', async () => {
    render(<LimitView items={mockItem} />);

    const seeMoreEl = screen.getByTestId(getTestId('show-hide'), {
      includeHiddenElements: true,
    });
    fireEvent.press(seeMoreEl);

    const items = await screen.findAllByTestId(/test:id\/item-/);
    const chevronDownIcon = screen.getByTestId('test:id/icon-chevron-up', {
      includeHiddenElements: true,
    });

    expect(items).toHaveLength(10);
    expect(chevronDownIcon).toBeOnTheScreen();
    expect(
      screen.getByTestId(getTestId('show-hide'), {
        includeHiddenElements: true,
      })
    ).toHaveTextContent('See less');
    expect(mockTrackUserEvent).toHaveBeenNthCalledWith(
      1,
      ACTION_HOME_DASHBOARD_WEALTH_SEE_MORE_TAPPED
    );
  });
});

describe('LimitView with less than or equal 3 array element', () => {
  it('should not display show-hide button by default height of 3', () => {
    render(<LimitView items={mockItem.slice(0, 3)} />);

    const seeMoreEl = screen.queryByTestId(getTestId('show-hide'), {
      includeHiddenElements: true,
    });
    const items = screen.getAllByTestId(/test:id\/item-/);

    expect(seeMoreEl).not.toBeOnTheScreen();
    expect(items).toHaveLength(3);
  });

  it('should not display show-hide button when height greater than array length', () => {
    render(<LimitView items={mockItem.slice(0, 6)} displayRow={7} />);

    const seeMoreEl = screen.queryByTestId(getTestId('show-hide'), {
      includeHiddenElements: true,
    });
    const items = screen.getAllByTestId(/test:id\/item-/);

    expect(items).toHaveLength(6);
    expect(seeMoreEl).not.toBeOnTheScreen();
  });

  it('should display show-hide button if array length is greater than height', () => {
    render(<LimitView items={mockItem.slice(0, 5)} displayRow={4} />);

    const seeMoreEl = screen.queryByTestId(getTestId('show-hide'), {
      includeHiddenElements: true,
    });
    const items = screen.getAllByTestId(/test:id\/item-/);

    expect(seeMoreEl).toBeOnTheScreen();
    expect(items).toHaveLength(4);
  });
});
describe('LimitView with opt', () => {
  it('should not display component if over max limit', () => {
    render(<LimitView items={mockItem} maxItems={5} />);

    expect(screen.queryByTestId('limit-view')).not.toBeOnTheScreen();
  });

  it('should not display component if below min limit', () => {
    render(<LimitView items={mockItem} minItems={50} />);

    expect(screen.queryByTestId('limit-view')).not.toBeOnTheScreen();
  });
});

describe('LimitView styles', () => {
  it('should have the correct styles for the limit-view', () => {
    render(<LimitView items={mockItem} />);
    expect(screen.getByTestId('test:id/limit-view')).toHaveStyle({
      alignItems: 'stretch',
      flex: 1,
      flexDirection: 'column',
      paddingLeft: 16,
      paddingRight: 16,
    });
  });

  it('should have the correct styles for the item rows', () => {
    render(<LimitView items={mockItem} />);
    const itemEls = screen.getAllByTestId(/test:id\/item/);

    itemEls.forEach((e) => {
      expect(e).toHaveStyle({
        alignItems: 'stretch',
        flexDirection: 'column',
      });
    });
  });

  it('should have the correct styles for the circle wrappers', () => {
    render(<LimitView items={mockItem} />);

    const circleWrappers = screen.getAllByTestId('test:id/circle-wrapper');

    circleWrappers.forEach((e) => {
      expect(e).toHaveStyle({
        paddingRight: 4,
      });
    });
  });

  it('should have the correct width and height for circle SVGs', () => {
    render(<LimitView items={mockItem} />);

    const circleEls = screen.getAllByTestId('test:id/icon-circle', {
      includeHiddenElements: true,
    });

    circleEls.forEach((e) => {
      expect(e).toHaveStyle({
        width: 8,
        height: 8,
      });
    });
  });

  it('should have the correct styles for labels', () => {
    render(<LimitView items={mockItem} />);

    const itemEls = screen.getAllByTestId(/test:id\/label-/);

    itemEls.forEach((e) => {
      expect(e).toHaveStyle({
        color: '#FFFFFF',
        flex: 1,
        fontFamily: 'SourceSansPro-Regular',
        fontSize: 16,
        lineHeight: 24,
      });
    });
  });

  it('should have the correct styles for values', () => {
    render(<LimitView items={mockItem} />);

    const valueEls = screen.getAllByTestId(/test:id\/value-/);

    valueEls.forEach((e) => {
      expect(e).toHaveStyle({
        color: '#FFFFFF',
        fontFamily: 'SourceSansPro-SemiBold',
        fontSize: 16,
        lineHeight: 24,
        paddingLeft: 16,
      });
    });
  });

  it('should have a separator in every item row', () => {
    render(<LimitView items={mockItem} />);
    const itemEls = screen.getAllByTestId(/test:id\/item/);

    itemEls.forEach((_, index) => {
      expect(
        screen.getByTestId(`test:id/separator-${index}`)
      ).toBeOnTheScreen();
    });
  });
});

describe('LimitView A11y', () => {
  it('should have correct A11y props', () => {
    render(<LimitView items={mockItem} />);
    const breakdownEl = screen.getByTestId(getTestId('breakdown-list-wrapper'));
    const showHideEl = screen.getByTestId(getTestId('show-hide'), {
      includeHiddenElements: true,
    });

    expect(breakdownEl).toHaveProp('accessible', true);
    expect(breakdownEl).toHaveProp(
      'accessibilityLabel',
      expect.stringMatching(/^List contains \d+ items\.(.*) End of list\.$/g)
    );
    expect(showHideEl).toHaveProp('accessibilityElementsHidden');
    expect(showHideEl).toHaveProp(
      'importantForAccessibility',
      'no-hide-descendants'
    );
  });
});
