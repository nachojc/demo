const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path'); 

const app = express();
const port = 8080;

const getTimestamp = () =>
  new Date()
    .toISOString()
    .replace(/T/, ' ')
    .replace(/\..+/, '');

var _privateLog = console.log;
console.log = (...params) => _privateLog.apply(console, [getTimestamp(), ...params]);

app.use(cors({
  origin: function (origin, callback) {
    return callback(null, true); //allow all origins
  },
  credentials: true
}));
let staticPath = '/static';
app.use( staticPath,express.static(path.join(__dirname, 'statics')))

app.all('*', (req, res) => {
  if (req.url == '/healthz') {
    return res.status(200).end('UP');
  }

  let file = req.path + '-' + req.method;

  const path = './mocks' + file + '.json';

  if (fs.existsSync(path)) {
    console.log(`sending ${path} to ${req.get('origin')}`);
    res.status(200).end(fs.readFileSync(path));
  } else {
    console.log(`Failed to serve ${path} to ${req.get('origin')}`);
    res.status(500).end('file does not exist');
  }
})

app.listen(port, () => console.log(`Mock server on port ${port}!`));