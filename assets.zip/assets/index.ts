import { isManga } from '@hooks/use-expo-config';

export { icons } from './icons';

export const getAppIcon = () =>
  isManga() ? require('./aviva-logo.png') : require('./avivawealth.png');

export const getIpadAppIcon = () =>
  isManga() ? require('./myaviva.png') : require('./avivawealth.png');
