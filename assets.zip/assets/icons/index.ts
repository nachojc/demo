/**
 * Export SVG files as individual icons to be consumed by Icon component via the 'name' prop.
 * To derive icons from existing file via props (e.g. colour variant) export such icons as
 * tuples with name as the first element and icons props as the second element of the tuple.
 */

import { tokens } from '@theme/tokens';
import { FC } from 'react';
import { SvgProps } from 'react-native-svg';

import acceleration from './acceleration.svg';
import accelerationPin from './acceleration-pin.svg';
import alertCircle from './alert-circle.svg';
import alertCircleOutline from './alert-circle-outline.svg';
import alertOctagonOutline from './alert-octagon-outline.svg';
import alertTriangleOutline from './alert-triangle-outline.svg';
import androidShare from './android-share.svg';
import annuity from './annuity.svg';
import arrowRight from './arrow-right.svg';
import avivaMarketplaceIcon from './aviva-marketplace-icon.svg';
import barChart from './bar-chart.svg';
import book from './book.svg';
import bookOpen from './book-open.svg';
import braking from './braking.svg';
import brakingPin from './braking-pin.svg';
import calculator from './calculator.svg';
import calendar from './calendar.svg';
import camera from './camera.svg';
import car from './car.svg';
import cartoonBook from './cartoon-book.svg';
import chat from './chat.svg';
import chevronDown from './chevron-down.svg';
import chevronLeft from './chevron-left.svg';
import chevronRight from './chevron-right.svg';
import chevronUp from './chevron-up.svg';
import circle from './circle.svg';
import circlePlay from './circle-play.svg';
import clipboard from './clipboard.svg';
import clock from './clock.svg';
import clockWithBackground from './clock-background.svg';
import clockColored from './clock-colored.svg';
import close from './close.svg';
import copy from './copy.svg';
import cornering from './cornering.svg';
import corneringPin from './cornering-pin.svg';
import creditCard from './credit-card.svg';
import criticalIllness from './critical-illness.svg';
import danger from './danger.svg';
import deleteIcon from './delete.svg';
import directDebit from './direct-debit.svg';
import document from './document.svg';
import documentExpired from './document-expired.svg';
import download from './download.svg';
import drivingLicense from './driving-license.svg';
import edit from './edit.svg';
import eye from './eye.svg';
import eyeOff from './eye-off.svg';
import feet from './feet.svg';
import file from './file.svg';
import fileText from './file-text.svg';
import financial from './financial.svg';
import guidance from './guidance.svg';
import heart from './heart.svg';
import helpCircle from './help-circle.svg';
import home from './home.svg';
import horizontalBarChart from './horizontal-bar-chart.svg';
import infoChatBubble from './info-chat-bubble.svg';
import infoCircle from './info-circle.svg';
import information from './information.svg';
import investments from './investments.svg';
import iosGpsArrow from './ios-gps-arrow.svg';
import iosSettings from './ios-settings.svg';
import iosShare from './ios-share.svg';
import iosTick from './ios-tick.svg';
import lifeInsurance from './life-insurance.svg';
import link from './link.svg';
import location from './location.svg';
import lock from './lock.svg';
import mail from './mail.svg';
import map from './map.svg';
import menu from './menu.svg';
import minus from './minus.svg';
import money from './money.svg';
import moneyCircles from './money-circles.svg';
import motor from './motor.svg';
import move from './move.svg';
import moveToAviva from './move-to-aviva.svg';
import passport from './passport.svg';
import paymentCards from './payment-cards.svg';
import pdf from './pdf.svg';
import personScan from './person-scan.svg';
import pet from './pet.svg';
import phone from './phone.svg';
import phonePin from './phone-pin.svg';
import pieChart from './pie-chart.svg';
import piggyBank from './piggy-bank.svg';
import play from './play.svg';
import plus from './plus.svg';
import process from './process.svg';
import qAndA from './q-and-a.svg';
import qAndAWhite from './q-and-a-white.svg';
import questionCircle from './question-circle.svg';
import carQL from './quicklinks-car.svg';
import creditCardQL from './quicklinks-credit-card.svg';
import mapPinQL from './quicklinks-map-pin.svg';
import usersQL from './quicklinks-users.svg';
import repeat from './repeat.svg';
import replay from './replay.svg';
import righCircleArrow from './right-circle-arrow.svg';
import sandCastle from './sand-castle.svg';
import search from './search.svg';
import searchCircle from './search-circle.svg';
import shield from './shield.svg';
import signDocument from './sign-document.svg';
import smartphone from './smartphone.svg';
import speed from './speed.svg';
import speedPin from './speed-pin.svg';
import speedometer from './speedometer.svg';
import switchIcon from './switch.svg';
import tag from './tag.svg';
import target from './target.svg';
import targetWithArrow from './target-with-arrow.svg';
import teaCup from './tea-cup.svg';
import tick from './tick.svg';
import tickBox from './tick-box.svg';
import tick2 from './tick2.svg';
import tick3 from './tick3.svg';
import tick4 from './tick4.svg';
import tick5 from './tick5.svg';
import travel from './travel.svg';
import trendingUp from './trending-up.svg';
import upload from './upload.svg';
import user from './user.svg';
import users from './users.svg';
import van from './van.svg';
import videocall from './videocall.svg';
import wallet from './wallet.svg';
import warningSign from './warning-sign.svg';
import wrench from './wrench.svg';
import xCircle from './x-circle.svg';

/**
 * Export all icons here. Icons can be composed from SVGs with props of the Icon
 * component (i.e. SVG) predefined, which makes it easy to create icon variations
 * (dark and light, or rotate them with style prop (e.g. `style: { transform: [{ rotate: '90deg' }] }`)).
 */
export const icons = {
  acceleration,
  'acceleration-pin': [accelerationPin, { color: tokens.color.Error.val }],
  'alert-circle': [alertCircle, { stroke: tokens.color.White.val }],
  'alert-circle-outline': alertCircleOutline,
  'alert-octagon-outline': alertOctagonOutline,
  'alert-triangle-outline': alertTriangleOutline,
  'android-save': download,
  'android-share': androidShare,
  annuity,
  'arrow-right': arrowRight,
  'aviva-marketplace-icon': avivaMarketplaceIcon,
  'bar-chart': barChart,
  book,
  'book-open': bookOpen,
  braking,
  'braking-pin': [brakingPin, { color: tokens.color.Error.val }],
  calculator: [calculator, { color: tokens.color.White.val }],
  calendar,
  camera,
  car,
  'cartoon-book': cartoonBook,
  chat,
  'chevron-down': chevronDown,
  'chevron-left': chevronLeft,
  'chevron-right': chevronRight,
  'chevron-up': chevronUp,
  circle,
  'circle-play': circlePlay,
  clipboard,
  clock,
  'clock-circle': [
    clock,
    {
      color: tokens.color.Information.val,
      fill: tokens.color.Information.val,
      stroke: tokens.color.White.val,
    },
  ],
  'clock-colored': clockColored,
  clockWithBackground,
  close: [close, { strokeWidth: 3 }],
  copy: [copy, { color: tokens.color.White.val }],
  cornering,
  'cornering-pin': [corneringPin, { color: tokens.color.Error.val }],
  'credit-card': creditCard,
  'critical-illness': criticalIllness,
  danger,
  delete: [deleteIcon, { color: tokens.color.Tertiary800.val }],
  'direct-debit': directDebit,
  document,
  'document-expired': documentExpired,
  'driving-license': drivingLicense,
  edit: [edit, { color: tokens.color.Tertiary800.val }],
  'external-link': link,
  eye,
  'eye-off': eyeOff,
  feet,
  file,
  'file-text': [fileText, { color: tokens.color.Tertiary800.val }],
  financial,
  guidance,
  health: heart,
  'help-circle': helpCircle,
  home,
  'horizontal-bar-chart': horizontalBarChart,
  info: [information, { stroke: tokens.color.White.val }],
  'info-chat-bubble': infoChatBubble,
  infoCircle,
  investments,
  'ios-gps-arrow': iosGpsArrow,
  'ios-settings': iosSettings,
  'ios-share': iosShare,
  'ios-tick': iosTick,
  'life-insurance': lifeInsurance,
  location: [location, { color: tokens.color.Tertiary800.val }],
  lock,
  mail: [mail, { color: tokens.color.White.val }],
  map,
  menu,
  minus: [minus, { color: tokens.color.Tertiary800.val }],
  money,
  'money-circles': moneyCircles,
  motor,
  move,
  'move-to-aviva': moveToAviva,
  'number-ellipse': [circle, { color: tokens.color.Primary500.val }],
  passport,
  paymentCards,
  pdf: [pdf, { color: '#D95044' }],
  'person-scan': personScan,
  pet,
  phone: [phone, { stroke: 'transparent' }],
  'phone-distraction': [phone, { fill: 'transparent' }],
  'phone-distraction-pin': [phonePin, { color: tokens.color.Error.val }],
  'pie-chart': pieChart,
  pieChart,
  'piggy-bank': piggyBank,
  play,
  plus: [plus, { color: tokens.color.Tertiary800.val }],
  process,
  'q-and-a': qAndA,
  'q-and-a-white': qAndAWhite,
  'question-circle': questionCircle,
  'quicklinks-car': carQL,
  'quicklinks-credit-card': creditCardQL,
  'quicklinks-map-pin': mapPinQL,
  'quicklinks-users': usersQL,
  repeat,
  replay,
  'right-circle-arrow': righCircleArrow,
  'sand-castle': sandCastle,
  search,
  'search-circle': searchCircle,
  sell: tag,
  shield,
  'sign-document': signDocument,
  smartphone,
  speed,
  'speeding-pin': [speedPin, { color: tokens.color.Error.val }],
  speedometer,
  switch: switchIcon,
  target,
  'target-with-arrow': targetWithArrow,
  'tea-cup': teaCup,
  tick: [tick, { color: tokens.color.Success.val }],
  tick2: [tick2, { color: tokens.color.Success.val }],
  tick3: [tick3, { color: '#3E812C' }],
  tick4: [tick4, { color: tokens.color.Success.val }],
  tick5,
  tickBox,
  travel,
  'trending-down': [
    trendingUp,
    {
      color: tokens.color.Error.val,
      style: { transform: [{ rotateX: '180deg' }] },
    },
  ],
  'trending-up': [trendingUp, { color: tokens.color.Success.val }],
  'trip-end-circle': [circle, { color: tokens.color.Gray900.val }],
  'trip-start-circle': [
    circle,
    { fill: tokens.color.White.val, stroke: tokens.color.Gray900.val },
  ],
  upload,
  user,
  users,
  van,
  videocall,
  wallet,
  'warning-sign': warningSign,
  wrench,
  'x-circle': [xCircle, { color: tokens.color.Error.val }],
} satisfies Record<string, FC<SvgProps> | [FC<SvgProps>, SvgProps]>;
