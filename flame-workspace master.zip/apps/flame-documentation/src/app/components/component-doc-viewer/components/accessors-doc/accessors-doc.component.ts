import { Component, Input } from '@angular/core';

@Component({
	selector: 'sn-accessors-doc',
	templateUrl: 'accessors-doc.component.html',
	styleUrls: ['accessors-doc.component.scss']
})
export class AccessorsDocComponent {
	constructor() {}

	public arguments: any;

	@Input() accessorsData: any;
}
