import { Component, Input } from '@angular/core';

@Component({
	selector: 'sn-methods-doc',
	templateUrl: 'methods-doc.component.html',
	styleUrls: ['methods-doc.component.scss']
})
export class MethodsDocComponent {
	constructor() {}

	public arguments: any;

	@Input() methodsData: any;
}
