import { Component, Input, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

const lifecycleHooks = [
	'ngOnChanges',
	'ngOnInit',
	'ngDoCheck',
	'ngAfterContentInit',
	'ngAfterContentChecked',
	'ngAfterViewInit',
	'ngAfterViewChecked',
	'ngOnDestroy'
];

@Component({
	selector: 'sn-component-doc-viewer',
	templateUrl: 'component-doc-viewer.component.html',
	styleUrls: ['component-doc-viewer.component.scss']
})
export class ComponentDocViewerComponent implements OnInit {
	constructor(private _httpClient: HttpClient) {}

	public docData: any;
	public groups: Array<number>;
	public constructors: any;
	public properties: any;
	public accessors: any;
	public methods: any;

	@Input() docUrl: string;
	@Input() libraryName: string;

	private getGroupsIds(groups: Array<number>, groupName: string) {
		return groups.filter(group => group['title'].toLowerCase() === groupName);
	}

	private getConstructorInfo(docData: any, groups: Array<number>) {
		const info = [];
		const groupIds = this.getGroupsIds(groups, 'constructors');
		groupIds[0]['children'].forEach((value: any) => {
			docData.children.filter((data: any) => {
				if (data.id === value) {
					info.push(data);
				}
			});
		});
		return info[0];
	}

	private getPropertiesInfo(docData: any, groups: Array<number>) {
		const info = [];
		const groupIds = this.getGroupsIds(groups, 'properties');
		groupIds[0]['children'].forEach((value: any) => {
			docData.children.filter((data: any) => {
				if (data.id === value && data.flags.hasOwnProperty('isPublic')) {
					info.push(data);
				}
			});
		});
		return info;
	}

	private getAccessorsInfo(docData: any, groups: Array<number>) {
		const info = [];
		const groupIds = this.getGroupsIds(groups, 'accessors');
		groupIds[0]['children'].forEach((value: any) => {
			docData.children.filter((data: any) => {
				if (data.id === value) {
					info.push(data);
				}
			});
		});
		return info;
	}

	private getMethodsInfo(docData: any, groups: Array<number>) {
		const info = [];
		const groupIds = this.getGroupsIds(groups, 'methods');
		groupIds[0]['children'].forEach((value: any) => {
			docData.children.filter((data: any) => {
				if (
					data.id === value &&
					!data.flags.hasOwnProperty('isPrivate') &&
					lifecycleHooks.indexOf(data.name) === -1
				) {
					info.push(data);
				}
			});
		});
		return info;
	}

	ngOnInit() {
		this._httpClient
			.get(`./assets/docs/libs/${this.libraryName}/${this.docUrl}/doc.json`)
			.subscribe((res: any) => {
				this.docData = res.children[0].children[0];
				this.groups = this.docData.groups;
				this.constructors = this.getConstructorInfo(this.docData, this.groups);
				this.properties = this.getPropertiesInfo(this.docData, this.groups);
				this.accessors = this.getAccessorsInfo(this.docData, this.groups);
				this.methods = this.getMethodsInfo(this.docData, this.groups);
			});
	}
}
