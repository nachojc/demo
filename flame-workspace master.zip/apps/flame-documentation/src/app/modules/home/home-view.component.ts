import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-home-view',
	templateUrl: 'home-view.component.html',
	styleUrls: ['home-view.component.scss']
})
export class HomeViewComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
