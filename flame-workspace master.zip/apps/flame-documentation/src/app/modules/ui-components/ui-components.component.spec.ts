import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { UIComponentsComponent } from './ui-components.component';
import {
	FormFieldModule,
	InputModule
} from '@santander/flame-component-library';

describe('UIComponentsComponent', () => {
	let component: UIComponentsComponent;
	let fixture: ComponentFixture<UIComponentsComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			imports: [FormFieldModule, InputModule],
			declarations: [UIComponentsComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(UIComponentsComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
});
