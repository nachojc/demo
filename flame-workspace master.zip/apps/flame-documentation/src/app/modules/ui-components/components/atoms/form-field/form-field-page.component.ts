import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
	selector: 'sn-form-field-page',
	templateUrl: './form-field-page.component.html',
	styleUrls: ['./form-field-page.component.scss']
})
export class FormFieldPageComponent implements OnInit {
	constructor() {}

	public language = 'html';

	public caseOneContent = `<sn-form-field>
  <input sn-input type="text" id="firstname" placeholder="Nombre"/>
  <div sn-hint>Ingrese nombre</div>
</sn-form-field>`;

	public caseTwoContent = `<form [formGroup]="simpleForm" novalidate>
  <sn-form-field clearable="true">
    <input sn-input type="text" id="lastname" placeholder="Apellido Paterno"/>
    <div sn-hint>Ingrese apellido paterno</div>
  </sn-form-field>
</form>`;

	simpleForm: FormGroup;

	ngOnInit() {
		this.simpleForm = new FormGroup({
			lastname: new FormControl('', {
				validators: [Validators.minLength(2)],
				updateOn: 'change'
			})
		});
	}
}
