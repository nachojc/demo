import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-top-bar-page',
	templateUrl: './top-bar-page.component.html',
	styleUrls: ['./top-bar-page.component.scss']
})
export class TopBarPageComponent {
	constructor() {}
	public implementation = `
  <sn-top-bar title="Title">
    <p left>izq</p>
    <p center></p> <!--Opcional-->
    <p right>der</p>
  </sn-top-bar>
  `;
}
