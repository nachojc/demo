import { Component } from '@angular/core';

@Component({
	selector: 'sn-stepper-page',
	templateUrl: './stepper-page.component.html',
	styleUrls: ['./stepper-page.component.scss']
})
export class StepperPageComponent {
	constructor() {}
}
