import { Component, ViewChild, ViewEncapsulation } from '@angular/core';

@Component({
	selector: 'sn-tooltip-page',
	templateUrl: './tooltip-page.component.html',
	styleUrls: ['./tooltip-page.component.scss']
})
export class TooltipPageComponent {
	@ViewChild('tooltip') tooltip;

	constructor() {}

	public language = 'html';

	public caseOneContent = `<button snTooltip="Message Tooltip">Aceptar</button>`;

	public caseDisabled = `<button snTooltipDisabled="true" snTooltip="Message Tooltip">Aceptar</button>`;

	public caseDelay = `<button snTooltipShowDelay="1000" snTooltipHideDelay="1000" snTooltip="Message Tooltip">Aceptar</button>`;

	public casePosition = `<button snTooltipPosition="right" snTooltip="Message Tooltip">Aceptar</button>`;

	public caseClass = `<button snTooltip="Message Tooltip" snTooltipClass="example-tooltip-red">Aceptar</button>`;

	public caseHideShow = `  <button (mouseenter)="tooltip.hide()">Ocultar</button>
  <button (mouseenter)="tooltip.show()">Mostrar</button>
  <button (mouseenter)="tooltip.toggle()">Toggle</button>

  <button #tooltip="SnTooltipDirective" snTooltip="Message Tooltip">Aceptar</button>`;
}
