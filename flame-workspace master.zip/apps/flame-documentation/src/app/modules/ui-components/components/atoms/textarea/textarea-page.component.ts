import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-textarea-page',
	templateUrl: './textarea-page.component.html',
	styleUrls: ['./textarea-page.component.scss']
})
export class TextareaPageComponent implements OnInit {
	constructor() {}

	public language = 'html';
	public languagejs = 'js';

	public caseOneContent = `<sn-form-field>
  <textarea sn-input></textarea>
</sn-form-field>`;
	ngOnInit() {}
}
