import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-radio-page',
	templateUrl: './radio-page.component.html',
	styleUrls: ['./radio-page.component.scss']
})
export class RadioPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
