import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-icon-button-page',
	templateUrl: './icon-button-page.component.html',
	styleUrls: ['./icon-button-page.component.scss']
})
export class IconButtonPageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
