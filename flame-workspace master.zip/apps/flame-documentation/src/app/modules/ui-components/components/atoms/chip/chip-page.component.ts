import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-chip-page',
	templateUrl: './chip-page.component.html',
	styleUrls: ['./chip-page.component.scss']
})
export class ChipPageComponent implements OnInit {
	constructor() {}

	public language = 'html';

	public caseOneContent = `<sn-chip id=1 (clickChip)="function()"></sn-chip>`;
	public caseTwoContent = `<sn-chip id=2 class="active" (clickChip)="function()"></sn-chip>`;
	public caseThreeContent = `<sn-chip id=3 class="medium" (clickChip)="function()"></sn-chip>`;
	public caseFourContent = `<sn-chip id=4 class="high" (clickChip)="function()"></sn-chip>`;

	ngOnInit() {}
}
