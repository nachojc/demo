import { OverlayPageComponent } from './overlay/overlay-page.component';

export const SERVICES = [OverlayPageComponent];
