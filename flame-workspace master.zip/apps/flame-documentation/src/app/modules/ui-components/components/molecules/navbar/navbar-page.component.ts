import { Component, OnInit } from '@angular/core';
import { NgbButtonsModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
	selector: 'sn-navbar-page',
	templateUrl: './navbar-page.component.html',
	styleUrls: ['./navbar-page.component.scss']
})
export class NavbarPageComponent {
	constructor() {}
	active = 0;
	buttons = [
		{ name: 'Home', icon: 'buscar' },
		{ name: 'Profile', icon: 'buscar' },
		{ name: 'Search', icon: 'buscar' },
		{ name: 'Cards', icon: 'buscar' }
	];
	example = ` [
    {'name': 'Home',
    'icon': 'buscar',
    },
    {'name': 'Profile',
    'icon': 'buscar',
    },
    {'name': 'Search',
    'icon': 'buscar',
    },
    {'name': 'Cards',
    'icon': 'buscar',
    }
  ];
  `;
	implementation = ` <sn-navbar [buttons]="buttons"></sn-navbar> `;
	selectElement(i: number, route: string) {
		this.active = i;
	}
}
