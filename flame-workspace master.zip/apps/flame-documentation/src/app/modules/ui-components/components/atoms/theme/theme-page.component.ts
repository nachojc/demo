import { Component } from '@angular/core';

@Component({
	selector: 'sn-theme-page',
	templateUrl: './theme-page.component.html',
	styleUrls: ['./theme-page.component.scss']
})
export class ThemePageComponent {
	constructor() {}

	public stepOne = `@NgModule({
  imports: [
    ThemeModule.forRoot({
      themes: [FlameFoundationTheme],
      active: 'flame-foundation'
    })
  ]
})`;

	public stepTwo = `<div class="container" snTheme>
  ...
</div>`;

	public stepThree = `import { Theme } from '@santander/flame-core-library/lib/theme/symbols';
export const ZurichTheme: Theme = {
  name: 'zurich',
  properties: {
    '--sn-theme-primary': '#4066b3',
    '--sn-theme-secondary': '#B39040',
    '--sn-theme-background': '#FFFFFF'
  }
};`;

	public stepFour = `@NgModule({
  imports: [
    ThemeModule.forRoot({
      themes: [FlameFoundationTheme, ZurichTheme],
      ...
    })
  ]
})`;

	public exampleOne = `<button snButton snTheme='zurich'>Ejemplo</button>`;
}
