import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-icon-page',
	templateUrl: './icon-page.component.html',
	styleUrls: ['./icon-page.component.scss']
})
export class IconPageComponent implements OnInit {
	constructor() {}

	public language = 'js';
	public iconSvg = `icon="sn-buscar"`;
	ngOnInit() {}
}
