import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-range-page',
	templateUrl: './range-page.component.html',
	styleUrls: ['./range-page.component.scss']
})
export class RangePageComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
