import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-components',
	templateUrl: './ui-components.component.html',
	styleUrls: ['./ui-components.component.scss']
})
export class UIComponentsComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
