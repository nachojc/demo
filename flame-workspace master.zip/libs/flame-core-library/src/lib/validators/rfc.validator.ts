import { AbstractControl } from '@angular/forms';
const rfcFisicasRegex = /^([A-ZÑ\x26]{4}([0-9]{2})(0[1-9]|1[0-2])(0[1-9]|1[0-9]|2[0-9]|3[0-1]))([A-Z\d]{3})?$/;

export function validRFCValidator(control: AbstractControl) {
	if (!rfcFisicasRegex.test(control.value)) {
		return {
			validRFC: true
		};
	}

	return null;
}
