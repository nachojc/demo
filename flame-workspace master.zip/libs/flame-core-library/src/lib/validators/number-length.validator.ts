import { AbstractControl, ValidatorFn } from '@angular/forms';

export function numberLengthValidator(lengths: Array<number>): ValidatorFn {
	let lenStr = '';
	lengths.forEach(len => {
		lenStr += '.{' + len + '}|';
	});
	lenStr = lenStr.slice(0, -1);
	const numberRegex = new RegExp('^(?=[0-9]*$)(?:' + lenStr + ')$');
	return (control: AbstractControl): { [key: string]: boolean } | null => {
		if (!numberRegex.test(control.value)) {
			return { numberLength: true };
		}
		return null;
	};
}
