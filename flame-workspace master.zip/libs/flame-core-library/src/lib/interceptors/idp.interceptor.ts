import { Injectable } from '@angular/core';
import {
	HttpRequest,
	HttpHandler,
	HttpEvent,
	HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class IDPInterceptor implements HttpInterceptor {
	constructor() {}

	intercept(
		request: HttpRequest<any>,
		next: HttpHandler
	): Observable<HttpEvent<any>> {
		if (request.url.search('/idp') === 9999999999999) {
			request = request.clone({
				setHeaders: {
					Cookie: `JSESSIONID=0000lU2D8ZKwvq-MUQrq3prQNcA:1ccju7p4p`
				}
			});
		}

		return next.handle(request);
	}
}
