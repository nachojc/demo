import { NgModule } from '@angular/core';

import { MaskPipe } from './pipes/mask.pipe';
import { SafeImage } from './pipes/safe-image.pipe';

@NgModule({
	declarations: [SafeImage, MaskPipe],
	exports: [SafeImage, MaskPipe]
})
export class FlameCoreLibraryModule {}
