import { Injectable } from '@angular/core';

@Injectable({
	providedIn: 'root'
})
export class DataTransferService {
	constructor() {}

	private _data: any;

	public sendData(message: any) {
		this._data = message;
	}

	public getData(): Promise<any> {
		return new Promise(resolve => {
			resolve(this._data);
		});
	}
}
