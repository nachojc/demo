import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	OnDestroy,
	forwardRef
} from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Subscription } from 'rxjs';
import {
	DialogService,
	DialogReference,
	CustomDialog
} from '../../atoms/dialog/index';
import { SelectScrollComponent } from './select-scroll/select-scroll.component';
import { SelectService } from './select-service/select.service';

export class SnDialogSelectChange {
	source: DialogSelectComponent;
	selected: any;
}

@Component({
	selector: 'sn-dialog-select',
	templateUrl: './dialog-select.component.html',
	styleUrls: ['./dialog-select.component.scss'],
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => DialogSelectComponent),
			multi: true
		}
	]
})
export class DialogSelectComponent
	implements OnInit, OnDestroy, ControlValueAccessor {
	constructor(
		private dialog: DialogService,
		private selService: SelectService
	) {}

	private _selectedOption = '';
	private _selectedOptionBefClosed;
	private subscription: Subscription;
	private dialogRef: DialogReference;
	public isDialogOpen: boolean;
	private _disabled = false;

	@Input() title: string;
	@Input() subtitle: string; // TODO: especificar el tipo
	@Input() options: any[]; // TODO: especificar el tipo
	@Input() value: any; // TODO: especificar el tipo
	@Input() mode = 'input';
	@Input() closeLabel: any;
	@Input() enableHr: any;
	@Input() placeholder: string;
	@Input() disabledButton: boolean;
	@Input() maxHeight: number;
	@Input()
	get disabled() {
		return this._disabled;
	}
	set disabled(value: any) {
		this._disabled = value;
	}
	@Output() onSelection = new EventEmitter();

	get selectedOption() {
		if (this._selectedOption !== '') {
			return this._selectedOption;
		} else {
			return '';
		}
	}
	set selectedOption(value: string) {
		this._selectedOption = value;
	}
	_onChange: (value: any) => void = () => {};

	clickOnSelect() {
		if (this.disabled) {
			return;
		}
		this.dialogRef = this.dialog.open(
			{
				closeLabel: this.closeLabel,
				title: this.title,
				enableHr: this.enableHr,
				disabledButton: this.disabledButton,
				maxHeight: this.maxHeight ? this.maxHeight : 450
			},
			new CustomDialog(SelectScrollComponent, {
				options: this.options,
				subtitle: this.subtitle
			})
		);
		this.isDialogOpen = true;
		this.dialogRef.changeStatusButton(this.disabledButton);
		this.dialogRef.beforeClose().subscribe((cancel?: boolean) => {
			this.isDialogOpen = false;
			if (!cancel && this._selectedOptionBefClosed !== null) {
				this._selectedOption = this._selectedOptionBefClosed.text.name;
				this.onSelection.emit(this._selectedOptionBefClosed);
				this._onChange(this._selectedOptionBefClosed);
			}
			this._selectedOptionBefClosed = null;
		});
	}

	/**
	 * Sets the select's value. Part of the ControlValueAccessor interface
	 * required to integrate with Angular's core forms API.
	 *
	 * @param value New value to be written to the model.
	 */
	writeValue(value: any): void {
		this._selectedOption = value.name;
		if (value.name === undefined) {
			this._selectedOption = value;
		}
	}

	/**
	 * Saves a callback function to be invoked when the select's value
	 * changes from user input. Part of the ControlValueAccessor interface
	 * required to integrate with Angular's core forms API.
	 *
	 * @param fn Callback to be triggered when the value changes.
	 */
	registerOnChange(fn: (value: any) => void): void {
		this._onChange = fn;
	}

	/**
	 * Saves a callback function to be invoked when the select is blurred
	 * by the user. Part of the ControlValueAccessor interface required
	 * to integrate with Angular's core forms API.
	 *
	 * @param fn Callback to be triggered when the component has been touched.
	 */
	registerOnTouched(fn: () => {}): void {}

	/**
	 * Disables the select. Part of the ControlValueAccessor interface required
	 * to integrate with Angular's core forms API.
	 *
	 * @param isDisabled Sets whether the component is disabled.
	 */
	setDisabledState(isDisabled: boolean): void {
		this.disabled = isDisabled;
	}

	ngOnInit() {
		this.subscription = this.selService.selectedElement().subscribe(element => {
			this.dialogRef.changeStatusButton(false);
			this._selectedOptionBefClosed = element;
		});
	}

	ngOnDestroy() {
		this.subscription.unsubscribe();
	}
}
