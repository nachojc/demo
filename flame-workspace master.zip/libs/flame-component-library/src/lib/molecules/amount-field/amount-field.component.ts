import {
	Component,
	OnInit,
	ElementRef,
	ViewChild,
	Input,
	Output,
	EventEmitter
} from '@angular/core';

@Component({
	selector: 'sn-amount-field',
	templateUrl: './amount-field.component.html',
	styleUrls: ['./amount-field.component.scss']
})
export class AmountFieldComponent implements OnInit {
	// Outputs
	@Output() monto = new EventEmitter<string>();

	// Inputs
	@Input() disableComponent = true;

	// Elementos DOM
	@ViewChild('hiddenText') textHelper: ElementRef;
	@ViewChild('amountInput') inputAmount: ElementRef;

	// Variables
	public minWidth = 70;
	public width = this.minWidth;

	// Control
	public cleanButtonActive = false;

	resize() {
		if (this.inputAmount.nativeElement.value !== '00.00') {
			this.cleanButtonActive = true;
			this.monto.emit(this.inputAmount.nativeElement.value);
			setTimeout(
				() =>
					(this.width = Math.max(
						this.minWidth,
						this.textHelper.nativeElement.offsetWidth
					))
			);
		}
	}

	resetInput() {
		this.inputAmount.nativeElement.value = '';
		this.monto.emit('00.00');
		this.minWidth = 70;
		this.width = this.minWidth;
		this.cleanButtonActive = false;
		setTimeout(
			() =>
				(this.width = Math.max(
					this.minWidth,
					this.textHelper.nativeElement.offsetWidth
				))
		);
	}

	calculateFocusWidth(focusin = true) {
		if (focusin) {
			if (this.inputAmount.nativeElement.value === '') {
				this.width = 10;
				this.minWidth = this.width;
			}
		} else {
			if (this.inputAmount.nativeElement.value === '') {
				this.minWidth = 70;
				this.width = this.minWidth;
				this.cleanButtonActive = false;
			}
		}
	}

	constructor() {
		this.monto.emit('00.00');
	}

	ngOnInit() {}
}
