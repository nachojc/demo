import { AmountFieldModule } from './amount-field/amount-field.module';
import { CallButtonModule } from './call-button/call-button.module';
import { MotiveFieldModule } from './motive-field/motive-field.module';
import { NavbarModule } from './navbar/navbar.module';
import { ProductModule } from './product/product.module';
import { SnackBarModule } from './snackbar/snackbar.module';
import { TopBarModule } from './top-bar/top-bar.module';

export const MOLECULES_COMPONENTS = [
	AmountFieldModule,
	CallButtonModule,
	MotiveFieldModule,
	NavbarModule,
	ProductModule,
	SnackBarModule,
	TopBarModule
];
