import {
	Component,
	OnInit,
	Input,
	Output,
	EventEmitter,
	ElementRef,
	ViewChild
} from '@angular/core';

@Component({
	selector: 'sn-motive-field',
	templateUrl: './motive-field.component.html',
	styleUrls: ['./motive-field.component.scss']
})
export class MotiveFieldComponent implements OnInit {
	// Outputs
	@Output() motivo = new EventEmitter<string>();

	// Inputs
	@Input() disableComponent = true;

	// Elementos DOM
	@ViewChild('hiddenText') textHelper: ElementRef;
	@ViewChild('motiveInput') inputMotive: ElementRef;

	// Variables
	public minWidth = 80;
	public width = this.minWidth;

	// Control
	public cleanButtonActive = false;

	resize() {
		if (this.inputMotive.nativeElement.value !== '') {
			this.cleanButtonActive = true;
			this.motivo.emit(this.inputMotive.nativeElement.value);
			setTimeout(
				() =>
					(this.width = Math.max(
						this.minWidth,
						this.textHelper.nativeElement.offsetWidth
					))
			);
		}
	}

	resetInput() {
		this.inputMotive.nativeElement.value = '';
		this.motivo.emit('');
		this.minWidth = 80;
		this.width = this.minWidth;
		this.cleanButtonActive = false;
		setTimeout(
			() =>
				(this.width = Math.max(
					this.minWidth,
					this.textHelper.nativeElement.offsetWidth
				))
		);
	}

	calculateFocusWidth(focusin = true) {
		if (focusin) {
			if (this.inputMotive.nativeElement.value === '') {
				this.width = 15;
				this.minWidth = this.width;
			}
		} else {
			if (this.inputMotive.nativeElement.value === '') {
				this.minWidth = 80;
				this.width = this.minWidth;
				this.cleanButtonActive = false;
			}
		}
	}

	constructor() {
		this.motivo.emit('');
	}

	ngOnInit() {}
}
