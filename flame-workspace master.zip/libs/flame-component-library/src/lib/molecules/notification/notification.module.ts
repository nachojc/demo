import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OverlayModule as OverlayModuleCDK } from '@angular/cdk/overlay';
import { NotificationComponent } from './notification.component';
import { NotificationService } from './notification.service';
import { IconModule } from '../../atoms/icon/icon.module';

@NgModule({
	imports: [CommonModule, OverlayModuleCDK, IconModule],
	declarations: [NotificationComponent],
	providers: [NotificationService],
	entryComponents: [NotificationComponent]
})
export class NotificationModule {}
