import { NgModule } from '@angular/core';
import { TextareaComponent } from './textarea.component';

@NgModule({
	imports: [],
	declarations: [TextareaComponent],
	exports: [TextareaComponent]
})
export class TextareaModule {}
