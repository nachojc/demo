import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SlideButtonComponent } from './slide-button.component';
import { IconModule } from '../icon/icon.module';

@NgModule({
	imports: [CommonModule, IconModule],
	declarations: [SlideButtonComponent],
	exports: [SlideButtonComponent]
})
export class SlideButtonModule {}
