import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SlideButtonComponent } from './slide-button.component';
import { By } from '@angular/platform-browser';
import { IconModule } from '../icon/icon.module';

describe('SlideButtonComponent', () => {
	let fixture: ComponentFixture<SlideButtonComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [SlideButtonComponent],
			imports: [IconModule]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(SlideButtonComponent);
	}),
		it('should change icon', () => {
			fixture.componentInstance.show = false;
			fixture.detectChanges();
			const slideIconLoad = fixture.debugElement.query(By.css('#iconLoad'));
			expect(slideIconLoad.nativeElement.id).toEqual('iconLoad');
		});
});
