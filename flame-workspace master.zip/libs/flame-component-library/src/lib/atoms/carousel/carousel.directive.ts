import {
	ContentChildren,
	Directive,
	QueryList,
	Input,
	Output,
	EventEmitter,
	AfterViewInit
} from '@angular/core';
import { SnSlideDirective } from './carousel-slide.directive';
import { Slide } from './carousel-slide.interface';
import { Subscription } from 'rxjs';
import { interval } from 'rxjs';

@Directive({
	selector: '[snCarousel]',
	exportAs: 'SnCarouselDirective'
})
export class SnCarouselDirective implements AfterViewInit {
	private _arrows = true;
	private _indicators = true;
	private _swipe = true;
	private _interval = 3000;
	private _infinity = true;
	private _autoplay = true;
	private _intervalSub: Subscription;

	@ContentChildren(SnSlideDirective) slides: QueryList<SnSlideDirective>;

	@Input()
	get arrows(): boolean {
		return this._arrows;
	}
	set arrows(value: boolean) {
		if (!value) {
			this._arrows = true;
		} else {
			if (value.toString() === 'true') {
				this._arrows = true;
			} else {
				this._arrows = false;
			}
		}
	}

	@Input()
	get indicators(): boolean {
		return this._indicators;
	}
	set indicators(value: boolean) {
		if (!value) {
			this._indicators = true;
		} else {
			if (value.toString() === 'true') {
				this._indicators = true;
			} else {
				this._indicators = false;
			}
		}
	}

	@Input()
	get swipe(): boolean {
		return this._swipe;
	}
	set swipe(value: boolean) {
		if (!value) {
			this._swipe = true;
		} else {
			if (value.toString() === 'true') {
				this._swipe = true;
			} else {
				this._swipe = false;
			}
		}
	}

	@Input()
	get interval(): number {
		return this._interval;
	}
	set interval(value: number) {
		this._interval = value;
	}

	@Input()
	get infinity(): boolean {
		return this._infinity;
	}
	set infinity(value: boolean) {
		if (!value) {
			this._infinity = true;
		} else {
			if (value.toString() === 'true') {
				this._infinity = true;
			} else {
				this._infinity = false;
			}
		}
	}

	@Input()
	get autoplay(): boolean {
		return this._autoplay;
	}
	set autoplay(value: boolean) {
		if (!value) {
			this._autoplay = true;
		} else {
			if (value.toString() === 'true') {
				this._autoplay = true;
			} else {
				this._autoplay = false;
			}
		}
	}

	@Output() slide = new EventEmitter<Slide>();

	@Output() playing = new EventEmitter<boolean>();

	ngAfterViewInit() {
		this.slides.forEach((slide: SnSlideDirective) => {
			slide.onActivate.subscribe(this._onSlideActivation.bind(this));
			slide.onComplete.subscribe(this._onSlideCompletation.bind(this));
		});

		if (this._interval && this._autoplay) {
			this._intervalSub = interval(this._interval).subscribe(() => {
				this.next();
			});
		}
	}

	selectSlide(slideSelected: Slide): void {
		const slidesArray = this.slides.toArray();
		const completedSlide = this.getActivatedSlideIndex();
		const index = slidesArray.findIndex(
			(slide: SnSlideDirective) => slide.id === slideSelected.id
		);
		const slideCompleted = this.slides.toArray()[completedSlide];

		slideCompleted.complete();
		slidesArray[index].activate();
	}

	selectSlideById(slideSelectedId: string): any {
		const slidesArray = this.slides.toArray();
		const completedSlide = this.getActivatedSlideIndex();
		const index = slidesArray.findIndex(
			(slide: SnSlideDirective) => slide.id === slideSelectedId
		);
		const slideCompleted = this.slides.toArray()[completedSlide];

		slideCompleted.complete();
		slidesArray[index].activate();
	}

	next(): void {
		let nextSlide = this.getActivatedSlideIndex() + 1;
		const completedSlide = this.getActivatedSlideIndex();

		if (nextSlide === this.slides.length) {
			if (this._infinity) {
				nextSlide = 0;
			} else {
				this._intervalSub.unsubscribe();
				return;
			}
		}

		if (this.slides && this.slides.length > 0) {
			const slide = this.slides.toArray()[nextSlide];
			const slideCompleted = this.slides.toArray()[completedSlide];
			slideCompleted.complete();
			slide.activate();
		}
	}

	prev(): void {
		let nextSlide = this.getActivatedSlideIndex();
		const completedSlide = this.getActivatedSlideIndex();

		if (nextSlide === 0) {
			if (this._infinity) {
				nextSlide = this.slides.length;
			}
		}

		if (this.slides && this.slides.length > 0 && nextSlide > 0) {
			const slide = this.slides.toArray()[nextSlide - 1];
			const slideCompleted = this.slides.toArray()[completedSlide];
			slideCompleted.complete();
			slide.activate();
		}
	}

	getActivatedSlideIndex(): number {
		if (this.slides && this.slides.length > 0) {
			return this.slides
				.toArray()
				.findIndex((slide: SnSlideDirective) => slide.activated);
		} else {
			return -1;
		}
	}

	getActivedSlide() {
		if (this.slides && this.slides.length > 0) {
			return this.slides
				.toArray()
				.find((slide: SnSlideDirective) => slide.activated);
		} else {
			return null;
		}
	}

	private _onSlideActivation(activatedSlide: Slide) {
		this.slides
			.filter((slide: SnSlideDirective) => slide.id !== activatedSlide.id)
			.forEach((slide: SnSlideDirective) => slide.deactivate());
	}

	private _onSlideCompletation(completedSlide: Slide) {
		this.slide.emit(completedSlide);
		this.playing.emit(this.autoplay);

		const slidesArray = this.slides.toArray();
		const index = slidesArray.findIndex(
			(slide: SnSlideDirective) => slide.id === completedSlide.id
		);
		if (index < slidesArray.length - 1) {
			slidesArray[index + 1].activate();
		}
	}
}
