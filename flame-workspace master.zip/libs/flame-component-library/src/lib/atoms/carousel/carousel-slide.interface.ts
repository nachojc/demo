export interface Slide {
	id: string;
	activated: boolean;
	completed: boolean;
}
