export * from './carousel.module';
export * from './carousel-slide.interface';
