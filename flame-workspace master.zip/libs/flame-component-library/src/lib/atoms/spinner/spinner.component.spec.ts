import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SpinnerComponent } from './spinner.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('SpinnerComponent', () => {
	let component: SpinnerComponent;
	let fixture: ComponentFixture<SpinnerComponent>;
	let spinnerEl: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [SpinnerComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(SpinnerComponent);
		component = fixture.componentInstance;
		spinnerEl = fixture.debugElement.query(By.css('#sn-loader'));
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});
	/*
  it('should change color', () => {
    component.color = 'rgb(128, 0, 128)';
    fixture.detectChanges();
    expect(spinnerEl.nativeElement.style.borderTopColor).toBe('rgb(128, 0, 128)');
    expect(spinnerEl.nativeElement.style.borderRightColor).toBe('rgb(128, 0, 128)');
  });

  it('should change diameter', () => {
    component.diameter = '10em';
    fixture.detectChanges();
    expect(spinnerEl.nativeElement.style.width).toBe('10em');
    expect(spinnerEl.nativeElement.style.height).toBe('10em');
  });

  it('should change stroke', () => {
    component.strokeWidth = '1px';
    fixture.detectChanges();
    expect(spinnerEl.nativeElement.style.borderWidth).toBe('1px');
  });

  it('should change speed', () => {
    component.speed = '0.1s';
    fixture.detectChanges();
    expect(spinnerEl.nativeElement.style.animationDuration).toBe('0.1s');
  });
*/
});
