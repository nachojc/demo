import { Component, OnInit, Input } from '@angular/core';

@Component({
	selector: 'sn-spinner, sn-loader',
	templateUrl: 'spinner.component.html',
	styleUrls: ['./spinner.component.scss']
})
export class SpinnerComponent implements OnInit {
	constructor() {}

	@Input()
	public type = '';

	@Input()
	public inverse: boolean;

	ngOnInit() {
		this.inverse = this.inverse !== undefined;
	}
}
