import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-range',
	templateUrl: './range.component.html',
	styleUrls: ['./range.component.css']
})
export class RangeComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
