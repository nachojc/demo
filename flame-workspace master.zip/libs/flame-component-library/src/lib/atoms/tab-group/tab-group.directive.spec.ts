import { Component, ViewChild } from '@angular/core';
import { TestBed, async } from '@angular/core/testing';

import { SnTabDirective } from './tab.directive';
import { SnTabGroupDirective } from './tab-group.directive';

@Component({
	selector: 'sn-tab-group-test',
	template: `
		<div>
			<ul snTabGroup>
				<li snTab></li>
				<li snTab id="secondTab"></li>
				<li snTab></li>
				<li snTab></li>
			</ul>
		</div>
	`
})
class TabGroupTestComponent {
	@ViewChild(SnTabGroupDirective) tabGroup: SnTabGroupDirective;
}

describe('TabGroupDirective', () => {
	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [SnTabGroupDirective, SnTabDirective, TabGroupTestComponent]
		}).compileComponents();
	}));

	it('Debe instanciarse correctamente', () => {
		const fixture = TestBed.createComponent(TabGroupTestComponent);
		expect(fixture.componentInstance.tabGroup).toBeDefined();
	});

	it('Debe recoger los tabs correctamente', () => {
		const fixture = TestBed.createComponent(TabGroupTestComponent);
		fixture.detectChanges();
		expect(fixture.componentInstance.tabGroup.tabs.length).toEqual(4);
	});

	// it('Debe poder recuperar un tab por posicion', () => {
	//   const fixture = TestBed.createComponent(TabGroupTestComponent);
	//   fixture.detectChanges();

	//   expect(fixture.componentInstance.tabGroup.get(1).id).toEqual('secondTab');
	// });

	// it('Debe poder recuperar un tab por identificador', () => {
	//   const fixture = TestBed.createComponent(TabGroupTestComponent);
	//   fixture.detectChanges();

	//   expect(fixture.componentInstance.tabGroup.get('secondTab').id).toEqual('secondTab');
	// });

	// it('Debe devolver undefined si no encuentra el tab', () => {
	//   const fixture = TestBed.createComponent(TabGroupTestComponent);
	//   fixture.detectChanges();

	//   expect(fixture.componentInstance.tabGroup.get('testTab')).toBeUndefined();
	// });
});
