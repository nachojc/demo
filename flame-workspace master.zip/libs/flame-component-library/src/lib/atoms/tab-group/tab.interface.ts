export interface Tab {
	id: string;
	activated: boolean;
	disabled: boolean;
}
