import {
	AfterViewInit,
	ContentChildren,
	Directive,
	QueryList,
	ChangeDetectorRef,
	Renderer2,
	ElementRef
} from '@angular/core';
import { AnimationBuilder, style, animate } from '@angular/animations';
import { SnTabDirective } from './tab.directive';
import { Tab } from './tab.interface';

@Directive({
	selector: '[snTabGroup]',
	exportAs: 'SnTabGroupDirective'
})
export class SnTabGroupDirective implements AfterViewInit {
	@ContentChildren(SnTabDirective) tabs: QueryList<SnTabDirective>;
	constructor(
		private _changeDetection: ChangeDetectorRef,
		private renderer: Renderer2,
		public eRef: ElementRef,
		private _animations: AnimationBuilder
	) {}
	ngAfterViewInit() {
		this.tabs.forEach((tab: SnTabDirective) => {
			tab.onActivate.subscribe(this._onTabActivation.bind(this));
		});
		this._changeDetection.detectChanges();
		this.generateTabs();
	}
	generateTabs() {
		let tabsSelection: any;
		const containerStyles = {
			display: 'block',
			width: '100%',
			height: '80px'
		};
		const tabsContainerStyle = {
			width: '100%',
			display: 'flex',
			'justify-content': 'space-evenly',
			'align-items': 'center'
		};
		const activeMarkerContainerStyle = {
			width: '100%',
			height: '10px'
		};
		const activeMarkerStyle = {
			display: 'block',
			width: 100 / this.tabs.length + '%',
			height: '10px',
			background: 'red',
			'border-radius': '8px'
		};
		const container = this.renderer.createElement('div');
		const activeMarkerContainer = this.renderer.createElement('div');
		const tabsContainer = this.renderer.createElement('div');
		const activeMarker = this.renderer.createElement('div');
		this.styleSetter(container, containerStyles);
		this.styleSetter(tabsContainer, tabsContainerStyle);
		this.styleSetter(activeMarkerContainer, activeMarkerContainerStyle);
		this.styleSetter(activeMarker, activeMarkerStyle);
		this.renderer.addClass(activeMarker, 'marker');
		this.tabs.forEach((tab, i) => {
			tabsSelection = this.renderer.createElement('div');
			this.renderer.setStyle(
				tabsSelection,
				'width',
				100 / this.tabs.length + '%'
			);
			this.renderer.setStyle(tabsSelection, 'text-align', 'center');
			const name = this.renderer.createText(tab.id);
			this.renderer.appendChild(tabsSelection, name);
			this.renderer.appendChild(tabsContainer, tabsSelection);
			this.renderer.listen(tabsSelection, 'click', e =>
				this.setActiveTab(e.target)
			);
		});
		this.renderer.appendChild(activeMarkerContainer, activeMarker);
		this.renderer.appendChild(container, tabsContainer);
		this.renderer.appendChild(container, activeMarkerContainer);
		// @append to the end
		// this.eRef.nativeElement.appendChild(container);
		// @append to the top
		this.renderer.insertBefore(
			this.eRef.nativeElement,
			container,
			this.eRef.nativeElement.firstChild
		);
	}
	moveMarker() {
		const element = this.eRef.nativeElement.querySelectorAll('.marker');
		const movement = this._animations.build([
			animate(
				'400ms ease-in-out',
				style({
					'margin-left':
						(100 / this.tabs.length + 2) * this.getActivatedTabIndex() + '%'
				})
			),
			animate(
				'80ms ease-in-out',
				style({
					'margin-left':
						(100 / this.tabs.length - 1) * this.getActivatedTabIndex() + '%'
				})
			),
			animate(
				'80ms ease-in-out',
				style({
					'margin-left':
						(100 / this.tabs.length) * this.getActivatedTabIndex() + '%'
				})
			)
		]);
		const player = movement.create(element[0]);
		player.play();
	}
	styleSetter(element: any, properties: object) {
		for (const key in properties) {
			if (properties.hasOwnProperty(key)) {
				this.renderer.setStyle(element, key, properties[key]);
			}
		}
	}
	setActiveTab(id: Element) {
		const text = id.innerHTML.toString();
		const tab = this.tabs.find((item: SnTabDirective) => item.id === text);
		const list = this.tabs.toArray();
		tab.activate();
		this.moveMarker();
	}
	getActivatedTabIndex(): number {
		if (this.tabs && this.tabs.length > 0) {
			return this.tabs
				.toArray()
				.findIndex((tab: SnTabDirective) => tab.activated);
		} else {
			return -1;
		}
	}
	private _onTabActivation(activatedTab: Tab) {
		this.tabs
			.filter((tab: SnTabDirective) => tab.id !== activatedTab.id)
			.forEach((tab: SnTabDirective) => tab.deactivate());
	}
}
