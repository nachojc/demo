import { SnTabDirective } from './tab.directive';

describe('TabDirective', () => {
	let instance: SnTabDirective;

	beforeEach(() => {
		instance = new SnTabDirective();
	});

	it('Debe tener los valores por defecto', () => {
		expect(instance.activated).toBe(false);
		expect(instance.disabled).toBe(false);
	});

	it('Debe poder ser activado y desactivado', () => {
		instance.activate();
		expect(instance.activated).toBe(true);
		instance.deactivate();
		expect(instance.activated).toBe(false);
	});

	it('Debe poder ser habilitado y deshabilitado', () => {
		instance.enable();
		expect(instance.disabled).toBe(true);
		instance.disable();
		expect(instance.disabled).toBe(false);
	});
});
