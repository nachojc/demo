import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChipComponent } from './chip.component';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

describe('ChipComponent', () => {
	let component: ChipComponent;
	let fixture: ComponentFixture<ChipComponent>;
	let chipEl: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [ChipComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(ChipComponent);
		component = fixture.componentInstance;
		chipEl = fixture.debugElement.query(By.css('#chip'));
	});

	it('Should create a chip', () => {
		expect(component).toBeTruthy();
	});

	it('should detonated click', () => {
		component.onClickChip();
		fixture.detectChanges();
		expect(chipEl.nativeElement.click());
	});

	it('should apply class default', () => {
		component.class = 'default';
		fixture.detectChanges();
		expect(chipEl.nativeElement.classList.contains('default')).toBe(true);
	});

	it('should apply class active', () => {
		component.class = 'active';
		fixture.detectChanges();
		expect(chipEl.nativeElement.classList.contains('active')).toBe(true);
	});

	it('should apply class medium', () => {
		component.class = 'medium';
		fixture.detectChanges();
		expect(chipEl.nativeElement.classList.contains('medium')).toBe(true);
	});

	it('should apply class high', () => {
		component.class = 'high';
		fixture.detectChanges();
		expect(chipEl.nativeElement.classList.contains('high')).toBe(true);
	});
});
