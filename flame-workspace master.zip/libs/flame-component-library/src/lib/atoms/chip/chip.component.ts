import {
	Component,
	OnInit,
	Input,
	ViewEncapsulation,
	Output,
	EventEmitter
} from '@angular/core';

export class EventChips {
	source: ChipComponent;
	num: number;
}

@Component({
	selector: 'sn-chip',
	templateUrl: './chip.component.html',
	styleUrls: ['./chip.component.scss'],
	encapsulation: ViewEncapsulation.Emulated
})
export class ChipComponent implements OnInit {
	private _typeClassChip = 'default';
	private _newClassTypeChip: string;
	private _idChip: number;

	@Output() readonly clickChip: EventEmitter<EventChips> = new EventEmitter<
		EventChips
	>();
	@Input() class: string = this._typeClassChip;
	@Input()
	set id(value: number) {
		this._idChip = value;
	}

	constructor() {}

	public get newClassTypeChip(): string {
		return this._newClassTypeChip;
	}
	public set newClassTypeChip(value: string) {
		this._newClassTypeChip = value;
	}

	public onClickChip(): void {
		const eventClass: EventChips = new EventChips();
		eventClass.source = this;
		eventClass.num = this._idChip;
		this.clickChip.emit(eventClass);
	}

	ngOnInit() {
		this.newClassTypeChip = this.class;
	}
}
