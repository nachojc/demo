import {
	Directive,
	Input,
	Output,
	EventEmitter,
	AfterContentInit,
	ChangeDetectorRef,
	forwardRef
} from '@angular/core';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
import { RadioButton, SnRadioChange } from './radio-button.interface';

let nextUniqueId = 0;

@Directive({
	selector: 'sn-radio-group',
	exportAs: 'snRadioGroup',
	host: {
		role: 'radiogroup',
		class: 'sn-radio-group'
	},
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => RadioGroupDirective),
			multi: true
		}
	]
})
export class RadioGroupDirective
	implements AfterContentInit, ControlValueAccessor {
	constructor(private _changeDetector: ChangeDetectorRef) {}

	private _required = false;
	private _id: string;
	private _uid = `sn-radio-group-${nextUniqueId++}`;
	private _name: any;
	private _selected = null;
	private _value: any;
	private _disabled = false;
	private _isInitialized = false;
	private radios: RadioButton[] = [];

	// @Input() panelClass: string | string[] | Set<string> | { [key: string]: any };

	/**  */
	@Input()
	get name(): any {
		return this._name;
	}
	set name(value: any) {
		this._name = value;
		this._updateRadioButtonNames();
	}

	/** Unique id of the element. */
	@Input()
	get id(): string {
		return this._id;
	}
	set id(value: string) {
		this._id = value || this._uid;
	}

	/** Value of the actual radio button selected in the group. */
	@Input()
	get value(): any {
		return this._value;
	}
	set value(newValue: any) {
		if (newValue !== this._value) {
			this._value = newValue;
			this._updateSelectedRadioFromValue();
			this._checkSelectedRadioButton();
		}
	}

	/**  */
	@Input()
	get selected(): RadioButton {
		return this._selected;
	}
	set selected(selected: RadioButton) {
		this._selected = selected;
		this.value = selected ? selected.value : null;
		this._checkSelectedRadioButton();
	}

	/** */
	@Input()
	get disabled(): boolean {
		return this._disabled;
	}
	set disabled(value: boolean) {
		this._disabled = coerceBooleanProperty(value);
		this._markRadiosForCheck();
	}

	/** */
	@Input()
	get required(): boolean {
		return this._required;
	}
	set required(value: boolean) {
		this._required = coerceBooleanProperty(value);
		this._markRadiosForCheck();
	}

	@Output() readonly change: EventEmitter<SnRadioChange> = new EventEmitter<
		SnRadioChange
	>();

	public _controlValueAccessorChangeFn = (value: any) => {};
	public onTouched = () => {};

	/**
	 * Sets the radio value. Part of the ControlValueAccessor interface
	 * required to integrate with Angular's core forms API.
	 *
	 * @param value New value to be written to the model.
	 */

	writeValue(value: any): void {
		this.value = value;
		this._changeDetector.markForCheck();
	}

	/** */
	registerOnTouched(func: any): void {
		this.onTouched = func;
	}

	ngAfterContentInit(): void {
		this._isInitialized = true;
	}

	/**
	 * Sets the disabled state of the control. Implemented as a part of ControlValueAccessor.
	 * @param isDisabled Whether the control should be disabled.
	 */
	setDisabledState(isDisabled: boolean): void {
		this.disabled = isDisabled;
		this._changeDetector.markForCheck();
	}

	/** */
	registerOnChange(func: any): void {
		this._controlValueAccessorChangeFn = func;
	}

	/** */
	_checkSelectedRadioButton(): void {
		if (this._selected && !this._selected.checked) {
			this._selected.checked = true;
		}
	}
	/** */
	_markRadiosForCheck(): void {
		if (this.radios) {
			this.radios.forEach((radio: RadioButton) => radio._markForCheck());
		}
	}

	/**  */
	_updateRadioButtonNames(): void {
		if (this.radios) {
			this.radios.forEach((radio: RadioButton) => (radio.name = this.name));
		}
	}
	/** Updates the selected radio from it's value  */
	_updateSelectedRadioFromValue(): void {
		if (
			this.radios &&
			this._selected !== null &&
			this._selected.value === this._value
		) {
			this._selected = null;
			this.radios.forEach((radio: RadioButton) => {
				radio.checked = this.value === radio.value;
				if (radio.checked) {
					this._selected = radio;
				}
			});
		}
	}

	/** */
	_touch(): void {
		if (this.onTouched) {
			this.onTouched();
		}
	}

	/** */
	_emitChangeEvent(): void {
		if (this._isInitialized) {
			this.change.emit(new SnRadioChange(this._selected, this._value));
		}
	}

	addRadio(radio: RadioButton) {
		this.radios.push(radio);
	}
}
