import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'sn-tabs',
	templateUrl: './tabs.component.html',
	styleUrls: ['./tabs.component.css']
})
export class TabsComponent implements OnInit {
	constructor() {}

	ngOnInit() {}
}
