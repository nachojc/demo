import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AvatarComponent } from './avatar.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('Test AvatarComponent', () => {
	let component: AvatarComponent;
	let fixture: ComponentFixture<AvatarComponent>;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [AvatarComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(AvatarComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
	});

	it('no tiene imagen de perfil', () => {
		expect(component.have_imageavatar).toBe(false);
	});

	it('tiene imagen de perfil', () => {
		component.imgsrc = 'https://goo.gl/rJfXfS';
		expect(component.have_imageavatar).toBeTruthy();
		expect(component.imgsrc).toBe('https://goo.gl/rJfXfS');
	});

	it('tipo de avatar no definido', () => {
		expect(component.typeavatar).toBe(0);
	});

	it('tipo de avatar mayor a 4', () => {
		component.typeavatar = 5;
		expect(component.typeavatar).toBe(5);
	});

	it('tipo de avatar menor que 0', () => {
		component.typeavatar = -1;
		expect(component.typeavatar).toBe(0);
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('testeando el nombre', () => {
		component.fullname = 'Alan Mathison Turing';
		expect(component.fullname).toBe('Alan Mathison Turing');
		expect(component.render_name).toBe('Alan');
		expect(component.render_lastname).toBe('Mathison');
		expect(component.render_namewithoutavatar).toBe('AM');
	});

	it('testeando click en el avatar', () => {
		// const button = fixture.debugElement.nativeElement.querySelector('.without-avatar');
		fixture.detectChanges();
		const element: DebugElement = fixture.debugElement;
		const buttonDe = element.query(By.css('.without-avatar'));
		const button: HTMLElement = buttonDe.nativeElement;
		button.click();
		fixture.detectChanges();
		console.log(button.classList);
		expect(button.classList).toContain('selected');
	});
});
