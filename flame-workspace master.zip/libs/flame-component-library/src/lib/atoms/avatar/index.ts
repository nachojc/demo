export * from './avatar.module';
