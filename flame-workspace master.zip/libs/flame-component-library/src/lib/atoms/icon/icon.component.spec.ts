import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IconComponent } from './icon.component';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';

describe('IconComponent', () => {
	let component: IconComponent;
	let fixture: ComponentFixture<IconComponent>;
	let iconEl: HTMLElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [IconComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(IconComponent);
		component = fixture.componentInstance;
		fixture.detectChanges();
		iconEl = fixture.debugElement.query(By.css('i')).nativeElement;
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should icon', () => {
		component.icon = 'sn-buscar';
		expect(component.icon).toBe('sn-buscar');
	});
	it('should show icon', () => {
		component.icon = 'sn-buscar';
		fixture.detectChanges();
		expect(iconEl.classList).toContain('sn-buscar');
	});
});
