import { Component, Input, OnInit } from '@angular/core';

@Component({
	selector: 'sn-progress-bar',
	templateUrl: './progress-bar.component.html',
	styleUrls: ['./progress-bar.component.scss']
})
export class ProgressBarComponent implements OnInit {
	constructor() {}

	private _value = '0';
	public percentage = 100;

	@Input()
	indeterminate: boolean;

	@Input()
	get value(): string {
		return this._value;
	}
	set value(value: string) {
		if (value !== this._value && !this.indeterminate) {
			this._value = value;
			if (Number(this._value) < 1 && Number(this._value) > 0) {
				this.percentage = Number(this._value) * 100;
			} else if (Number(this._value) < 100) {
				this.percentage = Number(this._value);
			}
		}
	}

	ngOnInit() {
		this.indeterminate = this.indeterminate !== undefined;
	}
}
