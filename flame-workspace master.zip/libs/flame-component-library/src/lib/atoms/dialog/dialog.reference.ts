import { OverlayRef } from '@angular/cdk/overlay';
import { Subject, Observable } from 'rxjs';
import { filter, take } from 'rxjs/operators';
import { DialogComponent } from '../dialog/dialog.component';

export class DialogReference {
	private _beforeClose = new Subject<boolean>();
	private _afterClosed = new Subject<void>();

	componentInstance: DialogComponent;

	constructor(private overlay: OverlayRef) {}

	close(cancel?: boolean): void {
		this.componentInstance.animationStateChanged
			.pipe(
				filter((event: any) => event.phaseName === 'start'),
				take(1)
			)
			.subscribe(() => {
				this._beforeClose.next(cancel || null);
				this._beforeClose.complete();
				this.overlay.detachBackdrop();
			});

		this.componentInstance.animationStateChanged
			.pipe(
				filter(
					(event: any) =>
						event.phaseName === 'done' && event.toState === 'leave'
				),
				take(1)
			)
			.subscribe(() => {
				this.overlay.dispose();
				this._afterClosed.next();
				this._afterClosed.complete();
				this.componentInstance = null;
			});

		// Start exit animation
		this.componentInstance.startExitAnimation();
	}

	afterClosed(): Observable<void> {
		return this._afterClosed.asObservable();
	}

	beforeClose(): Observable<boolean> {
		return this._beforeClose.asObservable();
	}

	changeStatusButton(status: boolean): void {
		this.componentInstance.disabledButton = status;
	}
}
