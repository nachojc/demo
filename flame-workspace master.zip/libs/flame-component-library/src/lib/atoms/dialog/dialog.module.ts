import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OverlayModule as OverlayModuleCDK } from '@angular/cdk/overlay';
import { DialogComponent } from './dialog.component';
import { DialogService } from '../dialog/dialog.service';
import { DialogDirective } from '../dialog/dialog-custom';
import { ButtonModule } from '../button/button.module';
import { OverlayService } from '../../services/overlay/overlay.service';

@NgModule({
	imports: [CommonModule, ButtonModule, OverlayModuleCDK],
	declarations: [DialogComponent, DialogDirective],
	providers: [DialogService, OverlayService],
	entryComponents: [DialogComponent]
})
export class DialogModule {}
