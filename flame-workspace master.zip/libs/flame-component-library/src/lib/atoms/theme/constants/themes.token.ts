import { InjectionToken } from '@angular/core';

export const THEMES = new InjectionToken('THEMES');
