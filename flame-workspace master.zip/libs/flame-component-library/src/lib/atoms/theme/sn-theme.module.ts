import { NgModule, ModuleWithProviders, InjectionToken } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ThemeService } from './sn-theme.service';
import { ThemeDirective } from './sn-theme.directive';
import { THEMES, ACTIVE_THEME } from './constants/index';
import { ThemeOptions } from './interfaces/theme-option.interface';

@NgModule({
	imports: [CommonModule],
	providers: [ThemeService],
	declarations: [ThemeDirective],
	exports: [ThemeDirective]
})
export class ThemeModule {
	public static forRoot(options: ThemeOptions): ModuleWithProviders {
		return {
			ngModule: ThemeModule,
			providers: [
				{
					provide: THEMES,
					useValue: options.themes
				},
				{
					provide: ACTIVE_THEME,
					useValue: options.active
				}
			]
		};
	}
}
