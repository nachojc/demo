export interface Theme {
	name: string;
	properties: any;
}
