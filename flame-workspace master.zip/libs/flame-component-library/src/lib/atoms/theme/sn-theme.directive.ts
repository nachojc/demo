import { Directive, OnInit, OnDestroy, ElementRef, Input } from '@angular/core';
import { ThemeService } from './sn-theme.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Theme } from './interfaces/theme.interface';

@Directive({
	selector: '[snTheme]'
})
export class ThemeDirective implements OnInit, OnDestroy {
	private _destroy$ = new Subject();
	@Input('snTheme') theme = 'flame-foundation';
	@Input() global = true;
	constructor(
		private _elementRef: ElementRef,
		private _themeService: ThemeService
	) {}

	ngOnInit() {
		this._themeService.themeChange
			.pipe(takeUntil(this._destroy$))
			.subscribe((theme: Theme) => this.updateTheme(theme));
		this._themeService.setTheme(this.theme);
	}

	ngOnDestroy() {
		this._destroy$.next();
		this._destroy$.complete();
	}

	updateTheme(theme: Theme) {
		const ele = this.global ? document.body : this._elementRef.nativeElement;
		for (const key in theme.properties) {
			if (theme.properties.hasOwnProperty(key)) {
				ele.style.setProperty(key, theme.properties[key]);
			}
		}
		for (const name of this._themeService.theme) {
			ele.classList.remove(`${name}-theme`);
		}
		ele.classList.add(`${theme.name}-theme`);
	}
}
