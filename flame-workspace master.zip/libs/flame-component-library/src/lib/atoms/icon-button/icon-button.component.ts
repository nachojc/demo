import { Component, Input, Output, EventEmitter } from '@angular/core';
@Component({
	selector: 'sn-icon-button',
	templateUrl: './icon-button.component.html',
	styleUrls: ['./icon-button.component.scss']
})
export class IconButtonComponent {
	@Input() title: string;
	@Input() icon: string;
	@Input() size = 'sm';
	@Input() invert_theme: string;
	@Output() onSelection = new EventEmitter();
	constructor() {}
	selectElement(element: string) {
		this.onSelection.emit(element);
	}
}
