import { NgModule } from '@angular/core';
import { IconButtonComponent } from './icon-button.component';
import { IconModule } from '../icon/icon.module';
import { CommonModule } from '@angular/common';

@NgModule({
	imports: [CommonModule, IconModule],
	declarations: [IconButtonComponent],
	exports: [IconButtonComponent]
})
export class IconButtonModule {}
