import { AccordionModule } from './accordion/accordion.module';
import { AvatarModule } from './avatar/avatar.module';
import { ButtonModule } from './button/button.module';
import { CarouselModule } from './carousel/carousel.module';
import { CheckboxModule } from './checkbox/checkbox.module';
import { ChipModule } from './chip/chip.module';
import { DateTimePickerModule } from './date-time-picker/date-time-picker.module';
import { FormFieldModule } from './form-field/form-field.module';
import { IconButtonModule } from './icon-button/icon-button.module';
import { IconModule } from './icon/icon.module';
import { InputModule } from './input/input.module';
import { ProgressBarModule } from './progress-bar/progress-bar.module';
import { RadioButtonModule } from './radio-button/radio-button.module';
import { RangeModule } from './range/range.module';
import { SlideButtonModule } from './slide-button/slide-button.module';
import { SliderModule } from './slider/slider.module';
import { SlideToggleModule } from './slide-toggle/slide-toggle.module';
import { SpinnerModule } from './spinner/spinner.module';
import { StepGroupModule } from './step-group/step-group.module';
import { TabGroupModule } from './tab-group/tab-group.module';
import { TabsModule } from './tabs/tabs.module';
import { TextareaModule } from './textarea/textarea.module';
import { TooltipModule } from './tooltip/tooltip.module';

export const ATOMS_COMPONENTS = [
	AccordionModule,
	AvatarModule,
	ButtonModule,
	CarouselModule,
	CheckboxModule,
	ChipModule,
	DateTimePickerModule,
	FormFieldModule,
	IconButtonModule,
	IconModule,
	InputModule,
	ProgressBarModule,
	RadioButtonModule,
	RangeModule,
	SlideButtonModule,
	SliderModule,
	SlideToggleModule,
	SpinnerModule,
	StepGroupModule,
	TabGroupModule,
	TabsModule,
	TextareaModule,
	TooltipModule
];
