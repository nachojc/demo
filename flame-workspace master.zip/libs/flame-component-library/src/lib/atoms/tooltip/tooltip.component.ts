import {
	Component,
	ChangeDetectorRef,
	ChangeDetectionStrategy,
	ViewEncapsulation
} from '@angular/core';

@Component({
	selector: 'sn-tooltip',
	templateUrl: './tooltip.component.html',
	styleUrls: ['./tooltip.component.scss'],
	changeDetection: ChangeDetectionStrategy.OnPush,
	encapsulation: ViewEncapsulation.None
})
export class TooltipComponent {
	message: string;
	visibility = false;

	tooltipClass: string | string[] | Set<string> | { [key: string]: any };

	constructor(private _changeDetectorRef: ChangeDetectorRef) {}

	show(delay: number) {
		setTimeout(() => {
			this.visibility = true;
			this.markForCheck();
		}, delay);
	}

	hide(delay: number) {
		return new Promise(resolve => {
			setTimeout(() => {
				resolve();
			}, delay);
		});
	}

	toggle(delay: number) {
		setTimeout(() => {
			this.visibility = !this.visibility;
			this.markForCheck();
		}, delay);
	}

	public markForCheck(): void {
		this._changeDetectorRef.markForCheck();
	}
}
