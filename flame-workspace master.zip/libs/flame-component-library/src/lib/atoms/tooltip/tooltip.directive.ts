import {
	Directive,
	Input,
	ElementRef,
	ViewContainerRef,
	Optional,
	HostListener,
	InjectionToken,
	Inject,
	OnDestroy
} from '@angular/core';
import { ComponentPortal } from '@angular/cdk/portal';
import {
	FlexibleConnectedPositionStrategy,
	HorizontalConnectionPos,
	OriginConnectionPosition,
	Overlay,
	OverlayConnectionPosition,
	OverlayRef,
	VerticalConnectionPos,
	ScrollStrategy,
	ScrollDispatcher
} from '@angular/cdk/overlay';
import { Directionality } from '@angular/cdk/bidi';
import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { TooltipComponent } from './tooltip.component';

export const TOOLTIP_PANEL_CLASS = 'sn-tooltip-panel';

export const SCROLL_THROTTLE_MS = 20;

export const SN_TOOLTIP_SCROLL_STRATEGY = new InjectionToken<
	() => ScrollStrategy
>('sn-tooltip-scroll-strategy');

export function SN_TOOLTIP_SCROLL_STRATEGY_FACTORY(
	overlay: Overlay
): () => ScrollStrategy {
	return () =>
		overlay.scrollStrategies.reposition({ scrollThrottle: SCROLL_THROTTLE_MS });
}

export const SN_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER = {
	provide: SN_TOOLTIP_SCROLL_STRATEGY,
	deps: [Overlay],
	useFactory: SN_TOOLTIP_SCROLL_STRATEGY_FACTORY
};

@Directive({
	selector: '[snTooltip], [sn-tooltip]',
	exportAs: 'SnTooltipDirective'
})
export class SnTooltipDirective implements OnDestroy {
	private _tooltipInstance: TooltipComponent | null;
	private _overlayRef: OverlayRef | null;

	private _portal: ComponentPortal<TooltipComponent>;
	private _position = 'below';
	private _disabled = false;
	private _message = '';
	private _showDelay = 0;
	private _hideDelay = 0;
	private _tooltipClass:
		| string
		| string[]
		| Set<string>
		| { [key: string]: any };
	private _scrollStrategy: () => ScrollStrategy;

	constructor(
		private _overlay: Overlay,
		private _elementRef: ElementRef<HTMLElement>,
		private _scrollDispatcher: ScrollDispatcher,
		private _viewContainerRef: ViewContainerRef,
		@Optional() private _dir: Directionality,
		@Inject(SN_TOOLTIP_SCROLL_STRATEGY) scrollStrategy
	) {
		this._scrollStrategy = scrollStrategy;
	}

	@Input('snTooltip')
	get message() {
		return this._message;
	}
	set message(value: string) {
		this._message = value != null ? `${value}`.trim() : '';
	}

	@Input('snTooltipPosition')
	get position(): string {
		return this._position;
	}
	set position(value: string) {
		if (value !== this._position) {
			this._position = value;
			if (this._overlayRef) {
				this._updatePosition();

				if (this._tooltipInstance) {
					this._tooltipInstance.show(0);
				}
				this._overlayRef.updatePosition();
			}
		}
	}

	@Input('snTooltipDisabled')
	get disabled(): boolean {
		return this._disabled;
	}
	set disabled(value) {
		this._disabled = coerceBooleanProperty(value);
		if (this._disabled) {
			this.hide(0);
		}
	}

	@Input('snTooltipHideDelay')
	get hideDelay(): number {
		return this._hideDelay;
	}
	set hideDelay(value) {
		this._hideDelay = value;
	}

	@Input('snTooltipShowDelay')
	get showDelay(): number {
		return this._showDelay;
	}
	set showDelay(value) {
		this._showDelay = value;
	}

	// TODO: Resolve the bug using the input snTooltipClass. The class is not being applied.
	@Input('snTooltipClass')
	get tooltipClass() {
		return this._tooltipClass;
	}
	set tooltipClass(
		value: string | string[] | Set<string> | { [key: string]: any }
	) {
		this._tooltipClass = value;
		if (this._tooltipInstance) {
			this._setTooltipClass(this._tooltipClass);
		}
	}

	@HostListener('mouseenter')
	mouseenter() {
		if (!this._disabled) {
			this.show(this._showDelay);
		}
	}

	@HostListener('mouseout')
	mouseout() {
		this.hide(this._hideDelay);
	}

	public hide(delay: number) {
		if (this._tooltipInstance) {
			this._tooltipInstance.hide(delay).then(() => {
				this._overlayRef.detach();
				this._tooltipInstance = null;
			});
		}
	}

	public toggle() {
		if (this._tooltipInstance) {
			this.hide(0);
		} else {
			this.show(0);
		}
	}

	public show(delay: number): void {
		if (this._tooltipInstance) {
			this._tooltipInstance
				.hide(0)
				.then(a => {
					this._overlayRef.detach();
					this._tooltipInstance = null;
				})
				.then(() => {
					this._createOverlay();
					this._tooltipInstance.show(delay);
				});
		} else {
			this._createOverlay();
			this._tooltipInstance.show(this._showDelay);
		}
	}

	private _createOverlay(): OverlayRef {
		const strategy = this._overlay
			.position()
			.flexibleConnectedTo(this._elementRef.nativeElement)
			.withTransformOriginOn('.sn-tooltip')
			.withFlexibleDimensions(false)
			.withViewportMargin(8);

		const scrollableAncestors = this._scrollDispatcher.getAncestorScrollContainers(
			this._elementRef
		);

		strategy.withScrollableContainers(scrollableAncestors);

		this._overlayRef = this._overlay.create({
			direction: this._dir,
			positionStrategy: strategy,
			panelClass: TOOLTIP_PANEL_CLASS,
			scrollStrategy: this._scrollStrategy()
		});

		this._updatePosition();

		this._portal =
			this._portal ||
			new ComponentPortal(TooltipComponent, this._viewContainerRef);

		this._tooltipInstance = this._overlayRef.attach(this._portal).instance;
		this._setTooltipClass(this._tooltipClass);
		this._updateTooltipMessage();

		return this._overlayRef;
	}

	private _updateTooltipMessage() {
		this._tooltipInstance.message = this._message;
		this._tooltipInstance.markForCheck();
	}

	private _setTooltipClass(
		tooltipClass: string | string[] | Set<string> | { [key: string]: any }
	) {
		if (this._tooltipInstance) {
			this._tooltipInstance.tooltipClass = tooltipClass;
			this._tooltipInstance.markForCheck();
		}
	}

	private _updatePosition() {
		const position = this._overlayRef.getConfig()
			.positionStrategy as FlexibleConnectedPositionStrategy;
		const origin = this._getOrigin();
		const overlay = this._getOverlayPosition();

		position.withPositions([
			{ ...origin.main, ...overlay.main },
			{ ...origin.fallback, ...overlay.fallback }
		]);
	}

	private _getOrigin(): {
		main: OriginConnectionPosition;
		fallback: OriginConnectionPosition;
	} {
		const isLtr = !this._dir || this._dir.value === 'ltr';
		const position = this._position;

		let originPosition: OriginConnectionPosition;

		if (position === 'above' || position === 'below') {
			originPosition = {
				originX: 'center',
				originY: position === 'above' ? 'top' : 'bottom'
			};
		} else if (
			position === 'before' ||
			(position === 'left' && isLtr) ||
			(position === 'right' && !isLtr)
		) {
			originPosition = { originX: 'start', originY: 'center' };
		} else if (
			position === 'after' ||
			(position === 'right' && isLtr) ||
			(position === 'left' && !isLtr)
		) {
			originPosition = { originX: 'end', originY: 'center' };
		}

		const { x, y } = this._invertPosition(
			originPosition.originX,
			originPosition.originY
		);

		return {
			main: originPosition,
			fallback: { originX: x, originY: y }
		};
	}

	private _getOverlayPosition(): {
		main: OverlayConnectionPosition;
		fallback: OverlayConnectionPosition;
	} {
		const isLtr = !this._dir || this._dir.value === 'ltr';
		const position = this._position;
		let overlayPosition: OverlayConnectionPosition;

		if (position === 'above') {
			overlayPosition = { overlayX: 'center', overlayY: 'bottom' };
		} else if (position === 'below') {
			overlayPosition = { overlayX: 'center', overlayY: 'top' };
		} else if (
			position === 'before' ||
			(position === 'left' && isLtr) ||
			(position === 'right' && !isLtr)
		) {
			overlayPosition = { overlayX: 'end', overlayY: 'center' };
		} else if (
			position === 'after' ||
			(position === 'right' && isLtr) ||
			(position === 'left' && !isLtr)
		) {
			overlayPosition = { overlayX: 'start', overlayY: 'center' };
		}

		const { x, y } = this._invertPosition(
			overlayPosition.overlayX,
			overlayPosition.overlayY
		);

		return {
			main: overlayPosition,
			fallback: { overlayX: x, overlayY: y }
		};
	}

	private _invertPosition(
		x: HorizontalConnectionPos,
		y: VerticalConnectionPos
	) {
		if (this._position === 'above' || this._position === 'below') {
			if (y === 'top') {
				y = 'bottom';
			} else if (y === 'bottom') {
				y = 'top';
			}
		} else {
			if (x === 'end') {
				x = 'start';
			} else if (x === 'start') {
				x = 'end';
			}
		}

		return { x, y };
	}

	ngOnDestroy() {
		if (this._overlayRef) {
			this._overlayRef.dispose();
			this._overlayRef.detach();
			this._tooltipInstance = null;
		}
	}
}
