import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';

import { CheckboxComponent } from './checkbox.component';

describe('CheckboxComponent', () => {
	let component: CheckboxComponent;
	let fixture: ComponentFixture<CheckboxComponent>;
	let checkboxNativeEl: DebugElement;

	beforeEach(async(() => {
		TestBed.configureTestingModule({
			declarations: [CheckboxComponent]
		}).compileComponents();
	}));

	beforeEach(() => {
		fixture = TestBed.createComponent(CheckboxComponent);
		component = fixture.componentInstance;
		checkboxNativeEl = fixture.debugElement.query(By.css('.sn-checkbox-input'));
	});

	it('should create', () => {
		expect(component).toBeTruthy();
	});

	it('should native input checked', () => {
		component.checked = true;
		fixture.detectChanges();
		expect(checkboxNativeEl.nativeElement.checked).toBeTruthy();
	});

	it('should native input unchecked', () => {
		component.checked = false;
		fixture.detectChanges();
		expect(checkboxNativeEl.nativeElement.checked).toBeFalsy();
	});
});
