import {
	Component,
	Input,
	ElementRef,
	EventEmitter,
	Output,
	ViewChild,
	ViewEncapsulation,
	forwardRef
} from '@angular/core';

import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

let nextUniqueId = 0;

export class SnCheckboxChange {
	source: CheckboxComponent;
	checked: boolean;
}

@Component({
	selector: 'sn-checkbox',
	templateUrl: './checkbox.component.html',
	styleUrls: ['./checkbox.component.scss'],
	host: {
		'[id]': 'id',
		class: 'sn-checkbox',
		'[class.sn-checkbox-checked]': 'checked',
		'[class.sn-checkbox-disabled]': 'disabled'
	},
	providers: [
		{
			provide: NG_VALUE_ACCESSOR,
			useExisting: forwardRef(() => CheckboxComponent),
			multi: true
		}
	],
	encapsulation: ViewEncapsulation.None
})
export class CheckboxComponent implements ControlValueAccessor {
	constructor(elementRef: ElementRef<HTMLElement>) {}

	private _uniqueId = `sn-checkbox-${++nextUniqueId}`;
	private _checked = false;
	private _required: boolean;
	private _disabled = false;

	@Input() id: string = this._uniqueId;
	get inputId(): string {
		return `${this.id || this._uniqueId}-input`;
	}

	@Input()
	get checked(): boolean {
		return this._checked;
	}
	set checked(value: boolean) {
		this._checked = value;
	}

	@Input()
	get required(): boolean {
		return this._required;
	}
	set required(value: boolean) {
		this._required = value;
	}

	@Input()
	get disabled() {
		return this._disabled;
	}
	set disabled(value: any) {
		this._disabled = value;
	}

	@Input() value: string;

	@Input() name: string | null = null;

	@Output() readonly change: EventEmitter<SnCheckboxChange> = new EventEmitter<
		SnCheckboxChange
	>();

	@ViewChild('input') _inputElement: ElementRef<HTMLInputElement>;

	private _controlValueAccessorChangeFn: (value: any) => void = () => {};

	private _emitChangeEvent() {
		const event = new SnCheckboxChange();
		event.source = this;
		event.checked = this.checked;

		this._controlValueAccessorChangeFn(this.checked);
		this.change.emit(event);
	}

	_onTouched: () => any = () => {};

	_onInputClick(event: Event) {
		event.stopPropagation();

		this.toggle();

		this._emitChangeEvent();
	}

	_onInteractionEvent(event: Event) {
		event.stopPropagation();
	}

	toggle(): void {
		this.checked = !this.checked;
	}

	writeValue(value: any) {
		this.checked = !!value;
	}

	registerOnChange(fn: (value: any) => void) {
		this._controlValueAccessorChangeFn = fn;
	}

	registerOnTouched(fn: any) {
		this._onTouched = fn;
	}

	setDisabledState(isDisabled: boolean) {
		this.disabled = isDisabled;
	}
}
