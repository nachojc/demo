import { SnStepDirective } from './step.directive';

describe('StepDirective', () => {
	let instance: SnStepDirective;

	beforeEach(() => {
		instance = new SnStepDirective();
	});

	it('Debe tener los valores por defecto', () => {
		expect(instance.activated).toBe(false);
		expect(instance.completed).toBe(false);
		expect(instance.disabled).toBe(false);
	});

	it('Debe poder ser completado y descompletado', () => {
		instance.complete();
		expect(instance.completed).toBe(true);
		instance.decomplete();
		expect(instance.completed).toBe(false);
	});

	it('Debe poder ser activado y desactivado', () => {
		instance.activate();
		expect(instance.activated).toBe(true);
		instance.deactivate();
		expect(instance.activated).toBe(false);
	});

	it('Debe poder ser habilitado y deshabilitado', () => {
		instance.enable();
		expect(instance.disabled).toBe(true);
		instance.disable();
		expect(instance.disabled).toBe(false);
	});
});
