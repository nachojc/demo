import { NgModule } from '@angular/core';
import { SnStepDirective } from './step.directive';
import { SnStepGroupDirective } from './step-group.directive';

@NgModule({
	imports: [],
	declarations: [SnStepGroupDirective, SnStepDirective],
	exports: [SnStepGroupDirective, SnStepDirective]
})
export class StepGroupModule {}
