import { Directive, Input, Output, EventEmitter } from '@angular/core';
import { Step } from './step.interface';

@Directive({
	selector: '[snStep]',
	exportAs: 'SnStepDirective'
})
export class SnStepDirective implements Step {
	@Input() id: string;
	private set _id(value: string) {
		this.id = value;
	}
	private get _id(): string {
		return this.id;
	}

	@Input() activated = false;
	private set _activated(value: boolean) {
		this.activated = value;
	}
	private get _activated(): boolean {
		return this.activated;
	}

	@Input() completed = false;
	private set _completed(value: boolean) {
		this.completed = value;
	}
	private get _completed(): boolean {
		return this.completed;
	}

	@Input() disabled = false;
	private set _disabled(value: boolean) {
		this.disabled = value;
	}
	private get _disabled(): boolean {
		return this.disabled;
	}

	@Output() onComplete = new EventEmitter<Step>();

	@Output() onDecomplete = new EventEmitter<Step>();

	@Output() onActivate = new EventEmitter<Step>();

	@Output() onDeactivate = new EventEmitter<Step>();

	@Output() onEnable = new EventEmitter<Step>();

	@Output() onDisable = new EventEmitter<Step>();

	complete(propagate = true) {
		this._completed = true;
		if (propagate) {
			this.onComplete.emit(this._toStep());
		}
	}

	decomplete(propagate = true) {
		this._completed = false;
		if (propagate) {
			this.onDecomplete.emit(this._toStep());
		}
	}

	activate(propagate = true) {
		this._activated = true;
		if (propagate) {
			this.onActivate.emit(this._toStep());
		}
	}

	deactivate(propagate = true) {
		this._activated = false;
		if (propagate) {
			this.onDeactivate.emit(this._toStep());
		}
	}

	enable(propagate = true) {
		this._disabled = true;
		if (propagate) {
			this.onEnable.emit(this._toStep());
		}
	}

	disable(propagate = true) {
		this._disabled = false;
		if (propagate) {
			this.onDisable.emit(this._toStep());
		}
	}

	private _toStep(): Step {
		return {
			id: this._id,
			activated: this._activated,
			completed: this._completed,
			disabled: this._disabled
		};
	}
}
