export interface Step {
	id: string;
	activated: boolean;
	completed: boolean;
	disabled: boolean;
}
