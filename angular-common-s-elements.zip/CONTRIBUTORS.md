## Angular Common S Elements

- **[Portland Team](https://uk-gitlab.almuk.santanderuk.corp/S0811746)**
  - SanTechDLPortlandDevelopment@santander.co.uk

- **[Spectrum Team](https://uk-gitlab.almuk.santanderuk.corp/S0811607)**
  - DLSpectrumDeliveryTeam@isbanuk.com

- **[Eforms Team](https://uk-gitlab.almuk.santanderuk.corp/S0501566)**
  - SanTechSanEformsEng@santander.co.uk
