export class PafItem {
  id: string;
  type: string;
  text: string;
  highlight: string;
  description: string;

  constructor(
              id: string,
              type: string,
              text: string,
              highlight: string,
              description: string) {
    this.id = id;
    this.type = type;
    this.text = text;
    this.highlight = highlight;
    this.description = description;
  }
}
