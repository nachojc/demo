export class PafAddressLookup {
    premise: string;
    primaryStreet: string;
    secondaryStreet: string;
    town: string;
    postcode: string;

    constructor(premise?: string, primaryStreet?: string, secondaryStreet?: string, town?: string, postcode?: string) {
        this.premise = premise;
        this.primaryStreet = primaryStreet;
        this.secondaryStreet = secondaryStreet;
        this.town = town;
        this.postcode = postcode;
    }
}
