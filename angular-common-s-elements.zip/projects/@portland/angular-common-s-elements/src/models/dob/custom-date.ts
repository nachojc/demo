export interface CustomDate {
    day: string;
    month: string;
    year: string;
}
