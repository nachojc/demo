export enum UploadStatus {
  Ready = 'READY',
  Uploading = 'UPLOADING',
  Error = 'ERROR',
  Invalid = 'INVALID',
  Completed = 'COMPLETED',
  Cancelled = 'CANCELLED'
}

export class UploadFile {
  id: string;
  nativefile: File;
  name: string;
  status: UploadStatus;
}

export class CustomUploadFile extends UploadFile {
  customFields: any;
}
