/* tslint:disable:max-line-length */
import { LabelDirective } from './label.directive';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NgControl, FormsModule, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { HelpLabelModel, OptionalLabelModel } from './label';
import { CheckboxComponent } from '../../components/checkbox/checkbox.component';

@Component({
  template: `
  <form>
    <input ngModel name="labeled" required label="This is the label">
    <input second-thing value="last child">
  </form>
  `
})
class TestSimpleRequiredLabelDirectiveComponent {
  labeled: string;
 }

describe('Label directive: required', () => {
  let fixture: ComponentFixture<TestSimpleRequiredLabelDirectiveComponent>;
  let element: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestSimpleRequiredLabelDirectiveComponent, LabelDirective],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    });
    fixture = TestBed.createComponent(TestSimpleRequiredLabelDirectiveComponent);
    element = fixture.debugElement.query(By.css('[label]'));
    fixture.detectChanges();
  });

  it('should display the right label value', () => {
    const labelContainer: DebugElement = element.parent;
    expect(labelContainer.name).toBe('label');
    expect(labelContainer.query(By.css('.s-label__default')).nativeElement.textContent).toEqual('This is the label');
  });

  it('should not modify the order of the template', () => {
    const form = fixture.debugElement.query(By.css('form'));
    expect(form.children[1].attributes['second-thing']).not.toBeUndefined();
  });

  it('should display the label box model in the correct order', () => {
    const labelContainer = fixture.debugElement.query(By.css('label'));

    expect(labelContainer.children.length).toEqual(2);
    expect(labelContainer.children[0].classes['s-label__default']).toBe(true);
    expect(labelContainer.children[1].name).toEqual('input');
  });
});

@Component({
  template: `
  <form>
    <input ngModel name="labeled" label="This is the label">
    <input second-thing value="last child">
  </form>
  `
})
class TestSimpleLabelDirectiveComponent {
  labeled: string;
 }

describe('Label directive: simple', () => {
  let fixture: ComponentFixture<TestSimpleLabelDirectiveComponent>;
  let element: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestSimpleLabelDirectiveComponent, LabelDirective],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    });
    fixture = TestBed.createComponent(TestSimpleLabelDirectiveComponent);
    element = fixture.debugElement.query(By.css('[label]'));
    fixture.detectChanges();
  });

  it('should display the right label value followed by (if applicable)', () => {
    const labelContainer: DebugElement = element.parent;
    expect(labelContainer.name).toBe('label');
    expect(labelContainer.query(By.css('.s-label__default')).nativeElement.textContent).toEqual('This is the label');
    expect(labelContainer.query(By.css('.s-label__optional')).nativeElement.textContent).toEqual(' (if applicable)');
  });

  it('should display the label box model in the correct order', () => {
    const labelContainer = fixture.debugElement.query(By.css('label'));

    expect(labelContainer.children.length).toEqual(3);
    expect(labelContainer.children[0].classes['s-label__default']).toBe(true);
    expect(labelContainer.children[1].classes['s-label__optional']).toBe(true);
    expect(labelContainer.children[2].name).toEqual('input');
  });

  it('should not modify the order of the template', () => {
    const form = fixture.debugElement.query(By.css('form'));
    expect(form.children[1].attributes['second-thing']).not.toBeUndefined();
  });
});

@Component({
  template: `
  <form>
    <input ngModel name="labeled" [label]="withHelpfulLabel">
    <input second-thing value="last child">
  </form>
  `
})
class TestHelpLabelDirectiveComponent {
  labeled: string;
  withHelpfulLabel: HelpLabelModel = {
    defaultValue: 'This is the label',
    help: 'Help value'
  };
}

describe('Label directive: help', () => {
  let fixture: ComponentFixture<TestHelpLabelDirectiveComponent>;
  let labelContainer: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestHelpLabelDirectiveComponent, LabelDirective],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    });
    fixture = TestBed.createComponent(TestHelpLabelDirectiveComponent);
    fixture.detectChanges();
    labelContainer = fixture.debugElement.query(By.css('label'));
  });

  it('should display help label if there is one', () => {
    expect(labelContainer.query(By.css('.s-label__help')).nativeElement.textContent).toEqual('Help value');
  });

  it('should display the label box model in the correct order', () => {
    expect(labelContainer.children.length).toBe(4);
    expect(labelContainer.children[0].classes['s-label__default']).toBe(true);
    expect(labelContainer.children[1].classes['s-label__optional']).toBe(true);
    expect(labelContainer.children[2].classes['s-label__help']).toBe(true);
    expect(labelContainer.children[3].name).toEqual('input');
  });

  it('should not modify the order of the template', () => {
    const form = fixture.debugElement.query(By.css('form'));
    expect(form.children[1].attributes['second-thing']).not.toBeUndefined();
  });
});


@Component({
  template: `
  <form>
    <input ngModel name="labeled" required [label]="withHelpfulLabel">
    <input second-thing value="last child">
  </form>
  `
})
class TestHelpRequiredLabelDirectiveComponent {
  labeled: string;
  withHelpfulLabel: HelpLabelModel = {
    defaultValue: 'This is the label',
    help: 'Help value'
  };
}

describe('Label directive: help', () => {
  let fixture: ComponentFixture<TestHelpRequiredLabelDirectiveComponent>;
  let labelContainer: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestHelpRequiredLabelDirectiveComponent, LabelDirective],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    });
    fixture = TestBed.createComponent(TestHelpRequiredLabelDirectiveComponent);
    fixture.detectChanges();
    labelContainer = fixture.debugElement.query(By.css('label'));
  });

  it('should display the label box model in the correct order', () => {
    expect(labelContainer.children.length).toBe(3);
    expect(labelContainer.children[0].classes['s-label__default']).toBe(true);
    expect(labelContainer.children[1].classes['s-label__help']).toBe(true);
    expect(labelContainer.children[2].name).toEqual('input');
  });
});

@Component({
  template: `
  <form>
    <input ngModel name="labeled" [label]="withHelpfulLabel">
    <input second-thing value="last child">
  </form>
  `
})
class TestOptionalLabelDirectiveComponent {
  labeled: string;
  withHelpfulLabel: OptionalLabelModel = {
    defaultValue: 'This is the label',
    optional: '(optional)'
  };
}

describe('Label directive: optional', () => {
  let fixture: ComponentFixture<TestOptionalLabelDirectiveComponent>;
  let labelContainer: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestOptionalLabelDirectiveComponent, LabelDirective],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    });
    fixture = TestBed.createComponent(TestOptionalLabelDirectiveComponent);
    fixture.detectChanges();
    labelContainer = fixture.debugElement.query(By.css('label'));
  });

  it('should display help label if there is one', () => {
    expect(labelContainer.query(By.css('.s-label__optional')).nativeElement.textContent).toEqual(' (optional)');
  });

  it('should display the label box model in the correct order', () => {
    expect(labelContainer.children.length).toBe(3);
    expect(labelContainer.children[0].classes['s-label__default']).toBe(true);
    expect(labelContainer.children[1].classes['s-label__optional']).toBe(true);
    expect(labelContainer.children[2].name).toEqual('input');
  });

});

@Component({
  selector: 's-multi-input',
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: TestMultipleInputsComponent, multi: true }
  ],
  template: `
  <div>
    <input>
    <input>
  </div>
  `
})
class TestMultipleInputsComponent implements ControlValueAccessor {
  writeValue(obj: any): void { }
  registerOnChange(fn: any): void { }
  registerOnTouched(fn: any): void { }
}

@Component({
  template: `
  <form>
    <s-multi-input label="this is the label for multiple inputs" ngModel name="labeled"></s-multi-input>
    <input second-thing value="last child">
  </form>
  `
})
class TestSeveralInputsLabelDirectiveComponent {
  labeled: string;
}

describe('Label directive: multiple inputs', () => {
  let fixture: ComponentFixture<TestSeveralInputsLabelDirectiveComponent>;
  let element: DebugElement;
  let fieldsetContainer: DebugElement;
  let legendContainer;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestSeveralInputsLabelDirectiveComponent, LabelDirective, TestMultipleInputsComponent],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    });
    fixture = TestBed.createComponent(TestSeveralInputsLabelDirectiveComponent);
    fixture.detectChanges();
    element = fixture.debugElement.query(By.css('[label]'));
    fieldsetContainer = element.parent;
    legendContainer = fieldsetContainer.children[0];
  });

  it('should display a styled fieldset wrapping the multi-input component and legend element with them being siblings of each other', () => {
    const multiInputComponent = fieldsetContainer.children[1];

    expect(fieldsetContainer.name).toBe('fieldset');
    expect(fieldsetContainer.classes['s-label__fieldset']).toBe(true);
    expect(legendContainer.name).toEqual('legend');
    expect(multiInputComponent.name).toEqual('s-multi-input');
  });


  it('should display the label box model in the correct order', () => {
    expect(legendContainer.children.length).toBe(2);
    expect(legendContainer.children[0].classes['s-label__default']).toBe(true);
    expect(legendContainer.children[1].classes['s-label__optional']).toBe(true);
  });
});



@Component({
  template: `
  <s-checkbox ngModel name="labeled" label="this makes no sense">A nice checkbox</s-checkbox>
  `
})
class SCheckboxLabelDirectiveComponent {
  labeled: string;
}

describe('Label directive: s-checkbox', () => {
  let fixture: ComponentFixture<SCheckboxLabelDirectiveComponent>;
  let element: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SCheckboxLabelDirectiveComponent, LabelDirective, CheckboxComponent],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    });
    fixture = TestBed.createComponent(SCheckboxLabelDirectiveComponent);
    fixture.detectChanges();
    element = fixture.debugElement.query(By.css('[label]'));
  });

  it('should not apply in this context', () => {
    expect(element.parent.name).not.toBe('label');
  });
});
