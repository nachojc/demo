import { AfterViewInit, Directive, ElementRef, Injector, Input, Renderer2 } from '@angular/core';
import { NgControl } from '@angular/forms';
import label, { HelpLabelModel, OptionalLabelModel } from './label';

@Directive({
  selector: '[label]:not(s-checkbox):not(s-select)'
})
export class LabelDirective implements AfterViewInit {

  @Input('label') labelText: string | HelpLabelModel | OptionalLabelModel;

  constructor (private el: ElementRef, private renderer: Renderer2, private injector: Injector) { }

  ngAfterViewInit () {
    // check required validator
    const ngControl: NgControl = this.injector.get(NgControl, null);
    let required = false;

    const functionToEvaluate = ngControl && ((ngControl.control && ngControl.control.validator) || ngControl.validator);
    if (functionToEvaluate) {
      const validations = functionToEvaluate(<any>'');
      if (validations && validations.required) {
        required = true;
      }
    }
    label(this.renderer, this.el, this.labelText, required);
  }
}
