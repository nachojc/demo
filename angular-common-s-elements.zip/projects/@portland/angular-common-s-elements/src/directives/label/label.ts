import { ElementRef, Renderer2 } from '@angular/core';

export interface HelpLabelModel {
  defaultValue: string;
  help: string;
  optional?: string;
}

export interface OptionalLabelModel {
  defaultValue: string;
  optional: string;
}

export default function(renderer: Renderer2, el: ElementRef, labelText: string | HelpLabelModel | OptionalLabelModel, required: boolean) {
  const labelDefaultValueText: string = labelText['defaultValue'] || labelText;
  const labelOptionalText: string = labelText['optional'] || '(if applicable)';
  const labelHelpText: string = labelText['help'];

  const parent = renderer.parentNode(el.nativeElement);
  const sibling = renderer.nextSibling(el.nativeElement);
  const nodes = buildLabelBoxModel(renderer, required, labelDefaultValueText, labelHelpText, labelOptionalText);
  renderer.removeChild(parent, el.nativeElement);

  if (isMultiInputComponent(el)) {
    const fieldset = renderer.createElement('fieldset');
    renderer.addClass(fieldset, 's-label__fieldset');
    const legend = renderer.createElement('legend');
    renderer.appendChild(legend, nodes.defaultBox);
    renderer.appendChild(fieldset, legend);

    insertingOptionalAndHelp(renderer, legend, nodes.optionalBox, nodes.helpBox);
    renderer.appendChild(fieldset, el.nativeElement);
    renderer.insertBefore(parent, fieldset, sibling);

  } else {
    const label = renderer.createElement('label');
    renderer.appendChild(label, nodes.defaultBox);
    insertingOptionalAndHelp(renderer, label, nodes.optionalBox, nodes.helpBox);
    renderer.appendChild(label, el.nativeElement);
    renderer.insertBefore(parent, label, sibling);

  }
}

function isMultiInputComponent (element: ElementRef): boolean {
  return element.nativeElement.querySelectorAll('input').length > 1;
}


function buildLabelBoxModel(
  renderer,
  required,
  labelDefaultValueText,
  labelHelpText,
  labelOptionalText): { defaultBox: Node, optionalBox?: Node, helpBox?: Node } {
    // default
    const defaultBox = renderer.createElement('span');
    renderer.addClass(defaultBox, 's-label__default');
    if (required) {
      renderer.addClass(defaultBox, 's-label__default--block');
    }
    const labelDefaultTextNode = renderer.createText(labelDefaultValueText);
    renderer.appendChild(defaultBox, labelDefaultTextNode);

    // optional
    let optionalBox;
    if (!required) {
      optionalBox = renderer.createElement('span');
      renderer.addClass(optionalBox, 's-label__optional');
      const labelOptionalTextNode = renderer.createText(` ${labelOptionalText}`);
      renderer.appendChild(optionalBox, labelOptionalTextNode);
    }

    // help
    let helpBox;
    if (labelHelpText) {
      helpBox = renderer.createElement('span');
      renderer.addClass(helpBox, 's-label__help');
      const labelHelpTextNode = renderer.createText(labelHelpText);
      renderer.appendChild(helpBox, labelHelpTextNode);
    }

    const ret = { defaultBox: defaultBox };
    if (optionalBox) ret['optionalBox'] = optionalBox;
    if (helpBox) ret['helpBox'] = helpBox;
    return ret;
}



function insertingOptionalAndHelp(renderer, box, optionalBox, helpBox) {
  if (optionalBox) {
    renderer.appendChild(box, optionalBox);
  }
  if (helpBox) {
    renderer.appendChild(box, helpBox);
  }
}
