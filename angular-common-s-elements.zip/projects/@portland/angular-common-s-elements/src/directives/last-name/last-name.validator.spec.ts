import { FormControl } from '@angular/forms';
import lastNameValidate from './last-name.validator';

const requiredError = { required: true } ;
const lastNameValidatorError = { lastNameValidator: { valid: false } };

describe('LastNameValidator', () => {
  it('#lastNameValidate should return required true object as error if AbstractControl passed with req invalid', () => {
    const control = new FormControl('');

    expect(lastNameValidate(control)).toEqual(requiredError);
  });

  it('#lastNameValidate should return custom pattern object as error if AbstractControl passed with wrong val', () => {
    const control = new FormControl('123');

    expect(lastNameValidate(control)).toEqual(lastNameValidatorError);
  });

  it('#lastNameValidate should return null if value of control is still null', () => {
    const control = new FormControl(null);

    expect(lastNameValidate(control)).toEqual(null);
  });

  it('#lastNameValidate should return null if value passed in control if correct', () => {
    const control = new FormControl('Okay');

    expect(lastNameValidate(control)).toEqual(null);
  });

  it('#lastNameValidate should return null if AbstractControl passed with no value but is not required', () => {
    const control = new FormControl('');

    expect(lastNameValidate(control, false)).toEqual(null);
  });

  it('#lastNameValidate should return lastnamevalidator error if AbstractControl passed with wrong value and is not required', () => {
    const control = new FormControl('33');

    expect(lastNameValidate(control, false)).toEqual(lastNameValidatorError);
  });
});
