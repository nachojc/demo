import { NgModule } from '@angular/core';
import { LastNameDirective } from './last-name.directive';

@NgModule({
  declarations: [
    LastNameDirective
  ],
  exports: [
    LastNameDirective
  ]
})

export class SLastNameDirectiveModule { }
