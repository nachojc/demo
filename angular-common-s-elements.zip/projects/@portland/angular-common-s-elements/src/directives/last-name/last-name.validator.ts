import { ValidationErrors, AbstractControl } from '@angular/forms';

const lastNamePattern = /^[a-zA-Z]([a-zA-Z\'\-\s]{0,28})[a-zA-Z]$/;

export default function lastNameValidate(c: AbstractControl, required: boolean = true): ValidationErrors | null {
  if (required && c.value === '') {
    return { required: true };
  } else if (c.value && c.value.length > 0 && !lastNamePattern.test(c.value)) {
    return { lastNameValidator: { valid: false } };
  }
  return null;
}
