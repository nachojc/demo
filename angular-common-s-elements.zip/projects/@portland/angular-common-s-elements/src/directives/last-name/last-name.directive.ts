import { Directive, ElementRef, Renderer2, forwardRef, AfterViewInit, OnDestroy, Injector, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, FormControl, ValidationErrors, AbstractControl, NgControl } from '@angular/forms';
import lastNameValidator from './last-name.validator';
import label from '../label/label';
import error from '../error/error';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[lastName][ngModel]', // TODO: like first name [lastName][formControl]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => LastNameDirective),
      multi: true
    }
  ]
})
export class LastNameDirective implements AfterViewInit, Validator, OnDestroy {
  private controlSubscription: Subscription;
  private control: AbstractControl;
  private messages = {
    lastNameValidator: 'Your last name must be 2 to 30 characters and not include numbers or symbols, only \'-\' is accepted',
    required: 'Please enter your last name'
  };

  private required = true;

  @Input('not-required')
  public set nonRequired (val: string | null) {
    this.required = val === null;
  }

  constructor(private el: ElementRef, private renderer: Renderer2, private injector: Injector) { }

   ngAfterViewInit () {
    label(this.renderer, this.el, 'Last name', this.required);

    const ngControl: NgControl = this.injector.get(NgControl, null);
    if (ngControl) {
      this.control = ngControl.control as AbstractControl;
      this.controlSubscription = error(this.control, this.messages, this.renderer, this.el);
    }
  }

  validate (c: FormControl): ValidationErrors | null {
    return lastNameValidator(c, this.required);
  }

  ngOnDestroy () {
    if (this.controlSubscription) this.controlSubscription.unsubscribe();
  }
}
