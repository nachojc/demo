/* tslint:disable:max-line-length */
import { Component, DebugElement, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { LastNameDirective } from './last-name.directive';
import { FormsModule, NgModel, NgControl } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  template: `
  <form myForm="ngForm">
    <input name="lastName" lastName #lastNameNgModel="ngModel" [(ngModel)]="lastName">
  </form>`
})
class TestLastNameDirectiveComponent {
  lastName: string;
  @ViewChild('lastNameNgModel') lastNameNgModel: NgModel;
 }

describe('Directive: LastNameDirective', () => {

  let component: TestLastNameDirectiveComponent;
  let fixture: ComponentFixture<TestLastNameDirectiveComponent>;
  let inputEl: DebugElement;
  let lastName1;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestLastNameDirectiveComponent, LastNameDirective],
      imports: [CommonModule, FormsModule],
      providers: [NgControl]
    });
    fixture = TestBed.createComponent(TestLastNameDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    lastName1 = inputEl.references['lastName1'];
    fixture.detectChanges();
  });

  it('should display a label for the last name', () => {
    const labelContainer = fixture.debugElement.query(By.css('label'));
    expect(labelContainer.nativeElement.textContent).toEqual('Last name');
  });

  it('should display an error message as follows for the last name', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('3');
    const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');
    expect(errorContainer.textContent).toEqual('Your last name must be 2 to 30 characters and not include numbers or symbols, only \'-\' is accepted');
  });

  it('should not allow numbers or special chars other than "-"', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('33f3%%');
    // do we need to test error container is actually displaying?
    expect(component.lastNameNgModel.valid).toBe(false);
  });

  it('should only accept these characters: "-", spaces and letters', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('Test pass');
    expect(component.lastNameNgModel.valid).toBe(true);
  });

  it('should contain at least 2 valid characters', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('n');
    expect(component.lastNameNgModel.valid).toBe(false);
  });

  it('should not contain more than 30 valid characters', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('it can\'t contain more than 30 characters');
    expect(component.lastNameNgModel.valid).toBe(false);
  });

  it('should be valid when input contains 30 characters', async () => {
    await fixture.whenStable();

    component.lastNameNgModel.control.patchValue('Only Thirty chars- are allowed');
    expect(component.lastNameNgModel.control.valid).toBe(true);
  });

  it('should be valid when input contains 2 characters only', async () => {
    await fixture.whenStable();

    component.lastNameNgModel.control.patchValue('To');
    expect(component.lastNameNgModel.control.valid).toBe(true);
  });

  it('should not validate when value is empty', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('');
    expect(component.lastNameNgModel.valid).toBe(false);
  });

  it('should not allow empty spaces neither at the begining nor at the end', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('  a  ');
    expect(component.lastNameNgModel.valid).toBe(false);
  });

  it('should not allow special characters between or before letters like "a[A", "^A"', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('a[A]zs');
    expect(component.lastNameNgModel.valid).toBe(false);

    component.lastNameNgModel.control.patchValue('a[A]zs');
    expect(component.lastNameNgModel.valid).toBe(false);

    component.lastNameNgModel.control.patchValue('^aszs^');
    expect(component.lastNameNgModel.valid).toBe(false);

    component.lastNameNgModel.control.patchValue('sszs]');
    expect(component.lastNameNgModel.valid).toBe(false);
  });

  it('should validate required when not-required attribute is not present', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('');

    expect(component.lastNameNgModel.control.valid).toBe(false);
  });
});

@Component({
  template: `
  <form myForm="ngForm">
    <input name="lastName" lastName #lastNameNgModel="ngModel" [(ngModel)]="lastName" not-required>
  </form>`
})
class TestNonRequiredLastNameDirectiveComponent {
  lastName: string;
  @ViewChild('lastNameNgModel') lastNameNgModel: NgModel;
}

describe('Directive: LastNameDirective not-required', () => {
  let component: TestNonRequiredLastNameDirectiveComponent;
  let fixture: ComponentFixture<TestNonRequiredLastNameDirectiveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestNonRequiredLastNameDirectiveComponent, LastNameDirective],
      imports: [CommonModule, FormsModule],
      providers: [NgControl]
    });
    fixture = TestBed.createComponent(TestNonRequiredLastNameDirectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should not validate required when not-required attribute is present', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('');

    expect(component.lastNameNgModel.control.valid).toBe(true);
  });

  it('should validate element against pattern even if not-required attribute is present', async () => {
    await fixture.whenStable();
    component.lastNameNgModel.control.patchValue('1212aa');

    expect(component.lastNameNgModel.control.valid).toBe(false);
  });
});

@Component({
  template: `
  <form myForm="ngForm">
    <input name="lastName" lastName #lastNameNgModel="ngModel" [(ngModel)]="lastName" not-required>
  </form>`
})
class TestLastNameNotRequiredDirectiveComponent {
  lastName: string;
  @ViewChild('lastNameNgModel') lastNameNgModel: NgModel;
}

describe('Directive: LastNameDirective NotRequired', () => {
  let component: TestLastNameNotRequiredDirectiveComponent;
  let fixture: ComponentFixture<TestLastNameNotRequiredDirectiveComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestLastNameNotRequiredDirectiveComponent, LastNameDirective],
      imports: [CommonModule, FormsModule],
      providers: [NgControl]
    });
    fixture = TestBed.createComponent(TestLastNameNotRequiredDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    fixture.detectChanges();
  });

  it('should display a label for the last name when not-required is present', () => {
    const labelContainer = fixture.debugElement.query(By.css('label'));
    expect(labelContainer.nativeElement.textContent).toEqual('Last name (if applicable)');
  });
});
