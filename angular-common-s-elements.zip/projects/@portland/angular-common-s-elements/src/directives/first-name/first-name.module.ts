import { NgModule } from '@angular/core';
import { FirstNameDirective } from './first-name.directive';

@NgModule({
  declarations: [
    FirstNameDirective
  ],
  exports: [
    FirstNameDirective
  ]
})

export class SFirstNameDirectiveModule { }
