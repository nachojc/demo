import { ValidationErrors, AbstractControl } from '@angular/forms';

const firstNamePattern = /^[a-zA-Z]([a-zA-Z\'\-\s]{0,18})[a-zA-Z]$/;

export default function firstNameValidate(c: AbstractControl, required: boolean = true): ValidationErrors | null {
  if (required && c.value === '') {
    return { required: true };
  } else if (c.value && c.value.length > 0 && !firstNamePattern.test(c.value)) {
    return { firstNameValidator: { valid: false } };
  }
  return null;
}
