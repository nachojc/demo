import { Component, DebugElement, ViewChild } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { FirstNameDirective } from './first-name.directive';
import { FormsModule, NgControl, NgModel } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  template: `
  <form myForm="ngForm">
    <input name="firstName" firstName #firstNameNgModel="ngModel" [(ngModel)]="firstName">
  </form>`
})
class TestFirstNameDirectiveComponent {
  firstName: string;
  @ViewChild('firstNameNgModel') firstNameNgModel: NgModel;
}

describe('Directive: FirstNameDirective', () => {
  let component: TestFirstNameDirectiveComponent;
  let fixture: ComponentFixture<TestFirstNameDirectiveComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestFirstNameDirectiveComponent, FirstNameDirective],
      imports: [CommonModule, FormsModule],
      providers: [NgControl]
    });
    fixture = TestBed.createComponent(TestFirstNameDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    fixture.detectChanges();
  });

  it('should display a label for the first name', () => {
    const labelContainer = fixture.debugElement.query(By.css('label'));
    expect(labelContainer.nativeElement.textContent).toEqual('First name');
  });

  it('should display custom pattern error if value entered is not correct', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('3');
    const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');
    expect(errorContainer.textContent).toEqual('Your first name must be 2 to 20 characters and' +
    ' not include numbers or symbols, only \'-\' is accepted');
  });

  it('should display required error if there is no value entered', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('');
    const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');
    expect(errorContainer.textContent).toEqual('Please enter your first name');
  });

  it('should not allow numbers or special chars other than "-"', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('33f3%%');

    // do we need to test error container is actually displaying?
    expect(component.firstNameNgModel.control.valid).toBe(false);
  });

  it('should only accept "-", spaces and letters', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('Test Pass');

    expect(component.firstNameNgModel.control.valid).toBe(true);
  });

  it('should contain at least 2 valid characters', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('n');

    expect(component.firstNameNgModel.control.valid).toBe(false);
  });

  it('should not contain more than 20 valid characters', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('it can\'t contain more than 20 characters');
    expect(component.firstNameNgModel.control.valid).toBe(false);

    component.firstNameNgModel.control.patchValue('no longer than twenty');
    expect(component.firstNameNgModel.control.valid).toBe(false);
  });

  it('should be valid when input contains 20 characters', async () => {
    await fixture.whenStable();

    component.firstNameNgModel.control.patchValue('Only twenty chars ok');
    expect(component.firstNameNgModel.control.valid).toBe(true);
  });

  it('should be valid when input contains 2 characters only', async () => {
    await fixture.whenStable();

    component.firstNameNgModel.control.patchValue('To');
    expect(component.firstNameNgModel.control.valid).toBe(true);
  });

  it('should not validate when value is empty', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('');

    expect(component.firstNameNgModel.control.valid).toBe(false);
  });

  it('should not allow special characters between or before letters like "a[A", "^A"', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('a[A]zs');
    expect(component.firstNameNgModel.control.valid).toBe(false);

    component.firstNameNgModel.control.patchValue('[aszs');
    expect(component.firstNameNgModel.control.valid).toBe(false);

    component.firstNameNgModel.control.patchValue('^aszs^');
    expect(component.firstNameNgModel.control.valid).toBe(false);

    component.firstNameNgModel.control.patchValue('sszs]');
    expect(component.firstNameNgModel.control.valid).toBe(false);
  });

  it('should validate required when not-required attribute is not present', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('');

    expect(component.firstNameNgModel.control.valid).toBe(false);
  });
});

@Component({
  template: `
  <form myForm="ngForm">
    <input name="firstName" firstName #firstNameNgModel="ngModel" [(ngModel)]="firstName" not-required>
  </form>`
})
class TestNonRequiredFirstNameDirectiveComponent {
  firstName: string;
  @ViewChild('firstNameNgModel') firstNameNgModel: NgModel;
}

describe('Directive: FirstNameDirective not-required', () => {
  let component: TestNonRequiredFirstNameDirectiveComponent;
  let fixture: ComponentFixture<TestNonRequiredFirstNameDirectiveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestNonRequiredFirstNameDirectiveComponent, FirstNameDirective],
      imports: [CommonModule, FormsModule],
      providers: [NgControl]
    });
    fixture = TestBed.createComponent(TestNonRequiredFirstNameDirectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should not validate required when not-required attribute is present', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('');

    expect(component.firstNameNgModel.control.valid).toBe(true);
  });

  it('should validate element against pattern even if not-required attribute is present', async () => {
    await fixture.whenStable();
    component.firstNameNgModel.control.patchValue('1212aa');

    expect(component.firstNameNgModel.control.valid).toBe(false);
  });
});

@Component({
  template: `
  <form myForm="ngForm">
    <input name="firstName" firstName #firstNameNgModel="ngModel" [(ngModel)]="firstName" not-required>
  </form>`
})
class TestFirstNameNotRequiredDirectiveComponent {
  firstName: string;
  @ViewChild('firstNameNgModel') firstNameNgModel: NgModel;
}

describe('Directive: FirstNameDirective NotRequired', () => {
  let component: TestFirstNameNotRequiredDirectiveComponent;
  let fixture: ComponentFixture<TestFirstNameNotRequiredDirectiveComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestFirstNameNotRequiredDirectiveComponent, FirstNameDirective],
      imports: [CommonModule, FormsModule],
      providers: [NgControl]
    });
    fixture = TestBed.createComponent(TestFirstNameNotRequiredDirectiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should display a label for the first name when not-required is present', () => {
    const labelContainer = fixture.debugElement.query(By.css('label'));
    expect(labelContainer.nativeElement.textContent).toEqual('First name (if applicable)');
  });
});
