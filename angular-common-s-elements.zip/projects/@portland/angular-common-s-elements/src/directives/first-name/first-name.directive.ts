import { Directive, ElementRef, Renderer2, forwardRef, AfterViewInit, OnDestroy, Injector, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, FormControl, ValidationErrors, AbstractControl, NgControl } from '@angular/forms';
import firstNameValidator from './first-name.validator';
import label from '../label/label';
import error from '../error/error';
import { Subscription } from 'rxjs';

@Directive({
  selector: '[firstName][ngModel]', // TODO: see if applicable to reactive.. [firstName][formControlName], [firstName][formControl]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: forwardRef(() => FirstNameDirective),
      multi: true
    }
  ]
})
export class FirstNameDirective implements AfterViewInit, Validator, OnDestroy {
  private controlSubscription: Subscription;
  private control: AbstractControl;
  private messages = {
    firstNameValidator: 'Your first name must be 2 to 20 characters and not include numbers or symbols, only \'-\' is accepted',
    required: 'Please enter your first name'
  };

  private required = true;

  @Input('not-required') // this.required = !(this.el.nativeElement.getAttribute('not-required') === null);
  public set nonRequired (val: string | null) {
    this.required = val === null;
  }

  // @see https://blog.thoughtram.io/angular/2016/03/14/custom-validators-in-angular-2.html
  constructor (private el: ElementRef, private renderer: Renderer2, private injector: Injector) { }

   ngAfterViewInit () {
    label(this.renderer, this.el, 'First name', this.required);

    const ngControl: NgControl = this.injector.get(NgControl, null);
    if (ngControl) {
      this.control = ngControl.control as AbstractControl;
      this.controlSubscription = error(this.control, this.messages, this.renderer, this.el);
    }
  }

  validate (c: FormControl): ValidationErrors | null {
    return firstNameValidator(c, this.required);
  }

  ngOnDestroy () {
    if (this.controlSubscription) this.controlSubscription.unsubscribe();
  }
}
