import { FormControl } from '@angular/forms';
import firstNameValidate from './first-name.validator';

const requiredError = { required: true } ;
const firstNameValidatorError = { firstNameValidator: { valid: false } };

describe('FirstNameValidator', () => {
  it('#firstNameValidate should return required true object as error if AbstractControl passed with req invalid', () => {
    const control = new FormControl('');

    expect(firstNameValidate(control)).toEqual(requiredError);
  });

  it('#firstNameValidate should return custom pattern object as error if AbstractControl passed with wrong val', () => {
    const control = new FormControl('123');

    expect(firstNameValidate(control)).toEqual(firstNameValidatorError);
  });

  it('#firstNameValidate should return null if value of control is still null', () => {
    const control = new FormControl(null);

    expect(firstNameValidate(control)).toEqual(null);
  });

  it('#firstNameValidate should return null if value passed in control if correct', () => {
    const control = new FormControl('Okay');

    expect(firstNameValidate(control)).toEqual(null);
  });

  it('#firstNameValidate should return null if AbstractControl passed with no value but is not required', () => {
    const control = new FormControl('');

    expect(firstNameValidate(control, false)).toEqual(null);
  });

  it('#firstNameValidate should return firstnamevalidator error if AbstractControl passed with wrong value and is not required', () => {
    const control = new FormControl('33');

    expect(firstNameValidate(control, false)).toEqual(firstNameValidatorError);
  });
});
