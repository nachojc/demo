import { CommonModule } from '@angular/common';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { FinancialDirective } from './financial.directive';
import { InputComponent } from '../../components/input/input.component';

@Component({
  template: `
    <form #form="ngForm">
      <s-input financial name="amountValue" [(ngModel)]="amountValue">  </s-input>
      {{amountValue}}
    </form>
  `
})
class TestComponent {
  amountValue = '';
}

let fakePasteEventPayload = {};
let fakeDragEventPayload = {};

const fakePasteEvent = {
  clipboardData: { getData : () => fakePasteEventPayload },
  preventDefault: jasmine.createSpy('prevent default')
};

const fakeDragEvent = {
  dataTransfer: { getData : () => fakeDragEventPayload },
  preventDefault: jasmine.createSpy('prevent default')
};

describe('FinancialDirective', () => {
  let fixture: ComponentFixture<TestComponent>;
  let inputComponent;
  let s_inputComponent: DebugElement;
  let component: TestComponent;

  const fakeEvent = {
    target: {
      value: ''
    },
    key: 43,
    code: '',
    preventDefault: jasmine.createSpy('preventDefault'),
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [
        TestComponent,
        FinancialDirective,
        InputComponent
      ],
      imports: [
        CommonModule,
        FormsModule
      ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    component = fixture.componentInstance;
    s_inputComponent = fixture.debugElement.query(By.css('s-input'));
    inputComponent = fixture.nativeElement.getElementsByTagName('input')[0];
    fixture.detectChanges();
  });

  afterEach(() => {
    fakePasteEvent.preventDefault.calls.reset();
    fakeDragEvent.preventDefault.calls.reset();
  });

  async function getChanges() {
    fixture.detectChanges();
    await fixture.whenStable();
  }

  it('should format value correctly', async () => {
    inputComponent.value = '1000';
    inputComponent.dispatchEvent(new Event('change'));
    await getChanges();
    expect(component.amountValue).toBe('1000.00');
    expect(inputComponent.value).toBe('1000.00');

    inputComponent.value = '10000';
    inputComponent.dispatchEvent(new Event('change'));
    await getChanges();
    expect(component.amountValue).toBe('10000.00');
    expect(inputComponent.value).toBe('10000.00');

    inputComponent.value = '1000000';
    inputComponent.dispatchEvent(new Event('change'));
    await getChanges();
    expect(component.amountValue).toBe('1000000.00');
    expect(inputComponent.value).toBe('1000000.00');
  });

  it('should not add decimal extension if its already added', () => {
    inputComponent.value = '1,000.00';
    inputComponent.dispatchEvent(new Event('change'));
    expect(component.amountValue).toBe('1000.00');
  });

  it('should add decimal extension if value has a "Period (.)" at the end', () => {
    inputComponent.value = '1000.';
    inputComponent.dispatchEvent(new Event('change'));
    expect(component.amountValue).toBe('1000.00');
  });


  it('should add extra zero if value has only one character after the period', () => {
    inputComponent.value = '1000.0';
    inputComponent.dispatchEvent(new Event('change'));
    expect(component.amountValue).toBe('1000.00');
  });

  it('should format value on blur event', async () => {
    inputComponent.value = '1000';
    inputComponent.dispatchEvent(new Event('change'));
    await getChanges();
    inputComponent.dispatchEvent(new Event('blur'));
    await getChanges();
    expect(inputComponent.value).toBe('1,000.00');
    expect(component.amountValue).toBe('1000.00');
  });

  it('should un-format value on focus event', async () => {
    inputComponent.value = '1,000.00';
    fixture.detectChanges();
    inputComponent.dispatchEvent(new Event('focus'));
    fixture.detectChanges();
    expect(inputComponent.value).toBe('1000.00');

    inputComponent.dispatchEvent(new Event('change'));
    await getChanges();
    expect(component.amountValue).toBe('1000.00');
  });

  it('should call preventDefault when input entered inside #spaceHandler is invalid', () => {
    fakeEvent.code = 'Space';
    s_inputComponent.triggerEventHandler('keypress', fakeEvent);

    expect(fakeEvent.preventDefault).toHaveBeenCalled();
  });

  it('should prevent decimal length increase', async () => {
    inputComponent.value = '1000.000';
    inputComponent.dispatchEvent(new Event('input'));
    inputComponent.dispatchEvent(new Event('change'));
    await getChanges();
    expect(component.amountValue).toBe('1000.00');
    expect(inputComponent.value).toBe('1000.00');
  });

  it('should prevent more than 2 decimals if currency is GBP', async () => {
    inputComponent.value = '1000.00';
    inputComponent.dispatchEvent(new Event('change'));
    await getChanges();
    expect(component.amountValue).toBe('1000.00');
    expect(inputComponent.value).toBe('1000.00');

    inputComponent.value = '10,00.00';
    inputComponent.dispatchEvent(new Event('focus'));
    await getChanges();
    expect(component.amountValue).toBe('1000.00');
    expect(inputComponent.value).toBe('1000.00');
  });

  it('should not call preventDefault when input data pasted in is valid', () => {
    fakePasteEventPayload = '123';

    s_inputComponent.triggerEventHandler('paste', fakePasteEvent);

    expect(fakePasteEvent.preventDefault).not.toHaveBeenCalled();
  });

  it('should call preventDefault when input data pasted in is invalid', () => {
    fakePasteEventPayload = 'abc';

    s_inputComponent.triggerEventHandler('paste', fakePasteEvent);

    expect(fakePasteEvent.preventDefault).toHaveBeenCalled();
  });

  it('should not call preventDefault when input data dragged in is valid', () => {
    fakeDragEventPayload = '123';

    s_inputComponent.triggerEventHandler('drop', fakeDragEvent);

    expect(fakeDragEvent.preventDefault).not.toHaveBeenCalled();
  });

  it('should call preventDefault when input data dragged in is invalid', () => {
    fakeDragEventPayload = 'abc';

    s_inputComponent.triggerEventHandler('drop', fakeDragEvent);

    expect(fakeDragEvent.preventDefault).toHaveBeenCalled();
  });
});
