import { Directive, ElementRef, HostListener, Input, OnInit, Renderer2, AfterViewInit, OnDestroy } from '@angular/core';
import { NgModel } from '@angular/forms';
import { FinancialHelper } from './financial';

@Directive({
  selector: '[financial]',
  providers: [NgModel],
})
export class FinancialDirective implements OnInit, AfterViewInit, OnDestroy {
  private separator = ',';
  private decimalSeparator = '.';
  private decimalSeparatorCode = 'Period';
  private separatorRemoverRegex = /\,/g;
  private currencyFormatRegex = /\B(?=(\d{3})+(?!\d))/g;
  private _positionLeft: 'left'|'right' = 'left';
  private _decimalLength = 2;

  @Input('currencyPrefix') currencyPrefix = '£';
  @Input('decimalLength') set decimalLength(val: string) {
    if (parseInt(val, 10)) {
      this._decimalLength = parseInt(val, 10);
    }
  }
  @Input('position') set position(val: 'left'|'right') {
    this._positionLeft = val;
  }

  private specialKeys = {
    'Backspace': true,
    'Enter': true,
    'Shift': true,
    'ArrowLeft': true,
    'ArrowUp': true,
    'ArrowRight': true,
    'ArrowDown': true,
    'Delete': true,
    'Tab': true
  };

  constructor(private ngModel: NgModel, private el: ElementRef, private renderer: Renderer2) { }

  private _inputOnChange: Function = () => {};
  private _inputOnFocus: Function = () => {};
  private _inputOnBlur: Function = () => {};
  private _inputOnInput: Function = () => {};

  ngOnInit() {
    this.renderer.addClass(this.el.nativeElement , 'currency');
    this.renderer.addClass(this.el.nativeElement , this._positionLeft);
    this.renderer.setAttribute(this.el.nativeElement, 'currencyPrefix', this.currencyPrefix);
  }

  ngAfterViewInit() {
    const input: HTMLInputElement[] = this.el.nativeElement.getElementsByTagName('input');
    if (input.length) {
      this._inputOnChange = this.renderer.listen(input[0], 'change', (event) => {
        const formatedValue = FinancialHelper.removeSeparators(event.target.value, this.separatorRemoverRegex);
        this.propagateValue(formatedValue);
        input[0].value = FinancialHelper.addSeparators(event.target.value, this.currencyFormatRegex, this.separator, this.decimalSeparator);
      });
      this._inputOnFocus = this.renderer.listen(input[0], 'focus', (event) => {
        if (parseInt(event.target.value, 10)) {
          input[0].value = FinancialHelper.removeSeparators(event.target.value, this.separatorRemoverRegex);
        } else {
          event.target.value = '';
        }
      });
      this._inputOnBlur = this.renderer.listen(input[0], 'blur', (event) => {
        input[0].value = FinancialHelper.addSeparators(event.target.value, this.currencyFormatRegex, this.separator, this.decimalSeparator);
        this.propagateValue(input[0].value);
      });
      this._inputOnInput = this.renderer.listen(input[0], 'input', (event) => {
        FinancialHelper.preventDecimalLengthIncrease(event, this.decimalSeparator, this._decimalLength);
      });
    }
  }

  ngOnDestroy() {
    this._inputOnChange();
    this._inputOnFocus();
    this._inputOnBlur();
    this._inputOnInput();
  }

  @HostListener('keypress', ['$event']) isValidInput(event) {
      this.spaceHandler(event);
      return this.isNumber(event.key) || this.isSpecialKey(event.code) || this.isSeparatorValid(event);
  }

  @HostListener('paste', ['$event']) pasteHandler(event) {
    const clipboardData = event.clipboardData.getData('Text');
    if (!parseInt(clipboardData, 10)) event.preventDefault();
  }

  @HostListener('drop', ['$event']) dropHandler(event) {
    const dragData = event.dataTransfer.getData('Text');
    if (!parseInt(dragData, 10)) event.preventDefault();
  }

  private propagateValue(value) {
    if (value) {
      value = FinancialHelper.currencyFormatter(value, this._decimalLength, this.decimalSeparator);
      value = FinancialHelper.addSeparators(value, this.currencyFormatRegex, this.separator, this.decimalSeparator);
      const formattedValue = FinancialHelper.getNumericValue(
        value,
        this.separatorRemoverRegex,
        this.decimalSeparator,
        this._decimalLength
      );
      this.ngModel.update.emit(formattedValue);
    }
  }

  private isNumber(number): Boolean {
    return 0 <= number && number <= 9;
  }

  private isSpecialKey(key): Boolean {
    return this.specialKeys[key] === true;
  }

  private isSeparatorValid(event) {
    return event.target.value.indexOf(this.decimalSeparator) === -1 && event.code === this.decimalSeparatorCode;
  }

  private spaceHandler(event) {
    if (event.code === 'Space') event.preventDefault();
  }
}
