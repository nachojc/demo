import { FinancialHelper } from './financial';

describe('FinancialHelper', () => {
    const currencyFormatRegex = /\B(?=(\d{3})+(?!\d))/g;
    const separatorRemoverRegexGBP = /\,/g;
    const separatorRemoverRegexEUR = /\./g;
 it('#currencyFormatter should format value when there are 4 digits and 2 decimals limit (GBP)', () => {
    expect(FinancialHelper.currencyFormatter('1000', 2, '.')).toBe('1000.00');
 });

 it('#currencyFormatter should when format value  there are 9 digits and 2 decimals limit (GBP)', () => {
    expect(FinancialHelper.currencyFormatter('100000000', 2, '.')).toBe('100000000.00');
 });

 it('#currencyFormatter should when format value there are 4 digits and 5 decimals limit (GBP)', () => {
    expect(FinancialHelper.currencyFormatter('1000', 5, '.')).toBe('1000.00000');
 });

 it('#currencyFormatter should when format value  there are 4 digits and 2 decimals limit (EUR)', () => {
    expect(FinancialHelper.currencyFormatter('1000', 2, ',')).toBe('1000,00');
  });

  it('#currencyFormatter should when format value  there are 3 digits and 2 decimals limit (EUR)', () => {
    expect(FinancialHelper.currencyFormatter('100', 2, ',')).toBe('100,00');
  });

  it('#currencyFormatter should when format value  there are 1 digits and 5 decimals limit (EUR)', () => {
    expect(FinancialHelper.currencyFormatter('1', 5, ',')).toBe('1,00000');
  });

  it('#currencyFormatter should when format value there are 1 digits and 1 decimal', () => {
    expect(FinancialHelper.currencyFormatter('1.1', 5, '.')).toBe('1.10000');
  });

  it('#currencyFormatter should when format value there are 1 digits and 2 decimal', () => {
    expect(FinancialHelper.currencyFormatter('1.12', 5, '.')).toBe('1.12000');
  });

  it('#currencyFormatter should when format value there are 1 digits and 4 decimal', () => {
    expect(FinancialHelper.currencyFormatter('1.1222', 5, '.')).toBe('1.12220');
  });

  it('#currencyFormatter should when format value there are 1 digits and 0 decimal', () => {
    expect(FinancialHelper.currencyFormatter('1', 5, '.')).toBe('1.00000');
  });

  it('#currencyFormatter should when format value there is a trailing decimal point', () => {
    expect(FinancialHelper.currencyFormatter('1.', 3, '.')).toBe('1.000');
  });

  it('#addSeparators should add separators (GBP)', () => {
    expect(FinancialHelper.addSeparators('1000', currencyFormatRegex, ',', '.')).toBe('1,000');
    expect(FinancialHelper.addSeparators('10000', currencyFormatRegex, ',', '.')).toBe('10,000');
    expect(FinancialHelper.addSeparators('100000', currencyFormatRegex, ',', '.')).toBe('100,000');
    expect(FinancialHelper.addSeparators('1000000', currencyFormatRegex, ',', '.')).toBe('1,000,000');
    expect(FinancialHelper.addSeparators('1', currencyFormatRegex, ',', '.')).toBe('1');
  });

  it('#addSeparators should add separators (EUR)', () => {
    expect(FinancialHelper.addSeparators('1000', currencyFormatRegex, '.', ',')).toBe('1.000');
    expect(FinancialHelper.addSeparators('10000', currencyFormatRegex, '.', ',')).toBe('10.000');
    expect(FinancialHelper.addSeparators('100000', currencyFormatRegex, '.', ',')).toBe('100.000');
    expect(FinancialHelper.addSeparators('1000000', currencyFormatRegex, '.', ',')).toBe('1.000.000');
    expect(FinancialHelper.addSeparators('1', currencyFormatRegex, '.', ',')).toBe('1');
  });

  it('#removeSeparators should remove separators (when there is 1) (GBP)', () => {
    expect(FinancialHelper.removeSeparators('1,000.00', separatorRemoverRegexGBP)).toBe('1000.00');
  });

  it('#removeSeparators should remove separators (when there is 3) (GBP)', () => {
    expect(FinancialHelper.removeSeparators('1,000,000,000.00', separatorRemoverRegexGBP)).toBe('1000000000.00');
  });

  it('#removeSeparators should remove separators (when there is 3) (GBP)', () => {
    expect(FinancialHelper.removeSeparators('1,000,000,000.00000', separatorRemoverRegexGBP)).toBe('1000000000.00000');
  });

  it('#removeSeparators should remove separators (when there is 1) (EUR)', () => {
    expect(FinancialHelper.removeSeparators('1.000,00', separatorRemoverRegexEUR)).toBe('1000,00');
  });

  it('#removeSeparators should remove separators (when there is 3) (EUR)', () => {
    expect(FinancialHelper.removeSeparators('1.000.000.000,00', separatorRemoverRegexEUR)).toBe('1000000000,00');
  });
});
