export const FinancialHelper = {
  currencyFormatter(value, decimalLength, decimalSeparator) {
    let baseDecimals;
    if (decimalLength) { baseDecimals = '0'.repeat(decimalLength); }

    // if there isn't a decimal point
    if (value.indexOf(decimalSeparator) === -1) { value += `${decimalSeparator}${baseDecimals}`; }
    if (value.indexOf(decimalSeparator) !== -1) {
        const valueDecimalLen = value.slice(value.indexOf(decimalSeparator)).length;
      if (valueDecimalLen - 1 < decimalLength && valueDecimalLen > 2 ) {
          value += baseDecimals.substring(0, (decimalLength + 1) - valueDecimalLen);
      }
      // if there is a trailing decimal point
      if (valueDecimalLen < 2) { value += baseDecimals; }
      // if there is only 1 number after decimal point
      if (valueDecimalLen === 2) {
        value = value.slice(0, value.indexOf(decimalSeparator)) +
        `${decimalSeparator}${value.slice(-1)}${baseDecimals.substring(0, (decimalLength + 1) - valueDecimalLen)}`;
      }
    }
    return value === undefined ? '' : value;
  },

  addSeparators(value, currencyFormatRegex, separator, decimalSeparator) {
    if (value.indexOf(decimalSeparator) !== -1) {
        const splitValue = value.split(decimalSeparator);
        return splitValue[0].replace(currencyFormatRegex, separator) + decimalSeparator + splitValue[1];
      } else {
        return value.replace(currencyFormatRegex, separator);
      }
  },

  removeSeparators(value, separatorRemoverRegex) {
    return value.replace(separatorRemoverRegex, '');
  },

  preventDecimalLengthIncrease(event, decimalSeparator, decimalLength) {
    const el: HTMLInputElement = event.target;
    const startPos = el.selectionStart;
    const endPos = el.selectionEnd;
    if (el.value) {
      if (el.value.indexOf(decimalSeparator) !== -1) {
        const valueSplit = el.value.split(decimalSeparator);
        const decimalValueLength = valueSplit[1].length;
        if (decimalValueLength > decimalLength) {
          const mainValue = valueSplit[0];
          const decimalValue = valueSplit[1];

          el.value = `${mainValue}${decimalSeparator}${decimalValue.substring(0, decimalLength)}`;
          el.setSelectionRange(startPos, endPos);
        }
      }
    }
  },
  getNumericValue(value, separatorRemoverRegex, decimalSeparator, length: number = 2): string {
    const separator: string = getLocalSeparator();
    const local = value.replace(separatorRemoverRegex, '');

    return parseFloat(local.indexOf(separator) >= 0 ? local : local.replace(decimalSeparator, separator)).toFixed(length);
  }
};

function getLocalSeparator() {
  let n: any = 1.1;
  n = n.toLocaleString().substring(1, 2);
  return n;
}
