import { NgModule } from '@angular/core';
import { FinancialDirective } from './financial.directive';

@NgModule({
  declarations: [
    FinancialDirective
  ],
  exports: [
    FinancialDirective
  ]
})

export class SFinancialDirectiveModule { }
