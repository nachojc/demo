import { NgModule } from '@angular/core';
import { ErrorDirective } from './error.directive';

@NgModule({
  declarations: [
    ErrorDirective
  ],
  exports: [
    ErrorDirective
  ]
})

export class SErrorDirectiveModule { }
