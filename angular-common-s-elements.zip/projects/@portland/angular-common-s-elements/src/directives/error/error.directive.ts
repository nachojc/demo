import { AfterViewInit, Directive, ElementRef, Injector, Input, OnDestroy, Renderer2 } from '@angular/core';
import { AbstractControl, NgControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import error from './error';

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: '[error-message]:not(s-select):not(s-title)'
})
export class ErrorDirective implements AfterViewInit, OnDestroy {
  private control: AbstractControl;
  private controlSubscription: Subscription;

  @Input('error-message') messages: string | object;

  constructor (private el: ElementRef, private renderer: Renderer2, private injector: Injector) { }

  ngAfterViewInit () {
    setTimeout(() => {
      const ngControl: NgControl = this.injector.get(NgControl, null);
      if (ngControl) {
        this.control = ngControl.control as AbstractControl;
        this.controlSubscription = error(this.control, this.messages, this.renderer, this.el);
      }
    }, 0); // So other directives runs before (such as label)
  }

  ngOnDestroy () {
    if (this.controlSubscription) this.controlSubscription.unsubscribe();
  }
}
