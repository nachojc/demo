import { ElementRef, Renderer2 } from '@angular/core';
import { Subscription } from 'rxjs';
import { AbstractControl } from '@angular/forms';

function error (renderer: Renderer2, el: ElementRef, messages: string) {
  let errorContainer = el.nativeElement.querySelector('[error-container]');

  if (errorContainer !== null) { // there is a slot for error
    setError(renderer, errorContainer, messages);
  } else { // put error at the bottom
    const siblingContainer = renderer.nextSibling(el.nativeElement);

    if (siblingContainer && siblingContainer.getAttribute && siblingContainer.getAttribute('error-container') !== null) {
      setError(renderer, siblingContainer, messages); // update the container
    } else {
      errorContainer = renderer.createElement('div');
      renderer.setAttribute(errorContainer, 'error-container', '');
      setError(renderer, errorContainer, messages);
      renderer.insertBefore(
        renderer.parentNode(el.nativeElement),
        errorContainer, renderer.nextSibling(el.nativeElement)
      );
    }
  }
}

function setError (renderer: Renderer2, container: HTMLElement, message: string) {
  renderer.addClass(container, 'errorDirective_error');
  const containerElement = container;
  containerElement.textContent = message;
}

export default function listenToStatusChanges (
  control: AbstractControl,
  messages: object | string,
  renderer: Renderer2,
  el: ElementRef): Subscription {
    const subscription = control.statusChanges.subscribe(() => {
      if (control.errors) {
        const firstError = Object.keys(control.errors)[0];
        const messageToDisplay = messages[firstError] || messages;
        error(renderer, el, messageToDisplay);
      }
    });
    const subject: any = control.statusChanges;
    subject.emit(); // Due to touch not triggering a control change, let's emit one so error message is there straigh away from beginning
    return subscription;
}
