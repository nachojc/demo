import { ErrorDirective } from './error.directive';
import { Component, DebugElement } from '@angular/core';
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { NgControl, FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { InputComponent } from '../../components/input/input.component';

@Component({
  template: `
    <form myForm="ngForm">
      <input error-message="This is the error" name="error" [(ngModel)]="testValue" required>
    </form>
  `
})
class TestErrorDirectiveComponent {
  testValue: string;
}

describe('Directive: ErrorDirective', () => {
  let component: TestErrorDirectiveComponent;
  let fixture: ComponentFixture<TestErrorDirectiveComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestErrorDirectiveComponent, ErrorDirective],
      providers: [NgControl],
      imports: [CommonModule, FormsModule]
    });
    fixture = TestBed.createComponent(TestErrorDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    fixture.detectChanges();
  });

  it('should display the right error message', async(() => {
    fixture.whenStable().then(() => {
      const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');

      expect(errorContainer).toBeTruthy();
      expect(errorContainer.textContent).toEqual('This is the error');
    });
  }));

  it('shouldn\'t create a new sibling div if one already exists', async(() => {
    fixture.whenStable().then(() => {
      inputEl.nativeElement.value = 'Test value';
      inputEl.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();
      inputEl.nativeElement.value = '';
      inputEl.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();

      const errorContainerArray = fixture.nativeElement.querySelectorAll('.errorDirective_error');

      expect(errorContainerArray.length).toEqual(1);
    });
  }));
});

@Component({
  template: `
    <form myForm="ngForm">
      <input required minlength="4" pattern="[^abc]*" name="multipleError" [(ngModel)]="testValue"
        [error-message]="{
          required: 'Please provide a value',
          pattern: 'A value must not have an a, b or c',
          minlength: 'Min length is 4 characters'
        }" >
    </form>
  `
})
class TestErrorMultipleDirectiveComponent {
  testValue: string;
}

describe('Directive: ErrorDirective multiple errors', () => {
  let component: TestErrorMultipleDirectiveComponent;
  let fixture: ComponentFixture<TestErrorMultipleDirectiveComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestErrorMultipleDirectiveComponent, ErrorDirective],
      providers: [NgControl],
      imports: [CommonModule, FormsModule]
    });
    fixture = TestBed.createComponent(TestErrorMultipleDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
    fixture.detectChanges();
  });

  it('should display the required error message when input is empty', async(() => {
    fixture.whenStable().then(() => {
      const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');

      expect(errorContainer).toBeTruthy();
      expect(errorContainer.textContent).toEqual('Please provide a value');
    });
  }));

  it('should display the min length error message when input is shorter than 4 characters', async(() => {
    fixture.whenStable().then(() => {
      inputEl.nativeElement.value = 'TNT';
      inputEl.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();

      const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');

      expect(errorContainer.textContent).toEqual('Min length is 4 characters');
    });
  }));

  it('should display the pattern error message when input contains invalid characters', async(() => {
    fixture.whenStable().then(() => {
      inputEl.nativeElement.value = 'ababc';
      inputEl.nativeElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();

      const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');

      expect(errorContainer.textContent).toEqual('A value must not have an a, b or c');
    });
  }));
});

@Component({
  template: `
    <form myForm="ngForm">
      <s-input name="error" [(ngModel)]="testValue" error-message="This is the error" required></s-input>
    </form>
  `
})
class TestErrorDirectiveWithContainerComponent {
  testValue = '';
}

describe('Directive: ErrorDirective', () => {
  let component: TestErrorDirectiveWithContainerComponent;
  let fixture: ComponentFixture<TestErrorDirectiveWithContainerComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestErrorDirectiveWithContainerComponent, ErrorDirective, InputComponent],
      providers: [NgControl],
      imports: [CommonModule, FormsModule]
    });
    fixture = TestBed.createComponent(TestErrorDirectiveWithContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should set error message to container if error container exists', async(() => {
    fixture.whenStable().then(() => {
      const errorContainer = fixture.nativeElement.querySelector('.errorDirective_error');

      expect(errorContainer).toBeTruthy();
      expect(errorContainer.textContent).toEqual('This is the error');
    });
  }));
});
