import { NumericDirective } from './numeric.directive';
import { Component } from '@angular/core';
import { TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

@Component({
  template: `<input numeric/>`
})
class TestComponent { }

let fakePasteEventPayload = {};
let fakeDragEventPayload = {};

const fakePasteEvent = {
  clipboardData: { getData : () => fakePasteEventPayload },
  preventDefault: jasmine.createSpy('prevent default')
};

const fakeDragEvent = {
  dataTransfer: { getData : () => fakeDragEventPayload },
  preventDefault: jasmine.createSpy('prevent default')
};

const keyPressEventSpace = {
  code: 'Space',
  preventDefault: jasmine.createSpy('prevent default')
};

describe('NumericDirective', () => {
  let fixture, inputComponent, directive;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ TestComponent, NumericDirective ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TestComponent);
    directive = new NumericDirective();
    inputComponent = fixture.debugElement.query(By.css('input'));
    fixture.detectChanges();
  });

  afterEach(() => {
    fakePasteEvent.preventDefault.calls.reset();
    fakeDragEvent.preventDefault.calls.reset();
  });

  it('should create an instance', () => {
    expect(directive).toBeTruthy();
  });

  it('#isValidInput should return the right boolean depending on event key value', () => {
    expect(directive.isValidInput({ key: '3' })).toBe(true);
    expect(directive.isValidInput({ key: '6' })).toBe(true);

    expect(directive.isValidInput({ code: 'Tab' })).toBe(true);
    expect(directive.isValidInput({ code: 'Period' })).toBe(false);
  });

  // TODO: Call the pasteHandler function of the TestComponent using the Numeric directive
    // Main issue is pasteHandler is not a function of InputComponent

  // e2e
  it('should not call preventDefault when event paste data is valid (e2e)', () => {
    fakePasteEventPayload = '123';

    inputComponent.triggerEventHandler('paste', fakePasteEvent);

    expect(fakePasteEvent.preventDefault).not.toHaveBeenCalled();
  });

  // Unit Test
  it('should not call preventDefault when event paste data is valid', () => {
    fakePasteEventPayload = '123';

    directive.pasteHandler(fakePasteEvent);

    expect(fakePasteEvent.preventDefault).not.toHaveBeenCalled();
  });

  // e2e
  it('should call preventDefault when event paste data is not valid (e2e)', () => {
    fakePasteEventPayload = 'abc';

    inputComponent.triggerEventHandler('paste', fakePasteEvent);

    expect(fakePasteEvent.preventDefault).toHaveBeenCalled();
  });

  // Unit Test
  it('should call preventDefault when event paste data is not valid', () => {
    fakePasteEventPayload = 'abc';

    directive.pasteHandler(fakePasteEvent);

    expect(fakePasteEvent.preventDefault).toHaveBeenCalled();
  });

  // e2e
  it('should call preventDefault when event paste data is not valid (e2e)', () => {
    inputComponent.triggerEventHandler('keypress', keyPressEventSpace);

    expect(keyPressEventSpace.preventDefault).toHaveBeenCalled();
  });

  // Unit Test
  it('should call preventDefault when keypress event data is a space', () => {
    directive.isValidInput(keyPressEventSpace);

    expect(keyPressEventSpace.preventDefault).toHaveBeenCalled();
  });

  // e2e
  it('should not call preventDefault when event drop data is valid (e2e)', () => {
    fakeDragEventPayload = '123';

    inputComponent.triggerEventHandler('drop', fakeDragEvent);

    expect(fakeDragEvent.preventDefault).not.toHaveBeenCalled();
  });

  // Unit Test
  it('should not call preventDefault when event paste data is valid', () => {
    fakeDragEventPayload = '123';

    directive.dropHandler(fakeDragEvent);

    expect(fakeDragEvent.preventDefault).not.toHaveBeenCalled();
  });

  // e2e
  it('should call preventDefault when event drop data is not valid (e2e)', () => {
    fakeDragEventPayload = 'abc';

    inputComponent.triggerEventHandler('drop', fakeDragEvent);

    expect(fakeDragEvent.preventDefault).toHaveBeenCalled();
  });

  // Unit Test
  it('should call preventDefault when event paste data is not valid', () => {
    fakeDragEventPayload = 'abc';

    directive.dropHandler(fakeDragEvent);

    expect(fakeDragEvent.preventDefault).toHaveBeenCalled();
  });
});
