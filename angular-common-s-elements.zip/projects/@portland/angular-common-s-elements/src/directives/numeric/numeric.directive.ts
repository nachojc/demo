import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[numeric]'
})
export class NumericDirective {
  private specialKeys = {
    'Backspace': true,
    'Enter': true,
    'Shift': true,
    'ArrowLeft': true,
    'ArrowUp': true,
    'ArrowRight': true,
    'ArrowDown': true,
    'Delete': true,
    'Tab': true
  };

  @HostListener('keypress', ['$event']) isValidInput(event) {
    if (event.code === 'Space') {
      event.preventDefault();
    }
    return this.isNumber(event.key) || this.isSpecialKey(event.code);
  }

  private isNumber(number): Boolean {
    return 0 <= number && number <= 9;
  }

  private isSpecialKey(key): Boolean {
    return this.specialKeys[key] === true;
  }

  @HostListener('paste', ['$event']) pasteHandler(event) {
    const clipboardData = event.clipboardData.getData('Text');

    if (!parseInt(clipboardData, 10)) {
      event.preventDefault();
    }
  }

  @HostListener('drop', ['$event']) dropHandler(event) {
    const dragData = event.dataTransfer.getData('Text');

    if (!parseInt(dragData, 10)) {
      event.preventDefault();
    }
  }
}
