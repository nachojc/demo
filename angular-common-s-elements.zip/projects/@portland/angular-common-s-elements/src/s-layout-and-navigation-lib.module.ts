import { NgModule } from '@angular/core';
import { SHeaderComponentModule } from './components/header/header.module';
import { SProgressIndicatorComponentModule } from './components/progress-indicator/progress-indicator.module';

@NgModule({
  imports: [
    SHeaderComponentModule,
    SProgressIndicatorComponentModule
  ],
  exports: [
    SHeaderComponentModule,
    SProgressIndicatorComponentModule
  ]
})
export class SLayoutAndNavigationLibModule { }
