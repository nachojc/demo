import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SListBuilderComponent } from './list-builder.component';
import { SSelectComponentModule } from '../select/select.module';
import { FormsModule } from '@angular/forms';
import { SInputComponentModule } from '../input/input.module';

@NgModule({
  imports: [
    CommonModule,
    SSelectComponentModule,
    SInputComponentModule,
    FormsModule
  ],
  declarations: [SListBuilderComponent],
  exports: [
    SListBuilderComponent
  ]
})
export class SListBuilderComponentModule { }
