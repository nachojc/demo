import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, NgControl } from '@angular/forms';
import { SInputComponentModule } from '../input/input.module';
import { SSelectComponentModule } from '../select/select.module';
import { SListBuilderComponent } from './list-builder.component';

describe('SListBuilderComponent', () => {
  let component: SListBuilderComponent;
  let fixture: ComponentFixture<SListBuilderComponent>;

  const _ngControl = <any>{
    name: 'title',
    touched: false,
    valueChanges: {
      subscribe: jasmine.createSpy('control value subscribe')
    },
    control: {
      statusChanges: {
        subscribe: jasmine.createSpy('control status subscribe'),
        emit: jasmine.createSpy('control status emit'),
      },
      touched: false,
      invalid: false,
      markAsUntouched: jasmine.createSpy('control markAsUntouched'),
      setErrors: jasmine.createSpy('control setErrors'),
      markAsTouched: jasmine.createSpy('control markAsTouched'),
      setValue: jasmine.createSpy('control setValue')
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SListBuilderComponent],
      imports: [FormsModule, SSelectComponentModule, SInputComponentModule],
      providers: [{ provide: NgControl, useValue: _ngControl }]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SListBuilderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('#ngOnInit should set error message values to defaults if left undefined', () => {
    const errorMessages = {
      error: 'Please select a value',
      existingValue: 'Option has already been selected'
    };
    component.errorMessage.error = undefined;
    component.errorMessage.existingValue = undefined;
    fixture.detectChanges();
    component.ngOnInit();
    expect(component.errorMessage).toEqual(errorMessages);
  });

  describe('#optionSelected', () => {
    it('when called, item will be added to the list', () => {
      component._selectedOptions = ['Andy'];
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      fixture.detectChanges();
      component.optionSelected('Sam');
      fixture.detectChanges();
      expect(component._selectedOptions).toEqual(['Andy', 'Sam']);
      expect(component.hasError).toEqual(false);
    });

    it('when called and item has already been selected, it will not be added to the list', () => {
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      component.optionSelected('Sam');
      fixture.detectChanges();
      expect(component._selectedOptions).toEqual(['Sam']);
      component.optionSelected('Sam');
      fixture.detectChanges();
      expect(component._selectedOptions).toEqual(['Sam']);
      expect(component.hasError).toEqual(true);
    });

    it('when called and item has already been selected, it will not be added to the list', () => {
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      component.optionSelected('Sam');
      fixture.detectChanges();
      expect(component._selectedOptions).toEqual(['Sam']);
      component.optionSelected('Sam');
      fixture.detectChanges();
      expect(component._selectedOptions).toEqual(['Sam']);
      expect(component.hasError).toEqual(true);
    });

    it('when called, display inputs is true and item has already been selected, it will not be added to the list', () => {
      component.displayInputs = true;
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      component.optionSelected('Sam');
      fixture.detectChanges();
      expect(component._selectedOptions[0].select).toEqual('Sam');
      component.inputChange(0, 'likes GoT');
      fixture.detectChanges();
      expect(component._selectedOptions[0].input).toEqual('likes GoT');
    });
  });

  describe('#removeItem', () => {
    it('when called, item will be removed from the list', () => {
      component._selectedOptions = ['Alex'];
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      component.optionSelected('Sam');
      fixture.detectChanges();
      component.removeItem(1);
      fixture.detectChanges();
      expect(component._selectedOptions).toEqual(['Alex']);
    });

    it('when called, item will be removed from the list', () => {
      component.displayInputs = true;
      component._selectedOptions = [{ select: 'Alex', input: 'likes flaskball' }];
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      component.optionSelected('Sam');
      fixture.detectChanges();
      component.inputChange(1, 'likes GoT');
      component.removeItem(0);
      fixture.detectChanges();
      expect(component._selectedOptions[0].select).toEqual('Sam');
      expect(component._selectedOptions[0].input).toEqual('likes GoT');
    });

    it('when called, the list is empty and the component is required the error will be set', () => {
      component.isRequired = true;
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      component.optionSelected('Sam');
      component.removeItem(0);
      fixture.detectChanges();

      expect(component._selectedOptions).toEqual([]);
      expect(component.hasError).toEqual(true);
    });

    it('when called and item selected already exists in the list, the item will be removed and the dropdown reset', () => {
      const selectedItemRestSpy = spyOn<any>(component.selectedItem, 'reset');
      component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
      component.optionSelected('Sam');
      fixture.detectChanges();
      component.optionSelected('Sam');
      fixture.detectChanges();
      component.removeItem(0);
      fixture.detectChanges();

      expect(selectedItemRestSpy).toHaveBeenCalled();
      expect(component._selectedOptions).toEqual([]);
    });
  });

  it('when #addAnother is called showDropDown should equal true', () => {
    component.showDropDown = false;
    component.addAnother();
    expect(component.showDropDown).toEqual(true);
  });

  it('when #inputChange is called, it should update the selection', () => {
    component.displayInputs = true;
    component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
    component.optionSelected('Sam');
    component.inputChange(0, 'likes GoT');
    fixture.detectChanges();
    expect(component._selectedOptions[0].select).toEqual('Sam');
    expect(component._selectedOptions[0].input).toEqual('likes GoT');
  });

  it('should call _onChange when an item is removed', () => {
    const onChangeSpy = spyOn<any>(component, 'onChange');
    component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
    component.optionSelected('Sam');
    fixture.detectChanges();
    component.removeItem(0);
    fixture.detectChanges();

    expect(onChangeSpy).toHaveBeenCalled();
  });

  it('should call _propogateChange when an item is selected', () => {
    component.registerOnChange(() => { });
    const spiedFunction = spyOn<any>(component, '_propagateChange');
    component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
    component.optionSelected('Sam');
    fixture.detectChanges();

    expect(spiedFunction).toHaveBeenCalled();
  });

  it('should call _propogateChange when an item is removed', () => {
    component.registerOnChange(() => { });
    const _propagateChangeSpy = spyOn<any>(component, '_propagateChange');
    component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
    component.optionSelected('Sam');
    fixture.detectChanges();
    component.removeItem(0);
    fixture.detectChanges();

    expect(_propagateChangeSpy).toHaveBeenCalled();
  });

  it('calls _onTouched when registerOnTouched is called', () => {
    component.registerOnTouched(() => { });
    component.options = ['Sam', 'Andy', 'Alex', 'Umair'];
    component.optionSelected('Sam');
    fixture.detectChanges();

    expect(component._onTouched).not.toEqual(() => {});
  });

  it('#writeValue works as expected', () => {
    const spiedFunction = spyOn<any>(component.selectedItem.valueAccessor, 'writeValue');
    component.writeValue(':)');
    fixture.detectChanges();
    expect(spiedFunction).toHaveBeenCalledWith(':)');
  });

  it('when #removeSelect is called, stuff happens', () => {
    const selectedItemResetSpy = spyOn<any>(component.selectedItem, 'reset');
    component.removeSelect();
    fixture.detectChanges();

    expect(selectedItemResetSpy).toHaveBeenCalled();
    expect(component.hasError).toEqual(false);
  });

  it('should set showDropDown to false when #ngAfterContentInit is called and _selectedOptions.length > 0', () => {
    component._selectedOptions = ['hello'];
    component.ngAfterContentInit();

    expect(component.showDropDown).toEqual(false);
  });

  it('#setErrors should call setError for both ngControl and selectedItem and set error', () => {
    const selectedItemSetErrorsSpy = spyOn(component.selectedItem.control, 'setErrors');
    component.hasError = true;
    component.setErrors();

    expect(selectedItemSetErrorsSpy).toHaveBeenCalledWith({ error : 'true'});
    expect(_ngControl.control.setErrors).toHaveBeenCalledWith({ error : 'true'});
  });

  it('#set selectedOptions should validate that only values part of the options list are allowed to be pre-set', () => {
    component.options = [1, 2];
    component.selectedOptions = [1, 2, 4, 5];

    expect(component._selectedOptions).toEqual([1, 2]);
  });

  it('#set selectedOptions should validate that pre-set value does not exceed maxSelections limit', () => {
    component.maxSelections = 1;
    component.options = [1, 2];
    component.selectedOptions = [1, 2, 4, 5];

    expect(component._selectedOptions).toEqual([1]);
  });

  it('#onChange should call valueEmiiter if there is no ngControl ', () => {
    const valueEmitterSpy = spyOn(component.valueEmitter, 'emit');
    component.options = [1, 2];
    component.selectedOptions = [1];
    component.ngControl = undefined;
    component.onChange();

    expect(valueEmitterSpy).toHaveBeenCalledWith([1]);
  });
});
