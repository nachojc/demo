import { AfterContentInit, Component, EventEmitter, Injector, Input, OnInit, Output, ViewChild } from '@angular/core';
import { AbstractControl, ControlValueAccessor, NgControl, NgModel, NG_VALUE_ACCESSOR } from '@angular/forms';

export interface Selections {
  select: string;
  input: string;
}

@Component({
  selector: 's-list-builder',
  templateUrl: './list-builder.component.html',
  styleUrls: ['./list-builder.component.scss', '../../styles/error.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SListBuilderComponent, multi: true }
  ]
})
export class SListBuilderComponent implements OnInit, ControlValueAccessor, AfterContentInit {
  @Input() options = [];
  _isRequired = false;
  @Input('required')
  set isRequired(val) {
    this._isRequired = true;
  }
  @Input() displayInputs = false;
  @Input() maxSelections = 3;
  @Input() inputs = {
    label: 'Please enter a value...',
    maxLength: 10
  };
  @Input() errorMessage = {
    error: 'Please select a value...',
    existingValue: 'Option has already been selected'
  };

  _selectedOptions: any[] = [];

  @Input('selectedOptions')
  set selectedOptions(value) {
    if (value) {
      const correctOptions: any[] = value.filter((option) => this.options.indexOf(option) !== -1);
      this._selectedOptions = correctOptions.length > this.maxSelections ? correctOptions.slice(0, this.maxSelections) : correctOptions;
    }
  }

  @Output() valueEmitter: EventEmitter<any> = new EventEmitter<any>();

  currentErrorMessage: string = this.errorMessage.error;
  itemSelected: string;
  showDropDown = true;
  hasError = false;
  alreadySelectedError = 'alreadySelected';
  optionRequiredError = 'optionRequired';

  ngControl: AbstractControl;
  @ViewChild('selectedItem') selectedItem: NgModel;

  _propagateChange = (value) => {};
  _onTouched = () => {};
  _touchFromSelect = () => {};

  constructor(private injector: Injector) { }

  ngOnInit() {
    this._setErrorMessages();
  }

  ngAfterContentInit() {
    if (this._selectedOptions.length > 0) {
      this.showDropDown = false;
    }
    const ngControl: NgControl = this.injector.get(NgControl, null);
    if (ngControl) {
      this.ngControl = ngControl.control;
      this.ngControl.setValue(this._selectedOptions);
      if (ngControl.name) {
        this.selectedItem.name = ngControl.name;
      }
    } else {
      this.valueEmitter.emit(this._selectedOptions);
    }
    setTimeout(() => {
      this._onTouched = this._touchFromSelect;
      this.selectedItem.valueAccessor.registerOnTouched(this._onTouched);
    }, 0);
  }

  optionSelected(item: string) {
    if (item) {
      const selection = <Selections>{};
      selection.select = item;
      if (this._checkCanAddAnother(item)) {
        this.displayInputs ? this._selectedOptions.push(selection) : this._selectedOptions.push(item);
        this.showDropDown = false;
        this.selectedItem.reset();
        this.hasError = false;
      } else {
        this.changeErrorTo('selected');
      }

      this.onTouched();
      this.onChange();
    }
  }

  private changeErrorTo(type: 'required' | 'selected') {
    if (type === 'selected') {
      this.currentErrorMessage = this.errorMessage.existingValue;
    } else {
      this.currentErrorMessage = this.errorMessage.error;
    }
    this.hasError = true;
  }

  _checkCanAddAnother(item: string) {
    if (this._selectedOptions.length > 0) {
      if (this._selectedOptions[0].select) {
        const duplicateArr = this._selectedOptions.filter((option: Selections) => option.select === item );
        return duplicateArr.length === 0;
      } else {
        return this._selectedOptions.indexOf(item) === -1;
      }
    } else {
      return true;
    }
  }

  removeItem(index: any) {
    this._selectedOptions.splice(index, 1);
    if (this._selectedOptions.length === 0) {
      if (this._isRequired) {
        this.changeErrorTo('required');
      }
      this.showDropDown = true;
      this.selectedItem.reset();
    } else {
      this.hasError = false;
      this.showDropDown = false;
    }
    this.onChange();
  }

  addAnother() {
    this.showDropDown = true;
  }

  private _setErrorMessages() {
    if (this.errorMessage.error === undefined) this.errorMessage.error = 'Please select a value';
    if (this.errorMessage.existingValue === undefined) this.errorMessage.existingValue = 'Option has already been selected';
  }

  inputChange(index, event) {
    this._selectedOptions[index].input = event;
  }

  setErrors() {
    if (this.hasError && this.ngControl && this.selectedItem) {
      this.ngControl.setErrors({ error: 'true' });
      this.selectedItem.control.setErrors({ error: 'true' });
    }
    this.selectedItem.control.markAsTouched();
  }

  onChange() {
    if (this.ngControl) {
      if (this._propagateChange) {
        if (this._selectedOptions.length === 0) {
          this._propagateChange('');
        } else {
          this._propagateChange(this._selectedOptions);
        }
        this.setErrors();
      }
    } else {
      this.valueEmitter.emit(this._selectedOptions);
    }
  }

  onTouched() {
    setTimeout(() => {
      if (this.selectedItem) {
        this.selectedItem.control.markAsTouched();
      }
    }, 0);
  }

  removeSelect() {
    this.showDropDown = false;
    this.selectedItem.reset();
    this.hasError = false;
    this.onChange();
  }

  writeValue(value: string): void {
    if (this.selectedItem) {
      this.selectedItem.valueAccessor.writeValue(value);
    }

    if (!this.ngControl && this._selectedOptions.length > 0) {
      this.valueEmitter.emit(this._selectedOptions);
    }
  }

  registerOnChange(fn: any): void {
    this._propagateChange = fn;
  }

  registerOnTouched(fn: any): void {
    this._touchFromSelect = () => {
      this.selectedItem.control.markAsTouched();
      fn();
    };
    this._onTouched = this._touchFromSelect;
  }
}
