import { BaseComponent } from './base.component';

describe('BaseComponent', () => {
  let component: BaseComponent;

  beforeEach(() => {
    component = new BaseComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the following properties', () => {
    expect(component._disabled).toBeNull();
    expect(component.value).toBeUndefined();
    expect(component._errMessage).not.toBeNull();
  });

  it('should set and get the value using the setter and getter functions', () => {
    component.value = 'okay';
    expect(component.value).toEqual('okay');
  });

  it('_errorMessage should have a default value', () => {
    expect(component._errMessage).toEqual('This field has an error!');
  });
});
