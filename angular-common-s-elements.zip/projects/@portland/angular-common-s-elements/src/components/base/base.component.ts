import { Input } from '@angular/core';

export class BaseComponent {
  protected _value: string;

  @Input('disabled') _disabled: Boolean | String = null;
  @Input('tabindex') _tabIndex: number;
  @Input('error') _errMessage = 'This field has an error!';
  @Input('value')
  set value(param: any) {
    if (!this._disabled) {
      this._value = param;
    }
  }
  get value() {
    return this._value;
  }
}
