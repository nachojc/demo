import { Component, NO_ERRORS_SCHEMA, OnInit, EventEmitter } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { expect } from 'chai';

import { DobComponent } from './dob.component';
import { CustomDate } from '../../models/dob/custom-date';
import { simulateEvent, elementInput, element } from '../../../../../../test-utils/test-helpers';

@Component({
  selector: 's-wrapper',
  template:
    `<form [formGroup]="form">
      <s-dob
        data-qa="dobContainer"
        formControlName="dobProperty"
        [displayErrors]="displayErrors"></s-dob>
    </form>`,
})
export class WrapperComponent implements OnInit {

  displayErrors: boolean;
  form: FormGroup;
  initialize: CustomDate = { day: '12', month: '11', year: '1988' };

  constructor(public fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.form = this.fb.group({
      dobProperty: [this.initialize]
    });
  }

  get dobProperty() { return this.form.get('dobProperty'); }
}

describe('DobComponent', () => {
  let component: WrapperComponent;
  let fixture: ComponentFixture<WrapperComponent>;
  let nativeElement: HTMLElement;

  const byDataQa = (value) => {
    return '[data-qa="' + value + '"]';
  };

  const addValueAndEventByDataQa = (dataQaValue: string, event: string, value?: number | string) => {
    const elem: HTMLInputElement = nativeElement.querySelector(byDataQa(dataQaValue));
    elem.value = value ? value.toString() : undefined;
    simulateEvent(event, elem);
    fixture.detectChanges();
  };

  const dobPropertyValue = () => component.form.controls.dobProperty.value;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        ReactiveFormsModule
      ],
      declarations: [DobComponent, WrapperComponent],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WrapperComponent);
    component = fixture.componentInstance;
    nativeElement = fixture.nativeElement;
  });

  describe('form', () => {
    describe('managing values', () => {
      describe('data pre-populated', () => {
        beforeEach(() => {
          fixture.detectChanges();
        });

        it('should read and fill data by default', () => {
          expect(elementInput(nativeElement, 'day').value).to.equal('12');
          expect(elementInput(nativeElement, 'month').value).to.equal('11');
          expect(elementInput(nativeElement, 'year').value).to.equal('1988');
        });

        it('should change the form whenever there is a blur event in the day', () => {
          addValueAndEventByDataQa('day', 'blur', 1);

          expect(dobPropertyValue().day).to.equal('1');
          expect(dobPropertyValue().month).to.equal('11');
          expect(dobPropertyValue().year).to.equal('1988');
        });

        it('should change the form whenever there is a blur event in the month', () => {
          addValueAndEventByDataQa('month', 'blur', 12);

          expect(dobPropertyValue().day).to.equal('12');
          expect(dobPropertyValue().month).to.equal('12');
          expect(dobPropertyValue().year).to.equal('1988');
        });

        it('should change the form whenever there is a blur event in the year', () => {
          addValueAndEventByDataQa('year', 'blur', 1999);

          expect(dobPropertyValue().day).to.equal('12');
          expect(dobPropertyValue().month).to.equal('11');
          expect(dobPropertyValue().year).to.equal('1999');
        });
      });

      describe('withtout data', () => {
        beforeEach(() => {
          component.initialize = null;
          fixture.detectChanges();
        });

        it('must display empty values', () => {
          expect(elementInput(nativeElement, 'day').value).to.equal('');
          expect(elementInput(nativeElement, 'month').value).to.equal('');
          expect(elementInput(nativeElement, 'year').value).to.equal('');
        });

        it('should change the form whenever there is a blur event in the day', () => {
          addValueAndEventByDataQa('day', 'blur', 1);

          expect(dobPropertyValue().day).to.equal('1');
          expect(dobPropertyValue().month).to.equal('');
          expect(dobPropertyValue().year).to.equal('');
        });

        it('should change the form whenever there is a blur event in the month', () => {
          addValueAndEventByDataQa('month', 'blur', 12);

          expect(dobPropertyValue().day).to.equal('');
          expect(dobPropertyValue().month).to.equal('12');
          expect(dobPropertyValue().year).to.equal('');
        });

        it('should change the form whenever there is a blur event in the year', () => {
          addValueAndEventByDataQa('year', 'blur', 1999);

          expect(dobPropertyValue().day).to.equal('');
          expect(dobPropertyValue().month).to.equal('');
          expect(dobPropertyValue().year).to.equal('1999');
        });
      });
    });

    describe('dirty, pristine, touched, valid, invalid', () => {
      describe('data pre-populated', () => {
        beforeEach(() => {
          fixture.detectChanges();
        });

        describe('touched status', () => {
          it('should be false by default', () => {
            expect(component.form.controls.dobProperty.touched).to.be.false;
          });

          describe('blur', () => {
            it('should be true for day', () => {
              addValueAndEventByDataQa('day', 'blur');

              expect(component.form.controls.dobProperty.touched).to.be.true;
            });

            it('should be true for month', () => {
              addValueAndEventByDataQa('month', 'blur');

              expect(component.form.controls.dobProperty.touched).to.be.true;
            });

            it('should be true for year', () => {
              addValueAndEventByDataQa('year', 'blur');

              expect(component.form.controls.dobProperty.touched).to.be.true;
            });
          });

          describe('keyup', () => {
            it('should be false for day', () => {
              addValueAndEventByDataQa('day', 'keyup');

              expect(component.form.controls.dobProperty.touched).to.be.false;
            });

            it('should be false for month', () => {
              addValueAndEventByDataQa('month', 'keyup');

              expect(component.form.controls.dobProperty.touched).to.be.false;
            });

            it('should be false for year', () => {
              addValueAndEventByDataQa('year', 'keyup');

              expect(component.form.controls.dobProperty.touched).to.be.false;
            });
          });
        });

        describe('dirty status', () => {
          it('should be false when user has not interacted with the control', () => {
            expect(component.form.controls.dobProperty.dirty).to.be.false;
          });

          it('should be activated when user has already interacted with day', () => {
            addValueAndEventByDataQa('day', 'blur', 1);

            expect(component.form.controls.dobProperty.dirty).to.be.true;
          });

          it('should be activated when user has already interacted with month', () => {
            addValueAndEventByDataQa('month', 'blur', 11);

            expect(component.form.controls.dobProperty.dirty).to.be.true;
          });

          it('should be activated when user has already interacted with year', () => {
            addValueAndEventByDataQa('year', 'blur', 1988);

            expect(component.form.controls.dobProperty.dirty).to.be.true;
          });
        });

        describe('pristine status', () => {
          it('should be acivated when user has not interacted with the control yet', () => {
            expect(component.form.controls.dobProperty.pristine).to.be.true;
          });

          it('should be false when user has interacted with the day', () => {
            addValueAndEventByDataQa('day', 'blur', 1);

            expect(component.form.controls.dobProperty.pristine).to.be.false;
          });

          it('should be false when user has interacted with the month', () => {
            addValueAndEventByDataQa('month', 'blur', 11);

            expect(component.form.controls.dobProperty.pristine).to.be.false;
          });

          it('should be false when user has interacted with the year', () => {
            addValueAndEventByDataQa('year', 'blur', 1988);

            expect(component.form.controls.dobProperty.pristine).to.be.false;
          });
        });
      });

      describe('withtout pre-population', () => {
        beforeEach(() => {
          component.initialize = null;
          fixture.detectChanges();
        });

        describe('touched status', () => {
          it('should be false by default', () => {
            expect(component.form.controls.dobProperty.touched).to.be.false;
          });

          describe('blur', () => {

            it('should be true for day', () => {
              addValueAndEventByDataQa('day', 'blur');

              expect(component.form.controls.dobProperty.touched).to.be.true;
            });

            it('should be true for month', () => {
              addValueAndEventByDataQa('month', 'blur');

              expect(component.form.controls.dobProperty.touched).to.be.true;
            });

            it('should be true for year', () => {
              addValueAndEventByDataQa('year', 'blur');

              expect(component.form.controls.dobProperty.touched).to.be.true;
            });

          });

          describe('keyup', () => {
            it('should be false for day', () => {
              addValueAndEventByDataQa('day', 'keyup');

              expect(component.form.controls.dobProperty.touched).to.be.false;
            });

            it('should be false for month', () => {
              addValueAndEventByDataQa('month', 'keyup');

              expect(component.form.controls.dobProperty.touched).to.be.false;
            });

            it('should be false for year', () => {
              addValueAndEventByDataQa('year', 'keyup');

              expect(component.form.controls.dobProperty.touched).to.be.false;
            });
          });
        });

        describe('dirty status', () => {
          it('should be false when user has not interacted with the control', () => {
            expect(component.form.controls.dobProperty.dirty).to.be.false;
          });

          it('should be activated when user has already interacted with day', () => {
            addValueAndEventByDataQa('day', 'blur', 1);

            expect(component.form.controls.dobProperty.dirty).to.be.true;
          });

          it('should be activated when user has already interacted with month', () => {
            addValueAndEventByDataQa('month', 'blur', 11);

            expect(component.form.controls.dobProperty.dirty).to.be.true;
          });

          it('should be activated when user has already interacted with year', () => {
            addValueAndEventByDataQa('year', 'blur', 1988);

            expect(component.form.controls.dobProperty.dirty).to.be.true;
          });
        });

        describe('pristine status', () => {
          it('should be acivated when user has not interacted with the control yet', () => {
            expect(component.form.controls.dobProperty.pristine).to.be.true;
          });

          it('should be false when user has interacted with the day', () => {
            addValueAndEventByDataQa('day', 'blur', 1);

            expect(component.form.controls.dobProperty.pristine).to.be.false;
          });

          it('should be false when user has interacted with the month', () => {
            addValueAndEventByDataQa('month', 'blur', 11);

            expect(component.form.controls.dobProperty.pristine).to.be.false;
          });

          it('should be false when user has interacted with the year', () => {
            addValueAndEventByDataQa('year', 'blur', 1988);

            expect(component.form.controls.dobProperty.pristine).to.be.false;
          });
        });
      });
    });
  });

  describe('validation', () => {
    const colorizeByField = (field?: string) => {
      if (field === 'day') {
        expect(element(nativeElement, 'day').getAttribute('class')).to.equal('center error');
        expect(element(nativeElement, 'month').getAttribute('class')).to.equal('center');
        expect(element(nativeElement, 'year').getAttribute('class')).to.equal('center');
      } else if (field === 'month') {
        expect(element(nativeElement, 'day').getAttribute('class')).to.equal('center');
        expect(element(nativeElement, 'month').getAttribute('class')).to.equal('center error');
        expect(element(nativeElement, 'year').getAttribute('class')).to.equal('center');
      } else if (field === 'year') {
        expect(element(nativeElement, 'day').getAttribute('class')).to.equal('center');
        expect(element(nativeElement, 'month').getAttribute('class')).to.equal('center');
        expect(element(nativeElement, 'year').getAttribute('class')).to.equal('center error');
      } else if (field === 'invalidDate') {
        expect(element(nativeElement, 'day').getAttribute('class')).to.equal('center error');
        expect(element(nativeElement, 'month').getAttribute('class')).to.equal('center error');
        expect(element(nativeElement, 'year').getAttribute('class')).to.equal('center error');
      } else {
        expect(element(nativeElement, 'day').getAttribute('class')).to.equal('center');
        expect(element(nativeElement, 'month').getAttribute('class')).to.equal('center');
        expect(element(nativeElement, 'year').getAttribute('class')).to.equal('center');
      }
    };

    describe('pre-populated', () => {
      beforeEach(() => {
        fixture.detectChanges();
      });

      describe('form', () => {
        it('should be valid by default', () => {
          expect(component.dobProperty.errors).to.be.null;
          expect(component.dobProperty.valid).to.be.true;
        });

        it('should be invalid when wrong day', () => {
          addValueAndEventByDataQa('day', 'blur', 32);

          expect(component.dobProperty.errors.dayFormat).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should be invalid when wrong month', () => {
          addValueAndEventByDataQa('month', 'blur', 13);

          expect(component.dobProperty.errors.monthFormat).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should be invalid when wrong year', () => {
          addValueAndEventByDataQa('year', 'blur', -155);

          expect(component.dobProperty.errors.yearFormat).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should be invalid when invalidDate', () => {
          addValueAndEventByDataQa('day', 'blur', 35);
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('year', 'blur', -155);

          expect(component.dobProperty.errors.invalidDate).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should allow leap years', () => {
          addValueAndEventByDataQa('day', 'blur', 29);
          addValueAndEventByDataQa('month', 'blur', 2);
          addValueAndEventByDataQa('year', 'blur', 1988);

          expect(component.dobProperty.errors).to.be.null;
          expect(component.dobProperty.valid).to.be.true;
        });

        it('should not allow 29 for none leap years', () => {
          addValueAndEventByDataQa('day', 'blur', 29);
          addValueAndEventByDataQa('month', 'blur', 2);
          addValueAndEventByDataQa('year', 'blur', 1987);

          expect(component.dobProperty.errors.dayFormat).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });
      });

      describe('error message', () => {
        it('should not display any message when correct date', () => {
          expect(element(nativeElement, 'day-error-message')).to.not.exist;
          expect(element(nativeElement, 'month-error-message')).to.not.exist;
          expect(element(nativeElement, 'year-error-message')).to.not.exist;
          expect(element(nativeElement, 'invalidDate-error-message')).to.not.exist;
        });

        it('displays day message when is invalid', () => {
          addValueAndEventByDataQa('day', 'blur', 32);

          expect(element(nativeElement, 'day-error-message')).to.exist;
        });

        it('displays month message when is invalid', () => {
          addValueAndEventByDataQa('month', 'blur', 13);

          expect(element(nativeElement, 'month-error-message')).to.exist;
        });

        it('displays year message when is invalid', () => {
          addValueAndEventByDataQa('year', 'blur', 20);

          expect(element(nativeElement, 'invalidDate-error-message')).to.exist;
        });

        it('displays invalid date message when is invalid', () => {
          addValueAndEventByDataQa('day', 'blur', 32);
          addValueAndEventByDataQa('year', 'blur', 19);

          expect(element(nativeElement, 'invalidDate-error-message')).to.exist;
        });
      });
    });

    describe('non pre-populated', () => {
      beforeEach(() => {
        component.initialize = null;
        fixture.detectChanges();
      });

      describe('form', () => {
        it('should be invalid by default', () => {
          expect(component.dobProperty.errors.invalidDate).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should be invalid when wrong day', () => {
          addValueAndEventByDataQa('day', 'blur', 32);

          expect(component.dobProperty.errors.invalidDate).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should be invalid when wrong month', () => {
          addValueAndEventByDataQa('month', 'blur', 13);

          expect(component.dobProperty.errors.invalidDate).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should be invalid when wrong year', () => {
          addValueAndEventByDataQa('year', 'blur', -155);

          expect(component.dobProperty.errors.invalidDate).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should be invalid when invalidDate', () => {
          addValueAndEventByDataQa('day', 'blur', 35);
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('year', 'blur', -155);

          expect(component.dobProperty.errors.invalidDate).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });

        it('should allow leap years', () => {
          addValueAndEventByDataQa('day', 'blur', 29);
          addValueAndEventByDataQa('month', 'blur', 2);
          addValueAndEventByDataQa('year', 'blur', 1988);

          expect(component.dobProperty.errors).to.be.null;
          expect(component.dobProperty.valid).to.be.true;
        });

        it('should not allow 29 for none leap years', () => {
          addValueAndEventByDataQa('day', 'blur', 29);
          addValueAndEventByDataQa('month', 'blur', 2);
          addValueAndEventByDataQa('year', 'blur', 1987);

          expect(component.dobProperty.errors.dayFormat).to.be.true;
          expect(component.dobProperty.invalid).to.be.true;
        });
      });

      describe('error message', () => {
        it('should not display any message by default', () => {
          expect(element(nativeElement, 'day-error-message')).to.not.exist;
          expect(element(nativeElement, 'month-error-message')).to.not.exist;
          expect(element(nativeElement, 'year-error-message')).to.not.exist;
          expect(element(nativeElement, 'invalidDate-error-message')).to.not.exist;
        });

        it('displays day message when day is invalid', () => {
          const invalidDay = 32;

          addValueAndEventByDataQa('day', 'blur', invalidDay);

          expect(nativeElement.querySelector(byDataQa('day-error-message'))).to.exist;
        });

        it('displays month message when month is invalid', () => {
          const invalidMonth = 13;

          addValueAndEventByDataQa('month', 'blur', invalidMonth);

          expect(nativeElement.querySelector(byDataQa('month-error-message'))).to.exist;
        });

        it('displays year message when year is invalid', () => {
          const invalidYear = 1799;

          addValueAndEventByDataQa('year', 'blur', invalidYear);

          expect(nativeElement.querySelector(byDataQa('year-error-message'))).to.exist;
        });

        describe('combination of date fields errors', () => {
          it('should display date error message when invalid day & month are entered', () => {
            addValueAndEventByDataQa('day', 'blur', 32);
            addValueAndEventByDataQa('month', 'blur', 13);

            expect(nativeElement.querySelector(byDataQa('invalidDate-error-message'))).to.exist;
          });

          it('should display date error message when invalid day & year are entered', () => {
            addValueAndEventByDataQa('day', 'blur', 32);
            addValueAndEventByDataQa('year', 'blur', 1799);

            expect(nativeElement.querySelector(byDataQa('invalidDate-error-message'))).to.exist;
          });

          it('should display date error message when invalid month & year are entered', () => {
            addValueAndEventByDataQa('month', 'blur', 13);
            addValueAndEventByDataQa('year', 'blur', 1799);

            expect(nativeElement.querySelector(byDataQa('invalidDate-error-message'))).to.exist;
          });
        });

        it('displays year message when is invalid and ', () => {
          addValueAndEventByDataQa('day', 'blur', 29);
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('year', 'blur', 18);

          expect(nativeElement.querySelector(byDataQa('year-error-message'))).to.exist;
        });
      });
    });

    describe('border color when there is an error', () => {
      beforeEach(() => {
        component.initialize = null;
        fixture.detectChanges();
      });

      describe('groups validations', () => {
        it('should not have any error by default', () => {
          colorizeByField();
        });

        it('should add error class when day is wrong format', () => {
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('day', 'blur', 32);
          addValueAndEventByDataQa('year', 'blur', 1988);

          colorizeByField('day');
        });

        it('should add error class when month is wrong format', () => {
          addValueAndEventByDataQa('month', 'blur', 13);
          addValueAndEventByDataQa('day', 'blur', 30);
          addValueAndEventByDataQa('year', 'blur', 1988);

          colorizeByField('invalidDate');
        });

        it('should add error class when year is wrong format', () => {
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('day', 'blur', 30);
          addValueAndEventByDataQa('year', 'blur', -155);

          colorizeByField('year');
        });

        it('should add error class when invalid day & year', () => {
          addValueAndEventByDataQa('day', 'blur', 35);
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('year', 'blur', 1799);

          colorizeByField('invalidDate');
        });

        describe('when the user starts filling the date of birth, it should not appear any error if the data is valid', () => {
          it('should not colorize the boder when until the user touch all the inputs', () => {
            addValueAndEventByDataQa('day', 'blur', 23);
            colorizeByField();
            addValueAndEventByDataQa('month', 'blur', 11);
            colorizeByField();
            addValueAndEventByDataQa('year', 'blur', 1988);
            colorizeByField();
          });
        });

        describe('day', () => {
          beforeEach(() => {
            addValueAndEventByDataQa('day', 'blur', 23);
            addValueAndEventByDataQa('month', 'blur', 11);
            addValueAndEventByDataQa('year', 'blur', 1988);
          });

          describe('a user has inputed right data and add wrong data', () => {
            it('wrong day', () => {
              addValueAndEventByDataQa('day', 'blur', 45);

              colorizeByField('day');
            });

            it('empty day', () => {
              addValueAndEventByDataQa('day', 'blur', '');

              colorizeByField('day');
            });
          });
        });

        describe('fill day, fill month and focus on year. It should color the border', () => {
          it('should not colorize the border until the user touches all the inputs', () => {
            addValueAndEventByDataQa('day', 'blur', 23);
            addValueAndEventByDataQa('month', 'blur', 11);
            addValueAndEventByDataQa('year', 'blur', 1989);
            colorizeByField();
          });
        });

        it('should colorize month when it is the only field invalid', () => {
          addValueAndEventByDataQa('day', 'blur', 12);
          addValueAndEventByDataQa('month', 'blur', 13);
          addValueAndEventByDataQa('year', 'blur', 1801);

          colorizeByField('month');
        });

        it('should colorize day when it is the only field invalid', () => {
          addValueAndEventByDataQa('day', 'blur', 32);
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('year', 'blur', 1801);

          colorizeByField('day');
        });

        it('should colorize year when it is the only field invalid', () => {
          addValueAndEventByDataQa('day', 'blur', 29);
          addValueAndEventByDataQa('month', 'blur', 12);
          addValueAndEventByDataQa('year', 'blur', 1799);

          colorizeByField('year');
        });

        it('should colorize all date fields when any of the two fields are invalid', () => {
          addValueAndEventByDataQa('day', 'blur', 32);
          addValueAndEventByDataQa('month', 'blur', 13);
          addValueAndEventByDataQa('year', 'blur', 1800);

          colorizeByField('invalidDate');
        });
      });

      describe('fields validations', () => {
        it('colorize day field when day is invalid', () => {
          const invalidDay = 32;

          addValueAndEventByDataQa('day', 'blur', invalidDay);

          expect(element(nativeElement, 'day').getAttribute('class')).to.equal('center error');
        });

        it('colorize month field when month is invalid', () => {
          const invalidMonth = 13;

          addValueAndEventByDataQa('month', 'blur', invalidMonth);

          expect(element(nativeElement, 'month').getAttribute('class')).to.equal('center error');
        });

        it('colorize year message when year is invalid', () => {
          const invalidYear = 1799;

          addValueAndEventByDataQa('year', 'blur', invalidYear);

          expect(element(nativeElement, 'year').getAttribute('class')).to.equal('center error');
        });
      });
    });

    describe('simulate markAsTouched', () => {
      beforeEach(() => {
        component.initialize = null;
        fixture.detectChanges();
      });

      it('should display error message when the emit an event', () => {
        component.displayErrors = true;
        fixture.detectChanges();
        expect(nativeElement.querySelector(byDataQa('invalidDate-error-message'))).to.exist;
        colorizeByField('invalidDate');
      });
    });
  });
});
