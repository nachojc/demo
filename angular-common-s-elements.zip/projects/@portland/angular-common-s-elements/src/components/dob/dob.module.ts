import { NgModule } from '@angular/core';
import { DobComponent } from './dob.component';
import { CommonModule } from '@angular/common';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    DobComponent,
  ],
  exports: [
    DobComponent
  ]
})

export class SDobComponentModule { }
