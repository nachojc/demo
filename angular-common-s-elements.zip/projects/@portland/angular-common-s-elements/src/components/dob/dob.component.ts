import { Component, ElementRef, forwardRef, Input, OnInit, Renderer2 } from '@angular/core';
import { ControlValueAccessor, FormControl, NG_VALIDATORS, NG_VALUE_ACCESSOR, Validator } from '@angular/forms';
import { CustomDate } from '../../models/dob/custom-date';
import { FieldsValidation } from './validators/fields/fields-validation';
import { GroupDateValidator } from './validators/groups/group-date-validator';

const CUSTOM_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => DobComponent),
  multi: true,
};

const CUSTOM_VALIDATORS: any = {
  provide: NG_VALIDATORS,
  useExisting: forwardRef(() => DobComponent),
  multi: true,
};

@Component({
  selector: 's-dob',
  templateUrl: './dob.component.html',
  styleUrls: ['./dob.component.css'],
  providers: [
    CUSTOM_VALUE_ACCESSOR,
    CUSTOM_VALIDATORS
  ],

})
export class DobComponent implements OnInit, ControlValueAccessor, Validator {
  onChange: Function;
  onTouched: Function;
  errorMessage: any;

  private dayFlag: boolean;
  private monthFlag: boolean;
  private yearFlag: boolean;

  @Input()
  set displayErrors(value: boolean) {
    if (value !== undefined && value !== null) {
      this.dayFlag = this.monthFlag = this.yearFlag = true;
    }
    this.validate();
  }

  constructor(
    private elementRef: ElementRef,
    private renderer: Renderer2) {
    this.onChange = (_: any) => { };
    this.onTouched = () => { };
  }

  ngOnInit() {
  }

  writeValue(valueForm?: CustomDate | null): void {
    if (valueForm) {
      this.day = +valueForm.day;
      this.month = +valueForm.month;
      this.year = +valueForm.year;
      this.dayFlag = this.monthFlag = this.yearFlag = true;
    }
    this.onChange(this.value);
  }

  validate(control?: FormControl): any {
    const error = new GroupDateValidator(+this.day, +this.month, +this.year).validateDate;
    this.validateIndividualFields();
    this.validateFieldGroups(error);
    return error;
  }

  registerOnChange(fn: any): void {
    this.onChange = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  blurOnDay(): void {
    this.dayFlag = true;
    this.writeValue();
    this.onTouched(this.value);
  }

  blurOnMonth(): void {
    this.monthFlag = true;
    this.writeValue();
    this.onTouched(this.value);
  }

  blurOnYear(): void {
    this.yearFlag = true;
    this.writeValue();
    this.onTouched(this.value);
  }

  get value(): CustomDate { return { day: String(this.day), month: String(this.month), year: String(this.year) }; }

  private validateFieldGroups(error: any): void {
    if (this.dayFlag && this.monthFlag && this.yearFlag) {
      this.errorMessage = error;
      this.initializeView(error);
    }
  }

  private initializeView(errorMessage: any): void {
    this.removeErrorClass = this.dayElement;
    this.removeErrorClass = this.monthElement;
    this.removeErrorClass = this.yearElement;

    if (errorMessage) {
      if (errorMessage.dayFormat) {
        this.addErrorClass = this.dayElement;
      }
      if (errorMessage.monthFormat) {
        this.addErrorClass = this.monthElement;
      }
      if (errorMessage.yearFormat) {
        this.addErrorClass = this.yearElement;
      }
      if (errorMessage.invalidDate) {
        this.addErrorClass = this.dayElement;
        this.addErrorClass = this.monthElement;
        this.addErrorClass = this.yearElement;
      }
    }
  }

  private validateIndividualFields(): void {
    let errorCounter = { value: 0 };
    this.validDay(errorCounter);
    this.validMonth(errorCounter);
    this.validYear(errorCounter);
    errorCounter = { value: 0 };
  }

  private validDay(counter: any): void {
    if (this.dayFlag && (FieldsValidation.isNonNumeric(String(this.day)) || FieldsValidation.isInvalidDay(this.day))) {
      this.errorMessage = counter.value > 0 ? { invalidDate: true } : { dayFormat: true };
      this.addErrorClass = this.dayElement;
      counter.value++;
    }
  }

  private validMonth(counter: any): void {
    if (this.monthFlag && (FieldsValidation.isNonNumeric(String(this.month)) || FieldsValidation.isInvalidMonth(this.month))) {
      this.errorMessage = counter.value > 0 ? { invalidDate: true } : { monthFormat: true };
      this.addErrorClass = this.monthElement;
      counter.value++;
    }
  }

  private validYear(counter: any): void {
    if (this.yearFlag && (FieldsValidation.isNonNumeric(String(this.year)) || FieldsValidation.isInvalidYear(this.year, 1800))) {
      this.errorMessage = counter.value > 0 ? { invalidDate: true } : { yearFormat: true };
      this.addErrorClass = this.yearElement;
      counter.value++;
    }
  }

  private get day(): number { return this.dayElement.value; }

  private set day(value: number) { this.setProperty(this.dayElement, value); }

  private get dayElement(): any { return this.querySelector('#day'); }

  private get month(): number { return this.monthElement.value; }

  private set month(value: number) { this.setProperty(this.monthElement, value); }

  private get monthElement(): any { return this.querySelector('#month'); }

  private get year(): number { return this.yearElement.value; }

  private set year(value: number) { this.setProperty(this.yearElement, value); }

  private get yearElement(): any { return this.querySelector('#year'); }

  private set addErrorClass(element: any) { this.renderer.addClass(element, 'error'); }

  private set removeErrorClass(element: any) { this.renderer.removeClass(element, 'error'); }

  private querySelector = (value: string) => this.elementRef.nativeElement.querySelector(value);

  private setProperty = (element: any, value: number) => this.renderer.setProperty(element, 'value', value);

}
