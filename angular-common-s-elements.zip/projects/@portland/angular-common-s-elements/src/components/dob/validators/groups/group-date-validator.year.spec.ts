import { expect } from 'chai';

import { GroupDateValidator } from './group-date-validator';

describe('DateValidator - years', () => {
  it('should be invalid when is less than 1', () => {
    const result = new GroupDateValidator(1, 11, 0).validateDate;

    expect(result.yearFormat).to.be.true;
  });

  it('should be invalid when the value is undefined', () => {
    const result = new GroupDateValidator(1, 11, undefined).validateDate;

    expect(result.yearFormat).to.be.true;
  });

  it('should be invalid when the value is null', () => {
    const result = new GroupDateValidator(1, 11, null).validateDate;

    expect(result.yearFormat).to.be.true;
  });

  it('should be invalid when year is less than 1800', () => {
    const result = new GroupDateValidator(12, 12, 1799).validateDate;

    expect(result.yearFormat).to.be.true;
  });

  it('should be valid when is bettween 1 and 12', () => {
    const result = new GroupDateValidator(10, 11, 1988).validateDate;

    expect(result).to.be.null;
  });
});
