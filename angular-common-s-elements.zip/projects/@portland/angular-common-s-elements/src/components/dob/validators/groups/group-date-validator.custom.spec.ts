import { expect } from 'chai';
import { GroupDateValidator } from './group-date-validator';

describe('DateValidator - years', () => {
  const wrongYear: number = new Date().getFullYear() - 1000;

  it('returns invalid date message when month and day are invalid', () => {
    const result = new GroupDateValidator(32, 13, 1).validateDate;

    expect(result.invalidDate).to.be.true;
  });

  it('returns invalid date message when year and day are invalid', () => {
    const result = new GroupDateValidator(0, 1, wrongYear).validateDate;

    expect(result.invalidDate).to.be.true;
  });

  it('returns invalid date message when month and year are invalid', () => {
    const result = new GroupDateValidator(1, 0, wrongYear).validateDate;

    expect(result.invalidDate).to.be.true;
  });

  it('returns invalid date message when month and year are invalid', () => {
    const result = new GroupDateValidator(0, 0, wrongYear).validateDate;

    expect(result.invalidDate).to.be.true;
  });

  describe('leap years', () => {
    it('should be invalid the 29th of February 2015 when is not Leap year', () => {
      const result = new GroupDateValidator(29, 2, 2015).validateDate;

      expect(result.dayFormat).to.be.true;
    });

    it('should be valid the 29th of February 2016 when is not Leap year', () => {
      const result = new GroupDateValidator(29, 2, 2016).validateDate;

      expect(result).to.be.null;
    });
  });

  describe('future dates', () => {
    it('should return true if entered date is greater than current date', () => {
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);

      const result = new GroupDateValidator(
        tomorrow.getUTCDate(),
        tomorrow.getUTCMonth() + 1,
        tomorrow.getUTCFullYear()).validateDate;

      expect(result.invalidDate).to.be.true;
    });
  });
});
