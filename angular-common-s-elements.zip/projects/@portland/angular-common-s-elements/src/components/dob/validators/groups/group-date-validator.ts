export class GroupDateValidator {
    private day: number;
    private month: number;
    private year: number;
    private lowerLimitYear: number;
    private daysPerMonth: number[] = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    constructor(day: number, month: number, year: number, lowerLimitYear?: number) {
      this.day = day;
      this.month = month;
      this.year = year;
      this.lowerLimitYear = lowerLimitYear ? +lowerLimitYear : 1800;

      if (this.isLeapYear) {
          this.daysPerMonth[1] = 29;
      }
    }

    get validateDate(): any {
      const parsedDate = new Date(`${this.month}/${this.day}/${this.year}`);

      if (parsedDate > new Date()) {
        return { invalidDate: true };
      }

      const dayFormatFlag = this.dayFormat;
      const monthFormatFlag = this.monthFormat;
      const yearFormatFlag = this.yearFormat;
      if (yearFormatFlag && monthFormatFlag || yearFormatFlag && dayFormatFlag || dayFormatFlag && monthFormatFlag) {
          return { invalidDate: true };
      }

      if (dayFormatFlag) {
          return { dayFormat: true };
      }

      if (monthFormatFlag) {
          return { monthFormat: true };
      }

      if (yearFormatFlag) {
          return { yearFormat: true };
      }
      return null;
    }

    private get dayFormat(): boolean {
      const isLowerLimitPassed = !this.day || this.day < 1;
      const isUnknownDay = this.monthFormat && this.day > 27;
      const isUpperLimitPassed = isUnknownDay ? true : this.day > this.daysPerMonth[this.month - 1];

      return isLowerLimitPassed || isUpperLimitPassed;
    }

    private get monthFormat(): boolean {
      return !this.month || this.month < 1 || this.month > 12;
    }

    private get yearFormat(): boolean {
      return !this.year || this.year < 1 || this.year < this.lowerLimitYear;
    }

    private get isLeapYear() {
      if ((this.year < this.lowerLimitYear) || (this.year > 2100)) {
          return false;
      }
      return (((this.year % 4 === 0) && (this.year % 100 !== 0)) || (this.year % 400 === 0));
    }
}
