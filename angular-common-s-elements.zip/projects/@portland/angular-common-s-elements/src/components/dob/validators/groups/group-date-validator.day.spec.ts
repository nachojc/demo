import { expect } from 'chai';

import { GroupDateValidator } from './group-date-validator';

describe('DateValidator- day validation', () => {
  describe('group validation', () => {
    it('should be invalid when is less than 1', () => {
      const result = new GroupDateValidator(0, 11, 1989).validateDate;

      expect(result.dayFormat).to.be.true;
    });

    it('should be invalid when the value is undefined', () => {
      const result = new GroupDateValidator(undefined, 11, 1989).validateDate;

      expect(result.dayFormat).to.be.true;
    });

    it('should be invalid when the value is null', () => {
      const result = new GroupDateValidator(null, 11, 1989).validateDate;

      expect(result.dayFormat).to.be.true;
    });

    describe('months limits', () => {
      describe('January', () => {
        it('invalid more than 31', () => {
          const result = new GroupDateValidator(32, 1, 1989).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 31', () => {
          const result = new GroupDateValidator(31, 1, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('February', () => {
        it('invalid more than 28', () => {
          const result = new GroupDateValidator(29, 2, 1989).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 28', () => {
          const result = new GroupDateValidator(28, 2, 1989).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('March', () => {
        it('invalid more than 31', () => {
          const result = new GroupDateValidator(32, 3, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 31', () => {
          const result = new GroupDateValidator(31, 3, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('April', () => {
        it('invalid more than 30', () => {
          const result = new GroupDateValidator(31, 4, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 30', () => {
          const result = new GroupDateValidator(30, 4, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('May', () => {
        it('invalid more than 31', () => {
          const result = new GroupDateValidator(32, 5, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 31', () => {
          const result = new GroupDateValidator(31, 5, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('June', () => {
        it('invalid more than 30', () => {
          const result = new GroupDateValidator(31, 6, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 30', () => {
          const result = new GroupDateValidator(30, 6, 1988).validateDate;

          expect(result).to.be.null;
        });
      });
      describe('July', () => {
        it('invalid more than 31', () => {
          const result = new GroupDateValidator(32, 7, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 31', () => {
          const result = new GroupDateValidator(31, 7, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('Augoust', () => {
        it('invalid more than 31', () => {
          const result = new GroupDateValidator(32, 8, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 31', () => {
          const result = new GroupDateValidator(31, 8, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('September', () => {
        it('invalid more than 30', () => {
          const result = new GroupDateValidator(31, 9, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 30', () => {
          const result = new GroupDateValidator(30, 9, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('October', () => {
        it('invalid more than 31', () => {
          const result = new GroupDateValidator(32, 10, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 31', () => {
          const result = new GroupDateValidator(31, 10, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('November', () => {
        it('invalid more than 30', () => {
          const result = new GroupDateValidator(31, 11, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 30', () => {
          const result = new GroupDateValidator(30, 11, 1988).validateDate;

          expect(result).to.be.null;
        });
      });

      describe('December', () => {
        it('invalid more than 31', () => {
          const result = new GroupDateValidator(32, 12, 1988).validateDate;

          expect(result.dayFormat).to.be.true;
        });

        it('valid less than 31', () => {
          const result = new GroupDateValidator(31, 12, 1988).validateDate;

          expect(result).to.be.null;
        });
      });
    });
  });
});
