export class FieldsValidation {

    public static isInvalidDay(day: number): boolean {
        return !day || day < 1 || day > 31;
    }

    public static isInvalidMonth(month: number): boolean {
        return !month || month < 1 || month > 12;
    }

    public static isInvalidYear(year: number, lowerLimitYear: number): boolean {
        return !year || !lowerLimitYear || year < lowerLimitYear;
    }

    public static isNonNumeric(date: string): boolean {
        return !new RegExp('^[0-9]*$').test(date);
    }
}
