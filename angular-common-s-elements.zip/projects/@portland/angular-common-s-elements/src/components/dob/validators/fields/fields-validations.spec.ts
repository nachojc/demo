import { expect } from 'chai';
import { FieldsValidation } from './fields-validation';

describe('Fields validations', () => {
    describe('day', () => {
        it('should return true when day is less than 1', () => {
            const day = 0;

            const result = FieldsValidation.isInvalidDay(day);

            expect(result).to.be.true;
        });

        it('should return false when day is between 1 and 31', () => {
            const day = 12;

            const result = FieldsValidation.isInvalidDay(day);

            expect(result).to.be.false;
        });

        it('should return true when the day is undefined', () => {
            const day = undefined;

            const result = FieldsValidation.isInvalidDay(day);

            expect(result).to.be.true;
        });

        it('should return true when the day is null', () => {
            const day = null;

            const result = FieldsValidation.isInvalidDay(day);

            expect(result).to.be.true;
        });

        it('should return true when the day is greater than 31', () => {
            const day = 32;

            const result = FieldsValidation.isInvalidDay(day);

            expect(result).to.be.true;
        });

        it('should return true when day is alphanumeric', () => {

            const day = 'date';

            const result = FieldsValidation.isNonNumeric(day);

            expect(result).to.be.true;
        });
    });

    describe('month', () => {
        it('should return true when month is less than 1', () => {
            const month = 0;

            const result = FieldsValidation.isInvalidMonth(month);

            expect(result).to.be.true;
        });

        it('should return false when month is between 1 and 12', () => {
            const month = 12;

            const result = FieldsValidation.isInvalidMonth(month);

            expect(result).to.be.false;
        });

        it('should return true when the value is undefined', () => {
            const month = undefined;

            const result = FieldsValidation.isInvalidMonth(month);

            expect(result).to.be.true;
        });

        it('should return true when the value is null', () => {
            const month = null;

            const result = FieldsValidation.isInvalidMonth(month);

            expect(result).to.be.true;
        });

        it('should return true when the value is greater than 31', () => {
            const month = 32;

            const result = FieldsValidation.isInvalidMonth(month);

            expect(result).to.be.true;
        });
    });

    describe('year', () => {
        it('should return true when year is less than a specific Value', () => {
            const year = 1799;
            const minYear = 1800;

            const result = FieldsValidation.isInvalidYear(year, minYear);

            expect(result).to.be.true;
        });

        it('should return false when year is greater than minYear', () => {
            const year = 1802;
            const minYear = 1800;

            const result = FieldsValidation.isInvalidYear(year, minYear);

            expect(result).to.be.false;
        });

        it('should return true when year is undefined', () => {
            const year = undefined;
            const minYear = 1800;

            const result = FieldsValidation.isInvalidYear(year, minYear);

            expect(result).to.be.true;
        });

        it('should return true when minYear is undefined', () => {
            const year = 1900;
            const minYear = undefined;

            const result = FieldsValidation.isInvalidYear(year, minYear);

            expect(result).to.be.true;
        });
    });
});
