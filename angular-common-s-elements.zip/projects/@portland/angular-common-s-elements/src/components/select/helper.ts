import { SelectorModel } from './selector.model';

export function getElements(filter: string, items: SelectorModel[], start: boolean = true) {
    return (!!filter && filter.length) ?
        start ?
            items.filter( item => item.label.toLowerCase().substr(0, filter.length) === filter.toLowerCase()) :
            items.filter( item => item.label.toLowerCase().indexOf(filter.toLowerCase()) !== -1) :
        items;
}
export function getIndexSelected(items) {
    return items.findIndex( (obj: SelectorModel) => obj.active );
}





export const MAC_ENTER = 3;
export const BACKSPACE = 8;
export const TAB = 9;
export const ENTER = 13;
export const SHIFT = 16;
export const CONTROL = 17;
export const ALT = 18;
export const ESCAPE = 27;
export const SPACE = 32;
export const LEFT_ARROW = 37;
export const UP_ARROW = 38;
export const RIGHT_ARROW = 39;
export const DOWN_ARROW = 40;
