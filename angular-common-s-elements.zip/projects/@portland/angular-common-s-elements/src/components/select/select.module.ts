import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SelectComponent } from './select.component';
import { SelectorFilterPipe } from './filter.pipe';

@NgModule({
  imports: [
    CommonModule,
    FormsModule
  ],
  declarations: [
    SelectComponent,
    SelectorFilterPipe
  ],
  exports: [
    SelectComponent
  ]
})
export class SSelectComponentModule {}
