export interface SelectorModel {
    label: string;
    value: any;
    active?: boolean;
}


export interface HelpLabelModel {
    defaultValue: string;
    help: string;
    optional?: string;
  }

export interface OptionalLabelModel {
    defaultValue: string;
    optional: string;
}
