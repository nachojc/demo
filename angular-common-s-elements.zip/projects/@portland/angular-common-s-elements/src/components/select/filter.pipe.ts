import { Pipe, PipeTransform } from '@angular/core';
import { SelectorModel } from './selector.model';
import { getElements } from './helper';

@Pipe({
    name: 'selectorFilter',
    pure: false
})
export class SelectorFilterPipe implements PipeTransform {
    transform(items: SelectorModel[], filter: string, start = true): any {
        return  getElements(filter, items, start);
    }
}
