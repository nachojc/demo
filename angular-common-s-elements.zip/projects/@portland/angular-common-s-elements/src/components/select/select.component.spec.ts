import { Component, DebugElement, ViewChild } from '@angular/core';
import { async, ComponentFixture, fakeAsync, flush, TestBed, tick } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { SelectorFilterPipe } from './filter.pipe';
// import { EventEmitter, Component } from '@angular/core';
import { SelectComponent } from './select.component';
import { SSelectComponentModule } from './select.module';

const fakeEvent = {
    preventDefault: jasmine.createSpy('prevent default')
};

describe('SelectComponent in Stand Alone:', () => {
    let fixture: ComponentFixture<SelectComponent>;
    let component: SelectComponent;
    let sSalector: DebugElement;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [SelectComponent, SelectorFilterPipe],
            imports: [FormsModule]
        }).compileComponents();

        fixture = TestBed.createComponent(SelectComponent);
        component = fixture.componentInstance;
        sSalector = fixture.debugElement;
        fixture.detectChanges();
    }));


    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should populete the placeholder', () => {
        component.placeholder = 'hi';
        const placeholder = sSalector.query(By.css('.placeholder')).nativeElement;
        fixture.detectChanges();

        expect(placeholder.textContent.substring(0, 2)).toEqual('hi');
    });

    it('should populete the id', () => {
        component.id = 'hi';
        const id = sSalector.nativeElement;

        fixture.detectChanges();
        expect(id.getAttribute('id')).toEqual('hi');
    });

    it('should label in all cases', () => {
        component.label = 'hi';
        component.required = true;
        fixture.detectChanges();
        let labels = sSalector.queryAll(By.css('label span'));

        expect(labels.length).toEqual(1);
        expect(labels[0].nativeElement.textContent).toEqual('hi');

        component.required = false;
        fixture.detectChanges();
        labels = sSalector.queryAll(By.css('label span'));
        expect(labels[1].nativeElement.textContent).toEqual('(if applicable)');

        component.required = false;
        fixture.detectChanges();

        component.label = {'defaultValue': 'HI', 'optional': '', 'help': 'me'};
        fixture.detectChanges();
        labels = sSalector.queryAll(By.css('label span'));

        expect(labels.length).toEqual(3);
        expect(labels[0].nativeElement.textContent).toEqual('HI');
        expect(labels[1].nativeElement.textContent).toEqual('');
        expect(labels[2].nativeElement.textContent).toEqual('me');
    });
});

@Component({
    template: `
    <s-select [options]="optionsValue"
        [value]="valueInput"
        [autoComplete]="autoCompleteValue"
        (valueChange)="onChange($event)"
        [id]="idValue"
        [disabled]="disabledValue"></s-select>
    `
  })
  class TestBasicComponent {
    optionsValue = ['a', 'd'];
    disabledValue = false;
    autoCompleteValue = true;
    valueInput;
    idValue = 0;

    @ViewChild(SelectComponent) select: SelectComponent;

    value: string;
    onChange(e) { this.value = e; }
  }

describe('SelectComponent in Stand Alone integration:', () => {
    let fixture: ComponentFixture<TestBasicComponent>;
    let component: TestBasicComponent;
    let sSalector: DebugElement;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [TestBasicComponent],
            imports: [FormsModule, SSelectComponentModule]
        }).compileComponents();

        fixture = TestBed.createComponent(TestBasicComponent);
        component = fixture.componentInstance;
        sSalector = fixture.debugElement;
        fixture.detectChanges();
    }));

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should populate the value when we do click in one option', () => {
        component.select.populate({label: 'a', value: 'a'});
        fixture.detectChanges();

        expect(component.value).toEqual('a');
    });
    it('should not populate the value when is disabled', () => {
        component.disabledValue = true;
        fixture.detectChanges();
        component.select.populate({label: 'a', value: 'a'});

        fixture.detectChanges();

        expect(component.value).not.toEqual('a');
    });

    it('should populate init the value and have it active', () => {

        component.valueInput = 'a';
        fixture.detectChanges();

        expect(component.select.value).toEqual({ label: 'a', value: 'a', active: true });
    });
});

@Component({
    template: `
    <s-select [options]="optionsValue"
        [autoComplete]="autoCompleteValue"
        [(ngModel)]="valueModel"
        [required]="requiredValue"
        [includedInFilter]="includedInFilterValue"
        [error-message]="errorMessageValue"
        [disabled]="disabledValue"></s-select>
    `
  })
  class TestBasicTemplateComponent {
        optionsValue: any = ['a', 'd'];
        autoCompleteValue = true;
        valueModel: string;
        requiredValue = false;
        includedInFilterValue = false;
        errorMessageValue = 'Error';
        disabledValue = false;

        @ViewChild(SelectComponent) select: SelectComponent;

}

describe('SelectComponent in Template mode integration:', () => {
    let fixture: ComponentFixture<TestBasicTemplateComponent>;
    let component: TestBasicTemplateComponent;
    let sSalector: DebugElement;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [TestBasicTemplateComponent],
            imports: [FormsModule, SSelectComponentModule]
        }).compileComponents();

        fixture = TestBed.createComponent(TestBasicTemplateComponent);
        component = fixture.componentInstance;
        sSalector = fixture.debugElement.query(By.directive(SelectComponent));
        fixture.detectChanges();

    }));
    afterEach(() => {
        fakeEvent.preventDefault.calls.reset();
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should to have one empty array if options is empty or array of objects', async () => {
        component.optionsValue = null;
        fixture.detectChanges();

        expect(component.select.options.length).toEqual(0);

        component.optionsValue = [ 1, 2 ];
        fixture.detectChanges();

        expect(component.select.options).toEqual([{'label': 1, 'value': 1}, {'label': 2, 'value': 2}]);

        component.optionsValue = {};
        fixture.detectChanges();
        expect(component.select.options).toEqual([]);

        component.optionsValue = 'a';
        fixture.detectChanges();
        expect(component.select.options).toEqual([{'label': 'a', 'value': 'a'}]);

        component.optionsValue = [{'label': 'b', 'value': 'a'}];
        fixture.detectChanges();
        expect(component.select.options).toEqual([{label: 'b', value: 'a', active: false}]);

        component.optionsValue = ['b'];
        fixture.detectChanges();
        expect(component.select.options).toEqual([{'label': 'b', 'value': 'b'}]);
    });
    it('should populate the value when we do click in one option', () => {
        component.select.populate({label: 'a', value: 'a'});
        fixture.detectChanges();

        expect(component.valueModel).toEqual('a');
    });
    it('should no populate the value when we do click in one option and it`s disable', () => {
        component.disabledValue = true;
        fixture.detectChanges();
        component.select.populate({label: 'a', value: 'a'});

        fixture.detectChanges();

        expect(component.valueModel).not.toEqual('a');
    });
    it('should populate the value when we change the value in the model', fakeAsync(() => {
        component.valueModel = 'a';
        fixture.detectChanges();
        flush();
        expect(component.select.value).toEqual({label: 'a', value: 'a', active: true});
    }));
    it('should not populate the value when we change the value in the model and it`s desabled', fakeAsync(() => {
        component.disabledValue = true;
        fixture.detectChanges();

        component.valueModel = 'a';
        fixture.detectChanges();
        flush();

        expect(component.select.value).toEqual(null);
    }));
    it('should filter values when I write in the input', fakeAsync(() => {
        component.autoCompleteValue = true;
        component.select._onFocus(fakeEvent);
        component.select.searchValue = 'a';
        fixture.detectChanges();
        flush();

        expect(component.select.option.length).toEqual(1);
    }));
    it('should filter values when I write in the input inside the labels', fakeAsync(() => {
        component.autoCompleteValue = true;
        component.includedInFilterValue = true;
        component.optionsValue = ['ab', 'db'];
        component.select._onFocus(fakeEvent);
        component.select.searchValue = 'b';
        fixture.detectChanges();
        flush();

        expect(component.select.option.length).toEqual(2);
    }));
    it('should remove the filter in blur event', fakeAsync(() => {
        component.autoCompleteValue = true;
        component.select.toggle(fakeEvent);
        component.select.searchValue = 'a';
        component.select.valueChanged();

        component.select._onBlurInput();
        fixture.detectChanges();
        flush();

        expect(component.select.searchValue).toEqual('');
    }));
    it('should open and close the selector is Touched if it`s required', fakeAsync(() => {
        component.autoCompleteValue = false;
        component.requiredValue = true;
        fixture.detectChanges();
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        component.select._onBlur();
        fixture.detectChanges();
        flush();

        expect(component.select.isTouched()).toEqual(true);
    }));
    it('should show active the first option when you keypress arrow down', fakeAsync(() => {
        component.autoCompleteValue = false;
        fixture.detectChanges();
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        const ev = {
            srcElement: null,
            keyCode: 40,
            preventDefault: () => {}
        };

        component.select._handleKeydown(<KeyboardEvent>ev);
        fixture.detectChanges();
        flush();

        expect(component.select.options[0].active).toEqual(true);
    }));

    it('should show active the last option when you keypress arrow up', fakeAsync(() => {
        component.autoCompleteValue = false;
        fixture.detectChanges();
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        const ev = {
            srcElement: null,
            keyCode: 38,
            preventDefault: () => {}
        };

        component.select._handleKeydown(<KeyboardEvent>ev);
        fixture.detectChanges();
        flush();

        expect(component.select.options[1].active).toEqual(true);
    }));
    it('should not show active the any option when you keypress scape', fakeAsync(() => {
        component.autoCompleteValue = false;
        fixture.detectChanges();
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        const ev = {
            srcElement: null,
            keyCode: 27,
            preventDefault: () => {}
        };

        component.select._handleKeydown(<KeyboardEvent>ev);
        fixture.detectChanges();
        flush();

        expect(component.select.options[0].active).not.toEqual(true);
        expect(component.select.options[1].active).not.toEqual(true);
    }));
    it('should populate active item when you keypress enter', fakeAsync(() => {
        component.autoCompleteValue = false;
        fixture.detectChanges();
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        const ev = {
            srcElement: null,
            keyCode: 38,
            preventDefault: () => {}
        };

        component.select._handleKeydown(<KeyboardEvent>ev);
        fixture.detectChanges();
        flush();

        expect(component.select.options[1].active).toEqual(true);
        ev.keyCode = 13;

        component.select._handleKeydown(<KeyboardEvent>ev);
        fixture.detectChanges();
        flush();

        expect(component.valueModel).toEqual('d');
    }));
    it('should open the panel if it`s not open and you keypress some', fakeAsync(() => {
        const ev =  {
            srcElement: null,
            keyCode: 38,
            preventDefault: () => {}
        };

        component.select._handleKeydown(<KeyboardEvent>ev);
        fixture.detectChanges();
        flush();

        expect(component.select.panelOpen).toEqual(true);
    }));

    it('should not open the panel if the keypress it`s letter', fakeAsync(() => {
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        expect(component.select.options[0].active).not.toEqual(true);
        expect(component.select.options[1].active).not.toEqual(true);

        const ev =  {
            srcElement: null,
            keyCode: 50,
            preventDefault: () => {}
        };

        component.select._handleKeydown(<KeyboardEvent>ev);
        fixture.detectChanges();
        flush();

        expect(component.select.options[0].active).not.toEqual(true);
        expect(component.select.options[1].active).not.toEqual(true);
    }));
    it('should close the panel if click in arrow if not is autoComplete', fakeAsync(() => {
        component.autoCompleteValue = false;
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        component.select.toggleArrow(fakeEvent);
        fixture.detectChanges();

        expect(component.select.panelOpen).toEqual(false);
    }));

    it('should move the focus to the input if click in arrow if is autoComplete', fakeAsync(() => {
        component.autoCompleteValue = true;
        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        flush();

        component.select.toggleArrow(fakeEvent);
        fixture.detectChanges();

        expect(component.select.panelOpen).toEqual(true);
        expect(component.select.focused).toEqual(true);

        expect(component.select.input).toBeTruthy();
    }));
    it('not should do anythink if it`s disbled  ', fakeAsync(() => {
        component.disabledValue = true;
        fixture.detectChanges();

        component.select._onFocus(fakeEvent);
        fixture.detectChanges();
        expect(component.select.panelOpen).toBe(false);

        component.select.toggle(fakeEvent);
        fixture.detectChanges();
        expect(component.select.panelOpen).toBe(false);

        component.select.toggleArrow(fakeEvent);
        fixture.detectChanges();
        expect(component.select.panelOpen).toBe(false);
        expect(component.select.focused).toEqual(false);

        component.select.open();
        fixture.detectChanges();
        expect(component.select.panelOpen).toBe(false);

    }));
});

@Component({
    template: `
    <form [formGroup]="formGroup">
        <s-select [options]="optionsValue"
            formControlName="selection"
            [autoComplete]="autoCompleteValue"
            [includedInFilter]="includedInFilterValue"
            [error-message]="errorMessageValue"
            [disabled]="disabledValue"></s-select>
    </form>
    `
  })
  class TestFormGroupReactiveComponent {
        optionsValue = ['a', 'd'];
        autoCompleteValue = true;
        includedInFilterValue = false;
        errorMessageValue = 'Error';
        disabledValue = false;

        formControl = new FormControl('', Validators.required);
        formGroup = new FormGroup({
            selection: this.formControl
        });
        @ViewChild(SelectComponent) select: SelectComponent;
}

describe('inside of a form group', () => {
    let fixture: ComponentFixture<TestFormGroupReactiveComponent>;
    let component: TestFormGroupReactiveComponent;
    let sSalector: DebugElement;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [TestFormGroupReactiveComponent],
            imports: [FormsModule, ReactiveFormsModule, SSelectComponentModule]
        }).compileComponents();

        fixture = TestBed.createComponent(TestFormGroupReactiveComponent);
        component = fixture.componentInstance;
        sSalector = fixture.debugElement.query(By.directive(SelectComponent));
        fixture.detectChanges();

    }));
    it('should create', () => {
        expect(component).toBeTruthy();
    });

    it('should not set the invalid class on a clean select', fakeAsync(() => {
        expect(component.formGroup.untouched).toBe(true, 'Expected the form to be untouched.');
        expect(component.formControl.invalid).toBe(true, 'Expected form control to be invalid.');
        const wrapper = fixture.debugElement.query(By.css('.select-wrapper'));
        expect(wrapper.nativeElement.classList)
            .not.toContain('touched', 'Expected select not touched.');
    }));
    it('should appear as invalid if it becomes touched', fakeAsync(() => {
        expect(sSalector.nativeElement.classList)
            .toContain('ng-untouched', 'Expected select not to appear invalid.');

        component.formControl.markAsTouched();
        fixture.detectChanges();

        expect(sSalector.nativeElement.classList)
            .toContain('ng-invalid', 'Expected select to appear invalid.');
        expect(sSalector.nativeElement.classList)
            .not.toContain('ng-untouched', 'Expected touched');
    }));
    it('should populate the value inside', fakeAsync(() => {
        component.formControl.setValue('a');
        fixture.detectChanges();
        tick();

        expect(component.select.value).toEqual({ label: 'a', value: 'a', active: true } );
    }));
});
