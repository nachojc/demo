import { Component, Input, ViewChild, ElementRef, Attribute,
  forwardRef, ViewChildren, QueryList, Output, EventEmitter } from '@angular/core';
import { ControlValueAccessor, NgModel, NG_VALUE_ACCESSOR } from '@angular/forms';
import { SelectorModel, HelpLabelModel, OptionalLabelModel } from './selector.model';
import { getElements, DOWN_ARROW, UP_ARROW, LEFT_ARROW, RIGHT_ARROW, ENTER, SPACE, getIndexSelected, ESCAPE } from './helper';



@Component({
  selector: 's-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss'],
// tslint:disable-next-line: use-input-property-decorator
  inputs: ['disabled', 'tabIndex'],
  host: {
    'role': 'listbox',
    '[attr.id]': 'id',
    '[class.disabled]': 'disabled',
    '[class.invalid]': '!value && required',
    '[class.required]': 'required',
    '[class.empty]': '!options.length'
  },
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => SelectComponent),
      multi: true
    }
  ]
})
export class SelectComponent implements ControlValueAccessor {
  private _touched = false;
  private _opening = false;

  @Input()
  get id(): string { return this._id; }
  set id(value: string) {
    this._id = value;
  }
  private _id: string;

  @Input()
  get placeholder(): string { return this._placeholder; }
  set placeholder(value: string) {
    this._placeholder = value;
  }
  private _placeholder = 'Please select...';

  @Input()
  get autoComplete() {return this._autoComplete; }
  set autoComplete(value: boolean) {this._autoComplete = value != null && `${value}` !== 'false'; }
  private _autoComplete = false;

  @Input()
  get includedInFilter() {return this._searchStart; }
  set includedInFilter(value: boolean) {this._searchStart = value === null || `${value}` === 'false'; }
  private _searchStart = true;

  @Input()
  get required(): boolean { return this._required; }
  set required(value: boolean) {
    this._required = value != null && `${value}` !== 'false';
  }
  private _required = false;

  @Input()
  get disabled() { return this._disabled; }
  set disabled(value: any) { this._disabled = value != null && `${value}` !== 'false'; }
  private _disabled = false;

  @Input()
  get value(): any { return this._value; }
  set value(newValue: any) {
      this.writeValue(newValue);
  }
  private _value: SelectorModel;

  @Input()
  get options(): any { return this._options; }
  set options(newoptions: any) {
    if (!newoptions || !Array.isArray( newoptions)) {
      this._options = (typeof newoptions === 'string' || typeof newoptions === 'number') ?
                  [{'label': newoptions, 'value': newoptions}] : [];
    } else if ( newoptions !== this._options) {
      if (newoptions.length && newoptions[0].hasOwnProperty('label') && newoptions[0].hasOwnProperty('value')) {
        this._options = newoptions;
        this.resetoptions();
      } else if (typeof newoptions[0] === 'string' || typeof newoptions[0] === 'number') {
        this._options = newoptions.map(obj => ({'label': obj, 'value': obj}));
      } else {
        this._options = [];
      }
    }
  }
  private _options = [];

  @Input()
  get tabIndex(): number { return this.disabled || (this._autoComplete && this.panelOpen) ? -1 : this._tabIndex; }
  set tabIndex(value: number) { this._tabIndex = value != null ? value : 0; }
  private _tabIndex = 0;

  @Input('error-message') errorMessage: string;

  @Input('label')
  set label(value: string | HelpLabelModel | OptionalLabelModel ) {
    if (typeof value === 'string') {
      this.labelValueText = value;
    } else {
      this.labelValueText = value['defaultValue'];
      this.labelOptionalText = value.hasOwnProperty('optional') ?
                  value['optional']  : '(if applicable)';
      this.labelHelpText = value['help'];
    }
  }
  labelValueText: string;
  labelOptionalText = '(if applicable)';
  labelHelpText: string;

  // To deprecate in future versions
  @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();

  get panelOpen() {return this._panelOpen; }
  private _panelOpen = false;

  get focused(): boolean { return this._focused || this._panelOpen; }
  private _focused = false;

  searchValue: string;

  @ViewChild('inputItem') input: NgModel;
  @ViewChildren('option') option: QueryList<ElementRef>;
  @ViewChild('selectElement') _selectElement: ElementRef;


  _onChange: (value: any) => void = () => {};
  _onTouched = () => {};


  constructor(
    private el: ElementRef,
    @Attribute('tabindex') tabIndex: string
  ) {
    this.tabIndex = parseInt(tabIndex, 10) || 0;
  }

  writeValue(val: any): void {
    if (!this._disabled ) {
      if (!val) {
        this._value = null;
      } else {
        const newValue: SelectorModel = this.setObjectSelected( val );
        if (this._value !== newValue) {
          this._value = newValue;
        }
      }
    }
  }

  registerOnChange(fn: (value: any) => void): void {
    this._onChange = fn;
  }
  registerOnTouched(fn: () => {}): void {
    this._onTouched = fn;
  }
  setDisabledState?(isDisabled: boolean): void {
    this._disabled = isDisabled;
  }

  _onBlur() {
    this._focused = false;
    if (!this._disabled && !this._autoComplete ) {
      setTimeout(() => {
        this.close();
      }, 300);
    }
  }
  _onBlurInput() {
    if (!this._disabled) {
      setTimeout(() => {
        if (this.panelOpen && !this._focused) {
          this.searchValue = '';
            this.close();
        }
      }, 300);
    }
  }
  _onFocus(e) {
    if (this.disabled) {
      return;
    }
    if (!this._autoComplete) {
      this._opening = true;
      e.preventDefault();
    }
    if (!this.panelOpen) {
      this.open();
    } else {
      this._opening = false;
    }
    this._focused = true;
  }
  focusInput() {
    if (this._disabled || (this._panelOpen && !this._autoComplete)) {
      return;
    }
    if (this._autoComplete && this.input) {
      const input = this.el.nativeElement.getElementsByTagName('input');
      if (input.length) {
        input[0].focus();
      }
    } else {
      this._selectElement.nativeElement.focus();
    }
  }
  toggle(e) {
    if (this._disabled) {
      return;
    }
    if (!this._autoComplete && this._opening) {
      e.preventDefault();
      return this._opening = false;
    }
    this.panelOpen ? this.close() : this.open();

  }
  toggleArrow(e) {
    if (this._disabled) {
      return;
    }
    if (!this._autoComplete && this._focused && !this._opening) {
      this.panelOpen ? this.close() : this.open();
    } else {
      this.focusInput();
    }
    e.preventDefault();
  }
  close() {
    if (this.panelOpen) {
      this._panelOpen = false;
      this._onTouched();
      if (this.required ) this._touched = true;
    }
  }
  open() {
    if (this.disabled || this.panelOpen) {
      return;
    }
    this.checkPosition();
    this._panelOpen = true;
    if (this._autoComplete) {
      setTimeout(() => {
        if (this._value) {
          this.setObjectSelected( this._value.value );
        }
        this.focusInput();
      }, 1);
    }

  }
  populate( item: SelectorModel ) {
    if (this._disabled) {
      return;
    }
    this.resetoptions();
    item.active = true;
    this._value = item;
    this.searchValue = '';
    this.close();

    this._onChange( item.value );
    this.valueChange.emit(item.value);
    // this._selectElement.nativeElement.focus();
  }

  valueChanged() {
    if (!this._selectionIsActive()) {
      this.resetoptions();
      this._moveFirst();
    }
  }
  isTouched() {
    return this._touched;
  }
  _handleKeydown(event: KeyboardEvent): void {

    const keyCode = event.keyCode;
    const isArrowKey = keyCode === DOWN_ARROW || keyCode === UP_ARROW ||
                       keyCode === LEFT_ARROW || keyCode === RIGHT_ARROW;
    const isOpenKey = keyCode === ENTER ||
                      (keyCode === SPACE && ! this._autoComplete) ||
                      keyCode === ESCAPE;

    if (!this._panelOpen ) {
      this.open();
      event.preventDefault();
      return;
    } else if (!(isOpenKey || isArrowKey)) {
      return;
    }
    event.preventDefault();
    switch (keyCode) {
      case DOWN_ARROW:
        this._moveDown();
        event.preventDefault();
        break;
      case UP_ARROW:
        this._moveUp();
        event.preventDefault();
        break;
      case ENTER:
      case SPACE:
        const selection = getIndexSelected(this._options) ;
        if (selection !== -1) {
          this.populate(this._options[selection]);
        }
        event.preventDefault();
      break;
      case ESCAPE:
          this.focusInput();
          this.close();
          event.preventDefault();
        break;
    }
    event.preventDefault();
  }

  getElementsNumber() {
    const _selection = getElements(this.searchValue, this._options, this._searchStart );

    return _selection.length;
  }
  checkPosition(): boolean {
    const posY = window.scrollY || document.body.scrollTop || 0;
    const position = this.el.nativeElement.offsetTop - posY;

    return this._panelOpen && (innerHeight - position) < 200;
  }

  private _selectionIsActive() {
    const _selection = getElements(this.searchValue, this._options, this._searchStart );
    const _optionselected = _selection.findIndex( (obj: SelectorModel) => obj.active );
    return _optionselected !== -1;
  }
  private _moveFirst() {
    if (!this._options && !this._options.length) {
      return;
    }
    const _selection = getElements(this.searchValue, this._options, this._searchStart );
    this.resetoptions();
    if (_selection.length) {
      this.showElement(0);
      _selection[0].active = true;
    }
  }
  private _moveDown() {
    if (!this._options && !this._options.length) {
      return;
    }
    const _selection = getElements(this.searchValue, this._options, this._searchStart );
    let _optionselected = _selection.findIndex( (obj: SelectorModel) => obj.active );
    const nextPos = (_optionselected === -1 || _optionselected === (_selection.length - 1)) ?
      0 : ++_optionselected;

    this.resetoptions();
    if (_selection.length) {
      this.showElement(nextPos);
      _selection[nextPos].active = true;
    }
  }
  private _moveUp() {
    if (!this._options && !this._options.length) {
      return;
    }
    const _selection = getElements(this.searchValue, this._options, this._searchStart );
    let _optionselected = _selection.findIndex( (obj: SelectorModel) => obj.active );
    const nextPos = (_optionselected === 0 || _optionselected === -1) ?
      (_selection.length - 1) : --_optionselected;

    this.resetoptions();
    if (_selection.length) {
      this.showElement(nextPos);
      _selection[nextPos].active = true;
    }
  }
  private resetoptions() {
    this._options = this._options.map( (obj: SelectorModel) => {obj.active = false; return obj; });
  }
  private setObjectSelected(value: string): SelectorModel {
    let result: SelectorModel;
    if (!!value ) {
      const val = this._options.findIndex( (obj: SelectorModel) => '' + obj.value === '' + value );
      if ( val !== -1 ) {
        this.resetoptions();
        this._options[val].active = true ;
        result = this._options[val];
      }
    }
    return result;
  }
  private showElement(element?: any) {
    const ele = this.option.toArray();
    let selection = element;
    if ( typeof element !== 'number' || ele.length > element) {
      selection = typeof element !== 'number' ?
                  getElements(this.searchValue, this._options, this._searchStart )
                    .findIndex( (obj: SelectorModel) => obj.active ) :
                  element;
      const target = ele[selection].nativeElement;
      if (target.scrollIntoViewIfNeeded) {
        target.scrollIntoViewIfNeeded(false);
      } else {
        target.parentNode.scrollTop = target.offsetTop;
      }

    }
  }
}
