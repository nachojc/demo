import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { RadioGroupComponent } from './radio-group.component';
import { Component, OnInit } from '@angular/core';
import { FormsModule, NgControl, ReactiveFormsModule, FormGroup, FormBuilder } from '@angular/forms';

describe('RadioGroupComponent', () => {
  let component: RadioGroupComponent;
  let fixture: ComponentFixture<RadioGroupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RadioGroupComponent ],
      providers: [ NgControl ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RadioGroupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have all the properties on init', () => {
    expect(component.options).not.toBeDefined;
  });

  it('should be touched and emit a value trough control value accessor interface when user selects one option', () => {
    const formRegisterOnChange = jasmine.createSpy('formRegisterOnChangeFunction');
    const formRegisterOnTouched = jasmine.createSpy('formRegisterOnTouchedFunction');
    component.registerOnChange(formRegisterOnChange);
    component.registerOnTouched(formRegisterOnTouched);
    component.options = ['tester', 'testing', 'failing', 'passing'];
    fixture.detectChanges();

    const options = fixture.debugElement.queryAll(By.css('label'));
    const option1 = options[0];
    option1.nativeElement.click();
    fixture.detectChanges();

    expect(formRegisterOnTouched).toHaveBeenCalled();
    expect(formRegisterOnChange).toHaveBeenCalledWith(component.options[0]);
  });

  it('calls registerOnTouched inside a form context when blur event is triggered', () => {
    component.options = ['tester', 'testing', 'failing', 'passing'];
    component.registerOnTouched(() => { }); // like angular would do
    const spiedFunction = spyOn<any>(component, '_onTouched');

    fixture.detectChanges();

    const options = fixture.debugElement.queryAll(By.css('input'));
    options[2].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    expect(spiedFunction).toHaveBeenCalled();
  });

  it('should display the radio group in the disabled state', async () => {
    component.options = ['tester', 'testing', 'failing', 'passing'];
    fixture.detectChanges();
    component.setDisabledState(true); // like angular would do

    const inputEls = fixture.debugElement.queryAll(By.css('input'));
    const allDisabled = inputEls.every(inputEl => inputEl.nativeElement.disabled === true);
    expect(allDisabled).toBe(true);
  });

});

@Component({
  template: `
  <form ngForm>
    <s-radio-group name="taskStatus" [(ngModel)]="task" [options]="options"></s-radio-group>
  </form>
  `
})
class TemplateFormRadioGroupComponent {
  options = ['TODO', 'In Progress', 'Done'];
  task: string;
}

describe('RadioGroupComponent Template Driven Form', () => {
  let form: TemplateFormRadioGroupComponent;
  let fixture: ComponentFixture<TemplateFormRadioGroupComponent>;
  let inputEls;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RadioGroupComponent, TemplateFormRadioGroupComponent ],
      imports: [ FormsModule ],
      providers: [ NgControl ]
    })
    .compileComponents();
  }));

  beforeEach(async () => {
    fixture = TestBed.createComponent(TemplateFormRadioGroupComponent);
    form = fixture.componentInstance;
    fixture.detectChanges();
    inputEls = fixture.debugElement.queryAll(By.css('input'));
    await fixture.whenStable();
  });

  it('should assign a name to all input elements, thats name is taken from the form control', () => {
    expect(inputEls.length).toEqual(form.options.length);
    inputEls.forEach(element => {
      expect(element.nativeElement.name).toEqual('taskStatus');
    });
  });

  it('should have checked the related button to the value', async () => {
    form.task = form.options[0];
    fixture.detectChanges();
    await fixture.whenStable();
    expect(inputEls[0].nativeElement.checked).toBe(true);
  });

  it('should have checked the related button to the value', async () => {
    form.task = 'Not an option';
    fixture.detectChanges();
    await fixture.whenStable();

    const allUnchecked = inputEls.every(inputEl => inputEl.nativeElement.checked === false);
    expect(allUnchecked).toBe(true);
  });

  it('should have propagated the correct value related to the checked input', () => {
    const options = fixture.debugElement.queryAll(By.css('label'));
    const option1 = options[1];
    option1.nativeElement.click();
    expect(form.task).toEqual(form.options[1]);
  });
});

@Component({
  template: `
  <form [formGroup]="taskForm">
  <s-radio-group formControlName="taskStatus" [options]="options"></s-radio-group>
  </form>
  `
})
class ReactiveFormRadioGroupComponent implements OnInit {
  taskForm: FormGroup;
  options = ['TODO', 'In Progress', 'Done'];
  constructor  (private formBuilder: FormBuilder) { }

  ngOnInit () {
    this.taskForm = this.formBuilder.group({
      taskStatus: null
    });
  }
}

describe('RadioGroupComponent Reactive Driven Form', () => {
  let form: ReactiveFormRadioGroupComponent;
  let fixture: ComponentFixture<ReactiveFormRadioGroupComponent>;
  let inputEls;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RadioGroupComponent, ReactiveFormRadioGroupComponent ],
      imports: [ ReactiveFormsModule ],
      providers: [ NgControl ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReactiveFormRadioGroupComponent);
    form = fixture.componentInstance;
    fixture.detectChanges();
    inputEls = fixture.debugElement.queryAll(By.css('input'));
  });

  it('should assign a name to all input elements, thats name is taken from the form control', () => {
    expect(inputEls.length).toEqual(form.options.length);
    inputEls.forEach(element => {
      expect(element.nativeElement.name).toEqual('taskStatus');
    });
  });

  it('should have checked the related button to the value', () => {
    form.taskForm.patchValue({
      taskStatus: form.options[1]
    });
    fixture.detectChanges();

    expect(inputEls[1].nativeElement.checked).toBe(true);
  });

  it('should have checked the related button to the value', () => {
    const options = fixture.debugElement.queryAll(By.css('label'));
    const option1 = options[1];
    option1.nativeElement.click();
    expect(form.taskForm.value.taskStatus).toEqual(form.options[1]);
  });
});
