import { RadioGroupComponent } from './radio-group.component';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
// import { SLabelDirectiveModule } from '../../directives/label/label.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    // SLabelDirectiveModule,
    FormsModule
  ],
  declarations: [
    RadioGroupComponent
  ],
  exports: [
    RadioGroupComponent
  ]
})

export class SRadioGroupComponentModule { }
