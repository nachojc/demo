import { Component, AfterContentInit, Input, Injector, ViewChildren, QueryList, ElementRef } from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor, NgControl } from '@angular/forms';

@Component({
  selector: 's-radio-group',
  templateUrl: './radio-group.component.html',
  styleUrls: ['./radio-group.component.css'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: RadioGroupComponent, multi: true }
  ]
})
export class RadioGroupComponent implements ControlValueAccessor, AfterContentInit {

  private _onTouched: Function;
  private _propagateChange: Function;
  public _name;

  @Input() options: string[];
  @ViewChildren('input') radios: QueryList<ElementRef>;


  constructor (private injector: Injector) { }

  ngAfterContentInit () {
    const ngControl: NgControl = this.injector.get(NgControl, null);
    if (ngControl && ngControl.name) {
      this._name = ngControl.name;
    }
  }

  onChange (value) {
    if (this._propagateChange) {
      this._propagateChange(value);
      this.onTouched();
    }
  }

  onTouched () {
    if (this._onTouched) {
      this._onTouched();
    }
  }

  writeValue (value: string): void {
    if (value) {
      const radio = this.radios.find((element: ElementRef) => element.nativeElement.value === value);
      if (radio) {
        radio.nativeElement.checked = true;
      }
    }
  }

  registerOnChange (fn: any): void {
    this._propagateChange = fn;
  }

  registerOnTouched (fn: any): void {
    this._onTouched = fn;
  }

  setDisabledState (isDisabled: boolean): void {
    this.radios.forEach((element: ElementRef) => element.nativeElement.disabled = isDisabled);
  }
}
