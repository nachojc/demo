import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { SortcodeComponent } from './sortcode.component';
import { By } from '@angular/platform-browser';
import { FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component } from '@angular/core';

function sendInput(
  text: string, firstInputEl: HTMLInputElement,
  secondInputEl: HTMLInputElement, thirdInputEl: HTMLInputElement,
  fixture: ComponentFixture<any>
  ) {
  let firstPair = text.length > 1 ? text.slice(0, 2) : '';
  let secondPair = text.length > 3 ? text.slice(2, 4) : '';
  let thirdPair = text.length > 5 ? text.slice(4, 6) : '';
  firstPair = text.length === 1 ? text.slice(0, 1) : firstPair;
  secondPair = text.length === 3 ? text.slice(2, 3) : secondPair;
  thirdPair = text.length === 5 ? text.slice(4, 5) : thirdPair;

  firstInputEl.focus();

  if (firstPair !== '') {
    firstInputEl.value = firstPair;
    firstInputEl.dispatchEvent(new Event('input'));
  }
  if (secondPair !== '') {
    secondInputEl.value = secondPair;
    secondInputEl.dispatchEvent(new Event('input'));
  }
  if (thirdPair !== '') {
    thirdInputEl.value = thirdPair;
    thirdInputEl.dispatchEvent(new Event('input'));
  }

  fixture.detectChanges();
  return fixture.whenStable();
}

describe('SortcodeComponent', () => {
  let component: SortcodeComponent;
  let fixture: ComponentFixture<SortcodeComponent>;
  let inputElements;
  let firstInputEl, secondInputEl, thirdInputEl;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SortcodeComponent]
    }).compileComponents();

    fixture = TestBed.createComponent(SortcodeComponent);
    component = fixture.componentInstance;

    inputElements = fixture.debugElement.queryAll(By.css('input'));
    firstInputEl = inputElements[0].nativeElement;
    secondInputEl = inputElements[1].nativeElement;
    thirdInputEl = inputElements[2].nativeElement;
    fixture.detectChanges();

  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('changes component value on writeValue', () => {
    component.writeValue('090129');
    fixture.detectChanges();
    expect(component.firstInput.nativeElement.value).toEqual('09');
    expect(component.secondInput.nativeElement.value).toEqual('01');
    expect(component.thirdInput.nativeElement.value).toEqual('29');
    expect(component.valueChange.hasError).toEqual(false);
  });

  it('disable component', () => {
    component.setDisabledState(true);
    fixture.detectChanges();
    expect(component.firstInput.nativeElement.disabled).toEqual(true);
    expect(component.secondInput.nativeElement.disabled).toEqual(true);
    expect(component.thirdInput.nativeElement.disabled).toEqual(true);
  });

  it('propagates the value when all the inputs are filled with a right value (form context)', async(() => {
    component.registerOnChange(() => { });
    const spiedComponent = spyOn<any>(component, '_propagateChange');
    sendInput('090129', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent.calls.first().args[0]).toEqual('');
      expect(spiedComponent.calls.mostRecent().args[0]).toEqual('090129');
      expect(spiedComponent.calls.count()).toEqual(3);
    });
  }));

  it('propagates empty value when all the inputs are filled and the first one have a wrong value (form context)', async(() => {
    component.registerOnTouched(() => { });
    component.registerOnChange(() => { });
    const spiedComponent = spyOn<any>(component, '_propagateChange');
    sendInput('a90129', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent.calls.first().args[0]).toEqual('');
      expect(spiedComponent.calls.mostRecent().args[0]).toEqual('');
      expect(spiedComponent.calls.count()).toEqual(3);
    });
  }));

  it('propagates empty value when all the inputs are filled and the second one have a wrong value (form context)', async(() => {
    component.registerOnTouched(() => { });
    component.registerOnChange(() => { });
    const spiedComponent = spyOn<any>(component, '_propagateChange');
    sendInput('09[129', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent.calls.first().args[0]).toEqual('');
      expect(spiedComponent.calls.mostRecent().args[0]).toEqual('');
      expect(spiedComponent.calls.count()).toEqual(3);
    });
  }));

  it('propagates empty value when all the inputs are filled and the third one have a wrong value (form context)', async(() => {
    component.registerOnTouched(() => { });
    component.registerOnChange(() => { });
    const spiedComponent = spyOn<any>(component, '_propagateChange');
    sendInput('09012X', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent.calls.first().args[0]).toEqual('');
      expect(spiedComponent.calls.mostRecent().args[0]).toEqual('');
      expect(spiedComponent.calls.count()).toEqual(3);
    });
  }));

  it('propagates empty value when just first input is filled (form context)', async(() => {
    component.registerOnChange(() => { });
    const spiedComponent = spyOn<any>(component, '_propagateChange');
    sendInput('09', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent.calls.mostRecent().args[0]).toEqual('');
      expect(spiedComponent.calls.count()).toEqual(1);
    });
  }));

  it('propagates empty value when just first and second input are filled (form context)', async(() => {
    component.registerOnChange(() => { });
    const spiedComponent = spyOn<any>(component, '_propagateChange');
    sendInput('0901', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent.calls.first().args[0]).toEqual('');
      expect(spiedComponent.calls.mostRecent().args[0]).toEqual('');
      expect(spiedComponent.calls.count()).toEqual(2);
    });
  }));

  it('emits the value when all the inputs are filled with a right value (not form context)', async(() => {
    let cannotBeSpied = false;
    try {
      const spiedComponent = spyOn<any>(component, '_propagateChange');
    } catch {
      cannotBeSpied = true;
    }

    let valueChange;
    component.valueChange.subscribe(value => {
      valueChange = value;
    });

    sendInput('090129', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(cannotBeSpied).toBe(true);
    });
    setTimeout(() => {
      expect(valueChange).toEqual('090129');
    }, 10);
  }));

  it('emits empty value when there is an error in first input (not form context)', async(() => {
    let cannotBeSpied = false;
    try {
      const spiedComponent = spyOn<any>(component, '_propagateChange');
    } catch {
      cannotBeSpied = true;
    }

    let valueChange;
    component.valueChange.subscribe(value => {
      valueChange = value;
    });

    sendInput('a90129', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(cannotBeSpied).toBe(true);
    });
    setTimeout(() => {
      expect(valueChange).toEqual('');
    }, 10);
  }));

  it('emits empty value when there is an error in second input (not form context)', async(() => {
    let cannotBeSpied = false;
    try {
      const spiedComponent = spyOn<any>(component, '_propagateChange');
    } catch {
      cannotBeSpied = true;
    }

    let valueChange;
    component.valueChange.subscribe(value => {
      valueChange = value;
    });

    sendInput('090[29', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(cannotBeSpied).toBe(true);
    });
    setTimeout(() => {
      expect(valueChange).toEqual('');
    }, 10);
  }));

  it('emits empty value when there is an error in third input (not form context)', async(() => {
    let cannotBeSpied = false;
    try {
      const spiedComponent = spyOn<any>(component, '_propagateChange');
    } catch {
      cannotBeSpied = true;
    }

    let valueChange;
    component.valueChange.subscribe(value => {
      valueChange = value;
    });

    sendInput('09012.', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(cannotBeSpied).toBe(true);
    });
    setTimeout(() => {
      expect(valueChange).toEqual('');
    }, 10);
  }));

  it('emits empty value when just the first input is filled (not form context)', async(() => {
    let cannotBeSpied = false;
    try {
      const spiedComponent = spyOn<any>(component, '_propagateChange');
    } catch {
      cannotBeSpied = true;
    }

    let valueChange;
    component.valueChange.subscribe(value => {
      valueChange = value;
    });

    sendInput('09', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(cannotBeSpied).toBe(true);
    });
    setTimeout(() => {
      expect(valueChange).toEqual('');
    }, 10);
  }));


  it('emits empty value when just first and second input are filled (not form context)', async(() => {
    let cannotBeSpied = false;
    try {
      const spiedComponent = spyOn<any>(component, '_propagateChange');
    } catch {
      cannotBeSpied = true;
    }

    let valueChange;
    component.valueChange.subscribe(value => {
      valueChange = value;
    });

    sendInput('09015', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(cannotBeSpied).toBe(true);
    });
    setTimeout(() => {
      expect(valueChange).toEqual('');
    }, 10);
  }));


  it('calls registerOnTouched when all the inputs lost the focus', async(() => {
    component.registerOnTouched(() => { });
    const spiedComponent = spyOn<any>(component, '_onTouched');
    sendInput('090129', firstInputEl, secondInputEl, thirdInputEl, fixture);

    thirdInputEl.blur();
    fixture.detectChanges();

    fixture.whenStable().then(() => {
      expect(spiedComponent).toHaveBeenCalled();
    });
  }));

  it('doesn\'t call registerOnTouched when all the inputs have been filled but the component has not lost the focus', async(() => {
    component.registerOnTouched(() => { });
    const spiedComponent = spyOn<any>(component, '_onTouched');
    sendInput('090129', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent).not.toHaveBeenCalled();
    });
  }));

  it('calls registerOnTouched first input is filled with wrong value', async(() => {
    component.registerOnTouched(() => { });
    const spiedComponent = spyOn<any>(component, '_onTouched');

    sendInput('0x', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent).toHaveBeenCalled();
    });
  }));

  it('doesn\'t call registerOnTouched when just the first input is filled and it has a right value', async(() => {
    component.registerOnTouched(() => { });
    const spiedComponent = spyOn<any>(component, '_onTouched');

    sendInput('09', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent).not.toHaveBeenCalled();
    });
  }));

  it('calls registerOnTouched second input is filled with wrong value', async(() => {
    component.registerOnTouched(() => { });
    const spiedComponent = spyOn<any>(component, '_onTouched');

    sendInput('09[1', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent).toHaveBeenCalled();
    });
  }));

  it('calls registerOnTouched third input is filled with wrong value', async(() => {
    component.registerOnChange(() => { });
    component.registerOnTouched(() => { });
    const spiedComponent = spyOn<any>(component, '_onTouched');

    sendInput('09012-', firstInputEl, secondInputEl, thirdInputEl, fixture).then(() => {
      expect(spiedComponent).toHaveBeenCalled();
    });
  }));
});

@Component({
  template:
    `<form ngForm>
      <s-sortcode id="sc" [formControl]="sortcodeControl"></s-sortcode>
      <s-sortcode id="scPrepopulated" [formControl]="scPrepControl"></s-sortcode>
    </form>`,
})
class TestFormSortcodeComponent {
  sortcodeControl = new FormControl('');
  scPrepControl = new FormControl('090124');
}

describe('SortcodeInADummyReactiveForm', () => {
  let form: TestFormSortcodeComponent;
  let fixture: ComponentFixture<TestFormSortcodeComponent>;
  let scInputElements, scFirstInputEl, scSecondInputEl, scThirdInputEl;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SortcodeComponent, TestFormSortcodeComponent],
      imports: [FormsModule, ReactiveFormsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(TestFormSortcodeComponent);

    scInputElements = fixture.debugElement.queryAll(By.css('#sc input'));
    scFirstInputEl = scInputElements[0].nativeElement;
    scSecondInputEl = scInputElements[1].nativeElement;
    scThirdInputEl = scInputElements[2].nativeElement;

    form = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(form).toBeTruthy();
  });

  it('has a value when it is prepopulated', () => {
    const prepopulatedSortcode = fixture.debugElement.query(By.css('#scPrepopulated'));
    expect(prepopulatedSortcode.componentInstance.firstInput.nativeElement.value).toEqual('09');
    expect(prepopulatedSortcode.componentInstance.secondInput.nativeElement.value).toEqual('01');
    expect(prepopulatedSortcode.componentInstance.thirdInput.nativeElement.value).toEqual('24');
  });

  it('has an empty value when it hasn\'t been prepopulated', () => {
    const sortcode = fixture.debugElement.query(By.css('#sc'));
    expect(sortcode.componentInstance.firstInput.nativeElement.value).toEqual('');
    expect(sortcode.componentInstance.secondInput.nativeElement.value).toEqual('');
    expect(sortcode.componentInstance.thirdInput.nativeElement.value).toEqual('');
  });

  it('is pristine, valid and untouched when it has been prepopulated', () => {
    // let sortcode = fixture.debugElement.query(By.css('#sc'));
    expect(form.sortcodeControl.pristine).toBeTruthy();
    expect(form.sortcodeControl.valid).toBeTruthy();
    expect(form.sortcodeControl.untouched).toBeTruthy();
  });

  it('is not pristine when it has at least an input filled', async(() => {
    const sortcode = fixture.debugElement.query(By.css('#sc'));
    sendInput('09', scFirstInputEl, scSecondInputEl, scThirdInputEl, fixture).then(() => {
      expect(form.sortcodeControl.pristine).toBeFalsy();
    });
  }));

  it('is touched when an input has been filled with a wrong value', async(() => {
    // let sortcode = fixture.debugElement.query(By.css('#sc'));
    sendInput('0x', scFirstInputEl, scSecondInputEl, scThirdInputEl, fixture).then(() => {
      expect(form.sortcodeControl.touched).toBeTruthy();
    });
  }));

  it('is touched when is has been written with any value and none of their inputs has the focus', async(() => {
    // let sortcode = fixture.debugElement.query(By.css('#sc'));
    sendInput('090129', scFirstInputEl, scSecondInputEl, scThirdInputEl, fixture);
    scThirdInputEl.blur();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(form.sortcodeControl.touched).toBeTruthy();
    });
  }));

  it('is valid when has a right value', async(() => {
    // let sortcode = fixture.debugElement.query(By.css('#sc'));
    sendInput('090129', scFirstInputEl, scSecondInputEl, scThirdInputEl, fixture).then(() => {
      expect(form.sortcodeControl.valid).toBeTruthy();
    });
  }));

});
