import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, AbstractControl, ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';

let uniqueId = 0;

@Component({
  selector: 's-yes-no-input',
  templateUrl: './yes-no-input.component.html',
  styleUrls: ['./yes-no-input.component.css', '../../styles/error.scss'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: YesNoInputComponent,
    multi: true
  }]
})
export class YesNoInputComponent implements OnInit, ControlValueAccessor {

  public form: FormGroup;
  public custom: string;
  private onChange = (value) => { };
  public onTouched = () => { };

  constructor(public fb: FormBuilder) { }

  ngOnInit() {
    this.custom = 'yesNoButton' + uniqueId++;

    this.form = this.fb.group({});
    this.form.addControl(this.custom, new FormControl(null, Validators.required));

    this.form.valueChanges.subscribe(() => {
      this.onChange(this.form.controls[this.custom].value);
    });
  }

  get yesNoButton(): AbstractControl { return this.form.get(this.custom); }

  get value() { return this.form.controls[this.custom].value; }

  writeValue(obj: any): void {
    this.form.controls[this.custom].setValue(obj);
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }
  selectOption(event: KeyboardEvent, selected: string) {
    const chosenElement = <HTMLElement>event.srcElement;
    const keyCode = event.keyCode;
    if (keyCode === 13) { // enter
     this.writeValue(selected);
    }
    if (keyCode === 39 || keyCode === 37) { // right arrow, left arrow
      const toFocus = this.getNextElement(chosenElement, keyCode === 39);
      if (toFocus) {
        toFocus.focus();
      }
    }
   }
   getNextElement(element: Element, right: boolean): HTMLElement {
    const elementParent = element.parentElement;
    let childrenArray = Array.from(elementParent.children);
    if (!right) {
      childrenArray = childrenArray.reverse(); // left arrow
    }
    const elementIndex = childrenArray.findIndex(el => el === element);
    return <HTMLElement>childrenArray.slice(elementIndex + 1, childrenArray.length)
    .find(el => el.nodeName === 'LABEL');
  }
}
