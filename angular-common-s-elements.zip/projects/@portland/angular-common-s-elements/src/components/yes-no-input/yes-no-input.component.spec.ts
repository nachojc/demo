import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { YesNoInputComponent } from './yes-no-input.component';
import { ReactiveFormsModule, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { Component, ViewChild, OnInit } from '@angular/core';
import { byDataQa } from '../../../../../../test-utils/test-helpers';


@Component({
  template:
    ` <form [formGroup]="form">
      <s-yes-no-input label="question" error-message="choose an option" formControlName="yesNoControl" #childInstance></s-yes-no-input>
    </form>
  `
})
class ParentComponent implements OnInit {
  value: string;
  click: string;

  @ViewChild('childInstance') childInstance;

  constructor(public fb: FormBuilder) {
  }

  form: FormGroup;

  ngOnInit() {
    this.form = this.fb.group({
      yesNoControl: [null, Validators.required]
    });
  }
}

describe('YesNoInputComponent', () => {
  let parent: ParentComponent;
  let component: YesNoInputComponent;
  let nativeElement;
  let fixture: ComponentFixture<ParentComponent>;
  let testBed: typeof TestBed;

  beforeEach(async(() => {
    testBed = TestBed.configureTestingModule({
      declarations: [YesNoInputComponent, ParentComponent],
      imports: [
        ReactiveFormsModule
      ]
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParentComponent);
    parent = fixture.componentInstance;
    component = parent.childInstance;
    nativeElement = fixture.nativeElement;
    fixture.detectChanges();
  });

  describe('model values', () => {

    const clickButton = (identifier) => {
      nativeElement.querySelector(identifier).click();
      fixture.detectChanges();
    };

    describe('coming with value', () => {

      it('should create', () => {
        expect(component).toBeTruthy();
        expect(nativeElement.querySelector(byDataQa('yesNoInputContainer'))).toBeTruthy();
        expect(nativeElement.querySelector('[error-container]')).toBeTruthy();
        expect(nativeElement.querySelector(byDataQa('inputBlock'))).toBeTruthy();
        expect(nativeElement.querySelector(byDataQa('input_YES'))).toBeTruthy();
        expect(nativeElement.querySelector(byDataQa('inputLabel_YES'))).toBeTruthy();
        expect(nativeElement.querySelector(byDataQa('input_NO'))).toBeTruthy();
        expect(nativeElement.querySelector(byDataQa('inputLabel_NO'))).toBeTruthy();
      });

      it('fill the form with the value coming from the parent', () => {
        parent.form.controls.yesNoControl.setValue('Yes');
        fixture.detectChanges();

        expect(component.form.controls[component.custom].value).toEqual('Yes');
      });
    });

    describe('coming empty', () => {

      it('the internal form should be invalid when there is no value in the model', () => {
        expect(component.form.controls[component.custom].value).toEqual(null);
        // expect(component.form.controls[component.custom].valid, 'the form should be invalid when there is no data').toBeFalsy;
      });

      describe('the control interface', () => {
        it('should have the value', () => {
          clickButton(byDataQa('inputLabel_YES'));

          expect(parent.form.controls.yesNoControl.value).toEqual('Yes');
        });
      });

      describe('validation', () => {
        describe('error display scenarios', () => {
          it('by default, error message and error class should not appear', () => {
            expect(nativeElement.querySelector('.errorDirective_error')).not.toBeTruthy();
            expect(nativeElement.querySelector(byDataQa('requiredErrorMessage'))).not.toBeTruthy();
          });

          it('error message should exist when the form is mark as touched', () => {
            component.form.controls[component.custom].markAsTouched();
            fixture.detectChanges();
            expect(nativeElement.querySelectorAll('[error-container]').length).toEqual(1);
          });
        });

        describe('control validity', () => {
          it('should be valid when the validation passed in by the parent is fulfilled', () => {
            clickButton(byDataQa('inputLabel_YES'));

            expect(parent.form.controls.yesNoControl.valid).toBeTruthy();
          });
          it('should be invalid when the validation passed in by the parent is not fulfilled', () => {
            expect(parent.form.controls.yesNoControl.valid).toBeFalsy();
          });
        });
      });
    });

    describe('keyboard interactions', () => {

      it('should call the #writeValue function when enter key is pressed', () => {
        spyOn(component, 'writeValue');
        event = <KeyboardEvent>{
          srcElement: null,
          keyCode: 13
        };
        component.selectOption(<KeyboardEvent>event, 'Yes');
        expect(component.writeValue).toHaveBeenCalled();
      });

      it('should call the #getNextElement function when right key is pressed', () => {
        const fakeElement = {
          focus: null
        };
        spyOn(fakeElement, 'focus');
        spyOn(component, 'getNextElement').and.returnValue(fakeElement);

        event = <KeyboardEvent>{
          srcElement: null,
          keyCode: 39
        };
        component.selectOption(<KeyboardEvent>event, 'Yes');

        expect(component.getNextElement).toHaveBeenCalled();
        expect(fakeElement.focus).toHaveBeenCalled();
      });

      it('should call the #getNextElement function when left key is pressed', () => {
        spyOn(component, 'getNextElement');

        event = <KeyboardEvent>{
          srcElement: null,
          keyCode: 39
        };
        component.selectOption(<KeyboardEvent>event, 'Yes');

        expect(component.getNextElement).toHaveBeenCalled();
      });

      it('should has #getNextElement function that returns an HTMLElement', () => {
        const mockElement = {
          parentElement: {
            children: <any>[]
          }
        };

        expect(component.getNextElement(<Element>mockElement, true)).toBeUndefined();
      });

    });
  });
});
