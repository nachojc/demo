import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';

import { YesNoInputComponent } from './yes-no-input.component';

@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule
  ],
  declarations: [YesNoInputComponent],
  exports: [
    YesNoInputComponent
  ]
})

export class SYesNoInputModule { }
