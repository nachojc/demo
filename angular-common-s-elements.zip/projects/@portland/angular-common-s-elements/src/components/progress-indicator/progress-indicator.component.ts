import { Component, Input } from '@angular/core';

export interface ProgressIndicatorItem {
  label: string;
  status?: 'ok' | 'selected' | 'error' | null;
}

@Component({
  selector: 's-progress-indicator',
  templateUrl: './progress-indicator.component.html',
  styleUrls: ['./progress-indicator.component.scss']
})
export class ProgressIndicatorComponent {
  @Input('items') _items: ProgressIndicatorItem[];

  findSelected(): ProgressIndicatorItem | undefined {
    return this._items && this._items.find((item: ProgressIndicatorItem) => item.status === 'selected');
  }
}
