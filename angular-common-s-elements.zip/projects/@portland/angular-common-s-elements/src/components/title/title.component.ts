import { AfterContentInit, Component, ElementRef, Injector, Input, OnDestroy, Renderer2, ViewChild } from '@angular/core';
import { AbstractControl, ControlValueAccessor, NgControl, NgModel, NG_VALUE_ACCESSOR } from '@angular/forms';
import otherTitlesArray from './otherTitles';

@Component({
  selector: 's-title',
  templateUrl: './title.component.html',
  styleUrls: [
    './title.component.css',
    '../../styles/error.scss',
    '../../assets/styles/s-label.css'
  ],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: TitleComponent,
    multi: true
  }]
})
export class TitleComponent implements AfterContentInit, OnDestroy, ControlValueAccessor {

  @Input('titles') titles = ['Mr', 'Mrs', 'Miss', 'Ms', 'Mx', 'Other'];
  @Input('other-titles') otherTitles = otherTitlesArray;

  @ViewChild('radioControl')  _radioControl: NgModel;
  @ViewChild('selectControl') _selectControl: NgModel;

  public _otherSelected = false;
  private control: AbstractControl;

  private _onChange: Function;
  private _onTouch: Function;

  private _touchedFromRadio: Function;
  private _touchedFromSelect: Function;

  // tslint:disable-next-line:max-line-length
  titleErrMsg = `Please select your title from the options provided. If you can't see your title please select other and choose from the extended list`;
  invalid_radio = false;
  invalid_select = false;

  _isRequired: boolean;

  _pendingTouched = false;

  initialValue; // to meet ng model

  private _documentListener: Function;

  constructor (private el: ElementRef, private renderer: Renderer2, private injector: Injector) { }

  private _clickout (event) {
    if (event.target.tagName === 'INPUT') { return; } // filter double click on label/input

    if (this._pendingTouched && !this.el.nativeElement.contains(event.target)) {
      this._onTouch();
      this._pendingTouched = false;
    }
  }

  writeValue(value: string): void {
    if (value) {
      if (this.titles && this.titles.indexOf(value) === -1) {
        this._radioControl.valueAccessor.writeValue('Other');
        this._otherSelected = true;
        setTimeout(() => this._selectControl.valueAccessor.writeValue(value), 0);
      } else {
        this._radioControl.valueAccessor.writeValue(value);
      }
    }
  }

  registerOnChange(fn: any): void {
    this._onChange = fn;
  }

  registerOnTouched(fn: any): void {
    // handle touch if receiving from radio group
    this._touchedFromRadio = () => {
      if (!this._otherSelected) {
        fn(); // update form (parent)
      } else {
        this._pendingTouched = true;
      }
       // touched and emit in case a s-radio-group happens at same time.
      this.invalid_radio = this.control.invalid && this._radioControl.value !== 'Other';
       // update child if child said it was touched (it is actually the own child who says it has been touched to itself)
      this._radioControl.control.markAsTouched();
    };
    // handle touch if receiving from select
    this._touchedFromSelect = () => {
      fn();
      this._selectControl.control.markAsTouched();
      this._updateSelectStyle();
    };

    this._onTouch = this._touchedFromRadio;
  }

  setDisabledState?(isDisabled: boolean): void {
    this._radioControl.valueAccessor.setDisabledState(isDisabled);
    setTimeout( () => {
      if (this._selectControl) {
        this._selectControl.valueAccessor.setDisabledState(isDisabled);
      }
    }, 0);
  }

  ngAfterContentInit () {
    const ngControl: NgControl = this.injector.get(NgControl, null);
    if (ngControl) {
      this.control = ngControl.control;
      if (ngControl.name) {
        this._radioControl.name = ngControl.name;
      }
    }
    this._onTouch = this._touchedFromRadio; // start listening radio-group
    setTimeout(() => {
      this._radioControl.valueAccessor.registerOnTouched(this._onTouch);
      this.checkIfControlIsRequired(ngControl);
    }, 0); // replace the child function to ours, this prevents child to be updated
  }

  ngOnDestroy () {
    if (this._documentListener) {
      this._documentListener();
    }
  }

  onRadioChange (value) {
    if (value === 'Other') {
      this._otherSelected = true;
      this.titleErrMsg = 'Please select your title from the options provided';
      // mark as untouched
      this.control.markAsUntouched();
      // start listening to select touches as well
      this._onTouch = this._touchedFromSelect;
      // set a listener to clickout
      this._documentListener = this.renderer.listen('document', 'click', (event) => this._clickout(event));
      setTimeout(() => {
        if (this._selectControl) {
          this._selectControl.valueAccessor.registerOnTouched(this._onTouch);
        }
      }, 0); // replace the child function to ours, this prevents child to be updated, also give time to be rendered

    } else {
      if (this._documentListener) {
        this._documentListener();
      }
      this._otherSelected = false;
      this._emitValue(value);
    }
  }

  _emitValue (value) {
    if (this._onChange) {
      this._onChange(value);
    }
  }

  onSelectChange(value) {
    this._emitValue(value);
    // after emitting control will have been updated by this time
    this._updateSelectStyle();
  }

  private _updateSelectStyle() {
    this.invalid_select = this.control.touched && this.control.invalid;
  }

  checkIfControlIsRequired(ngControl: NgControl) {
    const functionToEvaluate = ngControl && ((ngControl.control && ngControl.control.validator) || ngControl.validator);
    if (functionToEvaluate) {
      const validations = functionToEvaluate(<any>'');
      if (validations && validations.required) {
        this._isRequired = true;
      }
    }
  }
}
