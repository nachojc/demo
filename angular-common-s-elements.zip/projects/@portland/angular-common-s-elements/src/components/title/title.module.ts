import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TitleComponent } from './title.component';
import { SRadioGroupComponentModule } from '../radio-group/radio-group.module';
import { SSelectComponentModule } from '../select/select.module';
import { SLabelDirectiveModule } from '../../directives/label/label.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    SRadioGroupComponentModule,
    SSelectComponentModule,
    SLabelDirectiveModule,
    FormsModule
  ],
  declarations: [
    TitleComponent
  ],
  exports: [
    TitleComponent
  ]
})
export class STitleComponentModule { }
