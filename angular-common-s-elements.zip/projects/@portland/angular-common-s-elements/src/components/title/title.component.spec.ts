/* tslint:disable:max-line-length */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, NgControl } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { SRadioGroupComponentModule } from '../radio-group/radio-group.module';
import { SSelectComponentModule } from '../select/select.module';
import otherTitles from './otherTitles';
import { TitleComponent } from './title.component';

describe('TitleComponent', () => {
  let component: TitleComponent;
  let fixture: ComponentFixture<TitleComponent>;
  let ngControl;
  const _ngControl = {
    name: 'title',
    touched: false,
    valueChanges: {
      subscribe: jasmine.createSpy('control value subscribe')
    },
    control: {
      statusChanges: {
        subscribe: jasmine.createSpy('control status subscribe'),
        emit: jasmine.createSpy('control status emit'),
      },
      touched: false,
      invalid: false,
      markAsUntouched: jasmine.createSpy('control markAsUntouched')
    }
  };

  function _timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
  const initialiseComponentAsInAForm = async () => {
    const formRegisterOnChange = jasmine.createSpy('formRegisterOnChangeFunction');
    component.registerOnChange(formRegisterOnChange);
    const formRegisterOnTouched = jasmine.createSpy('formRegisterOnTouchedFunction');
    component.registerOnTouched(formRegisterOnTouched);

    await _timeout(20);
    component.ngAfterContentInit();
    await _timeout(20);

    return [formRegisterOnChange, formRegisterOnTouched];
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        SRadioGroupComponentModule,
        SSelectComponentModule,
        FormsModule
      ],
      providers: [
        { provide: NgControl, useValue: _ngControl }
      ],
      declarations: [ TitleComponent ]
    })
    .compileComponents();

    ngControl = TestBed.get(NgControl);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TitleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    ngControl.control.markAsUntouched.calls.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have a template made of a s-radio-group component and a s-select component, if other title is selected from the radio group', () => {
    const element = fixture.nativeElement;
    expect(element.querySelector('s-radio-group')).not.toBeNull();
    expect(element.querySelector('s-select')).toBeNull();

    component._otherSelected = true;
    fixture.detectChanges();

    expect(element.querySelector('s-select')).not.toBeNull();
  });

  it('should have a title and otherTitle properties that have default values', () => {
    expect(component.titles).toEqual(['Mr', 'Mrs', 'Miss', 'Ms', 'Mx', 'Other']);
    expect(component.otherTitles).toEqual(otherTitles);
  });

  it('should implement registerOnChange which emits and makes the component touched, when user interacts', () => {
    const formRegisterOnChange = jasmine.createSpy('formRegisterOnChangeFunction');
    component.registerOnChange(formRegisterOnChange);
    const formRegisterOnTouched = jasmine.createSpy('formRegisterOnTouchedFunction');
    component.registerOnTouched(formRegisterOnTouched);

    component._radioControl.valueAccessor.registerOnTouched(formRegisterOnTouched);


    const options = fixture.debugElement.queryAll(By.css('label'));
    const mrOption = options[0];

    mrOption.nativeElement.click();
    fixture.detectChanges();
    expect(formRegisterOnChange).toHaveBeenCalledWith('Mr');
    expect(formRegisterOnTouched).toHaveBeenCalled();
  });

  it('should display a select component if user clicks on "Other" option and should be able to emit values from there if they click', () => {
    const formRegisterOnChange = jasmine.createSpy('formRegisterOnChangeFunction');
    component.registerOnChange(formRegisterOnChange);
    const formRegisterOnTouched = jasmine.createSpy('formRegisterOnTouchedFunction');
    component.registerOnTouched(formRegisterOnTouched);
    component._radioControl.valueAccessor.registerOnTouched(formRegisterOnTouched);

    fixture.detectChanges();

    expect(component.titleErrMsg).toEqual(`Please select your title from the options provided. If you can't see your title please select other and choose from the extended list`);
    expect(component._otherSelected).toBe(false);

    component._radioControl.control.patchValue('Other');
    component._radioControl.control.markAsTouched();

    fixture.detectChanges();

    expect(component._otherSelected).toBe(true);
    expect(component.titleErrMsg).toEqual('Please select your title from the options provided');

    component._selectControl.control.patchValue('Dr');

    expect(formRegisterOnChange).toHaveBeenCalledWith('Dr');
  });

  it('should remove the select component if user clicks on "Other" option and then clicks another option other than Other.', () => {
    const element = fixture.nativeElement;

    component._radioControl.control.patchValue('Other');
    fixture.detectChanges();

    expect(element.querySelector('s-select')).not.toBeNull();
    expect(component._otherSelected).toBe(true);

    component._radioControl.control.patchValue('Mr');
    fixture.detectChanges();
    expect(element.querySelector('s-select')).toBeNull();
  });

  it('should set the name for s-radio-group', () => {
    expect(component._radioControl.name).toEqual(ngControl.name);
    const input = fixture.debugElement.query(By.css('s-radio-group input'));
    expect(input.nativeElement.name).toEqual(ngControl.name);
  });

  it('should display radios as invalid when title is touched, invalid and the value of the radio is no Other, (title is incomplete)', async () => {
    const [spyChange, spyTouched] = await initialiseComponentAsInAForm(); // just to initialise.
    ngControl.control.invalid = true; // mark that as invalid

    const options = fixture.debugElement.queryAll(By.css('input'));
    const mrOption = options[0];
    const blurEvent = new Event('blur');
    mrOption.nativeElement.dispatchEvent(blurEvent);

    fixture.detectChanges();

    expect(component.invalid_radio).toBe(true);
  });


  it('should display radios as valid when title is touched, valid and the value of the radio is no Other, (title is incomplete but not required)', async () => {
    const [spyChange, spyTouched] = await initialiseComponentAsInAForm(); // just to initialise.
    ngControl.control.invalid = false; // mark that as invalid

    const options = fixture.debugElement.queryAll(By.css('input'));
    const mrOption = options[0];
    const blurEvent = new Event('blur');
    mrOption.nativeElement.dispatchEvent(blurEvent);

    fixture.detectChanges();

    expect(component.invalid_radio).toBe(false);
  });

  it('should set the title as untouched when "Other" is selected', async () => {
    const [spyChange, spyTouched] = await initialiseComponentAsInAForm(); // just to initialise.

    component._radioControl.control.patchValue('Other');
    fixture.detectChanges();

    expect(ngControl.control.markAsUntouched).toHaveBeenCalled();
  });

  it('should not listen to clickOutside if other is not selected, and should remove the listener when it is not selected, and unsubscribe when destroy', () => {
    const spyClickOutside = spyOn<any>(component, '_clickout');

    fixture.nativeElement.parentElement.click(); // click outside
    component._radioControl.control.patchValue('Other');
    fixture.nativeElement.parentElement.click(); // click outside
    component._radioControl.control.patchValue('Mr');
    fixture.nativeElement.parentElement.click(); // click outside

    expect(spyClickOutside).toHaveBeenCalledTimes(1);

    component._radioControl.control.patchValue('Other');
    const spyClickOutsideUnsubscribe = spyOn<any>(component, '_documentListener');
    component.ngOnDestroy();

    expect(spyClickOutsideUnsubscribe).toHaveBeenCalled();
  });

  it('should removed "(if applicable)" from the radio label if title is required', async () => {
    ngControl.validator = () => ({required: true});
    component.ngAfterContentInit();
    await _timeout(20);
    expect(component._isRequired).toBe(true);

    fixture.detectChanges();
    const radioLabel = fixture.debugElement.query(By.css('fieldset .s-label__optional'));

    expect(radioLabel).toBeNull();
  });

  it('should removed "(if applicable)" from the select label if title is required', async () => {
    ngControl.validator = () => ({required: true});

    component.ngAfterContentInit();
    await _timeout(20);
    expect(component._isRequired).toBe(true);

    component._radioControl.control.patchValue('Other');
    fixture.detectChanges();

    const selectLabel = fixture.debugElement.query(By.css('label .s-label__optional'));

    expect(selectLabel).toBeNull();
  });

  it('should include "(if applicable)" for the select label if title is not required', () => {
    component._radioControl.control.patchValue('Other');
    fixture.detectChanges();

    const selectLabel = fixture.debugElement.query(By.css('label .s-label__optional'));

    expect(selectLabel).toBeDefined();
  });

  it('should include "(if applicable)" for the radio label if title is not required', () => {
    const radioLabel = fixture.debugElement.query(By.css('fieldset .s-label__optional'));

    expect(radioLabel).toBeDefined();
  });

  it('should display the title component in the disabled state', async () => {
    const spyRadioGroupSetDisable = spyOn<any>(component._radioControl.valueAccessor, 'setDisabledState');
    component.setDisabledState(true); // like angular would do

    expect(spyRadioGroupSetDisable).toHaveBeenCalled();
  });

  it('should propagate the correct value related to the checked input', () => {
    const spyRadioGroupWriteValue = spyOn<any>(component._radioControl.valueAccessor, 'writeValue');
    component.writeValue('Mr'); // like angular would do

    expect(spyRadioGroupWriteValue).toHaveBeenCalledWith('Mr');
  });

  it('should propagate the correct value related to the select option when "Other" radio is selected', async () => {
    const spyRadioGroupWriteValue = spyOn<any>(component._radioControl.valueAccessor, 'writeValue');
    component.writeValue('Dr'); // select Dr option like angular would do
    fixture.detectChanges();

    await fixture.whenStable();

    expect(spyRadioGroupWriteValue).toHaveBeenCalledWith('Other');
  });
});
