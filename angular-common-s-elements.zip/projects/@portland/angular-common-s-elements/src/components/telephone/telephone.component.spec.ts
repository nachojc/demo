import { Component, OnInit, DebugElement, ViewChild, ElementRef } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormsModule, ReactiveFormsModule, NgControl, FormGroup, FormBuilder, NgForm } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { TelephoneComponent } from './telephone.component';

describe('TelephoneComponent', () => {
  let component: TelephoneComponent;
  let fixture: ComponentFixture<TelephoneComponent>;
  let inputEls;
  let debugComponent;

  let fakePasteEventPayload = {};
  let fakeDragEventPayload = {};

  const fakePasteEvent = {
    clipboardData: { getData : () => fakePasteEventPayload },
    preventDefault: jasmine.createSpy('prevent default')
  };

  const fakeDragEvent = {
    dataTransfer: { getData : () => fakeDragEventPayload },
    preventDefault: jasmine.createSpy('prevent default')
  };

  let ngControl;

  const _ngControl = {
    control: {
      setErrors: jasmine.createSpy('setErrors'),
    }
  };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule
      ],
      providers: [
        { provide: NgControl, useValue: _ngControl }
      ],
      declarations: [ TelephoneComponent ]
    })
    .compileComponents();

    ngControl = TestBed.get(NgControl);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TelephoneComponent);
    component = fixture.componentInstance;
    debugComponent = fixture.debugElement;
    inputEls = fixture.debugElement.queryAll(By.css('input'));
    fixture.detectChanges();
  });

  afterEach(() => {
    fakePasteEvent.preventDefault.calls.reset();
    fakeDragEvent.preventDefault.calls.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('#validateOnBlur', () => {
    it('#validateOnBlur should call ngControl setErrors with the appropriate value', () => {
      const landlineNumber = '12345678';
      component.isPartOfForm = true;
      fixture.detectChanges();
      component.validateOnBlur(landlineNumber);
      expect(_ngControl.control.setErrors).toHaveBeenCalledWith(null);
    });

    it('#validateOnBlur should set landline to true after landline validation', () => {
      const landlineNumber = '12345678';

      component.validateOnBlur(landlineNumber);

      expect(component.showMobile).toEqual(true);
    });

    it('#validateOnBlur should change landline to false if mobile number is entered after landline validation', () => {
      const landlineNumber = '12345678';
      component.validateOnBlur(landlineNumber);
      expect(component.showMobile).toEqual(true);

      const mobileNumber = '72345678';
      component.validateOnBlur(mobileNumber);
      expect(component.showMobile).toEqual(false);
    });

    it('#validateOnBlur should change invalidContactNumber to true if invalid landline is entered', () => {
      const landlineNumber = '12315678';
      component.validateOnBlur(landlineNumber);
      expect(component.invalidContactflag).toEqual(true);
    });

    it('#validateOnBlur should change invalidContactNumber to false if valid landline is entered after landline validation', () => {
      const invalidLandlineNumber = '12315678';
      component.validateOnBlur(invalidLandlineNumber);
      expect(component.invalidContactflag).toEqual(true);

      const validLandlineNumber = '12345678';
      component.validateOnBlur(validLandlineNumber);
      expect(component.invalidContactflag).toEqual(false);
    });

    it('changes the error messages appropriately depending on which input is wrong', () => {
      expect(component.currentErrorMessage).toEqual(component.errorMessage.contact);

      const landlineNumber = '12345678';
      component.validateOnBlur(landlineNumber);
      expect(component.currentErrorMessage).toEqual(component.errorMessage.mobile);

      const wrongLandlineNumber = '12315678';
      component.validateOnBlur(wrongLandlineNumber);
      expect(component.currentErrorMessage).toEqual(component.errorMessage.contact);
    });
  });

  describe('#validateOnMobileBlur', () => {
    it('#validateOnMobileBlur should call ngControl setErrors with the appropriate value', () => {
      const landlineNumber = '12345678';
      const mobileNumber = '12345678';
      component.isPartOfForm = true;
      fixture.detectChanges();
      component.validateOnBlur(landlineNumber);
      expect(_ngControl.control.setErrors).toHaveBeenCalledWith(null);
      component.validateMobileOnBlur(mobileNumber);
      expect(_ngControl.control.setErrors).toHaveBeenCalledWith({ isValidMobileInput: 'false' });
    });

    it('#validateMobileOnBlur should change invalidMobileNumber to true if a landline number is entered', () => {
      const mobileNumber = '12345678';

      component.validateMobileOnBlur(mobileNumber);

      expect(component.invalidMobileflag).toEqual(true);
    });

    it('#validateMobileOnBlur should change invalidMobileflag to true if an invalid number is entered', () => {
      const mobileNumber = '00000000';

      component.validateMobileOnBlur(mobileNumber);

      expect(component.invalidMobileflag).toEqual(true);
    });

    it('#validateMobileOnBlur should change invalidMobileflag to false if a mobile number is entered after a landline', () => {
      const landlineNumber = '12345678';
      component.validateMobileOnBlur(landlineNumber);
      expect(component.invalidMobileflag).toEqual(true);

      const mobileNumber = '72345678';
      component.validateMobileOnBlur(mobileNumber);
      expect(component.invalidMobileflag).toEqual(false);
    });
  });

  describe('Control Value Accessor', () => {
    it('writeValue should work as expected', () => {
      component.writeValue('12345678'); // like angular would do

      expect(inputEls[1].nativeElement.value).toEqual('12345678');
    });

    it('calls _onTouched when registerOnTouched is called', () => {
      component.registerOnTouched(() => { });
      const spiedFunction = spyOn<any>(component, '_onTouched');

      inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
      fixture.detectChanges();

      expect(spiedFunction).toHaveBeenCalled();
    });

    it('calls _propagateChange when registerOnChange is called', async(() => {
      component.registerOnChange(() => { });
      const spiedFunction = spyOn<any>(component, '_propagateChange');

      inputEls[1].nativeElement.dispatchEvent(new Event('change'));
      fixture.detectChanges();

      expect(spiedFunction).toHaveBeenCalled();
    }));
  });

  describe('#isValidInput', () => {
    it('should return the right boolean depending on event key value', () => {
      expect(component.isValidInput({ key: '3' })).toBe(true);
      expect(component.isValidInput({ key: '6' })).toBe(true);
      expect(component.isValidInput({ key: 'a' })).toBe(false);

      expect(component.isValidInput({ code: 'Tab' })).toBe(true);
      expect(component.isValidInput({ code: 'Period' })).toBe(true);
      expect(component.isValidInput({ code: 'Backslash' })).toBe(false);
    });
  });

  describe('Paste events', () => {
    // e2e
    it('should not call preventDefault when event paste data is valid (e2e)', () => {
      fakePasteEventPayload = '123';

      inputEls[1].triggerEventHandler('paste', fakePasteEvent);

      expect(fakePasteEvent.preventDefault).not.toHaveBeenCalled();
    });

    // Unit Test
    it('should not call preventDefault when event paste data is valid', () => {
      fakePasteEventPayload = '123';

      component.pasteHandler(fakePasteEvent);

      expect(fakePasteEvent.preventDefault).not.toHaveBeenCalled();
    });

    // e2e
    it('should call preventDefault when event paste data is not valid (e2e)', () => {
      fakePasteEventPayload = 'abc';

      debugComponent.triggerEventHandler('paste', fakePasteEvent);

      expect(fakePasteEvent.preventDefault).toHaveBeenCalled();
    });

    // Unit Test
    it('should call preventDefault when event paste data is not valid', () => {
      fakePasteEventPayload = 'abc';

      component.pasteHandler(fakePasteEvent);

      expect(fakePasteEvent.preventDefault).toHaveBeenCalled();
    });
  });

  describe('Drag events', () => {
    // e2e
    it('should not call preventDefault when event drop data is valid (e2e)', () => {
      fakeDragEventPayload = '123';

      debugComponent.triggerEventHandler('drop', fakeDragEvent);

      expect(fakeDragEvent.preventDefault).not.toHaveBeenCalled();
    });

    // Unit Test
    it('should not call preventDefault when event paste data is valid', () => {
      fakeDragEventPayload = '123';

      component.dropHandler(fakeDragEvent);

      expect(fakeDragEvent.preventDefault).not.toHaveBeenCalled();
    });

    // e2e
    it('should call preventDefault when event drop data is not valid (e2e)', () => {
      fakeDragEventPayload = 'abc';

      debugComponent.triggerEventHandler('drop', fakeDragEvent);

      expect(fakeDragEvent.preventDefault).toHaveBeenCalled();
    });

    // Unit Test
    it('should call preventDefault when event paste data is not valid', () => {
      fakeDragEventPayload = 'abc';

      component.dropHandler(fakeDragEvent);

      expect(fakeDragEvent.preventDefault).toHaveBeenCalled();
    });
  });

  describe('#formatInput', () => {
    const event = {
      target: {
        value: undefined
      }
    };

    it('should return only numbers of any given value', () => {
      event.target.value = '123. 45, 678- 9';

      expect(component.formatInput(event)).toEqual('123456789');
    });

    it('should return only numbers of any given value without a leading 0', () => {
      event.target.value = '0123. 45, 678- 9';

      expect(component.formatInput(event)).toEqual('123456789');
    });
  });
});

/* In a reactive form */
@Component({
  template:
    `<form [formGroup]="reactiveForm">
      <s-telephone id="telephone" formControlName="telephoneControl"></s-telephone>
    </form>`,
})
class TestReactiveFormTelephoneComponent implements OnInit {
  reactiveForm: FormGroup;

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.reactiveForm = this.formBuilder.group({
      telephoneControl: new FormControl('')
    });
  }
}

describe('TelephoneInADummyReactiveForm', () => {
  let component: TestReactiveFormTelephoneComponent;
  let fixture: ComponentFixture<TestReactiveFormTelephoneComponent>;
  let inputEls: DebugElement[];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TelephoneComponent, TestReactiveFormTelephoneComponent],
      imports: [FormsModule, ReactiveFormsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(TestReactiveFormTelephoneComponent);

    component = fixture.componentInstance;
    fixture.detectChanges();
    inputEls = fixture.debugElement.queryAll(By.css('input'));
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should propagate the right value to the form', async(() => {
    inputEls[1].nativeElement.value = '71234567';
    inputEls[1].nativeElement.dispatchEvent(new Event('change')); // This needs to go first
    inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    expect(component.reactiveForm.controls.telephoneControl.value.contact).toEqual('71234567');
    expect(component.reactiveForm.status).toEqual('VALID');
  }));

  it('should propagate the right value to the form when the contact input has landline and second has mobile', async(() => {
    inputEls[1].nativeElement.value = '12345678';
    inputEls[1].nativeElement.dispatchEvent(new Event('change'));
    inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    inputEls = fixture.debugElement.queryAll(By.css('input'));

    inputEls[3].nativeElement.value = '71234567';
    inputEls[3].nativeElement.dispatchEvent(new Event('change'));
    inputEls[3].nativeElement.dispatchEvent(new Event('blur'));

    expect(component.reactiveForm.controls.telephoneControl.value.contact).toEqual('12345678');
    expect(component.reactiveForm.controls.telephoneControl.value.mobile).toEqual('71234567');
    expect(component.reactiveForm.status).toEqual('VALID');
  }));

  it('should propagate the right value to the form when the contact input has landline and second is empty', async(() => {
    inputEls[1].nativeElement.value = '12345678';
    inputEls[1].nativeElement.dispatchEvent(new Event('change'));
    inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    expect(component.reactiveForm.controls.telephoneControl.value.contact).toEqual('12345678');
    expect(component.reactiveForm.controls.telephoneControl.value.mobile).toEqual('');
    expect(component.reactiveForm.status).toEqual('VALID');
  }));
});

/* In a template driven form */
@Component({
  template:
    `<form #formRef="ngForm">
      <s-telephone id="telephone" ngModel name="telephone"></s-telephone>
    </form>`,
})
class TestTemplateFormTelephoneComponent {
  @ViewChild('formRef') formRef: NgForm;
}

describe('TelephoneInADummyTemplateForm', () => {
  let component: TestTemplateFormTelephoneComponent;
  let fixture: ComponentFixture<TestTemplateFormTelephoneComponent>;
  let inputEls: DebugElement[];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [TelephoneComponent, TestTemplateFormTelephoneComponent],
      imports: [FormsModule],
      providers: [ NgControl ]
    }).compileComponents();

    fixture = TestBed.createComponent(TestTemplateFormTelephoneComponent);

    component = fixture.componentInstance;
    fixture.detectChanges();
    inputEls = fixture.debugElement.queryAll(By.css('input'));
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should propagate the right value to the form', () => {
    inputEls[1].nativeElement.value = '71234567';
    inputEls[1].nativeElement.dispatchEvent(new Event('change'));
    inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    expect(component.formRef.controls.telephone.value.contact).toEqual('71234567');
    expect(component.formRef.status).toEqual('VALID');
  });

  it('should propagate an invalid value/status to the form', () => {
    inputEls[1].nativeElement.value = '12315678';
    inputEls[1].nativeElement.dispatchEvent(new Event('change'));
    inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    expect(component.formRef.controls.telephone.value.contact).toEqual('12315678');
    expect(component.formRef.status).toEqual('INVALID');
  });

  it('should propagate the right value to the form when the first input has landline and second has mobile', async(() => {
    inputEls[1].nativeElement.value = '12345678';
    inputEls[1].nativeElement.dispatchEvent(new Event('change'));
    inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    inputEls = fixture.debugElement.queryAll(By.css('input'));

    inputEls[3].nativeElement.value = '71234567';
    inputEls[3].nativeElement.dispatchEvent(new Event('change'));
    inputEls[3].nativeElement.dispatchEvent(new Event('blur'));

    expect(component.formRef.controls.telephone.value.contact).toEqual('12345678');
    expect(component.formRef.controls.telephone.value.mobile).toEqual('71234567');
    expect(component.formRef.status).toEqual('VALID');
  }));

  it('should propagate the right value to the form when the first input has landline and second is empty', async(() => {
    inputEls[1].nativeElement.value = '12345678';
    inputEls[1].nativeElement.dispatchEvent(new Event('change'));
    inputEls[1].nativeElement.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    expect(component.formRef.controls.telephone.value.contact).toEqual('12345678');
    expect(component.formRef.controls.telephone.value.mobile).toEqual('');
    expect(component.formRef.status).toEqual('VALID');
  }));
});
