import { LandlineValidations } from './landline-validations';

describe('Fields validations', () => {
  describe('#isValidLandlineNumber', () => {
    it('should return true if number starts with a 1 and continues with valid numbers', () => {
      const landline1 = '19971233';
      const landline2 = '11651233';
      const landline3 = '13397233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(true);
    });

    it('should return true if number starts with a 2 and continues with valid numbers', () => {
      const landline1 = '23801233';
      const landline2 = '29111233';
      const landline3 = '24111233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(true);
    });

    it('should return true if number starts with a 3 and continues with valid numbers', () => {
      const landline1 = '300801233';
      const landline2 = '303921233';
      const landline3 = '306201233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(true);
    });

    it('should return true if number starts with a 5 and continues with 5 or 6', () => {
      const landline1 = '550801233';
      const landline2 = '563921233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(true);
    });

    it('should return true if number starts with an 8 and continues with valid numbers', () => {
      const landline1 = '844801233';
      const landline2 = '845921233';
      const landline3 = '800921233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(true);
    });

    it('should return true if number starts with an 9 and continues with 0 or 1', () => {
      const landline1 = '902801233';
      const landline2 = '910921233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(true);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(true);
    });

    it('should return false if number starts with a 1 and continues with invalid numbers', () => {
      const landline1 = '19961233';
      const landline2 = '15231233';
      const landline3 = '11007233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(false);
    });

    it('should return false if number starts with a 2 and continues with invalid numbers', () => {
      const landline1 = '21801233';
      const landline2 = '25111233';
      const landline3 = '26111233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(false);
    });

    it('should return false if number starts with a 3 and continues with invalid numbers', () => {
      const landline1 = '310801233';
      const landline2 = '323921233';
      const landline3 = '366201233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(false);
    });

    it('should return false if number starts with a 5 and continues with invalid numbers', () => {
      const landline1 = '530801233';
      const landline2 = '523921233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(false);
    });

    it('should return false if number starts with an 8 and continues with invalid numbers', () => {
      const landline1 = '814801233';
      const landline2 = '865921233';
      const landline3 = '830921233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(false);
    });

    it('should return false if number starts with an 9 and continues with invalid numbers', () => {
      const landline1 = '922801233';
      const landline2 = '990921233';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(false);
    });

    it('should return false if any invalid landline number is entered', () => {
      const landline1 = '000000000';
      const landline2 = '777777777';
      const landline3 = '666666666';

      expect(LandlineValidations.isValidLandlineNumber(landline1)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline2)).toBe(false);
      expect(LandlineValidations.isValidLandlineNumber(landline3)).toBe(false);
    });
  });
});
