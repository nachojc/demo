import { LandlineValidations } from './landline/landline-validations';
import { FieldsValidations } from './type/type-validations';

export class TelephoneValidator {

  public static validateInput(inputValue) {
    if (inputValue === '') {
      return false;
    }

    return LandlineValidations.isValidLandlineNumber(inputValue) || FieldsValidations.isMobileNumber(inputValue);
  }

  public static validateMobileInput(mobileNumber) {
    return FieldsValidations.isMobileNumber(mobileNumber);
  }
}
