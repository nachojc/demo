// @dynamic
export class FieldsValidations {

  private static isValidNumber(telephoneNumber: string): boolean {
    return !(telephoneNumber === undefined || telephoneNumber.length < 8 || telephoneNumber.length > 10);
  }

  public static isLandlineNumber(telephoneNumber: string): boolean {
    const landlineStart = [ '1', '2', '3', '5', '8', '9' ];

    return this.isValidNumber(telephoneNumber) ? landlineStart.indexOf(telephoneNumber.charAt(0)) > -1 : false;
  }

  static isMobileNumber(mobileNumber: string): boolean {
    if (mobileNumber === '') {
      return true;
    }

    return this.isValidNumber(mobileNumber) ? mobileNumber.charAt(0) === '7' : false;
  }
}
