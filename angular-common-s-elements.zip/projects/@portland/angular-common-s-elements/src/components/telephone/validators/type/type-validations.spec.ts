import { FieldsValidations } from './type-validations';

describe('Fields validations', () => {
  describe('#isLandlineNumber', () => {
    it('should return true if telephone number is a landline', () => {
      const landlineNumberWith1 = '12345678';
      const landlineNumberWith2 = '22345678';

      expect(FieldsValidations.isLandlineNumber(landlineNumberWith1)).toEqual(true);
      expect(FieldsValidations.isLandlineNumber(landlineNumberWith2)).toEqual(true);
    });

    it('should return false if telephone number is not a landline', () => {
      const telephoneNumberWith0 = '02345678';
      const telephoneNumberWith4 = '42345678';
      const telephoneNumberWith6 = '62345678';

      expect(FieldsValidations.isLandlineNumber(telephoneNumberWith0)).toEqual(false);
      expect(FieldsValidations.isLandlineNumber(telephoneNumberWith4)).toEqual(false);
      expect(FieldsValidations.isLandlineNumber(telephoneNumberWith6)).toEqual(false);
    });

    it('should return false if telephone number is not 8 or more numbers in total', () => {
      const telephoneNumberShort = '1234567';

      expect(FieldsValidations.isLandlineNumber(telephoneNumberShort)).toEqual(false);
    });

    it('should return false if telephone number is 10 or more numbers in total', () => {
      const telephoneNumberLong = '12345678900';

      expect(FieldsValidations.isLandlineNumber(telephoneNumberLong)).toEqual(false);
    });

    it('should return false if telephone number is undefined', () => {
      const landlineNumber = undefined;

      expect(FieldsValidations.isLandlineNumber(landlineNumber)).toEqual(false);
    });
  });

  describe('#isMobileNumber', () => {
    it('should return true if telephone number is a mobile', () => {
      const mobileNumber = '72345678';

      expect(FieldsValidations.isMobileNumber(mobileNumber)).toEqual(true);
    });

    it('should return false if telephone number is not a mobile', () => {
      const mobileNumber = '12345678';

      expect(FieldsValidations.isMobileNumber(mobileNumber)).toEqual(false);
    });

    it('should return false if telephone number is not 8 or more numbers in total', () => {
      const mobileNumberShort = '7234567';

      expect(FieldsValidations.isMobileNumber(mobileNumberShort)).toEqual(false);
    });

    it('should return false if telephone number is 10 or more numbers in total', () => {
      const mobileNumberLong = '72345678900';

      expect(FieldsValidations.isMobileNumber(mobileNumberLong)).toEqual(false);
    });

    it('should return false if telephone number is undefined', () => {
      const mobileNumber = undefined;

      expect(FieldsValidations.isMobileNumber(mobileNumber)).toEqual(false);
    });

    it('should return true if telephone number is empty', () => {
      const mobileNumber = '';

      expect(FieldsValidations.isMobileNumber(mobileNumber)).toEqual(true);
    });
  });
});
