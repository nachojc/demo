import { TelephoneValidator } from './telephone.validator';

describe('TelephoneComponent', () => {
  it('#validateInput should return true if valid mobilePhone is entered', () => {
    const mobileNumber = '72345678';

    expect(TelephoneValidator.validateInput(mobileNumber)).toEqual(true);
  });

  it('#validateInput should return true if valid landlineNumber is entered', () => {
    const landline = '12345678';

    expect(TelephoneValidator.validateInput(landline)).toEqual(true);
  });

  it('#validateInput should return false if neither a valid landlineNumber or a valid mobileNumber is entered', () => {
    const invalidNumber = '02345678';

    expect(TelephoneValidator.validateInput(invalidNumber)).toEqual(false);
  });

  it('#validateMobileInput should return true if a valid mobile phone number is entered', () => {
    const mobileNumber = '72345678';

    expect(TelephoneValidator.validateMobileInput(mobileNumber)).toEqual(true);
  });

  it('#validateMobileInput should return false if an invalid mobile phone number is entered', () => {
    const mobileNumber = '02345678';

    expect(TelephoneValidator.validateMobileInput(mobileNumber)).toEqual(false);
  });

  it('#validateMobileInput should return false if a landline number is entered', () => {
    const mobileNumber = '12345678';

    expect(TelephoneValidator.validateMobileInput(mobileNumber)).toEqual(false);
  });
});
