import areaCodes from './area-codes';
import { FieldsValidations } from '../type/type-validations';

// @dynamic
export class LandlineValidations {

  public static isValidLandlineNumber(telephoneNumber: string): boolean {
    if (FieldsValidations.isLandlineNumber(telephoneNumber)) {
      switch (telephoneNumber.charAt(0)) {
        case '1':
          return areaCodes.areaCode01.indexOf(telephoneNumber.substring(1, 5)) > -1
              || areaCodes.areaCode01.indexOf(telephoneNumber.substring(1, 4)) > -1
              || areaCodes.areaCode01.indexOf(telephoneNumber.substring(1, 3)) > -1 ? true : false;
        case '2':
          return areaCodes.areaCode02.indexOf(telephoneNumber.substring(1, 4)) > -1
              || areaCodes.areaCode02.indexOf(telephoneNumber.charAt(1)) > -1 ? true : false;
        case '3':
          return areaCodes.areaCode03.indexOf(telephoneNumber.substring(1, 3)) > -1;
        case '5':
          return areaCodes.areaCode05.indexOf(telephoneNumber.charAt(1)) > -1;
        case '8':
          return areaCodes.areaCode08.indexOf(telephoneNumber.substring(1, 3)) > -1
              || areaCodes.areaCode08.indexOf(telephoneNumber.charAt(1)) > -1 ? true : false;
        case '9':
          return areaCodes.areaCode09.indexOf(telephoneNumber.charAt(1)) > -1;
      }
    } else {
      return false;
    }
  }
}
