import { Component, ElementRef, HostListener, Injector, Input, OnInit, ViewChild } from '@angular/core';
import { ControlValueAccessor, NgControl, NG_VALUE_ACCESSOR } from '@angular/forms';
import { TelephoneValidator } from './validators/telephone.validator';

@Component({
  selector: 's-telephone',
  templateUrl: './telephone.component.html',
  styleUrls: ['./telephone.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: TelephoneComponent, multi: true }
  ]
})
export class TelephoneComponent implements ControlValueAccessor, OnInit {
  @ViewChild('input') input: ElementRef;
  @ViewChild('mobileinput') mobileInput: ElementRef;

  @Input() prefix = {
    contact: '044',
    mobile: '+44'
  };
  @Input() errorMessage = {
    contact: 'Please enter a valid contact number',
    mobile: 'Please enter a valid mobile number'
  };
  @Input() disablePrefix = {
    contact: false,
    mobile: false
  };

  showMobile = false;
  invalidContactflag = false;
  invalidMobileflag = false;
  isPartOfForm = false;

  currentErrorMessage: string = this.errorMessage.contact;

  inputValues: any = {
    contact: '',
    mobile: ''
  };

  _propagateChange: Function;
  _onTouched: Function;

  ngControl: NgControl;

  private specialKeys = {
    'Backspace': true,
    'Enter': true,
    'Shift': true,
    'ArrowLeft': true,
    'ArrowUp': true,
    'ArrowRight': true,
    'ArrowDown': true,
    'Delete': true,
    'Tab': true,
    'Period': true,
    'Comma': true,
    'Minus': true
  };

  @HostListener('keypress', ['$event']) isValidInput(event) {
    return this.isNumber(event.key) || (!event.shiftKey && !event.altKey && this.isSpecialKey(event.code));
  }

  private isNumber(number): Boolean {
    return 0 <= number && number <= 9;
  }

  private isSpecialKey(key): Boolean {
    return this.specialKeys[key] === true;
  }

  @HostListener('paste', ['$event']) pasteHandler(event) {
    const clipboardData = event.clipboardData.getData('Text');

    if (!parseInt(clipboardData, 10)) {
      event.preventDefault();
    }
  }

  @HostListener('drop', ['$event']) dropHandler(event) {
    const dragData = event.dataTransfer.getData('Text');

    if (!parseInt(dragData, 10)) {
      event.preventDefault();
    }
  }

  constructor(
    private injector: Injector,
    private elRef: ElementRef
  ) { }

  ngOnInit() {
    this.ngControl = this.injector.get(NgControl, null);
    this.isPartOfForm = this.elRef.nativeElement.parentElement.nodeName === 'FORM';
  }

  validateOnBlur(value) {
    // Change the errorMessage dynamically
    if (value[0] !== '7' && TelephoneValidator.validateInput(value)) {
      this.showMobile = true;
      this.currentErrorMessage = this.errorMessage.mobile;
    } else {
      this.inputValues.mobile = '';
      this.showMobile = false;
      this.currentErrorMessage = this.errorMessage.contact;
    }

    TelephoneValidator.validateInput(value) ? this.invalidContactflag = false : this.invalidContactflag = true;
    if (this.isPartOfForm) {
      if (this.ngControl && TelephoneValidator.validateInput(value)) {
        this.ngControl.control.setErrors(null);
      } else {
        this.ngControl.control.setErrors({ isValidInput: 'false' });
      }
    }

    this.inputValues.contact = value; // Set the contact input value
  }

  validateMobileOnBlur(value) {
    TelephoneValidator.validateMobileInput(value) ? this.invalidMobileflag = false : this.invalidMobileflag = true;

    if (this.isPartOfForm) {
      if (this.ngControl && TelephoneValidator.validateMobileInput(value)) {
        this.ngControl.control.setErrors(null);
      } else {
        this.ngControl.control.setErrors({ isValidMobileInput: 'false' });
      }
    }

    this.inputValues.mobile = value; // Set the mobile input value
  }

  formatInput(event) {
    const el: HTMLInputElement = event.target;
    const newValue = [];
    const iterableInput = el.value.split('');

    iterableInput.forEach(char => {
      if (this.isNumber(char) && char !== ' ') {
        newValue.push(char);
      }
    });

    if (newValue[0] === '0') {
      newValue.shift();
    }

    el.value = newValue.join('').replace(/^[0]+/g, '');
    return el.value;
  }

  onChange() {
    if (this._propagateChange) {
      this._propagateChange(this.inputValues); // Propagate the telephone object with both inputs
    }
  }

  onTouched() {
    if (this._onTouched) {
      this._onTouched();
    }
  }

  writeValue(value: string): void {
    this.input.nativeElement.value = value;
  }

  registerOnChange(fn: any): void {
    this._propagateChange = fn;
  }

  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }
}
