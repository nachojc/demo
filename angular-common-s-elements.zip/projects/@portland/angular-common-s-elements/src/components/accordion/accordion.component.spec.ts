import { Renderer2, Type } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, NgControl } from '@angular/forms';
import { ErrorDirective } from '../../directives/error/error.directive';
import { CheckboxComponent } from '../checkbox/checkbox.component';
import { AccordionComponent } from './accordion.component';

describe('AccordionComponent', () => {
  let component: AccordionComponent;
  let fixture: ComponentFixture<AccordionComponent>;
  let toggleIconElm: HTMLElement;

  const registerOnChangeFn = jasmine.createSpy('registerOnChangeFn');

  const checkboxMock = <any>{
    valueAccessor: {
      registerOnChange: () => {},
      writeValue: () => {}
    },
    control: {
      invalid: false,
      markAsTouched: () => {}
    }
  };

  const _ngControl = <any>{
    name: 'title',
    touched: false,
    valueChanges: {
      subscribe: jasmine.createSpy('control value subscribe')
    },
    control: {
      statusChanges: {
        subscribe: jasmine.createSpy('control status subscribe'),
        emit: jasmine.createSpy('control status emit'),
      },
      touched: false,
      invalid: false,
      markAsUntouched: jasmine.createSpy('control markAsUntouched'),
      markAsTouched: jasmine.createSpy('control markAsTouched')
    }
  };

  const controlMock = <any>{
    setErrors: () => {},
    markAsTouched: () => {}
  };

  const scrollListenSpy = jasmine.createSpy('scrollListenSpy');
  const resizeListenSpy = jasmine.createSpy('resizeListenSpy');
  const resizeListenDocSpy = jasmine.createSpy('resizeListenDocSpy');
  let renderer2: Renderer2;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AccordionComponent,
        CheckboxComponent,
        ErrorDirective
      ],
      imports: [
        FormsModule
      ],
      providers: [
        { provide: NgControl, useValue: _ngControl },
        Renderer2,
      ]
    })
      .compileComponents();

    fixture = TestBed.createComponent(AccordionComponent);
    renderer2 = fixture.componentRef.injector.get<Renderer2>(Renderer2 as Type<Renderer2>);
    spyOn(renderer2, 'listen').and.returnValue('Scrolling event active');

    component = fixture.componentInstance;
    component.scrollListen = scrollListenSpy;
    component.resizeListen = resizeListenSpy;
    component.resizeListenDoc = resizeListenDocSpy;
    component.registerOnChange(registerOnChangeFn);

    fixture.detectChanges();
    toggleIconElm = fixture.nativeElement.querySelector('.icon');
  }));

  afterEach(() => {
    scrollListenSpy.calls.reset();
    resizeListenSpy.calls.reset();
    resizeListenDocSpy.calls.reset();
    registerOnChangeFn.calls.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the checkboxData in ngOnInit if its not provided', async () => {
    component.accordionName = 'Test accordion';
    component.checkboxData = { shown: true };
    component.ngOnInit();
    expect(component.checkboxData).toEqual({
      shown: true,
      text: 'Please tick the checkbox to confirm you have read and understood the Test accordion',
      errorText: 'Please tick the checkbox to confirm you have read and understood the information'
    });
  });

  it('#onCheckbox should set the validation property to true to when checkBox has been ticked and isRequired is true', () => {
    component._checkbox = checkboxMock;
    component.isRequired = true;
    component.control = controlMock;

    const checkboxNgModelSpy = spyOn(component._checkbox.valueAccessor, 'registerOnChange');
    component.onCheckbox(true);

    expect(component.validation).toEqual(true);
    expect(checkboxNgModelSpy).toHaveBeenCalledWith(true);
  });

  it('#onCheckbox should set the validation property to false to when checkBox has not been ticked', () => {
    checkboxMock.control.invalid = true;
    fixture.detectChanges();
    component._checkbox = checkboxMock;
    component.control = controlMock;
    component.isRequired = true;

    const checkboxNgModelSpy = spyOn(component._checkbox.valueAccessor, 'registerOnChange');
    component.onCheckbox(false);
    expect(component.validation).toEqual(false);
    expect(checkboxNgModelSpy).toHaveBeenCalledWith(false);
  });

  it('#validateAccordionOnScroll should check that scrolling is at the bottom and set validation when required is true', () => {
    const textContentMock = <any> {
      scrollTop: 1
    };
    component._checkbox = null;
    component.isRequired = true;
    component.hasScrolledToBottom = false;

    component.validateAccordionOnScroll(textContentMock, 2);

    expect(component.validation).toEqual(true);
    expect(component.hasScrolledToBottom).toEqual(true);
  });

  it('#validateAccordionOnScroll should only propagate value when control is present', () => {
    component.hasScrolledToBottom = false;

    const textContentMock = <any> {
      scrollTop: 1
    };
    component._checkbox = null;
    component.isRequired = false;
    component.control = controlMock;

    component.validateAccordionOnScroll(textContentMock, 2);

    expect(registerOnChangeFn).toHaveBeenCalledWith(true);
    expect(component.validation).toEqual(false);
    expect(component.hasScrolledToBottom).toEqual(true);
  });

  it('#validateAccordionOnScroll should not propagate value or set validation when scrolling is less than maxScrollingHeight', () => {
    const textContentMock = <any> {
      scrollTop: 0
    };

    component.validateAccordionOnScroll(textContentMock, 2);

    expect(registerOnChangeFn).not.toHaveBeenCalled();
    expect(component.validation).toEqual(undefined);
    expect(component.hasScrolledToBottom).toEqual(false);
  });

  it('#validateOnOpen should be called when accordion is opened and set the #validation to true when required is true', () => {
    const validateOnOpenSpy = spyOn(component, 'validateOnOpen').and.callThrough();

    component._checkbox = null;
    component.isRequired = true;
    fixture.detectChanges();

    toggleIconElm.click();
    fixture.detectChanges();

    expect(validateOnOpenSpy).toHaveBeenCalled();
    expect(component.validation).toEqual(true);
  });

  it('#validateOnOpen should be called when accordion is opened and only #propagateChange when required is false', () => {
    const validateOnOpenSpy = spyOn(component, 'validateOnOpen').and.callThrough();

    component._checkbox = null;
    component.isRequired = false;
    fixture.detectChanges();

    toggleIconElm.click();
    fixture.detectChanges();


    expect(validateOnOpenSpy).toHaveBeenCalled();
    expect(component.validation).toEqual(null);
  });

  it('#validateOnClose should be called when accordion is closed', () => {
    const validateOnCloseSpy = spyOn(component, 'validateOnClose').and.callThrough();
    checkboxMock.control.invalid = true;
    component._checkbox = checkboxMock;
    component.control = controlMock;

    const registerOnChangeSpy = spyOn(component._checkbox.valueAccessor, 'registerOnChange').and.callThrough();
    const markAsTouchedSpy = spyOn(component._checkbox.control, 'markAsTouched').and.callThrough();

    component.isOpened = true;
    component.onToggleAccordion();


    expect(validateOnCloseSpy).toHaveBeenCalled();
    expect(markAsTouchedSpy).toHaveBeenCalled();
    expect(registerOnChangeSpy).toHaveBeenCalledWith(false);
  });

  it('#validateOnClose should be called when accordion is closed and should set errors on accordion when scrollable and invalid', () => {
    const validateOnCloseSpy = spyOn(component, 'validateOnClose').and.callThrough();

    component._checkbox = null;
    component.control = controlMock;

    toggleIconElm.click();
    fixture.detectChanges();

    component.isScrollable = true;
    component.isRequired = true;
    component.hasScrolledToBottom = false;

    toggleIconElm.click();
    fixture.detectChanges();


    expect(validateOnCloseSpy).toHaveBeenCalled();
    expect(component.validation).toEqual(false);
    expect(registerOnChangeFn).toHaveBeenCalledWith(false);
  });

  it('#validateOnClose should be called when accordion is closed and should NOT set errors on accordion when scrollable and valid', () => {
    const validateOnCloseSpy = spyOn(component, 'validateOnClose').and.callThrough();

    component._checkbox = null;
    component.control = controlMock;

    toggleIconElm.click();
    fixture.detectChanges();

    component.isScrollable = true;
    component.isRequired = true;
    component.hasScrolledToBottom = true;

    toggleIconElm.click();
    fixture.detectChanges();


    expect(validateOnCloseSpy).toHaveBeenCalled();
    expect(registerOnChangeFn).toHaveBeenCalledWith(true);
  });

  it('#validateOnClose should be called when accordion is closed and should set errors when scrollable, not required and invalid', () => {
    const validateOnCloseSpy = spyOn(component, 'validateOnClose').and.callThrough();

    component._checkbox = null;
    component.control = controlMock;

    toggleIconElm.click();
    fixture.detectChanges();

    component.isScrollable = true;
    component.isRequired = false;
    component.hasScrolledToBottom = false;

    toggleIconElm.click();
    fixture.detectChanges();


    expect(validateOnCloseSpy).toHaveBeenCalled();
    expect(component.validation).toEqual(null);
    expect(registerOnChangeFn).toHaveBeenCalledWith(false);
  });

  it('#validateOnClose should be called when accordion is closed and should set NOT errors when scrollable, NOT required and valid', () => {
    const validateOnCloseSpy = spyOn(component, 'validateOnClose').and.callThrough();

    component._checkbox = null;
    component.control = controlMock;

    toggleIconElm.click();
    fixture.detectChanges();

    component.isScrollable = true;
    component.isRequired = false;
    component.hasScrolledToBottom = true;

    toggleIconElm.click();
    fixture.detectChanges();

    expect(validateOnCloseSpy).toHaveBeenCalled();
    expect(component.validation).toEqual(null);
    expect(registerOnChangeFn).toHaveBeenCalledWith(true);
  });

  it('#onScroll should set the number of dots to have been filled and call #validateAccordionOnScroll', () => {
    const fakeFunction = () => {};
    const validateAccordionOnScrollSpy = spyOn(component, 'validateAccordionOnScroll').and.callFake(fakeFunction);
    component.dots = 5;
    component.textContent = <any>{
      scrollTop: 159.0,
      scrollHeight: 710.0,
      offsetHeight: 310.0
    };

    component.onScroll();
    expect(component.currentDot).toEqual(2.00);
    expect(validateAccordionOnScrollSpy).toHaveBeenCalled();
  });

  it('#checkIfControlIsRequired should set isRequired to true if ngControl has required attribute', () => {
    const ngControl = <any>{
      control: {
        validator: () => {
          return {required: true};
        }
      }
    };

    component.checkIfControlIsRequired(ngControl);

    expect(component.isRequired).toEqual(true);
  });

  // tslint:disable-next-line:max-line-length
  it('#onToggleAccordion should set isOpened to true if false, if scrollHeight < 600 set isScrollable to false and call validateOnOpen', () => {
    component.control = controlMock;
    const validateOnOpenSpy = spyOn(component, 'validateOnOpen');

    component.onToggleAccordion();

    expect(component.dots).toEqual(0);
    expect(component.isOpened).toEqual(true);
    expect(component.isScrollable).toEqual(false);
    expect(validateOnOpenSpy).toHaveBeenCalled();

  });

  it('#checkIfScrollable should start listing to scrolling event if scrollHeight > 600', () => {
    component.textContent = <any>{
      scrollTop: 159.0,
      scrollHeight: 710.0,
      offsetHeight: 310.0
    };
    component.checkIfScrollable();

    expect(component.scrollListen).toEqual('Scrolling event active');
  });

  it('#onToggleAccordion should call #validateOnClose when isOpened is false', () => {
    component.isOpened = true;
    const validateOnCloseSpy = spyOn(component, 'validateOnClose');

    component.onToggleAccordion();

    expect(component.isOpened).toEqual(false);
    expect(component.isScrollable).toEqual(true);
    expect(validateOnCloseSpy).toHaveBeenCalled();
  });

  it('#registerOnTouched should set the checkbox registerOnTouched function if there is a checkbox', () => {
    const mockRegisterOnTouchedFn = () => { 'mock function'; };
    component._checkbox = checkboxMock;

    component.registerOnTouched(mockRegisterOnTouchedFn);

    expect(component._checkbox.valueAccessor.registerOnTouched).toEqual(mockRegisterOnTouchedFn);
  });

  it('#ngAfterContentInit should call checkIfControlIsRequired if there is a NgControl present', () => {
    const checkIfControlIsRequiredSpy = spyOn(component, 'checkIfControlIsRequired');
    component.ngAfterContentInit();

    expect(component.control).toEqual(_ngControl.control);
    expect(checkIfControlIsRequiredSpy).toHaveBeenCalled();
  });

  it('#ngOnDestroy should end call listeners', () => {
    component.ngOnDestroy();

    expect(scrollListenSpy).toHaveBeenCalled();
    expect(resizeListenSpy).toHaveBeenCalled();
    expect(resizeListenDocSpy).toHaveBeenCalled();
  });

  it('#writeValue should set writeValue of checkbox', () => {
    component._checkbox = checkboxMock;

    const writeValueSpy = spyOn(component._checkbox.valueAccessor, 'writeValue');
    component.writeValue(false);

    expect(writeValueSpy).toHaveBeenCalledWith(false);
  });

  it('should set the #registerOnChange function for the checkbox on init if its present', () => {
    const mockFunction = () => 'Getting changes';
    component._checkbox = checkboxMock;

    component.registerOnChange(mockFunction);
    fixture.detectChanges();

    expect(component._checkbox.valueAccessor.registerOnChange).toEqual(mockFunction);
  });

  it('#valueEmitter should emit value if a control is not present', () => {
    const valueEmitterSpy = spyOn(component.valueEmitter, 'emit');
    component.control = null;
    checkboxMock.control.invalid = true;
    fixture.detectChanges();

    component.validateOnClose();

    expect(valueEmitterSpy).toHaveBeenCalledWith(false);
  });

  it('#valueEmitter should emit value if a control is not present', () => {
    const valueEmitterSpy = spyOn(component.valueEmitter, 'emit');
    component._checkbox = checkboxMock;
    component.control = null;
    checkboxMock.control.invalid = true;
    fixture.detectChanges();

    component.validateOnClose();
    expect(valueEmitterSpy).toHaveBeenCalledWith(false);
  });
});
