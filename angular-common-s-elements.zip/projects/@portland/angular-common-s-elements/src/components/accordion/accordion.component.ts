// tslint:disable-next-line:max-line-length
import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit } from '@angular/core';
import { Output, Renderer2, ViewChild, AfterContentInit, Injector } from '@angular/core';
import { NgModel, ControlValueAccessor, NgControl, AbstractControl, NG_VALUE_ACCESSOR } from '@angular/forms';

import { CheckboxInformation } from './accordion.component.model';

@Component({
  selector: 's-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: [
    './accordion.component.scss',
    '../../styles/error.scss'
  ],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    useExisting: AccordionComponent,
    multi: true
  }]
})

export class AccordionComponent implements OnInit, AfterContentInit, OnDestroy, ControlValueAccessor {

  private _dots = 0;
  @Input()
    set dots(value: any ) {
      const tmpNum =  parseInt(value, 10);
      this._dots = !isNaN(tmpNum ) ? tmpNum : this._dots;
      this.dotElements = Array(this._dots).fill(false);
    }
    get dots() {
      return this._dots;
    }

  @Input() accordionName: string;
  @Input() checkboxData: CheckboxInformation = {
    shown: false,
    text: 'Please tick the checkbox to confirm you have read and understood the ' + (this.accordionName || ''),
    errorText: 'Please tick the checkbox to confirm you have read and understood the information'
  };


  @Output() valueEmitter: EventEmitter<any> = new EventEmitter<any>();
  @ViewChild('checkbox') _checkbox: NgModel;

  currentDot = 0;
  dotElements = [];

  textContent: HTMLElement;
  isOpened = null;
  isScrollable = true;
  isRequired: boolean;
  hasScrolledToBottom = false;
  validation: true | false | '';
  control: AbstractControl;

  resizeListen: Function;
  resizeListenDoc: Function;
  scrollListen: Function;
  private _propagateChange: Function = () => {};
  private _propagateTouch: Function = () => {};


  constructor(private el: ElementRef, private renderer: Renderer2, private injector: Injector ) { }

  ngOnInit() {
    if (this.checkboxData && this.checkboxData.shown && !this.checkboxData.errorText && !this.checkboxData.text) {
      this.checkboxData = {
        shown: true,
        text: 'Please tick the checkbox to confirm you have read and understood the ' + this.accordionName,
        errorText: 'Please tick the checkbox to confirm you have read and understood the information'
      };
    }
  }

  ngAfterContentInit () {
    const ngControl: NgControl = this.injector.get(NgControl, null);
    if (ngControl) {
      this.control = ngControl.control;
      this.checkIfControlIsRequired(ngControl);
    } else {
      if (this.el.nativeElement.attributes.required) {
        this.isRequired = true;
      }
    }
  }

  ngOnDestroy() {
    if (this.scrollListen && this.resizeListen && this.scrollListen) {
      this.scrollListen();
      this.resizeListen();
      this.resizeListenDoc();
    }
  }

  onScroll() {
    const maxScrollableHeight = this.textContent.scrollHeight - this.textContent.offsetHeight;

    this.currentDot = parseFloat(( (this.textContent.scrollTop + 1 ) / (maxScrollableHeight / this._dots)).toFixed(2));
    this.currentDot = this.currentDot > 0 ? this.currentDot : 0; // this keeps the first dot filled by default
    this.validateAccordionOnScroll(this.textContent, maxScrollableHeight);
  }

  onToggleAccordion() {
    if (!this.isOpened) {
      this.isOpened = true;
      this.textContent = this.el.nativeElement.querySelector('.text-content');

      this._propagateTouch();

      this.checkIfScrollable();

      if (!this.validation) { this.validation = null; }

    } else {
      this.validateOnClose();
      this.isOpened = false;
      this.isScrollable = true;
    }

  }

  checkIfScrollable() {
    if (this.textContent && this.textContent.scrollHeight < 600) {
      this.dots = 0;
      this.isScrollable = false;
      this.validateOnOpen();
    } else {
      this.scrollListen = this.renderer.listen(this.textContent, 'scroll', this.onScroll.bind(this));
    }
  }

  onCheckbox(value) {
    if (this.isRequired) {
      this.validation = (value === true);
    }

    if (this._checkbox) {
      if (this._checkbox.control.invalid) {
        if (this.control) {
          this._checkbox.valueAccessor.registerOnChange(false);
        } else {
          this.valueEmitter.emit(false);
        }
      } else {
        this.control ? this._checkbox.valueAccessor.registerOnChange(true) : this.valueEmitter.emit(true);
      }
    }
  }

  writeValue(value: boolean): void {
    if (this._checkbox && typeof value === 'boolean') {
      this._checkbox.valueAccessor.writeValue(value);
    }
  }
  registerOnChange(fn: any): void {
    if (this._checkbox) {
      this._checkbox.valueAccessor.registerOnChange = fn;
    } else {
      this._propagateChange = fn;
    }
  }
  registerOnTouched(fn: any): void {
    if (this._checkbox) {
      this._checkbox.valueAccessor.registerOnTouched = fn;
    } else {
      this._propagateTouch = fn;
    }
  }

  validateOnOpen() {
    if (!this._checkbox) {
      this.control ? this._propagateChange(true) : this.valueEmitter.emit(true);
      this.validation = this.isRequired;
    }
  }

  validateAccordionOnScroll(textContent: HTMLElement, maxScrollableHeight) {
    if (textContent.scrollTop + 1 >= maxScrollableHeight && !this._checkbox && !this.hasScrolledToBottom) {
      this.validation = this.isRequired;
      this.hasScrolledToBottom = true;
      this.control ? this._propagateChange(true) : this.valueEmitter.emit(true);
    }
  }

  validateOnClose() {
    if (this._checkbox && this._checkbox.control.invalid) {
      this._checkbox.control.markAsTouched();
      if (this.control) {
        this._checkbox.valueAccessor.registerOnChange(false);
      } else {
        this.valueEmitter.emit(false);
      }
    }

    if (!this._checkbox && this.isScrollable && !this.hasScrolledToBottom) {
      if (this.isRequired) {
        this.validation = false;
      }
      this.control ? this._propagateChange(false) : this.valueEmitter.emit(false);
    }
  }

  checkIfControlIsRequired(ngControl: NgControl) {
    const functionToEvaluate = ngControl && ((ngControl.control && ngControl.control.validator) || ngControl.validator);
    if (functionToEvaluate) {
      const validations = functionToEvaluate(<any>'');
      if (validations && validations.required) {
        this.isRequired = true;
      }
    }
  }

}
