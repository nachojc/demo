export interface CheckboxInformation {
    shown: boolean;
    text?: string;
    errorText?: string;
}
