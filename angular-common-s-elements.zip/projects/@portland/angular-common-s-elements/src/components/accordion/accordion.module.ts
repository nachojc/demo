import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccordionComponent } from './accordion.component';
import { SCheckboxComponentModule } from '../checkbox/checkbox.module';
import { FormsModule } from '@angular/forms';
import { SErrorDirectiveModule } from '../../directives/error/error.module';

@NgModule({
  declarations: [
    AccordionComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SCheckboxComponentModule,
    SErrorDirectiveModule
  ],
  exports: [
    AccordionComponent
  ]
})
export class SAccordionComponentModule { }
