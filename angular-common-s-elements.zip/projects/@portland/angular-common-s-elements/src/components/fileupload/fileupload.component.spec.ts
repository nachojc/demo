import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SFileUploadComponent } from './fileupload.component';
import { FileUploadService } from '../../services/fileupload/fileupload.service';
import { UploadStatus, CustomUploadFile, UploadFile } from '../../models/fileupload/fileupload.model';
import { of, throwError, Observable } from 'rxjs';

describe('SFileUploadComponent', () => {
  let component: SFileUploadComponent;
  let fixture: ComponentFixture<SFileUploadComponent>;
  let service: FileUploadService;

  let fileEvent;
  let fileUploaded: CustomUploadFile;

  class FileUploadServiceMock implements FileUploadService {
    startUpload(file: UploadFile): Observable<CustomUploadFile> {
      return null;
    }
    cancelUpload() {

    }
  }

  beforeEach(() => {
    TestBed
      .configureTestingModule({
        declarations: [SFileUploadComponent],
        providers: [
          {
            provide: 'GenericUploadService',
            useClass: FileUploadServiceMock
          }
        ]
      })
      .compileComponents();
  });

  beforeEach(() => {
    service = TestBed.get('GenericUploadService');
    fixture = TestBed.createComponent(SFileUploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();

    fileEvent = {
      target: {
        files: [
          {
            name: 'filename',
            size: '1'
          }
        ]
      }
    };

    fileUploaded = {
      id: '1',
      nativefile: null,
      name: 'dummyFile',
      status: UploadStatus.Completed,
      customFields: null
    };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    expect(component.fileHandler.status).toBe(UploadStatus.Ready);
  });

  it('should emit value on completed', () => {
    spyOn(service, 'startUpload').and.returnValue(of(fileUploaded));
    spyOn(component.completed, 'emit');

    component.fileChanged(fileEvent);

    expect(component.fileHandler.status).toBe(UploadStatus.Completed);
    expect(component.completed.emit).toHaveBeenCalledWith(fileUploaded);
    expect(service.startUpload).toHaveBeenCalled();
  });

  it('should not emit value if not completed', () => {

    fileUploaded.status = UploadStatus.Invalid;
    spyOn(service, 'startUpload').and.returnValue(of(fileUploaded));
    spyOn(component.completed, 'emit');

    component.fileChanged(fileEvent);

    expect(component.fileHandler.status).toBe(UploadStatus.Invalid);
    expect(component.completed.emit).not.toHaveBeenCalled();
    expect(service.startUpload).toHaveBeenCalled();
  });

  it('should emit known error', () => {

    const retVal = new CustomUploadFile();
    retVal.id = 'root';
    retVal.status = UploadStatus.Invalid;

    spyOn(service, 'startUpload').and.returnValue(throwError('INVALID'));
    spyOn(component.completed, 'emit');

    component.fileChanged(fileEvent);

    expect(service.startUpload).toHaveBeenCalled();
    expect(component.fileHandler.status).toBe(UploadStatus.Invalid);
    expect(component.completed.emit).toHaveBeenCalledWith(retVal);


  });

  it('should emit unknown error as error', () => {

    const retVal = new CustomUploadFile();
    retVal.id = 'root';
    retVal.status = UploadStatus.Error;

    spyOn(service, 'startUpload').and.returnValue(throwError('OTHER'));
    spyOn(component.completed, 'emit');

    component.fileChanged(fileEvent);

    expect(service.startUpload).toHaveBeenCalled();
    expect(component.fileHandler.status).toBe(UploadStatus.Error);
    expect(component.completed.emit).toHaveBeenCalledWith(retVal);

  });

  it('should reset status', () => {

    const file = new UploadFile();
    file.status = UploadStatus.Uploading;

    component.resetFileStatus(file);

    expect(component.fileHandler).toBe(file);
    expect(component.fileHandler.status).toBe(UploadStatus.Uploading);
  });

  it('should cancel upload', () => {

    spyOn(service, 'cancelUpload');
    spyOn(component.completed, 'emit');

    const retVal = new CustomUploadFile();
    retVal.id = 'root';
    retVal.status = UploadStatus.Ready;

    const fileHandlerBefore = component.fileHandler;

    const file = new UploadFile();
    file.status = UploadStatus.Completed;

    component.cancelUpload();

    expect(service.cancelUpload).toHaveBeenCalledWith(fileHandlerBefore);
    expect(component.fileHandler.status).toBe(UploadStatus.Ready);
    expect(component.fileHandler.name).toBe('');
    expect(component.completed.emit).toHaveBeenCalledWith(retVal);
  });

});
