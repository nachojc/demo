import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SFileUploadComponent } from './fileupload.component';

@NgModule({
  imports: [CommonModule],
  declarations: [SFileUploadComponent],
  exports: [SFileUploadComponent]
})
export class SFileUploadModule { }
