import { Component, OnInit, Input, Inject, Output, EventEmitter } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { UploadStatus, UploadFile, CustomUploadFile } from '../../models/fileupload/fileupload.model';
import { FileUploadService } from '../../services/fileupload/fileupload.service';

@Component({
  selector: 's-file-uploader',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.scss', '../../assets/styles/s-button.css', '../../assets/styles/s-link.css']
})
export class SFileUploadComponent implements OnInit {

  @Input() buttonText ?= 'Upload document';
  @Input() errorFileMsg ?= 'There was an error while uploading your document. Please try again.';
  @Input() invalidFileMsg ?= 'Invalid filename or filetype. Please check your file name and file '
    + 'type are correct (e.g. "passport.jpeg", "drivingLicense.pdf").';
  @Input() genericErrorMsg ?= 'Alternatively you can proceed with completing the form however we will '
    + 'need to contact you at a later date for further information.';
  @Input() uploadingMsg ?= 'Uploading your document...';
  @Input() acceptedFileTypes ?= 'application/pdf,image/png,image/jpeg';
  @Input() id = 'root';
  @Input() successImg ?= './assets/images/checkbox2.jpg';
  @Output() completed = new EventEmitter<CustomUploadFile>();

  public fileHandler: UploadFile;
  public fileStatus = UploadStatus;

  constructor(@Inject('GenericUploadService') private uploadService: FileUploadService) { }

  ngOnInit() {
    this.fileHandler = new UploadFile();
    this.fileHandler.id = this.id;
    this.fileHandler.status = UploadStatus.Ready;
  }

  public resetFileStatus(file: UploadFile) {
    this.fileHandler = file;
  }

  fileChanged(event) {
    const fileToUpload = event.target.files[0];
    if (!fileToUpload) {
      return;
    }
    this.fileHandler.nativefile = fileToUpload;
    this.fileHandler.name = fileToUpload.name;

    this.fileHandler.status = UploadStatus.Uploading;
    this.uploadService.startUpload(this.fileHandler).pipe(
      map(fileUploaded => {
        this.fileHandler.status = fileUploaded.status;
        if (fileUploaded.status === UploadStatus.Completed) {
          this.completed.emit(fileUploaded);
        }
      }),
      catchError(error => {
        const findKey: string = Object.keys(UploadStatus).find(key => UploadStatus[key] === error);
        const retVal = new CustomUploadFile();
        retVal.id = this.id;
        if (findKey) {
          retVal.status = UploadStatus[findKey];
          this.fileHandler.status = UploadStatus[findKey];
        } else {
          retVal.status = UploadStatus.Error;
          this.fileHandler.status = UploadStatus.Error;
        }
        this.completed.emit(retVal);
        return retVal.status;
      })
    ).subscribe();
  }

  removeFile() {
    this.fileHandler.name = '';
    this.fileHandler.status = UploadStatus.Ready;
    const retVal = new CustomUploadFile();
    retVal.id = this.id;
    retVal.status = UploadStatus.Ready;
    this.completed.emit(retVal);
  }

  cancelUpload() {
    this.uploadService.cancelUpload(this.fileHandler);
    this.removeFile();
  }

  public isStatus(status: UploadStatus): Boolean {
    return this.fileHandler.status === status;
  }

}
