import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CheckboxComponent } from './checkbox.component';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';
import { ReactiveFormsModule, FormControl, FormsModule } from '@angular/forms';

describe('CheckboxComponent', () => {
  let component: CheckboxComponent;
  let fixture: ComponentFixture<CheckboxComponent>;
  let checkboxEl;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CheckboxComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(CheckboxComponent);
    component = fixture.componentInstance;
    checkboxEl = fixture.debugElement.query(By.css('input')).nativeElement;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have the following properties by default', () => {
    expect(component._required).not.toBeNull();
  });

  it('component value should be true when element is checked', () => {
    checkboxEl.click();
    expect(checkboxEl.checked).toEqual(true);
    expect(component.value).toEqual(true);
  });

  it('component value should be empty when element is not checked', () => {
    expect(checkboxEl.checked).toEqual(false);
    checkboxEl.click();
    checkboxEl.click();
    expect(checkboxEl.checked).toEqual(false);
    expect(component.value).toEqual('');
  });

  it('emits the right value (true) to the parent when a click happens', () => {
    component.valueChange.subscribe((value) => {
      expect(value).toBe(true);
    });
    checkboxEl.click();
  });

  it('emits the right value (\'\') to the parent after clicking twice', () => {
    const obs = component.valueChange.subscribe((value) => {
      expect(value).toBe(true);
    });
    checkboxEl.click();
    obs.unsubscribe();

    component.valueChange.subscribe((value) => {
      expect(value).toBe('');
    });
    checkboxEl.click();
  });

  it('should change value when writeValue function is run', () => {
    expect(component.value).toBeUndefined();

    component.writeValue(true);
    expect(component.value).toBe(true);
  });

  it('calls registerOnChange inside a form context when click event is triggered', async(() => {
    component.registerOnChange(() => { });
    const spiedFunction = spyOn<any>(component, '_propagateChange');

    checkboxEl.dispatchEvent(new Event('click'));
    fixture.detectChanges();

    expect(spiedFunction).toHaveBeenCalled();
  }));

  it('eventEmitter is called as Output', async(() => {
    component.valueChange.subscribe(value => {
      expect(value).toEqual(true);
    });
    checkboxEl.click();
    component.valueChange.unsubscribe();
  }));

  it('calls registerOnTouched inside a form context when blur event is triggered', async(() => {
    component.registerOnTouched(() => { });
    const spiedFunction = spyOn<any>(component, '_onTouched');

    checkboxEl.dispatchEvent(new Event('blur'));
    fixture.detectChanges();

    expect(spiedFunction).toHaveBeenCalled();
  }));
});

/* In a reactive form */
@Component({
  template:
    `<form ngForm>
        <s-checkbox [formControl]="checkboxControl">Check this</s-checkbox>
        <s-checkbox [formControl]="checkboxControlPrepopulated">Check this</s-checkbox>
      </form>`
})
class TestTemplateFormComponent {
  checkboxControl = new FormControl();
  checkboxControlPrepopulated = new FormControl(true);
}

describe('CheckboxComponent in a dummy Reactive-Driven Form', () => {
  let fixture, form, checkboxDebug, inputElement, labelClassElement, checkboxTextElement, checkboxDebugPrepopulated;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule],
      declarations: [CheckboxComponent, TestTemplateFormComponent]
    })
      .compileComponents();

    fixture = TestBed.createComponent(TestTemplateFormComponent);
    form = fixture.componentInstance;
    const checkboxes = fixture.debugElement.queryAll(By.css('s-checkbox'));
    checkboxDebug = checkboxes[0];
    inputElement = <HTMLInputElement>checkboxDebug.nativeElement.querySelector('input');
    labelClassElement = <HTMLDivElement>checkboxDebug.nativeElement.querySelector('label');
    checkboxTextElement = <HTMLDivElement>checkboxDebug.nativeElement.querySelector('.label');

    checkboxDebugPrepopulated = checkboxes[1];
    fixture.detectChanges();
  }));

  it('should change to ng-touched once checkbox is clicked', () => {
    expect(form.checkboxControl.untouched).toBe(true);

    inputElement.click();
    fixture.detectChanges();

    expect(form.checkboxControl.untouched).toBe(false);
    expect(checkboxDebug.classes['ng-touched']).toBe(true);
  });

  it('should change ng-dirty once checkbox is clicked', () => {
    expect(form.checkboxControl.pristine).toBe(true);

    inputElement.click();
    fixture.detectChanges();

    expect(form.checkboxControl.pristine).toBe(false);
    expect(checkboxDebug.classes['ng-dirty']).toBe(true);
  });

  it('should change to ng-touched once div.label is clicked', () => {
    expect(form.checkboxControl.untouched).toBe(true);

    labelClassElement.click();
    fixture.detectChanges();

    expect(form.checkboxControl.untouched).toBe(false);
    expect(checkboxDebug.classes['ng-touched']).toBe(true);
  });

  it('should change to ng-touched once div.label is clicked', () => {
    expect(form.checkboxControl.untouched).toBe(true);

    checkboxTextElement.click();
    fixture.detectChanges();

    expect(form.checkboxControl.untouched).toBe(false);
    expect(checkboxDebug.classes['ng-touched']).toBe(true);
  });

  it('should change to ng-dirty once div.label is clicked', () => {
    expect(form.checkboxControl.pristine).toBe(true);

    labelClassElement.click();
    fixture.detectChanges();

    expect(form.checkboxControl.pristine).toBe(false);
    expect(checkboxDebug.classes['ng-dirty']).toBe(true);
  });

  it('should propagate true value to the form once clicked', () => {
    labelClassElement.click();
    expect(form.checkboxControl.value).toBe(true);
  });

  it('should have a null value at beginning in case checkboxControl', () => {
    expect(form.checkboxControl.value).toBeNull();
  });

  it('should propagate empty string value to the form once is clicked twice', () => {
    labelClassElement.click();
    labelClassElement.click();
    expect(form.checkboxControl.value).toEqual('');
  });

  it('should have a prepopulated value in case checkboxControlPrepopulated', () => {
    expect(checkboxDebugPrepopulated.componentInstance.value).toBe(true);
  });
});
