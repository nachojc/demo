import { HttpClient, HttpHandler } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import * as chai from 'chai';
import { assert } from 'chai';
import { of, throwError } from 'rxjs';
import * as sinon from 'sinon';
import * as sinonChai from 'sinon-chai';
import { byDataQa, simulateEvent } from '../../../../../../test-utils/test-helpers';
import { PafItem } from '../../models/paf';
import { HttpHeadersService } from '../../services/http-headers/http-headers.service';
import { PafSpectrumService } from '../../services/paf/paf-spectrum.service';
import { PafService } from '../../services/paf/paf.service';
import { PafComponent } from './paf.component';

describe('PafComponent', () => {

  let fixture: ComponentFixture<PafComponent>;
  let component: PafComponent;
  let nativeElement: HTMLElement;
  let expect;
  let stubServiceGetByParams;
  let stubServiceGetById;

  beforeAll(() => {
    expect = chai.expect;
    chai.use(sinonChai);
  });

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PafComponent],
      imports: [
        FormsModule,
        RouterTestingModule.withRoutes([])
      ],
      providers: [
        HttpClient,
        HttpHandler,
        {
          provide: 'GenericPafService',
          useClass: PafSpectrumService
        },
        PafService,
        HttpHeadersService
      ],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PafComponent);
    component = fixture.componentInstance;
    nativeElement = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('the component should render', () => {
    expect(nativeElement.querySelector(byDataQa('searchBox'))).to.exist;
    expect(nativeElement.querySelectorAll(byDataQa('resultBoxItem')).length).to.be.equal(0);
    expect(component.displayAddressErrorMessage).to.be.false;
    expect(nativeElement.querySelector(byDataQa('addressErrorMessage'))).to.not.exist;
    expect(component.restrictedCharacterError).to.be.false;
    expect(nativeElement.querySelector(byDataQa('restrictedCharacterError'))).to.not.exist;
  });

  describe('when entering some input in the search box', () => {
    const enterValue = (value) => {
      simulateUserInput(value);
      fixture.detectChanges();
    };

    beforeEach(async(() => {
      stubServiceGetByParams = sinon.stub(component.pafService, 'getByParams');
      stubServiceGetById = sinon.stub(component.pafService, 'getById');
    }));

    describe('with the service up', () => {

      beforeEach(async(() => {
        simulateUserInput('Road');
        fixture.whenStable().then(() => {
          fixture.detectChanges();
        });
      }));

      it('should call address lookup service', async(() => {
        fixture.whenStable().then(() => {
          expect(component.pafService.getByParams).to.have.been.calledWith({ container: undefined, query: 'Road' });
          expect(component.displayAddressErrorMessage).to.false;
        });
      }));

      it('should display a list of items with bold values', async(() => {
        fixture.whenStable().then(() => {
          expect(nativeElement.querySelectorAll(byDataQa('resultBoxItem')).length).to.be.greaterThan(0);
          expect(nativeElement.querySelectorAll('b')[0].textContent).to.contain('Road');
          expect(nativeElement.querySelector(byDataQa('resultBoxItem')).textContent).to.not.be.empty;
        });
      }));

      it('should hide the list of items when removing the input', async(() => {
        const emptyPaf: PafItem[] = [];
        stubServiceGetByParams.returns(of(emptyPaf));

        addValueSearchBox('');
        fixture.whenStable().then(() => {
          fixture.detectChanges();
          expect(nativeElement.querySelectorAll(byDataQa('resultBoxItem')).length).to.be.equal(0);
        });
      }));
    });

    describe('input validation', () => {

      it('searchBox should be valid when the first character is alphanumeric', () => {
        enterValue('a');

        expect(component.restrictedCharacterError).to.be.false;
        expect(nativeElement.querySelector(byDataQa('restrictedCharacterError'))).to.not.exist;
      });

      it('searchBox should be invalid when the first character is not alphanumeric', () => {
        enterValue('*');

        expect(component.restrictedCharacterError).to.be.true;
        expect(nativeElement.querySelector(byDataQa('errorMessage'))).to.exist;
      });

      it('should remove error message when the search box input is empty coming from a previous value', (() => {
        enterValue('*');
        expect(component.restrictedCharacterError).be.true;
        expect(nativeElement.querySelector(byDataQa('errorMessage'))).exist;

        enterValue('');

        expect(component.restrictedCharacterError).be.false;
        expect(nativeElement.querySelector(byDataQa('errorMessage'))).not.exist;
      }));

      it('should show error message if no input is provided and control has been touched', () => {
        simulateEvent('blur', nativeElement.querySelector(byDataQa('searchBox')));
        simulateEvent('click', nativeElement);

        fixture.detectChanges();
        assert.isTrue(component.emptyAddressFlag);
        assert.isFalse(component.serviceErrorFlag);
        assert.isFalse(component.restrictedCharacterFlag);
      });
    });

    it('if an error happens when calling paf, a message should be displayed', async(() => {
      simulateTechError('mk');

      fixture.whenStable().then(() => {
        fixture.detectChanges();
        expect(component.displayAddressErrorMessage).to.be.true;
        expect(nativeElement.querySelector(byDataQa('errorMessage'))).to.exist;
        assert.isTrue(component.serviceErrorFlag);
        assert.isFalse(component.emptyAddressFlag);
        assert.isFalse(component.restrictedCharacterFlag);
      });
    }));

    it('should overwrite an existing error message when the input is no-alphanumeric ', (() => {
      component.displayPendingValidations = true;
      component.isAddressSelected = false;
      fixture.detectChanges();
      expect(nativeElement.querySelector(byDataQa('errorMessage'))).to.exist;
      assert.isTrue(component.emptyAddressFlag);
      assert.isFalse(component.serviceErrorFlag);
      assert.isFalse(component.restrictedCharacterFlag);

      enterValue('*');

      expect(component.restrictedCharacterError).to.be.true;
      expect(nativeElement.querySelector(byDataQa('errorMessage'))).exist;
      assert.isTrue(component.restrictedCharacterFlag);
      assert.isFalse(component.serviceErrorFlag);
      assert.isFalse(component.emptyAddressFlag);
    }));

    it('should overwrite an existing error message when there is a bad response', () => {
      component.displayPendingValidations = true;
      component.isAddressSelected = false;
      component.displayAddressErrorMessage = true;
      component.restrictedCharacterError = false;
      fixture.detectChanges();

      expect(nativeElement.querySelector(byDataQa('errorMessage'))).to.exist;
      assert.isTrue(component.serviceErrorFlag);
      assert.isFalse(component.emptyAddressFlag);
      assert.isFalse(component.restrictedCharacterFlag);
    });

    it('should prioritize the restrictedCharacterError when all of them happens', () => {
      component.displayPendingValidations = true;
      component.isAddressSelected = false;
      component.displayAddressErrorMessage = true;
      component.restrictedCharacterError = true;
      fixture.detectChanges();

      expect(nativeElement.querySelector(byDataQa('errorMessage'))).exist;
      assert.isTrue(component.restrictedCharacterFlag);
      assert.isFalse(component.serviceErrorFlag);
      assert.isFalse(component.emptyAddressFlag);
    });

  });

  describe('when clicking on an item displayed', () => {

    beforeEach(async(() => {
      stubServiceGetByParams = sinon.stub(component.pafService, 'getByParams');
      stubServiceGetById = sinon.stub(component.pafService, 'getById');
    }));

    it('should call address lookup service when item refers to a collection of addresses', async(() => {
      simulateUserInput('Witham');

      fixture.whenStable().then(() => {
        fixture.detectChanges();
        const firstItem = nativeElement.querySelector(byDataQa('resultBoxItem'));
        simulateEvent('click', firstItem);
        fixture.whenStable().then(() => {
          const result = component.pafService.getByParams;
          expect(result).to.have.been.calledWith({ container: 'GB|RM|B|0003', query: '3N, Moss Road (3 addresses)' });
        });
      });
    }));

    it('is not colorized the box when paf list is more than zero ', async(() => {
      simulateUserInput('Witham');

      fixture.whenStable().then(() => {
        fixture.detectChanges();
        const firstItem: HTMLElement = nativeElement.querySelector(byDataQa('resultBoxItem'));
        simulateEvent('click', firstItem);
        expect(nativeElement.querySelector(byDataQa('searchBox')).getAttribute('class')).to.not.equal('error');
      });
    }));

    describe('when item refers to a single address', () => {

      beforeEach(async(() => {
        simulateUserInput('Lower Thames Road');
        fixture.whenStable().then(() => {
          fixture.detectChanges();
          const emptyPaf: PafItem[] = [];
          stubServiceGetByParams.returns(of(emptyPaf));
        });
      }));

      it('should call address lookup service', async(() => {
        stubServiceGetById.returns(of({}));

        simulateEvent('click', nativeElement.querySelector(byDataQa('resultBoxItem')));

        fixture.whenStable().then(() => {
          expect(component.pafService.getById).to.have.been.calledWith('GB|RM|B|0001');
          expect(component.displayAddressErrorMessage).to.be.false;
          expect(nativeElement.querySelector(byDataQa('addressErrorMessage'))).to.not.exist;
        });
      }));

      it('should clear the search box and hide the list of items', async(() => {
        stubServiceGetById.returns(of({}));

        simulateEvent('click', nativeElement.querySelector(byDataQa('resultBoxItem')));

        const result: HTMLInputElement = nativeElement.querySelector(byDataQa('searchBox'));
        expect(result.value).to.be.empty;
      }));

      it('should display an error message when the service is down', async(() => {
        stubServiceGetById.returns(throwError(null));

        simulateEvent('click', nativeElement.querySelector(byDataQa('resultBoxItem')));

        fixture.whenStable().then(() => {
          expect(component.displayAddressErrorMessage).to.be.true;
        });
      }));

    });
  });

  it('should implement ControlValueAccessor', () => {
    expect(component.writeValue).to.exist;
    expect(component.registerOnChange).to.exist;
    expect(component.registerOnTouched).to.exist;
  });

  function simulateUserInput(value: string) {
    const allResults = [
      {
        id: 'GB|RM|B|0001',
        type: 'Address',
        text: 'Flat 100, Lower Thames Road',
        highlight: '0-2',
        description: 'London, EC3R 6AG'
      },
      {
        id: 'GB|RM|B|0002',
        type: 'Address',
        text: '3N, Forthriver Road',
        highlight: '0-2',
        description: 'Belfast, BT13 3SB'
      },
      {
        id: 'GB|RM|B|0003',
        type: 'Postcode',
        text: '3N, Moss Road (3 addresses)',
        highlight: '0-2',
        description: 'Witham, CM8 3UW'
      }
    ];

    const filteredResults = allResults.filter(result => {
      return value && (result.text.indexOf(value) !== -1) || (result.description.indexOf(value) !== -1);
    });

    stubServiceGetByParams.returns(of(filteredResults));
    addValueSearchBox(value);
  }

  function simulateTechError(value: string) {
    stubServiceGetByParams.returns(throwError(null));
    addValueSearchBox(value);
  }

  function addValueSearchBox(value: string) {
    const searchBoxElement: HTMLInputElement = nativeElement.querySelector(byDataQa('searchBox'));
    searchBoxElement.value = value;
    simulateEvent('keyup', searchBoxElement);
  }
});
