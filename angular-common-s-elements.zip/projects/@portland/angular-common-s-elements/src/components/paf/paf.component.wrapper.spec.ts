import { HttpClient, HttpHandler } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { AbstractControl, FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { expect } from 'chai';
import { of, throwError } from 'rxjs';
import * as sinon from 'sinon';
import { byDataQa, simulateEvent } from '../../../../../../test-utils/test-helpers';
import { PafAddressLookup, PafItem } from '../../models/paf';
import { HttpHeadersService } from '../../services/http-headers/http-headers.service';
import { PafSpectrumService } from '../../services/paf/paf-spectrum.service';
import { PafComponent } from './paf.component';


@Component({
  selector: 's-dummy',
  template:
    `<form [formGroup]="form">
      <s-paf formControlName="paf" #childComponent>
        <span class="primary-label">Business Address</span>
        <span class="secondary-label">Please enter your address or postcode</span>
        <span class="empty-field-error" data-qa="empty-field-error-message">{{emptyFieldErrorMessage}}</span>
        <span class="restricted-character-error" data-qa="restricted-character-error-message">{{restrictedCharacterErrorMessage}}</span>
        <span class="service-error" data-qa="service-error-message">{{serviceErrorMessage}}</span>
      </s-paf>
    </form>`
})
class DummyComponent implements OnInit {

  @ViewChild('childComponent')
  childComponent: any;

  form: FormGroup;
  markAllTouched: boolean;

  emptyFieldErrorMessage = 'Please select the registered address of your business';
  restrictedCharacterErrorMessage = 'Please enter a valid address';
  serviceErrorMessage = 'System is not responding, please click on enter manually below to input your address';

  initialValue = new PafAddressLookup('123', 'fig street', '', 'Townville', 'MK62PU');

  constructor(private fb: FormBuilder) {
  }

  ngOnInit(): void {
    this.form = this.fb.group({ paf: [this.initialValue] });
  }
}

describe('PafComponent with wrapper', () => {
  let fixture: ComponentFixture<DummyComponent>;
  let component: DummyComponent;
  let nativeElement: HTMLElement;
  let control: AbstractControl;
  let child: PafComponent;

  let stubServiceGetByParams;
  let stubServiceGetById;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        PafComponent,
        DummyComponent,
      ],
      imports: [
        ReactiveFormsModule,
      ],
      providers: [
        {
          provide: 'GenericPafService',
          useClass: PafSpectrumService
        },
        HttpClient,
        HttpHandler,
        HttpHeadersService
      ],
    });
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DummyComponent);
    component = fixture.componentInstance;
    child = component.childComponent;
    nativeElement = fixture.nativeElement;
    fixture.detectChanges();
    control = component.form.controls.paf;
  });

  beforeEach(() => {
    stubServiceGetByParams = sinon.stub(child.pafService, 'getByParams');
    stubServiceGetById = sinon.stub(child.pafService, 'getById');
  });

  describe('value', () => {
    beforeEach(async(() => {
      simulateUserInput('Lower Thames Road');
      fixture.whenStable().then(() => {
        fixture.detectChanges();
        const emptyPaf: PafItem[] = [];
        stubServiceGetByParams.returns(of(emptyPaf));
      });
    }));

    it('should be set when an address is selected', () => {
      const address = new PafAddressLookup('aPremise', 'aPrimaryStreet', 'aSecondaryStreet', 'aTown', 'aPostcode');
      const returnVal = new PafAddressLookup('aPremise', 'aPrimaryStreet', 'aSecondaryStreet', 'aTown', 'aPostcode');
      stubServiceGetById.returns(of(returnVal));
      simulateEvent('click', nativeElement.querySelector(byDataQa('resultBoxItem')));
      fixture.detectChanges();

      expect(control.value).to.deep.equal(address);
    });
  });

  describe('touched', () => {
    it('should be marked as touched when the searchbox is touched', () => {
      simulateEvent('blur', nativeElement.querySelector(byDataQa('searchBox')));
      fixture.detectChanges();

      expect(control.touched).to.be.true;
    });
  });

  describe('inject values from parent', () => {
    it('should pass the primary label to the child component', () => {
      expect(nativeElement.querySelector(byDataQa('searchBoxLabel')).innerHTML).to.includes('Business Address');
    });

    it('should pass the secondary label to the child component', () => {
      const result: HTMLElement = nativeElement.querySelector(byDataQa('helpLabel'));
      expect(nativeElement.querySelector(byDataQa('helpLabel')).innerHTML).to.includes('Please enter your address or postcode');
    });

    describe('error messages', () => {
      it('displays the empty field error to the child component', () => {
        simulateEvent('blur', nativeElement.querySelector(byDataQa('searchBox')));
        simulateEvent('click', nativeElement);
        fixture.detectChanges();

        expect(nativeElement.querySelector('.empty-field-error')).to.exist;
        const result: HTMLHtmlElement = nativeElement.querySelector(byDataQa('empty-field-error-message'));
        expect(result.textContent).to.equal('Please select the registered address of your business');
      });

      it('displays the restricted character error to the child component', () => {
        const input: HTMLInputElement = nativeElement.querySelector(byDataQa('searchBox'));
        input.value = '*';

        simulateEvent('keyup', nativeElement.querySelector(byDataQa('searchBox')));
        fixture.detectChanges();

        const result: HTMLHtmlElement = nativeElement.querySelector(byDataQa('restricted-character-error-message'));
        expect(result).to.exist;
        expect(result.textContent).to.equal('Please enter a valid address');
      });

      it('displays the system error to the child component', async(() => {
        simulateError();
        const input: HTMLInputElement = nativeElement.querySelector(byDataQa('searchBox'));
        input.value = 'mk';

        simulateEvent('keyup', nativeElement.querySelector(byDataQa('searchBox')));

        fixture.whenStable().then(() => {
          fixture.detectChanges();

          const result: HTMLHtmlElement = nativeElement.querySelector(byDataQa('service-error-message'));
          expect(result).to.exist;
          expect(result.textContent).to.equal(
            'System is not responding, please click on enter manually below to input your address'
          );

        });
      }));
    });

  });

  function simulateUserInput(value: string): void {
    const allResults = [
      {
        id: 'GB|RM|B|0001',
        type: 'Address',
        text: 'Flat 100, Lower Thames Road',
        highlight: '0-2',
        description: 'London, EC3R 6AG'
      },
      {
        id: 'GB|RM|B|0002',
        type: 'Address',
        text: '3N, Forthriver Road',
        highlight: '0-2',
        description: 'Belfast, BT13 3SB'
      },
      {
        id: 'GB|RM|B|0003',
        type: 'Postcode',
        text: '3N, Moss Road (3 addresses)',
        highlight: '0-2',
        description: 'Witham, CM8 3UW'
      }
    ];

    const filteredResults = allResults.filter((result) => {
      return value && (result.text.indexOf(value) !== -1) || (result.description.indexOf(value) !== -1);
    });
    stubServiceGetByParams.returns(of(filteredResults));
    addValueSearchBox(value);
  }

  function simulateError(): void {
    stubServiceGetByParams.returns(throwError(null));
  }

  function addValueSearchBox(value: string): void {
    const searchBoxElement = nativeElement.querySelector(byDataQa('searchBox'));
    searchBoxElement.setAttribute('value', value);
    simulateEvent('keyup', searchBoxElement);
  }
});
