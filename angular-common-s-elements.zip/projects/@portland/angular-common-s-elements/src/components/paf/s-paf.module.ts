import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';

import { PafComponent } from './paf.component';


@NgModule({
  imports: [
    CommonModule,
    HttpClientModule
  ],
  declarations: [
    PafComponent
  ],
  exports: [
    PafComponent
  ]
})
export class SPafModule { }
