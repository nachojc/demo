import { Component, ElementRef, forwardRef, Input, OnInit, ViewChild, Inject } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { Observable, of, Subject } from 'rxjs';
import { catchError, debounceTime, distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators';

import { PafService } from '../../services/paf/paf.service';
import { PafAddressLookup, PafItem } from '../../models/paf';

const CUSTOM_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => PafComponent),
  multi: true,
};

@Component({
  selector: 's-paf',
  templateUrl: './paf.component.html',
  styleUrls: ['./paf.component.scss', '../../styles/input-boxes.scss'],
  providers: [CUSTOM_ACCESSOR]
})
export class PafComponent implements OnInit, ControlValueAccessor {

  isAddressSelected: boolean;

  @ViewChild('input')
  private input: ElementRef;

  @ViewChild('list')
  private list: ElementRef;

  @Input()
  public displayPendingValidations: boolean;

  @ViewChild('pafContainer')
  private pafContainer: ElementRef;

  public displayAddressErrorMessage = false;
  public restrictedCharacterError = false;
  public errorMessage = '';
  public searching = false;
  public show = true;
  public touched: Boolean = false;
  public query: string;
  public isPafListEmpty = false;
  public pafList$: Observable<PafItem[]> = of([]);
  public searchText$ = new Subject<{}>();
  private alphanumericRexExp = /^[A-Za-z0-9].*/;
  private onChange = (val) => { };
  private onTouched = () => { };

  constructor(@Inject('GenericPafService') public pafService: PafService) { }

  ngOnInit(): void {
    this.pafList$ = this.searchText$.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      tap(() => this.searching = true),
      switchMap(currentQuery => this.highlight(currentQuery).pipe(catchError((data) => {
        this.displayAddressErrorMessage = true;
        this.show = false;
        return of(null);
      }))),
      tap(() => this.searching = false)
    );
    this.search('');
    document.addEventListener('click', (obj) => {
      if (this.touched && this.checkClickOutsidePaf(obj.target as Element)) {
        this.displayPendingValidations = true;
        this.show = false;
      }
    });
  }
  checkClickOutsidePaf(el: Element) {
    const parent: Element = this.pafContainer.nativeElement;
    if (parent.contains(el) || el === parent) {
      return false;
    }
    return true;
  }
  highlight(currentQuery): Observable<PafItem[]> {
    const caseInsensitiveQueryRegex = new RegExp(this.query, 'i');
    return this.pafService.getByParams(currentQuery).pipe(map((data: PafItem[]) => {
      if (data) {
        return data.map((current) => {
          let originalText = current.text;
          let originalDescription = current.description;
          let highlightedText = '';
          let highlightedDescription = '';

          let match;
          while ((match = caseInsensitiveQueryRegex.exec(originalText)) !== null) {
            highlightedText += originalText.substr(0, match.index) + originalText.substr(match.index, this.query.length).bold();
            originalText = originalText.substr(match.index + this.query.length);
          }

          while ((match = caseInsensitiveQueryRegex.exec(originalDescription)) !== null) {
            highlightedDescription += originalDescription.substr(0, match.index)
              + originalDescription.substr(match.index, this.query.length).bold();
            originalDescription = originalDescription.substr(match.index + this.query.length);
          }

          highlightedText += originalText;
          highlightedDescription += originalDescription;

          return Object.assign(current, {
            text: highlightedText,
            description: highlightedDescription
          });
        });
      }
    }));
  }

  search(currentQuery: string, container?: string): void {
    this.restrictedCharacterError = false;
    this.query = currentQuery;

    if (this.alphanumericRexExp.test(currentQuery) || !currentQuery) {
      this.searchText$.next({
        query: currentQuery,
        container: container
      });
    } else {
      this.restrictedCharacterError = true;
    }
    if (!currentQuery) {
      this.isPafListEmpty = false;
    } else {
      this.isPafListEmpty = true;
    }
  }

  onClick(item): void {
    if (item.type === 'Address') {
      this.pafService.getById(item.id).subscribe((data: any) => {
        this.isAddressSelected = true;
        this.writeValue(data);
      }, () => this.displayAddressErrorMessage = true);
      this.search('');
      this.input.nativeElement.value = null;
    } else {
      item.text = item.text.replace('</b>', '').replace('<b>', '');
      this.search(item.text, item.id);
    }
  }

  onBlur(): void {
    this.onTouched();
    this.touched = true;
  }
  onFocus() {
    this.show = true;
    this.displayPendingValidations = false;
  }
  writeValue(address: PafAddressLookup): void {
    if (address) {
      this.onChange(address);
    }
  }
  registerOnChange(fn: any): void {
    this.onChange = fn;
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  displayErrorMessage(): boolean {
    let errorStatus = true;

    const element: HTMLElement = this.list.nativeElement;

    errorStatus = (this.serviceErrorFlag || this.emptyAddressFlag || this.restrictedCharacterFlag);

    return errorStatus;
  }
  get serviceErrorFlag() {
    return !(!this.displayAddressErrorMessage || this.restrictedCharacterError || this.emptyAddressFlag);
  }

  get restrictedCharacterFlag() {
    return !(!this.restrictedCharacterError || this.serviceErrorFlag || this.emptyAddressFlag);
  }

  get emptyAddressFlag() {
    return !(!this.displayPendingValidations || this.isAddressSelected || this.restrictedCharacterError || this.displayAddressErrorMessage);
  }
}
