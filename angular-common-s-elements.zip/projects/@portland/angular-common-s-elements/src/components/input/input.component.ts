import { Component, Input, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { fromEvent, Observable } from 'rxjs';
import { debounceTime, map, filter } from 'rxjs/operators';
import { BaseComponent } from '../base/base.component';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 's-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss', '../../styles/error.scss', '../../styles/input-boxes.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: InputComponent, multi: true }
  ]
})
export class InputComponent extends BaseComponent implements ControlValueAccessor, AfterViewInit {

  private _onTouched: Function;
  @ViewChild('input') input: ElementRef;
  // @see https://stackoverflow.com/questions/42361485/how-long-should-you-debounce-text-input
  @Input() type = 'text';
  @Input('debounce') _debounceTime: Number = 150;
  @Input() placeholder: string | null = null;
  @Input() maxlength: string | null = null;
  @Output() valueChange: EventEmitter<String> = new EventEmitter<String>();
  private _debounce: Observable<any>;
  private _propagateChange: Function;

  ngAfterViewInit () {
    // Setting the debounce time on the input element
    this._debounce = fromEvent<any>(this.input.nativeElement, 'input') // keyup
      .pipe(debounceTime(+this._debounceTime))
      .pipe(filter(() => !this._disabled))
      .pipe(map(event => event.target.value));

    this._debounce.subscribe(inputValue => {
      this.value = inputValue;
      if (this._propagateChange) {
        this._propagateChange(this.value);
      } else {
        this.valueChange.emit(this.value);
      }
    });
  }

  onTouched() {
    if (this._onTouched) this._onTouched();
  }

  writeValue (value: string): void {
    this.value = value;
    this.input.nativeElement.value = this.value;
  }

  registerOnChange (fn: any): void {
    this._propagateChange = fn;
  }

  registerOnTouched(fn: any): void {
    this._onTouched = fn;
  }
}
