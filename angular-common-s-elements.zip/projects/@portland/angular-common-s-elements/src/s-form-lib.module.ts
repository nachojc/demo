import { NgModule } from '@angular/core';
import { SCheckboxComponentModule } from './components/checkbox/checkbox.module';
import { SFileUploadModule } from './components/fileupload/fileupload.module';
import { SInputComponentModule } from './components/input/input.module';
import { SRadioGroupComponentModule } from './components/radio-group/radio-group.module';
import { SSelectComponentModule } from './components/select/select.module';
import { SSortcodeComponentModule } from './components/sortcode/sortcode.module';
import { SYesNoInputModule } from './components/yes-no-input/yes-no-input.module';
import { SErrorDirectiveModule } from './directives/error/error.module';
import { SFirstNameDirectiveModule } from './directives/first-name/first-name.module';
import { SFinancialDirectiveModule } from './directives/financial/financial.module';
import { SLabelDirectiveModule } from './directives/label/label.module';
import { SLastNameDirectiveModule } from './directives/last-name/last-name.module';
import { SNumericDirectiveModule } from './directives/numeric/numeric.module';
import { SPafModule } from './components/paf/s-paf.module';
import { STelephoneComponentModule } from './components/telephone/telephone.module';
import { STitleComponentModule } from './components/title/title.module';
import { SDobComponentModule } from './components/dob/dob.module';
import { SAccordionComponentModule } from './components/accordion/accordion.module';
import { SListBuilderComponentModule } from './components/list-builder/list-builder.module';


@NgModule({
  imports: [
    SAccordionComponentModule,
    SCheckboxComponentModule,
    SErrorDirectiveModule,
    SFileUploadModule,
    SFirstNameDirectiveModule,
    SFinancialDirectiveModule,
    SInputComponentModule,
    SLabelDirectiveModule,
    SLastNameDirectiveModule,
    SNumericDirectiveModule,
    SPafModule,
    SRadioGroupComponentModule,
    SSelectComponentModule,
    SSortcodeComponentModule,
    STelephoneComponentModule,
    STitleComponentModule,
    SYesNoInputModule,
    SYesNoInputModule,
    SPafModule,
    SDobComponentModule,
    SListBuilderComponentModule
  ],
  exports: [
    SAccordionComponentModule,
    SCheckboxComponentModule,
    SErrorDirectiveModule,
    SFileUploadModule,
    SFirstNameDirectiveModule,
    SFinancialDirectiveModule,
    SInputComponentModule,
    SLabelDirectiveModule,
    SLastNameDirectiveModule,
    SNumericDirectiveModule,
    SPafModule,
    SRadioGroupComponentModule,
    SSelectComponentModule,
    SSortcodeComponentModule,
    STelephoneComponentModule,
    STitleComponentModule,
    SYesNoInputModule,
    SYesNoInputModule,
    SPafModule,
    SDobComponentModule,
    SListBuilderComponentModule
  ]
})
export class SFormLibModule { }
