import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
  })
export class HttpHeadersService {

    authorization: string;
    ibmclientID: string;
    token: string;
    env: string;

    private oauth2Headers: Map<string, string>;
    private BEARER_WITH_SPACE: string = 'Bearer' + ' ';
    private headers: Map<string, string>;

    constructor() {
        this.headers = new Map<string, string>();
        this.globalCachingStrategy();
        this.oauth2Headers = new Map();
        this.authorization = 'Authorization';
        this.ibmclientID = 'x-ibm-client-id';
    }

    setOauth2Headers(token?: string, clientID?: string): void {
        this.token = token;
        if (token) {
            this.oauth2Headers.set(this.authorization, this.BEARER_WITH_SPACE + token);
        }
        if (clientID) {
            this.oauth2Headers.set(this.ibmclientID, clientID);
        }
    }

    getOauth2Headers(): Map<string, string> {
        return this.oauth2Headers;
    }

    setApiName(apiName: string): void {
        this.headers.set('apiName', apiName);
    }

    getHeaders(): Map<string, string> {
        return this.headers;
    }

    setPropertyInHeader(key: string, value: string): void {
        this.headers.set(key, value);
    }

    buildHeaders(): HttpHeaders {
        let httpHeaders: HttpHeaders = new HttpHeaders();

        this.headers.forEach((value: string, key: string) => {
            httpHeaders = httpHeaders.append(key, value);
        });

        return httpHeaders;
    }

    buildSecureHeaders(): HttpHeaders {
        let httpHeaders: HttpHeaders = this.buildHeaders();

        this.oauth2Headers.forEach((value: string, key: string) => {
            httpHeaders = httpHeaders.append(key, value);
        });
        return httpHeaders;
    }

    private globalCachingStrategy(): void {
        this.setPropertyInHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
        this.setPropertyInHeader('Pragma', 'no-cache');
        this.setPropertyInHeader('Expires', '0');
    }
}

