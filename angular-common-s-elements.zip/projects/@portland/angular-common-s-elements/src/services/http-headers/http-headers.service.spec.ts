import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import * as chai from 'chai';
import * as sinonChai from 'sinon-chai';
import { expect, assert } from 'chai';
import { HttpHeadersService } from './http-headers.service';

describe('httpHeadersService', () => {

  let service: HttpHeadersService;

  beforeAll(() => {
    chai.use(sinonChai);
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        HttpHeadersService,
      ],
      imports: [
        HttpClientTestingModule,
      ],
    });
    service = TestBed.get(HttpHeadersService);
  });

  describe('httpHeaders', () => {
    it('should exist', () => {
      expect(service.getHeaders()).to.exist;
    });

    it('should not be null', () => {
      expect(service.getHeaders()).to.not.be.equal(null);
    });

    it('should have a property when built', () => {
      service.setPropertyInHeader('customerNumber', 'J0000001');

      const httpHeaders = service.buildHeaders();

      expect(httpHeaders.get('customerNumber')).to.equal('J0000001');
    });

    describe('header creation', () => {

      it('should populate authorization header', () => {
        const token = 'PRETENDER_TOKEN';

        service.setOauth2Headers(token);

        const oauth2headerMap = service.getOauth2Headers();
        expect(oauth2headerMap.get('Authorization')).to.not.equal(null);
        expect(oauth2headerMap.get('Authorization')).to.equal('Bearer PRETENDER_TOKEN');
      });

      it('should populate clientID header', () => {
        const token = 'PRETENDER_TOKEN';
        const clientID = 'CLIENT_ID';

        service.setOauth2Headers(token, clientID);

        const oauth2headerMap = service.getOauth2Headers();
        expect(oauth2headerMap.get('x-ibm-client-id')).to.not.equal(null);
        expect(oauth2headerMap.get('x-ibm-client-id')).to.equal('CLIENT_ID');
      });

      it('should not contain clientID when is not provided', () => {
        const token = 'PRETENDER_TOKEN';

        service.setOauth2Headers(token);

        const oauth2headerMap = service.getOauth2Headers();
        assert.isFalse(oauth2headerMap.has('x-ibm-client-id'));
      });

      it('should not contain authorization header when the token is not provided', () => {
        service.setOauth2Headers();

        const oauth2headerMap = service.getOauth2Headers();

        assert.isFalse(oauth2headerMap.has('Authorization'));
      });

      it('should initialize global caching strategy', () => {
        const httpHeaders = service.buildHeaders();

        expect(httpHeaders.get('Cache-Control')).to.equals('no-cache, no-store, must-revalidate');
        expect(httpHeaders.get('Pragma')).to.equals('no-cache');
        expect(httpHeaders.get('Expires')).to.equals('0');
      });
    });
  });
});
