import { TestBed } from '@angular/core/testing';
import { FileUploadService } from './fileupload.service';

describe('FileUploadService', () => {

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [{
        provide: FileUploadService,
        useValue: true
      }]
    });
  });

  it('should be created', () => {
    const service: FileUploadService = TestBed.get(FileUploadService);
    expect(service).toBeTruthy();
  });
});
