import { Injectable } from '@angular/core';
import { UploadFile, CustomUploadFile } from '../../models/fileupload/fileupload.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export abstract class FileUploadService {
  abstract startUpload(file: UploadFile): Observable<CustomUploadFile>;
  abstract cancelUpload(file: UploadFile);
}
