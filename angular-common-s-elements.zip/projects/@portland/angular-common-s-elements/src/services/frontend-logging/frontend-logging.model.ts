export interface FrontendLog {
    details: FrontendLogHTTPErrorDetails | FrontendLogRuntimeErrorDetails;
    networkError?: FrontendLogHTTPError;
    runtimeError?: FrontendLogRuntimeError;
}

export interface FrontendLogHTTPError {
    status: Number; // HTTP status code
    errorCode: number;
}

export interface FrontendLogRuntimeError {
    nodeName: string;
}

export interface FrontendLogHTTPErrorDetails {
    message: string;
    errorName: string;
}

export interface FrontendLogRuntimeErrorDetails {
    message: string;
    errorName: string;
    stack: string;
}
