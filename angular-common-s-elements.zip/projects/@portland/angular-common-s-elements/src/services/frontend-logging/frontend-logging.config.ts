import { InjectionToken } from '@angular/core';

export const FRONTEND_LOGGING_API = new InjectionToken('frontend-logging-api');
