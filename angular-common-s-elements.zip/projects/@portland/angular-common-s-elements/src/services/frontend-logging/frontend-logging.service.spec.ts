import { TestBed } from '@angular/core/testing';

import { FrontendLoggingService } from './frontend-logging.service';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FRONTEND_LOGGING_API } from './frontend-logging.config';
import { HttpErrorResponse } from '@angular/common/http';

describe('FrontendLoggingService', () => {
  let service: FrontendLoggingService;
  let httpTestingController: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        FrontendLoggingService,
        { provide: FRONTEND_LOGGING_API, useValue: '/api/logging' }
       ],
      imports: [ HttpClientTestingModule ]
    });
    service = TestBed.get(FrontendLoggingService);
    httpTestingController = TestBed.get(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should have a sendErrorLog method that makes a POST call when there is a runtime error', () => {
    service.sendErrorLog({
      details: {
        message: 'hello',
        errorName: 'me',
        stack: 'here',
      },
      runtimeError: {
      nodeName: 'S-INPUT'
    }});

    const req = httpTestingController.expectOne('/api/logging');
    expect(req.request.method).toEqual('POST');
    expect(req.request.body.message).toEqual('hello');
    expect(req.request.body.errorName).toEqual('me');
    expect(req.request.body.stack).toEqual('here');
    expect(req.request.headers.get('s-logging-nodeName')).toEqual('S-INPUT');
    expect(req.request.headers.get('s-logging-type')).toEqual('RUNTIME_ERROR');
    expect(req.request.headers.keys().length).toEqual(2);
  });

  it('should have a sendErrorLog method that makes a POST call when there is a network error', () => {
    const error = {
      details: {
        message: 'hello',
        errorName: 'http'
      },
      networkError: {
        status: 409,
        errorCode: 1
      }
    };
    service.sendErrorLog(error);

    const req = httpTestingController.expectOne('/api/logging');
    expect(req.request.method).toEqual('POST');
    expect(req.request.body.message).toEqual('hello');
    expect(req.request.body.errorName).toEqual('http');
    expect(req.request.headers.get('s-logging-status')).toEqual('409');
    expect(req.request.headers.get('s-logging-errorCode')).toEqual('1');
    expect(req.request.headers.get('s-logging-type')).toEqual('NETWORK_ERROR');
    expect(req.request.headers.keys().length).toEqual(3);
  });

  it('should call sendErrorLog method when there is a runtime error is caught from the angular ErrorHandler method', () => {
    const spy = spyOn(service, 'sendErrorLog').and.callThrough();
    service.handleError({
      ngDebugContext: {
        componentRenderElement: {
          nodeName: 'nodeName'
        }
      },
        message: 'hello',
        name: 'errorName',
        stack: 'the stack'
    });

    const req = httpTestingController.expectOne('/api/logging');
    expect(req.request.method).toEqual('POST');
    expect(req.request.body.message).toEqual('hello');
    expect(req.request.body.errorName).toEqual('errorName');
    expect(req.request.body.stack).toEqual('the stack');
    expect(req.request.headers.get('s-logging-type')).toEqual('RUNTIME_ERROR');
    expect(req.request.headers.keys().length).toEqual(2);

    expect(spy).toHaveBeenCalledWith(
      {
        details: {
          message: 'hello',
          errorName: 'errorName',
          stack: 'the stack'
        },
        runtimeError: { nodeName: 'nodeName' }
      }
    );
  });

  it('should create a createNetworkErrorObj', () => {
    const error = new HttpErrorResponse({error: 'error', status: 500, url: 'url/', statusText: 'text' });

    expect(service.createNetworkErrorObj(error, 1)).toEqual({
      details: {
        message: 'Http failure response for url/: 500 text',
        errorName: 'HttpErrorResponse'
      },
      networkError: {
        status: 500,
        errorCode: 1
      }
    });
  });

  it('should create a createRuntimeErrorObj', () => {
    const myError: any = {};

    myError.ngDebugContext = { componentRenderElement: {nodeName: 'nodeName'}};
    myError.stack = 'stack';

    expect(service.createRuntimeErrorObj(myError)).toEqual({
      details: {
        errorName: undefined,
        message: undefined,
        stack: 'stack'
      },
      runtimeError: { nodeName: 'nodeName' }
    });
  });

  it('#handleError should create a createNetworkErrorObj if the error is not runtime', () => {
    const spy = spyOn(service, 'sendErrorLog').and.callThrough();
    const error = { message: 'error' };
    service.handleError(error);

    expect(spy).toHaveBeenCalledWith({
      details: {
        message: 'error',
        errorName: undefined
      },
      networkError: {
        status: undefined,
        errorCode: 0
      }
    });
  });

});
