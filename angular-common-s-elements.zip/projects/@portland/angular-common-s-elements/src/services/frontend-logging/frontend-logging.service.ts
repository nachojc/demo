import { Injectable, Inject, ErrorHandler } from '@angular/core';
import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { FrontendLog } from './frontend-logging.model';
import { FRONTEND_LOGGING_API } from './frontend-logging.config';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FrontendLoggingService implements ErrorHandler {

  constructor (
    private http: HttpClient,
    @Inject(FRONTEND_LOGGING_API) private loggingUrl$: Observable<string> | string
  ) {
    if (typeof loggingUrl$ === 'string') {
      this.loggingUrl$ = of(loggingUrl$);
    }
  }

  sendErrorLog(error: FrontendLog) {
    const body = error.details;

    let fields;
    if (error.runtimeError) {
      fields = Object.assign({}, error.runtimeError);
      fields.type = 'RUNTIME_ERROR';
    } else {
      fields = Object.assign({}, error.networkError);
      fields.type = 'NETWORK_ERROR';
    }

    const headers = Object.keys(fields).reduce((acc: any, key) => {
      if (fields[key] && fields[key].toString) {
        acc[`s-logging-${key}`] = fields[key].toString();
      }
      return acc;
    }, {});

    const options = {
      headers: new HttpHeaders(headers)
    };
    const url$ = <Observable<string>>this.loggingUrl$;
    url$.subscribe(url => this.http.post(url, body, options).subscribe());
  }

  handleError(error: any) {
    // we can enter here if http error happens as well and it is not captured.
    if (error.ngDebugContext && error.ngDebugContext.componentRenderElement) {
      const frontendLog: FrontendLog = this.createRuntimeErrorObj(error);
      this.sendErrorLog(frontendLog);
    } else {
      const frontendLog = this.createNetworkErrorObj(error);
      this.sendErrorLog(frontendLog);
    }
  }

  createNetworkErrorObj(error: HttpErrorResponse, errorCode = 0): FrontendLog {
    const errObj: FrontendLog = {
      details: {
        message: error.message,
        errorName: error.name
      },
      networkError: {
        status: error.status,
        errorCode: errorCode
      }
    };
    return errObj;
  }

  createRuntimeErrorObj(error): FrontendLog {
    const nodeName = error.ngDebugContext.componentRenderElement.nodeName;
      const errObj: FrontendLog = {
        details: {
          errorName: error.name,
          message: error.message,
          stack: error.stack
        },
        runtimeError: { nodeName }
      };
    return errObj;
  }
}
