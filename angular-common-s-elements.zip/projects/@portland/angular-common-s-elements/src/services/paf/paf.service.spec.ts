import { HttpErrorResponse, HttpHeaders, HttpRequest } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { fail } from 'assert';
import * as chai from 'chai';
import { expect } from 'chai';
import * as sinon from 'sinon';
import * as sinonChai from 'sinon-chai';
import { PafAddressLookup, PafItem } from '../../models/paf';
import { HttpHeadersService } from '../http-headers/http-headers.service';
import { PafSpectrumService } from './paf-spectrum.service';



describe('PafSecurityService', () => {

  let service: PafSpectrumService;
  let httpTestingController: HttpTestingController;

  beforeAll(() => {
    chai.use(sinonChai);
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        PafSpectrumService,
        HttpHeadersService,
      ],
      imports: [
        HttpClientTestingModule,
      ],
    });

    httpTestingController = TestBed.get(HttpTestingController);
    service = TestBed.get(PafSpectrumService);
  });

  afterEach(() => {
    httpTestingController.verify();
  });

  describe('#getByParams', () => {
    let stubBuildSecureHeaders;
    const params = { query: 'mk6', container: 'GB|RM|ENG|MILTON_KEYNES' };

    beforeEach(() => {
      let header = new HttpHeaders();
      header = header.set('Authorization', 'PRETENDER_TOKEN');

      stubBuildSecureHeaders = sinon.stub(service.httpHeadersService, 'buildSecureHeaders');
      stubBuildSecureHeaders.returns(header);

    });

    it('should retrieve a list of paf items', () => {
      let value = null;
      const pafItem: PafItem = new PafItem('Mk 6, Grand Central, Stephenson Place',
        'Birmingham, B2 4BQ',
        null,
        null,
        null);
      const pafList: PafItem[] = [];
      pafList.push(pafItem);
      const serviceResponse = {
        items: pafList
      };

      service.getByParams(params).subscribe(
        data => value = data,
        () => fail(null, null, 'should not fail')
      );

      httpTestingController.expectOne((req: HttpRequest<PafItem[]>) => {
        expect(service.httpHeadersService.getHeaders().has('apiName')).to.be.true;
        expect(req.params.get('query')).to.equal('mk6');
        expect(req.params.get('container')).to.equal('GB|RM|ENG|MILTON_KEYNES');
        expect(req.headers.get('Authorization')).to.equal('PRETENDER_TOKEN');
        expect(req.method).to.equal('GET');
        return true;
      }).flush(serviceResponse);

      expect(value).to.equal(pafList);
    });

    it('should return an error when there is any error', () => {
      service.getByParams(params).subscribe(
        () => fail(null, null, 'should not return a valid response'),
        (error: HttpErrorResponse) => expect(error.status).to.equal(400)
      );

      httpTestingController.expectOne((req: HttpRequest<PafItem[]>) => {
        expect(service.httpHeadersService.getHeaders().has('apiName')).to.be.true;
        expect(req.params.get('query')).to.equal('mk6');
        expect(req.params.get('container')).to.equal('GB|RM|ENG|MILTON_KEYNES');
        expect(req.method).to.equal('GET');
        return true;
      }).error(new ErrorEvent('Bad request'), { status: 400, statusText: 'wrong response' });
    });
  });

  describe('#getByID', () => {
    let stubBuildSecureHeaders;

    beforeEach(() => {
      let header = new HttpHeaders();
      header = header.set('Authorization', 'PRETENDER_TOKEN');

      stubBuildSecureHeaders = sinon.stub(service.httpHeadersService, 'buildSecureHeaders');
      stubBuildSecureHeaders.returns(header);
    });

    it('should call with format param in the request', () => {
      service.getById('idAddress').subscribe();

      httpTestingController.expectOne((req: HttpRequest<PafAddressLookup>) => {
        expect(service.httpHeadersService.getHeaders().has('apiName')).to.be.true;
        expect(req.params.get('format')).to.equal('legacy');
        expect(req.headers.get('Authorization')).to.equal('PRETENDER_TOKEN');
        return true;
      });
    });

    it('should return an error observable when there is an network issue', () => {
      service.getById('idAddress').subscribe(
        () => fail,
        (error: HttpErrorResponse) => expect(error.status).to.equal(503)
      );

      httpTestingController.expectOne((req: HttpRequest<PafAddressLookup>) => {
        expect(service.httpHeadersService.getHeaders().has('apiName')).to.be.true;
        expect(req.params.get('format')).to.equal('legacy');
        expect(req.headers.get('Authorization')).to.equal('PRETENDER_TOKEN');
        return true;
      }).error(new ErrorEvent('Bad request'), { status: 503, statusText: 'service down' });
    });

    it('should return the data as an Address object', () => {
      const address = new PafAddressLookup('housey house', 'streety street', '', 'towny town', 'posty post');

      let response;
      service.getById('id').subscribe((data) => {
        response = data;
      });

      httpTestingController.expectOne(() => true).flush({
        premise: 'housey house', primaryStreet: 'streety street', secondaryStreet: '', town: 'towny town', postcode: 'posty post'
      });

      expect(response).to.deep.equal(address);
    });
  });
});
