import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { PafAddressLookup, PafItem } from '../../models/paf';

@Injectable({
  providedIn: 'root'
})
export abstract class PafService {
  abstract getByParams(params: string): Observable<PafItem[]>;
  abstract getById(id: String): Observable<PafAddressLookup>;
}
