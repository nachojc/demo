import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, tap, timeoutWith } from 'rxjs/operators';
import { PafAddressLookup, PafItem } from '../../models/paf';
import { HttpHeadersService } from '../http-headers/http-headers.service';
import { PafService } from './paf.service';


@Injectable({
  providedIn: 'root'
})
export class PafSpectrumService implements PafService {

  private API_NAME = 'addresslookupservice';
  private endpoint = 'addresses';
  private retryCount = 0;

  constructor(
    public http: HttpClient,
    public httpHeadersService: HttpHeadersService) {
  }

  getByParams (params): Observable<PafItem[]> {
    if (params.query === '') {
      const emptyPaf: PafItem[] = [];
      return (of(emptyPaf));
    }
    const queryParams = this.toHttpParams({ query: this.parse(params.query), container: params.container });
    const url = `${this.httpHeadersService.env}/${this.endpoint}`;

    const tapOperator = tap(() => this.retryCount = 0);
    const timeoutOperator = timeoutWith(10000, of(new Error('TIMEOUT_ERROR')));
    const mapOperator = map((data) => data['items']);
    const catchErrorOperator = catchError((error: HttpErrorResponse) => {
      if (error.toString().includes('TIMEOUT_ERROR') && ++this.retryCount < 6) {
        return this.getByParams(params);
      }

      return throwError(error);
    });

    return this.http.get<PafItem[]>(url, { headers: this.httpHeadersService.buildSecureHeaders(), params: queryParams }).pipe(
      tapOperator, timeoutOperator, catchErrorOperator, mapOperator);
  }

  getById (id: String): Observable<PafAddressLookup> {
    const format = 'legacy';
    const queryParams = this.toHttpParams({ format });
    const url = `${this.httpHeadersService.env}/${this.endpoint}/${id}`;
    return this.http.get<PafAddressLookup>(url, { headers: this.httpHeadersService.buildSecureHeaders(), params: queryParams });
  }

  private parse(query): string {
    return query.replace(/[^a-zA-Z0-9\-]/g, ' ');
  }

  private toHttpParams(obj: Object): HttpParams {
    this.httpHeadersService.setApiName(this.API_NAME);
    let params = new HttpParams();
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        const val = obj[key];
        if (val !== null && val !== undefined) {
          params = params.append(key, val.toString());
        }
      }
    }
    return params;
  }
}
