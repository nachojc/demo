import { ProgressIndicatorItem } from './components/progress-indicator/progress-indicator.component';
import FirstNameValidator from './directives/first-name/first-name.validator';
import LastNameValidator from './directives/last-name/last-name.validator';
import OtherTitles from './components/title/otherTitles';
/*
 * FormLibrary of angular-common-s-elements
 */
export * from './s-form-lib.module';
export { FirstNameValidator };
export { LastNameValidator };
export { OtherTitles };
export { SAccordionComponentModule } from './components/accordion/accordion.module';
export { SCheckboxComponentModule } from './components/checkbox/checkbox.module';
export { SErrorDirectiveModule } from './directives/error/error.module';
export { SFirstNameDirectiveModule } from './directives/first-name/first-name.module';
export { SFinancialDirectiveModule } from './directives/financial/financial.module';
export { SInputComponentModule } from './components/input/input.module';
export { SLabelDirectiveModule } from './directives/label/label.module';
export { SLastNameDirectiveModule } from './directives/last-name/last-name.module';
export { SNumericDirectiveModule } from './directives/numeric/numeric.module';
export { SPafModule } from './components/paf/s-paf.module';
export { SRadioGroupComponentModule } from './components/radio-group/radio-group.module';
export { SSelectComponentModule } from './components/select/select.module';
export { SSortcodeComponentModule } from './components/sortcode/sortcode.module';
export { STitleComponentModule } from './components/title/title.module';
export { SDobComponentModule } from './components/dob/dob.module';
export { SYesNoInputModule } from './components/yes-no-input/yes-no-input.module';
export { SListBuilderComponentModule } from './components/list-builder/list-builder.module';

/*
 * LayoutAndNavigationLibrary of angular-common-s-elements
 */
export * from './s-layout-and-navigation-lib.module';
export { SHeaderComponentModule } from './components/header/header.module';
export { SProgressIndicatorComponentModule } from './components/progress-indicator/progress-indicator.module';
export { ProgressIndicatorItem };

/*
 * Models
 */
export * from './models/paf';
export * from './models/fileupload/fileupload.model';

/*
 * Whole angular-common-s-elements
 */
export * from './s-elements-lib.module';

/*
 *  Standalone s-elements, that haven't found a home (module) yet
 */
export { SFileUploadComponent } from './components/fileupload/fileupload.component';
export { SFileUploadModule } from './components/fileupload/fileupload.module';

/*
 * Services  // todo: see if this is the way to export services.. and not part as a module, can you get it from there?
 */

export { FrontendLoggingService } from './services/frontend-logging/frontend-logging.service';
export { FRONTEND_LOGGING_API } from './services/frontend-logging/frontend-logging.config';
export { PafService } from './services/paf/paf.service';
export { PafSpectrumService } from './services/paf/paf-spectrum.service';
export { FileUploadService } from './services/fileupload/fileupload.service';
