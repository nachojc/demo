import { NgModule } from '@angular/core';
import { SFormLibModule } from './s-form-lib.module';
import { SLayoutAndNavigationLibModule } from './s-layout-and-navigation-lib.module';
import { SFileUploadModule } from './components/fileupload/fileupload.module';


@NgModule({
  exports: [
    SFormLibModule,
    SLayoutAndNavigationLibModule,
    // standalone
    SFileUploadModule
  ]
})

export class SElementsLibModule { }
