import { Component, ElementRef } from '@angular/core';
import { routesDef } from '../../enums/routes';

@Component({
  selector: 's-sortcode-demo',
  templateUrl: './s-sortcode-demo.component.html',
  styleUrls: ['../../../styles/page.css', '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-label.css']
})
export class SSortcodeDemoComponent {
  constructor(private el: ElementRef) {}

  public link = routesDef;

  sc: String = '090128';
  sortCode: string;
  wrongValue: String = '0901XX';
  disabled: Boolean = true;

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }
}
