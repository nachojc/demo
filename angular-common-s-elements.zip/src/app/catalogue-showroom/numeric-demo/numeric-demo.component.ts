import { Component } from '@angular/core';

@Component({
  selector: 'numeric-demo',
  templateUrl: './numeric-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class NumericDemoComponent {

}
