import { Component } from '@angular/core';

@Component({
  selector: 'footer-demo',
  templateUrl: './footer-demo.component.html',
  styleUrls: ['../../../styles/page.css', '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-footer.css']
})
export class FooterStyleDemoComponent { }
