import { Component } from '@angular/core';

@Component({
  selector: 'button-demo',
  templateUrl: './button-demo.component.html',
  styleUrls: [
    '../../../styles/page.css',
    '../../../styles/table.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css'
  ]
})
export class ButtonStyleDemoComponent { }
