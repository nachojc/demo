import { Component, ElementRef } from '@angular/core';
import { routesDef } from 'src/app/enums/routes';

@Component({
  selector: 'error-demo',
  templateUrl: './error-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class ErrorDemoComponent {
  testValue: String = '';
  public link = routesDef;

  constructor(private el: ElementRef) { }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }
}
