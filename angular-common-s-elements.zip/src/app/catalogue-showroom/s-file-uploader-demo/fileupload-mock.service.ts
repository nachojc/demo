import { Injectable } from '@angular/core';
import { FileUploadService } from '@portland/angular-common-s-elements';
import { UploadFile, CustomUploadFile, UploadStatus } from '@portland/angular-common-s-elements';
import { Observable, Subject, of } from 'rxjs';
import { delay, takeUntil } from 'rxjs/operators';

@Injectable()
export class FileUploadMock implements FileUploadService {

  customDelay = 5000;
  subjects = new Map<String, Subject<any>>();

  startUpload(file: UploadFile): Observable<CustomUploadFile> {
    const toCancel: Subject<any> = new Subject();
    this.subjects.set(file.id, toCancel);

    const resultFile = Object.assign({}, file) as CustomUploadFile;
    resultFile.status = UploadStatus.Completed;

    return of(resultFile)
      .pipe(
        delay(this.customDelay),
        takeUntil(toCancel)
      );
  }

  cancelUpload(file) {
    if (this.subjects.has(file.id)) {
      this.subjects.get(file.id).next();
    }
  }
}
