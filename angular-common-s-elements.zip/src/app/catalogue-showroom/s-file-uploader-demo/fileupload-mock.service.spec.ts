import { TestBed } from '@angular/core/testing';
import { FileUploadMock } from './fileupload-mock.service';
import { UploadFile, UploadStatus } from '@portland/angular-common-s-elements';
import { Subject } from 'rxjs';

describe('FileUploadMock', () => {

  let service: FileUploadMock;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [FileUploadMock]
    });

    service = TestBed.get(FileUploadMock);
    service.customDelay = 0;
  });


  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should be start upload', () => {
    const file = new UploadFile();
    file.id = '1';

    service.startUpload(file).subscribe((result) => {
      expect(result.id).toBe('1');
      expect(result.status).toBe(UploadStatus.Completed);
    });
  });


  it('should cancel', () => {
    const file = new UploadFile();
    file.id = '1';

    const subject = new Subject();
    service.subjects.set(file.id, subject);

    spyOn(subject, 'next');

    service.cancelUpload(file);

    expect(subject.next).toHaveBeenCalled();
  });

  it('should not cancel', () => {
    const file = new UploadFile();
    file.id = '1';

    const subject = new Subject();
    service.subjects.set(file.id, subject);

    spyOn(subject, 'next');

    file.id = '2';
    service.cancelUpload(file);

    expect(subject.next).not.toHaveBeenCalled();
  });

});
