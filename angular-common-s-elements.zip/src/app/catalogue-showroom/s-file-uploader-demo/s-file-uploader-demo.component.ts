import { Component, OnInit, ViewChildren, QueryList, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { UploadFile, UploadStatus, CustomUploadFile, SFileUploadComponent } from '@portland/angular-common-s-elements';
import { FileUploadMock } from './fileupload-mock.service';

@Component({
  selector: 's-file-uploader-demo',
  templateUrl: './s-file-uploader-demo.component.html',
  providers: [{
    provide: 'GenericUploadService',
    useClass: FileUploadMock
  }],
  styleUrls: ['../../../styles/page.css']
})
export class SFileUploaderDemoComponent implements OnInit, AfterViewInit {

  @ViewChildren(SFileUploadComponent) public child: QueryList<SFileUploadComponent>;

  myFormTemplate: any;
  myFormReactive: any;

  standaloneValue: Boolean = true;

  checked: Boolean;

  myForm: FormGroup;

  constructor(private form: FormBuilder) { }

  ngOnInit() {
    this.myForm = this.form.group({
      adios: new FormControl(this.checked)
    });
  }

  ngAfterViewInit(): void {
    // set demo on file uploaders to corrrect state
    const errorFile: UploadFile = {
      id: '2',
      name: 'test.png',
      status: UploadStatus.Error,
      nativefile: null
    };
    setTimeout(() => {
      this.child.toArray()[2].resetFileStatus(errorFile);
    }, 0); // prevent ExpressionChangedAfterItHasBeenCheckedError

    const invalidFile: UploadFile = {
      id: '3',
      name: 'test.png',
      status: UploadStatus.Invalid,
      nativefile: null
    };
    setTimeout(() => {
      this.child.toArray()[3].resetFileStatus(invalidFile);
    }, 0); // prevent ExpressionChangedAfterItHasBeenCheckedError


    const genericErrorFile: UploadFile = {
      id: '4',
      name: 'test.png',
      status: UploadStatus.Error,
      nativefile: null
    };
    setTimeout(() => {
      this.child.toArray()[4].resetFileStatus(genericErrorFile);
    }, 0); // prevent ExpressionChangedAfterItHasBeenCheckedError
  }

  onFileUploadComplete(file: CustomUploadFile) {
    if (file.status === UploadStatus.Completed) {
      window.alert('hooray! file uploaded');
    } else if (file.status === UploadStatus.Ready) {
      window.alert('file removed');
    }
  }
}
