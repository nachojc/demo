import { Component } from '@angular/core';

@Component({
  selector: 'app-frontend-logging-demo',
  templateUrl: './frontend-logging-demo.component.html',
  styleUrls: ['../../../styles/page.css',
  './frontend-logging-demo.component.scss',
  '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css']
})
export class FrontendLoggingDemoComponent {
  displayError = {
    runtime: false,
    network: false,
    loading: false
  };

  onErrorSelection(typeOfError) {
    if (typeOfError === 'runtime') {
      this.displayError.network = false;
      this.displayError.runtime = false;
      this.displayError.loading = true;
      setTimeout(() => {
        this.displayError.loading = false;
        this.displayError.runtime = true;
      }, 2000);
    } else if (typeOfError === 'network') {
      this.displayError.network = false;
      this.displayError.runtime = false;
      this.displayError.loading = true;
      setTimeout(() => {
        this.displayError.loading = false;
        this.displayError.network = true;
      }, 2000);
    } else {
      this.displayError.network = false;
      this.displayError.runtime = false;
    }
  }
}
