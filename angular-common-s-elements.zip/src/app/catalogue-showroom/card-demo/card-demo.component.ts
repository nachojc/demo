import { Component } from '@angular/core';

@Component({
  selector: 'card-demo',
  templateUrl: './card-demo.component.html',
  styleUrls: ['../../../styles/page.css', '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-card.css']
})
export class CardStyleDemoComponent { }
