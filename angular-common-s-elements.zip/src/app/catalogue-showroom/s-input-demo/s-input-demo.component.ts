import { Component, OnInit, ElementRef } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder, AbstractControl } from '@angular/forms';
import { FirstNameValidator } from '@portland/angular-common-s-elements';

import { routesDef } from '../../enums/routes';

@Component({
  selector: 's-input-demo',
  templateUrl: './s-input-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class SInputDemoComponent implements OnInit {
  public link = routesDef;

  myFormTemplate: any;

  myForm: FormGroup;
  myFormReactive: any;
  testValue: String = '';
  noDebounceValue: String = '';

  constructor(private form: FormBuilder, private el: ElementRef) { }

  ngOnInit() {
    this.myForm = this.form.group({
      firstName: new FormControl('', [Validators.required, FirstNameValidator, Validators.minLength(5)]),
      nickname: new FormControl(''),
      lastName: ''
    });
  }

  onSubmitTemp (myFormValue) {
    this.myFormTemplate = myFormValue;
  }

  onSubmitReact (myFormValue) {
    this.myFormReactive = myFormValue;
  }

  hasValidator (_control: string, validator: string): boolean {
    const control: AbstractControl = this.myForm.controls[_control];
    const lastValue: any = control.value;
    switch (validator) {
      case 'required':
        control.setValue('');  // as is appropriate for the control
        break;
    }
    const hasValidator: boolean = !!control.validator(control).hasOwnProperty(validator);
    control.setValue(lastValue);
    return hasValidator;
  }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }
}
