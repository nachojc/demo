import { Component, OnInit, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { routesDef } from '../../enums/routes';

@Component({
  selector: 's-title-demo',
  templateUrl: './s-title-demo.component.html',
  styleUrls: ['../../../styles/page.css',
  '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-label.css',
  '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css',
  '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-label.css',
  ]
})
export class STitleDemoComponent implements OnInit {
  public link = routesDef;

  myFormTemplate: any;
  myFormReactive: any;

  myForm: FormGroup;

  constructor(private fb: FormBuilder, private el: ElementRef) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      title: ['', Validators.required],
    });
  }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }

  onSubmit(form) {
    if (form.valid === false) {
      Object.keys(form.controls).forEach((field) => {
        const control = form.controls[field];
        control.markAsTouched();
      });
    }
  }

}
