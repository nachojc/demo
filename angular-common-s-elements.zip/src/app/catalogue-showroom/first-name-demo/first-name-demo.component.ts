import { Component } from '@angular/core';

@Component({
  selector: 'first-name-demo',
  templateUrl: './first-name-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class FirstNameDemoComponent {
  myFormTemplate: any;

  onSubmitTemp (myFormValue) {
    this.myFormTemplate = myFormValue;
  }
}
