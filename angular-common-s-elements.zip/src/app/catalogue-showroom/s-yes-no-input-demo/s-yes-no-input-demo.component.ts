import { Component, ElementRef, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { routesDef } from '../../enums/routes';

@Component({
  selector: 's-yes-no-input-demo',
  templateUrl: './s-yes-no-input-demo.component.html',
  styleUrls: ['../../../styles/page.css', '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-label.css']
})
export class SYesNoInputDemoComponent implements OnInit {
  public form: FormGroup;
  public link = routesDef;
  constructor (private el: ElementRef) { }

  ngOnInit () {
    this.form = new FormBuilder().group({
      like: [null, [this.mustBeYes, Validators.required]],
      reallyLike: [null, [this.mustBeYes]],
      laziness: [null, [this.mustBeNo, Validators.required]],
    });
  }

  mustBeYes (control: AbstractControl) {
    return control.value === 'Yes' ? null : { YesNoValidation: true };
  }

  mustBeNo (control: AbstractControl) {
    return control.value === 'No' ? null : { YesNoValidation: true };
  }

  clickOnLink (route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }
}
