import { Component, ElementRef } from '@angular/core';
import { routesDef } from 'src/app/enums/routes';

@Component({
  selector: 'app-standalone',
  templateUrl: './standalone.component.html',
  styleUrls: ['../../../../styles/page.css']
})
export class StandaloneComponent {
  public link = routesDef;

  constructor(private el: ElementRef) { }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', { detail: route, bubbles: true }));
  }
}
