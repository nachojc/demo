import { Component } from '@angular/core';

@Component({
  selector: 'alert-demo',
  templateUrl: './alert-demo.component.html',
  styleUrls: [
    '../../../styles/page.css',
    '../../../styles/table.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-alert.css'
  ]
})
export class AlertStyleDemoComponent { }
