import { Component, ElementRef } from '@angular/core';
import { routesDef } from '../../enums/routes';

@Component({
  selector: 'label-demo',
  templateUrl: './label-demo.component.html',
  styleUrls: ['../../../styles/page.css', '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-label.css']
})
export class LabelDemoComponent {
  public link = routesDef;

  constructor(private el: ElementRef) { }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }
 }
