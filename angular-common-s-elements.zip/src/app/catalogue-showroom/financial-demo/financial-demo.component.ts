import { Component, ElementRef, HostListener, OnInit } from '@angular/core';
import { routesDef } from 'src/app/enums/routes';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'financial-demo',
  templateUrl: './financial-demo.component.html',
  styleUrls: [
    '../../../styles/page.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css'
  ]
})
export class FinancialDemoComponent implements OnInit {
  currencyValueGBP = '';
  currencyValueEUR = '';
  currencyPrefix = '';
  decimalLength = '';
  currencyDefault = '';
  currencyTemplate = '';

  myForm: FormGroup;

  public link = routesDef;

  @HostListener('change', ['$event']) formatValue(event) {
    // event.target.dispatchEvent(new Event('input'));
  }

  constructor(private fb: FormBuilder, private el: ElementRef) { }

  ngOnInit() {
    this.myForm = this.fb.group({
      financial: ['', Validators.required],
    });
  }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }

  onSubmit(form) {
    if (form.valid === false) {
      Object.keys(form.controls).forEach((field) => {
        const control = form.controls[field];
        control.markAsTouched();
      });
    }
  }
}
