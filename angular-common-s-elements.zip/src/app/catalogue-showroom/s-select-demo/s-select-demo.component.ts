import { Component, OnInit, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

import { routesDef } from '../../enums/routes';

@Component({
  selector: 's-select-demo',
  templateUrl: './s-select-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class SSelectDemoComponent implements OnInit {
  public link = routesDef;

  public flatOptions: Array<number> = [11, 13, 15, 17, 19, 21];
  public flatNumber: Number;
  public selectedCurrency: String = 'EUR';

  myFormTemplate: any;
  myFormReactive: any;

  myForm: FormGroup;

  selectModel = 2;

  reactiveModel = new FormControl('');


  reactiveModel1 = new FormGroup({
    selectValue: new FormControl('')
  });

  reactiveModel2 = this.form.group({
    selectValue1: ['', Validators.required],
  });

  constructor(private form: FormBuilder, private el: ElementRef) { }

  ngOnInit() {
    this.myForm = this.form.group({
      flatNumber: new FormControl('')
    });
  }

  onSubmitTemp(myFormValue) {
    this.myFormTemplate = myFormValue;
  }

  onSubmitReact(myFormValue) {
    this.myFormReactive = myFormValue;
  }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }

}
