import { Component } from '@angular/core';

@Component({
  selector: 'link-demo',
  templateUrl: './link-demo.component.html',
  styleUrls: [
    '../../../styles/page.css',
    '../../../styles/table.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-link.css'
  ]
})
export class LinkStyleDemoComponent { }
