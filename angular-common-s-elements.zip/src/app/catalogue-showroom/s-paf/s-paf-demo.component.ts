import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { PafAddressLookup, PafSpectrumService } from '@portland/angular-common-s-elements';


@Component({
  selector: 's-paf-demo',
  templateUrl: './s-paf-demo.component.html',
  styleUrls: ['../../../styles/page.css', '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css'],
  providers: [{
    provide: 'GenericPafService',
    useClass: PafSpectrumService
  }],
})
export class SPafDemoComponent implements OnInit {
  dataForm: FormGroup;
  pafForm: FormGroup;
  displayPaf: boolean;
  displayWarning: boolean;
  mark: boolean;

  constructor(public pafSpectrumService: PafSpectrumService, public fb: FormBuilder) { }

  ngOnInit() {
    this.dataForm = this.fb.group({
      url: ['', Validators.required],
      clientID: ['', Validators.required],
      token: ['', Validators.required]
    });

    this.pafForm = this.fb.group({
      paf: [null, Validators.required],
    });

    this.pafForm.valueChanges.subscribe((data) => {
      this.mark = data ? false : true;
    });
  }

  onClick(): void {
    if (this.displayPaf) {
      this.pafForm.get('paf').reset(null);
      this.displayPaf = false;
    } else {
      const isValid: boolean = this.dataForm.valid;
      if (isValid) {
        this.setHttpHeaders();
      } else {
        this.dataForm.get('url').markAsTouched();
        this.dataForm.get('clientID').markAsTouched();
        this.dataForm.get('token').markAsTouched();
      }
      this.displayPaf = isValid;
    }
  }

  onClickData(): void {
    if (this.displayPaf) {
      this.pafForm.get('paf').reset(null);
      this.displayPaf = false;
    } else {
      this.dataForm.get('url').setValue('https://mock-core-service-business-transfers-dev.appls.cap1.paas.gsnetcloud.corp');
      this.dataForm.get('clientID').setValue('any_not_empty_id');
      this.dataForm.get('token').setValue('any_not_empty_oken');
      this.displayWarning = true;

      this.setHttpHeaders();
      this.displayPaf = true;
    }
  }

  onPafFormSubmit(form) {
    Object.keys(form.controls).forEach((field) => {
      form.controls[field].markAsTouched();
    });

    this.mark = this.pafForm.invalid ? true : false;
  }

  get paf(): PafAddressLookup { return this.pafForm.get('paf').value; }
  private get url(): string { return this.dataForm.get('url').value; }
  private get clientID(): string { return this.dataForm.get('clientID').value; }
  private get token(): string { return this.dataForm.get('token').value; }


  private setHttpHeaders(): void {
    this.pafSpectrumService.httpHeadersService.setOauth2Headers(this.token, this.clientID);
    this.pafSpectrumService.httpHeadersService.env = this.url;
  }
}
