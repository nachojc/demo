import { Component } from '@angular/core';

@Component({
  selector: 'error-style-demo',
  templateUrl: './error-style-demo.component.html',
  styleUrls: [
    '../../../styles/page.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-error.css'
  ]
})
export class ErrorStyleDemoComponent {}
