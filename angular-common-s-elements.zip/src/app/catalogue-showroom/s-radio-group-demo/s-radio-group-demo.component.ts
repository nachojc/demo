import { Component, ElementRef, OnInit } from '@angular/core';
import { routesDef } from '../../enums/routes';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 's-radio-group-demo',
  templateUrl: './s-radio-group-demo.component.html',
  styleUrls: [
    '../../../styles/page.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-label.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-error.css'
  ]
})
export class SRadioGroupDemoComponent implements OnInit {
  public link = routesDef;

  public ageRange = ['0-10', '11-15', '16-20', '21-25', '25-30', 'Over 30'];
  reactiveForm: FormGroup;

  constructor(private el: ElementRef, public fb: FormBuilder) { }

  ngOnInit() {
    this.reactiveForm = this.fb.group({
      ageRangeReactive: ['', Validators.required],
    });
  }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }

  onSubmit(form) {
    if (form.valid === false) {
      Object.keys(form.controls).forEach((field) => {
        const control = form.controls[field];
        control.markAsTouched();
      });
    }
  }
}
