import { Component, OnInit, ElementRef } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder, AbstractControl } from '@angular/forms';
import { FirstNameValidator } from '@portland/angular-common-s-elements';

import { routesDef } from '../../enums/routes';
import { CustomDate } from '@portland/angular-common-s-elements/models/dob/custom-date';

@Component({
  selector: 's-dob-demo',
  templateUrl: './s-dob-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class SDobDemoComponent implements OnInit {

  constructor(public fb: FormBuilder) {
  }

  form: FormGroup;
  formGroup: FormGroup;
  initialize: CustomDate;
  displayErrors: boolean;

  ngOnInit() {
    this.form = this.fb.group({
      dobProperty: [this.initialize]
    });
    this.formGroup = this.fb.group({
      dobPropertyOne: [this.initialize],
      dobPropertyTwo: [this.initialize],
    });
  }

  get dobProperty() { return this.form.get('dobProperty'); }

  onClick(): void {
    this.displayErrors = !this.displayErrors;
  }

  initForm(): void {
    this.ngOnInit();
  }
}

