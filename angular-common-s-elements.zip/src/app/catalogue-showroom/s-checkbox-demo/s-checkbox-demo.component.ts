import { Component, OnInit, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

import { routesDef } from '../../enums/routes';

@Component({
  selector: 's-checkbox-demo',
  templateUrl: './s-checkbox-demo.component.html',
  styleUrls: ['../../../styles/page.css']
})
export class SCheckboxDemoComponent implements OnInit {
  public link = routesDef;

  myFormTemplate: any;
  myFormReactive: any;

  standaloneValue: Boolean = true;

  checked: Boolean;

  myForm: FormGroup;

  constructor(private form: FormBuilder, private el: ElementRef) { }

  ngOnInit() {
    this.myForm = this.form.group({
      adios: new FormControl(this.checked)
    });
  }

  onSubmitReact (myFormValue) {
    this.myFormReactive = myFormValue;
  }

  onSubmitTemp (myFormValue) {
    this.myFormTemplate = myFormValue;
  }

  clickOnLink(route: String) {
    this.el.nativeElement.dispatchEvent(new CustomEvent('click-on-link', {detail: route, bubbles: true}));
  }
}
