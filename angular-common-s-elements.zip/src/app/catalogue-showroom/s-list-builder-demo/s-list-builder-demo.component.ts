import { Component, OnInit, ViewChild } from '@angular/core';
import { Countries } from './countries.model';
import { NgModel, FormBuilder, FormControl, Validators, FormGroup} from '@angular/forms';
@Component({
  selector: 'app-list-builder-demo',
  templateUrl: './s-list-builder-demo.component.html',
  styleUrls: ['../../../styles/page.css',
  '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css']
})
export class SListBuilderDemoComponent implements OnInit {
  reactiveFormWithInputs: FormGroup;
  reactiveFormWithoutInputs: FormGroup;
  countries = Countries.map(obj => obj.value);

  @ViewChild('standalone') standalone: NgModel;

  constructor(public fb: FormBuilder) { }

  ngOnInit() {
    this.reactiveFormWithInputs = this.fb.group({
      builder: new FormControl('', Validators.required),
    });
    this.reactiveFormWithoutInputs = this.fb.group({
      builder: new FormControl('', Validators.required),
    });
  }

  onSubmit(form) {
    if (!form.valid) {
      Object.keys(form.controls).forEach((field) => {
        const control: FormControl = form.controls[field];
        control.markAsTouched();
      });
    }
  }

}
