import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 's-telephone-demo',
  templateUrl: './s-telephone-demo.component.html',
  styleUrls: ['./s-telephone-demo.component.scss',
              '../../../styles/page.css',
              '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-error.css',
              '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css']
})
export class STelephoneDemoComponent implements OnInit {
  reactiveForm: FormGroup;

  constructor(public fb: FormBuilder) {
  }

  ngOnInit() {
    this.reactiveForm = this.fb.group({
      telephone: new FormControl('', Validators.required),
    });
  }

  onSubmit(form) {
    if (!form.valid) {
      Object.keys(form.controls).forEach((field) => {
        const control = form.controls[field];
        control.markAsTouched();
      });
    }
  }
}
