import { Component } from '@angular/core';
import { ProgressIndicatorItem } from '@portland/angular-common-s-elements';

@Component({
  selector: 's-progress-indicator-demo',
  templateUrl: './s-progress-indicator-demo.component.html',
  styleUrls: [
    './s-progress-indicator-demo.component.css',
    '../../../styles/page.css',
    // in external app should be assets/styles/s-button.css
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css'
  ]
})
export class SProgressIndicatorDemoComponent {
  olaNavigation: ProgressIndicatorItem[] = [
    { label: 'About you', status: 'selected' },
    { label: 'Financial details' },
    { label: 'Summary' },
    { label: 'Sign up' },
    { label: 'what happens next'}
  ];

  previousPageFunction(navigation) {
    let selected = false;
    let i = 0;
    let posic = 0;
    while (i < navigation.length && !selected) {
      if (navigation[i].status === 'selected') {
        posic = i;
        selected = true;
      }
      i++;
    }

    if (selected && posic - 1 >= 0) {
      navigation[posic] = { label: navigation[posic].label };
      navigation[posic - 1] = { label: navigation[posic - 1].label, status: 'selected' };
    } else {
      if (navigation[navigation.length - 1].status === 'ok' || navigation[navigation.length - 1].status === 'error') {
        navigation[navigation.length - 1] = { label: navigation[navigation.length - 1].label, status: 'selected' };
      }
    }
  }

  nextPageFunction(navigation, estado: string) {
    let selected = false;
    let i = 0;
    let posic = 0;
    while (i < navigation.length - 1 && !selected) {
      if (navigation[i].status === 'selected') {
        posic = i;
        selected = true;
      }
      i++;
    }

    if (selected) {
      navigation[posic] = { label: navigation[posic].label, status: estado };
      if (posic + 1 < navigation.length) {
        navigation[posic + 1] = { label: navigation[posic + 1].label, status: 'selected' };
      }
    }
  }
}
