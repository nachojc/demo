import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 's-accordion-demo',
  templateUrl: './s-accordion-demo.component.html',
  styleUrls: [
    './s-accordion-demo.component.scss',
    '../../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css',
    '../../../styles/page.css'
  ]
})

export class SAccordionDemoComponent implements OnInit {
  @Input() accordionName = 'testName';

  display = [];
  accordions = [];
  totalAccordions = 4;
  valid = false;
  value;

  ngOnInit() {
    this.display = Array(this.totalAccordions).fill(false);
    this.accordions = Array(this.totalAccordions).fill([]);
    window.scrollTo(0, 0);
  }

  onToggleStatus(status, order) {
    this.accordions[order] = status;
    if ( this.accordions[order][1] ) {
      for (let i = 0; i < this.totalAccordions; i++) {
        if ( i !== order ) {
          this.display[i] = false;
        } else {
          this.display[i] = true;
        }
      }
    }
  }

  getValue(value) {
    this.value = value;
  }

  onSubmit() {
    let counter = 0;
    for ( let i = 0 ; i < this.totalAccordions ; i++ ) {
      if ( this.accordions[i][2] === true )  {
        counter++;
      }
    }
    if (counter === this.totalAccordions) {
      this.valid = true;
    } else {
      this.valid = false;
    }
  }
}
