import { Component, HostListener, OnInit, OnDestroy, ViewEncapsulation, ElementRef, Renderer2 } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { Subscription } from 'rxjs';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  showMenu: boolean;
  private routerSubscription: Subscription;
  activeItem: string;

  @HostListener('click-on-link', ['$event']) linkTo(route: CustomEvent) {
    this.navigateTo(route.detail);
  }
  constructor(private router: Router, private el: ElementRef, private renderer: Renderer2) {}

  ngOnInit(): void {
    this.routerSubscription = this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe(() => { window.scrollTo(0, 0); }
    );
  }

  navigateTo(route: string) {
    this.activeItem = route;
    this.router.navigate([route]);
    this.toggleMenu();
  }

  ngOnDestroy() {
    this.routerSubscription.unsubscribe();
  }

  toggleMenu() {
    const body = document.body;
    this.showMenu = !this.showMenu;
    if (this.showMenu) {
      this.renderer.addClass(body, 'scrollable-lock');
      this.renderer.addClass(body, 'has-overlay');
    } else {
      this.renderer.removeClass(body, 'scrollable-lock');
      this.renderer.removeClass(body, 'has-overlay');
    }
  }

  isActive(item) {
    return item === this.activeItem;
  }
}
