import { Component } from '@angular/core';
import md from '../../CHANGELOG.md';

@Component({
  selector: 'app-changelog',
  template:
    `
      <h1 class="title">What's new</h1>
      <div class="content" [innerHTML]="md"><div>
    `,
    styleUrls: ['../styles/page.css']
})
export class ChangelogComponent {
  public md = md;
}
