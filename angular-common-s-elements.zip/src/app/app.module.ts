/* tslint:disable */
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
// includes SFormLibModule and SLayoutAndNavigationLibModule
import { SElementsLibModule, SFileUploadModule } from '@portland/angular-common-s-elements';
import { HighlightJsModule } from 'ngx-highlight-js';
import { AppComponent } from './app.component';
import { AlertStyleDemoComponent } from './catalogue-showroom/alert-demo/alert-demo.component';
import { ButtonStyleDemoComponent } from './catalogue-showroom/button-demo/button-demo.component';
import { CardStyleDemoComponent } from './catalogue-showroom/card-demo/card-demo.component';
import { ErrorDemoComponent } from './catalogue-showroom/error-demo/error-demo.component';
import { ErrorStyleDemoComponent } from './catalogue-showroom/error-style-demo/error-style-demo.component';
import { FirstNameDemoComponent } from './catalogue-showroom/first-name-demo/first-name-demo.component';
import { FinancialDemoComponent } from './catalogue-showroom/financial-demo/financial-demo.component';
import { FooterStyleDemoComponent } from './catalogue-showroom/footer-demo/footer-demo.component';
import { LabelDemoComponent } from './catalogue-showroom/label-demo/label-demo.component';
import { LabelStyleDemoComponent } from './catalogue-showroom/label-styles-demo/label-styles-demo.component';
import { LastNameDemoComponent } from './catalogue-showroom/last-name-demo/last-name-demo.component';
import { LinkStyleDemoComponent } from './catalogue-showroom/link-demo/link-demo.component';
import { FormModuleComponent } from './catalogue-showroom/modules-and-categories/form-module/form-module.component';
import {
  LayoutAndNavigationModuleComponent
 } from './catalogue-showroom/modules-and-categories/layout-and-navigation-module/layout-and-navigation-module.component';
import { StandaloneComponent } from './catalogue-showroom/modules-and-categories/standalone/standalone.component';
import { StylesComponent } from './catalogue-showroom/modules-and-categories/styles/styles.component';
import { NumericDemoComponent } from './catalogue-showroom/numeric-demo/numeric-demo.component';
import { SAccordionDemoComponent } from './catalogue-showroom/s-accordion-demo/s-accordion-demo.component';
import { SCheckboxDemoComponent } from './catalogue-showroom/s-checkbox-demo/s-checkbox-demo.component';
import { SFileUploaderDemoComponent } from './catalogue-showroom/s-file-uploader-demo/s-file-uploader-demo.component';
import { SHeaderDemoComponent } from './catalogue-showroom/s-header-demo/s-header-demo.component';
import { SInputDemoComponent } from './catalogue-showroom/s-input-demo/s-input-demo.component';
import { SPafDemoComponent } from './catalogue-showroom/s-paf/s-paf-demo.component';
import { SProgressIndicatorDemoComponent } from './catalogue-showroom/s-progress-indicator-demo/s-progress-indicator-demo.component';
import { SRadioGroupDemoComponent } from './catalogue-showroom/s-radio-group-demo/s-radio-group-demo.component';
import { SSelectDemoComponent } from './catalogue-showroom/s-select-demo/s-select-demo.component';
import { SSortcodeDemoComponent } from './catalogue-showroom/s-sortcode-demo/s-sortcode-demo.component';
import { STitleDemoComponent } from './catalogue-showroom/s-title/s-title-demo.component';
import { SYesNoInputDemoComponent } from './catalogue-showroom/s-yes-no-input-demo/s-yes-no-input-demo.component';
import { ChangelogComponent } from './changelog.component';
import { CurrentVersionComponent } from './current-version.component';
import { routesDef } from './enums/routes';
import { GeneralInformationComponent } from './general-information/general-information/general-information.component';
import { ModelDrivenFormExampleComponent } from './model-driven-form-example/model-driven-form-example.component';
import { ReadmeComponent } from './readme/readme.component';
import { TemplateDrivenFormExampleComponent } from './template-driven-form-example/template-driven-form-example.component';
import { FrontendLoggingDemoComponent } from './catalogue-showroom/frontend-logging-demo/frontend-logging-demo.component';
import { SDobDemoComponent } from './catalogue-showroom/s-dob-demo/s-dob-demo.component';
import { STelephoneDemoComponent } from './catalogue-showroom/s-telephone-demo/s-telephone-demo.component';
import { SListBuilderDemoComponent } from './catalogue-showroom/s-list-builder-demo/s-list-builder-demo.component';




const appRoutes: Routes = [
  { path: '', component: GeneralInformationComponent },

  // Modules and Categories
  { path: routesDef.formModule, component: FormModuleComponent },
  { path: routesDef.layoutAndNavigationModule, component: LayoutAndNavigationModuleComponent },
  { path: routesDef.standalone, component: StandaloneComponent },
  { path: routesDef.styles, component: StylesComponent },

  // Form
  { path: routesDef.accordionComponentDemo, component: SAccordionDemoComponent },
  { path: routesDef.checkboxComponentDemo, component: SCheckboxDemoComponent },
  { path: routesDef.errorDirectiveDemo, component: ErrorDemoComponent },
  { path: routesDef.firstNameDirectiveDemo, component: FirstNameDemoComponent },
  { path: routesDef.inputComponentDemo, component: SInputDemoComponent },
  { path: routesDef.labelDirectiveDemo, component: LabelDemoComponent },
  { path: routesDef.lastNameDirectiveDemo, component: LastNameDemoComponent },
  { path: routesDef.selectComponentDemo, component: SSelectDemoComponent },
  { path: routesDef.sortcodeComponentDemo, component: SSortcodeDemoComponent },
  { path: routesDef.numericDirectiveDemo, component: NumericDemoComponent },
  { path: routesDef.yesNoInputComponentDemo, component: SYesNoInputDemoComponent },
  { path: routesDef.sPafDemoComponentDemo, component: SPafDemoComponent },
  { path: routesDef.sRadioGroupDemoComponent, component: SRadioGroupDemoComponent },
  { path: routesDef.sTelephoneComponentDemo, component: STelephoneDemoComponent },
  { path: routesDef.sTitleDemoComponent, component: STitleDemoComponent },
  { path: routesDef.sDobComponentDemo, component: SDobDemoComponent },
  { path: routesDef.sFinancialDemoComponent, component: FinancialDemoComponent },
  { path: routesDef.sListBuilderComponentDemo, component: SListBuilderDemoComponent},

  // Layout and Navigation
  { path: routesDef.ProgressIndicatorComponentDemo, component: SProgressIndicatorDemoComponent },
  { path: routesDef.headerComponentDemo, component: SHeaderDemoComponent },

  // Standalone
  { path: routesDef.fileUploaderComponentDemo, component: SFileUploaderDemoComponent },
  { path: routesDef.frontendLoggingComponentDemo, component: FrontendLoggingDemoComponent },

  // Styles
  { path: routesDef.alertStyleComponentDemo, component: AlertStyleDemoComponent },
  { path: routesDef.buttonStyleComponentDemo, component: ButtonStyleDemoComponent },
  { path: routesDef.cardStyleComponentDemo, component: CardStyleDemoComponent },
  { path: routesDef.errorStyleComponentDemo, component: ErrorStyleDemoComponent },
  { path: routesDef.footerStyleComponentDemo, component: FooterStyleDemoComponent },
  { path: routesDef.linkStyleComponentDemo, component: LinkStyleDemoComponent },
  { path: routesDef.labelStyleComponentDemo, component: LabelStyleDemoComponent },

  // Information
  { path: routesDef.changelogComponent, component: ChangelogComponent },
  { path: routesDef.readmeComponent, component: ReadmeComponent },
  { path: routesDef.modelFormComponentDemo, component: ModelDrivenFormExampleComponent },
  { path: routesDef.templateFormComponentDemo, component: TemplateDrivenFormExampleComponent },

  // Others
  { path: '**', redirectTo: '', pathMatch: 'full' }
];

@NgModule({
  declarations: [
    AlertStyleDemoComponent,
    AppComponent,
    ButtonStyleDemoComponent,
    CardStyleDemoComponent,
    ChangelogComponent,
    CurrentVersionComponent,
    ErrorDemoComponent,
    ErrorStyleDemoComponent,
    FirstNameDemoComponent,
    FinancialDemoComponent,
    FooterStyleDemoComponent,
    FormModuleComponent,
    GeneralInformationComponent,
    LabelDemoComponent,
    LastNameDemoComponent,
    LayoutAndNavigationModuleComponent,
    LabelStyleDemoComponent,
    LinkStyleDemoComponent,
    ModelDrivenFormExampleComponent,
    NumericDemoComponent,
    ReadmeComponent,
    SAccordionDemoComponent,
    SProgressIndicatorDemoComponent,
    SCheckboxDemoComponent,
    SFileUploaderDemoComponent,
    SHeaderDemoComponent,
    SInputDemoComponent,
    SPafDemoComponent,
    SRadioGroupDemoComponent,
    SSelectDemoComponent,
    SSortcodeDemoComponent,
    StandaloneComponent,
    STitleDemoComponent,
    StylesComponent,
    SYesNoInputDemoComponent,
    TemplateDrivenFormExampleComponent,
    FrontendLoggingDemoComponent,
    SDobDemoComponent,
    STelephoneDemoComponent,
    SListBuilderDemoComponent
  ],
  imports: [
    RouterModule.forRoot(appRoutes),
    BrowserModule,
    CommonModule,
    FormsModule,
    HighlightJsModule,
    ReactiveFormsModule,
    SElementsLibModule, // SFormLibModule and SLayoutAndNavigationLibModule
    SFileUploadModule
  ],
  providers: [ ],
  bootstrap: [AppComponent]
})
export class AppModule { }
