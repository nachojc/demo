import { Component, OnInit } from '@angular/core';
import npmpackage from '../../projects/@portland/angular-common-s-elements/package.json';
import mergerequest from '../../merge-request-info.md';

@Component({
  selector: 'app-current-version',
  template:
    `
      <h1 class="title">Current version</h1>
      <div class="content">
        <div *ngIf="!isMergeRequest">{{version}}</div>
        <div *ngIf="isMergeRequest" [innerHTML]="mergeRequest"></div>
      </div>
    `,
    styleUrls: ['../styles/page.css']
})
export class CurrentVersionComponent implements OnInit {
  public version: String;
  public mergeRequest: String;
  public isMergeRequest: Boolean;

  ngOnInit() {
    this.version = npmpackage.version;
    this.mergeRequest = mergerequest;
    this.isMergeRequest = !this.mergeRequest
    .startsWith('<h1 id="this-will-be-populated-automatically-with-merge-request-information-to-display-on-the-page">');
  }

}
