import { Component } from '@angular/core';
import readme from '../../../README.md';

@Component({
  selector: 'app-readme',
  template:
    `
      <h1 class="title">Instructions</h1>
      <div class="content" [innerHTML]="readme"><div>
    `,
    styleUrls: ['../../styles/page.css', './readme.component.css']
})
export class ReadmeComponent {
  public readme = readme;
}
