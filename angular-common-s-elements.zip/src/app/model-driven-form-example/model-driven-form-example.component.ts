import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators, AbstractControl } from '@angular/forms';
import { FirstNameValidator } from '@portland/angular-common-s-elements';

@Component({
  selector: 'model-driven-form-example',
  templateUrl: './model-driven-form-example.component.html',
  styleUrls: ['../../styles/forms-container.css', '../../../projects/@portland/angular-common-s-elements/src/assets/styles/s-button.css']
})
export class ModelDrivenFormExampleComponent implements OnInit {
  myForm: FormGroup;
  options = ['', 'this', 'is', 'my', 'only', 'option'];
  myFormReactive: any;

  constructor (private form: FormBuilder) { }

  onSubmitReact (myFormValue) {
    this.myFormReactive = myFormValue;
  }

  ngOnInit () {
    this.myForm = this.form.group({
      firstName: new FormControl('', [Validators.required, FirstNameValidator, Validators.minLength(5)]),
      lastName: '',
      age: '',
      postCode: '',
      isStudent: '',
      selectedValue: ''
    });
  }

  // TODO: take to a util package in our library, and see if there is common values for common
  // validations and see how to expand that
  hasValidator (_control: string, validator: string): boolean {
    const control: AbstractControl = this.myForm.controls[_control];
    const lastValue: any = control.value;
    switch (validator) {
      case 'required':
        control.setValue('');  // as is appropriate for the control
        break;
      // case 'pattern':
      //   control.setValue('3'); // given you have knowledge of what the pattern is - say its '\d\d\d'
      //   break;
      // case 'minlength':
      //   control.setValue('a')
      //   break;
    }
    const hasValidator: boolean = !!control.validator(control).hasOwnProperty(validator);
    control.setValue(lastValue);
    return hasValidator;
  }
}
