export enum routesDef {
  // Modules and Categories
  formModule = 'form-module',
  layoutAndNavigationModule = 'layout-and-navigation-module',
  standalone = 'standalone',
  styles = 'styles',

  // Form
  accordionComponentDemo = 'accordion',
  checkboxComponentDemo = 'checkbox',
  errorDirectiveDemo = 'error',
  firstNameDirectiveDemo = 'firstName',
  inputComponentDemo = 'input',
  labelDirectiveDemo = 'label',
  lastNameDirectiveDemo = 'lastName',
  selectComponentDemo = 'select',
  sortcodeComponentDemo = 'sortcode',
  numericDirectiveDemo = 'numeric',
  yesNoInputComponentDemo = 'yesNoInput',
  sFatcaComponentDemo = 'fatca',
  sPafDemoComponentDemo = 'paf',
  sRadioGroupDemoComponent = 'radioGroup',
  sTitleDemoComponent = 'title',
  sDobComponentDemo = 'dob',
  sFinancialDemoComponent = 'financial',
  sTelephoneComponentDemo = 'telephone',
  sListBuilderComponentDemo = 'list-builder',

  // Layout and Navigation
  ProgressIndicatorComponentDemo = 'progress-indicator',
  headerComponentDemo = 'header',

  // Standalone
  fileUploaderComponentDemo = 'fileUpload',
  frontendLoggingComponentDemo = 'frontendLogging',

  // Styles
  alertStyleComponentDemo = 'alert',
  buttonStyleComponentDemo = 'button',
  cardStyleComponentDemo = 'card',
  errorStyleComponentDemo = 'error-styles',
  footerStyleComponentDemo = 'footer',
  linkStyleComponentDemo = 'link',
  labelStyleComponentDemo = 'label-styles',

  // Information
  changelogComponent = 'changelog',
  readmeComponent = 'readme',
  modelFormComponentDemo = 'modelForm',
  templateFormComponentDemo = 'templateForm'
}
