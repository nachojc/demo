declare module '*.md' {
  const value: any;
  export default value;
}
