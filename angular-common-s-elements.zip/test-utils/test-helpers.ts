import { ComponentFixture } from '@angular/core/testing';

export function byDataQa(dataQa: string): string {
    return `[data-qa="${dataQa}"]`;
}

export function simulateEvent(eventKey, htmlElement): void {
    const event = document.createEvent('Events');
    event.initEvent(eventKey, true, true);
    htmlElement.dispatchEvent(event);
}

export function element(nativeElement: HTMLElement, data: string): HTMLElement {
    return nativeElement.querySelector(byDataQa(data));
}

export function select(nativeElement: HTMLInputElement, data: string): void {
    nativeElement.value = data;
    simulateEvent('change', nativeElement);
}

export class TestUtils {
    private fixture: ComponentFixture<{}>;
    private nativeElement;
    private componentInstance;

    public static createUtils(fixture: ComponentFixture<{}>) {
        const instance = new TestUtils();
        instance.fixture = fixture;
        instance.nativeElement = fixture.nativeElement;

        return instance;
    }
}

export function elementInput(nativeElement: HTMLElement, data: string): HTMLInputElement {
    return nativeElement.querySelector(byDataQa(data));
}
