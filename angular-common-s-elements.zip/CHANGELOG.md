## Changelog

## [v0.15.1](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.15.1.tgz) (2019-05-09)

### Changed
- s-list-builder documentation

### Fixed
- Fixed styles for 'Cancel' and 'Add another' links in s-list-builder
- emoved unnecessary imports in s-list-builder


## [v0.15.0](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.15.0.tgz) (2019-05-08)
### Added
- added s-list-builder

### Changed
- changed s-select styles


## [v0.14.3](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.14.3.tgz) (2019-04-26)
### Changed
- removed border from dropdown options in s-select

### Fixed
- s-select dropdown icon export


## [v0.14.2](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.14.2.tgz) (2019-04-12)
### Changed
- log_format in nginx with logging service
- removed ts utils dependencies in elements


## [v0.14.1](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.14.1.tgz) (2019-04-12)
### Changed
- s-button--tertiary hover
- fixed ie compatibility in s-select


## [v0.14.0](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.14.0.tgz) (2019-04-11)
### Added
- s-accordion component
- s-telephone component
- tertiary button style
- auto-complete functionally for s-select component
- secure logo to s-header component

### Changed
- Refactored the functionally of the select component
- frontend logging documentation

### Fixed
- numeric directive (no spaces)


## [v0.13.0](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.13.0.tgz) (2019-03-15)
### Added
- s-frontend-logging service
- s-financial directive

### Changed
- error directive can not be applied to the s-title 

### Fixed
- s-title to have 2 different custom error messages


## [v0.12.1-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.12.1-rc.tgz) (2019-03-04)
### Fixed
- s-paf component fix for results box to remain visible when an option is clicked on

## [v0.12.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.12.0-rc.tgz) (2019-02-18)
### Added
- s-dob

## [v0.11.1-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.11.1-rc.tgz) (2019-02-07)
### Fixed
- reverted: error style avoiding elements shift (move up and down) in the layout.

## [v0.11.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.11.0-rc.tgz) (2019-01-31)
### Added
- s-radio-group component
- s-title component
- s-error.css
- tslint as part of building process

### Changed
- error style avoiding elements shift (move up and down) in the layout.
- disable s-select using ControlValueAccessor

### Fixed
- Error message directive on reactive forms so it performs the same way that in template driven. Triggered an initial status change so error will be there from the start.
- Error message directive delayed a bit so other directives such as label come first. So they get along now.


## [v0.10.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.10.0-rc.tgz) (2019-01-23)
### Added
- s-paf component 
- s-paf service
- s-yes-no-input has a mobile view on screens up to 576px
- s-yes-no-input uses error-message directive

### Changed
- s-yes-no-input now supports keyboard interaction (left-right arrows, tab and enter).
- s-yes-no-input supports template forms as well.

### Fixed
- crash in label directive in case there are other validations than just required.
- label directive now works with reactive forms as well.

### Removed
- s-yes-no-input error handling and question text (now handled by label directive)


## [v0.9.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.9.0-rc.tgz) (2019-01-22)
### Changed
- Label Directive, became a functioning label, it has met accessibility.

### Added
- Label.css styles ready to be imported in each component that uses label directive.


## [v0.8.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.8.0-rc.1.tgz) (2019-01-16)
### Changed
- Error Directive can take a string or an object to show errors conditionally
- First-name and Last-name have the property of required validation by default
- Error Directive will create a sibling error container instead of a child, if no container is specified


## [v0.7.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.7.0-rc.1.tgz) (2010-01-14)
- **renamed** s-breadcrumbs to s-progress-indicator
- s-progress-indicator has a mobile view on screens up to 576px


## [v0.6.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.6.0-rc.1.tgz) (2018-11-19)
- added component file uploader
- added s-link style
- added s-button 'alike components' style


## [v0.5.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.5.0-rc.1.tgz) (2018-11-13)
- added type property in s-input


## [v0.4.0-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.4.0-rc.1.tgz) (2018-10-31)
- added s-yes-no-input component


## [v0.3.3-rc](https://nexus.almuk.santanderuk.corp/repository/npm-releases/@portland/angular-common-s-elements/-/angular-common-s-elements-0.3.3-rc.1.tgz) (2018-10-31)
- removed required asterisk from s-checkbox
- increased font-size from 11px to 1rem in inputs like components
