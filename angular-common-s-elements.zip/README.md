# Angular Common S Elements

This project provides some common angular elements that can be imported and used over multiple projects. Following this [link](https://angular-s-elements-catalogue-bank-account-dev.appls.cap1.paas.gsnetcloud.corp) you can see them in action.

## Using The Library In Your Project

The following steps illustrate how to import the library into your project.

### Add Dependency

Firstly, you will need to add the library as a dependancy. The easiest way to do this is to add the following line in your _package.json_, in the *"devDependencies"* section:

```javascript
"@portland/angular-common-s-elements": "version",
```

Check [nexus](https://nexus.almuk.santanderuk.corp/#browse/search/npm=name.raw%3Dangular-common-s-elements) for the different versions, and replace "version" in the above code with your desired version. We follow the [semver](https://semver.org) reference.

If this is unsuccessful, then try removing the proxy settings from your .npmrc file and setting the npm registry to the Santander one: *https://nexus.almuk.santanderuk.corp/repository/npm-group/*

If all else fails, you can download the package directly from nexus, and unzip the contents into the *node_modules/@portland/angular-s-common-elements* folder.


### Assets

The library contains assets. To access these, add the following block into your angular.json:

```javascript
"assets": [
  "src/favicon.ico",
  "src/assets",
  { 
    "glob": "**/*", 
    "input": "node_modules/@portland/angular-common-s-elements/assets/", 
    "output": "assets" 
  }
],
```

This states that the assets folder is located at *node_modules/@portland/angular-common-s-elements/assets/*. If there is an error saying that the dependency cannot be found, it might be because your package structure does not match this line.

### Import

To import the modules themselves, add the following lines into the module file:

```javascript
import { aPieceOfLibrary } from '@portland/angular-common-s-elements';
    @NgModule({
      ...
      imports: [
        ...
        aPieceOfLibrary,
        ...
      ],
      ...
    })
```

*aPieceOfLibrary* can be either a specific part, several parts, or the entirity of the library. So if we wanted to use SCheckboxComponentModule, for example, we would write:

```javascript
import { SCheckboxComponentModule } from '@portland/angular-common-s-elements';
    @NgModule({
      ...
      imports: [
        ...
        SCheckboxComponentModule,
        ...
      ],
      ...
    })
```

Once the dependency has successfully been imported, you can then use the imported elements freely, as shown below.

```html
<s-checkbox>Agree</s-checkbox>
```

You should now have a working Santander check box in your application!

## Contributing

You can participate in this project in two ways: developing, or raising improvements or defects.

### Open an Issue

To raise improvement or defects, firstly, you should open an [issue](https://uk-gitlab.almuk.santanderuk.corp/portland-banking/portland-bill/pulpit-rock/angular-common-s-elements/issues) in the angular-common-s-elements [Gitlab](https://uk-gitlab.almuk.santanderuk.corp/portland-banking/portland-bill/pulpit-rock/angular-common-s-elements) project.

### Develop

If you want to add to the library, you must create a merge request at the [Gitlab](https://uk-gitlab.almuk.santanderuk.corp/portland-banking/portland-bill/pulpit-rock/angular-common-s-elements) project against the [_master_](https://uk-gitlab.almuk.santanderuk.corp/portland-banking/portland-bill/pulpit-rock/angular-common-s-elements/tree/master) branch. 
In case you don't have permission to push to this repository you can either ask for permission (raising an issue) or fork this repo.

In the event of opening a merge request, your change (if tests went ok) will be available in [this link](https://angular-s-elements-catalogue-mr-bank-account-dev.appls.cap1.paas.gsnetcloud.corp/) (please note that if you fork this repo you will miss this feature). Please be aware that this space is unique for all merge requests that are open and so if you are working on one, and it is not complete, please mark your merge request [as WIP](https://docs.gitlab.com/ee/user/project/merge_requests/work_in_progress_merge_requests.html). This way you will not affect anybody elses work until completion. 

#### JIRA & User Stories

Since JIRA is not very convenient for sharing the stories between teams, we planned to use git issue board to track the progress (since every developer already have access).

We strongly recommend that you create an integration story in your project JIRA boards for tracking the issue within your team, which will be replica of the open issue just created in GitLab.

You have to progress the story into the right column in your workflow and as well as in the [Gitlab board](https://uk-gitlab.almuk.santanderuk.corp/portland-banking/portland-bill/pulpit-rock/angular-common-s-elements/boards).
Right now we have the following statuses in the board: 
1. **Backlog**: open issue for future development
2. **In Progress**: Being developed by some team
3. **Code Review**: Merge request (not marked WIP) has been sent and the community is reviewing it
4. **Release Candidate**: Approved by the community and release candidate created with version _x.x.x-rc(x)_ which can be tested in your real application
5. **Closed**: Deployed as part of release and available for the community to use with version _x.x.x_

Finally, please add a line with the name, current development status, and a little description of the element you will be working on, so users can search in [Confluence](https://confluence.almuk.santanderuk.corp/display/PORTLAND/Angular+common+s+elements) to know the available elements.

#### Definion of Done (DoD)

Below are the steps you should follow when developing a proposed change to the project:

1. **_Document_**
Create suitable documentation and produce a demo of the proposed change.

2. **_Test_**
Thoroughly test the change.

3. **_Code_**
Develop the change you would like to make.

4. **_Export_**
Export the change as an individual module in *public_api.ts* (standalone), and also include it as part of a bigger module. (e.g. s-checkbox is part of a form module).

Following these steps you won't need to actually test your element in a real application to see if it works, but if you still need that, you can follow these steps for local development:

1. Build angular-common-s-elements library in your local.
2. Using [npm link](https://docs.npmjs.com/cli/link) feature, the library module in your application *node_modules* is substituted by your built library in above step.
