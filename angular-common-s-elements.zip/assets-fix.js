#!/usr/bin/env node

const fs = require('fs');
const glob = require('glob');
const path = require('path');

const urlSlashRegexp = /url\(("?)\//;
function fixCSSfile(filePath) {
  let modified = false;
  var fixedCss = fs.readFileSync(filePath, 'utf-8')
    .split('\n')
    .map(line => {
      if (urlSlashRegexp.test(line)) {
        modified = true;
        return line.replace(urlSlashRegexp, 'url($1')
      } else {
        return line
      }
    })
    .join('\n');
  if (modified) {
    fs.writeFileSync(filePath, fixedCss, 'utf-8');
  }
};


function copyFileSync(source, target) {
  var targetFile = target;

  // if target is a directory a new file with the same name will be created
  if (fs.existsSync(target)) {
    if (fs.lstatSync(target).isDirectory()) {
      targetFile = path.join(target, path.basename(source));
    }
  }

  fs.writeFileSync(targetFile, fs.readFileSync(source));
}

function copyFolderRecursiveSync(source, target) {
  var files = [];

  // check if folder needs to be created or integrated
  var targetFolder = path.join(target, path.basename(source));
  if (!fs.existsSync(target)) {
    fs.mkdirSync(target);
  }
  if (!fs.existsSync(targetFolder)) {
    fs.mkdirSync(targetFolder);
  }

  // copy
  if (fs.lstatSync(source).isDirectory()) {
    files = fs.readdirSync(source);
    files.forEach(function (file) {
      var curSource = path.join(source, file);
      if (fs.lstatSync(curSource).isDirectory()) {
        copyFolderRecursiveSync(curSource, targetFolder);
      } else {
        copyFileSync(curSource, targetFolder);
      }
    });
  }
}

// work in a safe environment
copyFolderRecursiveSync('projects', 'tmp');

// change paths in ng-package.prod.json so distribution folder is on root level
const ngPackageProdPath = 'tmp/projects/@portland/angular-common-s-elements/ng-package.prod.json';
fs.writeFileSync(
  ngPackageProdPath,
  fs.readFileSync(ngPackageProdPath, 'utf-8')
    .replace('"$schema": "', '"$schema": "../')
    .replace('"dest": "', '"dest": "../'),
  'utf-8'
  );

// fix css urls
const basePath = 'tmp/projects/@portland/angular-common-s-elements/src'
glob(`${basePath}/**/*.{css,scss}`, (err, files) => {
  files
    .filter(file => !file.startsWith(`${basePath}/assets`))
    .forEach(fixCSSfile)
});
