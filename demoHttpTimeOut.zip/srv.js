const express = require('express')
const app = express()
const port = 3000

app.get('/', async (req, res) => {
    console.log('Init '+ req.query.sleep + ' seg.');
    
    await timeout(parseInt(req.query.sleep, 10)  * 1000);
    console.log('End ' + req.query.sleep + ' seg.');
    res.send({val:'Hello World!',sleep: req.query.sleep + ' seg.'});

})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))



function timeout(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
