import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';


import { timeout, catchError } from 'rxjs/operators';
import { of } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent  {
  time = {sec: 0, server: 60, front: 90 };
  result = '';
  msg = '';
  private _timer: any;
  constructor(private http: HttpClient) {}


  onSubmit() {
    this.time.sec = 0;
    this.send();
  }


  private send() {
    this.initTimer();

    this.http.get(`http://localhost:3000/?sleep=${this.time.server}`)
    .pipe(
      timeout(this.time.front * 1000),
      catchError(e => {
        console.log('obj');
        // do something on a timeout
        return of(null);
      })
    )
    .subscribe(obj => {
      // correct response if obj not null
      if (!!obj) {
        this.msg = 'Result in ' + this.time.sec + 'seg.';
      } else {
        this.msg = 'TimeOut in ' + this.time.sec + 'seg.';
      }
      this.stopTimer();
      this.result = JSON.stringify(obj) ;
    });
  }


  private initTimer() {
    this.result = '';
    this.msg = '';
    this._timer = setInterval(() => {
      this.time.sec ++;
    }, 1000);
  }
  private stopTimer() {
    clearInterval(this._timer);
  }
}
